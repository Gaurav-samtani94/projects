const express = require('express');
const authMiddleware = require('../../apps/middleware/auth.js');
const Router = express.Router();
const userController = require('../../apps/controllers/UserController');
const TenderController = require('../../apps/controllers/tender/TenderController');
const TenderListcontroller = require('../../apps/controllers/tender/TenderListcontroller');
const EMDController = require('../../apps/controllers/finance/EMDController');
const BGController = require('../../apps/controllers/finance/BGController');
const TendercycleController = require('../../apps/controllers/tender_cycle/TendercycleController');
const CronJobController = require('../../apps/controllers/CronJobController');
const authMiddlewareadmin = require('../middleware/adminauth');
const MasterController = require("../controllers/master/MasterController");
const RoleController = require("../controllers/master/RoleController");
const CompanyController = require("../controllers/master/CompanyController");
const DesignationController = require("../controllers/master/DesignationController");
const DoctrolController = require('../controllers/doctrol/DoctrolController.js')
const ProspectiveController = require('../controllers/tender/ProspectiveController')
const departmentController = require("../controllers/master/DepartmentController");
const JobGradeController = require('../../apps/controllers/master/JobGradeController');
const WishlistController = require('../controllers/master/WishlistController');
const TenderReminderController = require('../controllers/tender/TenderReminderController');
const WidgetController = require('../controllers/master/WidgetController');
const ProjectComptiterController = require('../controllers/tender/ProjectComptiterController')
const ProjecttodoController = require("../controllers/project_todo/ProjecttodoController");
const Competitorcontroller = require('../controllers/tender/CompetitorController');
const MenuController = require('../controllers/roleandpermission/MenuController');
const MenuPermissionController = require('../controllers/roleandpermission/MenuPermissionController');
const MeetingController = require('../controllers/meeting/MeetingController')
const DashboardController = require('../controllers/DashboardController');
const FinancialYearController = require('../controllers/siteconfig/FinancialYearController');
const SetConfigrationController = require('../controllers/siteconfig/SetConfigrationController');
const ActionPermController = require('../controllers/roleandpermission/ActionPermController');
const WidgetPermController = require('../controllers/roleandpermission/WidgetPermController');
const ChatController = require('../controllers/chats/ChatController');
const ContactusController = require('../controllers/master/ContactusController')
const TodoController = require('../controllers/todo/TodoController');
const DocumentShareController = require('../controllers/DocumentShareController');
const TeamrequisitionController = require('../controllers/requisition/Team_requisitionController');
const ProjectInfocontroller = require('../controllers/tender/Projectinfocontroller');
const TemplateFilterController = require('../controllers/tender/TemplateFilterController');
const TenderDetailsRequestController = require('../controllers/tender/TenderDetailsRequestController');
const MeetingMomController = require('../controllers/meetingMom/MeetingMomController');
const TenderCycleTrashController = require('../controllers/tender_cycle/TenderCycleTrashController');
const TenderReqReplyController = require('../controllers/tender/TenderReqReplyController')
const FactsheetController = require('../controllers/factsheet/FactsheetController');
const ReqNegotiationTeamsController = require('../controllers/requisition/ReqTeamsController');
const NotificationController = require('../controllers/NotificationHistoryController.js');
const GenralDoctroalController = require('../controllers/general_doctrol/GenralDoctroalController');
const ProjectDoctroalController = require('../controllers/project_doctrol/ProjectDoctrolController');
const TenderTrashController = require('../../apps/controllers/tender/TenderTrashListController')
const TenderCycleMoveHistoryController = require('../../apps/controllers/tender_cycle/TenderCycleMoveHistoryController')
const ActionPermissionController = require('../controllers/Menu/ActionPermissionController')
const MenuMasterController = require('../controllers/Menu/MenuMasterController')
const admin_configure_controller = require('../controllers/Admin_configuration/admin_configure_controller.js')
const SeoController = require('../controllers/SeoController')
const TendernewAddcontroller = require('../controllers/tender/TendernewAddcontroller')
const DiskLimitController = require('../controllers/DiskLimitController')
const TenderUpdateControoler = require('../controllers/tenderupdate/TenderUpdateControoler')

//update by tc growthgrids route
//const GrowthgridApi = require('../controllers/master/Controller')
// Create a new user 
Router.post('/user-login', userController.userlogin); // Use userController.createUser
Router.post('/user-add', authMiddleware, userController.useradd);
Router.get('/users-list-all', authMiddleware, userController.ListAllUsers);
Router.post('/user-details-edit', authMiddleware, userController.userdetails);
Router.put('/user-details-update', authMiddleware, userController.userdetails_update);
Router.post('/change-password', authMiddleware, userController.changepassword);
Router.post('/user-logout', authMiddleware, userController.userlogout);
Router.post('/user-activity-add', authMiddleware, userController.userhistory);
Router.post('/user-history-list', authMiddleware, userController.tnderuserhistotry);


//ceterlize master routes by abhimanyu start
Router.get('/country-list', authMiddleware, MasterController.GetcountryList);
Router.post('/state-list', authMiddleware, MasterController.GetstateList);
Router.post('/city-list', authMiddleware, MasterController.GetcityList);
Router.get('/continent-list', authMiddleware, MasterController.GetcontinentList);
Router.post('/region-list', authMiddleware, MasterController.GetregionList);
Router.get('/currency-list', authMiddleware, MasterController.GetcurrencyList);

Router.get('/prefix-list', authMiddleware, MasterController.GetprefixList);
Router.post('/prefix-add', authMiddleware, MasterController.Addprefix);
Router.post('/prefix-edit', authMiddleware, MasterController.Editprefix);
Router.put('/prefix-update', authMiddleware, MasterController.updateprefix);
Router.delete('/prefix-delete', authMiddleware, MasterController.deleteprefix);




Router.get('/language-list', authMiddleware, MasterController.GetlanguageList);
Router.get('/nationality-list', authMiddleware, MasterController.GetnationlityList);
Router.get('/timezones-list', authMiddleware, MasterController.GettimezonesList);
Router.get('/gender-list', authMiddleware, MasterController.GetgenderList);
Router.get('/bloodgroup-list', authMiddleware, MasterController.GetbloodgroupList);
Router.get('/empstatus-list', authMiddleware, MasterController.GetempstatusList);

Router.post('/country-add', authMiddleware, MasterController.Addcountry);
Router.post('/state-add', authMiddleware, MasterController.AddState);
Router.post('/city-add', authMiddleware, MasterController.AddCity);
Router.post('/region-add', authMiddleware, MasterController.Addregion);
Router.post('/currency-add', authMiddleware, MasterController.Addcurrency);

Router.post('/empstatus-add', authMiddleware, MasterController.AddEmpstatus);

Router.post('/language-add', authMiddleware, MasterController.Addlanguage);
Router.post('/continent-add', authMiddleware, MasterController.AddContinent);
Router.post('/timezone-add', authMiddleware, MasterController.AddTimezone);
//ceterlize master routes by abhimanyu end
Router.post('/nationality-add', authMiddleware, MasterController.Addnationality);
Router.post('/gender-add', authMiddleware, MasterController.Addgender);
Router.post('/bloodgroup-add', authMiddleware, MasterController.Addbloodgroup);


/***************************Start Durgesh Tender Route Define*****************/
//tender scope 
Router.post('/tenderscope-add', authMiddleware, MasterController.addtenderscope);
Router.post('/tenderscope-edit', authMiddleware, MasterController.edittenderscope);
Router.put('/tenderscope-update', authMiddleware, MasterController.updatetenderscope);
Router.delete('/tenderscope-delete', authMiddleware, MasterController.deletetenderscope);
Router.get('/tenderscope-list', authMiddleware, MasterController.tenderscopelist);


//tender status 
Router.post('/tenderstatus-add', authMiddleware, MasterController.addtenderstatus);
Router.post('/tenderstatus-edit', authMiddleware, MasterController.edittenderstatus);
Router.put('/tenderstatus-update', authMiddleware, MasterController.updatetenderstatus);
Router.delete('/tenderstatus-delete', authMiddleware, MasterController.deletetenderstatus);
Router.get('/tenderstatus-list', authMiddleware, MasterController.tenderstatuslist);


//tender Sector 
Router.post('/tendersector-add', authMiddleware, MasterController.addtendersector);
Router.post('/tendersector-edit', authMiddleware, MasterController.edittendersector);
Router.put('/tendersector-update', authMiddleware, MasterController.updatetendersector);
Router.delete('/tendersector-delete', authMiddleware, MasterController.deletetendersector);
Router.get('/tendersector-list', authMiddleware, MasterController.tendersectorlist);

//tender Sub Sector 
Router.post('/tendersubsector-add', authMiddleware, MasterController.addtendersubsector);
Router.post('/tendersubsector-edit', authMiddleware, MasterController.edittendersubsector);
Router.put('/tendersubsector-update', authMiddleware, MasterController.updatetendersubsector);
Router.delete('/tendersubsector-delete', authMiddleware, MasterController.deletetendersubsector);
Router.post('/tendersubsector-list', authMiddleware, MasterController.tendersubsectorlist);


//tender Sub Scope 
Router.post('/tendersubscope-add', authMiddleware, MasterController.addtendersubscope);
Router.post('/tendersubscope-edit', authMiddleware, MasterController.edittendersubscope);
Router.put('/tendersubscope-update', authMiddleware, MasterController.updatetendersubscope);
Router.delete('/tendersubscope-delete', authMiddleware, MasterController.deletetendersubscope);
Router.post('/tendersubscope-list', authMiddleware, MasterController.tendersubscopelist);

//tender Service 
Router.post('/tenderservice-add', authMiddleware, MasterController.addtenderservice);
Router.post('/tenderservice-edit', authMiddleware, MasterController.edittenderservice);
Router.put('/tenderservice-update', authMiddleware, MasterController.updatetenderservice);
Router.delete('/tenderservice-delete', authMiddleware, MasterController.deletetenderservice);
Router.get('/tenderservice-list', authMiddleware, MasterController.tenderservicelist);

//tender Phase 
Router.post('/tenderphase-add', authMiddleware, MasterController.addtenderphase);
Router.post('/tenderphase-edit', authMiddleware, MasterController.edittenderphase);
Router.put('/tenderphase-update', authMiddleware, MasterController.updatetenderphase);
Router.delete('/tenderphase-delete', authMiddleware, MasterController.deletetenderphase);
Router.get('/tenderphase-list', authMiddleware, MasterController.tenderphaselist);

//tender Consortium Type
// Router.post('/tenderconsortium-add', authMiddlewareadmin, MasterController.addtenderconsortium);
// Router.post('/tenderconsortium-edit', authMiddlewareadmin, MasterController.edittenderconsortium);
// Router.put('/tenderconsortium-update', authMiddlewareadmin, MasterController.updatetenderconsortium);
// Router.delete('/tenderconsortium-delete', authMiddlewareadmin, MasterController.deletetenderconsortium);
Router.get('/tenderconsortium-list', authMiddleware, MasterController.tenderconsortiumlist);

//tender Client
Router.post('/tenderclient-add', authMiddleware, MasterController.addtenderclient);
Router.post('/tenderclient-edit', authMiddleware, MasterController.edittenderclient);
Router.put('/tenderclient-update', authMiddleware, MasterController.updatetenderclient);
Router.delete('/tenderclient-delete', authMiddleware, MasterController.deletetenderclient);
Router.get('/tenderclient-list', authMiddleware, MasterController.tenderclientlist);


//tender Funding Agency
Router.post('/tenderfundingagency-add', authMiddleware, MasterController.addtenderfundingagency);
Router.post('/tenderfundingagency-edit', authMiddleware, MasterController.edittenderfundingagency);
Router.put('/tenderfundingagency-update', authMiddleware, MasterController.updatetenderfundingagency);
Router.delete('/tenderfundingagency-delete', authMiddleware, MasterController.deletetenderfundingagency);
Router.get('/tenderfundingagency-list', authMiddleware, MasterController.tenderfundingagencylist);


//fresh-live tender
Router.post('/newtender-add', authMiddleware, TenderController.addTender);
Router.post('/tendernumber-generate', authMiddleware, TenderController.addtendernumbergenrated);
Router.post('/tender-assign-manager', authMiddleware, TenderController.addtndrcycleassignmanagerbtn);
Router.post('/tenderdetail-edit', authMiddleware, TenderController.edittenderdetail);
Router.put('/tenderdetail-update', authMiddleware, TenderController.updateTenderdetail);
Router.post('/tenderdoc-add', authMiddleware, TenderController.addTenderDoc);
Router.post('/tender-list', authMiddleware, TenderListcontroller.tenderlist);
Router.post('/tender-docs-delete', authMiddleware, TenderController.DeleteTenderDoc);
Router.post('/add-tender-list', authMiddleware, TendernewAddcontroller.tenderlist);



//mis cycle route here by durgesh(12-04-2023)
Router.get('/mis_cycle_list', authMiddleware, TenderController.misleftlist);
Router.get('/tndrgentype-list', authMiddleware, TenderController.gettndrgeneratedtype);
Router.post('/mis-tender-list', authMiddleware, TenderController.mistenderlist);
Router.post('/mistendercycleinactionbtn-list', authMiddleware, TenderController.mistndrcycleinactionlist);
Router.post('/mistndrcyclejumpdbtn-bulk', authMiddleware, TenderController.addmistndrcyclejumpmultipledbtn);
Router.post('/mistndrcyclejumpdbtn-single', authMiddleware, TenderController.addmistndrcyclejumpsingledbtn);
Router.post('/mis-tndr-cycle-list-next', authMiddleware, TenderController.mistndcyclenext);
Router.get('/mis-tndr-cycle-list-all', authMiddleware, TenderController.mistndcycleall);
Router.get('/mistendercycle-assignbtn-list', authMiddleware, TenderController.mislistassignbtn);


//tender cycle
Router.get('/tenderconsortiumtype-list', authMiddleware, MasterController.tenderconsortiumtypelist);
Router.get('/tenderbdrole-list', authMiddleware, MasterController.tenderbdrolelist);
// Router.get('/tendercycleinaction-list-all', authMiddleware, MasterController.tendercycleinactionlist);
Router.post('/tendercycleinactionbtn-add', authMiddleware, TenderController.addtndrcycleinactionbtn);
Router.post('/tendercycleinactionbtn-edit', authMiddleware, TenderController.edittndrcycleinactionbtn);
Router.put('/tendercycleinactionbtn-update', authMiddleware, TenderController.updatetndrcycleinactionbtn);
Router.delete('/tendercycleinactionbtn-delete', authMiddleware, TenderController.deletetndrcycleinactionbtn);
Router.post('/tendercycleinactionbtn-list', authMiddleware, TenderController.tndrcycleinactionlist);
Router.post('/tndrcyclemovedbtn-add', authMiddleware, TenderController.addtndrcyclemovedbtn);
Router.post('/bulkupdatetndrcycle-update', authMiddleware, TenderController.bulkupdatetndrcycle);



//set configration
Router.get('/set-configuration-list', authMiddleware, SetConfigrationController.ListSetconfig);

//EMD/Bid Security 
Router.post('/tenderemd-add', authMiddleware, EMDController.addtenderemd);
Router.post('/tenderemd-edit', authMiddleware, EMDController.edittenderemd);
Router.put('/tenderemd-update', authMiddleware, EMDController.updatetenderemd);
Router.delete('/tenderemd-delete', authMiddleware, EMDController.deletetenderemd);

//bank gurantee
Router.post('/bgbank-add', authMiddleware, BGController.addbgbank);
Router.post('/bgbank-edit', authMiddleware, BGController.editbgbank);
Router.put('/bgbank-update', authMiddleware, BGController.updatebgbank);
Router.delete('/bgbank-delete', authMiddleware, BGController.deletebgbank);
Router.get('/bgbank-list', authMiddleware, BGController.bgbanklist);

Router.post('/bgdetail-add', authMiddleware, BGController.addbgdetail);
Router.post('/bgdetail-edit', authMiddleware, BGController.editbgdetail);
Router.put('/bgdetail-update', authMiddleware, BGController.updatebgdetail);
Router.delete('/bgdetail-delete', authMiddleware, BGController.deletebgdetail);
Router.get('/bgdetail-list', authMiddleware, BGController.bgdetaillist);


Router.post('/bgontender-add', authMiddleware, BGController.assignbgontender);
Router.delete('/bgontender-delete', authMiddleware, BGController.deleteassignbg);
Router.post('/bgontender-list', authMiddleware, BGController.assignbgontenderlist);
/***************************End Durgesh Tender Route Define*****************/
//Code By Ash......
Router.post('/role-add', authMiddleware, RoleController.InsertUserRole);
Router.get('/role-list', authMiddleware, RoleController.ListUserRole);
Router.delete('/role-delete', authMiddleware, RoleController.DeleteUserRole);
Router.post('/role-edit', authMiddleware, RoleController.GetByIDUserRole);
Router.put('/role-update', authMiddleware, RoleController.UpdateByIDUserRole);

Router.get('/company-list', authMiddleware, CompanyController.ListUserCompany);
Router.post('/company-add', authMiddleware, CompanyController.InsertUserCompany);
Router.delete('/company-delete', authMiddleware, CompanyController.DeleteUserCompany);
Router.post('/company-edit', authMiddleware, CompanyController.GetByIDUserCompany);
Router.put('/company-update', authMiddleware, CompanyController.UpdateByIDUserCompany);

Router.post('/designation-add', authMiddleware, DesignationController.InsertUserDesignation);
Router.get('/designation-list', authMiddleware, DesignationController.ListUserDesignation);
Router.delete('/designation-delete', authMiddleware, DesignationController.DeleteUserDesignation);
Router.post('/designation-edit', authMiddleware, DesignationController.GetByIDUserDesignation);
Router.put('/designation-update', authMiddleware, DesignationController.UpdateByIDUserDesignation);
//End Code Ash...


// Department 
Router.post('/department-add', authMiddleware, departmentController.addDepartment);
Router.get('/department-list', authMiddleware, departmentController.departmentList);
Router.post('/department-edit', authMiddleware, departmentController.editDepartment);
Router.put('/department-update', authMiddleware, departmentController.updateDepartment);
Router.delete('/department-delete', authMiddleware, departmentController.deleteDepartment);

// Job Grade 
Router.post('/jobgrade-add', authMiddleware, JobGradeController.addJobGrade);
Router.get('/jobgrade-list', authMiddleware, JobGradeController.jobGradeList);
Router.post('/jobgrade-edit', authMiddleware, JobGradeController.editJobGrade);
Router.put('/jobgrade-update', authMiddleware, JobGradeController.updateJobGrade);
Router.delete('/jobgrade-delete', authMiddleware, JobGradeController.deleteJobGrade);

//business unit
Router.post('/businessunit-add', authMiddleware, MasterController.addbusinessunit);
Router.post('/businessunit-edit', authMiddleware, MasterController.editbusinessunit);
Router.put('/businessunit-update', authMiddleware, MasterController.updatebusinessunit);
Router.delete('/businessunit-delete', authMiddleware, MasterController.deletebusinessunit);
Router.get('/businessunit-list', authMiddleware, MasterController.unitbusinesslist);

// prospective routs
Router.post('/prospective-add', authMiddleware, ProspectiveController.AddProspectivetender);
Router.post('/prospective-list', authMiddleware, ProspectiveController.ListProspectivetender);
Router.post('/prospective-edit', authMiddleware, ProspectiveController.editProspectivetender);
Router.delete('/prospective-delete', authMiddleware, ProspectiveController.deleteProspectivetender);
Router.post('/prospective-update', authMiddleware, ProspectiveController.updateProspectivetender);
Router.post('/prospective-docs-delete', authMiddleware, ProspectiveController.prospectivedocsdelete);
Router.post('/prospective-docs-down', authMiddleware, ProspectiveController.prospectivedocsDown);
Router.post('/prospective-add-inTenders', authMiddleware, ProspectiveController.addProspectivetenderInMainTender);

//Start Code {Gaurav} 
// Wishlist
Router.post('/add-to-wishlist', authMiddleware, WishlistController.addToWishlist);
Router.post('/wishlist-list', authMiddleware, WishlistController.wishlist_List);
Router.delete('/wishlist-delete', authMiddleware, WishlistController.updateRemoveWishlistByCollectionId);
Router.get('/wishlist-privacy-list', authMiddleware, WishlistController.wishlistPrivacyList);
Router.post('/remove-wishlist', authMiddleware, WishlistController.removeWishList)


//Collection Wishlist
Router.post('/wishlistcollection-add', authMiddleware, WishlistController.addCollection);
Router.get('/wishlistcollection-list', authMiddleware, WishlistController.collectoinList);
Router.post('/wishlistcollection-edit', authMiddleware, WishlistController.getCollectionById);
Router.put('/wishlistcollection-update', authMiddleware, WishlistController.updateCollectionById);
Router.delete('/wishlistcollection-delete', authMiddleware, WishlistController.deleteCollectionById);

// Tender Reminder 
Router.post('/reminder-add', authMiddleware, TenderReminderController.addReminder);
Router.post('/reminder-list', authMiddleware, TenderReminderController.tenderReminderList);
Router.post('/reminder-edit', authMiddleware, TenderReminderController.getTenderReminderById);
Router.put('/reminder-update', authMiddleware, TenderReminderController.updateTenderReminderById);
Router.delete('/reminder-delete', authMiddleware, TenderReminderController.deleteTenderReminderById);
Router.post('/remove-reminder', authMiddleware, TenderReminderController.removeReminder)




// Widget Route
Router.post('/widget-add', authMiddleware, WidgetController.addWidget);
Router.get('/widget-list', authMiddleware, WidgetController.widgetList);
Router.post('/widget-edit', authMiddleware, WidgetController.editWidget);
Router.put('/widget-update', authMiddleware, WidgetController.updateWidget);
Router.delete('/widget-delete', authMiddleware, WidgetController.deleteWidget);

// On Going Data Dashboard
Router.post('/dashboardongoing-list', authMiddleware, DashboardController.getOnGoingData);
// Router.post('/dashboard-teamtask', authMiddleware, DashboardController.teamtasklist);
Router.post('/team-login-history', authMiddleware, DashboardController.teamloginhistory);
Router.post('/personal-calender-list', authMiddleware, DashboardController.personalCalender);
Router.get('/user-under-list', authMiddleware, DashboardController.getUsersUnderuser);

//Menu Master
Router.post('/menu-permission-add', authMiddleware, MenuPermissionController.addMenuPermission);
Router.get('/menu-permission-list', authMiddleware, MenuPermissionController.menuPermissionList);
Router.post('/menu-add', authMiddleware, MenuController.addMenuMaster);
Router.get('/menu-list', authMiddleware, MenuController.menuList);
Router.post('/menu-edit', authMiddleware, MenuController.editMenu);
Router.put('/menu-update', authMiddleware, MenuController.updateMenu);
Router.delete('/menu-delete', authMiddleware, MenuController.deleteMenu);

// Task Priority 
Router.get('/task-priority-list', authMiddleware, MasterController.GetTaskPriorityList);
Router.post('/task-priority-add', authMiddleware, MasterController.AddTaskPriority);
//End Code {Gaurav}


//Site Config API...
Router.get('/financialyear-list', authMiddleware, FinancialYearController.ListFinancialYear);
Router.post('/set-financialyear-upd', authMiddleware, FinancialYearController.SetFinancialYear);
Router.post('/set-lettercode-upd', authMiddleware, FinancialYearController.SetLetterCode);
Router.get('/configuration-list', authMiddleware, FinancialYearController.ConfigurationDetails);

//Role And Per Code By Ashh..
// Router.get('/get-actionperm', authMiddleware, ActionPermController.ActPermListAll);
// Router.post('/set-actionperm-onrole-upd', authMiddleware, ActionPermController.SetActionPermRole);
// Router.post('/get-actionperm-onrole', authMiddleware, ActionPermController.ActPermByRoleID);
// Router.post('/get-actionperm-onrole-module', authMiddleware, ActionPermController.ActPermByRoleAndModuleId);
Router.post('/user-history-list', authMiddleware, TenderController.tnderuserhistotry);
Router.post('/tender-scope-list', authMiddleware, TenderController.ListTenderScope_bycycleId);
Router.post('/tender-scope-by-tenderid', authMiddleware, TenderController.ListTenderScope);

Router.get('/widgets-list', authMiddleware, WidgetPermController.widgetList);
Router.post('/set-widgetsperm_onrole-upd', authMiddleware, WidgetPermController.SetWidgetsPermRole);
Router.delete('/widgetsperm_onrole-delete', authMiddleware, WidgetPermController.DelWidgetsPerm_onRole);
Router.post('/get-widgetsperm_onrole', authMiddleware, WidgetPermController.GetWidgetsListRole);
Router.get('/widgets_perm_onrole-list', authMiddleware, WidgetPermController.AllWidgetsListOnRole);


//Crown Job ...  Ash...
Router.post('/curl', authMiddleware, CronJobController.curl);
Router.get('/user-interlinking', CronJobController.UserInterlinking);
Router.get('/user-interlinked-merge', CronJobController.UserInterLinkedMerge);
Router.get('/user-tokenlinked-merge', CronJobController.UserTokenInterlinking);


//Chats rout start
Router.get('/chat-user-list', authMiddleware, ChatController.chatuserListBYCompany);
Router.post('/user-chating-list', authMiddleware, ChatController.userchatinglist);
Router.post('/user-chatgroup-create', authMiddleware, ChatController.createGroup);
Router.post('/user-chatgroup-edit', authMiddleware, ChatController.GroupEdit);
Router.put('/user-chatgroup-update', authMiddleware, ChatController.groupupdate);
Router.delete('/user-chatgroup-delete', authMiddleware, ChatController.groupdelete);
Router.get('/user-chatgroup-list', authMiddleware, ChatController.grouplist);
Router.post('/user-chatgroupmember-assign', authMiddleware, ChatController.userassignGroupmember);
Router.put('/user-chatgroupmember-update', authMiddleware, ChatController.userupdateGroupmember);
Router.post('/user-chatgroupmember-edit', authMiddleware, ChatController.userEditGroupmember);
Router.get('/user-chatgroupmember-list', authMiddleware, ChatController.userListGroupmember);
Router.post('/user-groupchatinglist-history', authMiddleware, ChatController.groupchatinghistory);
Router.post('/single-cahting-uploading-file', authMiddleware, ChatController.single_chating_file_upload);
Router.post('/group-cahting-uploading-file', authMiddleware, ChatController.group_chating_file_upload);
Router.get('/single-cahting-unread-list', authMiddleware, ChatController.singlecahtingunreadlist);
Router.post('/group-chat-userlist', authMiddleware, ChatController.groupchatuserlist);
Router.post('/get-group-user-list', authMiddleware, ChatController.chatgroupuser_list);
Router.post('/update-user-in-group', authMiddleware, ChatController.updateuseringroup);
Router.delete('/delete-user-in-group', authMiddleware, ChatController.delleteuseringroup);
Router.put('/update-grope-info', authMiddleware, ChatController.updategropeinfo);
//chats rout End


//To Do List Code By Ash..
Router.post('/todo-create-task', authMiddleware, TodoController.todo_create_task);
Router.post('/todo-edit-task', authMiddleware, TodoController.todo_edit_task);
Router.put('/set-task-upd', authMiddleware, TodoController.todo_update_task);

Router.post('/todo-update-srnumber-task', authMiddleware, TodoController.todo_update_srnumber_task);
Router.post('/list-todo-taskuser', authMiddleware, TodoController.list_task_user);
Router.post('/list-hastag-search', authMiddleware, TodoController.list_hastag_search);
//To Do Comments Code By Durgesh..
Router.post('/todocmt-add', authMiddleware, TodoController.addtodocmt);
Router.post('/todocmt-edit', authMiddleware, TodoController.edittodocmt);
Router.post('/todocmt-list', authMiddleware, TodoController.todocmtlist);


Router.post('/list-todo-scope-mytask', authMiddleware, TodoController.list_todo_scope_mytask);
Router.post('/list-todo-inprogress-mytask', authMiddleware, TodoController.list_todo_inporgress_mytask);
Router.post('/list-todo-done-mytask', authMiddleware, TodoController.list_todo_done_mytask);
// To Do routes code by Gaurav
Router.put('/task-scope-update', authMiddleware, TodoController.UpdateScopeByTaskId);
Router.get('/task-hashtag-list', authMiddleware, TodoController.ListHastagMaster);
Router.get('/task-scope-history-list', authMiddleware, TodoController.ListTaskScopeMove);
Router.get('/task-document-list', authMiddleware, TodoController.ListTaskDocs);
Router.post('/task-document-update', authMiddleware, TodoController.updateUploadTaskDocument);
Router.post('/task-document-add', authMiddleware, TodoController.uploadTaskDocument);
Router.post('/task-hashtag-search', authMiddleware, TodoController.searchHashtagInTask);

// Document Share code by Gaurav
Router.post('/document-share', authMiddleware, DocumentShareController.documentShare);
Router.post('/document-share-mail', authMiddleware, DocumentShareController.sendMail_template);
Router.get('/document-download/:id', DocumentShareController.attachmentDownload);
Router.post('/document-shared-list', authMiddleware, DocumentShareController.docSharedlist);

Router.post('/tender-scope-bulkupdate', authMiddleware, TenderController.tenderscopeupdate);

Router.post('/tender-scope-bulkupdate', authMiddleware, TenderController.tenderscopeupdate);
//Tender Cycle start ############################---------------------------
Router.post('/tender-scope-list-next', authMiddleware, TendercycleController.cyclelistnext);
Router.get('/tender-scope-list-next-all', authMiddleware, TendercycleController.cyclelistnextAll);
Router.post('/tndrcyclejumpdbtn-bulk', authMiddleware, TendercycleController.addtndrcyclejumpmultipledbtn);
Router.post('/tndrcyclejumpdbtn-single', authMiddleware, TendercycleController.addtndrcyclejumpsingledbtn);
Router.post('/tndrcycletrashdbtn-single', authMiddleware, TendercycleController.addtndrcycletrashsingledbtn);
Router.post('/tndrmovenext-scope', authMiddleware, TendercycleController.tndrmovenextscope);

//Tender Cycle End ############################---------------------------

Router.post('/modules-list', authMiddleware, MasterController.GetMasterModulesList);
Router.get('/all-modules-list', authMiddleware, MasterController.GetAllMasterModulesList);
Router.get('/service-provider-list', authMiddleware, MasterController.ServiceproviderList);

Router.post('/tendercycleinaction-list', authMiddleware, TendercycleController.tendercycleinactionlist);
Router.post('/tenderinactionbtn-update', authMiddleware, TendercycleController.tenderinactionbtnupdate);
Router.post('/tendercycletrack-history', authMiddleware, TendercycleController.tendercycletrackhistory);
Router.post('/tender-comment-list', authMiddleware, TenderController.tenderCommentList);
Router.post('/tndrassign-consortium', authMiddleware, TendercycleController.tndrassignconsortium);
Router.get('/tender-cycle-all', authMiddleware, TendercycleController.tendercyclelAll);

//s Todo Projet List
Router.post('/project-todo-create-task', authMiddleware, ProjecttodoController.project_todo_create_task);
Router.post('/project-todo-edit-task', authMiddleware, ProjecttodoController.project_todo_edit_task);
Router.post('/project-todo-update-task', authMiddleware, ProjecttodoController.project_todo_update_task);
Router.post('/project-todo-todoscope-list', authMiddleware, ProjecttodoController.project_list_todo_scope_mytask);
Router.post('/project-todo-improgressscope-list', authMiddleware, ProjecttodoController.project_list_todo_inporgress_mytask);
Router.post('/project-todo-donescope-list', authMiddleware, ProjecttodoController.project_list_todo_done_mytask);
Router.post('/project-todo-document-add', authMiddleware, ProjecttodoController.projectuploadTaskDocument);
Router.post('/project-todo-taskuserlist-list', authMiddleware, ProjecttodoController.peoject_list_task_user);
Router.post('/project-todo-hastag-search', authMiddleware, ProjecttodoController.project_list_hastag_search);
Router.post('/project-todo-docs-list', authMiddleware, ProjecttodoController.project_ListTaskDocs);
Router.post('/project-todo-scope-update', authMiddleware, ProjecttodoController.projectUpdateScopeByTaskId);
Router.post('/project-todo-comment-list', authMiddleware, ProjecttodoController.TenderTodoCmtList);
Router.post('/project-todo-task-scope-update', authMiddleware, ProjecttodoController.UpdateScopeByTaskIdTenderId);


//Doctroll
Router.get('/doctrol-list', authMiddleware, DoctrolController.doctrolFolderList);
Router.delete('/doctrol-delete', authMiddleware, DoctrolController.doctrolFolderDelete);
Router.post('/doctrol-add', authMiddleware, DoctrolController.DoctrolAdd);
Router.post('/doctrol-edit', authMiddleware, DoctrolController.DoctrolEdit);
Router.put('/doctrol-update', authMiddleware, DoctrolController.UpdateDoctrol);

//doctroll main
Router.post('/doctrol-main-list', authMiddleware, DoctrolController.DoctrolmainList);
Router.post('/doctrol-main-add', authMiddleware, DoctrolController.DoctrolmainAdd);
Router.delete('/doctrol-main-delete', authMiddleware, DoctrolController.DoctrolmainDelete);
// Router.put('/doctrol-main-update', authMiddleware, DoctrolController.DoctrolmainUpdate)

//projec details
Router.post('/project-info-data', authMiddleware, ProjectInfocontroller.getProjectDetails);
Router.put('/project-info-date-update', authMiddleware, ProjectInfocontroller.updatetenderdate);
Router.put('/project-info-emd-update', authMiddleware, ProjectInfocontroller.updatetenderEmd);
Router.put('/project-info-feeinfo-update', authMiddleware, ProjectInfocontroller.updatetenderFEEinfo)
Router.put('/project-info-otherdata-update', authMiddleware, ProjectInfocontroller.updatetenderOtherData)
Router.post('/project-info-cover-add', authMiddleware, ProjectInfocontroller.addtendercoverInfo)
Router.put('/project-info-cover-update', authMiddleware, ProjectInfocontroller.updatetendercoverInfo)
Router.delete('/project-info-cover-delete', authMiddleware, ProjectInfocontroller.deletendercoverInfo)



// Tender Geneate Ids
Router.post('/no-generate-prefix-add', authMiddleware, TenderController.AddNoGeneratePrefix);
Router.get('/no-generate-prefix-list', authMiddleware, TenderController.listNoGeneratePrefix);
Router.post('/assign-tender-generate-id', authMiddleware, TenderController.AssignTenderGeneratedIds);
Router.get('/tender-gen-types', authMiddleware, TenderController.tenderGenTypes);
Router.post('/last-tender-gen-id', authMiddleware, TenderController.lastTenderGenerateId);
Router.post('/assign-manager-onTender', authMiddleware, TenderController.tenderAssignManager);
Router.get('/bd-role-list', authMiddleware, TenderController.bdRolelist);
Router.post('/assign-manager-onTender-list', authMiddleware, TenderController.tenderAssignMngrlist);

//===================================================Comptitor and Consortium route of tender detail page===================================//
Router.post('/companylist-competitor', authMiddleware, ProjectComptiterController.companyjvslist);
Router.get('/companylist-all', authMiddleware, ProjectComptiterController.companyverifylist);
Router.delete('/tndrcompany-delete', authMiddleware, ProjectComptiterController.DeleteTndrCompany);
Router.post('/tndrcompany-edit', authMiddleware, ProjectComptiterController.GetByIDTndrCompany);
Router.put('/tndrcompany-update', authMiddleware, ProjectComptiterController.UpdateByIDTndrCompany);
Router.post('/competitor-company-assign', authMiddleware, ProjectComptiterController.comptitorAssignonProject);
Router.post('/competitor-company-assign-list', authMiddleware, ProjectComptiterController.comptitorAssignonProjectListing);
Router.post('/competitor-company-assign-Edit', authMiddleware, ProjectComptiterController.comptitorAssignonProjectEdit);
Router.delete('/competitor-company-assign-delete', authMiddleware, ProjectComptiterController.comptitorAssignonProjectdelete);
Router.put('/competitor-company-assign-update', authMiddleware, ProjectComptiterController.comptitorAssignonProjectupdate);


Router.post('/centerlize-company-add', authMiddleware, ProjectInfocontroller.Addnewcompany)
Router.put('/update-consortium', authMiddleware, ProjectInfocontroller.addtenderparnercompany)
Router.post('/consortium-company-list', authMiddleware, ProjectInfocontroller.getconsortiumcompanydata)
Router.get('/consortium-companies', authMiddleware, ProjectInfocontroller.getconsortiumcompanies)
Router.post('/assign-consortium-companies-list', authMiddleware, ProjectInfocontroller.assignconsortiumcompanielist)


Router.put('/comp-weightage-update', authMiddleware, Competitorcontroller.updatetendercompweightage);
Router.post('/comp-list', authMiddleware, Competitorcontroller.tendecomplist);
Router.post('/comp-score-edit', authMiddleware, Competitorcontroller.edittendercompscore);
Router.post('/comp-weigtage-edit', authMiddleware, Competitorcontroller.edittendercompweigtage);
Router.put('/comp-score-update', authMiddleware, Competitorcontroller.updatetendercompscore);
Router.put('/comp-tech-marks-update', authMiddleware, Competitorcontroller.updatetendercomptechmarks);
Router.put('/comp-fin-marks-update', authMiddleware, Competitorcontroller.updatetendercompfinmarks);
Router.put('/comp-total-marks-update', authMiddleware, Competitorcontroller.updatetendercomptatalmarks);
Router.put('/comp-rank-update', authMiddleware, Competitorcontroller.updatetendercomprank);
//===================================================Comptitor and Consortium route of tender detail page===================================//



// Tender Filter Template
Router.post('/add-filter-template', authMiddleware, TemplateFilterController.addTemplateFilter);
Router.put('/update-filter-template', authMiddleware, TemplateFilterController.updateTemplateFilter);
Router.put('/delete-filter-template', authMiddleware, TemplateFilterController.deleteTemplateFilter);
Router.post('/list-filter-template', authMiddleware, TemplateFilterController.listTemplateFilter);
Router.post('/template-list', authMiddleware, TemplateFilterController.listTemplates);

//tender details request
Router.post('/add-request-tender-details', authMiddleware, TenderDetailsRequestController.tenderRequestAdd);
Router.put('/update-request-tender-details', authMiddleware, TenderDetailsRequestController.tenderRequestUpdate);
Router.post('/get-requests--by-tenderId', authMiddleware, TenderDetailsRequestController.tenderRequestEdit);
Router.post('/list-requests-tender-details', authMiddleware, TenderDetailsRequestController.tenderRequestList);
Router.delete('/delete-requests-tender-details', authMiddleware, TenderDetailsRequestController.tenderRequestDelete);
//tender details request
Router.get('/get-requests-list', authMiddleware, TenderDetailsRequestController.getrequestsformelist);
Router.post('/get-requests-details', authMiddleware, TenderDetailsRequestController.getrequestsdetails);
//meeting
Router.post('/meeting-add', authMiddleware, MeetingController.meetingcreate);
Router.post('/meeting-list', authMiddleware, MeetingController.meetingelist);
Router.post('/meeting-edit', authMiddleware, MeetingController.meetingEdit);
Router.delete('/meeting-delete', authMiddleware, MeetingController.meetingdelete);
Router.put('/meeting-update', authMiddleware, MeetingController.meetingUpdate);

//Dashboard
Router.post('/dashboard-teamtask', authMiddleware, DashboardController.teamtasklist);
Router.post('/dashboard-teamtask-details', authMiddleware, DashboardController.teamtasklist_details);

// company logo
Router.post('/add-company-logo', authMiddleware, MasterController.companyLogoAdd);
Router.get('/get-company-logo', authMiddleware, MasterController.getCompanyLogo);

// Tender Document 
Router.post('/add-tender-document', authMiddleware, TenderController.addTenderDocManual);
Router.post('/list-tender-document', authMiddleware, TenderController.tenderDocumentList);
Router.put('/delete-tender-document', authMiddleware, TenderController.tenderDocumentDelete);

// dashboard calender data
Router.post('/calender-data-bydate', authMiddleware, DashboardController.getCalenderDataByDate);
Router.post('/calender-data-byMonth', authMiddleware, DashboardController.getCalenderDataByMonth);


//requisition
Router.post('/category-add', authMiddleware, TeamrequisitionController.addCategory);
Router.get('/category-list', authMiddleware, TeamrequisitionController.listCategory);
Router.post('/category-edit', authMiddleware, TeamrequisitionController.editCategory);
Router.put('/category-update', authMiddleware, TeamrequisitionController.updateCategory);
Router.delete('/category-delete', authMiddleware, TeamrequisitionController.deleteCategory);
Router.post('/designation-rq-add', authMiddleware, TeamrequisitionController.addDesignation);
Router.post('/designation-rq-list', authMiddleware, TeamrequisitionController.listDesignation);
Router.post('/designation-rq-edit', authMiddleware, TeamrequisitionController.editDesignation);
Router.put('/designation-rq-update', authMiddleware, TeamrequisitionController.updateDesignation);
Router.delete('/designation-rq-delete', authMiddleware, TeamrequisitionController.deleteDesignation);


Router.post('/team-rq-negociation-create', authMiddleware, TeamrequisitionController.team_rq_create_negociation);
Router.post('/team-rq-negociation-list', authMiddleware, TeamrequisitionController.teamrqnegociationlist);
Router.post('/team-rq-negociation-Edit', authMiddleware, TeamrequisitionController.teamrqnegociationEdit);
Router.delete('/team-rq-negociation-delete', authMiddleware, TeamrequisitionController.teamrqnegociationdelete);
Router.put('/team-rq-negociation-update', authMiddleware, TeamrequisitionController.teamrqnegociationupdate);
Router.post('/team-rq-send-mail', authMiddleware, TeamrequisitionController.tm_req_mail);
Router.post('/list-generated-code', authMiddleware, TeamrequisitionController.getGeneratedCodeList);
Router.post('/add-team-requision-member-clone', authMiddleware, TeamrequisitionController.addTenderRqMemberClone);
Router.post('/update-team-requision-member-clone', authMiddleware, TeamrequisitionController.updateTenderRqMemberClone);



//Requistion Team by Himanshu Sharan 
Router.get('/team-rq-list', authMiddleware, ReqNegotiationTeamsController.getTeams)
Router.post('/team-rq-add', authMiddleware, ReqNegotiationTeamsController.addReqTeams)
Router.post('/team-rq-edit', authMiddleware, ReqNegotiationTeamsController.editTeams)
Router.put('/team-rq-update', authMiddleware, ReqNegotiationTeamsController.updateReqTeams)
Router.delete('/team-rq-delete', authMiddleware, ReqNegotiationTeamsController.deleteReqTeams)
Router.post('/team-rq-list-by-prjdesg', authMiddleware, ReqNegotiationTeamsController.getTeamsPrjDesig)
Router.post('/team-rq-approve', authMiddleware, ReqNegotiationTeamsController.approveTeam)
Router.put('/team-rq-resume-update', authMiddleware, ReqNegotiationTeamsController.ResumeUploadReqTeams)

//update by tc growthgrids route
Router.post('/contect-us-create', ContactusController.ContectUS);
Router.post('/careers', ContactusController.Careers);
Router.post('/send-email', ContactusController.SentEmail);
Router.post('/get-resume-contact-us', ContactusController.GetResumeList);



//key Details
Router.post('/keydetail-add', authMiddleware, ProjectInfocontroller.addkeydetail);
Router.post('/keydetail-edit', authMiddleware, ProjectInfocontroller.editkeydetail);
Router.put('/keydetail-update', authMiddleware, ProjectInfocontroller.updatekeydetail);
Router.delete('/keydetail-delete', authMiddleware, ProjectInfocontroller.deletekeydetail);

//Financial Details
Router.post('/financialdetail-add', authMiddleware, ProjectInfocontroller.addfinancialdetail);
Router.post('/financialrefdetail-add', authMiddleware, ProjectInfocontroller.addfinancialrefdetail);
Router.post('/financialdetail-edit', authMiddleware, ProjectInfocontroller.editfinancialdetail);
Router.put('/financialdetail-update', authMiddleware, ProjectInfocontroller.updatefinancialdetail);
Router.delete('/financialdetail-delete', authMiddleware, ProjectInfocontroller.deletefinancialdetail);


//Tender Status Manage
Router.post('/tender-status-manage-add', authMiddleware, ProjectInfocontroller.addtenderstatusmanage);
Router.post('/tender-status-manage-edit', authMiddleware, ProjectInfocontroller.edittenderstatusmanage);
Router.put('/tender-status-manage-update', authMiddleware, ProjectInfocontroller.updatetenderstatusmanage);

Router.post('/check-old-password', authMiddleware, userController.checkOldpassword);
Router.post('/tender-list-scope-wise', authMiddleware, TenderController.tenderlistscopewise);
Router.post('/user-profile-update', authMiddleware, userController.userprofile_update);
// Router.post('/user-profile-update', authMiddleware, userController.userprofile_update);

Router.get('/action-list-tender', authMiddleware, WishlistController.wishlist_List_tender);
Router.get('/tendercycle-assignbtn-list', authMiddleware, TendercycleController.listassignbtn);
Router.get('/meeting-list-tender', authMiddleware, MeetingController.meetingelist_tender);
Router.post('/meeting-docs-delete', authMiddleware, MeetingController.meeting_delete_docs);

Router.post('/tendercycletrash-single', authMiddleware, TenderCycleTrashController.addTenderCycleTrashBtn);
Router.post('/tendercycletrash-multiple', authMiddleware, TenderCycleTrashController.addTenderCycleTrashBtnMultiple);

//Meeting MOM By Himanshu Sharan
Router.post('/meeting-mom-add', authMiddleware, MeetingMomController.addMeetingMom)
Router.put('/meeting-mom-update', authMiddleware, MeetingMomController.updateMom)
Router.get('/meeting-mom-listAll', authMiddleware, MeetingMomController.ListAll)
Router.post('/meeting-mom-id', authMiddleware, MeetingMomController.GetMomById)

//Reply of Tender Request (Himanshu Sharan)
Router.post('/reply-tndr-req-add', authMiddleware, TenderReqReplyController.addReqReply)
Router.post('/reply-tndr-req-list', authMiddleware, TenderReqReplyController.ListAll)


// dashboard cards
Router.get('/to-be-submitted', authMiddleware, DashboardController.toBesubmittedData);
Router.get('/submitted-tenders-dashboard', authMiddleware, DashboardController.submittedDashData);

// ash user profile
Router.post('/user-profile-pic-update', authMiddleware, userController.userprofile_pic_update);
Router.post('/check-user-old-password', authMiddleware, userController.check_user_old_password);
Router.post('/user-change-password', authMiddleware, userController.user_change_password);


Router.get('/await-tenders-dashboard', authMiddleware, DashboardController.AwaitingDashData);
Router.get('/won-tenders-dashboard', authMiddleware, DashboardController.WonDashData);

//factsheet manage
Router.get('/fstypemstr-list', authMiddleware, FactsheetController.getfstypemstrList)
Router.post('/fsdescassigncomp-list', authMiddleware, FactsheetController.getfsdescassigncompList)
Router.post('/fsdescramarks-add', authMiddleware, FactsheetController.addfsdescramarks)
Router.post('/fsdescremarkdoc-add', authMiddleware, FactsheetController.addfsdescramarkdoc)
Router.post('/fsprepare-template', authMiddleware, FactsheetController.fspreparationtemplate)
Router.post('/fsprepare-email', authMiddleware, FactsheetController.fspreparationemailpopup)
Router.post('/fspreparedoc-add', authMiddleware, FactsheetController.addfspreparedoc)


Router.put('/notification-seen', authMiddleware, NotificationController.updateNotifyStatus);
Router.post('/notification-clicked', authMiddleware, NotificationController.updateClickedStatus);
Router.get('/notification-list', authMiddleware, NotificationController.notification_list);
Router.post('/update-user-notify', authMiddleware, NotificationController.update_user_notify);
Router.get('/notification-list-mentioned', authMiddleware, NotificationController.notification_listMentioned);


// Genral Doctroal folder add 

Router.get('/doctrol-files-list', authMiddleware, GenralDoctroalController.doctrol_files_list);
Router.post('/folder-add', authMiddleware, GenralDoctroalController.addFolder);
Router.get('/folder-list', authMiddleware, GenralDoctroalController.listFolder);
Router.post('/folder-edit', authMiddleware, GenralDoctroalController.editFolder);
Router.put('/folder-update', authMiddleware, GenralDoctroalController.updateFolder);
Router.delete('/folder-delete', authMiddleware, GenralDoctroalController.deleteFolder);
Router.get('/listgenral-doctroal', authMiddleware, GenralDoctroalController.doctrol_listFolder);
Router.delete('/doctrol-files-delete', authMiddleware, GenralDoctroalController.doctrol_files_delete);

// general list type
Router.get('/list-type', authMiddleware, GenralDoctroalController.listType);

// Genral Doctroal add
Router.post('/listgenral-doctroal', authMiddleware, GenralDoctroalController.listGenralDoctroal);
Router.post('/genral-doctroal-add', authMiddleware, GenralDoctroalController.GenralDoctroalAdd);
Router.put('/tender-basic-info-details-update', authMiddleware, ProjectInfocontroller.TenderBasicDetailsUpdate)

// project doctroal add
Router.post('/project-folder-add', authMiddleware, ProjectDoctroalController.addProjectFolder);
Router.post('/project-folder-list', authMiddleware, ProjectDoctroalController.listProjectFolder);
Router.post('/project-folder-edit', authMiddleware, ProjectDoctroalController.editProjectFolder);
Router.post('/project-folder-update', authMiddleware, ProjectDoctroalController.updateProjectFolder);
Router.delete('/project-folder-delete', authMiddleware, ProjectDoctroalController.deleteProjectFolder);
Router.get('/project-doctrol-folder-list', authMiddleware, ProjectDoctroalController.project_doctrol_listFolder);



// project doctral file
Router.post('/project-file-add', authMiddleware, ProjectDoctroalController.addProjectDoctrolFile);
Router.get('/project-doctrol-files-list', authMiddleware, ProjectDoctroalController.project_doctrol_files_list);
Router.delete('/project-doctrol-files-delete', authMiddleware, ProjectDoctroalController.project_doctrol_files_delete);

// Department calender data by date
Router.post('/dept-calender-data-byDate', authMiddleware, DashboardController.getDeptCalenderDataByDate);
Router.post('/todo-team-tasks', authMiddleware, DashboardController.todoTeamTasks);
Router.post('/users-by-io', authMiddleware, DashboardController.getAllUsersByReportingManager);
Router.post('/dept-calender-data-byMonth', authMiddleware, DashboardController.getDeptCalenderDataByMonth);

//Tender Trash list By Himanshu Sharan(15-04-2024)
Router.post('/tender-trash-list', authMiddleware, TenderTrashController.TenderTrashList);
Router.post('/tender-trash-reverse', authMiddleware, TenderCycleTrashController.RemovefromTenderCycleTrash)
Router.post('/tender-trash-reverse-multiple', authMiddleware, TenderCycleTrashController.RemovefromTenderCycleTrashMultiple)
Router.post('/get-tender-cycle-move-history-by-id', authMiddleware, TenderCycleMoveHistoryController.getMoveHistoryByTenderId);
Router.get('/trash-cycle-list', authMiddleware, TenderTrashController.tenderscopetrashlist);
Router.get('/trashtendercycleinactionbtn-list', authMiddleware, TenderCycleTrashController.trashtndrcycleinactionlist);


// region wise state
Router.post('/state-list-byRegion', authMiddleware, MasterController.GetStateListByRegion);




//Role action Permissioin By Himanshu Sharan
Router.get('/action-permission-list', authMiddleware, ActionPermissionController.ActionPermissionListAll);
Router.get('/menu-master-list', authMiddleware, MenuMasterController.MenuMasterListAll);
Router.post('/set-actionperm-onrole-upd', authMiddleware, ActionPermController.SetActionPermRole);
Router.post('/get-actionperm', authMiddleware, ActionPermController.ActPermListAll);
Router.post('/get-actionperm-onrole', authMiddleware, ActionPermController.ActPermByRoleID);
Router.post('/get-actionperm-onrole-module', authMiddleware, ActionPermController.ActPermByRoleAndModuleId);

//Role action Permission End 


//Code by Himanshu Sharan
Router.post('/update-company-thumbnail', authMiddleware, MasterController.UpdateCompanyThumbnail);

//user details update(Himanshu Sharan)
Router.put('/official-profile-update', authMiddleware, userController.official_profile_update);
Router.put('/personal-profile-update', authMiddleware, userController.personal_profile_update);

//Tender assign action on mis cycle
Router.post('/tender-assign-action-miscycle', authMiddleware, admin_configure_controller.addTndrAssignActionOnMisCycle);
Router.post('/update-tender-assign-action-miscycle', authMiddleware, admin_configure_controller.updateTndrAssignActionOnMisCycle);
Router.post('/list-tender-assign-action-miscycle', authMiddleware, admin_configure_controller.inActionsByCycleId);
Router.post('/seo-search-meta-list', SeoController.SeoSearchMetaList)


//by himanshu sharan
Router.post('/tendertrashdetail-edit', authMiddleware, TenderTrashController.edittendertrashdetail);
Router.post('/tender-document-trash-list', authMiddleware, TenderTrashController.tenderDocumentTrashList);
Router.post('/tender-trash-update', authMiddleware, TenderTrashController.updateTenderTrashdetail);
Router.get('/set-configuration', authMiddleware, SetConfigrationController.InsertData)
Router.get('/get-storage-details', authMiddleware, DiskLimitController.getSizeLimit)
Router.post('/delete-todo-document', authMiddleware, TodoController.deleteTaskDocument);

// role & permission ROUTE  by tc
Router.post('/set-menu-access', authMiddleware, MenuPermissionController.SetMenuAccess)
Router.post('/menu-list', authMiddleware, MenuPermissionController.GetMenuAccessList)
//upd corrigendum 

Router.post('/tender-upd-record', authMiddleware, TenderUpdateControoler.corrigendum_upd_data)
module.exports = Router;
