const { Sequelize } = require('sequelize');
const sequelize = new Sequelize({
    dialect: 'mysql', // Change this to your database dialect
    host: '202.131.122.247',
    username: 'bid_grid_node',
    password: 'as#$&fD$#afs22',
    database: 'big_grid_node',

    // host: 'localhost',
    // username: 'root',
    // password: '',
    // database: 'bid_grid_apr1',

    // host: '202.131.122.247',
    // username: 'bid_grid_production',
    // password: 'axbA##XFxb!!#avm',
    // database: 'bid_grid_production',


    timezone: '+05:30',
    define: {
        timestamps: false, // Sequelize will enable timestamps by default
    },
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000,
    },
});

module.exports = sequelize;
