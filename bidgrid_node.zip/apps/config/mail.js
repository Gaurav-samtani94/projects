let nodemailer = require('nodemailer');
require('dotenv').config();
const handlebars = require('handlebars');
const fs = require('fs');
// MAIL_HOST=mail.cegindia.com
// MAIL_PORT=587
// MAIL_USER=marketing@cegindia.com
// MAIL_PASS=MARK-2015ceg
// MAIL_FROM=marketing@cegindia.com
// const transporter = nodemailer.createTransport({
//     host: process.env.MAIL_HOST,
//     port: process.env.MAIL_PORT,
//     secure: false, // true for 465, false for other ports// Use your email service provider
//     auth: {
//         user: process.env.MAIL_USER,
//         pass: process.env.MAIL_PASS
//     },
//     // debug: true
// });

// let transporter = nodemailer.createTransport({
//     host: process.env.EMAIL_HOST,
//     port: 587,
//     // service: 'gmail',
//     secureConnection: false, // true for 465, false for other ports// Use your email service provider
//     // tls: {
//     //     ciphers: 'SSLv3'
//     // },
//     auth: {
//         user: process.env.EMAIL_USER,
//         pass: process.env.EMAIL_PASSWORD,
//     },
//     tls: {
//         ciphers: 'SSLv3'
//     }
// });

// const mailOptions = {
//     from: process.env.MAIL_FROM,
//     to: 'sabhimanyu336@gmail.com',
//     subject: 'Subject of the Email',
//     text: 'Body of the Email',
//     html: '<p>HTML body of the email</p>',
// };
function mailOptions(to, subject, text, html) {
    return {
        from: process.env.EMAIL_USER,
        to: to,
        subject: subject,
        text: text,
        html: html,
    };
}

function sendDynamicEmail(to, subject, text, html) {
    const mailOption = mailOptions(to, subject, text, html);
    transporter.sendMail(mailOption, (error, info) => {
        if (error) {

            console.error('Email sent: ', error);
            // reject(error);
        } else {
            console.log('Email sent: ' + info.response);
            // resolve(info.response);
        }
    });
}


function loadTemplate(templatePath, replacements) {
    const template = fs.readFileSync(templatePath, 'utf8');
    const compiledTemplate = handlebars.compile(template);
    return compiledTemplate(replacements);
}



function sendEmailWith_temp(to, subject = null, body = null, templatePath, dynamicData) {
    const mailOptions = {
        from: process.env.MAIL_FROM,
        to,
        subject,
        html: loadTemplate(templatePath, dynamicData),
    };
    return new Promise((resolve, reject) => {
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error('Email not sent: ', error);
                reject(error);
            } else {
                console.log('Email sent: ' + info.response);
                resolve(info.response);
            }
        });
    });
}

// const transporter = nodemailer.createTransport({
//     host: process.env.EMAIL_HOST,
//     port: 587,
//     secure: false, // Use false for other ports
//     auth: {
//         user: process.env.EMAIL_USER,
//         pass: process.env.EMAIL_PASSWORD,
//     },
//     tls: {
//         // Consider using modern cipher suites
//         // Consult your email service provider for recommended configurations
//         // ciphers: 'TLS_AES_256_GCM_SHA384',
//     }
// });

const transporter = nodemailer.createTransport({
    // host: process.env.EMAIL_HOST,
    host: 'mail.growthgrids.com',
    port: 587,
    secure: true, // Use `true` for port 465, `false` for all other ports
    // proxy: 'http://202.131.122.242:3020/',
    debug: true,
    ssl: false,
    tls: {
        minVersion: 'TLSv1.2'
    },
    auth: {
        // user: process.env.EMAIL_USER,
        // pass: process.env.EMAIL_PASSWORD,
        user: 'business@growthgrids.com',
        pass: 'Growth@2023Busi'
    },

});

// const main = async (req, res) => {
//     // send mail with defined transport object
//     let info = null
//     setTimeout(async () => {
//         info = await transporter.sendMail({
//             from: '"Sender Name" <business@growthgrids.com>',
//             to: "sabhimanyu336@gmail.com",
//             subject: "Hello ✔",
//             text: "Hello world?",
//             // send: true,
//         });
//     }
//         , 3000);
//     console.log("Message sent: %s", info);
//     // Message sent: <d786aa62-4e0a-070a-47ed-0b0666549519@ethereal.email>
// }

const main = async (req, res) => {
    try {
        transporter.verify(function (error, success) {
            if (error) {
                console.error('SMTP connection error:', error);
            } else {
                console.log('SMTP connection successful');
            }
        });
        // send mail with defined transport object
        let info = await new Promise((resolve, reject) => {
            setTimeout(async () => {
                try {
                    const info = await transporter.sendMail({
                        from: 'business@growthgrids.com',
                        // to: `sabhimanyu336@gmail.com`,
                        subject: "Hello ✔",
                        text: "Hello world?",
                        send: true,
                    });
                    resolve(info);
                } catch (error) {
                    reject(error);
                }
            }, 300);
        });
        console.log("Message sent: %s", info.accepted);
        // Message sent: <d786aa62-4e0a-070a-47ed-0b0666549519@ethereal.email>
    } catch (error) {
        console.error("Error sending email:", error);
    }
}
const sendemailonassignProposermaneser = async (req, res) => {

    main().catch(console.error);

    // try {
    //     const info = await transporter.sendMail(mailOptions);
    //     console.log(info);
    //     return info.response;
    // } catch (error) {
    //     console.error('Email not sent: ', error);
    //     throw error;
    // }
}

module.exports = { sendDynamicEmail, sendEmailWith_temp, sendemailonassignProposermaneser };