const jwt = require('jsonwebtoken');
const secretKey = 'bidgrid277833';
const Users = require('../models/Users');
const bodyParser = require('body-parser');
const express = require('express')
const verifyToken = (req, res, next) => {
    const token = req.header('authorization');
    if (!token) {
        return res.status(401).json({
            message: 'No token provided',
            error: false,
            success: true,
            status: '0',
        });
    }
    jwt.verify(token, secretKey, (err, decoded) => {
        if (err) {
            return res.status(401).json({
                message: 'Invalid token',
                error: false,
                success: true,
                status: '0',
            });
        }
        if (decoded.emp_role_id != '1') {
            return res.status(401).json({
                message: 'You have not permission!',
                error: false,
                success: true,
                status: '0',
            });
        }
        req.userId = decoded.id;
        req.comp_id = decoded.comp_id;
        next();
    });

};
module.exports = verifyToken;