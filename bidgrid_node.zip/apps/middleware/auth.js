// const jwt = require('jsonwebtoken');
// const secretKey = 'bidgrid277833';
// const verifyToken = (req, res, next) => {
//     const token = req.header('authorization');
//     if (!token) {
//         return res.status(401).json({ message: 'No token provided' });
//     }
//     jwt.verify(token, secretKey, (err, decoded) => {
//         if (err) {
//             return res.status(401).json({ message: 'Invalid token' });
//         }
//         req.userId = decoded.id;
//         req.comp_id = decoded.comp_id;
//         req.emp_role_id = decoded.emp_role_id;
//         next();
//     });

// };
// module.exports = verifyToken;


const jwt = require('jsonwebtoken');
const secretKey = 'bidgrid277833';
const users = require('../models/Users')

const verifyToken = async (req, res, next) => {
    const token = req.header('authorization');
    if (!token) {
        return res.status(401).json({ message: 'No token provided' });
    }

    try {
        const decoded = jwt.verify(token, secretKey);
        const user = await users.findOne({
            where: {
                id: decoded.id
            }
        })

        if (user.auth_token !== token) {
            return res.status(401).json({ message: 'You have logged into another device' });
        }

        req.userId = decoded.id;
        req.comp_id = decoded.comp_id;
        req.emp_role_id = decoded.emp_role_id;
        next();
    } catch (err) {
        console.log(err.message)
        return res.status(401).json({ message: 'Invalid token' });
    }
};

module.exports = verifyToken;

