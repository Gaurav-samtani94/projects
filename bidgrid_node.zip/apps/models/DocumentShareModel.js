
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
const DocumentShareModel = sequelize.define('bg_document_shares', {

    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
    },
    to_email: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    all_emails: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    message: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    doc_expiry_days: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    doc_filename: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    doc_path: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    doc_size: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

module.exports = DocumentShareModel;