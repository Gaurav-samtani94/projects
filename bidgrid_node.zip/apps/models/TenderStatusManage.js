
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');// Import your Sequelize instance
const TenderStatus = require('../models/master/TenderStatus')
const Tenderstatusmanage = sequelize.define('bg_tenders_status_manages', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    tender_status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
});
Tenderstatusmanage.belongsTo(TenderStatus, {
    foreignKey: 'tender_status',
});
module.exports = Tenderstatusmanage;    