
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');// Import your Sequelize instance
const Tenderfinancialrefdetails = sequelize.define('bg_tenders_financial_ref_details', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    comp_status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1', '2', '3'

        ],
        defaultValue: '0'
    },
    comp_amount: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    comp_share: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
});
module.exports = Tenderfinancialrefdetails;    