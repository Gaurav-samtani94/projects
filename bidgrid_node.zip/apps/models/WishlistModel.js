const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
const WishlistCollectionModel = require('../models/WishlistCollectionModel');
const TenderModel = require('../models/tender/TenderModel');
const WishlistModel = sequelize.define('bg_tndr_addto_wishlists', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    tender_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    collection_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    share_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    person_ids: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }

});

WishlistModel.belongsTo(WishlistCollectionModel, {
    foreignKey: 'collection_id',
});

// WishlistModel.belongsTo(TenderModel, {
//     foreignKey: 'tender_id',
// });
// TenderModel.belongsTo(WishlistTender, {
//     foreignKey: 'id',
//     sourceKey: 'tender_id',
//     as: 'tender_wishlist_id'
// });
module.exports = WishlistModel;