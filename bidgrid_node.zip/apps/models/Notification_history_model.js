const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../config/database"); // Import your Sequelize instance

const Notification = sequelize.define("bg_notification_histories", {
  id: {
    type: DataTypes.BIGINT(20),
    autoIncrement: true,
    primaryKey: true,
  },
  user_comp_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },

  mentioned_by: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  ping_users_info: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  tender_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  comment_text: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  category_id: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  category_details: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  category_types: {
    type: DataTypes.STRING,
    allowNull: false,
  },

  is_viewed: {
    type: DataTypes.ENUM,
    values: ["0", "1"],
    defaultValue: '0',
  },
  is_clicked: {
    type: DataTypes.ENUM,
    values: ["0", "1"],
    defaultValue: '0',
  },
  status: {
    type: DataTypes.ENUM,
    allowNull: false,
    values: ["0", "1"],
    defaultValue: "1",
  },
  created_by: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  modified_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  updated_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
});

module.exports = Notification;
