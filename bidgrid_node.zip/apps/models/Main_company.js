const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
const comp_logo = require('../models/master/CompanyLogoModel')

const Main_company = sequelize.define('comp_main_users', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    comp_userfullname: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    comp_useremail: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    comp_userpassword: {
     type: DataTypes.STRING,
        allowNull: true,
    },

    comp_tg_userid: {
     type: DataTypes.INTEGER,
        allowNull: true,
    },

    comp_usercontact: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    ggpl_api_tndr_token: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    status: {
        type: DataTypes.ENUM,
            values: ['0','1','2'],
        defaultValue: '1',
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});


Main_company.hasOne(comp_logo, {
    foreignKey: 'user_comp_id',
    sourceKey: 'id',
})
module.exports = Main_company;
