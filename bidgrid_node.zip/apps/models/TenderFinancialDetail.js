
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');// Import your Sequelize instance
const Tenderpartners = require('../../models/tender/TenderPartner')
const Tenderfinancialrefdetails = require('../../models/tender/TenderFinancialRefDetail')

const Tenderfinancialdetails = sequelize.define('bg_tenders_financial_details', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    financial_proposal: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    award_contract_value: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
});
Tenderfinancialdetails.hasMany(Tenderfinancialrefdetails, {
    foreignKey: 'project_id',
    sourceKey: 'project_id',
    as:'fin_ref_detail'
})
module.exports = Tenderfinancialdetails;    