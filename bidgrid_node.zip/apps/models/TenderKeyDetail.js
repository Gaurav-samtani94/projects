
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');// Import your Sequelize instance
const Tenderkeydetails = sequelize.define('bg_tenders_key_details', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    tender_bid_opening: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    technical_bid_opening: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    technical_evaluation: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    financial_bid_opening: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    financial_evaluation: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    award_of_contract: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    contract_agreement: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    contract_negotiation: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    minutes_negotiation: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    commencement: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    completion_per_contract:{
        type: DataTypes.DATE,
        allowNull: true,
    },
    actual_date_completion:{
        type: DataTypes.DATE,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
});
module.exports = Tenderkeydetails;    