const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const FilterPageMasterModel = require('../../models/seo/FilterPageMasterModel')

    const SeoSearchMetaModel = sequelize.define('seo_search_meta', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        page_title: {
            type: DataTypes.STRING(255),
            allowNull: true
        },
        meta_key: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        meta_desc: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        slug: {
            type: DataTypes.STRING(255),
            allowNull: true
        },
        page_id: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        page_type: {
            type: DataTypes.ENUM('1', '2', '3'),
            allowNull: false,
            defaultValue: '1'
        },
        status: {
            type: DataTypes.ENUM('0', '1', '2'),
            allowNull: false,
            defaultValue: '1'
        },
        created_by: {
            type: DataTypes.INTEGER,
        },
    
        created_at: {
            type: DataTypes.DATE,
        },
    
        modified_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
    
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
    }, {
        tableName: 'seo_search_meta',
        timestamps: false // Set this to true if you want Sequelize to handle timestamps
    });

    SeoSearchMetaModel.belongsTo(FilterPageMasterModel, {
        foreignKey: 'page_id',
        targetKey: 'id',
    });

module.exports = SeoSearchMetaModel;
