const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

    const FilterPageMasterModel = sequelize.define('filter_page_master', {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        page_name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        status: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 1
        }
    }, {
        tableName: 'filter_page_master',
        timestamps: false // Set this to true if you want Sequelize to handle timestamps
    });



module.exports = FilterPageMasterModel;
