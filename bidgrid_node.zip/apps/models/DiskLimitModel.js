// models/DiskLimit.js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // your sequelize instance

const DiskLimit = sequelize.define('disk_limit', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  comp_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  size_limit: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM('0', '1'),
    allowNull: false,
  },
  created_by: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  created_at: {
    type: DataTypes.DATE,
    allowNull: false,
    defaultValue: DataTypes.NOW,
  },
  modified_by: {
    type: DataTypes.INTEGER,
    allowNull: true,
  },
  modified_at: {
    type: DataTypes.DATE,
    allowNull: true,
  },
}, {
  tableName: 'disk_limit',
  timestamps: false,
});

module.exports = DiskLimit;
