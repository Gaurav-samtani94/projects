
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const ListType = sequelize.define('gen_dctr_share_types', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    type_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    entry_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },  
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },

});


module.exports = ListType;    