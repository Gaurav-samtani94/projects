
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Genral_Files = require('./GenralFilesModel')
const ListType = require('./ListTypeModel')
const GenralFolder = sequelize.define('gen_dctr_folders', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    folder_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    parent_id: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});

GenralFolder.hasMany(Genral_Files, {
    foreignKey: 'folder_id',
    sourceKey:'id'
});

// GenralFolder.hasMany(GenralFolder, {
//     foreignKey: 'parent_id',
//     as: 'child_folders',
// });

module.exports = GenralFolder;    