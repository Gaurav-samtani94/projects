const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const FinancialYear = require("../../models/siteconfig/FinancialYear");

const Siteconfiguration = sequelize.define('bg_mstr_configurations', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    user_comp_id: {
        type: DataTypes.INTEGER,
    },
    
    comp_letter_code : {
        type: DataTypes.STRING,
        allowNull: true,
    },

    financial_year_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    status: {
        type: DataTypes.ENUM,
            values: ['0','1','2'],
        defaultValue: '1',
    },

    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});


Siteconfiguration.belongsTo(FinancialYear, {
    foreignKey: 'financial_year_id',
});


module.exports = Siteconfiguration;