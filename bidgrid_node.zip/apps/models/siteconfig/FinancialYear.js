
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const FinancialYear = sequelize.define('bg_mstr_financial_years', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    fin_year_type: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
            values: ['0','1','2'],
        defaultValue: '1',
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

});
module.exports = FinancialYear;