const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); 
const fsdescmasters = require('../../models/factsheet/fsdescmasters')
const fsinputtypemasters = require('../../models/factsheet/fsinputtypemasters')
const fsdescremarks = require('../../models/factsheet/fsdescremarks')

const FsDescAssignComps = sequelize.define('fs_desc_assign_comps', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    type_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    desc_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    desc_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    is_self_create: {
        type: DataTypes.TINYINT,
        allowNull: false,
    },
    input_type: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    sr_no: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
            values: ['0','1'],
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

FsDescAssignComps.belongsTo(fsdescmasters, {
    foreignKey: 'desc_name_id',
})

FsDescAssignComps.hasOne(fsinputtypemasters, {
    foreignKey: 'id',
    sourceKey: 'input_type',
})
FsDescAssignComps.hasOne(fsdescremarks, {
    foreignKey: 'desc_remark_id',
    sourceKey: 'id',
})
module.exports = FsDescAssignComps;
