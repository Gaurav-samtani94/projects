const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); 

const FsRemarks = sequelize.define('fs_desc_remarks', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },

    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    desc_remark_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    desc_remark_data: {
        type: DataTypes.BLOB('long'),
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
            values: ['0','1','2'],
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});


module.exports = FsRemarks;
