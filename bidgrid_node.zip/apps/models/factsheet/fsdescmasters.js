const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); 

const FsDescMaster = sequelize.define('fs_desc_masters', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    desc_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
            values: ['0','1','2'],
        defaultValue: '1',
    },
    entry_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    entry_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

module.exports = FsDescMaster;
