const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); 

const FsPreparationtemplate = sequelize.define('fs_preparation_templates', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    sheet_type: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    assign_to: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    subject: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    remark: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    ho_contract: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: ['0','1','2'],
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});


module.exports = FsPreparationtemplate;
