const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); 
const fstypemasters = require('./fstypemasters')
const fsdescassigncomps = require('../../models/factsheet/fsdescassigncomps')
const FsTypeAssignComps = sequelize.define('fs_type_assign_comps', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    type_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    type_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    is_self_create: {
        type: DataTypes.TINYINT,
        allowNull: false,
    },
   
    status: {
        type: DataTypes.ENUM,
            values: ['0','1'],
        defaultValue: '1',
    },
    createdby: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

FsTypeAssignComps.belongsTo(fstypemasters, {
    foreignKey: 'type_name_id',
})
FsTypeAssignComps.hasMany(fsdescassigncomps, {
    foreignKey: 'type_id',
    sourceKey: 'id',
})


module.exports = FsTypeAssignComps;
