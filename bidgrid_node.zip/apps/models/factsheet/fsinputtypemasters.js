const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); 
const FsInputTypeMaster = sequelize.define('fs_input_types', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    fs_input_type: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: false,
    },
    entry_date: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    entry_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
});
module.exports = FsInputTypeMaster;
