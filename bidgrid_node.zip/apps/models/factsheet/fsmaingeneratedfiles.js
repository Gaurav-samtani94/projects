const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); 

const FsMainGenratedFiles = sequelize.define('fs_main_generated_files', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },

    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    // tbl_remark_id: {
    //     type: DataTypes.INTEGER,
    //     allowNull: false,
    // },
    file_path: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    file_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
            values: ['0','1','2'],
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});


module.exports = FsMainGenratedFiles;
