const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); 
const fsdescassigncomps = require('../../models/factsheet/fsdescassigncomps')
const FsTypeMaster = sequelize.define('fs_type_masters', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    fs_type_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: false,
    },
    entry_date: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    entry_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
});
FsTypeMaster.hasMany(fsdescassigncomps, {
    foreignKey: 'type_id',
    sourceKey: 'id',
})
module.exports = FsTypeMaster;
