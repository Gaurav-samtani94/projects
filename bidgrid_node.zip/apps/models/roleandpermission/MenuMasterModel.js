const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const MenuMasterModel = sequelize.define('bg_mstr_menus', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    parent_menu_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    menu_category: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: '1'
    },
    menu_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    action_url: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});

MenuMasterModel.belongsTo(MenuMasterModel, {
    as:'parent_menu',
    foreignKey: 'parent_menu_id',
});

module.exports = MenuMasterModel;