const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance

const Role = require("../master/Role");
const Widgets = require("../../models/roleandpermission/Widgets");
const WidgetModel = require('../../models/master/WidgetModel')
const WidgetPerm = sequelize.define('widget_perm_roles', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    user_comp_id: {
        type: DataTypes.INTEGER,
    },

    role_id: {
        type: DataTypes.INTEGER,
    },

    widget_id: {
        type: DataTypes.INTEGER,
    },

    status: {
        type: DataTypes.ENUM,
        values: ['0', '1', '2'],
        defaultValue: '1',
    },

    created_by: {
        type: DataTypes.INTEGER,
    },

    created_at: {
        type: DataTypes.DATE,
    },

    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

WidgetPerm.belongsTo(Role, {
    foreignKey: 'role_id',
});

WidgetPerm.belongsTo(Widgets, {
    foreignKey: 'widget_id',
});

// WidgetPerm.belongsTo(Widgets, {
//     foreignKey: 'widget_id',
// });
module.exports = WidgetPerm;