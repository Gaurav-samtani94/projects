const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance

const Role = require("../../models/master/Role");
const ActionPermissionModel = require("../../models/Menu/MenuMasterModel");

const ActionPerm = sequelize.define('action_perm_roles', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    user_comp_id: {
        type: DataTypes.INTEGER,
    },

    role_id: {
        type: DataTypes.INTEGER,
    },

    menu_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },

    view_perm: {
        type: DataTypes.ENUM,
        values: ['0', '1', '2'],
        defaultValue: '2',
    },

    add_perm: {
        type: DataTypes.ENUM,
        values: ['0', '1', '2'],
        defaultValue: '2',
    },

    update_perm: {
        type: DataTypes.ENUM,
        values: ['0', '1', '2'],
        defaultValue: '2',
    },

    delete_perm: {
        type: DataTypes.ENUM,
        values: ['0', '1', '2'],
        defaultValue: '2',
    },
    download_perm: {
        type: DataTypes.ENUM,
        values: ['0', '1', '2'],
        defaultValue: '2',
    },

    status: {
        type: DataTypes.ENUM,
        values: ['0', '1'],
        defaultValue: '1',
    },

    created_by: {
        type: DataTypes.INTEGER,
    },

    created_at: {
        type: DataTypes.DATE,
    },

    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});


ActionPerm.belongsTo(Role, {
    foreignKey: 'role_id',
});

ActionPerm.belongsTo(ActionPermissionModel, {
    foreignKey: 'menu_id',
});


module.exports = ActionPerm;