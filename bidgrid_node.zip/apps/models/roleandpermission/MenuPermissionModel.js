const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Role = require('../master/Role');
const MenuPermissionModel = sequelize.define('bg_menu_permissions', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id:{
        type: DataTypes.INTEGER,
        allowNull:false
    },
    role_id: {
        type: DataTypes.INTEGER,
        allowNull:false
    },
    menu_id: {
        type: DataTypes.INTEGER,
        allowNull:false
    },
    is_view:{
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1",'2'],
        defaultValue: "1",
    },
    is_add:{
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1",'2'],
        defaultValue: "1",
    },
    is_update:{
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1",'2'],
        defaultValue: "1",
    },
    is_delete:{
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1",'2'],
        defaultValue: "1",
    },
    status: {
        type: DataTypes.ENUM,
        values: ['0', '1',],
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
    },
    created_at: {
        type: DataTypes.DATE,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

// MenuPermissionModel.sync({alter:true})

MenuPermissionModel.belongsTo(Role, {
    foreignKey: 'role_id',
});

module.exports = MenuPermissionModel;