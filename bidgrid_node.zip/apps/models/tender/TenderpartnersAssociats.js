
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const MainCompany = require('../../models/master/MainCompany')
const TenderpartnersASSo = sequelize.define('bg_tenders_associatives', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,

    },
    project_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    associative_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    group_no: {
        type: DataTypes.INTEGER,
        defaultValue: '1'
    },
    type_data: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '2'
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '1'
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },

});
TenderpartnersASSo.belongsTo(MainCompany, {
    foreignKey: 'associative_id',
});
module.exports = TenderpartnersASSo;    