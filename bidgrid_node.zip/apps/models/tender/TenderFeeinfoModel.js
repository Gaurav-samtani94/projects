const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const createTenderModelFeeInfo = (comp_id) => {
    const tableName = `bg_main_tndr_fee_info_${comp_id}s`;
    const TenderFeeInfoModel = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        tnd_fee: {
            type: DataTypes.DOUBLE,
            allowNull: true,
        },
        currency: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        processing_fee: {
            type: DataTypes.DOUBLE,
            allowNull: true,
        },
        fee_payable_to: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        fee_payable_at: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        tnd_fee_exemption_allowed: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
    });
    TenderFeeInfoModel.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderFeeInfoModel.sync();
    return TenderFeeInfoModel;
};
module.exports = createTenderModelFeeInfo;