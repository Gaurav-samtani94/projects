const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const createTenderModelEMD = (comp_id) => {
    const tableName = `bg_main_tndr_emd_${comp_id}s`;
    const TenderEMDModel = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        emd_amount: {
            type: DataTypes.DOUBLE,
            allowNull: true,
        },
        currency: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        emd_fee_type: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        emd_payable_to: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        emd_payable_at: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        emd_percentage: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        emd_through_BG_ST_orEMD_exemption_allowed: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
    });
    TenderEMDModel.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderEMDModel.sync();
    return TenderEMDModel;
};
module.exports = createTenderModelEMD;