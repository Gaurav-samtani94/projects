const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Users = require('../../models/Users');
const TenderCommentModel = sequelize.define('tender_comments', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },

    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        foreignKey: true
    },
    tender_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        foreignKey: true
    },
    parent_id: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: '0'
    },
    comment_txt: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    file_attachment: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    ping_users_info: {
        type: DataTypes.TEXT,
        allowNull: true,
    },

    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
});
TenderCommentModel.belongsTo(Users, {
    foreignKey: 'created_by',
});
module.exports = TenderCommentModel;