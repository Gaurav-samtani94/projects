const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const createTenderModelcoverinfo = (comp_id) => {
    const tableName = `bg_main_tndr_cover_info_${comp_id}s`;
    const TenderCoverinfoModel = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },

        cover_type: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        description: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        doc_type: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
    });
    TenderCoverinfoModel.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderCoverinfoModel.sync();
    return TenderCoverinfoModel;
};
module.exports = createTenderModelcoverinfo;