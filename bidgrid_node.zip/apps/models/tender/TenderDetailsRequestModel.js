
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');// Import your Sequelize instance
const TenderDetailsRequest = sequelize.define('bg_request_for_apprvls', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    tender_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    subject: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    desc_details: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    parent_id: {
        type: DataTypes.INTEGER,
        defaultValue: '0'
    },
    file_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_path: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    req_from_userid: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    req_to_userid: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    curr_status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2', '3'

        ],
        defaultValue: '1',
        COMMENT: '1-Pending,2-Approve,3-cancelled',
    },
    comment_txt: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },


});

module.exports = TenderDetailsRequest;    