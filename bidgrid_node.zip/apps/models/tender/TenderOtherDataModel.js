const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const createTenderModelOtherData = (comp_id) => {
    const tableName = `bg_main_tndr_other_data_${comp_id}s`;
    const TenderOtherDataModel = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        product_category: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        tnd_url: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        form_of_contract: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        no_of_covers: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        payment_mode: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        general_technical_evaluation_allowed: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        item_wise_technical_value: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        is_multicurrency_allowed_for_boq: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        is_multicurrency_allowed_for_fee: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        allowed_two_stage_bidding: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        nda_pre_qualification: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        independent_external_monitor_remark: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        contract_type: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        bid_validity: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        period_of_work: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        region_code: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        pre_bid_meeting_place: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        pre_bid_meeting_address: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        pre_bid_meeting_date: {
            type: DataTypes.DATEONLY,
            allowNull: true,
        },
        pre_bid_meeting_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        bid_opening_place: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        should_allow_nda_tnd: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        allow_preferential_bidder: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        instrument_type: {
            type: DataTypes.TEXT,
            allowNull: true,
        },

        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
    });
    TenderOtherDataModel.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderOtherDataModel.sync();
    return TenderOtherDataModel;
};
module.exports = createTenderModelOtherData;