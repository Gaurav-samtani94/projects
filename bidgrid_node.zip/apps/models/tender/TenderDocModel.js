// module.exports = TenderDocModel;
const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database');
const createTenderModeDocs = (comp_id) => {
    const tableName = `bg_tndr_documents_${comp_id}s`;
    const TenderDocModel = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        file_name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        comment: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        doc_path: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        type: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        tender_category: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        }
    });
    // Add other attributes here...
    TenderDocModel.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderDocModel.sync();
    return TenderDocModel;
};

module.exports = createTenderModeDocs;
