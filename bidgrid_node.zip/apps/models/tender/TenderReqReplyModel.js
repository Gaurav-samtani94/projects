
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');// Import your Sequelize instance
const ReplyTenderRequest = sequelize.define('bg_tndr_req_reply_dashboards', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    tender_request_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    reply_tndr_req: {
        type: DataTypes.STRING,
        allowNull: true,
    },  
    reply_from_userid: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    file_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_path: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    reply_from_userid: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});

module.exports = ReplyTenderRequest;    