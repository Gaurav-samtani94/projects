const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const TenderGeneratedTypeModel = require('../tender/TenderGeneratedTypeModel');
const TenderGenTypeIdModel = sequelize.define('bg_assign_tndr_generated_ids', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    tender_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    generated_tender_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    financial_year: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    generate_type_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    last_generated_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: '0'
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
});
TenderGenTypeIdModel.belongsTo(TenderGeneratedTypeModel, {
    foreignKey: 'generate_type_id',
});
module.exports = TenderGenTypeIdModel;