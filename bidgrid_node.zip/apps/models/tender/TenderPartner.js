
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');// Import your Sequelize instance
const MainCompany = require('../../models/master/MainCompany')
const Tenderpartners = sequelize.define('bg_tenders_leads', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,

    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    method_type: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    lead_comp_ids: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    technical_weightage: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    technical_score: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    technical_marks: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    financial_weightage: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    financial_score: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    financial_marks: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    total: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    rank: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    group_no: {
        type: DataTypes.INTEGER,
        defaultValue: '1'
    },
    consortium_skip: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    is_solo: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '0'

    },
    type_data: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '2'
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },


});
Tenderpartners.belongsTo(MainCompany, {
    foreignKey: 'lead_comp_ids',
});
module.exports = Tenderpartners;    