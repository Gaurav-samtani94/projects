const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const Users = require('../Users');
const Tenderscope = require('../master/TenderScope')
const createTenderMoveHistory = (comp_id) => {
    const tableName = `bg_tndr_cycl_move_hist_${comp_id}s`;
    const TenderMovedHistroyByUserModel = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true
        },
        from_cycle_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true
        },
        tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true
        },
        to_cycle_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true
        },
        scope_move_type: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        reverse_cycle: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '0'
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
            defaultValue: '0'
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },
        modified_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        }
    });
    // Add other attributes here...

    TenderMovedHistroyByUserModel.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderMovedHistroyByUserModel.belongsTo(Tenderscope, {
        foreignKey: 'to_cycle_id',
        // This is the foreign key in TenderGeneratedTypeIdModel
        // targetKey: 'id',
    });

    TenderMovedHistroyByUserModel.belongsTo(Tenderscope, {
        foreignKey: 'to_cycle_id',
        as: 'to_cycle',
        // This is the foreign key in TenderGeneratedTypeIdModel
        // targetKey: 'id',
    });

    TenderMovedHistroyByUserModel.belongsTo(Tenderscope, {
        foreignKey: 'from_cycle_id',
        as: 'from_cycle' // This is the foreign key in TenderGeneratedTypeIdModel
        // targetKey: 'id',
    });
    TenderMovedHistroyByUserModel.belongsTo(Users, {
        foreignKey: 'created_by',
        as: 'created_by_user'

    });
    TenderMovedHistroyByUserModel.sync();
    return TenderMovedHistroyByUserModel;
};



module.exports = createTenderMoveHistory;