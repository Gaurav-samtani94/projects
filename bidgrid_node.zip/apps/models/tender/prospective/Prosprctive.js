
const { DataTypes } = require('sequelize');
const sequelize = require('../../../config/database'); // Import your Sequelize instance
const Country = require('../../master/Country');
const State = require('../../master/State');
const Tenderclient = require('../../master/TenderClient');
const Tendersector = require('../../master/TenderSector');
const Tenderfundingorg = require('../../master/TenderFundingagency');
const ProspectiveDocs = require('./ProspectiveDocuments');
const Prospectivepartnaers = require('./ProspectivePartner');
const ProspectivepartnersJVS = require('./ProspectivepartnersJVS');
const ProspectivepartnersASSo = require('./ProspectivepartnersAssociats');
const Prospective = sequelize.define('bg_prospective_tenders', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    project_name: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    tender_value: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },
    client_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    country_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    state_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    funding_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    sector_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2', '3'

        ],
        defaultValue: '1'
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    }

});
Prospective.belongsTo(Country, {
    foreignKey: 'country_id',
});
Prospective.belongsTo(State, {
    foreignKey: 'state_id',
});
Prospective.belongsTo(Tenderclient, {
    foreignKey: 'client_id',
});
Prospective.belongsTo(Tendersector, {
    foreignKey: 'sector_id',
});
Prospective.belongsTo(Tenderfundingorg, {
    foreignKey: 'funding_id',
});
Prospective.hasOne(Prospectivepartnaers, {
    foreignKey: 'project_id',
});
Prospective.hasMany(ProspectivepartnersJVS, {
    foreignKey: 'project_id',
});
Prospective.hasMany(ProspectivepartnersASSo, {
    foreignKey: 'project_id',
});
Prospective.hasMany(ProspectiveDocs, {
    foreignKey: 'project_id',
});
module.exports = Prospective;    