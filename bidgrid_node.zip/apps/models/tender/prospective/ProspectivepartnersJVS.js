
const { DataTypes } = require('sequelize');
const sequelize = require('../../../config/database');// Import your Sequelize instance
const Company = require('../../master/MainCompany');
const ProspectivepartnersJVS = sequelize.define('bg_prospective_tenders_jvs', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,

    },
    lead_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    project_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },


    jv_ids: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '1'
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },


});
ProspectivepartnersJVS.belongsTo(Company, {
    foreignKey: 'jv_ids',
});
module.exports = ProspectivepartnersJVS;    