
const { DataTypes } = require('sequelize');
const sequelize = require('../../../config/database'); // Import your Sequelize instance
const Company = require('../../master/MainCompany');
const ProspectivepartnersASSo = sequelize.define('bg_prospective_tenders_associatives', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,

    },
    lead_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    project_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    associative_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '1'
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },

});
ProspectivepartnersASSo.belongsTo(Company, {
    foreignKey: 'associative_id',
});
module.exports = ProspectivepartnersASSo;    