
const { DataTypes } = require('sequelize');
const sequelize = require('../../../config/database');// Import your Sequelize instance
const Company = require('../../master/MainCompany');
const Prospectivepartners = sequelize.define('bg_prospective_partners', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,

    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    lead_comp_ids: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '1'
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },


});
Prospectivepartners.belongsTo(Company, {
    foreignKey: 'lead_comp_ids',
});
module.exports = Prospectivepartners;    