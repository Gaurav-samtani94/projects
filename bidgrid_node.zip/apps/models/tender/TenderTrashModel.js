const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const Country = require('../master/Country');
const State = require('../master/State');
const City = require('../master/City');
const TenderScopeModel = require('../master/TenderScope');
const Tendersector = require('../master/TenderSector');
const Tenderscope = require('../master/TenderScope');
const TenderCycleAssignInactionModel = require('../tender/TenderCycleAssignInactionModel');
const TenderCycleInactionModel = require('../master/TenderCycleInactionModel');
const TenderGeneratedTypeIdModel = require('../tender/TenderGeneratedTypeIdModel');
const TenderAssignManagerModel = require('../tender/TenderAssignManagerModel');
const Client = require('../master/TenderClient');
const WishlistTender = require('../WishlistModel');
const TenderStatus = require('../master/TenderStatus');
const TenderStatusManage = require('../tender/TenderStatusManage');
const TenderCommentModel = require('../tender/TenderCommentModel');
const createTenderTrashModel = (comp_id) => {
    const tableName = `bg_dump_tndr_details_${comp_id}s`;
    const TenderTrashModel = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true
        },
        tg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        gg_tenderID: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true
        },
        tender_name: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        tnd_ref_id: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        tender_gov_id: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        tender_cost: {
            type: DataTypes.DOUBLE,
            allowNull: false,
            defaultValue: '0'
        },
        tender_emd_amnt_val: {
            type: DataTypes.DOUBLE,
            allowNull: true,
        },

        client_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        currency_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        region_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        country_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        state_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        city_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        sector_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },

        funding_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },

        cycle_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        client_cont_person: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        client_cont_address: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        email_id: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        phone_no: {
            type: DataTypes.STRING,
            allowNull: true,
        },

        publication_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        submission_start_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        submission_end_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        bid_opening_place: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        bid_validity_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        source_id: {
            type: DataTypes.INTEGER,
            allowNull: true,
            // defaultValue: '0'

        },
        national_intern: {
            type: DataTypes.INTEGER,
            allowNull: true,
            // defaultValue: '0'
        },
        pre_bid_meeting_place: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        pre_bid_meeting_address: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        pre_bid_meeting_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        pre_bid_meeting_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        tnd_url: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        pre_bid_meeting_link: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        pre_bid_mode: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        modified_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        status: {
            type: DataTypes.INTEGER,
            allowNull: true,
            // defaultValue: '1'


        },
        deleted_by: {
            type: DataTypes.INTEGER,
            allowNull: true,

        },
        deleted_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
    });
    TenderTrashModel.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };

    TenderTrashModel.belongsTo(Country, {
        foreignKey: 'country_id',
    });
    TenderTrashModel.belongsTo(State, {
        foreignKey: 'state_id',
    });
    TenderTrashModel.belongsTo(City, {
        foreignKey: 'city_id',
    });

    TenderTrashModel.belongsTo(Tendersector, {
        foreignKey: 'sector_id',
    });
    // TenderTrashModel.hasMany(TenderCycleAssignInactionModel, {
    //     foreignKey: 'cycle_id',
    //     sourceKey: 'cycle_id', // The field to compare in the source model (TenderTrashModel)
    //     as: 'inactions',
    // });
    TenderTrashModel.belongsTo(Tenderscope, {
        foreignKey: 'cycle_id',
    });
    TenderCycleAssignInactionModel.belongsTo(TenderCycleInactionModel, {
        foreignKey: 'inaction_id',
    });

    // added by gaurav
    TenderTrashModel.belongsTo(Client, {
        foreignKey: 'client_id',
    });
    TenderTrashModel.belongsTo(Client, {
        foreignKey: 'client_id',
    });
    TenderTrashModel.hasOne(TenderGeneratedTypeIdModel,
        {
            sourceKey: 'id',
            foreignKey: 'tender_id'
        });
    TenderTrashModel.hasOne(TenderGeneratedTypeIdModel,
        {
            sourceKey: 'id',
            foreignKey: 'tender_id',
            as: 'tender_ger_id',
        });
    TenderTrashModel.hasOne(TenderCommentModel,
        {
            sourceKey: 'id',
            foreignKey: 'tender_id',

        });
    TenderScopeModel.hasMany(TenderTrashModel, {
        foreignKey: 'cycle_id',
    });
    // TenderMovedHistroyByUserModel.belongsTo(TenderTrashModel, {
    //     foreignKey: 'tender_id', // This is the foreign key in TenderGeneratedTypeIdModel
    //     // targetKey: 'id',
    // });
    // TenderDocModel.belongsTo(TenderTrashModel, {
    //     foreignKey: 'tender_id', // This is the foreign key in TenderGeneratedTypeIdModel
    //     // targetKey: 'id',
    // });
    WishlistTender.belongsTo(TenderTrashModel, {
        foreignKey: 'tender_id',
    });
    TenderTrashModel.hasMany(TenderAssignManagerModel, {
        foreignKey: 'tender_id',
        sourceKey: 'id', // The field to compare in the source model (TenderModel)
        as: 'assign_tender',
    });
    TenderTrashModel.hasOne(TenderStatusManage, {
        sourceKey: 'id',
        foreignKey: 'project_id',
    });
    TenderTrashModel.sync();
    return TenderTrashModel;
};
module.exports = createTenderTrashModel;