const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const TenderModel = require('../../models/tender/TenderModel');
const TenderReminderModel = sequelize.define('bg_tndr_reminders', {
    id: {
        type: DataTypes.BIGINT(20),
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    tender_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    reminder_date: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    reminder_subject: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    reminder_message: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }

});

// TenderReminderModel.belongsTo(TenderModel, {
//     foreignKey: 'tender_id',
// });

module.exports = TenderReminderModel;