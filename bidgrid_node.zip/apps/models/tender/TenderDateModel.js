const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const createTenderModelDate = (comp_id) => {
    const tableName = `bg_main_tndr_dates_${comp_id}s`;
    const TenderDateModel = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        tnd_published_date: {
            type: DataTypes.DATEONLY,
            allowNull: true,
        },
        tnd_published_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        bid_opening_date: {
            type: DataTypes.DATEONLY,
            allowNull: true,
        },
        bid_opening_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        doc_download_start_date: {
            type: DataTypes.DATEONLY,
            allowNull: true,
        },
        doc_download_start_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        doc_download_end_date: {
            type: DataTypes.DATEONLY,
            allowNull: true,
        },
        doc_download_end_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        clarification_start_date: {
            type: DataTypes.DATEONLY,
            allowNull: true,
        },
        clarification_start_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        clarification_end_date: {
            type: DataTypes.DATEONLY,
            allowNull: true,
        },
        clarification_end_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        bid_submission_start_date: {
            type: DataTypes.DATEONLY,
            allowNull: true,
        },
        bid_submission_start_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        bid_submission_end_date: {
            type: DataTypes.DATEONLY,
            allowNull: true,
        },
        bid_submission_end_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
    });
    TenderDateModel.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderDateModel.sync();
    return TenderDateModel;
};
module.exports = createTenderModelDate;