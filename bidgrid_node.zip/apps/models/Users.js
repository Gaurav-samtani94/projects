const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance


const Role = require("../models/master/Role");
const Businessunit = require("../models/master/BusinessUnit");
const Main_company = require("../models/Main_company");
const JobGradeModel = require('../models/master/JobGradeModel');
const Designation = require("../models/master/Designation");
const DepartmentModel = require('../models/master/DepartmentModel');
const Company = require("../models/master/Company");
const Country = require('../models/master/Country');
const State = require('../models/master/State');
const City = require('../models/master/City');
const Useractivehistory = require('./activity/Useractivehistory');

const Users = sequelize.define('users', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    emp_role_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },

    comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    firstname: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    lastname: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    userfullname: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    email: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    contactnumber: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    password: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    unit_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    company_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    department_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    designation_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    jobgrade_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    reporting_mngr_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    createdby: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    isactive: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: '1',
        comment: "1-Active,2-resigned,3-left,4-suspended,5-deleted"
    },

    date_of_birth: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    profileimg: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    profileimg_path: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    country_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    state_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    city_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    zip_code: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    full_address_1: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    last_login: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    last_login_otp: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    login_attempt: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    user_login_block_datetime: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    login_otp_wrong_attempt: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    user_login_block_datetime_wrong_otp: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    resent_otp_attemp: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    user_status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    date_of_leaving: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    is_user_notified: {
        type: DataTypes.ENUM,
        values: ['0', '1'],
        defaultValue: '0',
        comment: "0-true,1-false"
    },
    is_verified_mobile: {
        type: DataTypes.ENUM,
        values: ['1', '2'],
        defaultValue: '2',
        comment: "1-yes,2-no"
    },

    app_device_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    auth_token: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    device_token: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    device_type: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    web_push_notification_token: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    permanent_sys_adm: {
        type: DataTypes.ENUM,
        values: ['1', '2'],
        defaultValue: '2',
        comment: "1-yes,2-no"
    },

});


Users.belongsTo(Role, {
    foreignKey: 'emp_role_id',
});

Users.belongsTo(Main_company, {
    foreignKey: 'comp_id',
});

Users.belongsTo(Company, {
    foreignKey: 'company_id',
});
Users.belongsTo(Businessunit, {
    foreignKey: 'unit_id',
});

Users.belongsTo(DepartmentModel, {
    foreignKey: 'department_id',
});

Users.belongsTo(Designation, {
    foreignKey: 'designation_id',
});

Users.belongsTo(JobGradeModel, {
    foreignKey: 'jobgrade_id',
});

Users.belongsTo(Users, {
    as: 'reporting_manager',
    foreignKey: 'reporting_mngr_id'
});

Users.belongsTo(Users, {
    as: 'createdby_username',
    foreignKey: 'createdby',
});

Users.belongsTo(Country, {
    foreignKey: 'country_id',
});

Users.belongsTo(State, {
    foreignKey: 'state_id',
});

Users.belongsTo(City, {
    foreignKey: 'city_id',
});

Users.belongsTo(Users, {
    as: 'updatedby_username',
    foreignKey: 'modified_by',
});

Users.hasMany(Useractivehistory, {
    foreignKey: 'created_by', // Replace with the actual foreign key in the junction table that corresponds to Users
    otherKey: 'id',
    as: 'userhistories'
});

Useractivehistory.belongsTo(Users, {
    foreignKey: 'created_by',
});
module.exports = Users;
