
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const MeetingInvitationModel = require('../meeting/MeetingInvitationModel');
const MeetingMomModel = require('../meetingMom/MeetingMomModel');
const Users = require('../Users');
const MainmeetingModel = sequelize.define('bg_main_meetings', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },

    meeting_type: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1',
        comment: '1-online,2-offline'

    },
    meeting_date: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    start_time: {
        type: DataTypes.TIME,
        allowNull: true,
    },
    end_time: {
        type: DataTypes.TIME, 
        allowNull: true,
    },
    meeting_link: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    meeting_address: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    meeting_title: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    meeting_discerption: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    meeting_host: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false
    },
    reminder_before_val: {
        type: DataTypes.STRING,
        allowNull: true
    },
    reminder_before_type: {
        type: DataTypes.STRING,
        allowNull: true
    },
    meeting_status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2', '3', '4'

        ],
        defaultValue: '1',
        comment: '1-waiting,2-live,3-finished,4-cancelled'
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    is_mom: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'
        ],
        defaultValue: '2'
    },

    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

MainmeetingModel.hasMany(MeetingInvitationModel, {
    foreignKey: 'meeting_id',
});
MainmeetingModel.belongsTo(Users, {
    foreignKey: 'meeting_host',
    as: 'hostname',

});


MainmeetingModel.hasOne(MeetingMomModel, {
    foreignKey:'meeting_id',
})
module.exports = MainmeetingModel;