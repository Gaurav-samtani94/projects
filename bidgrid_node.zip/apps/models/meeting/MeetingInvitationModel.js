
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Users = require('../Users');
const MeetingInvitationModel = sequelize.define('bg_meeting_invitations', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    project_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    meeting_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    send_invitation: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    send_invitation_other: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {

        type: DataTypes.INTEGER,
        allowNull: true,
    },

});
MeetingInvitationModel.belongsTo(Users, {
    foreignKey: 'send_invitation',
});

module.exports = MeetingInvitationModel;