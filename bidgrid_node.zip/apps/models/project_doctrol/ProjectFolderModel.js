
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const ProjectFilesModel = require('./ProjectFilesModel')
// const ListType = require('./ListTypeModel')
const ProjectFolderModel = sequelize.define('project_dctr_folders', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    project_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    parent_id: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    folder_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    is_deleteable: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '1', '2'

        ],
        defaultValue: '2'
    },
    parent_id: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});

ProjectFolderModel.hasMany(ProjectFilesModel, {
    foreignKey: 'folder_id',
    sourceKey:'id'
});

module.exports = ProjectFolderModel;    