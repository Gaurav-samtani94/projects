
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
//const ListTypeModel = require('./ListTypeModel');

const ProjectFilesModel = sequelize.define('project_dctr_files', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: false,
    },
    folder_id: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    document_title: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    document_file_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    document_file_path: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    exten: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});

// GenralFiles.hasMany(ListTypeModel, {
//     foreignKey: 'id',
//     sourceKey:'id'
// });

module.exports = ProjectFilesModel;    