const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
// const ReqDesignationModel = require('../requisition/ReqDesignationModel');
// const TeamreqAssingdesignationModel = require('../requisition/TeamreqAssingdesignationModel');
const ReqCategoryModel = sequelize.define('bg_mstr_tm_rq_categories', {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    category_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.BIGINT,
        allowNull: true,
    },

});



module.exports = ReqCategoryModel;