const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const ReqDesignationModel = require('../requisition/ReqDesignationModel')
const ReqCategoryModel = require('../requisition/ReqCategoryModel')
const TeamreqAssingdesignationModel = sequelize.define('bg_tm_rq_designation_on_proj', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    project_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    desig_category_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true,

    },
    designation_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
});

TeamreqAssingdesignationModel.hasMany(ReqCategoryModel, {
    foreignKey: 'id',
    sourceKey: 'desig_category_id',
  
  });

  TeamreqAssingdesignationModel.hasMany(ReqDesignationModel, {
    foreignKey: 'id',
    sourceKey: 'designation_id',
  
  });


  



module.exports = TeamreqAssingdesignationModel;