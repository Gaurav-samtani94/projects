const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const ReqDesignationModel = require('../requisition/ReqDesignationModel')
const ReqNegotiationTeams = require('../requisition/ReqNegotiationTeams')

const TeamNotiationMemberModel = sequelize.define('bg_tm_rq_negotiation_members', {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    category_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    designation_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    age_limit: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    man_months: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    construction_months: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    development_months: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    om_months: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    current_staus: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '1',
        comment: '1-vacant,2-occupied'
    },
    weightage_marks: {
        type: DataTypes.DOUBLE,
        allowNull: false,
    },
    remarks: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    lock: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '0'
    },
    mail_send: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});

TeamNotiationMemberModel.belongsTo(ReqDesignationModel, {
    foreignKey: 'designation_id',
    as: 'designation'
});

TeamNotiationMemberModel.hasMany(ReqNegotiationTeams, {
    foreignKey: 'tm_rq_members_id',
    sourceKey: 'id'
})


module.exports = TeamNotiationMemberModel;