const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database')
const ReqDesignationModel = require('../requisition/ReqDesignationModel')


const ReqNegotiationTeams = sequelize.define('bg_tm_rq_negotiation_teams', {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    tm_rq_members_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    category_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    designation_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    fullname: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    date_of_birth: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    working_exp: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    can_resume: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    file_path: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    remarks: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    curr_status: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: '2'
    },
    status: {
        type: DataTypes.ENUM,
        values: ['0', '1'],
        defaultValue: '1'
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

})

ReqNegotiationTeams.belongsTo(ReqDesignationModel, {
    foreignKey: 'designation_id',
    as: 'designation'
});

module.exports = ReqNegotiationTeams;