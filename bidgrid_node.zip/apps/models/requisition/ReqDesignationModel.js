const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const ReqCategoryModel = require('../requisition/ReqCategoryModel');


const ReqDesignationModel = sequelize.define('bg_mstr_tm_rq_designations', {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    category_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        foreignKey: true
    },
    designation_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});

ReqDesignationModel.hasMany(ReqCategoryModel, {
    foreignKey: 'id',
    sourceKey: 'category_id',
})



module.exports = ReqDesignationModel;