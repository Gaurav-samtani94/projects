const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const ReqCategoryModel = require('../requisition/ReqCategoryModel');
const TeamreqAssingcategoryModel = sequelize.define('bg_tm_rq_assign_categ_projects', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    category_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    project_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
});
TeamreqAssingcategoryModel.belongsTo(ReqCategoryModel, {
    foreignKey: 'category_id',
});
module.exports = TeamreqAssingcategoryModel;