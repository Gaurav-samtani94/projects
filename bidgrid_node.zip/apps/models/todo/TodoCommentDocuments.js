
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const TodoCommentDocs = sequelize.define('todo_comment_documents', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,

    },
    task_id: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    doc_name: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    doc_exten: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    doc_path: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },

    status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '1'
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },


});
module.exports = TodoCommentDocs;    