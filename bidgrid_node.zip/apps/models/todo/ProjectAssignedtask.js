
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
// const Todolist = require('./Todolist');
const Users = require('../Users');

const ProjectAssigntaskModel = sequelize.define('project_todo_assigned_tasks', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    project_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    task_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    assigned_to_userid: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    assign_type: {
        type: DataTypes.TINYINT,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: ['0', '1', '2'],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
});


// // Assignedtask.belongsTo(Todolist
//     , {
//     foreignKey: 'task_id',
//     targetKey:'id',
//     // sourceKey: 'id',
//     // as: 'assigned_users',
// }

ProjectAssigntaskModel.belongsTo(Users, {
    foreignKey: 'assigned_to_userid',
    // as: "assign_to",
});
ProjectAssigntaskModel.belongsTo(Users, {
    foreignKey: 'assigned_to_userid',
    as: "assin_by",
});

// Assignedtask.belongsTo(Todolist, {
//     foreignKey: 'task_id',
//     as: "task_name",
// });

module.exports = ProjectAssigntaskModel;
