const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../../config/database"); // Import your Sequelize instance
const MenuPermission = require('../../models/roleandpermission/MenuPermissionModel')
const MenuPermissionModel = sequelize.define("bg_mstr_menus", {
    id: {
        type: DataTypes.BIGINT(20),
        autoIncrement: true,
        primaryKey: true,
    },
    parent_menu_id: {
        type: DataTypes.INTEGER,
        allowNull: false,

    },
    menu_category: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["1", "2"],
        defaultValue: "2",
    },
    menu_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    action_url: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    icon: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    
    icon_path: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    active_icon: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    is_view:{
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1",'2'],
        defaultValue: "1",
    },
    is_add:{
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1",'2'],
        defaultValue: "1",
    },
    is_update:{
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1",'2'],
        defaultValue: "1",
    },
    is_delete:{
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1",'2'],
        defaultValue: "1",
    },
    is_download: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1"],
        defaultValue: "1",
    },
    status: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1"],
        defaultValue: "1",
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },


});

// MenuPermissionModel.sync({alter:true})


MenuPermissionModel.belongsTo(MenuPermission,{
    foreignKey:'id',
    targetKey:'menu_id'
})
module.exports = MenuPermissionModel;
