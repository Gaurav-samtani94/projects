const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../../config/database"); // Import your Sequelize instance
const ActionPermissionModel = sequelize.define("action_permission_masters", {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    action_name: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: ["0", "1"],
        defaultValue: "1",
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

});

module.exports = ActionPermissionModel;
