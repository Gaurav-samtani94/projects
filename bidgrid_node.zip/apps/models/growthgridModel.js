const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const ContactUs = sequelize.define('ContactUs', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    email: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    phone: {
        type: DataTypes.CHAR(20),
        allowNull: false,
    },
    comp_name: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    designation:{
        type: DataTypes.STRING(100),
        allowNull:true
    },
    subject: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    status: {
        type: DataTypes.TINYINT,
        defaultValue: 1,
    },
    document:{
        type: DataTypes.STRING,
        allowNull: true,
    }
})

// ContactUs.sync();


module.exports = ContactUs;

