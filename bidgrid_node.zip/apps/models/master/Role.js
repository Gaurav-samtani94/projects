
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Role = sequelize.define('bg_mstr_roles', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        //allowNull: true,
    },
    status: {
        type: DataTypes.INTEGER,
        defaultValue: '1'
    },
    role_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    deletable: {
        type: DataTypes.ENUM,
            values: ['0','1','2'],
        defaultValue: '1',
        comment: "1-yes_deletable,2-never-delete"
    },
});
module.exports = Role;