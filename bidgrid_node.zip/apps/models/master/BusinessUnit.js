
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Timezones = require('./Timezones');
const Country = require('./Country');
const State = require('./State');
const City = require('./City');
const Businessunit = sequelize.define('bg_mstr_business_units', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    unit_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    timezone_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    country_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    state_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    city_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});
Businessunit.belongsTo(Timezones, {
    foreignKey: 'timezone_id',
});
Businessunit.belongsTo(Country, {
    foreignKey: 'country_id',
});

Businessunit.belongsTo(State, {
    foreignKey: 'state_id',
});

Businessunit.belongsTo(City, {
    foreignKey: 'city_id',
});
module.exports = Businessunit;    