
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Timezones = sequelize.define('bg_mstr_timezones', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    timezone_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    timezone_abbr: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    offset_value: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    is_varified: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '2'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});
module.exports = Timezones;