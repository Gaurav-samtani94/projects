const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Tenderservice = sequelize.define('bg_mstr_service', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    }, 
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    service_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at:{
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at:{
        type: DataTypes.DATE,
        allowNull: true,
    }
    
});

module.exports = Tenderservice;