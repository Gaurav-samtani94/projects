const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const MainCompany = sequelize.define('main_companies', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    link_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    company_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    company_details: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    contact_no: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    email_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    country: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    state: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    company_website: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    operating_countries: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    com_sector: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    comp_field_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    fax_no: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    brochure: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    company_logo: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    full_address_ro: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    parent_com_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    child_com_name: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    com_merge_flag: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    tender_filter_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    add_parent_com: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    is_varified: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '2'
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});
module.exports = MainCompany;