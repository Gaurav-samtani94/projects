const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const ActionPerm = require('../roleandpermission/ActionPerm');
const MasterModulesModel = sequelize.define('bg_mstr_modules', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    parent_id: {
        type: DataTypes.FLOAT,
        allowNull: false,
    },
    modules_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    status: {
        type: DataTypes.TINYINT,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});


MasterModulesModel.belongsTo(ActionPerm, {
    foreignKey: 'id',
    targetKey: 'menu_id'
});

module.exports = MasterModulesModel;