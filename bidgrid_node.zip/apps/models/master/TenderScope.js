const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
// const TenderModel = require('../tender/TenderModel');
// const TenderSubscope = require('./TenderSubscope');
const Tenderscope = sequelize.define('bg_mstr_tndr_cycles', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    cycle_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    order_sr: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    deletable: {
        type: DataTypes.ENUM,
        values: ['0', '1', '2'],
        defaultValue: '1',
        comment: "1-yes_deletable,2-never-delete"
    },
    category: {
        type: DataTypes.ENUM,
        values: ['1', '2'],
        defaultValue: '1',
        comment: "1-default,2-not show"
    },

});
// Tenderscope.hasOne(TenderModel, {
//     // foreignKey: 'cycle_id',
//     sourceKey: 'cycle_id', // The field to compare in the source model (TenderModel)
//     // as: 'inactions'

// });
// Tenderscope.hasMany(TenderSubscope, {
//     foreignKey: 'scope_id',
//     sourceKey: 'id', // The field to compare in the source model (TenderModel)
// });
module.exports = Tenderscope;