const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');

const ContactUs = sequelize.define('ContactUs', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    email: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    comp_name: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    designation: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    subject: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    document: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    path: {
        type: DataTypes.STRING,
        allowNull: true,
    }
})

// ContactUs.sync();


module.exports = ContactUs;

