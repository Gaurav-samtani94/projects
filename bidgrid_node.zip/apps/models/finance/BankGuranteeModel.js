
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const BankModel = require("./BankModel");
const PerformancedetailModel = sequelize.define('bg_performance_details', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    bg_type: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'
        ]
    },
    bg_bank: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    bg_title: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    bg_amount: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    bg_number: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    bg_start_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    bg_validity: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    bg_status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '1'
    },
    amount_received: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});
PerformancedetailModel.belongsTo(BankModel, {
    foreignKey: 'bg_bank',
});
module.exports = PerformancedetailModel;    