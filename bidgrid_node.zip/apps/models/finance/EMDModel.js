
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const EMDModel = sequelize.define('bg_emd_details', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    tender_id: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    payment_mode: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'
        ]
    },
    emd_fee_type: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'
        ]
    },
    payment_link: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    emd_currency: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    emd_amount: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    emd_assign_to: {
        type: DataTypes.BIGINT(20),
        allowNull: true,
    },
    emd_payable_to: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    emd_payable_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    emd_remark: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    emd_validity: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    emd_status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1', '2'

        ],
        defaultValue: '0'
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});
module.exports = EMDModel;    