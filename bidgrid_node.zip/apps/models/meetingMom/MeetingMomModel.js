
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const MeetingMainModel = require('../meeting/MainmeetingModel');
const MeetingMomModel = sequelize.define('bg_meeting_mom', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,

    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    meeting_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    file_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_path: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});


// MeetingMomModel.belongsTo(MeetingMainModel, {
//     foreignKey: 'id',

// });
module.exports = MeetingMomModel