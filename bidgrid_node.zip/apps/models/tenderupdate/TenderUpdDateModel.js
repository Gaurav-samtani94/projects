// module.exports = TenderDocModel;
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const createTenderDateUpd = (comp_id) => {
    const tableName = `bg_upd_corr_date_${comp_id}s`;
    const TenderDATEupd = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        upd_bg_tndr_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        publish_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        bid_opening_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        document_download_start_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        document_download_end_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        clarification_start_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        clarification_end_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        bid_submission_start_date: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        bid_submission_end_date: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        prebid_meeting_date: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },

        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
    });
    // Add other attributes here...
    TenderDATEupd.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderDATEupd.sync();
    return TenderDATEupd;
};

module.exports = createTenderDateUpd;
