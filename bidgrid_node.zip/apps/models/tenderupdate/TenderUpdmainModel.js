// module.exports = TenderDocModel;
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const CorrTypemasterModel = require('../tenderupdate/CorrTypemasterModel');
const createTenderAutoExtUpd = require('./TenderUpdAutoExtModel');
const createTenderDateUpd = require('./TenderUpdDateModel');
const createTenderFeeUpd = require('./TenderUpdfeeModel');
const createTenderMainUpd = (comp_id) => {
    const tableName = `bg_upd_gg_main_tndr_${comp_id}s`;
    const Tendermainupd = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        tg_corr_upd_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        tg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        fin_year: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        corrigendum_type_master: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        website_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        corr_title: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        corr_desc: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        corr_reason: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        published_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        corr_desc: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        document_name: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        doc_path: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        document_size: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        tender_category: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },

        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        is_update_done: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '0'
        },

    });
    // Add other attributes here...
    Tendermainupd.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    Tendermainupd.sync();

    const TenderAutoExtupd = createTenderAutoExtUpd(comp_id);
    const TenderFeeupd = createTenderFeeUpd(comp_id);
    const TenderDATEupd = createTenderDateUpd(comp_id);

    Tendermainupd.belongsTo(CorrTypemasterModel, {
        foreignKey: 'corrigendum_type_master',
    });
    Tendermainupd.hasOne(TenderAutoExtupd, {
        foreignKey: 'upd_bg_tndr_id',
        sourceKey: 'id',
        as: 'autoextention'
    });
    Tendermainupd.hasOne(TenderFeeupd, {
        foreignKey: 'upd_bg_tndr_id',
        sourceKey: 'id',
        as: 'feeupdate'

    });
    Tendermainupd.hasOne(TenderDATEupd, {
        foreignKey: 'upd_bg_tndr_id',
        sourceKey: 'id',
        as: 'deteupdate'

    });

    return Tendermainupd;
};


module.exports = createTenderMainUpd;
