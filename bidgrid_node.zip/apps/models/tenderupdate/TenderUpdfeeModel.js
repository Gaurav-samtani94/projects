// module.exports = TenderDocModel;
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const createTenderFeeUpd = (comp_id) => {
    const tableName = `bg_upd_corr_fee_${comp_id}s`;
    const TenderFeeupd = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        upd_bg_tndr_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
        },
        tender_fee: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        currency: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        processing_fee: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        fee_payable_to: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        fee_payable_at: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        tender_fee_exemption_allowed: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        emd_amount: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        emd_exemption_allowed: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        emd_fee_type: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        emd_percentage: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        emd_payable_to: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        emd_payable_at: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },

        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
    });
    // Add other attributes here...
    TenderFeeupd.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderFeeupd.sync();
    return TenderFeeupd;
};

module.exports = createTenderFeeUpd;
