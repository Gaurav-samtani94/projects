const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database');
const createTenderEmdModel = (comp_id) => {
    const tableName = `bg_dump_main_tndr_emd_${comp_id}s`;
    const TenderModelemdtrash = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20),
            autoIncrement: true,
            primaryKey: true,
        },
        tndr_emd_id: {
            type: DataTypes.BIGINT(20),
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20),
            allowNull: false,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20),
            allowNull: false,
        },
        emd_amount: {
            type: DataTypes.DOUBLE,
            allowNull: true,
        },
        currency: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        emd_fee_type: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        emd_payable_to: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        emd_payable_at: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        emd_percentage: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        emd_through_BG_ST_orEMD_exemption_allowed: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM('0', '1'),
            defaultValue: '1',
            allowNull: false,
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        deleted_by: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        deleted_at: {
            type: DataTypes.DATE,
            allowNull: false,

        }
    });

    TenderModelemdtrash.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };

    TenderModelemdtrash.sync();
    return TenderModelemdtrash;
};

module.exports = createTenderEmdModel;
