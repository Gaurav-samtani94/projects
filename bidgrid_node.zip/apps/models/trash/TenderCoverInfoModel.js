const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const createTenderCoverModel = (comp_id) => {
    const tableName = `bg_dump_main_tndr_cover_info_${comp_id}s`;
    const TenderTrashModelcoverinfo = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20),
            primaryKey: true,
            autoIncrement: true,
        },
        cover_info_id: {
            type: DataTypes.BIGINT(20),
            allowNull: false,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20),
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20),
            allowNull: true,
        },
        cover_type: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        doc_type: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM('0', '1'),
            defaultValue: '1',
            allowNull: false,
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        deleted_by: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        deleted_at: {
            type: DataTypes.DATE,
            allowNull: false,

        }
    });
    TenderTrashModelcoverinfo.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    // Relationships with other models can be defined here
    TenderTrashModelcoverinfo.sync();
    return TenderTrashModelcoverinfo;
};

module.exports = createTenderCoverModel;
