const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const createTenderDatesModel = (comp_id) => {
    const tableName = `bg_dump_main_tndr_dates_${comp_id}s`;
    const Tendertarshdatemodal = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(11),
            primaryKey: true,
            autoIncrement: true,
        },
        tndr_dates_id: {
            type: DataTypes.BIGINT(20),
            allowNull: false,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20),
            allowNull: false,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20),
            allowNull: false,
        },
        tnd_published_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        tnd_published_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        bid_opening_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        bid_opening_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        doc_download_start_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        doc_download_start_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        doc_download_end_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        doc_download_end_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        clarification_start_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        clarification_start_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        clarification_end_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        clarification_end_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        bid_submission_start_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        bid_submission_start_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        bid_submission_end_date: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        bid_submission_end_time: {
            type: DataTypes.TIME,
            allowNull: true,
        },
        status: {
            type: DataTypes.ENUM('0', '1'),
            defaultValue: '1',
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        created_by: {
            type: DataTypes.INTEGER(11),
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_by: {
            type: DataTypes.INTEGER(11),
            allowNull: true,
        },
        deleted_by: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        deleted_at: {
            type: DataTypes.DATE,
            allowNull: false,

        }
    });

    Tendertarshdatemodal.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };

    Tendertarshdatemodal.sync();
    return Tendertarshdatemodal;
};

module.exports = createTenderDatesModel;
