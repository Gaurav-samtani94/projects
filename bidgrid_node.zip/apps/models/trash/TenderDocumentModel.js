const { DataTypes } = require('sequelize');
const sequelize = require('../../../apps/config/database'); // Import your Sequelize instance
const createTenderDocumentModel = (comp_id) => {
    const tableName = `bg_dump_tndr_documents_${comp_id}s`;
    const TenderModeldocstrash = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        tndr_documents_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true
        },
        file_doc_type: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        file_name: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        comment: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        type: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true
        },
        doc_path: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        file_doc_description: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        tender_category: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },

        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
            defaultValue: '0'
        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },
        updated_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        deleted_by: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        deleted_at: {
            type: DataTypes.DATE,
            allowNull: false,

        }
    });
    // Add other attributes here...

    TenderModeldocstrash.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };
    TenderModeldocstrash.sync();
    return TenderModeldocstrash;
};
module.exports = createTenderDocumentModel;