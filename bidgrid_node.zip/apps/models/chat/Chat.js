const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Users = require('../Users');
const Chat = sequelize.define('chats', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },

    from_user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    to_user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    message: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    is_file: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '1', '2'

        ],
        defaultValue: '2',
        comment: "1-yes,2-no"
    },
    file_name: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    original_file_name: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    extention: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_type: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    chat_room_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    is_group: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '1', '2'

        ],
        defaultValue: '1',
        comment: "1-Single chat,2-group chat"
    },

    group_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    is_delete: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '0', '1'

        ],
        defaultValue: '0',
        comment: "0-Not Delete,1-Delete"
    },
    read: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '0', '1'

        ],
        defaultValue: '0',
        comment: "0-Not Read,1-Read"
    },

    read_time: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});
Chat.belongsTo(Users, {
    foreignKey: 'from_user_id', // This is the foreign key in TenderGeneratedTypeIdModel
    // targetKey: 'id',
});
module.exports = Chat;