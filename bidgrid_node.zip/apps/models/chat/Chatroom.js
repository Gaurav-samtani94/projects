const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const ChatRooms = sequelize.define('chats_rooms', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },

    from_user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    to_user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    // is_group: {
    //     type: DataTypes.ENUM,
    //     allowNull: false,
    //     values: [
    //         '1', '2'

    //     ],
    //     defaultValue: '1',
    //     comment: "1-Single chat,2-group chat"
    // },
    status: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '0', '1'

        ],
        defaultValue: '1',
    },

    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

});

module.exports = ChatRooms;