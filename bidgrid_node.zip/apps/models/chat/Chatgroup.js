const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Users = require('../Users');
const Chatgroup = sequelize.define('chats_mstr_groups', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },

    group_name: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    group_profile: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '0', '1'

        ],
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});
Chatgroup.belongsTo(Users, {
    foreignKey: 'created_by', // This is the foreign key in TenderGeneratedTypeIdModel
    // targetKey: 'id',
});
module.exports = Chatgroup;