const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Chatgroup = require('./Chatgroup');
const Users = require('../Users');
const ChatgroupMembers = sequelize.define('chats_group_members', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    group_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '0', '1'

        ],
        defaultValue: '1',
    },

    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});
ChatgroupMembers.belongsTo(Chatgroup, {
    foreignKey: 'group_id', // This is the foreign key in TenderGeneratedTypeIdModel
    // targetKey: 'id',
});
ChatgroupMembers.belongsTo(Users, {
    foreignKey: 'user_id', // This is the foreign key in TenderGeneratedTypeIdModel
    // targetKey: 'id',
});

module.exports = ChatgroupMembers;