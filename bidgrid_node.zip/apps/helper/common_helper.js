const Tenderpartners = require('../models/tender/TenderPartner')
class ConsortiumChecker {
    static async consortium_existence(req) {
        try {
            const consortium_existence = await Tenderpartners.findAll({
                where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, consortium: 1 },
                attributes: ['id','lead_comp_ids','project_id'],
            });
            return consortium_existence;
        } catch (error) {
            throw error;
        }
    }
}
module.exports = ConsortiumChecker;