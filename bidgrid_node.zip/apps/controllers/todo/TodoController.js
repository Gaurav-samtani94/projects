const { Sequelize, DataTypes, Op, literal } = require('sequelize');
const jwt = require('jsonwebtoken');
const Joi = require('joi');
require('dotenv').config();
const TodoModel = require('../../models/todo/Todolist');
const HashtagModel = require('../../models/todo/Hashtag');
const AssigntaskModel = require('../../models/todo/Assignedtask');
const TodoCommentModel = require('../../models/todo/TodoCommentModel');
const TodoCommentDocs = require('../../models/todo/TodoCommentDocuments');
const ToDoTaskMoveHistoryModel = require('../../models/todo/ToDoTaskMoveHistoryModel');
const Users = require('../../models/Users');
const Assignedtaskserialnumber = require('../../models/todo/Assigntaskserialnumber')
const max = 10;
const min = 1;
const moment = require('moment-timezone');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const getCurrentDateTime = () => new Date();
//To Do Add ...
const todo_create_task = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        task_type: req.body.task_type,
        task_name: req.body.task_name,
        task_priority: req.body.task_priority,
        hash_tags: req.body.hash_tags,
        current_scope: req.body.current_scope,
        assign_type: req.body.assign_type,
        user_creater_id: req.userId,
        task_description: req.body.task_description,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
        // updated_at:  getCurrentDateTime(),
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        task_type: Joi.number().required(),
        task_name: Joi.string().required(),
        task_priority: Joi.string().required(),
        hash_tags: Joi.string().required(),
        current_scope: Joi.number().required(),
        assign_type: Joi.number().required(),
        user_creater_id: Joi.number().required(),
        task_description: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        // updated_at: Joi.date().iso().required()

    });

    console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const RecdExistCheck = await TodoModel.findOne({ where: { user_comp_id: req.comp_id, task_name: req.body.task_name, status: 1 }, attributes: ['id'] });
            if (RecdExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {

                if ((req.body.project_id) && (req.body.task_type == 2)) {
                    dataToValidate['project_id'] = req.body.project_id;
                }
                if (req.body.deadline_date) {
                    dataToValidate['deadline_date'] = req.body.deadline_date;
                }

                const Inserted_ID = await TodoModel.create(dataToValidate);

                if (Inserted_ID) {
                    const existingRecords = [];
                    const recordsToCreate = [];

                    //####################################################
                    //############### Start Hastags Code #######################
                    //####################################################
                    if (dataToValidate.hash_tags) {
                        const delimiter = ',';
                        const response_data = dataToValidate.hash_tags.split(delimiter);

                        for (const tagsdata of response_data) {
                            const existingRecord = await HashtagModel.findOne({ where: { user_comp_id: req.comp_id, hashtag_name: tagsdata } });
                            if (existingRecord) {
                                existingRecords.push(existingRecord);
                            } else {
                                recordsToCreate.push(
                                    {
                                        user_comp_id: req.comp_id,
                                        hashtag_name: tagsdata,
                                        created_by: req.userId,
                                        created_at: getCurrentDateTime()

                                    });
                            }
                        }

                        if (recordsToCreate.length > 0) {
                            const RecordsInserted = await HashtagModel.bulkCreate(recordsToCreate);
                        }
                    }
                    //####################################################
                    //############### Close Hastags Code #######################
                    //####################################################



                    //################################################################
                    //################## Start Code Assigned Task To EMP  #####################
                    //################################################################
                    if (dataToValidate.assign_type == "2") {
                        const existingRecords_2 = [];
                        const recordsToCreate_2 = [];

                        if (req.body.assigned_to_users) {
                            const AssignedUsers = req.body.assigned_to_users + ',' + req.userId;
                            const delimiter_2 = ',';
                            const response_data_2 = AssignedUsers.split(delimiter_2);

                            for (const empl_id of response_data_2) {
                                const existingRecd = await AssigntaskModel.findOne({ where: { user_comp_id: req.comp_id, task_id: Inserted_ID.id, assigned_to_userid: empl_id, status: '1' } });
                                if (existingRecd) {
                                    existingRecords_2.push(existingRecd);
                                } else {
                                    recordsToCreate_2.push({
                                        user_comp_id: req.comp_id,
                                        task_id: Inserted_ID.id,
                                        assigned_to_userid: empl_id,
                                        assign_type: Inserted_ID.assign_type,
                                        created_by: req.userId,
                                        created_at: getCurrentDateTime(),
                                    });
                                }
                            }

                            if (recordsToCreate_2.length > 0) {
                                const RecdInsert = await AssigntaskModel.bulkCreate(recordsToCreate_2);
                            }
                        }
                    }


                    if (dataToValidate.assign_type == "1") {
                        const recordsToCreate_3 = {
                            user_comp_id: req.comp_id,
                            task_id: Inserted_ID.id,
                            assigned_to_userid: req.userId,
                            assign_type: Inserted_ID.assign_type,
                            created_by: req.userId,
                            created_at: getCurrentDateTime()
                        }

                        if (recordsToCreate_3) {
                            const RecdInsert = await AssigntaskModel.create(recordsToCreate_3);
                        }

                    }

                    //################################################################
                    //################## Close Code Assigned Task To EMP  ##################
                    //################################################################
                }

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: Inserted_ID
                });

            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};





//To Do Edit ...
const todo_edit_task = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        task_id: req.body.task_id,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        task_id: Joi.number().required(),
    });

    // console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const RecdExistCheck = await TodoModel.findAll({
                where: { user_comp_id: req.comp_id, id: req.body.task_id, status: 1 },
                include: [{
                    model: AssigntaskModel,
                    attributes: ['id', 'assigned_to_userid', 'assign_type'],
                    as: 'assigned_users',
                    where: { status: '1' },
                    required: false,
                }],
            });
            if (!RecdExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPCODE_RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: RecdExistCheck
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};





//To Do Comment Add
const storage_todo_cmt = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const foldername = 'public' + '_' + req.comp_id + '/' + 'todo' + '/' + year + '/' + month + '/' + day + '/' + req.userId + '-' + req.comp_id;
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;
    }
})
const upload_cmt_doc = multer({
    storage: storage_todo_cmt,
    limits: { fileSize: 1024 * 1024 * 5, }
});
const addtodocmt = async (req, res) => {
    upload_cmt_doc.array('files')(req, res, async function (err) {
        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
        const schema = Joi.object().keys({
            user_comp_id: Joi.number().required(),
            task_id: Joi.number().required(),
            parent_id: Joi.number().allow(null),
            ping_users_info: Joi.string().pattern(/^[0-9,]+$/).allow(null),
            parent_id: Joi.number().allow(null),
            comment_txt: Joi.string().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required()
        });
        const dataToValidate = {
            user_comp_id: req.comp_id,
            task_id: req.body.task_id,
            parent_id: req.body.parent_id,
            ping_users_info: req.body.ping_users_info,
            comment_txt: req.body.comment_txt,
            created_by: req.userId,
            created_at: getCurrentDateTime()
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        } else {
            try {
                const response_todo_task_exist = await TodoModel.findOne({
                    where: { user_comp_id: req.comp_id, id: req.body.task_id, status: '1' }
                });

                if (response_todo_task_exist) {
                    const response_insert = await TodoCommentModel.create(dataToValidate);
                    if (response_insert) {
                        const files = req.files;
                        if (files[0]) {
                            const originalFolderPath = files[0].destination;
                            const newNumber = response_insert.id;
                            const pathSegments = files[0].destination.split('/');
                            pathSegments.pop();
                            pathSegments.push(newNumber);
                            const newFolderPath = pathSegments.join('/');
                            fs.rename(originalFolderPath, newFolderPath, (err) => {
                                if (err) {
                                    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                        message: process.env.ERROR_MSG,
                                        error: true,
                                        success: false,
                                        status: '0',
                                    })
                                }
                            })
                            const fileRecords = await TodoCommentDocs.bulkCreate(files.map((file) => ({ created_by: req.userId, user_comp_id: req.comp_id, task_id: response_insert.id, doc_name: file.filename, doc_exten: path.extname(file.filename), doc_path: newFolderPath })));
                            if (!fileRecords[0]) {
                                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                    message: process.env.ERROR_MSG,
                                    error: true,
                                    success: false,
                                    status: '0',
                                })
                            }
                        }
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',
                            data: response_insert,
                        });
                    }
                    else {
                        const files = req.files;
                        if (files) {
                            files.forEach(record => {
                                const filePath = record.path;
                                if (filePath) {
                                    fs.unlink(filePath, err => {
                                    });
                                }
                            })
                        }
                        res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                            message: process.env.APIRESPMSG_RECALREADYEXISTS,
                            error: true,
                            success: false,
                            status: '0',
                        })
                    }
                }
                else {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }

            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    // message: process.env.ERROR_MSG,
                    message: error.message,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
}

//edit todo comment
const edittodocmt = async (req, res) => {
    const schema = Joi.object().keys({
        comment_id: Joi.number().required(),
    });

    const dataToValidate = {
        comment_id: req.body.comment_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const edittodocmt = await TodoCommentModel.findOne({
                where: { id: req.body.comment_id, user_comp_id: req.comp_id }, attributes: ['id', 'task_id', 'comment_txt', 'parent_id', 'ping_users_info'],
            })
            if (!edittodocmt) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: edittodocmt,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


//get todo comment
const todocmtlist = async (req, res) => {
    const schema = Joi.object().keys({
        task_id: Joi.number().required(),
    });

    const dataToValidate = {
        task_id: req.body.task_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        // [literal(`DATE_FORMAT(created_at, '%Y-%m-%d')`),
        const list = await TodoCommentModel.findAll({
            // order: [['id', 'DESC']],
            where: { user_comp_id: req.comp_id, task_id: req.body.task_id, status: '1' },
            attributes: ['id', 'task_id', 'comment_txt', ['file_attachment', 'file_name'], 'file_path', 'parent_id', 'created_at', 'created_by']
        });
        try {
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//Update Scope By Task Id..
const UpdateScopeByTaskId = async (req, res) => {
    const schema = Joi.object().keys({
        task_id: Joi.number().required(),
        current_scope: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });
    const dataToValidate = {
        task_id: req.body.task_id,
        current_scope: req.body.current_scope,
        user_comp_id: req.comp_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await TodoModel.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.task_id }, attributes: ['id'] });
            if (existData) {
                const UpdateDataArr = {
                    current_scope: req.body.current_scope,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update = await TodoModel.update(UpdateDataArr, {
                    where: { status: "1", user_comp_id: req.comp_id, id: req.body.task_id }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}

//Lising data..
const ListHastagMaster = async (req, res) => {
    try {
        const response = await HashtagModel.findAll({
            order: [['hashtag_name', 'ASC']],
            where: { status: '1', user_comp_id: req.comp_id },
            attributes: ['id', 'hashtag_name'],
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,

            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: error.message,
            // message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        })
    }
}

// List of changed scope in tasks (history)
const ListTaskScopeMove = async (req, res) => {
    try {
        const response = await TodoModel.findAll({
            order: [['id', 'ASC']],
            where: { user_comp_id: req.comp_id },
            attributes: ['id', 'task_name', 'task_priority', 'hash_tags'],
            include: [
                {
                    model: ToDoTaskMoveHistoryModel,
                    attributes: ['id', 'current_scope'],
                    where: { user_comp_id: req.comp_id },
                    required: false,
                }
            ]
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,

            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: error.message,
            // message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        })
    }
}

// Document upload on task
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'Todo Task Docs';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;

    },
});
const upload = multer({ storage: storage });
const uploadTaskDocument = async (req, res) => {
    upload.array('files')(req, res, async function (err) {

        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        } else {
            const schema = Joi.object().keys({
                task_id: Joi.number().required(),
                created_by: Joi.number().integer().required(),
                created_at: Joi.date().iso().required(),
                user_comp_id: Joi.number().integer().required()
            });

            const dataToValidate = {
                task_id: req.body.task_id,
                created_by: req.userId,
                created_at: getCurrentDateTime(),
                user_comp_id: req.comp_id
            };

            const result = schema.validate(dataToValidate);
            if (result.error) {
                res.status(process.env.APIRESPCODE_VALIDATION).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: result.error.details[0].message
                });
            } else {
                try {
                    const files = req.files;
                    if (files.length != 0) {
                        const folderPath = files[0].destination;
                        const fileRecords = await TodoCommentDocs.bulkCreate(files.map((file) => (
                            {
                                created_by: req.userId, user_comp_id: req.comp_id, task_id: req.body.task_id,
                                doc_name: file.filename, doc_exten: path.extname(file.filename),
                                doc_path: folderPath, created_at: getCurrentDateTime()
                            })));

                        if (!fileRecords[0]) {
                            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                message: process.env.ERROR_MSG,
                                error: true,
                                success: false,
                                status: '0',
                            })
                        } else {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECINSERTED,
                                error: false,
                                success: true,
                                status: '1',
                            });
                        }

                    } else {
                        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                            message: "No File Selected",
                            error: false,
                            success: true,
                            status: '1',
                        });
                    }
                } catch (error) {
                    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                        message: process.env.ERROR_MSG,
                        error: error.message,
                        success: false,
                        status: '0',
                    })
                }
            }

        }

    });
}

// Task Document list
const ListTaskDocs = async (req, res) => {
    try {
        const response = await TodoModel.findAll({
            order: [['id', 'ASC']],
            where: { user_comp_id: req.comp_id },
            attributes: ['id', 'task_name', 'task_priority', 'hash_tags'],
            include: [
                {
                    model: TodoCommentDocs,
                    attributes: ['id', 'doc_name', 'doc_path'],
                    where: { user_comp_id: req.comp_id, status: '1' },
                    required: false,
                }
            ]
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,

            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: error.message,
            // message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        })
    }
};


const deleteTaskDocument = async (req, res) => {
    const dataToValidate = {
      document_id: req.body.document_id,
    };
  
    const schema = Joi.object().keys({
      document_id: Joi.number().required(),
    });
  
    // console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
      res.status(process.env.APIRESPCODE_VALIDATION).send({
        error: true,
        success: false,
        status: "0",
        message: result.error.details[0].message,
      });
    } else {
      try {
        const response = await TodoCommentDocs.findAll({
          where: { user_comp_id: req.comp_id, id: req.body.document_id, status: '1' },
        });
        if (!response[0]) {
          return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
            error: true,
            success: false,
            status: "0",
            message: process.env.APIRESPMSG_RECNOTFOUND,
          });
        } else {
          if(response[0].created_by != req.userId){
              return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                  message: 'You are not allowed',
                  error: true,
                  success: false,
                  status: "0",
              });
  
          }
          const updateData = {
            status: '2',
            updated_by: req.userId,
            updated_at: getCurrentDateTime(),
          };
  
          const deleteDocument = await TodoCommentDocs.update(updateData, {
              where: {
                  id: req.body.document_id,
                  user_comp_id: req.comp_id,
                  created_by: req.userId,
              }
          })
  
          if(deleteDocument){
              return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                  message: process.env.APIRESPMSG_RECDELETED,
                  error: false,
                  success: true,
                  status: "1",
              });
          }
  
        }
      } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
          message: error.message,
          // message: process.env.ERROR_MSG,
          error: true,
          success: false,
          status: "0",
        });
      }
    }
  };
  

// Update uploaded task documents
const updateUploadTaskDocument = async (req, res) => {
    upload.array('files')(req, res, async function (err) {
        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        } else {
            const schema = Joi.object().keys({
                task_id: Joi.number().required(),
                created_by: Joi.number().integer().required(),
                created_at: Joi.date().iso().required(),
                user_comp_id: Joi.number().integer().required()
            });

            const dataToValidate = {
                task_id: req.body.task_id,
                created_by: req.userId,
                created_at: getCurrentDateTime(),
                user_comp_id: req.comp_id
            };

            const result = schema.validate(dataToValidate);
            if (result.error) {
                res.status(process.env.APIRESPCODE_VALIDATION).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: result.error.details[0].message
                });
            } else {
                try {
                    const files = req.files;
                    console.log(files, 'filesfiles')
                    if (files.length != 0) {
                        const deleteOldAttachment = await TodoCommentDocs.update({ status: 2 }, {
                            where: {
                                task_id: req.body.task_id
                            }
                        });
                        const folderPath = files[0].destination;
                        const fileRecords = await TodoCommentDocs.bulkCreate(files.map((file) => (
                            {
                                created_by: req.userId, user_comp_id: req.comp_id, task_id: req.body.task_id,
                                doc_name: file.filename, doc_exten: path.extname(file.filename),
                                doc_path: folderPath, created_at: getCurrentDateTime()
                            })));

                        if (!fileRecords[0]) {
                            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                message: process.env.ERROR_MSG,
                                error: true,
                                success: false,
                                status: '0',
                            })
                        } else {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECUPDATED,
                                error: false,
                                success: true,
                                status: '1',
                            });
                        }

                    } else {
                        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                            message: "No File Selected",
                            error: false,
                            success: true,
                            status: '1',
                        });
                    }
                } catch (error) {
                    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                        // message: error.message,
                        message: process.env.ERROR_MSG,
                        error: error.message,
                        success: false,
                        status: '0',
                    })
                }
            }

        }

    });
};



//To Do Update ...
const todo_update_task = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        task_id: req.body.task_id,
        task_type: req.body.task_type,
        task_name: req.body.task_name,
        task_priority: req.body.task_priority,
        hash_tags: req.body.hash_tags,
        current_scope: req.body.current_scope,
        assign_type: req.body.assign_type,
        user_creater_id: req.userId,
        task_description: req.body.task_description,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        task_id: Joi.number().required(),
        task_type: Joi.number().required(),
        task_name: Joi.string().required(),
        task_priority: Joi.string().required(),
        hash_tags: Joi.string().required(),
        current_scope: Joi.number().required(),
        assign_type: Joi.number().required(),
        user_creater_id: Joi.number().required(),
        task_description: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const RecdExistCheck = await TodoModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.task_id, status: 1 }, attributes: ['id', 'user_creater_id'] });
            //code modified by abhimanyu 2-2-2024 start 
            const RecdExistCheck_task = await TodoModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    task_name: req.body.task_name,
                    status: 1,
                    id: {
                        [Op.ne]: req.body.task_id
                    },
                }, attributes: ['id']
            });
            if (RecdExistCheck_task) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            //code modified by abhimanyu 2-2-2024 end 
            if (!RecdExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {

                const UpdateDataArr = {
                    task_type: req.body.task_type,
                    task_name: req.body.task_name,
                    task_priority: req.body.task_priority,
                    hash_tags: req.body.hash_tags,
                    current_scope: req.body.current_scope,
                    assign_type: req.body.assign_type,
                    task_description: req.body.task_description,
                    updated_at: getCurrentDateTime(),
                    modified_by: req.userId,
                }

                if ((req.body.project_id) && (req.body.task_type == 2)) {
                    UpdateDataArr['project_id'] = req.body.project_id;
                }
                if (req.body.deadline_date) {
                    UpdateDataArr['deadline_date'] = req.body.deadline_date;
                }

                const UpdatedID = await TodoModel.update(UpdateDataArr, {
                    where: { user_comp_id: req.comp_id, id: req.body.task_id, status: 1 }
                });


                if (UpdatedID) {
                    const existingRecords = [];
                    const recordsToCreate = [];
                    //####################################################
                    //############### Start Hastags Code #######################
                    //####################################################
                    if (dataToValidate.hash_tags) {
                        const delimiter = ',';
                        const response_data = dataToValidate.hash_tags.split(delimiter);
                        for (const tagsdata of response_data) {
                            const existingRecord = await HashtagModel.findOne({ where: { user_comp_id: req.comp_id, hashtag_name: tagsdata } });
                            if (existingRecord) {
                                existingRecords.push(existingRecord);
                            } else {
                                recordsToCreate.push({
                                    user_comp_id: req.comp_id,
                                    hashtag_name: tagsdata,
                                    created_by: req.userId,
                                    created_at: getCurrentDateTime()
                                });
                            }
                        }
                        if (recordsToCreate.length > 0) {
                            const RecordsInserted = await HashtagModel.bulkCreate(recordsToCreate);
                        }
                    }

                    //##########################################################
                    //############### Close Hastags Code #######################
                    //##########################################################

                    //################  Remove All Previous Users ###################
                    //###############################################################
                    if (RecdExistCheck.user_creater_id === req.userId) {
                        const UpdateStatusArr = {
                            status: "0"
                        }
                        const UpdID = await AssigntaskModel.update(UpdateStatusArr, {
                            where: { user_comp_id: req.comp_id, task_id: req.body.task_id, status: 1 }
                        });
                        //#################################################################
                        //#################################################################
                        //################################################################
                        //################## Start Code Assigned Task To EMP  ############
                        //################################################################
                        if (dataToValidate.assign_type == "2") {
                            const existingRecords_2 = [];
                            const recordsToCreate_2 = [];

                            if (req.body.assigned_to_users) {
                                // req.body.assigned_to_users + ',' + req.userId;
                                const AssignedUsers = req.body.assigned_to_users + ',' + req.userId;
                                const delimiter_2 = ',';
                                const response_data_2 = AssignedUsers.split(delimiter_2);
                                for (const empl_id of response_data_2) {
                                    const existingRecd = await AssigntaskModel.findOne({ where: { user_comp_id: req.comp_id, task_id: req.body.task_id, assigned_to_userid: empl_id, status: '1' } });
                                    if (existingRecd) {
                                        existingRecords_2.push(existingRecd);
                                    } else {
                                        recordsToCreate_2.push({
                                            user_comp_id: req.comp_id,
                                            task_id: req.body.task_id,
                                            assigned_to_userid: empl_id,
                                            assign_type: req.body.assign_type,
                                            created_by: req.userId,
                                            created_at: getCurrentDateTime(),
                                        });
                                    }
                                }

                                if (recordsToCreate_2.length > 0) {
                                    const RecdInsert = await AssigntaskModel.bulkCreate(recordsToCreate_2);
                                }
                            }
                        }

                        if (dataToValidate.assign_type == "1") {
                            const recordsToCreate_3 = {
                                user_comp_id: req.comp_id,
                                task_id: req.body.task_id,
                                assigned_to_userid: req.userId,
                                assign_type: req.body.assign_type,
                                created_by: req.userId,
                                created_at: getCurrentDateTime()
                            }
                            if (recordsToCreate_3) {
                                const RecdInsert = await AssigntaskModel.create(recordsToCreate_3);
                            }
                        }
                    }
                    //################################################################
                    //############## Close Code Assigned Task To EMP  ################
                    //################################################################
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: UpdateDataArr
                    });
                }
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};


//Lising of Set Config..
// const list_todo_mytask = async (req, res) => {
//     const dataToValidate = {
//         user_comp_id: req.comp_id,
//         // task_scope: req.body.task_scope,
//     };

//     const schema = Joi.object().keys({
//         user_comp_id: Joi.number().required(),
//         // task_scope: Joi.number().required(),
//     });

//     //console.log(dataToValidate);
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {

//         try {
//             const WhereArrL = [];
//             if (req.body.task_scope > 0) {
//                 WhereArrL.push({ user_comp_id: req.comp_id, status: 1, current_scope: req.body.task_scope });
//             } else {
//                 WhereArrL.push({ user_comp_id: req.comp_id, status: 1 });
//             }

//             const response = await TodoModel.findAll({
//                 where: WhereArrL,
//                 order: [['updated_at', 'DESC']],
//                 include: [{
//                     model: AssigntaskModel,
//                     attributes: ['id', 'assigned_to_userid', 'assign_type'],
//                     as: 'assigned_users',
//                     where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
//                     required: true,

//                 }],
//             });

//             if (!response[0]) {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     error: true,
//                     success: false,
//                     status: '0',
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                 });
//             }
//             res.send({
//                 message: process.env.APIRESPMSG_RECFOUND,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 data: response,
//             });
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }
const list_todo_mytask = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        // task_scope: req.body.task_scope,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        // task_scope: Joi.number().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {
            const WhereArrL = [];
            if (req.body.task_scope > 0) {
                WhereArrL.push({ user_comp_id: req.comp_id, status: 1, current_scope: req.body.task_scope });
            } else {
                WhereArrL.push({ user_comp_id: req.comp_id, status: 1 });
            }
            //   const dataLisT = await Assignedtaskserialnumber.findOne({ where: { user_comp_id: req.comp_id, assign_by: req.userId, status: '1' } })
            const dataLisT = '1';
            if (!dataLisT) {
                const response_1 = await TodoModel.findAll({
                    where: WhereArrL,
                    // order: [['updated_at', 'DESC']],
                    include: [{
                        model: AssigntaskModel,
                        attributes: ['id', 'assigned_to_userid', 'assign_type'],
                        as: 'assigned_users',
                        where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                        required: true,

                    }],
                });
                if (!response_1[0]) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        error: true,
                        success: false,
                        status: '0',
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response_1,
                });

            } else {
                const response_2 = await TodoModel.findAll({
                    where: WhereArrL,
                    // order: [['updated_at', 'DESC']],
                    include: [{
                        model: Assignedtaskserialnumber,
                        order: [['sr_no', 'DESC']],
                        attributes: ['id', 'assigned_to_userid', 'assign_type', 'sr_no'],
                        as: 'assigned_users1',
                        where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                        required: true,

                    }],
                });
                if (!response_2[0]) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        error: true,
                        success: false,
                        status: '0',
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response_2,
                });
            }



        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


// Search Hashtag from task
//Lising of Set Config..
const searchHashtagInTask = async (req, res) => {
    const dataToValidate = {
        hashtag: req.body.hashtag,
        user_comp_id: req.comp_id
        // task_scope: req.body.task_scope,
    };

    const schema = Joi.object().keys({
        hashtag: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        // task_scope: Joi.number().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {
            // const response = await TodoModel.findAll({
            //     where: {
            //         status: 1, user_creater_id: req.userId, user_comp_id: req.comp_id,
            //         hash_tags: { [Op.like]: `%${req.body.hashtag}%` }

            //     },
            //     // attributes: ['id', 'hash_tags'],
            //     order: [['id', 'DESC']],
            // });

            const response2 = await TodoModel.findAll({
                where: {
                    status: 1, hash_tags: { [Op.like]: `%${req.body.hashtag}%` }
                },
                attributes: ['id', 'hash_tags', 'user_creater_id'],
                order: [['id', 'DESC']],
                include: [{
                    model: AssigntaskModel,
                    attributes: ['id'],
                    as: 'assigned_users',
                    where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                    required: true,
                }],
            });
            const mergedResponse = [...response, ...response2];
            if (!mergedResponse[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: mergedResponse,
            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
// const todo_update_srnumber_task = async (req, res) => {
//     const dataToValidate = {
//         user_comp_id: req.comp_id,
//         task_id: req.body.task_id,
//         scope_id: req.body.scope_id,
//         modified_by: req.userId,
//         updated_at:  getCurrentDateTime(),
//     };

//     const schema = Joi.object().keys({
//         user_comp_id: Joi.number().required(),
//         task_id: Joi.number().required(),
//         scope_id: Joi.number().required(),
//         modified_by: Joi.number().required(),
//         updated_at: Joi.date().iso().required()
//     });

//     //console.log(dataToValidate);
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {
//             const RecdExistCheck = await TodoModel.findOne({ where: { user_comp_id: req.comp_id, current_scope: req.body.scope_id, id: req.body.task_id, status: 1 }, attributes: ['id'] });
//             if (!RecdExistCheck) {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     error: true,
//                     success: false,
//                     status: '0',
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                 });
//             }
//             const UpdateDataArr = {
//                 updated_at:  getCurrentDateTime(),
//                 modified_by: req.userId,
//             }
//             await TodoModel.update(UpdateDataArr, { where: { user_comp_id: req.comp_id, current_scope: req.body.scope_id, id: req.body.task_id, status: 1 }, attributes: ['id'] });
//             res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                 message: process.env.APIRESPMSG_RECUPDATED,
//                 error: false,
//                 success: true,
//                 status: '1',
//             });
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// };
const todo_update_srnumber_task = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        // data_serial_number: req.body.data_serial_number,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        // data_serial_number: Joi.string().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required()
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            // const data = {

            //     scopeId: 2,
            //     sequence: {
            //         1: 1,
            //         2: 2,
            //         3: 3,

            //     }
            // };
            // //

            // console.log(req.body.data_serial_number, 'req.body.data_serial_number')
            // console.log(data, 'data')
            // const decodedTableName = decodeURIComponent(req.body.data_serial_number);
            console.log(req.body, 'datadatadatadata')
            const data = req.body;

            const scopeId = data.scopeId;
            const sequence = data.sequence;
            // const RecdExistCheck = await TodoModel.findOne({ where: { user_comp_id: req.comp_id, current_scope: req.body.scope_id, id: req.body.task_id, status: 1 }, attributes: ['id'] });
            // if (!RecdExistCheck) {
            //     return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
            //         error: true,
            //         success: false,
            //         status: '0',
            //         message: process.env.APIRESPMSG_RECNOTFOUND,
            //     });
            // }
            var no = 0;
            const dataLisT = await Assignedtaskserialnumber.findOne({ where: { user_comp_id: req.comp_id, assign_by: req.userId, status: '1' } })
            if (!dataLisT) {
                for (const index in sequence) {
                    no += 1
                    const taskId = sequence[index];
                    const dataLisT_3 = await AssigntaskModel.findOne({ where: { user_comp_id: req.comp_id, task_id: taskId, status: '1' } })
                    await Assignedtaskserialnumber.create({ user_comp_id: req.comp_id, task_id: taskId, task_id: taskId, assigned_to_userid: dataLisT_3.assigned_to_userid, assign_type: dataLisT_3.assign_type, assign_by: req.userId, sr_no: index, scope_id: scopeId, created_by: req.userId, created_at: getCurrentDateTime() });
                    no += 1
                }
            } else {
                for (const index in sequence) {
                    const taskId = sequence[index];
                    const dataLisT_3 = await AssigntaskModel.findOne({ where: { user_comp_id: req.comp_id, task_id: taskId, status: '1' } })
                    await Assignedtaskserialnumber.destroy(
                        {
                            where: { user_comp_id: req.comp_id, task_id: taskId, assign_by: req.userId, scope_id: scopeId }

                        });
                    await Assignedtaskserialnumber.create({ user_comp_id: req.comp_id, task_id: taskId, task_id: taskId, assigned_to_userid: dataLisT_3.assigned_to_userid, assign_type: dataLisT_3.assign_type, assign_by: req.userId, sr_no: index, scope_id: scopeId, created_by: req.userId, updated_by: req.userId, updated_at: getCurrentDateTime() });
                    no += 1
                }
            }
            if (no > 0) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Record Updated',
                    error: false,
                    success: true,
                    status: no,
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: 0,
                });

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};
const list_task_user = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        task_id: req.body.task_id,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        task_id: Joi.number().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {

            const response = await AssigntaskModel.findAll({
                where: {
                    status: '1', user_comp_id: req.comp_id, task_id: req.body.task_id,
                    assigned_to_userid: {
                        [Op.ne]: req.userId
                    }
                },
                include: [

                    {
                        model: Users,
                        attributes: ['userfullname'],
                        // as: "assign_to", // Use a distinct alias for the first association
                        where: { isactive: '1' },
                        required: false,
                    },
                    {
                        model: Users,
                        attributes: ['userfullname'],
                        as: "assin_by", // Use a distinct alias for the first association
                        where: { isactive: '1' },
                        required: false,
                    },
                    // {
                    //     model: TodoModel,
                    //     attributes: ['task_name'],
                    //     as: "task_name", // Use a distinct alias for the first association
                    //     where: { status: '1' },
                    //     required: false,
                    // },
                ],
            });

            if (!response[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,
            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
const list_hastag_search = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        hashtag: req.body.hashtag,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        hashtag: Joi.string().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {
            const hashtag = req.body.hashtag;
            const response = await TodoModel.findAll({
                where: {
                    user_comp_id: req.comp_id,
                    hash_tags: {
                        [Op.like]: `%${hashtag}%`,
                    },
                },
                include: [{
                    model: AssigntaskModel,
                    attributes: ['id', 'assigned_to_userid', 'assign_type'],
                    as: 'assigned_users',
                    where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                    required: true,
                },],
            });
            const tasksWithCount = await Promise.all(response.map(async (task) => {
                const assign_user = await AssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_comment = await TodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_list = await AssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assignedUsersCount = assign_user - 1;
                const taskcommentCount = assign_user_comment;
                return {
                    ...task.toJSON(),
                    assignedUsersCount,
                    taskcommentCount,
                    assign_user_list
                };
            }));
            if (!response[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount,
            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}




const list_todo_scope_mytask = async (req, res) => {
    try {
        console.log(req.userId,"===================")
        console.log(req.comp_id,"==========COMP=========")
        //  const dataLisT = await Assignedtaskserialnumber.findOne({ where: { user_comp_id: req.comp_id, scope_id: '1', assign_by: req.userId, status: '1' } })
        const dataLisT = 0;
        if (!dataLisT) {

            const response_1 = await TodoModel.findAll({
                where: { status: '1', current_scope: '1' },
                order: [['id', 'DESC']],
                include: [{
                    model: AssigntaskModel,
                    attributes: ['id', 'assigned_to_userid', 'assign_type'],
                    as: 'assigned_users',
                    where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                    required: true,
                },],
            });
            const tasksWithCount = await Promise.all(response_1.map(async (task) => {
                const assign_user = await AssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_comment = await TodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_list = await AssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assignedUsersCount = assign_user - 1;
                const taskcommentCount = assign_user_comment;
                return {
                    ...task.toJSON(),
                    assignedUsersCount,
                    taskcommentCount,
                    assign_user_list
                };
            }));
            if (!response_1[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount,
            });

        } else {
            const response_2 = await TodoModel.findAll({
                where: { status: '1', current_scope: '1' },
                // order: [['updated_at', 'DESC']],
                include: [{
                    model: Assignedtaskserialnumber,
                    order: [['sr_no', 'ASC']],
                    attributes: ['id', 'assigned_to_userid', 'assign_type', 'sr_no'],
                    as: 'assigned_users1',
                    where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                    required: true,
                }],
            });
            const tasksWithCount = await Promise.all(response_2.map(async (task) => {
                const assign_user = await AssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_comment = await TodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assignedUsersCount = assign_user - 1;
                const taskcommentCount = assign_user_comment;
                return {
                    ...task.toJSON(),
                    assignedUsersCount,
                    taskcommentCount
                };
            }));
            if (!response_2[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount,
            });
        }



    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }

}

const list_todo_inporgress_mytask = async (req, res) => {
    try {
        //   const dataLisT = await Assignedtaskserialnumber.findOne({ where: { user_comp_id: req.comp_id, scope_id: '2', assign_by: req.userId, status: '1' } })
        const dataLisT = 0;
        if (!dataLisT) {
            const response_1 = await TodoModel.findAll({
                where: { status: '1', current_scope: '2' },
                order: [['id', 'DESC']],
                include: [{
                    model: AssigntaskModel,
                    attributes: ['id', 'assigned_to_userid', 'assign_type'],
                    as: 'assigned_users',
                    where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                    required: true,
                },],
            });

            const tasksWithCount = await Promise.all(response_1.map(async (task) => {
                const assign_user = await AssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_comment = await TodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_list = await AssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assignedUsersCount = assign_user - 1;
                const taskcommentCount = assign_user_comment;
                return {
                    ...task.toJSON(),
                    assignedUsersCount,
                    taskcommentCount,
                    assign_user_list
                };
            }));
            if (!response_1[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount,
            });

        } else {
            const response_2 = await TodoModel.findAll({
                where: { status: '1', current_scope: '2' },
                // order: [['updated_at', 'DESC']],
                include: [{
                    model: Assignedtaskserialnumber,
                    order: [['sr_no', 'ASC']],
                    attributes: ['id', 'assigned_to_userid', 'assign_type', 'sr_no'],
                    as: 'assigned_users1',
                    where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                    required: true,
                }],
            });
            const tasksWithCount = await Promise.all(response_2.map(async (task) => {
                const assign_user = await AssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_comment = await TodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_list = await AssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assignedUsersCount = assign_user - 1;
                const taskcommentCount = assign_user_comment;
                return {
                    ...task.toJSON(),
                    assignedUsersCount,
                    taskcommentCount,
                    assign_user_list
                };
            }));
            if (!response_2[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount,
            });
        }



    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }

}

const list_todo_done_mytask = async (req, res) => {
    try {
        //const dataLisT = await Assignedtaskserialnumber.findOne({ where: { user_comp_id: req.comp_id, scope_id: '3', assign_by: req.userId, status: '1' } })
        const dataLisT = 0;
        if (!dataLisT) {
            const response_1 = await TodoModel.findAll({
                where: { status: '1', current_scope: '3' },
                order: [['id', 'DESC']],
                include: [{
                    model: AssigntaskModel,
                    attributes: ['id', 'assigned_to_userid', 'assign_type'],
                    as: 'assigned_users',
                    where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                    required: true,
                },],
            });

            const tasksWithCount = await Promise.all(response_1.map(async (task) => {
                const assign_user = await AssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_comment = await TodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_list = await AssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });

                const assignedUsersCount = assign_user - 1;
                const taskcommentCount = assign_user_comment;
                return {
                    ...task.toJSON(),
                    assignedUsersCount,
                    taskcommentCount,
                    assign_user_list
                };
            }));
            if (!response_1[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount,
            });

        } else {
            const response_2 = await TodoModel.findAll({
                where: { status: '1', current_scope: '3' },
                // order: [['id', 'DESC']],
                include: [{
                    model: Assignedtaskserialnumber,
                    order: [['sr_no', 'ASC']],
                    attributes: ['id', 'assigned_to_userid', 'assign_type', 'sr_no'],
                    as: 'assigned_users1',
                    where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                    required: true,
                }],
            });
            const tasksWithCount = await Promise.all(response_2.map(async (task) => {
                const assign_user = await AssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assign_user_comment = await TodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                const assignedUsersCount = assign_user - 1;
                const taskcommentCount = assign_user_comment;
                return {
                    ...task.toJSON(),
                    assignedUsersCount,
                    taskcommentCount
                };
            }));
            if (!response_2[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount,
            });
        }



    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }

}
module.exports = {
    todo_create_task, todo_edit_task, addtodocmt, edittodocmt, todocmtlist, UpdateScopeByTaskId, ListHastagMaster,
    ListTaskScopeMove, uploadTaskDocument, ListTaskDocs, updateUploadTaskDocument, todo_update_task, list_todo_mytask,
    searchHashtagInTask, todo_update_srnumber_task, list_task_user, list_hastag_search, list_todo_scope_mytask,
     list_todo_inporgress_mytask, list_todo_done_mytask, deleteTaskDocument
};  