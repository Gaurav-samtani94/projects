const ContactUs = require('../../models/master/ContacUsmodel');
const Joi = require('joi');
const { sendDynamicEmail } = require('../../config/mail');
const getCurrentDateTime = () => new Date();
const multer = require('multer');
// const { create } = require('domain');
const fs = require('fs');
const path = require('path');

const ContectUS = async (req, res) => {
    const schema = Joi.object().keys({
        name: Joi.string().required(),
        email: Joi.string().email().required(),
        phone: Joi.number().required(),
        comp_name: Joi.string(),
        subject: Joi.string().required(),
    });

    const dataToValidate = {
        name: req.body.name,
        email: req.body.email,
        phone: req.body.phone,
        comp_name: req.body.comp_name,
        subject: req.body.subject,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    }
    else {
        try {
            const Collection = await ContactUs.findOne({
                where: { email: req.body.email, status: "1" }, attributes: ['id', 'name']
            });
            if (!Collection) {

                const data = await ContactUs.create(dataToValidate)
                if (data) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: "1",
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
            });
        }
    }
};

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = 'uploads/career';
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + 'career_' + Math.random() + extension); // Rename file with a timestamp
    },
});
const upload = multer({ storage: storage });
const Careers = async (req, res) => {
    upload.single('document')(req, res, async function (err) {
        if (err) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'No file Selected',
                error: true,
                success: false,
                status: '0'
            });
        }

        const schema = Joi.object().keys({
            name: Joi.string().required(),
            email: Joi.string().email().required(),
            phone: Joi.number().required(),
            designation: Joi.string().required(),
            created_at: Joi.date().iso().required(),
        });
        const dataToValidate = {
            name: req.body.name,
            email: req.body.email,
            phone: req.body.phone,
            designation: req.body.designation,
            created_at: getCurrentDateTime(),
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        }
        else {
            try {
                const Collection = await ContactUs.findOne({
                    where: { email: req.body.email, status: '1' }, attributes: ['id', 'name']
                });
                if (!Collection) {
                    dataToValidate.document = req.file.filename;
                    dataToValidate.path = req.file.destination;
                    const data = await ContactUs.create(dataToValidate)
                    if (data) {
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',
                            data: data,
                        });
                    }
                }
                else {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }
            }
            catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0'
                });
            }
        }
    });
}
const SentEmail = async (req, res) => {
    try {
        const { name, email, comp_name, subject, phone } = req.body;
        const emailBody = `
            Name: ${name}
            Email: ${email}
            Phone: ${phone}
            Company: ${comp_name}
            Message: ${subject}
        `;
        const sendEmailResult = await sendDynamicEmail(
            process.env.TO_MAIL,
            subject,
            emailBody,
        );
        if (sendEmailResult) {
            return res.status(process.env.APIRESPCODE_SUCCESS).json({
                message: process.env.APIRESPMSG_EMAIL_SENT,
                error: false,
                success: true,
                status: '1'
            });
        } else {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).json({
                message: process.env.APIRESPMSG_EMAIL_FAILED,
                error: true,
                success: false,
                status: '0'
            });
        }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).json({
            message: process.env.APIRESPMSG_INTERNAL_SERVER_ERROR,
            error: true,
            success: false,
            status: '0'
        });
    }
};

const GetResumeList = async (req, res) => {
    const schema = Joi.object().keys({
        passcode: Joi.string().required(),
    });

const dataToValidate = {
    passcode: req.body.passcode,
    
};
const result = schema.validate(dataToValidate);
if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
        error: true,
        success: false,
        status: '0',
        message: result.error.details[0].message
    });
}
else {
    try {

        const passcode = req.body.passcode;
        if (passcode != process.env.GET_RESUME_PASSCODE) {
            return res.status(process.env.APIRESPCODE_INVALID_CREDENTIAL    ).send({
                message: 'Invalid passcode',
                error: true,
                success: false,
                status: '0'
            });

        }


        const Collection = await ContactUs.findAll({
            order: [['id', 'DESC']],
            where: {  status: "1" }, 
        });
        if (!Collection) {
            return res.status(process.env.APIRESPCODE_NOT_FOUND).send({
                message: process.env.APIRESPMSG_NOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
           
        }
        else {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: Collection
            });
        
          
        } 
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
        });
    }
}
};
module.exports = {
    ContectUS,
    Careers,
    SentEmail,
    GetResumeList
}