const ContactUs = require('../../models/growthgridModel');
const Joi = require('joi');
const { createTransporter,emailOptions } = require('../../config/mail');
const multer = require('multer');
const fs = require('fs')
const path = require('path')
const nodemailer = require('nodemailer');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'profile';
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + 'Profile_' + Math.random() + extension); // Rename file with a timestamp
    },
});
const upload = multer({ storage: storage });

const ContectUS = async (req, res) => {
    const schema = Joi.object().keys({
        name: Joi.string().required(),
        email: Joi.string().email().required(),
        phone: Joi.number().required(),
        comp_name: Joi.string(),
        subject: Joi.string().required(),
    });

    const dataToValidate = {
        name: req.body.name,
        email: req.body.email,
        phone: req.body.phone,
        comp_name: req.body.comp_name,
        subject: req.body.subject,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    }
    else {
        try {
            const Collection = await ContactUs.findOne({
                where: { email: req.body.email, status: "1" }, attributes: ['id', 'name']
            });
            if (!Collection) {
                const data = await ContactUs.create(dataToValidate)
                if (data) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: "1",
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });
            } 
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
            });
        }
    }
};


const Careers = async (req, res) => {
    upload.single('document')(req, res, async function (err) {
        if (err) {
            return res.status(400).send({ error: err.message });
        }
        const schema = Joi.object().keys({
            name: Joi.string().required(),
            email: Joi.string().email().required(),
            phone: Joi.number().required(),
            designation: Joi.string().required(),
            document: Joi.any()
        });
        const dataToValidate = {
            name: req.body.name,
            email: req.body.email,
            phone: req.body.phone,
            document: req.file ? req.file.filename : null,
            designation: req.body.designation
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        }
        else {
            try {
                const Collection = await ContactUs.findOne({
                    where: { email: req.body.email, status: '1' }, attributes: ['id', 'name']
                });
                if (!Collection) {
                    const data = await ContactUs.create(dataToValidate)
                    if (data) {
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1'
                        });
                    }
                }
                else {
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status:'0'
                    });
                }
            }
            catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error:true,
                    success: false,
                    status:'0'
                });
            }
        }
    });
}



const SentEmail = async (req, res) => {
    const { name, email, phone, designation } = req.body;
    console.log(name, email, phone, designation,'email');
    try {
        const transporter = await createTransporter(); 
        const info = await transporter.sendMail({
            ...emailOptions,
            html: `
                <style type="text/css" media="screen">
                    /* Your CSS styles here */
                </style>
                </head>
                <body>
                    <div class="main__wraper">
                        <div class="inner_wrapper" style="padding-bottom: 0;">
                            <div class="mb-1"><span>Subject:</span>New Contact Form Submission</div><br />
                            <div class="mb-1">Dear GGPL,</div>
                            <div class="mb-1">You have received a new contact form submission:</div>
                            <div class="mb-1">Name: ${name}</div>
                            <div class="mb-1">Email: ${email}</div>
                            <div class="mb-1">Phone: ${phone}</div>
                            <div class="mb-1">Designation: ${designation}</div>
                        </div>
                        <div class="inner_wrapper" style="padding-top: 0;">
                            <div class="mb-1">
                           <h4> Best regards,</h4>
                            <div class="mb-1">Name: ${name}</div>
                            </div>
                            <div class="mb-1">
                             <div class="mb-1">Email: ${email}</div>
                             </div>
                            <div><a href= ${phone}>Phone: ${phone}</a></div>
                        </div>
                    </div>
                </body>
                </html>
            `
        });
        if (info) {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.EMAILSENT_MSG,
                error: false,
                success: true,
                status: "1",
            });
        }
    } 
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
        });
    }
};

	










module.exports = {
    ContectUS,
    Careers,
    SentEmail,
    
}