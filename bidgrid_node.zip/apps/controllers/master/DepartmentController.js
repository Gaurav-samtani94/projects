const Joi = require('joi');
const DepartmentModel = require('../../models/master/DepartmentModel');
require('dotenv').config();
const { Op } = require('sequelize');

const getCurrentDateTime = () => new Date();
const addDepartment = async (req, res) => {
    const schema = Joi.object().keys({
        department_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        created_by: Joi.number().required(),
        status: Joi.number().required(),
    });

    const dataToValidate = {
        department_name: req.body.department_name,
        user_comp_id: req.comp_id,
        created_at: getCurrentDateTime(),
        created_by: req.userId,
        status: '1',
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const department = await DepartmentModel.findOne({ where: { user_comp_id: req.comp_id, department_name: req.body.department_name, status: '1' }, attributes: ['id', 'department_name'] })
            if (!department) {
                const insert = await DepartmentModel.create(dataToValidate)
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Department added successfully',
                    error: false,
                    success: true,
                    status: '1',
                    data: insert,
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'Department Name Already Exist',
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

            // res.status(400).send({ error: error.message });
        }
    }
};

const departmentList = async (req, res) => {
    // const schema = Joi.object().keys({
    //     limit: Joi.string().required(),
    //     page_number: Joi.string().required(),

    // });
    // const dataToValidate = {
    //     limit: req.body.limit,
    //     page_number: req.body.page_number,
    // }
    // const result = schema.validate(dataToValidate);
    // if (result.error) {
    //     res.status(process.env.APIRESPCODE_VALIDATION).send({
    //         error: true,
    //         success: false,
    //         status: '0',
    //         message: result.error.details[0].message
    //     });
    // } else {
    try {
        // const offset = (parseInt(dataToValidate.page_number) - 1) * parseInt(dataToValidate.limit);
        // const limit = parseInt(dataToValidate.limit);
        const department = await DepartmentModel.findAll({
            where: { user_comp_id: req.comp_id, status: '1' },
            attributes: ['id', 'department_name']
        })
        if (!department) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: 'Record Found',
            error: false,
            success: true,
            status: '1',
            data: department,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

        // res.status(400).send({ error: error.message });
    }
}
// }


//edit Department
const editDepartment = async (req, res) => {
    const schema = Joi.object().keys({
        department_id: Joi.number().required(),
    });

    const dataToValidate = {
        department_id: req.body.department_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const editDepartment = await DepartmentModel.findOne({
                where: { id: req.body.department_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'department_name'],
            })
            if (!editDepartment) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: false,
                    success: true,
                    status: '0',
                    data: [],
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record Found',
                error: false,
                success: true,
                status: '1',
                data: editDepartment,
            });
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//update Department
const updateDepartment = async (req, res) => {
    const schema = Joi.object().keys({
        department_id: Joi.number().required(),
        department_name: Joi.string().required(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        department_id: req.body.department_id,
        department_name: req.body.department_name,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const department = await DepartmentModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.department_id, status: '1' }, attributes: ['id', 'department_name'] })
            if (department) {
                const existData_upd = await DepartmentModel.findOne({ where: {id: { [Op.ne]: req.body.department_id}, status: "1", user_comp_id: req.comp_id, department_name: req.body.department_name, }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                await DepartmentModel.update(dataToValidate, {
                    where: { id: req.body.department_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Department updated successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

const deleteDepartment = async (req, res) => {
    const schema = Joi.object().keys({
        department_id: Joi.number().required(),
    });

    const dataToValidate = {
        department_id: req.body.department_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const updateData = {
            status: '0',
            modified_by: req.userId,
            updated_at: getCurrentDateTime(),
        }
        try {
            const deleteDepartment = await DepartmentModel.findOne({
                where: { id: req.body.department_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'department_name'],
            });
            if (deleteDepartment) {
                DepartmentModel.update(updateData, {
                    where: { id: req.body.department_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Department Deleted Successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });


            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

module.exports = {
    addDepartment, departmentList, editDepartment, updateDepartment, deleteDepartment
};       