
const Joi = require('joi');
const JobGradeModel = require('../../models/master/JobGradeModel');
const getCurrentDateTime = () => new Date();
const { Op } = require('sequelize');
require('dotenv').config();
const addJobGrade = async (req, res) => {
    const schema = Joi.object().keys({
        job_grade: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        job_grade: req.body.job_grade,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const jobGrade = await JobGradeModel.findOne({ where: { user_comp_id: req.comp_id, job_grade: req.body.job_grade, status: '1' }, attributes: ['id', 'job_grade'] })
            if (!jobGrade) {
                const insert = await JobGradeModel.create(dataToValidate)
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Job Grade added successfully',
                    error: false,
                    success: true,
                    status: '1',
                    data: insert,
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'Job Grade Already Exist',
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

            // res.status(400).send({ error: error.message });
        }
    }
};

const jobGradeList = async (req, res) => {
    // const schema = Joi.object().keys({
    //     limit: Joi.string().required(),
    //     page_number: Joi.string().required(),

    // });
    // const dataToValidate = {
    //     limit: req.body.limit,
    //     page_number: req.body.page_number,
    // }
    // const result = schema.validate(dataToValidate);
    // if (result.error) {
    //     res.status(process.env.APIRESPCODE_VALIDATION).send({
    //         error: true,
    //         success: false,
    //         status: '0',
    //         message: result.error.details[0].message
    //     });
    // } else {
    try {
        // const offset = (parseInt(dataToValidate.page_number) - 1) * parseInt(dataToValidate.limit);
        // const limit = parseInt(dataToValidate.limit);
        const jobGrade = await JobGradeModel.findAll({
            where: { user_comp_id: req.comp_id, status: '1' },
            attributes: ['id', 'job_grade'],

        })
        if (!jobGrade) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: 'Record Found',
            error: false,
            success: true,
            status: '1',
            data: jobGrade,

        });
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

    }
}
// }


//edit Department
const editJobGrade = async (req, res) => {
    const schema = Joi.object().keys({
        jobgrade_id: Joi.number().required(),
    });

    const dataToValidate = {
        jobgrade_id: req.body.jobgrade_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const editJobgrade = await JobGradeModel.findOne({
                where: { id: req.body.jobgrade_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'job_grade'],
            })
            if (!editJobgrade) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record Found',
                error: false,
                success: true,
                status: '1',
                data: editJobgrade,
            });
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//update Department
const updateJobGrade = async (req, res) => {
    const schema = Joi.object().keys({
        jobgrade_id: Joi.number().required(),
        job_grade: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        jobgrade_id: req.body.jobgrade_id,
        job_grade: req.body.job_grade,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const jobGrade = await JobGradeModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.jobgrade_id, status: '1' }, attributes: ['id', 'job_grade'] })
            if (jobGrade) {
                const existData_upd = await JobGradeModel.findOne({ where: {id: { [Op.ne]: req.body.jobgrade_id}, status: "1", user_comp_id: req.comp_id, job_grade: req.body.job_grade, }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                await JobGradeModel.update(dataToValidate, {
                    where: { id: req.body.jobgrade_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Job Grade updated successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            // res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

const deleteJobGrade = async (req, res) => {
    const schema = Joi.object().keys({
        jobgrade_id: Joi.number().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        jobgrade_id: req.body.jobgrade_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message
        });
    } else {
        try {
            const deleteJobGrade = await JobGradeModel.findOne({
                where: { user_comp_id: req.comp_id, id: req.body.jobgrade_id, status: '1' }, attributes: ['id', 'status']
            });
            const updateData = {
                status: '0',
                modified_by: req.userId,
                updated_at: getCurrentDateTime(),
            };
            if (deleteJobGrade) {
                JobGradeModel.update(updateData, {
                    where: { id: req.body.jobgrade_id, user_comp_id: req.comp_id },
                });

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Job Grade Deleted Successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

module.exports = {
    addJobGrade, jobGradeList, editJobGrade, updateJobGrade, deleteJobGrade
};       