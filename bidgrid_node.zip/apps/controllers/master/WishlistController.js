const Joi = require('joi');
require('dotenv').config();
const WishlistCollectionModel = require('../../models/WishlistCollectionModel');
const WishlistModel = require('../../models/WishlistModel');
const createTenderModel = require('../../../apps/models/tender/TenderModel');
const TenderReminderModel = require('../../models/tender/TenderReminderModel');
const MainmeetingModel = require('../../models/meeting/MainmeetingModel');
const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const TenderDetailsRequest = require('../../models/tender/TenderDetailsRequestModel');
const Country = require('../../models/master/Country');
const State = require('../../models/master/State');
const TenderClient = require('../../models/master/TenderClient');
const Tendersector = require('../../models/master/TenderSector');
const City = require('../../models/master/City');
// const TenderModel = require('../../models/tender/TenderModel');
const getCurrentDateTime = () => new Date();
const addCollection = async (req, res) => {
    const schema = Joi.object().keys({
        collection_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        collection_name: req.body.collection_name,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const wishlistCollection = await WishlistCollectionModel.findOne(
                { where: { user_comp_id: req.comp_id, created_by: req.userId, collection_name: req.body.collection_name, status: '1' }, attributes: ['id', 'collection_name'] })
            if (!wishlistCollection) {
                const insert = await WishlistCollectionModel.create(dataToValidate)
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Collection Created Successfully',
                    error: false,
                    success: true,
                    status: '1',
                    data: insert,
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'Collection Name Already Exist',
                    error: true,
                    success: false,
                    status: '0',
                    // data: wishlistCollection,
                });
            }

        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
};


const collectoinList = async (req, res) => {
    try {

        const collection = await WishlistCollectionModel.findAll({
            where: { user_comp_id: req.comp_id, created_by: req.userId, status: '1' },
            attributes: ['id', 'collection_name']
        })
        if (!collection[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record Found',
                error: false,
                success: true,
                status: '1',
                data: collection,

            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

    }
}


//Get Collection By Id
const getCollectionById = async (req, res) => {
    const schema = Joi.object().keys({
        collection_id: Joi.number().required(),
    });

    const dataToValidate = {
        collection_id: req.body.collection_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const editCollection = await WishlistCollectionModel.findOne({
                where: { id: req.body.collection_id, user_comp_id: req.comp_id, created_by: req.userId, status: '1' }, attributes: ['id', 'collection_name'],
            })
            if (!editCollection) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: false,
                    success: true,
                    status: '0',
                    // data: [],
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Record Found',
                    error: false,
                    success: true,
                    status: '1',
                    data: editCollection,
                });
            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//Update Colleciton 
const updateCollectionById = async (req, res) => {
    const schema = Joi.object().keys({
        collection_id: Joi.number().required(),
        collection_name: Joi.string().required(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        collection_id: req.body.collection_id,
        collection_name: req.body.collection_name,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const collection = await WishlistCollectionModel.findOne({ where: { user_comp_id: req.comp_id, created_by: req.userId, id: req.body.collection_id, status: '1' }, attributes: ['id', 'collection_name'] })
            if (collection) {
                const existData_upd = await WishlistCollectionModel.findOne({ where: { status: "1", user_comp_id: req.comp_id, collection_name: req.body.collection_name, }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                await WishlistCollectionModel.update(dataToValidate, {
                    where: { id: req.body.collection_id, user_comp_id: req.comp_id, created_by: req.userId },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Collection Updated successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//Delete Collection By Id

const deleteCollectionById = async (req, res) => {
    const schema = Joi.object().keys({
        collection_id: Joi.number().required(),
    });

    const dataToValidate = {
        collection_id: req.body.collection_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const updateData = {
            status: '0',
            modified_by: req.userId,
            updated_at: getCurrentDateTime(),
        }
        try {
            const deleteCollection = await WishlistCollectionModel.findOne({
                where: { id: req.body.collection_id, user_comp_id: req.comp_id, created_by: req.userId, status: '1' }, attributes: ['id', 'collection_name'],
            });
            // console.log(updateData)
            if (deleteCollection) {
                WishlistCollectionModel.update(updateData, {
                    where: { id: req.body.collection_id, user_comp_id: req.comp_id, created_by: req.userId },
                });

                WishlistModel.update(updateData, {
                    where: {
                        collection_id: req.body.collection_id, user_comp_id: req.comp_id, created_by: req.userId, status: '1'
                    }
                })
                
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Collection Deleted Successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });


            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//============================ Add to wishlist ===================================
// const addToWishlist = async (req, res) => {
//     const schema = Joi.object().keys({
//         user_comp_id: Joi.number().required(),
//         tender_id: Joi.number().required(),
//         collection_id: Joi.number().required(),
//         share_id: Joi.string().required(),
//         // person_ids: Joi.string().required(),
//         created_by: Joi.number().required(),
//         created_at: Joi.date().iso().required()
//     });

//     const dataToValidate = {
//         user_comp_id: req.comp_id,
//         tender_id: req.body.tender_id,
//         collection_id: req.body.collection_id,
//         share_id: req.body.share_id,
//         // person_ids: req.body.person_ids,
//         created_by: req.userId,
//         created_at: getCurrentDateTime(),
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {
//             const addToWishlist = await WishlistModel.findOne({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '1' }, attributes: ['id', 'tender_id'] })
//             if (!addToWishlist) {
//                 const insertArr = {
//                     user_comp_id: req.comp_id,
//                     tender_id: req.body.tender_id,
//                     collection_id: req.body.collection_id,
//                     share_id: req.body.share_id,
//                     person_ids: req.body.person_ids,
//                     created_by: req.userId,
//                     created_at: getCurrentDateTime()
//                 }
//                 if (req.body.share_id == '3') {
//                     insertArr.person_ids = req.body.person_ids + ',' + req.userId;
//                 }
//                 const insert = await WishlistModel.create(insertArr)
//                 return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                     message: 'Tender Added To Wishlist Successfully',
//                     error: false,
//                     success: true,
//                     status: '1',
//                     data: insert,
//                 });
//             } else {
//                 const recordwithStatus0 = await WishlistModel.findOne({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '0' }, attributes: ['id', 'tender_id'] })
//                 if (recordwithStatus0) {
//                     const updateObj = {
//                         status: 1,
//                         modified_by: req.userId,
//                         updated_at: getCurrentDateTime(),
//                     }
//                     const addWishList = await WishlistModel.update(updateObj, {
//                         where: {
//                             id: recordwithStatus0.id,
//                         }
//                     })
//                     if (addToWishlist) {
//                         return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                             message: 'Tender Added To Wishlist Successfully',
//                             error: false,
//                             success: true,
//                             status: '1',
//                             data: addWishList,
//                         });
//                     }
//                 } else {
//                     return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
//                         message: 'Tender for wishlist Already Exist',
//                         error: false,
//                         success: true,
//                         status: '0',
//                     });

//                 }

//             }

//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// };

const addToWishlist = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        tender_id: Joi.number().required(),
        collection_id: Joi.number().required(),
        share_id: Joi.string().required(),
        // person_ids: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        tender_id: req.body.tender_id,
        collection_id: req.body.collection_id,
        share_id: req.body.share_id,
        // person_ids: req.body.person_ids,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const addToWishlist = await WishlistModel.findAll({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '1' } })
            const wishlistpushdata = []
            const arraysharewith = []
            const insertArr = {
                user_comp_id: req.comp_id,
                tender_id: req.body.tender_id,
                collection_id: req.body.collection_id,
                share_id: req.body.share_id,
                person_ids: req.body.person_ids,
                created_by: req.userId,
                created_at: getCurrentDateTime()
            }
            if (addToWishlist[0]) {
                await Promise.all(addToWishlist.map(async (data) => {
                    if ((req.body.share_id == '2') && (data.created_by == req.userId)) {
                        wishlistpushdata.push({ tender_id: data.tender_id });
                    }
                    if (data.share_id == '1') {
                        wishlistpushdata.push({ tender_id: data.tender_id });
                    }
                    if ((data.share_id == '3') && (req.body.share_id == '3')) {
                        arraysharewith.push({ person_ids: data.person_ids });

                    }
                }));
            }
            if (!addToWishlist[0]) {
                const insert = await WishlistModel.create(insertArr)
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Tender Added To Wishlist Successfully',
                    error: false,
                    success: true,
                    status: '11',
                    data: insert,
                });
            } else if ((arraysharewith[0]) && (req.body.person_ids)) {
                const personIdsSet = new Set();
                const check_ids = req.body.person_ids;
                const unmatchedIds = [];
                arraysharewith.forEach(obj => {
                    const ids = obj.person_ids;
                    if (ids && ids.trim() !== "") {
                        ids.split(',').forEach(id => personIdsSet.add(id.trim()));
                    }
                });
                const uniquePersonIdsSet = new Set(Array.from(personIdsSet));
                const checkIdsArray = check_ids.split(',');
                checkIdsArray.forEach(id => {
                    if (!uniquePersonIdsSet.has(id)) {
                        unmatchedIds.push(id);
                    }
                });
                const person_ids = unmatchedIds.join(',')
                if ((req.body.share_id == '3') && (person_ids)) {
                    insertArr.person_ids = person_ids + ',' + req.userId;
                    const insert = await WishlistModel.create(insertArr)
                    if (insert) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: 'Tender Added To Wishlist Successfully',
                            error: false,
                            success: true,
                            status: '1',

                        });
                    } else {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: 'Already Wishlist',
                            error: false,
                            success: true,
                            status: '1',

                        });
                    }
                } else {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Already Wishlist',
                        error: false,
                        success: true,
                        status: '1',

                    });

                }
            } else if (!wishlistpushdata[0]) {
                const insert = await WishlistModel.create(insertArr)
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Tender Added To Wishlist Successfully',
                    error: false,
                    success: true,
                    status: '12',
                    data: insert,
                });
            } else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'Tender for wishlist Already Exist',
                    error: false,
                    success: true,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};

const removeWishList = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const updateData = {
            status: '0',
            modified_by: req.userId,
            updated_at: getCurrentDateTime(),
        }
        try {
            const removeWishlist = await WishlistModel.findOne({
                where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id, created_by: req.userId, status: '1' }, attributes: ['id',],
            });
            // console.log(updateData)
            if (removeWishlist) {
                WishlistModel.update(updateData, {
                    where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id, created_by: req.userId },
                });


                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Wishlist Removed Successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'You are not authorised to remove this wishlist.',
                    error: true,
                    success: false,
                    status: '0',
                });


            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
                h: error.message
            });

        }
    }
}

// add to Wishlist List
const wishlist_List = async (req, res) => {
    // const schema = Joi.object().keys({
    //     limit: Joi.string().required(),
    //     page_number: Joi.string().required(),
    // });
    // const dataToValidate = {
    //     limit: req.body.limit,
    //     page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
    // }
    // const result = schema.validate(dataToValidate);
    // if (result.error) {
    //     res.status(process.env.APIRESPCODE_VALIDATION).send({
    //         message: result.error.details[0].message,
    //         error: true,
    //         success: false,
    //         status: '0'
    //     });
    // } else {
    try {
        // const page_number = parseInt(dataToValidate.page_number) || 1;
        // const limit = parseInt(dataToValidate.limit) || 10;
        // const offset = (parseInt(page_number) - 1) * parseInt(limit);

        //filter record 
        const dynamicFilters = [];
        const filter_tender = [];
        if (req.body.collection_id) {
            const collection_id = req.body.collection_id;
            dynamicFilters.push({ collection_id: collection_id });
        }
        if (req.body.share_id) {
            const share_id = req.body.share_id;
            dynamicFilters.push({ share_id: share_id });
        }
        if (req.body.tender_scope) {
            const tender_scope = req.body.tender_scope;
            filter_tender.push({ cycle_id: tender_scope });
        }
        const TenderModel = createTenderModel(req.comp_id);
        await TenderModel.performOperation();
        const response_share_by_my = await WishlistModel.findAll({
            order: [['id', 'ASC']],
            where: {
                [Op.and]: [
                    { user_comp_id: req.comp_id, created_by: req.userId, status: '1' }, // Additional filters can be added here
                    ...dynamicFilters, // Include the dynamic filters

                ],
            },
            attributes: ['id', 'tender_id', 'share_id', 'collection_id'],
            include: [{
                model: WishlistCollectionModel,
                attributes: ['collection_name'],
                where: { status: '1' },
                required: true,
            },
            ]
        })
        const response_share_with = await WishlistModel.findAll({
            order: [['id', 'ASC']],
            where: {
                [Op.and]: [
                    {
                        user_comp_id: req.comp_id,
                        share_id: '3', status: '1'
                    }, // Additional filters can be added here
                    ...dynamicFilters, // Include the dynamic filters

                ],
                person_ids: {
                    [Op.regexp]: `(^|,)${req.userId}($|,)`
                },
                status: '1'
            },
            // where: filterConditions,
            attributes: ['id', 'tender_id', 'share_id', 'collection_id'],
            include: [{
                model: WishlistCollectionModel,
                attributes: ['collection_name'],
                where: { status: '1' },
                required: true,
            },
            ]
        })
        const response_share_public = await WishlistModel.findAll({
            order: [['id', 'ASC']],
            where: {
                [Op.and]: [
                    {
                        user_comp_id: req.comp_id,
                        share_id: '1',
                    }, // Additional filters can be added here
                    ...dynamicFilters, // Include the dynamic filter
                ],
                person_ids: {
                    [Op.is]: null
                },
                created_by: {
                    [Op.ne]: req.userId,
                },
                status: '1'
            },

            attributes: ['id', 'tender_id', 'share_id', 'collection_id'],
            include: [{
                model: WishlistCollectionModel,
                attributes: ['collection_name'],
                where: { status: '1' },
                required: true,
            },
            ]
        })
        const array_mearge = [...response_share_by_my, ...response_share_with, ...response_share_public]
        const store = [];
        const tender = await Promise.all(array_mearge.map(async (data) => {
            const tender_details = await TenderModel.findOne(
                {
                    where: {
                        [Op.and]: [
                            {
                                user_comp_id: req.comp_id, id: data.tender_id, status: '1'
                            },
                            ...filter_tender],
                    }
                    , attributes: ['id', 'tender_name', 'submission_start_date', 'tender_emd_amnt_val', 'submission_end_date', 'cycle_id'],
                    include: [{
                        model: Country,
                        attributes: ['country_name'],
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: State,
                        attributes: ['state_name'],
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: City,
                        attributes: ['city_name'],
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: Tendersector,
                        attributes: ['sector_name'],
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: TenderClient,
                        attributes: ['client_name'],
                        where: { status: '1' },
                        required: false,
                    },
                    ]
                });
            if (tender_details) {
                store.push({ ...data.toJSON(), tender_details });
            }
        }));
        if (!store[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: 'Record Found',
            error: false,
            success: true,
            status: '1',
            data: store,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            // message: process.env.ERROR_MSG,
            message: error.message,
            error: true,
            success: false,
            status: '0',
        });

    }
    // }
}



//Get Collection By Id
const getWishlistByCollectionId = async (req, res) => {
    const schema = Joi.object().keys({
        collection_id: Joi.number().required(),
    });

    const dataToValidate = {
        collection_id: req.body.collection_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const wishlistByCollectionId = await WishlistModel.findOne({
                where: { collection_id: req.body.collection_id, user_comp_id: req.comp_id, created_by: req.userId, status: '1' }, attributes: ['id', 'tender_id', 'collection_id'],
                include: [{
                    model: WishlistCollectionModel,
                    attributes: ['collection_name'],
                    where: { status: '1' },
                    required: false,
                }
                ]
            })
            console.log(wishlistByCollectionId)
            if (!wishlistByCollectionId) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: false,
                    success: true,
                    status: '0',
                    data: [],
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record Found',
                error: false,
                success: true,
                status: '1',
                data: wishlistByCollectionId,
            });
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

// Wishlist Update

//Update Colleciton 
const updateRemoveWishlistByCollectionId = async (req, res) => {
    const schema = Joi.object().keys({
        collection_id: Joi.number().required(),
        status: Joi.number().allow(null),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        collection_id: req.body.collection_id,
        status: '0',
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const collection = await WishlistModel.findOne({ where: { user_comp_id: req.comp_id, created_by: req.userId, id: req.body.collection_id, status: '1' }, attributes: ['id'] })
            if (collection) {

                await WishlistModel.update(dataToValidate, {
                    where: { id: req.body.collection_id, user_comp_id: req.comp_id, created_by: req.userId },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Tender Removed from Wishlist',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}


const wishlistPrivacyList = async (req, res) => {
    try {
        const wishlistPrivacy = [];
        const wishlistPrivacyList = wishlistPrivacy.push({ id: "1", privacy: "Public" }, { id: 2, privacy: "Private" }, { id: 3, privacy: "Share With" });
        if (!wishlistPrivacyList) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: 'Record Found',
            error: false,
            success: true,
            status: '1',
            data: wishlistPrivacy,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            // message: process.env.ERROR_MSG,
            message: error.message,
            error: true,
            success: false,
            status: '0',
        });

    }
}
const wishlist_List_tender = async (req, res) => {
    try {
        const response = await WishlistModel.findAll({
            order: [['id', 'ASC']],
            where: { user_comp_id: req.comp_id, status: '1' },
            // attributes: ['tender_id',''],
        })
        const dynamicFilters = [];
        if (response[0]) {
            const tasksWithCount = await Promise.all(response.map(async (data) => {
                if ((data.share_id == '2') && (data.created_by == req.userId)) {
                    dynamicFilters.push({ tender_id: data.tender_id });
                }
                if ((data.share_id == '1')) {
                    dynamicFilters.push({ tender_id: data.tender_id });
                }
                if ((data.share_id == '3')) {
                    const user_id = req.userId;
                    const csvString = data.person_ids;
                    const valuesArray = csvString.split(',');
                    if (valuesArray.includes(user_id.toString())) {
                        dynamicFilters.push({ tender_id: data.tender_id });
                    }

                }
            }))

        }

        const response_reminder = await TenderReminderModel.findAll({
            order: [['tender_id', 'DESC']],
            where: { user_comp_id: req.comp_id, status: '1' },
            attributes: ['tender_id'],
        })

        const response_meeting = await TenderDetailsRequest.findAll({
            where: {
                user_comp_id: req.comp_id,
                status: '1'
            },
            attributes: ['id', 'tender_id', [Sequelize.fn('count', Sequelize.col('id')), 'count_meeting']],
            group: ['tender_id', 'user_comp_id', 'req_from_userid'],
        })
        const data = {
            // wishlist_tender: response,
            wishlist_tender: dynamicFilters,
            reminder_tender: response_reminder,
            meeting_tender: response_meeting
        }
        if (!data) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: 'Record Found',
            error: false,
            success: true,
            status: '1',
            data: data,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            // message: process.env.ERROR_MSG,
            message: error.message,
            error: true,
            success: false,
            status: '0',
        });

    }
}
module.exports = {
    addCollection, collectoinList, getCollectionById, updateCollectionById, deleteCollectionById,
    addToWishlist, wishlist_List, getWishlistByCollectionId, updateRemoveWishlistByCollectionId,
    wishlistPrivacyList, wishlist_List_tender, removeWishList
};       