const Joi = require('joi');
require('dotenv').config();
const WidgetModel = require('../../models/master/WidgetModel');
const getCurrentDateTime = () => new Date();
const addWidget = async (req, res) => {
    const schema = Joi.object().keys({
        widget_name: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        widget_name: req.body.widget_name,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const widget = await WidgetModel.findOne({ where: { widget_name: req.body.widget_name }, attributes: ['id', 'widget_name'] })
            if (!widget) {
                const insert = await WidgetModel.create(dataToValidate)
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Widget created successfully',
                    error: false,
                    success: true,
                    status: '1',
                    data: insert,
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'Widget Already Exist',
                    error: false,
                    success: true,
                    status: '0',
                    data: widget,
                });
            }

        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};

const widgetList = async (req, res) => {
    try {

        const widget = await WidgetModel.findAll({
            where: { status: '1' },
            attributes: ['id', 'widget_name']
        })
        if (!widget) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: 'Record Found',
            error: false,
            success: true,
            status: '1',
            data: widget,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

        // res.status(400).send({ error: error.message });
    }
}


//edit Widget
const editWidget = async (req, res) => {
    const schema = Joi.object().keys({
        widget_id: Joi.number().required(),
    });

    const dataToValidate = {
        widget_id: req.body.widget_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const editWidget = await WidgetModel.findOne({
                where: { id: req.body.widget_id, status: '1' }, attributes: ['id', 'widget_name'],
            })

            if (!editWidget) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: false,
                    success: true,
                    status: '0',
                    data: [],
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record Found',
                error: false,
                success: true,
                status: '1',
                data: editWidget,
            });
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//update Department
const updateWidget = async (req, res) => {
    const schema = Joi.object().keys({
        widget_id: Joi.number().required(),
        widget_name: Joi.string().required(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        widget_id: req.body.widget_id,
        widget_name: req.body.widget_name,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existWidget = await WidgetModel.findOne({ where: { id: req.body.widget_id, status: '1' }, attributes: ['id', 'widget_name'] })
            if (existWidget) {
                const updWidget = await WidgetModel.findOne({ where: { id: req.body.widget_id, widget_name: req.body.widget_name, status: '1' }, attributes: ['id', 'widget_name'] })
                if (updWidget) {
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: 'Widget Already Exist',
                        error: false,
                        success: true,
                        status: '0',
                        data: updWidget,
                    });
                } else {
                    await WidgetModel.update(dataToValidate, {
                        where: { id: req.body.widget_id },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Widget updated successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

const deleteWidget = async (req, res) => {
    const schema = Joi.object().keys({
        widget_id: Joi.number().required(),
    });

    const dataToValidate = {
        widget_id: req.body.widget_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const updateData = {
            status: '0',
            modified_by: req.userId,
            updated_at: getCurrentDateTime(),
        }
        try {
            const deleteWidget = await WidgetModel.findOne({
                where: { id: req.body.widget_id, status: '1' }, attributes: ['id', 'widget_name'],
            });
            if (deleteWidget) {
                WidgetModel.update(updateData, {
                    where: { id: req.body.widget_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Widget Deleted Successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });


            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}


module.exports = {
    addWidget, widgetList, editWidget, updateWidget, deleteWidget
};  