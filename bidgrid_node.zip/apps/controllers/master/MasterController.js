const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Bloodgroup = require("../../models/master/Bloodgroup");
const Businessunit = require("../../models/master/BusinessUnit");
const City = require("../../models/master/City");
const Continent = require("../../models/master/Continent");
const Country = require("../../models/master/Country");
const Currency = require("../../models/master/Currency");
const Employeestatus = require("../../models/master/Employeestatus");
const Gender = require("../../models/master/Gender");
const Language = require("../../models/master/Language");
const Nationality = require("../../models/master/Nationality");
const Prefix = require("../../models/master/Prefix");
const Region = require("../../models/master/Region");
const State = require("../../models/master/State");
const Timezones = require("../../models/master/Timezones");
require('dotenv').config();
const currentDate = new Date();
//durgesh(20-10-2023)
const TenderScope = require('../../models/master/TenderScope');
const TenderSubscope = require('../../models/master/TenderSubscope');
const TenderStatus = require('../../models/master/TenderStatus');
const TenderSector = require('../../models/master/TenderSector');
const TenderService = require('../../models/master/TenderService');
const TenderSubsector = require('../../models/master/TenderSubsector');
const TenderPhase = require('../../models/master/TenderPhase');
const Tenderfundingorg = require('../../models/master/TenderFundingagency');
const TenderConsortiumtype = require('../../models/master/TenderConsortiumtype');
const TenderClient = require('../../models/master/TenderClient');

const TenderConsortiumTypeModel = require('../../models/master/TenderConsortiumTypeModel');
const TenderBdRoleModel = require('../../models/master/TenderBdRoleModel');
const TenderCycleInactionModel = require('../../models/master/TenderCycleInactionModel');
const TaskPriorityModel = require("../../models/master/TaskPriorityModel");

const MasterModulesModel = require('../../models/master/MasterModulesModel');
const ActionPerm = require('../../models/roleandpermission/ActionPerm');
//durgesh
const CompanyLogo = require('../../models/master/CompanyLogoModel');
const Serviceprovider = require('../../models/master/ServiceproviderModel');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const getCurrentDateTime = () => new Date();

const Joi = require('joi');





const ServiceproviderList = async (req, res) => {
    try {
        const response = await Serviceprovider.findAll({
            order: [['provider_name', 'ASC']],
            where: {
                status: '1', user_comp_id: req.comp_id
            },
            attributes: ['source_val', 'provider_name', 'image_name'],
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const GetcountryList = async (req, res) => {
    try {
        const response = await Country.findAll({
            order: [['country_name', 'ASC']],
            where: { status: '1', is_varified: '1' },
            attributes: ['id', 'country_name'],
        });
        const resp_private = await Country.findAll({
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'country_name'],
        });
        const mergedResponse = [...response, ...resp_private];
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const Addcountry = async (req, res) => {
    const schema = Joi.object().keys({
        continent_id: Joi.number().required(),
        country_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
    });
    const dataToValidate = {
        continent_id: req.body.continent_id,
        country_name: req.body.country_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Country.findOne({
                where: { status: '1', country_name: req.body.country_name, continent_id: req.body.continent_id, }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await Country.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const GetstateList = async (req, res) => {
    const country_id = req.body.country_id;
    const schema = Joi.object().keys({
        country_id: Joi.string().required(),
    });
    const dataToValidate = {
        country_id: country_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await State.findAll({
                order: [['state_name', 'ASC']],
                where: { status: '1', country_id: country_id, is_varified: '1', },
                attributes: ['id', 'state_name'],
            });
            const response_private = await State.findAll({
                // order: [['state_name', 'ASC']],
                where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id, country_id: country_id },
                attributes: ['id', 'state_name'],
            });
            const mergedResponse = [...response, ...response_private];
            if (!mergedResponse[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: mergedResponse,

            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const AddState = async (req, res) => {
    const schema = Joi.object().keys({
        region_id: Joi.number().required(),
        country_id: Joi.string().required(),
        state_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        region_id: req.body.region_id,
        country_id: req.body.country_id,
        state_name: req.body.state_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await State.findOne({
                where: { status: '1', state_name: req.body.state_name, country_id: req.body.country_id }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await State.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
const GetcityList = async (req, res) => {
    const state_id = req.body.state_id;
    const schema = Joi.object().keys({
        state_id: Joi.string().required(),
    });
    const dataToValidate = {
        state_id: state_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await City.findAll({
                order: [['city_name', 'ASC']],
                where: { status: '1', state_id: state_id, is_varified: '1', },
                attributes: ['id', 'city_name'],
            });
            const response_private = await City.findAll({
                order: [['city_name', 'ASC']],
                where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id, state_id: state_id },
                attributes: ['id', 'city_name'],
            });
            const mergedResponse = [...response, ...response_private];
            if (!mergedResponse[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: mergedResponse,

            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const AddCity = async (req, res) => {
    const schema = Joi.object().keys({
        state_id: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        city_name: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        state_id: req.body.state_id,
        city_name: req.body.city_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await City.findOne({
                where: { status: '1', state_id: req.body.state_id, city_name: req.body.city_name }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await City.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


//Add Continent 
const AddContinent = async (req, res) => {
    const schema = Joi.object().keys({
        continent_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        continent_name: req.body.continent_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Continent.findOne({
                where: { status: '1', continent_name: req.body.continent_name }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await Continent.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: response_insert,
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


const GetcontinentList = async (req, res) => {
    try {
        const response = await Continent.findAll({
            order: [['continent_name', 'ASC']],
            where: { status: '1', is_varified: '1' },
            attributes: ['id', 'continent_name'],
        });

        const resp_private = await Continent.findAll({
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'continent_name'],
        });

        const fullResponse = [...response, ...resp_private];

        if (!fullResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: fullResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}

const GetregionList = async (req, res) => {

    const country_id = req.body.country_id;
    const schema = Joi.object().keys({
        country_id: Joi.string().required(),
    });
    const dataToValidate = {
        country_id: country_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await Region.findAll({
                order: [['region_name', 'ASC']],
                where: { status: '1', country_id: country_id, is_varified: '1', },
                attributes: ['id', 'region_name'],
            });
            const response_private = await Region.findAll({
                order: [['region_name', 'ASC']],
                where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
                attributes: ['id', 'region_name'],
            });
            const mergedResponse = [...response, ...response_private];
            if (!mergedResponse[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: mergedResponse,

            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }

    }
}


const Addregion = async (req, res) => {
    const schema = Joi.object().keys({
        country_id: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        region_name: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        country_id: req.body.country_id,
        region_name: req.body.region_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Region.findOne({
                where: { status: '1', country_id: req.body.country_id, region_name: req.body.region_name }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await Region.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
const GetcurrencyList = async (req, res) => {

    try {
        const response = await Currency.findAll({
            order: [['name', 'ASC']],
            where: { status: '1', is_varified: '1', },
            attributes: ['id', 'name', 'code'],
        });
        const response_private = await Currency.findAll({
            order: [['name', 'ASC']],
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'name', 'code'],
        });
        const mergedResponse = [...response, ...response_private];
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}
const Addcurrency = async (req, res) => {
    const schema = Joi.object().keys({
        name: Joi.string().required(),
        code: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        name: req.body.name,
        code: req.body.code,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Currency.findOne({
                where: { status: '1', name: req.body.name, code: req.body.code }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await Currency.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
const GetprefixList = async (req, res) => {
    try {
        const response = await Prefix.findAll({
            order: [['prefix', 'ASC']],
            where: { status: '1', is_varified: '1', },
            attributes: ['id', 'prefix', 'is_varified'],
        });
        const response_private = await Prefix.findAll({
            order: [['prefix', 'ASC']],
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'prefix', 'is_varified'],
        });
        const mergedResponse = [...response, ...response_private];
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const Addprefix = async (req, res) => {
    const schema = Joi.object().keys({
        prefix: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        prefix: req.body.prefix,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const response_private = await Prefix.findOne({
                order: [['prefix', 'ASC']],
                where: { status: '1', prefix: req.body.prefix, is_varified: '2' },

            });
            const response_exist = await Prefix.findOne({
                where: { status: '1', prefix: req.body.prefix }
            });
            if (response_exist) {
                if (response_private) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: 'This prefix Is Already create Wait For Admin Aprvl',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }
            } else {
                const response_insert = await Prefix.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const Editprefix = async (req, res) => {
    const schema = Joi.object().keys({
        prefix_id: Joi.number().required(),
        created_by: Joi.number().required(),
    });
    const dataToValidate = {
        prefix_id: req.body.prefix_id,
        created_by: req.userId,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Prefix.findOne({
                where: { status: '1', id: req.body.prefix_id, is_varified: '2', created_by: req.userId },
            });
            if (!response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response_exist
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const updateprefix = async (req, res) => {
    const schema = Joi.object().keys({
        prefix: Joi.string().required(),
        prefix_id: Joi.number().required(),
        created_by: Joi.number().required(),
    });
    const dataToValidate = {
        prefix_id: req.body.prefix_id,
        prefix: req.body.prefix,
        created_by: req.userId,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Prefix.findOne({
                where: { status: '1', id: req.body.prefix_id, is_varified: '2', created_by: req.userId },
            });
            if (response_exist) {
                const updated = {
                    prefix: req.body.prefix,
                    updated_at: getCurrentDateTime(),
                }
                await Prefix.update(updated, {
                    where: { status: '1', id: req.body.prefix_id, is_varified: '2', created_by: req.userId },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'you have Not Permission To update',
                    error: true,
                    success: false,
                    status: '0'
                });


            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


const deleteprefix = async (req, res) => {
    const schema = Joi.object().keys({
        prefix_id: Joi.number().required(),
        created_by: Joi.number().required(),
    });
    const dataToValidate = {
        prefix_id: req.body.prefix_id,
        created_by: req.userId,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Prefix.findOne({
                where: { status: '1', id: req.body.prefix_id, is_varified: '2', created_by: req.userId },
            });
            if (response_exist) {
                const updated = {
                    status: '0',
                    updated_at: getCurrentDateTime(),
                }
                await Prefix.update(updated, {
                    where: { status: '1', id: req.body.prefix_id, is_varified: '2', created_by: req.userId },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'you have Not Permission To update',
                    error: true,
                    success: false,
                    status: '0'
                });


            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//Add Language
const Addlanguage = async (req, res) => {
    const schema = Joi.object().keys({
        language_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        language_name: req.body.language_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Language.findOne({
                where: { status: '1', language_name: req.body.language_name }
            });

            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const response_insert = await Language.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: response_insert,
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                message: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//language List
const GetlanguageList = async (req, res) => {
    try {
        const response = await Language.findAll({
            order: [['language_name', 'ASC']],
            where: { status: '1', is_varified: '1' },
            attributes: ['id', 'language_name'],
        });

        const resp_private = await Language.findAll({
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'language_name'],
        });

        const fullResponse = [...response, ...resp_private];

        if (!fullResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: fullResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const GetnationlityList = async (req, res) => {
    try {
        const response = await Nationality.findAll({
            order: [['nationality_name', 'ASC']],
            where: { status: '1', is_varified: '1', },
            attributes: ['id', 'nationality_name'],
        });
        const response_private = await Nationality.findAll({
            order: [['nationality_name', 'ASC']],
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'nationality_name'],
        });
        const mergedResponse = [...response, ...response_private];
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const Addnationality = async (req, res) => {
    const schema = Joi.object().keys({
        nationality_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        nationality_name: req.body.nationality_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Nationality.findOne({
                where: { status: '1', nationality_name: req.body.nationality_name }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await Nationality.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//Add Timezone
const AddTimezone = async (req, res) => {
    const schema = Joi.object().keys({
        timezone_name: Joi.string().required(),
        timezone_abbr: Joi.string().required(),
        offset_value: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        timezone_name: req.body.timezone_name,
        timezone_abbr: req.body.timezone_abbr,
        offset_value: (req.body.offset_value) ? req.body.offset_value : "00:00",
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Timezones.findOne({
                where: { status: '1', timezone_name: req.body.timezone_name }
            });

            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const response_insert = await Timezones.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: response_insert,
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const GettimezonesList = async (req, res) => {
    try {
        const response = await Timezones.findAll({
            order: [['timezone_name', 'ASC']],
            where: { status: '1', is_varified: '1' },
            attributes: ['id', 'timezone_name', 'timezone_abbr', 'offset_value'],
        });

        const resp_private = await Timezones.findAll({
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'timezone_name', 'timezone_abbr', 'offset_value'],
        });

        const fullResponse = [...response, ...resp_private];

        if (!fullResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: fullResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}
const GetgenderList = async (req, res) => {
    try {
        const response = await Gender.findAll({
            order: [['gender_name', 'ASC']],
            where: { status: '1', is_varified: '1', },
            attributes: ['id', 'gender_name'],
        });
        const response_private = await Gender.findAll({
            order: [['gender_name', 'ASC']],
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'gender_name'],
        });
        const mergedResponse = [...response, ...response_private];
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const Addgender = async (req, res) => {
    const schema = Joi.object().keys({
        gender_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        gender_name: req.body.gender_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Gender.findOne({
                where: { status: '1', gender_name: req.body.gender_name }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await Gender.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
const GetbloodgroupList = async (req, res) => {
    try {
        const response = await Bloodgroup.findAll({
            order: [['blood_group_name', 'ASC']],
            where: { status: '1', is_varified: '1' },
            attributes: ['id', 'blood_group_name'],
        });
        const response_private = await Bloodgroup.findAll({
            order: [['blood_group_name', 'ASC']],
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'blood_group_name'],
        });
        const mergedResponse = [...response, ...response_private];
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const Addbloodgroup = async (req, res) => {
    const schema = Joi.object().keys({
        blood_group_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        blood_group_name: req.body.blood_group_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Bloodgroup.findOne({
                where: { status: '1', blood_group_name: req.body.blood_group_name }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await Bloodgroup.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const GetempstatusList = async (req, res) => {
    try {
        const response = await Employeestatus.findAll({
            order: [['employeement_status_name', 'ASC']],
            where: { status: '1', is_varified: '1' },
            attributes: ['id', 'employeement_status_name'],
        });
        const response_private = await Employeestatus.findAll({
            order: [['employeement_status_name', 'ASC']],
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'employeement_status_name'],
        });
        const mergedResponse = [...response, ...response_private]
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const AddEmpstatus = async (req, res) => {
    const schema = Joi.object().keys({
        employeement_status_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        employeement_status_name: req.body.employeement_status_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await Employeestatus.findOne({
                where: { status: '1', employeement_status_name: req.body.employeement_status_name }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await Employeestatus.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


//tender consortium type list
const tenderconsortiumtypelist = async (req, res) => {
    const list = await TenderConsortiumTypeModel.findAll({ where: { status: '1' }, attributes: ['id', 'consortium_type'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

//tender Bd Role list
const tenderbdrolelist = async (req, res) => {
    const list = await TenderBdRoleModel.findAll({ where: { status: '1' }, attributes: ['id', 'role_name'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

//tender cycle inaction list
const tendercycleinactionlist = async (req, res) => {
    const list = await TenderCycleInactionModel.findAll({ where: { status: '1' }, attributes: ['id', 'inaction_name'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

/*****************Tender Scope method******************************* */
//add tender scope
const addtenderscope = async (req, res) => {
    const schema = Joi.object().keys({
        scope_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        order: Joi.number().max(5).min(2).required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        scope_name: req.body.scope_name,
        order: req.body.order,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const limit_existence = await TenderScope.count({
                where: { user_comp_id: req.comp_id, status: '1' }
            })
            if (limit_existence >= 8) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'Exceeed limit',
                    error: true,
                    success: false,
                    status: '0',
                });
            }

            const scopelist = await TenderScope.findAll({
                order: [['order_sr', 'ASC']],
                where: {
                    user_comp_id: req.comp_id,
                    status: '1',
                    order_sr: {
                        [Op.between]: [1, 6],
                    },
                },
                attributes: ['id', 'order_sr']
            });
            if (scopelist) {
                const scope_existence = await TenderScope.findOne({
                    where: { user_comp_id: req.comp_id, status: '1', cycle_name: req.body.scope_name }
                })
                const order_existence = await TenderScope.findOne({
                    where: { user_comp_id: req.comp_id, status: '1', order_sr: req.body.order }
                })
                //console.log(scope_existence,'scope');
                //console.log(order_existence,'order');
                if ((!scope_existence) && (!order_existence)) {

                    const insert = await TenderScope.create({
                        cycle_name: req.body.scope_name,
                        order_sr: req.body.order,
                        user_comp_id: req.comp_id,
                        created_by: req.userId,
                        created_at: currentDate,
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

                else {
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }

            }

            else {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender scope
const edittenderscope = async (req, res) => {
    const schema = Joi.object().keys({
        scope_id: Joi.number().required(),
    });

    const dataToValidate = {
        scope_id: req.body.scope_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editscope = await TenderScope.findOne({
                where: { id: req.body.scope_id, user_comp_id: req.comp_id, deletable: '1' }, attributes: ['id', ['cycle_name', 'scope_name'], 'order_sr'],
            })
            if (!editscope) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editscope,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender scope
const updatetenderscope = async (req, res) => {
    const schema = Joi.object().keys({
        scope_id: Joi.number().required(),
        order: Joi.number().max(5).min(2).required(),
        scope_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        scope_name: req.body.scope_name,
        order: req.body.order,
        scope_id: req.body.scope_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const order_existence = await TenderScope.findOne({
                where: {
                    user_comp_id: req.comp_id, cycle_name: req.body.scope_name,
                    id: {
                        [Op.ne]: req.body.scope_id
                    },
                    status: '1',
                    deletable: '1'
                },
                attributes: ['id']
            })
            const scope_existence = await TenderScope.findOne({
                where: {
                    user_comp_id: req.comp_id, order_sr: req.body.order,
                    id: {
                        [Op.ne]: req.body.scope_id,
                    },
                    status: '1',
                    deletable: '1'
                },
                attributes: ['id']
            })
            // console.log(order_existence);
            const tenderscope = await TenderScope.findOne({ where: { user_comp_id: req.comp_id, id: req.body.scope_id, status: '1', deletable: '1' }, attributes: ['id'] })
            if (tenderscope) {
                if ((scope_existence) || (order_existence)) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const scope_update_obj = {
                    cycle_name: req.body.scope_name,
                    order_sr: req.body.order,
                    modified_by: req.userId,
                    updated_at: currentDate,
                }
                const update = await TenderScope.update(scope_update_obj, {
                    where: { status: "1", id: req.body.scope_id, user_comp_id: req.comp_id, deletable: '1' },
                });
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const deletetenderscope = async (req, res) => {
    const schema = Joi.object().keys({
        scope_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        scope_id: req.body.scope_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const delete_existence = await TenderModel.count({ where: { user_comp_id: req.comp_id, cycle_id: req.body.scope_id, status: '1' }, attributes: ['id'] })
            if (delete_existence > 0) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'you can not delete',
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                const deletescope = await TenderScope.findOne({
                    where: { id: req.body.scope_id, user_comp_id: req.comp_id, status: '1', deletable: '1' }, attributes: ['id'],
                })
                if (deletescope) {
                    const status_update_obj = {
                        status: '0',
                        modified_by: req.userId,
                        // updated_at: currentDate
                    }
                    const status_update = await TenderScope.update(status_update_obj, {
                        where: { id: req.body.scope_id, user_comp_id: req.comp_id, deletable: '1' },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
                else {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }
            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//tender scope list
const tenderscopelist = async (req, res) => {
    const list = await TenderScope.findAll({
        order: [['order_sr', 'ASC']],
        where: {
            user_comp_id: req.comp_id,
            status: '1',
            order_sr: {
                [Op.ne]: 8
            }
        },
        attributes: ['id', ['cycle_name', 'scope_name'], 'order_sr', 'deletable'],
    });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}
/*****************Tender Scope method********************************/


/*****************Tender Status method******************************* */
//add tender status
const addtenderstatus = async (req, res) => {
    const schema = Joi.object().keys({
        status_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        status_name: req.body.status_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {

            const tenderstatus = await TenderStatus.findOne({ where: { user_comp_id: req.comp_id, status_name: req.body.status_name, status: '1' }, attributes: ['id', 'status_name'] })
            if (!tenderstatus) {
                const insert = await TenderStatus.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender Status
const edittenderstatus = async (req, res) => {
    const schema = Joi.object().keys({
        status_id: Joi.number().required(),
    });

    const dataToValidate = {
        status_id: req.body.status_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editstatus = await TenderStatus.findOne({
                where: { id: req.body.status_id, user_comp_id: req.comp_id, deletable: '1' }, attributes: ['id', 'status_name'],
            })
            if (!editstatus) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editstatus,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender Status
const updatetenderstatus = async (req, res) => {
    const schema = Joi.object().keys({
        status_id: Joi.number().required(),
        status_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        status_name: req.body.status_name,
        status_id: req.body.status_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetenderstatus = await TenderStatus.findOne({ where: { user_comp_id: req.comp_id, id: req.body.status_id, status: '1', deletable: '1' }, attributes: ['id', 'status_name'] })
            if (updatetenderstatus) {
                const existData_upd = await TenderStatus.findOne({ where: { status: "1", user_comp_id: req.comp_id, status_name: req.body.status_name, deletable: '1' }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const status_update_obj = {
                    status_name: req.body.status_name,
                    modified_by: req.userId,
                    updated_at: currentDate,
                }
                TenderStatus.update(status_update_obj, {
                    where: { id: req.body.status_id, user_comp_id: req.comp_id, deletable: '1' },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete tender status
const deletetenderstatus = async (req, res) => {
    const schema = Joi.object().keys({
        status_id: Joi.number().required(),
    });

    const dataToValidate = {
        status_id: req.body.status_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletestatus = await TenderStatus.findOne({
                where: { id: req.body.status_id, user_comp_id: req.comp_id, status: '1', deletable: '1' }, attributes: ['id', 'status_name'],
            })
            if (deletestatus) {
                const status_delete_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: currentDate,
                }
                const delete_obj = await TenderStatus.update(status_delete_obj, {
                    where: { id: req.body.status_id, user_comp_id: req.comp_id, deletable: '1' },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//tender status list
const tenderstatuslist = async (req, res) => {
    const list = await TenderStatus.findAll({
        order: [['status_name', 'ASC']],
        where: { user_comp_id: req.comp_id, status: '1' },
        attributes: ['id', 'status_name', 'deletable']
    });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
/*****************Tender Status method********************************/

/*****************Tender Sector method******************************* */
//add tender sector
const addtendersector = async (req, res) => {
    const schema = Joi.object().keys({
        sector_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        sector_name: req.body.sector_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tendersector = await TenderSector.findOne({ where: { user_comp_id: req.comp_id, sector_name: req.body.sector_name, status: '1' }, attributes: ['id', 'sector_name'] })
            if (!tendersector) {
                const insert = await TenderSector.create(dataToValidate);
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: insert,
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                    data: TenderSector,
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender Sector
const edittendersector = async (req, res) => {
    const schema = Joi.object().keys({
        sector_id: Joi.number().required(),
    });

    const dataToValidate = {
        sector_id: req.body.sector_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editsector = await TenderSector.findOne({
                where: { id: req.body.sector_id, user_comp_id: req.comp_id }, attributes: ['id', 'sector_name'],
            })
            if (!editsector) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editsector,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender sector
const updatetendersector = async (req, res) => {
    const schema = Joi.object().keys({
        sector_id: Joi.number().required(),
        sector_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        sector_name: req.body.sector_name,
        sector_id: req.body.sector_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetendersector = await TenderSector.findOne({ where: { user_comp_id: req.comp_id, id: req.body.sector_id, status: '1' }, attributes: ['id', 'sector_name'] })
            if (updatetendersector) {
                const existData_upd = await TenderSector.findOne({ where: { status: "1", user_comp_id: req.comp_id, sector_name: req.body.sector_name, }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const sector_update_obj = {
                    sector_name: req.body.sector_name,
                    modified_by: req.userId,
                    updated_at: currentDate,
                }
                const sector_update = await TenderSector.update(sector_update_obj, {
                    where: { id: req.body.sector_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete tender Sector
const deletetendersector = async (req, res) => {
    const schema = Joi.object().keys({
        sector_id: Joi.number().required(),
    });

    const dataToValidate = {
        sector_id: req.body.sector_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletesector = await TenderSector.findOne({
                where: { id: req.body.sector_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'sector_name'],
            })
            if (deletesector) {
                const sector_delete_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: currentDate,
                }
                const delete_sector = await TenderSector.update(sector_delete_obj, {
                    where: { id: req.body.sector_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//tender Sector list
const tendersectorlist = async (req, res) => {
    const list = await TenderSector.findAll({ where: { user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'sector_name'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
/*****************Tender Sector method********************************/

/*****************Tender Service method******************************* */
//add tender service
const addtenderservice = async (req, res) => {
    const schema = Joi.object().keys({
        service_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        service_name: req.body.service_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tenderservice = await TenderService.findOne({ where: { user_comp_id: req.comp_id, service_name: req.body.service_name, status: '1' }, attributes: ['id', 'service_name'] })
            if (!tenderservice) {
                const insert = await TenderService.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender service
const edittenderservice = async (req, res) => {
    const schema = Joi.object().keys({
        service_id: Joi.number().required(),
    });

    const dataToValidate = {
        service_id: req.body.service_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editservice = await TenderService.findOne({
                where: { id: req.body.service_id, user_comp_id: req.comp_id }, attributes: ['id', 'service_name'],
            })
            if (!editservice) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editservice,
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender service
const updatetenderservice = async (req, res) => {
    const schema = Joi.object().keys({
        service_id: Joi.number().required(),
        service_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        service_name: req.body.service_name,
        service_id: req.body.service_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetenderservice = await TenderService.findOne({ where: { user_comp_id: req.comp_id, id: req.body.service_id, status: '1' }, attributes: ['id', 'service_name'] })
            if (updatetenderservice) {
                const existData_upd = await TenderService.findOne({ where: { status: "1", user_comp_id: req.comp_id, service_name: req.body.service_name, }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const service_update_obj = {
                    service_name: req.body.service_name,
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                await TenderService.update(service_update_obj, {
                    where: { id: req.body.service_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete tender Service
const deletetenderservice = async (req, res) => {
    const schema = Joi.object().keys({
        service_id: Joi.number().required(),
    });

    const dataToValidate = {
        service_id: req.body.service_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deleteservice = await TenderService.findOne({
                where: { id: req.body.service_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'service_name'],
            })
            if (deleteservice) {
                const service_delete_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                await TenderService.update(service_delete_obj, {
                    where: { id: req.body.service_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//tender Service list
const tenderservicelist = async (req, res) => {
    const list = await TenderService.findAll({ where: { user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'service_name'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
/*****************Tender Service method********************************/

/*****************Tender Phase method******************************* */
//add tender phase
const addtenderphase = async (req, res) => {
    const schema = Joi.object().keys({
        phase_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        phase_name: req.body.phase_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tenderphase = await TenderPhase.findOne({ where: { user_comp_id: req.comp_id, phase_name: req.body.phase_name, status: '1' }, attributes: ['id', 'phase_name'] })
            if (!tenderphase) {
                const insert = await TenderPhase.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender phase
const edittenderphase = async (req, res) => {
    const schema = Joi.object().keys({
        phase_id: Joi.number().required(),
    });

    const dataToValidate = {
        phase_id: req.body.phase_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editphase = await TenderPhase.findOne({
                where: { id: req.body.phase_id, user_comp_id: req.comp_id }, attributes: ['id', 'phase_name'],
            })
            if (!editphase) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editphase,
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender phase
const updatetenderphase = async (req, res) => {
    const schema = Joi.object().keys({
        phase_id: Joi.number().required(),
        phase_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        phase_name: req.body.phase_name,
        phase_id: req.body.phase_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetenderphase = await TenderPhase.findOne({ where: { user_comp_id: req.comp_id, id: req.body.phase_id, status: '1' }, attributes: ['id', 'phase_name'] })
            if (updatetenderphase) {
                const existData_upd = await TenderPhase.findOne({ where: { status: "1", user_comp_id: req.comp_id, phase_name: req.body.phase_name, }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const phase_update_obj = {
                    phase_name: req.body.phase_name,
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const updatephase = await TenderPhase.update(phase_update_obj, {
                    where: { id: req.body.phase_id, user_comp_id: req.comp_id },
                });
                if (updatephase) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: updatephase
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete tender Phase
const deletetenderphase = async (req, res) => {
    const schema = Joi.object().keys({
        phase_id: Joi.number().required(),
    });

    const dataToValidate = {
        phase_id: req.body.phase_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletephase = await TenderPhase.findOne({
                where: { id: req.body.phase_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'phase_name'],
            })
            if (deletephase) {
                const phase_delete_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const deletephaserec = await TenderPhase.update(phase_delete_obj, {
                    where: { id: req.body.phase_id, user_comp_id: req.comp_id },
                });
                if (deletephaserec) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: deletephaserec
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error,
                success: false,
                status: '0',
            });
        }
    }
}

//tender Phase list
const tenderphaselist = async (req, res) => {
    const list = await TenderPhase.findAll({ where: { user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'phase_name'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
/*****************Tender Phase method********************************/

/*****************Tender Consortium Type method******************************* */
//add tender Consortium
// const addtenderconsortium = async (req, res) => {
//     const schema = Joi.object().keys({
//         consortium_type: Joi.string().required(),
//         user_comp_id: Joi.number().required(),
//         created_by: Joi.number().required(),
//         created_at: Joi.date().iso().required()
//     });

//     const dataToValidate = {
//         consortium_type: req.body.consortium_type,
//         user_comp_id: req.comp_id,
//         created_by: req.userId,
//         created_at: currentDate,
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     } else {
//         try {
//             const tenderconsortium = await TenderConsortiumtype.findOne({ where: { user_comp_id: req.comp_id, consortium_type: req.body.consortium_type, status: '1' }, attributes: ['id', 'consortium_type'] })
//             if (!tenderconsortium) {
//                 const insert = await TenderConsortiumtype.create(dataToValidate);
//                 if (insert) {
//                     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                         message: process.env.APIRESPMSG_RECINSERTED,
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: insert,
//                     });
//                 }
//             }
//             else {
//                 return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
//                     message: process.env.APIRESPMSG_RECALREADYEXISTS,
//                     error: true,
//                     success: false,
//                     status: '0',
//                 });
//             }

//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }

// //edit tender Consortium
// const edittenderconsortium = async (req, res) => {
//     const schema = Joi.object().keys({
//         consortium_type_id: Joi.number().required(),
//     });

//     const dataToValidate = {
//         consortium_type_id: req.body.consortium_type_id,
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     } else {
//         try {
//             const editconsortium = await TenderConsortiumtype.findOne({
//                 where: { id: req.body.consortium_type_id, user_comp_id: req.comp_id }, attributes: ['id', 'consortium_type'],
//             })
//             if (!editconsortium) {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             }
//             else {
//                 res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                     message: process.env.APIRESPMSG_RECFOUND,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     data: editconsortium,
//                 });
//             }

//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }

// //update tender consortium
// const updatetenderconsortium = async (req, res) => {
//     const schema = Joi.object().keys({
//         consortium_type_id: Joi.number().required(),
//         consortium_type: Joi.string().required(),
//         modified_by: Joi.number().allow(null),
//         updated_at: Joi.date().iso().allow(null),
//     });

//     const dataToValidate = {
//         consortium_type: req.body.consortium_type,
//         consortium_type_id: req.body.consortium_type_id,
//         modified_by: req.userId,
//         updated_at: currentDate,
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     } else {
//         try {
//             const updatetenderconsortium = await TenderConsortiumtype.findOne({ where: { user_comp_id: req.comp_id, id: req.body.consortium_type_id, status: '1' }, attributes: ['id', 'consortium_type'] })
//             if (updatetenderconsortium) {
//                 const existData_upd = await TenderConsortiumtype.findOne({ where: { status: "1", user_comp_id: req.comp_id, consortium_type: req.body.consortium_type }, attributes: ['id'] });
//                 if (existData_upd) {
//                     return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                         message: process.env.APIRESPMSG_RECALREADYEXISTS,
//                         error: true,
//                         success: false,
//                         status: '0',
//                     });
//                 }
//                 const update_consortium_obj = {
//                     consortium_type: req.body.consortium_type,
//                     modified_by: req.userId,
//                     updated_at: currentDate,
//                 };
//                 const updateconsortium = await TenderConsortiumtype.update(update_consortium_obj, {
//                     where: { id: req.body.consortium_type_id, user_comp_id: req.comp_id },
//                 });
//                 if (updateconsortium) {
//                     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                         message: process.env.APIRESPMSG_RECUPDATED,
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: updateconsortium
//                     });
//                 }

//             }
//             else {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }

// //delete tender Consortium
// const deletetenderconsortium = async (req, res) => {
//     const schema = Joi.object().keys({
//         consortium_type_id: Joi.number().required(),
//     });

//     const dataToValidate = {
//         consortium_type_id: req.body.consortium_type_id,
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     } else {
//         try {
//             const deleteconsortium = await TenderConsortiumtype.findOne({
//                 where: { id: req.body.consortium_type_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'consortium_type'],
//             })
//             if (deleteconsortium) {
//                 const delete_consortium_obj = {
//                     status: '0',
//                     modified_by: req.userId,
//                     updated_at: currentDate,
//                 };
//                 const deleteconsortiumrec = await TenderConsortiumtype.update(delete_consortium_obj, {
//                     where: { id: req.body.consortium_type_id, user_comp_id: req.comp_id },
//                 });
//                 if (deleteconsortiumrec) {
//                     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                         message: process.env.APIRESPMSG_RECDELETED,
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: deleteconsortium
//                     });
//                 }

//             }
//             else {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }

//tender Consortium list
const tenderconsortiumlist = async (req, res) => {
    const list = await TenderConsortiumtype.findAll({ where: { status: '1' }, attributes: ['id', 'consortium_type'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
/*****************Tender Consortium Type method********************************/


/*****************Tender Client method******************************* */
//add tender Client
const addtenderclient = async (req, res) => {
    const schema = Joi.object().keys({
        client_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        client_name: req.body.client_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tenderclient = await TenderClient.findOne({ where: { user_comp_id: req.comp_id, client_name: req.body.client_name, status: '1' }, attributes: ['id', 'client_name'] })
            if (!tenderclient) {
                const insert = await TenderClient.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                    data: TenderClient,
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender Client
const edittenderclient = async (req, res) => {
    const schema = Joi.object().keys({
        client_id: Joi.number().required(),
    });

    const dataToValidate = {
        client_id: req.body.client_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editclient = await TenderClient.findOne({
                where: { id: req.body.client_id, user_comp_id: req.comp_id }, attributes: ['id', 'client_name'],
            })
            if (!editclient) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editclient,
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender Client
const updatetenderclient = async (req, res) => {
    const schema = Joi.object().keys({
        client_id: Joi.number().required(),
        client_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        client_name: req.body.client_name,
        client_id: req.body.client_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetenderclient = await TenderClient.findOne({ where: { user_comp_id: req.comp_id, id: req.body.client_id, status: '1' }, attributes: ['id', 'client_name'] })
            if (updatetenderclient) {
                const existData_upd = await TenderClient.findOne({ where: { status: "1", user_comp_id: req.comp_id, client_name: req.body.client_name }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const update_client_obj = {
                    client_name: req.body.client_name,
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const updateclient = await TenderClient.update(update_client_obj, {
                    where: { id: req.body.client_id, user_comp_id: req.comp_id },
                });
                if (updateclient) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: updatetenderclient
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete tender Client
const deletetenderclient = async (req, res) => {
    const schema = Joi.object().keys({
        client_id: Joi.number().required(),
    });

    const dataToValidate = {
        client_id: req.body.client_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deleteclient = await TenderClient.findOne({
                where: { id: req.body.client_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'client_name'],
            })
            if (deleteclient) {
                const delete_client_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const deleteclientrec = await TenderClient.update(delete_client_obj, {
                    where: { id: req.body.client_id, user_comp_id: req.comp_id },
                });
                if (deleteclientrec) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: deleteclient
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//tender Client list
const tenderclientlist = async (req, res) => {
    const list = await TenderClient.findAll({ where: { user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'client_name'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
/*****************Tender Client method********************************/


/*****************Tender Sub Sector method******************************* */
//add tender Sub Sector
const addtendersubsector = async (req, res) => {
    const schema = Joi.object().keys({
        sector_id: Joi.number().required(),
        subsector_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        sector_id: req.body.sector_id,
        subsector_name: req.body.subsector_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tendersubsector = await TenderSubsector.findOne({ where: { user_comp_id: req.comp_id, sector_id: req.body.sector_id, subsector_name: req.body.subsector_name, status: '1' }, attributes: ['id', 'subsector_name'] })
            if (!tendersubsector) {
                const insert = await TenderSubsector.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender Sub Sector
const edittendersubsector = async (req, res) => {
    const schema = Joi.object().keys({
        subsector_id: Joi.number().required(),
    });

    const dataToValidate = {
        subsector_id: req.body.subsector_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editsubsector = await TenderSubsector.findOne({
                where: { id: req.body.subsector_id, user_comp_id: req.comp_id }, attributes: ['id', 'subsector_name', 'sector_id'],
            })
            if (!editsubsector) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editsubsector,
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender Sub Sector
const updatetendersubsector = async (req, res) => {
    const schema = Joi.object().keys({
        subsector_id: Joi.number().required(),
        subsector_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        subsector_name: req.body.subsector_name,
        subsector_id: req.body.subsector_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetendersubsector = await TenderSubsector.findOne({ where: { user_comp_id: req.comp_id, id: req.body.subsector_id, status: '1' }, attributes: ['id', 'subsector_name'] })
            if (updatetendersubsector) {
                const existData_upd = await TenderSubsector.findOne({ where: { status: "1", user_comp_id: req.comp_id, subsector_name: req.body.subsector_name }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const subsector_update_obj = {
                    subsector_name: req.body.subsector_name,
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const updatesubsector = await TenderSubsector.update(subsector_update_obj, {
                    where: { id: req.body.subsector_id, user_comp_id: req.comp_id },
                });
                if (updatesubsector) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: updatesubsector
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete tender Sub Sector
const deletetendersubsector = async (req, res) => {
    const schema = Joi.object().keys({
        subsector_id: Joi.number().required(),
    });

    const dataToValidate = {
        subsector_id: req.body.subsector_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletesubsector = await TenderSubsector.findOne({
                where: { id: req.body.subsector_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'subsector_name'],
            })
            if (deletesubsector) {
                const subsector_delete_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const deletesubsectorrec = await TenderSubsector.update(subsector_delete_obj, {
                    where: { id: req.body.subsector_id, user_comp_id: req.comp_id },
                });
                if (deletesubsectorrec) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: deletesubsector
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//tender Sub sector list
const tendersubsectorlist = async (req, res) => {

    const schema = Joi.object().keys({
        sector_id: Joi.number().required(),
    });

    const dataToValidate = {
        sector_id: req.body.sector_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        const list = await TenderSubsector.findAll({ where: { user_comp_id: req.comp_id, sector_id: req.body.sector_id, status: '1' }, attributes: ['id', 'subsector_name'] });
        try {
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }

        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
/*****************Tender Sub Sector method********************************/


/*****************Tender Sub Scope method******************************* */
//add tender Sub Scope
const addtendersubscope = async (req, res) => {
    const schema = Joi.object().keys({
        scope_id: Joi.number().required(),
        sub_scope_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        scope_id: req.body.scope_id,
        sub_scope_name: req.body.sub_scope_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tendersubscope = await TenderSubscope.findOne({ where: { user_comp_id: req.comp_id, scope_id: req.body.scope_id, sub_scope_name: req.body.sub_scope_name, status: '1' }, attributes: ['id', 'sub_scope_name'] })
            if (!tendersubscope) {
                const insert = await TenderSubscope.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender Sub Scope
const edittendersubscope = async (req, res) => {
    const schema = Joi.object().keys({
        sub_scope_id: Joi.number().required(),
    });

    const dataToValidate = {
        sub_scope_id: req.body.sub_scope_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editsubscope = await TenderSubscope.findOne({
                where: { id: req.body.sub_scope_id, user_comp_id: req.comp_id }, attributes: ['id', 'sub_scope_name', 'scope_id'],
            })
            if (!editsubscope) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editsubscope,
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender Sub Scope
const updatetendersubscope = async (req, res) => {
    const schema = Joi.object().keys({
        sub_scope_id: Joi.number().required(),
        sub_scope_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        sub_scope_name: req.body.sub_scope_name,
        sub_scope_id: req.body.sub_scope_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetendersubscope = await TenderSubscope.findOne({ where: { user_comp_id: req.comp_id, id: req.body.sub_scope_id, status: '1' }, attributes: ['id', 'sub_scope_name'] })
            if (updatetendersubscope) {
                const existData_upd = await TenderSubscope.findOne({ where: { status: "1", user_comp_id: req.comp_id, sub_scope_name: req.body.sub_scope_name }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const subscope_update_obj = {
                    sub_scope_name: req.body.sub_scope_name,
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const updatesubscope = await TenderSubscope.update(subscope_update_obj, {
                    where: { id: req.body.sub_scope_id, user_comp_id: req.comp_id },
                });
                if (updatesubscope) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: updatesubscope
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete tender Sub Scope
const deletetendersubscope = async (req, res) => {
    const schema = Joi.object().keys({
        sub_scope_id: Joi.number().required(),
    });

    const dataToValidate = {
        sub_scope_id: req.body.sub_scope_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletesubscope = await TenderSubscope.findOne({
                where: { id: req.body.sub_scope_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'sub_scope_name'],
            })
            if (deletesubscope) {
                const subscope_delete_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const deletesubscoperec = await TenderSubscope.update(subscope_delete_obj, {
                    where: { id: req.body.sub_scope_id, user_comp_id: req.comp_id },
                });
                if (deletesubscoperec) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: deletesubscope
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//tender Sub Scope list
const tendersubscopelist = async (req, res) => {

    const schema = Joi.object().keys({
        scope_id: Joi.number().required(),
    });

    const dataToValidate = {
        scope_id: req.body.scope_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        const list = await TenderSubscope.findAll({ where: { user_comp_id: req.comp_id, scope_id: req.body.scope_id, status: '1' }, attributes: ['id', 'sub_scope_name'] });
        try {
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }

        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
/*****************Tender Sub Sector method********************************/


/*****************Tender Funding Agency method******************************* */
//add tender Funding Agency
const addtenderfundingagency = async (req, res) => {
    const schema = Joi.object().keys({
        funding_org_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        funding_org_name: req.body.funding_org_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tenderfundingorg = await Tenderfundingorg.findOne({ where: { user_comp_id: req.comp_id, funding_org_name: req.body.funding_org_name, status: '1' }, attributes: ['id', 'funding_org_name'] })
            if (!tenderfundingorg) {
                const insert = await Tenderfundingorg.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender Funding Agency
const edittenderfundingagency = async (req, res) => {
    const schema = Joi.object().keys({
        funding_org_id: Joi.number().required(),
    });

    const dataToValidate = {
        funding_org_id: req.body.funding_org_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editfundingagency = await Tenderfundingorg.findOne({
                where: { id: req.body.funding_org_id, user_comp_id: req.comp_id }, attributes: ['id', 'funding_org_name'],
            })
            if (!editfundingagency) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editfundingagency,
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender funding agency
const updatetenderfundingagency = async (req, res) => {
    const schema = Joi.object().keys({
        funding_org_id: Joi.number().required(),
        funding_org_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        funding_org_name: req.body.funding_org_name,
        funding_org_id: req.body.funding_org_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetenderfundingagency = await Tenderfundingorg.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.funding_org_id }, attributes: ['id', 'funding_org_name'] })
            if (updatetenderfundingagency) {
                const existData_upd = await Tenderfundingorg.findOne({ where: { status: "1", user_comp_id: req.comp_id, funding_org_name: req.body.funding_org_name }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const update_funding_obj = {
                    funding_org_name: req.body.funding_org_name,
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const updatefundingorg = await Tenderfundingorg.update(update_funding_obj, {
                    where: { id: req.body.funding_org_id, user_comp_id: req.comp_id },
                });
                if (updatefundingorg) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: updatefundingorg
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete tender funding agency
const deletetenderfundingagency = async (req, res) => {
    const schema = Joi.object().keys({
        funding_org_id: Joi.number().required(),
    });

    const dataToValidate = {
        funding_org_id: req.body.funding_org_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletefundingorg = await Tenderfundingorg.findOne({
                where: { id: req.body.funding_org_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'funding_org_name'],
            })
            if (deletefundingorg) {
                const delete_funding_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: currentDate,
                };
                const deletefundingorgrec = await Tenderfundingorg.update(delete_funding_obj, {
                    where: { id: req.body.funding_org_id, user_comp_id: req.comp_id },
                });
                if (deletefundingorgrec) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: deletefundingorg
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//tender funding agency list
const tenderfundingagencylist = async (req, res) => {
    const list = await Tenderfundingorg.findAll({ where: { user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'funding_org_name'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
/*****************Tender funding agency method********************************/

/*****************Businees unit method******************************* */
//add business unit
const addbusinessunit = async (req, res) => {
    const schema = Joi.object().keys({
        unit_name: Joi.string().required(),
        country_id: Joi.number().required(),
        state_id: Joi.number().required(),
        city_id: Joi.number().required(),
        timezone_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        unit_name: req.body.unit_name,
        country_id: req.body.country_id,
        state_id: req.body.state_id,
        city_id: req.body.city_id,
        timezone_id: req.body.timezone_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const business_unit_check = await Businessunit.findOne({ where: { user_comp_id: req.comp_id, unit_name: req.body.unit_name, status: '1' }, attributes: ['id', 'unit_name'] })
            if (!business_unit_check) {
                const insert = await Businessunit.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//edit business unit
const editbusinessunit = async (req, res) => {
    const schema = Joi.object().keys({
        unit_id: Joi.number().required(),
    });

    const dataToValidate = {
        unit_id: req.body.unit_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editbusinessunit = await Businessunit.findOne({
                where: { id: req.body.unit_id, user_comp_id: req.comp_id },
                attributes: ['id', 'unit_name'],
                include: [
                    {
                        model: Timezones,
                        attributes: ['timezone_name', 'id'],
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: Country,
                        attributes: ['country_name', 'id'],
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: State,
                        attributes: ['state_name', 'id'],
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: City,
                        attributes: ['city_name', 'id'],
                        where: { status: '1' },
                        required: false,
                    }
                ],
            })
            if (!editbusinessunit) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editbusinessunit,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//update business unit
const updatebusinessunit = async (req, res) => {
    const schema = Joi.object().keys({
        unit_id: Joi.number().required(),
        country_id: Joi.number().required(),
        state_id: Joi.number().required(),
        city_id: Joi.number().required(),
        timezone_id: Joi.number().required(),
        unit_name: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        unit_name: req.body.unit_name,
        unit_id: req.body.unit_id,
        country_id: req.body.country_id,
        state_id: req.body.state_id,
        city_id: req.body.city_id,
        timezone_id: req.body.timezone_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const business_unit_existence = await Businessunit.findOne({ where: { user_comp_id: req.comp_id, id: req.body.unit_id, status: '1' }, attributes: ['id', 'unit_name'] })
            if (business_unit_existence) {
                const existData_upd = await Businessunit.findOne({ where: { id: { [Op.ne]: business_unit_existence.id}, status: "1", user_comp_id: req.comp_id, unit_name: req.body.unit_name }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const business_unit_update_obj = {
                    unit_name: req.body.unit_name,
                    country_id: req.body.country_id,
                    state_id: req.body.state_id,
                    city_id: req.body.city_id,
                    timezone_id: req.body.timezone_id,
                    modified_by: req.userId,
                    updated_at: currentDate,
                }
                const update = await Businessunit.update(business_unit_update_obj, {
                    where: { id: req.body.unit_id, user_comp_id: req.comp_id },
                });
                if (update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: update
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete business unit
const deletebusinessunit = async (req, res) => {
    const schema = Joi.object().keys({
        unit_id: Joi.number().required(),
    });

    const dataToValidate = {
        unit_id: req.body.unit_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletebusinessunit = await Businessunit.findOne({
                where: { id: req.body.unit_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'unit_name'],
            })
            if (deletebusinessunit) {
                const business_update_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: currentDate,
                }
                const businessunit_update = await Businessunit.update(business_update_obj, {
                    where: { id: req.body.unit_id, user_comp_id: req.comp_id },
                });
                if (businessunit_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: businessunit_update
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//unit business list
const unitbusinesslist = async (req, res) => {
    const list = await Businessunit.findAll({
        where: { user_comp_id: req.comp_id, status: '1' },
        attributes: ['id', 'unit_name'],
        include: [
            {
                model: Timezones,
                attributes: ['timezone_name', 'id'],
                where: { status: '1' },
                required: false,
            },
            {
                model: Country,
                attributes: ['country_name', 'id'],
                where: { status: '1' },
                required: false,
            },
            {
                model: State,
                attributes: ['state_name', 'id'],
                where: { status: '1' },
                required: false,
            },
            {
                model: City,
                attributes: ['city_name', 'id'],
                where: { status: '1' },
                required: false,
            }
        ],
    });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
/*****************Businees unit method********************************/


//Task Priority
const GetTaskPriorityList = async (req, res) => {
    try {
        const response = await TaskPriorityModel.findAll({
            order: [['task_priority_name', 'ASC']],
            where: { status: '1' },
            attributes: ['id', 'task_priority_name'],
        });

        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}

const AddTaskPriority = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        task_priority_name: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        task_priority_name: req.body.task_priority_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: currentDate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response_exist = await TaskPriorityModel.findOne({
                where: { status: '1', task_priority_name: req.body.task_priority_name }
            });
            if (response_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const response_insert = await TaskPriorityModel.create(dataToValidate);
                if (response_insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

// Master module list
const GetMasterModulesList = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        role_id: Joi.number().required(),
    });
    const dataToValidate = {
        role_id: req.body.role_id,
        user_comp_id: req.comp_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await MasterModulesModel.findAll({
                order: [['id', 'ASC']],
                where: { status: '1' },
                attributes: ['id', 'modules_name'],
                // group:['id'],
                include: [
                    {
                        model: ActionPerm,
                        where: { status: '1', role_id: req.body.role_id },
                        required: false,
                        attributes: ['id', 'view_perm', 'add_perm', 'edit_perm', 'delete_perm', 'role_id'],
                        // include: [
                        //     {
                        //         model: Role,
                        //         where: { status: '1' },
                        //         required: false,
                        //         attributes: ['id', 'role_name'],
                        //     }
                        // ]
                    }
                ]
            });

            if (!response[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,

            });

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                message: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }

}

// all module list
const GetAllMasterModulesList = async (req, res) => {
    try {
        const response = await MasterModulesModel.findAll({
            order: [['id', 'ASC']],
            where: { status: '1' },
            attributes: ['id', 'parent_id', 'modules_name'],
            // include: [
            //     {
            //         model: Role,
            //         where: { status: '1' },
            //         required: false,
            //         attributes: ['id', 'role_name'],
            //     }
            // ]

        });

        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            // message: process.env.ERROR_MSG,
            message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }

}

//========================= End of task Priority ====================================



// company logo 
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'logo';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;

    },
});
const upload = multer({ storage: storage });

const companyLogoAdd = async (req, res) => {
    upload.single('logo_file')(req, res, async function (err) {
        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }

        const schema = Joi.object().keys({
            user_comp_id: Joi.number().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required(),
        });

        const dataToValidate = {
            user_comp_id: req.comp_id,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };

        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        } else {
            const files = req.file;
            try {
                if (files) {
                    const checkExist = await CompanyLogo.findOne({
                        where: { user_comp_id: req.comp_id }
                    })
                    if (checkExist) {
                        const logoUpdObj = {
                            logo_file_name: files.filename,
                            logo_file_path: files.destination,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime()
                        }
                        const logo_update = await CompanyLogo.update(logoUpdObj, {
                            where: { user_comp_id: req.comp_id },
                        });
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    } else {
                        const insertObj = {
                            user_comp_id: req.comp_id,
                            logo_file_name: files.filename,
                            logo_file_path: files.path,
                            created_by: req.userId,
                            created_at: getCurrentDateTime()
                        }

                        const insertRequest = await CompanyLogo.create(insertObj)
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',
                            data: insertRequest
                        });
                    }

                }
                return res.status(process.env.APIRESPCODE_VALIDATION).send({
                    message: "Please select file to add Logo",
                    error: true,
                    success: false,
                    status: '0',
                })
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    // message: error.message,
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
}

// Fetch Company Logo
const getCompanyLogo = async (req, res) => {
    try {
        const response = await CompanyLogo.findOne({
            where: { status: '1', user_comp_id: req.comp_id },
            attributes: ['id', 'logo_file_name', 'logo_file_path'],

        });

        if (!response) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            // message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }

}

// Region wise State List
const GetStateListByRegion = async (req, res) => {
    const region_id = req.body.region_id;
    const schema = Joi.object().keys({
        region_id: Joi.string().required(),
    });
    const dataToValidate = {
        region_id: region_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await State.findAll({
                order: [['state_name', 'ASC']],
                where: { status: '1', region_id: region_id, is_varified: '1', },
                attributes: ['id', 'state_name'],
            });
            const response_private = await State.findAll({
                // order: [['state_name', 'ASC']],
                where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id, region_id: region_id },
                attributes: ['id', 'state_name'],
            });
            const mergedResponse = [...response, ...response_private];
            if (!mergedResponse[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: mergedResponse,

            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const ThumbnailStroage = multer.diskStorage({
    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'thumbnail';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;

    },
});
const uploadThumbnail = multer({ storage: ThumbnailStroage });

const UpdateCompanyThumbnail = async (req, res) => {
    uploadThumbnail.single('thumbnail_file')(req, res, async function (err) {
        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
        const files = req.file;
        try {
            const dataExist = await CompanyLogo.findOne({
                where: {
                    user_comp_id: req.comp_id
                }
            })
            if (!dataExist) {
                const createObj = {
                    user_comp_id: req.comp_id,
                    created_by: req.userId,
                    thumbnail_file_name: files.filename,
                    thumbnail_file_path: files.destination,
                    created_at: getCurrentDateTime()
                }
                const create = await CompanyLogo.create(createObj);

            } else {
                if (files) {
                    const logoUpdObj = {
                        thumbnail_file_name: files.filename,
                        thumbnail_file_path: files.destination,
                        modified_by: req.userId,
                        updated_at: getCurrentDateTime()
                    }
                    const logo_update = await CompanyLogo.update(logoUpdObj, {
                        where: { user_comp_id: req.comp_id, status: '1' },
                    });
                }

            }
            const data = await CompanyLogo.findOne({
                where: {
                    status: '1',
                    user_comp_id: req.comp_id
                }
            })
            if (data) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: data
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }

    });
}

module.exports = {
    GetcountryList, GetstateList, GetcityList, GetcontinentList, GetregionList, GetcurrencyList, GetprefixList, GetlanguageList,
    GetnationlityList, GettimezonesList, GetgenderList, GetbloodgroupList, GetempstatusList, tenderconsortiumtypelist,
    tenderbdrolelist, tendercycleinactionlist, addtenderscope, edittenderscope, updatetenderscope, deletetenderscope,
    tenderscopelist, addtenderstatus, edittenderstatus, updatetenderstatus, deletetenderstatus, tenderstatuslist,
    addtendersector, edittendersector, updatetendersector, deletetendersector, tendersectorlist, addtendersubsector,
    edittendersubsector, updatetendersubsector, deletetendersubsector, tendersubsectorlist, addtendersubscope,
    edittendersubscope, updatetendersubscope, deletetendersubscope, tendersubscopelist, addtenderservice, edittenderservice,
    updatetenderservice, deletetenderservice, tenderservicelist, addtenderphase, edittenderphase, updatetenderphase,
    deletetenderphase, tenderphaselist, tenderconsortiumlist, addbusinessunit, editbusinessunit, updatebusinessunit,
    deletebusinessunit, unitbusinesslist, addtenderclient, edittenderclient, updatetenderclient, deletetenderclient,
    tenderclientlist, addtenderfundingagency, edittenderfundingagency, updatetenderfundingagency, deletetenderfundingagency,
    tenderfundingagencylist, Addcountry, AddState, AddCity, Addregion, Addcurrency, Addprefix, Addnationality, Addgender,
    Addbloodgroup, AddEmpstatus, Addlanguage, AddContinent, AddTimezone, GetTaskPriorityList, AddTaskPriority,
    GetMasterModulesList, GetAllMasterModulesList, companyLogoAdd, getCompanyLogo, GetStateListByRegion, Editprefix, updateprefix,
    deleteprefix, UpdateCompanyThumbnail, ServiceproviderList
};    
