const Company = require("../../models/master/Company");
const Joi = require('joi');
require('dotenv').config();
const getCurrentDateTime = () => new Date();
//Insert Data..
const InsertUserCompany = async (req, res) => {
    const schema = Joi.object().keys({
        company_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        company_name: req.body.company_name,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existCompany = await Company.findOne({ where: { user_comp_id: req.comp_id, company_name: req.body.company_name, status: '1' }, attributes: ['id'] });
            if (existCompany) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const CompanyData = await Company.create(dataToValidate)
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: CompanyData,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}



//Lising data..
const ListUserCompany = async (req, res) => {
    try {
        const response = await Company.findAll({
            order: [['company_name', 'ASC']],
            where: { status: '1', user_comp_id: req.comp_id },
            attributes: ['id', 'company_name'],
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,

            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        })
    }
}

//Delete by id..
const DeleteUserCompany = async (req, res) => {
    const schema = Joi.object().keys({
        company_id: Joi.number().required(),
    });
    const dataToValidate = {
        company_id: req.body.company_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Company.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.company_id }, attributes: ['id'] });
            if (existData) {
                const UpdateDataArr = {
                    status: "0",
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update = await Company.update(UpdateDataArr, {
                    where: { user_comp_id: req.comp_id, id: req.body.company_id }
                });
                res.send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
            // res.status(400).send({ error: error.message });
        }
    }
}

//Single Data Get..
const GetByIDUserCompany = async (req, res) => {
    const schema = Joi.object().keys({
        company_id: Joi.number().required(),
    });
    const dataToValidate = {
        company_id: req.body.company_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Company.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.company_id }, attributes: ['id', 'company_name'] });
            if (existData) {
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
            // res.status(400).send({ error: error.message });
        }
    }
}

//Update By Id..
const UpdateByIDUserCompany = async (req, res) => {
    const schema = Joi.object().keys({
        company_id: Joi.number().required(),
        company_name: Joi.string().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });
    const dataToValidate = {
        company_id: req.body.company_id,
        company_name: req.body.company_name,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Company.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.company_id }, attributes: ['id'] });
            if (existData) {
                const existData_upd = await Company.findOne({ where: { status: "1", user_comp_id: req.comp_id, company_name: req.body.company_name, }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const UpdateDataArr = {
                    company_name: req.body.company_name,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update = await Company.update(UpdateDataArr, {
                    where: { status: "1", user_comp_id: req.comp_id, id: req.body.company_id }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}

module.exports = {
    InsertUserCompany, ListUserCompany, DeleteUserCompany, GetByIDUserCompany, UpdateByIDUserCompany
};