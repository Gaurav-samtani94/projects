const Designation = require("../../models/master/Designation");
const Joi = require('joi');
require('dotenv').config();
const { Op } = require('sequelize');
// const  getCurrentDateTime() = new Date();
const getCurrentDateTime = () => new Date();
const InsertUserDesignation = async (req, res) => {
    const schema = Joi.object().keys({
        designation_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        created_by: Joi.number().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        designation_name: req.body.designation_name,
        created_at: getCurrentDateTime(),
        created_by: req.userId,
    };

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Designation.findOne({ where: { user_comp_id: req.comp_id, designation_name: req.body.designation_name, status: '1' }, attributes: ['id'] });
            if (existData) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const InsertData = await Designation.create(dataToValidate)
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: InsertData,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}



//Lising data..
const ListUserDesignation = async (req, res) => {
    try {
        const response = await Designation.findAll({
            order: [['designation_name', 'ASC']],
            where: { status: '1', user_comp_id: req.comp_id },
            attributes: ['id', 'designation_name'],
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,

            });
        }
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

//Delete by id..
const DeleteUserDesignation = async (req, res) => {
    const schema = Joi.object().keys({
        designation_id: Joi.number().required(),
    });
    const dataToValidate = {
        designation_id: req.body.designation_id
    };
    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Designation.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.designation_id }, attributes: ['id'] });
            if (existData) {
                const UpdateDataArr = {
                    status: "0",
                    updated_at: getCurrentDateTime(),
                    modified_by: req.userId,
                }
                const update = await Designation.update(UpdateDataArr, {
                    where: { user_comp_id: req.comp_id, id: req.body.designation_id }
                });
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            // res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//Single Data Get..
const GetByIDUserDesignation = async (req, res) => {
    const schema = Joi.object().keys({
        designation_id: Joi.number().required(),
    });
    const dataToValidate = {
        designation_id: req.body.designation_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Designation.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.designation_id } });
            if (existData) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//Update By Id..
const UpdateByIDUserDesignation = async (req, res) => {
    const schema = Joi.object().keys({
        designation_id: Joi.number().required(),
        designation_name: Joi.string().required(),
    });
    const dataToValidate = {
        designation_id: req.body.designation_id,
        designation_name: req.body.designation_name,
    };
    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Designation.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.designation_id }, attributes: ['id'] });
            // console.log(existData.dataValues.id);
            if (existData) {
                const existData_upd = await Designation.findOne({ where: {id: { [Op.ne]: req.body.designation_id}, status: "1", user_comp_id: req.comp_id, designation_name: req.body.designation_name, }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const UpdateDataArr = {
                    designation_name: req.body.designation_name,
                    updated_at: getCurrentDateTime(),
                    modified_by: req.userId,
                }
                const update = await Designation.update(UpdateDataArr, {
                    where: { status: "1", user_comp_id: req.comp_id, id: req.body.designation_id }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            // res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}


module.exports = {
    InsertUserDesignation, ListUserDesignation, DeleteUserDesignation, GetByIDUserDesignation, UpdateByIDUserDesignation
};