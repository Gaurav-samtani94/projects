
const Main_company = require('../../models/Main_company');
const sequelize = require('../../config/database'); // Assuming you have your Sequelize instance defined here
const createTenderModelDate = require('../../models/tender/TenderDateModel');
const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const getCurrentDateTime = () => new Date();
const CreateMoveHistoryModel = require('../../models/tender/TenderMovedHistroyByUserModel');
const createDumpTender = require('../../models/tender/TenderTrashModel');
const createDumpCoverInfo = require('../../models/trash/TenderCoverInfoModel');
const createDumpDates = require('../../models/trash/TenderDatesModel');
const createDumpEmd = require('../../models/trash/TenderEmdModel');
const createDumpFeeInfo = require('../../models/trash/TenderFeeInfoModel');
const createDumpOtherData = require('../../models/trash/TenderOtherDataModel');
const createDumpDocument = require('../../models/trash/TenderDocumentModel');
const CreateTender = require('../../models/tender/TenderModel');
const CreateCoverInfo = require('../../models/tender/TenderCoverinfoModel');
const CreateDates = require('../../models/tender/TenderDateModel');
const CreateEmd = require('../../models/tender/TenderEmdModel');
const CreateFeeInfo = require('../../models/tender/TenderFeeinfoModel');
const CreateOtherData = require('../../models/tender/TenderOtherDataModel');
const CreateDocument = require('../../models/tender/TenderDocModel');
//Function to create Table if not exists in the databse
const createTableIfNotExists = async (req, res) => {
    try {
        const companies = await Main_company.findAll({
            where: {
                status: '1',
                is_table_create: '2',
                ggpl_api_tndr_token: {
                    [Op.ne]: null
                }
            },
            attributes: ['id']
        });
        let numCount = 0;
        const update = {
            is_table_create: '1',
            updated_at: getCurrentDateTime()
        }
        if (companies[0]) {
            for (const company of companies) {
                const comp_id = company.id;
                CreateDocument(comp_id)
                CreateOtherData(comp_id)
                CreateFeeInfo(comp_id)
                CreateEmd(comp_id)
                CreateCoverInfo(comp_id);
                CreateDates(comp_id);
                CreateTender(comp_id)
                createDumpTender(comp_id);
                createDumpCoverInfo(comp_id);
                createDumpDates(comp_id);
                createDumpEmd(comp_id);
                createDumpFeeInfo(comp_id);
                createDumpOtherData(comp_id);
                createDumpDocument(comp_id);
                CreateMoveHistoryModel(comp_id);
                numCount += 1;
                const Main_company_Update = await Main_company.update(update, {
                    where: {
                        id: comp_id
                    }
                })
            }
        }
        if (numCount > 0) {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message1: numCount > 1 ? `${numCount} tables created` : '1 table created',
                success: true,
                error: false,
                status: '1',
            });
        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Table Already Exists',
                success: true,
                error: false,
                status: '1',

            });
        }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: 'Internal server error',
            error: error.message,
            success: false,
            status: '0'
        });
    }
};

module.exports = {
    createTableIfNotExists
};

