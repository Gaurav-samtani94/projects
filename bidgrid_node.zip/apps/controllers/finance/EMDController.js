require('dotenv').config();
const EMDModel = require("../../models/finance/EMDModel");
const TenderModel = require('../../models/tender/TenderModel');
const Joi = require('joi');
const getCurrentDateTime = () => new Date();
//add tender EMD
const addtenderemd = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        payment_mode: Joi.number().required(),
        emd_fee_type: Joi.number().required(),
        payment_link: Joi.string().allow(null),
        emd_currency: Joi.number().required(),
        emd_amount: Joi.number().required(),
        emd_assign_to: Joi.number().required(),
        emd_payable_to: Joi.string().allow(null),
        emd_payable_at: Joi.string().allow(null),
        emd_remark: Joi.string().required(),
        emd_validity: Joi.date().required(),
        emd_status: Joi.string().allow(null),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
        payment_mode: req.body.payment_mode,
        emd_fee_type: req.body.emd_fee_type,
        payment_link: req.body.payment_link,
        emd_currency: req.body.emd_currency,
        emd_amount: req.body.emd_amount,
        emd_assign_to: req.body.emd_assign_to,
        emd_payable_to: req.body.emd_payable_to,
        emd_payable_at: req.body.emd_payable_at,
        emd_remark: req.body.emd_remark,
        emd_validity: req.body.emd_validity,
        emd_status: req.body.emd_status,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tender_emd = await EMDModel.findOne({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '1' }, attributes: ['id'] })
            if (!tender_emd) {
                const insert = await EMDModel.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender EMD
const edittenderemd = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editemd = await EMDModel.findOne({
                where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id }, attributes: ['id'],
            })
            if (!editemd) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editemd,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender EMD
const updatetenderemd = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        payment_mode: Joi.number().required(),
        emd_fee_type: Joi.number().required(),
        payment_link: Joi.string().allow(null),
        emd_currency: Joi.number().required(),
        emd_amount: Joi.number().required(),
        emd_assign_to: Joi.number().required(),
        emd_payable_to: Joi.string().allow(null),
        emd_payable_at: Joi.string().allow(null),
        emd_remark: Joi.string().required(),
        emd_validity: Joi.date().required(),
        emd_status: Joi.string().required(),

        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
        payment_mode: req.body.payment_mode,
        emd_fee_type: req.body.emd_fee_type,
        payment_link: req.body.payment_link,
        emd_currency: req.body.emd_currency,
        emd_amount: req.body.emd_amount,
        emd_assign_to: req.body.emd_assign_to,
        emd_payable_to: req.body.emd_payable_to,
        emd_payable_at: req.body.emd_payable_at,
        emd_remark: req.body.emd_remark,
        emd_validity: req.body.emd_validity,
        emd_status: req.body.emd_status,

        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tenderemd = await EMDModel.findOne({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '1' }, attributes: ['id'] })
            if (tenderemd) {
                const emd_update_obj = {
                    payment_mode: req.body.payment_mode,
                    emd_fee_type: req.body.emd_fee_type,
                    payment_link: req.body.payment_link,
                    emd_currency: req.body.emd_currency,
                    emd_amount: req.body.emd_amount,
                    emd_assign_to: req.body.emd_assign_to,
                    emd_payable_to: req.body.emd_payable_to,
                    emd_payable_at: req.body.emd_payable_at,
                    emd_remark: req.body.emd_remark,
                    emd_validity: req.body.emd_validity,
                    emd_status: req.body.emd_status,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update = await EMDModel.update(emd_update_obj, {
                    where: { status: "1", tender_id: req.body.tender_id, user_comp_id: req.comp_id },
                });
                if (update) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: update
                    });
                }

            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const deletetenderemd = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deleteemd = await EMDModel.findOne({
                where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id'],
            })
            if (deleteemd) {
                const emd_update_obj = {
                    status: '0',
                    modified_by: req.userId,
                    //updated_at:  getCurrentDateTime(),
                }
                const emd_update = await EMDModel.update(emd_update_obj, {
                    where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id },
                });
                if (emd_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: emd_update
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


module.exports = {
    addtenderemd, edittenderemd, updatetenderemd, deletetenderemd
};    
