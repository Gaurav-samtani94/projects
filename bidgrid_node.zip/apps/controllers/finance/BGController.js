require('dotenv').config();
// const  getCurrentDateTime() = new Date();
const BankModel = require("../../models/finance/BankModel");
const BankGuranteeModel = require("../../models/finance/BankGuranteeModel");
const BGAssignOnTenderModel = require("../../models/finance/BGAssignOnTenderModel");
const TenderModel = require('../../models/tender/TenderModel');
const Joi = require('joi');
const getCurrentDateTime = () => new Date();
const { sequelize, Op } = require('sequelize');
//add BG bank
const addbgbank = async (req, res) => {
    const schema = Joi.object().keys({
        bank_name: Joi.string().required(),
        amount_allowed: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        bank_name: req.body.bank_name,
        amount_allowed: req.body.amount_allowed,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const existence_bg_bank = await BankModel.findOne({ where: { user_comp_id: req.comp_id, bank_name: req.body.bank_name, status: '1' }, attributes: ['id'] })
            if (!existence_bg_bank) {
                const insert = await BankModel.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit Bg Bank
const editbgbank = async (req, res) => {
    const schema = Joi.object().keys({
        bank_id: Joi.number().required(),
    });

    const dataToValidate = {
        bank_id: req.body.bank_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editbgbank = await BankModel.findOne({
                where: { id: req.body.bank_id, user_comp_id: req.comp_id }, attributes: ['id', 'bank_name', 'amount_allowed'],
            })
            if (!editbgbank) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editbgbank,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update Bg Bank
const updatebgbank = async (req, res) => {
    const schema = Joi.object().keys({
        bank_id: Joi.number().required(),
        bank_name: Joi.string().required(),
        amount_allowed: Joi.number().required(),
    });

    const dataToValidate = {
        bank_id: req.body.bank_id,
        bank_name: req.body.bank_name,
        amount_allowed: req.body.amount_allowed,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const bgbank = await BankModel.findOne({
                where: { user_comp_id: req.comp_id, id: req.body.bank_id, status: '1' }, attributes: ['id']

            })
            if (bgbank) {
                const existData_upd = await BankModel.findOne({
                    where: {
                        status: "1",
                        user_comp_id: req.comp_id,
                        bank_name: req.body.bank_name,
                        id: {
                            [Op.ne]: req.body.bank_id
                        }
                    },
                    attributes: ['id']
                });

                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const bgbank_update_obj = {
                    bank_name: req.body.bank_name,
                    amount_allowed: req.body.amount_allowed,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update_bg_bank = await BankModel.update(bgbank_update_obj, {
                    where: { status: "1", id: req.body.bank_id, user_comp_id: req.comp_id },
                });
                if (update_bg_bank) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: update_bg_bank
                    });
                }

            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const deletebgbank = async (req, res) => {
    const schema = Joi.object().keys({
        bank_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        bank_id: req.body.bank_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletebgbank = await BankModel.findOne({
                where: { id: req.body.bank_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id'],
            })
            if (deletebgbank) {
                const bg_bank_update_obj = {
                    status: '0',
                    modified_by: req.userId,
                }
                const bg_bank_update = await BankModel.update(bg_bank_update_obj, {
                    where: { id: req.body.bank_id, user_comp_id: req.comp_id },
                });
                if (bg_bank_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: bg_bank_update
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//Bg Bank list
const bgbanklist = async (req, res) => {
    const list = await BankModel.findAll({ where: { user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'bank_name', 'amount_allowed'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

//add Bank Gurantee details
const addbgdetail = async (req, res) => {
    const schema = Joi.object().keys({
        bg_type: Joi.number().required(),
        bg_bank: Joi.number().required(),
        bg_title: Joi.string().required(),
        bg_amount: Joi.number().required(),
        bg_number: Joi.string().required(),
        bg_start_date: Joi.date().required(),
        bg_validity: Joi.date().required(),
        bg_status: Joi.number().allow(null),
        amount_received: Joi.number().allow(null),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        bg_type: req.body.bg_type,
        bg_bank: req.body.bg_bank,
        bg_title: req.body.bg_title,
        bg_amount: req.body.bg_amount,
        bg_number: req.body.bg_number,
        bg_start_date: req.body.bg_start_date,
        bg_validity: req.body.bg_validity,
        bg_status: req.body.bg_status,
        amount_received: req.body.amount_received,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const existence_bg_detail = await BankGuranteeModel.findOne({ where: { user_comp_id: req.comp_id, bg_type: req.body.bg_type, bg_bank: req.body.bg_bank, bg_number: req.body.bg_number, status: '1' }, attributes: ['id'] })
            if (!existence_bg_detail) {
                const insert = await BankGuranteeModel.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit Bank Gurantee details
const editbgdetail = async (req, res) => {
    const schema = Joi.object().keys({
        bg_id: Joi.number().required(),
    });

    const dataToValidate = {
        bg_id: req.body.bg_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editbgdetail = await BankGuranteeModel.findOne({
                where: { id: req.body.bg_id, user_comp_id: req.comp_id }, attributes: ['id', 'bg_type', 'bg_bank', 'bg_title', 'bg_amount', 'bg_number', 'bg_start_date', 'bg_validity', 'bg_status', 'amount_received'],
            })
            if (!editbgdetail) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editbgdetail,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update Bank Gurantee details
const updatebgdetail = async (req, res) => {
    const schema = Joi.object().keys({
        bg_id: Joi.number().required(),
        bg_type: Joi.string().required(),
        bg_bank: Joi.number().required(),
        bg_title: Joi.string().required(),
        bg_amount: Joi.number().required(),
        bg_number: Joi.string().required(),
        bg_start_date: Joi.date().required(),
        bg_validity: Joi.date().required(),
        bg_status: Joi.number().allow(null),
        amount_received: Joi.number().allow(null),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        bg_id: req.body.bg_id,
        bg_type: req.body.bg_type,
        bg_bank: req.body.bg_bank,
        bg_title: req.body.bg_title,
        bg_amount: req.body.bg_amount,
        bg_number: req.body.bg_number,
        bg_start_date: req.body.bg_start_date,
        bg_validity: req.body.bg_validity,
        bg_status: req.body.bg_status,
        amount_received: req.body.amount_received,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const bgdetail = await BankGuranteeModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.bg_id, status: '1' }, attributes: ['id'] })
            if (bgdetail) {
                const existData_upd = await BankGuranteeModel.findOne({ where: { status: "1", user_comp_id: req.comp_id, bg_validity: req.body.bg_validity, bg_status: req.body.bg_status }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                } else {
                    const bgdetail_update_obj = {
                        bg_type: req.body.bg_type,
                        bg_bank: req.body.bg_bank,
                        bg_title: req.body.bg_title,
                        bg_amount: req.body.bg_amount,
                        bg_number: req.body.bg_number,
                        bg_start_date: req.body.bg_start_date,
                        bg_validity: req.body.bg_validity,
                        bg_status: req.body.bg_status,
                        amount_received: req.body.amount_received,
                        modified_by: req.userId,
                        updated_at: getCurrentDateTime(),
                    }
                    const update_bg_detail = await BankGuranteeModel.update(bgdetail_update_obj, {
                        where: { status: "1", id: req.body.bg_id, user_comp_id: req.comp_id },
                    });
                    if (update_bg_detail) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',
                            data: update_bg_detail
                        });
                    }
                }
            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const deletebgdetail = async (req, res) => {
    const schema = Joi.object().keys({
        bg_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        bg_id: req.body.bg_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletebgdetail = await BankGuranteeModel.findOne({
                where: { id: req.body.bg_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id'],
            })
            if (deletebgdetail) {
                const bg_detail_update_obj = {
                    status: '0',
                    modified_by: req.userId,
                }
                const bg_detail_update = await BankGuranteeModel.update(bg_detail_update_obj, {
                    where: { id: req.body.bg_id, user_comp_id: req.comp_id },
                });
                if (bg_detail_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: bg_detail_update
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


//Bg detail list
const bgdetaillist = async (req, res) => {
    const list = await BankGuranteeModel.findAll({ where: { user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'bg_type', 'bg_bank', 'bg_title', 'bg_amount', 'bg_number', 'bg_start_date', 'bg_validity', 'bg_status', 'amount_received'] });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

//Assign BG on project
const assignbgontender = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        bg_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        tender_id: req.body.tender_id,
        bg_id: req.body.bg_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const existence_bg_assign = await BGAssignOnTenderModel.findOne({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, bg_id: req.body.bg_id, status: '1' }, attributes: ['id'] })
            if (!existence_bg_assign) {
                const insert = await BGAssignOnTenderModel.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete Assign BG on project
const deleteassignbg = async (req, res) => {
    const schema = Joi.object().keys({
        assign_bg_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        assign_bg_id: req.body.assign_bg_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deleteassignbg = await BGAssignOnTenderModel.findOne({
                where: { id: req.body.assign_bg_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id'],
            })
            if (deleteassignbg) {
                const assign_bg_update_obj = {
                    status: '0',
                    updated_at: getCurrentDateTime(),
                    modified_by: req.userId,
                }
                const assign_bg_update = await BGAssignOnTenderModel.update(assign_bg_update_obj, {
                    where: { id: req.body.assign_bg_id, user_comp_id: req.comp_id },
                });
                if (assign_bg_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: assign_bg_update
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//Assign Bg list on tender
const assignbgontenderlist = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        const list = await BGAssignOnTenderModel.findAll({
            where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' },
            attributes: ['id', 'bg_id', 'tender_id'],
            include: [{
                model: BankGuranteeModel,
                attributes: ['bg_type', 'bg_bank', 'bg_title', 'bg_amount', 'bg_number', 'bg_start_date', 'bg_validity', 'bg_status', 'amount_received'],
                where: { status: '1' },
                required: false,
                include: [{
                    model: BankModel,
                    attributes: ['bank_name'],
                    where: { status: '1' },
                    required: false,
                }]
            }]
        });
        try {
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

module.exports = {
    addbgbank, editbgbank, updatebgbank, deletebgbank, bgbanklist,
    addbgdetail, editbgdetail, updatebgdetail, deletebgdetail, bgdetaillist,
    assignbgontender, deleteassignbg, assignbgontenderlist
};    
