const path = require('path');
const DiskLimit = require('../models/DiskLimitModel');
const getCurrentDateTime = () => new Date();
const du = require('du');

// // Function to convert bytes to a human-readable format
// function formatBytes(bytes) {
//     console.log(bytes)
    
//   const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
//   if (bytes === 0) return '0 Byte';
//   const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)), 10);
//   return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
// }


// async function getDirectorySize(dir) {
//     try {
//         const size = await new Promise((resolve, reject) => {
//             du(dir, (err, size) => {
//                 if (err) {
//                     reject(err);
//                     return;
//                 }
//                 resolve(size);
//             });
//         });

//         return size;
//     } catch (error) {
//         throw error;
//     }
// }



// const StoreSizes = async (req, res) => {
//   const schema = Joi.object().keys({
//     created_by: Joi.number().required(),
//   });

//   const dataToValidate = {
//     created_by: 1,
//   };

//   const result = schema.validate(dataToValidate);
//   if (result.error) {
//     return res.status(400).send({
//       error: true,
//       success: false,
//       status: '0',
//       message: result.error.details[0].message,
//     });
//   }

//   try {
//     const publicDir = path.join(__dirname, '../../uploads');

//     const dirExists = await fs.pathExists(publicDir);
//     if (!dirExists) {
//       console.error('Directory does not exist:', publicDir);
//       return res.status(400).send({
//         message: 'Public directory does not exist.',
//         error: true,
//         success: false,
//         status: '0',
//       });
//     }

//     const folders = await fs.readdir(publicDir);

//     const folderData = await Promise.all(
//       folders.map(async (folder) => {
//         const folderPath = path.join(publicDir, folder);
//         const stats = await fs.stat(folderPath);

//         if (stats.isDirectory() && folder.startsWith('public_')) {
//           const compId = parseInt(folder.split('_')[1], 10);
          
//           const folderSizeBytes = await getDirectorySize(folderPath);

//           const folderSize = formatBytes(folderSizeBytes);
//           return { compId, folderSize };
//         }
//       })
//     );

// return;
//     const validFolderData = folderData.filter(data => data);
//     await Promise.all(validFolderData.map(({ compId, folderSize }) => {
        
//       return DiskLimit.create({
//         comp_id: compId,
//         size_limit: folderSize,
//         status: '1', // Assuming the status is '1' for active
//         created_by: '1',
//         created_at: getCurrentDateTime(),
//       });
//     }));

//     console.log('Data inserted');
//     res.status(200).send({
//       message: 'Folder sizes stored successfully.',
//       error: false,
//       success: true,
//       status: '1',
//     });
//   } catch (error) {
//     console.error(error);
//     // res.status(500).send({
//     //   message: 'An error occurred while storing folder sizes.',
//     //   error: error.message,
//     //   success: false,
//     //   status: '0',
//     // });
//   }
// };

// StoreSizes();


const getSizeLimit = async (req, res) => {
    try {

        const TotalSize = await DiskLimit.findOne({
            where: { status: '1', comp_id: req.comp_id },
            
        })

        const directoryPath = path.join(__dirname, `../../uploads/public_${req.comp_id}`)

        async function getDirectorySizeInGB(dir) {
            try {
                const sizeInBytes = await new Promise((resolve, reject) => {
                    du(dir, (err, size) => {
                        if (err) {
                            reject(err);
                            return;
                        }
                        resolve(size);
                    });
                });
        
                const sizeInGB = sizeInBytes / Math.pow(1024, 3); // Convert bytes to gigabytes
                return sizeInGB;
            } catch (error) {
                throw error;
            }
        }
        const TotalLimit = TotalSize.size_limit;
        const usedSpace = (await getDirectorySizeInGB(directoryPath)).toFixed(2)
        const remainingSpace = (TotalLimit-usedSpace).toFixed(2)

        const details = {
            TotalLimit: TotalLimit,
            UsedSpace: parseFloat(usedSpace),
            RemainingSpace: parseFloat(remainingSpace),
        };
        

        console.log(details)
        if (!TotalSize) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        }else{
           return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record Found',
                error: false,
                success: true,
                status: '1',
                data: details,
            });
        }

        

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
            msg: error.message,
        });

    }
}

module.exports = {getSizeLimit}
