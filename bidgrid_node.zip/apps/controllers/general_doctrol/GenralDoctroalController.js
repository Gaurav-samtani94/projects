require('dotenv').config();
const Joi = require('joi');
const { Op } = require('sequelize');
const path = require('path')
const multer = require('multer');
const fs = require('fs');
const getCurrentDateTime = () => new Date();

const GenralFolder = require('../../models/general_doctrol/GenralFolderModel');
const ListType = require('../../models/general_doctrol/ListTypeModel');
const GenralFiles = require('../../models/general_doctrol/GenralFilesModel');

const addFolder = async (req, res) => {
    const schema = Joi.object().keys({
        folder_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        parent_id: Joi.string().allow(null),
        // parent_id: Joi.string().required(),
    });

    const dataToValidate = {
        folder_name: req.body.folder_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
        parent_id: req.body.parent_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const existence_gen_folder = await GenralFolder.findOne({ where: { user_comp_id: req.comp_id, folder_name: req.body.folder_name, status: '1' }, attributes: ['id'] })
            if (!existence_gen_folder) {
                const insert = await GenralFolder.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                // message: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const buildHierarchy = (folders, parentId = 0) => {
    const hierarchy = folders.filter(folder => folder.parent_id === parentId).map(folder => {
        const children = buildHierarchy(folders, folder.id);
        if (children.length > 0) {
            return { ...folder.dataValues, children };
        }
        return folder.dataValues;
    });
    return hierarchy;
};


const listFolder = async (req, res) => {
    try {
        const allFolders = await GenralFolder.findAll({
            where: {
                status: "1",
                user_comp_id: req.comp_id,
            },
        });

        // Build the hierarchy starting from the root level (parentId = 0)
        const hierarchy = buildHierarchy(allFolders);

        if (!hierarchy || hierarchy.length === 0) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }

        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: hierarchy
        });
    } catch (error) {
        console.error(error);
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
           // message:error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
};

const editFolder = async (req, res) => {
    const schema = Joi.object().keys({
        folder_id: Joi.number().required(),
    });

    const dataToValidate = {
        folder_id: req.body.folder_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editfolder = await GenralFolder.findOne({
                where: { id: req.body.folder_id, user_comp_id: req.comp_id }, attributes: ['id', 'folder_name', 'parent_id'],
            })
            if (!editfolder) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editfolder,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const updateFolder = async (req, res) => {
    const schema = Joi.object().keys({
        folder_id: Joi.number().required(),
        folder_name: Joi.string().required(),
        updated_at: Joi.date().iso().allow(),
        modified_by: Joi.number().required(),
    });
    const dataToValidate = {
        folder_id: req.body.folder_id,
        folder_name: req.body.folder_name,
        updated_at: getCurrentDateTime(),
        modified_by: req.userId,
    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existingFolder = await GenralFolder.findOne({
                where: { 
                    folder_name: req.body.folder_name, 
                    user_comp_id: req.comp_id, 
                    status: '1' 
                }
            });

            if (existingFolder && existingFolder.id !== req.body.folder_id) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    status: '0',
                    success: false,
                });
            }

            const updateFolder = await GenralFolder.findOne({
                where: { 
                    id: req.body.folder_id, 
                    user_comp_id: req.comp_id, 
                    status: '1' 
                }, 
                attributes: ['id', 'folder_name']
            });

            if (!updateFolder) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    status: '0',
                    success: false,
                });
            } else {
                const updateCat = {
                    folder_name: req.body.folder_name,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                };

                await GenralFolder.update(updateCat, {
                    where: { id: req.body.folder_id, user_comp_id: req.comp_id },
                });

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    status: '1',
                    success: true,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                status: '0',
                success: false,
            });
        }
    }
}

const deleteFolder = async (req, res) => {
    const schema = Joi.object().keys({
        folder_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        folder_id: req.body.folder_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletefolder = await GenralFolder.findOne({ where: { id: req.body.folder_id, status: '1', user_comp_id: req.comp_id } })
            if (deletefolder) {
                const fldr_update_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const fldr_update = await GenralFolder.update(fldr_update_obj, {
                    where: {
                        id: req.body.folder_id,
                        user_comp_id: req.comp_id,
                        status: '1',

                    },
                });
                if (fldr_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                error: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
const listType = async (req, res) => {
    try {
        const data = await ListType.findAll({
            where: {
                status: "1",
            },
            attributes: ['id', 'type_name', 'status']
        });
        if (!data[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: data,
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            //  message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const listGenralDoctroal = async (req, res) => {

    let attributesToShow;

    if (req.body.share_with == 1) {
        attributesToShow = ['id', 'document_title', 'document_file_name', 'document_file_path', 'exten', 'folder_id', 'status'];
    } else if (req.body.share_with == 2) {
        attributesToShow = ['id', 'document_title', 'document_file_name', 'share_with_ids', 'document_file_path', 'exten', 'folder_id', 'status'];
    } else if (req.body.share_with == 3) {
        attributesToShow = ['id', 'document_title', 'document_file_name', 'share_with_email_list', 'document_file_path', 'exten', 'folder_id', 'status'];
    }

    try {
        const list = await GenralFiles.findAll({
            where: {
                status: "1",
                user_comp_id: req.comp_id,
            },
            attributes: attributesToShow,
        });

        if (!list || list.length === 0) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}


const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'generaldoctrol/';
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + 'doctrol_' + Math.random() + extension);
    },
});

const doc_upload = multer({ storage: storage });


// const GenralDoctroalAdd = async (req, res) => {
//     doc_upload.array('document_file_name')(req, res, async function (err) {
//         if (err) {
//             return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: "Error in file upload",
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }

//         let schema;
//         if (req.body.share_with == 1) {
//             schema = Joi.object().keys({
//                 document_title: Joi.string().required(),
//                 folder_id: Joi.string().required(),
//                 share_with: Joi.string().required(),
//                 share_with_email_list: Joi.string().allow(''),
//                 share_with_ids: Joi.string().allow()
//             });
//         } else if (req.body.share_with == 2) {
//             schema = Joi.object().keys({
//                 document_title: Joi.string().required(),
//                 folder_id: Joi.string().required(),
//                 share_with: Joi.string().required(),
//                 share_with_ids: Joi.string().required(),
//                 share_with_email_list: Joi.string().allow('')
//             });
//         } else if (req.body.share_with == 3) {
//             schema = Joi.object().keys({
//                 document_title: Joi.string().required(),
//                 folder_id: Joi.string().required(),
//                 share_with: Joi.string().required(),
//                 share_with_ids: Joi.string().allow(''),
//                 share_with_email_list: Joi.string().required()
//             });
//         } else {
//             return res.status(process.env.APIRESPCODE_VALIDATION).send({
//                 message: "Invalid share_with value",
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }

//         const dataToValidate = {
//             document_title: req.body.document_title,
//             folder_id: req.body.folder_id,
//             share_with: req.body.share_with,
//             share_with_ids: req.body.share_with_ids,
//             share_with_email_list: req.body.share_with_email_list
//         };

//         const result = schema.validate(dataToValidate);

//         if (result.error) {
//             return res.status(process.env.APIRESPCODE_VALIDATION).send({
//                 message: result.error.details[0].message,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//         try {
//             const files = req.files;
//             if (files[0]) {
//                 const originalFolderPath = files[0].destination;
//                 let fileRecords;
//                 if (req.body.share_with == 1) {
//                     fileRecords = await GenralFiles.bulkCreate(files.map((file) =>
//                     ({
//                         created_by: req.userId, user_comp_id: req.comp_id, document_title: req.body.document_title,
//                         document_file_name: file.filename, created_at: getCurrentDateTime(), document_file_path: originalFolderPath, exten: path.extname(file.filename), folder_id: req.body.folder_id, share_with: req.body.share_with,
//                     })));
//                 } else if (req.body.share_with == 2) {
//                     fileRecords = await GenralFiles.bulkCreate(files.map((file) =>
//                     ({
//                         created_by: req.userId, user_comp_id: req.comp_id, document_title: req.body.document_title,
//                         document_file_name: file.filename, created_at: getCurrentDateTime(), document_file_path: originalFolderPath, exten: path.extname(file.filename), folder_id: req.body.folder_id, share_with: req.body.share_with, share_with_ids: req.body.share_with_ids,
//                     })));
//                 } else if (req.body.share_with == 3) {
//                     fileRecords = await GenralFiles.bulkCreate(files.map((file) =>
//                     ({
//                         created_by: req.userId, user_comp_id: req.comp_id, document_title: req.body.document_title,
//                         document_file_name: file.filename, created_at: getCurrentDateTime(), document_file_path: originalFolderPath, exten: path.extname(file.filename), folder_id: req.body.folder_id, share_with: req.body.share_with, share_with_email_list: req.body.share_with_email_list
//                     })));
//                 }

//                 if (fileRecords.length > 0) {
//                     res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                         message: process.env.APIRESPMSG_RECINSERTED,
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: fileRecords
//                     });
//                 }
//             } else {
//                 res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.FILE_NOT_FOUND,
//                     error: true,
//                     success: false,
//                     status: '0',
//                 });
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     });
// }



//Code by Himanshu Sharan which suffixes  "_index+1" in document title when user uploads more than one file
const GenralDoctroalAdd = async (req, res) => {
    doc_upload.array('document_file_name')(req, res, async function (err) {
        if (err) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: "Error in file upload",
                error: true,
                success: false,
                status: '0',
            });
        }

        let schema;
        if (req.body.share_with == 1) {
            schema = Joi.object().keys({
                document_title: Joi.string().required(),
                folder_id: Joi.string().required(),
                share_with: Joi.string().required(),
                share_with_email_list: Joi.string().allow(''),
                share_with_ids: Joi.string().allow('')
            });
        } else if (req.body.share_with == 2) {
            schema = Joi.object().keys({
                document_title: Joi.string().required(),
                folder_id: Joi.string().required(),
                share_with: Joi.string().required(),
                share_with_ids: Joi.string().required(),
                share_with_email_list: Joi.string().allow('')
            });
        } else if (req.body.share_with == 3) {
            schema = Joi.object().keys({
                document_title: Joi.string().required(),
                folder_id: Joi.string().required(),
                share_with: Joi.string().required(),
                share_with_ids: Joi.string().allow(''),
                share_with_email_list: Joi.string().required()
            });
        } else {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: "Invalid share_with value",
                error: true,
                success: false,
                status: '0',
            });
        }

        const dataToValidate = {
            document_title: req.body.document_title,
            folder_id: req.body.folder_id,
            share_with: req.body.share_with,
            share_with_ids: req.body.share_with_ids,
            share_with_email_list: req.body.share_with_email_list
        };

        const result = schema.validate(dataToValidate);

        if (result.error) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        }
        try {
            const files = req.files;
            if (files[0]) {
                const originalFolderPath = files[0].destination;
                let fileRecords;
                
                fileRecords = await GenralFiles.bulkCreate(files.map((file, index) => {
                    const titleSuffix = files.length > 1 ? `_${index + 1}` : '';
                    const updatedTitle = `${req.body.document_title}${titleSuffix}`;
                    
                    const baseRecord = {
                        created_by: req.userId, 
                        user_comp_id: req.comp_id, 
                        document_title: updatedTitle,
                        document_file_name: file.filename, 
                        created_at: getCurrentDateTime(), 
                        document_file_path: originalFolderPath, 
                        exten: path.extname(file.filename), 
                        folder_id: req.body.folder_id, 
                        share_with: req.body.share_with,
                    };

                    if (req.body.share_with == 2) {
                        baseRecord.share_with_ids = req.body.share_with_ids;
                    }

                    if (req.body.share_with == 3) {
                        baseRecord.share_with_email_list = req.body.share_with_email_list;
                    }

                    return baseRecord;
                }));

                if (fileRecords.length > 0) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: fileRecords
                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.FILE_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    });
}


const doctrol_listFolder = async (req, res) => {
    try {
        const folders = await GenralFolder.findAll({
            where: {
                status: '1',
                user_comp_id: req.comp_id
            },
            include: [{
                model: GenralFiles,
                attributes: ['document_title', 'document_file_name', 'document_file_path', 'exten', 'share_with'],
                where: { status: '1' },
                required: false,
            }],
            order: [['folder_name', 'ASC']]
        });

        if (!folders || folders.length === 0) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: folders, 
            });
        }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            // message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const doctrol_files_list = async (req, res) => {
    try {
        const folders = await GenralFiles.findAll({
            attributes: ['id', ['folder_id','parent_id'],'document_title','document_file_name','document_file_path',['exten','folder_name'],'share_with','created_at','created_by'],
            where: {
                status: '1',
                user_comp_id: req.comp_id
            },
            
        });
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: folders, 
            });
        // }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            // message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const doctrol_files_delete = async (req, res) => {
    const schema = Joi.object().keys({
        file_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        file_id: req.body.file_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletefolder = await GenralFiles.findOne({ where: { id: req.body.file_id, status: '1', user_comp_id: req.comp_id } })
            if (deletefolder) {
                const fldr_update_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const fldr_update = await GenralFiles.update(fldr_update_obj, {
                    where: {
                        id: req.body.file_id,
                        user_comp_id: req.comp_id,
                        status: '1',

                    },
                });
                if (fldr_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                error: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
} 

module.exports = {
    addFolder, listFolder, editFolder, updateFolder, deleteFolder, listType, listGenralDoctroal, GenralDoctroalAdd,doctrol_listFolder,doctrol_files_list, doctrol_files_delete

};