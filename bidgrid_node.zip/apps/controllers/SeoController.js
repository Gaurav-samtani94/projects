
const SeoSearchMetaModel= require('../models/seo/SeoSearchMetaModel')
const FilterPageMasterModel = require('../models/seo/FilterPageMasterModel');
const Joi = require('joi');

const SeoSearchMetaList = async (req, res) => {
    const schema = Joi.object().keys({
        page_id: Joi.number().required(),
    });
    const dataToValidate = {
        page_id: req.body.page_id,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const searchMeta = await SeoSearchMetaModel.findAll({
                order: [['id', 'DESC']],
                where: { status: "1", page_id:req.body.page_id},
                // include: [
                //     {
                //         model: FilterPageMasterModel,
                //         attributes: ['page_name'],
                //         where: { status: "1"},
                //         required: false,
                //     }
                // ]
                
                
            });
            if (searchMeta[0]) {
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: searchMeta,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }

}


module.exports = {
    SeoSearchMetaList

}