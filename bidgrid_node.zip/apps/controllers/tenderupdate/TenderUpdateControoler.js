const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Joi = require('joi');
require('dotenv').config();
const multer = require('multer');
let nodemailer = require('nodemailer');
const createTenderAutoExtUpd = require('../../../apps/models/tenderupdate/TenderUpdAutoExtModel');
const createTenderDateUpd = require('../../../apps/models/tenderupdate/TenderUpdDateModel');
const createTenderFeeUpd = require('../../../apps/models/tenderupdate/TenderUpdfeeModel');
const createTenderMainUpd = require('../../../apps/models/tenderupdate/TenderUpdmainModel');
const CorrTypemasterModel = require('../../../apps/models/tenderupdate/CorrTypemasterModel');
const getCurrentDateTime = () => new Date();

const corrigendum_upd_data = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
    });
    const dataToValidate = {
        tender_id: req.body.tender_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0'
        });
    } else {
        const TenderAutoExtupd = createTenderAutoExtUpd(req.comp_id);
        await TenderAutoExtupd.performOperation();

        const TenderDATEupd = createTenderDateUpd(req.comp_id);
        await TenderDATEupd.performOperation();

        const TenderFeeupd = createTenderFeeUpd(req.comp_id);
        await TenderFeeupd.performOperation();

        const Tendermainupd = createTenderMainUpd(req.comp_id);
        await Tendermainupd.performOperation();

        const date_response = await Tendermainupd.findAll({
            order: [["created_at", "DESC"]],
            where: {
                user_comp_id: req.comp_id,
                status: "1",
                bg_tender_id: req.body.tender_id,
                corrigendum_type_master: '9'

            },
            include: [{
                model: CorrTypemasterModel,
                where: { status: '1' },
                attributes: ['corrigendum_name'],
                required: false,

            },
            {
                model: TenderDATEupd,
                where: { status: '1' },
                required: false,
                as: 'deteupdate'
                // attributes: ['corrigendum_name'],

            }
            ]
            // attributes: ["id", "cycle_name", "order_sr"],
        });
        const fee_response = await Tendermainupd.findAll({
            order: [["created_at", "DESC"]],
            where: {
                user_comp_id: req.comp_id,
                status: "1",
                bg_tender_id: req.body.tender_id,
                corrigendum_type_master: '10'

            },
            include: [{
                model: TenderFeeupd,
                where: { status: '1' },
                required: false,
                as: 'feeupdate'
                // attributes: ['corrigendum_name'],

            },
            {
                model: CorrTypemasterModel,
                where: { status: '1' },
                attributes: ['corrigendum_name'],
                required: false,

            }]
            // attributes: ["id", "cycle_name", "order_sr"],
        });
        const sutoexten_response = await Tendermainupd.findAll({
            order: [["created_at", "DESC"]],
            where: {
                user_comp_id: req.comp_id,
                status: "1",
                bg_tender_id: req.body.tender_id,
                corrigendum_type_master: '8'

            },
            include: [{
                model: CorrTypemasterModel,
                where: { status: '1' },
                attributes: ['corrigendum_name'],
                required: false,

            },
            {
                model: TenderAutoExtupd,
                where: { status: '1' },
                required: false,
                as: 'autoextention'
                // attributes: ['corrigendum_name'],

            }]
            // attributes: ["id", "cycle_name", "order_sr"],
        });
        const other_response = await Tendermainupd.findAll({
            order: [["created_at", "DESC"]],
            where: {
                user_comp_id: req.comp_id,
                status: "1",
                bg_tender_id: req.body.tender_id,
                corrigendum_type_master: {
                    [Op.notIn]: [8, 9, 10]
                }
            },
            include: [{
                model: CorrTypemasterModel,
                where: { status: '1' },
                attributes: ['corrigendum_name'],
                required: false,

            }]
            // attributes: ["id", "cycle_name", "order_sr"],
        });
        const all_res = {
            corr_date: date_response,
            corr_fee: fee_response,
            corr_ext: sutoexten_response,
            corr_other: other_response
        }
        try {
            if (all_res[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: "0",
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: "1",
                    data: all_res,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: "0",
            });
        }
    }

}
module.exports = {
    corrigendum_upd_data,

};
