const Joi = require('joi');
require('dotenv').config();
const { Sequelize, DataTypes, where, Op, fn, col, literal } = require('sequelize');
const Tenderscope = require('../../models/master/TenderScope');
const createTenderMoveHistory = require('../../models/tender/TenderMovedHistroyByUserModel')
const Users = require('../../models/Users');

const getMoveHistoryByTenderId = async (req, res) => {
    try {

        const schema = Joi.object().keys({
            tender_id: Joi.number().required(),
        });

        const dataToValidate = {
            tender_id: req.body.tender_id
        };

        const result = schema.validate(dataToValidate);

        if (result.error) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        }

        const TenderMoveCycleHistoryModel = await createTenderMoveHistory(req.comp_id);
        await TenderMoveCycleHistoryModel.performOperation();


        const response = await TenderMoveCycleHistoryModel.findOne({
            where: { tender_id: req.body.tender_id,reverse_cycle:'1' },
            //attributes: ['id', 'tender_id', 'to_cycle_id', 'from_cycle_id', 'created_at'],
            attributes: ['id', 'tender_id', 'to_cycle_id', 'from_cycle_id', 'created_at'],
            include: [
                {
                    model: Tenderscope,
                    as: 'from_cycle',
                    where: { status: '1' },
                    attributes: ['cycle_name', 'id'],
                    required: false,
                },
                {
                    model: Tenderscope,
                    as: 'to_cycle',
                    where: { status: '1' },
                    attributes: ['cycle_name', 'id'],
                    required: false,
                },
                {
                    model: Users,
                    as: 'created_by_user',
                    attributes: ['userfullname', 'id'],
                    required: false,
                },

            ],

        });
        if (!response) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        }



        // response.created_at = moment(response.created_at).add(5, 'hours').add(30, 'minutes').format('YYYY-MM-DD HH:mm:ss');
        // // Parse the timestamp using moment and then format it to keep only date and time
        // response.created_at = moment(response.created_at).format('YYYY-MM-DD HH:mm:ss');


        res.send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}


module.exports = {
    getMoveHistoryByTenderId
}