const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Joi = require('joi');
const getCurrentDateTime = () => new Date();
require('dotenv').config();

const createTenderModel = require('../../../apps/models/tender/TenderModel');
const createTenderTrashModel = require('../../models/tender/TenderTrashModel')
const Tenderscope = require('../../models/master/TenderScope');

const createTenderCoverInfoModel = require('../../models/tender/TenderCoverinfoModel')
const createTenderModelDate = require('../../models/tender/TenderDateModel')
const createTenderDocumentModel = require('../../models/tender/TenderDocModel')
const createTenderEmdModel = require('../../models/tender/TenderEmdModel')
const createTenderFeeInfoModel = require('../../models/tender/TenderFeeinfoModel')
const createTenderOtherDataModel = require('../../models/tender/TenderOtherDataModel')
const TenderGeneratedTypeModel = require('../../models/tender/TenderGeneratedTypeModel');
const TenderGeneratedTypeIdModel = require('../../models/tender/TenderGeneratedTypeIdModel');
const createTenderCoverInfoTrashModel = require('../../models/trash/TenderCoverInfoModel')
const createTenderDatesTrashModel = require('../../models/trash/TenderDatesModel')
const createTenderDocumentTrashModel = require('../../models/trash/TenderDocumentModel')
const createTenderEmdTrashModel = require('../../models/trash/TenderEmdModel')
const createTenderFeeInfoTrashModel = require('../../models/trash/TenderFeeInfoModel')
const createTenderOtherDataTrashModel = require('../../models/trash/TenderOtherDataModel');
const createTenderMoveHistory = require('../../models/tender/TenderMovedHistroyByUserModel');

const TenderCycleAssignInactionModel = require('../../../apps/models/tender/TenderCycleAssignInactionModel');
const Inaction = require('../../models/master/TenderCycleInactionModel');


const addTenderCycleTrashBtn = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        tender_id: req.body.tender_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    }
    else {
        try {

            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderTrashModel = createTenderTrashModel(req.comp_id);
            await TenderTrashModel.performOperation();

            const response = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    id: req.body.tender_id,
                    status: "1"
                    // cycle_id: { [Op.ne]: dataToValidate.cycle_id },
                },
            });
            if (response) {
                const check_scope_cr = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']],
                    where: {
                        user_comp_id: req.comp_id,
                        id: response.cycle_id,
                        status: '1',
                        category: '1'
                    },
                    attributes: ['id', 'order_sr']
                });

                const record_exist = await TenderGeneratedTypeIdModel.findOne({
                    where: {
                        user_comp_id: req.comp_id,
                        tender_id: req.body.tender_id,
                        status: '1',

                    },
                    attributes: ['id']
                });

                if ((check_scope_cr.order_sr >= 6) && (record_exist)) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: 'You cant Delete',
                        error: true,
                        success: false,
                        status: '0',
                    });
                } else {
                    const dataInsert = {
                        bg_tender_id: response.id,
                        tg_tender_id: response.tg_tender_id,
                        gg_tenderID: response.gg_tenderID,
                        user_comp_id: response.user_comp_id,
                        tender_name: response.tender_name,
                        tnd_ref_id: response.tnd_ref_id,
                        tender_gov_id: response.tender_gov_id,
                        tender_cost: response.tender_cost,
                        tender_emd_amnt_val: response.tender_emd_amnt_val,
                        client_id: response.client_id,
                        currency_id: response.currency_id,
                        region_id: response.region_id,
                        country_id: response.country_id,
                        state_id: response.state_id,
                        city_id: response.city_id,
                        sector_id: response.sector_id,
                        funding_id: response.funding_id,
                        cycle_id: response.cycle_id,
                        client_cont_person: response.client_cont_person,
                        client_cont_address: response.client_cont_address,
                        email_id: response.email_id,
                        phone_no: response.phone_no,
                        publication_date: response.publication_date,
                        submission_start_date: response.submission_start_date,
                        submission_end_date: response.submission_end_date,
                        bid_opening_place: response.bid_opening_place,
                        bid_validity_date: response.bid_validity_date,
                        source_id: response.source_id,
                        national_intern: response.national_intern,
                        pre_bid_meeting_place: response.pre_bid_meeting_place,
                        pre_bid_meeting_address: response.pre_bid_meeting_address,
                        pre_bid_meeting_date: response.pre_bid_meeting_date,
                        pre_bid_meeting_time: response.pre_bid_meeting_time,
                        tnd_url: response.tnd_url,
                        pre_bid_meeting_link: response.pre_bid_meeting_link,
                        pre_bid_mode: response.pre_bid_mode,
                        created_by: response.created_by,
                        status: response.status,
                        modified_by: response.modified_by,
                        created_at: response.created_at,
                        updated_at: response.updated_at,
                        deleted_by: req.userId,
                        deleted_at: getCurrentDateTime(),
                    }
                    const insert = await TenderTrashModel.create(dataInsert);
                    if (insert) {
                        await TenderModel.destroy({ where: { id: response.id, user_comp_id: req.comp_id } });
                        const userId = req.userId;
                        await TrashAndDeleteCoverInfo(req.comp_id, req.body.tender_id, userId)
                        await TrashAndDeleteDate(req.comp_id, req.body.tender_id, userId)
                        await TrashAndDeleteFeeInfo(req.comp_id, req.body.tender_id, userId)
                        await TrashAndDeleteOhterData(req.comp_id, req.body.tender_id, userId)
                        await TrashAndDeleteTenderDocument(req.comp_id, req.body.tender_id, userId)
                        await TrashAndDeleteTenderEmd(req.comp_id, req.body.tender_id, userId)
                    }
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Tender Trash Successfull',
                        error: false,
                        success: true,
                        status: '1',
                    });

                }
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Records Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }

}

const RemovefromTenderCycleTrash = async (req, res) => {
    const schema = Joi.object().keys({
        bg_tender_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        to_cycle_id: Joi.number().required(),
    });
    const dataToValidate = {
        bg_tender_id: req.body.tender_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
        to_cycle_id: req.body.to_cycle_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    }
    else {
        try {

            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderTrashModel = createTenderTrashModel(req.comp_id);
            await TenderTrashModel.performOperation();

            const response = await TenderTrashModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    bg_tender_id: req.body.tender_id,
                    status: "1"

                },
            });

            if (response) {

                const dataInsert = {
                    id: response.bg_tender_id,
                    tg_tender_id: response.tg_tender_id,
                    gg_tenderID: response.gg_tenderID,
                    user_comp_id: response.user_comp_id,
                    tender_name: response.tender_name,
                    tnd_ref_id: response.tnd_ref_id,
                    tender_gov_id: response.tender_gov_id,
                    tender_cost: response.tender_cost,
                    tender_emd_amnt_val: response.tender_emd_amnt_val,
                    client_id: response.client_id,
                    currency_id: response.currency_id,
                    region_id: response.region_id,
                    country_id: response.country_id,
                    state_id: response.state_id,
                    city_id: response.city_id,
                    sector_id: response.sector_id,
                    funding_id: response.funding_id,
                    cycle_id: req.body.to_cycle_id,
                    client_cont_person: response.client_cont_person,
                    client_cont_address: response.client_cont_address,
                    email_id: response.email_id,
                    phone_no: response.phone_no,
                    publication_date: response.publication_date,
                    submission_start_date: response.submission_start_date,
                    submission_end_date: response.submission_end_date,
                    bid_opening_place: response.bid_opening_place,
                    bid_validity_date: response.bid_validity_date,
                    source_id: response.source_id,
                    national_intern: response.national_intern,
                    pre_bid_meeting_place: response.pre_bid_meeting_place,
                    pre_bid_meeting_address: response.pre_bid_meeting_address,
                    pre_bid_meeting_date: response.pre_bid_meeting_date,
                    pre_bid_meeting_time: response.pre_bid_meeting_time,
                    tnd_url: response.tnd_url,
                    pre_bid_meeting_link: response.pre_bid_meeting_link,
                    pre_bid_mode: response.pre_bid_mode,
                    created_by: response.created_by,
                    status: 1,
                    modified_by: req.userId,
                    created_at: response.created_at,
                    updated_at: getCurrentDateTime(),
                }
                const insert = await TenderModel.create(dataInsert);
                console.log(insert.id)
                const bg_tender_id = insert.id;
                if (insert) {
                    await TenderTrashModel.destroy({ where: { id: response.id, user_comp_id: req.comp_id } });
                    const userId = req.userId;
                    await RemoveTrashAndDeleteCoverInfo(req.comp_id, req.body.tender_id, bg_tender_id)
                    await RemoveTrashAndDeleteDate(req.comp_id, req.body.tender_id, bg_tender_id)
                    await RemoveTrashAndDeleteFeeInfo(req.comp_id, req.body.tender_id, bg_tender_id)
                    await RemoveTrashAndDeleteOhterData(req.comp_id, req.body.tender_id, bg_tender_id)
                    await RemoveTrashAndDeleteTenderDocument(req.comp_id, req.body.tender_id, bg_tender_id)
                    await RemoveTrashAndDeleteTenderEmd(req.comp_id, req.body.tender_id, bg_tender_id)


                    const cycle_table_object = {
                        user_comp_id: response.user_comp_id,
                        tender_id: bg_tender_id,
                        from_cycle_id: response.cycle_id,
                        to_cycle_id: req.body.to_cycle_id,
                        scope_move_type: 'single-jump',
                        status: '1',
                        created_by: req.userId,
                        created_at: getCurrentDateTime(),
                        updated_at: getCurrentDateTime(),
                    }

                    console.log(cycle_table_object)

                    const TenderMoveCycleHistoryModel = createTenderMoveHistory(req.comp_id)
                    await TenderMoveCycleHistoryModel.performOperation()



                    const cycle_insert = await TenderMoveCycleHistoryModel.create(cycle_table_object);

                }
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Tender Restored',
                    error: false,
                    success: true,
                    status: '1',
                });




            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Records Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }

}


const RemovefromTenderCycleTrashMultiple = async (req, res) => {
    const schema = Joi.object().keys({
        bg_tender_ids: Joi.any().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        to_cycle_id: Joi.number().required(),
    });
    const dataToValidate = {
        bg_tender_ids: req.body.tender_ids,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
        to_cycle_id: req.body.to_cycle_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    }
    else {
        try {

            const bg_tender_ids = req.body.tender_ids.split(",").map(id => parseInt(id))

            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderTrashModel = createTenderTrashModel(req.comp_id);
            await TenderTrashModel.performOperation();

            let countDeleteRecord = 0;
            for (const tender_id of bg_tender_ids) {
                const response = await TenderTrashModel.findOne({
                    where: {
                        user_comp_id: req.comp_id,
                        bg_tender_id: tender_id,
                        status: "1"
                    },
                });
                if (response) {
                    const dataInsert = {
                        id: response.bg_tender_id,
                        tg_tender_id: response.tg_tender_id,
                        gg_tenderID: response.gg_tenderID,
                        user_comp_id: response.user_comp_id,
                        tender_name: response.tender_name,
                        tnd_ref_id: response.tnd_ref_id,
                        tender_gov_id: response.tender_gov_id,
                        tender_cost: response.tender_cost,
                        tender_emd_amnt_val: response.tender_emd_amnt_val,
                        client_id: response.client_id,
                        currency_id: response.currency_id,
                        region_id: response.region_id,
                        country_id: response.country_id,
                        state_id: response.state_id,
                        city_id: response.city_id,
                        sector_id: response.sector_id,
                        funding_id: response.funding_id,
                        cycle_id: req.body.to_cycle_id,
                        client_cont_person: response.client_cont_person,
                        client_cont_address: response.client_cont_address,
                        email_id: response.email_id,
                        phone_no: response.phone_no,
                        publication_date: response.publication_date,
                        submission_start_date: response.submission_start_date,
                        submission_end_date: response.submission_end_date,
                        bid_opening_place: response.bid_opening_place,
                        bid_validity_date: response.bid_validity_date,
                        source_id: response.source_id,
                        national_intern: response.national_intern,
                        pre_bid_meeting_place: response.pre_bid_meeting_place,
                        pre_bid_meeting_address: response.pre_bid_meeting_address,
                        pre_bid_meeting_date: response.pre_bid_meeting_date,
                        pre_bid_meeting_time: response.pre_bid_meeting_time,
                        tnd_url: response.tnd_url,
                        pre_bid_meeting_link: response.pre_bid_meeting_link,
                        pre_bid_mode: response.pre_bid_mode,
                        created_by: response.created_by,
                        status: 1,
                        modified_by: req.userId,
                        created_at: response.created_at,
                        updated_at: getCurrentDateTime(),
                    }
                    const insert = await TenderModel.create(dataInsert);
                    const bg_tender_id = insert.id;
                    if (insert) {
                        await TenderTrashModel.destroy({ where: { id: response.id, user_comp_id: req.comp_id } });
                        countDeleteRecord += 1;

                        await RemoveTrashAndDeleteCoverInfo(req.comp_id, tender_id, bg_tender_id)
                        await RemoveTrashAndDeleteDate(req.comp_id, tender_id, bg_tender_id)
                        await RemoveTrashAndDeleteFeeInfo(req.comp_id, tender_id, bg_tender_id)
                        await RemoveTrashAndDeleteOhterData(req.comp_id, tender_id, bg_tender_id)
                        await RemoveTrashAndDeleteTenderDocument(req.comp_id, tender_id, bg_tender_id)
                        await RemoveTrashAndDeleteTenderEmd(req.comp_id, tender_id, bg_tender_id)


                        const cycle_table_object = {
                            user_comp_id: response.user_comp_id,
                            tender_id: bg_tender_id,
                            from_cycle_id: response.cycle_id,
                            to_cycle_id: req.body.to_cycle_id,
                            scope_move_type: 'single-jump',
                            status: '1',
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                            updated_at: getCurrentDateTime(),
                        }


                        const TenderMoveCycleHistoryModel = createTenderMoveHistory(req.comp_id)
                        await TenderMoveCycleHistoryModel.performOperation()



                        const cycle_insert = await TenderMoveCycleHistoryModel.create(cycle_table_object);

                    }
                }

            }


            if (countDeleteRecord > 0) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: `${countDeleteRecord} Tenders Restored successfully`,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Records Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });
            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }

}




const trashtndrcycleinactionlist = async (req, res) => {
    try {
        const scope_rows = await Tenderscope.findOne({
            order: [['id', 'DESC']],
            attributes: ['id'],
            where: { category: '2', user_comp_id: req.comp_id, order_sr: 9 }
        })
        if (scope_rows) {
            const inactionlist = await TenderCycleAssignInactionModel.findAll({
                where: { user_comp_id: req.comp_id, status: '1', cycle_id: scope_rows.id },
                attributes: ['id', 'cycle_id', 'inaction_id'],
                include: [{
                    model: Inaction,
                    attributes: ['inaction_name', 'image_name'],
                    where: { status: '1' },
                    required: false,
                }
                ]
            })
            if (inactionlist) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: inactionlist
                });
            }
        }
        else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }



}


const addTenderCycleTrashBtnMultiple = async (req, res) => {
    const schema = Joi.object().keys({
        tender_ids: Joi.any().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        tender_ids: req.body.tender_ids,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    }
    else {
        try {
            const tender_ids = req.body.tender_ids.split(",").map(id => parseInt(id))
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderTrashModel = createTenderTrashModel(req.comp_id);
            await TenderTrashModel.performOperation();
            let countDeleteRecord = 0;
            for (const tenderId of tender_ids) {
                //console.log(tenderId);

                const response = await TenderModel.findOne({
                    where: {
                        user_comp_id: req.comp_id,
                        id: tenderId,
                        status: "1",
                        // cycle_id: { [Op.ne]: dataToValidate.cycle_id },
                    },
                   // attributes: ['id', 'cycle_id']

                });
                if (response) {
                    const check_scope_cr = await Tenderscope.findOne({
                        order: [['order_sr', 'ASC']],
                        where: {
                            user_comp_id: req.comp_id,
                            id: response.cycle_id,
                            status: '1',
                            category: '1'
                        },
                        attributes: ['id', 'order_sr']
                    });
                    const record_exist = await TenderGeneratedTypeIdModel.findOne({
                        where: {
                            user_comp_id: req.comp_id,
                            tender_id: tenderId,
                            status: '1',

                        },
                        attributes: ['id']
                    });
                    if ((check_scope_cr.order_sr <= 6) && (!record_exist)) {
                        const dataInsert = {
                            bg_tender_id: response.id,
                            tg_tender_id: response.tg_tender_id,
                            gg_tenderID: response.gg_tenderID,
                            user_comp_id: response.user_comp_id,
                            tender_name: response.tender_name,
                            tnd_ref_id: response.tnd_ref_id,
                            tender_gov_id: response.tender_gov_id,
                            tender_cost: response.tender_cost,
                            tender_emd_amnt_val: response.tender_emd_amnt_val,
                            client_id: response.client_id,
                            currency_id: response.currency_id,
                            region_id: response.region_id,
                            country_id: response.country_id,
                            state_id: response.state_id,
                            city_id: response.city_id,
                            sector_id: response.sector_id,
                            funding_id: response.funding_id,
                            cycle_id: response.cycle_id,
                            client_cont_person: response.client_cont_person,
                            client_cont_address: response.client_cont_address,
                            email_id: response.email_id,
                            phone_no: response.phone_no,
                            publication_date: response.publication_date,
                            submission_start_date: response.submission_start_date,
                            submission_end_date: response.submission_end_date,
                            bid_opening_place: response.bid_opening_place,
                            bid_validity_date: response.bid_validity_date,
                            source_id: response.source_id,
                            national_intern: response.national_intern,
                            pre_bid_meeting_place: response.pre_bid_meeting_place,
                            pre_bid_meeting_address: response.pre_bid_meeting_address,
                            pre_bid_meeting_date: response.pre_bid_meeting_date,
                            pre_bid_meeting_time: response.pre_bid_meeting_time,
                            tnd_url: response.tnd_url,
                            pre_bid_meeting_link: response.pre_bid_meeting_link,
                            pre_bid_mode: response.pre_bid_mode,
                            created_by: response.created_by,
                            status: response.status,
                            modified_by: response.modified_by,
                            created_at: response.created_at,
                            updated_at: response.updated_at,
                            deleted_by: req.userId,
                            deleted_at: getCurrentDateTime(),

                        }
                        const insert = await TenderTrashModel.create(dataInsert);
                        if (insert) {
                            await TenderModel.destroy({ where: { id: response.id, user_comp_id: req.comp_id } });
                            const userId = req.userId;
                            countDeleteRecord += 1;
                            await TrashAndDeleteCoverInfo(req.comp_id, tenderId, userId)
                            await TrashAndDeleteDate(req.comp_id, tenderId, userId)
                            await TrashAndDeleteFeeInfo(req.comp_id, tenderId, userId)
                            await TrashAndDeleteOhterData(req.comp_id, tenderId, userId)
                            await TrashAndDeleteTenderDocument(req.comp_id, tenderId, userId)
                            await TrashAndDeleteTenderEmd(req.comp_id, tenderId, userId)
                        }

                    }
                }
            }

            if (countDeleteRecord > 0) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: `${countDeleteRecord} Tender Trash Successfully Done`,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Records Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });
            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }

}




const TrashAndDeleteCoverInfo = async (comp_id, tender_id, userId) => {


    const TenderCoverInfoTrashModel = createTenderCoverInfoTrashModel(comp_id);
    await TenderCoverInfoTrashModel.performOperation();
    const TenderCoverInfoModel = createTenderCoverInfoModel(comp_id);


    const results = await TenderCoverInfoModel.findAll({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })

    for (data of results) {
        const result = data
        const idToDelete = result.dataValues.id;
        if (result) {
            const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
            dataToStore.cover_info_id = idToDelete;
            dataToStore.deleted_by = userId;
            dataToStore.deleted_at = getCurrentDateTime();
            const trashStore = await TenderCoverInfoTrashModel.create(dataToStore);
            if (trashStore) {
                const deleted = await TenderCoverInfoModel.destroy({
                    where: {
                        id: idToDelete
                    }
                });
            }
        }

    }




}

const RemoveTrashAndDeleteCoverInfo = async (comp_id, tender_id, bg_tender_id) => {


    const TenderCoverInfoTrashModel = createTenderCoverInfoTrashModel(comp_id);
    await TenderCoverInfoTrashModel.performOperation();
    const TenderCoverInfoModel = createTenderCoverInfoModel(comp_id);


    const results = await TenderCoverInfoTrashModel.findAll({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: bg_tender_id,
            status: "1"
        }
    })


    for (data of results) {
        const result = data
        const idToDelete = result.dataValues.id;
        console.log(idToDelete)
        if (result) {
            const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
            dataToStore.bg_tender_id = bg_tender_id;
            const trashRemove = await TenderCoverInfoModel.create(dataToStore);
            if (trashRemove) {
                const deleted = await TenderCoverInfoTrashModel.destroy({
                    where: {
                        id: idToDelete
                    }
                });
            }
        }

    }




}



const TrashAndDeleteDate = async (comp_id, tender_id, userId) => {
    const TenderDatesTrashModel = createTenderDatesTrashModel(comp_id);
    await TenderDatesTrashModel.performOperation();
    const TenderDatesModel = createTenderModelDate(comp_id);

    const result = await TenderDatesModel.findOne({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })

    const idToDelete = result?.dataValues.id
    if (result) {
        const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
        dataToStore.tndr_dates_id = idToDelete
        dataToStore.deleted_by = userId;
        dataToStore.deleted_at = getCurrentDateTime();
        const trashStore = await TenderDatesTrashModel.create(dataToStore);
        if (trashStore) {
            const deleted = await TenderDatesModel.destroy({
                where: {
                    id: idToDelete
                }
            });


        }
    }
}

const RemoveTrashAndDeleteDate = async (comp_id, tender_id, bg_tender_id) => {
    const TenderDatesTrashModel = createTenderDatesTrashModel(comp_id);
    await TenderDatesTrashModel.performOperation();
    const TenderDatesModel = createTenderModelDate(comp_id);

    const result = await TenderDatesTrashModel.findOne({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })

    const idToDelete = result?.dataValues.id
    if (result) {
        const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
        dataToStore.bg_tender_id = bg_tender_id
        const trashStore = await TenderDatesModel.create(dataToStore);
        if (trashStore) {
            const deleted = await TenderDatesTrashModel.destroy({
                where: {
                    id: idToDelete
                }
            });


        }
    }
}


const TrashAndDeleteTenderDocument = async (comp_id, tender_id, userId) => {

    const TenderDocumentTrashModel = createTenderDocumentTrashModel(comp_id);
    await TenderDocumentTrashModel.performOperation();
    const TenderDocumentModel = createTenderDocumentModel(comp_id);
    const results = await TenderDocumentModel.findAll({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })
    for (data of results) {
        const result = data
        const idToDelete = result.dataValues.id;
        if (result) {
            const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
            dataToStore.tndr_documents_id = idToDelete;
            dataToStore.deleted_by = userId;
            dataToStore.deleted_at = getCurrentDateTime();
            const trashStore = await TenderDocumentTrashModel.create(dataToStore);
            if (trashStore) {
                const deleted = await TenderDocumentModel.destroy({
                    where: {
                        id: idToDelete
                    }
                });
            }
        }

    }

}

const RemoveTrashAndDeleteTenderDocument = async (comp_id, tender_id, bg_tender_id) => {

    const TenderDocumentTrashModel = createTenderDocumentTrashModel(comp_id);
    await TenderDocumentTrashModel.performOperation();
    const TenderDocumentModel = createTenderDocumentModel(comp_id);
    const results = await TenderDocumentTrashModel.findAll({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })
    for (data of results) {
        const result = data
        const idToDelete = result.dataValues.id;
        if (result) {
            const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
            dataToStore.bg_tender_id = bg_tender_id;

            const RemovetrashStore = await TenderDocumentModel.create(dataToStore);
            if (RemovetrashStore) {
                const deleted = await TenderDocumentTrashModel.destroy({
                    where: {
                        id: idToDelete
                    }
                });
            }
        }

    }

}



const TrashAndDeleteTenderEmd = async (comp_id, tender_id, userId) => {

    const TenderEmdTrashModel = createTenderEmdTrashModel(comp_id);
    await TenderEmdTrashModel.performOperation();
    const TenderEmdModel = createTenderEmdModel(comp_id)


    const result = await TenderEmdModel.findOne({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })

    const idToDelete = result?.dataValues.id
    if (result) {
        const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
        dataToStore.tndr_emd_id = idToDelete
        dataToStore.deleted_by = userId;
        dataToStore.deleted_at = getCurrentDateTime();
        const trashStore = await TenderEmdTrashModel.create(dataToStore);
        if (trashStore) {
            const deleted = await TenderEmdModel.destroy({
                where: {
                    id: idToDelete
                }
            });
        }
    }
}

const RemoveTrashAndDeleteTenderEmd = async (comp_id, tender_id, bg_tender_id) => {

    const TenderEmdTrashModel = createTenderEmdTrashModel(comp_id);
    await TenderEmdTrashModel.performOperation();
    const TenderEmdModel = createTenderEmdModel(comp_id)


    const result = await TenderEmdTrashModel.findOne({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })

    const idToDelete = result?.dataValues.id
    if (result) {
        const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
        dataToStore.bg_tender_id = bg_tender_id
        const RemovetrashStore = await TenderEmdModel.create(dataToStore);
        if (RemovetrashStore) {
            const deleted = await TenderEmdTrashModel.destroy({
                where: {
                    id: idToDelete
                }
            });
        }
    }
}




const TrashAndDeleteFeeInfo = async (comp_id, tender_id, userId) => {

    const TenderFeeInfoTrashModel = createTenderFeeInfoTrashModel(comp_id);
    await TenderFeeInfoTrashModel.performOperation();
    const TenderFeeInfoModel = createTenderFeeInfoModel(comp_id)


    const result = await TenderFeeInfoModel.findOne({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })

    const idToDelete = result?.dataValues.id
    if (result) {
        const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
        dataToStore.tndr_fee_info_id = idToDelete
        dataToStore.deleted_by = userId;
        dataToStore.deleted_at = getCurrentDateTime();
        const trashStore = await TenderFeeInfoTrashModel.create(dataToStore);
        if (trashStore) {
            const deleted = await TenderFeeInfoModel.destroy({
                where: {
                    id: idToDelete
                }
            });


        }
    }
}

const RemoveTrashAndDeleteFeeInfo = async (comp_id, tender_id, bg_tender_id) => {

    const TenderFeeInfoTrashModel = createTenderFeeInfoTrashModel(comp_id);
    await TenderFeeInfoTrashModel.performOperation();
    const TenderFeeInfoModel = createTenderFeeInfoModel(comp_id)


    const result = await TenderFeeInfoTrashModel.findOne({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })

    const idToDelete = result?.dataValues.id
    if (result) {
        const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
        dataToStore.bg_tender_id = bg_tender_id
        const RemovetrashStore = await TenderFeeInfoModel.create(dataToStore);
        if (RemovetrashStore) {
            const deleted = await TenderFeeInfoTrashModel.destroy({
                where: {
                    id: idToDelete
                }
            });


        }
    }
}




const TrashAndDeleteOhterData = async (comp_id, tender_id, userId) => {

    const TenderOtherDataTrashModel = createTenderOtherDataTrashModel(comp_id);
    await TenderOtherDataTrashModel.performOperation();
    const TenderOtherDataModel = createTenderOtherDataModel(comp_id);

    const result = await TenderOtherDataModel.findOne({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })

    const idToDelete = result?.dataValues.id
    if (result) {
        const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
        dataToStore.tndr_other_data_id = idToDelete
        dataToStore.deleted_by = userId;
        dataToStore.deleted_at = getCurrentDateTime();
        const trashStore = await TenderOtherDataTrashModel.create(dataToStore);
        if (trashStore) {
            const deleted = await TenderOtherDataModel.destroy({
                where: {
                    id: idToDelete
                }
            });


        }
    }
}

const RemoveTrashAndDeleteOhterData = async (comp_id, tender_id, bg_tender_id) => {

    const TenderOtherDataTrashModel = createTenderOtherDataTrashModel(comp_id);
    await TenderOtherDataTrashModel.performOperation();
    const TenderOtherDataModel = createTenderOtherDataModel(comp_id);

    const result = await TenderOtherDataTrashModel.findOne({
        where: {
            user_comp_id: comp_id,
            bg_tender_id: tender_id,
            status: "1"
        }
    })

    const idToDelete = result?.dataValues.id
    if (result) {
        const dataToStore = { ...result.dataValues.id = null, ...result.dataValues }
        dataToStore.bg_tender_id = bg_tender_id
        const RemovetrashStore = await TenderOtherDataModel.create(dataToStore);
        if (RemovetrashStore) {
            const deleted = await TenderOtherDataTrashModel.destroy({
                where: {
                    id: idToDelete
                }
            });


        }
    }
}






module.exports = { addTenderCycleTrashBtn, addTenderCycleTrashBtnMultiple, RemovefromTenderCycleTrash, RemovefromTenderCycleTrashMultiple, trashtndrcycleinactionlist };