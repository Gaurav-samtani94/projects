const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Joi = require('joi');
const getCurrentDateTime = () => new Date();
require('dotenv').config();
const Tenderscope = require('../../models/master/TenderScope');
const createTenderModel = require('../../../apps/models/tender/TenderModel');
const createTenderMoveHistory = require('../../models/tender/TenderMovedHistroyByUserModel')
const TenderGeneratedTypeIdModel = require('../../models/tender/TenderGeneratedTypeIdModel')
const TenderAssignManagerModel = require('../../models/tender/TenderAssignManagerModel')
const TenderAssignConsortiumModel = require('../../models/tender/TenderAssignConsortiumModel')
const createTenderTrashModel = require('../../models/tender/TenderTrashModel')
const TenderCycleInactionModel = require('../../models/master/TenderCycleInactionModel');
const TenderCycleAssignInactionModel = require('../../models/tender/TenderCycleAssignInactionModel');
const Tenderpartners = require('../../models/tender/TenderPartner')
const Tenderstatusmanage = require('../../models/tender/TenderStatusManage');
const TenderStatus = require('../../models/master/TenderStatus');
const User = require('../../models/Users');



const cyclelistnext = async (req, res) => {
    try {
        if (req.body.cycle_id) {
            const response_2 = await Tenderscope.findOne({
                order: [['order_sr', 'ASC']],
                where: {
                    status: '1', user_comp_id: req.comp_id, id: req.body.cycle_id, // Additional filters can be added here
                },
                attributes: ['id', 'cycle_name', 'order_sr'],
            })
            if (!response_2) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            const datastore = [];
            for (let i = response_2.order_sr + 1; i <= 8; i++) {
                const response_3 = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']],
                    where: {
                        [Op.and]: [
                            { status: '1', user_comp_id: req.comp_id, order_sr: i }, // Additional filters can be added here
                        ],
                    },
                    attributes: ['id', 'cycle_name', 'order_sr']
                })
                if (response_3) {
                    datastore.push(response_3)
                }

            }
            if (datastore[0]) {
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: datastore,
                });
            } else {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } else {
            const response = await Tenderscope.findAll({
                order: [['order_sr', 'ASC']],
                where: {
                    [Op.and]: [
                        { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                        // Include the dynamic filters
                    ],
                },
                attributes: ['id', 'cycle_name', 'order_sr']

            })
            if (response[0]) {
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response,
                });
            } else {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            // message: error.message,
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        })
    }

}

// const addtndrcyclejompBulkdbtn = async (req, res) => {
//     const schema = Joi.object().keys({
//         tender_id: Joi.string().required(),
//         cycle_id: Joi.number().required(),
//         user_comp_id: Joi.number().required(),
//         created_by: Joi.number().required(),
//         created_at: Joi.date().iso().required()
//     });

//     const dataToValidate = {
//         tender_id: req.body.tender_id,
//         cycle_id: req.body.cycle_id,
//         user_comp_id: req.comp_id,
//         created_by: req.userId,
//         created_at:  getCurrentDateTime(),
//     };

//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     } else {
//         try {
//             console.log(req.body, 'tender_idtender_id')
//             const TenderModel = createTenderModel(req.comp_id);
//             await TenderModel.performOperation();

//             const TenderMovedHistroyByUserModel = createTenderMoveHistory(req.comp_id);
//             await TenderMovedHistroyByUserModel.performOperation();
//             const TenderArr = req.body.tender_id.split(',');
//             if (TenderArr) {
//                 const tasksWithCount = await Promise.all(TenderArr.map(async (data) => {
//                     const current_scope = await TenderModel.findOne({

//                         where: {
//                             user_comp_id: req.comp_id, id: data, status: '1',
//                             cycle_id: { [Op.ne]: req.body.cycle_id },

//                         }, attributes: ['cycle_id']
//                     })
//                     if (current_scope) {
//                         const check_scope = await Tenderscope.findOne({
//                             order: [['order_sr', 'ASC']],
//                             where: { user_comp_id: req.comp_id, id: req.body.cycle_id, status: '1' },
//                             attributes: ['cycle_name', 'order_sr']
//                         })
//                         //console.log(check_scope.order_sr,'scope');
//                         if (check_scope) {
//                             if ((check_scope.order_sr < 6)) {

//                                 const cycle_update_obj = {
//                                     cycle_id: req.body.cycle_id,
//                                     modified_by: req.userId,
//                                     updated_at:  getCurrentDateTime(),
//                                 }
//                                 const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
//                                     where: { id: data, user_comp_id: req.comp_id, status: '1' },
//                                 })

//                                 const tndr_cycle_move_history_insert = {
//                                     tender_id: data,
//                                     from_cycle_id: current_scope.cycle_id,
//                                     to_cycle_id: req.body.cycle_id,
//                                     user_comp_id: req.comp_id,
//                                     created_by: req.userId,
//                                     created_at:  getCurrentDateTime(),
//                                 };
//                                 await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
//                             }
//                             else {


//                                 return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                                     message: process.env.ERROR_MSG,
//                                     error: true,
//                                     success: false,
//                                     status: '0'
//                                 });
//                             }
//                         }
//                         else {
//                             return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                                 message: process.env.ERROR_MSG,
//                                 error: true,
//                                 success: false,
//                                 status: '0'
//                             });
//                         }

//                     }
//                     else {
//                         return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                             message: process.env.APIRESPMSG_RECNOTFOUND,
//                             error: true,
//                             success: false,
//                             status: '0'
//                         });
//                     }
//                 }));
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }

const addtndrcyclejumpsingledbtn = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        cycle_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
        cycle_id: req.body.cycle_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const TenderMovedHistroyByUserModel = createTenderMoveHistory(req.comp_id);
            await TenderMovedHistroyByUserModel.performOperation();
            const check_exist = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                }, attributes: ['cycle_id']
            });
            if (!check_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Recods Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            const current_scope = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                    cycle_id: { [Op.ne]: dataToValidate.cycle_id },
                }, attributes: ['cycle_id']
            });

            if (current_scope) {
                const check_scope_sr = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']],
                    where: { user_comp_id: req.comp_id, id: current_scope.cycle_id, status: '1' },
                    attributes: ['id', 'cycle_name', 'order_sr']
                })
                const check_next_scope = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']],
                    where: {
                        order_sr: {
                            [Sequelize.Op.gt]: check_scope_sr.order_sr,
                        },
                        user_comp_id: req.comp_id,
                        // id: current_scope.cycle_id,
                        status: '1',
                        category: '1'
                    },
                    attributes: ['id', 'order_sr']
                })

                const check_scope_cr = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']],
                    where: {
                        // order_sr: {
                        //     [Sequelize.Op.gt]: check_scope_sr.order_sr,
                        // },
                        user_comp_id: req.comp_id,
                        id: req.body.cycle_id,
                        status: '1',
                        category: '1'
                    },
                    attributes: ['id', 'order_sr']
                });
                if (check_scope_sr.order_sr > check_scope_cr.order_sr) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: 'Something Went Wrong',
                        error: true,
                        success: false,
                        status: '0',
                    });
                } else {
                    for (let i = 2; i <= check_scope_cr.order_sr; i++) {
                        const current_scope_1 = await TenderModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1'
                            }, attributes: ['cycle_id']
                        });

                        const check_scope_sr_1 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']], where: { user_comp_id: req.comp_id, id: current_scope_1.cycle_id, status: '1' }, attributes: ['id', 'cycle_name', 'order_sr']
                        })

                        const check_next_scope_1 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: {
                                order_sr: {
                                    [Sequelize.Op.gt]: check_scope_sr_1.order_sr,
                                },
                                user_comp_id: req.comp_id,
                                status: '1',
                                category: '1'
                            },
                            attributes: ['id', 'order_sr']
                        })
                        if (i < 7) {
                            if (check_next_scope_1.order_sr == 2) {
                                const current_scope_2 = await TenderModel.findOne({
                                    where: {
                                        user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                    }, attributes: ['cycle_id']
                                });
                                const check_scope_sr_2 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: { user_comp_id: req.comp_id, id: current_scope_2.cycle_id, status: '1' },
                                    attributes: ['id', 'cycle_name', 'order_sr']
                                })
                                const check_next_scope_2 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: {
                                        order_sr: {
                                            [Sequelize.Op.gt]: check_scope_sr_2.order_sr,
                                        },
                                        user_comp_id: req.comp_id,
                                        status: '1',
                                        category: '1'
                                    },
                                    attributes: ['id', 'order_sr', 'cycle_name']
                                })
                                const cycle_update_obj = {
                                    cycle_id: check_next_scope_2.id,
                                    modified_by: req.userId,
                                    updated_at: getCurrentDateTime(),
                                }
                                const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                    where: { id: dataToValidate.tender_id, user_comp_id: req.comp_id, status: '1' },
                                })
                                const tndr_cycle_move_history_insert = {
                                    tender_id: dataToValidate.tender_id,
                                    from_cycle_id: current_scope_2.cycle_id,
                                    to_cycle_id: check_next_scope_2.id,
                                    user_comp_id: req.comp_id,
                                    created_by: req.userId,
                                    created_at: getCurrentDateTime(),
                                    scope_move_type: 'single-jump'
                                };
                                await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                if (check_scope_cr.order_sr == 2) {
                                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: `Tender Move Into ${check_next_scope_2?.cycle_name} Successfully Done`,
                                        scope_name: check_next_scope_2?.cycle_name,
                                        error: false,
                                        success: true,
                                        status: '1',
                                        data: i,
                                    });
                                }
                            } else if (check_next_scope_1.order_sr == 3) {
                                const current_scope_3 = await TenderModel.findOne({
                                    where: {
                                        user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                    }, attributes: ['cycle_id']
                                });
                                const check_scope_sr_3 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: { user_comp_id: req.comp_id, id: current_scope_3.cycle_id, status: '1' },
                                    attributes: ['id', 'cycle_name', 'order_sr']
                                })
                                const check_next_scope_3 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: {
                                        order_sr: {
                                            [Sequelize.Op.gt]: check_scope_sr_3.order_sr,
                                        },
                                        user_comp_id: req.comp_id,
                                        // id: current_scope.cycle_id,
                                        status: '1',
                                        category: '1'
                                    },
                                    attributes: ['id', 'order_sr', 'cycle_name']
                                })
                                const cycle_update_obj = {
                                    cycle_id: check_next_scope_3.id,
                                    modified_by: req.userId,
                                    updated_at: getCurrentDateTime(),
                                }
                                const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                    where: { id: dataToValidate.tender_id, user_comp_id: req.comp_id, status: '1' },
                                })
                                const tndr_cycle_move_history_insert = {
                                    tender_id: dataToValidate.tender_id,
                                    from_cycle_id: current_scope_3.cycle_id,
                                    to_cycle_id: check_next_scope_3.id,
                                    user_comp_id: req.comp_id,
                                    created_by: req.userId,
                                    created_at: getCurrentDateTime(),
                                    scope_move_type: 'single-jump'
                                };
                                await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                if (check_scope_cr.order_sr == 3) {
                                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: `Tender Move Into ${check_next_scope_3?.cycle_name} Successfully Done`,
                                        scope_name: check_next_scope_3?.cycle_name,
                                        error: false,
                                        success: true,
                                        status: '1',
                                        data: i,
                                    });
                                }
                            } else if (check_next_scope_1.order_sr == 4) {
                                const current_scope_4 = await TenderModel.findOne({
                                    where: {
                                        user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                    }, attributes: ['cycle_id']
                                });
                                const check_scope_sr_4 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: { user_comp_id: req.comp_id, id: current_scope_4.cycle_id, status: '1' },
                                    attributes: ['id', 'cycle_name', 'order_sr']
                                })
                                const check_next_scope_4 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: {
                                        order_sr: {
                                            [Sequelize.Op.gt]: check_scope_sr_4.order_sr,
                                        },
                                        user_comp_id: req.comp_id,
                                        // id: current_scope.cycle_id,
                                        status: '1',
                                        category: '1'
                                    },
                                    attributes: ['id', 'order_sr', 'cycle_name']
                                })
                                const cycle_update_obj = {
                                    cycle_id: check_next_scope_4.id,
                                    modified_by: req.userId,
                                    updated_at: getCurrentDateTime(),
                                }
                                const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                    where: { id: dataToValidate.tender_id, user_comp_id: req.comp_id, status: '1' },
                                })
                                const tndr_cycle_move_history_insert = {
                                    tender_id: dataToValidate.tender_id,
                                    from_cycle_id: current_scope_4.cycle_id,
                                    to_cycle_id: check_next_scope_4.id,
                                    user_comp_id: req.comp_id,
                                    created_by: req.userId,
                                    created_at: getCurrentDateTime(),
                                    scope_move_type: 'single-jump'
                                };
                                await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                if (check_scope_cr.order_sr == 4) {
                                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: `Tender Move Into ${check_next_scope_4?.cycle_name} Successfully Done`,
                                        scope_name: check_next_scope_4?.cycle_name,
                                        error: false,
                                        success: true,
                                        status: '1',
                                    });
                                }
                            } else if (check_next_scope_1.order_sr == 5) {
                                const current_scope_5 = await TenderModel.findOne({
                                    where: {
                                        user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                    }, attributes: ['cycle_id']
                                });
                                const check_scope_sr_5 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: { user_comp_id: req.comp_id, id: current_scope_1.cycle_id, status: '1' },
                                    attributes: ['id', 'cycle_name', 'order_sr']
                                })
                                const check_next_scope_5 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: {
                                        order_sr: {
                                            [Sequelize.Op.gt]: check_scope_sr_5.order_sr,
                                        },
                                        user_comp_id: req.comp_id,
                                        // id: current_scope.cycle_id,
                                        status: '1',
                                        category: '1'
                                    },
                                    attributes: ['id', 'order_sr', 'cycle_name']
                                })
                                const cycle_update_obj = {
                                    cycle_id: check_next_scope_5.id,
                                    modified_by: req.userId,
                                    updated_at: getCurrentDateTime(),
                                }
                                const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                    where: { id: dataToValidate.tender_id, user_comp_id: req.comp_id, status: '1' },
                                })
                                const tndr_cycle_move_history_insert = {
                                    tender_id: dataToValidate.tender_id,
                                    from_cycle_id: current_scope_5.cycle_id,
                                    to_cycle_id: check_next_scope_5.id,
                                    user_comp_id: req.comp_id,
                                    created_by: req.userId,
                                    created_at: getCurrentDateTime(),
                                    scope_move_type: 'single-jump'
                                };
                                await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                if (check_scope_cr.order_sr == 5) {
                                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: `Tender Move Into ${check_next_scope_5?.cycle_name} Successfully Done`,
                                        scope_name: check_next_scope_5?.cycle_name,
                                        error: false,
                                        success: true,
                                        status: '1',
                                        data: i,
                                    });
                                }
                            } else if (check_next_scope_1.order_sr == 6) {

                                const current_scope_6 = await TenderModel.findOne({
                                    where: {
                                        user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                        // cycle_id: dataToValidate.cycle_id,
                                    }, attributes: ['cycle_id']
                                });
                                const check_scope_6 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: { user_comp_id: req.comp_id, id: current_scope_6.cycle_id, status: '1' },
                                    attributes: ['id', 'cycle_name', 'order_sr']
                                })
                                // console.log(current_scope.cycle_id, 'ss')
                                const check_next_scope_6 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: {
                                        order_sr: {
                                            [Sequelize.Op.gt]: check_scope_6.order_sr,
                                        },
                                        user_comp_id: req.comp_id,
                                        // id: current_scope.cycle_id,
                                        status: '1',
                                        category: '1'
                                    },
                                    attributes: ['id', 'order_sr', 'cycle_name']
                                })
                                const cycle_update_obj = {
                                    cycle_id: check_next_scope_6.id,
                                    modified_by: req.userId,
                                    updated_at: getCurrentDateTime(),
                                }
                                const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                    where: { id: req.body.tender_id, user_comp_id: req.comp_id },
                                })
                                const tndr_cycle_move_history_insert = {
                                    tender_id: req.body.tender_id,
                                    from_cycle_id: current_scope_6.cycle_id,
                                    to_cycle_id: check_next_scope_6.id,
                                    user_comp_id: req.comp_id,
                                    created_by: req.userId,
                                    created_at: getCurrentDateTime(),
                                    scope_move_type: 'single-jump'
                                };
                                TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                if (check_scope_cr.order_sr == 6) {
                                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: `Tender Move Into ${check_next_scope_6?.cycle_name} Successfully Done`,
                                        scope_name: check_next_scope_6?.cycle_name,
                                        error: false,
                                        success: true,
                                        status: '1',
                                        data: i,
                                    });
                                }

                            }

                        } else {
                            if (check_next_scope_1.order_sr == 7) {
                                const tenergenerated_id = await TenderGeneratedTypeIdModel.findOne({
                                    where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' },
                                    attributes: ['id']
                                })
                                const tenerkey_manager = await TenderAssignManagerModel.findOne({
                                    where: { bd_role_id: 1, tender_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' },
                                    attributes: ['id']
                                })
                                const tenerbid_manager = await TenderAssignManagerModel.findOne({
                                    where: { bd_role_id: 2, tender_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' },
                                    attributes: ['id']
                                })

                                const tener_consortium = await Tenderpartners.findOne({
                                    //where: { project_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1',type_data:'1', consortium_skip:null },
                                    // where: { 
                                    //     project_id: req.body.tender_id, 
                                    //     user_comp_id: req.comp_id, 
                                    //     status: '1', 
                                    //     type_data:'1', 
                                    //     consortium_skip: {
                                    //         [Op.eq]: 0
                                    //     }
                                    //     //consortium_skip:null 
                                    // },
                                    // where: {
                                    //     [Op.and]: [
                                    //         { 
                                    //             project_id: req.body.tender_id, 
                                    //             user_comp_id: req.comp_id, 
                                    //             status: '1', 
                                    //             type_data:'1', 
                                    //             //consortium_skip:null 
                                    //         },
                                    //         { 
                                    //             consortium_skip: {
                                    //                 [Op.eq]: 0
                                    //             }
                                    //         }
                                    //     ],
                                    // },
                                    where: {
                                        //[Op.and]: [
                                           // { 
                                                project_id: req.body.tender_id, 
                                                user_comp_id: req.comp_id, 
                                                status: '1', 
                                                type_data:'1', 
                                                //consortium_skip:null 
                                          // },
                                            //{ 
                                                consortium_skip: {
                                                    [Op.is]: null
                                                }
                                           // }
                                      //  ],
                                    },
                                    attributes: ['id']
                                })
                                if (!tenergenerated_id) {
                                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                        message: 'Set Tender Generated ID',
                                        error: true,
                                        success: false,
                                        status: '0',
                                        stage: 5
                                    });
                                } else if (!tenerkey_manager) {
                                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                        message: 'Set Tender Key Manager',
                                        error: true,
                                        success: false,
                                        status: '0',
                                        stage: 6
                                    });
                                } else if (!tenerbid_manager) {
                                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                        message: 'Set Tender Bid Manager',
                                        error: true,
                                        success: false,
                                        status: '0',
                                        stage: 7
                                    });

                                } else if (!tener_consortium) {
                                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                        message: 'Set Tender Consortium',
                                        error: true,
                                        success: false,
                                        status: '0',
                                        stage: 11
                                    });
                                } else {
                                    const current_scope_7 = await TenderModel.findOne({
                                        where: {
                                            user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                            // cycle_id: dataToValidate.cycle_id,
                                        }, attributes: ['cycle_id']
                                    });
                                    const check_scope_7 = await Tenderscope.findOne({
                                        order: [['order_sr', 'ASC']],
                                        where: { user_comp_id: req.comp_id, id: current_scope_7.cycle_id, status: '1' },
                                        attributes: ['id', 'cycle_name', 'order_sr']
                                    })
                                    // console.log(current_scope.cycle_id, 'ss')
                                    const check_next_scope_7 = await Tenderscope.findOne({
                                        order: [['order_sr', 'ASC']],
                                        where: {
                                            order_sr: {
                                                [Sequelize.Op.gt]: check_scope_7.order_sr,
                                            },
                                            user_comp_id: req.comp_id,
                                            // id: current_scope.cycle_id,
                                            status: '1',
                                            category: '1'
                                        },
                                        attributes: ['id', 'order_sr', 'cycle_name']
                                    })
                                    const cycle_update_obj = {
                                        cycle_id: check_next_scope_7.id,
                                        modified_by: req.userId,
                                        updated_at: getCurrentDateTime(),
                                    }
                                    const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                        where: { id: req.body.tender_id, user_comp_id: req.comp_id },
                                    })
                                    const tndr_cycle_move_history_insert = {
                                        tender_id: req.body.tender_id,
                                        from_cycle_id: current_scope_7.cycle_id,
                                        to_cycle_id: check_next_scope_7.id,
                                        user_comp_id: req.comp_id,
                                        created_by: req.userId,
                                        created_at: getCurrentDateTime(),
                                        scope_move_type: 'single-jump'
                                    };
                                    TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                    if (check_scope_cr.order_sr == 7) {
                                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                            message: `Tender Move Into ${check_next_scope_7?.cycle_name} Successfully Done`,
                                            scope_name: check_next_scope_7?.cycle_name,
                                            error: false,
                                            success: true,
                                            status: '1',
                                            data: i,
                                        });
                                    }
                                }
                            } else if (check_next_scope_1.order_sr == 8) {
                                const current_scope_8 = await TenderModel.findOne({
                                    where: {
                                        user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                        // cycle_id: dataToValidate.cycle_id,
                                    }, attributes: ['cycle_id']
                                });
                                const check_scope_8 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: { user_comp_id: req.comp_id, id: current_scope_8.cycle_id, status: '1' },
                                    attributes: ['id', 'cycle_name', 'order_sr']
                                })
                                // console.log(current_scope.cycle_id, 'ss')
                                const check_next_scope_8 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: {
                                        order_sr: {
                                            [Sequelize.Op.gt]: check_scope_8.order_sr,
                                        },
                                        user_comp_id: req.comp_id,
                                        // id: current_scope.cycle_id,
                                        status: '1',
                                        category: '1'
                                    },
                                    attributes: ['id', 'order_sr', 'cycle_name']
                                })
                                const check_awaiting_status = await TenderStatus.findOne({
                                    order: [['id', 'ASC']],
                                    where: { user_comp_id: req.comp_id, status: '1' },
                                    attributes: ['id']
                                })
                                const cycle_update_obj = {
                                    cycle_id: check_next_scope_8.id,
                                    modified_by: req.userId,
                                    updated_at: getCurrentDateTime(),
                                }
                                const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                    where: { id: req.body.tender_id, user_comp_id: req.comp_id },
                                })
                                const tndr_cycle_move_history_insert = {
                                    tender_id: req.body.tender_id,
                                    from_cycle_id: current_scope_8.cycle_id,
                                    to_cycle_id: check_next_scope_8.id,
                                    user_comp_id: req.comp_id,
                                    created_by: req.userId,
                                    created_at: getCurrentDateTime(),
                                    scope_move_type: 'single-jump'
                                };
                                TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                const tndr_cycle_awaiting_insert = {
                                    project_id: req.body.tender_id,
                                    tender_status: check_awaiting_status.id,
                                    user_comp_id: req.comp_id,
                                    created_by: req.userId,
                                    created_at: getCurrentDateTime(),
                                };
                                await Tenderstatusmanage.create(tndr_cycle_awaiting_insert);
                                if (check_scope_cr.order_sr == 8) {
                                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: `Tender Move Into ${check_next_scope_8?.cycle_name} Successfully Done`,
                                        scope_name: check_next_scope_8?.cycle_name,
                                        // message: 'Tender Submitted Successfully',
                                        error: false,
                                        success: true,
                                        status: '1',
                                        data: i,
                                    });
                                }
                            }

                        }
                    }
                }
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'This Tender Is Already On This Scope',
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
const addtndrcyclejumpmultipledbtn = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.string().required(),
        cycle_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
        cycle_id: req.body.cycle_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderMovedHistroyByUserModel = createTenderMoveHistory(req.comp_id);
            await TenderMovedHistroyByUserModel.performOperation();
            const TenderArr = req.body.tender_id.split(',');

            const check_scope_res = await Tenderscope.findOne({
                order: [['order_sr', 'ASC']],
                where: {
                    // order_sr: {
                    //     [Sequelize.Op.gt]: check_scope_sr.order_sr,
                    // },
                    user_comp_id: req.comp_id,
                    id: req.body.cycle_id,
                    status: '1',
                    category: '1'
                },
                attributes: ['id', 'order_sr']
            });
            if (check_scope_res.order_sr < 7) {
                const tasksWithCount = await Promise.all(TenderArr.map(async (data) => {
                    const current_scope = await TenderModel.findOne({
                        where: {
                            user_comp_id: req.comp_id, id: data, status: '1',
                            cycle_id: { [Op.ne]: dataToValidate.cycle_id },
                        }, attributes: ['cycle_id']
                    });
                    if (current_scope) {
                        const check_scope_sr = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: { user_comp_id: req.comp_id, id: current_scope.cycle_id, status: '1' },
                            attributes: ['id', 'cycle_name', 'order_sr']
                        })
                        const check_next_scope = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: {
                                order_sr: {
                                    [Sequelize.Op.gt]: check_scope_sr.order_sr,
                                },
                                user_comp_id: req.comp_id,
                                // id: current_scope.cycle_id,
                                status: '1',
                                category: '1'
                            },
                            attributes: ['id', 'order_sr']
                        })

                        const check_scope_cr = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: {
                                // order_sr: {
                                //     [Sequelize.Op.gt]: check_scope_sr.order_sr,
                                // },
                                user_comp_id: req.comp_id,
                                id: req.body.cycle_id,
                                status: '1',
                                category: '1'
                            },
                            attributes: ['id', 'order_sr']
                        });
                        if (check_scope_sr.order_sr < check_scope_cr.order_sr) {
                            for (let i = 2; i <= check_scope_cr.order_sr; i++) {
                                const current_scope_1 = await TenderModel.findOne({
                                    where: {
                                        user_comp_id: req.comp_id, id: data, status: '1'
                                    }, attributes: ['cycle_id']
                                });

                                const check_scope_sr_1 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']], where: { user_comp_id: req.comp_id, id: current_scope_1.cycle_id, status: '1' }, attributes: ['id', 'cycle_name', 'order_sr']
                                })
                                const check_next_scope_1 = await Tenderscope.findOne({
                                    order: [['order_sr', 'ASC']],
                                    where: {
                                        order_sr: {
                                            [Sequelize.Op.gt]: check_scope_sr_1.order_sr,
                                        },
                                        user_comp_id: req.comp_id,
                                        status: '1',
                                        category: '1'
                                    },
                                    attributes: ['id', 'order_sr']
                                })
                                if (i < 6) {
                                    if ((check_next_scope_1.order_sr == 2) && (i == 2)) {
                                        const current_scope_2 = await TenderModel.findOne({
                                            where: {
                                                user_comp_id: req.comp_id, id: data, status: '1',
                                            }, attributes: ['cycle_id']
                                        });
                                        const check_scope_sr_2 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: { user_comp_id: req.comp_id, id: current_scope_2.cycle_id, status: '1' },
                                            attributes: ['id', 'cycle_name', 'order_sr']
                                        })
                                        const check_next_scope_2 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: {
                                                order_sr: {
                                                    [Sequelize.Op.gt]: check_scope_sr_2.order_sr,
                                                },
                                                user_comp_id: req.comp_id,
                                                status: '1',
                                                category: '1'
                                            },
                                            attributes: ['id', 'order_sr']
                                        })
                                        const cycle_update_obj = {
                                            cycle_id: check_next_scope_2.id,
                                            modified_by: req.userId,
                                            updated_at: getCurrentDateTime(),
                                        }
                                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                            where: { id: data, user_comp_id: req.comp_id, status: '1' },
                                        })
                                        const tndr_cycle_move_history_insert = {
                                            tender_id: data,
                                            from_cycle_id: current_scope_2.cycle_id,
                                            to_cycle_id: check_next_scope_2.id,
                                            user_comp_id: req.comp_id,
                                            created_by: req.userId,
                                            created_at: getCurrentDateTime(),
                                            scope_move_type: 'jump-bulk'
                                        };
                                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                        // if (check_scope_cr.order_sr == 2) {
                                        // return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        //     message: 'Remove Tender Successfully Done',
                                        //     error: false,
                                        //     success: true,
                                        //     status: '1',
                                        //     data: i,
                                        // });
                                        // }
                                    } else if ((check_next_scope_1.order_sr == 3) && (i == 3)) {
                                        const current_scope_3 = await TenderModel.findOne({
                                            where: {
                                                user_comp_id: req.comp_id, id: data, status: '1',
                                            }, attributes: ['cycle_id']
                                        });
                                        const check_scope_sr_3 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: { user_comp_id: req.comp_id, id: current_scope_3.cycle_id, status: '1' },
                                            attributes: ['id', 'cycle_name', 'order_sr']
                                        })
                                        const check_next_scope_3 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: {
                                                order_sr: {
                                                    [Sequelize.Op.gt]: check_scope_sr_3.order_sr,
                                                },
                                                user_comp_id: req.comp_id,
                                                // id: current_scope.cycle_id,
                                                status: '1',
                                                category: '1'
                                            },
                                            attributes: ['id', 'order_sr']
                                        })
                                        const cycle_update_obj = {
                                            cycle_id: check_next_scope_3.id,
                                            modified_by: req.userId,
                                            updated_at: getCurrentDateTime(),
                                        }
                                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                            where: { id: data, user_comp_id: req.comp_id, status: '1' },
                                        })
                                        const tndr_cycle_move_history_insert = {
                                            tender_id: data,
                                            from_cycle_id: current_scope_3.cycle_id,
                                            to_cycle_id: check_next_scope_3.id,
                                            user_comp_id: req.comp_id,
                                            created_by: req.userId,
                                            created_at: getCurrentDateTime(),
                                            scope_move_type: 'jump-bulk'
                                        };
                                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                        // if (check_scope_cr.order_sr == 3) {
                                        // return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        //     message: 'Remove Tender Successfully Done',
                                        //     error: false,
                                        //     success: true,
                                        //     status: '1',
                                        //     data: i,
                                        // });
                                        // }
                                    } else if ((check_next_scope_1.order_sr == 4) && (i == 4)) {
                                        const current_scope_4 = await TenderModel.findOne({
                                            where: {
                                                user_comp_id: req.comp_id, id: data, status: '1',
                                            }, attributes: ['cycle_id']
                                        });
                                        const check_scope_sr_4 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: { user_comp_id: req.comp_id, id: current_scope_4.cycle_id, status: '1' },
                                            attributes: ['id', 'cycle_name', 'order_sr']
                                        })
                                        const check_next_scope_4 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: {
                                                order_sr: {
                                                    [Sequelize.Op.gt]: check_scope_sr_4.order_sr,
                                                },
                                                user_comp_id: req.comp_id,
                                                // id: current_scope.cycle_id,
                                                status: '1',
                                                category: '1'
                                            },
                                            attributes: ['id', 'order_sr']
                                        })
                                        const cycle_update_obj = {
                                            cycle_id: check_next_scope_4.id,
                                            modified_by: req.userId,
                                            updated_at: getCurrentDateTime(),
                                        }
                                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                            where: { id: data, user_comp_id: req.comp_id, status: '1' },
                                        })
                                        const tndr_cycle_move_history_insert = {
                                            tender_id: data,
                                            from_cycle_id: current_scope_4.cycle_id,
                                            to_cycle_id: check_next_scope_4.id,
                                            user_comp_id: req.comp_id,
                                            created_by: req.userId,
                                            created_at: getCurrentDateTime(),
                                            scope_move_type: 'jump-bulk'
                                        };
                                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                        // if (check_scope_cr.order_sr == 4) {
                                        // return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        //     message: 'Remove Tender Successfully Done',
                                        //     error: false,
                                        //     success: true,
                                        //     status: '1',
                                        // });
                                        // }
                                    } else if ((check_next_scope_1.order_sr == 5) && (i == 5)) {
                                        const current_scope_5 = await TenderModel.findOne({
                                            where: {
                                                user_comp_id: req.comp_id, id: data, status: '1',
                                            }, attributes: ['cycle_id']
                                        });
                                        const check_scope_sr_5 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: { user_comp_id: req.comp_id, id: current_scope_1.cycle_id, status: '1' },
                                            attributes: ['id', 'cycle_name', 'order_sr']
                                        })
                                        const check_next_scope_5 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: {
                                                order_sr: {
                                                    [Sequelize.Op.gt]: check_scope_sr_5.order_sr,
                                                },
                                                user_comp_id: req.comp_id,
                                                // id: current_scope.cycle_id,
                                                status: '1',
                                                category: '1'
                                            },
                                            attributes: ['id', 'order_sr']
                                        })
                                        const cycle_update_obj = {
                                            cycle_id: check_next_scope_5.id,
                                            modified_by: req.userId,
                                            updated_at: getCurrentDateTime(),
                                        }
                                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                            where: { id: data, user_comp_id: req.comp_id, status: '1' },
                                        })
                                        const tndr_cycle_move_history_insert = {
                                            tender_id: data,
                                            from_cycle_id: current_scope_5.cycle_id,
                                            to_cycle_id: check_next_scope_5.id,
                                            user_comp_id: req.comp_id,
                                            created_by: req.userId,
                                            created_at: getCurrentDateTime(),
                                            scope_move_type: 'jump-bulk'
                                        };
                                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                        // if (check_scope_cr.order_sr == 5) {
                                        // return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        //     message: 'Remove Tender Successfully Done',
                                        //     error: false,
                                        //     success: true,
                                        //     status: '1',
                                        //     data: i,
                                        // });
                                        // }
                                    } else if ((check_next_scope_1.order_sr == 6) && (i == 6)) {

                                        const current_scope_6 = await TenderModel.findOne({
                                            where: {
                                                user_comp_id: req.comp_id, id: data, status: '1',
                                            }, attributes: ['cycle_id']
                                        });
                                        const check_scope_sr_6 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: { user_comp_id: req.comp_id, id: current_scope_1.cycle_id, status: '1' },
                                            attributes: ['id', 'cycle_name', 'order_sr']
                                        })
                                        const check_next_scope_6 = await Tenderscope.findOne({
                                            order: [['order_sr', 'ASC']],
                                            where: {
                                                order_sr: {
                                                    [Sequelize.Op.gt]: check_scope_sr_6.order_sr,
                                                },
                                                user_comp_id: req.comp_id,
                                                // id: current_scope.cycle_id,
                                                status: '1',
                                                category: '1'
                                            },
                                            attributes: ['id', 'order_sr']
                                        })
                                        const cycle_update_obj = {
                                            cycle_id: check_next_scope_6.id,
                                            modified_by: req.userId,
                                            updated_at: getCurrentDateTime(),
                                        }
                                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                            where: { id: data, user_comp_id: req.comp_id, status: '1' },
                                        })
                                        const tndr_cycle_move_history_insert = {
                                            tender_id: data,
                                            from_cycle_id: current_scope_6.cycle_id,
                                            to_cycle_id: check_next_scope_6.id,
                                            user_comp_id: req.comp_id,
                                            created_by: req.userId,
                                            created_at: getCurrentDateTime(),
                                            scope_move_type: 'jump-bulk'
                                        };
                                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                                        // if (check_scope_cr.order_sr == 5) {
                                        // return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        //     message: 'Remove Tender Successfully Done',
                                        //     error: false,
                                        //     success: true,
                                        //     status: '1',
                                        //     data: i,
                                        // });
                                        // }
                                    }


                                }
                            }
                        }
                    }
                }));
                const current_scope = await TenderModel.findOne({
                    where: {
                        user_comp_id: req.comp_id, id: TenderArr[0], status: '1',
                    }, attributes: ['cycle_id']
                });
                const check_scope = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']],
                    where: { user_comp_id: req.comp_id, id: current_scope.cycle_id, status: '1' },
                    attributes: ['id', 'cycle_name', 'order_sr']
                })
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: `Tender Move Into ${check_scope?.cycle_name} Successfully Done`,
                    scope_name: check_scope?.cycle_name,
                    error: false,
                    success: true,
                    status: '1',
                    // data: i,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'You can Not perform this action',
                    error: true,
                    success: false,
                    status: '0',

                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
const addtndrcycletrashsingledbtn = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();


            const TenderTrashModel = createTenderTrashModel(req.comp_id);
            await TenderTrashModel.performOperation();

            const response = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                    // cycle_id: { [Op.ne]: dataToValidate.cycle_id },
                },
            });

            if (response) {
                const check_scope_cr = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']],
                    where: {
                        user_comp_id: req.comp_id,
                        id: response.cycle_id,
                        status: '1',
                        category: '1'
                    },
                    attributes: ['id', 'order_sr'],
                });
                if (check_scope_cr.order_sr >= 6) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: 'You cant Delete',
                        error: true,
                        success: false,
                        status: '0',
                    });
                } else {
                    const dataInsert = {
                        tender_id: response.id,
                        gg_tenderID: response.gg_tenderID,
                        user_comp_id: response.user_comp_id,
                        tender_name: response.tender_name,
                        tnd_ref_id: response.tnd_ref_id,
                        tender_gov_id: response.tender_gov_id,
                        tender_cost: response.tender_cost,
                        tender_emd_amnt_val: response.tender_emd_amnt_val,
                        client_id: response.client_id,
                        currency_id: response.currency_id,
                        region_id: response.region_id,
                        country_id: response.country_id,
                        state_id: response.state_id,
                        city_id: response.city_id,
                        sector_id: response.sector_id,
                        funding_id: response.funding_id,
                        cycle_id: response.cycle_id,
                        client_cont_person: response.client_cont_person,
                        client_cont_address: response.client_cont_address,
                        email_id: response.email_id,
                        phone_no: response.phone_no,
                        publication_date: response.publication_date,
                        submission_start_date: response.submission_start_date,
                        submission_end_date: response.submission_end_date,
                        bid_opening_place: response.bid_opening_place,
                        bid_validity_date: response.bid_validity_date,
                        source_id: response.source_id,
                        national_intern: response.national_intern,
                        pre_bid_meeting_place: response.pre_bid_meeting_place,
                        pre_bid_meeting_address: response.pre_bid_meeting_address,
                        pre_bid_meeting_date: response.pre_bid_meeting_date,
                        pre_bid_meeting_time: response.pre_bid_meeting_time,
                        tnd_url: response.tnd_url,
                        pre_bid_meeting_link: response.pre_bid_meeting_link,
                        pre_bid_mode: response.pre_bid_mode,
                        created_by: response.created_by,
                        tndr_status: response.status,
                        tndr_modified_by: response.modified_by,
                        tndr_created_at: response.created_at,
                        tndr_updated_at: response.updated_at,
                        trash_by: req.userId,
                        created_at: getCurrentDateTime(),
                    }
                    const insert = await TenderTrashModel.create(dataInsert);
                    if (insert) {
                        await TenderModel.destroy({ where: { id: response.id, user_comp_id: req.comp_id } });

                    } else {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.ERROR_MSG,
                            error: true,
                            success: false,
                            status: '0',
                        });


                    }
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Tender Trash Successfull',
                        error: false,
                        success: true,
                        status: '1',
                    });

                }
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Records Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
const tendercycleinactionlist = async (req, res) => {
    try {
        const check_scope = await Tenderscope.findOne({
            where: {
                user_comp_id: req.comp_id, status: '1', id: req.body.cycle_id,
            },
            attributes: ['id', 'cycle_name', 'order_sr']
        })
        if (check_scope) {
            const check_scope_1 = await Tenderscope.findAll({
                order: [['order_sr', 'ASC']],
                where: {
                    user_comp_id: req.comp_id, status: '1',
                    order_sr: {
                        [Sequelize.Op.lt]: 6,
                    },

                },
                attributes: ['id', 'cycle_name', 'order_sr']
            })
            const lastObject = check_scope_1[check_scope_1.length - 1];
            if (check_scope.order_sr < lastObject.order_sr) {
                const list = await TenderCycleInactionModel.findAll
                    ({
                        where: {
                            status: '1',
                            id: [1, 2, 3, 4, 12]
                        },
                        attributes: ['id', 'inaction_name']
                    });
                const response = await Promise.all(list.map(async (data) => {
                    const dataRes = await TenderCycleAssignInactionModel.findOne({
                        where: {
                            user_comp_id: req.comp_id, inaction_id: data.id, status: '1',
                            cycle_id: req.body.cycle_id,
                        }, attributes: ['id']
                    });
                    const inactionassignbtn = (dataRes) ? '1' : '0';
                    const inactionassign_id = (dataRes) ? dataRes.id : '';
                    return {
                        ...data.toJSON(),
                        inactionassignbtn,
                        inactionassign_id,


                    };
                }));
                if (list[0]) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECFOUND,
                        error: false,
                        success: true,
                        status: '1',
                        data: response
                    });

                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',

                    });
                }
            } else {
                if ((check_scope.order_sr == 5)) {
                    const list = await TenderCycleInactionModel.findAll
                        ({
                            where: {
                                status: '1',
                                // id: [1, 2, 3, 4, 5, 6, 7, 8, 9, 12]
                                id: [1, 2, 3, 4, 12]
                            },
                            attributes: ['id', 'inaction_name']
                        });

                    const response = await Promise.all(list.map(async (data) => {
                        const dataRes = await TenderCycleAssignInactionModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, inaction_id: data.id, status: '1',
                                cycle_id: req.body.cycle_id,
                            }, attributes: ['id']
                        });
                        const inactionassignbtn = (dataRes) ? '1' : '0';
                        const inactionassign_id = (dataRes) ? dataRes.id : ''
                        return {
                            ...data.toJSON(),
                            inactionassignbtn,
                            inactionassign_id

                        };
                    }));
                    if (list[0]) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECFOUND,
                            error: false,
                            success: true,
                            status: '1',
                            data: response
                        });

                    } else {
                        res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECNOTFOUND,
                            error: true,
                            success: false,
                            status: '0',

                        });
                    }
                } else if ((check_scope.order_sr == 6)) {
                    const list = await TenderCycleInactionModel.findAll
                        ({
                            where: {
                                status: '1',
                                id: [1, 2, 3, 5, 6, 7, 8, 9, 12]
                                // id: [1, 2, 3, 4, 10, 11, 12]
                            },
                            attributes: ['id', 'inaction_name']
                        });
                    const response = await Promise.all(list.map(async (data) => {
                        const dataRes = await TenderCycleAssignInactionModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, inaction_id: data.id, status: '1',
                                cycle_id: req.body.cycle_id,
                            }, attributes: ['id']
                        });
                        const inactionassignbtn = (dataRes) ? '1' : '0';
                        const inactionassign_id = (dataRes) ? dataRes.id : ''
                        return {
                            ...data.toJSON(),
                            inactionassignbtn,
                            inactionassign_id

                        };
                    }));
                    if (list[0]) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECFOUND,
                            error: false,
                            success: true,
                            status: '1',
                            data: response
                        });

                    } else {
                        res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECNOTFOUND,
                            error: true,
                            success: false,
                            status: '0',

                        });
                    }
                } else if ((check_scope.order_sr == 7)) {
                    const list = await TenderCycleInactionModel.findAll
                        ({
                            where: {
                                status: '1',
                                id: [1, 2, 3, 12]
                            },
                            attributes: ['id', 'inaction_name']
                        });
                    const response = await Promise.all(list.map(async (data) => {
                        const dataRes = await TenderCycleAssignInactionModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, inaction_id: data.id, status: '1',
                                cycle_id: req.body.cycle_id,
                            }, attributes: ['id']
                        });
                        const inactionassignbtn = (dataRes) ? '1' : '0';
                        const inactionassign_id = (dataRes) ? dataRes.id : ''
                        return {
                            ...data.toJSON(),
                            inactionassignbtn,
                            inactionassign_id

                        };
                    }));
                    if (list[0]) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECFOUND,
                            error: false,
                            success: true,
                            status: '1',
                            data: response
                        });

                    } else {
                        res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECNOTFOUND,
                            error: true,
                            success: false,
                            status: '0',

                        });
                    }
                } else if ((check_scope.order_sr == 8)) {
                    const list = await TenderCycleInactionModel.findAll
                        ({
                            where: {
                                status: '1',
                                id: [2, 12]
                            },
                            attributes: ['id', 'inaction_name']
                        });
                    const response = await Promise.all(list.map(async (data) => {
                        const dataRes = await TenderCycleAssignInactionModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, inaction_id: data.id, status: '1',
                                cycle_id: req.body.cycle_id,
                            }, attributes: ['id']
                        });
                        const inactionassignbtn = (dataRes) ? '1' : '0';
                        const inactionassign_id = (dataRes) ? dataRes.id : ''
                        return {
                            ...data.toJSON(),
                            inactionassignbtn,
                            inactionassign_id

                        };
                    }));
                    if (list[0]) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECFOUND,
                            error: false,
                            success: true,
                            status: '1',
                            data: response
                        });

                    } else {
                        res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECNOTFOUND,
                            error: true,
                            success: false,
                            status: '0',

                        });
                    }
                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.ERROR_MSG,
                        error: true,
                        success: false,
                        status: '0',

                    });
                }
            }
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
                data: ''
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }


}
const tenderinactionbtnupdate = async (req, res) => {
    const schema = Joi.object().keys({
        inaction_id: Joi.number().required(),
        cycle_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        inaction_id: req.body.inaction_id,
        cycle_id: req.body.cycle_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const check_inaction_btn = await TenderCycleInactionModel.findOne({
                where: {
                    status: '1', id: req.body.inaction_id,
                },
                attributes: ['id']
            })
            const check_scope_exist = await Tenderscope.findAll({
                order: [['order_sr', 'ASC']],
                where: {
                    user_comp_id: req.comp_id, status: '1', id: req.body.cycle_id,


                },
                attributes: ['id']
            })
            if ((check_scope_exist) && (check_inaction_btn)) {
                const response = await TenderCycleAssignInactionModel.findOne({
                    where: {
                        user_comp_id: req.comp_id, cycle_id: req.body.cycle_id,
                        inaction_id: req.body.inaction_id,
                    }, attributes: ['id', 'status']
                });
                if (response) {
                    if (response.status == '0') {
                        const updstutus = {
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                            status: '1',
                        }
                        const response = await TenderCycleAssignInactionModel.update(updstutus, {
                            where: {
                                user_comp_id: req.comp_id, cycle_id: req.body.cycle_id,
                                inaction_id: req.body.inaction_id, status: '0'
                            }
                        });
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    } else if (response.status == '1') {
                        const updstutus = {
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                            status: '0',
                        }
                        const response = await TenderCycleAssignInactionModel.update(updstutus, {
                            where: {
                                user_comp_id: req.comp_id, cycle_id: req.body.cycle_id,
                                inaction_id: req.body.inaction_id, status: '1'
                            }
                        });
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    }
                } else {
                    const insert = {
                        user_comp_id: req.comp_id,
                        cycle_id: req.body.cycle_id,
                        inaction_id: req.body.inaction_id,
                        created_by: req.userId,
                        created_at: getCurrentDateTime(),
                        status: '1',
                    }
                    const response = await TenderCycleAssignInactionModel.create(insert);
                    if (response) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    }
                }

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',

                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }

}

// const tendercycletrackhistory = async (req, res) => {
//     const schema = Joi.object().keys({
//         tender_id: Joi.number().required(),
//         user_comp_id: Joi.number().required(),
//         created_by: Joi.number().required(),
//         created_at: Joi.date().iso().required()
//     });
//     const dataToValidate = {
//         tender_id: req.body.tender_id,
//         user_comp_id: req.comp_id,
//         created_by: req.userId,
//         created_at: getCurrentDateTime(),
//     };

//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     } else {
//         try {

//             const TenderMovedHistroyByUserModel = createTenderMoveHistory(req.comp_id);
//             await TenderMovedHistroyByUserModel.performOperation();

//             const response = await TenderMovedHistroyByUserModel.findAll(
//                 {
//                     where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '1' },
//                     attributes: ['tender_id', 'to_cycle_id'],
//                     include: [{
//                         model: Tenderscope,
//                         attributes: ['cycle_name', 'created_at'],
//                         where: { status: '1' },
//                         required: false,
//                     },
//                     ]
//                 }
//             );
//             if (response[0]) {
//                 res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                     message: process.env.APIRESPMSG_RECFOUND,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     data: response,
//                 });
//             } else {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0',

//                 });
//             }
//         }
//         catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }

// }


const tendercycletrackhistory = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        tender_id: req.body.tender_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            // console.log(req.comp_id)
            // console.log(req.body.tender_id)
            // console.log(req.userId)

            const result = []

            const TenderMovedHistroyByUserModel = createTenderMoveHistory(req.comp_id);
            await TenderMovedHistroyByUserModel.performOperation();
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const TenderDetails = await TenderModel.findAll({
                where: {
                    id: req.body.tender_id,
                    user_comp_id: req.comp_id,
                    status: '1'
                },
                attributes: ['id', 'cycle_id', 'created_at', 'source_id'],

            })
            TenderDetails[0].source_id = (TenderDetails[0].source_id == '1') ? 'Manually' : (TenderDetails[0].source_id == '2') ? 'Api' : (TenderDetails[0].source_id == '3') ? 'Growthgrids' : (TenderDetails[0].source_id == '4') ? 'Tender247' : ''

            result.push({ 'TenderDetails': TenderDetails })
            const response = await TenderMovedHistroyByUserModel.findAll(
                {
                    where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '1' },
                    attributes: ['tender_id', 'from_cycle_id', 'to_cycle_id', 'created_at'],
                    order: [['created_at', 'ASC']],
                    include: [{
                        model: Tenderscope,
                        attributes: ['id', 'cycle_name', 'order_sr'],
                        as: 'from_cycle',
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: Tenderscope,
                        attributes: ['id', 'cycle_name', 'order_sr'],
                        as: 'to_cycle',
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: User,
                        attributes: ['id', 'userfullname'],
                        as: 'created_by_user',
                        where: { isactive: '1' },
                        required: false,
                    },
                    ]
                }
            );
            result.push({ 'cyclehistory': response })


            const merge_array = [...TenderDetails, ...response]
            //console.log(result)
            //  console.log('hoisidhfo')

            console.log(response)
            if (merge_array[0]) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: merge_array,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',

                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}



const tndrassignconsortium = async (req, res) => {

    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        // consortium_comp_id: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        user_comp_id: Joi.number().required(),
    });
    const dataToValidate = {
        tender_id: req.body.tender_id,
        // consortium_comp_id: req.body.consortium_comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
        user_comp_id: req.comp_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            if (req.body.consortium_comp_id) {
                const lead_comp_id = req.body.consortium_comp_id.split(',');
                const lead_upd = await Tenderpartners.update({
                    updated_by: req.userId,
                    updated_at: getCurrentDateTime(),
                    status: '0'
                }, {
                    where: {
                        status: '1', project_id: req.body.tender_id,
                        user_comp_id: req.comp_id,
                    },
                });
                const response_partners = await Promise.all(lead_comp_id.map(async (data) => {
                    const lead_upd = await Tenderpartners.create(
                        {
                            user_comp_id: req.comp_id,
                            project_id: req.body.tender_id,
                            lead_comp_ids: data,
                            created_at: getCurrentDateTime(),
                            created_by: req.userId,
                        }
                    );
                }));
                if (lead_upd) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } else {
                const lead_upd = await Tenderpartners.create(
                    {
                        user_comp_id: req.comp_id,
                        project_id: req.body.tender_id,
                        created_at: getCurrentDateTime(),
                        created_by: req.userId,
                    }
                );

                if (lead_upd) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

const tndrmovenextscope = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        user_comp_id: Joi.number().required(),
    });
    const dataToValidate = {
        tender_id: req.body.tender_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
        user_comp_id: req.comp_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const TenderMovedHistroyByUserModel = createTenderMoveHistory(req.comp_id);
            await TenderMovedHistroyByUserModel.performOperation();
            const current_scope = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                }, attributes: ['cycle_id']
            });
            const check_scope_current = await Tenderscope.findOne({
                order: [['order_sr', 'ASC']],
                where: {
                    // order_sr: {
                    //     [Sequelize.Op.gt]: check_scope_sr.order_sr,
                    // },
                    user_comp_id: req.comp_id,
                    id: current_scope.cycle_id,
                    status: '1',
                    category: '1'
                },
                attributes: ['id', 'order_sr']
            });
            if (check_scope_current.order_sr == 8) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'This Tender Is Already On This Scope',
                    error: true,
                    success: false,
                    status: '0',
                });

            }
            if (current_scope) {
                const current_scope_1 = await TenderModel.findOne({
                    where: {
                        user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1'
                    }, attributes: ['cycle_id']
                });

                const check_scope_sr_1 = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']], where: { user_comp_id: req.comp_id, id: current_scope_1.cycle_id, status: '1' }, attributes: ['id', 'cycle_name', 'order_sr']
                })

                const check_next_scope_1 = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']],
                    where: {
                        order_sr: {
                            [Sequelize.Op.gt]: check_scope_sr_1.order_sr,
                        },
                        user_comp_id: req.comp_id,
                        status: '1',
                        category: '1'
                    },
                    attributes: ['id', 'order_sr']
                })

                const check_scope_cr = await Tenderscope.findOne({
                    order: [['order_sr', 'ASC']],
                    where: {
                        // order_sr: {
                        //     [Sequelize.Op.gt]: check_scope_sr.order_sr,
                        // },
                        user_comp_id: req.comp_id,
                        id: check_next_scope_1.id,
                        status: '1',
                        category: '1'
                    },
                    attributes: ['id', 'order_sr']
                });
                if (check_next_scope_1.order_sr < 7) {
                    if (check_next_scope_1.order_sr == 2) {
                        const current_scope_2 = await TenderModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                            }, attributes: ['cycle_id']
                        });
                        const check_scope_sr_2 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: { user_comp_id: req.comp_id, id: current_scope_2.cycle_id, status: '1' },
                            attributes: ['id', 'cycle_name', 'order_sr']
                        })
                        const check_next_scope_2 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: {
                                order_sr: {
                                    [Sequelize.Op.gt]: check_scope_sr_2.order_sr,
                                },
                                user_comp_id: req.comp_id,
                                status: '1',
                                category: '1'
                            },
                            attributes: ['id', 'order_sr', 'cycle_name']
                        })
                        const cycle_update_obj = {
                            cycle_id: check_next_scope_2.id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                            where: { id: dataToValidate.tender_id, user_comp_id: req.comp_id, status: '1' },
                        })
                        const tndr_cycle_move_history_insert = {
                            tender_id: dataToValidate.tender_id,
                            from_cycle_id: current_scope_2.cycle_id,
                            to_cycle_id: check_next_scope_2.id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                            scope_move_type: 'move'
                        };
                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                        if (check_scope_cr.order_sr == 2) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: `Tender Move Into ${check_next_scope_2?.cycle_name} Successfully Done`,
                                scope_name: check_next_scope_2?.cycle_name,
                                error: false,
                                success: true,
                                status: '1',
                            });
                        }
                    } else if (check_next_scope_1.order_sr == 3) {
                        const current_scope_3 = await TenderModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                            }, attributes: ['cycle_id']
                        });
                        const check_scope_sr_3 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: { user_comp_id: req.comp_id, id: current_scope_3.cycle_id, status: '1' },
                            attributes: ['id', 'cycle_name', 'order_sr']
                        })
                        const check_next_scope_3 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: {
                                order_sr: {
                                    [Sequelize.Op.gt]: check_scope_sr_3.order_sr,
                                },
                                user_comp_id: req.comp_id,
                                // id: current_scope.cycle_id,
                                status: '1',
                                category: '1'
                            },
                            attributes: ['id', 'order_sr', 'cycle_name']
                        })
                        const cycle_update_obj = {
                            cycle_id: check_next_scope_3.id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                            where: { id: dataToValidate.tender_id, user_comp_id: req.comp_id, status: '1' },
                        })
                        const tndr_cycle_move_history_insert = {
                            tender_id: dataToValidate.tender_id,
                            from_cycle_id: current_scope_3.cycle_id,
                            to_cycle_id: check_next_scope_3.id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                            scope_move_type: 'move'
                        };
                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                        if (check_scope_cr.order_sr == 3) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: `Tender Move Into ${check_next_scope_3?.cycle_name} Successfully Done`,
                                scope_name: check_next_scope_3?.cycle_name,
                                error: false,
                                success: true,
                                status: '1',

                            });
                        }
                    } else if (check_next_scope_1.order_sr == 4) {
                        const current_scope_4 = await TenderModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                            }, attributes: ['cycle_id']
                        });
                        const check_scope_sr_4 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: { user_comp_id: req.comp_id, id: current_scope_4.cycle_id, status: '1' },
                            attributes: ['id', 'cycle_name', 'order_sr']
                        })
                        const check_next_scope_4 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: {
                                order_sr: {
                                    [Sequelize.Op.gt]: check_scope_sr_4.order_sr,
                                },
                                user_comp_id: req.comp_id,
                                // id: current_scope.cycle_id,
                                status: '1',
                                category: '1'
                            },
                            attributes: ['id', 'order_sr', 'cycle_name']
                        })
                        const cycle_update_obj = {
                            cycle_id: check_next_scope_4.id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                            where: { id: dataToValidate.tender_id, user_comp_id: req.comp_id, status: '1' },
                        })
                        const tndr_cycle_move_history_insert = {
                            tender_id: dataToValidate.tender_id,
                            from_cycle_id: current_scope_4.cycle_id,
                            to_cycle_id: check_next_scope_4.id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                            scope_move_type: 'move'
                        };
                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                        if (check_scope_cr.order_sr == 4) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: `Tender Move Into ${check_next_scope_4?.cycle_name} Successfully Done`,
                                scope_name: check_next_scope_4?.cycle_name,
                                error: false,
                                success: true,
                                status: '1',
                            });
                        }
                    } else if (check_next_scope_1.order_sr == 5) {
                        const current_scope_5 = await TenderModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                            }, attributes: ['cycle_id']
                        });
                        const check_scope_sr_5 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: { user_comp_id: req.comp_id, id: current_scope_1.cycle_id, status: '1' },
                            attributes: ['id', 'cycle_name', 'order_sr']
                        })
                        const check_next_scope_5 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: {
                                order_sr: {
                                    [Sequelize.Op.gt]: check_scope_sr_5.order_sr,
                                },
                                user_comp_id: req.comp_id,
                                // id: current_scope.cycle_id,
                                status: '1',
                                category: '1'
                            },
                            attributes: ['id', 'order_sr', 'cycle_name']
                        })
                        const cycle_update_obj = {
                            cycle_id: check_next_scope_5.id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                            where: { id: dataToValidate.tender_id, user_comp_id: req.comp_id, status: '1' },
                        })
                        const tndr_cycle_move_history_insert = {
                            tender_id: dataToValidate.tender_id,
                            from_cycle_id: current_scope_5.cycle_id,
                            to_cycle_id: check_next_scope_5.id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                            scope_move_type: 'move'
                        };
                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                        if (check_scope_cr.order_sr == 5) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: `Tender Move Into ${check_next_scope_5?.cycle_name} Successfully Done`,
                                scope_name: check_next_scope_5?.cycle_name,
                                error: false,
                                success: true,
                                status: '1',
                                // data: i,
                            });
                        }
                    } else if (check_next_scope_1.order_sr == 6) {
                        const current_scope_6 = await TenderModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                // cycle_id: dataToValidate.cycle_id,
                            }, attributes: ['cycle_id']
                        });
                        const check_scope_6 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: { user_comp_id: req.comp_id, id: current_scope_6.cycle_id, status: '1' },
                            attributes: ['id', 'cycle_name', 'order_sr']
                        })
                        // console.log(current_scope.cycle_id, 'ss')
                        const check_next_scope_6 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: {
                                order_sr: {
                                    [Sequelize.Op.gt]: check_scope_6.order_sr,
                                },
                                user_comp_id: req.comp_id,
                                // id: current_scope.cycle_id,
                                status: '1',
                                category: '1'
                            },
                            attributes: ['id', 'order_sr', 'cycle_name']
                        })
                        const cycle_update_obj = {
                            cycle_id: check_next_scope_6.id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                            where: { id: req.body.tender_id, user_comp_id: req.comp_id },
                        })
                        const tndr_cycle_move_history_insert = {
                            tender_id: req.body.tender_id,
                            from_cycle_id: current_scope_6.cycle_id,
                            to_cycle_id: check_next_scope_6.id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                            scope_move_type: 'move'
                        };
                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                        if (check_scope_cr.order_sr == 6) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: `Tender Move Into ${check_next_scope_6?.cycle_name} Successfully Done`,
                                scope_name: check_next_scope_6?.cycle_name,
                                error: false,
                                success: true,
                                status: '1',

                            });
                        }

                    }

                } else {
                    if (check_next_scope_1.order_sr == 7) {
                        const tenergenerated_id = await TenderGeneratedTypeIdModel.findOne({
                            where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' },
                            attributes: ['id']
                        })
                        const tenerkey_manager = await TenderAssignManagerModel.findOne({
                            where: { bd_role_id: 1, tender_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' },
                            attributes: ['id']
                        })
                        const tenerbid_manager = await TenderAssignManagerModel.findOne({
                            where: { bd_role_id: 2, tender_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' },
                            attributes: ['id']
                        })

                        const tener_consortium = await Tenderpartners.findOne({
                            where: {
                                //[Op.and]: [
                                   // { 
                                        project_id: req.body.tender_id, 
                                        user_comp_id: req.comp_id, 
                                        status: '1', 
                                        type_data:'1', 
                                        //consortium_skip:null 
                                  // },
                                    //{ 
                                        consortium_skip: {
                                            [Op.is]: null
                                        }
                                   // }
                              //  ],
                            },
                            attributes: ['id']
                        })
                        if (!tenergenerated_id) {
                            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                message: 'Set Tender ID',
                                error: true,
                                success: false,
                                status: '0',
                                stage: 5
                            });
                        } else if (!tenerkey_manager) {
                            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                message: 'Set Tender Key Manager',
                                error: true,
                                success: false,
                                status: '0',
                                stage: 6
                            });
                        } else if (!tenerbid_manager) {
                            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                message: 'Set Tender Bid Manager',
                                error: true,
                                success: false,
                                status: '0',
                                stage: 7
                            });

                        } else if (!tener_consortium) {
                            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                message: 'Set Tender Consortium',
                                error: true,
                                success: false,
                                status: '0',
                                stage: 11
                            });
                        } else {
                            const current_scope_7 = await TenderModel.findOne({
                                where: {
                                    user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                    // cycle_id: dataToValidate.cycle_id,
                                }, attributes: ['cycle_id']
                            });
                            const check_scope_7 = await Tenderscope.findOne({
                                order: [['order_sr', 'ASC']],
                                where: { user_comp_id: req.comp_id, id: current_scope_7.cycle_id, status: '1' },
                                attributes: ['id', 'cycle_name', 'order_sr']
                            })
                            // console.log(current_scope.cycle_id, 'ss')
                            const check_next_scope_7 = await Tenderscope.findOne({
                                order: [['order_sr', 'ASC']],
                                where: {
                                    order_sr: {
                                        [Sequelize.Op.gt]: check_scope_7.order_sr,
                                    },
                                    user_comp_id: req.comp_id,
                                    // id: current_scope.cycle_id,
                                    status: '1',
                                    category: '1'
                                },
                                attributes: ['id', 'order_sr', 'cycle_name']
                            })
                            const cycle_update_obj = {
                                cycle_id: check_next_scope_7.id,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                                where: { id: req.body.tender_id, user_comp_id: req.comp_id },
                            })
                            const tndr_cycle_move_history_insert = {
                                tender_id: req.body.tender_id,
                                from_cycle_id: current_scope_7.cycle_id,
                                to_cycle_id: check_next_scope_7.id,
                                user_comp_id: req.comp_id,
                                created_by: req.userId,
                                created_at: getCurrentDateTime(),
                                scope_move_type: 'move'
                            };
                            await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                            if (check_scope_cr.order_sr == 7) {
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: `Tender Move Into ${check_next_scope_7?.cycle_name} Successfully Done`,
                                    scope_name: check_next_scope_7?.cycle_name,
                                    error: false,
                                    success: true,
                                    status: '1',

                                });
                            }
                        }
                    } else if (check_next_scope_1.order_sr == 8) {
                        const current_scope_8 = await TenderModel.findOne({
                            where: {
                                user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                                // cycle_id: dataToValidate.cycle_id,
                            }, attributes: ['cycle_id']
                        });
                        const check_scope_8 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: { user_comp_id: req.comp_id, id: current_scope_8.cycle_id, status: '1' },
                            attributes: ['id', 'cycle_name', 'order_sr']
                        })
                        const check_awaiting_status = await TenderStatus.findOne({
                            order: [['id', 'ASC']],
                            where: { user_comp_id: req.comp_id, status: '1' },
                            attributes: ['id']
                        })


                        // console.log(current_scope.cycle_id, 'ss')
                        const check_next_scope_8 = await Tenderscope.findOne({
                            order: [['order_sr', 'ASC']],
                            where: {
                                order_sr: {
                                    [Sequelize.Op.gt]: check_scope_8.order_sr,
                                },
                                user_comp_id: req.comp_id,
                                // id: current_scope.cycle_id,
                                status: '1',
                                category: '1'
                            },
                            attributes: ['id', 'order_sr', 'cycle_name']
                        })
                        const cycle_update_obj = {
                            cycle_id: check_next_scope_8.id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_cycle_update = await TenderModel.update(cycle_update_obj, {
                            where: { id: req.body.tender_id, user_comp_id: req.comp_id },
                        })
                        const tndr_cycle_move_history_insert = {
                            tender_id: req.body.tender_id,
                            from_cycle_id: current_scope_8.cycle_id,
                            to_cycle_id: check_next_scope_8.id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                            scope_move_type: 'move'
                        };
                        await TenderMovedHistroyByUserModel.create(tndr_cycle_move_history_insert);
                        const tndr_cycle_awaiting_insert = {
                            project_id: req.body.tender_id,
                            tender_status: check_awaiting_status.id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        };
                        await Tenderstatusmanage.create(tndr_cycle_awaiting_insert);
                        if (check_scope_cr.order_sr == 8) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: `Tender Move Into ${check_next_scope_8?.cycle_name} Successfully Done`,
                                scope_name: check_next_scope_8?.cycle_name,
                                error: false,
                                success: true,
                                status: '1',
                                // data: i,
                            });
                        }
                    }

                }

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}

const listassignbtn = async (req, res) => {
    try {
        const response = await TenderCycleAssignInactionModel.findAll({
            where: { user_comp_id: req.comp_id, status: '1' },
            attributes: ['id', 'inaction_id', 'cycle_id'],
            // order: [['inaction_id', 'ASC']],
            // group: ['inaction_id'],
            include: [{
                model: TenderCycleInactionModel,
                attributes: ['id', 'inaction_name', 'image_name'],
                where: { status: '1' },
                required: false,
            },
            ]
        });
        if (response[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,
            });

        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',

            });

        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const cyclelistnextAll = async (req, res) => {
    try {
        const response = await Tenderscope.findOne({
            order: [['order_sr', 'desc']],
            where: {
                [Op.and]: [
                    { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                    // Include the dynamic filters
                ],
            },
            attributes: ['id', 'cycle_name', 'order_sr']

        })
        const response_2 = await Tenderscope.findOne({
            order: [['order_sr', 'ASC']],
            where: {
                [Op.and]: [
                    { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                    // Include the dynamic filters
                ],
            },
            attributes: ['id', 'cycle_name', 'order_sr']

        })
        // res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
        //     message: process.env.APIRESPMSG_RECFOUND,
        //     error: false,
        //     success: true,
        //     status: '1',
        //     data: response,
        // });
        const datastore = [];
        for (let i = 1; i < 8; i++) {

            const response_0 = await Tenderscope.findAll({
                order: [['order_sr', 'ASC']],
                where: {
                    [Op.and]: [
                        { status: '1' },
                        { user_comp_id: req.comp_id },
                        { order_sr: { [Op.eq]: i } } // Greater than comparison
                        // You can add additional filters here
                    ]
                },
                attributes: ['id', 'cycle_name', 'order_sr']
            })
            const response_3 = await Tenderscope.findAll({
                order: [['order_sr', 'ASC']],
                where: {
                    [Op.and]: [
                        { status: '1' },
                        { user_comp_id: req.comp_id },
                        { order_sr: { [Op.gt]: i } } // Greater than comparison
                        // You can add additional filters here
                    ]
                },
                attributes: ['id', 'cycle_name', 'order_sr']
            })
            if (response_3) {
                const newData = { [response_0[0]?.id]: response_3 };
                datastore.push(newData)
            }

        }

        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: datastore,
        });
        // if (datastore[0]) {
        //     res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
        //         message: process.env.APIRESPMSG_RECFOUND,
        //         error: false,
        //         success: true,
        //         status: '1',
        //         data: datastore,
        //     });
        // } else {
        //     return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
        //         message: process.env.APIRESPMSG_RECNOTFOUND,
        //         error: true,
        //         success: false,
        //         status: '0',
        //     });
        // }


        // if (response[0]) {
        //     res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
        //         message: process.env.APIRESPMSG_RECFOUND,
        //         error: false,
        //         success: true,
        //         status: '1',
        //         data: response,
        //     });
        // } else {
        //     return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
        //         message: process.env.APIRESPMSG_RECNOTFOUND,
        //         error: true,
        //         success: false,
        //         status: '0',
        //     });
        // }

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: error.message,
            // message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        })
    }

}


const tendercyclelAll = async (req, res) => {
    try {
        const response = await Tenderscope.findAll({
            order: [['order_sr', 'ASC']],
            where: {
                [Op.and]: [
                    { status: '1', user_comp_id: req.comp_id },

                ],
            },
            attributes: ['id', 'cycle_name', 'order_sr']

        })
        if (response[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,
            });
        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        })
    }

}
module.exports = {
    cyclelistnext, addtndrcyclejumpmultipledbtn, addtndrcyclejumpsingledbtn, tndrassignconsortium, tndrmovenextscope,
    addtndrcycletrashsingledbtn, tendercycleinactionlist, tenderinactionbtnupdate, tendercycletrackhistory,
    listassignbtn, cyclelistnextAll, tendercyclelAll
}