const { Sequelize, DataTypes, Op, literal } = require('sequelize');
const jwt = require('jsonwebtoken');
const Joi = require('joi');
require('dotenv').config();
const ProjectTodo = require('../../models/todo/Projecttodo');
const ProjectHashtag = require('../../models/todo/ProjectHastag');
const ProjectAssigntaskModel = require('../../models/todo/ProjectAssignedtask');
const ProjectTodoCommentModel = require('../../models/todo/ProjectTodoCommentModel');
const ProjectTodoCommentDocuments = require('../../models/todo/ProjectTodoCommentDocuments');
// const ToDoTaskMoveHistoryModel = require('../../models/todo/ToDoTaskMoveHistoryModel');
const Users = require('../../models/Users');
const currentDate = new Date();
const getCurrentDateTime = () => new Date();
// const Assignedtaskserialnumber = require('../../models/todo/Assigntaskserialnumber')
// const max = 10;
// const min = 1;
// const moment = require('moment-timezone');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const datetime = new Date();



//To Do Add ...
const project_todo_create_task = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        project_id: req.body.project_id,
        task_type: req.body.task_type,
        task_name: req.body.task_name,
        task_priority: req.body.task_priority,
        hash_tags: req.body.hash_tags,
        current_scope: req.body.current_scope,
        assign_type: req.body.assign_type,
        user_creater_id: req.userId,
        task_description: req.body.task_description,
        created_by: req.userId,
        created_at: currentDate,
        // updated_at: currentDate,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        project_id: Joi.number().required(),
        task_type: Joi.number().required(),
        task_name: Joi.string().required(),
        task_priority: Joi.string().required(),
        hash_tags: Joi.string().required(),
        current_scope: Joi.number().required(),
        assign_type: Joi.number().required(),
        user_creater_id: Joi.number().required(),
        task_description: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        // updated_at: Joi.date().iso().required()

    });

    console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const RecdExistCheck = await ProjectTodo.findOne({ where: { user_comp_id: req.comp_id, project_id: req.body.project_id, task_name: req.body.task_name, status: 1 }, attributes: ['id'] });
            if (RecdExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {

                if ((req.body.project_id) && (req.body.task_type == 2)) {
                    dataToValidate['project_id'] = req.body.project_id;
                }
                if (req.body.deadline_date) {
                    dataToValidate['deadline_date'] = req.body.deadline_date;
                }

                const Inserted_ID = await ProjectTodo.create(dataToValidate);

                if (Inserted_ID) {
                    const existingRecords = [];
                    const recordsToCreate = [];

                    //####################################################
                    //############### Start Hastags Code #######################
                    //####################################################
                    if (dataToValidate.hash_tags) {
                        const delimiter = ',';
                        const response_data = dataToValidate.hash_tags.split(delimiter);

                        for (const tagsdata of response_data) {
                            const existingRecord = await ProjectHashtag.findOne({ where: { user_comp_id: req.comp_id, hashtag_name: tagsdata } });
                            if (existingRecord) {
                                existingRecords.push(existingRecord);
                            } else {
                                recordsToCreate.push(
                                    {
                                        user_comp_id: req.comp_id,
                                        hashtag_name: tagsdata,
                                        created_by: req.userId,
                                        created_at: currentDate

                                    });
                            }
                        }

                        if (recordsToCreate.length > 0) {
                            const RecordsInserted = await ProjectHashtag.bulkCreate(recordsToCreate);
                        }
                    }
                    //####################################################
                    //############### Close Hastags Code #######################
                    //####################################################



                    //################################################################
                    //################## Start Code Assigned Task To EMP  #####################
                    //################################################################
                    if (dataToValidate.assign_type == "2") {
                        const existingRecords_2 = [];
                        const recordsToCreate_2 = [];

                        if (req.body.assigned_to_users) {
                            const AssignedUsers = req.body.assigned_to_users + ',' + req.userId;
                            const delimiter_2 = ',';
                            const response_data_2 = AssignedUsers.split(delimiter_2);
                            for (const empl_id of response_data_2) {
                                const existingRecd = await ProjectAssigntaskModel.findOne({ where: { user_comp_id: req.comp_id, task_id: Inserted_ID.id, assigned_to_userid: empl_id, status: '1' } });
                                if (existingRecd) {
                                    existingRecords_2.push(existingRecd);
                                } else {
                                    recordsToCreate_2.push({
                                        user_comp_id: req.comp_id,
                                        task_id: Inserted_ID.id,
                                        project_id: req.body.project_id,
                                        assigned_to_userid: empl_id,
                                        assign_type: Inserted_ID.assign_type,
                                        created_by: req.userId,
                                        created_at: currentDate,
                                    });
                                }
                            }

                            if (recordsToCreate_2.length > 0) {
                                const RecdInsert = await ProjectAssigntaskModel.bulkCreate(recordsToCreate_2);
                            }
                        }
                    }


                    if (dataToValidate.assign_type == "1") {
                        const recordsToCreate_3 = {
                            user_comp_id: req.comp_id,
                            task_id: Inserted_ID.id,
                            project_id: req.body.project_id,
                            assigned_to_userid: req.userId,
                            assign_type: Inserted_ID.assign_type,
                            created_by: req.userId,
                            created_at: currentDate
                        }

                        if (recordsToCreate_3) {
                            const RecdInsert = await ProjectAssigntaskModel.create(recordsToCreate_3);
                        }

                    }

                    //################################################################
                    //################## Close Code Assigned Task To EMP  ##################
                    //################################################################
                }

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: Inserted_ID
                });

            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};

// //To Do Edit ...
const project_todo_edit_task = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        task_id: req.body.task_id,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        task_id: Joi.number().required(),
    });

    // console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const dataexist = await ProjectAssigntaskModel.findOne({
                where: { user_comp_id: req.comp_id, task_id: req.body.task_id, assigned_to_userid: req.userId, status: 1 }
            });
            if (!dataexist) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'You have Not Permission To Edit',
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            const RecdExistCheck = await ProjectTodo.findAll({
                where: { user_comp_id: req.comp_id, id: req.body.task_id, status: 1 },
                include: [{
                    model: ProjectAssigntaskModel,
                    attributes: ['id', 'assigned_to_userid', 'assign_type'],
                    as: 'assigned_users',
                    where: { status: '1' },
                    required: false,
                }],
            });
            if (!RecdExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPCODE_RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: RecdExistCheck
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};
// //To Do Update ...
const project_todo_update_task = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        task_id: req.body.task_id,
        project_id: req.body.project_id,
        task_type: req.body.task_type,
        task_name: req.body.task_name,
        task_priority: req.body.task_priority,
        hash_tags: req.body.hash_tags,
        current_scope: req.body.current_scope,
        assign_type: req.body.assign_type,
        user_creater_id: req.userId,
        task_description: req.body.task_description,
        created_by: req.userId,
        created_at: currentDate,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        task_id: Joi.number().required(),
        project_id: Joi.number().required(),
        task_type: Joi.number().required(),
        task_name: Joi.string().required(),
        task_priority: Joi.string().required(),
        hash_tags: Joi.string().required(),
        current_scope: Joi.number().required(),
        assign_type: Joi.number().required(),
        user_creater_id: Joi.number().required(),
        task_description: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const dataexist = await ProjectAssigntaskModel.findOne({
                where: { user_comp_id: req.comp_id, task_id: req.body.task_id, assigned_to_userid: req.userId, status: 1 }
            });
            if (!dataexist) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'You have Not Permission To Update',
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            const RecdExistCheck = await ProjectTodo.findOne({ where: { user_comp_id: req.comp_id, id: req.body.task_id, status: 1 }, attributes: ['id', 'user_creater_id'] });
            //code modified by abhimanyu 2-2-2024 start 
            const RecdExistCheck_task = await ProjectTodo.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    task_name: req.body.task_name,
                    status: 1,
                    id: {
                        [Op.ne]: req.body.task_id
                    },
                }, attributes: ['id']
            });
            if (RecdExistCheck_task) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            //code modified by abhimanyu 2-2-2024 end 
            if (!RecdExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {

                const UpdateDataArr = {
                    task_type: req.body.task_type,
                    task_name: req.body.task_name,
                    task_priority: req.body.task_priority,
                    hash_tags: req.body.hash_tags,
                    current_scope: req.body.current_scope,
                    assign_type: req.body.assign_type,
                    task_description: req.body.task_description,
                    updated_at: currentDate,
                    modified_by: req.userId,
                }

                if ((req.body.project_id) && (req.body.task_type == 2)) {
                    UpdateDataArr['project_id'] = req.body.project_id;
                }
                if (req.body.deadline_date) {
                    UpdateDataArr['deadline_date'] = req.body.deadline_date;
                }

                const UpdatedID = await ProjectTodo.update(UpdateDataArr, {
                    where: { user_comp_id: req.comp_id, id: req.body.task_id, status: 1 }
                });


                if (UpdatedID) {
                    const existingRecords = [];
                    const recordsToCreate = [];
                    //####################################################
                    //############### Start Hastags Code #######################
                    //####################################################
                    if (dataToValidate.hash_tags) {
                        const delimiter = ',';
                        const response_data = dataToValidate.hash_tags.split(delimiter);
                        for (const tagsdata of response_data) {
                            const existingRecord = await ProjectHashtag.findOne({ where: { user_comp_id: req.comp_id, hashtag_name: tagsdata } });
                            if (existingRecord) {
                                existingRecords.push(existingRecord);
                            } else {
                                recordsToCreate.push({
                                    user_comp_id: req.comp_id,
                                    hashtag_name: tagsdata,
                                    created_by: req.userId,
                                    created_at: currentDate
                                });
                            }
                        }
                        if (recordsToCreate.length > 0) {
                            const RecordsInserted = await ProjectHashtag.bulkCreate(recordsToCreate);
                        }
                    }

                    //##########################################################
                    //############### Close Hastags Code #######################
                    //##########################################################

                    //################  Remove All Previous Users ###################
                    //###############################################################
                    if (RecdExistCheck.user_creater_id === req.userId) {
                        const UpdateStatusArr = {
                            status: "0"
                        }
                        const UpdID = await ProjectAssigntaskModel.update(UpdateStatusArr, {
                            where: { user_comp_id: req.comp_id, task_id: req.body.task_id, status: 1 }
                        });
                        //#################################################################
                        //#################################################################
                        //################################################################
                        //################## Start Code Assigned Task To EMP  ############
                        //################################################################
                        if (dataToValidate.assign_type == "2") {
                            const existingRecords_2 = [];
                            const recordsToCreate_2 = [];

                            if (req.body.assigned_to_users) {
                                // req.body.assigned_to_users + ',' + req.userId;
                                const AssignedUsers = req.body.assigned_to_users + ',' + req.userId;
                                const delimiter_2 = ',';
                                const response_data_2 = AssignedUsers.split(delimiter_2);
                                for (const empl_id of response_data_2) {
                                    const existingRecd = await ProjectAssigntaskModel.findOne({ where: { user_comp_id: req.comp_id, task_id: req.body.task_id, assigned_to_userid: empl_id, status: '1' } });
                                    if (existingRecd) {
                                        existingRecords_2.push(existingRecd);
                                    } else {
                                        recordsToCreate_2.push({
                                            user_comp_id: req.comp_id,
                                            task_id: req.body.task_id,
                                            project_id: req.body.project_id,
                                            assigned_to_userid: empl_id,
                                            assign_type: req.body.assign_type,
                                            created_by: req.userId,
                                            created_at: currentDate,
                                        });
                                    }
                                }

                                if (recordsToCreate_2.length > 0) {
                                    const RecdInsert = await ProjectAssigntaskModel.bulkCreate(recordsToCreate_2);
                                }
                            }
                        }

                        if (dataToValidate.assign_type == "1") {
                            const recordsToCreate_3 = {
                                user_comp_id: req.comp_id,
                                task_id: req.body.task_id,
                                project_id: req.body.project_id,
                                assigned_to_userid: req.userId,
                                assign_type: req.body.assign_type,
                                created_by: req.userId,
                                created_at: currentDate
                            }
                            if (recordsToCreate_3) {
                                const RecdInsert = await ProjectAssigntaskModel.create(recordsToCreate_3);
                            }
                        }
                    }
                    //################################################################
                    //############## Close Code Assigned Task To EMP  ################
                    //################################################################
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: UpdateDataArr
                    });
                }
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};
const project_list_todo_scope_mytask = async (req, res) => {

    const dataToValidate = {
        project_id: req.body.project_id,
    };

    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            //  const dataLisT = await Assignedtaskserialnumber.findOne({ where: { user_comp_id: req.comp_id, scope_id: '1', assign_by: req.userId, status: '1' } })
            const dataLisT = 0;
            if (!dataLisT) {
                const response_1 = await ProjectTodo.findAll({
                    where: { status: '1', current_scope: '1', user_comp_id: req.comp_id, project_id: req.body.project_id },
                    order: [['id', 'DESC']],
                    include: [{
                        model: ProjectAssigntaskModel,
                        attributes: ['id', 'assigned_to_userid', 'assign_type'],
                        as: 'assigned_users',
                        where: { status: '1', user_comp_id: req.comp_id },
                        required: true,
                    },],
                });
                const tasksWithCount = await Promise.all(response_1.map(async (task) => {
                    const assign_user = await ProjectAssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_comment = await ProjectTodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_list = await ProjectAssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assignedUsersCount = assign_user - 1;
                    const taskcommentCount = assign_user_comment;
                    return {
                        ...task.toJSON(),
                        assignedUsersCount,
                        taskcommentCount,
                        assign_user_list
                    };
                }));
                if (!response_1[0]) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        error: true,
                        success: false,
                        status: '0',
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tasksWithCount,
                });

            } else {
                const response_2 = await TodoModel.findAll({
                    where: { status: '1', current_scope: '1' },
                    // order: [['updated_at', 'DESC']],
                    include: [{
                        model: Assignedtaskserialnumber,
                        order: [['sr_no', 'ASC']],
                        attributes: ['id', 'assigned_to_userid', 'assign_type', 'sr_no'],
                        as: 'assigned_users1',
                        where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                        required: true,
                    }],
                });
                const tasksWithCount = await Promise.all(response_2.map(async (task) => {
                    const assign_user = await ProjectAssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_comment = await ProjectTodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assignedUsersCount = assign_user - 1;
                    const taskcommentCount = assign_user_comment;
                    return {
                        ...task.toJSON(),
                        assignedUsersCount,
                        taskcommentCount
                    };
                }));
                if (!response_2[0]) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        error: true,
                        success: false,
                        status: '0',
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tasksWithCount,
                });
            }



        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }

    }
}
const project_list_todo_inporgress_mytask = async (req, res) => {
    const dataToValidate = {
        project_id: req.body.project_id,
    };

    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {
            //   const dataLisT = await Assignedtaskserialnumber.findOne({ where: { user_comp_id: req.comp_id, scope_id: '2', assign_by: req.userId, status: '1' } })
            const dataLisT = 0;
            if (!dataLisT) {
                const response_1 = await ProjectTodo.findAll({
                    where: { status: '1', current_scope: '2', user_comp_id: req.comp_id, project_id: req.body.project_id },
                    order: [['id', 'DESC']],
                    include: [{
                        model: ProjectAssigntaskModel,
                        attributes: ['id', 'assigned_to_userid', 'assign_type'],
                        as: 'assigned_users',
                        where: { status: '1', user_comp_id: req.comp_id },
                        required: true,
                    },],
                });

                const tasksWithCount = await Promise.all(response_1.map(async (task) => {
                    const assign_user = await ProjectAssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_comment = await ProjectTodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_list = await ProjectAssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assignedUsersCount = assign_user - 1;
                    const taskcommentCount = assign_user_comment;
                    return {
                        ...task.toJSON(),
                        assignedUsersCount,
                        taskcommentCount,
                        assign_user_list
                    };
                }));
                if (!response_1[0]) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        error: true,
                        success: false,
                        status: '0',
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tasksWithCount,
                });

            } else {
                const response_2 = await TodoModel.findAll({
                    where: { status: '1', current_scope: '2' },
                    // order: [['updated_at', 'DESC']],
                    include: [{
                        model: Assignedtaskserialnumber,
                        order: [['sr_no', 'ASC']],
                        attributes: ['id', 'assigned_to_userid', 'assign_type', 'sr_no'],
                        as: 'assigned_users1',
                        where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                        required: true,
                    }],
                });
                const tasksWithCount = await Promise.all(response_2.map(async (task) => {
                    const assign_user = await AssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_comment = await TodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_list = await AssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assignedUsersCount = assign_user - 1;
                    const taskcommentCount = assign_user_comment;
                    return {
                        ...task.toJSON(),
                        assignedUsersCount,
                        taskcommentCount,
                        assign_user_list
                    };
                }));
                if (!response_2[0]) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        error: true,
                        success: false,
                        status: '0',
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tasksWithCount,
                });
            }



        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }

    }
}
const project_list_todo_done_mytask = async (req, res) => {
    const dataToValidate = {
        project_id: req.body.project_id,
    };

    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            //const dataLisT = await Assignedtaskserialnumber.findOne({ where: { user_comp_id: req.comp_id, scope_id: '3', assign_by: req.userId, status: '1' } })
            const dataLisT = 0;
            if (!dataLisT) {
                const response_1 = await ProjectTodo.findAll({
                    where: { status: '1', current_scope: '3', user_comp_id: req.comp_id, project_id: req.body.project_id },
                    order: [['id', 'DESC']],
                    include: [{
                        model: ProjectAssigntaskModel,
                        attributes: ['id', 'assigned_to_userid', 'assign_type'],
                        as: 'assigned_users',
                        where: { status: '1', user_comp_id: req.comp_id },
                        required: true,
                    },],
                });

                const tasksWithCount = await Promise.all(response_1.map(async (task) => {
                    const assign_user = await ProjectAssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_comment = await ProjectTodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_list = await ProjectAssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });

                    const assignedUsersCount = assign_user - 1;
                    const taskcommentCount = assign_user_comment;
                    return {
                        ...task.toJSON(),
                        assignedUsersCount,
                        taskcommentCount,
                        assign_user_list
                    };
                }));
                if (!response_1[0]) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        error: true,
                        success: false,
                        status: '0',
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tasksWithCount,
                });

            } else {
                const response_2 = await TodoModel.findAll({
                    where: { status: '1', current_scope: '3' },
                    // order: [['id', 'DESC']],
                    include: [{
                        model: Assignedtaskserialnumber,
                        order: [['sr_no', 'ASC']],
                        attributes: ['id', 'assigned_to_userid', 'assign_type', 'sr_no'],
                        as: 'assigned_users1',
                        where: { status: '1', user_comp_id: req.comp_id, assigned_to_userid: req.userId },
                        required: true,
                    }],
                });
                const tasksWithCount = await Promise.all(response_2.map(async (task) => {
                    const assign_user = await AssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assign_user_comment = await TodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
                    const assignedUsersCount = assign_user - 1;
                    const taskcommentCount = assign_user_comment;
                    return {
                        ...task.toJSON(),
                        assignedUsersCount,
                        taskcommentCount
                    };
                }));
                if (!response_2[0]) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        error: true,
                        success: false,
                        status: '0',
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tasksWithCount,
                });
            }



        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }

    }
}

// Document upload on task
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'ProjectTodoTaskDocs';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;

    },
});
const upload = multer({ storage: storage });
const projectuploadTaskDocument = async (req, res) => {
    upload.array('files')(req, res, async function (err) {
        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        } else {
            const schema = Joi.object().keys({
                task_id: Joi.number().required(),
                project_id: Joi.number().required(),
                created_by: Joi.number().integer().required(),
                created_at: Joi.date().iso().required(),
                user_comp_id: Joi.number().integer().required()
            });

            const dataToValidate = {
                task_id: req.body.task_id,
                created_by: req.userId,
                created_at: datetime,
                user_comp_id: req.comp_id,
                project_id: req.body.project_id
            };

            const result = schema.validate(dataToValidate);
            if (result.error) {
                res.status(process.env.APIRESPCODE_VALIDATION).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: result.error.details[0].message
                });
            } else {
                try {
                    const files = req.files;
                    if (files.length != 0) {
                        const folderPath = files[0].destination;
                        const fileRecords = await ProjectTodoCommentDocuments.bulkCreate(files.map((file) => (
                            {
                                created_by: req.userId, user_comp_id: req.comp_id, project_id: req.body.project_id, task_id: req.body.task_id,
                                doc_name: file.filename, doc_exten: path.extname(file.filename),
                                doc_path: folderPath, created_at: datetime
                            })));

                        if (!fileRecords[0]) {
                            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                message: process.env.ERROR_MSG,
                                error: true,
                                success: false,
                                status: '0',
                            })
                        } else {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECINSERTED,
                                error: false,
                                success: true,
                                status: '1',
                            });
                        }

                    } else {
                        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                            message: "No File Selected",
                            error: false,
                            success: true,
                            status: '1',
                        });
                    }
                } catch (error) {
                    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                        message: process.env.ERROR_MSG,
                        error: error.message,
                        success: false,
                        status: '0',
                    })
                }
            }

        }

    });
}
const peoject_list_task_user = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        task_id: req.body.task_id,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        task_id: Joi.number().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {

            const response = await ProjectAssigntaskModel.findAll({
                where: {
                    status: '1', user_comp_id: req.comp_id, task_id: req.body.task_id, project_id: req.body.project_id,
                    assigned_to_userid: {
                        [Op.ne]: req.userId
                    }
                },
                include: [

                    {
                        model: Users,
                        attributes: ['userfullname'],
                        // as: "assign_to", // Use a distinct alias for the first association
                        where: { isactive: '1' },
                        required: false,
                    },
                    {
                        model: Users,
                        attributes: ['userfullname'],
                        as: "assin_by", // Use a distinct alias for the first association
                        where: { isactive: '1' },
                        required: false,
                    },
                    // {
                    //     model: TodoModel,
                    //     attributes: ['task_name'],
                    //     as: "task_name", // Use a distinct alias for the first association
                    //     where: { status: '1' },
                    //     required: false,
                    // },
                ],
            });

            if (!response[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,
            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
const project_list_hastag_search = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        hashtag: req.body.hashtag,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        hashtag: Joi.string().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {
            const hashtag = req.body.hashtag;
            const response = await ProjectTodo.findAll({
                where: {
                    user_comp_id: req.comp_id,
                    hash_tags: {
                        [Op.like]: `%${hashtag}%`, // Replace 'your_pattern_here' with the pattern you're looking for
                    },
                },
            });

            if (!response[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response,
            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
const project_ListTaskDocs = async (req, res) => {
    const dataToValidate = {
        user_comp_id: req.comp_id,
        project_id: req.body.project_id,
    };

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        project_id: Joi.number().required(),

    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            // const response = await ProjectTodoCommentDocuments.findAll({
            //     where: { user_comp_id: req.comp_id, task_id: req.body.task_id, project_id: req.body.project_id },

            // })
            const response = await ProjectTodo.findAll({
                order: [['id', 'ASC']],
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id },
                attributes: ['id', 'task_name', 'task_priority', 'hash_tags'],
                include: [
                    {
                        model: ProjectTodoCommentDocuments,
                        as: 'todo_comment_documents',
                        attributes: ['id', 'doc_name'],
                        where: { user_comp_id: req.comp_id, project_id: req.body.project_id },
                        required: false,
                    }
                ]
            });
            if (!response[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response,

                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
};
const projectUpdateScopeByTaskId = async (req, res) => {
    const schema = Joi.object().keys({
        task_id: Joi.number().required(),
        current_scope: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        project_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });
    const dataToValidate = {
        task_id: req.body.task_id,
        project_id: req.body.project_id,
        current_scope: req.body.current_scope,
        user_comp_id: req.comp_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await ProjectTodo.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.task_id, project_id: req.body.project_id }, attributes: ['id'] });
            if (existData) {
                const UpdateDataArr = {
                    current_scope: req.body.current_scope,
                    modified_by: req.userId,
                    updated_at: currentDate,
                }
                const update = await ProjectTodo.update(UpdateDataArr, {
                    where: { status: "1", user_comp_id: req.comp_id, id: req.body.task_id, project_id: req.body.project_id }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}


//get Tender todo comment
const TenderTodoCmtList = async (req, res) => {
    const schema = Joi.object().keys({
        task_id: Joi.number().required(),
        tender_id: Joi.number().required(),
    });

    const dataToValidate = {
        task_id: req.body.task_id,
        tender_id: req.body.tender_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        // [literal(`DATE_FORMAT(created_at, '%Y-%m-%d')`),
        const list = await ProjectTodoCommentModel.findAll({
            // order: [['id', 'DESC']],
            where: { user_comp_id: req.comp_id, project_id: req.body.tender_id, task_id: req.body.task_id, status: '1' },
            attributes: ['id', 'task_id', 'comment_txt', ['file_attachment', 'file_name'], 'file_path', 'parent_id', 'created_at', 'created_by']
        });
        try {
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


//Update Scope By Task Id and Tender ID..
const UpdateScopeByTaskIdTenderId = async (req, res) => {
    const schema = Joi.object().keys({
        task_id: Joi.number().required(),
        tender_id: Joi.number().required(),
        current_scope: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });
    const dataToValidate = {
        task_id: req.body.task_id,
        tender_id: req.body.tender_id,
        current_scope: req.body.current_scope,
        user_comp_id: req.comp_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await ProjectTodo.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.task_id, project_id: req.body.tender_id }, attributes: ['id'] });
            if (existData) {
                const UpdateDataArr = {
                    current_scope: req.body.current_scope,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update = await ProjectTodo.update(UpdateDataArr, {
                    where: { status: "1", user_comp_id: req.comp_id, id: req.body.task_id, project_id: req.body.tender_id }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}


module.exports = {
    project_todo_create_task, project_todo_edit_task, project_todo_update_task, project_list_todo_scope_mytask, project_list_todo_inporgress_mytask,
    project_list_todo_done_mytask, projectuploadTaskDocument, peoject_list_task_user, project_list_hastag_search, project_ListTaskDocs
    , projectUpdateScopeByTaskId, TenderTodoCmtList, UpdateScopeByTaskIdTenderId
    // todo_edit_task, addtodocmt, edittodocmt, todocmtlist, UpdateScopeByTaskId, ListHastagMaster,
    // ListTaskScopeMove, uploadTaskDocument, ListTaskDocs, updateUploadTaskDocument, todo_update_task, list_todo_mytask,
    // searchHashtagInTask, todo_update_srnumber_task, list_task_user, list_hastag_search, list_todo_scope_mytask, list_todo_inporgress_mytask, list_todo_done_mytask
};  