const MenuMasterModel = require("../../models/Menu/MenuMasterModel");
const userModel = require("../../models/Users");
require("dotenv").config();

const MenuMasterListAll = async (req, res) => {
    try {
        const AllowedUser = await userModel.findOne({
            where: {
                id: req.userId,
                permanent_sys_adm: "1",
            },
        });

        if (!AllowedUser) {
            return res.status(403).send({
                message: "You are not permitted",
                error: true,
                success: false,
                status: "0",
            });
        }
        const existData = await MenuMasterModel.findAll({
            where: { status: "1" },
        });

        // Initialize an empty object to store the hierarchical data
        const hierarchy = {};

        // Iterate through the menu items to build the hierarchy
        existData.forEach(menu => {
            // If the menu item has parent_menu_id of 0, it's a top-level menu
            menu = menu.dataValues
            if (menu.parent_menu_id === 0) {
                hierarchy[menu.id] = { ...menu, children: [] };
            } else {
                // If the menu item has a parent, add it to the children array of its parent
                if (hierarchy[menu.parent_menu_id]) {
                    hierarchy[menu.parent_menu_id].children.push(menu);
                } else {
                    // If the parent doesn't exist in the hierarchy yet, create it
                    hierarchy[menu.parent_menu_id] = { children: [menu] };
                }
            }
        });

        // Get the top-level menus from the hierarchy object
        const mainMenus = Object.values(hierarchy);


        if (existData.length > 0) {
            res.send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: "1",
                data: mainMenus,
            });
        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: "0",
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            msg: error.message,
            error: true,
            success: false,
            status: "0",
        });
    }
};

module.exports = {
    MenuMasterListAll,
};
