const ActionPermissionModel = require('../../models/Menu/ActionPermissionModel')
const userModel = require('../../models/Users')
require('dotenv').config();
const ActionPermissionListAll = async (req, res) => {
    try {

        const AllowedUser = await userModel.findOne({
            where: {
                id: req.userId,
                permanent_sys_adm: '1'
            }
        })

        if (!AllowedUser) {
            return res.status(403).send({
                message: 'You are not permitted',
                error: true,
                success: false,
                status: '0',
            })
        }
        const existData = await ActionPermissionModel.findAll({
            where: { status: "1", }
        });

        if (existData[0]) {
            res.send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: existData,
            });
        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}







module.exports = {
    ActionPermissionListAll

};    
