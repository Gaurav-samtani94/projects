const Users = require("../../models/Users");
const Chat = require("../../models/chat/Chat");
const ChatRooms = require("../../models/chat/Chatroom");
const sequalize = require("../../config/database");
const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Joi = require('joi');
const ChatgroupMembers = require("../../models/chat/Chatgroupmembers");
const Chatgroup = require("../../models/chat/Chatgroup");
const Arrangementsmodel = require('../../models/chat/ChatarrangementsModel');
const Arrangementsgroupmodel = require('../../models/chat/ChatarrangementsgroupModel');
const ChatselectesModel = require('../../models/chat/ChatselectesModel');

const getCurrentDateTime = () => new Date();
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { group } = require("console");
const { create } = require("lodash");
// const chatuserListBYCompany = async (req, res) => {
//     try {
//         const UserList = await Users.findAll({
//             where: {
//                 comp_id: req.comp_id, isactive: '1', id: {
//                     [Op.not]: req.userId
//                 }
//             }, attributes: [['id', 'user_id'], 'userfullname', 'email', 'profileimg_path', 'profileimg']
//         })

//         const tasksWithCount = await Promise.all(UserList.map(async (data) => {
//             const chat_unread_count = await Chat.count({ where: { user_comp_id: req.comp_id, from_user_id: data.dataValues.user_id, is_group: '1', to_user_id: req.userId, read: '0' } });
//             const chat_check_room_first = await ChatRooms.findOne({ where: { user_comp_id: req.comp_id, from_user_id: req.userId, to_user_id: data.dataValues.user_id, status: '1' }, attributes: ['id'] });
//             const chat_check_room_second = await ChatRooms.findOne({ where: { user_comp_id: req.comp_id, from_user_id: data.dataValues.user_id, to_user_id: req.userId, status: '1' }, attributes: ['id'] });
//             if ((chat_check_room_first) || (chat_check_room_second)) {
//                 var roor_id = (chat_check_room_first) ? chat_check_room_first.id : chat_check_room_second.id;
//             }
//             let last_message
//             if (roor_id) {
//                 last_message = await Chat.findOne({
//                     where: { user_comp_id: req.comp_id, chat_room_id: roor_id, is_group: '1' },
//                     order: [['id', 'DESC']],
//                     attributes: ['from_user_id', 'to_user_id', 'message', 'created_at', 'read', 'file_name', 'original_file_name'],

//                 })
//             }

//             return {
//                 ...data.toJSON(),
//                 chat_unread_count,
//                 last_message,

//             };
//         }))
//         if (UserList[0]) {
//             res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                 message: process.env.APIRESPMSG_RECFOUND,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 data: tasksWithCount
//             });
//         } else {
//             res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                 message: process.env.APIRESPMSG_RECNOTFOUND,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });

//         }
//     } catch (error) {
//         res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//             message: process.env.ERROR_MSG,
//             error: error.message,
//             success: false,
//             status: '0',
//         });
//     }
// }
const chatuserListBYCompany = async (req, res) => {
    try {
        const UserList_all = await Users.findAll({
            where: {
                comp_id: req.comp_id, isactive: '1', id: {
                    [Op.ne]: req.userId
                }
            }, attributes: [['id', 'user_id'], 'userfullname', 'email', 'profileimg_path', 'profileimg']
        })
        for (const user_id of UserList_all) {
            const check_exist = await Arrangementsmodel.count({ where: { user_comp_id: req.comp_id, from_user_id: req.userId, to_user_id: user_id.dataValues.user_id, status: '1' }, attributes: ['id'] })
            if (check_exist < 1) {
                await Arrangementsmodel.create({
                    user_comp_id: req.comp_id,
                    from_user_id: req.userId,
                    to_user_id: user_id.dataValues.user_id,
                    created_by: req.userId,
                    created_at: getCurrentDateTime()
                })
            }
        }
        const UserList = await Arrangementsmodel.findAll({
            where: {
                user_comp_id: req.comp_id,
                from_user_id: req.userId,
                to_user_id: {
                    [Op.ne]: req.userId
                },
                status: '1'
            }, attributes: [['to_user_id', 'user_id'], 'to_user_id'], order: [['updated_at', 'DESC']],
            group: ['to_user_id'],
            include: [{
                model: Users,
                attributes: ['userfullname', 'profileimg_path', 'profileimg'],
                where: {
                    isactive: '1',
                    id: {
                        [Op.ne]: req.userId
                    },
                },
                required: false,
            },
            ]
        })
        const tasksWithCount = await Promise.all(UserList.map(async (data) => {
            var roor_id = "";
            const chat_unread_count = await Chat.count({ where: { user_comp_id: req.comp_id, from_user_id: data.dataValues.user_id, is_group: '1', to_user_id: req.userId, read: '0' } });
            const chat_check_room_first = await ChatRooms.findOne({ where: { user_comp_id: req.comp_id, from_user_id: req.userId, to_user_id: data.dataValues.user_id, status: '1' }, attributes: ['id'] });
            const chat_check_room_second = await ChatRooms.findOne({ where: { user_comp_id: req.comp_id, from_user_id: data.dataValues.user_id, to_user_id: req.userId, status: '1' }, attributes: ['id'] });
            if ((chat_check_room_first) || (chat_check_room_second)) {
                var roor_id = (chat_check_room_first) ? chat_check_room_first.id : chat_check_room_second.id;
            }
            let last_message = null;
            if (roor_id) {
                last_message = await Chat.findOne({
                    where: { user_comp_id: req.comp_id, chat_room_id: roor_id, is_group: '1' },
                    order: [['id', 'DESC']],
                    attributes: ['from_user_id', 'to_user_id', 'message', 'created_at', 'read', 'file_name', 'original_file_name'],

                })
            }
            return {
                ...data.toJSON(),
                chat_unread_count,
                last_message,

            };
        }))
        if (UserList[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount
            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });

        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}
const userchatinglist = async (req, res) => {
    const schema = Joi.object().keys({
        user_id: Joi.number().required(),
    });
    const dataToValidate = {
        user_id: req.body.user_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const existsSync = await ChatselectesModel.findOne({ where: { user_comp_id: req.comp_id, from_user_id: req.userId }, attributes: ['id'] })
            if (existsSync) {
                await ChatselectesModel.update({
                    to_user_id: req.body.user_id,
                    updated_by: req.userId,
                    updated_at: getCurrentDateTime(),
                },
                    { where: { user_comp_id: req.comp_id, from_user_id: req.userId } })

            } else {
                await ChatselectesModel.create({
                    user_comp_id: req.comp_id,
                    from_user_id: req.userId,
                    to_user_id: req.body.user_id,
                    created_by: req.userId,
                    created_at: getCurrentDateTime(),
                },)
            }
            const UserList = await Users.findOne({ where: { id: req.body.user_id, isactive: '1' }, attributes: ['id'] })
            const chat_check_room_first = await ChatRooms.findOne({ where: { user_comp_id: req.comp_id, from_user_id: req.userId, to_user_id: req.body.user_id, status: '1' }, attributes: ['id'] });
            const chat_check_room_second = await ChatRooms.findOne({ where: { user_comp_id: req.comp_id, from_user_id: req.body.user_id, to_user_id: req.userId, status: '1' }, attributes: ['id'] });
            if ((chat_check_room_first) || (chat_check_room_second)) {
                var roor_id = (chat_check_room_first) ? chat_check_room_first.id : chat_check_room_second.id;
            }
            if ((roor_id) && (UserList)) {
                const upd = {
                    read: '1'
                }
                await Chat.update(upd, { where: { from_user_id: req.body.user_id, to_user_id: req.userId, user_comp_id: req.comp_id, read: '0' } })
                const chatRecord = await Chat.findAll({
                    where: { user_comp_id: req.comp_id, chat_room_id: roor_id, is_group: '1' },
                    // attributes: [['id', 'chat_id'], 'from_user_id', 'to_user_id', 'message', 'created_at'],

                })

                if (chatRecord[0]) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECFOUND,
                        error: false,
                        success: true,
                        status: '1',
                        data: chatRecord
                    });
                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
const groupchatinghistory = async (req, res) => {

    const schema = Joi.object().keys({
        group_id: Joi.string().required(),
    });
    const dataToValidate = {
        group_id: req.body.group_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const chatRecord = await Chat.findAll({
                where: { user_comp_id: req.comp_id, is_group: '2', group_id: req.body.group_id },
                // attributes: [['id', 'chat_id'], 'from_user_id', 'to_user_id', 'message', 'created_at'],
                include: [{
                    model: Users,
                    attributes: ['userfullname', 'profileimg_path', 'profileimg'],
                    where: { isactive: '1' },
                    required: false,
                },
                ]
            })
            if (chatRecord[0]) {
                const upd = {
                    read: '1'
                }
                await Chat.update(upd, { where: { user_comp_id: req.comp_id, group_id: req.body.group_id, read: '0' } })

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: chatRecord
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }

}
const createGroup = async (req, res) => {
    const schema = Joi.object().keys({
        group_name: Joi.string().required(),
        user_id: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        group_name: req.body.group_name,
        user_id: req.body.user_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const checkexist = await Chatgroup.findOne({ where: { user_comp_id: req.comp_id, group_name: req.body.group_name, status: '1' }, attributes: ['id'] })
            if (checkexist) {
                res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });

            } else {
                const insert = await Chatgroup.create(dataToValidate)
                if (insert) {
                    const user_id_str = req.body.user_id + ',' + req.userId;
                    const user_id_arr = user_id_str.split(',');
                    if (user_id_arr[0]) {
                        await Promise.all(user_id_arr.map(async (item, index) => {
                            const insert_val = {
                                user_comp_id: req.comp_id,
                                group_id: insert.id,
                                user_id: item,
                                created_by: req.userId,
                                created_at: getCurrentDateTime(),
                            }
                            var add_data = await ChatgroupMembers.create(insert_val);
                        }));

                    }
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });

                }

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}

const GroupEdit = async (req, res) => {
    const schema = Joi.object().keys({
        group_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        group_id: req.body.group_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const checkexist = await Chatgroup.findOne({ where: { id: req.body.group_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'group_name'] })
            if (!checkexist) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: checkexist
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}

const groupupdate = async (req, res) => {
    const schema = Joi.object().keys({
        group_name: Joi.string().required(),
        group_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        updated_by: Joi.number().required(),
        updated_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        group_name: req.body.group_name,
        group_id: req.body.group_id,
        user_comp_id: req.comp_id,
        updated_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const checkexist = await Chatgroup.findOne({
                where: {
                    group_name: req.body.group_name, user_comp_id: req.comp_id, status: '1',
                    id: {
                        [Op.not]: req.body.group_id
                    }
                }, attributes: ['id', 'group_name']

            })
            if (checkexist) {
                res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const updrecord = {
                    group_name: req.body.group_name,
                    updated_by: req.userId,
                    updated_at: getCurrentDateTime(),

                }
                const response = await Chatgroup.update(updrecord, {
                    where: {
                        id: req.body.group_id, user_comp_id: req.comp_id, status: '1',
                    },
                })
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}

const groupdelete = async (req, res) => {
    const schema = Joi.object().keys({
        group_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        updated_by: Joi.number().required(),
        updated_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        group_id: req.body.group_id,
        user_comp_id: req.comp_id,
        updated_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const checkexist = await Chatgroup.findOne({
                where: {
                    id: req.body.group_id, user_comp_id: req.comp_id, status: '1',
                }, attributes: ['id', 'group_name']

            })
            if (!checkexist) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            } else {
                const updrecord = {
                    status: '0',
                    updated_by: req.userId,
                    updated_at: getCurrentDateTime(),

                }
                const response = await Chatgroup.update(updrecord, {
                    where: {
                        id: req.body.group_id, user_comp_id: req.comp_id, status: '1',
                    },
                })
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}

const grouplist = async (req, res) => {
    try {
        const List = await Chatgroup.findAll({
            where: {
                user_comp_id: req.comp_id, status: '1',
            }, attributes: ['id', 'group_name']

        })
        if (!List[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: List
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });

    }
}

const userassignGroupmember = async (req, res) => {
    const schema = Joi.object().keys({
        group_id: Joi.number().required(),
        user_id: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        group_id: req.body.group_id,
        user_id: req.body.user_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const user_id_str = req.body.user_id;
            const user_id_arr = user_id_str.split(',');
            if (user_id_arr[0]) {
                await Promise.all(user_id_arr.map(async (item, index) => {
                    const checkExist = await ChatgroupMembers.findOne({
                        where: { user_comp_id: req.comp_id, group_id: req.body.group_id, user_id: item, status: '1' },
                        attributes: ['id']
                    });
                    if (checkExist < 1) {
                        const insert = {
                            user_comp_id: req.comp_id,
                            group_id: req.body.group_id,
                            user_id: item,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        }
                        await ChatgroupMembers.create(insert);

                    }
                }));
            }

            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECINSERTED,
                error: false,
                success: true,
                status: '1',
            });

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}

const userEditGroupmember = async (req, res) => {
    const schema = Joi.object().keys({
        group_id: Joi.number().required(),

    });
    const dataToValidate = {
        group_id: req.body.group_id,

    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const checkExist = await ChatgroupMembers.findAll({
                where: { user_comp_id: req.comp_id, group_id: req.body.group_id, status: '1' },
                attributes: ['id', 'group_id', 'user_id']
            });
            if (checkExist[0]) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: checkExist
                });
            } else {

                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}


const userupdateGroupmember = async (req, res) => {
    const schema = Joi.object().keys({
        group_id: Joi.number().required(),
        user_id: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        updated_by: Joi.number().required(),
        updated_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        group_id: req.body.group_id,
        user_id: req.body.user_id,
        user_comp_id: req.comp_id,
        updated_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const user_id_str = req.body.user_id;
            const user_id_arr = user_id_str.split(',');
            await ChatgroupMembers.destroy({
                where: { user_comp_id: req.comp_id, group_id: req.body.group_id, status: '1' },
            });
            if (user_id_arr[0]) {
                await Promise.all(user_id_arr.map(async (item, index) => {
                    const checkExist = await ChatgroupMembers.findOne({
                        where: { user_comp_id: req.comp_id, group_id: req.body.group_id, user_id: item, status: '1' },
                        attributes: ['id']
                    });
                    if (checkExist < 1) {
                        const insert = {
                            user_comp_id: req.comp_id,
                            group_id: req.body.group_id,
                            user_id: item,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                            updated_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        await ChatgroupMembers.create(insert);

                    }
                }));
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECUPDATED,
                error: false,
                success: true,
                status: '1',
            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}
// const userListGroupmember = async (req, res) => {
//     try {

//         const checkExist = await ChatgroupMembers.findAll({
//             where: { user_comp_id: req.comp_id, user_id: req.userId, status: '1' },
//             attributes: ['id', 'group_id', 'user_id'],
//             include: [{
//                 model: Chatgroup,
//                 attributes: ['group_name'],
//                 where: { status: '1' },
//                 required: false,
//             },
//             {
//                 model: Users,
//                 attributes: ['userfullname'],
//                 where: { isactive: '1' },
//                 required: false,
//             },
//             ]
//         });

//         const tasksWithCount = await Promise.all(checkExist.map(async (data) => {
//             const chat_unread_count = await Chat.count({ where: { user_comp_id: req.comp_id, group_id: data.group_id, is_group: '2', read: '0' } });
//             const last_message = await Chat.findOne({ where: { user_comp_id: req.comp_id, group_id: data.group_id, is_group: '2' }, order: [['id', 'DESC']], });
//             return {
//                 ...data.toJSON(),
//                 chat_unread_count,
//                 last_message

//             };
//         }))
//         if (checkExist[0]) {
//             res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                 message: process.env.APIRESPMSG_RECFOUND,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 data: tasksWithCount
//             });
//         } else {
//             res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                 message: process.env.APIRESPMSG_RECNOTFOUND,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });

//         }
//     } catch (error) {
//         res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//             message: process.env.ERROR_MSG,
//             error: error.message,
//             success: false,
//             status: '0',
//         });

//     }
// }
const userListGroupmember = async (req, res) => {
    try {
        const response = await ChatgroupMembers.findAll({
            where: { user_comp_id: req.comp_id, user_id: req.userId, status: '1' },
            attributes: ['id', 'group_id', 'user_id'],
        });
        for (const group_id of response) {
            const check_exist = await Arrangementsgroupmodel.count({ where: { user_comp_id: req.comp_id, group_id: group_id.group_id, status: '1' }, attributes: ['id'] })
            if (check_exist < 1) {
                await Arrangementsgroupmodel.create({
                    user_comp_id: req.comp_id,
                    group_id: group_id.group_id,
                    created_by: req.userId,
                    created_at: getCurrentDateTime()
                })
            }
        }
        const respionse_Arrangementsgroupmodel = await Arrangementsgroupmodel.findAll({
            where: { user_comp_id: req.comp_id, status: '1' },
            attributes: ['id', 'group_id'],
            order: [['updated_at', 'DESC']],
            include: [{
                model: ChatgroupMembers,
                attributes: ['group_id', 'user_id'],
                where: { status: '1', user_comp_id: req.comp_id, user_id: req.userId, },
                include: [{
                    model: Chatgroup,
                    attributes: ['group_name', 'group_profile'],
                    where: { status: '1' },
                    required: false,
                },
                    // {
                    //     model: Users,
                    //     attributes: ['userfullname'],
                    //     where: { isactive: '1' },
                    //     required: false,
                    // },
                ]
            },
            ]
        });

        // const checkExist = await ChatgroupMembers.findAll({
        //     where: { user_comp_id: req.comp_id, user_id: req.userId, status: '1' },
        //     attributes: ['id', 'group_id', 'user_id'],
        //     include: [{
        //         model: Chatgroup,
        //         attributes: ['group_name'],
        //         where: { status: '1' },
        //         required: false,
        //     },
        //     {
        //         model: Users,
        //         attributes: ['userfullname'],
        //         where: { isactive: '1' },
        //         required: false,
        //     },
        //     ]
        // });
        // Arrangementsgroupmodel
        const tasksWithCount = await Promise.all(respionse_Arrangementsgroupmodel.map(async (data) => {
            const chat_unread_count = await Chat.count({ where: { user_comp_id: req.comp_id, group_id: data.group_id, is_group: '2', read: '0' } });
            const last_message = await Chat.findOne({ where: { user_comp_id: req.comp_id, group_id: data.group_id, is_group: '2' }, order: [['id', 'DESC']], });
            return {
                ...data.toJSON(),
                chat_unread_count,
                last_message

            };
        }))
        if (respionse_Arrangementsgroupmodel[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount
            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });

        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });

    }
}
const single_chat_file_upload = multer.diskStorage({
    destination: (req, file, cb) => {
        console.log(req.userId, 'filesfilesww')
        const foldername = 'public' + '_' + req.comp_id + '/' + 'chats' + '/' + req.userId;
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const random = Math.floor((Math.random() * 1000000) + 1000);
        const extension = path.extname(file.originalname);
        //console.log("Ash :- "+extension);
        cb(null, req.userId + random + file.originalname); // Rename file with a timestamp
    },
});

const upload = multer({ storage: single_chat_file_upload });
const single_chating_file_upload = async (req, res) => {
    upload.array('files')(req, res, async function (err) {
        console.log(req.body.to_user_id, 'filesfiles')
        if (err) {
            console.log(err, 'error')
        }
        const schema = Joi.object().keys({
            to_user_id: Joi.number().required(),
        });
        const dataToValidate = {
            to_user_id: req.body.to_user_id,
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        } else {

            const UserList = await Users.findOne({ where: { id: req.body.to_user_id, isactive: '1' }, attributes: ['id'] })
            const chat_check_room_first = await ChatRooms.findOne({ where: { user_comp_id: req.comp_id, from_user_id: req.userId, to_user_id: req.body.to_user_id, status: '1' }, attributes: ['id'] });
            const chat_check_room_second = await ChatRooms.findOne({ where: { user_comp_id: req.comp_id, from_user_id: req.body.to_user_id, to_user_id: req.userId, status: '1' }, attributes: ['id'] });
            if ((chat_check_room_first) || (chat_check_room_second)) {
                var roor_id = (chat_check_room_first) ? chat_check_room_first.id : chat_check_room_second.id;
            } else {
                const insert_val = {
                    user_comp_id: req.comp_id,
                    from_user_id: req.userId,
                    to_user_id: req.body.to_user_id,
                    created_at: getCurrentDateTime(),
                    created_by: from_user_id,
                }
                const insert_room = await ChatRooms.create(insert_val);
                var roor_id = insert_room.id;
            }
            try {
                if (!roor_id) {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',
                    });

                } else {
                    const files = req.files;
                    console.log(files, 'filesfiles')
                    if (files[0]) {
                        const fileRecords = await Chat.bulkCreate(files.map((file) => ({
                            user_comp_id: req.comp_id,
                            from_user_id: req.userId,
                            file_type: req.body.file_type,
                            to_user_id: req.body.to_user_id,
                            original_file_name: file.originalname,
                            is_file: '1',
                            file_name: file.destination + '/' + file.filename,
                            chat_room_id: roor_id,
                            extention: path.extname(file.filename),
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        })));
                        if (fileRecords[0]) {
                            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECINSERTED,
                                error: false,
                                success: true,
                                status: '1',
                                data: fileRecords
                            });
                        } else {
                            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                message: process.env.ERROR_MSG,
                                error: true,
                                success: false,
                                status: '0',
                            });



                        }
                    }
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                })

            }
        }
    })
}
const group_chating_file_upload = async (req, res) => {
    upload.array('files')(req, res, async function (err) {
        if (err) {
            console.log(err, 'error')
        }
        const schema = Joi.object().keys({
            group_id: Joi.number().required(),
        });
        const dataToValidate = {
            group_id: req.body.group_id,
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        } else {
            try {
                const files = req.files;
                if (files[0]) {
                    const fileRecords = await Chat.bulkCreate(files.map((file) => ({
                        user_comp_id: req.comp_id,
                        from_user_id: req.userId,
                        original_file_name: file.originalname,
                        is_group: '2',
                        is_file: '1',
                        file_type: req.body.file_type,
                        group_id: req.body.group_id,
                        file_name: file.destination + '/' + file.filename,
                        extention: path.extname(file.filename),
                        created_by: req.userId,
                        created_at: getCurrentDateTime(),
                    })));
                    if (fileRecords[0]) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',
                            data: fileRecords
                        });
                    } else {
                        res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.ERROR_MSG,
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                })

            }
        }
    })

}
const singlecahtingunreadlist = async (req, res) => {
    try {
        const UserList = await Users.findAll({
            where: {
                comp_id: req.comp_id, isactive: '1', id: {
                    [Op.not]: req.userId
                }
            }, attributes: ['id']
        })
        const tasksWithCount = await Promise.all(UserList.map(async (user_id) => {
            const chat_unread_count = await Chat.count({ where: { user_comp_id: req.comp_id, from_user_id: user_id.id, is_group: '1', to_user_id: req.userId, read: '0' } });
            return {
                ...user_id.toJSON(),
                chat_unread_count,

            };
        }))
        if (UserList[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount
            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });

        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}

const groupchatuserlist = async (req, res) => {
    const schema = Joi.object().keys({
        group_id: Joi.number().required(),
    });
    const dataToValidate = {
        group_id: req.body.group_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const response = await Chatgroup.findOne({
                where: { user_comp_id: req.comp_id, status: '1', id: req.body.group_id },
                attributes: ['id', 'group_name', 'group_profile', 'created_by'],
                include: [
                    {
                        model: Users,
                        attributes: ['userfullname', 'email'],
                        where: { isactive: '1' },
                        required: false,
                    },
                ]
            })
            const response_2 = await ChatgroupMembers.findAll({
                where: {
                    user_comp_id: req.comp_id, status: '1', group_id: req.body.group_id,
                    user_id: {
                        [Op.not]: req.userId
                    },
                },
                attributes: ['id', 'group_id', 'user_id'],
                include: [
                    {
                        model: Users,
                        attributes: ['userfullname', 'email', 'profileimg', 'profileimg_path'],
                        where: { isactive: '1' },
                        required: false,
                    },
                ]
            });
            const datares = {
                group_info: response,
                group_user: response_2
            }
            if (response) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: datares,

                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }

    }
}
const chatgroupuser_list = async (req, res) => {
    const schema = Joi.object().keys({
        group_id: Joi.number().required(),
    });
    const dataToValidate = {
        group_id: req.body.group_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const response_1 = await ChatgroupMembers.findAll({
                where: {
                    user_comp_id: req.comp_id, status: '1', group_id: req.body.group_id,
                },
                attributes: ['user_id'],

            });
            const activityIds = response_1.map((data) => data.user_id);
            const response = await Users.findAll({
                where: {
                    comp_id: req.comp_id, isactive: '1',
                    id: {
                        [Op.notIn]: activityIds,
                    },
                },
                attributes: ['id', 'userfullname'],
            })
            if (response[0]) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response,

                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

const updateuseringroup = async (req, res) => {
    const schema = Joi.object().keys({
        group_id: Joi.number().required(),
        user_ids: Joi.string().required(),
    });
    const dataToValidate = {
        group_id: req.body.group_id,
        user_ids: req.body.user_ids
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const check_exist = await Chatgroup.findOne({
                where: { user_comp_id: req.comp_id, status: '1', id: req.body.group_id, created_by: req.userId },
                attributes: ['id'],
            })

            const user_id_arr = req.body.user_ids.split(',');
            let no = 0
            if ((user_id_arr[0]) && (check_exist)) {
                await Promise.all(user_id_arr.map(async (item, index) => {
                    const response = await ChatgroupMembers.findOne({
                        where: {
                            user_comp_id: req.comp_id,
                            group_id: req.body.group_id,
                            user_id: item,
                            status: '1'
                        },
                    })
                    if (!response) {
                        const insert_val = {
                            user_comp_id: req.comp_id,
                            group_id: req.body.group_id,
                            user_id: item,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        }
                        no += 1
                        await ChatgroupMembers.create(insert_val);
                    }

                }));
                if (no > 0) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } else {

                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


const delleteuseringroup = async (req, res) => {
    const schema = Joi.object().keys({
        group_id: Joi.number().required(),
        user_id: Joi.number().required(),
    });
    const dataToValidate = {
        group_id: req.body.group_id,
        user_id: req.body.user_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            let no = 0
            const response = await ChatgroupMembers.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    group_id: req.body.group_id,
                    user_id: req.body.user_id,
                    status: '1'
                },
            })

            const check_exist = await Chatgroup.findOne({
                where: { user_comp_id: req.comp_id, status: '1', id: req.body.group_id, created_by: req.userId },
                attributes: ['id'],
            })
            if ((response) && (check_exist)) {
                const upd_status = {
                    status: '0',
                    updated_at: getCurrentDateTime(),
                    updated_by: req.userId,
                }
                await ChatgroupMembers.update(upd_status, {
                    where: {
                        user_comp_id: req.comp_id,
                        group_id: req.body.group_id,
                        user_id: req.body.user_id,
                        status: '1'
                    }

                });
                no += 1
                if (no > 0) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
const uploadgroup_profiles = multer.diskStorage({
    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'chats' + '/' + 'group_profile';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const random = Math.floor((Math.random() * 1000000) + 1000);
        cb(null, req.userId + random + file.originalname);
    },
});

const uploadgroup_profile = multer({ storage: uploadgroup_profiles });
const updategropeinfo = async (req, res) => {
    uploadgroup_profile.single('file')(req, res, async function (err) {
        if (err) {
            console.log(err, 'error')
        }
        const schema = Joi.object().keys({
            group_id: Joi.string().required(),
            group_name: Joi.string().required(),
        });
        const dataToValidate = {
            group_name: req.body.group_name,
            group_id: req.body.group_id,
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        } else {
            try {
                let no = 0;
                const file = req.file;
                if (file) {
                    no += 1
                    const upd_status = {
                        group_name: req.body.group_name,
                        group_profile: file.destination + '/' + file.filename,
                        updated_at: getCurrentDateTime(),
                        updated_by: req.userId,
                    }
                    await Chatgroup.update(upd_status, {
                        where: {
                            user_comp_id: req.comp_id,
                            id: req.body.group_id,
                            created_by: req.userId,
                            status: '1',
                        }
                    });
                } else {
                    no += 1
                    const upd_status = {
                        group_name: req.body.group_name,
                        updated_at: getCurrentDateTime(),
                        updated_by: req.userId,
                    }
                    await Chatgroup.update(upd_status, {
                        where: {
                            user_comp_id: req.comp_id,
                            id: req.body.group_id,
                            created_by: req.userId,
                            status: '1',
                        }
                    });
                }


                const response = await Chatgroup.findOne({
                    where: { user_comp_id: req.comp_id, status: '1', id: req.body.group_id },
                    attributes: ['id', 'group_name', 'group_profile'],
                })
                if (no > 0) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: response
                    });
                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.ERROR_MSG,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                })

            }
        }
    })
}
module.exports = {
    chatuserListBYCompany, userchatinglist, createGroup, GroupEdit, groupupdate,
    groupdelete, grouplist, userassignGroupmember, userupdateGroupmember, userEditGroupmember,
    userListGroupmember, groupchatinghistory, single_chating_file_upload, group_chating_file_upload,
    singlecahtingunreadlist, groupchatuserlist, chatgroupuser_list, updateuseringroup, delleteuseringroup,
    updategropeinfo
};  
