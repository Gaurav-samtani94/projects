const Configmstr = require("../../models/siteconfig/Configrationmaster");
const Setconfiguration = require("../../models/siteconfig/Setconfiguration");
const Confimastr = require("../../models/siteconfig/Configrationmaster");
const Joi = require('joi');
require('dotenv').config();
const getCurrentDateTime = () => new Date();

//Lising of Set Config..
const ListSetconfig = async (req, res) => {
    try {
        const response = await Setconfiguration.findAll({
            order: [['configuration_id', 'ASC']],
            where: { user_comp_id: req.comp_id, status: '1' },
            attributes: ['id', 'configuration_id', 'is_done'],
            include: [
                {
                    model: Confimastr,
                    attributes: ['config_name'],
                    where: { status: '1' },
                    required: false,
                },

            ]
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        }
        res.send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}



const InsertData = async (req, res) => {
    try {
      // Fetch all configuration masters
      const configMasters = await Configmstr.findAll();
      let insertCount = 0;
  
      for (const configMaster of configMasters) {
        const { id, ref_table_name } = configMaster;
  
        if (ref_table_name != "") {
          let data;
  
          if (ref_table_name == "main_companies") {
            // Check if data exists in the corresponding table with the specific user_comp_id and status
            const checkDataQuery = `SELECT COUNT(*) AS count FROM ${ref_table_name} WHERE link_comp_id = ? AND status = ?`;
            const [results, metadata] = await Configmstr.sequelize.query(
              checkDataQuery,
              {
                replacements: [req.comp_id, "1"],
              }
            );
            data = results;
          } else {
            // Check if data exists in the corresponding table with the specific user_comp_id and status
            const checkDataQuery = `SELECT COUNT(*) AS count FROM ${ref_table_name} WHERE user_comp_id = ? AND status = ?`;
            const [results, metadata] = await Configmstr.sequelize.query(
              checkDataQuery,
              {
                replacements: [req.comp_id, "1"],
              }
            );
            data = results;
          }
  
          const isDone = data[0].count > 0 ? 1 : 2;
  
          // Check if the configuration_id already exists in set_configurations
          const existingConfig = await Setconfiguration.findOne({
            where: { configuration_id: id },
          });
  
          if (!existingConfig) {
            // Insert the result into set_configurations if it does not already exist
            await Setconfiguration.create({
              configuration_id: id,
              is_done: isDone,
              user_comp_id: req.comp_id,
              created_at: getCurrentDateTime(),
              updated_at: getCurrentDateTime(),
            });
            insertCount++;
  
            console.log(
              `Inserted config id ${id} with is_done ${isDone} into set_configurations`
            );
          } else {
            insertCount++;
  
            // Update the existing record with the current details
            await Setconfiguration.update(
              {
                is_done: isDone,
                updated_at: getCurrentDateTime(),
              },
              {
                where: { configuration_id: id, user_comp_id: req.comp_id },
              }
            );
  
            console.log(
              `Updated config id ${id} with is_done ${isDone} in set_configurations`
            );
          }
        }
      }
      res.status(200).json({
        message: `Configuration data inserted successfully. Count: ${insertCount}`,
        success: true,
        status: "1",
        error: false,
      });
    } catch (error) {
      console.error("Error inserting configuration data:", error);
      res.status(500).json({
        message: "Failed to insert configuration data",
        success: false,
        status: 0,
        error: error.message,
      });
    }
  };
  





module.exports = {
    ListSetconfig, InsertData
};    
