const FinancialYear = require("../../models/siteconfig/FinancialYear");
const Siteconfiguration = require("../../models/siteconfig/Siteconfiguration");

const Joi = require('joi');
require('dotenv').config();
const getCurrentDateTime = () => new Date();

//Lising of Role..
const ListFinancialYear = async (req, res) => {
    try {
        const response = await FinancialYear.findAll({
            order: [['fin_year_type', 'ASC']],
            where: { status: '1' },
            attributes: ['id', 'fin_year_type'],
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        }
        res.send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}




//Update / Set Financial Year ..
const SetFinancialYear = async (req, res) => {

    const schema = Joi.object().keys({
        fin_year_id: Joi.number().required(),
    });

    const dataToValidate = {
        fin_year_id: req.body.fin_year_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Siteconfiguration.findOne({ where: { status: "1", user_comp_id: req.comp_id }, attributes: ['id'] });
            // console.log(existData.dataValues.id);
            if (existData) {
                const UpdateDataArr = {
                    financial_year_id: req.body.fin_year_id,
                    updated_at: getCurrentDateTime(),
                    modified_by: req.userId,
                }
                const update = await Siteconfiguration.update(UpdateDataArr, {
                    where: { status: "1", user_comp_id: req.comp_id }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            // res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}





//Update Letter Code...
const SetLetterCode = async (req, res) => {
    const schema = Joi.object().keys({
        lettercode_no: Joi.string().min(3).max(15).required(),
    });

    const dataToValidate = {
        lettercode_no: req.body.lettercode_no,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Siteconfiguration.findOne({ where: { status: "1", user_comp_id: req.comp_id }, attributes: ['id'] });
            // console.log(existData.dataValues.id);
            if (existData) {
                const UpdateDataArr = {
                    comp_letter_code: req.body.lettercode_no,
                    updated_at: getCurrentDateTime(),
                    modified_by: req.userId,
                }
                const update = await Siteconfiguration.update(UpdateDataArr, {
                    where: { status: "1", user_comp_id: req.comp_id }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            // res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}



//Get Configuration Details..
const ConfigurationDetails = async (req, res) => {
    try {
        const response = await Siteconfiguration.findOne({
            where: { status: '1', user_comp_id: req.comp_id },
            include: [
                {
                    model: FinancialYear,
                    attributes: ['fin_year_type'],
                    where: { status: '1' },
                    required: false,
                },

            ],

        });
        if (!response) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        }
        res.send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}





module.exports = {
    ListFinancialYear, SetFinancialYear, SetLetterCode, ConfigurationDetails
};    
