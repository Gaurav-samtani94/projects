const bodyParser = require('body-parser');
const express = require('express')
const jwt = require('jsonwebtoken');
const Joi = require('joi');
const Users = require('../../apps/models/Users');
const Country = require('../../apps/models/master/Country');
const State = require('../../apps/models/master/State');
const City = require('../../apps/models/master/City');
const md5 = require('md5');
const multer = require('multer');
const secretKey = 'bidgrid277833';
const getCurrentDateTime = () => new Date();
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const Role = require('../models/master/Role');
const Businessunit = require('../models/master/BusinessUnit');
const Company = require('../models/master/Company');
const DepartmentModel = require('../models/master/DepartmentModel');
const Designation = require('../models/master/Designation');
const JobGradeModel = require('../models/master/JobGradeModel');
const Useractivehistory = require('../models/activity/Useractivehistory');
const Userhistory = require('../models/activity/Userhistory');
const PageMster = require('../models/activity/Page');
const TenderMovedHistroyByUserModel = require('../models/tender/TenderMovedHistroyByUserModel');
const TenderModel = require('../models/tender/TenderModel');
const Tendersector = require('../models/master/TenderSector');
const TenderClient = require('../models/master/TenderClient');
const TenderDocModel = require('../models/tender/TenderDocModel');
const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const userlogin = async (req, res) => {
    const username = req.body.username;
    const password = req.body.password
    const schema = Joi.object().keys({
        username: Joi.string().required(),
        password: Joi.string().required(),
    });
    const dataToValidate = {
        username: username,
        password: password,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const user = await Users.findOne({ where: { email: req.body.username, password: md5(req.body.password), isactive: '1' }, attributes: ['id', 'comp_id', 'emp_role_id', 'email', 'contactnumber', 'permanent_sys_adm'] })
            if ((!user)) {
                res.status(process.env.APIRESPCODE_INVALID_CREDENTIAL).send({
                    message: 'Invalid credentials',
                    error: true,
                    success: false,
                    status: '0',

                });
            } else {
                // if ((user.comp_id == 31) && ((user.id !== 78) && (user.id !== 100))) {
                //     console.log(user.id, 'user.comp_id user.comp_id user.comp_id ')
                //     return res.status(process.env.APIRESPCODE_INVALID_CREDENTIAL).send({
                //         message: 'Invalid credentials',
                //         error: true,
                //         success: false,
                //         status: '0',

                //     });
                // } else if ((user.comp_id == 31) && ((user.id !== 100) && (user.id !== 78))) {
                //     return res.status(process.env.APIRESPCODE_INVALID_CREDENTIAL).send({
                //         message: 'Invalid credentials',
                //         error: true,
                //         success: false,
                //         status: '0',

                //     });
                // }
                const check_exist = await Useractivehistory.findOne({ where: { created_by: user.id, }, attributes: ['id', 'status'] })
                if (check_exist) {
                    const add_activity = {
                        created_by: user.id,
                        user_comp_id: user.comp_id,
                        activity: 'login',
                        ip_address: req.body.ip_address,
                        created_at: getCurrentDateTime(),

                    };
                    await Useractivehistory.create(add_activity);
                }
                // const user_role = await Role.findOne({ where: { id: user.emp_role_id, user_comp_id: user.comp_id, status: '1', role_name: 'System Admin' }, attributes: ['id'] })
                // if (user_role) {
                //     var emp_role = '1';
                // } else {
                //     var emp_role = '2';
                // }
                const token = jwt.sign({ id: user.id, comp_id: user.comp_id, emp_role_id: user.emp_role_id }, secretKey, {
                    expiresIn: '30d', // Token expires in 1 hour
                });
                const udate_info = {
                    last_login: getCurrentDateTime(),
                    auth_token: token,
                    device_token: req.body.device_token,
                    device_type: req.body.device_type,

                }
                if (req.body.web_push_notification_token) {
                    udate_info.web_push_notification_token = req.body.web_push_notification_token;
                }
                console.log(udate_info, 'udate_infoudate_infoudate_info')
                await Users.update(udate_info, { where: { id: user.id, isactive: '1' } })
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Login successful',
                    error: false,
                    success: true,
                    status: '1',
                    data: user,
                    token
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',

            });
        }
    }
};


//Change Password..
const changepassword = async (req, res) => {
    const schema = Joi.object().keys({
        password: Joi.string().required(),
    });

    const dataToValidate = {
        password: req.body.password,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            console.log(dataToValidate, 'dataToValidatedataToValidate', req.userId);
            const user = await Users.update({ password: md5(req.body.password) }, { where: { id: req.userId } });
            if (!user[0]) {
                return res.status(400).send({
                    message: 'something went wrong',
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            res.send({
                message: 'Password change successfully done.',
                error: false,
                success: true,
                status: '1',
                data: user,
            });
        } catch (error) {
            res.status(400).send({ error: error.message });
        }
    }
};



//User Add ...

const useradd = async (req, res) => {
    const dataToValidate = {
        emp_role_id: req.body.role_id,
        comp_id: req.comp_id,
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        userfullname: req.body.firstname + " " + req.body.lastname,
        email: req.body.email,
        contactnumber: req.body.contactnumber,
        password: req.body.password,
        unit_id: req.body.unit_id,
        company_id: req.body.company_id,
        department_id: req.body.department_id,
        designation_id: req.body.designation_id,
        jobgrade_id: req.body.jobgrade_id,
        reporting_mngr_id: req.body.reporting_mngr_id,

        createdby: req.userId,
        created_at: getCurrentDateTime(),
    };


    const schema = Joi.object().keys({
        emp_role_id: Joi.number().required(),
        comp_id: Joi.number().required(),
        firstname: Joi.string().required(),
        lastname: Joi.string().required(),
        userfullname: Joi.string().required(),
        email: Joi.string().email().required(),
        contactnumber: Joi.string().pattern(/^[0-9]{10}$/).required(),
        password: Joi.string().required(),
        unit_id: Joi.number().required(),
        company_id: Joi.number().required(),
        department_id: Joi.number().required(),
        designation_id: Joi.number().required(),
        jobgrade_id: Joi.number().required(),
        reporting_mngr_id: Joi.number().required(),

        createdby: Joi.number().required(),
        created_at: Joi.date().iso().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const EmailExistCheck = await Users.findOne({ where: { comp_id: req.comp_id, email: req.body.email, isactive: 1 }, attributes: ['id'] });
            const PhoneExistCheck = await Users.findOne({ where: { comp_id: req.comp_id, contactnumber: req.body.contactnumber, isactive: 1 }, attributes: ['id'] });
            if (EmailExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: "Email already exists",
                    error: true,
                    success: false,
                    status: '0',
                });
            } else if (PhoneExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: "Contact number already exists",
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            else {
                dataToValidate['password'] = md5(req.body.password);
                const insert = await Users.create(dataToValidate)
                if (insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert
                    });
                }

            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};




const userdetails_update = async (req, res) => {
    const dataToValidate = {
        comp_id: req.comp_id,
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        userfullname: req.body.firstname + " " + req.body.lastname,
        contactnumber: req.body.contactnumber,

        company_id: req.body.company_id,
        department_id: req.body.department_id,
        designation_id: req.body.designation_id,
        jobgrade_id: req.body.jobgrade_id,
        reporting_mngr_id: req.body.reporting_mngr_id,
        date_of_birth: req.body.date_of_birth,
        country_id: req.body.country_id,
        // state_id: req.body.state_id,
        // city_id: req.body.city_id,
        zip_code: req.body.zip_code,
        full_address_1: req.body.full_address_1,
        // isactive: (req.body.isactive) ? req.body.isactive : 1,

        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    const schema = Joi.object().keys({
        comp_id: Joi.number().required(),
        firstname: Joi.string().required(),
        lastname: Joi.string().required(),
        userfullname: Joi.string().required(),
        contactnumber: Joi.string().pattern(/^[0-9]{10}$/).required(),
        business_unit_id: Joi.number().required(),
        company_id: Joi.number().required(),
        department_id: Joi.number().required(),
        designation_id: Joi.number().required(),
        jobgrade_id: Joi.number().required(),
        reporting_mngr_id: Joi.number().required(),
        date_of_birth: Joi.date().iso(),
        country_id: Joi.number(),
        // state_id: Joi.number(),
        // city_id: Joi.number(),
        zip_code: Joi.string().pattern(/^[0-9]{6}$/),
        full_address_1: Joi.string(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            var upd_user_details = {
                firstname: req.body.firstname,
                lastname: req.body.lastname,
                userfullname: req.body.firstname + " " + req.body.lastname,
                contactnumber: req.body.contactnumber,
                company_id: req.body.company_id,
                department_id: req.body.department_id,
                designation_id: req.body.designation_id,
                jobgrade_id: req.body.jobgrade_id,
                reporting_mngr_id: req.body.reporting_mngr_id,
                date_of_birth: req.body.date_of_birth,
                country_id: req.body.country_id,
                state_id: (req.body.state_id) ? req.body.state_id : null,
                city_id: (req.body.city_id) ? req.body.city_id : null,
                zip_code: req.body.zip_code,
                full_address_1: req.body.full_address_1,
                unit_id: req.body.business_unit_id,
                emp_role_id: req.body.role_id,
                modified_by: req.userId,
                updated_at: getCurrentDateTime(),
                isactive: (req.body.isactive == '0') ? req.body.isactive : 1
            }
            const update = await Users.update(upd_user_details, {
                where: { comp_id: req.comp_id, id: req.body.update_user_id }
            });

            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECUPDATED,
                error: false,
                success: true,
                status: '1',
            });

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const official_profile_update = async (req, res) => {
    const dataToValidate = {
        comp_id: req.comp_id,
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        userfullname: req.body.firstname + " " + req.body.lastname,
        emp_role_id: req.body.emp_role_id,
        email: req.body.email,
        unit_id: req.body.business_unit_id,
        reporting_mngr_id: req.body.reporting_mngr_id,
        company_id: req.body.company_id,
        department_id: req.body.department_id,
        jobgrade_id: req.body.jobgrade_id,
        designation_id: req.body.designation_id,
        user_status: req.body.user_status,
        isactive: req.body.isactive,
        contactnumber: req.body.contactnumber,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    const schema = Joi.object().keys({
        comp_id: Joi.number().required(),
        firstname: Joi.string().required(),
        lastname: Joi.string().required(),
        userfullname: Joi.string().required(),
        emp_role_id: Joi.number().required(),
        email: Joi.string().required(),
        contactnumber: Joi.string()
            .pattern(/^[0-9]{10}$/)
            .required(),
        unit_id: Joi.number().required(),
        company_id: Joi.number().required(),
        department_id: Joi.number().required(),
        designation_id: Joi.number().required(),
        jobgrade_id: Joi.number().required(),
        reporting_mngr_id: Joi.number().required(),
        user_status: Joi.number().allow(null),
        isactive: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {
        try {


            const emailExistCheck = await Users.findOne({
                where: {
                    id: { [Op.ne]: req.body.update_user_id },
                    comp_id: req.comp_id,
                    email: req.body.email,
                    isactive: 1
                },
                attributes: ['id']
            });

            const phoneExistCheck = await Users.findOne({
                where: {
                    id: { [Op.ne]: req.body.update_user_id },
                    comp_id: req.comp_id,
                    contactnumber: req.body.contactnumber,
                    isactive: 1
                },
                attributes: ['id']
            });

            if (emailExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: "Email already exists",
                    error: true,
                    success: false,
                    status: '0',
                });
            } else if (phoneExistCheck) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: "Contact number already exists",
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            if (req.body.is_left == "true") {
                dataToValidate.date_of_leaving = req.body.left_date;
            }

            const update = await Users.update(dataToValidate, {
                where: {
                    comp_id: req.comp_id,
                    id: req.body.update_user_id,
                },
            });

            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECUPDATED,
                error: false,
                success: true,
                status: "1",
            });



        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                err: error.message,
                error: true,
                success: false,
                status: "0",
            });
        }
    }
};

const personal_profile_update = async (req, res) => {
    const dataToValidate = {
        comp_id: req.comp_id,
        date_of_birth: req.body.date_of_birth,
        country_id: req.body.country_id,
        state_id: req.body.state_id,
        city_id: req.body.city_id,
        zip_code: req.body.zip_code,
        full_address_1: req.body.full_address_1,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    const schema = Joi.object().keys({
        comp_id: Joi.number().required(),
        date_of_birth: Joi.date().iso(),
        country_id: Joi.number(),
        state_id: Joi.number(),
        city_id: Joi.number(),
        zip_code: Joi.string().pattern(/^[0-9]{6}$/),
        full_address_1: Joi.string(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {
        try {


            const update = await Users.update(dataToValidate, {
                where: {
                    comp_id: req.comp_id,
                    id: req.body.update_user_id,
                },
            });

            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECUPDATED,
                error: false,
                success: true,
                status: "1",
            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                err: error.message,
                error: true,
                success: false,
                status: "0",
            });
        }
    }
};






//Single Data Get..
const userdetails = async (req, res) => {
    const schema = Joi.object().keys({
        user_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_id: req.body.user_id
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Users.findOne({
                where: { comp_id: req.comp_id, id: req.body.user_id },
                attributes: { exclude: ['emp_role_id'] },
                include: {
                    model: Role,
                    required: false,
                    attributes: ['id', 'role_name'],
                }
            });
            if (existData) {
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
            // res.status(400).send({ error: error.message });
        }
    }
}






const ListAllUsers = async (req, res) => {
    try {
        const response = await Users.findAll({
            order: [['id', 'DESC']],
            // isactive: '1',
            where: { comp_id: req.comp_id },
            include: [
                {
                    model: Role,
                    attributes: ['role_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: Businessunit,
                    attributes: ['unit_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: Company,
                    attributes: ['company_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: DepartmentModel,
                    attributes: ['department_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: Designation,
                    attributes: ['designation_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: JobGradeModel,
                    attributes: ['job_grade'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['userfullname'],
                    as: 'reporting_manager',
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['userfullname'],
                    as: 'createdby_username',
                    required: false,
                },
                {
                    model: Country,
                    attributes: ['country_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: State,
                    attributes: ['state_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: City,
                    attributes: ['city_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['userfullname'],
                    as: 'updatedby_username',
                    required: false,
                },

            ],

        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        }
        res.send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}

const userlogout = async (req, res) => {
    const schema = Joi.object().keys({
        user_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_id: req.userId,
        user_comp_id: req.comp_id
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const add_activity = {
                created_by: req.userId,
                user_comp_id: req.comp_id,
                activity: 'log_out',
                ip_address: req.body.ip_address,
                created_at: getCurrentDateTime()
            };
            const insert = await Useractivehistory.create(add_activity);
            if (insert) {
                res.send({
                    message: 'Logout successful',
                    error: false,
                    success: true,
                    status: '1',

                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }

}
const userhistory = async (req, res) => {
    const schema = Joi.object().keys({
        created_by: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        page_id: Joi.number().required(),
        page_activity: Joi.string().required(),
        ip_address: Joi.string().required()
    });

    const dataToValidate = {
        created_by: req.userId,
        user_comp_id: req.comp_id,
        page_id: req.body.page_id,
        page_activity: req.body.page_activity,
        ip_address: req.body.ip_address
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await PageMster.findOne({ where: { status: "1", id: req.body.page_id }, attributes: ['page_name'] });
            if (existData) {
                const dataadde = {
                    created_by: req.userId,
                    user_comp_id: req.comp_id,
                    page_title: existData.page_name,
                    page_activity: req.body.page_activity,
                    ip_address: req.body.ip_address
                };
                const insert = await Userhistory.create(dataadde);
                if (insert) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: false,
                        status: '1',
                    });
                }

            } else {
                res.status(process.env.APIRESPCODE_VALIDATION).send({
                    message: 'Page Not Found In Database',
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}
const tnderuserhistotry = async (req, res) => {
    const schema = Joi.object().keys({
        limit: Joi.string().required(),
        page_number: Joi.string().required(),
    });
    const dataToValidate = {
        limit: req.body.limit,
        page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {

            const page_number = parseInt(dataToValidate.page_number) || 1;
            const limit = parseInt(dataToValidate.limit) || 10;
            const offset = (parseInt(page_number) - 1) * parseInt(limit);
            const dateFilters = [];
            const dynamicFilters = [];
            if (req.body.scope_id) {
                const scopeId = req.body.scope_id;
                dynamicFilters.push({ cycle_id: scopeId });

            }
            if (req.body.from_date && req.body.to_date) {
                const startDate = req.body.from_date;
                const endDate = req.body.to_date;
                dateFilters.push(where(fn('DATE', col('created_at')), '>=', startDate));
                dateFilters.push(where(fn('DATE', col('created_at')), '<=', endDate));
            }
            const data_doc_history = await TenderDocModel.findAndCountAll({
                where: {
                    [Op.and]: [
                        { user_comp_id: req.comp_id, status: '1', created_by: req.userId }, // Additional filters can be added here
                        ...dateFilters, // Include the dynamic date range condition
                    ],
                },
                attributes: ['file_name', 'tender_id', 'created_at'],
                offset,
                limit,
                include: [
                    {
                        model: TenderModel,
                        attributes: [['id', 'project_id'], 'tender_name', 'tender_cost', 'tender_emd_amnt_val', 'submission_start_date', 'submission_end_date'], // Add the attributes you want from TenderDetailsModel
                        required: false,
                        include: [{
                            model: Country,
                            attributes: ['country_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: State,
                            attributes: ['state_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: City,
                            attributes: ['city_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: Tendersector,
                            attributes: ['sector_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: TenderClient,
                            attributes: ['client_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        ]

                    }],
            });
            const last_login_rec = await Users.findOne({
                where: { id: req.userId, isactive: '1' },
                attributes: ['last_login'],
            })


            const login_history = await Useractivehistory.findAll({
                where: {
                    [Op.and]: [
                        { user_comp_id: req.comp_id, status: '1', created_by: req.userId }, // Additional filters can be added here
                        ...dateFilters, // Include the dynamic date range condition
                    ],
                },
                attributes: ['activity', 'created_at'],
                offset,
                limit,
            });

            const activate_data = await Userhistory.findAll({
                where: {
                    [Op.and]: [
                        { user_comp_id: req.comp_id, status: '1', created_by: req.userId }, // Additional filters can be added here
                        ...dateFilters, // Include the dynamic date range condition
                    ],
                },
                attributes: ['page_activity', 'page_title', 'created_at'],
                offset,
                limit,
            });
            const data = await TenderMovedHistroyByUserModel.findAndCountAll({
                where: {
                    [Op.and]: [
                        { user_comp_id: req.comp_id, status: '1', created_by: req.userId }, // Additional filters can be added here
                        ...dateFilters, // Include the dynamic date range condition
                        ...dynamicFilters
                    ],
                },
                attributes: ['cycle_id'],
                offset,
                limit,
                include: [
                    {
                        model: TenderModel,
                        attributes: [['id', 'project_id'], 'tender_name', 'tender_cost', 'tender_emd_amnt_val', 'submission_start_date', 'submission_end_date'], // Add the attributes you want from TenderDetailsModel
                        required: false,
                        include: [{
                            model: Country,
                            attributes: ['country_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: State,
                            attributes: ['state_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: City,
                            attributes: ['city_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: Tendersector,
                            attributes: ['sector_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: TenderClient,
                            attributes: ['client_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        ]

                    }],
            })
            if ((data.rows) || (data_doc_history) || (activate_data.rows) || (login_history) || (last_login_rec.last_login)) {
                const response_data = {
                    last_login: last_login_rec,
                    login_history: login_history,
                    user_activate: activate_data,
                    move_history: data,
                    document_history: data_doc_history,
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response_data,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',

            });
        }
    }
}


const checkOldpassword = async (req, res) => {
    const schema = Joi.object().keys({
        old_password: Joi.string().required(),
    });
    const dataToValidate = {
        old_password: req.body.old_password,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const response = await Users.findOne({
                where: { comp_id: req.comp_id, id: req.userId, password: md5(req.body.old_password), isactive: '1' },
                attributes: ['id'],
            });
            if (response) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                });

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',

            });
        }

    }
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'profile';
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        //console.log("Ash :- "+extension);
        cb(null, Date.now() + '_Profile_img_' + file.originalname);
        req.extension = extension;
        // cb(null, Date.now() + 'Profile_' + Math.random() + extension); // Rename file with a timestamp
    },
});



//Update By Id Role..
const upload = multer({ storage: storage });
const userprofile_update = async (req, res) => {
    upload.single('profileimg')(req, res, async function (err) {
        // if (err) {
        //     return res.status(400).send({ error: err.message });
        // }
        const files = req.file;
        try {
            if (files) {
                var upd_user_details = {
                    profileimg: req.file.filename,
                    profileimg_path: files.destination,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                console.log(upd_user_details);
                const update = await Users.update(upd_user_details, {
                    where: { isactive: "1", comp_id: req.comp_id, id: req.userId }
                });


            }
            const response = await Users.findOne({
                where: { isactive: "1", isactive: "1", comp_id: req.comp_id, id: req.userId }, attributes: ['id', 'profileimg', 'profileimg_path']
            }
            );

            if (response) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }




        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    });

}




const userprofile_pic_update = async (req, res) => {
    upload.array('files')(req, res, async function (err) {
        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }

        const schema = Joi.object().keys({
            user_id: Joi.number().required(),
            created_by: Joi.number().integer().required(),
            created_at: Joi.date().iso().required(),
            user_comp_id: Joi.number().integer().required()
        });

        const dataToValidate = {
            user_id: req.body.user_id,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
            user_comp_id: req.comp_id
        };

        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
            });
        } else {
            try {
                const files = req.files;
                if (files[0]) {
                    const originalFolderPath = files[0].destination;
                    const ProfileResp = await Users.findOne({
                        where: { id: req.body.user_id, isactive: "1", comp_id: req.comp_id }, attributes: ['id']
                    });

                    if (ProfileResp.id) {
                        const ProfilePicUpdObj = {
                            profileimg: files[0].filename,
                            profileimg_path: originalFolderPath,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const update_profilepic = await Users.update(ProfilePicUpdObj, {
                            where: { id: req.body.user_id, isactive: "1", comp_id: req.comp_id },
                        });

                        if (update_profilepic) {
                            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: 'Profile Updated.',
                                error: false,
                                success: true,
                                status: '1',
                            });
                        } else {
                            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                message: process.env.ERROR_MSG,
                                error: true,
                                success: false,
                                status: '0',
                            })
                        }

                    } else {
                        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                            message: 'Invalid user_id',
                            error: true,
                            success: false,
                            status: '0',
                        })
                    }
                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: 'File Validation Error',
                        error: true,
                        success: false,
                        status: '0',
                    })
                }

            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                })
            }
        }
    });
}



const check_user_old_password = async (req, res) => {
    const schema = Joi.object().keys({
        user_id: Joi.number().required(),
        old_password: Joi.string().required(),
    });

    const dataToValidate = {
        user_id: req.body.user_id,
        old_password: req.body.old_password,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const response = await Users.findOne({
                where: { comp_id: req.comp_id, id: req.body.user_id, password: md5(req.body.old_password), isactive: '1' },
                attributes: ['id'],
            });
            if (response) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                });

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }

}




//Change Password..
const user_change_password = async (req, res) => {
    const schema = Joi.object().keys({
        user_id: Joi.number().required(),
        password: Joi.string().required(),
    });

    const dataToValidate = {
        user_id: req.body.user_id,
        password: req.body.password,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            //console.log(dataToValidate, 'dataToValidatedataToValidate', req.userId);
            const user = await Users.update({
                password: md5(req.body.password), modified_by: req.userId, updated_at: getCurrentDateTime(),
            }, { where: { comp_id: req.comp_id, id: req.body.user_id } });
            if (!user[0]) {
                return res.status(400).send({
                    message: 'something went wrong',
                    error: true,
                    success: false,
                    status: '0',
                });
            }
            res.send({
                message: 'Password has been changed successfully.',
                error: false,
                success: true,
                status: '1',
                data: user,
            });
        } catch (error) {
            res.status(400).send({ error: error.message });
        }
    }
};





module.exports = {
    userlogin, userdetails, userdetails_update, changepassword, useradd, ListAllUsers, userlogout, userhistory,
    tnderuserhistotry, checkOldpassword, userprofile_update, userprofile_pic_update, check_user_old_password, user_change_password,
    official_profile_update, personal_profile_update
};
