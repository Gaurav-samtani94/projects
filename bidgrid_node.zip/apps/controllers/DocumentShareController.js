const Joi = require('joi');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const url = require('url')
const { Sequelize, DataTypes, where, Op, fn, col, literal } = require('sequelize');
const DocumentShareModel = require('../models/DocumentShareModel');
const DocumentSizeHandleModel = require('../models/DocumentSizeHandleModel');
const getCurrentDateTime = () => new Date();
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'docShare';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;

    },
});
const upload = multer({ storage: storage });

// Document share 
const documentShare = async (req, res) => {
    upload.single('files')(req, res, async function (err) {
        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: err.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        } else {
            const schema = Joi.object().keys({
                doc_expiry_days: Joi.number().required(),
                created_by: Joi.number().integer().required(),
                created_at: Joi.date().iso().required(),
                user_comp_id: Joi.number().integer().required()
            });

            const schema2 = Joi.object().keys({
                title: Joi.string().required(),
                message: Joi.string().required(),
            });

            const dataToValidate = {
                doc_expiry_days: 7,
                created_by: req.userId,
                created_at: getCurrentDateTime(),
                user_comp_id: req.comp_id
            };

            const dataValidation = {
                title: req.body.title,
                message: req.body.message
            }

            const result = schema.validate(dataToValidate);
            if (req.body.mailIds) {
                const resValidation = schema2.validate(dataValidation);
                const result2 = (resValidation.error) ? resValidation.error.details[0].message : "";
                if (result2 != "") {
                    return res.status(process.env.APIRESPCODE_VALIDATION).send({
                        error: true,
                        success: false,
                        status: '0',
                        message: result2
                    });
                }
            }

            if (result.error) {
                res.status(process.env.APIRESPCODE_VALIDATION).send({
                    error: true,
                    success: false,
                    status: '0',
                    message: result.error.details[0].message
                });
            } else {
                try {
                    const files = req.file;
                    
                    const folderPath = files.destination;
                    // console.log(req.body.mailIds)
                    console.log("testingggggggg");
                    if ((!req.body.mailIds) && (req.body.get_link) && req.body.get_link == 1) {
                        const fileRecords = await DocumentShareModel.create(
                            {
                                created_by: req.userId, user_comp_id: req.comp_id, to_email: "", all_emails: "", title: "",
                                message: "", doc_expiry_days: 7, doc_filename: files.filename,
                                doc_path: folderPath, doc_size: (files.size / 1024), created_at: getCurrentDateTime()
                            }
                        );
                        if (!fileRecords) {
                            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                message: process.env.ERROR_MSG,
                                error: true,
                                success: false,
                                status: '0',
                            })
                        }
                        // const docDownloadLink = "https://web.growthgrids.com/api/user/document-download/" + fileRecords.id;
                        const docDownloadLink = process.env.DOCUMENT_SHARE_URL;
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',
                            link: (docDownloadLink) ? docDownloadLink + folderPath + '/' + files.filename : "-"
                        });

                    } else if ((req.body.mailIds) && req.body.mailIds.length > 0 && !req.body.get_link) {
                        const all_mail_ids = req.body.mailIds.join(',');
                        const fileRecords = await DocumentShareModel.bulkCreate(req.body.mailIds.map((mailId) => (
                            {
                                created_by: req.userId, user_comp_id: req.comp_id, to_email: mailId, all_emails: all_mail_ids, title: req.body.title,
                                message: req.body.message, doc_expiry_days: 7, doc_filename: files.filename,
                                doc_path: folderPath, doc_size: (files.size / 1024), created_at: getCurrentDateTime()
                            }
                        )));
                        if (!fileRecords[0]) {
                            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                message: process.env.ERROR_MSG,
                                error: true,
                                success: false,
                                status: '0',
                            })
                        }
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    } else {
                        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                            message: process.env.ERROR_MSG,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    }


                    // const docPath = [];
                    // const docFilename = [];
                    // const insertedId = [];
                    // await Promise.all(fileRecords.map(async (data) => {
                    //         docPath.push(data.doc_path);
                    //         docFilename.push(data.doc_filename);
                    //         insertedId.push(data.id);
                    //     }))




                    // if(req.body.get_link == 1 && req.body.mailIds.length < 1){
                    //     console.log(req.body.get_link)
                    //     const docDownloadLink = "http://localhost:3005/api/user/document-download/"+fileRecords[0].id;
                    //     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    //         message: process.env.APIRESPMSG_RECINSERTED,
                    //         error: false,
                    //         success: true,
                    //         status: '1',
                    //         link: (docDownloadLink) ? docDownloadLink : "-"
                    //     });
                    // }else if(req.body.mailIds.length > 0 && req.body.get_link != 1){
                    //     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    //         message: process.env.APIRESPMSG_RECINSERTED,
                    //         error: false,
                    //         success: true,
                    //         status: '1',
                    //     });
                    // }

                    // const mailSent = sendMail_template(insertedId, req.body.mailIds);
                    // if(mailSent){
                    //     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    //         message: process.env.APIRESPMSG_RECINSERTED,
                    //         error: false,
                    //         success: true,
                    //         status: '1',
                    //     });
                    // }else{
                    //     return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    //         message: process.env.ERROR_MSG,
                    //         error: true,
                    //         success: false,
                    //         status: '0',
                    //     });
                    // }

                } catch (error) {
                    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                        message: process.env.ERROR_MSG,
                        // message: error.message,
                        error: true,
                        success: false,
                        status: '0',
                    })
                }
            }

        }

    });
}


//get document share list
const docSharedlist = async (req, res) => {
    const schema = Joi.object().keys({
        user_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_id: req.body.user_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {

        const dateFilters = [];
        if (req.body.start_date && req.body.end_date) {
            const start_doc = req.body.start_date;
            const end_date = req.body.end_date;
            dateFilters.push(
                {
                    [Op.and]: [
                        literal(`DATE_FORMAT(created_at, '%Y-%m-%d') >= '${start_doc}'`),
                    ],
                    [Op.and]: [
                        literal(`DATE_FORMAT(created_at, '%Y-%m-%d') <= '${end_date}'`)
                    ],
                }
            )
        }
        // const docDownloadLink = "https://web.growthgrids.com/api/user/document-download/";
        const docDownloadLink = "https://web.growthgrids.com/";

        const list = await DocumentShareModel.findAll({
            order: [['id', 'DESC']],
            group: ['doc_filename'],
            where: {
                [Op.and]: [
                    { user_comp_id: req.comp_id, created_by: req.body.user_id, status: '1' }, // Additional filters can be added here
                    ...dateFilters, // Include the dynamic date range condition
                ],
            },
            attributes: ['id', 'created_at', 'to_email', 'title', 'all_emails', 'message', 'doc_expiry_days', 'doc_path', 'doc_filename', 'doc_size']
        });
        try {
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    basepath: docDownloadLink,
                    data: list
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}



// const documentShare = async (req, res) => {
//     upload.array('files')(req, res, async function (err) {
//         if (err) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             })
//         }else{
//             const schema = Joi.object().keys({
//                 // userIds: Joi.number().required(),
//                 userIds: Joi.array().items(Joi.string()).required(),
//                 // to_email: Joi.string().required(),
//                 title: Joi.string().required(),
//                 message: Joi.string().required(),
//                 doc_expiry_days: Joi.number().required(),
//                 created_by: Joi.number().integer().required(),
//                 created_at: Joi.date().iso().required(),
//                 user_comp_id: Joi.number().integer().required()
//             });

//             const dataToValidate = {
//                 userIds: req.body.userIds,
//                 // to_email: req.body.to_email,
//                 title: req.body.title,
//                 message: req.body.message,
//                 doc_expiry_days: req.body.doc_expiry_days,
//                 created_by: req.userId,
//                 created_at:  getCurrentDateTime(),
//                 user_comp_id: req.comp_id
//             };

//             const result = schema.validate(dataToValidate);
//             if (result.error) {
//                 res.status(process.env.APIRESPCODE_VALIDATION).send({
//                     error: true,
//                     success: false,
//                     status: '0',
//                     message: result.error.details[0].message
//                 });
//             } else {
//                 try {
//                     const files = req.files;
//                     console.log(files, 'filesfiles')
//                     if (files.length != 0) {
//                         const docSize = await DocumentSizeHandleModel.findOne({
//                             where: { status: '1', user_comp_id: req.comp_id }
//                         });
//                         if(docSize.get('doc_size_count') < docSize.get('doc_size_limit')){
//                             const fromEmail = await Users.findOne({
//                                 where: { isactive: '1', id: req.userId }
//                             });

//                             const toEmailArr = await Users.findAll({
//                                 attributes:['id','email']
//                                 ,where: {
//                                     id: {
//                                     [Op.in]: req.body.userIds
//                                   }},
//                             });
//                             const toUsers = req.body.userIds.join(",")
//                             const folderPath = files[0].destination;
//                             const fileRecords = await DocumentShareModel.bulkCreate(files.map((file) => ({ created_by: req.userId,
//                                  user_comp_id: req.comp_id, from_email: fromEmail.email, to_users: toUsers, title: req.body.title,
//                                   message: req.body.message, doc_expiry_days: req.body.doc_expiry_days, doc_filename: file.filename,
//                                    doc_path: folderPath, doc_size: (file.size/1024), created_at:  getCurrentDateTime() })));

//                             const docPath = [];
//                             const docFilename = [];
//                             const insertedId = [];
//                             if (fileRecords) {
//                                 await Promise.all(fileRecords.map(async (data) => {
//                                     docPath.push(data.doc_path);
//                                     docFilename.push(data.doc_filename);
//                                     insertedId.push(data.id);
//                                 }))
//                             }

//                             if (!fileRecords[0]) {
//                                 res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                                     message: process.env.ERROR_MSG,
//                                     error: true,
//                                     success: false,
//                                     status: '0',
//                                 })
//                             } else{
//                                 const mailSent = sendMail_template(insertedId, toEmailArr);
//                                 if(mailSent){
//                                     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                                         message: process.env.APIRESPMSG_RECINSERTED,
//                                         error: false,
//                                         success: true,
//                                         status: '1',
//                                     });
//                                 }else{
//                                     return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                                         message: process.env.ERROR_MSG,
//                                         error: true,
//                                         success: false,
//                                         status: '0',
//                                     });
//                                 }
//                             }
//                         }else{
//                             return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                                 message: process.env.DOCUMENT_SIZE_LIMIT_OVER,
//                                 error: true,
//                                 success: false,
//                                 status: '0',
//                             });
//                         }

//                     }else{
//                         res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                             message: process.env.FILE_NOT_FOUND,
//                             error: true,
//                             success: false,
//                             status: '0',
//                         });
//                     }
//                 } catch (error) {
//                     res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                         message: process.env.ERROR_MSG,
//                         error: error.message,
//                         success: false,
//                         status: '0',
//                     })
//                 }
//             }

//         }

//     });
// }


const { sendDynamicEmail, sendEmailWith_temp } = require('../config/mail');
const Users = require('../models/Users');

const attachmentDownload = async (req, res) => {
    try {
        const response = await DocumentShareModel.findOne({
            where: { status: '1', id: req.params.id }
        });
        const currentDayOfMonth = getCurrentDateTime().getDate();
        const currentMonth = getCurrentDateTime().getMonth(); // Be careful! January is 0, not 1
        const currentYear = getCurrentDateTime().getFullYear();
        // const getCurrentDateTime() = (currentMonth + 1) + "/" + currentDayOfMonth + "/" + currentYear;

        const createdDayOfMonth = response.get('created_at').getDate();
        const createdMonth = response.get('created_at').getMonth(); // Be careful! January is 0, not 1
        const createdYear = response.get('created_at').getFullYear();
        const createdDate = (createdMonth + 1) + "/" + createdDayOfMonth + "/" + createdYear;

        // const dateCreated = new Date(createdDate);
        // const dateCurrent = new Date(getCurrentDateTime());

        const Difference_In_Time = dateCurrent.getTime() - dateCreated.getTime();
        var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
        const filePath = response.get('doc_path') + '/' + response.get('doc_filename');

        if (Difference_In_Days < response.get('doc_expiry_days')) {
            res.setHeader('Content-disposition', 'attachment; filename=' + path.basename(filePath));
            res.setHeader('Content-type', 'application/octet-stream');
            const fileStream = fs.createReadStream(filePath);  // Use the corrected file path
            fileStream.pipe(res);
        } else {
            res.sendFile(path.join(__dirname, '../../link_expire.html'));
        }
        // if (fs.existsSync(filePath)) 
        // {
        // res.setHeader('Content-disposition', 'attachment; filename=' + path.basename(filePath));
        // res.setHeader('Content-type', 'application/octet-stream');
        // const fileStream = fs.createReadStream(filePath);  // Use the corrected file path
        // fileStream.pipe(res);

        // } else {
        //     console.error('File does not exist:', filePath);
        // }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

    }
}

function sendMail_template(insertedId, toEmailArr) {
    const dynamicData = {
        // subject: 'Document Shared by ',
        // fileRecords:subject1,
        body: 'Dynasssssmic Body of the Email',
        link: insertedId,
    };
    const templatePath = path.join(__dirname, '../emailtemplates/DocShareEmailTemplate.hbs');
    // console.log("to email", toEmailArr)
    const response = toEmailArr.map((toEmailAdd) =>
        sendEmailWith_temp(
            toEmailAdd.email,
            "new subject",
            // 'Dynamic Body of the Email',
            null,
            templatePath,
            dynamicData
        )
    );

    if (!response) {
        return false;
    }
    return true


}

module.exports = {
    documentShare, sendMail_template, attachmentDownload, docSharedlist
}; 