require('dotenv').config();
const Joi = require('joi');
const getCurrentDateTime = () => new Date();
const DoctrolFolder = require('../../models/doctrol/Doctrol');
const DoctrolModel = require('../../models/doctrol/Maindoctrol');
const { Op } = require('sequelize');
const path = require('path')
const multer = require('multer');
const fs = require('fs');
const DoctrolAdd = async (req, res) => {
    const schema = Joi.object().keys({
        folder_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        folder_name: req.body.folder_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const existence_bg_bank = await DoctrolFolder.findOne({ where: { user_comp_id: req.comp_id, folder_name: req.body.folder_name, status: '1' }, attributes: ['id'] })
            if (!existence_bg_bank) {
                const insert = await DoctrolFolder.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const DoctrolEdit = async (req, res) => {
    const schema = Joi.object().keys({
        folder_id: Joi.number().required(),
    });

    const dataToValidate = {
        folder_id: req.body.folder_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editbgbank = await DoctrolFolder.findOne({
                where: { id: req.body.folder_id, user_comp_id: req.comp_id }, attributes: ['id', 'folder_name'],
            })
            if (!editbgbank) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editbgbank,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


const UpdateDoctrol = async (req, res) => {
    const schema = Joi.object().keys({
        folder_id: Joi.number().required(),
        folder_name: Joi.string().required(),
        updated_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        folder_id: req.body.folder_id,
        folder_name: req.body.folder_name,
        updated_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const bgbank = await DoctrolFolder.findOne({ where: { user_comp_id: req.comp_id, id: req.body.folder_id, status: '1' }, attributes: ['id'] })
            if (bgbank) {
                const existData_upd = await DoctrolFolder.findOne({
                    where: {
                        status: "1", user_comp_id: req.comp_id, folder_name: req.body.folder_name, id: {
                            [Op.ne]: req.body.folder_id
                        }
                    }, attributes: ['id']
                });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const bg_update_obj = {
                    folder_name: req.body.folder_name,
                    updated_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update_bg = await DoctrolFolder.update(bg_update_obj, {
                    where: { status: "1", id: req.body.folder_id, user_comp_id: req.comp_id },
                });
                if (update_bg) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

const doctrolFolderDelete = async (req, res) => {
    const schema = Joi.object().keys({
        folder_id: Joi.number().required(),
        updated_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        folder_id: req.body.folder_id,
        updated_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletefolder = await DoctrolFolder.findOne({ where: { id: req.body.folder_id, status: '1', user_comp_id: req.comp_id, deletable: '1' } })
            if (deletefolder) {
                const bg_fldr_update_obj = {
                    status: '0',
                    updated_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const bg_fldr_update = await DoctrolFolder.update(bg_fldr_update_obj, {
                    where: {
                        id: req.body.folder_id,
                        user_comp_id: req.comp_id,
                        status: '1',
                        deletable: '1'
                    },
                });
                if (bg_fldr_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

const doctrolFolderList = async (req, res) => {
    const list = await DoctrolFolder.findAll({
        where: {
            status: "1",
            user_comp_id: req.comp_id,
        },
        attributes: ['id', 'folder_name', 'deletable']
    });
    try {
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const DoctrolmainList = async (req, res) => {
    const dataToValidate = {
        folder_id: req.body.folder_id,
    };
    const schema = Joi.object().keys({
        folder_id: Joi.number().required(),
    });
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const list = await DoctrolModel.findAll({
            where: {
                status: "1",
                user_comp_id: req.comp_id,
                doctrol_id: req.body.folder_id
            },
            attributes: ['id', 'file_name', 'category', 'doctrol_id', 'size', 'exten', 'path']
        });
        try {
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'doctrol/';
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + 'doctrol_' + Math.random() + extension); // Rename file with a timestamp
    },
});
const doc_upload = multer({ storage: storage });
const DoctrolmainAdd = async (req, res) => {
    doc_upload.array('doctrol_doc')(req, res, async function (err) {
        console.log(req.body.doctrol_id);
        const schema = Joi.object().keys({
            doctrol_id: Joi.number().required(),
        });

        const dataToValidate = {
            doctrol_id: req.body.doctrol_id,
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        } else {
            try {
                const files = req.files;
                if (files[0]) {
                    const originalFolderPath = files[0].destination;
                    const fileRecords = await DoctrolModel.bulkCreate(files.map((file) =>
                    ({
                        created_by: req.userId, user_comp_id: req.comp_id, doctrol_id: req.body.doctrol_id,
                        file_name: file.filename, created_at: getCurrentDateTime(), path: originalFolderPath, size: (file.size / (1024 * 1024)).toFixed(2), exten: path.extname(file.filename),
                    })));
                    if (fileRecords.length > 0) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: `${fileRecords.length} records inserted successfully`,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    }
                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.ERROR_MSG,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                });
            }
        }
    })
}

const DoctrolmainDelete = async (req, res) => {

    const schema = Joi.object().keys({
        file_id: Joi.number().required(),
    });

    const dataToValidate = {
        file_id: req.body.file_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const fileRecord = await DoctrolModel.findOne({ where: { id: req.body.file_id, status: '1', user_comp_id: req.comp_id, created_by: req.userId } });
            if (!fileRecord) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'You Have Not Permission To Delete',
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                // const filePath = path.join('uploads/public' + '_' + req.comp_id + '/', 'doctrol/', fileRecord.document);
                // fs.unlinkSync(filePath);
                await DoctrolModel.update({
                    status: '0',
                    updated_at: getCurrentDateTime(),
                    updated_by: req.userId,
                }, {
                    where: {
                        id: req.body.file_id, status: '1', user_comp_id: req.comp_id, created_by: req.userId,
                    },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });

            }
        } catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}



// const DoctrolmainUpdate = async (req, res) => {
//     doc_upload.single('doctrol_doc')(req, res, async function (err) {

//         const schema = Joi.object().keys({
//             file_id: Joi.number().required(),
//             doctrol_id: Joi.number().required(),
//         });

//         const dataToValidate = {
//             file_id: req.body.file_id,
//             doctrol_id: req.body.folder_id,
//         };

//         const result = schema.validate(dataToValidate);
//         if (result.error) {
//             return res.status(process.env.APIRESPCODE_VALIDATION).send({
//                 message: result.error.details[0].message,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         } else {
//             try {
//                 const fileRecord = await DoctrolModel.findOne({ where: { id: req.body.file_id, status: '1', user_comp_id: req.userId } });
//                 if (!fileRecord) {
//                     return res.status(process.env.APIRESPCODE_NOT_FOUND).send({
//                         message: process.env.APIRESPCODE_NOT_FOUND,
//                         error: true,
//                         success: false,
//                         status: '0',
//                     });
//                 }
//                 const updatedRecord = await DoctrolModel.update({
//                     where: {
//                         doctrol_id: req.body.folder_id,
//                         updated_at: getCurrentDateTime(),
//                         updated_by: req.comp_id
//                     }
//                 });
//                 return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                     message: 'Record updated successfully',
//                     error: false,
//                     success: true,
//                     status: '1',
//                     data: updatedRecord,
//                 });
//             } catch (error) {
//                 console.error('Error:', error);
//                 return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                     message: 'Something went wrong. Please try again later',
//                     error: error.message,
//                     success: false,
//                     status: '0',
//                 });
//             }
//         }
//     });
// };

module.exports = {
    doctrolFolderList,
    doctrolFolderDelete,
    DoctrolAdd,
    DoctrolEdit,
    UpdateDoctrol,
    DoctrolmainList,
    DoctrolmainAdd,
    DoctrolmainDelete,
    // DoctrolmainUpdate
};    
