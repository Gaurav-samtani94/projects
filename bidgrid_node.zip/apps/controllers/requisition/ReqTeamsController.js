
const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Joi = require('joi');
require('dotenv').config();
const ReqCategoryModel = require('../../../apps/models/requisition/ReqCategoryModel');
const ReqDesignationModel = require('../../../apps/models/requisition/ReqDesignationModel');
const TeamNotiationMemberModel = require('../../models/requisition/TeamNotiationMemberModel');

const ReqNegotiationTeamsModel = require('../../models/requisition/ReqNegotiationTeams');
const multer = require('multer');
const getCurrentDateTime = () => new Date();
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { get } = require('http');


const storage = multer.diskStorage({

    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'reqteams';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        //console.log("Ash :- "+extension);
        cb(null, Date.now() + 'reqteams' + Math.random() + extension); // Rename file with a timestamp
    },
});

//Update By Id Role..
const upload = multer({ storage: storage }); // Initialize Multer

const addReqTeams = async (req, res) => {
    upload.single('can_resume')(req, res, async function (err) {
        if (err) {
            return res.status(400).send({ error: err.message });
        }
        const dataToValidate = {
            project_id: req.body.project_id,
            designation_id: req.body.designation_id,
            tm_rq_members_id: req.body.tm_rq_members_id,
            category_id: req.body.category_id,
            fullname: req.body.fullname,
            date_of_birth: req.body.date_of_birth,
            working_exp: req.body.working_exp,
            remarks: req.body.remarks,
        };
        const schema = Joi.object().keys({
            project_id: Joi.number().required(),
            designation_id: Joi.number().required(),
            tm_rq_members_id: Joi.number().required(),
            category_id: Joi.number().required(),
            fullname: Joi.string().required(),
            date_of_birth: Joi.date().required(),
            working_exp: Joi.number().required(),
            remarks: Joi.string().required(),

        });

        const result = schema.validate(dataToValidate);
        if (result.error) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        }

        try {
            if (req.file) { // Corrected variable name from `files` to `file`
                var add_team_details = {
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                    designation_id: req.body.designation_id,
                    fullname: req.body.fullname,
                    date_of_birth: req.body.date_of_birth,
                    working_exp: req.body.working_exp,
                    can_resume: req.file.filename,
                    file_path: req.file.destination,
                    remarks: req.body.remarks,
                    created_by: req.userId,
                    created_at: getCurrentDateTime(),
                    tm_rq_members_id: req.body.tm_rq_members_id,
                    category_id: req.body.category_id,
                }
            } else {
                var add_team_details = {
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                    designation_id: req.body.designation_id,
                    fullname: req.body.fullname,
                    date_of_birth: req.body.date_of_birth,
                    working_exp: req.body.working_exp,
                    remarks: req.body.remarks,
                    created_by: req.userId,
                    created_at: getCurrentDateTime(),
                    tm_rq_members_id: req.body.tm_rq_members_id,
                    category_id: req.body.category_id,
                }
            }

            const alreadyApprove = await ReqNegotiationTeamsModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                    designation_id: req.body.designation_id,
                    category_id: req.body.category_id,
                    curr_status: '1',
                    status: '1',
                }
            })

            if (alreadyApprove) {
                return res.status(process.env.APIRESPCODE_VALIDATION).send({
                    message: 'Record on this project for this designation and category is already approved',
                    error: true,
                    success: false,
                    status: '0'
                })
            }



            const alreadyExists = await ReqNegotiationTeamsModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                    designation_id: req.body.designation_id,
                    tm_rq_members_id: req.body.tm_rq_members_id,
                    category_id: req.body.category_id,
                    curr_status: '1',

                }
            })


            if (alreadyExists) {
                return res.status(process.env.APIRESPCODE_VALIDATION).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

            const team = await ReqNegotiationTeamsModel.create(add_team_details);
            if (team) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: team // Corrected variable name from `insert` to `mom`
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
                text: error.message
            });
        }
    });
}



const getTeams = async (req, res) => {

    try {
        const teams = await ReqNegotiationTeamsModel.findAll({
            where: {
                user_comp_id: req.comp_id,
                status: '1'
            }
        })
        if (!teams) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            })
        }

        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            data: teams
        })

    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            er: error.message,
            error: true,
            success: false,
            status: '0'
        })

    }

}


const editTeams = async (req, res) => {

    const schema = Joi.object().keys({
        id: Joi.number().required(),
        project_id: Joi.number().required()


    });
    const dataToValidate = {
        id: req.body.team_id,
        project_id: req.body.project_id

    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message


        });
    }

    try {
        const teams = await ReqNegotiationTeamsModel.findOne({
            where: {
                user_comp_id: req.comp_id,
                id: req.body.team_id,
                project_id: req.body.project_id,
                status: '1'
            }
        })
        if (!teams) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            })
        }

        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            data: teams
        })

    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
            msg: error.message
        })

    }

}


const updateReqTeams = async (req, res) => {
    upload.single('can_resume')(req, res, async function (err) {
        if (err) {
            return res.status(400).send({ error: err.message });
        }

        const team_id = req.body.team_id
        const fullname = req.body.fullname
        const date_of_birth = req.body.date_of_birth
        const working_exp = req.body.working_exp
        const remarks = req.body.remarks
        const curr_status = req.body.curr_status
        const project_id = req.body.project_id
        const tm_rq_members_id = req.body.tm_rq_members_id
        const category_id = req.body.category_id
        const designation_id = req.body.designation_id
        let updateFields = false

        if (fullname || date_of_birth || working_exp || remarks || curr_status || project_id || tm_rq_members_id || category_id || designation_id) {
            updateFields = true
        }

        const dataToValidate = {
            team_id, fullname, date_of_birth, working_exp, remarks, curr_status
        };
        const schema = Joi.object().keys({
            team_id: Joi.number().required(),
            fullname: Joi.string(),
            date_of_birth: Joi.date(),
            working_exp: Joi.number(),
            remarks: Joi.string(),
            curr_status: Joi.number(),
            project_id: Joi.number(),
            tm_rq_members_id: Joi.number(),
            category_id: Joi.number(),
            designation_id: Joi.number(),


        });

        const result = schema.validate(dataToValidate);
        if (result.error) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        }



        if (!updateFields) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: 'Plase input fileds to update',
                error: true,
                success: false,
                status: '0',
            });

        }

        try {
            if (req.file) { // Corrected variable name from `files` to `file`
                var update_team_details = {
                    fullname: req.body.fullname,
                    date_of_birth: req.body.date_of_birth,
                    working_exp: req.body.working_exp,
                    can_resume: req.file.filename,
                    file_path: req.file.destination,
                    remarks: req.body.remarks,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                    project_id,
                    designation_id,
                    tm_rq_members_id,
                    category_id,

                }
            } else {
                var update_team_details = {
                    fullname: req.body.fullname,
                    date_of_birth: req.body.date_of_birth,
                    working_exp: req.body.working_exp,
                    remarks: req.body.remarks,
                    curr_status,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                    project_id,
                    designation_id,
                    tm_rq_members_id,
                    category_id,
                }
            }

            const teamExists = await ReqNegotiationTeamsModel.findOne({
                where: {
                    id: req.body.team_id,
                    user_comp_id: req.comp_id,
                    status: '1'
                }
            })

            if (!teamExists) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

            console.log(teamExists)

            const alreadyApprove = await ReqNegotiationTeamsModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    project_id: teamExists.project_id,
                    designation_id: teamExists.designation_id,
                    category_id: teamExists.category_id,
                    curr_status: '1',
                    status: '1',
                }
            })    

                if (alreadyApprove) {
                    return res.status(process.env.APIRESPCODE_VALIDATION).send({
                        message: 'Record on this project for this designation and category is already approved',
                        error: true,
                        success: false,
                        status: '0'
                    })
                }

            const team = await ReqNegotiationTeamsModel.update(update_team_details, {
                where: {
                    id: req.body.team_id,
                    user_comp_id: req.comp_id,
                    status: '1'
                }

            })
            if (team) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
                text: error.message
            });
        }
    });
}

const deleteReqTeams = async (req, res) => {
    const dataToValidate = {
        team_id: req.body.team_id,
    };
    const schema = Joi.object().keys({
        team_id: Joi.number().required(),
    });

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    }


    try {
        const teamExists = await ReqNegotiationTeamsModel.findOne({
            where: {
                id: req.body.team_id,
                user_comp_id: req.comp_id,
                status: '1'
            }
        })

        if (!teamExists) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        const alreadyApprove = await ReqNegotiationTeamsModel.findOne({
            where: {
                user_comp_id: req.comp_id,
                project_id: teamExists.project_id,
                designation_id: teamExists.designation_id,
                category_id: teamExists.category_id,
                curr_status: '1',
                status: '1',
            }
        })    

            if (alreadyApprove) {
                return res.status(process.env.APIRESPCODE_VALIDATION).send({
                    message: 'Record on this project for this designation and category is already approved',
                    error: true,
                    success: false,
                    status: '0'
                })
            }

        const update_team_details = {
            status: '0'
        }

        const team = await ReqNegotiationTeamsModel.update(update_team_details, {
            where: {
                id: req.body.team_id,
                user_comp_id: req.comp_id,
                status: '1'
            }

        })
        if (team) {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECDELETED,
                error: false,
                success: true,
                status: '1',
            });
        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
            text: error.message
        });
    }

}

const getTeamsPrjDesig = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        designation_id: Joi.number().required(),

    });
    const dataToValidate = {
        project_id: req.body.project_id,
        designation_id: req.body.designation_id,

    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message


        });
    }

    try {
        const teams = await ReqNegotiationTeamsModel.findAll({
            where: {
                user_comp_id: req.comp_id,
                project_id: req.body.project_id,
                designation_id: req.body.designation_id,
                status: '1',
            },
            include: [{
                model: ReqDesignationModel,
                as: 'designation',
                where: { user_comp_id: req.comp_id, status: '1' },
                attributes: ['id', 'designation_name'],
                required: false,
            }]
        });

        if (!teams[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            })
        }

        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            data: teams
        })

    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            //message:error.message,
            error: true,
            success: false,
            status: '0'
        })

    }

}



const approveTeam = async (req, res) => {

    const dataToValidate = {
        team_id: req.body.team_id,
        curr_status: req.body.curr_status
    };
    const schema = Joi.object().keys({
        team_id: Joi.number().required(),
        curr_status: Joi.number().required(),

    });

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    }


    try {

        const team = await ReqNegotiationTeamsModel.findOne({
            where: {
                id: req.body.team_id,
                user_comp_id: req.comp_id,
                status: '1'
            }
        })

        if (!team) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        console.log(team.tm_rq_members_id)


        const project_id = team.dataValues.project_id
        const designation_id = team.dataValues.designation_id
        const category_id = team.dataValues.category_id
        const user_comp_id = team.dataValues.user_comp_id


        const alreadyApprove = await ReqNegotiationTeamsModel.findOne({
            where: {
                user_comp_id: user_comp_id,
                project_id: project_id,
                designation_id: designation_id,
                category_id: category_id,
                curr_status: '1',
                status: '1',
            }
        })

        const curr_status = req.body.curr_status

        if (curr_status == 1) {
            if (alreadyApprove) {
                return res.status(process.env.APIRESPCODE_VALIDATION).send({
                    message: 'Record on this project for this designation and category is already approved',
                    error: true,
                    success: false,
                    status: '0'
                })
            }

        }




        const update_team_details = {
            curr_status: req.body.curr_status,
            updated_at: getCurrentDateTime(),
            modified_by: req.userId
        }

        const teamUpdate = await ReqNegotiationTeamsModel.update(update_team_details, {
            where: {
                id: req.body.team_id,
                user_comp_id: req.comp_id,
                status: '1'
            }

        })

        if (teamUpdate) {
            if (curr_status == 1) {
                const update_details = {
                    current_staus: '2',
                    updated_at: getCurrentDateTime(),
                    updated_by: req.userId
                }
                const update = await TeamNotiationMemberModel.update(update_details, {
                    where: {
                        id: team.tm_rq_members_id,
                        user_comp_id: req.comp_id,
                        status: '1'
                    }
                })
            }

            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: "Team Updated",
                error: false,
                success: true,
                status: '1',
            });
        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
            text: error.message
        });
    }

}

const ResumeUploadReqTeams = async (req, res) => {
    upload.single('can_resume')(req, res, async function (err) {
        if (err) {
            return res.status(400).send({ error: err.message });
        }
        const dataToValidate = {
            team_id: req.body.team_id,

        };
        const schema = Joi.object().keys({
            team_id: Joi.number().required(),


        });

        const result = schema.validate(dataToValidate);
        if (result.error) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        }

        try {
            if (req.file) { // Corrected variable name from `files` to `file`
                var add_team_details = {

                    can_resume: req.file.filename,
                    file_path: req.file.destination,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
            }

            const dataToUpdate = await ReqNegotiationTeamsModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    id: req.body.team_id,
                    status: '1',

                }
            })

            if (!dataToUpdate) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                })
            }

            const team = await ReqNegotiationTeamsModel.update(add_team_details, {
                where: {
                    id: req.body.team_id,
                    status: '1'
                }
            });
            if (team) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: team // Corrected variable name from `insert` to `mom`
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
                text: error.message
            });
        }
    });
}





module.exports = {

    getTeams, addReqTeams, editTeams, updateReqTeams, deleteReqTeams, getTeamsPrjDesig, approveTeam, ResumeUploadReqTeams

}