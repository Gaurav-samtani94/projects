
const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Joi = require('joi');
require('dotenv').config();
const ReqCategoryModel = require('../../../apps/models/requisition/ReqCategoryModel');
const ReqDesignationModel = require('../../../apps/models/requisition/ReqDesignationModel');
const TeamNotiationMemberModel = require('../../models/requisition/TeamNotiationMemberModel');
const ReqNegotiationTeams = require('../../models/requisition/ReqNegotiationTeams');
const getCurrentDateTime = () => new Date();
const axios = require('axios');
const FormData = require('form-data');
const addCategory = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        category_name: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        category_name: req.body.category_name,
        created_by: req.userId,
        created_at: getCurrentDateTime()

    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });

    }
    else {
        try {
            const CategoryCollection = await ReqCategoryModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    category_name: req.body.category_name,
                    status: '1'
                }, attributes: ['id', 'category_name']
            });
            if (!CategoryCollection) {
                const insert = await ReqCategoryModel.create(dataToValidate)
                //console.log(insert);
                if (insert) {
                    const { status, ...insertWithoutStatus } = insert.dataValues;
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insertWithoutStatus,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                message: error.message,
                error: true,
                success: false,
                status: '0',

            });

        }
    }
}
const listCategory = async (req, res) => {
    try {
        const catList = await ReqCategoryModel.findAll({
            order: [['created_at', 'DESC']],
            where: { user_comp_id: req.comp_id, status: '1' },
            attributes: ['id', 'category_name']
        });
        if (!catList[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: catList,
        });

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            // message: error.message,
            error: true,
            success: false,
            status: '0',

        });
    }


}
const editCategory = async (req, res) => {
    const schema = Joi.object().keys({
        category_id: Joi.number().required(),

    });
    const dataToValidate = {
        category_id: req.body.category_id,

    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message


        });
    } else {
        try {
            const editCategory = await ReqCategoryModel.findOne({
                where: { id: req.body.category_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'category_name']
            });
            if (!editCategory) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: editCategory,
            });

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0'

            });
        }

    }

}
const updateCategory = async (req, res) => {
    const schema = Joi.object().keys({
        category_id: Joi.number().required(),
        category_name: Joi.string().required(),
        updated_at: Joi.date().iso().allow()

    });
    const dataToValidate = {
        category_id: req.body.category_id,
        category_name: req.body.category_name,
        updated_at: getCurrentDateTime()
    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const updateCategory = await ReqCategoryModel.findOne({
                where: { id: req.body.category_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'category_name']
            });
            if (!updateCategory) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });

            } else {
                const updateCat = {
                    category_name: req.body.category_name,
                    updated_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                await ReqCategoryModel.update(updateCat, {
                    where: { id: req.body.category_id, user_comp_id: req.comp_id, },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1'

                });

            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                // message: error.message,
                error: true,
                success: false,
                status: '0'

            });
        }

    }

}
const deleteCategory = async (req, res) => {
    const schema = Joi.object().keys({
        category_id: Joi.number().required(),
    });
    const dataToValidate = {
        category_id: req.body.category_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const updateData = {
            status: '0',
            updated_by: req.userId,
            updated_at: getCurrentDateTime(),
        }
        try {
            const deleteCategory = await ReqCategoryModel.findOne({
                where: { id: req.body.category_id, user_comp_id: req.comp_id, created_by: req.userId, status: '1' },
                attributes: ['id', 'category_name'],
            });

            if (deleteCategory) {
                await ReqCategoryModel.update(updateData, {
                    where: { id: req.body.category_id, user_comp_id: req.comp_id, created_by: req.userId },
                });

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                message: error.message,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}



const addDesignation = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        designation_name: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        category_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        designation_name: req.body.designation_name,
        category_id: req.body.category_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),

    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });

    }
    else {
        try {

            const categoryExists = await ReqCategoryModel.findOne({
                where: {
                    id: req.body.category_id,
                    status: '1'
                }
            })
            if (!categoryExists) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            const designationCollection = await ReqDesignationModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    designation_name: req.body.designation_name,
                    category_id: req.body.category_id,
                    status: '1'
                }, attributes: ['id', 'designation_name']
            });
            if (!designationCollection) {
                const insert = await ReqDesignationModel.create(dataToValidate)
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        // data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                // message: error.message,
                error: true,
                success: false,
                status: '0',

            });

        }
    }
}
const listDesignation = async (req, res) => {
    const schema = Joi.object().keys({
        category_id: Joi.number().required(),
    });

    const dataToValidate = {
        category_id: req.body.category_id,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });

    }


    try {
        const designationList = await ReqDesignationModel.findAll({
            order: [['updated_at', 'DESC']],
            where: { user_comp_id: req.comp_id, status: '1', category_id: req.body.category_id },
            attributes: ['id', 'designation_name', 'category_id']
        });
        if (!designationList[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: designationList,
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            msg: error.message,
            error: true,
            success: false,
            status: '0'
        });
    }



}
const editDesignation = async (req, res) => {
    const schema = Joi.object().keys({
        designation_id: Joi.number().required()
    });
    const dataToValidate = {
        designation_id: req.body.designation_id,
    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message

        });
    } else {
        try {
            const editeDesignation = await ReqDesignationModel.findOne({
                where: { id: req.body.designation_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'designation_name', 'category_id']
            });
            if (!editeDesignation) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: editeDesignation,
            });

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0'

            });
        }

    }

}
const updateDesignation = async (req, res) => {
    const schema = Joi.object().keys({
        designation_id: Joi.number().required(),
        designation_name: Joi.string().required(),
        updated_at: Joi.date().iso().allow(),

    });
    const dataToValidate = {
        designation_id: req.body.designation_id,
        designation_name: req.body.designation_name,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const designationCollection = await ReqDesignationModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    designation_name: req.body.designation_name,
                    status: '1'
                }, attributes: ['id', 'designation_name']
            });

            if (designationCollection) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: false,
                    success: true,
                    status: '0',
                });
            }
            const updateDesignation = await ReqDesignationModel.findOne({
                where: { id: req.body.designation_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'designation_name']
            });
            if (!updateDesignation) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                });

            } else {
                const updateData = {
                    designation_name: req.body.designation_name,
                    updated_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }

                await ReqDesignationModel.update(updateData, {
                    where: { id: req.body.designation_id, user_comp_id: req.comp_id },
                });

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1'

                });

            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                message: error.message,
                error: true,
                success: false,

            });
        }

    }

}
const deleteDesignation = async (req, res) => {
    const schema = Joi.object().keys({
        designation_id: Joi.number().required(),

    });
    const dataToValidate = {
        designation_id: req.body.designation_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const deleteDesignation = await ReqDesignationModel.findOne({
                where: { user_comp_id: req.comp_id, created_by: req.userId, status: '1', id: req.body.designation_id },
                attributes: ['id', 'designation_name'],
            });
            const updateData = {
                status: '0',
                updated_by: req.userId,
                updated_at: getCurrentDateTime(),
            }

            if (deleteDesignation) {
                await ReqDesignationModel.update(updateData, {
                    where: { id: req.body.designation_id, user_comp_id: req.comp_id, created_by: req.userId },
                });

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                message: error.message,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}









const team_rq_create_negociation = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        project_id: Joi.number().required(),
        age_limit: Joi.number().max(100).required(),
        man_months: Joi.number().required(),
        construction_months: Joi.number().required(),
        development_months: Joi.number().required(),
        om_months: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        created_by: Joi.number().required(),
        category_id: Joi.number().required(),
        designation_id: Joi.any().required(),

    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        project_id: req.body.project_id,
        age_limit: req.body.age_limit,
        man_months: req.body.man_months,
        construction_months: req.body.construction_months,
        development_months: req.body.development_months,
        om_months: req.body.om_months,
        created_at: getCurrentDateTime(),
        created_by: req.userId,
        category_id: req.body.category_id,
        designation_id: req.body.designation_id,

    };


    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const designation_ids = req.body.designation_id.split(",").map(id => parseInt(id))
            let insertCount = 0;

            let insertIds = [];

            for (dsg_id of designation_ids) {
                const findDesig = await ReqDesignationModel.findOne({
                    where: {
                        id: dsg_id,
                        status: '1'
                    }
                })

                const findCategory = await ReqCategoryModel.findOne({
                    where: {
                        id: req.body.category_id,
                        status: '1'
                    }
                })

                if (!findCategory || !findDesig) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }



                dataToValidate.designation_id = dsg_id
                const recodes = await TeamNotiationMemberModel.findOne({
                    where: { user_comp_id: req.comp_id, project_id: req.body.project_id, category_id: req.body.category_id, designation_id: dsg_id, status: '1' },

                });
                if (!recodes) {
                    const insert = await TeamNotiationMemberModel.create(dataToValidate);
                    if (insert) {
                        insertCount++;
                    }
                }
            }
            if (insertCount > 0) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: `${insertCount} records inserted`,
                    error: false,
                    success: true,
                    status: '1'
                });
            } else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}
// }

// const teamrqnegociationlist = async (req, res) => {
//     const schema = Joi.object().keys({
//         user_comp_id: Joi.number().required(),
//         project_id: Joi.number().required(),



//     });
//     const dataToValidate = {
//         user_comp_id: req.comp_id,
//         project_id: req.body.project_id,

//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {

//             const recodes = await TeamNotiationMemberModel.findAll({
//                 order: [['updated_at', 'DESC']],
//                 where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },

//             });

//             const designation_name = await ReqCategoryModel.findAll({
//                 order: [['updated_at', 'DESC']],
//             where: { user_comp_id: req.comp_id, status: '1' },
//             attributes: ['id', 'designation_name']

//             });

//             if (!recodes[0]) {
//                 res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else {
//                 res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                     message: process.env.APIRESPMSG_RECFOUND,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     data: recodes
//                 });
//             }
//         }
//         catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             });
//         }

//     }
// }

const teamrqnegociationlist = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        project_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        project_id: req.body.project_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const recodes = await TeamNotiationMemberModel.findAll({
                order: [['updated_at', 'DESC']],
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },
                include: [{
                    model: ReqDesignationModel,
                    as: 'designation',
                    where: { user_comp_id: req.comp_id, status: '1' },
                    attributes: ['id', 'designation_name'],
                    required: false,
                },
                {
                    model: ReqNegotiationTeams,
                    where: { user_comp_id: req.comp_id, status: '1' },
                    attributes: ['id', 'fullname'],
                    required: false,
                }
            ]
            });

            console.log(req.comp_id)


            if (!recodes[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: recodes
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}



const teamrqnegociationEdit = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        project_id: Joi.number().required(),
        tm_rq_negotiation_members_id: Joi.number().required(),


    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        project_id: req.body.project_id,
        tm_rq_negotiation_members_id: req.body.tm_rq_negotiation_members_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const recodes = await TeamNotiationMemberModel.findOne({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, id: req.body.tm_rq_negotiation_members_id, status: '1', current_staus: '1' },
                // attributes: ['id'],
            });
            if (!recodes) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: recodes
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }

    }
}

const teamrqnegociationdelete = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        project_id: Joi.number().required(),
        tm_rq_negotiation_members_id: Joi.number().required(),


    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        project_id: req.body.project_id,
        tm_rq_negotiation_members_id: req.body.tm_rq_negotiation_members_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const recodes = await TeamNotiationMemberModel.findOne({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, id: req.body.tm_rq_negotiation_members_id, status: '1', current_staus: '1' },
                // attributes: ['id']

            });
            if (!recodes) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const upd_status = {
                    status: '0',
                    updated_at: getCurrentDateTime(),
                    updated_by: req.userId,
                }
                const recodes = await TeamNotiationMemberModel.update(upd_status, {
                    where: { user_comp_id: req.comp_id, project_id: req.body.project_id, id: req.body.tm_rq_negotiation_members_id, status: '1', current_staus: '1' },
                    // attributes: ['id']

                });
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',

                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }

    }
}

const teamrqnegociationupdate = async (req, res) => {
    const schema = Joi.object().keys({
        tm_rq_negotiation_members_id: Joi.number().required(),
        age_limit: Joi.number().max(100).required(),
        man_months: Joi.number().required(),
        construction_months: Joi.number().required(),
        development_months: Joi.number().required(),
        om_months: Joi.number().required(),

    });
    const dataToValidate = {
        tm_rq_negotiation_members_id: req.body.tm_rq_negotiation_members_id,
        age_limit: req.body.age_limit,
        man_months: req.body.man_months,
        construction_months: req.body.construction_months,
        development_months: req.body.development_months,
        om_months: req.body.om_months,

    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {


            const recodes = await TeamNotiationMemberModel.findOne({
                where: {
                    id: req.body.tm_rq_negotiation_members_id, user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1'

                },
                attributes: ['id'],
            });

            if (!recodes) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {

                const update_data = {
                    age_limit: req.body.age_limit,
                    man_months: req.body.man_months,
                    construction_months: req.body.construction_months,
                    development_months: req.body.development_months,
                    om_months: req.body.om_months,
                    updated_by: req.userId,
                    updated_at: getCurrentDateTime(),

                }
                const recodes = await TeamNotiationMemberModel.update(update_data, {
                    where: {
                        id: req.body.tm_rq_negotiation_members_id, user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1',
                        current_staus: '1'
                    }
                },);
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1'
                });



            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
    // }
}

//code by durgesh(23-05-2024)
const tm_req_mail = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        user_id: Joi.number().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        user_comp_id: req.comp_id,
        user_id: req.userId,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        let form_data = new FormData();
        form_data.append('project_id', dataToValidate.project_id);
        form_data.append('user_comp_id', dataToValidate.user_comp_id);
        form_data.append('user_id', dataToValidate.user_id);
        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: 'https://api.growthgrids.com/bid_grid_superadmin/api/auth/get_tender_filter',
            headers: {
                'Token': 'nrWY4SPrEZ2?Z14mYDwWNj5M7GcUrra77EWt8?vC2w4YXGwsU#mJyFQTcwX@',
                ...form_data.getHeaders()
            },
            data: form_data
        };
        const response = await axios.request(config)
        const response_data = Object.values(response.data);
        //console.log(response);
        try {
            if(response_data){
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: response.data.message,
                    error: false,
                    success: true,
                    status: '1',
                    data: response.data.data,
    
                });
            }
            else{
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
   
}



module.exports = {
    addCategory, listCategory, editCategory, updateCategory, deleteCategory, addDesignation,
    listDesignation, editDesignation, updateDesignation, deleteDesignation,
    team_rq_create_negociation, teamrqnegociationlist, teamrqnegociationEdit, teamrqnegociationdelete, teamrqnegociationupdate, tm_req_mail


}