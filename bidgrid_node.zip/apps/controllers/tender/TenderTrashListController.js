const { Sequelize, DataTypes, where, Op, fn, col } = require("sequelize");
require("dotenv").config();
const Joi = require("joi");
const Country = require("../../models/master/Country");
const State = require("../../models/master/State");
const City = require("../../models/master/City");
const Tendersector = require("../../models/master/TenderSector");
const Tenderscope = require("../../models/master/TenderScope");
const TenderGeneratedTypeIdModel = require("../../models/tender/TenderGeneratedTypeIdModel");
const TenderAssignManagerModel = require("../../models/tender/TenderAssignManagerModel");
const Client = require("../../models/master/TenderClient");
const TenderCommentModel = require("../../models/tender/TenderCommentModel");
const Users = require("../../models/Users");
const createTenderTrashModel = require("../../models/tender/TenderTrashModel");
const createTenderDocTrashModel = require("../../models/trash/TenderDocumentModel");


const getCurrentDateTime = () => new Date();

const tenderscopetrashlist = async (req, res) => {
  const list = await Tenderscope.findAll({
    order: [["order_sr", "ASC"]],
    where: {
      user_comp_id: req.comp_id,
      status: "1",
      order_sr: {
        [Op.lt]: 7,
      },
    },
    attributes: ["id", "cycle_name", "order_sr"],
  });
  try {
    if (!list[0]) {
      res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
        message: process.env.APIRESPMSG_RECNOTFOUND,
        error: true,
        success: false,
        status: "0",
      });
    } else {
      res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
        message: process.env.APIRESPMSG_RECFOUND,
        error: false,
        success: true,
        status: "1",
        data: list,
      });
    }
  } catch (error) {
    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
      message: process.env.ERROR_MSG,
      error: error.message,
      success: false,
      status: "0",
    });
  }
};

function formatDate(date) {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, "0");
  const day = date.getDate().toString().padStart(2, "0");
  return `${year}-${month}-${day}`;
}

const TenderTrashList = async (req, res) => {
  const schema = Joi.object().keys({
    limit: Joi.string().required(),
    page_number: Joi.string().required(),
  });
  const dataToValidate = {
    limit: req.body.limit,
    page_number: req.body.page_number == 0 ? "1" : req.body.page_number,
  };
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: "0",
    });
  } else {
    try {
      const currentDate = getCurrentDateTime();
      const year = currentDate.getFullYear();
      const month = (currentDate.getMonth() + 1).toString().padStart(2, "0"); // Add padding if needed
      const day = currentDate.getDate().toString().padStart(2, "0"); // Add padding if needed
      const formattedDate = `${year}-${month}-${day}`;

      const page_number = parseInt(req.body.page_number) || 1; // Get page number from query parameter, default to 1
      const limit = parseInt(req.body.limit) || 10; // Get limit from query parameter, default to 10
      const offset = (page_number - 1) * limit;

      //filter record
      //normal filter
      const dynamicFilters = [];
      const dateFilters = [];
      if (req.body.tender_keyword) {
        const tender_keyword = req.body.tender_keyword;
        dynamicFilters.push({
          tender_name: {
            [Op.like]: `%${tender_keyword}%`,
          },
        });
      }
      if (req.body.country_id) {
        const countryId = req.body.country_id;
        dynamicFilters.push({ country_id: countryId });
      }
      if (req.body.state_id) {
        const stateId = req.body.state_id;
        dynamicFilters.push({ state_id: stateId });
      }

      if (req.body.sector_id) {
        const sectorId = req.body.sector_id;
        dynamicFilters.push({ sector_id: sectorId });
      }
      if (req.body.client_id) {
        const clientID = req.body.client_id;
        dynamicFilters.push({ client_id: clientID });
      }
      if (req.body.currency_id) {
        const currendyId = req.body.currency_id;
        dynamicFilters.push({ currency_id: currendyId });
      }
      if (req.body.funding_id) {
        const fundingId = req.body.funding_id;
        dynamicFilters.push({ funding_id: fundingId });
      }

      if (req.body.cycle_id) {
        if (req.body.cycle_id !== "ALL") {
          const cycleId = req.body.cycle_id;
          dynamicFilters.push({ cycle_id: cycleId });
        }
      }

      //date filter
      if (req.body.from_date && req.body.to_date) {
        const startDate = req.body.from_date;
        const endDate = req.body.to_date;
        const tableName = "bg_tndr_details_" + req.comp_id + "s";
        dateFilters.push(
          where(fn("DATE", col(`${tableName}.created_at`)), ">=", startDate)
        );
        dateFilters.push(
          where(fn("DATE", col(`${tableName}.created_at`)), "<=", endDate)
        );
      }

      //publication date filter
      // if (req.body.published_date) {
      //     const publication_date = req.body.published_date;
      //     if (publication_date == 'today') {
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '=', formattedDate));

      //     } else if (publication_date == 'yesterday') {
      //         const nextDate = new Date(year, month, day - 1);
      //         const nextYear = nextDate.getFullYear();
      //         const nextMonth = nextDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const nextDay = nextDate.getDate();
      //         const formattedNextDate = `${nextYear}-${nextMonth}-${nextDay}`;
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '=', formattedNextDate));

      //     } else if (publication_date == 'last_7_days') {
      //         const nextDate = new Date(year, month, day - 7);
      //         const nextYear = nextDate.getFullYear();
      //         const nextMonth = nextDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const nextDay = nextDate.getDate();
      //         const formatlast_7 = `${nextYear}-${nextMonth}-${nextDay}`;
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formatlast_7));
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedDate));

      //     } else if (publication_date == 'last_30_days') {
      //         const nextDate = new Date(year, month, day - 30);
      //         const nextYear = nextDate.getFullYear();
      //         const nextMonth = nextDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const nextDay = nextDate.getDate();
      //         const formatlast_30 = `${nextYear}-${nextMonth}-${nextDay}`;
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formatlast_30));
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedDate));

      //     } else if (publication_date == 'this_month') {
      //         const startOfMonthDate = new Date(year, month, 1);
      //         const startYear = startOfMonthDate.getFullYear();
      //         const startMonth = startOfMonthDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const startDay = startOfMonthDate.getDate();
      //         const formattedStartOfMonthDate = `${startYear}-${startMonth}-${startDay}`;
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formattedStartOfMonthDate));
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedDate));
      //     } else if (publication_date == 'last_month') {
      //         const lastMonthStartDate = new Date(year, month - 1, 1);
      //         const lastMonthEndDate = new Date(year, month, 0); // Day 0 is the last day of the previous month
      //         const lastMonthStartYear = lastMonthStartDate.getFullYear();
      //         const lastMonthStartMonth = lastMonthStartDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const lastMonthStartDay = lastMonthStartDate.getDate();
      //         const lastMonthEndYear = lastMonthEndDate.getFullYear();
      //         const lastMonthEndMonth = lastMonthEndDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const lastMonthEndDay = lastMonthEndDate.getDate();
      //         const formattedLastMonthStartDate = `${lastMonthStartYear}-${lastMonthStartMonth}-${lastMonthStartDay}`;
      //         const formattedLastMonthEndDate = `${lastMonthEndYear}-${lastMonthEndMonth}-${lastMonthEndDay}`;
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formattedLastMonthStartDate));
      //         dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedLastMonthEndDate));
      //     } else if (publication_date == 'custom_date') {
      //         const pubdate_cust_from_date = req.body.pubdate_cust_from_date;
      //         const pubdate_cust_to_date = req.body.pubdate_cust_to_date;
      //         if ((pubdate_cust_from_date) && (pubdate_cust_to_date)) {
      //             dateFilters.push(where(fn('DATE', col('publication_date')), '>=', pubdate_cust_from_date));
      //             dateFilters.push(where(fn('DATE', col('publication_date')), '<=', pubdate_cust_to_date));

      //         }

      //     }
      // }

      // //clossing data filter
      // if (req.body.close_exp_date) {
      //     const close_exp_date = req.body.close_exp_date;
      //     if (close_exp_date == 'today') {
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '=', formattedDate));

      //     } else if (close_exp_date == 'yesterday') {
      //         const nextDate = new Date(year, month, day - 1);
      //         const nextYear = nextDate.getFullYear();
      //         const nextMonth = nextDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const nextDay = nextDate.getDate();
      //         const formattedNextDate = `${nextYear}-${nextMonth}-${nextDay}`;
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '=', formattedNextDate));

      //     } else if (close_exp_date == 'last_7_days') {
      //         const nextDate = new Date(year, month, day - 7);
      //         const nextYear = nextDate.getFullYear();
      //         const nextMonth = nextDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const nextDay = nextDate.getDate();
      //         const formatlast_7 = `${nextYear}-${nextMonth}-${nextDay}`;
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formatlast_7));
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedDate));

      //     } else if (close_exp_date == 'last_30_days') {
      //         const nextDate = new Date(year, month, day - 30);
      //         const nextYear = nextDate.getFullYear();
      //         const nextMonth = nextDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const nextDay = nextDate.getDate();
      //         const formatlast_30 = `${nextYear}-${nextMonth}-${nextDay}`;
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formatlast_30));
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedDate));

      //     } else if (close_exp_date == 'this_month') {
      //         const startOfMonthDate = new Date(year, month, 1);
      //         const startYear = startOfMonthDate.getFullYear();
      //         const startMonth = startOfMonthDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const startDay = startOfMonthDate.getDate();
      //         const formattedStartOfMonthDate = `${startYear}-${startMonth}-${startDay}`;
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formattedStartOfMonthDate));
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedDate));
      //     } else if (close_exp_date == 'last_month') {
      //         const lastMonthStartDate = new Date(year, month - 1, 1);
      //         const lastMonthEndDate = new Date(year, month, 0); // Day 0 is the last day of the previous month
      //         const lastMonthStartYear = lastMonthStartDate.getFullYear();
      //         const lastMonthStartMonth = lastMonthStartDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const lastMonthStartDay = lastMonthStartDate.getDate();
      //         const lastMonthEndYear = lastMonthEndDate.getFullYear();
      //         const lastMonthEndMonth = lastMonthEndDate.getMonth() + 1; // Months are zero-based, so add 1
      //         const lastMonthEndDay = lastMonthEndDate.getDate();
      //         const formattedLastMonthStartDate = `${lastMonthStartYear}-${lastMonthStartMonth}-${lastMonthStartDay}`;
      //         const formattedLastMonthEndDate = `${lastMonthEndYear}-${lastMonthEndMonth}-${lastMonthEndDay}`;
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formattedLastMonthStartDate));
      //         dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedLastMonthEndDate));
      //     } else if (close_exp_date == 'custom_date') {
      //         const expdate_cust_from_date = rqq.body.expdate_cust_from_date;
      //         const expdate_cust_to_date = rqq.body.expdate_cust_to_date;
      //         if ((expdate_cust_from_date) && (expdate_cust_to_date)) {
      //             dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', expdate_cust_from_date));
      //             dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', expdate_cust_to_date));
      //         }
      //     }
      // }

      if (req.body.published_date) {
        const publication_date = req.body.published_date;
        if (publication_date == "today") {
          dateFilters.push(
            where(fn("DATE", col("publication_date")), "=", formattedDate)
          );
        } else if (publication_date == "yesterday") {
          const currentDate = getCurrentDateTime();
          const previousDate = new Date(currentDate);
          previousDate.setDate(currentDate.getDate() - 1);
          const year = previousDate.getFullYear();
          const month = (previousDate.getMonth() + 1)
            .toString()
            .padStart(2, "0"); // Add padding if needed
          const day = previousDate.getDate().toString().padStart(2, "0"); // Add padding if needed
          const formattedPreviousDate = `${year}-${month}-${day}`;
          dateFilters.push(
            where(
              fn("DATE", col("publication_date")),
              "=",
              formattedPreviousDate
            )
          );
        } else if (publication_date == "last_7_days") {
          const currentDate = getCurrentDateTime();
          const previousDate = new Date(currentDate);
          previousDate.setDate(currentDate.getDate() - 7);
          const year = previousDate.getFullYear();
          const month = (previousDate.getMonth() + 1)
            .toString()
            .padStart(2, "0");
          const day = previousDate.getDate().toString().padStart(2, "0");
          const formatlast_7 = `${year}-${month}-${day}`;
          dateFilters.push(
            where(fn("DATE", col("publication_date")), ">=", formatlast_7)
          );
          dateFilters.push(
            where(fn("DATE", col("publication_date")), "<=", formattedDate)
          );
        } else if (publication_date == "last_30_days") {
          const currentDate = getCurrentDateTime();
          const previousDate = new Date(currentDate);
          previousDate.setDate(currentDate.getDate() - 30);
          const year = previousDate.getFullYear();
          const month = (previousDate.getMonth() + 1)
            .toString()
            .padStart(2, "0");
          const day = previousDate.getDate().toString().padStart(2, "0");
          const formatlast_30 = `${year}-${month}-${day}`;
          dateFilters.push(
            where(fn("DATE", col("publication_date")), ">=", formatlast_30)
          );
          dateFilters.push(
            where(fn("DATE", col("publication_date")), "<=", formattedDate)
          );
        } else if (publication_date == "this_month") {
          const currentDate = getCurrentDateTime();
          currentDate.setDate(1);
          const year = currentDate.getFullYear();
          const month = (currentDate.getMonth() + 1)
            .toString()
            .padStart(2, "0");
          const day = currentDate.getDate().toString().padStart(2, "0");
          const formattedFirstDateOfMonth = `${year}-${month}-${day}`;
          dateFilters.push(
            where(
              fn("DATE", col("publication_date")),
              ">=",
              formattedFirstDateOfMonth
            )
          );
          dateFilters.push(
            where(fn("DATE", col("publication_date")), "<=", formattedDate)
          );
        } else if (publication_date == "last_month") {
          const currentDate = getCurrentDateTime();
          const lastDayOfPreviousMonth = new Date(
            currentDate.getFullYear(),
            currentDate.getMonth(),
            0
          );
          const startOfLastMonth = new Date(
            lastDayOfPreviousMonth.getFullYear(),
            lastDayOfPreviousMonth.getMonth(),
            1
          );
          const endOfLastMonth = lastDayOfPreviousMonth;
          const formattedStartDate = formatDate(startOfLastMonth);
          const formattedEndDate = formatDate(endOfLastMonth);
          dateFilters.push(
            where(fn("DATE", col("publication_date")), ">=", formattedStartDate)
          );
          dateFilters.push(
            where(fn("DATE", col("publication_date")), "<=", formattedEndDate)
          );
        } else if (publication_date == "custom_date") {
          const pubdate_cust_from_date = req.body.pubdate_cust_from_date;
          const pubdate_cust_to_date = req.body.pubdate_cust_to_date;
          if (pubdate_cust_from_date && pubdate_cust_to_date) {
            dateFilters.push(
              where(
                fn("DATE", col("publication_date")),
                ">=",
                pubdate_cust_from_date
              )
            );
            dateFilters.push(
              where(
                fn("DATE", col("publication_date")),
                "<=",
                pubdate_cust_to_date
              )
            );
          }
        }
      }
      //clossing data filter
      if (req.body.close_exp_date) {
        const close_exp_date = req.body.close_exp_date;
        if (close_exp_date == "today") {
          dateFilters.push(
            where(fn("DATE", col("submission_end_date")), "=", formattedDate)
          );
        } else if (close_exp_date == "yesterday") {
          const currentDate = getCurrentDateTime();
          const previousDate = new Date(currentDate);
          previousDate.setDate(currentDate.getDate() - 1);
          const year = previousDate.getFullYear();
          const month = (previousDate.getMonth() + 1)
            .toString()
            .padStart(2, "0"); // Add padding if needed
          const day = previousDate.getDate().toString().padStart(2, "0"); // Add padding if needed
          const formattedPreviousDate = `${year}-${month}-${day}`;
          dateFilters.push(
            where(
              fn("DATE", col("submission_end_date")),
              "=",
              formattedPreviousDate
            )
          );
        } else if (close_exp_date == "last_7_days") {
          const currentDate = getCurrentDateTime();
          const previousDate = new Date(currentDate);
          previousDate.setDate(currentDate.getDate() - 7);
          const year = previousDate.getFullYear();
          const month = (previousDate.getMonth() + 1)
            .toString()
            .padStart(2, "0");
          const day = previousDate.getDate().toString().padStart(2, "0");
          const formatlast_7 = `${year}-${month}-${day}`;
          dateFilters.push(
            where(fn("DATE", col("submission_end_date")), ">=", formatlast_7)
          );
          dateFilters.push(
            where(fn("DATE", col("submission_end_date")), "<=", formattedDate)
          );
        } else if (close_exp_date == "last_30_days") {
          const currentDate = getCurrentDateTime();
          const previousDate = new Date(currentDate);
          previousDate.setDate(currentDate.getDate() - 30);
          const year = previousDate.getFullYear();
          const month = (previousDate.getMonth() + 1)
            .toString()
            .padStart(2, "0");
          const day = previousDate.getDate().toString().padStart(2, "0");
          const formatlast_30 = `${year}-${month}-${day}`;
          dateFilters.push(
            where(fn("DATE", col("submission_end_date")), ">=", formatlast_30)
          );
          dateFilters.push(
            where(fn("DATE", col("submission_end_date")), "<=", formattedDate)
          );
        } else if (close_exp_date == "this_month") {
          const currentDate = getCurrentDateTime();
          currentDate.setDate(1); // Set the day to 1 to get the first date of the current month
          const year = currentDate.getFullYear();
          const month = (currentDate.getMonth() + 1)
            .toString()
            .padStart(2, "0");
          const day = currentDate.getDate().toString().padStart(2, "0");
          const formattedFirstDateOfMonth = `${year}-${month}-${day}`;
          dateFilters.push(
            where(
              fn("DATE", col("submission_end_date")),
              ">=",
              formattedFirstDateOfMonth
            )
          );
          dateFilters.push(
            where(fn("DATE", col("submission_end_date")), "<=", formattedDate)
          );
        } else if (close_exp_date == "last_month") {
          const currentDate = getCurrentDateTime();
          const lastDayOfPreviousMonth = new Date(
            currentDate.getFullYear(),
            currentDate.getMonth(),
            0
          );
          const startOfLastMonth = new Date(
            lastDayOfPreviousMonth.getFullYear(),
            lastDayOfPreviousMonth.getMonth(),
            1
          );
          const endOfLastMonth = lastDayOfPreviousMonth;
          const formattedStartDate = formatDate(startOfLastMonth);
          const formattedEndDate = formatDate(endOfLastMonth);
          dateFilters.push(
            where(
              fn("DATE", col("submission_end_date")),
              ">=",
              formattedStartDate
            )
          );
          dateFilters.push(
            where(
              fn("DATE", col("submission_end_date")),
              "<=",
              formattedEndDate
            )
          );
        } else if (close_exp_date == "custom_date") {
          const expdate_cust_from_date = rqq.body.expdate_cust_from_date;
          const expdate_cust_to_date = rqq.body.expdate_cust_to_date;
          if (expdate_cust_from_date && expdate_cust_to_date) {
            dateFilters.push(
              where(
                fn("DATE", col("submission_end_date")),
                ">=",
                expdate_cust_from_date
              )
            );
            dateFilters.push(
              where(
                fn("DATE", col("submission_end_date")),
                "<=",
                expdate_cust_to_date
              )
            );
          }
        }
      }

      //filter amount
      if (req.body.estm_value_emd) {
        const estm_value_emd = req.body.estm_value_emd;
        if (estm_value_emd == "not_specified") {
          dateFilters.push({
            tender_emd_amnt_val: {
              [Op.lt]: "1",
            },
          });
        } else if (
          estm_value_emd != "not_specified" &&
          estm_value_emd != "10000000000>" &&
          estm_value_emd != "custom_range"
        ) {
          const AmountRecdArr = estm_value.split("-");
          const cvMin = AmountRecdArr[0];
          const cvMax = AmountRecdArr[1];
          dateFilters.push({
            tender_emd_amnt_val: {
              [Op.gte]: cvMin,
              [Op.lte]: cvMax,
            },
          });
        } else if (estm_value_emd == "10000000000>") {
          dateFilters.push({
            tender_emd_amnt_val: {
              [Op.gte]: "10000000000",
            },
          });
        } else if (estm_value_emd == "custom_range") {
          const amnt_custrange_operator_emd =
            req.body.amnt_custrange_operator_emd;
          const amnt_custrange_amount = req.body.amnt_custrange_amount;

          if (amnt_custrange_operator_emd && amnt_custrange_amount) {
            const custrange_denomination =
              req.body.custrange_denomination_emd || "";
            const denominationObj = {
              "": "",
              hundred: "00",
              thousand: "000",
              lacs: "00000",
              million: "000000",
              crores: "0000000",
              billion: "000000000",
              trillion: "000000000000",
            };

            const ZeroOnAmnt = denominationObj[custrange_denomination] || "";

            const amnt_custrange_amount_withZero =
              amnt_custrange_amount + ZeroOnAmnt;

            dateFilters.push({
              tender_emd_amnt_val: {
                [Op[amnt_custrange_operator]]: amnt_custrange_amount_withZero,
              },
            });
          }
        }
      }

      if (req.body.estm_value) {
        const estm_value = req.body.estm_value;
        if (estm_value == "not_specified") {
          dateFilters.push({
            tender_cost: {
              [Op.lt]: "1",
            },
          });
        } else if (
          estm_value != "not_specified" &&
          estm_value != "10000000000>" &&
          estm_value != "custom_range"
        ) {
          const AmountRecdArr = estm_value.split("-");
          const cvMin = AmountRecdArr[0];
          const cvMax = AmountRecdArr[1];
          dateFilters.push({
            tender_cost: {
              [Op.gte]: cvMin,
              [Op.lte]: cvMax,
            },
          });
        } else if (estm_value == "10000000000>") {
          dateFilters.push({
            tender_cost: {
              [Op.gte]: "10000000000",
            },
          });
        } else if (estm_value == "custom_range") {
          const amnt_custrange_operator = req.body.amnt_custrange_operator;
          const amnt_custrange_amount = req.body.amnt_custrange_amount;

          if (amnt_custrange_operator && amnt_custrange_amount) {
            const custrange_denomination =
              req.body.custrange_denomination || "";
            const denominationObj = {
              "": "",
              hundred: "00",
              thousand: "000",
              lacs: "00000",
              million: "000000",
              crores: "0000000",
              billion: "000000000",
              trillion: "000000000000",
            };

            const ZeroOnAmnt = denominationObj[custrange_denomination] || "";

            const amnt_custrange_amount_withZero =
              amnt_custrange_amount + ZeroOnAmnt;

            dateFilters.push({
              tender_cost: {
                [Op[amnt_custrange_operator]]: amnt_custrange_amount_withZero,
              },
            });
          }
        }
      }

      //const MainModel = createMainTenderModel(req.comp_id);
      //await MainModel.performOperation();

      // await Model.performOperation();

      const trashModel = createTenderTrashModel(req.comp_id);
      await trashModel.performOperation();

      // Find only the data for the current page
      const response = await trashModel.findAll({
        order: [["id", "DESC"]],
        where: {
          [Op.and]: [
            { status: "1", user_comp_id: req.comp_id }, // Additional filters can be added here
            ...dynamicFilters, // Include the dynamic filters
            ...dateFilters, // Include the dynamic date range condition
          ],
        },
        //where: {status: '1', user_comp_id: req.comp_id},
        limit: limit,
        offset: offset,
        include: [
          {
            model: Country,
            attributes: ["country_name"],
            where: { status: "1" },
            required: false,
          },
          {
            model: State,
            attributes: ["state_name"],
            where: { status: "1" },
            required: false,
          },
          {
            model: City,
            attributes: ["city_name"],
            where: { status: "1" },
            required: false,
          },
          {
            model: Tendersector,
            attributes: ["sector_name"],
            where: { status: "1" },
            required: false,
          },
          {
            model: Client,
            attributes: ["client_name"],
            where: { status: "1" },
            required: false,
          },
          {
            model: Tenderscope,
            attributes: [["id", "scope_id"], "order_sr", "cycle_name"],
            where: { status: "1" },
            required: false,
          },
          {
            model: TenderCommentModel,
            attributes: ["id", "comment_txt", "created_at"],
            where: { status: "1", user_comp_id: req.comp_id },
            required: false,
            include: [
              {
                model: Users,
                attributes: ["userfullname"],
                where: { isactive: "1" },
                required: false,
              },
            ],
          },
          {
            model: TenderGeneratedTypeIdModel,
            attributes: ["generated_tender_id"],
            where: { status: "1", user_comp_id: req.comp_id },
            required: false,
          },
          {
            model: TenderAssignManagerModel,
            attributes: ["bd_role_id"],
            where: { status: "1", user_comp_id: req.comp_id },
            as: "assign_tender",
            required: false,
            include: [
              {
                model: Users,
                attributes: ["userfullname"],
                where: { isactive: "1" },
                required: false,
              },
            ],
          },
        ],
      });

      if (!response[0]) {
        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
          error: true,
          success: false,
          status: "0",
          message: process.env.APIRESPMSG_RECNOTFOUND,
        });
      } else {
        let count = null;
        if (!req?.body?.cycle_id) {
          count = await trashModel.count({
            where: {
              [Op.and]: [
                { status: "1", user_comp_id: req.comp_id }, // Additional filters can be added here
                ...dynamicFilters, // Include the dynamic filters
                ...dateFilters, // Include the dynamic date range condition
              ],
            },
          });
        } else {
          count = await trashModel.count({
            where: {
              [Op.and]: [
                { status: "1", user_comp_id: req.comp_id }, // Additional filters can be added here
                ...dynamicFilters, // Include the dynamic filters
                ...dateFilters, // Include the dynamic date range condition
              ],
            },
          });
        }

        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: process.env.APIRESPMSG_RECFOUND,
          error: false,
          success: true,
          status: "1",
          totalItems: count,
          totalPages: Math.ceil(count / limit),
          currentPage: page_number,
          dataoncurrentPage: response.length,
          data: response,
        });
      }
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: "0",
      });
    }
  }
};

const edittendertrashdetail = async (req, res) => {
  const schema = Joi.object().keys({
    tender_id: Joi.number().required(),
  });

  const dataToValidate = {
    tender_id: req.body.tender_id,
  };
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: "0",
    });
  } else {
    try {
      console.log(req.comp_id);

      const TenderTrashModel = createTenderTrashModel(req.comp_id);
      await TenderTrashModel.performOperation();

      const data = await TenderTrashModel.findOne({
        where: {
          user_comp_id: req.comp_id,
          id: req.body.tender_id,
          status: "1",
        },
      });

      if (!data) {
        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
          // message: process.env.APIRESPMSG_RECNOTFOUND,
          message: error.message,
          error: true,
          success: false,
          status: "0",
        });
      } else {
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: process.env.APIRESPMSG_RECFOUND,
          error: false,
          success: true,
          status: "1",
          data: data,
        });
      }
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        //  message: process.env.ERROR_MSG,
        message: error.message,
        error: true,
        success: false,
        status: "0",
      });
    }
  }
};

// tender document list
const tenderDocumentTrashList = async (req, res) => {
  const schema = Joi.object().keys({
    user_comp_id: Joi.number().required(),
    tender_id: Joi.number().required(),
  });

  const dataToValidate = {
    user_comp_id: req.comp_id,
    tender_id: req.body.tender_id,
  };

  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      error: true,
      success: false,
      status: "0",
      message: result.error.details[0].message,
    });
  } else {
    try {
      const TenderDocTrashModel = createTenderDocTrashModel(req.comp_id);
      await TenderDocTrashModel.performOperation();

      const record = await TenderDocTrashModel.findAll({
        order: [["id", "DESC"]],
        where: {
          status: "1",
          user_comp_id: req.comp_id,
          bg_tender_id: req.body.tender_id,
        },
      });
      if (!record[0]) {
        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: process.env.APIRESPMSG_RECNOTFOUND,
          error: true,
          success: false,
          status: "0",
        });
      } else {
        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: process.env.APIRESPMSG_RECFOUND,
          error: false,
          success: true,
          status: "1",
          caterory_1: process.env.DOCS_CATEGORY_1,
          caterory_2: process.env.DOCS_CATEGORY_2,
          data: record,
        });
      }
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        // message: error.message,
        message: process.env.ERROR_MSG,
        error: true,
        success: false,
        status: "0",
      });
    }
  }
};

const updateTenderTrashdetail = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        tender_name: Joi.string().required(),
        client_id: Joi.number().required(),
        currency_id: Joi.number().required(),
        country_id: Joi.number().required(),
        state_id: Joi.number().required(),
        sector_id: Joi.number().required(),
        submission_end_date: Joi.date().required(),
    });

    const dataToValidate = {
        tender_name: req.body.tender_name,
        tender_id: req.body.tender_id,
        client_id: req.body.client_id,
        submission_end_date: req.body.submission_end_date,
        currency_id: req.body.currency_id,
        country_id: req.body.country_id,
        state_id: req.body.state_id,
        sector_id: req.body.sector_id,

    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0'
        });
    } else {
        try {
            const TenderModel = createTenderTrashModel(req.comp_id);
            await TenderModel.performOperation();

            const tender_check_exist = await TenderModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.tender_id, status: '1' }, attributes: ['id', 'tender_name', 'cycle_id'] })
            if (tender_check_exist) {
                const tebder_upd = {
                    tender_name: req.body.tender_name,
                    tender_cost: req.body.tender_cost,
                    client_id: req.body.client_id,
                    submission_start_date: req.body.submission_start_date,
                    submission_end_date: req.body.submission_end_date,
                    currency_id: req.body.currency_id,
                    sector_id: req.body.sector_id,
                    country_id: req.body.country_id,
                    state_id: req.body.state_id,
                    city_id: req.body.city_id,
                    region_id: req.body.region_id,
                    pre_bid_meeting_date: req.body.pre_bid_meeting_date,
                    bid_validity_date: req.body.bid_validity_date ,
                    client_cont_person: req.body.client_cont_person,
                    client_cont_address: req.body.client_cont_address,
                    funding_id: req.body.funding_id,
                    pre_bid_attend_by: req.body.pre_bid_attend_by,
                    tender_emd_amnt_val: req.body.tender_emd_amnt_val,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime()
                }
                const update = await TenderModel.update(tebder_upd, {
                    where: { id: req.body.tender_id, user_comp_id: req.comp_id }
                });

                if (update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};



module.exports = {
  TenderTrashList,
  tenderscopetrashlist,
  edittendertrashdetail,
  tenderDocumentTrashList,
  updateTenderTrashdetail
  
};
