const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Joi = require('joi');
require('dotenv').config();
const currentDate = new Date();
const Tenderpartners = require('../../../apps/models/tender/TenderPartner');
const { isNull } = require('lodash');

/*****************Tender Competitor Weightage Manage method******************************* */


//update tender Competitor Weightage
const updatetendercompweightage = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        weightage_method: Joi.number().required(),
        technical_weightage: Joi.number().when('weightage_method', {
            is: 2,
            then: Joi.number().required(),
            otherwise: Joi.number().allow(null)
        }),
        financial_weightage: Joi.number().when('weightage_method', {
            is: 2,
            then: Joi.number().required(),
            otherwise: Joi.number().allow(null)
        }),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        weightage_method: req.body.weightage_method,
        technical_weightage: (req.body.weightage_method == 2) ? req.body.technical_weightage : 0,
        financial_weightage: (req.body.weightage_method == 2) ? req.body.financial_weightage : 100,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {

            const result_arr = await Tenderpartners.findAll({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },
                attributes: ['id', 'lead_comp_ids', 'technical_weightage', 'financial_weightage'],
                raw: true
            })
            if (result_arr[0]) {
                const update_all = await Promise.all(result_arr.map(async (row_arr) => {
                    const weightage_update_obj = {
                        method_type: req.body.weightage_method,
                        technical_weightage: (req.body.weightage_method == 2) ? req.body.technical_weightage : 0,
                        financial_weightage: (req.body.weightage_method == 2) ? req.body.financial_weightage : 100,
                        modified_by: req.userId,
                        updated_at: currentDate,
                    }
                    const weightage_update = await Tenderpartners.update(weightage_update_obj, {
                        where: { id: row_arr.id, user_comp_id: req.comp_id },
                    });
                }));
                if (update_all.length > 0) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: `${update_all.length} ` + `records updated successfully`,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }


}

//competitor list
const tendecomplist = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        const list = await Tenderpartners.findAll({
            where: { project_id: req.body.project_id, user_comp_id: req.comp_id, status: '1' },
            attributes: ['id', 'method_type', 'lead_comp_ids', 'technical_weightage', 'technical_score', 'technical_marks', 'financial_weightage', 'financial_score', 'financial_marks', 'total', 'rank'],
        });
        try {
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


//edit tender Competitor Score
const edittendercompscore = async (req, res) => {
    const schema = Joi.object().keys({
        comp_score_id: Joi.number().required(),
    });

    const dataToValidate = {
        comp_score_id: req.body.comp_score_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editcompscore = await Tenderpartners.findOne({
                where: { id: req.body.comp_score_id, user_comp_id: req.comp_id }, 
                attributes: ['id', 'method_type', 'technical_weightage', 'technical_score', 'financial_weightage', 'financial_score'],
            })
            if (!editcompscore) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editcompscore,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


//edit tender Competitor weigtage
const edittendercompweigtage = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editcompweigtage = await Tenderpartners.findOne({
                order: [['id', 'DESC']],
                where: { 
                    project_id: req.body.project_id, 
                    user_comp_id: req.comp_id,
                    method_type: { [Op.ne]: null } 
                }, 
                attributes: ['id', 'method_type', 'technical_weightage', 'financial_weightage'],
            })
            if (!editcompweigtage) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editcompweigtage,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender Competitor Score
const updatetendercompscore = async (req, res) => {
    const schema = Joi.object().keys({
        comp_score_id: Joi.number().required(),
        lead_comp_id: Joi.number().required(),
        project_id: Joi.number().required(),
        technical_score: Joi.string().required(),
        financial_score: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        technical_score: req.body.technical_score,
        financial_score: req.body.financial_score,
        comp_score_id: req.body.comp_score_id,
        lead_comp_id: req.body.lead_comp_id,
        project_id: req.body.project_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetendercompscore = await Tenderpartners.findOne({ where: { user_comp_id: req.comp_id, id: req.body.comp_score_id, status: '1' }, attributes: ['id', 'technical_weightage', 'technical_score', 'financial_weightage', 'financial_score'] })
            if (updatetendercompscore) {
                const existData_upd = await Tenderpartners.findOne({
                    where: { status: "1", user_comp_id: req.comp_id, lead_comp_ids: req.body.lead_comp_id, project_id: req.body.project_id, technical_score: req.body.technical_score, financial_score: req.body.financial_score }, attributes: ['id']
                });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const score_update_obj = {
                    technical_score: req.body.technical_score,
                    financial_score: req.body.financial_score,
                    modified_by: req.userId,
                    updated_at: currentDate,
                }
                const score_update = await Tenderpartners.update(score_update_obj, {
                    where: { id: req.body.comp_score_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                    data: score_update
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}




//update tender Competitor tech marks
const updatetendercomptechmarks = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {

            const result_arr = await Tenderpartners.findAll({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },
                attributes: ['id', 'lead_comp_ids', 'technical_weightage', 'technical_score', 'technical_marks'],
                raw: true
            })
            if (result_arr) {
                const update_all = await Promise.all(result_arr.map(async (row_arr) => {
                    const tech_marks_update_obj = {
                        technical_marks: (row_arr.technical_score * row_arr.technical_weightage) / 100,
                        modified_by: req.userId,
                        updated_at: currentDate,
                    }
                    const tech_marks_update = await Tenderpartners.update(tech_marks_update_obj, {
                        where: { id: row_arr.id, user_comp_id: req.comp_id },
                    });
                }));
                if (update_all.length > 0) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: `${update_all.length} ` + `records updated successfully`,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


//update tender Competitor fin marks
const updatetendercompfinmarks = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {

            const result_arr = await Tenderpartners.findAll({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },
                attributes: ['id', 'lead_comp_ids', 'financial_weightage', 'financial_score', 'financial_marks'],
                raw: true
            })
            const find_min = await Tenderpartners.findOne({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },
                attributes: [
                    [Sequelize.fn('min', Sequelize.col('financial_score')), 'minValue']
                ],
                raw: true
            });
            console.log(find_min);
            if (result_arr) {
                const update_all = await Promise.all(result_arr.map(async (row_arr) => {
                    const fin_marks_update_obj = {
                        financial_marks: Math.round((find_min.minValue / row_arr.financial_score) * row_arr.financial_weightage),
                        modified_by: req.userId,
                        updated_at: currentDate,
                    }
                    const fin_marks_update = await Tenderpartners.update(fin_marks_update_obj, {
                        where: { id: row_arr.id, user_comp_id: req.comp_id },
                    });
                }));
                if (update_all.length > 0) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: `${update_all.length} ` + `records updated successfully`,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


//update tender Competitor total marks
const updatetendercomptatalmarks = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {

            const result_arr = await Tenderpartners.findAll({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },
                attributes: ['id', 'technical_marks', 'financial_marks'],
                raw: true
            })
            if (result_arr[0]) {
                const update_all = await Promise.all(result_arr.map(async (row_arr) => {
                    const total_marks_update_obj = {
                        total: row_arr.technical_marks + row_arr.financial_marks,
                        modified_by: req.userId,
                        updated_at: currentDate,
                    }
                    const total_marks_update = await Tenderpartners.update(total_marks_update_obj, {
                        where: { id: row_arr.id, user_comp_id: req.comp_id },
                    });
                }));
                if (update_all.length > 0) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: `${update_all.length} ` + `records updated successfully`,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


//update tender Competitor rank
const updatetendercomprank = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {

            const result_arr = await Tenderpartners.findAll({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },
                attributes: ['id', 'total'],
                order: [['total', 'ASC']],
                raw: true
            })
            if (result_arr[0]) {
                let updatedRowCount = 0;
                const update_all = await Promise.all(result_arr.map(async (row_arr) => {
                    updatedRowCount += 1;
                    const rank_update_obj = {
                        rank: updatedRowCount,
                        modified_by: req.userId,
                        updated_at: currentDate,
                    }
                    const rank_update = await Tenderpartners.update(rank_update_obj, {
                        where: { id: row_arr.id, user_comp_id: req.comp_id },
                    });

                }));
                if (update_all.length > 0) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: `${update_all.length} ` + `records updated successfully`,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

/*****************Tender Competitor Weightage Manage method********************************/

module.exports = {
    updatetendercompweightage, tendecomplist, edittendercompscore, edittendercompweigtage,
    updatetendercompscore, updatetendercomptechmarks, updatetendercompfinmarks, updatetendercomptatalmarks, updatetendercomprank
};    