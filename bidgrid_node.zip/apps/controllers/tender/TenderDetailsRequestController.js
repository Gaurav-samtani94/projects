const Joi = require('joi');
var express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();
const getCurrentDateTime = () => new Date();
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const TenderDetailsRequest = require('../../models/tender/TenderDetailsRequestModel');
const createTenderModel = require('../../models/tender/TenderModel');
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'request';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;

    },
});
const upload = multer({ storage: storage });
const tenderRequestAdd = async (req, res) => {
    upload.single('request_file')(req, res, async function (err) {
        // if (err) {
        //     res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        //         message: process.env.ERROR_MSG,
        //         error: true,
        //         success: false,
        //         status: '0',
        //     })
        // }
        const schema = Joi.object().keys({
            user_comp_id: Joi.number().required(),
            tender_id: Joi.number().required(),
            subject: Joi.string().required(),
            desc_details: Joi.string().required(),
            parent_id: Joi.string().allow(null),
            req_from_userid: Joi.number().required(),
            req_to_userid: Joi.number().required(),
            comment_txt: Joi.string().required(),
            // curr_status: Joi.number().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required(),
        });

        const dataToValidate = {
            user_comp_id: req.comp_id,
            tender_id: req.body.tender_id,
            subject: req.body.subject,
            desc_details: req.body.desc_details,
            parent_id: req.body.parent_id,
            req_from_userid: req.body.req_from_userid,
            req_to_userid: req.body.req_to_userid,
            // curr_status: req.body.curr_status,
            comment_txt: req.body.comment_txt,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };

        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        } else {
            const files = req.file;
            try {
                if (files) {
                    const insertObj = {
                        user_comp_id: req.comp_id,
                        tender_id: req.body.tender_id,
                        subject: req.body.subject,
                        desc_details: req.body.desc_details,
                        parent_id: req.body.parent_id,
                        file_name: files.filename,
                        file_path: files.destination,
                        req_from_userid: req.body.req_from_userid,
                        req_to_userid: req.body.req_to_userid,
                        curr_status: 1,
                        comment_txt: req.body.comment_txt,
                        created_by: req.userId,
                        created_at: getCurrentDateTime(),
                    }
                    const insertRequest = await TenderDetailsRequest.create(insertObj)
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insertRequest
                    });
                } else {
                    const insertObj = {
                        user_comp_id: req.comp_id,
                        tender_id: req.body.tender_id,
                        subject: req.body.subject,
                        desc_details: req.body.desc_details,
                        parent_id: req.body.parent_id,
                        req_from_userid: req.body.req_from_userid,
                        req_to_userid: req.body.req_to_userid,
                        curr_status: 1,
                        comment_txt: req.body.comment_txt,
                        created_by: req.userId,
                        created_at: getCurrentDateTime(),
                    }
                    const insertRequest = await TenderDetailsRequest.create(insertObj)
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insertRequest
                    });
                }

            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    // message: error.message,
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
}



const tenderRequestUpdate = async (req, res) => {
    upload.single('request_file')(req, res, async function (err) {
        const schema = Joi.object().keys({
            user_comp_id: Joi.number().required(),
            request_id: Joi.number().required(),
            tender_id: Joi.number().required(),
            subject: Joi.string().required(),
            desc_details: Joi.string().required(),
            parent_id: Joi.string().allow(null),
            req_from_userid: Joi.number().required(),
            req_to_userid: Joi.number().required(),
            comment_txt: Joi.string().required(),
            curr_status: Joi.number().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required(),
        });
        const dataToValidate = {
            user_comp_id: req.comp_id,
            request_id: req.body.request_id,
            tender_id: req.body.tender_id,
            subject: req.body.subject,
            desc_details: req.body.desc_details,
            parent_id: req.body.parent_id,
            req_from_userid: req.body.req_from_userid,
            req_to_userid: req.body.req_to_userid,
            curr_status: req.body.curr_status,
            comment_txt: req.body.comment_txt,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };

        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        } else {
            const files = req.file;
            try {
                const response_exist = await TenderDetailsRequest.findOne({
                    where: { status: '1', user_comp_id: req.comp_id, id: req.body.request_id },
                })
                if (response_exist) {
                    if (files) {
                        const updateObj = {
                            subject: req.body.subject,
                            desc_details: req.body.desc_details,
                            parent_id: req.body.parent_id,
                            file_name: files.filename,
                            file_path: files.destination,
                            req_from_userid: req.body.req_from_userid,
                            req_to_userid: req.body.req_to_userid,
                            curr_status: req.body.curr_status,
                            comment_txt: req.body.comment_txt,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }

                        const updRequest = await TenderDetailsRequest.update(updateObj, {
                            where: { status: '1', user_comp_id: req.comp_id, id: req.body.request_id }
                        })
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    } else {
                        const updateObj = {
                            subject: req.body.subject,
                            desc_details: req.body.desc_details,
                            parent_id: req.body.parent_id,
                            req_from_userid: req.body.req_from_userid,
                            req_to_userid: req.body.req_to_userid,
                            curr_status: req.body.curr_status,
                            comment_txt: req.body.comment_txt,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }

                        const updRequest = await TenderDetailsRequest.update(updateObj, {
                            where: { status: '1', user_comp_id: req.comp_id, id: req.body.request_id }
                        })
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    }
                }
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                })

            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
}



const tenderRequestEdit = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        request_id: Joi.number().required(),
        tender_id: Joi.number().required(),
    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        request_id: req.body.request_id,
        tender_id: req.body.tender_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const record = await TenderDetailsRequest.findAll({
                where: { status: '1', user_comp_id: req.comp_id, id: req.body.request_id, id: req.body.request_id, tender_id: req.body.tender_id },
            })
            if (!record[0]) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: record
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const tenderRequestList = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        tender_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        tender_id: req.body.tender_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const record = await TenderDetailsRequest.findAll({
                where: { status: '1', user_comp_id: req.comp_id, tender_id: req.body.tender_id },
            })
            if (!record[0]) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: record
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }

}
const tenderRequestDelete = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        request_id: Joi.number().required(),
    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        request_id: req.body.request_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const record = await TenderDetailsRequest.findOne({
                where: { status: '1', user_comp_id: req.comp_id, id: req.body.request_id, created_by: req.userId },
            })
            if (!record) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const deleteRecObj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime()
                }
                const deleteRec = await TenderDetailsRequest.update(deleteRecObj, {
                    where: { status: '1', user_comp_id: req.comp_id, id: req.body.request_id },
                })
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const getrequestsformelist = async (req, res) => {
    const TenderModel = createTenderModel(req.comp_id);
    await TenderModel.performOperation();

    try {
        const record = await TenderDetailsRequest.findAll({
            where: { status: '1', user_comp_id: req.comp_id, req_to_userid: req.userId },
            order: [['created_at', 'DESC']]
        })

        const myRequests = await TenderDetailsRequest.findAll({
            where: { status: '1', user_comp_id: req.comp_id, req_from_userid: req.userId },
            order: [['created_at', 'DESC']]
        })

        if (!record[0] && !myRequests[0]) {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        } else {

            const assignReq = await Promise.all(record.map(async (data) => {
                const tender_Data = await TenderModel.findOne({
                    where: { id: data.tender_id, status: '1', user_comp_id: req.comp_id }, attributes: ['tender_name'],
                })
                return {
                    ...data.toJSON(),
                    tender_Data,
                };
            }))

            const tenderReqSelf = await Promise.all(myRequests.map(async (data) => {
                const tender_Data = await TenderModel.findOne({
                    where: { id: data.tender_id, status: '1', user_comp_id: req.comp_id }, attributes: ['tender_name'],
                })
                return {
                    ...data.toJSON(),
                    tender_Data,
                };
            }))

            const response = [...tenderReqSelf, ...assignReq];

            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            // message: error.message,
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}
const getrequestsdetails = async (req, res) => {
    const schema = Joi.object().keys({
        request_id: Joi.number().required(),
    });

    const dataToValidate = {
        request_id: req.body.request_id,

    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const TenderModel = createTenderModel(req.comp_id);
        await TenderModel.performOperation();
        try {
            const record = await TenderDetailsRequest.findOne({
                where: { status: '1', user_comp_id: req.comp_id, id: req.body.request_id },
            })
            if (!record) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const tender_Data = await TenderModel.findOne({
                    where: { id: record.tender_id, status: '1', user_comp_id: req.comp_id }, attributes: ['tender_name'],
                });
                const response = {
                    tender_Data: tender_Data,
                    reequest_data: record,
                }
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                    data: response
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }

}

module.exports = {
    tenderRequestAdd, tenderRequestUpdate, tenderRequestEdit, tenderRequestList, tenderRequestDelete, getrequestsformelist, getrequestsdetails
};   