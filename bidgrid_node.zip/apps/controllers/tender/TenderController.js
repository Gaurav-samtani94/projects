const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Joi = require('joi');
require('dotenv').config();
const multer = require('multer');
let nodemailer = require('nodemailer');
const Siteconfiguration = require('../../../apps/models/siteconfig/Siteconfiguration');
const FinancialYear = require('../../../apps/models/siteconfig/FinancialYear');
const TenderGeneratedTypeModel = require('../../../apps/models/tender/TenderGeneratedTypeModel');
const TenderGeneratedTypeIdModel = require('../../../apps/models/tender/TenderGeneratedTypeIdModel');
const createTenderModel = require('../../../apps/models/tender/TenderModel');
const createTenderModelDate = require('../../../apps/models/tender/TenderModel');
const createTenderDocModel = require('../../../apps/models/tender/TenderDocModel');
const TenderDocModel = require('../../../apps/models/tender/TenderDocModel');
const getCurrentDateTime = () => new Date();
const TenderCycleAssignInactionModel = require('../../../apps/models/tender/TenderCycleAssignInactionModel');
const MisTenderCycleAssignInactionModel = require('../../../apps/models/tender/MisTenderCycleAssignInactionModel');
const TenderMovedHistroyByUserModel = require('../../../apps/models/tender/TenderMovedHistroyByUserModel');
const TenderAssignManagerModel = require('../../../apps/models/tender/TenderAssignManagerModel');
const fs = require('fs');
const path = require('path');
const Country = require('../../models/master/Country');
const State = require('../../models/master/State');
const City = require('../../models/master/City');
const Tendersector = require('../../models/master/TenderSector');
const Tenderscope = require('../../models/master/TenderScope');
// const TenderCycleAssignInactionModel = require('../../models/tender/TenderCycleAssignInactionModel');
const TenderCycleInactionModel = require('../../models/master/TenderCycleInactionModel');
const Users = require('../../models/Users');
const Inaction = require('../../models/master/TenderCycleInactionModel');
const TenderClient = require('../../models/master/TenderClient');
const TenderCommentModel = require('../../models/tender/TenderCommentModel');
const TenderStatusManage = require('../../models/tender/TenderStatusManage');

const TenderNoGeneratePrefixModel = require('../../models/master/TenderGeneratedPrefixModel');
const TenderGenTypeIdModel = require('../../../apps/models/tender/TenderGeneratedTypeIdModel');
const TenderGenTypeModel = require('../../../apps/models/tender/TenderGeneratedTypeModel');
const TenderBdRoleModel = require('../../models/master/TenderBdRoleModel');
const TenderStatus = require('../../models/master/TenderStatus');

const TenderFundingagency = require('../../models/master/TenderFundingagency');
const TenderPartnerModel = require('../../models/tender/TenderPartner');
const TenderpartnersJVS = require('../../models/tender/TenderpartnersJVS');
const TenderPartnerAssociates = require('../../models/tender/TenderpartnersAssociats');
const MainCompany = require('../../models/master/MainCompany');

/*****************************mis cycle code here by durgesh(12-04-2023)********************************/
const misleftlist = async (req, res) => {
    try {
        const TenderModel = createTenderModel(req.comp_id);
        await TenderModel.performOperation();

        const cycleId = await Tenderscope.findAll({
            where: { status: '1', order_sr: 8, user_comp_id: req.comp_id },
            attributes: ['id', 'cycle_name', 'order_sr']
        })
        const mis_cycle_list = {};
        if (cycleId) {
            //mis_cycle_list.push(cycleId);
            const tenderstatusId = await TenderStatus.findAll({
                order: [['id', 'ASC']],
                where: { status: '1', user_comp_id: req.comp_id },
                attributes: ['id', 'status_name']
            })

            if (tenderstatusId) {
                let counter = 9;
                await Promise.all(tenderstatusId.map(async (status_name1) => {
                    cycleId.push({
                        'id': status_name1.id,
                        'cycle_name': status_name1.status_name,
                        'order_sr': counter++
                    });
                }));

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: cycleId
                });
            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
        else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            //message: error.message,
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });

    }

}

const gettndrgeneratedtype = async (req, res) => {
    try {
        const tndrgentype = await TenderGeneratedTypeModel.findAll({
            order: [['id', 'ASC']],
            where: { status: '1', user_comp_id: req.comp_id },
            attributes: ['id', 'generated_type']
        })

        if (tndrgentype) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tndrgentype
            });
        }
        else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }


    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            //message: error.message,
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });

    }

}


function formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}


const mistenderlist = async (req, res) => {
    const schema = Joi.object().keys({
        limit: Joi.string().required(),
        page_number: Joi.string().required(),

    });
    const dataToValidate = {
        limit: req.body.limit,
        page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0'
        });
    } else {
        try {

            const currentDate = getCurrentDateTime();
            const year = currentDate.getFullYear();
            const month = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Add padding if needed
            const day = currentDate.getDate().toString().padStart(2, '0'); // Add padding if needed
            const formattedDate = `${year}-${month}-${day}`;

            const page_number = parseInt(dataToValidate.page_number) || 1;
            const limit = parseInt(dataToValidate.limit) || 10;
            const offset = (parseInt(page_number) - 1) * parseInt(limit);

            //filter record 
            //normal filter
            const dynamicFilters = [];
            const dynamicFilterstatus = [];
            const dateFilters = [];
            const filterfinyear = []
            const orderbydata = [];
            if (req.body.tender_keyword) {
                const tender_keyword = req.body.tender_keyword;
                dynamicFilters.push({
                    tender_name: {
                        [Op.like]: `%${tender_keyword}%`,
                    },
                });
            }
            if (req.body.country_id) {
                const countryId = req.body.country_id;
                dynamicFilters.push({ country_id: countryId });
            }
            if (req.body.state_id) {
                const stateId = req.body.state_id;
                dynamicFilters.push({ state_id: stateId });
            }


            if (req.body.sector_id) {
                const sectorId = req.body.sector_id;
                dynamicFilters.push({ sector_id: sectorId });
            }
            if (req.body.client_id) {
                const clientID = req.body.client_id;
                dynamicFilters.push({ client_id: clientID });
            }
            if (req.body.currency_id) {
                const currendyId = req.body.currency_id;
                dynamicFilters.push({ currency_id: currendyId });
            }
            if (req.body.funding_id) {
                const fundingId = req.body.funding_id;
                dynamicFilters.push({ funding_id: fundingId });
            }



            if (req.body.bid_manager_filter) {
                const bid_manager_filter = req.body.bid_manager_filter;

                const tender_bid_manager_arr = await TenderAssignManagerModel.findAll({
                    where: { status: '1', user_comp_id: req.comp_id, bd_role_id: 2, assign_to: bid_manager_filter },
                    attributes: ['tender_id'],
                    raw: true
                });

                const tndr_bid_mngr_arr = [];
                const tndr_bid_mngr_obj = await Promise.all(tender_bid_manager_arr.map(async (tndr_bid_manager_row) => {
                    tndr_bid_mngr_arr.push(tndr_bid_manager_row.tender_id)
                }));
                dynamicFilters.push({
                    id: tndr_bid_mngr_arr
                });
            }


            if (req.body.generated_type) {
                const generated_type_filter = req.body.generated_type;

                const tender_generated_type_arr = await TenderGeneratedTypeIdModel.findAll({
                    where: { status: '1', user_comp_id: req.comp_id, generate_type_id: generated_type_filter },
                    attributes: ['tender_id'],
                    raw: true
                });

                const tndr_generated_type_arr = [];
                const tndr_generated_type_obj = await Promise.all(tndr_generated_type_arr.map(async (tndr_generated_type_row) => {
                    tndr_generated_type_arr.push(tndr_generated_type_row.tender_id)
                }));
                dynamicFilters.push({
                    id: tndr_generated_type_arr
                });
            }


            if (req.body.key_manager_filter) {
                const key_manager_filter = req.body.key_manager_filter;

                const tender_key_manager_arr = await TenderAssignManagerModel.findAll({
                    where: { status: '1', user_comp_id: req.comp_id, bd_role_id: 1, assign_to: key_manager_filter },
                    attributes: ['tender_id'],
                    raw: true
                });

                const tndr_key_mngr_arr = [];
                const tndr_key_mngr_obj = await Promise.all(tender_key_manager_arr.map(async (tndr_key_manager_row) => {
                    tndr_key_mngr_arr.push(tndr_key_manager_row.tender_id)
                }));
                dynamicFilters.push({
                    id: tndr_key_mngr_arr
                });
            }
            if (req.body.tender_activity_status) {
                if (req.body.tender_activity_status == '1') {
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formattedDate));
                } else if (req.body.tender_activity_status == '2') {
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '<', formattedDate));
                }
            }
            if (req.body.located == '1') {
                dynamicFilters.push({ national_intern: '1' });
            }
            if (req.body.located == '2') {
                dynamicFilters.push({ national_intern: '2' });
            }
            
            let set_true_generate_id = false
            if (req.body.filter_fin_year) {
                set_true_generate_id = true
                const filter_fin_year = req.body.filter_fin_year;
                filterfinyear.push({ financial_year: filter_fin_year });
            }
            else{
                const default_fin_year = `${year}-${year +1}`;
                filterfinyear.push({ financial_year: default_fin_year });
            }


            if ((req.body.sort_key) && (req.body.sort_val)) {
                let key_val = null;
                const sort_key = req.body.sort_key
                if ((req.body.sort_val == 'asc') || (req.body.sort_val == 'ASC')) {
                    key_val = 'ASC';
                }
                if ((req.body.sort_val == 'desc') || (req.body.sort_val == 'DESC')) {
                    key_val = 'DESC';
                }
                if ((sort_key == 'tender_emd_amnt_val') || (sort_key == 'submission_end_date')) {
                    orderbydata.push([sort_key, key_val]);
                } else if (sort_key == 'published_date') {
                    orderbydata.push(['publication_date', key_val]);
                } else if (sort_key == 'tender_amnt_val') {
                    orderbydata.push(['tender_cost', key_val]);
                }
            }
            if (req.body.cycle_id) {
                const scope_rows = await Tenderscope.findOne({
                    order: [['id', 'DESC']],
                    attributes: ['id'],
                    where: { status: '1', user_comp_id: req.comp_id, order_sr: 8, id: req.body.cycle_id }
                })
                if (req.body.cycle_id !== 'ALL') {
                    if (!scope_rows) {
                        const tender_status_arr = await TenderStatusManage.findAll({
                            where: { status: '1', user_comp_id: req.comp_id, tender_status: req.body.cycle_id },
                            attributes: ['project_id'],
                        });
                        if (tender_status_arr.length > 0) {
                            const tndr_status_arr = await Promise.all(tender_status_arr.map(async (tndr_status_row) => {
                                return tndr_status_row.project_id;
                            }));
                            dynamicFilters.push({
                                id: tndr_status_arr,
                            });
                        }
                        else {
                            const tender_scope_arr2 = await Tenderscope.findAll({
                                where: { status: '1', user_comp_id: req.comp_id },
                                attributes: ['id'],
                            });
                            if (tender_scope_arr2.length > 0) {
                                const tndr_scope_arr2 = await Promise.all(tender_scope_arr2.map(async (tndr_scope_row2) => {
                                    return tndr_scope_row2.id;
                                }));
                                dynamicFilters.push({
                                    cycle_id: {
                                        [Op.e]: tndr_scope_arr2
                                    },
                                });
                            }
                        }
                    }
                    else {
                        dynamicFilters.push({
                            cycle_id: scope_rows.id,
                        });
                    }
                }

            }


            //date filter
            if (req.body.from_date && req.body.to_date) {
                const startDate = req.body.from_date;
                const endDate = req.body.to_date;
                const tableName = 'bg_tndr_details_' + req.comp_id + 's';
                dateFilters.push(where(fn('DATE', col(`${tableName}.created_at`)), '>=', startDate));
                dateFilters.push(where(fn('DATE', col(`${tableName}.created_at`)), '<=', endDate));
            }


            if (req.body.published_date) {
                const publication_date = req.body.published_date;
                if (publication_date == 'today') {
                    dateFilters.push(where(fn('DATE', col('publication_date')), '=', formattedDate));

                } else if (publication_date == 'yesterday') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 1);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0'); // Add padding if needed
                    const day = previousDate.getDate().toString().padStart(2, '0'); // Add padding if needed
                    const formattedPreviousDate = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('publication_date')), '=', formattedPreviousDate));

                } else if (publication_date == 'last_7_days') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 7);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = previousDate.getDate().toString().padStart(2, '0');
                    const formatlast_7 = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formatlast_7));
                    dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedDate));

                } else if (publication_date == 'last_30_days') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 30);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = previousDate.getDate().toString().padStart(2, '0');
                    const formatlast_30 = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formatlast_30));
                    dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedDate));

                } else if (publication_date == 'this_month') {
                    const currentDate = getCurrentDateTime();
                    currentDate.setDate(1);
                    const year = currentDate.getFullYear();
                    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = currentDate.getDate().toString().padStart(2, '0');
                    const formattedFirstDateOfMonth = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formattedFirstDateOfMonth));
                    dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedDate));
                } else if (publication_date == 'last_month') {
                    const currentDate = getCurrentDateTime();
                    const lastDayOfPreviousMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0);
                    const startOfLastMonth = new Date(lastDayOfPreviousMonth.getFullYear(), lastDayOfPreviousMonth.getMonth(), 1);
                    const endOfLastMonth = lastDayOfPreviousMonth;
                    const formattedStartDate = formatDate(startOfLastMonth);
                    const formattedEndDate = formatDate(endOfLastMonth);
                    dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formattedStartDate));
                    dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedEndDate));
                } else if (publication_date == 'custom_date') {
                    const pubdate_cust_from_date = req.body.pubdate_cust_from_date;
                    const pubdate_cust_to_date = req.body.pubdate_cust_to_date;
                    if ((pubdate_cust_from_date) && (pubdate_cust_to_date)) {
                        dateFilters.push(where(fn('DATE', col('publication_date')), '>=', pubdate_cust_from_date));
                        dateFilters.push(where(fn('DATE', col('publication_date')), '<=', pubdate_cust_to_date));

                    }

                }
            }
            //clossing data filter
            if (req.body.close_exp_date) {
                const close_exp_date = req.body.close_exp_date;
                if (close_exp_date == 'today') {
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '=', formattedDate));

                } else if (close_exp_date == 'yesterday') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 1);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0'); // Add padding if needed
                    const day = previousDate.getDate().toString().padStart(2, '0'); // Add padding if needed
                    const formattedPreviousDate = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '=', formattedPreviousDate));

                } else if (close_exp_date == 'last_7_days') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 7);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = previousDate.getDate().toString().padStart(2, '0');
                    const formatlast_7 = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formatlast_7));
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedDate));

                } else if (close_exp_date == 'last_30_days') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 30);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = previousDate.getDate().toString().padStart(2, '0');
                    const formatlast_30 = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formatlast_30));
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedDate));

                } else if (close_exp_date == 'this_month') {
                    const currentDate = getCurrentDateTime();
                    currentDate.setDate(1); // Set the day to 1 to get the first date of the current month
                    const year = currentDate.getFullYear();
                    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = currentDate.getDate().toString().padStart(2, '0');
                    const formattedFirstDateOfMonth = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formattedFirstDateOfMonth));
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedDate));
                } else if (close_exp_date == 'last_month') {
                    const currentDate = getCurrentDateTime();
                    const lastDayOfPreviousMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0);
                    const startOfLastMonth = new Date(lastDayOfPreviousMonth.getFullYear(), lastDayOfPreviousMonth.getMonth(), 1);
                    const endOfLastMonth = lastDayOfPreviousMonth;
                    const formattedStartDate = formatDate(startOfLastMonth);
                    const formattedEndDate = formatDate(endOfLastMonth);
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formattedStartDate));
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedEndDate));
                } else if (close_exp_date == 'custom_date') {
                    const expdate_cust_from_date = rqq.body.expdate_cust_from_date;
                    const expdate_cust_to_date = rqq.body.expdate_cust_to_date;
                    if ((expdate_cust_from_date) && (expdate_cust_to_date)) {
                        dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', expdate_cust_from_date));
                        dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', expdate_cust_to_date));
                    }
                }
            }


            //filter amount
            if (req.body.estm_value_emd) {
                const estm_value_emd = req.body.estm_value_emd
                if (estm_value_emd == 'not_specified') {
                    dateFilters.push({
                        tender_emd_amnt_val: {
                            [Op.lt]: '1',
                        },
                    });
                } else if ((estm_value_emd != "not_specified") && (estm_value_emd != "10000000000>") && (estm_value_emd != "custom_range")) {
                    const AmountRecdArr = estm_value.split('-');
                    const cvMin = AmountRecdArr[0];
                    const cvMax = AmountRecdArr[1];
                    dateFilters.push({
                        tender_emd_amnt_val: {
                            [Op.gte]: cvMin,
                            [Op.lte]: cvMax,
                        },
                    });
                } else if (estm_value_emd == "10000000000>") {
                    dateFilters.push({
                        tender_emd_amnt_val: {
                            [Op.gte]: '10000000000',
                        },
                    });
                } else if (estm_value_emd == "custom_range") {
                    const amnt_custrange_operator_emd = req.body.amnt_custrange_operator_emd;
                    const amnt_custrange_amount = req.body.amnt_custrange_amount;

                    if (amnt_custrange_operator_emd && amnt_custrange_amount) {
                        const custrange_denomination = req.body.custrange_denomination_emd || '';
                        const denominationObj = {
                            '': '',
                            'hundred': '00',
                            'thousand': '000',
                            'lacs': '00000',
                            'million': '000000',
                            'crores': '0000000',
                            'billion': '000000000',
                            'trillion': '000000000000',
                        };

                        const ZeroOnAmnt = denominationObj[custrange_denomination] || '';

                        const amnt_custrange_amount_withZero = amnt_custrange_amount + ZeroOnAmnt;

                        dateFilters.push({
                            tender_emd_amnt_val: {
                                [Op[amnt_custrange_operator_emd]]: amnt_custrange_amount_withZero,
                            },
                        });
                    }
                }
            }

            if (req.body.estm_value) {
                const estm_value = req.body.estm_value
                if (estm_value == 'not_specified') {
                    dateFilters.push({
                        tender_cost: {
                            [Op.lt]: '1',
                        },
                    });
                } else if ((estm_value != "not_specified") && (estm_value != "10000000000>") && (estm_value != "custom_range")) {
                    const AmountRecdArr = estm_value.split('-');
                    const cvMin = AmountRecdArr[0];
                    const cvMax = AmountRecdArr[1];
                    dateFilters.push({
                        tender_cost: {
                            [Op.gte]: cvMin,
                            [Op.lte]: cvMax,
                        },
                    });
                } else if (estm_value == "10000000000>") {
                    dateFilters.push({
                        tender_cost: {
                            [Op.gte]: '10000000000',
                        },
                    });
                } else if (estm_value == "custom_range") {

                    const amnt_custrange_operator = req.body.amnt_custrange_operator;
                    const amnt_custrange_amount = req.body.amnt_custrange_amount;

                    if (amnt_custrange_operator && amnt_custrange_amount) {
                        const custrange_denomination = req.body.custrange_denomination || '';
                        const denominationObj = {
                            '': '',
                            'hundred': '00',
                            'thousand': '000',
                            'lacs': '00000',
                            'million': '000000',
                            'crores': '0000000',
                            'billion': '000000000',
                            'trillion': '000000000000',
                        };

                        const ZeroOnAmnt = denominationObj[custrange_denomination] || '';

                        const amnt_custrange_amount_withZero = amnt_custrange_amount + ZeroOnAmnt;

                        dateFilters.push({
                            tender_cost: {
                                [Op[amnt_custrange_operator]]: amnt_custrange_amount_withZero,
                            },
                        });
                    }
                }
            }

            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderDocModel = createTenderDocModel(req.comp_id);
            await TenderDocModel.performOperation();

            const scope_rows2 = await Tenderscope.findOne({
                order: [['id', 'DESC']],
                attributes: ['id'],
                where: { status: '1', user_comp_id: req.comp_id, order_sr: 8 }
            })

            const response = await TenderModel.findAll({
                // order: [['id', 'DESC']],
                order: orderbydata.length > 0 ? orderbydata : [['updated_at', 'DESC']],
                attributes: ['id', 'gg_tenderID', 'tender_name', 'tnd_ref_id', 'tender_gov_id', 'publication_date', 'updated_at', 'tender_cost', 'tender_emd_amnt_val', 'submission_start_date', 'submission_end_date', 'tnd_url', 'cycle_id', 'national_intern', 'client_cont_person', 'client_cont_address', 'pre_bid_meeting_date'],
                where: {
                    [Op.and]: [
                        { status: '1', user_comp_id: req.comp_id, cycle_id: scope_rows2.id }, // Additional filters can be added here
                        ...dynamicFilters, // Include the dynamic filters
                        ...dateFilters, // Include the dynamic date range condition
                    ],
                },
                offset,
                limit,
                include: [{
                    model: Country,
                    attributes: ['country_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: State,
                    attributes: ['state_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: City,
                    attributes: ['city_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['userfullname'],
                    where: { isactive: '1' },
                    as: 'pre_bid_attend',
                    required: false,
                },
                {
                    model: TenderFundingagency,
                    attributes: ['funding_org_name'],
                    where: { status: '1' },
                    as: 'funding_agency',
                    required: false,
                },
                {
                    model: TenderPartnerModel,
                    attributes: ['lead_comp_ids', 'group_no',],
                    where: { status: '1' },
                    required: false,
                    include: [
                        {
                            model: MainCompany,
                            attributes: ['company_name'],
                            where: { status: '1' },
                            required: false,
                        }]
                },
                {
                    model: TenderpartnersJVS,
                    attributes: ['jv_ids', 'group_no'],
                    where: { status: '1' },
                    required: false,
                    include: [
                        {
                            model: MainCompany,
                            attributes: ['company_name'],
                            where: { status: '1' },
                            required: false,
                        }]
                },
                {
                    model: TenderPartnerAssociates,
                    attributes: ['associative_id', 'group_no'],
                    where: { status: '1' },
                    required: false,
                    include: [
                        {
                            model: MainCompany,
                            attributes: ['company_name'],
                            where: { status: '1' },
                            required: false,
                        }]
                },
                {
                    model: Tenderscope,
                    attributes: [['id', 'scope_id'], 'order_sr', 'cycle_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: TenderStatusManage,
                    attributes: ['tender_status'],
                    where: { status: '1' },
                    required: false,
                    include: {
                        model: TenderStatus,
                        attributes: ['status_name'],
                        where: { status: '1' },
                        required: false,
                    }
                },
                {
                    model: Tendersector,
                    attributes: ['sector_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: TenderClient,
                    attributes: ['client_name'],
                    where: { status: '1' },
                    required: false,
                },

                {
                    model: TenderCommentModel,
                    attributes: ['id', 'comment_txt', 'created_at'],
                    where: { status: '1' },
                    required: false,
                    //group: ['tender_id'],
                    include: [
                        {
                            model: Users,
                            attributes: ['userfullname'],
                            where: { isactive: '1' },
                            required: false,
                        }]

                },
                {
                    model: TenderGeneratedTypeIdModel,
                    attributes: ['generated_tender_id', 'generate_type_id'],
                    where: {
                        [Op.and]: [
                            { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                            ...filterfinyear, // Include the dynamic filters

                        ],
                    },
                    required: set_true_generate_id,
                    include:
                    {
                        model: TenderGeneratedTypeModel,
                        attributes: ['generated_type'],
                        where: { status: '1', user_comp_id: req.comp_id },
                        required: false,
                    }
                },
                {
                    model: TenderAssignManagerModel,
                    attributes: ['bd_role_id', 'created_at'],
                    where: { status: '1' },
                    as: 'assign_tender',
                    required: false,
                    include: [
                        {
                            model: TenderBdRoleModel,
                            attributes: ['role_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: Users,
                            attributes: ['userfullname'],
                            where: { isactive: '1' },
                            required: false,
                        }]
                },
                {
                    model: TenderDocModel,
                    attributes: ['file_doc_type', 'file_name', 'doc_path', 'file_doc_description', 'tender_category'],
                    as: 'tender_docs',
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                    // {
                    // model: TenderCycleAssignInactionModel,
                    // attributes: [['id', 'inaction_id']],
                    // as: 'inactions',
                    // where: { status: '1', user_comp_id: req.comp_id },
                    // required: false,
                    // include: [
                    //     {
                    //         model: TenderCycleInactionModel,
                    //         attributes: ['inaction_name'],
                    //         where: { status: '1' },
                    //         required: false,
                    //     }]

                    // },
                ]
            })
            if (!response[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                let count = null;
                if (!req?.body?.cycle_id) {
                    count = await TenderModel.count({
                        //where: { status: '1', user_comp_id: req.comp_id, cycle_id: scope_rows2.id } 
                        where: {
                            [Op.and]: [
                                { status: '1', user_comp_id: req.comp_id, cycle_id: scope_rows2.id }, // Additional filters can be added here
                                ...dynamicFilters, // Include the dynamic filters
                                ...dateFilters, // Include the dynamic date range condition
                            ],
                        },
                        include: [

                            {
                                model: TenderGeneratedTypeIdModel,
                                attributes: ['generated_tender_id'],
                                where: {
                                    [Op.and]: [
                                        { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                                        ...filterfinyear, // Include the dynamic filters

                                    ],
                                },
                                required: set_true_generate_id,
                            },
                        ]
                    });
                } else {
                    const scope_rows3 = await Tenderscope.findOne({
                        order: [['id', 'DESC']],
                        attributes: ['id'],
                        where: { status: '1', user_comp_id: req.comp_id, order_sr: 8, id: req.body.cycle_id }
                    })
                    if (!scope_rows3) {
                        const tender_status_arr = await TenderStatusManage.findAll({
                            where: { status: '1', user_comp_id: req.comp_id, tender_status: req.body.cycle_id },
                            attributes: ['project_id'],
                        });
                        if (tender_status_arr.length > 0) {
                            const tndr_status_arr = await Promise.all(tender_status_arr.map(async (tndr_status_row) => {
                                return tndr_status_row.project_id;
                            }));
                            count = await TenderModel.count({
                                //where: { status: '1', user_comp_id: req.comp_id, id: tndr_status_arr } 
                                where: {
                                    [Op.and]: [
                                        { status: '1', user_comp_id: req.comp_id, id: tndr_status_arr }, // Additional filters can be added here
                                        ...dynamicFilters, // Include the dynamic filters
                                        ...dateFilters, // Include the dynamic date range condition
                                    ],
                                },
                                include: [

                                    {
                                        model: TenderGeneratedTypeIdModel,
                                        attributes: ['generated_tender_id'],
                                        where: {
                                            [Op.and]: [
                                                { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                                                ...filterfinyear, // Include the dynamic filters

                                            ],
                                        },
                                        required: set_true_generate_id,
                                    },
                                ]
                            });
                        }

                    }
                    else {
                        count = await TenderModel.count({
                            // where: { status: '1', user_comp_id: req.comp_id, cycle_id: scope_rows3.id } 
                            where: {
                                [Op.and]: [
                                    { status: '1', user_comp_id: req.comp_id, cycle_id: scope_rows3.id }, // Additional filters can be added here
                                    ...dynamicFilters, // Include the dynamic filters
                                    ...dateFilters, // Include the dynamic date range condition
                                ],
                            },

                        });
                    }
                    //count = await TenderModel.count({ where: { status: '1', user_comp_id: req.comp_id, cycle_id: req.body.cycle_id } });
                }
                // const count_data = await TenderModel.count();
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    totalItems: count,
                    totalPages: Math.ceil(count / limit),
                    currentPage: page_number,
                    dataoncurrentPage: response.length,
                    data: response,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


const mistndcycleall = async (req, res) => {
    try {

        const cycles = await Tenderscope.findAll({
            where: {
                [Op.and]: [
                    { status: '1', order_sr: 8, user_comp_id: req.comp_id },
                ]
            },
            attributes: ['id', 'cycle_name', 'order_sr']
        });

        const tenderstatusId = await TenderStatus.findAll({
            where: {
                [Op.and]: [
                    { status: '1', user_comp_id: req.comp_id },
                ]
            },
            order: [['id', 'ASC']],
            attributes: ['id', 'status_name']
        });

        if (cycles.length > 0 && tenderstatusId.length > 0) {

            // const combinedCycles = [...cycles, ...tenderstatusId.map(({ id, status_name }) => ({ id, cycle_name: status_name,order_sr:'' }))];
            let counter = 8;
            const combinedCycles = [
                ...cycles.map(cycle => ({ id: cycle.id, cycle_name: cycle.cycle_name, order_sr: cycle.order_sr })),
                ...tenderstatusId.map((status) =>
                    ({ id: status.id, cycle_name: status.status_name, order_sr: ++counter })
                )
            ];
            if (combinedCycles.length > 0) {
                var filterArrall = [];
                for (var i = 0; i < combinedCycles.length; i++) {
                    var filterArr = [];
                    let counter = i;

                    //skip key value with prevous data value
                    if (i === counter) {
                        filterArr = filterArr.concat(combinedCycles.slice(counter + 1));

                    }

                    counter += 1
                    var obj = {};
                    obj[combinedCycles[i]['id']] = filterArr;

                    if (obj[combinedCycles[i]['id']].length > 0) {
                        filterArrall.push(obj);
                    }

                }

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: filterArrall,
                });
            }

        }
        else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
};

const mistndrcycleinactionlist = async (req, res) => {
    const schema = Joi.object().keys({
        scope_id: Joi.number().required(),
    });

    const dataToValidate = {
        scope_id: req.body.scope_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {

            const scope_rows = await Tenderscope.findOne({
                order: [['id', 'DESC']],
                attributes: ['id'],
                where: { status: '1', user_comp_id: req.comp_id, order_sr: 8, id: req.body.scope_id }
            })

            var combinedCycles = []
            if (scope_rows) {
                const inactionlist = await TenderCycleAssignInactionModel.findAll({
                    where: { user_comp_id: req.comp_id, status: '1', cycle_id: req.body.scope_id },
                    attributes: ['id', 'cycle_id', 'inaction_id'],
                    include: [{
                        model: Inaction,
                        attributes: ['inaction_name', 'image_name'],
                        where: { status: '1' },
                        required: false,
                    },
                    ]
                })
                combinedCycles = inactionlist;
            }
            else {
                const mis_inactionlist = await MisTenderCycleAssignInactionModel.findAll({
                    where: { user_comp_id: req.comp_id, status: '1', cycle_id: req.body.scope_id },
                    attributes: ['id', 'cycle_id', 'inaction_id'],
                    include: [{
                        model: Inaction,
                        attributes: ['inaction_name', 'image_name'],
                        where: { status: '1' },
                        required: false,
                    },
                    ]
                })
                combinedCycles = mis_inactionlist;
            }
            if (combinedCycles) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: combinedCycles
                });
            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }


}

const mislistassignbtn = async (req, res) => {
    try {
        const cycles = await Tenderscope.findAll({
            order: [['id', 'ASC']],
            attributes: ['id'],
            where: { status: '1', user_comp_id: req.comp_id, order_sr: 8 }
        })
        const tenderstatusId = await TenderStatus.findAll({
            order: [['id', 'ASC']],
            attributes: ['id'],
            where: { status: '1', user_comp_id: req.comp_id }
        })
        if (cycles.length > 0 && tenderstatusId.length > 0) {
            //const combinedCycles = [...cycles, ...tenderstatusId.map(({ id, status_name }) => ({ id, cycle_name: status_name }))];


            const scope_arr = await TenderCycleAssignInactionModel.findAll({
                where: { user_comp_id: req.comp_id, status: '1', cycle_id: cycles[0].id },
                attributes: ['id', 'inaction_id', 'cycle_id'],
                include: [
                    {
                        model: TenderCycleInactionModel,
                        attributes: ['id', 'inaction_name', 'image_name'],
                        where: { status: '1' },
                        required: false,
                    },
                ]
            });


            const status_arr = await MisTenderCycleAssignInactionModel.findAll({
                where: { user_comp_id: req.comp_id, status: '1' },
                attributes: ['id', 'inaction_id', 'cycle_id'],
                include: [
                    {
                        model: TenderCycleInactionModel,
                        attributes: ['id', 'inaction_name', 'image_name'],
                        where: { status: '1' },
                        required: false,
                    },
                ]
            });

            const combinedCycles = [...scope_arr, ...status_arr];
            if (combinedCycles) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: combinedCycles,
                });

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',

                });

            }
        }


    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}


const addmistndrcyclejumpmultipledbtn = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.string().required(),
        cycle_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
        cycle_id: req.body.cycle_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const TenderArr = req.body.tender_id.split(',');

            const check_scope_res = await Tenderscope.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    id: req.body.cycle_id,
                    status: '1',
                },
                attributes: ['id']
            });

            const check_status_res = await TenderStatus.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    id: req.body.cycle_id,
                    status: '1',
                },
                attributes: ['id']
            });



            if (check_scope_res) {
                const scopetoawaitstatus = await Promise.all(TenderArr.map(async (tender_row_id) => {
                    const check_status_existence = await TenderStatusManage.findOne({
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: tender_row_id,
                            status: '1',
                        },
                        attributes: ['id']
                    });
                    if (check_status_existence) {
                        const status_update_obj = {
                            tender_status: req.body.cycle_id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_await_status_update = await TenderStatusManage.update(status_update_obj, {
                            where: { project_id: tender_row_id, user_comp_id: req.comp_id, status: '1' },
                        })
                    }
                    else {
                        const status_insert_obj = {
                            project_id: tender_row_id,
                            tender_status: req.body.cycle_id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        };
                        const tndr_await_status_insert = await TenderStatusManage.create(status_insert_obj);
                    }
                }))
                if (scopetoawaitstatus) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Tender cycle change Successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            }
            else if (check_status_res) {
                const scopetoawaitstatus = await Promise.all(TenderArr.map(async (tender_row_id) => {
                    const check_status_existence = await TenderStatusManage.findOne({
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: tender_row_id,
                            status: '1',
                        },
                        attributes: ['id']
                    });
                    if (check_status_existence) {
                        const status_update_obj = {
                            tender_status: req.body.cycle_id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_await_status_update = await TenderStatusManage.update(status_update_obj, {
                            where: { project_id: tender_row_id, user_comp_id: req.comp_id, status: '1' },
                        })
                    }
                    else {
                        const status_insert_obj = {
                            project_id: tender_row_id,
                            tender_status: req.body.cycle_id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        };
                        const tndr_await_status_insert = await TenderStatusManage.create(status_insert_obj);
                    }
                }))
                if (scopetoawaitstatus) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Tender cycle change Successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            }
            else {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

const addmistndrcyclejumpsingledbtn = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        cycle_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
        cycle_id: req.body.cycle_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const check_exist = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                }, attributes: ['cycle_id']
            });

            if (!check_exist) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Recods Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });
            }


            const current_scope = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, id: dataToValidate.tender_id, status: '1',
                    cycle_id: { [Op.ne]: dataToValidate.cycle_id },
                }, attributes: ['cycle_id']
            });

            if (current_scope) {

                const check_scope_res = await Tenderscope.findOne({
                    where: {
                        user_comp_id: req.comp_id,
                        id: req.body.cycle_id,
                        status: '1',
                    },
                    attributes: ['id']
                });

                const check_status_res = await TenderStatus.findOne({
                    where: {
                        user_comp_id: req.comp_id,
                        id: req.body.cycle_id,
                        status: '1',
                    },
                    attributes: ['id']
                });

                if (check_scope_res) {
                    const check_status_existence = await TenderStatusManage.findOne({
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: req.body.tender_id,
                            status: '1',
                        },
                        attributes: ['id']
                    });
                    if (check_status_existence) {
                        const status_update_obj = {
                            tender_status: req.body.cycle_id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_await_status_update = await TenderStatusManage.update(status_update_obj, {
                            where: { project_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' },
                        })
                        if (tndr_await_status_update) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: 'Tender cycle change Successfully',
                                error: false,
                                success: true,
                                status: '1',
                                data: tndr_await_status_update
                            });
                        }
                    }
                    else {
                        const status_insert_obj = {
                            project_id: req.body.tender_id,
                            tender_status: req.body.cycle_id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        };
                        const tndr_await_status_insert = await TenderStatusManage.create(status_insert_obj);
                        if (tndr_await_status_insert) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: 'Tender cycle change Successfully',
                                error: false,
                                success: true,
                                status: '1',
                                data: tndr_await_status_insert
                            });
                        }
                    }

                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Tender cycle change Successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });

                }
                else if (check_status_res) {
                    const check_status_existence = await TenderStatusManage.findOne({
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: req.body.tender_id,
                            status: '1',
                        },
                        attributes: ['id']
                    });
                    if (check_status_existence) {
                        const status_update_obj = {
                            tender_status: req.body.cycle_id,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const tndr_await_status_update = await TenderStatusManage.update(status_update_obj, {
                            where: { project_id: req.body.tender_id, user_comp_id: req.comp_id, status: '1' },
                        })
                        if (tndr_await_status_update) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: 'Tender cycle change Successfully',
                                error: false,
                                success: true,
                                status: '1',
                                data: tndr_await_status_update
                            });
                        }
                    }
                    else {
                        const status_insert_obj = {
                            project_id: req.body.tender_id,
                            tender_status: req.body.cycle_id,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        };
                        const tndr_await_status_insert = await TenderStatusManage.create(status_insert_obj);
                        if (tndr_await_status_insert) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: 'Tender cycle change Successfully',
                                error: false,
                                success: true,
                                status: '1',
                                data: tndr_await_status_insert
                            });
                        }
                    }

                }
                else {
                    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                        message: process.env.ERROR_MSG,
                        error: error.message,
                        success: false,
                        status: '0',
                    });
                }


            } else {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

const mistndcyclenext = async (req, res) => {
    const schema = Joi.object().keys({
        cycle_id: Joi.number().required()
    });

    const dataToValidate = {
        cycle_id: req.body.cycle_id
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0'
        });
    }

    try {
        const cycles = await Tenderscope.findAll({
            where: {
                [Op.and]: [
                    { status: '1', order_sr: 8, user_comp_id: req.comp_id },
                ]
            },
            attributes: ['id', 'cycle_name', 'order_sr']
        });

        const tenderstatusId = await TenderStatus.findAll({
            where: {
                [Op.and]: [
                    { status: '1', user_comp_id: req.comp_id },
                ]
            },
            order: [['id', 'ASC']],
            attributes: ['id', 'status_name']
        });

        if (cycles.length > 0 && tenderstatusId.length > 0) {
            let counter = 9;
            const combinedCycles = [...cycles, ...tenderstatusId.map(({ id, status_name }) => ({ id, cycle_name: status_name, order_sr: counter++ }))];

            if (combinedCycles.length > 0) {
                for (var i = 0; i < combinedCycles.length; i++) {
                    if (dataToValidate.cycle_id == combinedCycles[i]['id']) {
                        combinedCycles.splice(0, i + 1);
                    }
                }
            }
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: combinedCycles
            });
        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
};
/*****************************mis cycle code end here by durgesh(12-04-2023)********************************/

const live_doc_storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const foldername = 'public' + '_' + req.comp_id + '/' + 'tender_doc' + '/' + year + '/' + month + '/' + day + '/' + req.userId + '-' + req.comp_id;
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;

    },
});
const live_doc_upload = multer({ storage: live_doc_storage });

const addTender = async (req, res) => {
    live_doc_upload.array('files')(req, res, async function (err) {
        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
        const schema = Joi.object().keys({
            tender_name: Joi.string().required(),
            gg_tenderID: Joi.string().allow(null),
            // tnd_ref_id: Joi.string().allow(null),
            // tender_gov_id: Joi.string().allow(null),
            //tender_result_id: Joi.number().required(),
            tender_cost: Joi.number().required(),
            tender_emd_amnt_val: Joi.number().allow(null),
            // client_id: Joi.number().required(),
            currency_id: Joi.number().required(),
            // region_id: Joi.number().allow(null),
            country_id: Joi.number().required(),
            // state_id: Joi.number().required(null),
            // city_id: Joi.number().allow(null),
            sector_id: Joi.number().required(),
            // funding_id: Joi.number().required(),
            cycle_id: Joi.number().required(),
            // client_cont_person: Joi.string().allow(null),
            // client_cont_address: Joi.string().allow(null),
            // email_id: Joi.string().allow(null),
            // phone_no: Joi.string().allow(null),
            // publication_date: Joi.date().allow(null),
            submission_start_date: Joi.date().required(null),
            submission_end_date: Joi.date().required(null),
            // bid_opening_place: Joi.string().allow(null),
            // bid_validity_date: Joi.date().allow(null),
            //national_intern: Joi.string().required(),
            // pre_bid_meeting_place: Joi.string().allow(null),
            // pre_bid_meeting_address: Joi.string().allow(null),
            // pre_bid_meeting_date: Joi.date().allow(null),
            // pre_bid_meeting_time: Joi.date().iso().allow(null),
            // tnd_url: Joi.string().allow(null),
            // pre_bid_meeting_link: Joi.string().allow(null),
            // pre_bid_mode: Joi.string().allow(null),
            user_comp_id: Joi.number().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required(),
            updated_at: Joi.date().iso().required()

        });

        const dataToValidate = {
            gg_tenderID: "BD" + Math.random().toString(36).substring(2, 10),
            user_comp_id: req.comp_id,
            tender_name: req.body.tender_name,
            tender_cost: req.body.tender_cost,
            tender_emd_amnt_val: req.body.tender_emd_amnt_val,
            submission_start_date: req.body.submission_start_date,
            submission_end_date: req.body.submission_end_date,
            currency_id: req.body.currency_id,
            // region_id: req.body.region_id,
            country_id: req.body.country_id,
            // state_id: req.body.state_id,
            // city_id: req.body.city_id,
            sector_id: req.body.sector_id,

            // funding_id: req.body.funding_id,
            //tender_result_id: req.body.tender_result_id,
            sector_id: req.body.sector_id,
            cycle_id: req.body.cycle_id,
            // national_intern: req.body.national_intern,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
            updated_at: getCurrentDateTime(),
        };

        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            try {
                const TenderModel = createTenderModel(req.comp_id);
                await TenderModel.performOperation();
                const TenderDocModel = createTenderDocModel(req.comp_id);
                await TenderDocModel.performOperation();
                dataToValidate.client_id = (req.body.client_id) ? req.body.client_id : null;
                dataToValidate.state_id = (req.body.state_id) ? req.body.state_id : null;
                dataToValidate.region_id = (req.body.region_id) ? req.body.region_id : null;
                dataToValidate.city_id = (req.body.city_id) ? req.body.city_id : null;
                const tender_check_exist = await TenderModel.findOne({ where: { user_comp_id: req.comp_id, tender_name: req.body.tender_name, status: '1' }, attributes: ['id', 'tender_name'] })
                if (!tender_check_exist) {
                    // const scope_current = await Tenderscope.findOne({
                    //     order: [['order_sr', 'ASC']],
                    //     where: {
                    //         user_comp_id: req.comp_id,
                    //         status: '1',
                    //         category: '1'
                    //     },
                    //     attributes: ['id', 'order_sr']
                    // });
                    // dataToValidate.cycle_id = scope_current.id
                    const insert = await TenderModel.create(dataToValidate)
                    console.log(insert.id, '++++++++++++++++')
                    if (insert) {
                        // const files = req.files;
                        if (req.files) {
                            const files = req.files;
                            const originalFolderPath = files[0].destination;
                            const newNumber = insert.id;
                            const pathSegments = files[0].destination.split('/');
                            pathSegments.pop();
                            pathSegments.push(newNumber);
                            const newFolderPath = pathSegments.join('/');
                            fs.rename(originalFolderPath, newFolderPath, (err) => {
                                if (err) {
                                    console.error('Error renaming folder:', err);
                                    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                        message: process.env.ERROR_MSG,
                                        error: true,
                                        success: false,
                                        status: '0',
                                    })
                                }
                            })
                            const fileRecords = await TenderDocModel.bulkCreate(files.map((file) => (
                                {
                                    created_by: req.userId,
                                    user_comp_id: req.comp_id,
                                    bg_tender_id: insert.id,
                                    file_name: file.filename,
                                    type: 3,
                                    doc_path: newFolderPath
                                })));
                            if (!fileRecords[0]) {
                                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                    message: process.env.ERROR_MSG,
                                    error: true,
                                    success: false,
                                    status: '0',
                                })
                            }
                        }
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',
                            data: insert,
                        });
                    }
                }
                else {
                    const files = req.files;
                    if (files) {
                        files.forEach(record => {
                            const filePath = record.path;
                            if (filePath) {
                                fs.unlink(filePath, err => {
                                });
                            }
                        })
                    }
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                });
            }
        }
    });
};


const live_tender_doc_storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'tender' + '/' + year + '/' + month + '/' + day + '/' + req.userId + '-' + req.comp_id;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        //console.log("Ash :- "+extension);
        cb(null, Date.now() + 'tenderdoc_' + Math.random() + extension); // Rename file with a timestamp
    },
});


const tender_doc_upload = multer({ storage: live_tender_doc_storage });
const addTenderDoc = async (req, res) => {
    tender_doc_upload.array('tender_doc')(req, res, async function (err) {
        const schema = Joi.object().keys({
            tender_id: Joi.number().required(),
            file_name: Joi.string().required(),
            comment: Joi.string().allow(null),
            type: Joi.number().required(),
            user_comp_id: Joi.number().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required()
        });

        const dataToValidate = {
            tender_id: req.body.tender_id,
            file_name: req.files[0].filename,
            user_comp_id: req.comp_id,
            type: req.body.type,
            comment: req.body.comment,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            try {
                const TenderModel = createTenderModel(req.comp_id);
                await TenderModel.performOperation();
                const response_exist = await TenderModel.findOne({
                    where: { status: '1', id: req.body.tender_id, user_comp_id: req.comp_id },
                })
                if (response_exist) {
                    const files = req.files;
                    if (files[0]) {
                        const originalFolderPath = files[0].destination;
                        const newNumber = req.body.tender_id;
                        const pathSegments = originalFolderPath.split('/');
                        pathSegments.pop();
                        const newFolderPath = path.join(pathSegments.join('/'), newNumber);
                        if (!fs.existsSync(newFolderPath)) {
                            fs.mkdirSync(newFolderPath);
                        }
                        files.forEach((file) => {
                            const oldPath = path.join(originalFolderPath, file.filename);
                            const newPath = path.join(newFolderPath, file.filename);
                            fs.rename(oldPath, newPath, (err) => {
                                // if (err) {
                                //     res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                //         message: process.env.ERROR_MSG,
                                //         error: 'sllsls',
                                //         success: false,
                                //         status: '0',
                                //     });
                                // }
                            });
                        });
                        const fileRecords = await TenderDocModel.bulkCreate(files.map((file) =>
                        ({
                            created_by: req.userId, user_comp_id: req.comp_id, tender_id: req.body.tender_id,
                            file_name: file.filename, comment: req.body.comment, type: req.body.type, doc_path: newFolderPath, created_at: getCurrentDateTime()
                        })));
                        if (fileRecords.length > 0) {
                            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: `${fileRecords.length} records inserted successfully`,
                                error: false,
                                success: true,
                                status: '1',
                            });
                        }
                    }
                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
};
const DeleteTenderDoc = async (req, res) => {
    tender_doc_upload.array('tender_doc')(req, res, async function (err) {
        const schema = Joi.object().keys({
            tender_id: Joi.number().required(),
            docs_id: Joi.number().required(),

        });

        const dataToValidate = {
            tender_id: req.body.tender_id,
            docs_id: req.body.docs_id,

        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            try {
                const TenderModel = createTenderModel(req.comp_id);
                await TenderModel.performOperation();
                const response_exist = await TenderModel.findOne({
                    where: { status: '1', id: req.body.tender_id, user_comp_id: req.comp_id },
                })
                if (response_exist) {
                    const updArr = {
                        status: '0',
                    }
                    const fileRecords = await TenderDocModel.update(updArr, {
                        where: {
                            id: req.body.docs_id, tender_id: req.body.tender_id, status: '1', user_comp_id: req.comp_id
                        }
                    });
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
};

const edittenderdetail = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderDocModel = createTenderDocModel(req.comp_id);
            await TenderDocModel.performOperation();
            const key_client_manger = await TenderAssignManagerModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', tender_id: req.body.tender_id, bd_role_id: '1'
                },
                include: [{
                    model: TenderBdRoleModel,
                    attributes: ['id', 'role_name'],
                    // as: 'fin_ref_detail',
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['id', 'userfullname'],
                    // as: 'fin_ref_detail',
                    where: { isactive: '1', },
                    required: false,

                },

                ]
            })
            const Bid_Manager = await TenderAssignManagerModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', tender_id: req.body.tender_id, bd_role_id: '2'
                },
                include: [{
                    model: TenderBdRoleModel,
                    attributes: ['id', 'role_name'],
                    // as: 'fin_ref_detail',
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['id', 'userfullname'],
                    // as: 'fin_ref_detail',
                    where: { isactive: '1', },
                    required: false,

                }
                ]
            })
            //console.log("Bid_Manager:", Bid_Manager);
            // Bid_Manager
            const Bid_Executive = await TenderAssignManagerModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', tender_id: req.body.tender_id, bd_role_id: '3'
                },
                include: [{
                    model: TenderBdRoleModel,
                    attributes: ['id', 'role_name'],
                    // as: 'fin_ref_detail',
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['id', 'userfullname'],
                    // as: 'fin_ref_detail',
                    where: { isactive: '1', },
                    required: false,

                }

                ]
            })
            const RFP_Reviewer = await TenderAssignManagerModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', tender_id: req.body.tender_id, bd_role_id: '4'
                },
                include: [{
                    model: TenderBdRoleModel,
                    attributes: ['id', 'role_name'],
                    // as: 'fin_ref_detail',
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['id', 'userfullname'],
                    // as: 'fin_ref_detail',
                    where: { isactive: '1', },
                    required: false,

                }]
            })
            const edittender = await TenderModel.findOne({
                where: { id: req.body.tender_id, user_comp_id: req.comp_id },
                attributes: {
                    exclude: ['user_comp_id', 'created_by', 'modified_by', 'status', 'created_at', 'updated_at']
                },
                include: [{
                    model: TenderGeneratedTypeIdModel,
                    attributes: ['generated_tender_id'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: Country,
                    attributes: ['country_name'],
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: State,
                    attributes: ['state_name'],
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: City,
                    attributes: ['city_name'],
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Tendersector,
                    attributes: ['sector_name'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: TenderClient,
                    attributes: ['client_name'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: Tenderscope,
                    attributes: [['id', 'scope_id'], 'order_sr', 'cycle_name'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: TenderAssignManagerModel,
                    attributes: ['bd_role_id', 'created_at'],
                    where: { status: '1' },
                    as: 'assign_tender',
                    required: false,
                    include: [
                        {
                            model: TenderBdRoleModel,
                            attributes: ['role_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: Users,
                            attributes: ['userfullname'],
                            where: { isactive: '1' },
                            required: false,
                        }
                    ]
                },
                {
                    model: TenderStatusManage,
                    attributes: ['tender_status'],
                    where: { status: '1' },
                    required: false,
                    include: {
                        model: TenderStatus,
                        attributes: ['status_name'],
                        where: { status: '1' },
                        required: false,
                    }
                }],
            });
            const tenderrec = {
                edittender: edittender
            }
            const tenderdocs = await TenderDocModel.findAll({ where: { user_comp_id: req.comp_id, bg_tender_id: edittender.id, status: '1' } });

            const datareturn = {
                edittender,
                tenderdocs,
                Bid_Manager,
                // Bid_Executive,
                key_client_manger,
                // RFP_Reviewer

            }
            if (!edittender) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    // message: process.env.APIRESPMSG_RECNOTFOUND,
                    message: error.message,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    source_1: process.env.DOCS_CATEGORY_1,
                    source_2: process.env.DOCS_CATEGORY_2,
                    data: datareturn,
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                //  message: process.env.ERROR_MSG,
                message: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

// const edittenderdetail = async (req, res) => {
//     const schema = Joi.object().keys({
//         tender_id: Joi.number().required(),
//     });

//     const dataToValidate = {
//         tender_id: req.body.tender_id,
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     } else {
//         try {
//             const TenderModel = createTenderModel(req.comp_id);
//             await TenderModel.performOperation();

//             const TenderDocModel = createTenderDocModel(req.comp_id);
//             await TenderDocModel.performOperation();

//             const edittender = await TenderModel.findOne({
//                 where: { id: req.body.tender_id, user_comp_id: req.comp_id }, 
//                 attributes: { exclude: ['user_comp_id', 'created_by', 'modified_by', 'status', 'created_at', 'updated_at'] },
//             });

//             if (!edittender) {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: error.message,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else {
//                 const key_client_manager = await TenderAssignManagerModel.findOne({
//                     where: {
//                         user_comp_id: req.comp_id, status: '1', tender_id: req.body.tender_id, bd_role_id: '1'
//                     }
//                 });

//                 const bid_manager = await TenderAssignManagerModel.findOne({
//                     where: {
//                         user_comp_id: req.comp_id, status: '1', tender_id: req.body.tender_id, bd_role_id: '2'
//                     }
//                 });

//                 const responseData = {
//                     edittender,
//                     tenderdocs: await TenderDocModel.findAll({ where: { user_comp_id: req.comp_id, bg_tender_id: edittender.id, status: '1' } }),
//                 };

//                 // Include key_client_manager if it exists and is not null, empty, or undefined
//                 if (key_client_manager) {
//                     responseData.key_client_manager = key_client_manager;
//                 }

//                 // Include bid_manager if it exists and is not null, empty, or undefined
//                 if (bid_manager) {
//                     responseData.bid_manager = bid_manager;
//                 }

//                 res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                     message: process.env.APIRESPMSG_RECFOUND,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     source_1: process.env.DOCS_CATEGORY_1,
//                     source_2: process.env.DOCS_CATEGORY_2,
//                     data: responseData,
//                 });
//             }

//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: error.message,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// };


// const updateTenderdetail = async (req, res) => {
//     const schema = Joi.object().keys({
//         tender_id: Joi.number().required(),
//         tender_name: Joi.string().required(),
//         gg_tenderID: Joi.string().allow(null),
//         tnd_ref_id: Joi.string().allow(null),
//         tender_gov_id: Joi.string().allow(null),

//         tender_cost: Joi.number().required(),
//         tender_emd_amnt_val: Joi.number().required(),
//         client_id: Joi.number().required(),
//         currency_id: Joi.number().required(),
//         region_id: Joi.number().required(),
//         country_id: Joi.number().required(),
//         state_id: Joi.number().required(),
//         city_id: Joi.number().required(),
//         sector_id: Joi.number().required(),
//         funding_id: Joi.number().required(),

//         client_cont_person: Joi.string().allow(null),
//         client_cont_address: Joi.string().allow(null),
//         email_id: Joi.string().allow(null),
//         phone_no: Joi.string().allow(null),
//         publication_date: Joi.date().allow(null),
//         submission_start_date: Joi.date().allow(null),
//         submission_end_date: Joi.date().allow(null),
//         bid_opening_place: Joi.string().allow(null),
//         bid_validity_date: Joi.date().allow(null),
//         national_intern: Joi.string().required(),
//         pre_bid_meeting_place: Joi.string().allow(null),
//         pre_bid_meeting_address: Joi.string().allow(null),
//         pre_bid_meeting_date: Joi.date().allow(null),
//         pre_bid_meeting_time: Joi.date().iso().allow(null),
//         tnd_url: Joi.string().allow(null),
//         pre_bid_meeting_link: Joi.string().allow(null),
//         pre_bid_mode: Joi.string().allow(null),

//         user_comp_id: Joi.number().required(),
//         modified_by: Joi.number().required(),
//         updated_at: Joi.date().iso().required()

//     });

//     const dataToValidate = {
//         user_comp_id: req.comp_id,
//         tender_name: req.body.tender_name,
//         tender_id: req.body.tender_id,
//         tender_cost: req.body.tender_cost,
//         tender_emd_amnt_val: req.body.tender_emd_amnt_val,
//         client_id: req.body.client_id,
//         submission_start_date: req.body.submission_start_date,
//         submission_end_date: req.body.submission_end_date,
//         currency_id: req.body.currency_id,
//         region_id: req.body.region_id,
//         country_id: req.body.country_id,
//         state_id: req.body.state_id,
//         city_id: req.body.city_id,
//         sector_id: req.body.sector_id,
//         funding_id: req.body.funding_id,
//         sector_id: req.body.sector_id,
//         // cycle_id:req.body.cycle_id,
//         national_intern: req.body.national_intern,
//         modified_by: req.userId,
//         updated_at: getCurrentDateTime(),
//     };

//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0'
//         });
//     } else {
//         try {
//             const TenderModel = createTenderModel(req.comp_id);
//             await TenderModel.performOperation();
//             const tender_check_exist = await TenderModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.tender_id, status: '1' }, attributes: ['id', 'tender_name'] })
//             if (tender_check_exist) {
//                 const update = await TenderModel.update(dataToValidate, {
//                     where: { id: req.body.tender_id, user_comp_id: req.comp_id }
//                 })
//                 if (update) {
//                     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                         message: process.env.APIRESPMSG_RECUPDATED,
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: update,
//                     });
//                 }
//             }
//             else {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// };


// const updateTenderdetail = async (req, res) => {
//     const schema = Joi.object().keys({
//         tender_id: Joi.number().required(),
//         tender_name: Joi.string().required(),
//         tender_cost: Joi.number().required(),
//         client_id: Joi.number().required(),
//         currency_id: Joi.number().required(),
//         country_id: Joi.number().required(),
//         state_id: Joi.number().required(),
//         sector_id: Joi.number().required(),
//         funding_id: Joi.number().required(),
//         submission_end_date: Joi.date().required(),
//     });

//     const dataToValidate = {
//         tender_name: req.body.tender_name,
//         tender_id: req.body.tender_id,
//         tender_cost: req.body.tender_cost,
//         client_id: req.body.client_id,
//         submission_end_date: req.body.submission_end_date,
//         currency_id: req.body.currency_id,
//         country_id: req.body.country_id,
//         state_id: req.body.state_id,
//         sector_id: req.body.sector_id,
//         funding_id: req.body.funding_id,

//     };

//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0'
//         });
//     } else {
//         try {
//             const TenderModel = createTenderModel(req.comp_id);
//             await TenderModel.performOperation();

//             const tender_check_exist = await TenderModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.tender_id, status: '1' }, attributes: ['id', 'tender_name', 'cycle_id'] })
//             if (tender_check_exist) {
//                 const tebder_upd = {
//                     tender_name: req.body.tender_name,
//                     tender_cost: req.body.tender_cost,
//                     client_id: req.body.client_id,
//                     submission_start_date: (req.body.submission_start_date) ? req.body.submission_start_date : null,
//                     submission_end_date: req.body.submission_end_date,
//                     currency_id: req.body.currency_id,
//                     country_id: req.body.country_id,
//                     state_id: req.body.state_id,
//                     region_id:(req.body.region_id) ? req.body.region_id :null ,
//                     pre_bid_meeting_date: (req.body.pre_bid_meeting_date) ? req.body.pre_bid_meeting_date : null,
//                     bid_validity_date: (req.body.bid_validity_date) ? req.body.bid_validity_date : null,
//                     client_cont_person: (req.body.client_cont_person) ? req.body.client_cont_person : null,
//                     client_cont_address: (req.body.client_cont_address) ? req.body.client_cont_address : null,
//                     funding_id: (req.body.funding_id) ? req.body.funding_id : null,
//                     pre_bid_attend_by: (req.body.pre_bid_attend_by) ? req.body.pre_bid_attend_by : null,
//                     tender_emd_amnt_val: (req.body.tender_emd_amnt_val) ? req.body.tender_emd_amnt_val : null,
//                     modified_by: req.userId,
//                     updated_at: getCurrentDateTime()
//                 }
//                 const update = await TenderModel.update(tebder_upd, {
//                     where: { id: req.body.tender_id, user_comp_id: req.comp_id }
//                 })

//                 if ((req.body.submission_start_date) || (req.body.submission_end_date)) {
//                     const TenderDateModel = createTenderModelDate(req.comp_id);
//                     await TenderDateModel.performOperation();
//                     const response_date = await TenderDateModel.findOne({
//                         where: {
//                             user_comp_id: req.comp_id, status: '1', tg_tender_id: req.body.tender_id
//                         },
//                     })
//                     if (response_date) {
//                         const updatedData = {
//                             bid_submission_start_date: (req.body.submission_start_date) ? req.body.submission_start_date : null,
//                             bid_submission_end_date: req.body.submission_end_date,
//                             modified_by: req.userId,
//                             updated_at: getCurrentDateTime()
//                         }

//                         await TenderDateModel.update(updatedData, {
//                             where: {
//                                 user_comp_id: req.comp_id,
//                                 tg_tender_id: req.body.tender_id,
//                                 status: '1'

//                             }
//                         })
//                     }


//                 }

//                 const get_sr_nmbr = await Tenderscope.findOne({ where: { user_comp_id: req.comp_id, id: tender_check_exist.cycle_id, status: '1' }, attributes: ['id', 'order_sr'] })
//                 if (get_sr_nmbr.order_sr >= 6) {
//                     const check_exist_genrated_id = await TenderGenTypeIdModel.count({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '1' }, attributes: ['id'] })
//                     if (check_exist_genrated_id < 1) {
//                         return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                             message: 'Genrated id less then one',
//                             error: true,
//                             success: false,
//                             status: '0',
//                         });

//                     }
//                     if (req.body.key_client_manager) {
//                         const existingManager = await TenderAssignManagerModel.findOne({
//                             where: {
//                                 user_comp_id: req.comp_id,
//                                 tender_id: req.body.tender_id,
//                                 bd_role_id: 1,
//                                 status: '1'
//                             }
//                         })
//                         const updatedData = {
//                             assign_to: req.body.key_client_manager,
//                             modified_by: req.userId,
//                             updated_at: getCurrentDateTime()
//                         }

//                         if (existingManager) {
//                             await TenderAssignManagerModel.update(updatedData, {
//                                 where: {
//                                     user_comp_id: req.comp_id,
//                                     tender_id: req.body.tender_id,
//                                     bd_role_id: 1,
//                                     status: '1'

//                                 }
//                             })

//                         } else {
//                             const createData = {
//                                 user_comp_id: req.comp_id,
//                                 tender_id: req.body.tender_id,
//                                 bd_role_id: 1,
//                                 assign_to: req.body.key_client_manager,
//                                 created_by: req.userId,
//                                 created_at: getCurrentDateTime()
//                             }

//                             // await TenderAssignManagerModel.create(createData);

//                         }
//                     }

//                     if (req.body.bid_manager) {
//                         const existingManager = await TenderAssignManagerModel.findOne({
//                             where: {
//                                 user_comp_id: req.comp_id,
//                                 tender_id: req.body.tender_id,
//                                 bd_role_id: 2,
//                                 status: '1'
//                             }
//                         })
//                         const updatedData = {
//                             assign_to: req.body.bid_manager,
//                             modified_by: req.userId,
//                             updated_at: getCurrentDateTime()
//                         }

//                         if (existingManager) {
//                             await TenderAssignManagerModel.update(updatedData, {
//                                 where: {
//                                     user_comp_id: req.comp_id,
//                                     tender_id: req.body.tender_id,
//                                     bd_role_id: 2,
//                                     status: '1'

//                                 }
//                             })

//                         } else {
//                             updatedData.user_comp_id = req.comp_id
//                             updatedData.tender_id = req.body.tender_id
//                             updatedData.bd_role_id = 2
//                             updatedData.created_by = req.userId
//                             updatedData.created_at = getCurrentDateTime()
//                             // await TenderAssignManagerModel.create(updatedData);


//                         }
//                     }
//                 } else {
//                     return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                         message: 'Serial number less then 6',
//                         error: true,
//                         success: false,
//                         status: '0',
//                     });
//                 }

//                 if (update) {
//                     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                         message: process.env.APIRESPMSG_RECUPDATED,
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: update,
//                     });
//                 }
//             }
//             else {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// };

const updateTenderdetail = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        tender_name: Joi.string().required(),
        // client_id: Joi.number().required(),
        currency_id: Joi.number().required(),
        country_id: Joi.number().required(),
        // state_id: Joi.number().required(),
        sector_id: Joi.number().required(),
        submission_end_date: Joi.date().required(),
    });

    const dataToValidate = {
        tender_name: req.body.tender_name,
        tender_id: req.body.tender_id,
        // client_id: req.body.client_id,
        submission_end_date: req.body.submission_end_date,
        currency_id: req.body.currency_id,
        country_id: req.body.country_id,
        // state_id: req.body.state_id,
        sector_id: req.body.sector_id,


    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0'
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const tender_check_exist = await TenderModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.tender_id, status: '1' }, attributes: ['id', 'tender_name', 'cycle_id'] })
            if (tender_check_exist) {
                const tebder_upd = {
                    tender_name: req.body.tender_name,
                    tender_cost: req.body.tender_cost,
                    client_id: (req.body.client_id) ? req.body.client_id : null,
                    publication_date: (req.body.publication_date) ? req.body.publication_date : null,
                    submission_start_date: (req.body.submission_start_date) ? req.body.submission_start_date : null,
                    submission_end_date: req.body.submission_end_date,
                    currency_id: req.body.currency_id,
                    sector_id: req.body.sector_id,
                    country_id: req.body.country_id,
                    state_id: (req.body.state_id) ? req.body.state_id : null,
                    city_id: (req.body.city_id) ? req.body.city_id : null,
                    region_id: (req.body.region_id) ? req.body.region_id : null,
                    pre_bid_meeting_date: (req.body.pre_bid_meeting_date) ? req.body.pre_bid_meeting_date : null,
                    bid_validity_date: (req.body.bid_validity_date) ? req.body.bid_validity_date : null,
                    client_cont_person: (req.body.client_cont_person) ? req.body.client_cont_person : null,
                    client_cont_address: (req.body.client_cont_address) ? req.body.client_cont_address : null,
                    funding_id: (req.body.funding_id) ? req.body.funding_id : null,
                    pre_bid_attend_by: (req.body.pre_bid_attend_by) ? req.body.pre_bid_attend_by : null,
                    tender_emd_amnt_val: (req.body.tender_emd_amnt_val) ? req.body.tender_emd_amnt_val : null,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime()
                }
                const update = await TenderModel.update(tebder_upd, {
                    where: { id: req.body.tender_id, user_comp_id: req.comp_id }
                });
                // Fetch the updated record
                const updatedRecord = await TenderModel.findOne({ where: { id: req.body.tender_id, user_comp_id: req.comp_id } });
                if ((req.body.submission_start_date) || (req.body.submission_end_date)) {
                    const TenderDateModel = createTenderModelDate(req.comp_id);
                    await TenderDateModel.performOperation();
                    const response_date = await TenderDateModel.findOne({
                        where: {
                            user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.tender_id
                        },
                    })
                    if (response_date) {
                        const updatedData = {
                            bid_submission_start_date: (req.body.submission_start_date) ? req.body.submission_start_date : null,
                            bid_submission_end_date: req.body.submission_end_date,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime()
                        }

                        await TenderDateModel.update(updatedData, {
                            where: {
                                user_comp_id: req.comp_id,
                                tg_tender_id: req.body.tender_id,
                                status: '1'

                            }
                        })
                    }
                }
                const get_sr_nmbr = await Tenderscope.findOne({ where: { user_comp_id: req.comp_id, id: tender_check_exist.cycle_id, status: '1' }, attributes: ['id', 'order_sr'] })
                if ((req.body.bid_manager) || (req.body.key_client_manager)) {
                    if (get_sr_nmbr.order_sr >= 6) {
                        const check_exist_genrated_id = await TenderGenTypeIdModel.count({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '1' }, attributes: ['id'] })
                        if (check_exist_genrated_id < 1) {
                            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                message: 'Generated ID Is Not Define',
                                error: true,
                                success: false,
                                status: '0',
                            });
                        }
                        if (req.body.key_client_manager) {
                            const existingManager = await TenderAssignManagerModel.findOne({
                                where: {
                                    user_comp_id: req.comp_id,
                                    tender_id: req.body.tender_id,
                                    bd_role_id: 1,
                                    status: '1'
                                }
                            })
                            const updatedData = {
                                assign_to: req.body.key_client_manager || null,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime()
                            }

                            if (existingManager) {
                                await TenderAssignManagerModel.update(updatedData, {
                                    where: {
                                        user_comp_id: req.comp_id,
                                        tender_id: req.body.tender_id,
                                        bd_role_id: 1,
                                        status: '1'
                                    }
                                })
                            } else {
                                const createData = {
                                    user_comp_id: req.comp_id,
                                    tender_id: req.body.tender_id,
                                    bd_role_id: 1,
                                    assign_to: req.body.key_client_manager || null,
                                    created_by: req.userId,
                                    created_at: getCurrentDateTime()
                                }
                                await TenderAssignManagerModel.create(createData);
                            }
                        }
                        if (req.body.bid_manager) {
                            const existingManager1 = await TenderAssignManagerModel.findOne({
                                where: {
                                    user_comp_id: req.comp_id,
                                    tender_id: req.body.tender_id,
                                    bd_role_id: 2,
                                    status: '1'
                                }
                            })
                            const updatedData1 = {
                                assign_to: req.body.bid_manager || null,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime()
                            }

                            if (existingManager1) {
                                await TenderAssignManagerModel.update(updatedData1, {
                                    where: {
                                        user_comp_id: req.comp_id,
                                        tender_id: req.body.tender_id,
                                        bd_role_id: 2,
                                        status: '1'
                                    }
                                })
                            }
                            else {
                                updatedData.user_comp_id = req.comp_id
                                updatedData.tender_id = req.body.tender_id
                                updatedData.bd_role_id = 2
                                updatedData.created_by = req.userId
                                updatedData.created_at = getCurrentDateTime()
                                await TenderAssignManagerModel.create(updatedData);
                            }
                        }
                    } else {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: 'Proposal Manager Not Assign On This  Scope',
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                }
                if (update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        // data: updatedRecord, // Returning the updated record
                    });
                }
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};


/*****************Tender cycle method********************************/

//assign tender cycle inaction btn 
const addtndrcycleinactionbtn = async (req, res) => {
    const schema = Joi.object().keys({
        cycle_id: Joi.number().required(),
        inaction_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        cycle_id: req.body.cycle_id,
        inaction_id: req.body.inaction_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const assign_tndr_cycle_inaction = await TenderCycleAssignInactionModel.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    cycle_id: req.body.cycle_id,
                    inaction_id: req.body.inaction_id,
                    status: '1'
                }, attributes: ['id', 'cycle_id', 'inaction_id']
            })
            if (!assign_tndr_cycle_inaction) {
                const insert = await TenderCycleAssignInactionModel.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender cycle inaction btn 
const edittndrcycleinactionbtn = async (req, res) => {
    const schema = Joi.object().keys({
        cycle_inaction_id: Joi.number().required(),
    });

    const dataToValidate = {
        cycle_inaction_id: req.body.cycle_inaction_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const edittndrcycinaction = await TenderCycleAssignInactionModel.findOne({
                where: { id: req.body.cycle_inaction_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'cycle_id', 'inaction_id'],
            })
            if (!edittndrcycinaction) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: edittndrcycinaction,
            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender cycle inaction btn 
const updatetndrcycleinactionbtn = async (req, res) => {
    const schema = Joi.object().keys({
        cycle_inaction_id: Joi.number().required(),
        cycle_id: Joi.string().required(),
        inaction_id: Joi.string().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        cycle_id: req.body.cycle_id,
        inaction_id: req.body.inaction_id,
        cycle_inaction_id: req.body.cycle_inaction_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const updatetndrcycinaction = await TenderCycleAssignInactionModel.findOne({
                where:
                {
                    user_comp_id: req.comp_id,
                    id: req.body.cycle_inaction_id,
                    // cycle_id: req.body.cycle_id,
                    // inaction_id: req.body.inaction_id,
                    status: '1',
                }, attributes: ['id', 'cycle_id', 'inaction_id']
            })
            if (updatetndrcycinaction) {
                const tndrcycinaction_update_obj = {
                    cycle_id: req.body.cycle_id,
                    inaction_id: req.body.inaction_id,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update_tndrcycinaction = await TenderCycleAssignInactionModel.update(tndrcycinaction_update_obj, {
                    where: { id: req.body.cycle_inaction_id, user_comp_id: req.comp_id, status: '1' },
                });
                if (update_tndrcycinaction) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete tender cycle inaction btn 
const deletetndrcycleinactionbtn = async (req, res) => {
    const schema = Joi.object().keys({
        cycle_inaction_id: Joi.number().required(),
    });

    const dataToValidate = {
        cycle_inaction_id: req.body.cycle_inaction_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletetndrcycleinaction = await TenderCycleAssignInactionModel.findOne({
                where: { id: req.body.cycle_inaction_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'cycle_id', 'inaction_id'],
            })
            if (deletetndrcycleinaction) {
                const delete_tndr_cycle_inaction_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                };
                const deletetndrcycleinactionrec = await TenderCycleAssignInactionModel.update(delete_tndr_cycle_inaction_obj, {
                    where: { id: req.body.cycle_inaction_id, user_comp_id: req.comp_id, status: '1' },
                });
                if (deletetndrcycleinactionrec) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: deletetndrcycleinactionrec
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//tender tender cycle inaction btn
const tndrcycleinactionlist = async (req, res) => {
    const schema = Joi.object().keys({
        scope_id: Joi.number().required(),
    });

    const dataToValidate = {
        scope_id: req.body.scope_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const list = await TenderCycleAssignInactionModel.findAll({
                where: { user_comp_id: req.comp_id, status: '1', cycle_id: req.body.scope_id }, attributes: ['id', 'cycle_id', 'inaction_id'],
                order: [['inaction_id', 'ASC']],
                include: [{
                    model: Inaction,
                    attributes: ['inaction_name', 'image_name'],
                    where: { status: '1' },
                    required: false,
                },
                    // {
                    //     model: Scope,
                    //     attributes: ['scope_name'],
                    //     where: { status: '1' },
                    //     required: false,
                    // }
                ]
            })
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: false,
                    success: true,
                    status: '1'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }


}


//assign tender cycle moved btn 
const addtndrcyclemovedbtn = async (req, res) => {
    const schema = Joi.object().keys({
        cycle_id: Joi.number().required(),
        inaction_id: Joi.number().required(),
        tender_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        cycle_id: req.body.cycle_id,
        inaction_id: req.body.inaction_id,
        tender_id: req.body.tender_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const move_tndr_cycle_inaction = await TenderModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.tender_id, status: '1' }, attributes: ['id'] })
            if (move_tndr_cycle_inaction) {
                const insert = await TenderMovedHistroyByUserModel.create(dataToValidate);
                if (insert) {
                    const update_tndr_move_scope = {
                        cycle_id: req.body.cycle_id,
                        modified_by: req.userId,
                        updated_at: getCurrentDateTime(),
                    };
                    const update_tndr_move_obj = await TenderModel.update(update_tndr_move_scope, {
                        where: { id: req.body.tender_id, user_comp_id: req.comp_id },
                    });
                    if (update_tndr_move_obj) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',
                            data: update_tndr_move_obj
                        });
                    }

                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


//bulk update tender cycle
const bulkupdatetndrcycle = async (req, res) => {
    const schema = Joi.object().keys({
        inaction_id: Joi.number().required(),
        tender_ids: Joi.string().pattern(/^[0-9,]+$/).required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        inaction_id: req.body.inaction_id,
        tender_ids: req.body.tender_ids,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const delimiter = ',';
            const response_data = dataToValidate.tender_ids.split(delimiter);

            const existingRecords = [];
            const recordsToCreate = [];

            // Split the data into existing and new records
            for (const data of response_data) {
                const existingRecord = await TenderMovedHistroyByUserModel.findOne({ where: { cycle_id: 1, inaction_id: req.body.inaction_id, tender_id: data, user_comp_id: req.comp_id } });
                if (existingRecord) {
                    existingRecords.push(existingRecord);
                } else {
                    recordsToCreate.push({
                        cycle_id: 1,
                        inaction_id: req.body.inaction_id,
                        tender_id: data,
                        user_comp_id: req.comp_id,
                        created_by: req.userId,
                        created_at: getCurrentDateTime(),
                    });
                }
            }


            if (recordsToCreate.length > 0) {
                const fileRecords = await TenderMovedHistroyByUserModel.bulkCreate(recordsToCreate);
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: `${fileRecords.length} records inserted successfully`,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//assign tender cycle moved btn 
const addtndrcycleassignmanagerbtn = async (req, res) => {
    const schema = Joi.object().keys({
        assign_to: Joi.number().required(),
        bd_role_id: Joi.number().required(),
        tender_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        assign_to: req.body.assign_to,
        bd_role_id: req.body.bd_role_id,
        tender_id: req.body.tender_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const assign_tender_person = await TenderModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.tender_id, cycle_id: 2, status: '1' }, attributes: ['id'] })
            if (assign_tender_person) {
                const check_tender_person = await TenderAssignManagerModel.findOne({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, bd_role_id: req.body.bd_role_id, status: '1' }, attributes: ['id'] })
                if (!check_tender_person) {
                    const insert = await TenderAssignManagerModel.create(dataToValidate);
                    // if (insert) {
                    //     res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    //         message: process.env.APIRESPMSG_RECUPDATED,
                    //         error: false,
                    //         success: true,
                    //         status: '1',
                    //         data: insert
                    //     });
                    // }
                    if (insert) {
                        // API call to send email
                        try {
                            let result = await axios.post('https://api.growthgrids.com/bid_grid_superadmin/api/auth/get_keyclient_emails', null, {
                                headers: {
                                    'Cookie': 'PHPSESSID=nu45tloiik729hmf7taovaehln; PHPSESSID=ucd7503msprk743o5gu7o141lj; PHPSESSID=nu45tloiik729hmf7taovaehln'
                                },
                                params: {
                                    project_id: req.body.tender_id,
                                    user_comp_id: req.comp_id,
                                    from_id: 78,
                                    to_id: req.body.assign_to
                                }
                            });
                            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECUPDATED,
                                error: false,
                                success: true,
                                status: '1',
                                data: insert
                            });
                        } catch (emailError) {
                            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                message: 'Record updated but failed to send email',
                                error: emailError.message,
                                success: true,
                                status: '1',
                                data: insert
                            });
                        }


                    }
                }
                else {
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//assign tender cycle generated id
const addtendernumbergenrated = async (req, res) => {
    //console.log('hi');
    const fin_year_string = '';
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
        generate_type_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
        generate_type_id: req.body.generate_type_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const assign_tender_no = await TenderModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.tender_id, cycle_id: 3, status: '1' }, attributes: ['id'] })
            if (assign_tender_no) {
                const check_tender_no = await TenderGeneratedTypeIdModel.findOne({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '1' }, attributes: ['id'] })
                if (!check_tender_no) {

                    //site configration code and financial year
                    const check_tender_config = await Siteconfiguration.findAll({
                        where: { user_comp_id: req.comp_id, status: '1' },
                        attributes: ['comp_letter_code', 'financial_year_id'],
                        include: [{
                            model: FinancialYear,
                            attributes: ['fin_year_type', 'id'],
                            where: { status: '1' },
                            required: false,
                        }]
                    });

                    if (check_tender_config) {
                        if (check_tender_config[0].bg_mstr_financial_year.id == '2') {
                            const today = new Date();
                            const currentYear = today.getFullYear();
                            const fin_year_string = `${currentYear}-${currentYear + 1}`;
                            if (fin_year_string) {
                                const check_tender_type = await TenderGeneratedTypeModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.generate_type_id, status: '1' }, attributes: ['generated_type_id'] })
                                if (check_tender_type) {
                                    console.log(check_tender_type.generated_type_id);
                                    const tndr_generated_arr = {
                                        tender_id: req.body.tender_id,
                                        generate_type_id: req.body.generate_type_id,
                                        generated_tender_id: check_tender_config[0].comp_letter_code + 'HO/BD' + fin_year_string + '/' + check_tender_type.generated_type_id,
                                        last_generated_id: 1,
                                        user_comp_id: req.comp_id,
                                        created_by: req.userId,
                                        created_at: getCurrentDateTime(),
                                    }
                                    const insert = await TenderGeneratedTypeIdModel.create(tndr_generated_arr);
                                    if (insert) {
                                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                            message: process.env.APIRESPMSG_RECUPDATED,
                                            error: false,
                                            success: true,
                                            status: '1',
                                            data: insert
                                        });
                                    }
                                }
                            }
                            else {
                                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                    message: process.env.ERROR_MSG,
                                    error: true,
                                    success: false,
                                    status: '0',
                                });
                            };
                        }
                        else {
                            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                message: process.env.ERROR_MSG,
                                error: true,
                                success: false,
                                status: '0',
                            });
                        }
                    }
                    else {
                        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                            message: process.env.ERROR_MSG,
                            error: error.message,
                            success: false,
                            status: '0',
                        });
                    }
                }

                else {
                    res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }

            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

        } catch (error) {
            // console.log(error,'errorerrorerror')
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}



/*****************Tender cycle method********************************/

const tnderuserhistotry = async (req, res) => {
    const schema = Joi.object().keys({
        scope_id: Joi.number().required(),
        limit: Joi.string().required(),
        page_number: Joi.string().required(),
    });
    const dataToValidate = {
        scope_id: req.body.scope_id,
        limit: req.body.limit,
        page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const page_number = parseInt(dataToValidate.page_number) || 1;
            const limit = parseInt(dataToValidate.limit) || 10;
            const offset = (parseInt(page_number) - 1) * parseInt(limit);
            const last_login_rec = await Users.findOne({
                where: { id: req.userId, isactive: '1' },
                attributes: ['last_login'],
            })
            const { count, rows } = await TenderMovedHistroyByUserModel.findAndCountAll({
                where: { user_comp_id: req.comp_id, status: '1', cycle_id: '1', created_by: req.userId },
                attributes: ['cycle_id'],
                offset,
                limit,
                include: [
                    //     {
                    //     model: Users,
                    //     attributes: ['userfullname'], // Add the attributes you want from TenderDetailsModel
                    //     required: false,
                    // },
                    {
                        model: TenderModel,
                        attributes: [['id', 'project_id'], 'tender_name', 'tender_cost', 'tender_emd_amnt_val', 'submission_start_date', 'submission_end_date'], // Add the attributes you want from TenderDetailsModel
                        required: false,
                        include: [{
                            model: Country,
                            attributes: ['country_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: State,
                            attributes: ['state_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: City,
                            attributes: ['city_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: Tendersector,
                            attributes: ['sector_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: TenderClient,
                            attributes: ['client_name'],
                            where: { status: '1' },
                            required: false,
                        },
                        ]

                    }],
            })
            if (rows[0]) {
                const response_data = {
                    last_login: last_login_rec.last_login,
                    move_history: rows
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    totalItems: count,
                    totalPages: Math.ceil(count / limit),
                    currentPage: page_number,
                    dataoncurrentPage: rows.length,
                    data: response_data,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                    // data: list
                });

            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',

            });
        }
    }
}


//Lising data..
const ListTenderScope = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
    });
    const dataToValidate = {
        tender_id: req.body.tender_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const existData = await TenderModel.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.tender_id }, attributes: ['id', 'cycle_id'] });
            if (existData) {
                const tenderScope = await Tenderscope.findAll({
                    order: [['id', 'ASC']],
                    limit: [1],
                    where: {
                        status: "1", user_comp_id: req.comp_id, id: {
                            [Op.gt]: existData.cycle_id
                        }
                    }, attributes: ['id', 'scope_name']
                });


                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tenderScope,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
            // res.status(400).send({ error: error.message });
        }
    }
}

const tenderscopeupdate = async (req, res) => {
    const schema = Joi.object().keys({
        tender_ids: Joi.string().pattern(/^[0-9,]+$/).required(),
        cycle_id: Joi.number().required(),
        inaction_ids: Joi.string().pattern(/^[0-9,]+$/).required(),
    });
    const dataToValidate = {
        tender_ids: req.body.tender_ids,
        cycle_id: req.body.cycle_id,
        inaction_ids: req.body.inaction_ids
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const tenderIdsArr = dataToValidate.tender_ids.split(",");
        const cycle_id = dataToValidate.cycle_id;
        const inaction_ids = dataToValidate.inaction_ids;
        var no = 0;
        try {
            if ((tenderIdsArr) && (inaction_ids) && (cycle_id)) {
                // const combinedLength = Math.max(tenderIdsArr.length, inactionIdsArr.length);
                // const combinedIdsArr = [];
                // for (let i = 0; i < combinedLength; i++) {
                //     const combinedObject = {
                //         'tender_id': tenderIdsArr[i] || '',
                //         'inaction_id': inactionIdsArr[i] || ''
                //     };
                //     combinedIdsArr.push(combinedObject);
                // }
                for (const data of tenderIdsArr) {
                    const TenderModel = createTenderModel(req.comp_id);
                    await TenderModel.performOperation();
                    const existingRecord = await TenderModel.findOne({
                        where: {
                            cycle_id: cycle_id, id: data, user_comp_id: req.comp_id, status: '1',
                            cycle_id: {
                                [Op.ne]: inaction_ids,
                            },
                        }
                    });
                    if (existingRecord) {
                        const updateDATA = {
                            cycle_id: inaction_ids,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),

                        }
                        await TenderModel.update(updateDATA, { where: { id: data, user_comp_id: req.comp_id, status: '1' } });
                        no++;
                    }
                }

            }
            if (no > 0) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: no + ' ' + process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}

//Lising data..
const ListTenderScope_bycycleId = async (req, res) => {
    const schema = Joi.object().keys({
        cycle_id: Joi.number().required(),
    });
    const dataToValidate = {
        cycle_id: req.body.cycle_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            // const existData = await TenderModel.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.tender_id }, attributes: ['id', 'cycle_id'] });
            const tenderScope = await Tenderscope.findAll({
                order: [['id', 'ASC']],
                limit: [1],
                where: {
                    status: "1", user_comp_id: req.comp_id, id: {
                        [Op.gt]: req.body.cycle_id
                    }
                }, attributes: ['id', 'scope_name']
            });
            if (tenderScope) {

                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tenderScope,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
            // res.status(400).send({ error: error.message });
        }
    }
}


//get Tender comment
const tenderCommentList = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {

        const list = await TenderCommentModel.findAll({
            // order: [['id', 'DESC']],
            where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: "1" },
            attributes: ['id', 'user_comp_id', 'tender_id', 'parent_id', 'comment_txt', ['file_attachment', 'file_name'], 'file_path', 'parent_id', 'ping_users_info', 'created_by', 'created_at']
        });
        console.log(list, "============================")
        try {
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    message1: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

// Add Number Generate Prefix
const AddNoGeneratePrefix = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        prefix_name: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        prefix_name: req.body.prefix_name,
        created_by: req.userId,
        created_at: getCurrentDateTime()
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const responsxist = await TenderGeneratedTypeIdModel.findOne({
                where: { status: '1', user_comp_id: req.comp_id }
            });
            const response_exist = await TenderNoGeneratePrefixModel.findOne({
                where: { status: '1', user_comp_id: req.comp_id }
            });
            if (!responsxist) {
                if (response_exist) {
                    const updObj = {
                        user_comp_id: req.comp_id,
                        prefix_name: req.body.prefix_name,
                        modified_by: req.userId,
                        updated_at: getCurrentDateTime()
                    };
                    const update = await TenderNoGeneratePrefixModel.update(updObj, {
                        where: { status: '1', user_comp_id: req.comp_id }
                    })
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '0'
                    });

                } else {
                    const response_insert = await TenderNoGeneratePrefixModel.create(dataToValidate);
                    if (response_insert) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',
                        });
                    }

                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'You Cant Update',
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


const listNoGeneratePrefix = async (req, res) => {

    try {

        const response_exist = await TenderNoGeneratePrefixModel.findAll({
            where: { status: '1', user_comp_id: req.comp_id }
        });
        if (response_exist) {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response_exist
            });

        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });

        }

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            // message: error.message,
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}
// Assign Tender Generated Ids
const AssignTenderGeneratedIds = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        tender_id: Joi.number().required(),
        generate_type_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        tender_id: req.body.tender_id,
        generate_type_id: req.body.generate_type_id,
        created_by: req.userId,
        created_at: getCurrentDateTime()
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const currentFinancialYear = getCurrentFinancialYear();
            const getGeneratePrefix = await TenderNoGeneratePrefixModel.findOne({
                where: { status: '1', user_comp_id: req.comp_id },
                attributes: ['id', 'prefix_name']
            })
            if (!getGeneratePrefix) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'first you add frefix',
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const getGenerateTypenameById = await TenderGeneratedTypeModel.findOne({
                    where: { status: '1', id: req.body.generate_type_id },
                    attributes: ['id', 'generated_type_id']
                })

                // const generatedLastId = await TenderGenTypeIdModel.findAndCountAll({
                //     where: { status: '1', financial_year:currentFinancialYear, generate_type_id: req.body.generate_type_id, user_comp_id: req.comp_id },
                //     attributes: ['id', 'generated_tender_id'],
                // })

                // const squance = generatedLastId.count + 1;

                const generatedLastId = await TenderGenTypeIdModel.findOne({
                    order: [['last_generated_id', 'DESC']],
                    where: { status: '1', financial_year: currentFinancialYear, generate_type_id: req.body.generate_type_id, user_comp_id: req.comp_id },
                    attributes: ['id', 'generated_tender_id', 'last_generated_id'],
                })

                const squance = generatedLastId.last_generated_id + 2;


                const generate_tndr_id = getGeneratePrefix.prefix_name + '/' + currentFinancialYear + '/' + getGenerateTypenameById.generated_type_id + squance;
                const tenderGenerateId = await TenderGeneratedTypeIdModel.findOne({
                    where: { status: '1', user_comp_id: req.comp_id, tender_id: req.body.tender_id },
                    attributes: ['id']
                })

                if (tenderGenerateId) {
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                else {
                    const insertObj = {
                        user_comp_id: req.comp_id,
                        tender_id: req.body.tender_id,
                        generated_tender_id: generate_tndr_id,
                        financial_year: currentFinancialYear,
                        generate_type_id: req.body.generate_type_id,
                        last_generated_id: generatedLastId.last_generated_id + 1,
                        created_by: req.userId,
                        created_at: getCurrentDateTime()
                    }

                    const response = await TenderGeneratedTypeIdModel.create(insertObj);
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: response
                    });
                }

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//Tender Generated Types
const tenderGenTypes = async (req, res) => {
    try {
        const tenderGenTypelist = await TenderGenTypeModel.findAll({
            where: { user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'generated_type', 'generated_type_id'],
        })
        if (!tenderGenTypelist[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tenderGenTypelist
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}


//Tender Generated Types
const lastTenderGenerateId = async (req, res) => {
    try {
        const lastTndrGenId = await TenderGeneratedTypeIdModel.findAll({
            where: { user_comp_id: req.comp_id, status: '1', generate_type_id: req.body.generate_type_id },
            attributes: ['id', 'generate_type_id', 'generated_tender_id'],
            order: [['id', 'DESC']],
            limit: 1
        })
        if (!lastTndrGenId[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: lastTndrGenId
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            // message: error.message,
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}










const tenderAssignManager = async (req, res) => {

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        tender_id: Joi.number().required(),
        bd_role_id: Joi.number().required(),
        assign_to: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        tender_id: req.body.tender_id,
        bd_role_id: req.body.bd_role_id,
        assign_to: req.body.assign_to,
        created_by: req.userId,
        created_at: getCurrentDateTime()
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const respExist = await TenderAssignManagerModel.findOne({
                where: { status: '1', user_comp_id: req.comp_id, tender_id: req.body.tender_id, bd_role_id: req.body.bd_role_id },
                attributes: ['id']
            })
            const user_rec = await Users.findOne({
                where: { isactive: '1', comp_id: req.comp_id, id: req.body.assign_to },
                attributes: ['id', 'userfullname']
            })
            const user_rec_from = await Users.findOne({
                where: { isactive: '1', comp_id: req.comp_id, id: req.userId },
                attributes: ['id', 'userfullname']
            })
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            // const tender_rec = await TenderModel.findOne({
            //     where: { id: req.body.tender_id },
            //     attributes: ['tender_name'],
            //     include: [{

            //         model: TenderGeneratedTypeIdModel,
            //         attributes: ['generated_tender_id'],
            //         where: { status: '1' },
            //         required: false,
            //     },
            //     {
            //         model: Country,
            //         attributes: ['country_name'],
            //         where: { status: '1' },
            //         required: false,
            //     },
            //     {
            //         model: State,
            //         attributes: ['state_name'],
            //         where: { status: '1' },
            //         required: false,
            //     },
            //     {
            //         model: City,
            //         attributes: ['city_name'],
            //         where: { status: '1' },
            //         required: false,
            //     },
            //     {
            //         model: TenderClient,
            //         attributes: ['client_name'],
            //         where: { status: '1' },
            //         required: false,
            //     },
            //     ]
            // },)
            if (respExist) {
                // const tender_details = {
                //     tender_name: tender_rec?.tender_name,
                //     generated_tender_id: tender_rec?.bg_assign_tndr_generated_id?.generated_tender_id,
                //     location: tender_rec?.bg_mstr_country?.country_name + ' ' + tender_rec?.bg_mstr_state?.state_name + ' ' + tender_rec?.bg_mstr_city?.city_name,
                //     client: tender_rec?.bg_mstr_client?.client_name,
                //     assign_by: user_rec_from?.userfullname
                // }

                // const dynamicData = {
                //     subject: user_rec?.userfullname,
                //     body: tender_details,
                // };

                const updObj = {
                    assign_to: req.body.assign_to,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime()
                };
                const update = await TenderAssignManagerModel.update(updObj, {
                    where: { status: '1', user_comp_id: req.comp_id, bd_role_id: req.body.bd_role_id }
                })
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
            const assignMangrOnTndr = await TenderAssignManagerModel.create(dataToValidate)


            if (assignMangrOnTndr) {

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: assignMangrOnTndr
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

// BD Role List
const bdRolelist = async (req, res) => {

    try {
        const list = await TenderBdRoleModel.findAll({
            where: { status: '1' }, attributes: ['id', 'role_name'],
        })
        if (!list[0]) {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: list
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

//tender Assign Manager List
const tenderAssignMngrlist = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        tender_id: Joi.number().required(),
    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        tender_id: req.body.tender_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const list = await TenderAssignManagerModel.findAll({
                where: { user_comp_id: req.comp_id, status: '1', tender_id: req.body.tender_id }, attributes: ['id', 'tender_id'],
                include: [{
                    model: Users,
                    attributes: ['userfullname'],
                    where: { isactive: '1' },
                    required: false,
                },
                {
                    model: TenderBdRoleModel,
                    attributes: ['role_name'],
                    where: { status: '1' },
                    required: false,
                }]
            })
            if (!list[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: list
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


function getCurrentFinancialYear() {
    const today = new Date();
    const currentMonth = today.getMonth(); // Month is zero-based (0-11)

    let startYear, endYear;

    if (currentMonth < 3) {
        // If the current month is January, February, or March
        startYear = today.getFullYear() - 1;
        endYear = today.getFullYear();
    } else {
        // If the current month is April or later
        startYear = today.getFullYear();
        endYear = today.getFullYear() + 1;
    }

    return `${startYear}-${endYear}`;
}


// add tender document
const tender_doc_storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'tender_doc' + '/' + year + '/' + month + '/' + day + '/' + req.userId + '-' + req.comp_id;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        //console.log("Ash :- "+extension);
        cb(null, Date.now() + '_tenderdoc_' + extension); // Rename file with a timestamp
    },
});


const tender_document_upload = multer({ storage: tender_doc_storage });

const addTenderDocManual = async (req, res) => {
    tender_document_upload.single('tender_doc')(req, res, async function (err) {
        const schema = Joi.object().keys({
            tender_id: Joi.number().required(),
            file_doc_description: Joi.string().required(),
            user_comp_id: Joi.number().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required()
        });

        const dataToValidate = {
            tender_id: req.body.tender_id,
            user_comp_id: req.comp_id,
            file_doc_description: req.body.file_doc_description,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            try {
                const files = req.file;
                const TenderDocModel = createTenderDocModel(req.comp_id);
                await TenderDocModel.performOperation();
                if (files) {
                    const insertObj = {
                        user_comp_id: req.comp_id,
                        bg_tender_id: req.body.tender_id,
                        file_name: files.filename,
                        doc_path: files.destination,
                        type: 3,
                        tender_category: 1,
                        file_doc_description: req.body.file_doc_description,
                        created_by: req.userId,
                        created_at: getCurrentDateTime(),
                    }

                    const insertTenderDoc = await TenderDocModel.create(insertObj)
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insertTenderDoc
                    });
                } else {
                    return res.status(process.env.APIRESPCODE_VALIDATION).send({
                        message: "Please select Document ",
                        error: true,
                        success: false,
                        status: '0',
                    })
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    // message: error.message,
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
};

// tender document list
const tenderDocumentList = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        tender_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        tender_id: req.body.tender_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const TenderDocModel = createTenderDocModel(req.comp_id);
            await TenderDocModel.performOperation();



            const record = await TenderDocModel.findAll({
                order: [['id', 'DESC']],
                where: { status: '1', user_comp_id: req.comp_id, bg_tender_id: req.body.tender_id },
            })
            if (!record[0]) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    caterory_1: process.env.DOCS_CATEGORY_1,
                    caterory_2: process.env.DOCS_CATEGORY_2,
                    data: record
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }

}

const tenderDocumentDelete = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        tender_doc_id: Joi.number().required(),
    });
    const dataToValidate = {
        user_comp_id: req.comp_id,
        tender_doc_id: req.body.tender_doc_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const TenderDocModel = createTenderDocModel(req.comp_id);
            await TenderDocModel.performOperation();
            const record = await TenderDocModel.findOne({
                where: { status: '1', user_comp_id: req.comp_id, id: req.body.tender_doc_id },
            })
            if (!record) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const deleteRecObj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime()
                }
                const deleteRec = await TenderDocModel.update(deleteRecObj, {
                    where: { status: '1', user_comp_id: req.comp_id, id: req.body.tender_doc_id },
                })
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}



const tenderlistscopewise = async (req, res) => {
    const schema = Joi.object().keys({
        scope_id: Joi.string().required(),
    });
    const dataToValidate = {
        scope_id: req.body.scope_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const response = await TenderModel.findAll({
                where: { user_comp_id: req.comp_id, cycle_id: req.body.scope_id, status: '1' },
                attributes: ['id', 'tender_name'],
            });
            if (response[0]) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response
                });

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',

            });
        }

    }
}
module.exports = {
    addTender, edittenderdetail, updateTenderdetail, addTenderDoc, tenderlistscopewise,
    misleftlist, gettndrgeneratedtype, mistenderlist, mistndrcycleinactionlist, addmistndrcyclejumpmultipledbtn, addmistndrcyclejumpsingledbtn, mistndcyclenext, mistndcycleall,
    mislistassignbtn, addtndrcycleinactionbtn, edittndrcycleinactionbtn, updatetndrcycleinactionbtn, deletetndrcycleinactionbtn, tndrcycleinactionlist,
    addtndrcyclemovedbtn, bulkupdatetndrcycle, addtendernumbergenrated, tnderuserhistotry, addtndrcycleassignmanagerbtn, ListTenderScope,
    tenderscopeupdate, ListTenderScope_bycycleId, tenderCommentList, DeleteTenderDoc, AddNoGeneratePrefix, AssignTenderGeneratedIds, tenderGenTypes,
    lastTenderGenerateId, tenderAssignManager, bdRolelist, tenderAssignMngrlist, listNoGeneratePrefix, addTenderDocManual, tenderDocumentList, tenderDocumentDelete
};       