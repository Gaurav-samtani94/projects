require('dotenv').config();
// const  getCurrentDateTime() = new Date();
const Joi = require('joi');
const getCurrentDateTime = () => new Date();
const { Op } = require('sequelize');
const TenderTemplateFilter = require('../../models/tender/TenderTemplateFilter');
const Sequelize = require("../../config/database")

const addTemplateFilter = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        user_id: Joi.number().required(),
        template_type: Joi.number().required(),
        template_name: Joi.string().required(),
        filter_field_name: Joi.string().required(),
        filter_field_value: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    
    const dataToValidate = {
        user_comp_id: req.comp_id,
        user_id: req.userId,
        template_type: req.body.template_type,
        template_name: req.body.template_name,
        filter_field_name: req.body.filter_field_name,
        filter_field_value: req.body.filter_field_value,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const filter_field_name = req.body.filter_field_name.split(','); 
            const filter_field_value = req.body.filter_field_value.split(',');
            if(filter_field_name.length == filter_field_value.length){
                const response_filter = await Promise.all(filter_field_name.map(async (data, index) => {
                    const existCheck = await TenderTemplateFilter.findOne({
                        where: {filter_field_name:data, status:'1', template_type: req.body.template_type, template_name:req.body.template_name}
                    });
                    if(!existCheck){
                        const filterTemplate = await TenderTemplateFilter.create(
                            {
                                user_comp_id: req.comp_id,
                                user_id: req.userId,
                                template_type: req.body.template_type,
                                template_name: req.body.template_name,
                                filter_field_name: data,
                                filter_field_value: filter_field_value[index],
                                created_by: req.userId,
                                created_at: getCurrentDateTime(),
                            }
                        );
                    }
                    
                }));
                if(response_filter){
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Tender Filter Template Created Successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            }else{
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'Tender Filter Template name and value should be equal',
                    error: false,
                    success: true,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }

    }
}


const updateTemplateFilter = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        user_id: Joi.number().required(),
        template_type: Joi.number().required(),
        template_name: Joi.string().required(),
        filter_field_name: Joi.string().required(),
        filter_field_value: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    
    const dataToValidate = {
        user_comp_id: req.comp_id,
        user_id: req.userId,
        template_type: req.body.template_type,
        template_name: req.body.template_name,
        filter_field_name: req.body.filter_field_name,
        filter_field_value: req.body.filter_field_value,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const filter_field_name = req.body.filter_field_name.split(',');
            const filter_field_value = req.body.filter_field_value.split(',');
            if(filter_field_name.length == filter_field_value.length){
                const response_filter = await Promise.all(filter_field_name.map(async (data, index) => {
                    const existCheck = await TenderTemplateFilter.findOne({
                        where: {filter_field_name:data, status:'1', template_type:req.body.template_type, template_name:req.body.template_name}
                    });
                    if(existCheck){
                        const filterTemplate = await TenderTemplateFilter.update(
                            {
                                filter_field_value: filter_field_value[index],
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            },{where: {filter_field_name:data, status:'1',template_type:req.body.template_type,template_name:req.body.template_name}}
                        );
                    }else{
                        const filterTemplate = await TenderTemplateFilter.create(
                            {
                                user_comp_id: req.comp_id,
                                user_id: req.userId,
                                template_type:req.body.template_type,
                                template_name: req.body.template_name,
                                filter_field_name: data,
                                filter_field_value: filter_field_value[index],
                                created_by: req.userId,
                                created_at: getCurrentDateTime(),
                            }
                        );
                        // console.log(filterTemplate)
                    }
                }));
                if(response_filter){
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Tender Filter Template updated Successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            }else{
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'Tender Filter Template name and value should be equal',
                    error: false,
                    success: true,
                    status: '0',
                });
            }

        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }

    }
}

const deleteTemplateFilter = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        user_id: Joi.number().required(),
        template_type: Joi.number().required(),
        template_name: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    
    const dataToValidate = {
        user_comp_id: req.comp_id,
        user_id: req.userId,
        template_type: req.body.template_type,
        template_name: req.body.template_name,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
                const filterTemplate = await TenderTemplateFilter.update(
                    {
                        status: '0',
                        created_by: req.userId,
                        created_at: getCurrentDateTime(),
                    },{where: {template_type: req.body.template_type,template_name:req.body.template_name,user_id:req.userId, status:'1'}}
                );
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Tender Filter Template Deleted Successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
                

        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }

    }
}

const listTemplateFilter = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        user_id: Joi.number().required(),
        template_type: Joi.number().required(),
        template_name: Joi.string().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        user_id: req.userId,
        template_type: req.body.template_type,
        template_name: req.body.template_name,
    };

const result = schema.validate(dataToValidate);
if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
        message: result.error.details[0].message,
        error: true,
        success: false,
        status: '0',
    });
} else {
    try {
            const filterTemplate = await TenderTemplateFilter.findAll(
                {where: {template_type:req.body.template_type,template_name:req.body.template_name,user_id:req.userId, status:'1'}
                , attributes:['filter_field_name','filter_field_value']},
                
            );
            if(!filterTemplate[0]){
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Record Not found',
                    error: false,
                    success: true,
                    status: '0',
                });
            }
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record found',
                error: false,
                success: true,
                status: '1',
                data:filterTemplate
            });
            

    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: error.message,
            // message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}
}

const getTemplateValData =async (modelName,fieldValue) => {
    const data= await Sequelize.query(`SELECT * FROM ${modelName}  where id=${fieldValue}`, { type: Sequelize.QueryTypes.SELECT });
    if(data){
        return data;
    }else{
        return null;
    }
}


const listTemplates = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        template_type: Joi.number().required(),
        user_id: Joi.number().required(),
    });
    
    const dataToValidate = {
        user_comp_id: req.comp_id,
        template_type: req.body.template_type,
        user_id: req.userId,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
                const filterTemplate = await TenderTemplateFilter.findAll(
                    {where: {template_type:req.body.template_type, user_comp_id: req.comp_id, user_id:req.userId, status:'1'}
                    , attributes:['template_name'],group: ['template_name'],},
                    
                );
                if(!filterTemplate[0]){
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Record Not found',
                        error: false,
                        success: true,
                        status: '0',
                    });
                }
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Record found',
                    error: false,
                    success: true,
                    status: '1',
                    data:filterTemplate
                });
                

        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }

    }
}

module.exports = {
    addTemplateFilter, updateTemplateFilter, deleteTemplateFilter, listTemplateFilter, listTemplates
};  
