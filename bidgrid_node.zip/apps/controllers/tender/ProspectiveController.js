const Joi = require('joi');
var express = require('express');
const bodyParser = require('body-parser');
require('dotenv').config();
const Country = require('../../models/master/Country');
const State = require('../../models/master/State');
const TenderClient = require('../../models/master/TenderClient');
const Prospective = require('../../models/tender/prospective/Prosprctive');
const ProspectiveDocs = require('../../models/tender/prospective/ProspectiveDocuments');
const Prospectivepartners = require('../../models/tender/prospective/ProspectivePartner');
const Tendersector = require('../../models/master/TenderSector');
const Tenderfundingorg = require('../../models/master/TenderFundingagency');
const Company = require('../../models/master/MainCompany');
const ProspectivepartnersJVS = require('../../models/tender/prospective/ProspectivepartnersJVS');
const ProspectivepartnersASSo = require('../../models/tender/prospective/ProspectivepartnersAssociats');
const createTenderModel = require('../../models/tender/TenderModel');
const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
// const  getCurrentDateTime() = new Date();
const getCurrentDateTime = () => new Date();
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const createTenderModeDocs = require('../../models/tender/TenderDocModel');
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const foldername = 'public' + '_' + req.comp_id + '/' + 'prospective' + '/' + year + '/' + month + '/' + day + '/' + req.userId + '-' + req.comp_id;
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;

    },
});
const upload = multer({ storage: storage });

const AddProspectivetender = async (req, res) => {
    upload.array('files')(req, res, async function (err) {
        if (err) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
        const schema = Joi.object().keys({
            project_name: Joi.string().required(),
            tender_value: Joi.string().allow(null),
            country_id: Joi.string().required(),
            // funding_id: Joi.string().allow(null),
            sector_id: Joi.string().required(),
            created_by: Joi.number().integer().required(),
            created_at: Joi.date().iso().required(),
            user_comp_id: Joi.number().integer().required()
        });
        const schema_partner = Joi.object().keys({
            lead_comp_ids: Joi.string().required(),
            // jv_ids: Joi.string().allow(null),
            associative_ids: Joi.string().allow(null),
            created_by: Joi.number().integer().required(),
            created_at: Joi.date().iso().required()

        });
        const dataToValidate_partner = {
            lead_comp_ids: req.body.lead_comp_ids,
            // jv_ids: req.body.jv_ids,
            associative_ids: req.body.associative_ids,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };

        const dataToValidate = {
            project_name: req.body.project_name,
            tender_value: req.body.tender_value,
            country_id: req.body.country_id,
            sector_id: req.body.sector_id,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
            user_comp_id: req.comp_id
        };
        const result = schema.validate(dataToValidate);
        const result_partner = schema_partner.validate(dataToValidate_partner);
        if ((result.error) || (result_partner.error)) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
            });
        } else {
            try {
                const response_exist = await Prospective.findOne({
                    where: { status: '1', project_name: req.body.project_name, user_comp_id: req.comp_id, },
                })
                if (response_exist) {
                    const files = req.files;
                    if (files) {
                        files.forEach(record => {
                            const filePath = record.path;
                            if (filePath) {
                                fs.unlink(filePath, err => {
                                });
                            }
                        })
                    }
                    res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    })

                } else {
                    dataToValidate.client_id = (req.body.client_id) ? req.body.client_id : null;
                    dataToValidate.state_id = (req.body.state_id) ? req.body.state_id : null;
                    const response = await Prospective.create(dataToValidate);
                    if (!response) {
                        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                            message: process.env.ERROR_MSG,
                            error: true,
                            success: false,
                            status: '0',
                        })
                    } else {
                        const files = req.files;
                        if (files[0]) {
                            const originalFolderPath = files[0].destination;
                            const newNumber = response.id;
                            const pathSegments = files[0].destination.split('/');
                            pathSegments.pop();
                            pathSegments.push(newNumber);
                            const newFolderPath = pathSegments.join('/');
                            fs.rename(originalFolderPath, newFolderPath, (err) => {
                                if (err) {
                                    console.error('Error renaming folder:', err);
                                    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                        message: process.env.ERROR_MSG,
                                        error: true,
                                        success: false,
                                        status: '0',
                                    })
                                }
                            })
                            const fileRecords = await ProspectiveDocs.bulkCreate(files.map((file) => ({ created_by: req.userId, user_comp_id: req.comp_id, project_id: response.id, doc_name: file.filename, doc_exten: path.extname(file.filename), doc_path: newFolderPath })));
                            if (!fileRecords[0]) {
                                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                    message: process.env.ERROR_MSG,
                                    error: true,
                                    success: false,
                                    status: '0',
                                })
                            }
                        }
                        const prospectivepartnaers = await Prospectivepartners.create({ created_by: req.userId, user_comp_id: req.comp_id, project_id: response.id, lead_comp_ids: req.body.lead_comp_ids, created_at: getCurrentDateTime() });
                        if (!prospectivepartnaers) {
                            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                message: process.env.ERROR_MSG,
                                error: true,
                                success: false,
                                status: '0',
                            })
                        }
                        if ((prospectivepartnaers.id) && (req.body.jv_ids)) {
                            const str_to_arrjvs = req.body.jv_ids.split(',');
                            const recodsJvs = await ProspectivepartnersJVS.bulkCreate(str_to_arrjvs.map((data) => ({
                                created_by: req.userId, user_comp_id: req.comp_id, lead_comp_id: prospectivepartnaers.id, project_id: response.id, jv_ids: data
                            })));
                        }
                        if ((prospectivepartnaers.id) && (req.body.associative_ids)) {
                            const str_to_arrasso = req.body.associative_ids.split(',');
                            const recodsAsso = await ProspectivepartnersASSo.bulkCreate(str_to_arrasso.map((data) => ({
                                created_by: req.userId, user_comp_id: req.comp_id, lead_comp_id: prospectivepartnaers.id, project_id: response.id, associative_id: data
                            })));
                        }
                        if ((prospectivepartnaers) && (response)) {
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECINSERTED,
                                error: false,
                                success: true,
                                status: '1',
                            });
                        }
                    }
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                })
            }
        }

    });
}

const ListProspectivetender = async (req, res) => {

    const schema = Joi.object().keys({
        limit: Joi.string().required(),
        page_number: Joi.string().required(),

    });
    const dataToValidate = {
        limit: req.body.limit,
        page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {
            const page_number = parseInt(dataToValidate.page_number) || 1;
            const limit = parseInt(dataToValidate.limit) || 10;
            const offset = (parseInt(page_number) - 1) * parseInt(limit);

            //filter record 
            //normal filter
            const dynamicFilters = [];
            if (req.body.tender_keyword) {
                const tender_keyword = req.body.tender_keyword;
                dynamicFilters.push({
                    project_name: {
                        [Op.like]: `%${tender_keyword}%`,
                    },
                });
            }

            const response = await Prospective.findAll({
                order: [['id', 'DESC']],
                where: {
                    [Op.and]: [
                        { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                        ...dynamicFilters, // Include the dynamic filters
                    ]
                },
                attributes: [['id', 'project_id'], 'project_name', 'tender_value'],
                offset,
                limit,
                include: [{
                    model: Country,
                    attributes: ['country_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: State,
                    attributes: ['state_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: TenderClient,
                    attributes: ['client_name'],
                    where: { status: '1' },
                    required: false,

                },
                {
                    model: Tendersector,
                    attributes: ['sector_name'],
                    where: { status: '1' },
                    required: false,

                },
                {
                    model: Tenderfundingorg,
                    attributes: ['funding_org_name'],
                    where: { status: '1' },
                    required: false,

                }, {
                    model: ProspectiveDocs,
                    attributes: [
                        ['id', 'prospective_doc_id'],
                        'doc_name', 'doc_exten', 'doc_path'
                    ],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                }, {
                    model: Prospectivepartners,
                    attributes: [
                        ['lead_comp_ids', 'prospective_partner_id'],
                    ],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                    include: [{
                        model: Company,
                        attributes: ['company_name'],
                        where: { status: '1' },
                        required: false,
                    },],

                },
                {
                    model: ProspectivepartnersJVS,
                    attributes: [
                        ['jv_ids', 'prospective_jvs_id'],
                    ],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                    include: [{
                        model: Company,
                        attributes: ['company_name'],
                        where: { status: '1' },
                        required: false,
                    }],
                },
                    // {
                    //     model: ProspectivepartnersASSo,
                    //     attributes: [
                    //         ['id', 'prospective_associats_id'],
                    //     ],
                    //     where: { status: '1' },
                    //     required: false,
                    //     include: [{
                    //         model: Company,
                    //         attributes: ['company_name'],
                    //         where: { status: '1' },
                    //         required: false,
                    //     }],
                    // }
                ]
            });

            if (!response[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                let count = null;
                count = await Prospective.count({
                    where: {
                        [Op.and]: [
                            { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                            ...dynamicFilters, // Include the dynamic filters
                        ],
                    },
                });

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    error: false,
                    success: true,
                    status: '1',
                    message: process.env.APIRESPMSG_RECFOUND,
                    totalItems: count,
                    totalPages: Math.ceil(count / limit),
                    currentPage: page_number,
                    dataoncurrentPage: response.length,
                    data: response,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            })
        }
    }
}
const editProspectivetender = async (req, res) => {

    const schema = Joi.object().keys({
        project_id: Joi.string().required(),


    });
    const dataToValidate = {
        project_id: req.body.project_id,

    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await Prospective.findOne({
                where: { status: '1', id: req.body.project_id, user_comp_id: req.comp_id },

                include: [
                    {
                        model: ProspectiveDocs,
                        attributes: [
                            ['id', 'prospective_doc_id'],
                            'doc_name', 'doc_exten', 'doc_path'
                        ],
                        where: { status: '1' },
                        required: false,
                    }, {
                        model: Prospectivepartners,
                        attributes: [
                            ['id', 'prospective_partner_id'],
                        ],
                        where: { status: '1' },
                        required: false,
                        // include: [{
                        //     model: Company,
                        //     attributes: ['company_name'],
                        //     where: { status: '1' },
                        //     required: false,
                        // },],

                    },
                    {
                        model: ProspectivepartnersJVS,
                        attributes: [
                            ['id', 'prospective_jvs_id'],
                        ],
                        where: { status: '1' },
                        required: false,
                        // include: [{
                        //     model: Company,
                        //     attributes: ['company_name'],
                        //     where: { status: '1' },
                        //     required: false,
                        // }],
                    },
                    {
                        model: ProspectivepartnersASSo,
                        attributes: [
                            ['id', 'prospective_associats_id'],
                        ],
                        where: { status: '1' },
                        required: false,
                        // include: [{
                        //     model: Company,
                        //     attributes: ['company_name'],
                        //     where: { status: '1' },
                        //     required: false,
                        // }],
                    }
                ]
            });

            if (!response) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}
const deleteProspectivetender = async (req, res) => {

    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await Prospective.findOne({
                where: { status: '1', id: req.body.project_id, user_comp_id: req.comp_id },
            });
            if (!response) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const update_status = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime()
                }
                const response_delete = await Prospective.update(update_status, {
                    where: { status: '1', id: req.body.project_id, user_comp_id: req.comp_id },
                });

                const recodslead = await Prospectivepartners.findOne({
                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                })
                if ((recodslead)) {
                    const recodsleadcom = await Prospectivepartners.update(update_status, {
                        where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                    });
                }

                const recodsJvs = await ProspectivepartnersJVS.findAll({
                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                })
                if ((recodsJvs[0])) {
                    const recodsJvs = await ProspectivepartnersJVS.update(update_status, {
                        where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                    });
                }
                const recodsasso = await ProspectivepartnersASSo.findAll({
                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                })
                if ((recodsasso[0])) {
                    const recodsasso = await ProspectivepartnersASSo.update(update_status, {
                        where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                    });
                }
                const recodsdoc = await ProspectiveDocs.findAll({
                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                })
                if ((recodsdoc[0])) {
                    const recoddocs = await ProspectiveDocs.update(update_status, {
                        where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}
const storage_upd = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const foldername = 'public' + '_' + req.comp_id + '/' + 'prospective' + '/' + year + '/' + month + '/' + day + '/';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + '-' + file.originalname);
        req.extension = extension;

    },
});
const upload_upd = multer({ storage: storage_upd });
const updateProspectivetender = async (req, res) => {
    upload_upd.array('files')(req, res, async function (err) {
        const schema = Joi.object().keys({
            project_id: Joi.string().required(),
            project_name: Joi.string().required(),
            tender_value: Joi.string().allow(null),
            // client_id: Joi.string().required(),
            country_id: Joi.string().required(),
            // state_id: Joi.string().required(),
            // funding_id: Joi.number().allow(null),
            sector_id: Joi.string().required(),
            created_by: Joi.number().integer().required(),
            created_at: Joi.date().iso().required(),
            user_comp_id: Joi.number().integer().required()
        });
        const schema_partner = Joi.object().keys({
            lead_comp_ids: Joi.number().integer().required(),
            // jv_ids: Joi.string().allow(null),
            associative_ids: Joi.string().allow(null),
            created_by: Joi.number().integer().required(),
            created_at: Joi.date().iso().required()

        });
        const dataToValidate_partner = {
            lead_comp_ids: req.body.lead_comp_ids,
            // jv_ids: req.body.jv_ids,
            associative_ids: req.body.associative_ids,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };

        const dataToValidate = {
            project_id: req.body.project_id,
            project_name: req.body.project_name,
            tender_value: req.body.tender_value,
            // client_id: req.body.client_id,
            country_id: req.body.country_id,
            // state_id: req.body.state_id,
            // funding_id: req.body.funding_id,
            sector_id: req.body.sector_id,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
            user_comp_id: req.comp_id
        };
        const result = schema.validate(dataToValidate);
        const result_partner = schema_partner.validate(dataToValidate_partner);
        if ((result.error) || (result_partner.error)) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
            });
        } else {
            try {

                const response_exist = await Prospective.findOne({
                    where: {
                        status: '1', project_name: req.body.project_name, user_comp_id: req.comp_id, id: {
                            [Op.not]: req.body.project_id // Exclude the specified project_id
                        }
                    },
                })
                if (response_exist) {
                    const files = req.files;
                    if (files) {
                        files.forEach(record => {
                            const filePath = record.path;
                            if (filePath) {
                                fs.unlink(filePath, err => {

                                });
                            }
                        })
                    }
                    res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    })
                } else {
                    const recodslead = await Prospective.findOne({
                        where: { status: '1', id: req.body.project_id, user_comp_id: req.comp_id },
                    })
                    const update_prospective = {
                        project_name: req.body.project_name,
                        tender_value: req.body.tender_value,
                        client_id: req.body.client_id,
                        country_id: req.body.country_id,
                        state_id: req.body.state_id,
                        funding_id: req.body.funding_id,
                        sector_id: req.body.sector_id,
                        modified_by: req.userId,
                        updated_at: getCurrentDateTime(),
                    }
                    if (!recodslead) {
                        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                            message: recodslead,
                            error: true,
                            success: false,
                            status: '0',
                        })
                    } else {
                        const data_upd = await Prospective.update(update_prospective, {
                            where: { status: '1', id: req.body.project_id, user_comp_id: req.comp_id },
                        })
                        const files = req.files;
                        if (files[0]) {
                            const originalFolderPath = files[0].destination;
                            const newNumber = req.body.project_id;
                            const pathSegments = originalFolderPath.split('/');
                            pathSegments.pop();
                            const newFolderPath = path.join(pathSegments.join('/'), newNumber);
                            if (!fs.existsSync(newFolderPath)) {
                                fs.mkdirSync(newFolderPath);
                            }
                            files.forEach((file) => {
                                const oldPath = path.join(originalFolderPath, file.filename);
                                const newPath = path.join(newFolderPath, file.filename);
                                fs.rename(oldPath, newPath, (err) => {
                                    // if (err) {
                                    //     res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                                    //         message: process.env.ERROR_MSG,
                                    //         error: 'sllsls',
                                    //         success: false,
                                    //         status: '0',
                                    //     });
                                    // }
                                });
                            });
                            const fileRecords = await ProspectiveDocs.bulkCreate(
                                files.map((file) => ({
                                    user_comp_id: req.comp_id,
                                    project_id: req.body.project_id,
                                    doc_name: file.filename,
                                    doc_exten: path.extname(file.filename),
                                    doc_path: newFolderPath,
                                    modified_by: req.userId,
                                    updated_at: getCurrentDateTime()
                                })
                                )
                            )
                        }

                        const add_update_status_lead = {
                            project_id: req.body.project_id,
                            lead_comp_ids: req.body.lead_comp_ids,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                            user_comp_id: req.comp_id
                        }
                        const response_lead = await Prospectivepartners.findOne({
                            where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id, lead_comp_ids: req.body.lead_comp_ids },
                        })
                        if (req.body.lead_comp_ids) {
                            if ((response_lead)) {
                                const lead_upd = await Prospectivepartners.destroy({
                                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id, lead_comp_ids: req.body.lead_comp_ids },
                                });
                                const lead_upd_create = await Prospectivepartners.create(add_update_status_lead);
                            } else {
                                const lead_upd_create = await Prospectivepartners.create(add_update_status_lead);

                            }
                        }
                        const response_lead_data = await Prospectivepartners.findOne({
                            where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id, lead_comp_ids: req.body.lead_comp_ids },
                        })
                        if (req.body.jv_ids) {
                            const reco_jvids = await ProspectivepartnersJVS.findAll({
                                where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                            })

                            if ((reco_jvids[0])) {
                                const recoddocs = await ProspectivepartnersJVS.destroy({
                                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                                });
                            }
                            const str_to_arrjvs = req.body.jv_ids.split(',');
                            const fileRecords = await ProspectivepartnersJVS.bulkCreate(str_to_arrjvs.map((data) => ({ modified_by: req.userId, created_by: req.userId, user_comp_id: req.comp_id, project_id: req.body.project_id, lead_comp_id: response_lead_data.id, jv_ids: data, updated_at: getCurrentDateTime() })));
                        }

                        if (req.body.associative_ids) {

                            const reco_asso = await ProspectivepartnersASSo.findAll({
                                where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                            })

                            if ((reco_asso[0])) {
                                const recoddocs = await ProspectivepartnersASSo.destroy({
                                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                                });
                            }
                            const str_to_arrjvs = req.body.associative_ids.split(',');
                            const fileRecords = await ProspectivepartnersASSo.bulkCreate(str_to_arrjvs.map((data) => ({ modified_by: req.userId, created_by: req.userId, user_comp_id: req.comp_id, project_id: req.body.project_id, lead_comp_id: response_lead_data.id, associative_id: data, updated_at: getCurrentDateTime() })));



                        }

                    }
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                })
            }
        }

    });
}

const prospectivedocsdelete = async (req, res) => {

    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
        docs_id: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        docs_id: req.body.project_id,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await ProspectiveDocs.findOne({
                where: { status: '1', id: req.body.docs_id, project_id: req.body.project_id, user_comp_id: req.comp_id },
            });
            if (!response) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const update_status = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime()
                }
                const recoddocs = await ProspectiveDocs.update(update_status, {
                    where: { status: '1', id: req.body.docs_id, project_id: req.body.project_id, user_comp_id: req.comp_id },
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}


const prospectivedocsDown = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
        docs_id: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        docs_id: req.body.project_id,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const file_data = await ProspectiveDocs.findOne({
                where: { status: '1', id: req.body.docs_id, project_id: req.body.project_id, user_comp_id: req.comp_id }, attributes
                    : ['doc_path', 'doc_name']
            })
            console.log(file_data, 'file_datafile_data')
            if (file_data) {
                // Construct the full path to the file
                // const filePath = path.join('/opt/lampp/htdocs/bidrid/', file_data.doc_path + '/' + file_data.doc_name);
                const filePath = file_data.doc_path + '/' + file_data.doc_name;
                if (fs.existsSync(filePath)) {
                    console.log('File exists:', filePath);
                } else {
                    // console.error('File does not exist:', filePath);
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.ERROR_MSG,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                // console.log(filePath, 'filePathfilePath');
                // // Set appropriate headers for the response
                res.setHeader('Content-disposition', 'attachment; filename=' + path.basename(filePath));
                res.setHeader('Content-type', 'application/octet-stream');

                const fileStream = fs.createReadStream(filePath);  // Use the corrected file path
                fileStream.pipe(res);
            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            })
        }
    }
}

// get and update prospective Tender
const addProspectivetenderInMainTender = async (req, res) => {
    const schema = Joi.object().keys({
        prosp_tndr_id: Joi.number().required(),
    });
    const dataToValidate = {
        prosp_tndr_id: req.body.prosp_tndr_id,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const prospectiveData = await Prospective.findOne({
                where: { user_comp_id: req.comp_id, status: '1', id: req.body.prosp_tndr_id },
                attributes: ['id', 'project_name', 'client_id', 'country_id', 'state_id', 'funding_id', 'sector_id'],

            });
            const prospectiveDocs = await ProspectiveDocs.findOne({
                where: { user_comp_id: req.comp_id, status: '1', project_id: req.body.prosp_tndr_id },
                attributes: ['id', 'project_id', 'doc_name', 'doc_exten', 'doc_path'],

            });

            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            if (!prospectiveData) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Prospective Tenders Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {

                updProspTndrObj = {
                    user_comp_id: req.comp_id, tender_name: prospectiveData.project_name, client_id: prospectiveData.client_id, country_id: prospectiveData.country_id,
                    state_id: prospectiveData.state_id, funding_id: prospectiveData.funding_id, sector_id: prospectiveData.sector_id, tender_category: 1, created_at: getCurrentDateTime()
                }
                const response = await TenderModel.create(updProspTndrObj);

                if (response) {
                    const update_status = {
                        status: '0',
                        modified_by: req.userId,
                        updated_at: getCurrentDateTime()
                    }
                    const response_delete = await Prospective.update(update_status, {
                        where: { status: '1', id: req.body.prosp_tndr_id, user_comp_id: req.comp_id },
                    });

                    if (!prospectiveDocs && response_delete) {
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message1: 'Prospective Tenders Added Successfully',
                            message2: 'Prospective Tender Document Not Found',
                            error: false,
                            success: true,
                            status: '1',
                        });
                    } else {

                        updProspTndrDocObj = {
                            user_comp_id: req.comp_id, bg_tender_id: prospectiveDocs.project_id, file_name: prospectiveDocs.doc_name, type: 1, doc_path: prospectiveDocs.doc_path, tender_category: 1,
                            created_at: getCurrentDateTime(), created_by: req.userId
                        }

                        const TenderDocModel = createTenderModeDocs(req.comp_id);
                        await TenderDocModel.performOperation();

                        const responseDoc = await TenderDocModel.create(updProspTndrDocObj);

                        if (responseDoc) {
                            const update_status = {
                                status: '0',
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime()
                            }

                            const response_deleteDoc = await ProspectiveDocs.update(update_status, {
                                where: { status: '1', project_id: req.body.prosp_tndr_id, user_comp_id: req.comp_id },
                            });

                            if (response_deleteDoc) {
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: 'Prospective Tender & Tender Document Added Successfully',
                                    error: false,
                                    success: true,
                                    status: '1',
                                });
                            }
                        }
                    }
                }
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}


module.exports = {
    AddProspectivetender, ListProspectivetender, editProspectivetender, deleteProspectivetender, updateProspectivetender, prospectivedocsdelete,
    prospectivedocsDown, addProspectivetenderInMainTender
};   