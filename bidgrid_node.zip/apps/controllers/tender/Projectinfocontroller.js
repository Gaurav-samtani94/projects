require('dotenv').config();
// const  getCurrentDateTime() = new Date();
const Joi = require('joi');
const moment = require('moment')
const getCurrentDateTime = () => new Date();
const createTenderModelcoverinfo = require('../../models/tender/TenderCoverinfoModel');
const createTenderModelDate = require('../../models/tender/TenderDateModel');
const createTenderModelEMD = require('../../models/tender/TenderEmdModel');
const createTenderModelFeeInfo = require('../../models/tender/TenderFeeinfoModel');
const createTenderModelOtherData = require('../../models/tender/TenderOtherDataModel');
const createTenderModel = require('../../models/tender/TenderModel');
const createTenderModeDocs = require('../../models/tender/TenderDocModel');
const MainCompany = require('../../models/master/MainCompany')
const Tenderpartners = require('../../models/tender/TenderPartner')
const TenderpartnersASSo = require('../../models/tender/TenderpartnersAssociats')
const TenderpartnersJVS = require('../../models/tender/TenderpartnersJVS')
const { Op } = require('sequelize');
const Main_company = require('../../models/Main_company');

const TenderKeyDetails = require('../../models/tender/TenderKeyDetail');
const TenderFinancialDetails = require('../../models/tender/TenderFinancialDetail')
const TenderFinancialRefDetail = require('../../models/tender/TenderFinancialRefDetail')
const TenderStatusManage = require('../../models/tender/TenderStatusManage')
const TenderStatus = require('../../models/master/TenderStatus');
const ConsortiumChecker = require('../../helper/common_helper');
const ProspectivepartnersJVS = require('../../models/tender/prospective/ProspectivepartnersJVS');
const TenderAssignManagerModel = require('../../models/tender/TenderAssignManagerModel');
const TenderBdRoleModel = require('../../models/master/TenderBdRoleModel');
const Users = require('../../models/Users');

const getProjectDetails = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const response_basic = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', id: req.body.project_id
                },
            })
            const TenderDateModel = createTenderModelDate(req.comp_id);
            await TenderDateModel.performOperation();
            const response_date = await TenderDateModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })

            const TenderEMDModel = createTenderModelEMD(req.comp_id);
            await TenderEMDModel.performOperation();
            const response_EMD = await TenderEMDModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })
            const TenderFeeInfoModel = createTenderModelFeeInfo(req.comp_id);
            await TenderFeeInfoModel.performOperation();
            const response_Feeinfo = await TenderFeeInfoModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })
            const TenderOtherDataModel = createTenderModelOtherData(req.comp_id);
            await TenderOtherDataModel.performOperation();
            const response_other = await TenderOtherDataModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })
            const TenderCoverinfoModel = createTenderModelcoverinfo(req.comp_id);
            await TenderCoverinfoModel.performOperation();
            const response_cover = await TenderCoverinfoModel.findAll({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })
            const TenderDocModel = createTenderModeDocs(req.comp_id);
            await TenderDocModel.performOperation();
            const response_docs = await TenderDocModel.findAll({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })
            const key_client_maneser = await TenderAssignManagerModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', tender_id: req.body.project_id, bd_role_id: '1'
                },
                include: [{
                    model: TenderBdRoleModel,
                    attributes: ['id', 'role_name'],
                    // as: 'fin_ref_detail',
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['id', 'userfullname'],
                    // as: 'fin_ref_detail',
                    where: { isactive: '1', },
                    required: false,

                }
                ]
            })
            const Bid_Manager = await TenderAssignManagerModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', tender_id: req.body.project_id, bd_role_id: '2'
                },
                include: [{
                    model: TenderBdRoleModel,
                    attributes: ['id', 'role_name'],
                    // as: 'fin_ref_detail',
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['id', 'userfullname'],
                    // as: 'fin_ref_detail',
                    where: { isactive: '1', },
                    required: false,

                }
                ]
            })
            const Bid_Executive = await TenderAssignManagerModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', tender_id: req.body.project_id, bd_role_id: '3'
                },
                include: [{
                    model: TenderBdRoleModel,
                    attributes: ['id', 'role_name'],
                    // as: 'fin_ref_detail',
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['id', 'userfullname'],
                    // as: 'fin_ref_detail',
                    where: { isactive: '1', },
                    required: false,

                }

                ]
            })
            const RFP_Reviewer = await TenderAssignManagerModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', tender_id: req.body.project_id, bd_role_id: '4'
                },
                include: [{
                    model: TenderBdRoleModel,
                    attributes: ['id', 'role_name'],
                    // as: 'fin_ref_detail',
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['id', 'userfullname'],
                    // as: 'fin_ref_detail',
                    where: { isactive: '1', },
                    required: false,

                }]
            })


            const response = {
                key_client_mnser: key_client_maneser,
                bid_Manager: Bid_Manager,
                bid_Executive: Bid_Executive,
                rfp_reviewer: RFP_Reviewer,
                tender_basic_details: response_basic,
            }
            const data_res = {
                basic_info: response,
                tender_date: response_date,
                tender_emd: response_EMD,
                tender_feeinfo: response_Feeinfo,
                tender_other_data: response_other,
                tender_cover_info: response_cover,
                tender_docs: response_docs

            }
            if (response_basic) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: data_res
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }

    }
}


const updatetenderdate = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const response_basic = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', id: req.body.project_id
                },
            })
            const TenderDateModel = createTenderModelDate(req.comp_id);
            await TenderDateModel.performOperation();
            const response_date = await TenderDateModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })
            const update_date = {
                tnd_published_date: (req.body.tnd_published_date) ? req.body.tnd_published_date : null,
                tnd_published_time: (req.body.tnd_published_time) ? req.body.tnd_published_time : null,
                bid_opening_date: (req.body.bid_opening_date) ? req.body.bid_opening_date : null,
                bid_opening_time: (req.body.bid_opening_time) ? req.body.bid_opening_time : null,
                doc_download_start_date: (req.body.doc_download_start_date) ? req.body.doc_download_start_date : null,
                doc_download_start_time: (req.body.doc_download_start_time) ? req.body.doc_download_start_time : null,
                doc_download_end_date: (req.body.doc_download_end_date) ? req.body.doc_download_end_date : null,
                doc_download_end_time: (req.body.doc_download_end_time) ? req.body.doc_download_end_time : null,
                clarification_start_date: (req.body.clarification_start_date) ? req.body.clarification_start_date : null,
                clarification_start_time: (req.body.clarification_start_time) ? req.body.clarification_start_time : null,
                clarification_end_date: (req.body.clarification_end_date) ? req.body.clarification_end_date : null,
                clarification_end_time: (req.body.clarification_end_time) ? req.body.clarification_end_time : null,
                bid_submission_start_date: (req.body.bid_submission_start_date) ? req.body.bid_submission_start_date : null,
                bid_submission_start_time: (req.body.bid_submission_start_time) ? req.body.bid_submission_start_time : null,
                bid_submission_end_date: (req.body.bid_submission_end_date) ? req.body.bid_submission_end_date : null,
                bid_submission_end_time: (req.body.bid_submission_end_time) ? req.body.bid_submission_end_time : null,
            }
            if (response_basic) {
                if (response_date) {

                    update_date.updated_at = getCurrentDateTime();
                    update_date.updated_by = req.userId;
                    const response_date = await TenderDateModel.update(update_date, {
                        where: {
                            user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                        },
                    })
                    if (response_date) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',

                        });
                    }
                } else {
                    update_date.user_comp_id = req.comp_id;
                    update_date.bg_tender_id = req.body.project_id;
                    update_date.created_at = getCurrentDateTime();
                    update_date.created_by = req.userId;
                    const response_date = await TenderDateModel.create(update_date)
                    if (response_date) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',

                        });
                    }
                }

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }

    }
}

const updatetenderEmd = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const response_basic = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', id: req.body.project_id
                },
            })
            const TenderEMDModel = createTenderModelEMD(req.comp_id);
            await TenderEMDModel.performOperation();
            const response_date = await TenderEMDModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })
            const update_EMD = {
                emd_amount: (req.body.emd_amount) ? req.body.emd_amount : null,
                currency: (req.body.currency) ? req.body.currency : null,
                emd_fee_type: (req.body.emd_fee_type) ? req.body.emd_fee_type : null,
                emd_payable_to: (req.body.emd_payable_to) ? req.body.emd_payable_to : null,
                emd_payable_at: (req.body.emd_payable_at) ? req.body.emd_payable_at : null,
                emd_percentage: (req.body.emd_percentage) ? req.body.emd_percentage : null,
                emd_through_BG_ST_orEMD_exemption_allowed: (req.body.emd_through_BG_ST_orEMD_exemption_allowed) ? req.body.emd_through_BG_ST_orEMD_exemption_allowed : null,
            }
            if (response_basic) {
                if (response_date) {
                    update_EMD.updated_at = getCurrentDateTime();
                    update_EMD.updated_by = req.userId;
                    const response_date = await TenderEMDModel.update(update_EMD, {
                        where: {
                            user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                        },
                    })
                    if (response_date) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',

                        });
                    }
                } else {
                    update_EMD.user_comp_id = req.comp_id;
                    update_EMD.bg_tender_id = req.body.project_id;
                    update_EMD.created_at = getCurrentDateTime();
                    update_EMD.created_by = req.userId;
                    const response_date = await TenderEMDModel.create(update_EMD)
                    if (response_date) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',

                        });
                    }
                }

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }

    }
}

const updatetenderFEEinfo = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const response_basic = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', id: req.body.project_id
                },
            })
            const TenderFeeInfoModel = createTenderModelFeeInfo(req.comp_id);
            await TenderFeeInfoModel.performOperation();
            const response_date = await TenderFeeInfoModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })
            const update_Fee = {
                tnd_fee: (req.body.tnd_fee) ? req.body.tnd_fee : null,
                currency: (req.body.currency) ? req.body.currency : null,
                processing_fee: (req.body.processing_fee) ? req.body.processing_fee : null,
                fee_payable_to: (req.body.fee_payable_to) ? req.body.fee_payable_to : null,
                fee_payable_at: (req.body.fee_payable_at) ? req.body.fee_payable_at : null,
                tnd_fee_exemption_allowed: (req.body.tnd_fee_exemption_allowed) ? req.body.tnd_fee_exemption_allowed : null,
            }
            if (response_basic) {
                if (response_date) {
                    update_Fee.updated_at = getCurrentDateTime();
                    update_Fee.updated_by = req.userId;
                    const response_date = await TenderFeeInfoModel.update(update_Fee, {
                        where: {
                            user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                        },
                    })
                    if (response_date) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',

                        });
                    }
                } else {
                    update_Fee.user_comp_id = req.comp_id;
                    update_Fee.bg_tender_id = req.body.project_id;
                    update_Fee.created_at = getCurrentDateTime();
                    update_Fee.created_by = req.userId;
                    const response_date = await TenderFeeInfoModel.create(update_Fee)
                    if (response_date) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',

                        });
                    }
                }

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }

    }
}

const updatetenderOtherData = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const response_basic = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', id: req.body.project_id
                },
            })
            const TenderOtherDataModel = createTenderModelOtherData(req.comp_id);
            await TenderOtherDataModel.performOperation();
            const response_date = await TenderOtherDataModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                },
            })
            const update_other_data = {
                product_category: (req.body.product_category) ? req.body.product_category : null,
                tnd_url: 'https://apps.growthgrids.com/bidgrid/bdtenderdetails/' + req.body.project_id,
                form_of_contract: (req.body.form_of_contract) ? req.body.form_of_contract : null,
                no_of_covers: (req.body.no_of_covers) ? req.body.no_of_covers : null,
                payment_mode: (req.body.payment_mode) ? req.body.payment_mode : null,
                general_technical_evaluation_allowed: (req.body.general_technical_evaluation_allowed) ? req.body.general_technical_evaluation_allowed : null,
                item_wise_technical_value: (req.body.item_wise_technical_value) ? req.body.item_wise_technical_value : null,
                is_multicurrency_allowed_for_boq: (req.body.is_multicurrency_allowed_for_boq) ? req.body.is_multicurrency_allowed_for_boq : null,
                is_multicurrency_allowed_for_fee: (req.body.is_multicurrency_allowed_for_fee) ? req.body.is_multicurrency_allowed_for_fee : null,
                allowed_two_stage_bidding: (req.body.allowed_two_stage_bidding) ? req.body.allowed_two_stage_bidding : null,
                nda_pre_qualification: (req.body.nda_pre_qualification) ? req.body.nda_pre_qualification : null,
                independent_external_monitor_remark: (req.body.independent_external_monitor_remark) ? req.body.independent_external_monitor_remark : null,
                contract_type: (req.body.contract_type) ? req.body.contract_type : null,
                bid_validity: (req.body.bid_validity) ? req.body.bid_validity : null,
                period_of_work: (req.body.period_of_work) ? req.body.period_of_work : null,
                region_code: (req.body.region_code) ? req.body.region_code : null,
                pre_bid_meeting_place: (req.body.pre_bid_meeting_place) ? req.body.pre_bid_meeting_place : null,
                pre_bid_meeting_address: (req.body.pre_bid_meeting_address) ? req.body.pre_bid_meeting_address : null,
                pre_bid_meeting_date: (req.body.pre_bid_meeting_date) ? req.body.pre_bid_meeting_date : null,
                pre_bid_meeting_time: (req.body.pre_bid_meeting_time) ? req.body.pre_bid_meeting_time : null,
                bid_opening_place: (req.body.bid_opening_place) ? req.body.bid_opening_place : null,
                should_allow_nda_tnd: (req.body.should_allow_nda_tnd) ? req.body.should_allow_nda_tnd : null,
                allow_preferential_bidder: (req.body.allow_preferential_bidder) ? req.body.allow_preferential_bidder : null,
                instrument_type: (req.body.instrument_type) ? req.body.instrument_type : null,
            }
            if (response_basic) {
                if (response_date) {
                    update_other_data.updated_at = getCurrentDateTime();
                    update_other_data.updated_by = req.userId;
                    const response_date = await TenderOtherDataModel.update(update_other_data, {
                        where: {
                            user_comp_id: req.comp_id, status: '1', bg_tender_id: req.body.project_id
                        },
                    })
                    if (response_date) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECUPDATED,
                            error: false,
                            success: true,
                            status: '1',

                        });
                    }
                } else {
                    update_other_data.user_comp_id = req.comp_id;
                    update_other_data.bg_tender_id = req.body.project_id;
                    update_other_data.created_at = getCurrentDateTime();
                    update_other_data.created_by = req.userId;
                    const response_date = await TenderOtherDataModel.create(update_other_data)
                    if (response_date) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECINSERTED,
                            error: false,
                            success: true,
                            status: '1',

                        });
                    }
                }

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }

    }
}

const addtendercoverInfo = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
        cover_type: Joi.string().required(),
        description: Joi.string().required(),
        doc_type: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        cover_type: req.body.cover_type,
        description: req.body.description,
        doc_type: req.body.doc_type,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const response_basic = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', id: req.body.project_id
                },
            })
            const TenderCoverinfoModel = createTenderModelcoverinfo(req.comp_id);
            await TenderCoverinfoModel.performOperation();
            if (response_basic) {
                const cover_type_arr = req.body.cover_type.split(',')
                const doc_type_arr = req.body.doc_type.split(',');
                const description_arr = req.body.description.split(',');
                const resultArray = [];
                for (let i = 0; i < cover_type_arr.length; i++) {
                    const newObj = {
                        cover_type: cover_type_arr[i],
                        doc_type: doc_type_arr[i],
                        description: description_arr[i]
                    };

                    resultArray.push(newObj);
                }
                const response_date = await TenderCoverinfoModel.bulkCreate(resultArray.map((data) => ({
                    cover_type: data.cover_type,
                    doc_type: data.doc_type,
                    description: data.description,
                    user_comp_id: req.comp_id,
                    bg_tender_id: req.body.project_id,
                    created_at: getCurrentDateTime(),
                    created_by: req.userId,
                })))

                // const response_date = await TenderCoverinfoModel.create(dataToValidate)
                if (response_date) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',

                    });
                }


            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }

    }
}


const updatetendercoverInfo = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
        cover_id: Joi.number().required(),
        cover_type: Joi.string().required(),
        description: Joi.string().required(),
        doc_type: Joi.string().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        cover_id: req.body.cover_id,
        cover_type: req.body.cover_type,
        description: req.body.description,
        doc_type: req.body.doc_type,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const response_basic = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', id: req.body.project_id
                },
            })
            const TenderCoverinfoModel = createTenderModelcoverinfo(req.comp_id);
            await TenderCoverinfoModel.performOperation();
            if (response_basic) {
                dataToValidate.updated_at = getCurrentDateTime();
                dataToValidate.updated_by = req.userId;
                const response_date = await TenderCoverinfoModel.update(dataToValidate, {
                    where: {
                        id: req.body.cover_id, bg_tender_id: req.body.project_id
                    }
                })
                if (response_date) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',

                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }

    }
}

const deletendercoverInfo = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
        cover_id: Joi.number().required(),

    });
    const dataToValidate = {
        project_id: req.body.project_id,
        cover_id: req.body.cover_id,

    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const response_basic = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', id: req.body.project_id
                },
            })
            const TenderCoverinfoModel = createTenderModelcoverinfo(req.comp_id);
            await TenderCoverinfoModel.performOperation();
            if (response_basic) {
                const delete_cover = {
                    status: '0',
                }
                delete_cover.updated_at = getCurrentDateTime();
                delete_cover.updated_by = req.userId;
                const response_date = await TenderCoverinfoModel.update(delete_cover, {
                    where: {
                        id: req.body.cover_id, bg_tender_id: req.body.project_id
                    }
                })
                if (response_date) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',

                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }

    }
}

const getcompanyList = async (req, res) => {
    try {
        const response = await MainCompany.findAll({
            order: [['company_details', 'ASC']],
            where: { status: '1', is_varified: '1' },
            attributes: ['id', 'company_details'],
        });
        const resp_private = await MainCompany.findAll({
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'company_details'],
        });
        const mergedResponse = [...response, ...resp_private];
        if (mergedResponse[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECINSERTED,
                error: false,
                success: true,
                status: '1',
                data: mergedResponse

            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });

        }

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });

    }
}

const Addnewcompany = async (req, res) => {
    const schema = Joi.object().keys({
        company_name: Joi.string().required(),
        company_details: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        user_comp_id: Joi.number().required(),
    });
    const dataToValidate = {
        company_name: req.body.company_name,
        company_details: req.body.company_details,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
        user_comp_id: req.comp_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const response = await MainCompany.findOne({
                where: { status: '1', company_name: req.body.company_name },
            });
            if (!response) {
                const response = await MainCompany.create(dataToValidate)
                if (response) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: response
                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }

}


const addtenderparnercompany = async (req, res) => {
    const getLinkComp = await MainCompany.findOne({
        where: { status: '1', link_comp_id: req.comp_id },
        attributes: ['id', 'company_name']
    });
    const lead_comp_string = (req.body.solo) ? Joi.number().allow(null) : Joi.number().allow(null);
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        consortium_skip: Joi.number().allow(null),
        lead_comp_id: lead_comp_string,
        associats_id: Joi.string().allow(null),
        jvs_company: Joi.string().allow(null),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        user_comp_id: Joi.number().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        consortium_skip: req.body.consortium_skip,
        lead_comp_id: (req.body.solo) ? getLinkComp.id : req.body.lead_comp_id,
        associats_id: req.body.associats_id,
        jvs_company: req.body.jvs_company,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
        user_comp_id: req.comp_id
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {

            //tender existence check
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const tndr_existence = await TenderModel.findOne({
                where: { status: '1', user_comp_id: req.comp_id, id: req.body.project_id }
            })

            if (tndr_existence) {

                if (req.body.solo && req.body.solo == 'true') {      
                    //sole existence
                    const sole_existence = await Tenderpartners.findOne({
                        where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' },
                        attributes: ['lead_comp_ids']
                    })
                    if (sole_existence) {

                        //jv delete
                        const jv_existence = await TenderpartnersJVS.findAll({
                            where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' },
                            attributes: ['id']
                        })
                        const response_jv_partners = await Promise.all(jv_existence.map(async (jv_data) => {
                            await TenderpartnersJVS.destroy({
                                where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, id: jv_data.id },
                            })
                        }));

                        //assoc delete
                        const assoc_existence = await TenderpartnersASSo.findAll({
                            where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' },
                            attributes: ['id']
                        })
                        const response_assoc_partners = await Promise.all(assoc_existence.map(async (assoc_data) => {
                            await TenderpartnersASSo.destroy({
                                where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, id: assoc_data.id },
                            })
                        }));

                        const sole_data = {
                            updated_by: req.userId,
                            updated_at: getCurrentDateTime(),
                            lead_comp_ids: getLinkComp.id,
                            //status: '1',
                            is_solo: '1'
                        }
                        const sole_data_upd = await Tenderpartners.update(sole_data, {
                            where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' }
                        })
                        if (sole_data_upd) {
                            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECFOUND,
                                error: false,
                                success: true,
                                status: '1',
                                data: sole_data_upd
                            });
                        }
                    }
                    else {
                        const sole_data = {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            lead_comp_ids: getLinkComp.id,
                            is_solo: '1',
                            type_data: '1',
                            status: '1',
                            created_at: getCurrentDateTime(),
                            created_by: req.userId,
                        }
                        const sole_data_insert = await Tenderpartners.create(sole_data)
                        if (sole_data_insert) {
                            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECFOUND,
                                error: false,
                                success: true,
                                status: '1',
                                data: sole_data_insert
                            });
                        }
                    }
                }
                else {

                    if ((req.body.lead_comp_id) || (req.body.jvs_company) || (req.body.associats_id)) {
                        const lead_comp_ids = req.body.lead_comp_id;

                        if (lead_comp_ids) {
                            //lead existence
                            const lead_existence = await Tenderpartners.findOne({
                                where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' },
                                attributes: ['lead_comp_ids']
                            })

                            if (!lead_existence) {
                                const lead_insert_data = {
                                    user_comp_id: req.comp_id,
                                    project_id: req.body.project_id,
                                    lead_comp_ids: lead_comp_ids,
                                    group_no: lead_comp_ids,
                                    type_data: '1',
                                    status: '1',
                                    created_at: getCurrentDateTime(),
                                    created_by: req.userId,
                                }
                                const insert_lead = await Tenderpartners.create(lead_insert_data);
                                if (insert_lead) {
                                    if (req.body.jvs_company) {
                                        const jv_comp_ids = req.body.jvs_company.split(',');
                                        if (jv_comp_ids.length > 0) {
                                            const response_jv_partners = await Promise.all(jv_comp_ids.map(async (jv_data) => {
                                                const jv_insert_data = {
                                                    user_comp_id: req.comp_id,
                                                    project_id: req.body.project_id,
                                                    group_no: lead_comp_ids,
                                                    type_data: '1',
                                                    jv_ids: jv_data,
                                                    status: '1',
                                                    created_at: getCurrentDateTime(),
                                                    created_by: req.userId,
                                                }
                                                await TenderpartnersJVS.create(jv_insert_data);
                                            }));
                                        }
                                    }
                                    if (req.body.associats_id) {
                                        const assoc_comp_ids = req.body.associats_id.split(',');
                                        if (assoc_comp_ids.length > 0) {
                                            const response_assoc_partners = await Promise.all(assoc_comp_ids.map(async (assoc_data) => {
                                                const assoc_insert_data = {
                                                    user_comp_id: req.comp_id,
                                                    project_id: req.body.project_id,
                                                    group_no: req.body.lead_comp_id,
                                                    type_data: '1',
                                                    associative_id: assoc_data,
                                                    status: '1',
                                                    created_at: getCurrentDateTime(),
                                                    created_by: req.userId,
                                                }
                                                await TenderpartnersASSo.create(assoc_insert_data);
                                            }));
                                        }
                                    }
                                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: process.env.APIRESPMSG_RECFOUND,
                                        error: false,
                                        success: true,
                                        status: '1',
                                        data: insert_lead
                                    });
                                }
                            }
                            else {
                                if (req.body.jvs_company) {
                                    const jv_comp_ids = req.body.jvs_company.split(',');
                                    if (jv_comp_ids.length > 0) {
                                        //jv delete
                                        const jv_existence = await TenderpartnersJVS.findAll({
                                            where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' },
                                            attributes: ['id']
                                        })
                                        const response_jv_partners = await Promise.all(jv_existence.map(async (jv_data) => {
                                            await TenderpartnersJVS.destroy({
                                                where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, id: jv_data.id },
                                            })
                                        }));
                                    }
                                }
                                else {
                                    const jv_existence = await TenderpartnersJVS.findAll({
                                        where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' },
                                        attributes: ['id']
                                    })
                                    const response_jv_partners = await Promise.all(jv_existence.map(async (jv_data) => {
                                        await TenderpartnersJVS.destroy({
                                            where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, id: jv_data.id },
                                        })
                                    }));
                                }
                                if (req.body.associats_id) {
                                    const assoc_comp_ids = req.body.associats_id.split(',');
                                    if (assoc_comp_ids.length > 0) {
                                        //assoc delete
                                        const assoc_existence = await TenderpartnersASSo.findAll({
                                            where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' },
                                            attributes: ['id']
                                        })
                                        const response_assoc_partners = await Promise.all(assoc_existence.map(async (assoc_data) => {
                                            await TenderpartnersASSo.destroy({
                                                where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, id: assoc_data.id },
                                            })
                                        }));
                                    }
                                }
                                else {
                                    const assoc_existence = await TenderpartnersASSo.findAll({
                                        where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' },
                                        attributes: ['id']
                                    })
                                    const response_assoc_partners = await Promise.all(assoc_existence.map(async (assoc_data) => {
                                        await TenderpartnersASSo.destroy({
                                            where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, id: assoc_data.id },
                                        })
                                    }));
                                }

                                const lead_update_data = {
                                    lead_comp_ids: lead_comp_ids,
                                    is_solo: '0',
                                    group_no: lead_comp_ids,
                                    updated_by: req.userId,
                                    updated_at: getCurrentDateTime(),
                                }
                                const upd_lead_data = await Tenderpartners.update(lead_update_data, {
                                    where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' }
                                });
                                if (upd_lead_data) {
                                    if (req.body.jvs_company) {
                                        const jv_comp_ids = req.body.jvs_company.split(',');
                                        if (jv_comp_ids.length > 0) {
                                            const response_jv_partners = await Promise.all(jv_comp_ids.map(async (jv_data) => {
                                                const jv_insert_data = {
                                                    user_comp_id: req.comp_id,
                                                    project_id: req.body.project_id,
                                                    group_no: lead_comp_ids,
                                                    type_data: '1',
                                                    jv_ids: jv_data,
                                                    status: '1',
                                                    created_at: getCurrentDateTime(),
                                                    created_by: req.userId,
                                                }
                                                await TenderpartnersJVS.create(jv_insert_data);
                                            }));
                                        }
                                    }

                                    if (req.body.associats_id) {
                                        const assoc_comp_ids = req.body.associats_id.split(',');
                                        if (assoc_comp_ids.length > 0) {
                                            const response_assoc_partners = await Promise.all(assoc_comp_ids.map(async (assoc_data) => {
                                                const assoc_insert_data = {
                                                    user_comp_id: req.comp_id,
                                                    project_id: req.body.project_id,
                                                    group_no: req.body.lead_comp_id,
                                                    type_data: '1',
                                                    associative_id: assoc_data,
                                                    status: '1',
                                                    created_at: getCurrentDateTime(),
                                                    created_by: req.userId,
                                                }
                                                await TenderpartnersASSo.create(assoc_insert_data);
                                            }));
                                        }
                                    }

                                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: process.env.APIRESPMSG_RECFOUND,
                                        error: false,
                                        success: true,
                                        status: '1',
                                        data: upd_lead_data
                                    });

                                }
                            }
                        }
                        else {
                            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                message: process.env.APIRESPMSG_RECNOTFOUND,
                                error: error.message,
                                success: false,
                                status: '0'
                            });
                        }
                    }
                    else {
                        const skip_existence = await Tenderpartners.findOne({
                            where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1'},
                            attributes: ['lead_comp_ids']
                        })
                        if (!skip_existence) {
                            const skip_insert_data = {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                consortium_skip: 0,
                                type_data: '1',
                                status: '1',
                                created_at: getCurrentDateTime(),
                                created_by: req.userId,
                            }
                            const insert_lead = await Tenderpartners.create(skip_insert_data);
                            if (insert_lead) {
                                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECFOUND,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: insert_lead
                                });
                            }
                        }
                        else {
                            const skip_upd_data = {
                                updated_by: req.userId,
                                updated_at: getCurrentDateTime(),
                                consortium_skip: 0,
                                lead_comp_ids: null,
                                is_solo: '0'
                            }
                            const skip_upd_datas = await Tenderpartners.update(skip_upd_data, {
                                where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1' }
                            })
                            if (skip_upd_datas) {
                                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECFOUND,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: skip_upd_datas
                                });
                            }
                        }

                    }
                }

            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: error.message,
                    success: false,
                    status: '0'
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }

} 


const getconsortiumcompanydata = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const lead_company_data = await Tenderpartners.findAll({
                where: {
                    status: '1',
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                }, attributes: ['id', 'lead_comp_ids', 'project_id']
            });
            const asso_company_data = await TenderpartnersASSo.findAll({
                where: {
                    status: '1',
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                }, attributes: ['id', 'associative_id', 'project_id']
            });
            const jvs_company_data = await TenderpartnersJVS.findAll(
                {
                    where: {
                        status: '1',
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                    }, attributes: ['id', 'jv_ids', 'project_id']
                }
            );
            const data_res = {
                lead_company_data: lead_company_data,
                asso_company_data: asso_company_data,
                jvs_company_data: jvs_company_data
            }
            if ((lead_company_data[0]) || (asso_company_data[0]) || (jvs_company_data[0])) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: data_res
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                    data: data_res
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }

}

const getconsortiumcompanies = async (req, res) => {
    try {
        const company_data = await MainCompany.findAll({
            where: {
                status: '1',
                is_varified: '1',
            }, attributes: ['id', 'company_name', 'company_details']
        });

        if ((company_data[0])) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: company_data
            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: error.message,
            // message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

    }

}


//============================================key detail=====================================// 
//add key detail
const addkeydetail = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        tender_bid_opening: Joi.date().required(),
        technical_bid_opening: Joi.date().required(),
        technical_evaluation: Joi.date().required(),
        financial_bid_opening: Joi.date().required(),
        financial_evaluation: Joi.date().required(),
        award_of_contract: Joi.date().required(),
        contract_agreement: Joi.date().required(),
        contract_negotiation: Joi.date().required(),
        minutes_negotiation: Joi.date().required(),
        commencement: Joi.date().required(),
        completion_per_contract: Joi.date().required(),
        actual_date_completion: Joi.date().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        tender_bid_opening: req.body.tender_bid_opening,
        technical_bid_opening: req.body.technical_bid_opening,
        technical_evaluation: req.body.technical_evaluation,
        financial_bid_opening: req.body.financial_bid_opening,
        financial_evaluation: req.body.financial_evaluation,
        award_of_contract: req.body.award_of_contract,
        contract_agreement: req.body.contract_agreement,
        contract_negotiation: req.body.contract_negotiation,
        minutes_negotiation: req.body.minutes_negotiation,
        commencement: req.body.commencement,
        completion_per_contract: req.body.completion_per_contract,
        actual_date_completion: req.body.actual_date_completion,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const existence_key_detail = await TenderKeyDetails.findOne({ where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' }, attributes: ['id'] })
            if (!existence_key_detail) {
                const insert = await TenderKeyDetails.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//edit key details
const editkeydetail = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editkeydetail = await TenderKeyDetails.findOne({
                where: { project_id: req.body.project_id, user_comp_id: req.comp_id, status: '1' },
                attributes: ['id', 'project_id', 'tender_bid_opening', 'technical_bid_opening', 'technical_evaluation', 'financial_bid_opening', 'financial_evaluation', 'award_of_contract', 'contract_agreement', 'contract_negotiation', 'minutes_negotiation', 'commencement', 'completion_per_contract', 'actual_date_completion'],
            })
            if (!editkeydetail) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editkeydetail,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update Key details
const updatekeydetail = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        tender_bid_opening: Joi.date().required(),
        technical_bid_opening: Joi.date().required(),
        technical_evaluation: Joi.date().required(),
        financial_bid_opening: Joi.date().required(),
        financial_evaluation: Joi.date().required(),
        award_of_contract: Joi.date().required(),
        contract_agreement: Joi.date().required(),
        contract_negotiation: Joi.date().required(),
        minutes_negotiation: Joi.date().required(),
        commencement: Joi.date().required(),
        completion_per_contract: Joi.date().required(),
        actual_date_completion: Joi.date().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        tender_bid_opening: req.body.tender_bid_opening,
        technical_bid_opening: req.body.technical_bid_opening,
        technical_evaluation: req.body.technical_evaluation,
        financial_bid_opening: req.body.financial_bid_opening,
        financial_evaluation: req.body.financial_evaluation,
        award_of_contract: req.body.award_of_contract,
        contract_agreement: req.body.contract_agreement,
        contract_negotiation: req.body.contract_negotiation,
        minutes_negotiation: req.body.minutes_negotiation,
        commencement: req.body.commencement,
        completion_per_contract: req.body.completion_per_contract,
        actual_date_completion: req.body.actual_date_completion,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const keydetail = await TenderKeyDetails.findOne({ where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' }, attributes: ['id'] })
            if (keydetail) {
                const existData_upd = await TenderKeyDetails.findOne({
                    where: {
                        status: "1",
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        tender_bid_opening: req.body.tender_bid_opening,
                        technical_bid_opening: req.body.technical_bid_opening,
                        technical_evaluation: req.body.technical_evaluation,
                        financial_bid_opening: req.body.financial_bid_opening,
                        financial_evaluation: req.body.financial_evaluation,
                        award_of_contract: req.body.award_of_contract,
                        contract_agreement: req.body.contract_agreement,
                        contract_negotiation: req.body.contract_negotiation,
                        minutes_negotiation: req.body.minutes_negotiation,
                        commencement: req.body.commencement,
                        completion_per_contract: req.body.completion_per_contract,
                        actual_date_completion: req.body.actual_date_completion,
                    },
                    attributes: ['id']
                });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const keydetail_update_obj = {
                    tender_bid_opening: req.body.tender_bid_opening,
                    technical_bid_opening: req.body.technical_bid_opening,
                    technical_evaluation: req.body.technical_evaluation,
                    financial_bid_opening: req.body.financial_bid_opening,
                    financial_evaluation: req.body.financial_evaluation,
                    award_of_contract: req.body.award_of_contract,
                    contract_agreement: req.body.contract_agreement,
                    contract_negotiation: req.body.contract_negotiation,
                    minutes_negotiation: req.body.minutes_negotiation,
                    commencement: req.body.commencement,
                    completion_per_contract: req.body.completion_per_contract,
                    actual_date_completion: req.body.actual_date_completion,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update_key_detail = await TenderKeyDetails.update(keydetail_update_obj, {
                    where: { status: "1", project_id: req.body.project_id, user_comp_id: req.comp_id },
                });
                if (update_key_detail) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: update_key_detail
                    });
                }

            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete Key details
const deletekeydetail = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletekeydetail = await TenderKeyDetails.findOne({
                where: { project_id: req.body.project_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id'],
            })
            if (deletekeydetail) {
                const key_detail_update_obj = {
                    status: '0',
                    modified_by: req.userId,
                }
                const key_detail_update = await TenderKeyDetails.update(key_detail_update_obj, {
                    where: { project_id: req.body.project_id, user_comp_id: req.comp_id },
                });
                if (key_detail_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: key_detail_update
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


//============================================key detail=====================================// 

//============================================financial detail=====================================// 

//add financial detail
const addfinancialdetail = async (req, res) => {
    const schema = Joi.object({
        project_id: Joi.number().required(),
        financial_proposal: Joi.number().required(),
        award_contract_value: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        financial_proposal: req.body.financial_proposal,
        award_contract_value: req.body.award_contract_value,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    }
    else {
        try {
            const financial_existence = await TenderFinancialDetails.findOne({
                where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id },
                attributes: ['id'],
            })
            if (!financial_existence) {
                const insert = await TenderFinancialDetails.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert
                    });
                }
            }
            else {
                res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                })
            }
        }
        catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

const addfinancialrefdetail = async (req, res) => {
    const schema = Joi.object({
        project_id: Joi.number().required(),
        comp_id: Joi.string().pattern(/^[0-9,]+$/).required(),
        comp_amount: Joi.string().pattern(/^[0-9,]+$/).required(),
        comp_share: Joi.string().pattern(/^[0-9,]+$/).required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        comp_id: req.body.comp_id,
        comp_amount: req.body.comp_amount,
        comp_share: req.body.comp_share,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    }
    else {
        try {

            const delimiter = ',';
            const projectIds = [dataToValidate.project_id];
            const response_data = dataToValidate.comp_id.split(delimiter).map(Number);
            const response_comp_amount_data = dataToValidate.comp_amount.split(delimiter).map(Number);
            const response_comp_share_data = dataToValidate.comp_share.split(delimiter).map(Number);


            const existingRecords = [];
            const recordsToCreate = [];

            for (let i = 0; i < response_data.length; i++) {
                const existingLeadRecord = await Tenderpartners.findOne({
                    where: { status: '1', consortium: 1, user_comp_id: req.comp_id, lead_comp_ids: response_data[i], project_id: projectIds[0] },
                    attributes: ['id', 'group_no']
                });

                const existingAssocRecord = await TenderpartnersASSo.findOne({
                    where: { status: '1', group_no: existingLeadRecord.group_no, user_comp_id: req.comp_id, associative_id: response_data[i], project_id: projectIds[0] },
                    attributes: ['id', 'group_no']
                });
                if (existingLeadRecord) {
                    const existingJvRecord = await TenderpartnersJVS.findOne({
                        where: { status: '1', group_no: existingLeadRecord.group_no, user_comp_id: req.comp_id, jv_ids: response_data[i], project_id: projectIds[0] },
                        attributes: ['id', 'group_no']
                    });
                    if (existingJvRecord) {
                        recordsToCreate.push({
                            project_id: projectIds[0],
                            comp_id: response_data[i],
                            comp_status: '1',
                            comp_amount: response_comp_amount_data[i] ? response_comp_amount_data[i] : 0,
                            comp_share: response_comp_share_data[i] ? response_comp_share_data[i] : 0,
                            user_comp_id: req.comp_id,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        });
                    }
                    //     const existingFinRecord = await TenderFinancialDetails.findOne({ 
                    //         where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id } 
                    //     });
                    //     if (!existingFinRecord) {
                    //         existingRecords.push(existingFinRecord);
                    //     } 
                    //     else{
                    //         const existingFinrefRecord = await TenderFinancialRefDetail.findOne({ 
                    //             where: { status: '1', user_comp_id: req.comp_id, comp_id: data, project_id: req.body.project_id } 
                    //         });
                    //         if(!existingFinrefRecord){

                    //         }

                    //     }
                }
            }


            if (recordsToCreate.length > 0) {
                //const fileRecords = await TenderFinancialRefDetail.bulkCreate(recordsToCreate);
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: `${recordsToCreate.length} records inserted successfully`,
                    error: false,
                    success: true,
                    status: '1',
                    data: recordsToCreate
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        }
        catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//edit financial details
const editfinancialdetail = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editfindetail = await TenderFinancialDetails.findOne({
                where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                attributes: ['id', 'project_id', 'financial_proposal', 'award_contract_value'],
                include: [{
                    model: TenderFinancialRefDetail,
                    attributes: ['comp_id', 'comp_amount', 'comp_share'],
                    as: 'fin_ref_detail',
                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                    required: false,
                }]
            });
            if (editfindetail) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editfindetail,
                });
            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

//update financial details
const updatefinancialdetail = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        financial_proposal: Joi.number().required(),
        award_contract_value: Joi.number().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        financial_proposal: req.body.financial_proposal,
        award_contract_value: req.body.award_contract_value,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const findetail = await TenderFinancialDetails.findOne({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },
                attributes: ['id']
            })
            if (findetail) {
                const existData_upd = await TenderFinancialDetails.findOne({
                    where: {
                        status: "1",
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        financial_proposal: req.body.financial_proposal,
                        award_contract_value: req.body.award_contract_value,
                    },
                    attributes: ['id']
                });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const findetail_update_obj = {
                    financial_proposal: req.body.financial_proposal,
                    award_contract_value: req.body.award_contract_value,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update_fin_detail = await TenderFinancialDetails.update(findetail_update_obj, {
                    where: { status: "1", project_id: req.body.project_id, user_comp_id: req.comp_id },
                });
                if (update_fin_detail) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: update_fin_detail
                    });
                }

            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//delete financial details
const deletefinancialdetail = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletefindetail = await TenderFinancialDetails.findOne({
                where: { project_id: req.body.project_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id'],
            })
            if (deletefindetail) {
                const fin_detail_update_obj = {
                    status: '0',
                    modified_by: req.userId,
                }
                const fin_detail_update = await TenderFinancialDetails.update(fin_detail_update_obj, {
                    where: { project_id: req.body.project_id, user_comp_id: req.comp_id },
                });
                if (fin_detail_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                        data: fin_detail_update
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//============================================financial detail=====================================// 


//============================================Tender Status Manage =====================================// 

//add tender Status Manage
const addtenderstatusmanage = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        tender_status: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        tender_status: req.body.tender_status,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const existence_tender_status = await TenderStatusManage.findOne({
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' },
                attributes: ['id']
            })
            if (!existence_tender_status) {
                const insert = await TenderStatusManage.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//edit tender Status Manage
const edittenderstatusmanage = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const edittenderstatusmanage = await TenderStatusManage.findOne({
                where: { project_id: req.body.project_id, user_comp_id: req.comp_id },
                attributes: ['id', 'project_id', 'tender_status'],
                include: [{
                    model: TenderStatus,
                    attributes: ['id', 'status_name'],
                    where: { status: '1' },
                    required: false,
                }]
            })
            if (!edittenderstatusmanage) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: edittenderstatusmanage,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//update tender Status Manage
const updatetenderstatusmanage = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        tender_status: Joi.number().required(),
        modified_by: Joi.number().allow(null),
        updated_at: Joi.date().iso().allow(null),
    });

    const dataToValidate = {
        project_id: req.body.bg_id,
        tender_status: req.body.tender_status,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tenderstatusmanage = await TenderStatusManage.findOne({ where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1' }, attributes: ['id'] })
            if (tenderstatusmanage) {
                const existData_upd = await TenderStatusManage.findOne({
                    where: {
                        status: "1",
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        tender_status: req.body.tender_status,
                    },
                    attributes: ['id']
                });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const tenderstatusmanage_update_obj = {
                    tender_status: req.body.tender_status,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update_tenderstatusmanage = await TenderStatusManage.update(tenderstatusmanage_update_obj, {
                    where: { status: "1", project_id: req.body.project_id, user_comp_id: req.comp_id },
                });
                if (update_tenderstatusmanage) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: update_tenderstatusmanage
                    });
                }

            }
            else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const assignconsortiumcompanielist = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const tender_group = await Tenderpartners.findOne({ 
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '1', status: '1', consortium_skip:null }, 
                attributes: ['id', 'lead_comp_ids', 'group_no'] 
            })
            const tenderstatusmanage = await Tenderpartners.findOne({ 
                where: { user_comp_id: req.comp_id, project_id: req.body.project_id, is_solo: '1', type_data: '1', status: '1',consortium_skip:null }, 
                attributes: ['id', 'lead_comp_ids', 'group_no'] 
            })

            if ((tenderstatusmanage) || (tender_group)) {
                if (tenderstatusmanage) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECFOUND,
                        error: false,
                        success: true,
                        status: '1',
                        is_solo: '1',
                        data: tenderstatusmanage,
                    });
                } else {
                    const lead_comp = await Tenderpartners.findAll({ 
                        where: { user_comp_id: req.comp_id, project_id: req.body.project_id, status: '1', group_no: tender_group.group_no, type_data: '1' }, 
                        attributes: ['id', 'lead_comp_ids', 'group_no'] 
                    })
                    const tender_list_asso = await TenderpartnersASSo.findAll({ 
                        where: { user_comp_id: req.comp_id, project_id: req.body.project_id, group_no: tender_group.group_no, status: '1' } ,
                        attributes: ['id', 'associative_id', 'group_no'] 
                    });
                    const tender_list_jvs = await TenderpartnersJVS.findAll({ 
                        where: { user_comp_id: req.comp_id, project_id: req.body.project_id, group_no: tender_group.group_no, status: '1' } ,
                        attributes: ['id', 'jv_ids', 'group_no'] 
                    });
                    const datares = {
                        lead_comp: lead_comp,
                        tender_list_asso: tender_list_asso,
                        tender_list_jvs: tender_list_jvs,
                    }
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECFOUND,
                        error: false,
                        success: true,
                        status: '1',
                        is_solo: '0',
                        data: datares,
                    });

                }
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


//============================================Tender Status Manage=====================================// 
const TenderBasicDetailsUpdate = async (req, res) => {
    const project_id = req.body.project_id;
    const pre_bid_meeting_date = (req.body.prebid_meeting_date) ? req.body.prebid_meeting_date : null;
    const bid_validity_date = (req.body.bid_validity_date) ? req.body.bid_validity_date : null;
    const submission_start_date = (req.body.submission_start_date) ? req.body.submission_start_date : null
    const submission_end_date = req.body.submission_end_date;
    const location = req.body.location;
    const client = req.body.client;
    const funding_agency = (req.body.funding_agency) ? req.body.funding_agency : null;
    const sector = req.body.sector;
    const country = req.body.country;
    const state = req.body.state;
    const city = (req.body.city) ? req.body.city : null;
    const tender_estimated_cost = req.body.tender_estimated_cost;

    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
        // submission_start_date: Joi.date().required(),
        submission_end_date: Joi.date().required(),
        sector: Joi.number().required(),
        client: Joi.number().required(),
        country: Joi.number().required(),
        state: Joi.number().required(),
        tender_estimated_cost: Joi.number().required(),
    });
    const dataToValidate = {
        project_id, submission_end_date, sector, client, country, state, tender_estimated_cost

    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderDatesModel = createTenderModelDate(req.comp_id);
            await TenderDatesModel.performOperation();
            const tender_exists = await TenderModel.findOne({
                where: {
                    user_comp_id: req.comp_id, status: '1', id: project_id
                },
            })

            const update_basic_details = {
                pre_bid_meeting_date: pre_bid_meeting_date,
                bid_validity_date: bid_validity_date,
                submission_start_date: submission_start_date,
                submission_end_date: submission_end_date,
                bid_opening_place: location,
                client_id: client,
                funding_id: funding_agency,
                sector_id: sector,
                country_id: country,
                state_id: state,
                city_id: city,
                tender_cost: tender_estimated_cost,
                modified_by: req.comp_id,
                updated_at: getCurrentDateTime(),
            }
            if (tender_exists) {
                const updateMain = await TenderModel.update(update_basic_details, {
                    where: {
                        user_comp_id: req.comp_id, status: '1', id: project_id
                    }
                })
                const existingTndrDetailsinDates = await TenderDatesModel.findOne({
                    where: {
                        user_comp_id: req.comp_id, status: '1', bg_tender_id: project_id
                    }
                })
                let updateDate = {
                    bid_submission_start_date: submission_start_date,
                    bid_submission_end_date: submission_end_date,
                    updated_by: req.comp_id,
                    updated_at: getCurrentDateTime(),
                }

                if (existingTndrDetailsinDates) {
                    const updateDates = await TenderDatesModel.update(updateDate, {
                        where: {
                            user_comp_id: req.comp_id, status: '1', bg_tender_id: project_id
                        }
                    })
                } else {
                    updateDate.bg_tender_id = req.body.project_id
                    updateDate.user_comp_id = req.comp_id
                    updateDate.created_by = req.comp_id
                    updateDate.created_at = getCurrentDateTime();
                    const newTenderDates = await TenderDatesModel.create(updateDate)
                    console.log('new dates created');
                }

                if (updateMain) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: update_basic_details
                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }

    }
}

module.exports = {
    getProjectDetails, updatetenderdate, updatetenderEmd, updatetenderFEEinfo, updatetenderOtherData,
    addtendercoverInfo, updatetendercoverInfo, deletendercoverInfo, getcompanyList, Addnewcompany, addtenderparnercompany, getconsortiumcompanydata,
    getconsortiumcompanies,
    addkeydetail, editkeydetail, updatekeydetail, deletekeydetail,
    addfinancialdetail, addfinancialrefdetail, editfinancialdetail, updatefinancialdetail, deletefinancialdetail,
    addtenderstatusmanage, edittenderstatusmanage, updatetenderstatusmanage, assignconsortiumcompanielist, TenderBasicDetailsUpdate
};  
