require('dotenv').config();
const Tenderpartners = require('../../models/tender/TenderPartner')
const TenderpartnersASSo = require('../../models/tender/TenderpartnersAssociats')
const TenderpartnersJVS = require('../../models/tender/TenderpartnersJVS')
const { Op, Sequelize } = require('sequelize');
const Main_company = require('../../models/Main_company');
const Joi = require('joi');
const getCurrentDateTime = () => new Date();
const MainCompany = require('../../models/master/MainCompany')


const companyjvslist = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const response = await MainCompany.findAll({
                order: [['company_name', 'ASC']],
                where: { status: '1', is_varified: '1' },
                attributes: ['id', 'company_name','link_comp_id'],
            });

            const resp_private = await MainCompany.findAll({
                where: { status: '1', is_varified: '2', user_comp_id: req.comp_id },
                attributes: ['id', 'company_name', 'link_comp_id'],
            });


            const mergedResponse = [...response, ...resp_private];
            if (mergedResponse[0]) {


                const response_lead = await Tenderpartners.findAll({
                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                    attributes: ['lead_comp_ids'],
                });
                const response_jvs = await TenderpartnersJVS.findAll({
                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                    attributes: ['jv_ids'],
                });
                const response_associates = await TenderpartnersASSo.findAll({
                    where: { status: '1', project_id: req.body.project_id, user_comp_id: req.comp_id },
                    attributes: ['associative_id'],
                });

                if (response_lead[0] || response_jvs[0] || response_associates[0]) {


                    const response_lead_ids_comp = response_lead.map(item => item.lead_comp_ids);

                    const response_jvs_comp = response_jvs.map(item => item.jv_ids);

                    const response_associates_comp = response_associates.map(item => item.associative_id);

                    const reaspose_all = [...response_lead_ids_comp, ...response_jvs_comp, ...response_associates_comp];

                    const response_comp = await MainCompany.findAll({
                        order: [['company_name', 'ASC']],
                        where: {
                            status: '1',
                            id: {
                                [Op.notIn]: reaspose_all
                            },
                            is_varified: '1'
                        },
                        attributes: ['id', 'company_name'],
                    });
                    
                    const response_comp_private = await MainCompany.findAll({
                        where: {
                            status: '1', is_varified: '2',
                            created_by: req.userId,
                            id: {
                                [Op.notIn]: reaspose_all
                            },
                            user_comp_id: req.comp_id
                        },
                        attributes: ['id', 'company_name'],
                    });
                    const mergedResponse_comp = [...response_comp, ...response_comp_private];
                    if (mergedResponse_comp[0]) {
                        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: process.env.APIRESPMSG_RECFOUND,
                            error: false,
                            success: true,
                            status: '1',
                            data: mergedResponse
                        });
                    } else {
                        res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECNOTFOUND,
                            error: true,
                            success: false,
                            status: '0',
                        });

                    }

                } else {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECFOUND,
                        error: false,
                        success: true,
                        status: '1',
                        data: mergedResponse
                    });

                }

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }

    }
}

const companyverifylist = async (req, res) => {
    try {
        const response = await MainCompany.findAll({
            order: [['company_name', 'ASC']],
            where: { status: '1', is_varified: '1' },
            attributes: ['id', 'company_name','company_details'],
        });
        const resp_private = await MainCompany.findAll({
            where: { status: '1', is_varified: '2', user_comp_id: req.comp_id },
            attributes: ['id', 'company_name', 'company_details'],
        });

        const mergedResponse = [...response, ...resp_private];

        if (mergedResponse[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: mergedResponse
            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        })
    }
}

//Delete by id..
const DeleteTndrCompany = async (req, res) => {
    const schema = Joi.object().keys({
        company_id: Joi.number().required(),
    });
    const dataToValidate = {
        company_id: req.body.company_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await MainCompany.findOne({ 
                where: { status: "1", id: req.body.company_id }, 
                attributes: ['id'] 
            });
            if (existData) {
                const UpdateDataArr = {
                    status: "0",
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update = await MainCompany.update(UpdateDataArr, {
                    where: { id: req.body.company_id }
                });
                res.send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
            // res.status(400).send({ error: error.message });
        }
    }
}

//Single Data Get..
const GetByIDTndrCompany = async (req, res) => {
    const schema = Joi.object().keys({
        company_id: Joi.number().required(),
    });
    const dataToValidate = {
        company_id: req.body.company_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await MainCompany.findOne({ 
                where: { status: "1", id: req.body.company_id }, 
                attributes: ['id', 'company_name', 'company_details'] 
            });
            if (existData) {
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
            // res.status(400).send({ error: error.message });
        }
    }
}

//Update By Id..
const UpdateByIDTndrCompany = async (req, res) => {
    const schema = Joi.object().keys({
        company_id: Joi.number().required(),
        company_name: Joi.string().required(),
        company_details:Joi.string().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });
    const dataToValidate = {
        company_id: req.body.company_id,
        company_name: req.body.company_name,
        company_details: req.body.company_details,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await MainCompany.findOne({ 
                where: { status: "1", id: req.body.company_id }, 
                attributes: ['id'] 
            });
            if (existData) {
                const existData_upd = await MainCompany.findOne({ 
                    where: { status: "1", company_name: req.body.company_name,company_details: req.body.company_details }, 
                    attributes: ['id'] 
                });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const UpdateDataArr = {
                    company_name: req.body.company_name,
                    company_details: req.body.company_details,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const update = await MainCompany.update(UpdateDataArr, {
                    where: { status: "1", id: req.body.company_id }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}


const comptitorAssignonProject = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        lead_comp_ids: Joi.string().required(),
        // jv_ids: Joi.string().allow(null),
        // associative_ids: Joi.string().allow(null),


    });
    const dataToValidate = {
        project_id: req.body.project_id,
        lead_comp_ids: req.body.lead_comp_ids,
        // jv_ids: req.body.jv_ids,
        // associative_ids: req.body.associative_ids,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            let num_lead_insert = 0;
            let num_asso_insert = 0;
            let num_jvs_insert = 0;
            const lead_group = await Tenderpartners.findOne(
                {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        status: '1',
                    },
                    attributes: ['group_no'],
                    order: [['id', 'desc']],
                },
            );
            if (req.body.lead_comp_ids) {
                const lead_comp_id = req.body.lead_comp_ids.split(',');
                const lead_comp_ids_comp_id = await Promise.all(lead_comp_id.map(async (data) => {
                    const lead_exist = await Tenderpartners.findOne(
                        {
                            where: {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                lead_comp_ids: data,
                                status: '1',
                            }
                        }
                    );
                    if (!lead_exist) {
                        num_lead_insert++;
                        const lead_insert = await Tenderpartners.create(
                            {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                lead_comp_ids: data,
                                group_no: (lead_group) ? lead_group.group_no + 1 : 1,
                                created_at: getCurrentDateTime(),
                                created_by: req.userId,
                            }
                        );
                    }

                }));
            }
            if (req.body.associative_ids) {
                const associative_ids_comp_id = req.body.associative_ids.split(',');
                const response_asociatives = await Promise.all(associative_ids_comp_id.map(async (data) => {
                    const asso_exist = await TenderpartnersASSo.findOne(
                        {
                            where: {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                associative_id: data,
                                status: '1',
                            }
                        }
                    );
                    if (!asso_exist) {
                        num_asso_insert++;
                        const lead_upd = await TenderpartnersASSo.create(
                            {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                associative_id: data,
                                group_no: (lead_group) ? lead_group.group_no + 1 : 1,
                                type_data: '2',
                                created_at: getCurrentDateTime(),
                                created_by: req.userId,
                            }
                        );
                    }
                }));
            }
            if (req.body.jv_ids) {
                const jv_ids_comp_id = req.body.jv_ids.split(',');
                const response_jv_ids_comp_id = await Promise.all(jv_ids_comp_id.map(async (data) => {
                    const ajv_ids_exist = await TenderpartnersJVS.findOne(
                        {
                            where: {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                jv_ids: data,
                                status: '1',
                            }
                        }
                    );
                    if (!ajv_ids_exist) {
                        num_jvs_insert++;
                        const ajv_ids_insert = await TenderpartnersJVS.create(
                            {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                jv_ids: data,
                                group_no: (lead_group) ? lead_group.group_no + 1 : 1,
                                type_data: '2',
                                created_at: getCurrentDateTime(),
                                created_by: req.userId,
                            }
                        );
                    }
                }));
            }
            if ((num_lead_insert > 0) || (num_asso_insert > 0) || (num_jvs_insert > 0)) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: (num_lead_insert + num_asso_insert + num_jvs_insert) + '  ' + process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'No Record Inserted',
                    error: true,
                    success: false,
                    status: '0',
                });
            }


        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}


const comptitorAssignonProjectListing = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),



    });
    const dataToValidate = {
        project_id: req.body.project_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const lead_comp_rec = await Tenderpartners.findAll(
                {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        status: '1'
                    },
                    attributes: ['id', 'lead_comp_ids', 'group_no', [Sequelize.fn('COUNT', Sequelize.col('id')), 'count']],
                    order: [['id', 'desc']],
                    group: ['group_no']
                },
            );
            if (lead_comp_rec[0]) {
                const response = await Promise.all(lead_comp_rec.map(async (data) => {
                    const lead_comp_record = await Tenderpartners.findAll(
                        {
                            where: {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                group_no: data.group_no,
                                status: '1'
                            },
                            attributes: ['id', 'lead_comp_ids', 'group_no', 'type_data'],
                            include: [{
                                model: MainCompany,
                                attributes: ['company_name', 'created_at'],
                                where: { status: '1' },
                                required: false,
                            },
                            ]

                        },
                    );
                    const jvs_ids_rec = await TenderpartnersJVS.findAll(
                        {
                            where: {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                group_no: data.group_no,
                                status: '1',
                            },
                            attributes: ['id', 'jv_ids', 'group_no'],
                            include: [{
                                model: MainCompany,
                                attributes: ['company_name', 'created_at'],
                                where: { status: '1' },
                                required: false,
                            },
                            ]
                        }
                    );
                    const asso_ids_rec = await TenderpartnersASSo.findAll(
                        {
                            where: {
                                user_comp_id: req.comp_id,
                                project_id: req.body.project_id,
                                group_no: data.group_no,
                                status: '1',
                            }, attributes: ['id', 'associative_id', 'group_no'],
                            include: [{
                                model: MainCompany,
                                attributes: ['company_name', 'created_at'],
                                where: { status: '1' },
                                required: false,
                            },
                            ]
                        }
                    );

                    const Lead_company = lead_comp_record.map(item => ({
                        companyName: (item.main_company) ? item.main_company.company_name + ' (' + 'lead' + ')' : null,
                        lead_id: item.id,
                        company_id: item.lead_comp_ids,
                        group_no: item.group_no,
                        type_data: item.type_data
                    }));
                    const jvs_company = jvs_ids_rec.map(item => ({
                        companyName: (item.main_company) ? item.main_company.company_name + ' (' + 'jvs' + ')' : null,
                        jvs_id: item.id,
                        company_id: item.jv_ids,
                        group_no: item.group_no
                    })
                    );
                    const associative_company = asso_ids_rec.map(item => ({
                        companyName: (item.main_company) ? item.main_company.company_name + ' (' + 'associative' + ')' : null,
                        associative_id: item.id,
                        company_id: item.associative_id,
                        group_no: item.group_no
                    }))
                    const comptitor_assign_company_list = {
                        Lead_company,
                        jvs_company,
                        associative_company
                    }
                    return {
                        comptitor_assign_company_list
                    };
                }))

                if (response[0]) {
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECFOUND,
                        error: false,
                        success: true,
                        status: '1',
                        data: response
                    });

                } else {
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',
                    });

                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


const comptitorAssignonProjectEdit = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        group_no: Joi.number().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        group_no: req.body.group_no,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const lead_comp_record = await Tenderpartners.findAll(
                {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        group_no: req.body.group_no,
                        status: '1'
                    },
                    attributes: ['id', 'lead_comp_ids', 'group_no'],
                    include: [{
                        model: MainCompany,
                        attributes: ['company_name', 'created_at'],
                        where: { status: '1' },
                        required: false,
                    },
                    ]

                },
            );
            const jvs_ids_rec = await TenderpartnersJVS.findAll(
                {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        group_no: req.body.group_no,
                        status: '1',
                    },
                    attributes: ['id', 'group_no'],
                    include: [{
                        model: MainCompany,
                        attributes: ['company_name', 'created_at'],
                        where: { status: '1' },
                        required: false,
                    },
                    ]
                }
            );
            const asso_ids_rec = await TenderpartnersASSo.findAll(
                {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        group_no: req.body.group_no,
                        status: '1',
                    }, attributes: ['id', 'group_no'],
                    include: [{
                        model: MainCompany,
                        attributes: ['company_name', 'created_at'],
                        where: { status: '1' },
                        required: false,
                    },
                    ]
                }
            );
            const Lead_company = lead_comp_record.map(item => ({
                companyName: (item.main_company) ? item.main_company.company_name + ' (' + 'lead' + ')' : null,
                lead_id: item.id,
                group_no: item.group_no
            }));
            const jvs_company = jvs_ids_rec.map(item => ({
                companyName: (item.main_company) ? item.main_company.company_name + ' (' + 'jvs' + ')' : null,
                jvs_id: item.id,
                group_no: item.group_no
            })
            );
            const associative_company = asso_ids_rec.map(item => ({
                companyName: (item.main_company) ? item.main_company.company_name + ' (' + 'associative' + ')' : null,
                associative_id: item.id,
                group_no: item.group_no
            }))
            const comptitor_assign_company_edit = {
                Lead_company,
                jvs_company,
                associative_company
            }



            if (lead_comp_record[0]) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: comptitor_assign_company_edit
                });

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }

        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


const comptitorAssignonProjectdelete = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        group_no: Joi.number().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        group_no: req.body.group_no,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const lead_comp_record_exist = await Tenderpartners.findOne(
                {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        group_no: req.body.group_no,
                        status: '1'
                    },
                    attributes: ['id'],


                },
            );
            const jvs_comp_record_exist = await TenderpartnersJVS.findOne(
                {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        group_no: req.body.group_no,

                        status: '1'
                    },
                    attributes: ['id'],


                },
            );
            const asso_comp_record_exist = await TenderpartnersASSo.findOne(
                {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        group_no: req.body.group_no,
                        status: '1'
                    },
                    attributes: ['id'],
                },
            );
            if ((lead_comp_record_exist) || (jvs_comp_record_exist) || (asso_comp_record_exist)) {
                const upd_status = {
                    status: '0',
                    updated_at: getCurrentDateTime(),
                    modified_by: req.userId
                }

                const lead_comp_record = await Tenderpartners.update(upd_status,
                    {
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            group_no: req.body.group_no,

                            status: '1'
                        },
                    },
                );
                const jvs_ids_rec = await TenderpartnersJVS.update(upd_status,
                    {
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            group_no: req.body.group_no,
                            status: '1',
                        },


                    }
                );
                const asso_ids_rec = await TenderpartnersASSo.update(upd_status,
                    {
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            group_no: req.body.group_no,
                            status: '1',
                        },
                    }
                );
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


const comptitorAssignonProjectupdate = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        group_no: Joi.number().required(),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        group_no: req.body.group_no,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {


            let num_lead_upd = 0;
            let num_asso_upd = 0;
            let num_jvs_upd = 0;
            const upd_status = {
                status: '0',
                updated_at: getCurrentDateTime(),
                modified_by: req.userId
            }
            if (req.body.lead_comp_ids) {

                //jv delete
                const jv_existence = await TenderpartnersJVS.findAll({
                    where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '2' },
                    attributes: ['id']
                })
                const response_jv_partners = await Promise.all(jv_existence.map(async (jv_data) => {
                    await TenderpartnersJVS.destroy({
                        where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, id: jv_data.id },
                    })
                }));

                //assoc delete
                const assoc_existence = await TenderpartnersASSo.findAll({
                    where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, type_data: '2' },
                    attributes: ['id']
                })
                const response_assoc_partners = await Promise.all(assoc_existence.map(async (assoc_data) => {
                    await TenderpartnersASSo.destroy({
                        where: { status: '1', user_comp_id: req.comp_id, project_id: req.body.project_id, id: assoc_data.id },
                    })
                }));


                const lead_upd = await Tenderpartners.update(upd_status,
                    {
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            group_no: req.body.group_no,
                            type_data: '2',
                            status: '1',
                        }
                    }
                );
                const lead_comp_id = req.body.lead_comp_ids.split(',');
                const lead_comp_ids_comp_id = await Promise.all(lead_comp_id.map(async (data) => {
                    num_lead_upd++
                    const lead_insert = await Tenderpartners.create(
                        {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            lead_comp_ids: data,
                            group_no: req.body.group_no,
                            type_data: '2',
                            created_at: getCurrentDateTime(),
                            created_by: req.userId,
                        }
                    );


                }));
            }
            if (req.body.associative_ids) {
                const asso_upd = await TenderpartnersASSo.update(upd_status,
                    {
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            group_no: req.body.group_no,
                             type_data: '2',
                            status: '1',
                        }
                    }
                );
                const associative_ids_comp_id = req.body.associative_ids.split(',');
                const response_asociatives = await Promise.all(associative_ids_comp_id.map(async (data) => {
                    num_asso_upd++
                    const lead_upd = await TenderpartnersASSo.create(
                        {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            associative_id: data,
                            group_no: req.body.group_no,
                             type_data: '2',
                            created_at: getCurrentDateTime(),
                            created_by: req.userId,
                        }
                    );

                }));
            }
            if (req.body.jv_ids) {
                const jv_ids_upd = await TenderpartnersJVS.update(upd_status,
                    {
                        where: {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            group_no: req.body.group_no,
                             type_data: '2',
                            status: '1',
                        }
                    }
                );
                const jv_ids_comp_id = req.body.jv_ids.split(',');
                const response_jv_ids_comp_id = await Promise.all(jv_ids_comp_id.map(async (data) => {
                    num_jvs_upd++
                    const ajv_ids_insert = await TenderpartnersJVS.create(
                        {
                            user_comp_id: req.comp_id,
                            project_id: req.body.project_id,
                            jv_ids: data,
                            group_no: req.body.group_no,
                            type_data: '2',
                            created_at: getCurrentDateTime(),
                            created_by: req.userId,
                        }
                    );

                }));
            }

            if ((num_lead_upd > 0) || (num_asso_upd > 0) || (num_jvs_upd > 0)) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: '  ' + (num_lead_upd + num_asso_upd + num_jvs_upd) + '  ' + process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'No Record Updated',
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

module.exports = {
    companyjvslist, companyverifylist, comptitorAssignonProject, comptitorAssignonProjectListing, comptitorAssignonProjectEdit,
    comptitorAssignonProjectdelete, comptitorAssignonProjectupdate, DeleteTndrCompany, GetByIDTndrCompany, UpdateByIDTndrCompany
}