
const { Sequelize, DataTypes, where, Op, fn, col, literal } = require('sequelize');
const Joi = require('joi');
require('dotenv').config();
const multer = require('multer');
const TenderGeneratedTypeIdModel = require('../../../apps/models/tender/TenderGeneratedTypeIdModel');
const TenderGeneratedTypeModel = require('../../../apps/models/tender/TenderGeneratedTypeModel');
const createTenderModel = require('../../../apps/models/tender/TenderModel');
const createTenderModeDocs = require('../../../apps/models/tender/TenderDocModel');
const getCurrentDateTime = () => new Date();
const TenderAssignManagerModel = require('../../../apps/models/tender/TenderAssignManagerModel');
const Country = require('../../models/master/Country');
const State = require('../../models/master/State');
const City = require('../../models/master/City');
const Tendersector = require('../../models/master/TenderSector');
const Tenderscope = require('../../models/master/TenderScope');
const Users = require('../../models/Users');
const TenderClient = require('../../models/master/TenderClient');
const TenderCommentModel = require('../../models/tender/TenderCommentModel');
const TenderStatusManage = require('../../models/tender/TenderStatusManage');
const TenderBdRoleModel = require('../../models/master/TenderBdRoleModel');
const TenderFundingagency = require('../../models/master/TenderFundingagency');
const TenderPartnerModel = require('../../models/tender/TenderPartner');
const TenderpartnersJVS = require('../../models/tender/TenderpartnersJVS');
const TenderPartnerAssociates = require('../../models/tender/TenderpartnersAssociats');
const MainCompany = require('../../models/master/MainCompany');

function formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}


const tenderlist = async (req, res) => {
    const schema = Joi.object().keys({
        limit: Joi.string().required(),
        page_number: Joi.string().required(),

    });
    const dataToValidate = {
        limit: req.body.limit,
        page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0'
        });
    } else {
        try {
            const page_number = parseInt(dataToValidate.page_number) || 1;
            const limit = parseInt(dataToValidate.limit) || 10;
            const offset = (parseInt(page_number) - 1) * parseInt(limit);
            const currentDate = getCurrentDateTime();
            const year = currentDate.getFullYear();
            const month = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Add padding if needed
            const day = currentDate.getDate().toString().padStart(2, '0'); // Add padding if needed
            const formattedDate = `${year}-${month}-${day}`;
            const dynamicFilters = [];
            const dateFilters = [];
            const orderbydata = [];
            if (req.body.tender_keyword) {
                const tender_keyword = req.body.tender_keyword;
                dynamicFilters.push({
                    tender_name: {
                        [Op.like]: `%${tender_keyword}%`,
                    },
                });
            }
            if (req.body.country_id) {
                const countryId = req.body.country_id;
                dynamicFilters.push({ country_id: countryId });
            }
            if (req.body.state_id) {
                const stateId = req.body.state_id;
                dynamicFilters.push({ state_id: stateId });
            }

            if (req.body.sector_id) {
                const sectorId = req.body.sector_id;
                dynamicFilters.push({ sector_id: sectorId });
            }
            if (req.body.client_id) {
                const clientID = req.body.client_id;
                dynamicFilters.push({ client_id: clientID });
            }
            if (req.body.currency_id) {
                const currendyId = req.body.currency_id;
                dynamicFilters.push({ currency_id: currendyId });
            }
            if (req.body.funding_id) {
                const fundingId = req.body.funding_id;
                dynamicFilters.push({ funding_id: fundingId });
            }

            if (req.body.cycle_id) {
                const cycleId = req.body.cycle_id;
                dynamicFilters.push({ cycle_id: cycleId });

            }

            //comment tag
            if (req.body.ping_users) {
                const ping_users = req.body.ping_users;

                const tender_ping_users_arr = await TenderCommentModel.findAll({
                    where: {
                        status: '1', user_comp_id: req.comp_id,
                        [Op.and]: Sequelize.literal(`FIND_IN_SET('${ping_users}', ping_users_info)`)
                    },
                    attributes: ['tender_id'],
                    raw: true
                });

                const tndr_ping_users_arr = [];
                const tndr_ping_users_obj = await Promise.all(tender_ping_users_arr.map(async (tndr_ping_users_row) => {
                    tndr_ping_users_arr.push(tndr_ping_users_row.tender_id)
                }));
                dynamicFilters.push({ id: tndr_ping_users_arr });


                // dateFilters.push({
                //     [Op.and]: [
                //         literal(`FIND_IN_SET('${tndr_ping_users_arr}', id)`),
                //     ],
                // });
            }




            if (req.body.tender_status) {
                const tender_status = req.body.tender_status;
                dynamicFilters.push({ cycle_id: tender_status });
            }
            if (req.body.tender_activity_status != 'ALL') {
                if (req.body.tender_activity_status) {
                    if (req.body.tender_activity_status == '1') {
                        dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formattedDate));
                    } else if (req.body.tender_activity_status == '2') {
                        dateFilters.push(where(fn('DATE', col('submission_end_date')), '<', formattedDate));
                    }
                } else {
                    // const tender_scope = await Tenderscope.findAll({
                    //     where: {
                    //         status: '1',
                    //         user_comp_id: req.comp_id,
                    //         order_sr: [6, 7]
                    //     },
                    //     attributes: ['id', 'order_sr']
                    // });

                    // if (tender_scope.length > 0) {
                    //     const orderSrFlattened = tender_scope.map(scope => scope.order_sr).flat();
                    //     const allOrder = orderSrFlattened.every(sr => [6, 7].includes(sr));

                    //     if (!allOrder) {
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formattedDate));
                    // }
                    // }
                }
            }
            if (req.body.located == '1') {
                dynamicFilters.push({ national_intern: '1' });
            }
            if (req.body.located == '2') {
                dynamicFilters.push({ national_intern: '2' });
            }
            // if (req.body.service_provider) {
            //     const service_provider = req.body.service_provider;
            //     dynamicFilters.push({ source_id: service_provider });
            // }


            if ((req.body.sort_key) && (req.body.sort_val)) {
                let key_val = null;
                const sort_key = req.body.sort_key
                if ((req.body.sort_val == 'asc') || (req.body.sort_val == 'ASC')) {
                    key_val = 'ASC';
                }
                if ((req.body.sort_val == 'desc') || (req.body.sort_val == 'DESC')) {
                    key_val = 'DESC';
                }
                if ((sort_key == 'tender_emd_amnt_val') || (sort_key == 'submission_end_date')) {
                    orderbydata.push([sort_key, key_val]);
                } else if (sort_key == 'published_date') {
                    orderbydata.push(['publication_date', key_val]);
                } else if (sort_key == 'tender_amnt_val') {
                    orderbydata.push(['tender_cost', key_val]);
                }
            }
            if ((!req.body.tender_status) && (!req.body.cycle_id)) {
                const response_scope = await Tenderscope.findOne({
                    where: {
                        status: '1', user_comp_id: req.comp_id, order_sr: 8
                    },
                    attributes: ['id']
                });
                dateFilters.push({
                    cycle_id: {
                        [Op.lt]: response_scope?.id,
                    },
                });
            }
            //date filter
            if (req.body.from_date && req.body.to_date) {
                const startDate = req.body.from_date;
                const endDate = req.body.to_date;
                const tableName = 'bg_tndr_details_' + req.comp_id + 's';
                dateFilters.push(where(fn('DATE', col(`${tableName}.created_at`)), '>=', startDate));
                dateFilters.push(where(fn('DATE', col(`${tableName}.created_at`)), '<=', endDate));
            }

            //publication date filter
            if (req.body.published_date) {
                const publication_date = req.body.published_date;
                if (publication_date == 'today') {
                    dateFilters.push(where(fn('DATE', col('publication_date')), '=', formattedDate));

                } else if (publication_date == 'yesterday') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 1);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0'); // Add padding if needed
                    const day = previousDate.getDate().toString().padStart(2, '0'); // Add padding if needed
                    const formattedPreviousDate = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('publication_date')), '=', formattedPreviousDate));

                } else if (publication_date == 'last_7_days') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 7);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = previousDate.getDate().toString().padStart(2, '0');
                    const formatlast_7 = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formatlast_7));
                    dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedDate));

                } else if (publication_date == 'last_30_days') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 30);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = previousDate.getDate().toString().padStart(2, '0');
                    const formatlast_30 = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formatlast_30));
                    dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedDate));

                } else if (publication_date == 'this_month') {
                    const currentDate = getCurrentDateTime();
                    currentDate.setDate(1);
                    const year = currentDate.getFullYear();
                    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = currentDate.getDate().toString().padStart(2, '0');
                    const formattedFirstDateOfMonth = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formattedFirstDateOfMonth));
                    dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedDate));
                } else if (publication_date == 'last_month') {
                    const currentDate = getCurrentDateTime();
                    const lastDayOfPreviousMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0);
                    const startOfLastMonth = new Date(lastDayOfPreviousMonth.getFullYear(), lastDayOfPreviousMonth.getMonth(), 1);
                    const endOfLastMonth = lastDayOfPreviousMonth;
                    const formattedStartDate = formatDate(startOfLastMonth);
                    const formattedEndDate = formatDate(endOfLastMonth);
                    dateFilters.push(where(fn('DATE', col('publication_date')), '>=', formattedStartDate));
                    dateFilters.push(where(fn('DATE', col('publication_date')), '<=', formattedEndDate));
                } else if (publication_date == 'custom_date') {
                    const pubdate_cust_from_date = req.body.pubdate_cust_from_date;
                    const pubdate_cust_to_date = req.body.pubdate_cust_to_date;
                    if ((pubdate_cust_from_date) && (pubdate_cust_to_date)) {
                        dateFilters.push(where(fn('DATE', col('publication_date')), '>=', pubdate_cust_from_date));
                        dateFilters.push(where(fn('DATE', col('publication_date')), '<=', pubdate_cust_to_date));

                    }

                }
            }
            //clossing data filter
            if (req.body.close_exp_date) {
                const close_exp_date = req.body.close_exp_date;
                if (close_exp_date == 'today') {
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '=', formattedDate));

                } else if (close_exp_date == 'yesterday') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 1);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0'); // Add padding if needed
                    const day = previousDate.getDate().toString().padStart(2, '0'); // Add padding if needed
                    const formattedPreviousDate = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '=', formattedPreviousDate));

                } else if (close_exp_date == 'last_7_days') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 7);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = previousDate.getDate().toString().padStart(2, '0');
                    const formatlast_7 = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formatlast_7));
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedDate));

                } else if (close_exp_date == 'last_30_days') {
                    const currentDate = getCurrentDateTime();
                    const previousDate = new Date(currentDate);
                    previousDate.setDate(currentDate.getDate() - 30);
                    const year = previousDate.getFullYear();
                    const month = (previousDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = previousDate.getDate().toString().padStart(2, '0');
                    const formatlast_30 = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formatlast_30));
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedDate));

                } else if (close_exp_date == 'this_month') {
                    const currentDate = getCurrentDateTime();
                    currentDate.setDate(1); // Set the day to 1 to get the first date of the current month
                    const year = currentDate.getFullYear();
                    const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
                    const day = currentDate.getDate().toString().padStart(2, '0');
                    const formattedFirstDateOfMonth = `${year}-${month}-${day}`;
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formattedFirstDateOfMonth));
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedDate));
                } else if (close_exp_date == 'last_month') {
                    const currentDate = getCurrentDateTime();
                    const lastDayOfPreviousMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0);
                    const startOfLastMonth = new Date(lastDayOfPreviousMonth.getFullYear(), lastDayOfPreviousMonth.getMonth(), 1);
                    const endOfLastMonth = lastDayOfPreviousMonth;
                    const formattedStartDate = formatDate(startOfLastMonth);
                    const formattedEndDate = formatDate(endOfLastMonth);
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', formattedStartDate));
                    dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', formattedEndDate));
                } else if (close_exp_date == 'custom_date') {
                    const expdate_cust_from_date = req.body.expdate_cust_from_date;
                    const expdate_cust_to_date = req.body.expdate_cust_to_date;
                    if ((expdate_cust_from_date) && (expdate_cust_to_date)) {
                        dateFilters.push(where(fn('DATE', col('submission_end_date')), '>=', expdate_cust_from_date));
                        dateFilters.push(where(fn('DATE', col('submission_end_date')), '<=', expdate_cust_to_date));
                    }
                }
            }
            //filter amount
            if (req.body.estm_value_emd) {
                const estm_value_emd = req.body.estm_value_emd
                if (estm_value_emd == 'not_specified') {
                    dateFilters.push({
                        tender_emd_amnt_val: {
                            [Op.lt]: '1',
                        },
                    });
                } else if ((estm_value_emd != "not_specified") && (estm_value_emd != "10000000000>") && (estm_value_emd != "custom_range")) {
                    const AmountRecdArr = estm_value.split('-');
                    const cvMin = AmountRecdArr[0];
                    const cvMax = AmountRecdArr[1];
                    dateFilters.push({
                        tender_emd_amnt_val: {
                            [Op.gte]: cvMin,
                            [Op.lte]: cvMax,
                        },
                    });
                } else if (estm_value_emd == "10000000000>") {
                    dateFilters.push({
                        tender_emd_amnt_val: {
                            [Op.gte]: '10000000000',
                        },
                    });
                } else if (estm_value_emd == "custom_range") {
                    const amnt_custrange_operator_emd = req.body.amnt_custrange_operator_emd;
                    const amnt_custrange_amount = req.body.amnt_custrange_amount;

                    if (amnt_custrange_operator_emd && amnt_custrange_amount) {
                        const custrange_denomination = req.body.custrange_denomination_emd || '';
                        const denominationObj = {
                            '': '',
                            'hundred': '00',
                            'thousand': '000',
                            'lacs': '00000',
                            'million': '000000',
                            'crores': '0000000',
                            'billion': '000000000',
                            'trillion': '000000000000',
                        };

                        const ZeroOnAmnt = denominationObj[custrange_denomination] || '';

                        const amnt_custrange_amount_withZero = amnt_custrange_amount + ZeroOnAmnt;

                        dateFilters.push({
                            tender_emd_amnt_val: {
                                [Op[amnt_custrange_operator_emd]]: amnt_custrange_amount_withZero,
                            },
                        });
                    }
                }
            }

            if (req.body.estm_value) {
                const estm_value = req.body.estm_value
                if (estm_value == 'not_specified') {
                    dateFilters.push({
                        tender_cost: {
                            [Op.lt]: '1',
                        },
                    });
                } else if ((estm_value != "not_specified") && (estm_value != "10000000000>") && (estm_value != "custom_range")) {
                    const AmountRecdArr = estm_value.split('-');
                    const cvMin = AmountRecdArr[0];
                    const cvMax = AmountRecdArr[1];
                    dateFilters.push({
                        tender_cost: {
                            [Op.gte]: cvMin,
                            [Op.lte]: cvMax,
                        },
                    });
                } else if (estm_value == "10000000000>") {
                    dateFilters.push({
                        tender_cost: {
                            [Op.gte]: '10000000000',
                        },
                    });
                } else if (estm_value == "custom_range") {
                    // var amnt_custrange_operator = req.body.amnt_custrange_operator;
                    // var amnt_custrange_amount = req.body.amnt_custrange_amount;
                    // if ((amnt_custrange_operator) && (amnt_custrange_amount)) {
                    //     var custrange_denomination = (req.body.custrange_denomination) ? req.body.custrange_denomination : '';

                    //     var denominationObj = {
                    //         "": "",
                    //         "hundred": "00",
                    //         "thousand": "000",
                    //         "lacs": "00000",
                    //         "million": "000000",
                    //         "crores": "0000000",
                    //         "billion": "000000000",
                    //         "trillion": "000000000000",
                    //     };
                    //     var ZeroOnAmnt = denominationObj[custrange_denomination];

                    //     amnt_custrange_amount = amnt_custrange_amount + ZeroOnAmnt;
                    //     console.log(amnt_custrange_amount, 'custrange_denominationcustrange_denominationcustrange_denominations', amnt_custrange_operator)
                    //     dateFilters.push({
                    //         tender_emd_amnt_val: {
                    //             [Op[amnt_custrange_operator]]: amnt_custrange_amount,
                    //         },
                    //     });
                    const amnt_custrange_operator = req.body.amnt_custrange_operator;
                    const amnt_custrange_amount = req.body.amnt_custrange_amount;
                    if (amnt_custrange_operator && amnt_custrange_amount) {
                        const custrange_denomination = req.body.custrange_denomination || '';
                        const denominationObj = {
                            '': '',
                            'hundred': '00',
                            'thousand': '000',
                            'lacs': '00000',
                            'million': '000000',
                            'crores': '0000000',
                            'billion': '000000000',
                            'trillion': '000000000000',
                        };
                        const ZeroOnAmnt = denominationObj[custrange_denomination] || '';
                        const amnt_custrange_amount_withZero = amnt_custrange_amount + ZeroOnAmnt;
                        dateFilters.push({
                            tender_cost: {
                                [Op[amnt_custrange_operator]]: amnt_custrange_amount_withZero,
                            },
                        });
                    }
                }
            }
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderDocModel = createTenderModeDocs(req.comp_id);
            await TenderDocModel.performOperation();

            const response = await TenderModel.findAll({
                // order: [['updated_at', 'DESC']],
                order: orderbydata.length > 0 ? orderbydata : [['updated_at', 'DESC']],
                attributes: ['id', 'gg_tenderID', 'updated_at', 'tender_name', 'tnd_ref_id', 'publication_date', 'tender_gov_id', 'tender_cost', 'tender_emd_amnt_val', 'client_cont_person', 'client_cont_address', 'submission_start_date', 'submission_end_date', 'source_id', 'tnd_url', 'cycle_id', 'is_corri_update', 'national_intern'],
                where: {
                    [Op.and]: [
                        { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                        ...dynamicFilters, // Include the dynamic filters
                        ...dateFilters, // Include the dynamic date range condition
                    ],
                },
                offset,
                limit,
                include: [{
                    model: Country,
                    attributes: ['country_name'],
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: State,
                    attributes: ['state_name'],
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: City,
                    attributes: ['city_name'],
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: Users,
                    attributes: ['userfullname'],
                    where: { isactive: '1' },
                    as: 'pre_bid_attend',
                    required: false,
                },
                {
                    model: TenderFundingagency,
                    attributes: ['funding_org_name'],
                    where: { status: '1' },
                    as: 'funding_agency',
                    required: false,
                },
                {
                    model: TenderPartnerModel,
                    attributes: ['lead_comp_ids', 'group_no',],
                    where: { status: '1' },
                    required: false,
                    include: [
                        {
                            model: MainCompany,
                            attributes: ['company_name'],
                            where: { status: '1' },
                            required: false,
                        }]
                },
                {
                    model: TenderpartnersJVS,
                    attributes: ['jv_ids', 'group_no'],
                    where: { status: '1' },
                    required: false,
                    include: [
                        {
                            model: MainCompany,
                            attributes: ['company_name'],
                            where: { status: '1' },
                            required: false,
                        }]
                },
                {
                    model: TenderPartnerAssociates,
                    attributes: ['associative_id', 'group_no'],
                    where: { status: '1' },
                    required: false,
                    include: [
                        {
                            model: MainCompany,
                            attributes: ['company_name'],
                            where: { status: '1' },
                            required: false,
                        }]
                },
                {
                    model: TenderStatusManage,
                    attributes: ['tender_status'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: TenderGeneratedTypeIdModel,
                    attributes: ['generated_tender_id', 'generate_type_id'],
                    where: {
                        [Op.and]: [
                            { status: '1', user_comp_id: req.comp_id }, // Additional filters can be added here
                            //...dynamicFilters, // Include the dynamic filters

                        ],
                    },
                    required: false,
                    include:
                    {
                        model: TenderGeneratedTypeModel,
                        attributes: ['generated_type'],
                        where: { status: '1', user_comp_id: req.comp_id },
                        required: false,
                    }
                },
                {
                    model: Tendersector,
                    attributes: ['sector_name'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: TenderClient,
                    attributes: ['client_name'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: Tenderscope,
                    attributes: [['id', 'scope_id'], 'order_sr', 'cycle_name'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: TenderCommentModel,
                    attributes: ['id', 'comment_txt', 'created_at'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                    include: [
                        {
                            model: Users,
                            attributes: ['userfullname'],
                            where: { isactive: '1' },
                            required: false,
                        }]

                },
                // {
                //     model: TenderGeneratedTypeIdModel,
                //     attributes: ['generated_tender_id'],
                //     where: { status: '1', user_comp_id: req.comp_id },
                //     required: false,
                // },

                {
                    model: TenderAssignManagerModel,
                    attributes: ['bd_role_id'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    as: 'assign_tender',
                    required: false,
                    include: [
                        {
                            model: TenderBdRoleModel,
                            attributes: ['role_name'],
                            where: { status: '1', },
                            required: false,
                        },
                        {
                            model: Users,
                            attributes: ['userfullname'],
                            where: { isactive: '1' },
                            required: false,
                        }],
                },
                {
                    model: TenderDocModel,
                    attributes: ['file_doc_type', 'file_name', 'doc_path', 'file_doc_description', 'tender_category'],
                    as: 'tender_docs',
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },

                ]

            })
            if (!response[0]) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                let count = null;
                if (!req?.body?.cycle_id) {
                    count = await TenderModel.count({
                        where: {
                            [Op.and]: [
                                { status: '1', user_comp_id: req.comp_id },
                                ...dynamicFilters,
                                ...dateFilters,
                            ],
                        },
                    });
                } else {
                    count = await TenderModel.count({
                        where: {
                            [Op.and]: [
                                { status: '1', user_comp_id: req.comp_id },
                                ...dynamicFilters,
                                ...dateFilters,
                            ],
                        },
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    totalItems: count,
                    totalPages: Math.ceil(count / limit),
                    currentPage: page_number,
                    dataoncurrentPage: response.length,
                    data: response,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

module.exports = {
    tenderlist

};  