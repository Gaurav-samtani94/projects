
const { Sequelize, DataTypes, where, Op, fn, col, literal } = require('sequelize');
const Joi = require('joi');
require('dotenv').config();
const multer = require('multer');
const TenderGeneratedTypeIdModel = require('../../../apps/models/tender/TenderGeneratedTypeIdModel');
const createTenderModel = require('../../../apps/models/tender/TenderModel');
const createTenderModeDocs = require('../../../apps/models/tender/TenderDocModel');
const getCurrentDateTime = () => new Date();
const TenderAssignManagerModel = require('../../../apps/models/tender/TenderAssignManagerModel');
const Country = require('../../models/master/Country');
const State = require('../../models/master/State');
const City = require('../../models/master/City');
const Tendersector = require('../../models/master/TenderSector');
const Tenderscope = require('../../models/master/TenderScope');
const Users = require('../../models/Users');
const TenderClient = require('../../models/master/TenderClient');
const TenderCommentModel = require('../../models/tender/TenderCommentModel');
const TenderStatusManage = require('../../models/tender/TenderStatusManage');
const TenderBdRoleModel = require('../../models/master/TenderBdRoleModel');
function formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
}


const tenderlist = async (req, res) => {
    const schema = Joi.object().keys({
        limit: Joi.string().required(),
        page_number: Joi.string().required(),

    });
    const dataToValidate = {
        limit: req.body.limit,
        page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0'
        });
    } else {
        try {
            const page_number = parseInt(dataToValidate.page_number) || 1;
            const limit = parseInt(dataToValidate.limit) || 10;
            const offset = (parseInt(page_number) - 1) * parseInt(limit);
            const currentDate = getCurrentDateTime();
            const year = currentDate.getFullYear();
            const month = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // Add padding if needed
            const day = currentDate.getDate().toString().padStart(2, '0'); // Add padding if needed
            const formattedDate = `${year}-${month}-${day}`;
            const dynamicFilters = [];
            const dateFilters = [];
            const orderbydata = [];
            if (req.body.tender_keyword) {
                const tender_keyword = req.body.tender_keyword;
                dynamicFilters.push({
                    tender_name: {
                        [Op.like]: `%${tender_keyword}%`,
                    },
                });
            }

            if (req.body.country_id) {
                const countryId = req.body.country_id;
                dynamicFilters.push({ country_id: countryId });
            }
            if (req.body.state_id) {
                const stateId = req.body.state_id;
                dynamicFilters.push({ state_id: stateId });
            }

            if (req.body.sector_id) {
                const sectorId = req.body.sector_id;
                dynamicFilters.push({ sector_id: sectorId });
            }
            const check_user_role = await Users.findOne({ where: { permanent_sys_adm: '1', id: req.userId, isactive: '1' } })
            if (!check_user_role) {
                dynamicFilters.push({ created_by: req.userId });
            }
            const getscopeid = await Tenderscope.findOne({ where: { user_comp_id: req.comp_id, order_sr: '1', status: '1' } })
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();

            const TenderDocModel = createTenderModeDocs(req.comp_id);
            await TenderDocModel.performOperation();

            const response = await TenderModel.findAll({
                // order: [['updated_at', 'DESC']],
                order: orderbydata.length > 0 ? orderbydata : [['updated_at', 'DESC']],
                attributes: ['id', 'gg_tenderID', 'updated_at', 'tender_name', 'tnd_ref_id', 'publication_date', 'tender_gov_id', 'tender_cost', 'tender_emd_amnt_val', 'submission_start_date', 'submission_end_date', 'source_id', 'tnd_url', 'cycle_id', 'is_corri_update'],
                where: {
                    [Op.and]: [
                        { status: '1', user_comp_id: req.comp_id, source_id: '1', cycle_id: getscopeid?.id }, // Additional filters can be added here
                        ...dynamicFilters, // Include the dynamic filters
                        ...dateFilters, // Include the dynamic date range condition
                    ],
                },
                offset,
                limit,
                include: [{
                    model: Country,
                    attributes: ['country_name'],
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: State,
                    attributes: ['state_name'],
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: City,
                    attributes: ['city_name'],
                    where: { status: '1', },
                    required: false,
                },
                {
                    model: TenderStatusManage,
                    attributes: ['tender_status'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: Tendersector,
                    attributes: ['sector_name'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: TenderClient,
                    attributes: ['client_name'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: Tenderscope,
                    attributes: [['id', 'scope_id'], 'order_sr', 'cycle_name'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: TenderCommentModel,
                    attributes: ['id', 'comment_txt', 'created_at'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                    include: [
                        {
                            model: Users,
                            attributes: ['userfullname'],
                            where: { isactive: '1' },
                            required: false,
                        }]

                },
                {
                    model: TenderGeneratedTypeIdModel,
                    attributes: ['generated_tender_id'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },
                {
                    model: TenderAssignManagerModel,
                    attributes: ['bd_role_id'],
                    where: { status: '1', user_comp_id: req.comp_id },
                    as: 'assign_tender',
                    required: false,
                    include: [
                        {
                            model: TenderBdRoleModel,
                            attributes: ['role_name'],
                            where: { status: '1', },
                            required: false,
                        },
                        {
                            model: Users,
                            attributes: ['userfullname'],
                            where: { isactive: '1' },
                            required: false,
                        }],
                },
                {
                    model: TenderDocModel,
                    attributes: ['file_doc_type', 'file_name', 'doc_path', 'file_doc_description', 'tender_category'],
                    as: 'tender_docs',
                    where: { status: '1', user_comp_id: req.comp_id },
                    required: false,
                },

                ]

            })
            if (!response[0]) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',

                });
            }
            else {
                let count = null;
                if (!req?.body?.cycle_id) {
                    count = await TenderModel.count({
                        where: {
                            [Op.and]: [
                                { status: '1', source_id: '1', user_comp_id: req.comp_id, cycle_id: getscopeid?.id },
                                ...dynamicFilters,
                                ...dateFilters,
                            ],
                        },
                    });
                } else {
                    count = await TenderModel.count({
                        where: {
                            [Op.and]: [
                                { status: '1', source_id: '1', user_comp_id: req.comp_id, cycle_id: getscopeid?.id },
                                ...dynamicFilters,
                                ...dateFilters,
                            ],
                        },
                    });
                }
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    totalItems: count,
                    totalPages: Math.ceil(count / limit),
                    currentPage: page_number,
                    dataoncurrentPage: response.length,
                    data: response,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}




module.exports = {
    tenderlist

};  