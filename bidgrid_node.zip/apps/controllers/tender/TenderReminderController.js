const Joi = require('joi');
require('dotenv').config();
const createTenderModel = require('../../../apps/models/tender/TenderModel');
const TenderReminderModel = require('../../models/tender/TenderReminderModel');
// const Tende = require('../../models/tender/TenderReminderModel');
const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const getCurrentDateTime = () => new Date();
const addReminder = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        reminder_date: Joi.date().required(),
        reminder_subject: Joi.string().required(),
        reminder_message: Joi.string().required(),
        tender_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });
    // console.log(req.comp_id)
    const dataToValidate = {
        user_comp_id: req.comp_id,
        tender_id: req.body.tender_id,
        reminder_date: req.body.reminder_date,
        reminder_subject: req.body.reminder_subject,
        reminder_message: req.body.reminder_message,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const tenderReminder = await TenderReminderModel.findOne({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, reminder_date: req.body.reminder_date }, attributes: ['id', 'reminder_date'] })
            if (!tenderReminder) {
                const insert = await TenderReminderModel.create(dataToValidate)
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Reminder Created Successfully',
                    error: false,
                    success: true,
                    status: '1',
                    data: insert,
                });
            }
            else {
                const recordwithStatus0 = await TenderReminderModel.findOne({ where: { user_comp_id: req.comp_id, tender_id: req.body.tender_id, status: '0' }, attributes: ['id', 'tender_id'] })

                if (recordwithStatus0) {

                    const updateObj = {
                        status: 1
                    }

                    const addRemainder = await TenderReminderModel.update(updateObj, {
                        where: {
                            id: recordwithStatus0.id,
                        }
                    })

                    if (addRemainder) {
                        return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                            message: 'Remainder Created Successfully',
                            error: false,
                            success: true,
                            status: '1',
                            data: addRemainder,
                        });
                    }
                } else {
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: 'Remainder Already Exist',
                        error: false,
                        success: true,
                        status: '0',
                    });

                }

            }



        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
};

const removeReminder = async (req, res) => {
    const schema = Joi.object().keys({
        tender_id: Joi.number().required(),
    });

    const dataToValidate = {
        tender_id: req.body.tender_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const updateData = {
            status: '0',
            modified_by: req.userId,
            updated_at: getCurrentDateTime(),
        }
        try {
            const removeReminder = await TenderReminderModel.findOne({
                where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id, created_by: req.userId, status: '1' }, attributes: ['id',],
            });
            // console.log(updateData)
            if (removeReminder) {
                TenderReminderModel.update(updateData, {
                    where: { tender_id: req.body.tender_id, user_comp_id: req.comp_id, created_by: req.userId },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Reminder Removed Successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'You are not authorised to remove this Reminder.',
                    error: true,
                    success: false,
                    status: '0',
                });


            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
                h: error.message
            });

        }
    }
}

// Tender Reminder List
const tenderReminderList = async (req, res) => {
    try {
        const reminder_date = req.body.reminder_date;
        const dateFilters = [];
        if (reminder_date) {
            dateFilters.push(where(fn('DATE', col('reminder_date')), '=', reminder_date));
        }
        const TenderModel = createTenderModel(req.comp_id);
        await TenderModel.performOperation();
        const tenderReminder_list = await TenderReminderModel.findAll({
            where: {
                [Op.and]: [
                    { user_comp_id: req.comp_id, created_by: req.userId, status: '1' },
                    ...dateFilters,
                ],
            },
            attributes: [['id', 'reminder_id'], 'reminder_date', 'reminder_subject', 'tender_id', 'reminder_message'],
            order: [['id', 'DESC']],
        });
        const tasksWithCount = await Promise.all(tenderReminder_list.map(async (data) => {
            const tender_details = await TenderModel.findOne(
                {
                    where: { user_comp_id: req.comp_id, id: data.tender_id, status: '1' }
                    , attributes: ['id', 'tender_name', 'submission_start_date', 'submission_end_date']
                });
            return {
                ...data.toJSON(),
                tender_details,

            };
        }));
        if (!tenderReminder_list[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount,
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}


//Get tender reminder By Id
const getTenderReminderById = async (req, res) => {
    const schema = Joi.object().keys({
        reminder_id: Joi.number().required(),
    });

    const dataToValidate = {
        reminder_id: req.body.reminder_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const editReminder = await TenderReminderModel.findOne({
                where: { id: req.body.reminder_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'reminder_date', 'reminder_subject', 'reminder_message'],
            })
            if (!editReminder) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: false,
                    success: true,
                    status: '0',
                    data: [],
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record Found',
                error: false,
                success: true,
                status: '1',
                data: editReminder,
            });
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}


//Update Tender Reminder 
const updateTenderReminderById = async (req, res) => {
    const schema = Joi.object().keys({
        reminder_id: Joi.number().required(),
        reminder_date: Joi.date().iso().allow(),
        reminder_subject: Joi.string().allow(),
        reminder_message: Joi.string().allow(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        reminder_id: req.body.reminder_id,
        reminder_date: req.body.reminder_date,
        reminder_subject: req.body.reminder_subject,
        reminder_message: req.body.reminder_message,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const tenderReminder = await TenderReminderModel.findOne({ where: { user_comp_id: req.comp_id, id: req.body.reminder_id, status: '1' }, attributes: ['id', 'reminder_date'] })
            console.log(tenderReminder)
            if (tenderReminder) {
                TenderReminderModel.update(dataToValidate, {
                    where: { id: req.body.reminder_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Tender Reminder Updated successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//Delete Collection By Id

const deleteTenderReminderById = async (req, res) => {
    const schema = Joi.object().keys({
        reminder_id: Joi.number().required(),
    });

    const dataToValidate = {
        reminder_id: req.body.reminder_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const updateData = {
            status: '0',
            modified_by: req.userId,
            updated_at: getCurrentDateTime(),
        }
        try {
            const deleteCollection = await TenderReminderModel.findOne({
                where: { id: req.body.reminder_id, user_comp_id: req.comp_id, status: '1' }, attributes: ['id', 'reminder_date'],
            });
            // console.log(updateData)
            if (deleteCollection) {
                TenderReminderModel.update(updateData, {
                    where: { id: req.body.reminder_id, user_comp_id: req.comp_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Tender Reminder Deleted Successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: true,
                    success: false,
                    status: '0',
                });


            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}
const tenderwishlistrecord = async (req, res) => {


    const TenderModel = createTenderModel(req.comp_id);
    await TenderModel.performOperation();

    const tenderReminder_list = await TenderReminderModel.findAll({
        where: { user_comp_id: req.comp_id, created_by: req.userId, status: '1' },
        attributes: [['id', 'reminder_id'], 'reminder_date', 'reminder_subject', 'tender_id', 'reminder_message'],
        order: [['id', 'DESC']],
    });
    const tasksWithCount = await Promise.all(tenderReminder_list.map(async (data) => {
        const tender_details = await TenderModel.findOne(
            {
                where: { user_comp_id: req.comp_id, id: data.tender_id, status: '1' }
                , attributes: ['id', 'tender_name', 'submission_start_date', 'submission_end_date']
            });
        return {
            ...data.toJSON(),
            tender_details,

        };
    }));
    try {
        if (!tenderReminder_list[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
        else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: tasksWithCount,
            });
        }
    }
    catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

// const reminder_List_tender = async (req, res) => {
//     try {
//         const response = await TenderReminderModel.findAll({
//             order: [['tender_id', 'DESC']],
//             where: { user_comp_id: req.comp_id, created_by: req.userId, status: '1' },
//             attributes: ['tender_id'],
//         })
//         if (!response[0]) {
//             return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                 message: 'Record Not Found',
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         } else {
//             res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                 message: 'Record Found',
//                 error: false,
//                 success: true,
//                 status: '1',
//                 data: response,

//             });
//         }
//     } catch (error) {
//         res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//             message: process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });

//     }
// }


module.exports = {
    addReminder, tenderReminderList, getTenderReminderById, updateTenderReminderById, deleteTenderReminderById,
    tenderwishlistrecord, removeReminder
};  