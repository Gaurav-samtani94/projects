const Joi = require('joi');
const multer = require('multer');
const getCurrentDateTime = () => new Date();
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const TenderReqReplyModel = require('../../models/tender/TenderReqReplyModel')


const storage = multer.diskStorage({

    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'reqreply';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        //console.log("Ash :- "+extension);
        cb(null, Date.now() + 'reqreply' + Math.random() + extension); // Rename file with a timestamp
    },
});

//Update By Id Role..
const upload = multer({ storage: storage }); // Initialize Multer

const addReqReply = async (req, res) => {
    upload.single('file')(req, res, async function (err) {
        if (err) {
            return res.status(400).send({ error: err.message });
        }
        const dataToValidate = {
            tender_request_id: req.body.tender_request_id,
            reply_tndr_req: req.body.reply_tndr_req
        };
        const schema = Joi.object().keys({
            tender_request_id: Joi.number().required(),
            reply_tndr_req: Joi.string(),
        });

        const result = schema.validate(dataToValidate);
        if (result.error) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        }

        if (req.body.reply_tndr_req === undefined && req.file === undefined) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: "Please enter field/s to update",
                error: true,
                success: false,
                status: '0',
            });
        }

        try {
            if (req.file) { // Corrected variable name from `files` to `file`
                var add_reply_details = {
                    file_name: req.file.filename,
                    file_path: req.file.destination,
                    created_by: req.userId,
                    created_at: getCurrentDateTime(),
                    tender_request_id: req.body.tender_request_id,
                    reply_tndr_req: req.body.reply_tndr_req,
                    user_comp_id: req.comp_id,
                    reply_from_userid: req.userId
                }
            } else {
                var add_reply_details = {
                    created_by: req.userId,
                    created_at: getCurrentDateTime(),
                    tender_request_id: req.body.tender_request_id,
                    reply_tndr_req: req.body.reply_tndr_req,
                    user_comp_id: req.comp_id,
                    reply_from_userid: req.userId

                }
            }

            const reply = await TenderReqReplyModel.create(add_reply_details)
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECINSERTED,
                error: false,
                success: true,
                status: '1',
                data: reply // Corrected variable name from `insert` to `mom`
            });

        } catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
                text: error.message
            });
        }
    });
}





const ListAll = async (req, res) => {

    const dataToValidate = {
        tender_request_id: req.body.tender_request_id,
    };
    const schema = Joi.object().keys({
        tender_request_id: Joi.number().required(),
    });

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    }

    try {
        const replies = await TenderReqReplyModel.findAll({
            order: [['id', 'ASC']],
            where: {
                status: '1',
                user_comp_id: req.comp_id,
                tender_request_id: req.body.tender_request_id

            }

        });
        if (!replies[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: replies,

        });
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}









module.exports = {
    addReqReply, ListAll
};
