const Joi = require('joi');
const multer = require('multer');
const getCurrentDateTime = () => new Date();
require('dotenv').config();
const fs = require('fs');
const path = require('path');
// const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const MeetingMomModel = require('../../models/meetingMom/MeetingMomModel');
const MainmeetingModel = require('../../models/meeting/MainmeetingModel');


const storage = multer.diskStorage({

    destination: (req, file, cb) => {
        const foldername = 'public' + '_' + req.comp_id + '/' + 'meetingmom';
        const uploadPath = `uploads/${foldername}`;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        //console.log("Ash :- "+extension);
        cb(null, Date.now() + 'mom' + Math.random() + extension); // Rename file with a timestamp
    },
});

//Update By Id Role..
const upload = multer({ storage: storage }); // Initialize Multer

const addMeetingMom = async (req, res) => {
    upload.single('file')(req, res, async function (err) {
        if (err) {
            return res.status(400).send({ error: err.message });
        }
        const dataToValidate = {
            meeting_id: req.body.meeting_id,
            description: req.body.description
        };
        const schema = Joi.object().keys({
            meeting_id: Joi.number().required(),
            description: Joi.string().required(),
        });

        const result = schema.validate(dataToValidate);
        if (result.error) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        }

        try {
            if (req.file) { // Corrected variable name from `files` to `file`
                var add_mom_details = {
                    file_name: req.file.filename,
                    file_path: req.file.destination,
                    created_by: req.userId,
                    created_at: getCurrentDateTime(),
                    meeting_id: req.body.meeting_id,
                    description: req.body.description,
                    user_comp_id: req.comp_id,
                }
            } else {
              var  add_mom_details = {
                    created_by: req.userId,
                    created_at: getCurrentDateTime(),
                    meeting_id: req.body.meeting_id,
                    description: req.body.description,
                    user_comp_id: req.comp_id,
                }
            }

            const meeting = await MainmeetingModel.findOne({
                where: {
                    id: req.body.meeting_id,
                    status: '1'
                }
            })


            if (!meeting) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

            if (meeting.dataValues.is_mom == 1) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                })
            }

            if (meeting.dataValues.created_by !== req.userId) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_NOTPERMITTED,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

            const mom = await MeetingMomModel.create(add_mom_details);
            if (mom) {
                await MainmeetingModel.update(
                    { is_mom: '1', updated_by: req.userId, updated_at: getCurrentDateTime() },
                    {
                        where: {
                            id: req.body.meeting_id,
                            user_comp_id: req.comp_id,
                            status: '1'
                        }
                    }
                )
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: mom // Corrected variable name from `insert` to `mom`
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
                text: error.message
            });
        }
    });
}


const updateMom = async (req, res) => {
    upload.single('file')(req, res, async function (err) {
        if (err) {
            return res.status(400).send({ error: err.message });
        }
        const dataToValidate = {
            description: req.body.description,
            id: req.body.id
        };
        const schema = Joi.object().keys({
            description: Joi.string(),
            id: Joi.number().required(),

        });

        const result = schema.validate(dataToValidate);
        if (result.error) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        }

        if (req.body.description === undefined && req.file === undefined) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: "Please enter field/s to update",
                error: true,
                success: false,
                status: '0',
            });
        }

        try {
            if (req.file) { // Corrected variable name from `files` to `file`
                var upd_mom_details = {
                    file_name: req.file.filename,
                    file_path: req.file.destination,
                    modified_by: req.userId,
                    modified_at: getCurrentDateTime(),
                    description: req.body.description
                }
            } else {
               var upd_mom_details = {
                    modified_by: req.userId,
                    modified_at: getCurrentDateTime(),
                    description: req.body.description
                }

            }

            const momtoupdate = await MeetingMomModel.findOne({
                where: {
                    id: req.body.id,
                    status: '1'
                }
            })

            if (!momtoupdate) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

            if (momtoupdate.dataValues.created_by != req.userId) {
                console.log(momtoupdate.dataValues.created_by, "and", req.userId);
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_NOTPERMITTED,
                    error: true,
                    success: false,
                    status: '0'
                });
            }


            const update = await MeetingMomModel.update(upd_mom_details, {
                where: { id: req.body.id, status: '1' }
            });

            if (update) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                    
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    });
}


const ListAll = async (req, res) => {
    try {
        const MOMs = await MeetingMomModel.findAll({
            order: [['id', 'DESC']],
            where: {
                status: 1,
                user_comp_id: req.comp_id
            },


        });
        if (!MOMs[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: MOMs,

        });
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}



const GetMomById = async (req, res) => {
    const dataToValidate = {
        mom_id: req.body.mom_id,
    };
    const schema = Joi.object().keys({
        mom_id: Joi.number().required()
    });

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    }
    try {
        const MOMs = await MeetingMomModel.findOne({
            where: {
                status: 1,
                id: req.body.mom_id,
                user_comp_id: req.comp_id
            },

        });
        if (!MOMs) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: MOMs,

        });
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}
//xyz


module.exports = {
    addMeetingMom, updateMom, ListAll, GetMomById
};
