require('dotenv').config();
const { Op, Sequelize } = require('sequelize');
const Joi = require('joi');
const getCurrentDateTime = () => new Date();
const MainCompany = require('../../models/master/MainCompany')
const MainmeetingModel = require('../../models/meeting/MainmeetingModel')
const MeetingInvitationModel = require('../../models/meeting/MeetingInvitationModel');
const MeetingMomModel = require('../../models/meetingMom/MeetingMomModel');
// const TenderDetailsRequest = require('../../models/tender/TenderDetailsRequestModel');
const Users = require('../../models/Users')
// const TenderDetailsRequest = require("../../models/tender/TenderDetailsRequestModel")
const { sendMailForMeeting } = require('../../config/mail')
const path = require('path')
const currentDate = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Month is zero-based
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const meetingcreate = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        meeting_type: Joi.number().required(),
        meeting_date: Joi.date().required(),
        start_time: Joi.required(),
        // end_time: Joi.string().allow(null),
        // meeting_link: Joi.string().uri().allow(null),
        // meeting_address: Joi.string().allow(null),
        meeting_discerption: Joi.string().required(),
        meeting_host: Joi.number().required(),
        reminder_before_val: Joi.required(),
        reminder_before_type: Joi.required(),
        send_invitation: Joi.string().required(),
        // send_invitation_other: Joi.string().allow(null),
    });
    const dataToValidate = {
        project_id: req.body.project_id,
        meeting_type: req.body.meeting_type,
        meeting_date: req.body.meeting_date,
        start_time: req.body.start_time,
        // end_time: req.body.end_time,
        // meeting_link: req.body.meeting_link,
        // meeting_address: req.body.meeting_address,
        meeting_discerption: req.body.meeting_discerption,
        meeting_host: req.body.meeting_host,
        reminder_before_val: req.body.reminder_before_val,
        reminder_before_type: req.body.reminder_before_type,
        send_invitation: req.body.send_invitation,
        // send_invitation_other: req.body.send_invitation_other,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const insert_val = await MainmeetingModel.create({
                user_comp_id: req.comp_id,
                project_id: req.body.project_id,
                meeting_type: req.body.meeting_type,
                meeting_date: req.body.meeting_date,
                start_time: req.body.start_time,
                end_time: (req.body.end_time) ? req.body.end_time : null,
                meeting_link: req.body.meeting_link,
                meeting_title: req.body.meeting_title,
                meeting_address: req.body.meeting_address,
                meeting_discerption: req.body.meeting_discerption,
                meeting_host: req.body.meeting_host,
                reminder_before_val: req.body.reminder_before_val,
                reminder_before_type: req.body.reminder_before_type,
                created_at: getCurrentDateTime(),
                created_by: req.userId,
            }
            );
            if (insert_val) {
                const send_invitation = req.body.send_invitation.split(',');
                const invitation_other = req.body.send_invitation_other.split(',');
                let invitation;
                if (send_invitation.length > invitation_other.length) {
                    invitation = send_invitation;
                } else if (send_invitation.length < invitation_other.length) {
                    invitation = invitation_other;
                } else {
                    invitation = send_invitation;
                }
                const combinedArrays = invitation.map((data, index) => ({
                    send_invitation: send_invitation[index] || '',
                    send_invitation_other: invitation_other[index] || '',
                }));
                const response_send_invitation = await Promise.all(combinedArrays.map(async (data) => {

                    const user_email = await Users.findOne({ where: { id: data.send_invitation, comp_id: req.comp_id, isactive: '1' }, attributes: ['email'] })
                    const response_send_insert = await MeetingInvitationModel.create({
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        meeting_id: insert_val.id,
                        send_invitation: data.send_invitation,
                        send_invitation_other: data.send_invitation_other,
                        created_at: getCurrentDateTime(),
                        created_by: req.userId,
                    });
                    // const templatePath = path.join(__dirname, '../../emailtemplates/Meetingtemplates.hbs');
                    // const response = sendMailForMeeting(
                    //     'sabhimanyu336@gmail.com',
                    //     // 'Dynamic Subject',
                    //     insert_val,
                    //     templatePath,
                    //     // '<p>Dynamic HTML body of the email</p>',
                    // );
                }));
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data:insert_val
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }

    }
}

const meetingelist = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),

    });
    const dataToValidate = {
        project_id: req.body.project_id,

    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const response = await MainmeetingModel.findAll({
                order: [['meeting_date', 'DESC']],
                where: {
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                    status: '1'
                },

                include: [{
                    model: MeetingInvitationModel,
                    attributes: ['id', 'send_invitation', 'send_invitation_other'],
                    where: {
                        status: '1', user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                    },
                    required: false,

                    include: [{
                        model: Users,
                        attributes: ['id', 'userfullname'],
                        required: false,
                    },
                    ],
                },
                {
                    model: Users,
                    attributes: ['id', 'userfullname'],
                    as: 'hostname',
                    required: false,
                },
                {
                    model: MeetingMomModel,
                    where: { status: '1' },
                    required: false,
                },

                ]

            }
            );

            //upddated response message
            if (response[0]) {
              return  res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response
                });
            } else {
              return  res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }

    }
}

const meetingEdit = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        meeting_id: Joi.number().required(),

    });
    const dataToValidate = {
        project_id: req.body.project_id,
        meeting_id: req.body.meeting_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const response = await MainmeetingModel.findOne({
                where: {
                    id: req.body.meeting_id,
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                    status: '1'
                },

                include: [{
                    model: MeetingInvitationModel,
                    attributes: ['id', 'send_invitation', 'send_invitation_other'],
                    where: {
                        status: '1', user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                    },
                    required: false,
                },
                ]

            }
            );
            if (response) {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: response
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }

    }
}

const meetingdelete = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        meeting_id: Joi.number().required(),

    });
    const dataToValidate = {
        project_id: req.body.project_id,
        meeting_id: req.body.meeting_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const upd_status = {
                status: '0',
                updated_at: getCurrentDateTime(),
                updated_by: req.userId
            }
            const response = await MainmeetingModel.findOne({
                where: {
                    id: req.body.meeting_id,
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                    created_by: req.userId,
                    status: '1'
                },
            }
            );
            if (response) {
                const response = await MainmeetingModel.update(upd_status, {
                    where: {
                        id: req.body.meeting_id,
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        status: '1'
                    },
                }
                );
                const response_1 = await MeetingInvitationModel.update(upd_status, {
                    where: {
                        meeting_id: req.body.meeting_id,
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        status: '1'
                    },
                }
                );
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',

                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });


            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }

    }
}

const meetingUpdate = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        meeting_id: Joi.number().required(),
        meeting_date: Joi.date().required(),
        start_time: Joi.required(),
        end_time: Joi.required(),
        meeting_discerption: Joi.string().required(),
        meeting_host: Joi.number().required(),
        reminder_before_val: Joi.required(),
        reminder_before_type: Joi.required(),
        send_invitation: Joi.string().required(),

    });
    const dataToValidate = {
        project_id: req.body.project_id,
        meeting_id: req.body.meeting_id,
        meeting_date: req.body.meeting_date,
        start_time: req.body.start_time,
        end_time: req.body.end_time,
        meeting_discerption: req.body.meeting_discerption,
        meeting_host: req.body.meeting_host,
        reminder_before_val: req.body.reminder_before_val,
        reminder_before_type: req.body.reminder_before_type,
        send_invitation: req.body.send_invitation,

    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const response = await MainmeetingModel.findOne({
                where: {
                    id: req.body.meeting_id,
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id,
                    status: '1'
                },

                include: [{
                    model: MeetingInvitationModel,
                    attributes: ['id', 'send_invitation', 'send_invitation_other'],
                    where: {
                        status: '1', user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                    },
                    required: false,
                },
                ]

            }
            );
            if (response) {
                const update_val = await MainmeetingModel.update({
                    meeting_type: req.body.meeting_type,
                    meeting_date: req.body.meeting_date,
                    start_time: req.body.start_time,
                    end_time: req.body.end_time,
                    meeting_link: req.body.meeting_link,
                    meeting_title: req.body.meeting_title,
                    meeting_address: req.body.meeting_address,
                    meeting_discerption: req.body.meeting_discerption,
                    meeting_host: req.body.meeting_host,
                    reminder_before_val: req.body.reminder_before_val,
                    reminder_before_type: req.body.reminder_before_type,
                    updated_at: getCurrentDateTime(),
                    updated_by: req.userId,
                }, {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        id: req.body.meeting_id,
                    }
                }
                );
                const send_invitation = req.body.send_invitation.split(',');
                const invitation_other = req.body.send_invitation_other.split(',');
                let invitation;
                if (send_invitation.length > invitation_other.length) {
                    invitation = send_invitation;
                } else if (send_invitation.length < invitation_other.length) {
                    invitation = invitation_other;
                } else {
                    invitation = send_invitation;
                }
                const combinedArrays = invitation.map((data, index) => ({
                    send_invitation: send_invitation[index] || '',
                    send_invitation_other: invitation_other[index] || '',
                }));
                const upd_obj = {
                    status: '0',
                    updated_at: getCurrentDateTime(),
                    updated_by: req.userId,

                }
                const response = await MeetingInvitationModel.update(upd_obj, {
                    where: {
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        meeting_id: req.body.meeting_id,
                    }
                });
                const response_send_invitation = await Promise.all(combinedArrays.map(async (data) => {
                    const user_email = await Users.findOne({ where: { id: data.send_invitation, comp_id: req.comp_id, isactive: '1' }, attributes: ['email'] })
                    const response_send_insert = await MeetingInvitationModel.create({
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id,
                        meeting_id: req.body.meeting_id,
                        send_invitation: data.send_invitation,
                        send_invitation_other: data.send_invitation_other,
                        created_at: getCurrentDateTime(),
                        created_by: req.userId,
                    });
                    // const templatePath = path.join(__dirname, '../../emailtemplates/Meetingtemplates.hbs');
                    // const response = sendMailForMeeting(
                    //     'sabhimanyu336@gmail.com',
                    //     // 'Dynamic Subject',
                    //     insert_val,
                    //     templatePath,
                    //     // '<p>Dynamic HTML body of the email</p>',
                    // );
                }));
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',

                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }

    }
}

const meetingelist_tender = async (req, res) => {
    try {
        const response = await MainmeetingModel.findAll({
            where: {
                user_comp_id: req.comp_id,
                status: '1'
            },
            attributes: ['id', 'project_id', [Sequelize.fn('count', Sequelize.col('id')), 'count_meeting']],
            group: ['project_id', 'user_comp_id'],
        }
        );
        if (response[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: response
            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: error.message,
            // message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        })
    }
}


const meeting_delete_docs = async (req, res) => {

    const schema = Joi.object().keys({
        request_id: Joi.number().required(),


    });
    const dataToValidate = {
        request_id: req.body.request_id,

    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {

        const upd_status = {
            file_name: null,
            file_path: null,
            updated_at: getCurrentDateTime(),
            updated_by: req.userId
        }
        try {
            const response_1 = await TenderDetailsRequest.findOne({
                where: {
                    user_comp_id: req.comp_id,
                    id: req.body.request_id,
                    created_by: req.userId,
                    file_name: {
                        [Op.ne]: null
                    },
                    status: '1'
                },

            }
            );
            if (!response_1) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            } else {
                const response = await TenderDetailsRequest.update(upd_status, {
                    where: {
                        user_comp_id: req.comp_id,
                        id: req.body.request_id,
                        status: '1'
                    },

                }
                );
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            })
        }
    }
}
// const meeting_delete_docs = async (req, res) => {

//     const schema = Joi.object().keys({
//         request_id: Joi.number().required(),

//     });
//     const dataToValidate = {
//         request_id: req.body.request_id,

//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     } else {
//         try {
//             const response = await TenderDetailsRequest.findOne({
//                 where: {
//                     user_comp_id: req.comp_id,
//                     id: req.body.request_id,
//                     created_by: req.userId,
//                     status: '1',
//                     file_name: {
//                         [Op.ne]: null
//                     },

//                 },
//                 attributes: ['id'],
//             }
//             );
//             if (response) {
//                 const upd_status = {
//                     file_path: null,
//                     file_name: null,
//                     updated_at: getCurrentDateTime(),
//                     updated_by: req.userId
//                 }
//                 const response = await TenderDetailsRequest.update(upd_status, {
//                     where: {
//                         id: req.body.request_id,
//                         user_comp_id: req.comp_id,
//                         status: '1'
//                     },
//                 }
//                 );
//                 res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                     message: process.env.APIRESPMSG_RECDELETED,
//                     error: false,
//                     success: true,
//                     status: '1',
//                 });
//             } else {
//                 res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0',
//                 });
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: error.message,
//                 // message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             })
//         }


//     }
// }

module.exports = {
    meetingcreate, meetingelist, meetingEdit, meeting_delete_docs,
    meetingdelete, meetingUpdate, meetingelist_tender
}
