require('dotenv').config();
const Joi = require('joi');
const { Op } = require('sequelize');
const path = require('path')
const multer = require('multer');
const fs = require('fs');
const getCurrentDateTime = () => new Date();
const ProjectFolderModel = require('../../models/project_doctrol/ProjectFolderModel');
const ProjectFilesModel  = require('../../models/project_doctrol/ProjectFilesModel');

const addProjectFolder = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.string().required(),
       // parent_id: Joi.string().required(),
        folder_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        parent_id: Joi.string().allow(null),

    });

    const dataToValidate = {
        project_id: req.body.project_id,
        parent_id: req.body.parent_id,
        folder_name: req.body.folder_name,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
        parent_id: req.body.parent_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const ext_project_folder = await ProjectFolderModel.findOne({ where: { user_comp_id: req.comp_id, folder_name: req.body.folder_name, status: '1', project_id: req.body.project_id }, attributes: ['id',] })
            if (!ext_project_folder) {
                const insert = await ProjectFolderModel.create(dataToValidate);
                if (insert) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                message: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
const listProjectFolder = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required()
    });
    const dataToValidate = {
        project_id: req.body.project_id
    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message

        });
    } else {

        try {
            const data = await ProjectFolderModel.findAll({
                where: {
                    status: "1",
                    user_comp_id: req.comp_id,
                    project_id: req.body.project_id
                },
                attributes: ['id', 'parent_id', 'folder_name', 'created_at', 'status']
            });
            if (!data[0]) {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: data,
                });
            }
        }
        catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                // message: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


const editProjectFolder = async (req, res) => {
    const schema = Joi.object().keys({
        folder_id: Joi.number().required(),
        project_id: Joi.number().required()
    });

    const dataToValidate = {
        folder_id: req.body.folder_id,
        project_id: req.body.project_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const editfolder = await ProjectFolderModel.findOne({
                where: { id: req.body.folder_id, user_comp_id: req.comp_id ,project_id: req.body.project_id}, attributes: ['id', 'folder_name', 'parent_id', 'project_id'],
            })
            if (!editfolder) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: editfolder,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


const updateProjectFolder = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        folder_id: Joi.number().required(),
        folder_name: Joi.string().required(),
        updated_at: Joi.date().iso().allow(),
        modified_by: Joi.number().required(),
    });

    const dataToValidate = {
        folder_id: req.body.folder_id,
        project_id: req.body.project_id,
        folder_name: req.body.folder_name,
        updated_at: getCurrentDateTime(),
        modified_by: req.userId,
    };

    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existingProjectFolder = await ProjectFolderModel.findOne({
                where: {
                    folder_name: req.body.folder_name,
                    user_comp_id: req.comp_id,
                    status: '1',
                    project_id: req.body.project_id
                }
            });

            if (existingProjectFolder && existingProjectFolder.id !== req.body.folder_id) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    status: '0',
                    success: false,
                });
            }

            const updateFolder = await ProjectFolderModel.findOne({
                where: {
                    id: req.body.folder_id,
                    user_comp_id: req.comp_id,
                    status: '1',
                    project_id: req.body.project_id
                },
                attributes: ['id', 'folder_name']
            });

            if (!updateFolder) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    status: '0',
                    success: false,
                });
            } else {
                const updateCat = {
                    folder_name: req.body.folder_name,
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                };

                await ProjectFolderModel.update(updateCat, {
                    where: {
                        id: req.body.folder_id,
                        user_comp_id: req.comp_id,
                        project_id: req.body.project_id
                    },
                });

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    status: '1',
                    success: true,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
             // message: error.message,
                error: true,
                status: '0',
                success: false,
            });
        }
    }
}



// const deleteProjectFolder = async (req, res) => {
//     const schema = Joi.object().keys({
//         folder_id: Joi.number().required(),
//         project_id: Joi.number().required(),
//         modified_by: Joi.number().required(),
//         updated_at: Joi.date().iso().required(),
//     });

//     const dataToValidate = {
//         project_id: req.body.project_id,
//         folder_id: req.body.folder_id,
//         modified_by: req.userId,
//         updated_at: getCurrentDateTime(),
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     } else {
//         try {
//             const deletefolder = await ProjectFolderModel.findOne({ where: { id: req.body.folder_id, status: '1', user_comp_id: req.comp_id, is_deleteable: '2', project_id: req.body.project_id} })
//             if (deletefolder) {
//                 const bg_fldr_update_obj = {
//                     status: '0',
//                     is_deleteable: '1',
//                     modified_by: req.userId,
//                     updated_at: getCurrentDateTime(),
//                 }
//                 const bg_fldr_update = await ProjectFolderModel.update(bg_fldr_update_obj, {
//                     where: {
//                         id: req.body.folder_id,
//                         user_comp_id: req.comp_id,
//                         status: '1',
//                         is_deleteable: '2'
//                     },
//                 });
//                 if (bg_fldr_update) {
//                     return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                         message: process.env.APIRESPMSG_RECDELETED,
//                         error: false,
//                         success: true,
//                         status: '1',
//                     });
//                 }
//             }
//             else {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }


const deleteProjectFolder = async (req, res) => {
    const schema = Joi.object().keys({
        folder_id: Joi.number().required(),
        project_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        folder_id: req.body.folder_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    }

    try {
        const deleteFolder = await ProjectFolderModel.findOne({ 
            where: { 
                id: req.body.folder_id, 
                status: '1', 
                user_comp_id: req.comp_id, 
                is_deleteable: '2', 
                project_id: req.body.project_id 
            } 
        });

        if (!deleteFolder) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        if (deleteFolder.created_by !== req.userId) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: "You are not authorized to delete or rename this folder.",
                error: true,
                success: false,
                status: '0'
            });
        }
        const folderUpdate = await ProjectFolderModel.update({
            status: '0',
            is_deleteable: '1',
            modified_by: req.userId,
            updated_at: getCurrentDateTime(),
        }, {
            where: {
                id: req.body.folder_id,
                user_comp_id: req.comp_id,
                status: '1',
                is_deleteable: '2'
            },
        });
        if (folderUpdate[0] === 1) {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECDELETED,
                error: false,
                success: true,
                status: '1',
            });
        } else {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: "Failed to delete or rename the folder.",
                error: true,
                success: false,
                status: '0'
            });
        }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'projectdoctrol/';
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + 'doctrol_' + Math.random() + extension);
    },
});

const doc_upload = multer({ storage: storage });



const addProjectDoctrolFile = async (req, res) => {
    doc_upload.array('document_file_name')(req, res, async function (err) {
        if (err) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: "Error in file upload",
                error: true,
                success: false,
                status: '0',
            });
        }
        
        const schema = Joi.object().keys({
            folder_id: Joi.number().required(),
            document_title: Joi.string().required(),
            user_comp_id: Joi.number().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required(),
        });

        const dataToValidate = {
            folder_id: req.body.folder_id,
            document_title: req.body.document_title,
            user_comp_id: req.comp_id,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };

        const result = schema.validate(dataToValidate);
        if (result.error) {
            return res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        }

        try {
            const files = req.files;
            if (!files || files.length === 0) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.FILE_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            const existingRecords = await ProjectFilesModel.findAll({
                where: {
                    folder_id: req.body.folder_id,
                    document_title: req.body.document_title,
                    user_comp_id: req.comp_id,
                    created_by: req.userId
                }
            });

            if (existingRecords.length > 0) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            const originalFolderPath = files[0].destination;
            const fileRecords = await ProjectFilesModel.bulkCreate(files.map((file) => ({
                created_by: req.userId,
                user_comp_id: req.comp_id,
                folder_id: req.body.folder_id,
                document_title: req.body.document_title,
                document_file_name: file.filename,
                created_at: getCurrentDateTime(),
                document_file_path: originalFolderPath,
                exten: path.extname(file.filename),
            })));

            if (fileRecords.length > 0) {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: `${fileRecords.length} records inserted successfully`,
                    error: false,
                    success: true,
                    status: '1',
                    data: fileRecords
                });
            }
            
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '1',
            });
        } catch (error) {
            return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '1',
            });
        }
    });
}

const project_doctrol_listFolder = async (req, res) => {
    try {
        const folders = await ProjectFolderModel.findAll({
            where: {
                status: '1',
                user_comp_id: req.comp_id,
            },
            include: [{
                model: ProjectFilesModel,
                attributes: ['document_title', 'document_file_name', 'document_file_path', 'exten'],
                where: { status: '1' },
                required: false,
            }],
            order: [['folder_name', 'ASC']]
        });

        if (!folders || folders.length === 0) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: folders, 
            });
        }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            // message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const project_doctrol_files_list = async (req, res) => {
    try {
        const folders = await ProjectFilesModel.findAll({
            attributes: ['id', ['folder_id','parent_id'],'document_title','document_file_name','document_file_path',['exten','folder_name'],'created_at','created_by'],
            where: {
                status: '1',
                user_comp_id: req.comp_id
            },
            
        });
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: folders, 
            });
        // }
    } catch (error) {
        return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            // message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const project_doctrol_files_delete = async (req, res) => {
    const schema = Joi.object().keys({
        file_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        file_id: req.body.file_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const deletefolder = await ProjectFilesModel.findOne({ where: { id: req.body.file_id, status: '1', user_comp_id: req.comp_id } })
            if (deletefolder) {
                const fldr_update_obj = {
                    status: '0',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                const fldr_update = await ProjectFilesModel.update(fldr_update_obj, {
                    where: {
                        id: req.body.file_id,
                        user_comp_id: req.comp_id,
                        status: '1',

                    },
                });
                if (fldr_update) {
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECDELETED,
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            }
            else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: process.env.ERROR_MSG,
                error: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
} 

module.exports = {
    addProjectFolder, listProjectFolder,editProjectFolder,updateProjectFolder,deleteProjectFolder,addProjectDoctrolFile,project_doctrol_listFolder,project_doctrol_files_list,project_doctrol_files_delete
}