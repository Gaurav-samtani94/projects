const Notification = require('../models/Notification_history_model');
const Users = require('../models/Users');
const getCurrentDateTime = () => new Date();
const Joi = require('joi');
const TodoComment = require('../models/todo/TodoCommentModel');
const ProjectTodo = require('../models/todo/Projecttodo');
const TenderCommentModel = require('../models/tender/TenderCommentModel');
const ProjectTodoCommentModel = require('../models/todo/ProjectTodoCommentModel');
const Todolist = require('../models/todo/Todolist');

const updateNotifyStatus = async (req, res) => {
    try {
        const notification = await Notification.findOne({ 
            where: { ping_users_info:req.userId, user_comp_id: req.comp_id, status: '1' },
            attributes: ['id'] 
        })

        if (notification) {
            const updateObj = {
                is_viewed: '1',
                modified_by: req.userId,
                updated_at: getCurrentDateTime(),
            }

            const view =  await Notification.update(updateObj, {
                where: { ping_users_info:req.userId, status: "1" },
            });

            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Notification Viewed successfully',
                error: false,
                success: true,
                status: '1',
            });

        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: "Record Not Found",
                error: true,
                success: false,
                status: '0',
            });
        }

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

    }
}

const updateClickedStatus = async (req, res) => {
    const schema = Joi.object().keys({
        notification_id: Joi.number().required(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        notification_id: req.body.notification_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const notification = await Notification.findOne({ where: { user_comp_id: req.comp_id, id: req.body.notification_id, status: '1', is_viewed: '1' }, attributes: ['id'] })
            if (notification) {
                const updateObj = {
                    is_clicked: '1',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }


               const view =  await Notification.update(updateObj, {
                    where: { id: notification.id },
                });

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Notification Clicked successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}



const notification_list = async (req, res) => {
    try {
        const notification = await Notification.findAll({ 
            order: [['created_at', 'DESC']],
            where: { user_comp_id: req.comp_id, ping_users_info:req.userId, status: '1' },

        })
        if (notification) {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Notification List',
                error: false,
                success: true,
                status: '1',
                data:notification
            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: "Record Not Found",
                error: true,
                success: false,
                status: '0',
            });

        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

    }
}


const update_user_notify = async (req, res) => {
    const schema = Joi.object().keys({
        user_id: Joi.number().required(),
    });
    const dataToValidate = {
        user_id: req.body.user_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
    
        try {

            const users = await Users.findOne({
                where: { id:req.body.user_id, isactive: '1' },
                attributes: ['id'] 
            })

            if (users) {
                const updateObj = {
                    is_user_notified: '0',
                    modified_by: req.userId,
                    updated_at: getCurrentDateTime(),
                }
                
                const updUserdata =  await Users.update(updateObj, {
                    where: { id:req.body.user_id, isactive: "1" },
                });
                
                if(updUserdata){
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'User Data Updated successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
                

            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message1: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

const notification_listTaggedToUsers = async (req, res) => {
    try {
        const notification = await Notification.findAll({ 
            order: [['created_at', 'DESC']],
            where: { user_comp_id: req.comp_id, created_by:req.userId, status: '1' },

        })
        if (notification) {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Notification List',
                error: false,
                success: true,
                status: '1',
                data:notification
            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: "Record Not Found",
                error: true,
                success: false,
                status: '0',
            });

        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

    }
}


const notification_listMentioned = async (req, res) => {
    try {
        const todoComments = await TodoComment.findAll({ 
            order: [['created_at', 'DESC']],
            where: { user_comp_id: req.comp_id, ping_users_info:req.userId, status: '1', parent_id:0 },
            include : [
                {
                    model:Todolist,
                    where:{status:'1',},
                    attributes:['ID','task_name'],
                    as:"comment_task_name"
                }
            ]

        })
        
        const tenderComments = await TenderCommentModel.findAll({ 
            order: [['created_at', 'DESC']],
            where: { user_comp_id: req.comp_id, ping_users_info:req.userId, status: '1', parent_id:0 },

        })

        const tenderTodoComments = await ProjectTodoCommentModel.findAll({ 
            order: [['created_at', 'DESC']],
            where: { user_comp_id: req.comp_id, ping_users_info:req.userId, status: '1', parent_id:0 },

        })

        const mergedCommentObj = {
            todo_comments : todoComments,
            tender_comments : tenderComments,
            tender_todo_comments : tenderTodoComments
        }

        if (mergedCommentObj) {
            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'All Comments Data',
                error: false,
                success: true,
                status: '1',
                data:mergedCommentObj
            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: "Record Not Found",
                error: true,
                success: false,
                status: '0',
            });

        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

    }
}


module.exports = {
    updateNotifyStatus, notification_list, updateClickedStatus, update_user_notify, notification_listTaggedToUsers,notification_listMentioned
}; 