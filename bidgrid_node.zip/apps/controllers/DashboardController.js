const Joi = require('joi');
require('dotenv').config();
const { Sequelize, DataTypes, where, Op, fn, col, literal } = require('sequelize');
const TenderScopeModel = require('../models/master/TenderScope');
const createTenderModel = require('../../apps/models/tender/TenderModel');
const Country = require('../models/master/Country');
const State = require('../models/master/State');
const City = require('../models/master/City');
const Client = require('../models/master/TenderClient');
const Sector = require('../models/master/TenderSector');
const TenderGeneratedTypeIdModel = require('../models/tender/TenderGeneratedTypeIdModel');
const TenderGeneratedTypeModel = require('../models/tender/TenderGeneratedTypeModel');
const Users = require('../models/Users');
const TenderBdRoleModel = require('../models/master/TenderBdRoleModel');
const Designation = require('../models/master/Designation');
const TenderAssignManagerModel = require('../models/tender/TenderAssignManagerModel');
const getCurrentDateTime = () => new Date();
const DepartmentModel = require('../models/master/DepartmentModel');
const WidgetPerm = require('../models/roleandpermission/WidgetPerm')
const WidgetModel = require('../models/master/WidgetModel')
const Widgets = require("../models/roleandpermission/Widgets");
const MainmeetingModel = require('../models/meeting/MainmeetingModel');
const TenderGenTypeIdModel = require('../models/tender/TenderGeneratedTypeIdModel');
const TenderDetailsRequest = require('../models/tender/TenderDetailsRequestModel');
const ProjectTodo = require('../models/todo/Projecttodo');
const Todolist = require('../models/todo/Todolist');
const TenderGenTypeModel = require('../models/tender/TenderGeneratedTypeModel');

const Tenderscope = require('../models/master/TenderScope');

const TenderStatusManage = require('../models/tender/TenderStatusManage');
const TenderStatus = require('../models/master/TenderStatus');
const AssignedtaskModel = require('../models/todo/Assignedtask');
const MeetingInvitationModel = require('../models/meeting/MeetingInvitationModel');
const ProjectAssigntaskModel = require('../models/todo/ProjectAssignedtask');
const Assignedtask = require('../models/todo/Assignedtask');
const ProjectTodoCommentModel = require('../models/todo/ProjectTodoCommentModel');
const getOnGoingData = async (req, res) => {
  const schema = Joi.object().keys({
    scope_id: Joi.number().required(),

  });
  const dataToValidate = {
    scope_id: req.body.scope_id,
  }
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: '0'
    });
  } else {
    try {
      const TenderModel = createTenderModel(req.comp_id);
      await TenderModel.performOperation();
      // const onGoingData = await TenderScopeModel.findAndCountAll({
      //     order: [['id', 'DESC']],
      //     where: { user_comp_id: req.comp_id, id: req.body.scope_id, status: '1' },
      //     attributes: ['id'],
      //     include: [
      //         {
      const onGoingData = await TenderModel.findAndCountAll({
        attributes: [['id', 'project_id'], 'tender_name', 'tender_emd_amnt_val', ['submission_end_date', 'expiry_date'],],
        order: [['id', 'DESC']],
        where: { status: '1', user_comp_id: req.comp_id, cycle_id: req.body.scope_id },
        include: [
          {
            model: Country,
            attributes: ['country_name'],
            where: { status: '1' },
            required: false,
          }, {
            model: State,
            attributes: ['State_name'],
            where: { status: '1' },
            required: false,
          }, {
            model: City,
            attributes: ['City_name'],
            where: { status: '1' },
            required: false,
          }, {
            model: Client,
            attributes: ['client_name'],
            where: { status: '1', user_comp_id: req.comp_id },
            required: false,
          },
          {
            model: TenderGeneratedTypeIdModel,
            attributes: ['id', 'generated_tender_id', 'tender_id', 'generate_type_id'],
            where: { status: '1', user_comp_id: req.comp_id },
            required: false,
          },
        ]
        //         }
        //     ],
      })

      if (!onGoingData) {
        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
          message: 'Record Not Found',
          error: true,
          success: false,
          status: '0',
        });
      }
      res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
        message: 'Record Found',
        error: false,
        success: true,
        status: '1',
        data: onGoingData,

      });
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: error.message,
        // message: process.env.ERROR_MSG,
        error: true,
        success: false,
        status: '0',
      });

    }
  }
}


const personalCalender = async (req, res) => {

  const schema = Joi.object().keys({
    tenderMonth: Joi.number().required(),

  });
  const dataToValidate = {
    tenderMonth: (req.body.tenderMonth) ? req.body.tenderMonth : getCurrentDateTime().getMonth() + 1,
  }
  const tenderExpMonth = (req.body.tenderMonth) ? req.body.tenderMonth : getCurrentDateTime().getMonth() + 1;
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: '0'
    });
  } else {
    try {

      const year = getCurrentDateTime().getFullYear();
      const month = getCurrentDateTime().getMonth() + 1; // Months are zero-based, so add 1
      const day = getCurrentDateTime().getDate();
      const formattedDate = `${year}-${month}-${day}`;
      const dateFilters = [];
      if (req.body.tenderdateFilter) {
        const date_tender = req.body.tenderdateFilter;
        dateFilters.push(
          {
            [Op.and]: [
              literal(`DATE_FORMAT(submission_end_date, '%Y-%m') = '${date_tender}'`),
            ],
          }
        )
      } else {
        dateFilters.push(
          {
            [Op.and]: [
              literal(`DATE_FORMAT(submission_end_date, '%Y-%m') = '${year}-${month}'`),
            ],
          }
        )
      }

      const personalCalData = await TenderModel.findAll({
        where: {
          [Op.and]: [
            { status: '1' }, // Additional filters can be added here
            ...dateFilters, // Include the dynamic date range condition
          ],
        },
        // limit: 10,
        group: [literal(`DATE_FORMAT(submission_end_date, '%Y-%m-%d')`)],
        order: [[col('submission_end_date'), 'DESC']],
        attributes: [[literal(`DATE_FORMAT(submission_end_date, '%Y-%m-%d')`), 'submission_end_date'],],
      });
      const tenderkeyy = {};
      if (personalCalData) {
        await Promise.all(personalCalData.map(async (data) => {
          const datadate = data.submission_end_date;
          const additionalData = await TenderModel.findAndCountAll({
            where: {
              [Op.and]: [
                literal(`DATE_FORMAT(submission_end_date, '%Y-%m-%d') = '${datadate}'`),
              ],
            }, attributes: [[literal(`DATE_FORMAT(submission_end_date, '%Y-%m-%d')`), 'submission_end_date'], 'gg_tenderID', 'tender_name', 'tender_emd_amnt_val'],
            include: [
              {
                model: Country,
                attributes: ['country_name'],
                where: { status: '1' },
                required: false,
              }, {
                model: State,
                attributes: ['State_name'],
                where: { status: '1' },
                required: false,
              }, {
                model: City,
                attributes: ['City_name'],
                where: { status: '1' },
                required: false,
              }, {
                model: Client,
                attributes: ['client_name'],
                where: { status: '1', user_comp_id: req.comp_id },
                required: false,
              },
              {
                model: TenderGeneratedTypeIdModel,
                attributes: ['id', 'generated_tender_id', 'tender_id'],
                as: 'tender_ger_id',
                where: { status: '1', user_comp_id: req.comp_id },
                required: false,
              },
            ]
          });
          if (!tenderkeyy[datadate]) {
            tenderkeyy[datadate] = [];
          }
          if (additionalData.rows.length > 0) {
            tenderkeyy[datadate].push(
              additionalData
            )
          }
        }))

      }


      if (!tenderkeyy) {
        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
          message: 'Record Not Found',
          error: true,
          success: false,
          status: '0',
        });
      } else {
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: 'Record Found',
          error: false,
          success: true,
          status: '1',
          data: tenderkeyy,

        });
      }

    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: '0',
      });

    }
  }
}


const teamloginhistory = async (req, res) => {
  const schema = Joi.object().keys({
    limit: Joi.string().required(),
    page_number: Joi.string().required(),

  });
  const dataToValidate = {
    limit: req.body.limit,
    page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
  }
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: '0'
    });
  } else {
    try {
      const page_number = parseInt(dataToValidate.page_number) || 1;
      const limit = parseInt(dataToValidate.limit) || 10;
      const offset = (parseInt(page_number) - 1) * parseInt(limit);
      const response = await Users.findAll({
        where: { reporting_mngr_id: req.userId, isactive: '1' },
        attributes: ['id', 'userfullname', 'last_login', 'profileimg'],
        offset,
        limit,
        include: [
          {
            model: DepartmentModel,
            attributes: ['id', 'department_name'],
            where: { user_comp_id: req.comp_id, status: '1' },
            required: false,
          },
          {
            model: Designation,
            attributes: ['id', 'designation_name'],
            where: { user_comp_id: req.comp_id, status: '1' },
            required: false,
          },
          {
            model: Useractivehistory,
            as: 'userhistories',
            attributes: ['id', 'activity', 'created_at', 'created_by'],
            where: { user_comp_id: req.comp_id, status: '1' },
            required: false,
            include: [
              {
                model: Users,
                attributes: ['id', 'userfullname'],
                where: { isactive: '1' },
                required: false,
                include: [
                  {
                    model: DepartmentModel,
                    attributes: ['id', 'department_name'],
                    where: { user_comp_id: req.comp_id, status: '1' },
                    required: false,

                  }
                ]

              },]
          },
        ],
      })

      if (!response[0]) {
        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
          message: 'Record Not Found',
          error: true,
          success: false,
          status: '0',
        });
      }
      res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
        message: 'Record Found',
        error: false,
        success: true,
        status: '1',
        data: response,

      });
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: '0',
      });

    }
  }
}

const teamtasklist = async (req, res) => {
  // const schema = Joi.object().keys({
  //     limit: Joi.string().required(),
  //     page_number: Joi.string().required(),

  // });
  // const dataToValidate = {
  //     limit: req.body.limit,
  //     page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
  // }
  // const result = schema.validate(dataToValidate);
  // if (result.error) {
  //     res.status(process.env.APIRESPCODE_VALIDATION).send({
  //         message: result.error.details[0].message,
  //         error: true,
  //         success: false,
  //         status: '0'
  //     });
  // } else {
  try {

    const TenderModel = createTenderModel(req.comp_id);
    await TenderModel.performOperation();
    // const page_number = parseInt(dataToValidate.page_number) || 1;
    // const limit = parseInt(dataToValidate.limit) || 10;
    // const offset = (parseInt(page_number) - 1) * parseInt(limit);

    const records = await WidgetPerm.findOne(
      {
        where: { role_id: req.emp_role_id, widget_id: '4', status: '1', user_comp_id: req.comp_id },
        include: [{
          model: Widgets,
          attributes: ['widget_name', 'column_span'],
          where: { status: '1' },
          required: false,
        }]

      },
    )
    if (records) {
      const TeamtaskData = await TenderAssignManagerModel.findAll(
        {
          where: { status: '1', user_comp_id: req.comp_id },
          attributes: ['id', 'assign_to', 'tender_id', [Sequelize.fn('COUNT', 'id'), 'num_tender_assign']],
          group: ['assign_to'],
          include: [{
            model: Users,
            attributes: ['userfullname'],
            where: {
              isactive: '1',
              permanent_sys_adm: {
                [Op.ne]: '1',
              }


            },
            // required: false,
            include: {
              model: Designation,
              attributes: ['designation_name'],
              where: { user_comp_id: req.comp_id, status: '1' },
              required: false,
            }
          }]
        })
      if (TeamtaskData[0]) {
        const scope_arrss = [];
        const scope_arrs = await Tenderscope.findAll({
          order: [['order_sr', 'ASC']],
          where: {
            user_comp_id: req.comp_id,
            status: '1',
            category: '1',
            order_sr: [7]
          },
          attributes: ['id'],
          raw: true
        });
        const scope_arr = await Promise.all(scope_arrs.map(async (scope_data) => {
          scope_arrss.push(scope_data.id);
        }));

        //console.log(scope_arrss);
        const tasksWithCount = await Promise.all(TeamtaskData.map(async (data) => {
          const tender_check_exist = await TenderModel.findOne({
            where: {
              cycle_id: scope_arrss,
              user_comp_id: req.comp_id,
              id: data.tender_id,
              status: '1'
            },
            attributes: ['id']
          })
          // let userRoleResp = [];
          // if (tender_check_exist) {
          const userRoleResp = await TenderAssignManagerModel.findAll({
            where: { user_comp_id: req.comp_id, assign_to: data.assign_to, status: '1' },
            group: ['bd_role_id'],
            attributes: [[Sequelize.fn('COUNT', 'id'), 'num_tender_role'], 'bd_role_id'],
            include: [{
              model: TenderBdRoleModel,
              attributes: ['id', 'role_name'],
              where: { status: '1' },
              required: false,
            }],
          });
          // }

          return {
            ...data?.toJSON(),
            userRoleResp,
            // taskcommentCount,
            // assign_user_list
          };
        }));
        if (TeamtaskData[0]) {
          res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            column_span: (records.bg_mstr_widget) ? records.bg_mstr_widget.column_span : null,
            heading: (records.bg_mstr_widget) ? records.bg_mstr_widget.widget_name : null,
            data: tasksWithCount,

          });
        } else {
          return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
            message: process.env.APIRESPMSG_RECNOTFOUND,
            error: true,
            success: false,
            status: '0',
          });
        }
      } else {
        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
          message: process.env.APIRESPMSG_RECNOTFOUND,
          error: true,
          success: false,
          status: '0',
        });
      }
    } else {
      return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
        message: process.env.APIRESPMSG_RECNOTFOUND,
        error: true,
        success: false,
        status: '0',
      });

    }
  } catch (error) {
    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
      message: process.env.ERROR_MSG,
      error: error.message,
      success: false,
      status: '0',
    });

  }
}


const teamtasklist_details = async (req, res) => {
  const schema = Joi.object().keys({
    assign_to: Joi.number().required(),

  });
  const dataToValidate = {
    assign_to: req.body.assign_to,
  }
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: '0'
    });
  } else {
    try {
      const TenderModel = createTenderModel(req.comp_id);
      await TenderModel.performOperation();
      const records = await WidgetPerm.findOne({ where: { role_id: req.emp_role_id, widget_id: '4', status: '1', user_comp_id: req.comp_id } })
      if (records) {
        const TeamtaskData = await TenderAssignManagerModel.findAll(
          {
            where: { status: '1', user_comp_id: req.comp_id, assign_to: req.body.assign_to }, attributes: ['bd_role_id', 'assign_to', 'tender_id'],
            include: [{
              model: TenderBdRoleModel,
              attributes: ['id', 'role_name'],
              where: { status: '1' },
              required: false,
            }],
          })
        // res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
        //     message: process.env.APIRESPMSG_RECFOUND,
        //     error: false,
        //     success: true,
        //     status: '1',
        //     heading: 'Team Tasks List',
        //     data: TeamtaskData,

        // });
        if (TeamtaskData[0]) {
          const tesponse_tender = await Promise.all(TeamtaskData.map(async (data) => {
            const tender_Data = await TenderModel.findOne({
              where: { id: data.tender_id, status: '1', user_comp_id: req.comp_id }, attributes: ['tender_name', 'submission_end_date'],
              include: [
                {
                  model: TenderGeneratedTypeIdModel,
                  attributes: ['generated_tender_id', 'generate_type_id', 'tender_id'],
                  where: { user_comp_id: req.comp_id, status: '1' },
                  as: 'tender_ger_id',
                  required: false,
                  include: [{
                    model: TenderGeneratedTypeModel,
                    attributes: ['generated_type_id'],
                    where: { status: '1' },
                    required: false,
                  }],

                },
                {
                  model: Client,
                  attributes: ['Client_name'],
                  where: { user_comp_id: req.comp_id, status: '1' },
                  required: false,
                }
              ]
            })
            return {
              ...data.toJSON(),
              tender_Data,

            };
          }));

          res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            heading: 'Team Tasks List',
            data: tesponse_tender,

          });
        } else {
          return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
            message: process.env.APIRESPMSG_RECNOTFOUND,
            error: true,
            success: false,
            status: '0',
          });
        }
      } else {
        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
          message: process.env.APIRESPMSG_RECNOTFOUND,
          error: true,
          success: false,
          status: '0',
        });

      }
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: '0',
      });

    }
  }
}





const toBesubmittedData = async (req, res) => {
  try {

    const TenderModel = createTenderModel(req.comp_id);
    await TenderModel.performOperation();
    const cycleId = await Tenderscope.findOne({
      where: { status: '1', order_sr: 7, user_comp_id: req.comp_id },
      attributes: ['id']
    })
    const gen_type = await TenderGeneratedTypeModel.findAll({
      where: { user_comp_id: req.comp_id, status: '1' },
      attributes: ['id']
    })


    const getTendersSubmitted = await TenderModel.findAndCountAll({
      attributes: ['id', 'tender_name', 'tender_emd_amnt_val', 'submission_end_date',],
      order: [['id', 'DESC']],
      where: { status: '1', user_comp_id: req.comp_id, cycle_id: cycleId.id },
      include: [
        {
          model: TenderGeneratedTypeIdModel,
          attributes: ['id', 'generate_type_id'],
          where: { status: '1' },
          required: false,
          include: [
            {
              model: TenderGenTypeModel,
              attributes: ['id', 'generated_type'],
              where: { status: '1' },
              required: false,
            },
          ]
        },

      ]
    })


    const EOIArr = [];
    const RFPArr = [];
    const RFQArr = [];
    const responseTenderSubmmit = await Promise.all(getTendersSubmitted.rows.map(async (data) => {

      const EOITenderGenerated = await TenderGeneratedTypeIdModel.findOne({
        where: { tender_id: data.id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[0].id },
        attributes: ['id']
      })

      const RFPTenderGenerated = await TenderGeneratedTypeIdModel.findOne({
        where: { tender_id: data.id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[1].id },
        attributes: ['id']
      })

      const RFQTenderGenerated = await TenderGeneratedTypeIdModel.findOne({
        where: { tender_id: data.id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[2].id },
        attributes: ['id']
      })


      if (EOITenderGenerated) {
        EOIArr.push(EOITenderGenerated);
      }
      if (RFPTenderGenerated) {
        RFPArr.push(RFPTenderGenerated);
      }
      if (RFQTenderGenerated) {
        RFQArr.push(RFQTenderGenerated);
      }

    }));

    const AllResponse = { toBeSubmittedAll: getTendersSubmitted, TenderEOI: EOIArr.length, TenderRFP: RFPArr.length, TenderRFQ: RFQArr.length }

    if (!AllResponse) {
      return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
        message: 'Record Not Found',
        error: true,
        success: false,
        status: '0',
      });
    }
    
    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
      message: 'Record Found',
      error: false,
      success: true,
      status: '1',
      data: AllResponse,

    });

  } catch (error) {
    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
      // message: error.message,
      message: process.env.ERROR_MSG,
      error: true,
      success: false,
      status: '0',
    });

  }

}


const submittedDashData = async (req, res) => {
  try {

    const TenderModel = createTenderModel(req.comp_id);
    await TenderModel.performOperation();
    const cycleId = await Tenderscope.findOne({
      where: { status: '1', order_sr: 8, user_comp_id: req.comp_id },
      attributes: ['id']
    })
    const gen_type = await TenderGeneratedTypeModel.findAll({
      where: { user_comp_id: req.comp_id, status: '1' },
      attributes: ['id']
    })

    const getTendersSubmitted = await TenderModel.findAndCountAll({
      attributes: ['id', 'tender_name', 'tender_emd_amnt_val', 'submission_end_date',],
      order: [['id', 'DESC']],
      where: { status: '1', user_comp_id: req.comp_id, cycle_id: cycleId.id },
      include: [
        {
          model: TenderGeneratedTypeIdModel,
          attributes: ['id', 'generate_type_id'],
          where: { status: '1' },
          required: false,
          include: [
            {
              model: TenderGenTypeModel,
              attributes: ['id', 'generated_type'],
              where: { status: '1' },
              required: false,
            },
          ]
        },

      ]
    })


    const EOIArr = [];
    const RFPArr = [];
    const RFQArr = [];
    const responseTenderSubmmit = await Promise.all(getTendersSubmitted.rows.map(async (data) => {

      const EOITenderGenerated = await TenderGeneratedTypeIdModel.findOne({
        where: { tender_id: data.id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[0].id },
        attributes: ['id']
      })

      const RFPTenderGenerated = await TenderGeneratedTypeIdModel.findOne({
        where: { tender_id: data.id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[1].id },
        attributes: ['id']
      })

      const RFQTenderGenerated = await TenderGeneratedTypeIdModel.findOne({
        where: { tender_id: data.id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[2].id },
        attributes: ['id']
      })


      if (EOITenderGenerated) {
        EOIArr.push(EOITenderGenerated);
      }
      if (RFPTenderGenerated) {
        RFPArr.push(RFPTenderGenerated);
      }
      if (RFQTenderGenerated) {
        RFQArr.push(RFQTenderGenerated);
      }

    }));

    const AllResponse = { toBeSubmittedAll: getTendersSubmitted, TenderEOI: EOIArr.length, TenderRFP: RFPArr.length, TenderRFQ: RFQArr.length }

    if (!AllResponse) {
      return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
        message: 'Record Not Found',
        error: true,
        success: false,
        status: '0',
      });
    }
    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
      message: 'Record Found',
      error: false,
      success: true,
      status: '1',
      data: AllResponse,

    });

  } catch (error) {
    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
      // message: error.message,
      message: process.env.ERROR_MSG,
      error: true,
      success: false,
      status: '0',
    });

  }

}




const AwaitingDashData = async (req, res) => {
  try {
    const TenderModel = createTenderModel(req.comp_id);
    await TenderModel.performOperation();

    const cycleId = await Tenderscope.findOne({
      where: { status: '1', order_sr: 8, user_comp_id: req.comp_id },
      attributes: ['id']
    })
    const gen_type = await TenderGeneratedTypeModel.findAll({
      where: { user_comp_id: req.comp_id, status: '1' },
      attributes: ['id']
    })

    if ((cycleId) && (gen_type[0])) {
      const statusId = await TenderStatus.findOne({
        order: [['id', 'ASC']],
        limit: 1,
        offset: 0,
        where: { status: '1', user_comp_id: req.comp_id },
        attributes: ['id']
      })
      if (statusId) {
        const tenderstatusId = await TenderStatusManage.findAll({
          order: [['id', 'ASC']],
          where: { status: '1', user_comp_id: req.comp_id, tender_status: statusId.id },
          attributes: ['id', 'project_id', 'tender_status']
        })
        const tnderdata = [];
        const EOIArr = [];
        const RFPArr = [];
        const RFQArr = [];
        var totalArr = 0;
        const responseTenderAwait = await Promise.all(tenderstatusId.map(async (data) => {
          const Tndrdata = await TenderModel.findOne({
            where: { id: data.project_id, user_comp_id: req.comp_id, status: '1', cycle_id: cycleId.id },
            attributes: ['id', 'tender_name', 'submission_end_date'],
            include: [
              {
                model: TenderGeneratedTypeIdModel,
                attributes: ['generated_tender_id', 'generate_type_id'],
                where: { status: '1' },
                required: false,
                include: [
                  {
                    model: TenderGenTypeModel,
                    attributes: ['generated_type'],
                    where: { status: '1' },
                    required: false,
                  }
                ]
              },
            ]
          })

          const EOITenderGenerated = await TenderGeneratedTypeIdModel.findOne({
            where: { tender_id: data.project_id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[0].id },
            attributes: ['id']
          })

          const RFPTenderGenerated = await TenderGeneratedTypeIdModel.findOne({
            where: { tender_id: data.project_id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[1].id },
            attributes: ['id']
          })

          const RFQTenderGenerated = await TenderGeneratedTypeIdModel.findOne({
            where: { tender_id: data.project_id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[2].id },
            attributes: ['id']
          })

          if (EOITenderGenerated) {
            EOIArr.push(EOITenderGenerated);
          }
          if (RFPTenderGenerated) {
            RFPArr.push(RFPTenderGenerated);
            //RFPArr.push(data);
          }
          if (RFQTenderGenerated) {
            RFQArr.push(RFQTenderGenerated);
          }

          tnderdata.push(Tndrdata);

        }));
        totalArr = (EOIArr.length + RFPArr.length + RFQArr.length);
        const AllResponse = { count: totalArr, rowdata: tnderdata, TenderEOI: EOIArr.length, TenderRFP: RFPArr.length, TenderRFQ: RFQArr.length }
        if (AllResponse) {
          res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: AllResponse
          });
        }
        else {
          res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
            message: process.env.APIRESPMSG_RECNOTFOUND,
            error: true,
            success: false,
            status: '0',
          });
        }

      }
      else {
        res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
          message: process.env.APIRESPMSG_RECNOTFOUND,
          error: true,
          success: false,
          status: '0',
        });
      }
    }
    else {
      res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
        message: process.env.APIRESPMSG_RECNOTFOUND,
        error: true,
        success: false,
        status: '0',
      });
    }

  } catch (error) {
    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
      //message: error.message,
      message: process.env.ERROR_MSG,
      error: error.message,
      success: false,
      status: '0',
    });

  }

}


const WonDashData = async (req, res) => {
  try {
    const TenderModel = createTenderModel(req.comp_id);
    await TenderModel.performOperation();

    const cycleId = await Tenderscope.findOne({
      where: { status: '1', order_sr: 8, user_comp_id: req.comp_id },
      attributes: ['id']
    })
    const gen_type = await TenderGeneratedTypeModel.findAll({
      where: { user_comp_id: req.comp_id, status: '1' },
      attributes: ['id']
    })
    if ((cycleId) && (gen_type[0])) {
      const statusId = await TenderStatus.findOne({
        order: [['id', 'ASC']],
        limit: 2,
        offset: 1,
        where: { status: '1', user_comp_id: req.comp_id },
        attributes: ['id']
      })
      if (statusId) {
        const tenderstatusId = await TenderStatusManage.findAll({
          order: [['id', 'ASC']],
          where: { status: '1', user_comp_id: req.comp_id, tender_status: statusId.id },
          attributes: ['id', 'project_id', 'tender_status']
        })
        const tnderdata = [];
        const EOIArr = [];
        const RFPArr = [];
        const RFQArr = [];
        var totalArr = 0;
        const responseTenderAwait = await Promise.all(tenderstatusId.map(async (data) => {
          const Tndrdata = await TenderModel.findOne({
            where: { id: data.project_id, user_comp_id: req.comp_id, status: '1', cycle_id: cycleId.id },
            attributes: ['id', 'tender_name', 'submission_end_date'],
            include: [
              {
                model: TenderGeneratedTypeIdModel,
                attributes: ['generated_tender_id', 'generate_type_id'],
                where: { status: '1' },
                required: false,
                include: [
                  {
                    model: TenderGenTypeModel,
                    attributes: ['generated_type'],
                    where: { status: '1' },
                    required: false,
                  }
                ]
              },
            ]
          })

          const EOITenderGenerated = await TenderGeneratedTypeIdModel.findOne({
            where: { tender_id: data.project_id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[0].id },
            attributes: ['id']
          })

          const RFPTenderGenerated = await TenderGeneratedTypeIdModel.findOne({
            where: { tender_id: data.project_id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[1].id },
            attributes: ['id']
          })

          const RFQTenderGenerated = await TenderGeneratedTypeIdModel.findOne({
            where: { tender_id: data.project_id, user_comp_id: req.comp_id, status: '1', generate_type_id: gen_type[2].id },
            attributes: ['id']
          })

          if (EOITenderGenerated) {
            EOIArr.push(EOITenderGenerated);
          }
          if (RFPTenderGenerated) {
            RFPArr.push(RFPTenderGenerated);
            //RFPArr.push(data);
          }
          if (RFQTenderGenerated) {
            RFQArr.push(RFQTenderGenerated);
          }

          tnderdata.push(Tndrdata);

        }));
        totalArr = (EOIArr.length + RFPArr.length + RFQArr.length);
        const AllResponse = { count: totalArr, rowdata: tnderdata, TenderEOI: EOIArr.length, TenderRFP: RFPArr.length, TenderRFQ: RFQArr.length }
        if (AllResponse) {
          res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: AllResponse
          });
        }
        else {
          res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
            message: process.env.APIRESPMSG_RECNOTFOUND,
            error: true,
            success: false,
            status: '0',
          });
        }

      }
      else {
        res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
          message: process.env.APIRESPMSG_RECNOTFOUND,
          error: true,
          success: false,
          status: '0',
        });
      }
    }
    else {
      res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
        message: process.env.APIRESPMSG_RECNOTFOUND,
        error: true,
        success: false,
        status: '0',
      });
    }

  } catch (error) {
    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
      //message: error.message,
      message: process.env.ERROR_MSG,
      error: error.message,
      success: false,
      status: '0',
    });

  }

}


// Department Calendar by date



async function getUsersUnderReportingManager(reportingManagerId) {
  const usersByIo = await Users.findAll({
    where: { reporting_mngr_id: reportingManagerId },
    attributes: ['id', 'reporting_mngr_id', 'userfullname']
  });

  let result = [...usersByIo]; // Initialize result with direct reports

  // Function to recursively fetch users under a given reporting manager
  async function fetchSubUsers(reportingManagerId) {

    const subUsers = await Users.findAll({
      where: { reporting_mngr_id: reportingManagerId },
      attributes: ['id', 'reporting_mngr_id', "userfullname"]
    });
    let subUsersResult = [...subUsers]; // Initialize with direct sub-users

    // Recursively fetch users under each direct sub-user
    for (const user of subUsers) {
      const subSubUsers = await fetchSubUsers(user.id);
      subUsersResult = [...subUsersResult, ...subSubUsers];
    }

    return subUsersResult;
  }

  // Iterate through each direct report and fetch users under them recursively
  for (const user of usersByIo) {
    const subUsers = await fetchSubUsers(user.id);
    result = [...result, ...subUsers];
  }

  //   console.log(result);
  return result;
}

const getUsersUnderuser = async (req, res) => {

  try {
    const usersByIo = await getUsersUnderReportingManager(req.userId)
    if (usersByIo[0]) {
      res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
        message: process.env.APIRESPMSG_RECFOUND,
        error: false,
        success: true,
        status: '1',
        data: usersByIo
      });
    } else {
      res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
        message: process.env.APIRESPMSG_RECFOUND,
        error: false,
        success: true,
        status: '1',
        data: usersByIo
      });
    }
  } catch (error) {
    res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
      message: process.env.ERROR_MSG,
      error: true,
      success: false,
      status: '0',
    });
  }
}
//todo team tasks

const todoTeamTasks = async (req, res) => {
  const schema = Joi.object().keys({
    user_id: Joi.string().allow(null),
    todo_scope: Joi.string().required(),

  });
  const dataToValidate = {
    user_id: req.body.user_id,
    todo_scope: req.body.todo_scope,
  }
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: '0'
    });
  } else {
    try {

      const userData = await getUsersUnderReportingManager(req.userId);

      const usersByIo = await Promise.all(userData.map(async (user_id) => {

        if (req.body.user_id) {

          const user_id_arr = req.body.user_id.split(',');
          const user_idArrInt = user_id_arr.map(str => Number(str));

          if (user_idArrInt.length > 0) {
            let toDoTasks = [];
            if (user_idArrInt.includes(user_id.id)) {

              toDoTasks = await Todolist.findAll({
                where: { status: "1", current_scope: req.body.todo_scope },
                // attributes:['id', 'task_name', 'hash_tags', 'current_scope', 'deadline_date', 'task_description'],
                include: {
                  model: Assignedtask,
                  where: { status: "1", user_comp_id: req.comp_id, assigned_to_userid: user_id.id },
                  attributes: ['id', 'assigned_to_userid'],
                  as: 'assigned_users'
                }
              });

              const todo_tasks = (toDoTasks[0]) ? toDoTasks : 0;
              const mainUserId = (user_id) ? user_id : 0;
              return {
                ...mainUserId.toJSON(),
                todo_tasks
              };

            } else {
              const todo_tasks = (toDoTasks[0]) ? toDoTasks : null;
              const mainUserId = (user_id) ? user_id : null;
              return {
                ...mainUserId.toJSON(),
                todo_tasks
              };
            }
          }
        }
        else {
          const toDoTasks = await Todolist.findAll({
            where: { status: "1", current_scope: req.body.todo_scope },
            // attributes:['id', 'task_name', 'hash_tags', 'current_scope', 'deadline_date', 'task_description'],
            include: {
              model: Assignedtask,
              where: { status: "1", user_comp_id: req.comp_id, assigned_to_userid: user_id.id },
              attributes: ['id', 'assigned_to_userid'],
              as: 'assigned_users'
            }
          });

          const todo_tasks = (toDoTasks[0]) ? toDoTasks : "";
          const mainUserId = (user_id) ? user_id : 0;

          return {
            ...mainUserId.toJSON(),
            todo_tasks
          };
        }



      }))

      if (usersByIo) {
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: process.env.APIRESPMSG_RECFOUND,
          error: false,
          success: true,
          status: '1',
          data: usersByIo,

        });
      }

    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: '0',
      });
    }
  }
}

// Get All Users By Reporting Manager

const getAllUsersByReportingManager = async (req, res) => {
  const schema = Joi.object().keys({
    user_id: Joi.string().required(),

  });
  const dataToValidate = {
    user_id: req.body.user_id,
  }
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: '0'
    });
  } else {
    try {

      const usersByIo = await getUsersUnderReportingManager(req.body.user_id);
      if (usersByIo[0]) {
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: process.env.APIRESPMSG_RECFOUND,
          error: false,
          success: true,
          status: '1',
          data: usersByIo,

        });
      } else {
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: process.env.APIRESPMSG_RECNOTFOUND,
          error: false,
          success: true,
          status: '0',

        });
      }

    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: '0',
      });
    }
  }
}


//get Prebid data by date in calendar
async function getPreBidDataByDateForLoginUser(req, getYearMonthDate, isPrebid) {

  const year = getYearMonthDate.getFullYear();
  const month = String(getYearMonthDate.getMonth() + 1).padStart(2, "0");
  const date = String(getYearMonthDate.getDate()).padStart(2, "0");
  const TenderModel = createTenderModel(req.comp_id);
  await TenderModel.performOperation();

  let whereCond = {};
  if (isPrebid == 1) {
    whereCond.pre_bid_meeting_date = {
      [Op.like]: literal(`'%${year}-${month}-${date}%'`),
    };
  } else {
    whereCond.submission_end_date = {
      [Op.like]: literal(`'%${year}-${month}-${date}%'`),
    };
  }

  const prebidTenderData = [];
  const tenderAssignData = await TenderAssignManagerModel.findAll({
    where: {
      status: "1",
      user_comp_id: req.comp_id,
      assign_to: req.userId,
    },
    attributes: ["assign_to", "tender_id"],
  });

  if (tenderAssignData[0]) {

    const scope_arrss = [];
    const scope_arrs = await Tenderscope.findAll({
      order: [["order_sr", "ASC"]],
      where: {
        user_comp_id: req.comp_id,
        status: "1",
        category: "1",
        order_sr: [6, 7],
      },
      attributes: ["id"],
      raw: true,
    });

    const scope_arr = await Promise.all(
      scope_arrs.map(async (scope_data) => {
        scope_arrss.push(scope_data.id);
      })
    );


    const tasksWithCount = await Promise.all(tenderAssignData.map(async (data) => {

      const prebid_check_exist = await TenderModel.findOne({
        where: {
          cycle_id: scope_arrss,
          user_comp_id: req.comp_id,
          id: data.tender_id,
          status: "1",
          ...whereCond
        },
        attributes: [
          "id",
          "tender_name",
          [
            literal(`DATE_FORMAT(submission_end_date, '%Y-%m-%d')`),
            "submission_end_date",
          ],
          [
            literal(`DATE_FORMAT(pre_bid_meeting_date, '%Y-%m-%d')`),
            "pre_bid_meeting_date",
          ],
        ],
        include: [
          {
            model: TenderGeneratedTypeIdModel,
            where: { status: "1" },
            attributes: ["id", "generated_tender_id"],
          },
          {
            model: TenderAssignManagerModel,
            where: { status: "1", assign_to: req.userId },
            attributes: ["id", "assign_to"],
            as: "assign_tender",
            include: [
              {
                model: TenderBdRoleModel,
                where: { status: "1" },
                attributes: ["id", "role_name"]
              }
            ]

          },
        ],
      });

      if (prebid_check_exist) {
        prebidTenderData.push(prebid_check_exist);
      }

    })
    );
  }
  return prebidTenderData
}

//=========== Function for fetching tender request data by Date ==================
async function getTenderRequestDataByDate(req, year, month, date, userId) {
  const tenderReqData = await TenderDetailsRequest.findAll({
    where: {
      created_at: { [Op.like]: literal(`'%${year}-${month}-${date}%'`), },
      [Op.or]: [
        { req_from_userid: userId },
        { req_to_userid: userId },
      ],
      status: "1",
      user_comp_id: req.comp_id,
    },
  });
  return tenderReqData;
}
//======================================================================================

//========== Script to fetch todo task list
async function getTodoTaskDataByDate(req, year, month, date, userId, isConditionValue) {

  if (isConditionValue == 1) {
    var conditionVal = { [Op.like]: literal(`'%${year}-${month}-${date}%'`), };
  } else if (isConditionValue == 2) {
    var conditionVal = { [Op.like]: literal(`'%${year}-${month}-%'`), };
  }
  const toDoTaskList = await Todolist.findAll({
    where: {
      created_at: conditionVal,
      status: "1",
    },

    include: {
      model: AssignedtaskModel,
      where: {
        status: "1",
        user_comp_id: req.comp_id,
        [Op.or]: [
          { assigned_to_userid: userId },
          { created_by: userId },
        ],
      },
      attributes: ["assigned_to_userid", "created_by"],
      as: "assigned_users",
      include: {
        model: Users,
        where: { isactive: "1" },
        attributes: ["userfullname"],
      },
    },
  });

  return toDoTaskList;
}
//============================================================================


//=========== Function for tender request data by Date ==================
async function getTenderTodoTaskDataList(req, year, month, date, userId) {

  if (date != null) {
    var conditionVal = { [Op.like]: literal(`'%${year}-${month}-${date}%'`), };
  } else {
    var conditionVal = { [Op.like]: literal(`'%${year}-${month}-%'`), };
  }

  const todoResponse = await ProjectTodo.findAll({
    where: {
      created_at: conditionVal,
      status: "1",
    },
    include: {
      model: ProjectAssigntaskModel,
      where: {
        status: "1",
        user_comp_id: req.comp_id,
        [Op.or]: [
          { assigned_to_userid: userId },
          { created_by: userId },
        ],
      },
      attributes: ["id", "assigned_to_userid"],
      as: "assigned_users",
    },
  });

  const tenderTodoTask = await Promise.all(todoResponse.map(async (task) => {

    const assign_user = await ProjectAssigntaskModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
    const assign_user_comment = await ProjectTodoCommentModel.count({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
    const assign_user_list = await ProjectAssigntaskModel.findAll({ where: { user_comp_id: req.comp_id, task_id: task.id, status: '1' } });
    const assignedUsersCount = assign_user - 1;
    const taskcommentCount = assign_user_comment;

    return {
      ...task.toJSON(),
      assignedUsersCount,
      taskcommentCount,
      assign_user_list
    };
  }));
  return tenderTodoTask;
}
//=========================================================================

//============== Personal Calendar Data By Date ==============================
const getCalenderDataByDate = async (req, res) => {
  const schema = Joi.object().keys({
    date: Joi.date().required(),
  });
  const dataToValidate = {
    date: req.body.date,
  };
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: "0",
    });
  } else {
    try {
      var yearMonthDate = new Date(req.body.date);
      const getYearMonth = () => new Date(req.body.date);
      const year = getYearMonth().getFullYear();
      const month = String(getYearMonth().getMonth() + 1).padStart(2, "0");
      const date = String(getYearMonth().getDate()).padStart(2, "0");
      const TenderModel = createTenderModel(req.comp_id);
      await TenderModel.performOperation();

      // ============= Meeting scheduled on date=====================
      const meetingResp = await MainmeetingModel.findAll({
        where: {
          status: "1",
          meeting_date: { [Op.like]: literal(`'%${year}-${month}-${date}%'`) },
        },
        include: {
          model: MeetingInvitationModel,
          where: {
            status: "1",
            //  send_invitation:req.userId
            [Op.or]: [
              { send_invitation: req.userId },
              { created_by: req.userId },
            ],
          },
          attributes: ["id", "send_invitation", "created_by"],
        },
      });

      //================================================================================

      // ========================= PRE BID DATA FETCH===================================

      const prebidTenderData = await getPreBidDataByDateForLoginUser(req, yearMonthDate, 1);

      //================================================================================

      //=================== TENDER SUBMISSION Data Fetch ==============================

      const tendersData = await getPreBidDataByDateForLoginUser(req, yearMonthDate, 2);

      //===============================================================================

      //=========================== Tender Request Data Start =========================

      const tenderReqData = await getTenderRequestDataByDate(req, year, month, date, req.userId);

      //==============================================================================

      //======================== Todo Task Data =======================================

      const toDoTasks = await getTodoTaskDataByDate(req, year, month, date, req.userId, 1);

      //===============================================================================

      //======================== Todo Task Data =======================================

      const tenderTodoTask = await getTenderTodoTaskDataList(req, year, month, date, req.userId);

      //===============================================================================

      const mergedArr = {
        meetingList: meetingResp,
        prebid_data: prebidTenderData,
        tenderDataList: tendersData,
        tenderReqList: tenderReqData,
        tenderTodoTaskList: tenderTodoTask,
        toDoTaskList: toDoTasks,
      };

      if (mergedArr) {
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: process.env.APIRESPMSG_RECFOUND,
          error: false,
          success: true,
          status: "1",
          data: mergedArr,
        });
      }
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: "0",
      });
    }
  }
};




// Get Prebid Data of month for personal Calendar
async function getPreBidDataByMonthForLoginUser(req, getYearMonth, isPrebid) {
  // const tendersData = [];
  const year = getYearMonth.getFullYear();
  const month = String(getYearMonth.getMonth() + 1).padStart(2, "0");

  const TenderModel = createTenderModel(req.comp_id);
  await TenderModel.performOperation();

  let whereCond = {};
  if (isPrebid == 1) {
    whereCond.pre_bid_meeting_date = {
      [Op.like]: literal(`'%${year}-${month}-%'`),
    };
  } else {
    whereCond.submission_end_date = {
      [Op.like]: literal(`'%${year}-${month}-%'`),
    };
  }

  const prebidTenderData = [];
  const tenderAssignData = await TenderAssignManagerModel.findAll({
    where: {
      status: "1",
      user_comp_id: req.comp_id,
      assign_to: req.userId,
    },
    attributes: ["assign_to", "tender_id"],
  });

  if (tenderAssignData[0]) {
    const scope_arrss = [];
    const scope_arrs = await Tenderscope.findAll({
      order: [["order_sr", "ASC"]],
      where: {
        user_comp_id: req.comp_id,
        status: "1",
        category: "1",
        order_sr: [6, 7],
      },
      attributes: ["id"],
      raw: true,
    });

    const scope_arr = await Promise.all(
      scope_arrs.map(async (scope_data) => {
        scope_arrss.push(scope_data.id);
      })
    );

    const tasksWithCount = await Promise.all(tenderAssignData.map(async (data) => {

      const prebid_check_exist = await TenderModel.findOne({
        where: {
          cycle_id: scope_arrss,
          user_comp_id: req.comp_id,
          id: data.tender_id,
          status: "1",
          ...whereCond
        },
        attributes: ["id", "tender_name", "cycle_id",
          [literal(`DATE_FORMAT(submission_end_date, '%Y-%m-%d')`), "submission_end_date",],
          [literal(`DATE_FORMAT(pre_bid_meeting_date, '%Y-%m-%d')`), "pre_bid_meeting_date",],
        ],
        include: [
          {
            model: TenderGeneratedTypeIdModel,
            where: { status: "1" },
            attributes: ["id", "generated_tender_id"],
          },
          {
            model: TenderAssignManagerModel,
            where: { status: "1", assign_to: req.userId },
            attributes: ["id", "assign_to"],
            as: "assign_tender",
          },
        ],
      });

      if (prebid_check_exist) {
        prebidTenderData.push(prebid_check_exist);
      }
    })
    );
  }
  return prebidTenderData
}

//=========== Function for tender request data by Date ==================
async function getTenderRequestDataByMonth(req, year, month, userId) {
  const tenderReqData = await TenderDetailsRequest.findAll({
    where: {
      created_at: { [Op.like]: literal(`'%${year}-${month}-%'`), },
      [Op.or]: [
        { req_from_userid: userId },
        { req_to_userid: userId },
      ],
      status: "1",
      user_comp_id: req.comp_id,
    },
  });
  return tenderReqData;
}
//=========================================================================


// Events & Activity on date from calender
const getCalenderDataByMonth = async (req, res) => {
  const schema = Joi.object().keys({
    month: Joi.date().required(),
  });
  const dataToValidate = {
    month: req.body.month,
  };
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: "0",
    });
  } else {
    try {
      var year_month = new Date(req.body.month);
      const getYearMonth = () => new Date(req.body.month);
      const year = getYearMonth().getFullYear();
      const month = String(getYearMonth().getMonth() + 1).padStart(2, "0");

      const TenderModel = createTenderModel(req.comp_id);
      await TenderModel.performOperation();

      // ============= Meeting scheduled on month =====================
      const meetingResp = await MainmeetingModel.findAll({
        where: {
          status: "1",
          meeting_date: { [Op.like]: literal(`'%${year}-${month}-%'`) },
        },
        include: {
          model: MeetingInvitationModel,
          where: {
            status: "1",
            [Op.or]: [
              { send_invitation: req.userId },
              { created_by: req.userId },
            ],
          },
          attributes: ["id", "send_invitation", "created_by"],
        },
      });

      // ===================== End Meeting Data ====================================

      //====================== PREBID DATA =========================================

      const prebidTenderData = await getPreBidDataByMonthForLoginUser(req, year_month, 1);

      //===============================================================================

      //====================== TENDER SUBMMISSION DATA ================================

      const tendersData = await getPreBidDataByMonthForLoginUser(req, year_month, 2);

      //===============================================================================

      //======================= Tender Request Data Start =============================

      const tenderReqData = await getTenderRequestDataByMonth(req, year, month, req.userId);

      // ==============================================================================

      //======================== Todo Task Data =======================================

      const toDoTasks = await getTodoTaskDataByDate(req, year, month, null, req.userId, 2);

      //===============================================================================


      //======================== Todo Task Data =======================================

      const tenderTodoTask = await getTenderTodoTaskDataList(req, year, month, null, req.userId);

      //===============================================================================


      // const tenderTodoTask = await ProjectTodo.findAll({
      //   where: {
      //     created_at: { [Op.like]: literal(`'%${year}-${month}-%'`) },
      //     status: "1",
      //   },

      //   include: {
      //     model: ProjectAssigntaskModel,
      //     where: {
      //       status: "1",
      //       user_comp_id: req.comp_id,
      //       assigned_to_userid: req.userId,
      //     },
      //     attributes: ["id", "assigned_to_userid"],
      //     as: "assigned_users",
      //   },
      // });

      const mergedArr = {
        meetingList: meetingResp,
        prebid_data: prebidTenderData,
        tenderDataList: tendersData,
        tenderReqList: tenderReqData,
        tenderTodoTaskList: tenderTodoTask,
        toDoTaskList: toDoTasks,
      };

      if (mergedArr) {
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
          message: process.env.APIRESPMSG_RECFOUND,
          error: false,
          success: true,
          status: "1",
          data: mergedArr,
        });
      }
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: "0",
      });
    }
  }
};


// Get Prebid Data for month in personal Calendar
async function getDeptPreBidDataByDateForLoginUser(req, getYearMonthDate, userId, isPrebid) {

  const year = getYearMonthDate.getFullYear();
  const month = String(getYearMonthDate.getMonth() + 1).padStart(2, "0");
  const date = String(getYearMonthDate.getDate()).padStart(2, "0");

  const TenderModel = createTenderModel(req.comp_id);
  await TenderModel.performOperation();

  let whereCond = {};
  if (isPrebid === 1) {
    whereCond.pre_bid_meeting_date = {
      [Op.like]: literal(`'%${year}-${month}-${date}%'`),
    };
  } else if (isPrebid === 2) {
    whereCond.submission_end_date = {
      [Op.like]: literal(`'%${year}-${month}-${date}%'`),
    };
  }


  const prebidTenderData = [];
  const tenderAssignData = await TenderAssignManagerModel.findAll({
    where: {
      status: "1",
      user_comp_id: req.comp_id,
      assign_to: userId,
    },
    attributes: ["assign_to", "tender_id"],
  });


  if (tenderAssignData[0]) {

    const scope_arrss = [];
    const scope_arrs = await Tenderscope.findAll({
      order: [["order_sr", "ASC"]],
      where: {
        user_comp_id: req.comp_id,
        status: "1",
        category: "1",
        order_sr: [6, 7],
      },
      attributes: ["id"],
      raw: true,
    });

    const scope_arr = await Promise.all(
      scope_arrs.map(async (scope_data) => {
        scope_arrss.push(scope_data.id);
      })
    );

    const tasksWithCount = await Promise.all(tenderAssignData.map(async (data) => {

      var prebid_check_exist = await TenderModel.findOne({
        where: {
          cycle_id: scope_arrss,
          user_comp_id: req.comp_id,
          id: data.tender_id,
          status: "1",
          ...whereCond
          // pre_bid_meeting_date: {
          //   [Op.like]: literal(`'%${year}-${month}-${date}%'`),
          // },
        },
        attributes: ["id", "tender_name",
          [
            literal(`DATE_FORMAT(submission_end_date, '%Y-%m-%d')`),
            "submission_end_date",
          ],
          [
            literal(`DATE_FORMAT(pre_bid_meeting_date, '%Y-%m-%d')`),
            "pre_bid_meeting_date",
          ],
        ],
        include: [
          {
            model: TenderGeneratedTypeIdModel,
            where: { status: "1" },
            attributes: ["id", "generated_tender_id"],
          },
          {
            model: TenderAssignManagerModel,
            where: { status: "1", assign_to: userId },
            attributes: ["id", "assign_to"],
            as: "assign_tender",
            include: [
              {
                model: TenderBdRoleModel,
                where: { status: "1" },
                attributes: ["id", "role_name"]
              }
            ]

          },
        ],
      });

      if (prebid_check_exist) {
        prebidTenderData.push(prebid_check_exist);
      }

    })
    );
  }
  return prebidTenderData;
}

// Department Calendar Data by Date
const getDeptCalenderDataByDate = async (req, res) => {
  const schema = Joi.object().keys({
    date: Joi.date().required(),
    user_id: Joi.string().allow(null),
  });
  const dataToValidate = {
    date: req.body.date,
    user_id: req.body.user_id,
  };
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: "0",
    });
  } else {
    try {
      var yearMonthDate = new Date(req.body.date);
      const getYearMonth = () => new Date(req.body.date);
      const year = getYearMonth().getFullYear();
      const month = String(getYearMonth().getMonth() + 1).padStart(2, "0");
      const date = String(getYearMonth().getDate()).padStart(2, "0");
      const TenderModel = createTenderModel(req.comp_id);
      await TenderModel.performOperation();

      if (req.body.user_id != null) {
        const user_id_arr = req.body.user_id.split(",");
        const user_idArrInt = user_id_arr.map((str) => Number(str));


        let prebidDataArr = [];
        let tndrSubmitDataArr = [];
        if (user_idArrInt.length > 0) {
          const userData = await getSelectedUsersUnderReportingManager_(req.userId, user_idArrInt);
          const meetingData = await Promise.all(userData.map(async (user_id) => {

            if (user_idArrInt.includes(user_id.id)) {

              const meetingList = await MainmeetingModel.findAll({
                where: { status: "1", meeting_date: { [Op.like]: literal(`'%${year}-${month}-${date}%'`) }, },
                include: {
                  model: MeetingInvitationModel,
                  where: {
                    status: "1",
                    [Op.or]: [
                      { send_invitation: user_id.id },
                      { created_by: user_id.id },
                    ],
                  },
                  attributes: ["id", "send_invitation"],
                },
              });

              // =============== PREBID DATA FETCH ===========================================

              const prebid_data = await getDeptPreBidDataByDateForLoginUser(req, yearMonthDate, user_id.id, 1);

              prebidDataArr = [...prebid_data, ...prebidDataArr]

              //===============================================================================

              // ============= TENDER SUBMISSION DATA FETCH ======================================
              const tenderDataList = await getDeptPreBidDataByDateForLoginUser(req, yearMonthDate, user_id.id, 2);

              tndrSubmitDataArr = [...tenderDataList, ...tndrSubmitDataArr]

              //===================================================================================

              //====================== Todo Task Data =============================================

              const toDoTaskList = await getTodoTaskDataByDate(req, year, month, date, user_id.id, 1);

              //====================================================================================

              //======================== Todo Task Data =======================================

              const tenderTodoTaskList = await getTenderTodoTaskDataList(req, year, month, date, user_id.id);

              //===============================================================================

              //================= Tender Request Data Start ====================================
              const tenderReqList = await getTenderRequestDataByDate(req, year, month, date, user_id.id);
              //=================================================================================


              // ============= Tender To Do Tasks list on date =====================

              return {
                ...user_id.toJSON(),
                meetingList,
                prebid_data,
                tenderDataList,
                tenderReqList,
                tenderTodoTaskList,
                toDoTaskList,
              };
            }
          })
          );

          if (meetingData[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
              message: process.env.APIRESPMSG_RECFOUND,
              error: false,
              success: true,
              status: "1",
              data: meetingData,
            });
          } else {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
              message: process.env.APIRESPMSG_RECNOTFOUND,
              error: false,
              success: true,
              status: "0",
            });
          }
        }
      } else {
        let prebidDataArr = [];
        let tndrSubmitDataArr = [];
        const userData = await getUsersUnderReportingManager(req.userId);
        const meetingData = await Promise.all(userData.map(async (user_id) => {

          const meetingList = await MainmeetingModel.findAll({
            where: { status: "1", meeting_date: req.body.date },
            include: {
              model: MeetingInvitationModel,
              where: {
                status: "1",
                [Op.or]: [
                  { send_invitation: user_id.id },
                  { created_by: user_id.id },
                ],
              },
              attributes: ["id", "send_invitation"],
            },
          });

          // ============= pre bid data=======================================
          const prebid_data = await getDeptPreBidDataByDateForLoginUser(req, yearMonthDate, user_id.id, 1);

          prebidDataArr = [...prebid_data, ...prebidDataArr]

          //====================================================================


          //================= Tender Request Data Start ========================
          const tenderReqList = await getTenderRequestDataByDate(req, year, month, date, user_id.id);

          //=====================================================================


          // ===================== TENDER SUBMISSION DATA FETCH =================================

          const tenderDataList = await getDeptPreBidDataByDateForLoginUser(req, yearMonthDate, user_id.id, 2);

          tndrSubmitDataArr = [...tenderDataList, ...tndrSubmitDataArr]

          //======================================================================================

          //====================== Todo Task Data =============================================

          const toDoTaskList = await getTodoTaskDataByDate(req, year, month, date, user_id.id, 1);

          //====================================================================================

          //======================== Tender Todo Task Data =======================================

          const tenderTodoTaskList = await getTenderTodoTaskDataList(req, year, month, date, user_id.id);

          //===============================================================================

          return {
            ...user_id.toJSON(),
            meetingList,
            prebid_data,
            tenderDataList,
            tenderReqList,
            tenderTodoTaskList,
            toDoTaskList,
          };

          // }
        })
        );

        if (meetingData) {
          res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: "1",
            data: meetingData,
          });
        }
      }
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: "0",
      });
    }
  }
};

// Get Prebid Data for month in personal Calendar
async function getDeptPreBidDataByMonthForLoginUser(req, getYearAndMonth, userId, isPrebid) {

  const year = getYearAndMonth.getFullYear();
  const month = String(getYearAndMonth.getMonth() + 1).padStart(2, "0");
  const date = String(getYearAndMonth.getDate()).padStart(2, "0");

  const TenderModel = createTenderModel(req.comp_id);
  await TenderModel.performOperation();

  let whereCond = {};
  if (isPrebid == 1) {
    whereCond.pre_bid_meeting_date = {
      [Op.like]: literal(`'%${year}-${month}-%'`),
    };
  } else {
    whereCond.submission_end_date = {
      [Op.like]: literal(`'%${year}-${month}-%'`),
    };
  }

  const prebidTenderData = [];
  const tenderAssignData = await TenderAssignManagerModel.findAll({
    where: {
      status: "1",
      user_comp_id: req.comp_id,
      assign_to: userId,
    },
    attributes: ["assign_to", "tender_id"],
  });

  if (tenderAssignData[0]) {

    const scope_arrss = [];
    const scope_arrs = await Tenderscope.findAll({
      order: [["order_sr", "ASC"]],
      where: {
        user_comp_id: req.comp_id,
        status: "1",
        category: "1",
        order_sr: [6, 7],
      },
      attributes: ["id"],
      raw: true,
    });

    const scope_arr = await Promise.all(
      scope_arrs.map(async (scope_data) => {
        scope_arrss.push(scope_data.id);
      })
    );

    const tasksWithCount = await Promise.all(tenderAssignData.map(async (data) => {

      var prebid_check_exist = await TenderModel.findOne({
        where: {
          cycle_id: scope_arrss,
          user_comp_id: req.comp_id,
          id: data.tender_id,
          status: "1",
          ...whereCond
          // pre_bid_meeting_date: {
          //   [Op.like]: literal(`'%${year}-${month}-%'`),
          // },
        },
        attributes: ["id", "tender_name",
          [
            literal(`DATE_FORMAT(submission_end_date, '%Y-%m-%d')`),
            "submission_end_date",
          ],
          [
            literal(`DATE_FORMAT(pre_bid_meeting_date, '%Y-%m-%d')`),
            "pre_bid_meeting_date",
          ],
        ],
        include: [
          {
            model: TenderGeneratedTypeIdModel,
            where: { status: "1" },
            attributes: ["id", "generated_tender_id"],
          },
          {
            model: TenderAssignManagerModel,
            where: { status: "1", assign_to: userId },
            attributes: ["id", "assign_to"],
            as: "assign_tender",
            include: [
              {
                model: TenderBdRoleModel,
                where: { status: "1" },
                attributes: ["id", "role_name"]
              }
            ]

          },
        ],
      });

      if (prebid_check_exist) {
        prebidTenderData.push(prebid_check_exist);
      }

    })
    );
  }
  return prebidTenderData;
}

// Department Calendar by Month
const getDeptCalenderDataByMonth = async (req, res) => {
  const schema = Joi.object().keys({
    month: Joi.date().required(),
    user_id: Joi.string().allow(null),
  });
  const dataToValidate = {
    month: req.body.month,
    user_id: req.body.user_id,
  };
  const result = schema.validate(dataToValidate);
  if (result.error) {
    res.status(process.env.APIRESPCODE_VALIDATION).send({
      message: result.error.details[0].message,
      error: true,
      success: false,
      status: "0",
    });
  } else {
    try {
      var yearAndMonth = new Date(req.body.month);
      const getYearMonth = () => new Date(req.body.month);
      const year = getYearMonth().getFullYear();
      const month = String(getYearMonth().getMonth() + 1).padStart(2, "0");

      const TenderModel = createTenderModel(req.comp_id);
      await TenderModel.performOperation();

      if (req.body.user_id != null) {
        const user_id_arr = req.body.user_id.split(",");
        const user_idArrInt = user_id_arr.map((str) => Number(str));


        if (user_idArrInt.length > 0) {
          const userData = await getSelectedUsersUnderReportingManager_(req.userId, user_idArrInt);
          let prebidDataArr = [];
          let tndrSubmitDataArr = [];
          const usersByIo = await Promise.all(userData.map(async (user_id) => {

            if (user_idArrInt.includes(user_id.id)) {
              const meetingList = await MainmeetingModel.findAll({
                where: {
                  status: "1",
                  meeting_date: {
                    [Op.like]: literal(`'%${year}-${month}-%'`),
                  },
                },
                include: {
                  model: MeetingInvitationModel,
                  where: {
                    status: "1",
                    [Op.or]: [
                      { send_invitation: user_id.id },
                      { created_by: user_id.id },
                    ],
                  },
                  attributes: ["id", "send_invitation"],
                },
              });

              // ============= pre bid data=========================================================

              const prebid_data = await getDeptPreBidDataByMonthForLoginUser(req, yearAndMonth, user_id.id, 1);

              prebidDataArr = [...prebid_data, ...prebidDataArr]

              //======================================================================================

              //================= Tender Request Data Start ==========================================

              const tenderReqList = await getTenderRequestDataByMonth(req, year, month, user_id.id);

              // ======================================================================================

              // ================== TENDER SUBMISSION DATA FETCH=========================================

              const tenderDataList = await getDeptPreBidDataByMonthForLoginUser(req, yearAndMonth, user_id.id, 2);

              tndrSubmitDataArr = [...tenderDataList, ...tndrSubmitDataArr]

              //=========================================================================================

              //====================== Todo Task Data =======================================

              const toDoTaskList = await getTodoTaskDataByDate(req, year, month, null, user_id.id, 2);

              //=============================================================================

              //======================== Tender Todo Task Data =======================================

              const tenderTodoTaskList = await getTenderTodoTaskDataList(req, year, month, null, user_id.id);

              //===============================================================================


              // ============= Tender To Do Tasks list on date =====================
              // const tenderTodoTaskList = await ProjectTodo.findAll({
              //   where: {
              //     created_at: { [Op.like]: literal(`'%${year}-${month}-%'`) },
              //     status: "1",
              //   },
              //   // attributes:['id', 'task_name', 'hash_tags', 'current_scope', 'deadline_date', 'task_description'],
              //   include: {
              //     model: ProjectAssigntaskModel,
              //     where: {
              //       status: "1",
              //       user_comp_id: req.comp_id,
              //       assigned_to_userid: user_id.id,
              //     },
              //     attributes: ["id", "assigned_to_userid"],
              //     as: "assigned_users",
              //   },
              // });


              return {
                ...user_id.toJSON(),
                meetingList,
                prebid_data,
                tenderReqList,
                tenderTodoTaskList,
                tenderDataList,
                toDoTaskList,
              };
            }
          })
          );

          if (usersByIo) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
              message: process.env.APIRESPMSG_RECFOUND,
              error: false,
              success: true,
              status: "1",
              data: usersByIo,
            });
          }
        }
      } else {
        const userData = await getUsersUnderReportingManager(req.userId);
        let prebidDataArr = [];
        let tndrSubmitDataArr = [];
        const usersByIo = await Promise.all(userData.map(async (user_id) => {

          const meetingList = await MainmeetingModel.findAll({
            where: {
              status: "1",
              meeting_date: { [Op.like]: literal(`'%${year}-${month}-%'`) },
            },
            include: {
              model: MeetingInvitationModel,
              where: {
                status: "1",
                [Op.or]: [
                  { send_invitation: user_id.id },
                  { created_by: user_id.id },
                ],
              },
              attributes: ["id", "send_invitation"],
            },
          });

          // =============================== pre bid data======================================

          const prebid_data = await getDeptPreBidDataByMonthForLoginUser(req, yearAndMonth, user_id.id, 1);

          prebidDataArr = [...prebid_data, ...prebidDataArr]

          // =====================================================================================

          //=========================== Tender Request Data Start ================================

          const tenderReqList = await getTenderRequestDataByMonth(req, year, month, user_id.id);

          //=======================================================================================

          // =========================== TENDER FETCH DATA=========================================

          const tenderDataList = await getDeptPreBidDataByMonthForLoginUser(req, yearAndMonth, user_id.id, 2);

          tndrSubmitDataArr = [...tenderDataList, ...tndrSubmitDataArr]

          //======================================================================================

          //====================== Todo Task Data ================================================

          const toDoTaskList = await getTodoTaskDataByDate(req, year, month, null, user_id.id, 2);

          //======================================================================================

          //======================== Tender Todo Task Data =======================================

          const tenderTodoTaskList = await getTenderTodoTaskDataList(req, year, month, null, user_id.id);

          //===============================================================================

          // ============= Tender To Do Tasks list on date =====================
          // const tenderTodoTaskList = await ProjectTodo.findAll({
          //   where: {
          //     created_at: { [Op.like]: literal(`'%${year}-${month}-%'`) },
          //     status: "1",
          //   },
          //   // attributes:['id', 'task_name', 'hash_tags', 'current_scope', 'deadline_date', 'task_description'],
          //   include: {
          //     model: ProjectAssigntaskModel,
          //     where: {
          //       status: "1",
          //       user_comp_id: req.comp_id,
          //       assigned_to_userid: user_id.id,
          //     },
          //     attributes: ["id", "assigned_to_userid"],
          //     as: "assigned_users",
          //   },

          // });


          return {
            ...user_id.toJSON(),
            meetingList,
            prebid_data,
            tenderDataList,
            tenderReqList,
            tenderTodoTaskList,
            toDoTaskList,
          };

        })
        );
        if (usersByIo) {
          res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: "1",
            data: usersByIo,
          });
        }
      }
    } catch (error) {
      res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
        message: process.env.ERROR_MSG,
        error: error.message,
        success: false,
        status: "0",
      });
    }
  }
};


//get user under the reporting manager 

async function getSelectedUsersUnderReportingManager_(reportingManagerId, userIds) {
  if (userIds.length > 0) {
    var whereCond = {
      [Op.in]: userIds
    }
  } else {
    var whereCond = {};
  }
  const usersByIo = await Users.findAll({
    where: { reporting_mngr_id: reportingManagerId, id: whereCond },
    attributes: ['id', 'reporting_mngr_id', 'userfullname']
  });

  let result = [...usersByIo]; // Initialize result with direct reports

  // Function to recursively fetch users under a given reporting manager
  async function fetchSubUsers(reportingManagerId) {

    const subUsers = await Users.findAll({
      where: { reporting_mngr_id: reportingManagerId, id: whereCond },
      attributes: ['id', 'reporting_mngr_id', "userfullname"]
    });
    let subUsersResult = [...subUsers]; // Initialize with direct sub-users

    // Recursively fetch users under each direct sub-user
    for (const user of subUsers) {
      const subSubUsers = await fetchSubUsers(user.id);
      subUsersResult = [...subUsersResult, ...subSubUsers];
    }

    return subUsersResult;
  }  // Iterate through each direct report and fetch users under them recursively

  for (const user of usersByIo) {
    const subUsers = await fetchSubUsers(user.id);
    result = [...result, ...subUsers];
  }

  //   console.log(result);
  return result;
}



async function getUsersUnderReportingManager(reportingManagerId) {

  const usersByIo = await Users.findAll({
    where: { reporting_mngr_id: reportingManagerId },
    attributes: ['id', 'reporting_mngr_id', 'userfullname']
  });
  let result = [...usersByIo]; // Initialize result with direct reports

  async function fetchSubUsers(reportingManagerId) {

    const subUsers = await Users.findAll({
      where: { reporting_mngr_id: reportingManagerId },
      attributes: ['id', 'reporting_mngr_id', "userfullname"]
    });
    let subUsersResult = [...subUsers]; // Initialize with direct sub-users

    for (const user of subUsers) {
      const subSubUsers = await fetchSubUsers(user.id);
      subUsersResult = [...subUsersResult, ...subSubUsers];
    }
    return subUsersResult;
  }

  // Iterate through each direct report and fetch users under them recursively
  for (const user of usersByIo) {
    const subUsers = await fetchSubUsers(user.id);
    result = [...result, ...subUsers];
  }

  return result;
}

module.exports = {
  getOnGoingData, personalCalender, teamloginhistory, teamtasklist, teamtasklist_details, getCalenderDataByDate, getCalenderDataByMonth,
  toBesubmittedData, submittedDashData, AwaitingDashData, WonDashData, getDeptCalenderDataByDate, todoTeamTasks, getAllUsersByReportingManager,
  getDeptCalenderDataByMonth, getUsersUnderuser
};
