const Joi = require('joi');
require('dotenv').config();
const MenuMasterModel = require('../../models/roleandpermission/MenuMasterModel');
const getCurrentDateTime = () => new Date();
const addMenuMaster = async (req, res) => {
    const schema = Joi.object().keys({
        menu_name: Joi.string().required(),
        action_url: Joi.string().required(),
        parent_menu_id: Joi.number().required(),
        created_at: Joi.date().iso().required(),
        created_by: Joi.number().required(),
        status: Joi.number().required(),
    });

    const dataToValidate = {
        menu_name: req.body.menu_name,
        parent_menu_id: req.body.parent_menu_id ? req.body.parent_menu_id : 0,
        action_url: req.body.action_url,
        created_at: getCurrentDateTime(),
        created_by: req.userId,
        status: '1',
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const menuMaster = await MenuMasterModel.findOne({ where: { menu_name: req.body.menu_name, parent_menu_id: req.body.parent_menu_id ? req.body.parent_menu_id : 0 }, attributes: ['id', 'menu_name'] })
            console.log(menuMaster)
            if (!menuMaster) {
                console.log(dataToValidate, 'testing')
                const insert = await MenuMasterModel.create(dataToValidate)
                console.log(insert, 'inside if')
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Menu added successfully',
                    error: false,
                    success: true,
                    status: '1',
                    data: insert,
                });
            }
            else {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: 'Menu Already Exist',
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                // message: error.message,
                error: true,
                success: false,
                status: '0',
            });

            // res.status(400).send({ error: error.message });
        }
    }
};

// Menu List
const menuList = async (req, res) => {
    try {
        const menus = await MenuMasterModel.findAll({
            where: { status: '1' },
            attributes: ['id', 'parent_menu_id', 'menu_name', 'action_url']
        })
        if (!menus) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: 'Record Found',
            error: false,
            success: true,
            status: '1',
            data: menus,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });

        // res.status(400).send({ error: error.message });
    }
}

//edit Department
const editMenu = async (req, res) => {
    const schema = Joi.object().keys({
        menu_id: Joi.number().required(),
    });

    const dataToValidate = {
        menu_id: req.body.menu_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {
            const editMenu = await MenuMasterModel.findOne({
                where: { id: req.body.menu_id, status: '1' }, attributes: ['id', 'parent_menu_id', ['menu_name', 'sub_menu']],
                include: [
                    {
                        model: MenuMasterModel,
                        attributes: ['menu_name'],
                        as: 'parent_menu',
                        where: { status: '1' },
                        required: false,
                    }]
            })
            if (!editMenu) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: false,
                    success: true,
                    status: '0',
                    data: [],
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record Found',
                error: false,
                success: true,
                status: '1',
                data: editMenu,
            });
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                // message: error.message,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//update Menu
const updateMenu = async (req, res) => {
    const schema = Joi.object().keys({
        menu_id: Joi.number().required(),
        menu_name: Joi.string().required(),
        action_url: Joi.string().required(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        menu_id: req.body.menu_id,
        menu_name: req.body.menu_name,
        action_url: req.body.action_url,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const updMenu = await MenuMasterModel.findOne({ where: { id: req.body.menu_id, status: '1' }, attributes: ['id', 'parent_menu_id'] })
            console.log(updMenu, "testing")
            if (updMenu) {
                if (updMenu.parent_menu_id == 0) {
                    const existData_upd = await MenuMasterModel.findOne({ where: { status: "1", id: req.body.menu_id, menu_name: req.body.menu_name }, attributes: ['id'] });

                    if (existData_upd) {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECALREADYEXISTS,
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                    await MenuMasterModel.update(dataToValidate, {
                        where: { id: req.body.menu_id },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Menu updated successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
                else {
                    const existData_upd = await MenuMasterModel.findOne({ where: { status: "1", menu_name: req.body.menu_name, parent_menu_id: updMenu.parent_menu_id }, attributes: ['id'] });

                    if (existData_upd) {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECALREADYEXISTS,
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                    await MenuMasterModel.update(dataToValidate, {
                        where: { id: req.body.menu_id },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Menu updated successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}



//update Menu
const deleteMenu = async (req, res) => {
    const schema = Joi.object().keys({
        menu_id: Joi.number().required(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        menu_id: req.body.menu_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const updateData = {
            status: '0',
            modified_by: req.userId,
            updated_at: getCurrentDateTime(),
        }
        try {
            const updMenu = await MenuMasterModel.findOne({ where: { id: req.body.menu_id, status: '1' }, attributes: ['id', 'parent_menu_id'] })
            if (updMenu) {
                if (updMenu.parent_menu_id == 0) {
                    const existData_upd = await MenuMasterModel.findOne({ where: { status: "1", id: req.body.menu_id }, attributes: ['id'] });

                    if (!existData_upd) {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            // message: process.env.APIRESPMSG_RECNOTFOUND,
                            message: "inside if",
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                    await MenuMasterModel.update(updateData, {
                        where: { id: req.body.menu_id },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Menu Deleted successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
                else {
                    const existData_upd = await MenuMasterModel.findOne({ where: { status: "1", parent_menu_id: updMenu.parent_menu_id }, attributes: ['id'] });

                    if (!existData_upd) {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECNOTFOUND,
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                    await MenuMasterModel.update(updateData, {
                        where: { id: req.body.menu_id },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Menu Deleted successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}



module.exports = {
    addMenuMaster, menuList, editMenu, updateMenu, deleteMenu
};   