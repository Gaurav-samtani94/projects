const ActionPerm = require("../../models/roleandpermission/ActionPerm");
const Role = require("../../models/master/Role");
const userModel = require('../../models/Users')
const ActionPermissionModel = require("../../models/Menu/MenuMasterModel");
const Joi = require('joi');
require('dotenv').config();
// const  getCurrentDateTime() = new Date();
const getCurrentDateTime = () => new Date();

//Update Letter Code...
const SetActionPermRole = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        role_id: Joi.number().required(),
        view_perm: Joi.number().required(),
        add_perm: Joi.number().required(),
        update_perm: Joi.number().required(),
        delete_perm: Joi.number().required(),
        menu_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        role_id: req.body.role_id,
        view_perm: req.body.view_perm,
        add_perm: req.body.add_perm,
        update_perm: req.body.update_perm,
        delete_perm: req.body.delete_perm,
        menu_id: req.body.menu_id,
        created_by: req.userId,
        created_at: getCurrentDateTime()
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const AllowedUser = await userModel.findOne({
                where: {
                    id: req.userId,
                    permanent_sys_adm: "1",
                    isactive: '1'
                },
            });

            if (!AllowedUser) {
                return res.status(403).send({
                    message: "You are not permitted",
                    error: true,
                    success: false,
                    status: "0",
                });
            }

            const existData = await Role.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.role_id }, attributes: ['id'] });
            if (existData) {
                const existData2 = await ActionPerm.findOne({ where: { status: "1", user_comp_id: req.comp_id, role_id: req.body.role_id, menu_id: req.body.menu_id }, attributes: ['id'] });
                if (existData2) {

                    const UpdateDataArr = {
                        view_perm: req.body.view_perm,
                        add_perm: req.body.add_perm,
                        edit_perm: req.body.edit_perm,
                        update_perm: req.body.update_perm,
                        delete_perm: req.body.delete_perm,
                        menu_id: req.body.menu_id,
                        modified_by: req.userId,
                        updated_at: getCurrentDateTime(),
                    }

                    const update = await ActionPerm.update(UpdateDataArr, {
                        where: { status: "1", user_comp_id: req.comp_id, role_id: req.body.role_id, menu_id: req.body.menu_id }
                    });

                    res.status(200).send({
                        message: process.env.APIRESPMSG_RECUPDATED,
                        error: false,
                        success: true,
                        status: '1',
                        data: existData,
                    });

                } else {
                    const insert = await ActionPerm.create(dataToValidate)
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECINSERTED,
                        error: false,
                        success: true,
                        status: '1',
                        data: insert,
                    });
                }


            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Role ID Invalid.",
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            // res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}




//Single Data Get of Role..
const ActPermByRoleID = async (req, res) => {
    const schema = Joi.object().keys({
        role_id: Joi.number().required(),
    });
    const dataToValidate = {
        role_id: req.body.role_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const AllowedUser = await userModel.findOne({
                where: {
                    id: req.userId,
                    permanent_sys_adm: "1",
                    isactive: '1'
                },
            });
            if (!AllowedUser) {
                return res.status(403).send({
                    message: "You are not permitted",
                    error: true,
                    success: false,
                    status: "0",
                });
            }
            const existData = await ActionPerm.findAll({
                where: { status: "1", user_comp_id: req.comp_id, role_id: req.body.role_id },
                attributes: ['menu_id', 'view_perm', 'add_perm', 'update_perm', 'delete_perm', 'download_perm'],
                include: [
                    {
                        model: ActionPermissionModel,
                        attributes: ['id', 'parent_menu_id', 'menu_category', 'menu_name', 'action_url', 'icon', 'icon_path', 'view_perm', 'add_perm', 'update_perm', 'delete_perm', 'download_perm'],
                        where: { status: '1' },
                        required: false,
                    },
                ],
            });
            if (existData[0]) {


                const tasksWithCount = await Promise.all(existData.map(async (data) => {

                    return {
                        ...data.toJSON(),

                    };
                }));
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tasksWithCount,
                });
            }
            // Function to organize data hierarchy
            // const organizeDataHierarchy = (data) => {
            //     const organizedData = {};

            //     data.forEach((item) => {
            //         // console.log(item.dataValues.bg_mstr_role.dataValues.role_name)
            //         // const roleId = item.dataValues.bg_mstr_role.dataValues.role_name;
            //         const roleId = item.role_id;
            //         const menu_id = item.menu_id;

            //         if (!organizedData[roleId]) {
            //             organizedData[roleId] = {};
            //         }

            //         if (!organizedData[roleId][menu_id]) {
            //             organizedData[roleId][menu_id] = [];
            //         }

            //         organizedData[roleId][menu_id].push(item);
            //     });

            //     return organizedData;
            // };

            // Organize data into hierarchy
            // const organizedData = organizeDataHierarchy(existData);
            if (existData[0]) {
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}



const ActPermListAll = async (req, res) => {
    try {
        const AllowedUser = await userModel.findOne({
            where: {
                id: req.userId,
                permanent_sys_adm: "1",
            },
        });

        if (!AllowedUser) {
            return res.status(403).send({
                message: "You are not permitted",
                error: true,
                success: false,
                status: "0",
            });
        }

        const existData = await ActionPerm.findAll({
            where: { status: "1", user_comp_id: req.comp_id, },
            include: [
                {
                    model: Role,
                    attributes: ['role_name'],
                    where: { status: '1' },
                    required: false,
                },
            ],
        });

        // Function to organize data hierarchy
        const organizeDataHierarchy = (data) => {
            const organizedData = {};

            data.forEach((item) => {
                // console.log(item.dataValues.bg_mstr_role.dataValues.role_name)
                // const roleId = item.dataValues.bg_mstr_role.dataValues.role_name;
                const roleId = item.role_id;
                const menu_id = item.menu_id;

                if (!organizedData[roleId]) {
                    organizedData[roleId] = {};
                }

                if (!organizedData[roleId][menu_id]) {
                    organizedData[roleId][menu_id] = [];
                }

                organizedData[roleId][menu_id].push(item);
            });

            return organizedData;
        };

        // Organize data into hierarchy
        const organizedData = organizeDataHierarchy(existData);
        if (existData[0]) {
            res.send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: organizedData,
            });
        } else {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}



//Get Action Permission By Role ID and Module ID

const ActPermByRoleAndModuleId = async (req, res) => {

    const schema = Joi.object().keys({
        role_id: Joi.number().required(),
        menu_id: Joi.number().required(),
    });

    const dataToValidate = {
        role_id: req.body.role_id,
        menu_id: req.body.menu_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const AllowedUser = await userModel.findOne({
                where: {
                    id: req.userId,
                    permanent_sys_adm: "1",
                },
            });

            if (!AllowedUser) {
                return res.status(403).send({
                    message: "You are not permitted",
                    error: true,
                    success: false,
                    status: "0",
                });
            }

            const existData = await ActionPerm.findOne({
                where: { status: "1", user_comp_id: req.comp_id, role_id: req.body.role_id, menu_id: req.body.menu_id },
                include: [
                    {
                        model: Role,
                        attributes: ['role_name'],
                        where: { status: '1' },
                        required: false,
                    },

                ],
            });
            if (existData) {
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}





module.exports = {
    SetActionPermRole, ActPermByRoleID, ActPermByRoleAndModuleId, ActPermListAll
};    
