const Joi = require('joi');
require('dotenv').config();
const MenuPermissionModel = require('../../models/roleandpermission/MenuPermissionModel');
const MenuModel = require('../../models/Menu/MenuprmsModel')
const Role = require('../../models/master/Role');
const getCurrentDateTime = () => new Date();
const addMenuPermission = async (req, res) => {
    const schema = Joi.object().keys({
        role_id: Joi.number().required(),
        menu_ids: Joi.string().required(),
        created_at: Joi.date().iso().required(),
        created_by: Joi.number().required(),
        status: Joi.number().required(),
    });

    const dataToValidate = {
        role_id: req.body.role_id,
        menu_ids: req.body.menu_ids,
        created_at: getCurrentDateTime(),
        created_by: req.userId,
        status: '1',
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const menuPermission = await MenuPermissionModel.findOne({ where: { role_id: req.body.role_id }, attributes: ['id', 'role_id'] })
            if (!menuPermission) {
                const insert = await MenuPermissionModel.create(dataToValidate)
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Menu Permission added successfully',
                    error: false,
                    success: true,
                    status: '1',
                    data: insert,
                });
            }
            else {
                const updMenuPermObj = { menu_ids: req.body.menu_ids };
                const update = await MenuPermissionModel.update(updMenuPermObj, {
                    where: { id: req.body.role_id },
                });
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Menu Permission Updated Successfully',
                    error: true,
                    success: false,
                    status: '1',
                    data: update
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                // message: error.message,
                error: true,
                success: false,
                status: '0',
            });

            // res.status(400).send({ error: error.message });
        }
    }
};

//=====================================================================================

// Menu List
const menuPermissionList = async (req, res) => {
    try {


        const menus = await MenuPermissionModel.findAll({
            where: { status: '1' },
            attributes: ['id', 'menu_ids'],
            include: [
                {
                    model: Role,
                    attributes: ['role_name'],
                    where: { status: '1' },
                    required: false,
                }]
        })

        if (!menus) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: 'Record Not Found',
                error: true,
                success: false,
                status: '0',
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: 'Record Found',
            error: false,
            success: true,
            status: '1',
            data: menus,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            // message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });

        // res.status(400).send({ error: error.message });
    }
}

//edit Department
const editMenu = async (req, res) => {
    const schema = Joi.object().keys({
        menu_id: Joi.number().required(),
    });

    const dataToValidate = {
        menu_id: req.body.menu_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        try {
            const editMenu = await MenuMasterModel.findOne({
                where: { id: req.body.menu_id, status: '1' }, attributes: ['id', 'parent_menu_id', ['menu_name', 'sub_menu']],
                include: [
                    {
                        model: MenuMasterModel,
                        attributes: ['menu_name'],
                        as: 'parent_menu',
                        where: { status: '1' },
                        required: false,
                    }]
            })

            if (!editMenu) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: 'Record Not Found',
                    error: false,
                    success: true,
                    status: '0',
                    data: [],
                });
            }
            
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: 'Record Found',
                error: false,
                success: true,
                status: '1',
                data: editMenu,
            });
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                // message: error.message,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//update Menu
const updateMenu = async (req, res) => {
    const schema = Joi.object().keys({
        menu_id: Joi.number().required(),
        menu_name: Joi.string().required(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        menu_id: req.body.menu_id,
        menu_name: req.body.menu_name,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const updMenu = await MenuMasterModel.findOne({ where: { id: req.body.menu_id, status: '1' }, attributes: ['id', 'parent_menu_id'] })
            if (updMenu) {
                if (updMenu.parent_menu_id == 0) {
                    const existData_upd = await MenuMasterModel.findOne({ where: { status: "1", id: req.body.menu_id, menu_name: req.body.menu_name }, attributes: ['id'] });

                    if (existData_upd) {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECALREADYEXISTS,
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                    await MenuMasterModel.update(dataToValidate, {
                        where: { id: req.body.menu_id },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Menu updated successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
                else {
                    const existData_upd = await MenuMasterModel.findOne({ where: { status: "1", menu_name: req.body.menu_name, parent_menu_id: updMenu.parent_menu_id }, attributes: ['id'] });

                    if (existData_upd) {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECALREADYEXISTS,
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                    await MenuMasterModel.update(dataToValidate, {
                        where: { id: req.body.menu_id },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Menu updated successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}



//update Menu
const deleteMenu = async (req, res) => {
    const schema = Joi.object().keys({
        menu_id: Joi.number().required(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });
    const dataToValidate = {
        menu_id: req.body.menu_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const updateData = {
            status: '0',
            modified_by: req.userId,
            updated_at: getCurrentDateTime(),
        }
        try {
            const updMenu = await MenuMasterModel.findOne({ where: { id: req.body.menu_id, status: '1' }, attributes: ['id', 'parent_menu_id'] })
            if (updMenu) {
                if (updMenu.parent_menu_id == 0) {
                    const existData_upd = await MenuMasterModel.findOne({ where: { status: "1", id: req.body.menu_id }, attributes: ['id'] });

                    if (!existData_upd) {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            // message: process.env.APIRESPMSG_RECNOTFOUND,
                            message: "inside if",
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                    await MenuMasterModel.update(updateData, {
                        where: { id: req.body.menu_id },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Menu Deleted successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
                else {
                    const existData_upd = await MenuMasterModel.findOne({ where: { status: "1", parent_menu_id: updMenu.parent_menu_id }, attributes: ['id'] });

                    if (!existData_upd) {
                        return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            message: process.env.APIRESPMSG_RECNOTFOUND,
                            error: true,
                            success: false,
                            status: '0',
                        });
                    }
                    await MenuMasterModel.update(updateData, {
                        where: { id: req.body.menu_id },
                    });
                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: 'Menu Deleted successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0',
                });

            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: error.message,
                // message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}

//set menu permission
const SetMenuAccess = async (req, res) => {
    // Base schema definition

    const baseSchema = {
        role_id: Joi.number().required(),
        menu_id: Joi.string().required(),
        created_by: Joi.number().required(),
        user_comp_id: Joi.number().required()
    };

    // Function to create dynamic schema based on event_name
    const createDynamicSchema = (eventName) => {
        const dynamicSchema = {
            ...baseSchema,
            [eventName]: Joi.string().required(), // Ensure max length is within DB column limit
        };
        return Joi.object(dynamicSchema);
    };

    // Function to create dataToValidate dynamically
    const eventName = req.body.event_name;

    const createDataToValidate = (eventName) => {

        const dataToValidate = {
            role_id: req.body.role_id,
            menu_id: req.body.menu_id,
            user_comp_id: req.comp_id,
            created_by: req.userId,
        };
        // Only add the eventName key to dataToValidate
        dataToValidate[eventName] = '1';
        return dataToValidate;
    };
    // Validate the data only if eventName is provided
    if (!eventName) {
        return res.status(400).json({ error: true, message: 'Event name is required.' });
    }
    const dataToValidate = createDataToValidate(eventName);
    // Generate the dynamic schema based on event_name
    const dynamicSchema = createDynamicSchema(eventName);
    const result = dynamicSchema.validate(dataToValidate);

    if (result.error) {
        return res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const menuPermission = await MenuPermissionModel.findOne({ where: { role_id: dataToValidate?.role_id, menu_id: dataToValidate?.menu_id, status: '1' } });
            if (!menuPermission) {
                 
                // Insert new record if not found
                const getExistingPermission = await MenuModel.findOne({
                    where: {id: dataToValidate?.menu_id, status:"1"},
                    attributes: ['is_view', 'is_add', 'is_update', 'is_delete']
                }) 

                const insertObj = {
                    role_id: req.body.role_id,
                    menu_id: req.body.menu_id,
                    user_comp_id: req.comp_id,
                    created_by: req.userId,
                    is_view: (eventName == 'is_view') ? '1' : getExistingPermission.is_view,
                    is_add: (eventName == 'is_add') ? '1' : getExistingPermission.is_add,
                    is_update: (eventName == 'is_update') ? '1' : getExistingPermission.is_update,
                    is_delete: (eventName == 'is_delete') ? '1' : getExistingPermission.is_delete,
                }
                
                const insert = await MenuPermissionModel.create(insertObj);
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Menu access allowed successfully',
                    error: false,
                    success: true,
                    status: '1',
                    data: insert,
                });
            } else {
                // Update existing record
                const valueOfEventName = menuPermission[eventName];
                // Toggle the value
                const toggledValue = valueOfEventName === '0' ? '1' : '0';
                const updatedata = {
                    [eventName]: toggledValue
                };
                await MenuPermissionModel.update(updatedata, { where: { id: menuPermission.id, status: '1', role_id: dataToValidate?.role_id } }); // Update the record
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: 'Menu access status updated successfully',
                    error: false,
                    success: true,
                    status: '1',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};

// Menu List
const GetMenuAccessList = async (req, res) => {
    const schema = Joi.object().keys({
        role_id: Joi.number().required(),
    });
    const dataToValidate = {
        role_id: req?.body.role_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const menupermissionlist = await MenuModel.findAll({
                where: { status: '1' },
                order: [['id','ASC']],
                attributes: ['id','parent_menu_id', 'menu_name', 'action_url', 'icon_path', 'active_icon'],
                include: {
                    model: MenuPermissionModel,
                    where: { role_id: dataToValidate?.role_id, status: '1', user_comp_id: req.comp_id },
                    required: false,
                    attributes: ['id', 'menu_id', 'is_view', 'is_add', 'is_update', 'is_delete']
                },
            })
            const menulist = await MenuModel.findAll({
                where: { status: '1' },
                order: [['id','ASC']],
                attributes: ['id','parent_menu_id', 'menu_name', 'action_url', 'icon_path', 'active_icon', 'is_view', 'is_add', 'is_update', 'is_delete'],
            })
            const fs_preparetion_data = [];
            const tasksWithCount = await Promise.all(menulist.map(async (data) => {
                const { dataValues, bg_mstr_menus } = data;
                const permissions = await MenuPermissionModel.findOne({
                    where: { menu_id: data.dataValues.id, status: '1', role_id:dataToValidate?.role_id }
                })

                if (permissions) {
                    data.dataValues.is_view = permissions.is_view;
                    data.dataValues.is_add = permissions.is_add;
                    data.dataValues.is_update = permissions.is_update;
                    data.dataValues.is_delete = permissions.is_delete;
                }


                if (data.dataValues) {
                    fs_preparetion_data.push({
                        ...data.toJSON()
                    });
                }

            }));

            fs_preparetion_data.sort((a, b) => a.id - b.id);

            if (!menupermissionlist[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: fs_preparetion_data,
                });
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


module.exports = {
    addMenuPermission, menuPermissionList, SetMenuAccess, GetMenuAccessList,
};   