const Widgets = require("../../models/roleandpermission/Widgets");
const WidgetPerm = require("../../models/roleandpermission/WidgetPerm");
const Role = require("../../models/master/Role");

const Joi = require('joi');
require('dotenv').config();
const getCurrentDateTime = () => new Date();
//Widget List..
const widgetList = async (req, res) => {
    try {
        const widgetsAll = await Widgets.findAll({
            where: { status: '1' },
            attributes: ['id', 'widget_name', 'status'],
        })

        if (!widgetsAll[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });
        }

        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: widgetsAll,
        });

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}



//Update Letter Code...
const SetWidgetsPermRole = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        role_id: Joi.number().required(),
        widget_id: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        role_id: req.body.role_id,
        widget_id: req.body.widget_id,
        created_by: req.userId,
        created_at: getCurrentDateTime()
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existingRecords = [];
            const recordsToCreate = [];
            const existData = await Role.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.role_id }, attributes: ['id'] });
            if (existData) {
                const delimiter = ',';
                const response_data = dataToValidate.widget_id.split(delimiter);
                for (const data of response_data) {
                    const existingRecord = await WidgetPerm.findOne({ where: { user_comp_id: req.comp_id, role_id: req.body.role_id, widget_id: data, status: '1' } });
                    if (existingRecord) {
                        existingRecords.push(existingRecord);
                    } else {
                        recordsToCreate.push({
                            user_comp_id: req.comp_id,
                            role_id: req.body.role_id,
                            widget_id: data,
                            created_by: req.userId,
                            created_at: getCurrentDateTime(),
                        });
                    }
                }
                if (recordsToCreate.length > 0) {
                    const WidInsertRecords = await WidgetPerm.bulkCreate(recordsToCreate);
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: `${WidInsertRecords.length} Records inserted successfully`,
                        error: false,
                        success: true,
                        status: '1',
                    });
                } else {
                    return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: "Role ID Invalid.",
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}





//Delete Widget on Role...
const DelWidgetsPerm_onRole = async (req, res) => {

    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        role_id: Joi.number().required(),
        widget_id: Joi.number().required(),
        modified_by: Joi.number().allow(),
        updated_at: Joi.date().iso().allow(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        role_id: req.body.role_id,
        widget_id: req.body.widget_id,
        modified_by: req.userId,
        updated_at: getCurrentDateTime(),
    };

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await WidgetPerm.findOne({ where: { status: "1", user_comp_id: req.comp_id, role_id: req.body.role_id, widget_id: req.body.widget_id }, attributes: ['id'] });
            if (existData) {
                const UpdateDataArr = {
                    status: "0",
                    updated_at: getCurrentDateTime(),
                    modified_by: req.userId,
                }

                const update = await WidgetPerm.update(UpdateDataArr, {
                    where: { status: "1", user_comp_id: req.comp_id, role_id: req.body.role_id, widget_id: req.body.widget_id }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            // res.status(500).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}



//edit Department
const GetWidgetsListRole = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        role_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        role_id: req.body.role_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const recdData = await WidgetPerm.findAll({
                where: { status: "1", user_comp_id: req.comp_id, role_id: req.body.role_id },
                attributes: ['id', 'role_id', 'widget_id'],
                include: [
                    {
                        model: Role,
                        attributes: ['role_name'],
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: Widgets,
                        attributes: ['widget_name'],
                        where: { status: '1' },
                        required: false,
                    },
                ],
            })

            if (!recdData[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: false,
                    success: true,
                    status: '0',
                });
            } else {
                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: recdData,
                });
            }

        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                // error: true,
                success: false,
                status: '0',
            });
        }
    }
}


//Get All Widgets List on Role..
const AllWidgetsListOnRole = async (req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const recdData = await WidgetPerm.findAll({
                where: { status: "1", user_comp_id: req.comp_id },
                attributes: ['id', 'role_id', 'widget_id'],
                include: [
                    {
                        model: Role,
                        attributes: ['role_name'],
                        where: { status: '1' },
                        required: false,
                    },
                    {
                        model: Widgets,
                        attributes: ['widget_name'],
                        where: { status: '1' },
                        required: false,
                    },
                ],
            })

            if (!recdData) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: false,
                    success: true,
                    status: '0',
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: recdData,
            });
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });

        }
    }
}



module.exports = {
    widgetList, SetWidgetsPermRole, DelWidgetsPerm_onRole, GetWidgetsListRole, AllWidgetsListOnRole
};    
