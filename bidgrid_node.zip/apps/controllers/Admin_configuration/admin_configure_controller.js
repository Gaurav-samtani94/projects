const Joi = require('joi');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const url = require('url')
const { Sequelize, DataTypes, where, Op, fn, col, literal, Model } = require('sequelize');
const MisTenderCycleAssignInactionModel = require('../../models/tender/MisTenderCycleAssignInactionModel');
const inaction = require('../../models/master/TenderCycleInactionModel');
const Tenderscope = require('../../models/master/TenderScope');
const TenderStatus = require('../../models/master/TenderStatus');
const getCurrentDateTime = () => new Date();

const addTndrAssignActionOnMisCycle = async(req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        cycle_id: Joi.number().required(),
        inaction_id: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        cycle_id: req.body.cycle_id,
        inaction_id: req.body.inaction_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            
            const InactionIds = req.body.inaction_id.split(',');

            await Promise.all(InactionIds.map(async (item, index) => {
                const insertObj = { user_comp_id: req.comp_id,
                    cycle_id: req.body.cycle_id,
                    inaction_id: item,
                    created_by: req.userId,
                    created_at: getCurrentDateTime() }
                const tndrAssignAction = await MisTenderCycleAssignInactionModel.create(insertObj);
            }))

            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECINSERTED,
                error: false,
                success: true,
                status: '1',
                // data: tndrAssignAction
            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const updateTndrAssignActionOnMisCycle = async(req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        cycle_id: Joi.number().required(),
        inaction_id: Joi.string().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        cycle_id: req.body.cycle_id,
        inaction_id: req.body.inaction_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const checkExist = await MisTenderCycleAssignInactionModel.findAll({
                where: { cycle_id: req.body.cycle_id, status: '1', user_comp_id:req.comp_id }
            })

            if(checkExist[0]) {

                await MisTenderCycleAssignInactionModel.destroy({
                    where: { user_comp_id: req.comp_id, cycle_id: req.body.cycle_id, status: '1' },
                });
                
                const InactionIds = req.body.inaction_id.split(',').map(id => parseInt(id.trim(), 10));

                const fileRecords = await MisTenderCycleAssignInactionModel.bulkCreate(InactionIds.map((inActionId) => (
                    {
                        user_comp_id: req.comp_id, cycle_id: req.body.cycle_id, inaction_id:inActionId, created_by: req.userId,
                        created_at: getCurrentDateTime()
                    }
                )));

                if (!fileRecords[0]) {
                    return res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                        message: process.env.ERROR_MSG,
                        error: true,
                        success: false,
                        status: '0',
                    })
                }
           
                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                });

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    // data: tndrAssignAction
                });

            }

                
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


// Get Inaction Ids By Cycle ID
const inActionsByCycleId = async(req, res) => {
    const schema = Joi.object().keys({
        user_comp_id: Joi.number().required(),
        cycle_id: Joi.number().required(),
    });

    const dataToValidate = {
        user_comp_id: req.comp_id,
        cycle_id: req.body.cycle_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const cycleId = await Tenderscope.findOne({
                where: { status: '1', order_sr: 8, user_comp_id: req.comp_id },
                attributes: ['id', 'cycle_name', 'order_sr']
            })
            
            if (cycleId.id == req.body.cycle_id) {
                
                var tndrAssignAction = await MisTenderCycleAssignInactionModel.findAll({
                    where: { cycle_id: req.body.cycle_id, status: '1', user_comp_id:req.comp_id },
                    attributes:['id', 'cycle_id', 'inaction_id'],
                    include: [
                        {
                            model: inaction,
                            attributes: ['inaction_name', 'image_name'],
                            where: { status: '1' },
                            required: false,
                        },
                    ]
                })

                // console.log(tndrAssignAction.length,"========23=33333333=3=3===========")
            } else {
                const tenderstatusId = await TenderStatus.findOne({
                    order: [['id', 'ASC']],
                    where: { id:req.body.cycle_id ,status: '1', user_comp_id: req.comp_id },
                    attributes: ['id', 'status_name']
                })

                if(!tenderstatusId) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: false,
                        success: true,
                        status: '1',
                        // data: tndrAssignAction
                    });
                }
                
                var tndrAssignAction = await MisTenderCycleAssignInactionModel.findAll({
                    where: { cycle_id: tenderstatusId.id, status: '1', user_comp_id:req.comp_id },
                    attributes:['id', 'cycle_id', 'inaction_id'],
                    include: [
                        {
                            model: inaction,
                            attributes: ['inaction_name', 'image_name'],
                            where: { status: '1' },
                            required: false,
                        },
                    ]
                })
            }

            if(tndrAssignAction[0]) {

                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: tndrAssignAction
                });

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    // data: tndrAssignAction
                });

            }                
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                // message: error.message,
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

module.exports = { addTndrAssignActionOnMisCycle, updateTndrAssignActionOnMisCycle, inActionsByCycleId }