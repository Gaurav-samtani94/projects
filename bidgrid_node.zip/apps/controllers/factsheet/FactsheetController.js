const { Sequelize, DataTypes, where, Op, fn, col } = require('sequelize');
const Joi = require('joi')
require('dotenv').config()
var express = require('express');
const bodyParser = require('body-parser');


const fstypemasters = require('../../models/factsheet/fstypemasters')

const fstypeassigncomps = require('../../models/factsheet/fstypeassigncomps')
const fsdescmasters = require('../../models/factsheet/fsdescmasters')
const fsdescassigncomps = require('../../models/factsheet/fsdescassigncomps')
const fsinputtypemasters = require('../../models/factsheet/fsinputtypemasters')
const fsdescremarks = require('../../models/factsheet/fsdescremarks')
const fsuploadedfiles = require('../../models/factsheet/fsuploadedfiles')
const fspreparationtemplates = require('../../models/factsheet/fspreparationtemplates')
const fsmaingeneratedfiles = require('../../models/factsheet/fsmaingeneratedfiles')

const createTenderModel = require('../../../apps/models/tender/TenderModel');
const TenderGeneratedTypeIdModel = require('../../../apps/models/tender/TenderGeneratedTypeIdModel');
const TenderAssignManagerModel = require('../../../apps/models/tender/TenderAssignManagerModel');
const TenderBdRoleModel = require('../../models/master/TenderBdRoleModel');
const Users = require('../../models/Users');


const Country = require('../../models/master/Country');
const State = require('../../models/master/State');
const City = require('../../models/master/City');
const TenderClient = require('../../models/master/TenderClient');

const comp_main_users = require('../../models/Main_company')
const comp_logo = require('../../models/master/CompanyLogoModel')


const getCurrentDateTime = () => new Date()
const multer = require('multer')
const fs = require('fs')
const path = require('path')
const os = require('os');


//get fs type mstr list
const getfstypemstrList = async (req, res) => {
    try {
        const fs_type_mstr_list = await fstypeassigncomps.findAll({
            order: [['id', 'ASC']],
            where: { status: '1', user_comp_id:req.comp_id},
            attributes: ['id', 'type_name'],
        });

        if (fs_type_mstr_list[0]) {
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: fs_type_mstr_list

            });
        } else {
            res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0',
            });

        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });

    }
}


//get fs desc assign comp
const getfsdescassigncompList = async (req, res) => {
    const schema = Joi.object().keys({
        type_id: Joi.number().required(),
        project_id: Joi.number().required(),
    });

    const dataToValidate = {
        type_id: req.body.type_id,
        project_id:req.body.project_id,
    };

    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const fs_desc_assign_comp_list = await fstypeassigncomps.findAll({
                where: { status: '1', user_comp_id:req.comp_id, id:req.body.type_id},
                attributes: ['id', 'type_name_id', 'type_name'],
                include:[ 
                    {
                        model: fstypemasters,
                        attributes: ['id','fs_type_name'],
                        where: { status: '1'},
                        required: false,
                    },
                    {
                    model: fsdescassigncomps,
                    order: ['id', 'ASC'],
                    attributes: ['id', 'desc_name_id','desc_name', 'sr_no', 'input_type'],
                    where: { status: '1',user_comp_id:req.comp_id },
                    required: false,
                    include:[
                        {
                            model: fsdescmasters,
                            attributes: ['id','desc_name'],
                            where: { status: '1'},
                            required: false,
                        },
                        {
                            model: fsinputtypemasters,
                            attributes: ['fs_input_type'],
                            where: { status: '1'},
                            required: false,
                        },
                        {
                            model: fsdescremarks,
                            attributes: ['desc_remark_data'],
                            where: { status: '1', user_comp_id:req.comp_id},
                            required: false,
                        }
                    ],
                }]
            });
        
            if (fs_desc_assign_comp_list.length>0) {
                const result_arr = [];
                var select_arr = [];
                var tenderdata = [];
                var desc_remark_data = [];
                var fs_desc_assign_comps=[];
                const fs_desc_assign_comp_arr = await Promise.all(fs_desc_assign_comp_list.map(async (fs_desc_assign_comp_row) => {
                    await Promise.all(fs_desc_assign_comp_row['fs_desc_assign_comps'].map(async (fs_desc_assign_comp_rowss) => {
                        if(dataToValidate.project_id){
                            const TenderModel = createTenderModel(req.comp_id);
                            await TenderModel.performOperation();
                            tenderdata = await TenderModel.findOne({
                                where:{ status: '1', user_comp_id: req.comp_id, id:dataToValidate.project_id },
                                attributes: ['id', 'tender_name', 'client_id','client_cont_person','client_cont_address','country_id', 'pre_bid_meeting_date','state_id','city_id','tnd_ref_id', 'tender_gov_id', 'tender_cost', 'tender_emd_amnt_val', 'submission_start_date', 'submission_end_date'],
                            })
                            if(tenderdata){
                                if(fs_desc_assign_comp_rowss.desc_name_id == 3){
                                    select_arr = [];
                                    desc_remark_data = tenderdata.tender_name;
                                }
                                else if(fs_desc_assign_comp_rowss.desc_name_id == 4){
                                    select_arr  = await Country.findAll({
                                        attributes: ['id',['country_name', 'select_name']],
                                        where: { status: '1' },
                                    })
                                    desc_remark_data = tenderdata.country_id
                                }
                                else if(fs_desc_assign_comp_rowss.desc_name_id == 7){
                                    select_arr  = await State.findAll({
                                        attributes: ['id',['state_name', 'select_name'],['country_id', 'select_id']],
                                        where: { status: '1' },
                                    })
                                    desc_remark_data = tenderdata.state_id
                                }
                                else if(fs_desc_assign_comp_rowss.desc_name_id == 8){
                                    select_arr  = await City.findAll({
                                        attributes: ['id',['city_name', 'select_name'],['state_id', 'select_id']],
                                        where: { status: '1' },
                                    })
                                    desc_remark_data = tenderdata.city_id
                                }
                                else if(fs_desc_assign_comp_rowss.desc_name_id == 9){
                                    select_arr  = [];
                                    desc_remark_data = tenderdata.tender_cost
                                }
                                else if(fs_desc_assign_comp_rowss.desc_name_id == 14){
                                    select_arr  = [];
                                    desc_remark_data = tenderdata.pre_bid_meeting_date
                                }
                                else if(fs_desc_assign_comp_rowss.desc_name_id == 19){
                                    select_arr  = [];
                                    desc_remark_data = tenderdata.submission_end_date
                                }
                                else if(fs_desc_assign_comp_rowss.desc_name_id == 21){
                                    select_arr  = await TenderClient.findAll({
                                        attributes: ['id',['client_name', 'select_name']],
                                        where: { status: '1' },
                                    })
                                    desc_remark_data = tenderdata.client_id
                                }
                                else if(fs_desc_assign_comp_rowss.desc_name_id == 22){
                                    select_arr  = [];
                                    desc_remark_data = tenderdata.client_cont_person
                                }
                                else if(fs_desc_assign_comp_rowss.desc_name_id == 23){
                                    select_arr  = [];
                                    desc_remark_data = tenderdata.client_cont_address
                                }
                                else{
                                    select_arr = [];
                                    if(fs_desc_assign_comp_rowss.fs_desc_remark){
                                        desc_remark_data = fs_desc_assign_comp_rowss.fs_desc_remark;
                                    }
                                    else{
                                        desc_remark_data = '';
                                    }
                                }
                            }
                            else{
                                select_arr = [];
                                if(fs_desc_assign_comp_rowss.fs_desc_remark){
                                    desc_remark_data = fs_desc_assign_comp_rowss.fs_desc_remark;
                                }
                                else{
                                    desc_remark_data = '';
                                }
                            }
                        }
                        else{
                            select_arr = [];
                            if(fs_desc_assign_comp_rowss.fs_desc_remark){
                                desc_remark_data = fs_desc_assign_comp_rowss.fs_desc_remark;
                            }
                            else{
                                desc_remark_data = '';
                            }
                            
                        }
                        fs_desc_assign_comps.push({
                            "id": fs_desc_assign_comp_rowss.id,
                            "desc_name_id": fs_desc_assign_comp_rowss.desc_name_id,
                            "desc_name": fs_desc_assign_comp_rowss.desc_name,
                            "sr_no": fs_desc_assign_comp_rowss.sr_no,
                            "input_type": fs_desc_assign_comp_rowss.input_type,
                            "fs_desc_master": fs_desc_assign_comp_rowss.fs_desc_master,
                            "fs_input_type": fs_desc_assign_comp_rowss.fs_input_type,
                            "select_box_data": select_arr,
                            "fs_desc_remark": desc_remark_data
                        });
                        
                    }));
                    result_arr.push({
                        "id": fs_desc_assign_comp_row.id,
                        "type_name_id": fs_desc_assign_comp_row.type_name_id,
                        "type_name": fs_desc_assign_comp_row.type_name,
                        "fs_type_masters": fs_desc_assign_comp_row['fs_type_master'],
                        "fs_desc_assign_comps":fs_desc_assign_comps
                        //"desc_name_id": fs_desc_assign_comp_rowss.desc_name_id,
                       // "desc_name": fs_desc_assign_comp_rowss.desc_name,
                        //"fs_desc_master": fs_desc_assign_comp_rowss.fs_desc_master.desc_name,
                       // "fs_input_type": fs_desc_assign_comp_rowss.fs_input_type.fs_input_type,
                        //"select_arr": select_arr,
                       // "desc_remark_data": desc_remark_data,
                    })

                }));
                if(result_arr.length>0){
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECFOUND,
                        error: false,
                        success: true,
                        status: '1',
                        data: result_arr,
                       // data1:fs_desc_assign_comp_list
        
                    });
                }
              
            } else {
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
    
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
    
        }
    }
}


//add fs desc remarks
const addfsdescramarks = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        desc_remark_id: Joi.number().required(),
        desc_remark_data: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        desc_remark_id: req.body.desc_remark_id,
        desc_remark_data: req.body.desc_remark_data,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const fs_desc_assign_existence = await fsdescassigncomps.findOne({ 
                where: { 
                    id: req.body.desc_remark_id, 
                    user_comp_id: req.comp_id,
                    status: '1' 
                },
                attributes: ['id','desc_name_id'] 
            })
            if(fs_desc_assign_existence){
                if(!fs_desc_assign_existence.desc_name_id){
                    const fs_desc_remark_existence = await fsdescremarks.findOne({ 
                        where: { project_id: req.body.project_id, desc_remark_id: req.body.desc_remark_id, status: '1',user_comp_id:req.comp_id },
                        attributes: ['id','project_id','desc_remark_id','desc_remark_data']  
                    })
                    if(!fs_desc_remark_existence){
                        const insert = await fsdescremarks.create(dataToValidate)
                        if(insert){
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECINSERTED,
                                error: false,
                                success: true,
                                status: '1',
                                data: insert,
                            });
                        }
                    }
                    else{
                        const existData_upd = await fsdescremarks.findOne({
                            where: {
                                status: "1",
                                user_comp_id: req.comp_id,
                                desc_remark_id: req.body.desc_remark_id,
                                desc_remark_data: req.body.desc_remark_data,
                                project_id: req.body.project_id,
                            },
                            attributes: ['id']
                        });
        
                        if (existData_upd) {
                            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                message: process.env.APIRESPMSG_RECALREADYEXISTS,
                                error: true,
                                success: false,
                                status: '0',
                            });
                        }

                        const fs_desc_remark_update_obj = {
                            desc_remark_data: req.body.desc_remark_data,
                            modified_by: req.userId,
                            updated_at: getCurrentDateTime(),
                        }
                        const update_fs_desc_remark = await fsdescremarks.update(fs_desc_remark_update_obj, {
                            where: { status: "1", project_id: req.body.project_id, desc_remark_id: req.body.desc_remark_id, user_comp_id: req.comp_id },
                        });
                        if(update_fs_desc_remark){
                            return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.APIRESPMSG_RECUPDATED,
                                error: false,
                                success: true,
                                status: '1',
                                data: update_fs_desc_remark
                            });
                        }
                    }
                }else{
                    const TenderModel = createTenderModel(req.comp_id);
                    await TenderModel.performOperation();
                    tenderdata = await TenderModel.findOne({
                        where:{ status: '1', user_comp_id: req.comp_id, id:dataToValidate.project_id },
                        attributes: ['id', 'tender_name', 'client_id','client_cont_person','client_cont_address','country_id', 'pre_bid_meeting_date','state_id','city_id','tnd_ref_id', 'tender_gov_id', 'tender_cost', 'tender_emd_amnt_val', 'submission_start_date', 'submission_end_date'],
                    })
                    if(tenderdata){
                        if(fs_desc_assign_existence.desc_name_id == 3){
                            const fs_tndr_name_desc_remark_update_obj = {
                                tender_name: req.body.desc_remark_data,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const update_tndr_name_fs_desc_remark = await TenderModel.update(fs_tndr_name_desc_remark_update_obj, {
                                where: { status: "1", id: req.body.project_id, user_comp_id: req.comp_id },
                            });
                            if(update_tndr_name_fs_desc_remark){
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECUPDATED,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: update_tndr_name_fs_desc_remark
                                });
                            }
                        }
                        else if(fs_desc_assign_existence.desc_name_id == 4){
                            const fs_tndr_name_desc_remark_update_obj = {
                                country_id: req.body.desc_remark_data,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const update_tndr_name_fs_desc_remark = await TenderModel.update(fs_tndr_name_desc_remark_update_obj, {
                                where: { status: "1", id: req.body.project_id, user_comp_id: req.comp_id },
                            });
                            if(update_tndr_name_fs_desc_remark){
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECUPDATED,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: update_tndr_name_fs_desc_remark
                                });
                            }
                        }
                        else if(fs_desc_assign_existence.desc_name_id == 7){
                            const fs_tndr_name_desc_remark_update_obj = {
                                state_id: req.body.desc_remark_data,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const update_tndr_name_fs_desc_remark = await TenderModel.update(fs_tndr_name_desc_remark_update_obj, {
                                where: { status: "1", id: req.body.project_id, user_comp_id: req.comp_id },
                            });
                            if(update_tndr_name_fs_desc_remark){
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECUPDATED,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: update_tndr_name_fs_desc_remark
                                });
                            }
                        }
                        else if(fs_desc_assign_existence.desc_name_id == 8){
                            const fs_tndr_name_desc_remark_update_obj = {
                                city_id: req.body.desc_remark_data,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const update_tndr_name_fs_desc_remark = await TenderModel.update(fs_tndr_name_desc_remark_update_obj, {
                                where: { status: "1", id: req.body.project_id, user_comp_id: req.comp_id },
                            });
                            if(update_tndr_name_fs_desc_remark){
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECUPDATED,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: update_tndr_name_fs_desc_remark
                                });
                            }
                        }
                        else if(fs_desc_assign_existence.desc_name_id == 9){
                            const fs_tndr_name_desc_remark_update_obj = {
                                tender_cost: req.body.desc_remark_data,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const update_tndr_name_fs_desc_remark = await TenderModel.update(fs_tndr_name_desc_remark_update_obj, {
                                where: { status: "1", id: req.body.project_id, user_comp_id: req.comp_id },
                            });
                            if(update_tndr_name_fs_desc_remark){
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECUPDATED,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: update_tndr_name_fs_desc_remark
                                });
                            }
                        }
                        else if(fs_desc_assign_existence.desc_name_id == 14){
                            const fs_tndr_name_desc_remark_update_obj = {
                                pre_bid_meeting_date: req.body.desc_remark_data,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const update_tndr_name_fs_desc_remark = await TenderModel.update(fs_tndr_name_desc_remark_update_obj, {
                                where: { status: "1", id: req.body.project_id, user_comp_id: req.comp_id },
                            });
                            if(update_tndr_name_fs_desc_remark){
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECUPDATED,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: update_tndr_name_fs_desc_remark
                                });
                            }
                        }
                        else if(fs_desc_assign_existence.desc_name_id == 19){
                            const fs_tndr_name_desc_remark_update_obj = {
                                submission_end_date: req.body.desc_remark_data,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const update_tndr_name_fs_desc_remark = await TenderModel.update(fs_tndr_name_desc_remark_update_obj, {
                                where: { status: "1", id: req.body.project_id, user_comp_id: req.comp_id },
                            });
                            if(update_tndr_name_fs_desc_remark){
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECUPDATED,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: update_tndr_name_fs_desc_remark
                                });
                            }
                        }
                   
                        else if(fs_desc_assign_existence.desc_name_id == 21){
                            const fs_tndr_name_desc_remark_update_obj = {
                                client_id: req.body.desc_remark_data,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const update_tndr_name_fs_desc_remark = await TenderModel.update(fs_tndr_name_desc_remark_update_obj, {
                                where: { status: "1", id: req.body.project_id, user_comp_id: req.comp_id },
                            });
                            if(update_tndr_name_fs_desc_remark){
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECUPDATED,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: update_tndr_name_fs_desc_remark
                                });
                            }
                        }
                        else if(fs_desc_assign_existence.desc_name_id == 23){
                            const fs_tndr_name_desc_remark_update_obj = {
                                client_cont_address: req.body.desc_remark_data,
                                modified_by: req.userId,
                                updated_at: getCurrentDateTime(),
                            }
                            const update_tndr_name_fs_desc_remark = await TenderModel.update(fs_tndr_name_desc_remark_update_obj, {
                                where: { status: "1", id: req.body.project_id, user_comp_id: req.comp_id },
                            });
                            if(update_tndr_name_fs_desc_remark){
                                return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                    message: process.env.APIRESPMSG_RECUPDATED,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: update_tndr_name_fs_desc_remark
                                });
                            }
                        }
                        else{
                            const fs_desc_remark_existence = await fsdescremarks.findOne({ 
                                where: { project_id: req.body.project_id, desc_remark_id: req.body.desc_remark_id, status: '1',user_comp_id:req.comp_id },
                                attributes: ['id','project_id','desc_remark_id','desc_remark_data']  
                            })
                            if(!fs_desc_remark_existence){
                                const insert = await fsdescremarks.create(dataToValidate)
                                if(insert){
                                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: process.env.APIRESPMSG_RECINSERTED,
                                        error: false,
                                        success: true,
                                        status: '1',
                                        data: insert,
                                    });
                                }
                            }
                            else{
                                const existData_upd = await fsdescremarks.findOne({
                                    where: {
                                        status: "1",
                                        user_comp_id: req.comp_id,
                                        desc_remark_id: req.body.desc_remark_id,
                                        desc_remark_data: req.body.desc_remark_data,
                                        project_id: req.body.project_id,
                                    },
                                    attributes: ['id']
                                });
                
                                if (existData_upd) {
                                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                                        error: true,
                                        success: false,
                                        status: '0',
                                    });
                                }
        
                                const fs_desc_remark_update_obj = {
                                    desc_remark_data: req.body.desc_remark_data,
                                    modified_by: req.userId,
                                    updated_at: getCurrentDateTime(),
                                }
                                const update_fs_desc_remark = await fsdescremarks.update(fs_desc_remark_update_obj, {
                                    where: { status: "1", project_id: req.body.project_id, desc_remark_id: req.body.desc_remark_id, user_comp_id: req.comp_id },
                                });
                                if(update_fs_desc_remark){
                                    return res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                        message: process.env.APIRESPMSG_RECUPDATED,
                                        error: false,
                                        success: true,
                                        status: '1',
                                        data: update_fs_desc_remark
                                    });
                                }
                            }
                        }
                    }
                   
                }
                  
            }
            else{
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
         

        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}


const live_factsheet_doc_storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'factsheet' + '/' + year + '/' + month + '/' + day + '/' + req.userId + '-' + req.comp_id; 
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + 'factsheet_' + Math.random() + extension); // Rename file with a timestamp
    }
});


const fs_doc_upload = multer({ 
    storage: live_factsheet_doc_storage,
});

//add fs desc remarks document
const addfsdescramarkdoc = async (req, res) => {

    fs_doc_upload.array('files')(req, res, async function (err) {

        const schema = Joi.object().keys({
            project_id: Joi.number().required(),
            desc_remark_id: Joi.number().required(),
            user_comp_id: Joi.number().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required()
        });

        const dataToValidate = {
            project_id: req.body.project_id,
            desc_remark_id: req.body.desc_remark_id,
            user_comp_id: req.comp_id,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };

        const result = schema.validate(dataToValidate);

        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        } else {
            try {
                const fs_desc_assign_existence = await fsdescassigncomps.findOne({ 
                    where: { id: req.body.desc_remark_id, user_comp_id: req.comp_id, status: '1' },
                    attributes: ['id'] 
                })
                if(fs_desc_assign_existence){
                    const files = req.files;
                    if (files) {
                        console.log(fs_desc_assign_existence)
                        const originalFolderPath = files[0].destination;
                        
                        const newNumber = req.body.project_id;
                        const pathSegments = originalFolderPath.split('/');
                        pathSegments.pop();
                        const newFolderPath = path.join(pathSegments.join('/'), newNumber);
                        if (!fs.existsSync(newFolderPath)) {
                            fs.mkdirSync(newFolderPath);
                        }
                        files.forEach((file) => {
                            const oldPath = path.join(originalFolderPath, file.filename);
                            const newPath = path.join(newFolderPath, file.filename);
                            fs.rename(oldPath, newPath, (err) => {
                            });
                        });
                        const fileRecords = await fsuploadedfiles.bulkCreate(files.map((file) =>
                        ({
                            created_by: req.userId, user_comp_id: req.comp_id, project_id: req.body.project_id,desc_remark_id: req.body.desc_remark_id,
                            file_name: file.filename, file_path: newFolderPath, created_at: getCurrentDateTime()
                        })));
                        if (fileRecords.length > 0) {
                            const docDownloadLink = "https://web.growthgrids.com/";
                            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: `${fileRecords.length} records inserted successfully`,
                                error: false,
                                success: true,
                                status: '1',
                                data: (docDownloadLink) ? docDownloadLink + newFolderPath + '/' + files[0]['filename'] : "-"
                            });
                        }

                    }
                }
                else{
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            

            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                });
            }
        }

    });
}


//fs preparation template
const fspreparationtemplate = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const tenderdata = await TenderModel.findOne({
                where:{ status: '1', user_comp_id: req.comp_id, id:dataToValidate.project_id },
                attributes: ['id', 'tender_name', 'client_id','client_cont_person','client_cont_address','country_id', 'pre_bid_meeting_date','state_id','city_id','tnd_ref_id', 'tender_gov_id', 'tender_cost', 'tender_emd_amnt_val', 'submission_start_date', 'submission_end_date'],
                include: [   
                    {
                        model: TenderGeneratedTypeIdModel,
                        attributes: ['generated_tender_id'],
                        where: { status: '1', user_comp_id: req.comp_id },
                        required: false,
                    },
                    {
                        model: TenderAssignManagerModel,
                        attributes: ['bd_role_id'],
                        where: { status: '1', user_comp_id: req.comp_id },
                        as: 'assign_tender',
                        required: false,
                        include: [
                            {
                                model: TenderBdRoleModel,
                                attributes: ['role_name'],
                                where: { status: '1', },
                                required: false,
                            },
                            {
                                model: Users,
                                attributes: ['userfullname'],
                                where: { isactive: '1' },
                                required: false,
                            }
                        ],
                    }
                ]
            })
            if(tenderdata){

                var fs_preparetion_data = [];
                var comp_assign_desc_arr = [];
                const company_Record = await comp_main_users.findOne({ 
                    where: { status: '1', id: req.comp_id },
                    attributes: ['id','comp_userfullname'],
                    include:[
                        {
                            model: comp_logo,
                            attributes: ['logo_file_name','logo_file_path'],
                            where: { status: '1', user_comp_id:req.comp_id},
                            required: false,
                        }
                    ],
                });
                const fspreparationtemplates_row = await fspreparationtemplates.findOne({ 
                    order:[['id', 'DESC']],
                    where: { status: '1', user_comp_id: req.comp_id,project_id:req.body.project_id },
                    attributes: ['subject','remark','ho_contract']
                });


                if(tenderdata.bg_assign_tndr_generated_id){
                    fs_preparetion_data.push({ 
                        'ref_no':tenderdata.bg_assign_tndr_generated_id.generated_tender_id,
                    });
                }
                else{
                    fs_preparetion_data.push({ 
                        'ref_no':'',
                    }); 
                }


                if(tenderdata){
                    fs_preparetion_data.push({ 
                        'bid_date':tenderdata.submission_end_date,
                    });
                }
                else{
                    fs_preparetion_data.push({ 
                        'bid_date':'',
                    }); 
                }



                if(fspreparationtemplates_row){
                    fs_preparetion_data.push({
                        'subject':fspreparationtemplates_row.subject
                    });
                    fs_preparetion_data.push({
                        'notes':fspreparationtemplates_row.remark
                    });
                    fs_preparetion_data.push({
                        'ho_contract':fspreparationtemplates_row.ho_contract
                    });
                    //fs_preparetion_data_new.push({fs_preparetion_data});
                }
                else{
                    fs_preparetion_data.push({
                        'subject':''
                    }); 
                    fs_preparetion_data.push({
                        'notes':''
                    }); 
                    fs_preparetion_data.push({
                        'ho_contract':''
                    });
                    //fs_preparetion_data_new.push({fs_preparetion_data});
                }


                if(company_Record){
                    // fs_preparetion_data.push(tenderdata);
                     fs_preparetion_data.push({ 
                         'logo':company_Record.bg_company_logo.logo_file_path+'/'+company_Record.bg_company_logo.logo_file_name,
                         'comp_name':company_Record.comp_userfullname,
                     });
                     //fs_preparetion_data_new.push({fs_preparetion_data});
                }
                else{
                    fs_preparetion_data.push({ 
                        'logo':'',
                        'comp_name':'',
                    }); 
                    //fs_preparetion_data_new.push({fs_preparetion_data});
                }

                const existing_Record2 = await fsdescassigncomps.findAll({ 
                    order:[['type_id', 'ASC'],['sr_no', 'ASC']],
                    where: { status: '1', user_comp_id: req.comp_id },
                    attributes: ['id','type_id','desc_name_id','desc_name','sr_no'],
                    include:[
                        {
                            model: fsdescremarks,
                            attributes: ['desc_remark_data'],
                            where: { status: '1', user_comp_id:req.comp_id, project_id:req.body.project_id},
                            required: false,
                        }
                    ],
                });
                if(existing_Record2){
                    await Promise.all(existing_Record2.map(async (comp_assign_desc) => {
                        if(comp_assign_desc.desc_name_id == 3){
                            desc_remark_data = tenderdata.tender_name;
                        }
                        else if(comp_assign_desc.desc_name_id == 4){
                            const country_row  = await Country.findOne({
                                attributes: ['id', 'country_name'],
                                where: { status: '1', id:tenderdata.country_id },
                            })
                            desc_remark_data = country_row.country_name
                        }
                        else if(comp_assign_desc.desc_name_id == 7){
                            const state_row  = await State.findOne({
                                attributes: ['id', 'state_name'],
                                where: { status: '1', id:tenderdata.state_id },
                            })
                            desc_remark_data = state_row?.state_name ?? null;
                        }
                        else if(comp_assign_desc.desc_name_id == 8){
                            const city_row  = await City.findOne({
                                attributes: ['id', 'city_name'],
                                where: { status: '1', id:tenderdata.city_id },
                            })
                            desc_remark_data = city_row?.city_name ?? null;
                        }
                        else if(comp_assign_desc.desc_name_id == 9){
                            desc_remark_data = tenderdata.tender_cost
                        }
                        else if(comp_assign_desc.desc_name_id == 14){
                            desc_remark_data = tenderdata.pre_bid_meeting_date
                        }
                        else if(comp_assign_desc.desc_name_id == 19){
                            desc_remark_data = tenderdata.submission_end_date
                        }
                        else if(comp_assign_desc.desc_name_id == 21){
                            const client_row   = await TenderClient.findOne({
                                attributes: ['id', 'client_name'],
                                where: { status: '1', id:tenderdata.client_id },
                            })
                            desc_remark_data = client_row.client_name
                        }
                        else if(comp_assign_desc.desc_name_id == 22){
                            desc_remark_data = tenderdata.client_cont_person
                        }
                        else if(comp_assign_desc.desc_name_id == 23){
                            desc_remark_data = tenderdata.client_cont_address
                        }
                        else{
                            desc_remark_data = comp_assign_desc.fs_desc_remark;
                        }
                        comp_assign_desc_arr.push({
                            'sr_no':comp_assign_desc.sr_no,
                            'desc_name':comp_assign_desc.desc_name,
                            'fs_desc_remark':desc_remark_data
                        });
                        
                        
                    }));
                    fs_preparetion_data.push({comp_assign_desc_arr});
                }

                if(fs_preparetion_data){
                    res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                        message: process.env.APIRESPMSG_RECFOUND,
                        error: false,
                        success: true,
                        status: '1',
                        data: fs_preparetion_data
                    });
                } 
            }
            else{
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                }); 
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });

        }
    }
}

//fs preparation email popup
const fspreparationemailpopup = async (req, res) => {
    const schema = Joi.object().keys({
        project_id: Joi.number().required(),
        sheet_type: Joi.number().required(),
        assign_to: Joi.string().pattern(/^[0-9,]+$/).required(),
        subject: Joi.string().required(),
        remark: Joi.string().required(),
        ho_contract: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required()
    });

    const dataToValidate = {
        project_id: req.body.project_id,
        sheet_type: req.body.sheet_type,
        assign_to: req.body.assign_to,
        subject: req.body.subject,
        remark: req.body.remark,
        ho_contract: req.body.ho_contract,
        user_comp_id: req.comp_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };

    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const TenderModel = createTenderModel(req.comp_id);
            await TenderModel.performOperation();
            const tenderdata = await TenderModel.findOne({
                where:{ status: '1', user_comp_id: req.comp_id, id:dataToValidate.project_id },
                attributes: ['id'],
            })
            if(tenderdata){
                const delimiter = ',';
                const assign_response_data = dataToValidate.assign_to.split(delimiter);
    
                const existingRecords = [];
                const recordsToCreate = [];
                if(assign_response_data.length>0){
                    for (const assign_to_row of assign_response_data) {
                        const existing_Record = await fspreparationtemplates.findOne({ 
                            where: { status: '1', sheet_type: req.body.sheet_type, project_id: req.body.project_id, assign_to: assign_to_row, user_comp_id: req.comp_id },
                            attributes: ['project_id','sheet_type','assign_to','subject','remark','ho_contract'],
                        });
                        if(!existing_Record){
                            recordsToCreate.push({
                                project_id: req.body.project_id,
                                sheet_type: req.body.sheet_type,
                                assign_to: assign_to_row,
                                subject: req.body.subject,
                                remark: req.body.remark,
                                ho_contract: req.body.ho_contract,
                                user_comp_id: req.comp_id,
                                created_by: req.userId,
                                created_at: getCurrentDateTime(),
                            });
                        }
                        else{
                            //existingRecords.push(existing_Record);
                            recordsToCreate.push({
                                project_id: existing_Record.project_id,
                                sheet_type: existing_Record.sheet_type,
                                assign_to: existing_Record.assign_to,
                                subject: existing_Record.subject,
                                remark: existing_Record.remark,
                                ho_contract: existing_Record.ho_contract,
                                user_comp_id: req.comp_id,
                                created_by: req.userId,
                                created_at: getCurrentDateTime(),
                            });
                            // return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                            //     message: process.env.APIRESPMSG_RECALREADYEXISTS,
                            //     error: true,
                            //     success: false,
                            //     status: '0'
                            // });
                        }

                    }
                    if (recordsToCreate.length > 0) {
                        const fileRecords = await fspreparationtemplates.bulkCreate(recordsToCreate);
                        if(fileRecords.length >0){
                            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: process.env.EMAILSENT_MSG,
                                error: false,
                                success: true,
                                status: '1',
                            });
                        }
                    }
                }
             
            }
            else{
                res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                }); 
            }
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: error,
                success: false,
                status: '0',
            });

        }
    }
}

//upload prepare factsheet
const prepare_factsheet_doc_storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'factsheet' + '/' + year + '/' + month + '/' + day + '/' + req.userId + '-' + req.comp_id; 
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + 'factsheet_' + Math.random() + extension); // Rename file with a timestamp
    }
});


const prepare_fs_doc_upload = multer({ 
    storage: prepare_factsheet_doc_storage,
});

//add fs parepare document
const addfspreparedoc = async (req, res) => {

    prepare_fs_doc_upload.array('files')(req, res, async function (err) {

        const schema = Joi.object().keys({
            project_id: Joi.number().required(),
            user_comp_id: Joi.number().required(),
            created_by: Joi.number().required(),
            created_at: Joi.date().iso().required()
        });

        const dataToValidate = {
            project_id: req.body.project_id,
            user_comp_id: req.comp_id,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };

        const result = schema.validate(dataToValidate);

        if (result.error) {
            res.status(process.env.APIRESPCODE_VALIDATION).send({
                message: result.error.details[0].message,
                error: true,
                success: false,
                status: '0',
            });
        } else {
            try {
                const fs_prepare_existence = await fspreparationtemplates.findOne({ 
                    order: [['id', 'DESC']],
                    where: { project_id: req.body.project_id, user_comp_id: req.comp_id, status: '1' },
                    attributes: ['id'] 
                })
                if(fs_prepare_existence){
                    const files = req.files;
                    if (files) {
                        const originalFolderPath = files[0].destination;
                        
                        const newNumber = req.body.project_id;
                        const pathSegments = originalFolderPath.split('/');
                        pathSegments.pop();
                        const newFolderPath = path.join(pathSegments.join('/'), newNumber);
                        if (!fs.existsSync(newFolderPath)) {
                            fs.mkdirSync(newFolderPath);
                        }
                        files.forEach((file) => {
                            const oldPath = path.join(originalFolderPath, file.filename);
                            const newPath = path.join(newFolderPath, file.filename);
                            fs.rename(oldPath, newPath, (err) => {
                            });
                        });
                        const fileRecords = await fsmaingeneratedfiles.bulkCreate(files.map((file) =>
                        ({
                            created_by: req.userId, user_comp_id: req.comp_id, project_id: req.body.project_id,
                            file_name: file.filename, file_path: newFolderPath, created_at: getCurrentDateTime()
                        })));
                        if (fileRecords.length > 0) {
                            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                                message: `${fileRecords.length} records inserted successfully`,
                                error: false,
                                success: true,
                                status: '1',
                            });
                        }

                    }
                }
                else{
                    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECNOTFOUND,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            

            } catch (error) {
                res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                });
            }
        }

    });
}

module.exports = {
    getfstypemstrList, getfsdescassigncompList, addfsdescramarks, addfsdescramarkdoc, fspreparationtemplate, fspreparationemailpopup, addfspreparedoc
}; 