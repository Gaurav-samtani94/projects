const { Sequelize, DataTypes, Op } = require('sequelize');
const jwt = require('jsonwebtoken');
const Joi = require('joi');
require('dotenv').config();
const TenderModel = require('../../apps/models/tender/TenderModel');
const Country = require('../models/master/Country');
const State = require('../models/master/State');
const City = require('../models/master/City');
const Users = require('../models/Users');
const Main_company = require('../models/Main_company');
const Role = require("../models/master/Role");
const getCurrentDateTime = () => new Date();
const max = 10;
const min = 1;
const moment = require('moment-timezone');
const path = require('path');
const curl = async (req, res) => {
    const axios = require('axios');
    const FormData = require('form-data');
    let data = new FormData();
    data.append('financial_year', '2023-2024');
    data.append('tender_date', '2023-10-31');

    let config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://api.growthgrids.com/bd_growthgrids/index.php/gg_alltenderlist',
        headers: {
            'Token': 'nrWY4SPrEZ2?Z14mYDwWNj5M7GcUrra77EWt8?vC2w4YXGwsU#mJyFQTcwX@',
            'Cookie': 'PHPSESSID=udoh75us0mcv924cn9uitjlhfd',
            ...data.getHeaders()
        },
        data: data
    };
    const response = await axios.request(config)
    // const response_data = response;

    const response_data = Object.values(response.data);

    // const response_data = JSON.parse(response);
    try {
        if (response_data) {
            // console.log(response_data[3], 'dddd')
            const fileRecords = await TenderModel.bulkCreate(response_data[3].map((data) => ({

                user_comp_id: req.comp_id,
                gg_tenderID: data.gg_tenderID,
                tender_name: data.tender_details,
                tnd_ref_id: data.tnd_ref_id,
                tender_gov_id: data.tender_gov_id,
                tender_cost: data.tender_amnt_val,
                tender_emd_amnt_val: data.tender_emd_amnt_val,
                cycle_id: 1,
                source_id: '1',
                national_intern: '1',
                currency_id: '1',
                country_id: 1,
                funding_id: 1,
                region_id: 1,
                state_id: 1,
                city_id: 1,
                client_id: 1,
                sector_id: 1,
                // Math.random() * (max - min) + min
                client_cont_person: data.client_cont_person,
                client_cont_address: data.client_cont_address,
                bid_opening_place: data.bid_opening_place,
                submission_start_date: data.submission_start_date,
                submission_end_date: data.submission_end_date,

                pre_bid_meeting_place: data.pre_bid_meeting_place,
                pre_bid_meeting_address: data.pre_bid_meeting_address,
                pre_bid_meeting_date: data.pre_bid_meeting_date,
                pre_bid_meeting_time: data.pre_bid_meeting_time,

                tnd_url: data.tnd_url,
                created_at: data.entry_date,
                created_by: req.userId,
            })));
            res.status(200).send({
                message: `${fileRecords.length} records inserted successfully`,
                error: false,
                success: true,
                status: '1',
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
        // Handle the error appropriately
    }
}



//User Inter Linking ,.... Code By Ash..
const UserInterlinking = async (req, res) => {
    const axios = require('axios');
    let data = new FormData();

    let config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://api.growthgrids.com/bd_growthgrids/index.php/users_interlinking',
        data: data
    };

    const response = await axios.request(config)
    const response_data = Object.values(response.data);

    try {
        const InsertExistingRec = [];
        const BulkInsertRecordArr = [];

        if (response_data[0] == 1) {
            await Promise.all(response_data[2].map(async (element) => {

                //console.log(element);

                const existingRecord = await Main_company.findOne({ where: { status: '1', comp_useremail: element.emailaddress } });

                if (existingRecord) {
                    InsertExistingRec.push(existingRecord);
                } else {
                    BulkInsertRecordArr.push({
                        comp_userfullname: element.userfullname,
                        comp_useremail: element.emailaddress,
                        comp_usercontact: element.contactnumber,
                        comp_userpassword: element.emppassword,
                        comp_tg_userid: element.id,
                        created_at: getCurrentDateTime()
                    });
                }
            }));
        }

        console.log(BulkInsertRecordArr, 'hi')
        if (BulkInsertRecordArr.length > 0) {
            const NewUsersInsertRecords = await Main_company.bulkCreate(BulkInsertRecordArr);
            // const NewUsersInsertRecords = '';
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: `${NewUsersInsertRecords.length} Records inserted successfully`,
                error: false,
                success: true,
                status: '1',
            });
        } else {
            return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                message: process.env.APIRESPMSG_RECALREADYEXISTS,
                error: true,
                success: false,
                status: '0',
            });
        }

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}



// Merge ...
const UserInterLinkedMerge = async (req, res) => {
    try {
        const existingRecdArr = [];
        const BulkInsertRecordArr = [];
        const existingRecord = await Main_company.findAll({ where: { status: '1' } });

        await Promise.all(existingRecord.map(async (element) => {
            const UserExistingRec = await Users.findOne({ where: { isactive: '1', email: element.comp_useremail } });

            if (UserExistingRec) {
                existingRecdArr.push(UserExistingRec);
            } else {
                const SysAdminRole = await Role.findOne({ where: { user_comp_id: element.id, status: '1', deletable: '2', role_name: 'System Admin' }, attributes: ['id'] });
                if (SysAdminRole) {
                    BulkInsertRecordArr.push(
                        {
                            emp_role_id: SysAdminRole.id,
                            comp_id: element.id,
                            firstname: element.comp_userfullname,
                            userfullname: element.comp_userfullname,
                            email: element.comp_useremail,
                            contactnumber: element.comp_usercontact,
                            password: element.comp_userpassword,
                            created_at: getCurrentDateTime(),
                            permanent_sys_adm: "1",
                        }
                    );
                }
            }
        }));

        // console.log(BulkInsertRecordArr);
        if (BulkInsertRecordArr.length > 0) {
            const NewUsersInsertRecords = await Users.bulkCreate(BulkInsertRecordArr);
            // const NewUsersInsertRecords = '';
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: `${NewUsersInsertRecords.length} Records inserted successfully`,
                error: false,
                success: true,
                status: '1',
            });
        } else {
            return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                message: process.env.APIRESPMSG_RECALREADYEXISTS,
                error: true,
                success: false,
                status: '0',
            });
        }

    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}


//Token Update Tg to Bg..  Code By Ash..
const UserTokenInterlinking = async (req, res) => {
    const axios = require('axios');
    let data = new FormData();
    let config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: 'https://api.growthgrids.com/bd_growthgrids/index.php/users_tokenlinking',
        data: data
    };
    const response = await axios.request(config)
    const response_data = Object.values(response.data);
    //console.log(response_data);
    try {
        const ExistUpdRecdArr = [];
        if (response_data[0] == 1) {
            await Promise.all(response_data[2].map(async (element) => {
                const existingRecord = await Main_company.findOne({ where: { status: '1', comp_tg_userid: element.id } });
                if (existingRecord) {
                    const UpdateRecdArr = {
                        ggpl_api_tndr_token: element.auth_token,
                        updated_at: getCurrentDateTime()
                    };
                    const update = await Main_company.update(UpdateRecdArr, {
                        where: { status: '1', id: existingRecord.id }
                    });
                    ExistUpdRecdArr.push(update);
                }
            }));

            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: `${ExistUpdRecdArr.length} Users token updated successfully`,
                error: false,
                success: true,
                status: '1',
            });

        } else {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: "There is no API-Data",
                error: true,
                success: false,
                status: '0',
            });
        }
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}


const { sendDynamicEmail, sendEmailWith_temp } = require('../config/mail');
const sendMail = async (req, res) => {
    try {
        const response = sendDynamicEmail(
            'sabhimanyu336@gmail.com',
            'Dynamic Subject',
            'Dynamic Body of the Email',
            '<p>Dynamic HTML body of the email</p>',
        );
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECDELETED,
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}


const sendMail_temp = async (req, res) => {
    try {
        const dynamicData = {
            subject: 'Dyssssssssnamic Subject',
            body: 'Dynasssssmic Body of the Email',
        };
        const templatePath = path.join(__dirname, '../emailtemplates/emailTemplate.hbs');
        const response = sendEmailWith_temp(
            'sabhimanyu336@gmail.com',
            null,
            // 'Dynamic Body of the Email',
            null,
            templatePath,
            dynamicData
        );
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECDELETED,
            error: false,
            success: true,
            status: '1',
            data: response
        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}



module.exports = {
    curl, UserInterlinking, UserInterLinkedMerge, UserTokenInterlinking, sendMail
};  