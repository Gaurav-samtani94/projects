const express = require('express');
const crypto = require('crypto');
const session = require('express-session');
const bodyParser = require('body-parser');
var dbConn = require('./apps/config/database');
var multer = require('multer');
const cors = require('cors');
const employeeRoutes = require('./apps/config/routes')
const app = express();
require('dotenv').config();
const port = process.env.PORT || 3010;
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors({ origin: '*' }));
app.get('/', (req, res) => {
    res.send("Welcome");
});


//session testing
const secret = crypto.randomBytes(32).toString('hex');

app.use(session({
    secret: secret,
    resave: false,
    saveUninitialized: false,
    // cookie: { maxAge: 60000 } // session timeout in milliseconds (1 minute in this example)
}));



// app.use('/uploads', express.static('uploads'));
// const sequelize = dbConn
// sequelize.sync()
//     .then(() => {
//         console.log('Database synced');
//     })
//     .catch((err) => {
//         console.error('Error syncing database:', err);
//     });
// const basepath = '/bidgrid';
// console.log(employeeRoutes,'employeeRoutes======')
app.use('/api/user/', employeeRoutes)
app.use((req, res) => {
    res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).json({
        message: 'Invalid Url',
        error: true,
        success: false,
        status: '0',
    });
});
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});
