import {
    BID_DYNAMIC_MENU_FAILED,
    BID_DYNAMIC_MENU_REQUEST,
    BID_DYNAMIC_MENU_SUCCESS,
    NAVIGATION_DATA,
} from "Redux/constants/bidgrid/bidgridConstants"

const setNavigationDataAction = (data) => async (dispatch) => {

    try {
        dispatch({ type: NAVIGATION_DATA, payload: data })
    }
    catch (error) {
        console.log('error in action of navigation data')
    }
}

const BidMenuData = (data) => async (dispatch) => {
    try {
        dispatch({ type: BID_DYNAMIC_MENU_REQUEST })
        dispatch({ type: BID_DYNAMIC_MENU_SUCCESS, payload: data })
    }
    catch (error) {
        dispatch({ type: BID_DYNAMIC_MENU_FAILED, payload: error })
    }
}


export const navigationData = {
    setNavigationDataAction,
    BidMenuData
}