// @ts-nocheck
import {
    MIS_FILTER_INACTION_FAILED,
    MIS_FILTER_INACTION_REQUEST,
    MIS_FILTER_UPDATE_ALL_KEYS_OBJECTS,
    MIS_FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS,
    MIS_FILTER_RESET_ARR_KEYS,
    MIS_FILTER_IS_UPDATE_RESET_TRUE,
    MIS_FILTER_RESET_INDIVIDUAL_ARR_OBJECTS,
    MIS_FILTER_IS_UPDATE_RESET,
    // MIS_FILTER_INACTION_REQUEST,
} from "Redux/constants/bidgrid/bidgridConstants"

const misFilterUpdateAllKeys = (data) => async (dispatch) => {

    try {
        // console.log('data===', data);
        dispatch({ type: MIS_FILTER_INACTION_REQUEST })
        dispatch({ type: MIS_FILTER_UPDATE_ALL_KEYS_OBJECTS, payload: data })
    }
    catch (error) {
        dispatch({ type: MIS_FILTER_INACTION_FAILED, payload: error })
    }
}

const misFilterUpdateIndividualKeys = (data) => async (dispatch) => {
    // console.log('data=mis=25>', data);

    try {
        dispatch({ type: MIS_FILTER_INACTION_REQUEST })
        dispatch({ type: MIS_FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS, payload: data })
    }
    catch (error) {
        dispatch({ type: MIS_FILTER_INACTION_FAILED, payload: error })
    }
}

const misFilterResetKeys = (data) => async (dispatch) => {
    try {
        dispatch({ type: MIS_FILTER_INACTION_REQUEST })
        dispatch({ type: MIS_FILTER_RESET_ARR_KEYS, payload: data })
    }
    catch (error) {
        dispatch({ type: MIS_FILTER_INACTION_FAILED, payload: error })
    }
}

const misFilterResetIndividualKeys = (data) => async (dispatch) => {
    try {
        dispatch({ type: MIS_FILTER_INACTION_REQUEST })
        dispatch({ type: MIS_FILTER_RESET_INDIVIDUAL_ARR_OBJECTS, payload: data })
    }
    catch (error) {
        dispatch({ type: MIS_FILTER_INACTION_FAILED, payload: error })
    }
}

const misFilterResetisUpdate = (data) => async (dispatch) => {
    try {
        dispatch({ type: MIS_FILTER_INACTION_REQUEST })
        dispatch({ type: MIS_FILTER_IS_UPDATE_RESET, payload: data })
    }
    catch (error) {
        dispatch({ type: MIS_FILTER_INACTION_FAILED, payload: error })
    }
}

const misFilterResetisUpdateTrue = (data) => async (dispatch) => {
    try {
        dispatch({ type: MIS_FILTER_INACTION_REQUEST })
        dispatch({ type: MIS_FILTER_IS_UPDATE_RESET_TRUE, payload: data })
    }
    catch (error) {
        dispatch({ type: MIS_FILTER_INACTION_FAILED, payload: error })
    }
}
// const filterUpdateStateVal = (data) => async (dispatch) => {
//     try {
//         dispatch({ type: FILTER_INACTION_REQUEST })
//         dispatch({ type: FILTER_UPDATE_STATE_VAL, payload: data }) // Dispatch new action type with data
//     }
//     catch (error) {
//         dispatch({ type: FILTER_INACTION_FAILED, payload: error })

//     }
// }
// const CalendarEventUpdate = (data) => async (dispatch) => {
//     try {
//         dispatch({ type: CALENDAR_REQUEST })
//         dispatch({ type: CALENDAR_SUCCESS, payload: data })
//     }
//     catch (error) {
//         dispatch({ type: CALENDAR_FAILED, payload: error })
//     }
// }

export const misFilterActions = {
    misFilterUpdateAllKeys,
    misFilterUpdateIndividualKeys,
    misFilterResetKeys,
    misFilterResetIndividualKeys,
    misFilterResetisUpdate,
    misFilterResetisUpdateTrue
}
