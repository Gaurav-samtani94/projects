// @ts-nocheck
import {
    TRASH_FILTER_INACTION_FAILED,
    TRASH_FILTER_INACTION_REQUEST,
    TRASH_FILTER_UPDATE_ALL_KEYS_OBJECTS,
    TRASH_FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS,
    TRASH_FILTER_RESET_ARR_KEYS,
    TRASH_FILTER_RESET_INDIVIDUAL_ARR_OBJECTS,
    TRASH_FILTER_IS_UPDATE_RESET,
    // MIS_FILTER_INACTION_REQUEST,
} from "Redux/constants/bidgrid/bidgridConstants"

const trashFilterUpdateAllKeys = (data) => async (dispatch) => {

    try {
        // console.log('data===', data);
        dispatch({ type: TRASH_FILTER_INACTION_REQUEST })
        dispatch({ type: TRASH_FILTER_UPDATE_ALL_KEYS_OBJECTS, payload: data })
    }
    catch (error) {
        dispatch({ type: TRASH_FILTER_INACTION_FAILED, payload: error })
    }
}

const trashFilterUpdateIndividualKeys = (data) => async (dispatch) => {
    // console.log('data=mis=25>', data);

    try {
        dispatch({ type: TRASH_FILTER_INACTION_REQUEST })
        dispatch({ type: TRASH_FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS, payload: data })
    }
    catch (error) {
        dispatch({ type: TRASH_FILTER_INACTION_FAILED, payload: error })
    }
}

const trashFilterResetKeys = (data) => async (dispatch) => {
    try {
        dispatch({ type: TRASH_FILTER_INACTION_REQUEST })
        dispatch({ type: TRASH_FILTER_RESET_ARR_KEYS, payload: data })
    }
    catch (error) {
        dispatch({ type: TRASH_FILTER_INACTION_FAILED, payload: error })
    }
}

const trashFilterResetIndividualKeys = (data) => async (dispatch) => {
    try {
        dispatch({ type: TRASH_FILTER_INACTION_REQUEST })
        dispatch({ type: TRASH_FILTER_RESET_INDIVIDUAL_ARR_OBJECTS, payload: data })
    }
    catch (error) {
        dispatch({ type: TRASH_FILTER_INACTION_FAILED, payload: error })
    }
}

const trashFilterResetisUpdate = (data) => async (dispatch) => {
    try {
        dispatch({ type: TRASH_FILTER_INACTION_REQUEST })
        dispatch({ type: TRASH_FILTER_IS_UPDATE_RESET, payload: data })
    }
    catch (error) {
        dispatch({ type: TRASH_FILTER_INACTION_FAILED, payload: error })
    }
}
// const filterUpdateStateVal = (data) => async (dispatch) => {
//     try {
//         dispatch({ type: FILTER_INACTION_REQUEST })
//         dispatch({ type: FILTER_UPDATE_STATE_VAL, payload: data }) // Dispatch new action type with data
//     }
//     catch (error) {
//         dispatch({ type: FILTER_INACTION_FAILED, payload: error })

//     }
// }
// const CalendarEventUpdate = (data) => async (dispatch) => {
//     try {
//         dispatch({ type: CALENDAR_REQUEST })
//         dispatch({ type: CALENDAR_SUCCESS, payload: data })
//     }
//     catch (error) {
//         dispatch({ type: CALENDAR_FAILED, payload: error })
//     }
// }

export const trashFilterAction = {
    trashFilterUpdateAllKeys,
    trashFilterUpdateIndividualKeys,
    trashFilterResetKeys,
    trashFilterResetIndividualKeys,
    trashFilterResetisUpdate,
}
