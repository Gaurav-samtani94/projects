// @ts-nocheck
import {
    FILTER_INACTION_FAILED,
    FILTER_INACTION_REQUEST,
    FILTER_UPDATE_ALL_KEYS_OBJECTS,
    FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS,
    FILTER_RESET_ARR_KEYS,
    FILTER_RESET_INDIVIDUAL_ARR_OBJECTS,
    FILTER_IS_UPDATE_RESET,
    FILTER_UPDATE_STATE_VAL,
    CALENDAR_REQUEST,
    CALENDAR_FAILED,
    CALENDAR_SUCCESS,
    FILTER_IS_UPDATE_RESET_TRUE
} from "Redux/constants/bidgrid/bidgridConstants"

const filterUpdateAllKeys = (data) => async (dispatch) => {

    try {
        // console.log('data===', data);
        dispatch({ type: FILTER_INACTION_REQUEST })
        dispatch({ type: FILTER_UPDATE_ALL_KEYS_OBJECTS, payload: data })
    }
    catch (error) {
        dispatch({ type: FILTER_INACTION_FAILED, payload: error })
    }
}

const filterUpdateIndividualKeys = (data) => async (dispatch) => {

    try {
        dispatch({ type: FILTER_INACTION_REQUEST })
        dispatch({ type: FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS, payload: data })
    }
    catch (error) {
        dispatch({ type: FILTER_INACTION_FAILED, payload: error })
    }
}

const filterResetKeys = (data) => async (dispatch) => {
    // console.log(data, "data")
    try {
        dispatch({ type: FILTER_INACTION_REQUEST })
        dispatch({ type: FILTER_RESET_ARR_KEYS, payload: data })
        // console.log(data, "reset data")
    }
    catch (error) {
        dispatch({ type: FILTER_INACTION_FAILED, payload: error })
    }
}

const filterResetIndividualKeys = (data) => async (dispatch) => {
    try {
        dispatch({ type: FILTER_INACTION_REQUEST })
        dispatch({ type: FILTER_RESET_INDIVIDUAL_ARR_OBJECTS, payload: data })
    }
    catch (error) {
        dispatch({ type: FILTER_INACTION_FAILED, payload: error })
    }
}

const filterResetisUpdate = (data) => async (dispatch) => {
    try {
        dispatch({ type: FILTER_INACTION_REQUEST })
        dispatch({ type: FILTER_IS_UPDATE_RESET, payload: data })
    }
    catch (error) {
        dispatch({ type: FILTER_INACTION_FAILED, payload: error })
    }
}
const filterResetisUpdateTrue = (data) => async (dispatch) => {
    try {
        dispatch({ type: FILTER_INACTION_REQUEST })
        dispatch({ type: FILTER_IS_UPDATE_RESET_TRUE, payload: data })
    }
    catch (error) {
        dispatch({ type: FILTER_INACTION_FAILED, payload: error })
    }
}
const filterUpdateStateVal = (data) => async (dispatch) => {
    try {
        dispatch({ type: FILTER_INACTION_REQUEST })
        dispatch({ type: FILTER_UPDATE_STATE_VAL, payload: data }) // Dispatch new action type with data
    }
    catch (error) {
        dispatch({ type: FILTER_INACTION_FAILED, payload: error })

    }
}
const CalendarEventUpdate = (data) => async (dispatch) => {
    try {
        dispatch({ type: CALENDAR_REQUEST })
        dispatch({ type: CALENDAR_SUCCESS, payload: data })
    }
    catch (error) {
        dispatch({ type: CALENDAR_FAILED, payload: error })
    }
}

export const filterCycleActions = {
    filterUpdateAllKeys,
    filterUpdateIndividualKeys,
    filterResetKeys,
    filterResetIndividualKeys,
    filterResetisUpdate,
    filterUpdateStateVal,
    CalendarEventUpdate,
    filterResetisUpdateTrue
}
