import { PERSIST_REQUEST, PERSIST_SUCCESS, PERSIST_FAILED } from "../../constants/common/persistConstant"

export const persistAction = (data) => async (dispatch) => {

    try {
        dispatch({ type: PERSIST_REQUEST })
        dispatch({ type: PERSIST_SUCCESS, payload: data })
    }
    catch (error) {
        dispatch({ type: PERSIST_FAILED, payload: error })
    }
}