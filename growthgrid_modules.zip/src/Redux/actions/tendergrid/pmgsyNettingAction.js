import { FilterServices } from "../../../Services/common/filters/FilterServices";
import { PMGSY_ERROR_TENDER_GRID, PMGSY_INITIALIZE_NETTING_API_FAIL, PMGSY_INITIALIZE_NETTING_WITHOUT_AUTH, PMGSY_INITIALIZE_NETTING_WITH_AUTH } from "../../constants/tendergrid/pmgsyFilterConstant";


export const pmgsyNettingAction = (updatedData) => {
    console.log(updatedData,"getupdatedData");
    return (dispatch) => {
        if (localStorage.getItem('auth')) {
            console.log("hellooooooo");
            const formdata = new FormData();
            formdata.append('user_id', localStorage.getItem('user_id'));
            formdata.append('page_name', updatedData?.page_name);
            try {
                FilterServices?.getTenderFilters(formdata).then((res) => {
                    console.log(res,"res");
                    if(res?.data?.status === 1){
                        const pmgsyChips = res?.data?.data;
                        console.log(pmgsyChips,"pmgsyChipspmgsyChips");
                        const pmgsyFilterObject = {
                            page_number: updatedData?.page_number,
                            limit: updatedData?.limit,
                            page_name: updatedData?.page_name,
                            sort_key: updatedData?.filter_sort_key,
                            sort_val: updatedData?.filter_sort_val,
                            tndr_category_type: updatedData?.filter_tndr_category_type,
                            tndr_not_specified_emd:updatedData?.tndr_not_specified_emd,
                            tndr_not_specified_amt:updatedData?.tndr_not_specified_amt
                        };
                        pmgsyChips.forEach((item) => {
                            if(item.filter_keyword === "tndr_not_specified_emd" || item.filter_keyword  === "tndr_not_specified_amt" ){
                              return 
                            }
                            pmgsyFilterObject[item.filter_keyword] = item.filter_val;
                          });
                          dispatch({
                            type : PMGSY_INITIALIZE_NETTING_WITH_AUTH,
                            payload : {pmgsyChips,pmgsyFilterObject}
                          })
                    } else if(res?.response?.data?.status === 0){
                           const pmgsyInitialState = {
                            state_id: "",
                            tnd_ref_id: "",
                            tnd_id: '',
                            tnd_govt_id: '',
                            client_id: "",
                            tender_keyword: "",
                            tender_docs: "",
                            sector_id: "",
                            country_id: "",
                            region_id: "",
                            funding_agency_id: "",
                            financial_year: '',
                            from_date: "",
                            to_date: "",
                            latest_activity: '',
                            published_date: "",
                            close_exp_date: "",
                            estm_value: "",
                            estm_value_emd: "",
                            pubdate_cust_from_date: "",
                            pubdate_cust_to_date: "",
                            expdate_cust_from_date: "",
                            expdate_cust_to_date: "",
                            amnt_custrange_operator: "",
                            amnt_custrange_amount: "",
                            custrange_denomination: "",
                            amnt_custrange_operator_emd: "",
                            amnt_custrange_amount_emd: "",
                            custrange_denomination_emd: "",
                            sort_key: "",
                            sort_val: "",
                            limit: 25,
                            page_name: updatedData?.page_name,
                            tender_status: 'active',
                            no_bid: '',
                            tndr_category_type: "",
                            wishlist_category_id: '',
                            page_number: 0,
                            pmgsyChips: [],
                            pmgsyFilterObject: {},
                            tndr_not_specified_amt: "tndr_not_specified_amt",
                            tndr_not_specified_emd: "tndr_not_specified_emd",
                            error: ''
                        };
                        dispatch({
                            type: PMGSY_INITIALIZE_NETTING_API_FAIL,
                            payload: {pmgsyInitialState}
                        }) 
                    }else{
                        console.log("error on pmgsynettingaction");
                    }
                })
            } catch (error) {
                dispatch({
                    type: PMGSY_ERROR_TENDER_GRID,
                    payload: { error: 'Unable to fetch records at the moment. Please try again in a few minutes.' },
                  });
            }
        } else {
            dispatch({
                type: PMGSY_INITIALIZE_NETTING_WITHOUT_AUTH,
                payload: { updatedData },
              });
        }
    }
}