import { BLOG_INACTION_FAILED, BLOG_INACTION_REQUEST, BLOG_UPDATE_ALL_KEYS_OBJECTS } from "Redux/constants/tendergrid/BlogConstant"



const BlogUpdateAllKeys = (data) => async (dispatch) => {

    try {
        // console.log('data===', data);
        dispatch({ type: BLOG_INACTION_REQUEST })
        dispatch({ type: BLOG_UPDATE_ALL_KEYS_OBJECTS, payload: data })
    }
    catch (error) {
        dispatch({ type: BLOG_INACTION_FAILED, payload: error })
    }
}


export const BlogAction ={
    BlogUpdateAllKeys
}