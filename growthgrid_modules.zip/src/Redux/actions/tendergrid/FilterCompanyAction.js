import {
    FILTER_CONSTANT_REQUEST,
    FILTER_CONSTANT_SUCCESS,
    FILTER_CONSTANT_FAILED
} from "../../constants/tendergrid/FilterCompanyConstant"

export const FilterCompanyAction = (data) => async (dispatch) => {
    try {
        dispatch({ type: FILTER_CONSTANT_REQUEST })
        dispatch({ type: FILTER_CONSTANT_SUCCESS, payload: data })
    }
    catch (error) {
        dispatch({ type: FILTER_CONSTANT_FAILED, payload: error })
    }
}

