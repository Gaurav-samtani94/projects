
// @ts-nocheck
import { pmgsyInitialState } from 'Redux/reducers/tendergrid/pmgsyFilterReducer';
import { FilterServices } from '../../../Services/common/filters/FilterServices';
import { pmgsyNettingAction } from './pmgsyNettingAction';
export const setPmgsyNettingAction = (updatedData) => {
    return (dispatch) => {
        const setFilterApi = (value) => {
            console.log(value,"value");
            const formdata = new FormData();
            formdata.append('user_id', localStorage.getItem('user_id'))
            formdata.append('page_name', value?.page_name ? value?.page_name : "")
            formdata.append('filter_tnd_ref_id', value?.tnd_ref_id ?value?.tnd_ref_id :"")
            formdata.append('filter_wishlist_category_id', value?.wishlist_category_id ? value?.wishlist_category_id :"")
            formdata.append('filter_tnd_id', value?.tnd_id ? value?.tnd_id :"")
            formdata.append('filter_tnd_govt_id', value?.tnd_govt_id ? value?.tnd_govt_id : "")
            formdata.append('filter_country_id', value?.country_id ? value?.country_id :"")
            formdata.append('filter_tender_status', value?.tender_status !== '' ? value?.tender_status : 'active')
            formdata.append('filter_state_id', value?.state_id ? value?.state_id :"")
            formdata.append('filter_region_id', value?.region_id ? value?.region_id :"")
            formdata.append('filter_client_id', value?.client_id ? value?.client_id : "")
            formdata.append('filter_tender_docs', value?.tender_docs ? value?.tender_docs : "")
            formdata.append('filter_tender_keyword', value?.tender_keyword ? value?.tender_keyword :"")
            formdata.append('filter_sector_id', value?.sector_id ? value?.sector_id :"")
            formdata.append('filter_from_date', value?.from_date ? value?.from_date :"")
            formdata.append('filter_to_date', value?.to_date ? value?.to_date :"")
            formdata.append('filter_latest_activity', value?.latest_activity ? value?.latest_activity : "")
            formdata.append('filter_funding_agency_id', value?.funding_agency_id ? value?.funding_agency_id: "")
            formdata.append('filter_financial_year', value?.financial_year ? value?.financial_year : "")
            formdata.append("filter_published_date", value?.published_date ? value?.published_date :"" )
            formdata.append("filter_close_exp_date", value?.close_exp_date ? value?.close_exp_date : "")
            formdata.append("filter_estm_value", value?.estm_value ? value?.estm_value :"")
            formdata.append("filter_estm_value_emd", value?.estm_value_emd ? value?.estm_value_emd :"")
            formdata.append('filter_pubdate_cust_from_date', value?.pubdate_cust_from_date ?  value?.pubdate_cust_from_date : "")
            formdata.append('filter_pubdate_cust_to_date', value?.pubdate_cust_to_date ? value?.pubdate_cust_to_date :"")
            formdata.append('filter_expdate_cust_from_date', value?.expdate_cust_from_date ? value?.expdate_cust_from_date :"")
            formdata.append('filter_expdate_cust_to_date', value?.expdate_cust_to_date ? value?.expdate_cust_to_date :"")
            formdata.append('filter_amnt_custrange_operator', value?.amnt_custrange_operator ? value?.amnt_custrange_operator :"")
            formdata.append('filter_amnt_custrange_amount', value?.amnt_custrange_amount ? value?.amnt_custrange_amount :"")
            formdata.append('filter_custrange_denomination', value?.custrange_denomination ? value?.custrange_denomination :"")
            formdata.append('filter_amnt_custrange_operator_emd', value?.amnt_custrange_operator_emd ? value?.amnt_custrange_operator_emd:"")
            formdata.append('filter_amnt_custrange_amount_emd', value?.amnt_custrange_amount_emd ?  value?.amnt_custrange_amount_emd :"")
            formdata.append('filter_custrange_denomination_emd', value?.custrange_denomination_emd ? value?.custrange_denomination_emd:"")
            // formdata.append('filter_no_bid', value?.no_bid)
            formdata.append('filter_limit', value?.limit)
            formdata.append('filter_page_number', value?.page_number)
            formdata.append('filter_sort_key', value?.sort_key)
            formdata.append('filter_sort_val', value?.sort_val)
            formdata.append('filter_tndr_category_type', value?.tndr_category_type ? value?.tndr_category_type :"")
            formdata.append('filter_tndr_not_specified_amt' , value?.tndr_not_specified_amt)
            formdata.append('filter_tndr_not_specified_emd', value?.tndr_not_specified_emd)
            
         
            if (localStorage.getItem('auth')) {
                try {
                    FilterServices.setTenderFilters(formdata)
                        .then((res) => {
                            if (res?.data?.status === 1) {
                                dispatch(pmgsyNettingAction(updatedData))
                            } else {
                            }
                        })
                } catch {
                    console.log('error')
                }
            } else {
                dispatch(pmgsyNettingAction(updatedData))
            }
        }

        if (Object.keys(updatedData).length === 5 && localStorage.getItem('auth')) {

            const formdata = new FormData();
            formdata.append('user_id', localStorage.getItem('user_id'));
            formdata.append('page_name', updatedData?.page_name);
            try {
                FilterServices.getTenderFilters(formdata)
                    .then((res) => {
                        if (res?.data?.status === 1) {
                            const pmgsyChips = res?.data?.data; // change the variable name to serverFilterData
                            const pmgsyFilterObject = {};

                            pmgsyChips.forEach((item) => {
                                pmgsyFilterObject[item.filter_keyword] = item.filter_val;
                            });
                            pmgsyFilterObject['page_number'] = updatedData?.page_number
                            pmgsyFilterObject['limit'] = updatedData?.limit
                            pmgsyFilterObject['page_name'] = updatedData?.page_name
                            pmgsyFilterObject['sort_key'] = updatedData?.sort_key
                            pmgsyFilterObject['sort_val'] = updatedData?.sort_val
                            // filterObject['tndr_category_type'] = updatedData?.tndr_category_type
                            setFilterApi(pmgsyFilterObject)
                        } else if (res?.response?.data?.status === 0) {
                            pmgsyInitialState['page_name'] = updatedData?.page_name
                            setFilterApi(pmgsyInitialState)
                        }
                        else {
                            console.log('error')
                        }
                    })
            } catch {
                console.log('error')
            }
        }
        else {
            setFilterApi(updatedData)
        }
    };
};


