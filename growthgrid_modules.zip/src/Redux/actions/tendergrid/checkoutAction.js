import { CHECKOUT_INFO_SUCCESS, CHECKOUT_INFO_REQUEST, CHECKOUT_WALLET_UPDATE_SUCCESS, CHECKOUT_INFO_FAILURE } from "Redux/constants/tendergrid/checkoutConstant"

export const checkoutAction = (data) => async (dispatch) => {
    try {
        dispatch({ type: CHECKOUT_INFO_REQUEST })
        dispatch({ type: CHECKOUT_INFO_SUCCESS, payload: data })
    }
    catch (error) {
        dispatch({ type: CHECKOUT_INFO_FAILURE, payload: error })
    }
}

export const checkoutUpdateWalletAction = (data) => async (dispatch) => {
    try {
        dispatch({ type: CHECKOUT_WALLET_UPDATE_SUCCESS, payload: data })
    }
    catch (error) {
        dispatch({ type: CHECKOUT_INFO_FAILURE, payload: error })
    }
}


