// actions/tenderListActions.js
export const setTenderList = (tenderlength) => ({
  type: 'SET_TENDER_LIST',
  payload: { count_filtered: tenderlength },
});

  