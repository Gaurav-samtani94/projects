import {
    COMPANY_BALANCE_REQUEST,
    COMPANY_BALANCE_SUCCESS,
    COMAPNY_BALANCE_FAILED
} from "../../constants/statgrid/statComapnyBalanceConstatnt"

export const CompanyBalanceAction = (data) => async (dispatch) => {
    try {
        dispatch({ type: COMPANY_BALANCE_REQUEST })
        dispatch({ type: COMPANY_BALANCE_SUCCESS, payload: data })
    }
    catch (error) {
        dispatch({ type: COMAPNY_BALANCE_FAILED, payload: error })
    }
}