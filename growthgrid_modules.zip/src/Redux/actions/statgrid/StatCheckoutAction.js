
import {STAT_CHECKOUT_INFO_REQUEST , STAT_CHECKOUT_INFO_SUCCESS , STAT_CHECKOUT_INFO_FAILURE} from "../../constants/statgrid/statCheckoutConstant"

export const StatCheckoutAction = (data) => async (dispatch) => {
    try {
        dispatch({ type: STAT_CHECKOUT_INFO_REQUEST })
        dispatch({ type: STAT_CHECKOUT_INFO_SUCCESS, payload: data })
    }
    catch (error) {
        dispatch({ type: STAT_CHECKOUT_INFO_FAILURE, payload: error })
    }
}