import {
    STAT_FILTER_INACTION_FAILED,
    STAT_FILTER_INACTION_REQUEST,
    STAT_FILTER_IS_UPDATE_RESET,
    STAT_FILTER_IS_UPDATE_RESET_TRUE,
    STAT_FILTER_RESET_ARR_KEYS,
    STAT_FILTER_RESET_INDIVIDUAL_ARR_OBJECTS,
    STAT_FILTER_UPDATE_ALL_KEYS_OBJECTS,
    STAT_FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS,
    STAT_FILTER_UPDATE_STATE_VAL
} from "../../../Redux/constants/statgrid/statFilterConstant"

const statFilterUpdateAllKeys = (data) => async (dispatch) => {

    try {
        // console.log('data===', data);
        dispatch({ type: STAT_FILTER_INACTION_REQUEST })
        dispatch({ type: STAT_FILTER_UPDATE_ALL_KEYS_OBJECTS, payload: data })
    }
    catch (error) {
        dispatch({ type: STAT_FILTER_INACTION_FAILED, payload: error })
    }
}

const statFilterUpdateIndividualKeys = (data) => async (dispatch) => {

    try {
        dispatch({ type: STAT_FILTER_INACTION_REQUEST })
        dispatch({ type: STAT_FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS, payload: data })
    }
    catch (error) {
        dispatch({ type: STAT_FILTER_INACTION_FAILED, payload: error })
    }
}

const staFilterResetKeys = (data) => async (dispatch) => {
    // console.log(data, "data")
    try {
        dispatch({ type: STAT_FILTER_INACTION_REQUEST })
        dispatch({ type: STAT_FILTER_RESET_ARR_KEYS, payload: data })
        // console.log(data, "reset data")
    }
    catch (error) {
        dispatch({ type: STAT_FILTER_INACTION_FAILED, payload: error })
    }
}

const statFilterResetIndividualKeys = (data) => async (dispatch) => {
    try {
        dispatch({ type: STAT_FILTER_INACTION_REQUEST })
        dispatch({ type: STAT_FILTER_RESET_INDIVIDUAL_ARR_OBJECTS, payload: data })
    }
    catch (error) {
        dispatch({ type: STAT_FILTER_INACTION_FAILED, payload: error })
    }
}

const statFilterResetisUpdate = (data) => async (dispatch) => {
    try {
        dispatch({ type: STAT_FILTER_INACTION_REQUEST })
        dispatch({ type: STAT_FILTER_IS_UPDATE_RESET, payload: data })
    }
    catch (error) {
        dispatch({ type: STAT_FILTER_INACTION_FAILED, payload: error })
    }
}
const statFilterResetisUpdateTrue = (data) => async (dispatch) => {
    try {
        dispatch({ type: STAT_FILTER_INACTION_REQUEST })
        dispatch({ type: STAT_FILTER_IS_UPDATE_RESET_TRUE, payload: data })
    }
    catch (error) {
        dispatch({ type: STAT_FILTER_INACTION_FAILED, payload: error })
    }
}
const statFilterUpdateStateVal = (data) => async (dispatch) => {
    try {
        dispatch({ type: STAT_FILTER_INACTION_REQUEST })
        dispatch({ type: STAT_FILTER_UPDATE_STATE_VAL, payload: data }) // Dispatch new action type with data
    }
    catch (error) {
        dispatch({ type: STAT_FILTER_INACTION_FAILED, payload: error })

    }
}


export const statFilterAction = {
    statFilterUpdateAllKeys,
    statFilterUpdateIndividualKeys,
    staFilterResetKeys,
    statFilterResetIndividualKeys,
    statFilterResetisUpdate,
    statFilterResetisUpdateTrue,
    statFilterUpdateStateVal

}