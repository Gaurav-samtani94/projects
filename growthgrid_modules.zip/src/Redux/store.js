// @ts-nocheck
import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';
import { persistStore, persistReducer } from 'redux-persist'
import storage from 'redux-persist/lib/storage'
import { userDataReducer } from './reducers/common/auth';
import { empersistReducer } from './reducers/common/persistReducer';
import { userInfoReducer } from './reducers/common/userInfoReducer';
import { filterCompanyReducer } from './reducers/tendergrid/FilterCompanyReducer';
import { seoRequestValueReducer, dropdownValReducer, dynamicMenuReducer, bidDropdownValReducer, statDropdownValReducer } from './reducers/common/DropdownReducer';
import advanceFilterReducer from './reducers/tendergrid/advanceFiltersReducer';
import CycleFilterReducer from './reducers/bidgrid/cycleFilterReducer';
import { checkoutReducer } from './reducers/tendergrid/checkoutReducer';
import socketReducer from './reducers/bidgrid/socketReducer';
import { createStateSyncMiddleware, initMessageListener } from 'redux-state-sync';
import { userLogoutAction } from './actions/common/authAction';
import { calendarReducer } from './reducers/bidgrid/cycleFilterReducer';
import MisFilterReducer from './reducers/bidgrid/misFilterReducer';
import { companybalanceReducer } from './reducers/statgrid/ComapnyBalanceReducer';
import navigationDataReducer, { BidMenuReducer } from './reducers/bidgrid/navigationDataReducer';
import TrashFilterReducer from './reducers/bidgrid/trashFilterReducer';
import StatFilterReducer from './reducers/statgrid/statFilterReducer';
import { StatCheckoutReducer } from './reducers/statgrid/statCheckoutReducer';
import advanceNoticeFilterReducer from './reducers/tendergrid/advanceNoticeFilterReducer';
import gemFilterReducer from './reducers/tendergrid/gemFilterReducer';
import irepsFilterReducer from './reducers/tendergrid/irepsFilterReducer';
import { eprocFilterReducer } from './reducers/tendergrid/eprocFilterReducer';
import { pmgsyFilterReducer } from './reducers/tendergrid/pmgsyFilterReducer';
import BlogReducer from './reducers/tendergrid/BlogReducer';

const rootReducer = combineReducers({
  loginData: userDataReducer,
  userDetails: userInfoReducer,
  cycleFilter: CycleFilterReducer,
  companyStatBalance: companybalanceReducer,
  misFilter: MisFilterReducer,
  trashFilter: TrashFilterReducer,
  companyStatBalance: companybalanceReducer,
  companyData: filterCompanyReducer,
  dropdownCalVal: dropdownValReducer,
  dynamicMenuVal: dynamicMenuReducer,
  bidDropdownCalVal: bidDropdownValReducer,
  statDropdownCalVal: statDropdownValReducer,
  nettingData: advanceFilterReducer,
  gemNettingData: gemFilterReducer,
  pmgsyNettingData: pmgsyFilterReducer,
  irepsNettingData: irepsFilterReducer,
  eprocNettingData: eprocFilterReducer,
  checkoutData: checkoutReducer,
  statCheckoutData: StatCheckoutReducer,
  seoValues: seoRequestValueReducer,
  socket: socketReducer,
  calendar: calendarReducer,
  navigationData: navigationDataReducer,
  persist: empersistReducer,
  StatFilter : StatFilterReducer,
  blogdata : BlogReducer,
  bidMenuVal:BidMenuReducer
  // session: sessionReducer
});

const persistConfig = {
  key: 'empersistReducer',
  version: 1,
  storage,
  whitelist: [
    'dynamicMenuVal',
    'seoValues',
    "dropdownCalVal",
    "bidDropdownCalVal",
    'loginData',
    "cycleFilter",
    "misFilter",
    "trashFilter",
    "userDetails",
    "persist",
    "myTenderList",
    "companyData",
    "nettingData",
    "checkoutData",
    "calendar",
    "statDropdownCalVal",
    "companyStatBalance",
    "StatFilter",
    
    "statCheckoutData",
    "gemNettingData",
    "irepsNettingData",
    "eprocNettingData",
    "pmgsyNettingData",
    "blogdata",
    "bidMenuVal"
  ]
};

const syncMiddleware = createStateSyncMiddleware({
  whitelist: [
    'loginData',
    "userDetails",
  ],
  broadcastChannelOption: {
    type: 'localstorage', // Use localStorage for state synchronization between tabs
    persistence: 'permanent', // Store the state permanently in localStorage
  },
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = createStore(persistedReducer, composeWithDevTools(applyMiddleware(thunk, syncMiddleware)));
initMessageListener(store);


const persistor = persistStore(store);

window.addEventListener("storage", (event) => {
  if (event.key === "auth" && !event.newValue) {
    store.dispatch(userLogoutAction());
  }
});

export { persistor, store };