// @ts-nocheck
import {
    MIS_FILTER_INACTION_REQUEST,
    MIS_FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS,
    MIS_FILTER_INACTION_FAILED,
    // MIS_FILTER_INACTION_REQUEST,
    MIS_FILTER_UPDATE_ALL_KEYS_OBJECTS,
    // MIS_FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS,
    MIS_FILTER_RESET_ARR_KEYS,
    MIS_FILTER_RESET_INDIVIDUAL_ARR_OBJECTS,
    MIS_FILTER_IS_UPDATE_RESET_TRUE,
    MIS_FILTER_IS_UPDATE_RESET,
} from "../../constants/bidgrid/bidgridConstants";

let misFilterValObj = {
    limit: 25,
    page_number: '',
    country_id: '',
    state_id: '',
    sector_id: '',
    tender_keyword: '',
    from_date: '',
    to_date: '',
    client_id: '',
    currency_id: '',
    funding_id: '',
    tender_status: '',
    published_date: '',
    close_exp_date: '',
    estm_value: '',
    estm_value_emd: '',
    pubdate_cust_from_date: '',
    pubdate_cust_to_date: '',
    expdate_cust_from_date: '',
    expdate_cust_to_date: '',
    amnt_custrange_operator: '',
    amnt_custrange_amount: '',
    custrange_denomination: '',
    amnt_custrange_operator_emd: '',
    amnt_custrange_amount_emd: '',
    custrange_denomination_emd: '',
    cycle_id: '',
    tender_result_id: '',
    generated_type: '',
    bid_manager_filter: '',
    key_manager_filter: '',
    orderSerial: '8',
    tender_activity_status: '',
    located: '',
    filter_fin_year: '',
    sort_key: '',
    sort_val: '',

}

const convertObjectToArr = (val) => {
    const chipsArr = Object.entries(val).map(([key, value]) => ({ key, value }));
    return chipsArr;
}

export const initialState = {
    misFilterValues: misFilterValObj,
    misFilterChips: convertObjectToArr(misFilterValObj),
    // stateValue: [],
    isUpdate: false,
    error: ''
};

const MisFilterReducer = (state = initialState, { type, payload }) => {
    // debugger;
    switch (type) {

        case MIS_FILTER_INACTION_REQUEST:
            return { ...state };

        case MIS_FILTER_UPDATE_ALL_KEYS_OBJECTS:
            // debugger;
            const updatedmisFilterValues = { ...payload };
            return { ...state, misFilterValues: updatedmisFilterValues, misFilterChips: convertObjectToArr(updatedmisFilterValues), isUpdate: true };

        // CAN BE USED AS APPLY TEMPLATE TOO
        case MIS_FILTER_UPDATE_INDIVIDUAL_OBJECTS_KEYS:
            const updatedmisFilterValuesIndividual = { ...state.misFilterValues, ...payload };
            const updatedFilterChipsIndividual = state.misFilterChips.map(chip => {

                if (payload[chip.key] !== undefined) {
                    updatedmisFilterValuesIndividual[chip.key] = payload[chip.key];
                    return { key: chip.key, value: payload[chip.key] };
                }
                return chip;
            });

            return { ...state, misFilterValues: updatedmisFilterValuesIndividual, misFilterChips: updatedFilterChipsIndividual, isUpdate: true };

        case MIS_FILTER_RESET_INDIVIDUAL_ARR_OBJECTS:

            const resetKey = payload;

            let updatedmisFilterValuesReset = { ...state.misFilterValues };
            resetKey?.map((item) => {
                return updatedmisFilterValuesReset[item] = ''
            })
            return { ...state, misFilterValues: updatedmisFilterValuesReset, misFilterChips: convertObjectToArr(updatedmisFilterValuesReset), isUpdate: true };
            // if (state.misFilterValues.hasOwnProperty(resetKey)) {
            //     const updatedmisFilterValuesReset = {
            //         ...state.misFilterValues,
            //         [resetKey]: '',
            //     };

            //     const updatedFilterChipsReset = state.misFilterChips.map(chip => {
            //         if (chip.key === resetKey) {
            //             return { key: chip.key, value: '' };
            //         }
            //         return chip;
            //     });
            //     return { ...state, misFilterValues: updatedmisFilterValuesReset, misFilterChips: updatedFilterChipsReset, isUpdate: true };
            // }
            return state;

        case MIS_FILTER_RESET_ARR_KEYS:
            return { ...state, misFilterValues: misFilterValObj, misFilterChips: convertObjectToArr(misFilterValObj), isUpdate: true };

        case MIS_FILTER_IS_UPDATE_RESET:
            return { ...state, isUpdate: false };

        case MIS_FILTER_IS_UPDATE_RESET_TRUE:
            return { ...state, isUpdate: true };

        case MIS_FILTER_INACTION_FAILED:
            return { ...state, error: payload, isUpdate: false };

        // case FILTER_UPDATE_STATE_VAL:
        //     return { ...state, stateValue: payload, isUpdate: true };

        default:
            return state;
    }
};


// const calInital = {
//     events: []
// }
// export const calendarReducer = (state = calInital, action) => {
//     switch (action.type) {
//         case CALENDAR_REQUEST:
//             return { ...state }
//         case CALENDAR_SUCCESS:
//             return {
//                 ...state,
//                 events: action.payload,
//             };
//         case CALENDAR_FAILED:
//             return { ...state };
//         default:
//             return state;
//     }
// };


export default MisFilterReducer;

