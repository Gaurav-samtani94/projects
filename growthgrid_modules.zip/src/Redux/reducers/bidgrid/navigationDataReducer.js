import { BID_DYNAMIC_MENU_FAILED, BID_DYNAMIC_MENU_REQUEST, BID_DYNAMIC_MENU_SUCCESS, NAVIGATION_DATA } from "Redux/constants/bidgrid/bidgridConstants";
const initialState = {
    navigateData: {}
};

const navigationDataReducer = (state = initialState, action) => {
    switch (action.type) {
        case NAVIGATION_DATA:
            return {
                ...state,
                navigateData: action.payload,
            };
        default:
            return state;
    }
};


export const BidMenuReducer = (state = { bidMenu: [], }, { type, payload }) => {
    switch (type) {
        case BID_DYNAMIC_MENU_REQUEST:
            return { ...state }
        case BID_DYNAMIC_MENU_SUCCESS:
            return { ...state, bidMenu: payload }
        case BID_DYNAMIC_MENU_FAILED:
            return { ...state, error: payload }
        default: return state
    }
}

export default navigationDataReducer;