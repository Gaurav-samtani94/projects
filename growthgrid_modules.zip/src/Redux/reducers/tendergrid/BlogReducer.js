import { BLOG_INACTION_FAILED, BLOG_INACTION_REQUEST, BLOG_UPDATE_ALL_KEYS_OBJECTS } from "Redux/constants/tendergrid/BlogConstant";


let blogValObj = {
    limit: 25,
    Page_number: 1,
    category_id: "",
}

export const initialState = {
    blogValues: blogValObj,
    isUpdate: false,
    error: ''
};

const BlogReducer = (state = initialState, { type, payload }) => {
    switch (type) {
        case BLOG_INACTION_REQUEST:
            return { ...state }
        case BLOG_UPDATE_ALL_KEYS_OBJECTS:
            const blogUpdateValues = { ...payload };
            return { ...state, blogValues: blogUpdateValues, isUpdate: true }
        case BLOG_INACTION_FAILED:
            return { ...state, error: payload, isUpdate: false };

        default:
            return state;

    }

}

export default BlogReducer