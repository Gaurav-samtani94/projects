// reducers/tenderListReducer.js
const initialState = null;

const tenderListReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'SET_TENDER_LIST':
      return action.payload;
    default:
      return state;
  }
};

export default tenderListReducer;
