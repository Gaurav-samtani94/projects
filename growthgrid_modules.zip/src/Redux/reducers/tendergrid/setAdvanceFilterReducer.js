import { ERROR_SET_NETTING_FILTER, SET_NETTING_FILTER_WITH_AUTH, SET_NETTING_FILTER_WITHOUT_AUTH } from '../../constants/tendergrid/setAdvanceFilterConstant';

const initialState = {
    message: ''
};

export const userSocialDataReducer = (state = initialState, { type, payload }) => {
    switch (type) {
        case SET_NETTING_FILTER_WITH_AUTH:
            return { ...state, message: payload }
        case SET_NETTING_FILTER_WITHOUT_AUTH:
            return { ...state, message: payload }
        case ERROR_SET_NETTING_FILTER:
            return { ...state, error: payload }
        default: return state
    }
}