// @ts-nocheck
import { bidProspective } from "Services/bidgrid/prospective/bidProspective";
import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { bidClientAction, bidCountryAction, bidFundingClientAction, bidLeadCompanyAction, bidSectorAction, bidCurrencyAction, bidServiceProviderAction } from "Redux/actions/common/DropdownAction";
import { AddTenderList } from "Services/bidgrid/add/AddTender";

const BidGridMaster = () => {

    const { BidClient } = useSelector((state) => state.bidDropdownCalVal)
    const { BidFundingClientAgency } = useSelector((state) => state.bidDropdownCalVal)
    const { BidCountry } = useSelector((state) => state.bidDropdownCalVal)
    const { BidLeadCompany } = useSelector((state) => state.bidDropdownCalVal)
    const { BidSector } = useSelector((state) => state.bidDropdownCalVal)
    const { BidCurrency } = useSelector((state) => state.bidDropdownCalVal)
    const { BidServiceProviders } = useSelector((state) => state.bidDropdownCalVal)
    const { bidgridData } = useSelector((state) => state.loginData)
    const objDetiail = new FormData()
    const dispatch = useDispatch()

    const getBidClient = async () => {
        try {
            const res = await bidProspective.getClientList()
            if (res?.data?.status === '1') {
                dispatch(bidClientAction(res?.data?.data))
            }
        } catch {
            dispatch(bidClientAction([]))
        }
    }

    const getFundingClient = async () => {
        try {
            const res = await bidProspective.getFundingAgencyList()
            if (res?.data?.status === '1') {
                dispatch(bidFundingClientAction(res?.data?.data))
            }
        } catch {
            dispatch(bidFundingClientAction([]))

        }
    }

    const getBidCountry = async () => {
        try {
            const res = await bidProspective.getCountryList()
            if (res?.data?.status === '1') {
                dispatch(bidCountryAction(res?.data?.data))
            }
        } catch {
            dispatch(bidCountryAction([]))

        }
    }
    const getBidCurrency = async () => {
        try {
            const res = await AddTenderList.getTenderCurrencyList()
            if (res?.data?.status === '1') {
                dispatch(bidCurrencyAction(res?.data?.data))
            }
        } catch {
            dispatch(bidCurrencyAction([]))

        }
    }


    const getBidLeadCompany = async () => {
        try {
            const res = await bidProspective.getLeadCompanyList()
            if (res?.data?.status === '1') {
                dispatch(bidLeadCompanyAction(res?.data?.data))
            }
        } catch {
            dispatch(bidLeadCompanyAction([]))

        }
    }

    const getBidSector = async () => {
        try {
            const res = await bidProspective.getSectorList()
            if (res?.data?.status === '1') {
                dispatch(bidSectorAction(res?.data?.data))
            }
        } catch {
            dispatch(bidSectorAction([]))
        }
    }


    useEffect(() => {

        if (BidClient?.length > 0) {
            return
        } else {
            if (bidgridData?.token) {
                getBidClient()
            }

        }
    }, [BidClient, bidgridData])

    useEffect(() => {

        if (BidFundingClientAgency?.length > 0) {
            return
        } else {
            if (bidgridData?.token) {
                getFundingClient()
            }

        }
    }, [BidFundingClientAgency, bidgridData])


    useEffect(() => {

        if (BidCountry?.length > 0) {
            return
        } else {
            if (bidgridData?.token) {
                getBidCountry()
            }

        }
    }, [BidCountry, bidgridData])

    useEffect(() => {
        if (BidCurrency?.length > 0) {
            return
        } else {
            if (bidgridData?.token) {
                getBidCurrency()
            }

        }

    }, [BidCurrency, bidgridData])

    useEffect(() => {

        if (BidLeadCompany?.length > 0) {
            return
        } else {
            if (bidgridData?.token) {
                getBidLeadCompany()
            }
        }
    }, [BidLeadCompany, bidgridData])

    useEffect(() => {

        if (BidSector?.length > 0) {
            return
        } else {
            if (bidgridData?.token) {
                getBidSector()
            }
        }

    }, [BidSector, bidgridData])


}


export default BidGridMaster



