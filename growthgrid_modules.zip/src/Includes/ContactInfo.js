import React from 'react'
import FacebookOutlinedIcon from '@mui/icons-material/FacebookOutlined';
import TwitterIcon from '@mui/icons-material/Twitter';
import InstagramIcon from '@mui/icons-material/Instagram';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import LocalPhoneIcon from '@mui/icons-material/LocalPhone';
import EmailIcon from '@mui/icons-material/Email';
import PinterestIcon from '@mui/icons-material/Pinterest';

function ContactInfo() {
    return (
        <>
            <div className="topHeader hide--mobile">
                <div className="contact-item">
                    <div className="">
                        <ul className="social-icon-three">
                            <li>
                                <a href="https://www.facebook.com/profile.php?id=100091305726028" target="_blank" rel="noopener noreferrer">
                                    <span><FacebookOutlinedIcon /></span>
                                </a>
                            </li>
                            <li>
                                <a href=" https://twitter.com/GridsGrowth" target="_blank" rel="noopener noreferrer">
                                    <span><TwitterIcon /></span>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/growthgrids/" target="_blank" rel="noopener noreferrer">
                                    <span><InstagramIcon /></span>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.linkedin.com/company/93260427" target="_blank" rel="noopener noreferrer">
                                    <span><LinkedInIcon /></span>
                                </a>
                            </li>
                            {/* <li>
                                <a href="" target="_blank" rel="noopener noreferrer">
                                    <span><PinterestIcon /></span>
                                </a>
                            </li> */}
                        </ul>
                    </div>
                    <div className="responsive_size">
                        <span className="mx-2">
                            <span className="text-dark">
                                <LocalPhoneIcon />Sales Number:
                                <a href="tel:+919773356001">+91-9773356001</a>
                            </span>
                        </span>
                        <span className="mx-2">
                            <span className="text-dark">
                                <LocalPhoneIcon />Support Number:
                                <a href="tel:+919773356002">+91-9773356002</a>
                            </span>
                        </span>
                        <span className="mx-2">
                            <span className="text-dark">
                                <EmailIcon /> Email:
                                <a href="mailto:business@growthgrids.com">
                                    business@growthgrids.com
                                </a>
                            </span>
                        </span>
                    </div>
                    {/* <div className=""><span className="text-dark">Available Credit 150/200  </span></div> */}
                </div>
            </div>

        </>
    )
}

export default ContactInfo
