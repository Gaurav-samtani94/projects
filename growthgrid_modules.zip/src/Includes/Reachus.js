// @ts-nocheck
import React from "react";

import Footer from "./Footer";
import Header from "./Header";

const Reachus = () => {
    return (
        <>

            <div style={{marginTop:"70px"}}> 
                <div className="py-4 py-md-5 py-lg-5 reach-us ">
                    <div className="mx-auto main-width">
                        <h2 className="main-heading">Reach Us</h2>
                        <div className="mx-auto main-border"></div>


                        <div style={{width:'100%'}} className="row d-flex  justify-content-center">
                            {/* <div className="col-12 col-md-4 my-auto">
                <div className="card-contact mb-3">
                    <h6 className="cardcontact-heading">The Vice Chancellor</h6>
                    <p className="mb-0">Jaypee University Anoopshahr, Aligarh Road Anoopshahr-203390</p>
                    <p>District- Bulandshahr, Uttar Pradesh, India.</p>
                </div>

                <div className="card-contact">
                    <h6 className="cardcontact-heading">The Vice Chancellor</h6>
                    <p className="mb-0">Jaypee University Anoopshahr, Aligarh Road Anoopshahr-203390</p>
                    <p>District- Bulandshahr, Uttar Pradesh, India.</p>
                </div>
            </div> */}

                            <div className="col-12 col-md-8 pt-4 mt-5 pt-md-0 pt-lg-0">
                                <div className="jaypee-map shadow-reachus">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3559.480190364713!2d75.82801781451944!3d26.856480768975132!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db66a78979dc7%3A0xc04a015cee43e8fc!2sConsulting%20Engineers%20Group%20Ltd.!5e0!3m2!1sen!2sin!4v1677010395066!5m2!1sen!2sin" 
                                style={{border:'0px'}} 
                                width="100%"
                                height="450"
                                allowfullscreen="" 
                                loading="lazy" 
                                referrerpolicy="no-referrer-when-downgrade">
                                </iframe>
                            
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
                </div>

            </>

            );
}

            export default Reachus;