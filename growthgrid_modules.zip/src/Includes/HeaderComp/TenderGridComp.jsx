// @ts-nocheck
import React, { useEffect, useState } from 'react'
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import { useSelector, useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import close from "../../assests/img/skip-back.png";
import ROUTES from "Constants/Routes";
import managementData from "../../assests/img/data-management.png";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import { Log } from '@icon-park/react';
import { baseUrl } from 'utils/configurable';
import { setNettingAction } from 'Redux/actions/tendergrid/setNettingAction';

function TenderGridComp({ openDrawer, setOpenDrawer, setOpenLogin }) {
    const { dynamicMenu } = useSelector((state) => state.dynamicMenuVal);
    const dispatch = useDispatch()
    const navigate = useNavigate();
    const [selectedSubmenu, setSelectedSubmenu] = useState(false);
    const [submenuFldId, setSubmenuFldId] = useState(null);
    const [headName, setHeadName] = useState("");
    const { userData } = useSelector((state) => state.loginData);
    const { dropdownValues } = useSelector((state) => state.dropdownCalVal);
    const nettingData = useSelector((state) => state.nettingData);
    const [isMobileView, setIsMobileView] = useState(false);
    const [menuHide, setMenuHide] = useState(false);
    const [mobileDisplay, setMobileDisplay] = useState(window.innerWidth >= 991);
    const [redirectUrl, setRedirectUrl] = useState('')

    useEffect(() => {
        const handleResize = () => {
            setMobileDisplay(window.innerWidth >= 991);
        };

        window.addEventListener('resize', handleResize);

        return () => {
            window.removeEventListener('resize', handleResize);
        };
    }, []);




    const handleHCSL = (e, obj) => {
        if (obj?.fld_id === '7') {
            setOpenDrawer(false);
        }
        e.preventDefault();
        // setOpenDrawer(false)
        if (obj.hasOwnProperty("child")) {
            setOpenDrawer(false)
            return;
        } else {
            navigate(ROUTES.ROOT + obj?.action_url);
        }
    };
    const handleCloseDrawer = () => {
        setOpenDrawer(false);
    };


    const mobileNavigate = (item, index) => {

        if ((item?.fld_id === '3') || (item?.fld_id === '4') || (item?.fld_id === '5')) {
            setHeadName(item?.menu_name);
            if ((item?.fld_id === '14' || item?.fld_id === '15') && !userData?.user_data?.loginid) {
                setOpenLogin(true)
            }
            else {
                setSelectedSubmenu(true);
                setSubmenuFldId(item?.fld_id);
            }
        }
        else {
            setOpenDrawer(false)
            navigate(`/${item?.action_url}`);
        }
    }

    const navigatetender = (item) => {
        if (item?.fld_id === '2' || item.fld_id === "14" || item.fld_id === "15") {
            setOpenDrawer(false)
            if ((item?.fld_id === '14' || item?.fld_id === '15') && !userData?.user_data?.loginid) {
                setOpenLogin(true)

            } else {
                navigate(`/${item?.action_url}`);

            }
        }
    };

    const handledrawer = () => {
        setOpenDrawer(!openDrawer);
    };

    // const handleViewAll = (item) => {
    //     setMenuHide(false)
    //     closemenu()
    //     navigate(`/${item?.action_url}`);  
    // };

    const handleViewAll = (item) => {

        setMenuHide(false)
        closemenu()

        navigate(`/${item?.action_url}`);


    };





    const closemenu = () => {
        setMenuHide(true);
        setTimeout(() => {
            setMenuHide(false);
        }, 1);
    }


    const commonISCGWise = (e, obj, encodedString, type) => {
        e.preventDefault();
        setSelectedSubmenu(false)
        setOpenDrawer(false)
        sessionStorage.setItem('hasUsedNavigatingData', '');
        dynamicMenu?.filter(val => val.fld_id === '1').map((val) => {
            val.child?.filter((value) => value.fld_id === '2')?.map((val) => {
                navigate(`/${val.action_url}/${type}/${encodedString}`, { state: obj })
            })
        })
        setMenuHide(true);
        setTimeout(() => {
            setMenuHide(false);
        }, 1);
    }
    const handleClient = (e, id, name) => {
        // let updatedName = name.toLowerCase().split(' ').join('-').split('&').join('and').split('(').join('').split(')').join('');
        // let updatedName = name.toLowerCase().replace(/\s+/g, ' ').split(' ').join('-').split('&').join('and').split(',').join('-').split('.').join('').split('(').join('').split(')').join('');
        let updatedName = name.toLowerCase().replace(/\s+/g, ' ')
            .replace(/[^a-zA-Z0-9\s&,.()]+/g, '')
            .split(' ')
            .map(word => word.replace(/[^a-zA-Z0-9]+/g, ''))
            .filter(word => word.length > 0)
            .join('-').split(' ').join('-').split('&').join('and').split(',').join('-').split('.').join('').split('(').join('').split(')').join('').split(" - ").join(" ");
        updatedName += '-tenders';
        const encodedString = encodeURIComponent(updatedName);
        const type = "authority"
        const obj = {
            ...nettingData,
            client_id: id,
            page_number: 0,
            limit: 25,
            sort_key: '',
            sort_val: '',
            page_name: 'tender-list'
        }
        commonISCGWise(e, obj, encodedString, type)
    }




    const handleSector = (e, id, name) => {
        let updatedName = name.toLowerCase().split(' ').join('-').split(",").join("-").split('&').join('and').split('(').join('').split(')').join('');
        const encodedString = encodeURIComponent(updatedName);
        const type = "sector"
        const obj = {
            ...nettingData,
            sector_id: id,
            page_number: 0,
            limit: 25,
            sort_key: '',
            sort_val: '',
            page_name: 'tender-list'
        }
        commonISCGWise(e, obj, encodedString, type)
    }

    const handleState = (e, id, name) => {
        // let updatedName = name.toLowerCase().split(' ').join('-').split('&').join('and').split('(').join('-').split(')').join('-tenders');
        let updatedName = name.toLowerCase().split(' ').join('-').split('&').join('and').split('(').join('').split(')').join('');
        updatedName += '-tenders';
        const encodedString = encodeURIComponent(updatedName);
        const type = "state"
        const obj = {
            ...nettingData,
            state_id: id,
            page_number: 0,
            limit: 25,
            sort_key: '',
            sort_val: '',
            page_name: 'tender-list',
            region_id: ""
        }
        commonISCGWise(e, obj, encodedString, type)
    }






    const handleStateFocus = (id, name) => {
        // let updatedName = name.toLowerCase().split(' ').join('-').split('&').join('and').split('(').join('-').split(')').join('-tenders');

        let updatedName = name.toLowerCase().split(' ').join('-').split('&').join('and').split('(').join('').split(')').join('');
        updatedName += '-tenders';
        const encodedString = encodeURIComponent(updatedName);
        const type = "state"
        const obj = {
            ...nettingData,
            state_id: id,
            page_number: 0,
            limit: 25,
            sort_key: '',
            sort_val: '',
            page_name: 'tender-list',
            region_id: ""
        }
        let url = NewTabUrl(encodedString, type);
        setRedirectUrl(url)
        if (redirectUrl !== '') {
            return dispatch(setNettingAction(obj))
        }

    }


    const handleSectorFocus = (id, name) => {
        // window.location.reload(true);
        let updatedName = name.toLowerCase().split(' ').join('-').split('&').join('and').split('(').join('').split(')').join('');
        const encodedString = encodeURIComponent(updatedName);
        const type = "sector"
        const obj = {
            ...nettingData,
            sector_id: id,
            page_number: 0,
            limit: 25,
            sort_key: '',
            sort_val: '',
            page_name: 'tender-list'
        }
        dispatch(setNettingAction(obj))
        let url = NewTabUrl(encodedString, type);
        setRedirectUrl(url)
    }

    const handleClientFocus = (id, name) => {
        let updatedName = name
            .toLowerCase() // Convert to lowercase
            .replace(/\s+/g, '-')
            .replace(/[^a-zA-Z0-9\s,.()-]/g, '') // Remove special characters except space, &, , , (, and )
            .replace(/(-and-|-of-|-in-)/ig, '-$1') // Correct hyphens around certain words
            .replace(/(^-+|-+$)/g, '')
            .replace(/\./g, '-')
            .replace(/\(/g, '-')    // .replace(/%2C$/, '-')
            .split("(").join("").split(')').join("").split("&").join("").split(",").join("-");

        updatedName = `${updatedName.replace(/-+/g, '-')}-tenders`;
        const encodedString = encodeURIComponent(updatedName);
        const type = "authority"
        const obj = {
            ...nettingData,
            client_id: id,
            page_number: 0,
            limit: 25,
            sort_key: '',
            sort_val: '',
            page_name: 'tender-list'
        }

        let url = NewTabUrl(encodedString, type, obj);
        setRedirectUrl(url)
        dispatch(setNettingAction(obj))
    }




    const NewTabUrl = (encodedString, type, obj) => {
        let newUrl = ''
        sessionStorage.setItem('hasUsedNavigatingData', '');
        // dispatch(setNettingAction(obj))
        dynamicMenu?.filter(val => val.fld_id === '1').map((val) => {
            val.child?.filter((value) => value.fld_id === '2')?.map((val) => {
                newUrl = `/${val.action_url}/${type}/${encodedString}`
            })
        })

        return newUrl
    };





    const handleMobileView = () => {
        setIsMobileView(!isMobileView)
    }
    const [loggedIn, setLoggedIn] = useState(false)
    useEffect(() => {
        const handleStorageChange = (event) => {
            if (event.key === "persist:empersistReducer") {
                checkLoggedIn();
            }
        };

        window.addEventListener("storage", handleStorageChange);

        return () => {
            window.removeEventListener("storage", handleStorageChange);
        };
    }, []);

    // const checkLoggedIn = () => {
    //     const storedUser = JSON.parse(localStorage.getItem("persist:empersistReducer"));
    //     let userDetailsData = JSON.parse(storedUser?.loginData)

    //     // console.log(userDetailsData.userData.token,"ooooo");
    //     setLoggedIn(!!(userDetailsData.userData.token));
    // };
    // useEffect(() => {
    //     checkLoggedIn()
    // }, [])log


    const checkLoggedIn = () => {
        const storedUser = JSON?.parse(localStorage.getItem("persist:empersistReducer"));
        if (storedUser) {
            let userDetailsData = JSON?.parse(storedUser?.loginData);
            if (userDetailsData && userDetailsData.userData && userDetailsData.userData.token) {
                setLoggedIn(true);
            } else {
                setLoggedIn(false);
            }
        } else {
            setLoggedIn(false);
        }
    };

    useEffect(() => {
        checkLoggedIn();
    }, []);

    const handleCloseState = () => {
        navigate(ROUTES?.STATE_WISE_TENDER)
        // handleViewAll()
        setOpenDrawer(false)
        setSelectedSubmenu(false);
    }

    const handleCloseSector = () => {
        navigate(ROUTES?.CATEGORY_WISE_TENDER)
        // handleViewAll()
        setOpenDrawer(false)
        setSelectedSubmenu(false);
    }

    const handleCloseAuthority = () => {
        navigate(ROUTES?.ORGANIZATION)
        // handleViewAll()
        setOpenDrawer(false)
        setSelectedSubmenu(false);
    }



    return (
        <>
            <div className='header_side_menu'>
                <ul className="main-menu mainMenuNew">

                    {dynamicMenu

                        ?.filter((val) => val.fld_id === "1")
                        .map((value) => {

                            return (value?.child)
                                ?.filter(
                                    (val) => {

                                        return (
                                            val.fld_id === "2" ||
                                            val.fld_id === "3" ||
                                            val.fld_id === "4" ||
                                            val.fld_id === "5"
                                        )

                                    }

                                )
                                ?.map((item, index) => {
                                    return (
                                        <>
                                            <li
                                                key={index}
                                                className={`nav-item ${item?.fld_id !== "2" &&
                                                    item?.fld_id !== "14" &&
                                                    item?.fld_id !== "15" &&
                                                    "dropdown"
                                                    }`}
                                            >
                                                <span
                                                    onClick={() => {
                                                        if (
                                                            item?.fld_id === "2" ||
                                                            item?.fld_id === "3" ||
                                                            item?.fld_id === "4" ||
                                                            item?.fld_id === "5"

                                                        ) {
                                                            window.innerWidth < 1000 ?
                                                                mobileNavigate(item, index) :
                                                                <>
                                                                    {navigatetender(item, index)}
                                                                    {handleViewAll(item)}
                                                                </>
                                                        } else {

                                                        }

                                                    }}
                                                    className={`nav-link ${item?.fld_id !== "2" &&
                                                        item?.fld_id !== "14" &&
                                                        item?.fld_id !== "15" &&
                                                        "dropdown-toggle active"
                                                        }`}

                                                >
                                                    {item?.menu_name}
                                                </span>



                                                {item?.fld_id !== "2" &&
                                                    item?.fld_id !== "14" &&
                                                    item?.fld_id !== "15" && (
                                                        <div
                                                            className={
                                                                selectedSubmenu
                                                                    ? "dropdown-menu mega-menu visbleSubMenu"
                                                                    : "dropdown-menu mega-menu"
                                                            }
                                                            aria-labelledby="navbarDropdown"
                                                            style={
                                                                menuHide
                                                                    ? { display: "none" }
                                                                    : null
                                                            }
                                                        >
                                                            <div className="row">
                                                                <div className="col-sm-2 display-none-cont">
                                                                    <div
                                                                        // onClick={closemenu}
                                                                        onClick={() =>
                                                                            handleViewAll(item)

                                                                        }
                                                                        className="mianMenu_full"
                                                                    >
                                                                        <img
                                                                            src={managementData}
                                                                            width={90}
                                                                        />
                                                                        <span>
                                                                            {" "}
                                                                            View All{" "}
                                                                            <ArrowForwardIcon fontSize="inherit" />{" "}
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <div className="col-sm-10">
                                                                    <div className="submenu-close">
                                                                        <img
                                                                            className="navbar_inner_close"
                                                                            src={close}
                                                                            onClick={() =>
                                                                                setSelectedSubmenu(
                                                                                    !selectedSubmenu
                                                                                )
                                                                            }

                                                                        />
                                                                        <span>{headName}</span>
                                                                    </div>

                                                                    <div className="subMenu_grid">
                                                                        {(item.fld_id === "3" ||
                                                                            submenuFldId === "3") && (
                                                                                <>
                                                                                    {dropdownValues?.state
                                                                                        ?.filter(
                                                                                            (val) =>
                                                                                                val?.state_name !==
                                                                                                "NA"
                                                                                        )
                                                                                        ?.sort((a, b) =>
                                                                                            a.state_name?.localeCompare(
                                                                                                b.state_name
                                                                                            )
                                                                                        )
                                                                                        ?.slice(0, 9)
                                                                                        ?.map(
                                                                                            (state, index) => {
                                                                                                return (
                                                                                                    <Link
                                                                                                        to={redirectUrl}
                                                                                                        // onClick={(e) => handleState(e, state?.state_id, state?.state_name)}
                                                                                                        onFocus={() => handleStateFocus(state?.state_id, state?.state_name)}
                                                                                                    >
                                                                                                        <div
                                                                                                            key={index}
                                                                                                            className="sb_menu"
                                                                                                            onClick={(e) =>
                                                                                                                handleState(
                                                                                                                    e,
                                                                                                                    state?.state_id,
                                                                                                                    state?.state_name
                                                                                                                )
                                                                                                            }
                                                                                                        >
                                                                                                            {
                                                                                                                capitalizeExceptPrepositionsAndLowerCase(state?.state_name)
                                                                                                            }
                                                                                                            <ArrowForwardIosIcon />
                                                                                                        </div>
                                                                                                    </Link>
                                                                                                );
                                                                                            }
                                                                                        )}

                                                                                    {window.innerWidth < 1000 &&
                                                                                        <div
                                                                                            className="sb_menu mobile_view_all"
                                                                                            onClick={
                                                                                                handleCloseState
                                                                                            }
                                                                                        >
                                                                                            <span>View All
                                                                                                <ArrowForwardIcon fontSize="inherit" />
                                                                                            </span>
                                                                                        </div>}
                                                                                </>
                                                                            )}
                                                                        {(item.fld_id === "4" ||
                                                                            submenuFldId === "4") && (
                                                                                <>
                                                                                    {dropdownValues?.sector
                                                                                        ?.sort((a, b) =>
                                                                                            a.sectName?.localeCompare(
                                                                                                b.sectName
                                                                                            )
                                                                                        )
                                                                                        .slice(0, 9)
                                                                                        .map((sect, index) => {
                                                                                            return (
                                                                                                <Link
                                                                                                    to={redirectUrl}
                                                                                                    // onClick={(e) => handleState(e, state?.state_id, state?.state_name)}
                                                                                                    onFocus={() => handleSectorFocus(sect?.fld_id, sect?.sectName)}
                                                                                                >
                                                                                                    <div
                                                                                                        className="sb_menu"
                                                                                                        onClick={(e) =>
                                                                                                            handleSector(
                                                                                                                e,
                                                                                                                sect?.fld_id,
                                                                                                                sect?.sectName
                                                                                                            )
                                                                                                        }
                                                                                                    >
                                                                                                        {capitalizeExceptPrepositionsAndLowerCase(sect?.sectName)}
                                                                                                        <ArrowForwardIosIcon />
                                                                                                    </div>
                                                                                                </Link>

                                                                                            );
                                                                                        })}


                                                                                    {window.innerWidth < 1000 &&
                                                                                        <div
                                                                                            className="sb_menu mobile_view_all"
                                                                                            onClick={
                                                                                                handleCloseSector
                                                                                            }
                                                                                        >
                                                                                            <span>View All
                                                                                                <ArrowForwardIcon fontSize="inherit" />
                                                                                            </span>
                                                                                        </div>}
                                                                                </>
                                                                            )}
                                                                        {window.innerWidth > 1000 && (item.fld_id === "5"
                                                                            && (
                                                                                <>
                                                                                    {dropdownValues?.client
                                                                                        ?.sort((a, b) =>
                                                                                            a.client_name?.localeCompare(
                                                                                                b.client_name
                                                                                            )
                                                                                        )
                                                                                        ?.slice(0, 9)
                                                                                        ?.map(
                                                                                            (client, index) => {
                                                                                                // console.log(client,'client');
                                                                                                return (
                                                                                                    <Link
                                                                                                        to={redirectUrl}
                                                                                                        onFocus={() => handleClientFocus(client?.fld_id, client?.client_name)}
                                                                                                    >
                                                                                                        <div
                                                                                                            className="sb_menu"
                                                                                                            onClick={(e) =>
                                                                                                                handleClient(
                                                                                                                    e,
                                                                                                                    client?.fld_id,
                                                                                                                    client.client_name,

                                                                                                                )
                                                                                                            }
                                                                                                        >
                                                                                                            {
                                                                                                                capitalizeExceptPrepositionsAndLowerCase(client.client_name)
                                                                                                            }
                                                                                                            <ArrowForwardIosIcon />
                                                                                                        </div>
                                                                                                    </Link>

                                                                                                );
                                                                                            }
                                                                                        )}


                                                                                </>
                                                                            ))}
                                                                        {window.innerWidth < 1000 &&
                                                                            (submenuFldId === "5" && (
                                                                                <>
                                                                                    {dropdownValues?.client
                                                                                        ?.sort((a, b) =>
                                                                                            a.client_name.localeCompare(
                                                                                                b.client_name
                                                                                            )
                                                                                        )
                                                                                        ?.slice(0, 9)
                                                                                        ?.map(
                                                                                            (client, index) => {
                                                                                                return (

                                                                                                    <div
                                                                                                        className="sb_menu"
                                                                                                        onClick={(e) =>
                                                                                                            handleClient(
                                                                                                                e,
                                                                                                                client?.fld_id,
                                                                                                                client.client_name
                                                                                                            )
                                                                                                        }
                                                                                                    >
                                                                                                        {
                                                                                                            capitalizeExceptPrepositionsAndLowerCase(client.client_name)
                                                                                                        }
                                                                                                        <ArrowForwardIosIcon />
                                                                                                    </div>

                                                                                                );
                                                                                            }
                                                                                        )}
                                                                                    {window.innerWidth < 1000 &&
                                                                                        <div
                                                                                            className="sb_menu mobile_view_all"
                                                                                            onClick={
                                                                                                handleCloseAuthority
                                                                                            }
                                                                                        >
                                                                                            <span>View All
                                                                                                <ArrowForwardIcon fontSize="inherit" />
                                                                                            </span>
                                                                                        </div>}

                                                                                </>
                                                                            ))
                                                                        }
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    )}
                                            </li >
                                        </>
                                    );
                                });
                        })}



                    {/* {dynamicMenu
                        ?.filter((val) => val.fld_id === "43")
                        .map((item, index) => {

                            return (
                                <li key={index} className="nav-item dropdown">
                                    <span
                                        onClick={(e) => handleHCSL(e, item)}
                                        className="nav-link dropdown-toggle active"
                                    >
                                        {item?.menu_name}
                                    </span>
                                    <div
                                        className={
                                            selectedSubmenu
                                                ? "dropdown-menu mega-menu visbleSubMenu"
                                                : "dropdown-menu mega-menu"
                                        }
                                        aria-labelledby="navbarDropdown"
                                        style={
                                            menuHide
                                                ? { display: "none" }
                                                : null
                                        }
                                    >


                                        <div className="row">
                                            <div className="col-sm-2 display-none-cont">
                                                <div
                                                    // onClick={closemenu}
                                                    onClick={() => navigate(ROUTES?.WEBSITE)
                                                    }
                                                    className="mianMenu_full"
                                                >
                                                    <img
                                                        src={managementData}
                                                        width={90}
                                                    />
                                                    <span>
                                                        {" "}
                                                        View All{" "}
                                                        <ArrowForwardIcon fontSize="inherit" />{" "}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="col-sm-10">
                                                <div className="submenu-close">
                                                    <img
                                                        className="navbar_inner_close"
                                                        src={close}
                                                        onClick={() =>
                                                            setSelectedSubmenu(
                                                                !selectedSubmenu
                                                            )
                                                        }

                                                    />
                                                    <span>{headName}</span>
                                                </div>

                                                <div className="subMenu_grid">
                                                    {(item.fld_id === "43" ||
                                                        submenuFldId === "43") && (
                                                            <>
                                                                {dropdownValues?.webSiteData
                                                                    ?.filter(
                                                                        (val) =>
                                                                            val?.url !==
                                                                            "NA"
                                                                    )
                                                                    ?.sort((a, b) =>
                                                                        a.url?.localeCompare(
                                                                            b.url
                                                                        )
                                                                    )
                                                                    ?.slice(0, 9)
                                                                    ?.map(
                                                                        (webSiteData, index) => {
                                                                            return (
                                                                                <div
                                                                                    key={index}
                                                                                    className="sb_menu"
                                                                                // onClick={(e) =>
                                                                                //     handleState(
                                                                                //         e,
                                                                                //         webSiteData?.fld_id,
                                                                                //         webSiteData?.url
                                                                                //     )
                                                                                // }

                                                                                >
                                                                                    {
                                                                                        capitalizeExceptPrepositionsAndLowerCase(webSiteData?.url)
                                                                                    }
                                                                                    <ArrowForwardIosIcon />
                                                                                </div>
                                                                            );
                                                                        }
                                                                    )}
                                                            </>
                                                        )}


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            );
                        })} */}

                    <li  className="nav-item dropdown">
                        <span
                            onClick={(e) => navigate(ROUTES?.TENDER_Notice)}
                            className="nav-link dropdown-toggle active"
                        >
                            Tender Notice
                        </span>
                        <div
                        // className={
                        //     selectedSubmenu
                        //         ? "dropdown-menu mega-menu visbleSubMenu"
                        //         : "dropdown-menu mega-menu"
                        // }
                        // aria-labelledby="navbarDropdown"
                        // style={
                        //     menuHide
                        //         ? { display: "none" }
                        //         : null
                        // }
                        >

                            {/* 
                            <div className="row">
                                <div className="col-sm-2 display-none-cont">
                                    <div
                                        // onClick={closemenu}
                                        onClick={() => navigate(ROUTES?.TENDER_Notice)
                                        }
                                        className="mianMenu_full"
                                    >
                                        <img
                                            src={managementData}
                                            width={90}
                                        />
                                        <span>
                                            {" "}
                                            View All{" "}
                                            <ArrowForwardIcon fontSize="inherit" />{" "}
                                        </span>
                                    </div>
                                </div>
                                <div className="col-sm-10">
                                    <div className="submenu-close">
                                        <img
                                            className="navbar_inner_close"
                                            src={close}
                                            onClick={() =>
                                                setSelectedSubmenu(
                                                    !selectedSubmenu
                                                )
                                            }

                                        />
                                        <span>{headName}</span>
                                    </div>

                                    <div className="subMenu_grid">
                                        {(item.fld_id === "43" ||
                                            submenuFldId === "43") && (
                                                <>
                                                    {dropdownValues?.webSiteData
                                                        ?.filter(
                                                            (val) =>
                                                                val?.url !==
                                                                "NA"
                                                        )
                                                        ?.sort((a, b) =>
                                                            a.url?.localeCompare(
                                                                b.url
                                                            )
                                                        )
                                                        ?.slice(0, 9)
                                                        ?.map(
                                                            (webSiteData, index) => {
                                                                return (
                                                                    <div
                                                                        key={index}
                                                                        className="sb_menu"
                                                                    // onClick={(e) =>
                                                                    //     handleState(
                                                                    //         e,
                                                                    //         webSiteData?.fld_id,
                                                                    //         webSiteData?.url
                                                                    //     )
                                                                    // }

                                                                    >
                                                                        {
                                                                            capitalizeExceptPrepositionsAndLowerCase(webSiteData?.url)
                                                                        }
                                                                        <ArrowForwardIosIcon />
                                                                    </div>
                                                                );
                                                            }
                                                        )}
                                                </>
                                            )}


                                    </div>
                                </div>
                            </div> */}
                        </div>
                    </li>


                </ul>
                <div className="social-link social_subscribe">
                    <div className="main-menu-right">
                        <ul className="navbar-nav main-menu subscribe_menu">
                            {/* {dynamicMenu
                                ?.filter((val) => val.fld_id === "12")
                                ?.map((item, index) => {
                                    return item?.child
                                        ?.filter(
                                            (val) =>
                                                val.fld_id === "14" || val.fld_id === "15"
                                        )
                                        ?.map((item, index) => {
                                            return (
                                                <li key={index} className="nav-item">
                                                    <span
                                                        onClick={() => navigatetender(item)}
                                                        className="nav-link"
                                                    >
                                                        {item?.menu_name}
                                                    </span>
                                                </li>
                                            );
                                        });
                                })} */}

                            <li className={mobileDisplay ? "nav-item has-child has-hover" : "nav-item has-child"}>
                                <span className="nav-link"
                                    onClick={() => {
                                        window.innerWidth < 1000 ?
                                            handleMobileView() :
                                            <></>
                                    }}
                                >My Tender  <ArrowDropDownIcon fontSize="small" />  </span>
                                {dynamicMenu
                                    ?.filter((val) => val.fld_id === "12")
                                    ?.map((item, index) => (
                                        <ul key={index} className={isMobileView ? "child-menu mobileBlock" : "child-menu displayBlock "}>
                                            {item?.child
                                                ?.filter((val) => val.fld_id === "14" || val.fld_id === "15")
                                                ?.map((childItem, childIndex) => (
                                                    <li key={childIndex} className="nav-item">
                                                        <span
                                                            onClick={() => navigatetender(childItem)}
                                                            className="nav-link"
                                                        >
                                                            {childItem?.menu_name}
                                                        </span>
                                                    </li>
                                                ))}
                                        </ul>
                                    ))}
                            </li>

                            {dynamicMenu
                                ?.filter((val) => val.fld_id === "7")
                                .map((item, index) => {
                                    return (
                                        <li key={index} className="nav-item">
                                            <span
                                                onClick={(e) => handleHCSL(e, item)}
                                                className="nav-link"
                                            >
                                                {item?.menu_name}
                                            </span>
                                        </li>
                                    );
                                })}
                        </ul>
                    </div>
                </div>
            </div >
        </>
    )
}

export default TenderGridComp
