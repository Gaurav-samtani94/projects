import Personal from 'BidGrid/pages/Personal'
import TaskManager from 'BidGrid/pages/TaskManager'
import React from 'react'

import "../../BidGrid/assets/css/app.scss"

function BidGrid() {
    return (
        <div>
            {/* <TaskManager /> */}
            < Personal />
        </div>
    )
}

export default BidGrid
