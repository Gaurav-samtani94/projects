// @ts-nocheck
import React, { useState, useEffect } from 'react'
import tenderGridLogo from "../../assests/img/tender-logo.png"
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import ROUTES from "Constants/Routes";
import { Log } from '@icon-park/react';
function StatGrid({ openDrawer, setOpenDrawer }) {
  const { dynamicMenu } = useSelector((state) => state.dynamicMenuVal);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  // const [openDrawer, setOpenDrawer] = useState(false);
  const [openLogin, setOpenLogin] = useState(false);
  const [active, setActive] = useState(null);
  const handleHCSL = (e, obj) => {

    if (obj?.fld_id === '7') {
      setOpenDrawer(false);
    }
    e.preventDefault();
    // setOpenDrawer(false)
    if (obj.hasOwnProperty("child")) {
      setOpenDrawer(false)
      return;
    } else {
      navigate(ROUTES.ROOT + obj?.action_url);
    }
  };

  const navigateStat = (item) => {
    if (item?.action_url == "stats") {
      navigate("/statgrid")
    } else {
      navigate(`/${item?.action_url}`);
    }
    setOpenDrawer(false)

  }
  const handleClick = () => {
    
    navigate("/statgrid/statgriddashboard ")
  }
  const navCalender = () => {
    navigate("/statgrid/statgridcalender")
  }
  return (
    <>
{/* 
      <ul className="main-menu">
        {dynamicMenu?.filter(val => val.fld_id === '8').map((value) => {
          return (
            value?.child?.filter(
              val => val.fld_id === "9"
                || val.fld_id === "10"
                || val.fld_id === "11"
            )?.map((item, index) => {
              return (
                <li key={index} className={`nav-item`}>
                  <span
                    onClick={() => navigateStat(item)}
                    className={`nav-link `}>
                    {item?.menu_name}
                  </span>

                </li>
              )
            }))
        })
        }

        <li className="nav-item">
          <span onClick={() => handleClick()} className="nav-link">Dashboard</span>
        <li className={`nav-item`}>
          <span
            onClick={navCalender}
            className={`nav-link `}>
            Calender
          </span>

        </li>
        </li>
        <li className="nav-item">
          <span onClick={() => navigate("/statgrid/companydashboard ")} className="nav-link">Company Details</span>
        </li>
      </ul>

      <div className="social-link social_subscribe">
        <div className="main-menu-right">
          <ul className="navbar-nav main-menu subscribe_menu">
            {dynamicMenu?.filter(val =>
              val.fld_id === '7').map((item, index) => {
                let showArr;
                if (item.hasOwnProperty('child')) {
                  showArr = true
                } else {
                  showArr = false
                }
                return (
                  <li key={index} className="nav-item">
                    <span onClick={(e) => handleHCSL(e, item)} className="nav-link">{item?.menu_name}</span>
                  </li>
                )
              })}
          </ul>
        </div>
      </div> */}

    </>
  )
}

export default StatGrid
