// @ts-nocheck
import { StatClientAction, StatCountryTypeAction, StatFundingAction, StatSectorAction, StatStateTypeAction, StatTenderCatTypeAction } from 'Redux/actions/common/DropdownAction'
import { statGridFilterApi } from 'Services/statgrid/filter/StatGridFilterApi'
import { useEffect } from 'react'
import { useDispatch } from 'react-redux'

function StatGridDropDown() {
    const dispatch = useDispatch()



    const getStatClient = async () => {
        try {
            const res = await statGridFilterApi?.getStatClientList()
            if (res?.data?.status === '1') {
                dispatch(StatClientAction(res?.data?.data))
            }
        } catch {
            dispatch(StatClientAction([]))
        }
    }


    const getStatFundingOrg = async () => {
        try {
            const res = await statGridFilterApi?.getFundingList()
            if (res?.data?.status === '1') {
                dispatch(StatFundingAction(res?.data?.data))
            }
        } catch {
            dispatch(StatFundingAction([]))
        }
    }
    const getStatTenderCat = async () => {
        try {
            const res = await statGridFilterApi?.getTenderCatList()
            if (res?.data?.status === '1') {
                dispatch(StatTenderCatTypeAction(res?.data?.data))
            }
        } catch {
            dispatch(StatTenderCatTypeAction([]))
        }
    }

    const getStatCountryData = async () => {
        try {
            const res = await statGridFilterApi?.getCountryList()
            if (res?.data?.status === '1') {
                dispatch(StatCountryTypeAction(res?.data?.data))
            }
        } catch {
            dispatch(StatCountryTypeAction([]))
        }
    }
    const getStatSectorData = async () => {
        try {
            const res = await statGridFilterApi?.getSectorList()
            if (res?.data?.status === '1') {
                dispatch(StatSectorAction(res?.data?.data))
            }
        } catch {
            dispatch(StatSectorAction([]))
        }
    }
    // const getStatStateData = async () => {
    //     try {
    //         const res = await statGridFilterApi?.statStateList()
    //         if (res?.data?.status === '1') {
    //             dispatch(StatStateTypeAction(res?.data?.data))
    //         }
    //     } catch {
    //         dispatch(StatStateTypeAction([]))
    //     }
    // }


    useEffect(() => {
        getStatFundingOrg()
        getStatClient()
        getStatTenderCat()
        getStatCountryData()
        // getStatStateData()
        getStatSectorData()

    }, [])
}

export default StatGridDropDown
