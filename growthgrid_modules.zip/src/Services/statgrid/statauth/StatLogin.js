
import { statBaseUrl } from "../../../utils/configurable";
import axios from "axios";
const StatLogin = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
    }
    try {
        const response = await axios.post(`${statBaseUrl}/user-login`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}



const getUserDetails = async () => {
    const headers = {
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/user-details`, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}


const StatForgotPassword = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
    }
    try {
        const response = await axios.post(`${statBaseUrl}/forget-password`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const addIpAddress = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}//add-ip-login`, data, { headers })
        return response
    } catch (error) {
        return error

    }
}


const getIpAddress = async () => {
    const headers = {
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/get-ip-address`, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}
export const StatAuthServices = {
    StatLogin,
    getUserDetails,
    StatForgotPassword,
    addIpAddress,
    getIpAddress

}