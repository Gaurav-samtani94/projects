import axios from "axios";
import { statBaseUrl } from "utils/configurable";

const PlanListData = async () => {
    try {
        const response = await axios.get(`${statBaseUrl}/plan-list`)
        return response
    } catch (error) {
        return error

    }
}

const PolicyData = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
    }
    try {
        const response = await axios.post(`${statBaseUrl}/slug`, data,{headers})
        return response
    } catch (error) {
        return error

    }
}

const AboustUsList = async () => {
    try {
        const response = await axios.get(`${statBaseUrl}/about-us`)
        return response
    } catch (error) {
        return error

    }
}

const getStatTicket = async () => {
    const headers = {    
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/ticket-rise-list`, { headers })
        return response
    } catch (error) {
        return error

    }
}


const getCouponList = async () => {
    const headers = {    
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/coupon-list`, { headers })
        return response
    } catch (error) {
        return error

    }
}


const StatCouponCheck = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('statToken'),
        'Content-Type': "application/x-www-form-urlencoded",
    }
    try {
        const response = await axios.post(`${statBaseUrl}/coupon-check`, data, {headers})
        return response
    } catch (error) {
        return error

    }
}

const getSubsDetails = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('statToken'),
        'Content-Type': "application/x-www-form-urlencoded",
    }
    try {
        const response = await axios.post(`${statBaseUrl}/subscription-details`, data, {headers})
        return response
    } catch (error) {
        return error

    }
}
export const PlanListApi = {
    PlanListData,
    PolicyData,
    AboustUsList,
    getStatTicket,
    getCouponList,
    StatCouponCheck,
    getSubsDetails
}