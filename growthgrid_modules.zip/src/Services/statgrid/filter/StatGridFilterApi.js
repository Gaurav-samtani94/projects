import axios from "axios";
import { statBaseUrl } from "utils/configurable";

const getStatClientList = async () => {
    const headers = {
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/client-list`, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const getFundingList = async () => {
    const headers = {
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/funding-list`, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const getTenderCatList = async () => {
    const headers = {
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/sg-catg-type-list`, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const getCountryList = async () => {
    const headers = {
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/country-list`, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const statStateList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/state-list`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}

const statCityList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/city-list`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}

const getSectorList = async () => {
    const headers = {
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/sector-list`, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
export const statGridFilterApi = {
    getStatClientList,
    getFundingList,
    getTenderCatList,
    getCountryList,
    statStateList,
    statCityList,
    getSectorList
}