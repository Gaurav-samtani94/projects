import axios from 'axios';
import { statBaseUrl } from 'utils/configurable';

const userAddByAdmin = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/add-user`,data , { headers });
        return response
    }
    catch (error) {
        return error
    }
}


const getUserListByAdmin = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/user-list`, { headers });
        return response
    }
    catch (error) {
        return error
    }
}



export const  userByAdminService = {userAddByAdmin, getUserListByAdmin};