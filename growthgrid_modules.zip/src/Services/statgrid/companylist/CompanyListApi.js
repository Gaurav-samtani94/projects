// @ts-nocheck
import axios from "axios";
import { statBaseUrl } from "utils/configurable";


const CompanyListData = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/company-list`, data, { headers })
        return response
    } catch (error) {
        return error

    }
}
const VisitingCard = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/member-list`, { headers })
        return response
    } catch (error) {
        return error

    }
}

const VisitingListById = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/member-byid`, data, { headers })
        return response
    } catch (error) {
        return error

    }
}

const addVisitingCard = async (data) => {
    const headers = {
        'Content-Type': "multipart/form-data",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/member-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const updateVisitingCard = async (data) => {
    const headers = {
        'Content-Type': "multipart/form-data",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${statBaseUrl}/member-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const SiteOfficeById = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/site-office-byid`, data, { headers })
        return response
    } catch (error) {
        return error

    }
}


const RegionalofficeListById = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/resional-company-byid`, data, { headers })
        return response
    } catch (error) {
        return error

    }
}

const companyViewList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/view-add`, data, { headers })
        return response
    } catch (error) {
        return error

    }
}

const getCompanyViewList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/view-list`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}


const AddCompanyFollow = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/company-follow`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}

const CompanyUnfollow = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/company-unfollow`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}


const CommpanyFindById = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/find-comp-byid`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}



const getSubsidaryList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/subsidiary-company-byid`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}


const getSectorById = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/sector-byid`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}

const getCompanyDocument = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/company-brochure-byid`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}
 

const unlockCompanydata = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/company-unlock`, data, { headers })
        return response

    }
    catch (error_msg) {
        return error_msg
    }
}


const getCompanyBalance = async () => {
    const headers = {    
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/company-balance`, { headers })
        return response
    } catch (error) {
        return error

    }
}
export const CompanyListApi = {
    CompanyListData,
    VisitingCard,
    VisitingListById,
    updateVisitingCard,
    addVisitingCard,
    SiteOfficeById,
    RegionalofficeListById,
    companyViewList,
    getCompanyViewList,
    AddCompanyFollow,
    CommpanyFindById,
    CompanyUnfollow,
    getSubsidaryList,
    getSectorById,
    getCompanyDocument,
    unlockCompanydata,
    getCompanyBalance
}