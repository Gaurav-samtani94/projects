// @ts-nocheck
import axios from "axios";
import { statBaseUrl } from "utils/configurable";


const getAllResults = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/result-list`,{ headers });
        return response
    }
    catch (error) {
        return error
    }
}

export const resultServiceApi = {getAllResults}