import axios from "axios";
import { statBaseUrl } from "utils/configurable";
const getRollPermission = async () => {
    const headers = {    
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.get(`${statBaseUrl}/permission`, { headers })
        return response
    } catch (error) {
        return error

    }
}
const updatepermission = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('statToken')
    }
    try {
        const response = await axios.post(`${statBaseUrl}/allow-permission`, data, { headers })
        return response
    } catch (error) {
        return error

    }
}
export const RollPermissionApi = {
    getRollPermission,
    updatepermission
}
