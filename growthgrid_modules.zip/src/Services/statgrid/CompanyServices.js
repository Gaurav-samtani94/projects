import { APIService } from "../APIService";
import { baseUrl, isAuth } from "../../utils/configurable";
import { authHeader } from '../../helper/authHeader'

const getAlltenderStage = async (data) => {

    try {
        const response = await APIService.post(`${baseUrl}/GetAllTenderStage`, data);
        return response
    }
    catch (error) {
        return error
    }
}

const getAllCompetitor = async (data) => {
    const headers = authHeader()

    try {
        const response = await APIService.post(`${baseUrl}/GetAllCompetitor`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}

const getTenderStageListbyfinYear = async (data) => {
    try {
        const response = await APIService.post(`${baseUrl}/GetTenderStageListbyfinYear`, data);
        return response
    }
    catch (error) {
        return error
    }
}

const getTenderBidderListfinYear = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/GetTenderBidderListbyfinYear`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}

const getTenderAwardListbyfinYear = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/GetTenderAwardListbyfinYear`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}

const getTenderResultDetail = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/Tenderresult_detailsnew`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}

const getCompanyDetail = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/competitordetailbyId`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}

const getCompanyDoc = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/GetTenderResultDocById`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}

const getTenderAward = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/GetTenderAwardListbyfinYear`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}


const getSimilerTenderResult = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/GetTenderResultSimilarById`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}

const getUserCompanyDetails = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/check_state_grid_authentication`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}

const getStatsDetail = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/dashboardstatsgrids`, data, { headers });
        return response
    }
    catch (error) {
        return error
    }
}






export const CompanyService = {
    getAlltenderStage,
    getAllCompetitor,
    getTenderStageListbyfinYear,
    getTenderBidderListfinYear,
    getTenderAwardListbyfinYear,
    getTenderResultDetail,
    getCompanyDetail,
    getCompanyDoc,
    getTenderAward,
    getSimilerTenderResult,
    getUserCompanyDetails,
    getStatsDetail
}