export const AuthService = {
    isLoggedIn: () => {
        return !!localStorage.getItem("auth")
    }
}
