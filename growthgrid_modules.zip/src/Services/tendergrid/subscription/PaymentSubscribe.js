import { APIService } from "../../APIService";
import { baseUrl, isAuth } from "../../../utils/configurable";
import { authHeader } from '../../../helper/authHeader'


const addTransactionData = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/add_transaction_data`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const addWalletPoint = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/add_wallet_point`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const addSubscriptionPlan = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/add_subscription_plan`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const updateSubscriptionConfig = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/update_subscription_config`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
const setSubscriptionConfigEditable = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/set_subscription_config_editable`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const mySubscriptionDetails = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/my_subscription_details`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const setSubscriptionConfigDone = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/set_subscription_config_done`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const buyPayPerTender = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/user_pay_per_tender`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const renewSubscriptionPlan = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/renew_subscription_plan`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
const updateSubs = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/User_upgrade_subs`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }

}

export const PaymentSubscribe = {
    addTransactionData,
    setSubscriptionConfigDone,
    mySubscriptionDetails,
    updateSubscriptionConfig,
    addSubscriptionPlan,
    addWalletPoint,
    buyPayPerTender,
    renewSubscriptionPlan,
    setSubscriptionConfigEditable,
    updateSubs
}
