import { APIService } from "../../APIService";
import { baseUrl, isAuth } from "../../../utils/configurable";
import { authHeader } from '../../../helper/authHeader'


const BlogCategory = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/blog_category`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const BlogListData = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/get_blog`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const Blogdetails = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/get_blog_by_id`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const BlogCommentdetails = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/get_blog_comment`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const SaveComment = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/save_blog_comment`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}





export const BlogApiList = {
    BlogCategory,
    BlogListData,
    Blogdetails,
    BlogCommentdetails,
    SaveComment
}