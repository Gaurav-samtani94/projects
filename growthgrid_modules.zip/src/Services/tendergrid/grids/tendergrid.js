import { APIService } from "../../APIService";
import { baseUrl, isAuth } from "../../../utils/configurable";
import { authHeader } from '../../../helper/authHeader'


const FilterLatestTenderFinancialYear = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/LatestTenders_fin_year`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const NoticeLatestTenderFinancialYear = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/notice_latest_tenders_fin_year`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const UpdateLatestTenderFinancialYear = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/LatestTenders`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const detailsData = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/Tender_details`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const getMyTenderList = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/Mytender_config_ppt_plan`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
const getTenderDocData = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/Tender_docs`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const tenderDetailsData = async (data) => {
    try {
        const response = await APIService.post(`${baseUrl}/TenderDetailsByID`, data);
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const myTenderPPt = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/Mytenderlist_ppt`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const myTenderPPtExcel = async (data) => {
    const headers =  authHeader()
    try {
        const response  =  await APIService?.post(`${baseUrl}/Mytenderlist_ppt_excel`, data ,{headers});
        return response
        
    } catch (error_msg) {
        return error_msg
    }
}

const myTenderConfig = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/Mytenderlist_cofig_plan`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
const AllInactiveTenders = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/LatestTenders_fin_year_inactive`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const tenderCover = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/tender_cover_information`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}



const getTenderUpdateData = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/get_tndr_corrigendum_data`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const GetTenSubRateByTenid = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/GetTenSubRateByTenid`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const myTenderConfigExcel = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/Mytenderlist_cofig_plan_excel`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const GetTenderRelate = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/Gettenderrelate`, data, { headers });
        return response
    } 
    catch (error_msg) {
        return error_msg
    }
}


const GemLatestTenderFinYear = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/gem_latest_tenders_fin_year`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const IrepsLatestTenderFinYear = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/ireps_latest_tenders_fin_year`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const EprocLatestTenderFinYear = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/eproc_latest_tenders_fin_year`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const PmgsyLatestTenderFinYear = async (data) => {
    const headers = { 'Content-Type': "multipart/form-data" }
    try {
        const response = await APIService.post(`${baseUrl}/pmgsytenders_latest_tenders_fin_year`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const guestApiData = async (data) => {
    try {
        const response = await APIService.post(`${baseUrl}/guest_visitors_ip`, data);
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const guestIpCount = async (data) => {
    try {
        const response = await APIService.post(`${baseUrl}/get_guest_visitors_ip_count`, data);
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const documentInsertId = async (data) => {
    try {
        const response = await APIService.post(`${baseUrl}/document_dowanload_insert`, data);
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const documentDownloadCount = async (data) => {
    try {
        const response = await APIService.post(`${baseUrl}/get_document_dowanload_count`, data);
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
export const tendergridServices = {
    FilterLatestTenderFinancialYear,
    detailsData,
    getMyTenderList,
    getTenderDocData,
    AllInactiveTenders,
    myTenderConfig,
    myTenderPPt,
    tenderDetailsData,
    GetTenSubRateByTenid,
    getTenderUpdateData,
    tenderCover,
    myTenderConfigExcel,
    myTenderPPtExcel,
    GetTenderRelate,
    UpdateLatestTenderFinancialYear,
    NoticeLatestTenderFinancialYear,
    GemLatestTenderFinYear,
    IrepsLatestTenderFinYear,
    EprocLatestTenderFinYear,
    PmgsyLatestTenderFinYear,
    guestApiData,
    guestIpCount,
    documentInsertId,
    documentDownloadCount
}
