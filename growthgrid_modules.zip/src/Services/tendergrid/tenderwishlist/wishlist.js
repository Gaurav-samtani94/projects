import { APIService } from "../../APIService";
import { baseUrl, isAuth } from "../../../utils/configurable";
import { authHeader } from '../../../helper/authHeader'



const deleteWishlistCategory = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/wishlist_categ_tender_del`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const editWishlistCategory = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/wishlist_category_edit`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const allMyTenderList = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/tenderwishlist_by_user`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const removeMyWishTenderList = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/tenderwishlist_remove`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const getMyWishTenderList = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/tenderwishlist`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
const getWishListCategory = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/show_wishlist_category`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
const addWishListCategory = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/add_wishlist_category`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
export const WishlistServices = {
    deleteWishlistCategory,
    editWishlistCategory,
    allMyTenderList,
    addWishListCategory,
    getWishListCategory,
    getMyWishTenderList,
    removeMyWishTenderList
}
