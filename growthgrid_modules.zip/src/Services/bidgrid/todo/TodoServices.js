// @ts-nocheck
import axios from "axios";
import { bidBaseUrl } from "utils/configurable";
import 'react-toastify/dist/ReactToastify.css';
import { verifyBidAuth } from "utils/auth";

const getToDoList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/list-todo-scope-mytask`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const getInProgressList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/list-todo-inprogress-mytask`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const getDoneList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/list-todo-done-mytask`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const getTaskPriorityList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/task-priority-list`, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}


const postTodoCreateTask = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/todo-create-task`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}


const postDocumentUpdate = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/task-document-add`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const todoDocumentUpdate = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/task-document-update`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const gethashlist = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/task-hashtag-list`, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const getTodoDocumentList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/task-document-list`, { headers })
        return response;

    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const UpdateToDoScope = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.put(`${bidBaseUrl}/task-scope-update`, data, { headers })
        return response
    }
    catch (error_msg) {

        return error_msg
    }
}

const UpdateTenderToDoScope = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-task-scope-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const UpdateTaskUpd = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.put(`${bidBaseUrl}/set-task-upd`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const showAssignedUserList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/list-todo-taskuser`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}


const AddUserComment = async (data) => {
    const headers = {
        'Content-Type': "multipart/form-data",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/todocmt-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const userCommentList = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken'),
        'Content-Type': "application/x-www-form-urlencoded"

    }

    try {
        const response = await axios.post(`${bidBaseUrl}/todocmt-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const TenderTodoCommentList = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken'),
        'Content-Type': "application/x-www-form-urlencoded"

    }

    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-comment-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const rearrangeOrder = async (data) => {
    const headers = {
        'Content-Type': 'application/json',
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/todo-update-srnumber-task`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const HastagSearch = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/list-hastag-search`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}


const todoEdit = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/todo-edit-task`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}


const TodoDepartment = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/todo-team-tasks`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const TodoDocDelete = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/delete-todo-document`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

export const TodoServices = {
    getToDoList,
    getInProgressList,
    getDoneList,
    getTaskPriorityList,
    postTodoCreateTask,
    postDocumentUpdate,
    getTodoDocumentList,
    gethashlist,
    UpdateToDoScope,
    UpdateTenderToDoScope,
    UpdateTaskUpd,
    rearrangeOrder,
    showAssignedUserList,
    AddUserComment,
    userCommentList,
    TenderTodoCommentList,
    HastagSearch,
    todoDocumentUpdate,
    todoEdit,
    TodoDepartment,
    TodoDocDelete
}