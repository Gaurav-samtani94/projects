import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";


const Bglist = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/bgdetail-list`, { headers })
        return response
    }
    catch (error) {
        verifyBidAuth(error)
        return error
    }
}

const addBg = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.post(`${bidBaseUrl}/bgdetail-add`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)
        return error;
    }
};

const updateBg = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.put(`${bidBaseUrl}/bgdetail-update`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)
        return error;
    }
};

const Bgdelete = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.delete(`${bidBaseUrl}/bgdetail-delete`, { data: data, headers: headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)
        return error;
    }
};

export const bgdetail = {
    Bglist,
    updateBg,
    addBg,
    Bgdelete
}