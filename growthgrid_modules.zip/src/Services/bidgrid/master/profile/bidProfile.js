import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";

const updateUserDetail = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.put(`${bidBaseUrl}/official-profile-update`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};
const updatePersonalInfo = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.put(`${bidBaseUrl}/personal-profile-update`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};
const changePassword = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.post(`${bidBaseUrl}/user-change-password`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};

const oldPassword = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.post(`${bidBaseUrl}/check-user-old-password`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};

const updateUserProfile = async (data) => {
    const headers = {
        'Content-Type': "multipart/form-data",
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.post(`${bidBaseUrl}/user-profile-update`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};

const updateUserProfilePic = async (data) => {
    const headers = {
        'Content-Type': "multipart/form-data",
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.post(`${bidBaseUrl}/user-profile-pic-update`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};

const getStorageDetail = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/get-storage-details`, { headers })
        return response

    }
    catch (error_msg) {
        verifyBidAuth(error_msg)
        return error_msg
    }
}


export const userDetailsApi = {
    updateUserDetail,
    updatePersonalInfo,
    changePassword,
    oldPassword,
    updateUserProfile,
    updateUserProfilePic,
    getStorageDetail
}