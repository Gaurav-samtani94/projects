// @ts-nocheck
import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";


const createJobGrid = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/jobgrade-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}




const getJobGridList = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.get(`${bidBaseUrl}/jobgrade-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const updateJobGridList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.put(`${bidBaseUrl}/jobgrade-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const deleteJobGridList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.delete(`${bidBaseUrl}/jobgrade-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

export const JobGrid = {
    createJobGrid,
    getJobGridList,
    updateJobGridList,
    deleteJobGridList
}



