// @ts-nocheck
import { APIService } from "../../../APIService"
import { bidBaseUrl } from "../../../../utils/configurable"
import { authHeader } from '../../../../helper/authHeader'
import axios from "axios";
import { verifyBidAuth } from "utils/auth";

// const getAllDepartmentList = async () => {
//     try {
//         const response = await APIService.get(`${bidBaseUrl}/department-list`, {
//         });
//         return response;
//     } catch (error) {
//         console.error('API Request Error:', error);
//         return error;
//     }
// }
const getAllDepartmentList = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.get(`${bidBaseUrl}/department-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const addDepartmentList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/department-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const updatedepartmentList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.put(`${bidBaseUrl}/department-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const deleteDepartment = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.delete(`${bidBaseUrl}/department-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)
        return error_msg
    }
}
export const biddepartment = {
    getAllDepartmentList,
    addDepartmentList,
    updatedepartmentList,
    deleteDepartment
}