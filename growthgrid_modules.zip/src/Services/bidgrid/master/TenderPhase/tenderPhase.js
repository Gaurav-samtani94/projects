// @ts-nocheck
import { APIService } from "../../../APIService"
import { bidBaseUrl } from "../../../../utils/configurable"
import { authHeader } from '../../../../helper/authHeader'
import axios from "axios";
import { verifyBidAuth } from "utils/auth";

// const getAllDepartmentList = async () => {
//     try {
//         const response = await APIService.get(`${bidBaseUrl}/department-list`, {
//         });
//         return response;
//     } catch (error) {
//         console.error('API Request Error:', error);
//         return error;
//     }
// }
const getAllPhase = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.get(`${bidBaseUrl}/tenderphase-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const addPhaseList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/tenderphase-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const updatePhaseList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.put(`${bidBaseUrl}/tenderphase-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const deletePhase = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.delete(`${bidBaseUrl}/tenderphase-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
export const tenderPhase = {
    getAllPhase,
    addPhaseList,
    updatePhaseList,
    deletePhase
}