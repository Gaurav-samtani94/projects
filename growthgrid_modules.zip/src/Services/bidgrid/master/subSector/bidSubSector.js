import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";


const getSubSectorList = async () => {
    const headers = {
        // 'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/tendersubsector-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const editSubSectorList = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.put(`${bidBaseUrl}/tendersubsector-update`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};
const addSubSectorList = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.post(`${bidBaseUrl}/tendersubsector-add`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};
const handleDeleteSubSector = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.delete(`${bidBaseUrl}/tendersubsector-delete`, { data: data, headers: headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};
const getSubSectorId = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.get(`${bidBaseUrl}/tendersector-list`, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)
        return error;
    }
};
export const bidSubSector = {
    getSubSectorList,
    editSubSectorList,
    addSubSectorList,
    handleDeleteSubSector,
    getSubSectorId
}