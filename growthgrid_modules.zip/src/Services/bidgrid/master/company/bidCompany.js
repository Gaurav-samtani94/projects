import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";


const getCompanyList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/company-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const editCompanyList = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.put(`${bidBaseUrl}/company-update`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};
const addCompanyList = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.post(`${bidBaseUrl}/company-add`, data, { headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)
        return error;
    }
};
const handleDeleteCompany = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.delete(`${bidBaseUrl}/company-delete`, { data: data, headers: headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)

        return error;
    }
};


const getTenderCompanyList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/companylist-all`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}


const addTenderCompanyList = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.post(`${bidBaseUrl}/centerlize-company-add`, data, { headers });
        return response;
    } catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg;
    }
};

const editTenderCompanyList = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.put(`${bidBaseUrl}/tndrcompany-update`, data, { headers });
        return response;
    } catch (error_msg) {
        verifyBidAuth(error_msg)
        return error_msg;
    }
};

const handleTenderDeleteCompany = async (data) => {
    const headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'authorization': localStorage.getItem('bidToken')
    };

    try {
        const response = await axios.delete(`${bidBaseUrl}/tndrcompany-delete`, { data: data, headers: headers });
        return response;
    } catch (error) {
        verifyBidAuth(error)
        return error;
    }
};
export const bidCompany = {
    getCompanyList,
    editCompanyList,
    addCompanyList,
    handleDeleteCompany,


    getTenderCompanyList,
    addTenderCompanyList,
    editTenderCompanyList,
    handleTenderDeleteCompany
}