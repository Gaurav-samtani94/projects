// import axios from "axios";
// import { bidBaseUrl } from "utils/configurable";


// const getcurrency = async () => {
//     const headers = {
//         'Content-Type': "application/x-www-form-urlencoded",
//         "authorization": localStorage.getItem('bidToken')
//     }

//     try {
//         const response = await axios.get(`${bidBaseUrl}/currency-list`, { headers })
//         return response
//     }
//     catch (error_msg) {
//         return error_msg
//     }
// }

// export const bidcurrency = {
//     getcurrency,                                 
// }