// @ts-nocheck
import axios from "axios";
import { bidBaseUrl } from "utils/configurable";
import { verifyBidAuth } from "utils/auth";

const getUnitList = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.get(`${bidBaseUrl}/businessunit-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)
        return error_msg
    }
}
// sdf
const addUnitList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/businessunit-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)
        return error_msg
    }
}

const updateUnitList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${bidBaseUrl}/businessunit-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)
        return error_msg
    }
}

const deleteUnitList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.delete(`${bidBaseUrl}/businessunit-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)
        return error_msg
    }
}
export const AddUnitApiList = {
    getUnitList,
    addUnitList,
    updateUnitList,
    deleteUnitList
}