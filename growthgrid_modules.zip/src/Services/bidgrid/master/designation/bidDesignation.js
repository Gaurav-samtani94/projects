// @ts-nocheck
import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";


const getDesignationList = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.get(`${bidBaseUrl}/designation-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
// sdf
const addDesignationList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/designation-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const updateDesignationList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${bidBaseUrl}/designation-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const deleteDesignationList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.delete(`${bidBaseUrl}/designation-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
export const DesignationList = {
    getDesignationList,
    addDesignationList,
    updateDesignationList,
    deleteDesignationList
}