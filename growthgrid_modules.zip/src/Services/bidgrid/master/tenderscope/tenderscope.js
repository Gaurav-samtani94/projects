// @ts-nocheck
import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";


const createTender = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/tenderscope-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}




const getTenderList = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.get(`${bidBaseUrl}/tenderscope-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const updateTenderList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.put(`${bidBaseUrl}/tenderscope-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const deleteTenderList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.delete(`${bidBaseUrl}/tenderscope-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

export const TenderList = {
    createTender,
    getTenderList,
    updateTenderList,
    deleteTenderList
}



