// @ts-nocheck
import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";


const getSectorList = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.get(`${bidBaseUrl}/tendersector-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
// sdf
const addSectorList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/tendersector-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const updateSectorList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${bidBaseUrl}/tendersector-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const deleteSectorList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.delete(`${bidBaseUrl}/tendersector-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
export const SectorList = {
    getSectorList,
    addSectorList,
    updateSectorList,
    deleteSectorList
}