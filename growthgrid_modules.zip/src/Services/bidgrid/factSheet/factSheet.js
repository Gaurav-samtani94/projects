import axios from "axios";
import { bidBaseUrl } from "utils/configurable";
import { verifyBidAuth } from "utils/auth";

const getFactList = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.get(`${bidBaseUrl}/fstypemstr-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)
        return error_msg
    }
}

const assignDescCompanyList = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/fsdescassigncomp-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const submitFormData = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/fsdescramarks-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const factSheetDocAdd = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/fsdescremarkdoc-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const fsPrepareEmail = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/fsprepare-email`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
// Download factsheet template data api
const fsPrepareTemplate = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/fsprepare-template`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const preparedFsUpload = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/fspreparedoc-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}



export const factSheet = {
    getFactList,
    assignDescCompanyList,
    submitFormData,
    factSheetDocAdd,
    fsPrepareEmail,
    fsPrepareTemplate,
    preparedFsUpload
}