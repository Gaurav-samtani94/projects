import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";


const DeleteCollection = async (data) => {
  const headers = {
    'Content-Type': "application/x-www-form-urlencoded",
    "authorization": localStorage.getItem('bidToken')
  }
  try {
    const response = await axios.delete(`${bidBaseUrl}/wishlistcollection-delete`, { data: data, headers: headers })
    return response
  }
  catch (error_msg) {
    verifyBidAuth(error_msg)

    return error_msg
  }
}


export const WishListApi = {
  DeleteCollection,
}


