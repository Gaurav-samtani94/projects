import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";

const getContinent = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.get(`${bidBaseUrl}/continent-list`, { headers })
        return response
    }
    catch (error) {
        verifyBidAuth(error)
        return error
    }
}
const addContinent = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/continent-add`, data, { headers })
        return response
    }
    catch (error) {
        verifyBidAuth(error)
        return error
    }
}

export const bidContinent = {
    getContinent,
    addContinent
}