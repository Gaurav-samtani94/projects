// @ts-nocheck
import axios from "axios";
import { bidBaseUrl } from "utils/configurable";
import 'react-toastify/dist/ReactToastify.css';
import { verifyBidAuth } from "utils/auth";
const getUserList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/users-list-all`, { headers })
        return response
    }
    catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const getUserListTeam = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/user-under-list`, { headers })
        return response
    }
    catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const addEmployee = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/user-add`, data, { headers })
        return response
    }
    catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const updateEmployee = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${bidBaseUrl}/user-details-update`, data, { headers })
        return response
    }
    catch (error) {
        verifyBidAuth(error)
        return error
    }
}


export const bidEmployeeList = {
    getUserList,
    addEmployee,
    updateEmployee,
    getUserListTeam
}