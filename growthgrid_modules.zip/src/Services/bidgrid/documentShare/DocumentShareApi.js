// @ts-nocheck
import axios from "axios";
import { bidBaseUrl } from "utils/configurable";
import { verifyBidAuth } from "utils/auth";

// Get Api for showing list of uploaded Files in the Table
const getDocumentsList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/document-shared-list`, data, { headers })
        return response
    }
    catch (error) {
        verifyBidAuth(error)
        return error
    }
}


// Post Api for submit data of uploaded file
const postDocument = async (data) => {
    const headers = {
        'Content-Type': "multipart/form-data",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/document-share`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)
        return error_msg
    }
}


export const DocumentShareService = {
    getDocumentsList, postDocument
}