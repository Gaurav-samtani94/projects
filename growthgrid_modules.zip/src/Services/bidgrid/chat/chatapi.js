// @ts-nocheck
import axios from "axios";
import { bidBaseUrl } from "utils/configurable";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { verifyBidAuth } from "utils/auth";
// const notify = (error) => toast.error(error);
// const notifySuccess = (msg) => toast.success(msg);

const notify_error = (message) => {
    toast.error(message);
};
const chatuserList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/chat-user-list`, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
const getUserchatList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/user-chating-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
const assignuserOngroup = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/user-chatgroup-create`, data, { headers })
        return response
    }
    catch (error_msg) {
        // return error_msg;
        notify_error(error_msg.response?.data.message);
        // if (error_msg.response.status === 400) {
        //     notify(error_msg.response?.data?.message)
        // } else if (error_msg.response.status === 401) {
        //     notify(error_msg.response?.data?.message)
        // } else if (error_msg.response.status === 404) {
        //     notify(error_msg.response?.data?.message)
        // } else if (error_msg.response.status === 405) {
        //     notify(error_msg.response?.data?.message)
        // }
    }
}

const getgroupList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/user-chatgroupmember-list`, { headers })
        return response
    }
    catch (error) {
        verifyBidAuth(error)
        return error
    }
}
const getGroupChatingList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/user-groupchatinglist-history`, data, { headers })
        return response
    }
    catch (error_msg) {
        // notify_error(error_msg.response?.data.message);
        return error_msg
    }
}

const singlecahtApifileuploading = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/single-cahting-uploading-file`, data, { headers })
        return response
    }
    catch (error_msg) {
        // notify_error(error_msg.response?.data.message);
        return error_msg
    }
}

const groupcahtApifileuploading = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/group-cahting-uploading-file`, data, { headers })
        return response
    }
    catch (error_msg) {
        // notify_error(error_msg.response?.data.message);
        return error_msg
    }
}

const singlecahtingunreadmsglist = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/single-cahting-unread-list`, { headers })
        return response
    }
    catch (error_msg) {
        // notify_error(error_msg.response?.data.message);
        return error_msg
    }
}

const group_details = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/group-chat-userlist`, data, { headers })
        return response
    }
    catch (error_msg) {
        // notify_error(error_msg.response?.data.message);
        return error_msg
    }
}

const get_userlist_of_group = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/get-group-user-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        // notify_error(error_msg.response?.data.message);
        return error_msg
    }
}


const updateuseringroup = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/update-user-in-group`, data, { headers })
        return response
    }
    catch (error_msg) {
        // notify_error(error_msg.response?.data.message);
        return error_msg
    }
}

const deleteuseringroup = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.delete(`${bidBaseUrl}/delete-user-in-group`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        // notify_error(error_msg.response?.data.message);
        return error_msg
    }
}

const updategroupinfo = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${bidBaseUrl}/update-grope-info`, data, { headers })
        return response
    }
    catch (error_msg) {
        // notify_error(error_msg.response?.data.message);
        return error_msg
    }
}

export const bidgridChatApi = {
    chatuserList, getUserchatList, assignuserOngroup,
    getgroupList, getGroupChatingList, singlecahtApifileuploading,
    groupcahtApifileuploading, singlecahtingunreadmsglist, group_details,
    get_userlist_of_group, updateuseringroup, deleteuseringroup, updategroupinfo

}