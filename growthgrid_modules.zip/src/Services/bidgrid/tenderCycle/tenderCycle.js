// @ts-nocheck
import axios from "axios";
import { verifyBidAuth } from "utils/auth";
import { bidBaseUrl } from "utils/configurable";


const bdtenderdetails = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/tenderdetail-edit`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const bdwishlist = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/wishlistcollection-add`, data, { headers })
        return response
    } catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const bdwishlistCollection = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/wishlistcollection-list`, { headers })
        return response
    } catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const bdPrivacyList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/wishlist-privacy-list`, { headers })
        return response
    } catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }

}
const bdAddToWishList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/add-to-wishlist`, data, { headers })
        return response
    } catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const bdGenerateNum = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/tender-gen-types`, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const getbdGenerateId = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/assign-tender-generate-id`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const getBdRoleList = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/bd-role-list`, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const getBdRoleSubmit = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/assign-manager-onTender`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const getBdConsortiumCompanyList = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/consortium-companies`, { data, headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const getBdAssignConsortium = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tndrassign-consortium`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const getBdMoveTender = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tndrmovenext-scope`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const getBdAddTemplateName = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/add-filter-template`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const getAccordianLableList = async (data) => {
    // console.log(data, "dataaaa");
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    // console.log(headers, "mjnjnjn");
    try {
        const response = await axios.post(`${bidBaseUrl}/template-list`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const bdDeleteAccordian = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${bidBaseUrl}/delete-filter-template`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const bdShowChipstemp = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/list-filter-template`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const bdUpdateTempFilterChips = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${bidBaseUrl}/update-filter-template`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const bdActionListTender = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/action-list-tender`, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const bdDeleteBulkTender = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tendercycletrash-multiple`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const bdSelectScopeAll = async () => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/tender-scope-list-next-all`, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const removeFromWhishlist = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/remove-wishlist`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const removeFromReminder = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/remove-reminder`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const getWishList = async (data) => {
    const headers = {
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/wishlist-list`, data, { headers })
        return response;

    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}


export const tenderCycle = {
    bdtenderdetails,
    bdwishlist,
    bdwishlistCollection,

    bdPrivacyList,
    bdAddToWishList,
    bdGenerateNum,
    getbdGenerateId,
    getBdRoleList,
    getBdRoleSubmit,
    getBdConsortiumCompanyList,
    getBdAssignConsortium,
    getBdMoveTender,
    getBdAddTemplateName,
    getAccordianLableList,
    bdDeleteAccordian,
    bdShowChipstemp,
    bdUpdateTempFilterChips,
    bdActionListTender,
    bdDeleteBulkTender,
    bdSelectScopeAll,
    removeFromWhishlist,
    removeFromReminder,
    getWishList
}
