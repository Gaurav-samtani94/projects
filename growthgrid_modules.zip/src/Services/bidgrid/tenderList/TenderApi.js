// @ts-nocheck
import axios from "axios";
import { bidBaseUrl } from "utils/configurable";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { verifyBidAuth } from "utils/auth";
// const headers = {
//     'Content-Type': "application/x-www-form-urlencoded",
//     "authorization": localStorage.getItem('bidToken')
// }


// const notify = (error) => toast.error(error);
// const notifySuccess = (msg) => toast.success(msg);


// Function for calling the Tender Scope-list.
const getScopList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/tenderscope-list`, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        // notify(error_msg?.response?.data?.message)
        return error_msg
    }
}

// Function for calling the Tender-list.
const getTenderList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tender-list`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        // notify(error_msg?.response?.data?.message)
        return error_msg
    }
}


// Function for Tender cycle In action Buttons list.
const getTenderCycleInactionBtnList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tendercycleinactionbtn-list`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        // notify(error_msg?.response?.data?.message)
        return error_msg
    }
}

// For Select all pop dropdown values in tender cycle page
const getBulkDropdownScopeValues = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'authorization': localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/tender-scope-list`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg;
    }
}

const DeleteTender = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'authorization': localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/tendercycletrash-single`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg;
    }
}

const getDropDownValuesSingle = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'authorization': localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/tender-scope-list-next`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg;
    }
}

const getTransferTender = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'authorization': localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/tndrcyclejumpdbtn-single`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg;
    }
}

const bulkTendesTransfer = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        'authorization': localStorage.getItem('bidToken')
    }

    try {
        const response = await axios.post(`${bidBaseUrl}/tndrcyclejumpdbtn-bulk`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg;
    }
}

const getTenderCycleInactionList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tendercycleinaction-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const updateInActionButtons = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tenderinactionbtn-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const tenderCommentList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tender-comment-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}
const updateTenderdesc = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        // const response = await axios.put(`http://202.131.122.242:3020/api/user/tenderdetail-update`, data, { headers })
        const response = await axios.put(`${bidBaseUrl}/tenderdetail-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const tenderTrackHistory = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tendercycletrack-history`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const addProjectTodoTask = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-create-task`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const ProjectTodoList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')

    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-todoscope-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const ProjectProgressList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')

    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-improgressscope-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}


const ProjectDoneList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')

    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-donescope-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const updateProjectTodo = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')

    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-update-task`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const AddProjectDoc = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')

    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-document-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        return error_msg
    }
}

const projectUserList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')

    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-taskuserlist-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const projectHashSearch = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')

    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-hastag-search`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const projectDocList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')

    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-todo-docs-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

// project info

const projectBasicDetail = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')


    }
    try {
        const response = await axios.put(`${bidBaseUrl}/tender-basic-info-details-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const projectInfo = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')


    }
    try {
        const response = await axios.put(`${bidBaseUrl}/project-info-date-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const projectEmdData = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')


    }
    try {
        const response = await axios.put(`${bidBaseUrl}/project-info-emd-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const projectInfoData = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')


    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-info-data`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const projectFeeInfo = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')


    }
    try {
        const response = await axios.put(`${bidBaseUrl}/project-info-feeinfo-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const projectCoverInfo = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')


    }
    try {
        const response = await axios.post(`${bidBaseUrl}/project-info-cover-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const editProjectCoverInfo = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')


    }
    try {
        const response = await axios.put(`${bidBaseUrl}/project-info-cover-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const deleteProjectCoverInfo = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.delete(`${bidBaseUrl}/project-info-cover-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const getConsortiumCompanyList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/consortium-companies`, { headers })
        return response
    }
    catch (error_msg) {
        // notify(error_msg?.response?.data?.message)
        return error_msg
    }
}

const addCompanyName = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/centerlize-company-add`, data, { headers })
        return response;
    }
    catch (error_msg) {
        // notify(error_msg?.response?.data?.message)
        return error_msg
    }
}

const CompanyList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/consortium-company-list`, data, { headers })
        return response;
    }
    catch (error_msg) {
        // notify(error_msg?.response?.data?.message)
        return error_msg
    }
}


const updateConsortium = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${bidBaseUrl}/update-consortium`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const updateConsortiumStatus = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/assign-consortium-companies-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const CompetitorList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/companylist-competitor`, data, { headers })
        return response;
    }
    catch (error_msg) {
        // notify(error_msg?.response?.data?.message)
        return error_msg
    }
}



const CompetitorAssign = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/competitor-company-assign`, data, { headers })
        return response;
    }
    catch (error_msg) {
        // notify(error_msg?.response?.data?.message)
        return error_msg
    }
}

const competitorCompany = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/competitor-company-assign-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const centerlizeCompany = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/centerlize-company-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const deleteCompetitorCompany = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.delete(`${bidBaseUrl}/competitor-company-assign-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const editCompetitorCompany = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.put(`${bidBaseUrl}/competitor-company-assign-update`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const addBgBank = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/bgontender-add`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const bgBankList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/bgontender-list`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const deleteBgBank = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.delete(`${bidBaseUrl}/bgontender-delete`, { data: data, headers: headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const getAllTenderCycleInactionBtnList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/tendercycle-assignbtn-list`, { headers })
        return response
    } catch (error) {
        return error
    }
}

const fetchProjectList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/tender-list-scope-wise`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}
const getTenderResultStatus = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/tenderstatus-list`, { headers })
        return response
    } catch (error) {
        return error
    }
}

const getAllCompanyList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/companylist-all`, { headers })
        return response
    } catch (error) {
        return error
    }
}

export const TenderApi = {
    getScopList, getTenderList, getTenderCycleInactionBtnList, getBulkDropdownScopeValues, DeleteTender, getDropDownValuesSingle,
    getTransferTender, bulkTendesTransfer, getTenderCycleInactionList, updateInActionButtons, tenderCommentList, updateTenderdesc, tenderTrackHistory, addProjectTodoTask,
    ProjectTodoList, ProjectProgressList, ProjectDoneList, updateProjectTodo, AddProjectDoc, projectUserList, projectHashSearch, projectDocList, projectInfoData,
    projectEmdData, projectInfo, projectBasicDetail, projectFeeInfo, projectCoverInfo, editProjectCoverInfo, deleteProjectCoverInfo, updateConsortium, getConsortiumCompanyList, addCompanyName,
    CompanyList, CompetitorList, CompetitorAssign, competitorCompany, centerlizeCompany, deleteCompetitorCompany, editCompetitorCompany
    , addBgBank, bgBankList, deleteBgBank, fetchProjectList, getAllTenderCycleInactionBtnList, updateConsortiumStatus, getTenderResultStatus
    , getAllCompanyList
}