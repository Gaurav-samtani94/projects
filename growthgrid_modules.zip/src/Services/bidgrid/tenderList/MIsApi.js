import axios from "axios";
import { bidBaseUrl } from "utils/configurable";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { verifyBidAuth } from "utils/auth";

const getMisTenderscope = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/mis_cycle_list`, { headers })
        return response
    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const getGenerateList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/tndrgentype-list`, { headers })
        return response
    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const getMisAllInActionBtnList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/mistendercycle-assignbtn-list`, { headers })
        return response
    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const getTenderCycleNextList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/mis-tndr-cycle-list-next`, data, { headers })
        return response
    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const getMisTenderList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/mis-tender-list`, data, { headers })
        return response;
    }
    catch (error_msg) {
        verifyBidAuth(error_msg)

        // notify(error_msg?.response?.data?.message)
        return error_msg
    }
}

const moveTenderToNextScope = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/mistndrcyclejumpdbtn-single`, data, { headers })
        return response
    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const moveMultipleTender = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/mistndrcyclejumpdbtn-bulk`, data, { headers })
        return response
    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}
const getMisInActionBtnList = async (data) => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.post(`${bidBaseUrl}/mistendercycleinactionbtn-list`, data, { headers })
        return response
    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}

const getMisSubmittedList = async () => {
    const headers = {
        'Content-Type': "application/x-www-form-urlencoded",
        "authorization": localStorage.getItem('bidToken')
    }
    try {
        const response = await axios.get(`${bidBaseUrl}/mis-tndr-cycle-list-all`, { headers })
        return response
    } catch (error) {
        verifyBidAuth(error)

        return error
    }
}


export const MisApi = {
    getMisTenderscope,
    getGenerateList,
    getTenderCycleNextList,
    moveTenderToNextScope,
    moveMultipleTender,
    getMisTenderList,
    getMisInActionBtnList,
    getMisSubmittedList,
    getMisAllInActionBtnList
}