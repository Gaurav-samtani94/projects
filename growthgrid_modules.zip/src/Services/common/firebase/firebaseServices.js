import { APIService } from "../../APIService";
import { baseUrl, isAuth } from "../../../utils/configurable";
import { authHeader } from '../../../helper/authHeader'

const webPushNotification = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/web_push_notification`, data, { headers })
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


export const firebaseServices = {
    webPushNotification
};
