import { APIService } from "../../APIService";
import { baseUrl } from "../../../utils/configurable";
import { authHeader } from '../../../helper/authHeader'

const createTicket = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/ticket_create`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


const ticketShow = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/ticket_show`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const ticketDelete = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/ticket_delete`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const createfeedback = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/feedback_add`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const feedbackShow = async (data) => {
    const headers = authHeader()
    try {
        const response = await APIService.post(`${baseUrl}/feedback_show`, data, { headers });
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}

const allfeedback = async (data) => {

    try {
        const response = await APIService.post(`${baseUrl}/all_feedback_show`, data);
        return response
    }
    catch (error_msg) {
        return error_msg
    }
}


export const TickestServices = {
    createTicket,
    ticketShow,
    ticketDelete,
    createfeedback,
    feedbackShow,
    allfeedback
}