// @ts-nocheck
import { MailOutlined } from '@ant-design/icons'
import ROUTES from 'Constants/Routes';
import { statGridAction, userStatLogoutAction } from 'Redux/actions/common/authAction';
import { userStatInfoAction } from 'Redux/actions/common/userInfoAction';
import { StatAuthServices } from 'Services/statgrid/statauth/StatLogin';
import { Button, Input, Tooltip } from 'antd'
import React, { useEffect, useRef, useState } from 'react'
import { useDispatch } from 'react-redux';
import { toast } from 'react-toastify';
import { Link, useNavigate } from 'react-router-dom';
import STATROUTES from 'Statgrid/router/statgridRoutes';

const initialState = {
  email: "",
}

const StatForgotPassword = () => {
  const [data, setData] = useState(initialState)
  const [loader, setLoader] = useState(false)
  const dispatch = useDispatch()
  const emailInputRef = useRef(null);
  const [message, setMessage] = useState('');
  const navigate = useNavigate()
  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
    handleCheckMsg();
  }
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);


  const handleKeyDown = () => {
    handleCheckMsg();
    // if (e.key === " ") {
    //   e.preventDefault();
    // }
  };
  const handleCheckMsg = () => {
    const emailRegex = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    if (data?.email?.length == 0) {
      setMessage('');
    } else {
      if (emailRegex?.test(data?.email)) {
        setMessage('');
      } else {
        setMessage('Please enter a valid email!');
      }
    }
  }

  useEffect(() => {
    handleCheckMsg()
  }, [data?.email])

  useEffect(() => {
    if (emailInputRef.current) {
      emailInputRef.current.focus();
    }
  }, []);


  const handleLogin = async (e) => {
    e.preventDefault()
    if (data?.email === "" ) {
      notify('please fill email the fields')
    }
   
    else {
      setLoader(true)
      const statForgetData = new URLSearchParams();
      statForgetData.append("email", data?.email)
      try {
        const res = await StatAuthServices?.StatForgotPassword(statForgetData)
        console.log(res,"res");
        if(res?.data?.status === "1"){
          setData("")
          notify(res?.data?.message)
          
        }
        else {
          notify("not authorised")
      }



      } catch (error) {

      }
    }

  }

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
        handleLogin(e);
    }
};

  return (
    <main className='p-3'>
      <div className="row">
        <div className="col-12 col-lg-6 col-xl-7">
          <div className='d-flex align-items-center justify-content-center h-100'>
            <div className='login-content'>
              <img className='mb-5' src={require("../../assets/img/logo-dark.png")} width={220} />
              <h1 className='mb-3'>Login to your account</h1>
              <p className='text-secondary mb-5'>Enter your email and password for login</p>
              <div className='mb-4'>
                <p className='mb-2'>Email</p>
                <Input
                  ref={emailInputRef}
                  placeholder="Enter your username"
                  size='large'
                  name="email"
                  onKeyPress={handleKeyPress}
                  onChange={handleChange} // Use onChange event instead of onInput
                  onKeyDown={handleKeyDown} // Attach handleKeyDown to the onKeyDown event
                  value={data?.email}
                  className='brand-outlined-input w-100 '
                  suffix={
                    <svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M0.666504 4.28691V14.9536C0.666504 15.6608 0.947455 16.3391 1.44755 16.8392C1.94765 17.3393 2.62593 17.6202 3.33317 17.6202H16.6665C17.3737 17.6202 18.052 17.3393 18.5521 16.8392C19.0522 16.3391 19.3332 15.6608 19.3332 14.9536V4.28691C19.3332 3.57966 19.0522 2.90138 18.5521 2.40129C18.052 1.90119 17.3737 1.62024 16.6665 1.62024H3.33317C2.62593 1.62024 1.94765 1.90119 1.44755 2.40129C0.947455 2.90138 0.666504 3.57966 0.666504 4.28691Z" stroke="#7E7E7E" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M3.3335 5.62024L10.0002 9.62024L16.6668 5.62024" stroke="#7E7E7E" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                  }
                />
                <div className='message' style={{ color: 'red' }}>
                  {message}
                </div>
              </div>

              <div className='d-flex justify-content-end mb-5'>
                <Link to={`/${STATROUTES.PLACEHOLDER}/${STATROUTES?.STAT_LOGIN}`} href="" className='brand-link'  >Login</Link>
              </div>

              <Button type='primary' size='large' className='brand-solid-btn w-100 mb-5' shape='round' onClick={handleLogin}>Submit</Button>
              {/* <p className='text-secondary text-center'>Don’t have an account <a href="#" className='brand-link'>Signup</a></p> */}
            </div>
          </div>
        </div>
        <div className="col-12 col-lg-6 col-xl-5">
          <img src={require("../../assets/img/login-bg.png")} className='w-100 loginBanner' />
        </div>
      </div>
    </main>
  )
}

export default StatForgotPassword