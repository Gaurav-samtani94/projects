import { RiseOutlined } from '@ant-design/icons'
import React from 'react'
import Slider from 'react-slick'

const CompetitivePerformanceSection = () => {
    const sliderSettings = {
        dots: true,
        infinite: true,
        speed: 2500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: false,
        autoplaySpeed: 2000,
    };

    return (
        <div className="bd_wise_qwtr_right">
            <h2 className='mb-4'>Competitive Performance</h2>
            <div className='qwtr_slides'>

                <Slider {...sliderSettings} className='slick-slider' >
                    <div className="competitive_card">
                        <p>Bid Summary for <a style={{ color: "#0c66e4", textDecoration: "underline" }}>Chaitanya Projects Consultancy Private Limited</a> Q4 (Oct - Dec)</p>

                        <div className="tendet__card">
                            <div className="qwtr_slides_top">
                                <div className="slides_sub">
                                    <h3>Win/total of Bids</h3>
                                    <h2>5/35</h2>
                                    <div className="bid_percent">
                                        <span>66.67% <RiseOutlined /></span>
                                        <span>66.67% <RiseOutlined /></span>
                                    </div>

                                </div>
                                <div className="slides_sub" id='midSlides'>
                                    <h3>Winning Percentage (L1)</h3>
                                    <h2>14.29%</h2>

                                </div>
                                <div className="slides_sub" id='lastSlides'>
                                    <h3>Amount won/Total Amount bid</h3>
                                    <h2>66.8 Cr/116.13 Cr</h2>
                                    <div className="bid_percent">
                                        <span>66.67% <RiseOutlined /></span>
                                        <span>66.67% <RiseOutlined /></span>
                                    </div>

                                </div>
                            </div>

                            <div className="qwtr_slides_bottom">
                                <div className="bottom_slides_title">
                                    <p>Against you in Q4 (Oct - Dec)</p>
                                    <button>See Details</button>
                                </div>
                                <div className="bid_details_btm">
                                    <div className="slides_sub">
                                        <h3>Common Bids</h3>
                                        <h2>1</h2>
                                        <div className="bid_percent">
                                            <span>0% </span>
                                        </div>

                                    </div>
                                    <div className="slides_sub" id='midSlides'>
                                        <h3>Your Win % against them</h3>
                                        <h2>0%</h2>
                                        <div className="bid_percent">
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div className="slides_sub" id='lastSlides'>
                                        <h3>Your loss % against them</h3>
                                        <h2>0%</h2>
                                        <div className="bid_percent">
                                            <span>0%</span>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className="competitive_card">
                        <p>Bid Summary for <a style={{ color: "#0c66e4", textDecoration: "underline" }}>Chaitanya Projects Consultancy Private Limited</a> Q4 (Oct - Dec)</p>

                        <div className="tendet__card">
                            <div className="qwtr_slides_top">
                                <div className="slides_sub">
                                    <h3>Win/total of Bids</h3>
                                    <h2>5/35</h2>
                                    <div className="bid_percent">
                                        <span>66.67% <RiseOutlined /></span>
                                        <span>66.67% <RiseOutlined /></span>
                                    </div>

                                </div>
                                <div className="slides_sub" id='midSlides'>
                                    <h3>Winning Percentage (L1)</h3>
                                    <h2>14.29%</h2>

                                </div>
                                <div className="slides_sub" id='lastSlides'>
                                    <h3>Amount won/Total Amount bid</h3>
                                    <h2>66.8 Cr/116.13 Cr</h2>
                                    <div className="bid_percent">
                                        <span>66.67% <RiseOutlined /></span>
                                        <span>66.67% <RiseOutlined /></span>
                                    </div>

                                </div>
                            </div>

                            <div className="qwtr_slides_bottom">
                                <div className="bottom_slides_title">
                                    <p>Against you in Q4 (Oct - Dec)</p>
                                    <button>See Details</button>
                                </div>
                                <div className="bid_details_btm">
                                    <div className="slides_sub">
                                        <h3>Common Bids</h3>
                                        <h2>1</h2>
                                        <div className="bid_percent">
                                            <span>0% </span>
                                        </div>

                                    </div>
                                    <div className="slides_sub" id='midSlides'>
                                        <h3>Your Win % against them</h3>
                                        <h2>0%</h2>
                                        <div className="bid_percent">
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div className="slides_sub" id='lastSlides'>
                                        <h3>Your loss % against them</h3>
                                        <h2>0%</h2>
                                        <div className="bid_percent">
                                            <span>0%</span>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className="competitive_card">
                        <p>Bid Summary for <a style={{ color: "#0c66e4", textDecoration: "underline" }}>Chaitanya Projects Consultancy Private Limited</a> Q4 (Oct - Dec)</p>

                        <div className="tendet__card">
                            <div className="qwtr_slides_top">
                                <div className="slides_sub">
                                    <h3>Win/total of Bids</h3>
                                    <h2>5/35</h2>
                                    <div className="bid_percent">
                                        <span>66.67% <RiseOutlined /></span>
                                        <span>66.67% <RiseOutlined /></span>
                                    </div>

                                </div>
                                <div className="slides_sub" id='midSlides'>
                                    <h3>Winning Percentage (L1)</h3>
                                    <h2>14.29%</h2>

                                </div>
                                <div className="slides_sub" id='lastSlides'>
                                    <h3>Amount won/Total Amount bid</h3>
                                    <h2>66.8 Cr/116.13 Cr</h2>
                                    <div className="bid_percent">
                                        <span>66.67% <RiseOutlined /></span>
                                        <span>66.67% <RiseOutlined /></span>
                                    </div>

                                </div>
                            </div>

                            <div className="qwtr_slides_bottom">
                                <div className="bottom_slides_title">
                                    <p>Against you in Q4 (Oct - Dec)</p>
                                    <button>See Details</button>
                                </div>
                                <div className="bid_details_btm">
                                    <div className="slides_sub">
                                        <h3>Common Bids</h3>
                                        <h2>1</h2>
                                        <div className="bid_percent">
                                            <span>0% </span>
                                        </div>

                                    </div>
                                    <div className="slides_sub" id='midSlides'>
                                        <h3>Your Win % against them</h3>
                                        <h2>0%</h2>
                                        <div className="bid_percent">
                                            <span>0%</span>
                                        </div>
                                    </div>
                                    <div className="slides_sub" id='lastSlides'>
                                        <h3>Your loss % against them</h3>
                                        <h2>0%</h2>
                                        <div className="bid_percent">
                                            <span>0%</span>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </Slider>
            </div>
        </div>
    )
}

export default CompetitivePerformanceSection