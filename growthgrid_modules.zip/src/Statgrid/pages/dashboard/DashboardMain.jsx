// @ts-nocheck
import React, { useState } from 'react';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Row, Col, Button } from 'antd';
import LiveStatusSection from './LiveStatusSection';
import StateAndSectorDonutChart from '../../components/UI/StateAndSectorDonutChart';
import QuarterWiseBidingChart from './QuarterWiseBidingChart';
import CompetitivePerformanceSection from './CompetitivePerformanceSection';


const DashboardMain = () => {
  const [activeTab, setActiveTab] = useState(1)
  return (
    <div className="dashboard_right_main">
      <div className="container-fluid">
        <div className="bid_status_main">
          <div className="headings_left_side mb-4">
            <p className='mb-2'>Welcome</p>
            <h1>Consulting Engineers Group Limited</h1>
          </div>
          <LiveStatusSection />
          <Row gutter={[24, 24]} className="mt-5">
            <Col span={24} lg={14}>
              <CompetitivePerformanceSection />
            </Col>
            <Col span={24} lg={10}>
              <StateAndSectorDonutChart id="myDonutChart" />
            </Col>
          </Row>
        </div>
        <div className='dash_brd_qwatr_main mt-0 mb-5'>
          <QuarterWiseBidingChart />
        </div>
        <Row gutter={[24, 24]}>
          <Col span={24} lg={14}>
            <h2 className='mb-4'>Your Top Competitors & their Organization distribution</h2>
            <div className="d-flex flex-column gap-0">
              {Array(6).fill(0).map((_, index) => (
                <div onClick={() => setActiveTab(index)} className={`d-flex position-relative align-items-center justify-content-between gap-3 w-full p-4 comp-tab ${activeTab === index ? "active" : ""}`}>
                  <div>
                    <h5 className='mb-2'>Lorem ipsum dolor sit amet consectetur.</h5>
                    <p className='mb-0'>Number of bids: 2031</p>
                  </div>
                  <Button className='brand-outlined-btn'>
                    Show Bids
                  </Button>
                  <span className='tab-arrow'>
                    <svg width="23" height="27" viewBox="0 0 23 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M22 11.7679C23.3333 12.5378 23.3333 14.4622 22 15.232L3.25 26.0574C1.91666 26.8272 0.249999 25.8649 0.249999 24.3253L0.25 2.67468C0.25 1.13508 1.91667 0.17283 3.25 0.942631L22 11.7679Z" fill="#F3EDFF" />
                    </svg>
                  </span>
                </div>
              ))}
            </div>
          </Col>
          <Col span={24} lg={10}>
            <StateAndSectorDonutChart id="competitorChart" />
          </Col>
        </Row>
      </div>
    </div >
  )
}

export default DashboardMain