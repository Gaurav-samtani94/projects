import { ChartHistogram, ChartLine } from '@icon-park/react';
import DurationFilterDropDown from 'Statgrid/components/UI/DurationFilterDropDown';
import { Divider } from 'antd';
import { Chart } from 'chart.js';
import React, { useEffect, useState } from 'react'

const QuarterWiseBidingChart = () => {
    const [chartType, setChartType] = useState("bar")
    useEffect(() => {
        const quarterData = {
            labels: ['January', 'February', 'March', 'April', 'May', 'June'],
            datasets: [
                {
                    label: 'Cancelled',
                    data: [40, 20, 2005, 18, 4, 55],
                    backgroundColor: '#925FFF',
                    borderColor: '#925FFF'
                },
                {
                    label: 'In Progress',
                    data: [25, 15, 10, 40, 13, 4],
                    backgroundColor: '#F6CE81',
                    borderColor: '#F6CE81'
                },
                {
                    label: 'Lost Tender',
                    data: [45, 15, 10, 20, 13, 4],
                    backgroundColor: '#FC7878',
                    borderColor: '#FC7878'
                },
                {
                    label: 'L1 Bids',
                    data: [8, 12, 18, 60, 15, 4],
                    backgroundColor: '#B5EDC8',
                    borderColor: '#B5EDC8'
                },

            ],
        };

        const dogHuntBarCanvas = document.getElementById('quarterChart');

        if (dogHuntBarCanvas) {
            // @ts-ignore
            const ctx = dogHuntBarCanvas.getContext('2d');
            Chart.getChart(ctx)?.destroy();

            new Chart(ctx, {
                // @ts-ignore
                type: chartType,
                data: quarterData,
                options: {
                    responsive: true,
                    interaction: {
                        mode: 'index',
                        intersect: false
                    },
                    scales: {
                        x: { stacked: true, display: true }, // Set to true for a stacked bar chart
                        y: { stacked: true, display: true },
                        // y: {
                        //     stacked: false,
                        //     display: true,
                        //     ticks: {
                        //         beginAtZero: false, // Start y-axis from the minimum value in the dataset
                        //         suggestedMin: 15 // Start the y-axis at 10
                        //     }
                        // },
                    },
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                    }
                },

            });
        }
    }, [chartType]);
    return (
        <>
            <div className="dashboard_heading mb-3">
                <h2>Your Bids (Quarter-Wise)</h2>
                <div className="d-flex gap-3 align-items-center justify-content-end mb-3">
                    <button onClick={() => { setChartType('bar') }} className={`tabs-btn ${chartType === 'bar' ? "active" : ""}`}>
                        <ChartHistogram theme="outline" size="22" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                        bar
                    </button>
                    <button onClick={() => { setChartType('line') }} className={`tabs-btn ${chartType === 'line' ? "active" : ""}`}>
                        <ChartLine theme="outline" size="22" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                        Line
                    </button>
                    <Divider type='vertical' className='bg-black border-black' style={{ height: "30px", borderColor: "gray" }} />
                    <DurationFilterDropDown />
                </div>
            </div>
            <div className="tendet__card">
                <canvas id="quarterChart" height={100} ></canvas>
            </div>
        </>
    )
}

export default QuarterWiseBidingChart