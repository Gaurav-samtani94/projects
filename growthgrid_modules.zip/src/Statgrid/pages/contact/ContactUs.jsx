//@ts-nocheck
import React from 'react'
import "../../assets/styles/contact.scss"
import { Button, Form, Input, Select } from 'antd'
import TextArea from 'antd/es/input/TextArea'
import { ChevronLeft } from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'

const ContactUs = () => {
    const navigation = useNavigate()
    return (
        <main>
            <div className='p-4'>
                <div onClick={() => navigation(-1)} className='d-flex gap-1 align-items-center cursor-pointer'>
                    <ChevronLeft sx={{ width: "42px", height: "42px" }} />
                    <h4 className='fw-normal'>Back</h4>
                </div>
            </div>
            <div className="container contact-section">
                <div className="row align-items-center g-0 cont">
                    <div className='col-6 contact-details' style={{ backgroundImage: `url(${require("../../assets/img/contact-bg.png")})` }}>
                        <div className='mb-5'>
                            <img src={require("../../assets/img/logo-large.png")} className='contact-logo mb-5' />
                            <h2 className="mb-3 fw-normal text-white">Contact Info</h2>
                            <p className="mb-2 text-white op-7">Stay ahead of the competition and secure lucrative contracts confidently. Trust in our proven track record to drive your business growth like never before. Join the league of successful entrepreneurs who make winning tenders a habit – choose Tender Grid today!</p>
                            <p className="mb-3 text-white op-7">We have the expertise and resources to help you win more business. We have different offers so that you can see how we can help you grow your business. Contact us today to get started!</p>
                        </div>
                        <div className="d-flex gap-4 flex-column">
                            <div className="contact-item">
                                <svg width="54" height="54" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M41.7796 20.6066C42.0324 18.9108 41.9495 17.1747 41.5309 15.5054C40.978 13.3002 39.8392 11.2118 38.1147 9.4873C36.3902 7.76281 34.3018 6.62409 32.0967 6.07115C30.4274 5.65257 28.6912 5.56967 26.9954 5.82245" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M34.1896 19.8035C34.4604 17.9869 33.8966 16.0699 32.4982 14.6715C31.0997 13.2731 29.1827 12.7092 27.3662 12.98" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M14.3755 8.79423C15.1021 8.79423 15.7715 9.18825 16.1241 9.82349L18.5706 14.2303C18.8909 14.8073 18.9059 15.5052 18.6108 16.0955L16.254 20.8091C16.254 20.8091 16.937 24.3206 19.7954 27.179C22.6538 30.0374 26.1535 30.7086 26.1535 30.7086L30.8664 28.3522C31.4571 28.0568 32.1555 28.0721 32.7327 28.393L37.152 30.85C37.7866 31.2028 38.1802 31.8719 38.1802 32.598L38.1802 37.6715C38.1802 40.2552 35.7803 42.1213 33.3322 41.2952C28.3043 39.5987 20.4996 36.3685 15.5528 31.4216C10.6059 26.4748 7.3757 18.6701 5.67916 13.6422C4.85314 11.1941 6.71923 8.79423 9.30288 8.79423L14.3755 8.79423Z" fill="none" stroke="#fff" stroke-width="2.5" stroke-linejoin="round" />
                                </svg>
                                <div>
                                    <h5 className='fw-normal text-white mb-2'>Phone</h5>
                                    <span className='d-flex flex-wrap gap-2'><a href="#" className='white-link'> +91-9773356001, </a><a href="#" className='white-link'> +91-9773356002, </a></span>
                                </div>
                            </div>
                            <div className="contact-item">
                                <svg width="54" height="54" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4 39H44V24V9H24H4V24V39Z" fill="none" stroke="#fff" stroke-width="2.4" stroke-linejoin="round" />
                                    <path d="M4 9L24 24L44 9" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M24 9H4V24" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M44 24V9H24" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>

                                <div>
                                    <h5 className='fw-normal text-white mb-2'>Mail</h5>
                                    <span className='d-flex flex-wrap gap-2'><a href="#" className='white-link'> business@growthgrids.com </a></span>
                                </div>
                            </div>
                            <div className="contact-item">
                                <svg width="54" height="54" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M24 20C28.4183 20 32 16.4183 32 12C32 7.58172 28.4183 4 24 4C19.5817 4 16 7.58172 16 12C16 16.4183 19.5817 20 24 20Z" fill="none" stroke="#fff" stroke-width="2.5" stroke-linejoin="round" />
                                    <path d="M24 20V38" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                    <path d="M16 32H12L4 44H44L36 32H32" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                                <div>
                                    <h5 className='fw-normal text-white mb-2'>Address</h5>
                                    <span className='d-flex flex-wrap gap-2'><a href="#" className='white-link'> N 79-80 Adinath Nagar , JLN Marg Jaipur-302018, Raj , India </a></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-6 contact-form">
                        <h3 className='fw-normal mb-3'>Get in Touch</h3>
                        <p className='mb-4 text-secondary'>Connect with our technical and marketing team to get more insights on tenders or to resolve your queries.</p>
                        <Form
                            name="basic"
                            className='w-100, row'
                            autoComplete="off"
                            layout='vertical'
                        >
                            <Form.Item
                                label="Full Name*"
                                name="name"
                                className='mb-4 col-12 col-lg-6'
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your name!',
                                    },
                                ]}
                            >
                                <Input size='large' className='brand-input' placeholder='Your Name' />
                            </Form.Item>
                            <Form.Item
                                label="Mobile No*"
                                name="number"
                                className='mb-4 col-12 col-lg-6'
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your Mobile No!',
                                    },
                                ]}
                            >
                                <Input size='large' className='brand-input' placeholder='Enter Your Mobile No.' />
                            </Form.Item>

                            <Form.Item
                                label="Email*"
                                name="email"
                                className='mb-4 col-12 col-lg-6'
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your Email Id!',
                                    },
                                ]}
                            >
                                <Input size='large' className='brand-input' placeholder='Enter Your Email Id.' />
                            </Form.Item>

                            <Form.Item
                                label="Sector*"
                                name="sector"
                                className='mb-4 col-12 col-lg-6'
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please Select Sector!',
                                    },
                                ]}
                            >
                                <Select className='brand-input' placeholder='Select Sector.' size='large'>
                                    <Select.Option value="demo">Demo</Select.Option>
                                </Select>
                            </Form.Item>

                            <Form.Item
                                label="Message*"
                                name="message"
                                className='mb-5'
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please write a message!',
                                    },
                                ]}
                            >
                                <TextArea rows={2} size='large' className='brand-input'></TextArea>
                            </Form.Item>

                            <Form.Item className='mb-0 '>
                                <Button type="primary" htmlType="submit" size='large' className='brand-solid-btn w-100'>
                                    Submit
                                </Button>
                            </Form.Item>
                        </Form>
                    </div>
                </div>
                <div className='mb-5 map-c'>
                    <h2 className='mb-4 fw-normal text-center'>Location</h2>
                    <p className='text-center'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reiciendis recusandae sapiente numquam ipsam explicabo excepturi quibusdam nam modi unde maiores. Earum, quibusdam?</p>
                </div>
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3559.655067808589!2d75.7989383811481!3d26.850921216565432!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db67800658171%3A0x3191a1eaa7df9c04!2sJawahar%20Lal%20Nehru%20Marg%2C%20Adinath%20Nagar%2C%20Jaipur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1682571059165!5m2!1sen!2sin"
                    style={{ padding: "0", minHeight: 400 }}
                    allowFullScreen
                    loading="lazy"
                    className="w-100 h-100 contact-map bg-white"
                    title="website Google Map"
                ></iframe>
            </div>
        </main>
    )
}

export default ContactUs