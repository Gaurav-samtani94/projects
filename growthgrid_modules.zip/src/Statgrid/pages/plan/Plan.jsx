// @ts-nocheck
import React, { useEffect, useState } from 'react'
import '../../assets/styles/plans.scss'
import { Button, Divider } from 'antd'
import { PlanListApi } from 'Services/statgrid/PlanList/PlanListApi'
import ChevronLeft from '@mui/icons-material/ChevronLeft'
import { useNavigate } from 'react-router-dom'
import STATROUTES from 'Statgrid/router/statgridRoutes'
import ROUTES from 'Constants/Routes'
import { useDispatch } from 'react-redux'
import { StatCheckoutAction } from 'Redux/actions/statgrid/StatCheckoutAction'
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { RightOutlined, LeftOutlined } from '@ant-design/icons';

const NextArrow = (props) => {
  const { className, style, onClick } = props;
  return (
    <div className={className} style={{ ...style, display: 'block' }} onClick={onClick}>
      <div style={{ color: '#000', fontSize: '24px', position: 'absolute', top: '-30px', right: '13px' }}><RightOutlined /></div>
    </div>
  );
};
const PrevArrow = (props) => {
  const { className, style, onClick } = props;
  return (
    <div className={className} style={{ ...style, display: 'block' }} onClick={onClick}>
      <div style={{ color: '#000', fontSize: '24px', position: 'absolute', top: '-30px', left: '-20px' }}><LeftOutlined /></div>
    </div>
  );
};

const Plans = () => {
  const navigation = useNavigate()
  const [palnList, setPlanList] = useState([])
  const [subscData, setSubscData] = useState([])
  const dispatch = useDispatch()
  const [relatedData, setRelatedData] = useState([]);

  const getPlanList = async () => {
    try {
      const res = await PlanListApi?.PlanListData()
      if (res?.data?.status === "1") {
        setPlanList(res?.data?.data, "data");
      } else {
        setPlanList([])
      }
    } catch (error) {

    }
  }

  const subscriptionDetailApi = async () => {
    try {
      const response = await PlanListApi?.getSubsDetails()
      setSubscData(response?.data?.data)
    } catch {
      console.log("error")
    }

  }

  const handleClick = (item) => {
    console.log(item, "hjhjhjhhjhj");
    if (localStorage?.getItem("statToken")) {
      const payload = {
        statSubPlan: item,
        type: 'plan'
      }
      if (!subscData?.plan_id)
        dispatch(StatCheckoutAction(payload))
      navigation(`/${STATROUTES?.PLACEHOLDER}/${STATROUTES?.CHECKOUT}`, { state: { val: '2' } })
    }
    else {
      navigation(ROUTES?.STAT_LOGIN)
    }
  }

  const relatedSettings = {
    dots: true,
    infinite: relatedData?.length > 4 ? true : false,
    centerMode: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    nextArrow: <NextArrow />,
    prevArrow: <PrevArrow />,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };


  useEffect(() => {
    subscriptionDetailApi()
    getPlanList()
  }, [])
  return (
    <main className='position-relative py-4'>
      <div className='container plan-container'>
        <h2 className='text-align-center text-center mb-4 fw-normal'>Choose Right Plan</h2>
        <p className='text-center'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Tempore, odit quos, velit voluptate id aspernatur excepturi similique vitae quas laborum facere nisi itaque officia totam veniam quidem ab reprehenderit tempora omnis at eaque. Doloribus est atque sint laborum praesentium ex.</p>
      </div>
      <div className="container">
        <div className="row">
          <Slider {...relatedSettings}>
            {palnList?.map((item, index) => {
              return (
                <div className="col-4">
                  <div className='plan-card' key={index}>
                    <Button type='primary' size='large' className='brand-solid-btn mb-4'>{item?.plan_name}</Button>
                    <p className='text-secondary mb-5'>{item?.description}</p>
                    <p className='fs-2 fw-medium'>₹{item?.plan_rate} <small className='text-secondary fs-6'>/month</small></p>
                    <Divider className='my-3' />
                    <div>
                      <div className=' d-flex gap-2 align-items-start mb-2'> <span className='text-secondary'>{tickSvg()}</span> <p className='text-secondary'>Lorem ipsum dolor sit <span className='text-dark'>- 3</span></p></div>
                      <div className=' d-flex gap-2 align-items-start mb-2'> <span className='text-secondary'>{tickSvg()}</span> <p className='text-secondary'>Lorem ipsum dolor sit <span className='text-dark'>- 3</span></p></div>
                      <div className=' d-flex gap-2 align-items-start mb-2'> <span className='text-secondary'>{tickSvg()}</span> <p className='text-secondary'>Lorem ipsum dolor sit <span className='text-dark'>- 3</span></p></div>
                      <div className=' d-flex gap-2 align-items-start mb-2'> <span className='text-secondary'>{tickSvg()}</span> <p className='text-secondary'>Lorem ipsum dolor sit <span className='text-dark'>- 3</span></p></div>
                    </div>
                    <Divider className='my-3' />
                    <Button type='default' size='large' className='brand-outlined-btn w-100 mt-auto' onClick={() => handleClick(item)}>Get Started</Button>
                  </div>
                </div>
              )
            })}
            <div className="col-4">
              <div className='plan-card'>
                <img src={require("../../assets/img/blur-circle.png")} className='card-blur-circle' />
                <Button type='primary' size='large' className='brand-solid-btn btn-white mb-4'>Custom</Button>
                <p className='text-secondary mb-5'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Alias sed ad laudantium eum molestiae dolorem voluptas explicabo, est pariatur! </p>
                <p className='fs-2 fw-medium'>Let's Talk</p>
                <Divider className='my-3' />
                <div>
                  <div className=' d-flex gap-2 align-items-start mb-2'> <span className='text-secondary'>{tickSvg()}</span> <p className='text-secondary'>Lorem ipsum dolor sit <span className='text-dark'>- 3</span></p></div>
                  <div className=' d-flex gap-2 align-items-start mb-2'> <span className='text-secondary'>{tickSvg()}</span> <p className='text-secondary'>Lorem ipsum dolor sit <span className='text-dark'>- 3</span></p></div>
                  <div className=' d-flex gap-2 align-items-start mb-2'> <span className='text-secondary'>{tickSvg()}</span> <p className='text-secondary'>Lorem ipsum dolor sit <span className='text-dark'>- 3</span></p></div>
                </div>
                <Divider className='my-3' />
                <Button type='primary' size='large' shape='round' className='brand-solid-btn w-100 mt-auto'>Book A Call</Button>
              </div>
            </div>
            
          </Slider>

        </div>
      </div>
      <div>
        <img src={require("../../assets/img/blur-circle.png")} className='main-blur-circle' />
      </div>
      <div className='back-btn d-flex gap-3 align-items-center'>
        <div onClick={() => navigation(-1)}>
          <ChevronLeft sx={{ width: "42px", height: "42px" }} />
        </div>
        <img src={require("../../assets/img/logo-large.png")} className='plan-logo' />

      </div>
    </main>
  )
}

const tickSvg = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 16 16"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m2.75 8.75l3.5 3.5l7-7.5" /></svg>
)

export default Plans