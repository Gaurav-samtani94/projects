
import React, { lazy } from 'react'
import Plans from './Plan'



function InnerPlan() {
   
    return (
        <div>
            <Plans />
            
        </div>
    )
}

export default InnerPlan
