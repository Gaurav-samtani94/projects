import React, { useEffect } from 'react'
import SearchBar from 'Statgrid/components/searchBar/SearchBar'
import { Pagination, Select } from 'antd'
import FilteredTagsAndSearchResult from 'Statgrid/components/UI/FilteredTagsAndSearchResult';
import PerformanceCard from 'Statgrid/components/cards/PerformanceCard';
import { useNavigate } from 'react-router-dom';
import ROUTES from 'Statgrid/router/statgridRoutes';
import { Down } from '@icon-park/react';

const Performance = () => {
  const navigation = useNavigate()
  return (
    <div className='container-fluid'>
      <div className="prformnce__wrapper">
        <div className="prformnce_headings mb-4">
          <h2>Performance</h2>
        </div>
        <SearchBar />

        <div className='my-4 d-flex align-items-center justify-content-between'>
          {/* <FilteredTagsAndSearchResult onTagClose={console.log} tagsData={Array(5).fill(1)} searchResults="Showing 1 to 20 of 4364210 Results" /> */}
          <div className="prformnce_heading_btns">
            <Select
              className='prformnce_select_box'
              defaultValue="Your Performance"
              suffixIcon={<Down theme="outline" size="22" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />}
              options={[
                {
                  value: 'Your Performance',
                  label: 'Your Performance',
                },

              ]}
            />
            <Select
              className='prformnce_select_box'
              defaultValue="Your Wins (Highest)"
              suffixIcon={<Down theme="outline" size="22" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />}
              options={[
                {
                  value: 'Your Wins (Highest)',
                  label: 'Your Wins (Highest)',
                },

              ]}
            />
          </div>
          <div className="searchResults_count">Showing 1 to 20 of 4364210 Results</div>
        </div>
        <div className='d-flex gap-4 flex-column my-4'>
          {Array(10).fill(1).map((_, index) => (
            <div className='cursor-pointer' key={index} onClick={() => navigation(`/${ROUTES.PLACEHOLDER}/${ROUTES.PERFORMANCE_DETAIL}/${index + 1}`)}>
              <PerformanceCard id={"fd" + index} />
            </div>
          ))}
        </div>
        <Pagination defaultCurrent={6} className='justify-content-center d-flex' total={500} />
      </div>
    </div>
  )
}

export default Performance

