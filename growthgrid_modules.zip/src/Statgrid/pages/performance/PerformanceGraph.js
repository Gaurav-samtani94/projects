import { ChartHistogram, ChartLine } from '@icon-park/react';
import DurationFilterDropDown from 'Statgrid/components/UI/DurationFilterDropDown';
import { Divider } from 'antd';
import { Chart } from 'chart.js';
import React, { useEffect, useState } from 'react'

const PerformanceGraph = () => {
    const [chartType, setChartType] = useState("bar")
    useEffect(() => {
        const quarterData = {
            labels: ['January', 'February', 'March', 'April', 'May', 'June'],
            datasets: [
                {
                    label: 'You',
                    data: [10, 20, 15, 25, 18, 4],
                    backgroundColor: '#1d9e4991',
                    borderColor: '#1D9E49',
                    borderWidth: '3'
                },
                {
                    label: 'Competitor',
                    data: [5, 15, 10, 20, 13, 4],
                    backgroundColor: '#fc565685',
                    borderColor: '#FC5656',
                    borderWidth: '3'
                },
            ],
        };

        const dogHuntBarCanvas = document.getElementById('quarterChart');

        if (dogHuntBarCanvas) {
            // @ts-ignore
            const ctx = dogHuntBarCanvas.getContext('2d');
            Chart.getChart(ctx)?.destroy();

            new Chart(ctx, {
                // @ts-ignore
                type: chartType,
                // @ts-ignore
                data: quarterData,
                options: {
                    responsive: true,
                    interaction: {
                        mode: 'index',
                        intersect: false
                    },
                    scales: {
                        x: { display: true }, // Set to true for a stacked bar chart
                        y: { display: true },
                    },
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                    }
                },

            });
        }
    }, [chartType]);
    return (
        <>
            <div className="dashboard_heading mb-3">
                <h2>Performance Graph</h2>
                <div className="d-flex gap-3 align-items-center justify-content-end mb-3">
                    <button onClick={() => { setChartType('bar') }} className={`tabs-btn ${chartType === 'bar' ? "active" : ""}`}>
                        <ChartHistogram theme="outline" size="22" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                        bar
                    </button>
                    <button onClick={() => { setChartType('line') }} className={`tabs-btn ${chartType === 'line' ? "active" : ""}`}>
                        <ChartLine theme="outline" size="22" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                        Line
                    </button>
                    <Divider type='vertical' className='bg-black border-black' style={{ height: "30px", borderColor: "gray" }} />
                    <DurationFilterDropDown />
                </div>
            </div>

            <div className="tendet__card">
                <canvas id="quarterChart" height={100} ></canvas>
            </div>
        </>
    )
}

export default PerformanceGraph