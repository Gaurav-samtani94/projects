// @ts-nocheck
import React, { useCallback, useEffect, useMemo, useState } from 'react'
import StateAndSectorDonutChart from '../../components/UI/StateAndSectorDonutChart';
import OverviewSection from './OverviewSection';
import TimelineSection from './TimelineSection';
import TopCompetitorSection from './TopCompetitorSection';
import RecentBids from './RecentBids';
import ContentInformation from './ContentInformation';
import OrganizationComparison from './OrganizationComparison';
// import RegionalOfficeCard from 'Statgrid/components/cards/RegionalOfficeCard';
import RegionalOffices from 'Statgrid/pages/companies/RegionalOffices';
import SiteOfficeCard from 'companyVisitor/components/cards/SiteOfficeCard';
import SiteOffices from 'Statgrid/pages/companies/SiteOffices';
import Subsidiaries from 'Statgrid/pages/companies/Subsidiaries';
import Documents from 'Statgrid/pages/companies/Document';
import Visiting from 'Statgrid/pages/companies/Visiting';
import { useNavigate, useParams } from 'react-router-dom';
import { CompanyListApi } from 'Services/statgrid/companylist/CompanyListApi';
import { Avatar, Button, Divider, Input, List, Tooltip } from 'antd';
import { toast } from 'react-toastify';
import { StatClientAction } from 'Redux/actions/common/DropdownAction';
import { statGridFilterApi } from 'Services/statgrid/filter/StatGridFilterApi';
import { useDispatch } from 'react-redux';
import { motion } from 'framer-motion'
import { SearchSvg } from 'Statgrid/utils/Svgs';
import { CloseOutlined } from '@ant-design/icons';
import STATROUTES from 'Statgrid/router/statgridRoutes';


const competitorsData = [
    {
        "id": "16459234398290011014",
        "title": "NH Consulting Private Limited",
        "checked": false,
        "lastBidDate": "2024-01-12"
    },
    {
        "id": "11620294049939283879",
        "title": "Water Power Consultants India Private Limited",
        "checked": false,
        "lastBidDate": "2024-03-06"
    },
    {
        "id": "9797662158353016526",
        "title": "JS Environics Consultants Private Limited",
        "checked": false,
        "lastBidDate": "2021-04-06"
    },
    {
        "id": "5358618297381794835",
        "title": "Highway Consulting Engineers Private Limited",
        "checked": false,
        "lastBidDate": "2024-03-06"
    },
    {
        "id": "16676685917132825680",
        "title": "The Building Consultant & Technological Service Cooperative Society Limited T 1054",
        "checked": false,
        "lastBidDate": "2024-03-21"
    },
    {
        "id": "15112791841539220679",
        "title": "BE Water - Marine Equipment Suppliers & Consultants Limited Liability Partnership",
        "checked": false,
        "lastBidDate": "2024-03-23"
    },
    {
        "id": "1550128554243587760",
        "title": "Samarth Water Consultants Private Limited",
        "checked": false,
        "lastBidDate": "2024-05-02"
    },
    {
        "id": "13628854555286072399",
        "title": "Plan & Build Consultants Limited Liability Partnership",
        "checked": false,
        "lastBidDate": "2022-09-28"
    },
    {
        "id": "1318944168367674180",
        "title": "Beml Limited",
        "checked": false,
        "lastBidDate": "2024-05-20"
    },
    {
        "id": "3201726696673297303",
        "title": "Ela Green Buildings & Infrastructure Consultants Private Limited",
        "checked": false,
        "lastBidDate": "2024-04-12"
    },
    {
        "id": "12486379351258418073",
        "title": "Nilkamal Limited",
        "checked": false,
        "lastBidDate": "2024-05-21"
    },
    {
        "id": "16156151659280471609",
        "title": "Aimil Limited",
        "checked": false,
        "lastBidDate": "2024-05-20"
    },
    {
        "id": "17519508457613661198",
        "title": "Gmmco Limited",
        "checked": false,
        "lastBidDate": "2024-05-21"
    },
    {
        "id": "1314213118176246689",
        "title": "Instrumentation Limited",
        "checked": false,
        "lastBidDate": "2024-05-22"
    },
    {
        "id": "14020991117347056779",
        "title": "Wapcos Limited",
        "checked": false,
        "lastBidDate": "2024-05-22"
    },
    {
        "id": "1943872258643201488",
        "title": "Cipla Limited",
        "checked": false,
        "lastBidDate": "2024-05-17"
    },
    {
        "id": "3788113158514624235",
        "title": "Flowmore Limited",
        "checked": false,
        "lastBidDate": "2024-05-17"
    },
    {
        "id": "5261102140399498075",
        "title": "Ncc Limited",
        "checked": false,
        "lastBidDate": "2024-05-22"
    },
    {
        "id": "13143490727865502806",
        "title": "Gee Limited",
        "checked": false,
        "lastBidDate": "2024-05-22"
    },
    {
        "id": "11470918495031144966",
        "title": "Thermax Limited",
        "checked": false,
        "lastBidDate": "2024-05-17"
    }
];

const CompanyDashboard = () => {
    const { id } = useParams();
    const navigation = useNavigate()
    const [visitingCard, setVisitingCard] = useState([])
    const [siteOfficecard, setSiteOfficecard] = useState([])
    const [regionalOfficeCard, setRegionalOfficeCard] = useState([])
    const [comopanyCount, setComopanyCount] = useState([])
    const [follower, setFollower] = useState([])
    const [isFollowing, setIsFollowing] = useState(false);
    const [companyData, setCompanyData] = useState([])
    const [subsidayList, setSubsidayList] = useState([])
    const [sectorList, setSectorList] = useState([])
    const [documentData, setDocumentData] = useState([])
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const VisitingCardLIst = async () => {
        if (localStorage?.getItem("statToken")) {
            const VisitingData = new URLSearchParams();
            VisitingData?.append("comp_id", id)
            const response = await CompanyListApi?.VisitingListById(VisitingData)
            if (response?.data?.status === "1") {
                setVisitingCard(response?.data?.data)

            }
        }


    }

    const siteOfficeDetails = async () => {
        if (localStorage?.getItem("statToken")) {
            const siteOfficedata = new URLSearchParams()
            siteOfficedata?.append("comp_id", id)
            const response = await CompanyListApi?.SiteOfficeById(siteOfficedata)
            if (response?.data?.status === "1") {
                setSiteOfficecard(response?.data?.data)
            }

        }
    }

    const RegionalOfficeDetails = async () => {
        if (localStorage?.getItem("statToken")) {
            const regionalOfficedata = new URLSearchParams()
            regionalOfficedata?.append("comp_id", id)
            const response = await CompanyListApi?.RegionalofficeListById(regionalOfficedata)
            if (response?.data?.status === "1") {
                setRegionalOfficeCard(response?.data?.data)
            }

        }
    }

    const getCompanyViewCount = async () => {
        if (localStorage?.getItem("statToken")) {
            const viewCountData = new URLSearchParams()
            viewCountData?.append("comp_id", id)
            const response = await CompanyListApi?.getCompanyViewList(viewCountData)
            if (response?.data?.status === "1") {

                setComopanyCount(response?.data?.data)
            }

        }
    }


    const AddCompanyFollowData = async (e) => {
        e.preventDefault()
        if (localStorage?.getItem("statToken")) {
            const followData = new URLSearchParams()
            followData?.append("comp_id", id)
            const response = await CompanyListApi?.AddCompanyFollow(followData)
            if (response?.data?.status === "1") {
                notifySuccess("Successfully follow company")
                setIsFollowing(true)
                CompanyDetailsData()
            }

        }
    }


    const companyUnfollowData = async (e) => {
        e.preventDefault()
        const unFollowFormData = new URLSearchParams()
        unFollowFormData?.append("comp_id", id)
        const res = await CompanyListApi?.CompanyUnfollow(unFollowFormData)
        if (res?.data?.status === "1") {
            notify(res?.data?.message)
            setIsFollowing(false);

        }
    }

    const CompanyDetailsData = async () => {
        const formData = new URLSearchParams()
        formData?.append("comp_id", id)
        const response = await CompanyListApi?.CommpanyFindById(formData)
        if (response?.data?.status === "1") {

            if (response?.data?.data?.sg_company_follower) {
                const updatedCompanyData = { ...response?.data?.data };
                updatedCompanyData.sg_company_follower.is_followed = response?.data?.data?.sg_company_follower?.is_followed;
                setCompanyData(updatedCompanyData);
                setIsFollowing(response?.data?.data?.sg_company_follower?.is_followed)
            } else {
                setCompanyData(response?.data?.data);
                setIsFollowing(false)

            }
        }

    }
    const getSubsidary = async () => {
        if (localStorage?.getItem("statToken")) {
            const subsidaryData = new URLSearchParams()
            subsidaryData?.append("comp_id", id)
            const response = await CompanyListApi?.getSubsidaryList(subsidaryData)
            if (response?.data?.status === "1") {
                setSubsidayList(response?.data?.data)

            }

        }
    }

    const getSectorListData = async () => {
        if (localStorage?.getItem("statToken")) {
            const sectorDataForm = new URLSearchParams()
            sectorDataForm?.append("comp_id", id)
            const response = await CompanyListApi?.getSectorById(sectorDataForm)
            if (response?.data?.status === "1") {
                setSectorList(response?.data?.data)
            }

        }
    }
    const getDocumentByCompany = async () => {
        if (localStorage?.getItem("statToken")) {
            const documentDataForm = new URLSearchParams()
            documentDataForm?.append("comp_id", id)
            const response = await CompanyListApi?.getCompanyDocument(documentDataForm)
            if (response?.data?.status === "1") {
                setDocumentData(response?.data?.data)
            }

        }
    }


    useEffect(() => {
        VisitingCardLIst()
        siteOfficeDetails()
        RegionalOfficeDetails()
        getCompanyViewCount()
        CompanyDetailsData()
        getSubsidary()
        getSectorListData()
        getDocumentByCompany()

    }, [id])


    const [showAside, setShowAside] = useState(false)
    const [searchQuery, setSearchQuery] = useState('');
    const [data, setData] = useState(competitorsData);

    const filteredData = useMemo(() => {
        const query = searchQuery.toLowerCase();
        return data.filter(item => item.title.toLowerCase().includes(query));
    }, [searchQuery, data]);

    const handleSearch = useCallback((e) => {
        setSearchQuery(e.target.value);
    }, []);

    const handleItemClick = (id) => {
        const checkedCompaniesLength = data.filter((itm) => itm.checked).length;
        console.log("length", data.filter((itm) => itm.checked))
        setData(prevData =>
            prevData.map(item => {
                if (item.id === id) {
                    const isChecked = item.checked;
                    if (checkedCompaniesLength < 4) {
                        return { ...item, checked: !isChecked };
                    } else {
                        if (isChecked) {
                            return { ...item, checked: !isChecked };
                        } else {
                            alert('You can select maximum 4 companies')
                        }
                    }
                    // if (isChecked) {
                    //     setSelectedDataSets(prevSelected => [
                    //         ...prevSelected,
                    //         {
                    //             label: item.title,
                    //             data: authorities.map(() => Math.floor(Math.random() * 100) + 1), // Example data
                    //             backgroundColor: uniqueColors[prevSelected.length % uniqueColors.length],
                    //             borderColor: uniqueColors[prevSelected.length % uniqueColors.length],
                    //         }
                    //     ]);
                    // } else {
                    //     setSelectedDataSets(prevSelected =>
                    //         prevSelected.filter(dataset => dataset.label !== item.title)
                    //     );
                    // }
                }
                return item;
            })
        );
    };


    return (
        <section className='d-flex gap-4 align-items-start'>
            <article className='w-50 flex-grow-1'>
                <div className='container-fluid py-4 py-lg-5'>
                    <div className="company_dashboard_main">
                        <div className="topsection_btn mb-4 mb-lg-5">

                            <h2>{companyData?.company_name}</h2>

                            <Tooltip title="Tender View" placement='right'>
                                {comopanyCount?.map((item, index) => (
                                    <Button type='link' key={index}>
                                        <span>{item?.tot_count_view}</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 16 16">
                                            <path fill="currentColor" fillRule="evenodd" d="M1.87 8.515L1.641 8l.229-.515a6.708 6.708 0 0 1 12.26 0l.228.515l-.229.515a6.708 6.708 0 0 1-12.259 0M.5 6.876l-.26.585a1.328 1.328 0 0 0 0 1.079l.26.584a8.208 8.208 0 0 0 15 0l.26-.584a1.328 1.328 0 0 0 0-1.08l-.26-.584a8.208 8.208 0 0 0-15 0M9.5 8a1.5 1.5 0 1 1-3 0a1.5 1.5 0 0 1 3 0M11 8a3 3 0 1 1-6 0a3 3 0 0 1 6 0" clipRule="evenodd" />
                                        </svg>
                                    </Button>
                                ))}
                            </Tooltip>
                            {!isFollowing && (
                                <button className='follow_btn' onClick={AddCompanyFollowData}>Follow</button>
                            )}
                            {isFollowing && (
                                <>
                                    <button className='follow_btn'>Following</button>
                                    <button className='follow_btn' onClick={companyUnfollowData}>Unfollow</button>
                                </>
                            )}
                            <Button type='primary' className='brand-solid-btn' onClick={() => setShowAside(!showAside)}>
                                Compare
                            </Button>
                        </div>
                        <div className='row g-4 mb-4 mb-lg-5'>
                            <div className='col-12 col-lg-7'>
                                <OverviewSection />
                            </div>
                            <div className='col-12 col-lg-5'>
                                <StateAndSectorDonutChart id="companyDonutChart" />
                            </div>
                        </div>
                        <div className='row g-5 mb-4 mb-lg-5'>
                            <div className='col-12 col-lg-7'>
                                <TimelineSection />
                            </div>
                            <div className='col-12 col-lg-5'>
                                <TopCompetitorSection />
                            </div>
                        </div>


                        <div className='row g-4 mb-4 mb-lg-5'>
                            <div className='col-12 col-lg-4 '>
                                <div className="original_detail_sub">
                                    <h2 className='mb-4'>Organization Detail</h2>
                                    <div className="bid_records_main">
                                        <div className="bid_records">
                                            <p>Location : <span>{companyData?.sg_mstr_cities && companyData.sg_mstr_cities.length > 0 && (
                                                companyData.sg_mstr_cities[0]?.city_name ? companyData.sg_mstr_cities[0].city_name + "," : ""
                                            )}
                                                {companyData?.sg_mstr_states && companyData.sg_mstr_states.length > 0 && (
                                                    companyData.sg_mstr_states[0]?.state_name ? companyData.sg_mstr_states[0].state_name + "," : ""
                                                )}
                                                {companyData?.sg_mstr_countries && companyData.sg_mstr_countries.length > 0 && (
                                                    companyData.sg_mstr_countries[0]?.country_name
                                                )}</span></p>
                                            <Divider orientation='center' type='vertical' style={{ height: "60px", background: 'grey' }} />
                                            {/* <p>Last bid on: <span>{companyData?.last_bid_on}</span></p> */}
                                            <p className='last_pera'>Records available since: <span>Mar 10, 2017</span></p>
                                        </div>
                                        <div className="company_desc mb-4">
                                            <span>Company Description:</span>
                                            <span className='company_desc_content'>{companyData?.company_desc}</span>
                                        </div>
                                        <div className="company_desc" >
                                            <span>secotor:</span>
                                            {sectorList?.map((item, index) => {
                                                return (
                                                    <span className='company_desc_content' key={index}>{item?.sectName}</span>
                                                )
                                            })}
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div className='col-12 col-lg-8'>
                                <RecentBids />
                            </div>
                        </div>

                        <div className='row g-4 mb-4'>
                            <div className="col-6">
                                <RegionalOffices regionalOfficeCard={regionalOfficeCard} />
                            </div>

                            <div className="col-6">
                                < SiteOffices siteOfficecard={siteOfficecard} />
                            </div>
                            <div className='col-6'>
                                <Subsidiaries subsidayList={subsidayList} />
                            </div>
                            <div className='col-6'>
                                <Documents documentData={documentData} />
                            </div>
                            {/* <div className='col-12'>
                        <Visiting visitingCard={visitingCard} setVisitingCard={setVisitingCard} comp_id={id} />
                    </div> */}
                        </div>
                        <div className='row g-4 mb-4 mb-lg-5'>
                            <div className='col-12 col-lg-8'>
                                <OrganizationComparison />
                            </div>
                            <div className='col-12 col-lg-4'>
                                <ContentInformation visitingCard={visitingCard} />
                            </div>
                        </div>
                    </div>
                </div>
            </article>
            <motion.aside
                className={`competitor-aside`}
                style={{
                    overflow: 'hidden'
                }}
                initial={{
                    width: 0
                }}
                animate={{
                    width: showAside ? 350 : 0
                }}
                transition={{
                    delay: showAside ? 0 : 0.5
                }}
            >
                <motion.div
                    initial={{
                        opacity: 0
                    }}
                    animate={{
                        opacity: showAside ? 1 : 0
                    }}
                    transition={{
                        delay: showAside ? 0.5 : 0
                    }}
                    className='p-4 d-flex gap-3 flex-column'
                >
                    <div className='d-flex gap-3'>
                        <Input
                            placeholder="Search for competitor"
                            prefix={<SearchSvg color='#7E7E7E' w={20} h={20} />}
                            className="g-search-input py-2 w-fit rounded-pill mb-2 w-50 flex-grow-1"
                            onChange={handleSearch}
                            value={searchQuery}
                        />
                        <Tooltip title="Close">
                            <Button onClick={() => setShowAside(false)} size='large' className=' d-flex align-items-center justify-content-center' shape="circle" icon={<CloseOutlined />} />
                        </Tooltip>
                    </div>
                    <List
                        className='flex-grow-1'
                        style={{ overflowY: 'auto', maxHeight: 'calc(100vh - 250px)' }}
                        itemLayout="horizontal"
                        dataSource={filteredData}
                        renderItem={(item, index) => (
                            <List.Item className='cursor-pointer d-flex gap-3' onClick={() => handleItemClick(item.id)}>
                                <List.Item.Meta
                                    className='w-50 flex-grow-1'
                                    avatar={<Avatar src={`https://api.dicebear.com/7.x/miniavs/svg?seed=${index}`} />}
                                    title={item.title}
                                    description={`Last Bid Date: ${item?.lastBidDate}`}
                                />
                                {item?.checked &&
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" width={28} height={28}>
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                    </svg>
                                }
                            </List.Item>
                        )}
                    />
                    <div className='pt-2'>
                        <Button block type='primary' className='brand-solid-btn' size='large' onClick={() => navigation(`/${STATROUTES.PLACEHOLDER}/${STATROUTES.COMPANY_COMPARE}`)}>
                            Compare
                        </Button>
                    </div>
                </motion.div>
            </motion.aside>
        </section>
    )
}

export default CompanyDashboard