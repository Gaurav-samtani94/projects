import DurationFilterDropDown from 'Statgrid/components/UI/DurationFilterDropDown'
import { Divider } from 'antd'
import { Chart } from 'chart.js/auto'
import React, { useEffect, useState } from 'react'

const TimelineSection = () => {
    const [chartType, setChartType] = useState('line')
    useEffect(() => {
        const dogHuntData = {
            labels: ["13-02-2023", "13-02-2023", "13-02-2023", "13-02-2023", "13-02-2023", "13-02-2023"],
            datasets: [{
                label: 'No. of bids',
                data: [1, 6, 5, 4, 6, 3],
                backgroundColor: 'rgba(22, 91, 170, 0.2)',
                borderColor: '#165BAA',
                borderWidth: 2,
                pointBackgroundColor: '#165BAA',
                pointRadius: 5,
            }],
        };

        const dogHuntLineCanvas = document.getElementById('timelineChart');

        if (dogHuntLineCanvas) {
            // @ts-ignore
            const ctx = dogHuntLineCanvas.getContext('2d');
            Chart.getChart(ctx)?.destroy();
            new Chart(ctx, {
                // @ts-ignore
                type: chartType,
                data: dogHuntData,
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: false,
                        },
                        legend: {
                            position: 'bottom',
                        },
                    },

                },
            });
        }
    }, [chartType]);
    return (
        <div className="timeline_chart">
            <h2 className='mb-4 '>Bidding Timeline</h2>
            <div className="d-flex gap-3 align-items-center justify-content-end mb-4">
                <button onClick={() => { setChartType('bar') }} className={`tabs-btn ${chartType === 'bar' ? "active" : ""}`}>
                    <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3.58728 20.7495C3.44528 20.7495 3.32661 20.7015 3.23128 20.6055C3.13528 20.5095 3.08728 20.3909 3.08728 20.2495C3.08728 20.1082 3.13528 19.9895 3.23128 19.8935C3.32661 19.7975 3.44528 19.7495 3.58728 19.7495H20.5873C20.7293 19.7495 20.8479 19.7975 20.9433 19.8935C21.0386 19.9895 21.0866 20.1082 21.0873 20.2495C21.0873 20.3909 21.0393 20.5095 20.9433 20.6055C20.8479 20.7009 20.7293 20.7485 20.5873 20.7485L3.58728 20.7495ZM5.08928 17.9795C4.81261 17.9795 4.57628 17.8829 4.38028 17.6895C4.18495 17.4935 4.08728 17.2569 4.08728 16.9795V13.7495C4.08728 13.4715 4.18428 13.2355 4.37828 13.0415C4.57228 12.8469 4.80795 12.7495 5.08528 12.7495C5.36195 12.7495 5.59828 12.8469 5.79428 13.0415C5.98961 13.2355 6.08728 13.4715 6.08728 13.7495V16.9795C6.08728 17.2575 5.99028 17.4942 5.79628 17.6895C5.60228 17.8829 5.36661 17.9795 5.08928 17.9795ZM9.74328 17.9795C9.46595 17.9795 9.22961 17.8829 9.03428 17.6895C8.83895 17.4942 8.74128 17.2575 8.74128 16.9795V8.74954C8.74128 8.47154 8.83795 8.23554 9.03128 8.04154C9.22661 7.84688 9.46295 7.74954 9.74028 7.74954C10.0169 7.74954 10.2533 7.84688 10.4493 8.04154C10.6446 8.23554 10.7423 8.47154 10.7423 8.74954V16.9795C10.7423 17.2575 10.6453 17.4942 10.4513 17.6895C10.2573 17.8829 10.0206 17.9795 9.74328 17.9795ZM14.4163 17.9795C14.1389 17.9795 13.9026 17.8829 13.7073 17.6895C13.5119 17.4942 13.4143 17.2575 13.4143 16.9795V11.7495C13.4143 11.4715 13.5109 11.2355 13.7043 11.0415C13.8989 10.8469 14.1349 10.7495 14.4123 10.7495C14.6889 10.7495 14.9253 10.8469 15.1213 11.0415C15.3166 11.2355 15.4143 11.4715 15.4143 11.7495V16.9795C15.4143 17.2575 15.3173 17.4942 15.1233 17.6895C14.9293 17.8829 14.6936 17.9795 14.4163 17.9795ZM19.0893 17.9795C18.8126 17.9795 18.5763 17.8829 18.3803 17.6895C18.1849 17.4942 18.0873 17.2575 18.0873 16.9795V5.74954C18.0873 5.47154 18.1843 5.23554 18.3783 5.04154C18.5723 4.84688 18.8079 4.74954 19.0853 4.74954C19.3619 4.74954 19.5983 4.84688 19.7943 5.04154C19.9896 5.23554 20.0873 5.47154 20.0873 5.74954V16.9795C20.0873 17.2575 19.9903 17.4942 19.7963 17.6895C19.6023 17.8829 19.3666 17.9795 19.0893 17.9795Z" fill="currentColor" />
                    </svg>
                    bar
                </button>
                <button onClick={() => { setChartType('line') }} className={`tabs-btn ${chartType === 'line' ? "active" : ""}`}>
                    <svg width="22" height="15" viewBox="0 0 22 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1.75272 13.7969L5.78426 8.1527L8.20318 12.1842L17.0726 1.70224L19.4915 6.54009L21.1041 4.12116" stroke="currentColor" stroke-width="1.61262" stroke-linecap="round" />
                    </svg>
                    Line
                </button>
                <Divider type='vertical' className='bg-black border-black' style={{ height: "30px", borderColor: "gray" }} />
                <DurationFilterDropDown />
            </div>
            <canvas id="timelineChart"></canvas>
        </div>
    )
}

export default TimelineSection