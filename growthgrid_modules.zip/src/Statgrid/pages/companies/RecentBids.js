import FilteredTagsAndSearchResult from 'Statgrid/components/UI/FilteredTagsAndSearchResult'
import TenderCard from 'Statgrid/components/cards/TenderCard'
import SearchBar from 'Statgrid/components/searchBar/SearchBar'
import { Col, Pagination, Row, Switch } from 'antd'
import React, { useState } from 'react'

const RecentBids = () => {
    const [isGridView, setIsGridView] = useState(false)

    return (
        <div className="recent_bid_main">
            <h2 className='mb-4'>Recent Bids</h2>
            <SearchBar />
            <div className="grid_view_toggle_btn">
                <p>Against Consulting Engineers Group Limited</p>
                <Switch defaultChecked className='switch_icons' />
                {isGridView
                    ? <span onClick={() => setIsGridView(false)} >
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10.6666 8.66663H26.6666M10.6666 16H26.6666M10.6666 23.3333H26.6666M5.33325 8.66663H6.66659M5.33325 16H6.66659M5.33325 23.3333H6.66659" stroke="#7E7E7E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                    : <span onClick={() => setIsGridView(true)}>
                        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4 9C4 6.64267 4 5.464 4.73333 4.73333C5.46267 4 6.64133 4 9 4C11.3573 4 12.536 4 13.2667 4.73333C14 5.464 14 6.64267 14 9C14 11.3573 14 12.536 13.2667 13.2667C12.536 14 11.3573 14 9 14C6.64267 14 5.464 14 4.73333 13.2667C4 12.5373 4 11.3587 4 9ZM4 23.0093C4 20.652 4 19.4733 4.73333 18.7427C5.464 18.0093 6.64267 18.0093 9 18.0093C11.3573 18.0093 12.536 18.0093 13.2667 18.7427C14 19.4733 14 20.652 14 23.0093C14 25.3667 14 26.5453 13.2667 27.276C12.536 28.0093 11.3573 28.0093 9 28.0093C6.64267 28.0093 5.464 28.0093 4.73333 27.276C4 26.5467 4 25.3667 4 23.0093ZM18 9C18 6.64267 18 5.464 18.7333 4.73333C19.464 4 20.6427 4 23 4C25.3573 4 26.536 4 27.2667 4.73333C28 5.464 28 6.64267 28 9C28 11.3573 28 12.536 27.2667 13.2667C26.536 14 25.3573 14 23 14C20.6427 14 19.464 14 18.7333 13.2667C18 12.536 18 11.3573 18 9ZM18 23.0093C18 20.652 18 19.4733 18.7333 18.7427C19.464 18.0093 20.6427 18.0093 23 18.0093C25.3573 18.0093 26.536 18.0093 27.2667 18.7427C28 19.4733 28 20.652 28 23.0093C28 25.3667 28 26.5453 27.2667 27.276C26.536 28.0093 25.3573 28.0093 23 28.0093C20.6427 28.0093 19.464 28.0093 18.7333 27.276C18 26.5453 18 25.3667 18 23.0093Z" stroke="#7E7E7E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </span>
                }
            </div>
            <div className='my-4'>
                <FilteredTagsAndSearchResult
                    onTagClose={console.log}
                    tagsData={Array(10).fill(1)}
                    searchResults="Showing 1 to 20 of 4364210 Results"
                />
            </div>
            <div className={`mt-5 ${isGridView ? 'grid_view_active' : ''}`}>
                <div className='row g-4'>
                    {Array.from({ length: 10 }).map((_, index) => (
                        <div className={`col-12 ${isGridView ? "col-lg-6" : ""}`} key={index}>
                            <TenderCard isGridView={isGridView} status='primary'/>
                        </div>
                    ))}
                </div>
            </div>
            <Pagination defaultCurrent={6} total={500} className='mt-5 d-flex justify-content-center' />
        </div>
    )
}

export default RecentBids