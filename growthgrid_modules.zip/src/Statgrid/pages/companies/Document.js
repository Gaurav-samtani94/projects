import { Button } from 'antd';
import React from 'react';

// Import images for different file types
import fileImgImage from "../../../BidGrid/assets/images/image.png";
import fileTextImage from "../../../BidGrid/assets/images/txt-file.png";
import fileCSVImage from "../../../BidGrid/assets/images/sheets.png";
import fileVideoImage from "../../../BidGrid/assets/images/video.png";
import filePPTImage from "../../../BidGrid/assets/images/ppt.png";
import fileDocImage from "../../../BidGrid/assets/images/doc.png";
import filePDFImage from "../../../BidGrid/assets/images/pdf.png";
import universalImg from "../../../BidGrid/assets/images/attachment.png";

const Documents = ({ documentData }) => {
    console.log(documentData, "documentData");

    const renderDocument = (item, index) => {
        const fileType = item?.ext?.toLowerCase();
        const fileUrl = `https://api.growthgrids.com/stats_grid_staging/${item.path}${item.document_url}`;

       
        const handleButtonClick = () => {
            if (fileType === '.jpeg' || fileType === '.jpg' || fileType === '.png') {
                
                window.open(fileUrl);
            } else {
                
                window.location.href = fileUrl;
            }
        };

      
        return (
            <div className='col-2' key={index}>
                <div className='border rounded-3 w-100 p-2'>

                    {fileType === '.jpeg' || fileType === '.jpg' || fileType === '.png' ? (
                        <img className='w-100' src={fileImgImage} alt={`File ${index + 1}`} />
                    ) : fileType === '.pdf' ? (
                        <img className='w-100' src={filePDFImage} alt={`File ${index + 1}`} />
                    ) : fileType === '.doc' || fileType === '.docx' || fileType === '.pdf' ? (
                        <img className='w-100' src={fileDocImage} alt={`File ${index + 1}`} />
                    ) : (
                        <img className='w-100' src={universalImg} alt={`File ${index + 1}`} />
                    )}
                    <h6 className='text-center'>File {index + 1}</h6>
 
                    <Button className='w-100 button-primary-solid' size='small' type='primary' onClick={handleButtonClick}>
                        {fileType === '.jpeg' || fileType === '.jpg' || fileType === '.png' ? 'View' : 'Download'}
                    </Button>
                </div>
            </div>
        );
    };

    return (
        <div className='bg-white p-4 info-section'>
            <div className="d-flex gap-3 justify-content-between mb-4">
                <h4 className='mb-0'>Documents</h4>
            </div>
            <div className="row g-2">
                {documentData.map((item, index) => (
                    renderDocument(item, index)
                ))}
            </div>
        </div>
    );
};

export default Documents;
