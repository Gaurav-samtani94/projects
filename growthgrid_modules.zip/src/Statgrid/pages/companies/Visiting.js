// @ts-nocheck
import { PlusOutlined, UploadOutlined } from '@ant-design/icons'
import { CompanyListApi } from 'Services/statgrid/companylist/CompanyListApi';
import { Button, Col, Divider, Drawer, Input, Modal, Row, Select, Upload } from 'antd'
import VisitingCard from 'companyVisitor/components/cards/VisitingCard'
import React, { useState } from 'react'

const initialState = {
    request_file: ["JHJHJ"],

}
// const getBase64 = (file) =>
//     new Promise((resolve, reject) => {
//         const reader = new FileReader();
//         reader.readAsDataURL(file);
//         reader.onload = () => resolve(reader.result);
//         reader.onerror = (error) => reject(error);
//     });

const Visiting = ({visitingCard,comp_id,setVisitingCard}) => {
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
   
    const [fileList, setFileList] = useState(initialState);

    const handleCancel = () => setPreviewOpen(false);
    const handlePreview = async (file) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj);
        }
        setPreviewImage(file.url || file.preview);
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url.substring(file.url.lastIndexOf('/') + 1));
    };
    const handleChangeData = (name, value) => setFileList({ ...fileList, [name]: value })

    const getBase64 = (file, callback) => {
        const reader = new FileReader();
        reader.addEventListener('load', () => callback(reader.result));
        reader.addEventListener('error', () => callback(null));
        reader.readAsDataURL(file);
    };

    const handleDoc = (info) => {
        if (info.file.status === 'uploading') {
            Promise.all(info.fileList.map(file => new Promise((resolve, reject) => {
                getBase64(file.originFileObj, (url) => {
                    if (url) {
                        resolve({
                            uid: file.uid,
                            name: file.name,
                            status: 'done',
                            originFileObj: file.originFileObj,
                        });
                    } else {
                        reject(new Error('File is corrupted or invalid'));
                    }
                });
            })))
                .then(fileList => {
                    setFileList({ ...fileList, request_file: fileList });
                })
                .catch(error => {
                    console.error('Error processing files:', error);
                });
        }
    };

    const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
    
    const uploadButton = (
        <button
            style={{
                border: 0,
                background: 'none',
            }}
            type="button"
        >
            <PlusOutlined />
            <div
                style={{
                    marginTop: 8,
                }}
            >
                Upload
            </div>
        </button>
    )
    const [editModalOpen, setEditModalOpen] = useState(false);
    const [editedData, setEditedData] = useState({});
    const [isDrawerOpen, setIsDrawerOpen] = useState(false)

    const closeDrawer = () => {
        setIsDrawerOpen(false)
    }
    const handleEditData = () => {
        setEditModalOpen(true)
        setEditedData({})
        
    }

    // const detailsData = async () => {
    //     const formData = new FormData();
    //     formData.append('name', editedData?.name);
    //     formData.append('email', editedData?.email);
    //     formData.append('contact_number', editedData?.contact_number);
    //     formData.append('desiganation', editedData?.desiganation);
        
    //     // Append comp_id only when adding a new entry
    //     if (!editedData?.id) {
    //         formData.append('comp_id', comp_id);
    //     }
        
    //     fileList?.request_file?.forEach((file, index) => {
    //         formData.append('visiting_card', file.originFileObj);
    //     });
        
    //     console.log('editedData?.id===>>>', editedData?.id);
        
    //     try {
    //         if (editedData?.id) {
    //             // Append both comp_id and id when updating an existing entry
    //             formData.append('comp_id', parseInt(comp_id));
    //             formData.append('id', parseInt(editedData.id));
    //             const rsp = await CompanyListApi?.updateVisitingCard(formData);
    //             if (rsp?.data?.status === "1") {
    //                 // Find the updated card in the visitingCard state and update it
    //                 const updatedVisitingCard = rsp?.data?.data;
    //                 const updatedVisitingCardList = visitingCard.map(card => {
    //                     if (card.id === updatedVisitingCard.id) {
    //                         return updatedVisitingCard;
    //                     } else {
    //                         return card;
    //                     }
    //                 });
    //                 setVisitingCard(updatedVisitingCardList);
    //                 setEditedData({});
    //                 setFileList([]);
    //                 setEditModalOpen(false);
    //             }
    //         } else {
    //             const respndata = await CompanyListApi?.addVisitingCard(formData);
    //             if (respndata?.data?.status === "1") {
    //                 const newVisitingCardList = [...visitingCard, respndata?.data?.data];
    //                 setVisitingCard(newVisitingCardList);
    //                 setEditedData({});
    //                 setFileList([]);
    //                 setEditModalOpen(false);
    //             }
    //         }
    //     } catch (error) {
    //         console.log(error);
    //     }
    // }
    
    
    
    const beforeUpload = (file) => {
        const allowedFileTypes = ['image/jpeg', 'image/png', 'application/pdf', 'text/html'];

        // if (!allowedFileTypes.includes(file.type)) {
        //     notify('You can only upload JPG, PNG, PDF, or HTML files!');
        //     return false;
        // }
        return true;
    };
    // const showSiteOffices = siteOfficecard?.some(siteOffice => siteOffice?.sg_comp_site_offices?.length > 0);
    return (
        <div className='bg-white p-4 info-section'>
            <div className="d-flex gap-3 justify-content-between mb-4">
                <h4 className='mb-0'>Visiting Card</h4>
                {/* <Button className='button-primary-solid' key="submit" type="primary" onClick={() =>handleEditData()} icon={<PlusOutlined />}>
                </Button> */}
            </div>
            <div className="row g-4">
                {visitingCard.map((items, index) => {
                    return (
                        <div className="col-3" key={index}>
                            <VisitingCard
                                // onDelete={() => {
                                //     Modal.confirm({
                                //         title: 'Delete Card',
                                //         content: 'Are You sure you want to delete this visiting card',
                                //         onOk: () => {
                                //             // Handle the delete action here
                                //             // You can close the modal or perform any other necessary tasks
                                //         },
                                //         onCancel: () => {
                                //             // Handle the cancel action here
                                //             // You can close the modal or perform any other necessary tasks
                                //         },
                                //         okText: 'Sure', // Customize the text for the "Sure" button
                                //         cancelText: 'Cancel', // Customize the text for the "Cancel" button
                                //         okButtonProps: {
                                //             danger: true,
                                //             type: "primary"
                                //         },
                                //         cancelButtonProps: {
                                //             className: "button-primary-outlined"
                                //         },
                                //         // footer: (item, { OkBtn, CancelBtn }) => (
                                //         //     <>
                                //         //         <CancelBtn />
                                //         //         <OkBtn  />
                                //         //     </>
                                //         // ),
                                //     });
                                // }}
                                // // onEdit={() => setEditModalOpen(true)}
                                // onEdit={() => {
                                //     setEditedData({
                                //         id: items?.id,
                                //         name: items?.name,
                                //         desiganation: items?.desiganation,
                                //         email: items?.email,
                                //         contact_number: items?.contact_number,
                                //         companyName: items?.comp_name,
                                //         // Add other fields here
                                //     });
                                //     setEditModalOpen(true);
                                // }}
                                onView={() => setIsDrawerOpen(true)}
                                data={{
                                    id: items?.id,
                                    name: items?.name,
                                    desiganation: items?.desiganation,
                                    companyName: items?.comp_name,
                                    mobileNo: items?.contact_number,
                                    email: items?.email,
                                  
                                }}
                            />
                        </div>
                    )
                })}
            </div>


            {/* <Modal
                title="Modal 1000px width"
                centered
                open={editModalOpen }
                onOk={ detailsData}
                onCancel={() => setEditModalOpen(false)}
                width={1000}
                okButtonProps={{
                    className: "button-primary-solid",
                    type: "primary"
                }}
                cancelButtonProps={{
                    className: "button-primary-outlined"
                }}
            >
                <form className='mb-4'>
                    <div
                        className="row g-4"
                    >
                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'>Company Logo</p>
                                <Upload
                                    action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
                                    listType="picture"
                                    maxCount={1}
                                    fileList={fileList?.document_file_name}
                                    onChange={handleDoc}
                                    beforeUpload={beforeUpload}
                                    name="files"
                                >
                                    <Button size='large' icon={<UploadOutlined />}>Upload Logo</Button>
                                </Upload>
                            </label>
                        </div>
                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'> Name</p>
                                <Input name='name' className='input-outlined' size="large" placeholder="Enter Email"value={editedData.name} onChange={(e) => setEditedData({ ...editedData, name: e.target.value })}   />
                            </label>
                        </div>
                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'>Company Name</p>
                                <Input name='name' className='input-outlined' size="large" placeholder="Enter Email"value={editedData.comp_name} onChange={(e) => setEditedData({ ...editedData, comp_name: e.target.value })}   />
                            </label>
                        </div>
                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'>Email</p>
                                <Input className='input-outlined' size="large" placeholder="Enter Email" value={editedData.email} onChange={(e) => setEditedData({ ...editedData, email: e.target.value })} />
                            </label>
                        </div>
                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'>Phone</p>
                                <Input className='input-outlined' size="large" placeholder="Enter Phone" value={editedData.contact_number} onChange={(e) => setEditedData({ ...editedData, contact_number: e.target.value })}/>
                               
                            </label>
                        </div>

                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'>Designation</p>
                                <Input className='input-outlined' size="large" placeholder="Enter Phone" value={editedData.desiganation} onChange={(e) => setEditedData({ ...editedData, desiganation: e.target.value })}/>
                            </label>
                        </div>
                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'>Website</p>
                                <Input className='input-outlined' size="large" placeholder="Enter Website" />
                            </label>
                        </div>
                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'>Ho-Country</p>
                                <Select
                                    showSearch
                                    size='large'
                                    className='input-outlined w-100'
                                    placeholder="Select Country"
                                    optionFilterProp="children"
                                    // mode="multiple"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    filterSort={(optionA, optionB) =>
                                        (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                    }
                                    options={[
                                        {
                                            value: '1',
                                            label: 'Not Identified',
                                        },
                                        {
                                            value: '2',
                                            label: 'India',
                                        }
                                    ]}
                                />
                            </label>
                        </div>
                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'>State</p>
                                <Select
                                    showSearch
                                    size='large'
                                    className='input-outlined w-100'
                                    placeholder="Select State"
                                    optionFilterProp="children"
                                    // mode="multiple"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    filterSort={(optionA, optionB) =>
                                        (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                    }
                                    options={[
                                        {
                                            value: '1',
                                            label: 'Not Identified',
                                        },
                                        {
                                            value: '2',
                                            label: 'UP',
                                        }
                                    ]}
                                />
                            </label>
                        </div>
                        <div className="col-12 col-lg-6">
                            <label className='d-block'>
                                <p className='mb-2'>Operating Countries</p>
                                <Select
                                    showSearch
                                    size='large'
                                    className='input-outlined w-100'
                                    placeholder="Select Operating Countries"
                                    optionFilterProp="children"
                                    mode="multiple"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    filterSort={(optionA, optionB) =>
                                        (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                    }
                                    options={[
                                        {
                                            value: '1',
                                            label: 'US',
                                        },
                                        {
                                            value: '2',
                                            label: 'INDIA',
                                        }
                                    ]}
                                />
                            </label>
                        </div>
                        <div className="col-12 col-md-6">
                            <label className='d-block'>
                                <p className='mb-2'>Field / Company's Nature </p>
                                <Select
                                    showSearch
                                    size='large'
                                    className='input-outlined w-100'
                                    placeholder="Select Field / Company's Nature "
                                    optionFilterProp="children"
                                    mode="multiple"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    filterSort={(optionA, optionB) =>
                                        (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                    }
                                    options={[
                                        {
                                            value: '1',
                                            label: 'Consultancy',
                                        },
                                        {
                                            value: '2',
                                            label: 'INDIA',
                                        }
                                    ]}
                                />
                            </label>
                        </div>
                        <div className="col-12 col-md-6">
                            <label className='d-block'>
                                <p className='mb-2'>Sector </p>
                                <Select
                                    showSearch
                                    size='large'
                                    className='input-outlined w-100'
                                    placeholder="Select Sector "
                                    optionFilterProp="children"
                                    mode="multiple"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    filterSort={(optionA, optionB) =>
                                        (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                    }
                                    options={[
                                        {
                                            value: '1',
                                            label: 'Highway',
                                        },
                                        {
                                            value: '2',
                                            label: 'INDIA',
                                        }
                                    ]}
                                />
                            </label>
                        </div>
                    </div>
                </form>
            </Modal> */}



            <Drawer width={640} placement="right" closable={false} onClose={closeDrawer} open={isDrawerOpen}>
                <div className='d-flex gap-4 mb-4'>
                    <Upload
                        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
                        listType="picture-card"
                        // @ts-ignore
                        // fileList={fileList}
                        style={{ width: "fit-content" }}
                        onPreview={handlePreview}
                        accept='image/png, image/jpg, image/jpeg, image/webp'
                        onChange={handleChange}
                        className='upload-input'
                    >
                        {fileList.length > 0 ? null : uploadButton}
                    </Upload>
                    <div>
                        <small>Managing Director</small>
                        <h2 className='mb-2'>Vishwas Jain</h2>
                        <p>Consulting Engineers Group Ltd.</p>
                    </div>
                </div>
                <p className='mb-4'><strong>Description: </strong>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit doloremque delectus sunt magnam. Illum, fugiat minima quia vero modi hic, deserunt inventore nulla nostrum voluptate repellat atque quo assumenda, ipsum in officia.</p>

                <div className='detail-list row g-2 mb-4'>
                    <div className="col-6">
                        <p className='d-flex gap-2 align-items-center'><span>{callIcon()}</span><span>9876543210</span></p>
                    </div>
                    <div className="col-6">
                        <p className='d-flex gap-2 align-items-center'><span>{mailIcon()}</span><span>example.com</span></p>
                    </div>
                    <div className="col-6">
                        <p className='d-flex gap-2 align-items-center'><span>{referralIcon()}</span><span>Eran</span></p>
                    </div>
                </div>

                <p className='d-flex gap-2 align-items-center mb-4'><span>{pinIcon()}</span><span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta debitis cumque est?</span></p>

                {/* <CommentSection/> */}
            </Drawer>

            <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                <img alt="example" style={{ width: '100%' }} src={previewImage} />
            </Modal>
        </div>
    )
}

const callIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24">
        <path fill="currentColor" d="M3.833 4h4.49L9.77 7.618l-2.325 1.55A1 1 0 0 0 7 10c.003.094 0 .001 0 .001v.021a2.129 2.129 0 0 0 .006.134c.006.082.016.193.035.33c.039.27.114.642.26 1.08c.294.88.87 2.019 1.992 3.141c1.122 1.122 2.261 1.698 3.14 1.992c.439.146.81.22 1.082.26a4.424 4.424 0 0 0 .463.04l.013.001h.008s.112-.006.001 0a1 1 0 0 0 .894-.553l.67-1.34l4.436.74v4.32c-2.111.305-7.813.606-12.293-3.874C3.227 11.813 3.527 6.11 3.833 4zm5.24 6.486l1.807-1.204a2 2 0 0 0 .747-2.407L10.18 3.257A2 2 0 0 0 8.323 2H3.781c-.909 0-1.764.631-1.913 1.617c-.34 2.242-.801 8.864 4.425 14.09c5.226 5.226 11.848 4.764 14.09 4.425c.986-.15 1.617-1.004 1.617-1.913v-4.372a2 2 0 0 0-1.671-1.973l-4.436-.739a2 2 0 0 0-2.118 1.078l-.346.693a4.71 4.71 0 0 1-.363-.105c-.62-.206-1.481-.63-2.359-1.508c-.878-.878-1.302-1.739-1.508-2.36a4.583 4.583 0 0 1-.125-.447z" />
    </svg>
)
const mailIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 21 21">
        <g fill="none" fill-rule="evenodd" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3.5 6.5v8a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-8a2 2 0 0 0-2-2h-10a2 2 0 0 0-2 2z" />
            <path d="m5.5 7.5l5 3l5-3" />
        </g>
    </svg>
)
const referralIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 14 14">
        <g fill="none" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M2.04 13.448v-2.48h2.48" />
            <path stroke-linecap="round" stroke-linejoin="round" d="M13.339 5.815a6.449 6.449 0 0 1-11.3 5.308M.661 8.185a6.449 6.449 0 0 1 11.3-5.308" />
            <path stroke-linecap="round" stroke-linejoin="round" d="M11.96.552v2.48H9.48" />
            <path d="M5.75 5.25a1.25 1.25 0 1 0 2.5 0a1.25 1.25 0 1 0-2.5 0" />
            <path stroke-linecap="round" d="M4.708 9.5a2.5 2.5 0 0 1 4.584 0" />
        </g>
    </svg>
)
const pinIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
        <g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5">
            <path d="M12.56 20.82a.964.964 0 0 1-1.12 0C6.611 17.378 1.486 10.298 6.667 5.182A7.592 7.592 0 0 1 12 3c2 0 3.919.785 5.333 2.181c5.181 5.116.056 12.196-4.773 15.64Z" />
            <path d="M12 12a2 2 0 1 0 0-4a2 2 0 0 0 0 4Z" />
        </g>
    </svg>
)

export default Visiting