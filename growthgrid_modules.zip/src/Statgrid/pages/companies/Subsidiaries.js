import { PlusOutlined } from '@ant-design/icons'
import { Button } from 'antd'
import React from 'react'

const Subsidiaries = ({ subsidayList }) => {
    // Check if any subsidiary has a main_tbl_company with a non-empty company_name
    const hasMainCompany = subsidayList.some(item => item.main_tbl_company && item.main_tbl_company.company_name);

    return (
        <div className='bg-white p-4 info-section'>
            {hasMainCompany && (
                <div className="d-flex gap-3 justify-content-between mb-4">
                    <h4 className='mb-0'>Subsidiaries</h4>
                    {/* <Button className='button-primary-solid' key="submit" type="primary" icon={<PlusOutlined />}>
                    </Button> */}
                </div>
            )}
            {subsidayList?.map((item, index) => (
                <div key={index}>
                    {item.main_tbl_company && item.main_tbl_company.company_name && (
                        <div  className='brand-links d-block mb-2'>{item.main_tbl_company.company_name}</div>
                    )}
                </div>
            ))}
        </div>
    )
}

export default Subsidiaries;
