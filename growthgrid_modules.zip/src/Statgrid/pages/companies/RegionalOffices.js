import React from 'react'
import RegionalOfficeCard from '../../components/cards/RegionalOfficeCard'
import { PlusOutlined } from '@ant-design/icons'
import { Button, Modal } from 'antd'

const RegionalOffices = ({ regionalOfficeCard }) => {
    return (
        <div className='bg-white p-4 info-section'>
            {regionalOfficeCard?.length > 0 && (
                <div className="d-flex gap-3 justify-content-between mb-4">
                    <h4 className='mb-0'>Regional Offices</h4>
                    {/* <Button className='button-primary-solid' key="submit" type="primary" icon={<PlusOutlined />}>
                    </Button> */}
                </div>
            )}
            <div className="row g-3">
                {regionalOfficeCard.map((regionalOffice, index) => (
                    <div className="col-12" key={regionalOffice.id}>
                        <RegionalOfficeCard
                            key={regionalOffice.id}
                            onDelete={() => {
                                Modal.confirm({
                                    title: 'Delete Card',
                                    content: 'Are You sure you want to delete this visiting card',
                                    onOk: () => {
                                        // Handle the delete action here
                                    },
                                    onCancel: () => {
                                        // Handle the cancel action here
                                    },
                                    okText: 'Sure',
                                    cancelText: 'Cancel',
                                    okButtonProps: {
                                        danger: true,
                                        type: "primary"
                                    },
                                    cancelButtonProps: {
                                        className: "button-primary-outlined"
                                    },
                                    footer: (item, { OkBtn, CancelBtn }) => (
                                        <>
                                            <CancelBtn />
                                            <OkBtn />
                                        </>
                                    ),
                                });
                            }}
                            onEdit={() => console.log("edit")}
                            data={{
                                country: regionalOffice?.sg_mstr_country?.country_name || "",
                                state: regionalOffice?.sg_mstr_state?.state_name || "",
                                city: regionalOffice?.sg_mstr_city?.city_name || "",
                                companyName: regionalOffice.name || "",
                                companyAddress: regionalOffice.address || "",
                                mobileNo: regionalOffice.contact_number || "",
                                email: regionalOffice.email || "",
                            }}
                        />
                    </div>
                ))}


            </div>

        </div>
    )
}

export default RegionalOffices