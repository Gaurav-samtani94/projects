import DurationFilterDropDown from 'Statgrid/components/UI/DurationFilterDropDown'
import OverviewCard from 'Statgrid/components/cards/OverviewCard'
import React from 'react'

const OverviewSection = () => {
    return (
        <>
            <div className="d-flex gap-3 justify-content-between mb-4">
                <h2>Overview</h2>
                <DurationFilterDropDown />
            </div>
            <div className="row g-4">
                <div className='col-12 col-lg-6'>
                    <OverviewCard
                        cartTitle="Number of Bids"
                        details={[
                            { value: "62", label: "Total Bids" },
                            { value: "6 (9.68%)", label: "Winning Bids (L1)" },
                        ]}
                    />
                </div>
                <div className='col-12 col-lg-6'>
                    <OverviewCard
                        cartTitle="Total Bid Amount"
                        details={[
                            { value: "19.15 Cr", label: "Total Amount Bid" },
                            { value: "2.49 Cr", label: "Amount won (L1)" },
                        ]}
                    />
                </div>
                <div className='col-12 col-lg-6'>
                    <OverviewCard
                        cartTitle="Organizations Bid"
                        details={[
                            { value: "37", label: "Organization bid by company" },
                            { value: "5", label: "Common Orgs" },
                        ]}
                    />
                </div>
                <div className='col-12 col-lg-6'>
                    <OverviewCard
                        cartTitle="Company"
                        details={[
                            { value: "256", label: "Number of competitors" },
                            { value: "2", label: "Number of contacts" },
                        ]}
                    />
                </div>
            </div>
        </>
    )
}

export default OverviewSection