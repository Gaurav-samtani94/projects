import { PlusOutlined } from '@ant-design/icons'
import { Button } from 'antd'

import React from 'react'
import SiteOfficeCard from '../../components/cards/SiteOfficeCard'

const SiteOffices = ({ siteOfficecard }) => {
    return (
        <div className='bg-white p-4 info-section'>
            <div className="d-flex gap-3 justify-content-between mb-4">
                {siteOfficecard.length > 0 && (
                    <h4 className='mb-0'>Site Offices</h4>
                )}

                {/* <Button className='button-primary-solid' key="submit" type="primary" icon={<PlusOutlined />}>
                    </Button> */}
            </div>

            {/* <div className="row g-3">
                {siteOfficecard.filter(item => item.sg_comp_site_offices && item.sg_comp_site_offices.length > 0).map((office, index) => (
                    <div className="col-12" key={index}>
                        <SiteOfficeCard
                            onDelete={() => console.log("deleted")}
                            onEdit={() => console.log("edit")}
                            data={{
                                country: "In",
                                state: "RJ",
                                officeManager: office.sg_comp_site_offices[0]?.office_manager || "",
                                contactPerson: office.sg_comp_site_offices[0]?.contact_person || "",
                                companyAddress: office.sg_comp_site_offices[0]?.address || "",
                            }}
                        />
                    </div>
                ))}
            </div> */}
            <div className="row g-3">
                {siteOfficecard?.map((office, index) => {
                    return (
                        // office && office.length > 0 &&
                        // office.map((siteOffice, subIndex) => (
                        <div className="col-12" key={`${index}`}>
                            <SiteOfficeCard
                                onDelete={() => console.log("deleted")}
                                onEdit={() => console.log("edit")}
                                data={{
                                    country: office?.sg_mstr_country?.country_name || "",
                                    state: office?.sg_mstr_state?.state_name || "",
                                    city: office?.sg_mstr_city?.city_name || "",
                                    officeManager: office?.office_manager || "",
                                    contactPerson: office?.contact_person || "",
                                    companyAddress: office?.address || "",
                                    contactNumber: office?.contact_number || "",
                                    email: office?.email || ""

                                }}
                            />
                        </div>
                        // ))
                    )

                })}
            </div>

        </div>
    )
}

export default SiteOffices