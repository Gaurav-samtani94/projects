// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Row, Switch, Col, Pagination, Modal } from 'antd'
import { useNavigate } from 'react-router-dom'
import SearchBar from 'Statgrid/components/searchBar/SearchBar'
import FilteredTagsAndSearchResult from 'Statgrid/components/UI/FilteredTagsAndSearchResult'
import CompanyCard from 'Statgrid/components/cards/CompanyCard'
import { CompanyListApi } from 'Services/statgrid/companylist/CompanyListApi'
import STATROUTES from 'Statgrid/router/statgridRoutes'
import { useDispatch } from 'react-redux'
import { CompanyBalanceAction } from 'Redux/actions/statgrid/statBalanceAction'

import EmptyBox from '../../../assests/img/empty-box.png'
import { useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux'
import { statFilterAction } from 'Redux/actions/statgrid/statFilterAction'
import { companyListData } from 'Statgrid/utils/companyData'

const initialstate = {
    page: "",
    limit: ""
}



function CompanyList() {
    const [data, setData] = useState(initialstate)
    const navigation = useNavigate()
    const [isGridView, setIsGridView] = useState(false)
    // const [page, setPage] = useState(parseInt(data.page) || 1);

    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const currentPage = parseInt(searchParams.get('page')) || 1;
    const { statFilterValues } = useSelector((state => state.StatFilter))
    const dispatch = useDispatch()
    const onChange = (checked) => {
        console.log(`switch to ${checked}`);
    };

    const [comapnyRecord, setCompanyRecord] = useState([])
    const [companyRecordCount, setCompanyRecordCount] = useState([])
    // const [companyCount, setCompanyCount] = useState()



    const CalledCompanyList = async () => {
        const formData = new URLSearchParams();
        formData.append("client_id", statFilterValues?.client_id ? statFilterValues?.client_id : "")
        formData.append("funding_id", statFilterValues?.funding_id ? statFilterValues?.funding_id : "")
        formData.append("category_id", statFilterValues?.category_id ? statFilterValues?.category_id : "")
        formData.append("country_id", statFilterValues?.country_id ? statFilterValues?.country_id : "")
        formData.append("state_id", statFilterValues?.state_id ? statFilterValues?.state_id : "")
        formData.append("city_it", statFilterValues?.city_it ? statFilterValues?.city_it : "")
        formData.append("sector_id", statFilterValues?.sector_id ? statFilterValues?.sector_id : "")
        // formData.append("page",  page)
        formData.append('page', statFilterValues?.page ? statFilterValues?.page : "1")
        formData.append("limit", statFilterValues?.limit ? parseInt(statFilterValues?.limit) : 25)
        // formData.append("page", data?.page)
        try {
            const response = await CompanyListApi?.CompanyListData(formData)
            if (response?.data?.status === "1") {
                setCompanyRecord(response?.data?.data)
                setCompanyRecordCount(response?.data?.count)
            } else {
                setCompanyRecord([])
                setCompanyRecordCount([])
            }
        } catch (error) {
            console.log(error)
        }

    }


    const UnlockedCompany = async (id) => {
        const formData = new URLSearchParams();
        formData.append("comp_id", id)
        try {
            const response = await CompanyListApi?.unlockCompanydata(formData)
            const balanseRes = await CompanyListApi?.getCompanyBalance()
            console.log(balanseRes?.data, "balance");
            if (response?.data?.status === "1" && balanseRes?.data?.status === "1") {
                // setCompanybalance(balanseRes?.data?.data)
                dispatch(CompanyBalanceAction(balanseRes?.data?.data))
                setCompanyRecord(response?.data?.data)
                CalledCompanyList()
            }
        } catch (error) {
            console.log(error)
        }
    }

    const handleClick = async (event, id, isLocked) => {
        event.preventDefault();

        if (localStorage.getItem('statToken') !== '') {
            try {
                const filterCount = new URLSearchParams()
                filterCount.append('comp_id', id)
                const res = await CompanyListApi?.companyViewList(filterCount)
                if (res?.data?.status === "1") {
                    // setCompanyCount(res?.data?.data)
                    // const isLocked = comapnyRecord?.sg_company_unlock?.is_locked
                    if (isLocked) {
                        Modal.confirm({
                            title: 'Delete Reminder',
                            content: 'Are you sure want to delete this reminder?',
                            onOk: () => UnlockedCompany(id),
                            cancelText: "cancel",
                            okButtonProps: {
                                danger: true,
                            },
                            okText: "Sure",
                        })

                    } else {
                        navigation(`/${STATROUTES.PLACEHOLDER}/${STATROUTES.COMPANY_DETAIL}/${id}`)
                    }
                }

            } catch (error) {
                console.log(error)
            }
        } else {
            console.log('fail')
        }

    };

    const updateURLParams = (params) => {
        const newSearchParams = new URLSearchParams(location.search);
        for (const key in params) {
            if (params.hasOwnProperty(key)) {
                newSearchParams.set(key, params[key]);
            }
        }
        const newURL = `${window.location.pathname}?${newSearchParams.toString()}`;
        window.history.replaceState(null, '', newURL);
    };

    useEffect(() => {
        CalledCompanyList();
    }, [statFilterValues])


    // useEffect(() => {
    //     const obj = {
    //         // limit: statFilterValues?.limit ? statFilterValues?.limit : '25',
    //         page: statFilterValues?.page ? statFilterValues?.page : '1',
    //     }
    //     dispatch(statFilterAction.statFilterUpdateAllKeys(obj))
    // }, [])

    const handlePageChange = (newPage) => {
        const obj = {
            page: newPage,
        }

        dispatch(statFilterAction.statFilterUpdateAllKeys(obj))
    };
    // const showCompanyList = () => {
    //     if (!comapnyRecord || !Array.isArray(comapnyRecord)) {
    //         return null;
    //     }
    //     return comapnyRecord?.length !== "0" && (
    //     comapnyRecord?.map((item, index) => {
    //         return (
    //             <Col span={isGridView ? 12 : 24} key={index} onClick={(event) => handleClick(event, item?.id, item?.sg_company_unlock === null ? true : item?.sg_company_unlock?.is_locked)}>
    //                 <CompanyCard isLocked={item?.sg_company_unlock === null ? true : item?.sg_company_unlock?.is_locked} isGridView={isGridView} item={item} />
    //             </Col>


    //         )
    //     })
    // ) 
    // }
    const showCompanyList = () => {
        if (!comapnyRecord || !Array.isArray(comapnyRecord)) {
            return null;
        }

        if (comapnyRecord.length === 0) {
            return (
                <div className="spinerWrap">
                    <div className="data_foundDiv">
                        <img src={EmptyBox} width={120} />
                        <div style={{ textAlign: "center", fontSize: 16, marginTop: 15 }}>No Record Found</div>
                    </div>
                </div>
            );
        }

        return comapnyRecord.map((item, index) => (
            <Col
                span={isGridView ? 12 : 24}
                key={index}
                onClick={(event) =>
                    handleClick(
                        event,
                        item?.id,
                        item?.sg_company_unlock === null
                            ? true
                            : item?.sg_company_unlock?.is_locked
                    )
                }
            >
                <CompanyCard
                    isLocked={
                        item?.sg_company_unlock === null
                            ? true
                            : item?.sg_company_unlock?.is_locked
                    }
                    isGridView={isGridView}
                    item={{
                        imgUrl: "https://api.dicebear.com/7.x/miniavs/svg?seed=2",
                        name: "company name",
                        state: "rajasthan",
                        sectors: [
                            "eathmoving",
                            " rail metro",
                            " defence",
                            "manufacturer of earth moving equipment",
                            "manufacturer of earthmoving machineries",
                            "manufacturer of hemm",
                            "manufactures of heavy equipment",
                            "manufacturing and supply of equipment",
                            "mining equipment",
                            " rail  metro coaches",
                            " defence eq"
                        ],
                    }}
                />
            </Col>
        ));
    };

    return (
        <div className='container-fluid'>
            <div className="company_list_main">
                <div className='company_heading mb-4'>
                    <h2>Companies</h2>
                </div>
                <SearchBar />
                <div className='company_grid_main'>
                    <div className="searchResults_count">Showing 1 to 20 of 4364210 Results</div>
                    <div className='company_leftcontent'>
                        <div className='content_lc'>
                            <p>Only Unlocked Companies</p>
                            <div className='switch_btn'>
                                <Switch defaultChecked onChange={onChange} />
                            </div>
                        </div>

                        <div className='grid_btnlc'>
                            {isGridView
                                ? <span onClick={() => setIsGridView(false)} >
                                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M10.6666 8.66663H26.6666M10.6666 16H26.6666M10.6666 23.3333H26.6666M5.33325 8.66663H6.66659M5.33325 16H6.66659M5.33325 23.3333H6.66659" stroke="#7E7E7E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </span>

                                : <span onClick={() => setIsGridView(true)}>
                                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M4 9C4 6.64267 4 5.464 4.73333 4.73333C5.46267 4 6.64133 4 9 4C11.3573 4 12.536 4 13.2667 4.73333C14 5.464 14 6.64267 14 9C14 11.3573 14 12.536 13.2667 13.2667C12.536 14 11.3573 14 9 14C6.64267 14 5.464 14 4.73333 13.2667C4 12.5373 4 11.3587 4 9ZM4 23.0093C4 20.652 4 19.4733 4.73333 18.7427C5.464 18.0093 6.64267 18.0093 9 18.0093C11.3573 18.0093 12.536 18.0093 13.2667 18.7427C14 19.4733 14 20.652 14 23.0093C14 25.3667 14 26.5453 13.2667 27.276C12.536 28.0093 11.3573 28.0093 9 28.0093C6.64267 28.0093 5.464 28.0093 4.73333 27.276C4 26.5467 4 25.3667 4 23.0093ZM18 9C18 6.64267 18 5.464 18.7333 4.73333C19.464 4 20.6427 4 23 4C25.3573 4 26.536 4 27.2667 4.73333C28 5.464 28 6.64267 28 9C28 11.3573 28 12.536 27.2667 13.2667C26.536 14 25.3573 14 23 14C20.6427 14 19.464 14 18.7333 13.2667C18 12.536 18 11.3573 18 9ZM18 23.0093C18 20.652 18 19.4733 18.7333 18.7427C19.464 18.0093 20.6427 18.0093 23 18.0093C25.3573 18.0093 26.536 18.0093 27.2667 18.7427C28 19.4733 28 20.652 28 23.0093C28 25.3667 28 26.5453 27.2667 27.276C26.536 28.0093 25.3573 28.0093 23 28.0093C20.6427 28.0093 19.464 28.0093 18.7333 27.276C18 26.5453 18 25.3667 18 23.0093Z" stroke="#7E7E7E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </span>
                            }
                        </div>
                    </div>
                </div>
                {/* <FilteredTagsAndSearchResult
                        tagsData={Array(8).fill(0)}
                        onTagClose={console.log}
                        searchResults={`Showing 1 to 20 of ${companyRecordCount} Results`}

                    /> */}
                <div>
                    <Row gutter={[24, 24]}>
                        {/* {showCompanyList()} */}
                        {companyListData.map((itm, index) => (
                            <Col span={isGridView ? 12 : 24} key={index} onClick={() => navigation(`/${STATROUTES.PLACEHOLDER}/${STATROUTES.COMPANY_DETAIL}/${index + 1}`)}>
                                <CompanyCard
                                    isGridView={isGridView}
                                    isLocked={itm?.unlocked}
                                    item={{
                                        imgUrl: itm?.logo,
                                        // imgUrl: "https://api.dicebear.com/7.x/miniavs/svg?seed=" + index,
                                        name: itm?.display_name,
                                        state: itm?.state,
                                        sectors: itm?.nature_of_business,
                                        num_bids: itm?.num_bids,
                                        last_bid_date: itm?.last_bid_date,
                                        following: 32
                                    }}
                                />
                            </Col>
                        ))}
                    </Row>
                </div>
                <Pagination
                    className='stats-pagination justify-content-center d-flex mt-5'
                    current={statFilterValues?.page}
                    count={companyRecordCount}
                    // defaultCurrent={1}
                    onChange={(newPage) => handlePageChange(newPage)}
                    total={500}
                />
            </div>
        </div>

    )
}

export default CompanyList