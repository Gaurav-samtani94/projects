import { CheckCircleOutlined, CloseCircleOutlined } from '@ant-design/icons';
import { Table, Tabs } from 'antd';
import React from 'react'

const OrganizationComparison = () => {
    const columns = [
        {
            title: 'Organization Name',
            dataIndex: 'organizationName',
        },
        {
            title: 'Bidded by Wapcos Limited',
            dataIndex: 'biddedByWapcos',
        },
        {
            title: 'Bidded by you',
            dataIndex: 'biddedByYou',
        },
        {
            title: 'Missed Tenders by you',
            dataIndex: 'missedByYou',
        },
    ];
    const data = [
        {
            key: '1',
            organizationName: 'National Highways Authority Of India',
            biddedByWapcos: <CheckCircleOutlined className='table_check_icon' />,
            biddedByYou: <CloseCircleOutlined className='table_close_icon' />,
            missedByYou: <div className='table_action'>
                <span>3</span>
                <button>see details</button>
            </div>
        },
        {
            key: '2',
            organizationName: 'National Highways Authority Of India',
            biddedByWapcos: <CheckCircleOutlined className='table_check_icon' />,
            biddedByYou: <CloseCircleOutlined className='table_close_icon' />,
            missedByYou: <div className='table_action'>
                <span>3</span>
                <button>see details</button>
            </div>
        },
        {
            key: '3',
            organizationName: 'National Highways Authority Of India',
            biddedByWapcos: <CheckCircleOutlined className='table_check_icon' />,
            biddedByYou: <CloseCircleOutlined className='table_close_icon' />,
            missedByYou: <div className='table_action'>
                <span>3</span>
                <button>see details</button>
            </div>
        },
        {
            key: '4',
            organizationName: 'National Highways Authority Of India',
            biddedByWapcos: <CheckCircleOutlined className='table_check_icon' />,
            biddedByYou: <CloseCircleOutlined className='table_close_icon' />,
            missedByYou: <div className='table_action'>
                <span>3</span>
                <button>see details</button>
            </div>
        },
        {
            key: '5',
            organizationName: 'National Highways Authority Of India',
            biddedByWapcos: <CheckCircleOutlined className='table_check_icon' />,
            biddedByYou: <CloseCircleOutlined className='table_close_icon' />,
            missedByYou: <div className='table_action'>
                <span>3</span>
                <button>see details</button>
            </div>
        },
        {
            key: '6',
            organizationName: 'National Highways Authority Of India',
            biddedByWapcos: <CheckCircleOutlined className='table_check_icon' />,
            biddedByYou: <CloseCircleOutlined className='table_close_icon' />,
            missedByYou: <div className='table_action'>
                <span>3</span>
                <button>see details</button>
            </div>
        },

    ];

    const itemsOrg = [
        {
            key: '1',
            label: 'All Result',
            children: <div className='all_result_data mt-4'>
                <div className='all_result_heading_main'>
                    <div className="all_result_heading_sub">
                        <h2>Detailed </h2>
                        <h2>Comparison</h2>
                    </div>
                    <div className="all_result_bids">
                        <div className="bid_by_org">
                            <span>401</span>
                            <p>Organizations not bid by you</p>
                        </div>
                        <div className="bid_by_company">
                            <span>432</span>
                            <p>Organizations bid by Company</p>
                        </div>
                    </div>
                </div>
                <div className="all_results_table">
                    <Table columns={columns} dataSource={data} />
                </div>
            </div>,
        },
        {
            key: '2',
            label: 'My Keywords',
            children: <div className='all_result_data mt-4'>
                <div className='all_result_heading_main'>
                    <div className="all_result_heading_sub">
                        <h2>Detailed </h2>
                        <h2>Comparison</h2>
                    </div>
                    <div className="all_result_bids">
                        <div className="bid_by_org">
                            <span>401</span>
                            <p>Organizations not bid by you</p>
                        </div>
                        <div className="bid_by_company">
                            <span>432</span>
                            <p>Organizations bid by Company</p>
                        </div>
                    </div>
                </div>
                <div className="all_results_table">
                    <Table columns={columns} dataSource={data} />
                </div>
            </div>,
        }

    ];
    return (
        <div className="org_details_comp_main">
            <h2 className='mb-4 '>Organization Comparison</h2>
            <div className="org_details_tabs_main">
                <Tabs defaultActiveKey="1" items={itemsOrg} className='comparison-tabs' />
            </div>
        </div>
    )
}

export default OrganizationComparison