import React, { useState } from 'react';
import { Avatar, Tooltip, Button, Divider } from 'antd';
import { ArrowUpOutlined } from '@ant-design/icons';
import MultiBarChart from 'Statgrid/components/UI/MultiBarChart';


const CompanyCompare = () => {


    return (
        <div className='container-fluid py-4 py-lg-5'>
            <h2>Companies Comparison</h2>
            <div className='compare_Wrapper pt-5'>
                <div className='row g-4 company_nameDet'>
                    <div className='col-12 col-lg-3'>
                        <div className='companyName_wrapper'>
                            <Avatar src={`https://api.dicebear.com/7.x/miniavs/svg?seed=16459234398290011014`} />
                            <p>Ela Green Buildings & Infrastructure Consultants Private Limited</p>
                            <Tooltip title="Close">
                                <Button size='small' className=' d-flex align-items-center justify-content-center' shape="circle" icon={<ArrowUpOutlined />} />
                            </Tooltip>
                        </div>
                    </div>
                    <div className='col-12 col-lg-3'>
                        <div className='companyName_wrapper'>
                            <Avatar src={`https://api.dicebear.com/7.x/miniavs/svg?seed=9797662158353016526`} />
                            <p>Plan & Build Consultants Limited Liability Partnership</p>
                            <Tooltip title="Close">
                                <Button size='small' className=' d-flex align-items-center justify-content-center' shape="circle" icon={<ArrowUpOutlined />} />
                            </Tooltip>
                        </div>
                    </div>
                    <div className='col-12 col-lg-3'>
                        <div className='companyName_wrapper'>
                            <Avatar src={`https://api.dicebear.com/7.x/miniavs/svg?seed=11620294049939283879`} />
                            <p>The Building Consultant & Technological Service Cooperative Society Limited T 1054</p>
                            <Tooltip title="Close">
                                <Button size='small' className=' d-flex align-items-center justify-content-center' shape="circle" icon={<ArrowUpOutlined />} />
                            </Tooltip>
                        </div>
                    </div>
                    <div className='col-12 col-lg-3'>
                        <div className='companyName_wrapper'>
                            <Avatar src={`https://api.dicebear.com/7.x/miniavs/svg?seed=15112791841539220679`} />
                            <p>NH Consulting Private Limited</p>
                            <Tooltip title="Close">
                                <Button size='small' className=' d-flex align-items-center justify-content-center' shape="circle" icon={<ArrowUpOutlined />} />
                            </Tooltip>
                        </div>
                    </div>
                </div>
                <div className='row g-4 mb-4 mb-lg-5'>
                    <div className='col-12 col-lg-3'>
                        <div className='compare_compDetail'>
                            <div className='mt-2'>
                                <span>Number of Bids</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>62</h2>
                                        <p>Total Bids</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>6 (9.68%)</h2>
                                        <p>Winning Bids (L1)</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Total Bid Amount</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>19.15 Cr</h2>
                                        <p>Total Amount Bid</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2.49 Cr</h2>
                                        <p>Amount won (L1)</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Organizations Bid</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>37</h2>
                                        <p>Organization bid by company</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2</h2>
                                        <p>Common Orgs</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Company</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>337</h2>
                                        <p>Number of competitors</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2</h2>
                                        <p>Number of contacts</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Company Description</span>
                                <div className='bids_compare mt-3'>
                                    <p>IT and Software Services</p>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Sectors</span>
                                <div className='bidsSector_compare mt-3'>
                                    <div className='sector_name'>
                                        <span>medical</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>technology</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>it services</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>automobile</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>oil</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>study</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-12 col-lg-3'>
                        <div className='compare_compDetail'>
                            <div className='mt-2'>
                                <span>Number of Bids</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>62</h2>
                                        <p>Total Bids</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>6 (9.68%)</h2>
                                        <p>Winning Bids (L1)</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Total Bid Amount</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>19.15 Cr</h2>
                                        <p>Total Amount Bid</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2.49 Cr</h2>
                                        <p>Amount won (L1)</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Organizations Bid</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>37</h2>
                                        <p>Organization bid by company</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2</h2>
                                        <p>Common Orgs</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Company</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>337</h2>
                                        <p>Number of competitors</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2</h2>
                                        <p>Number of contacts</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Company Description</span>
                                <div className='bids_compare mt-3'>
                                    <p>IT and Software Services</p>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Sectors</span>
                                <div className='bidsSector_compare mt-3'>
                                    <div className='sector_name'>
                                        <span>medical</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>technology</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>it services</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>automobile</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>oil</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>study</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-12 col-lg-3'>
                        <div className='compare_compDetail'>
                            <div className='mt-2'>
                                <span>Number of Bids</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>62</h2>
                                        <p>Total Bids</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>6 (9.68%)</h2>
                                        <p>Winning Bids (L1)</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Total Bid Amount</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>19.15 Cr</h2>
                                        <p>Total Amount Bid</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2.49 Cr</h2>
                                        <p>Amount won (L1)</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Organizations Bid</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>37</h2>
                                        <p>Organization bid by company</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2</h2>
                                        <p>Common Orgs</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Company</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>337</h2>
                                        <p>Number of competitors</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2</h2>
                                        <p>Number of contacts</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Company Description</span>
                                <div className='bids_compare mt-3'>
                                    <p>IT and Software Services</p>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Sectors</span>
                                <div className='bidsSector_compare mt-3'>
                                    <div className='sector_name'>
                                        <span>medical</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>technology</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>it services</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>automobile</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>oil</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>study</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className='col-12 col-lg-3'>
                        <div className='compare_compDetail'>
                            <div className='mt-2'>
                                <span>Number of Bids</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>62</h2>
                                        <p>Total Bids</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>6 (9.68%)</h2>
                                        <p>Winning Bids (L1)</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Total Bid Amount</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>19.15 Cr</h2>
                                        <p>Total Amount Bid</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2.49 Cr</h2>
                                        <p>Amount won (L1)</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Organizations Bid</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>37</h2>
                                        <p>Organization bid by company</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2</h2>
                                        <p>Common Orgs</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Company</span>
                                <div className='bids_compare mt-3'>
                                    <div className='total_bids'>
                                        <h2>337</h2>
                                        <p>Number of competitors</p>
                                    </div>
                                    <div className='total_bids'>
                                        <h2>2</h2>
                                        <p>Number of contacts</p>
                                    </div>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Company Description</span>
                                <div className='bids_compare mt-3'>
                                    <p>IT and Software Services</p>
                                </div>
                            </div>
                            <Divider />
                            <div className='mt-4'>
                                <span>Sectors</span>
                                <div className='bidsSector_compare mt-3'>
                                    <div className='sector_name'>
                                        <span>medical</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>technology</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>it services</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>automobile</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>oil</span>
                                    </div>
                                    <div className='sector_name'>
                                        <span>study</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <MultiBarChart
                    title={'Bidding Timeline'}
                    labels={[
                        "January", "February", "March", "April", "May", "June",
                        "July", "August", "September", "October", "November", "December"
                    ]}
                    dataSet={[
                        {
                            label: 'Ela Green Buildings & Infrastructure Consultants Private Limited<',
                            data: Array(12).fill(0).map(() => Math.floor(Math.random() * 100) + 1),
                            backgroundColor: '#925FFF',
                            borderColor: '#925FFF'
                        },
                        {
                            label: 'Plan & Build Consultants Limited Liability Partnership',
                            data: Array(12).fill(0).map(() => Math.floor(Math.random() * 100) + 1),
                            backgroundColor: '#F6CE81',
                            borderColor: '#F6CE81'
                        },
                        {
                            label: 'The Building Consultant & Technological Service Cooperative Society Limited T 1054',
                            data: Array(12).fill(0).map(() => Math.floor(Math.random() * 100) + 1),
                            backgroundColor: '#FC7878',
                            borderColor: '#FC7878'
                        },
                        {
                            label: 'NH Consulting Private Limited',
                            data: Array(12).fill(0).map(() => Math.floor(Math.random() * 100) + 1),
                            backgroundColor: '#B5EDC8',
                            borderColor: '#B5EDC8'
                        },

                    ]}
                />
            </div>
        </div>
    )
}

export default CompanyCompare