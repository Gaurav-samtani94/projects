import React from 'react'

const TopCompetitorSection = () => {
    const items = [
        {
            no: 1,
            id: 3232,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 31,
            isLocked: false

        },
        {
            no: 2,
            id: 3662,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 35,
            isLocked: false

        },
        {
            no: 3,
            id: 3112,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 41,
            isLocked: true

        },
    ]
    return (
        <>
            <h2 className='mb-4'>Top Competitors</h2>
            {items && items.map((item, index) => (
                <div className="d-flex gap-4 align-items-top competitor_list mb-4">
                    <div className="competitor_number">{item?.no}</div>
                    <div className="w-50 flex-grow-1 d-flex justify-content-between align-items-center">
                        <div>
                            <h5 className='mb-2 glow'>{item?.name}</h5>
                            <div className="text-secondary">Common Bids: {item?.commonBids}</div>
                        </div>
                        {item.isLocked
                            ? <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M4.17647 5.5455V4.09095C4.17647 2.08295 5.05106 0.45459 7 0.45459C8.94894 0.45459 9.82353 2.08295 9.82353 4.09095V5.5455M1 11.2182V7.87277C1 7.05823 1 6.65095 1.15388 6.34041C1.28911 6.06646 1.50509 5.84368 1.77082 5.70404C2.07294 5.54623 2.46824 5.54623 3.25882 5.54623H10.7412C11.5318 5.54623 11.9271 5.54623 12.2292 5.70404C12.4948 5.84349 12.7108 6.066 12.8461 6.33968C13 6.65095 13 7.05823 13 7.87277V11.2182C13 12.0328 13 12.44 12.8461 12.7513C12.7108 13.025 12.4948 13.2475 12.2292 13.387C11.9271 13.5455 11.5318 13.5455 10.7412 13.5455H3.25882C2.46824 13.5455 2.07294 13.5455 1.77082 13.387C1.50519 13.2475 1.28923 13.025 1.15388 12.7513C1 12.4408 1 12.0335 1 11.2182Z" stroke="#FC7878" stroke-width="0.818182" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            : <svg width="14" height="15" viewBox="0 0 14 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M4.17647 5.94118V4.52941C4.17647 2.58047 5.05106 1 7 1C8.47812 1 9.33859 1.90918 9.66824 3.19812M9.82353 8.76471V10.8824M1 11.4471V8.2C1 7.40941 1 7.01412 1.15388 6.71271C1.28911 6.44682 1.50509 6.23059 1.77082 6.09506C2.07294 5.94188 2.46824 5.94188 3.25882 5.94188H10.7412C11.5318 5.94188 11.9271 5.94188 12.2292 6.09506C12.4948 6.23041 12.7108 6.44637 12.8461 6.712C13 7.01412 13 7.40941 13 8.2V11.4471C13 12.2376 13 12.6329 12.8461 12.9351C12.7108 13.2007 12.4948 13.4167 12.2292 13.552C11.9271 13.7059 11.5318 13.7059 10.7412 13.7059H3.25882C2.46824 13.7059 2.07294 13.7059 1.77082 13.552C1.50519 13.4167 1.28923 13.2007 1.15388 12.9351C1 12.6336 1 12.2384 1 11.4471Z" stroke="#1D9E49" stroke-width="1.01647" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        }
                    </div>
                </div>
            ))}
        </>
    )
}

export default TopCompetitorSection