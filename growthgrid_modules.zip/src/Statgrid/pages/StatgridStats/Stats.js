// @ts-nocheck

import React, { useState, useEffect } from 'react'
import '../../../assests/tenderStatCommonCss/stats/stats.css'
import '../../../assests/tenderStatCommonCss/company/companyDetails.css'
import { CompanyService } from 'Services/statgrid/CompanyServices';
import AdvancePiChart from 'Statgrid/components/AdvancePiChart';
import AccessibleLineChart from 'Statgrid/components/AccessibleLineChart';
import Breadcrumb from 'common/components/Breadcrumb/Breadcrumb';
import { useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import PiChart from 'Statgrid/components/PiChart';

const Stats = () => {

    const [show, setShow] = useState(false)
    const textRender = (val) => {
        setShow(val)
        alert(val)
    }
    // --------
    // const { userComp } = useSelector(state => state.userCompany)
    const [errormsg, setErrormsg] = useState('')
    const [statsData, setStatsData] = useState([])
    const objDetiail = new FormData()
    const { userData } = useSelector((state) => state.loginData)
    const nettingData = useSelector((state) => state.nettingData)

    const companyInformation = () => {
        objDetiail.append('user_id', userData?.user_data?.loginid)
        try {
            CompanyService.getUserCompanyDetails(objDetiail).then(res => {
                if (res?.data?.status === 1) {
                    console.log("success")
                } else {
                    setErrormsg(res?.response?.data?.message)
                }

            })
        } catch (error) {
            console.log(error)
        }
    }

    const statsInformation = () => {
        objDetiail.append('user_id', userData?.user_data?.loginid)
        // objDetiail.append('comp_id', userComp?.user_id_compid)
        objDetiail.append('comp_id', 1)
        objDetiail.append('tender_fin_year', nettingData?.financial_year)

        try {
            CompanyService.getStatsDetail(objDetiail).then((res) => {
                if (res?.data?.status === 1) {
                    setStatsData(res?.data?.data)
                } else {
                    // setErrormsg(res?.response?.data?.message)
                    console.log(res?.response?.data?.message)
                }
            })
        } catch (error) {
            console.log(error)
        }
    }

    const location = useLocation()
    const val = location.pathname;
    const str = val.replace('/', '')

    useEffect(() => {
        companyInformation()
        statsInformation()
    }, [])

    var renderTopComp = Object.entries(statsData?.top_comp ? statsData?.top_comp : {}).map(([key, value]) => (
        <div key={key} className="OverviewList">
            <div className='top-competitor-middle'>
                {value[0]}
                <span>Number of bids: {value[1]}</span>
            </div>
            <a onClick={(event) => event.preventDefault()} className="showBtn">Show bids</a>
        </div>
    ))
    return (
        <>
            <Breadcrumb data={str} />
            {/* {userComp?.gst_is_verified == 1
                ? */}
            <section className="stats_wrapper companyDetails_wrapper">
                <div className="conatiner-fluid">
                    <div className="title">Welcome to Stats Grid</div>

                    <div className="row">
                        <div className="col-sm-4">
                            <div className="statCards">
                                <div className="comCard">
                                    <div className='cardFiltHead'>
                                        <h5 className="text-dark">Fresh/Live Tenders</h5>
                                        {/* <a href="javascript:void(0);" className="linkButton"><MoreHorizOutlinedIcon fontSize='inherit' /></a> */}
                                    </div>
                                    <div className="countsNumber">
                                        Tender Count <span>{statsData?.fresh_tenders !== null ? statsData?.fresh_tenders : 0} / {statsData?.live_tenders !== null ? statsData?.live_tenders : 0}</span>
                                        {/* Tender Count <span>{statsData?.fresh_tenders == null ? 0 : statsData?.fresh_tenders + '/' + statsData?.live_tenders}</span> */}
                                    </div>
                                    {/* <a href="" className="linkButton"><RemoveRedEyeOutlinedIcon fontSize='inherit' /> Show</a> */}
                                </div>
                                {/* ./comCard */}
                                <div className="comCard">
                                    <div className='cardFiltHead'>
                                        <h5 className="text-dark">Submitted By Company</h5>
                                        {/* <a href="javascript:void(0);" className="linkButton"><MoreHorizOutlinedIcon fontSize='inherit' /></a> */}
                                    </div>
                                    <div className="countsNumber">
                                        Based on your products <span>{statsData?.submitted_by_comp !== null ? statsData?.submitted_by_comp : 0}</span>
                                    </div>
                                    {/* <a href="" className="linkButton"><RemoveRedEyeOutlinedIcon fontSize='inherit' /> Show</a> */}
                                </div>
                                {/* ./comCard */}
                                <div className="comCard">
                                    <div className='cardFiltHead'>
                                        <h5 className="text-dark">Awaiting Bid</h5>
                                        {/* <a href="javascript:void(0);" className="linkButton"><MoreHorizOutlinedIcon fontSize='inherit' /></a> */}
                                    </div>
                                    <div className="countsNumber">
                                        You vs Others <span>{statsData?.total_bid_await !== null ? statsData?.total_bid_await : 0}</span>
                                    </div>
                                    {/* <a href="" className="linkButton"><RemoveRedEyeOutlinedIcon fontSize='inherit' /> Show</a> */}
                                </div>
                                {/* ./comCard */}
                                <div className="comCard">
                                    <div className='cardFiltHead'>
                                        <h5 className="text-dark">Won Bid</h5>
                                        {/* <a href="javascript:void(0);" className="linkButton"><MoreHorizOutlinedIcon fontSize='inherit' /></a> */}
                                    </div>
                                    <div className="countsNumber">
                                        You vs Others <span>{statsData?.total_bid_won !== null ? statsData?.total_bid_won : 0}</span>

                                    </div>
                                    {/* <a href="" className="linkButton"><RemoveRedEyeOutlinedIcon fontSize='inherit' /> Show</a> */}
                                </div>
                                {/* ./comCard */}
                            </div>
                        </div>
                        <div className="col-sm-8">
                            {/* <div className="card h-100">
                                    <div className="card-title">
                                        <h1>Your Bids (Quarter-wise)</h1>
                                    </div>
                                    <div className="card-body">
                                        <div className="inner_Chart">
                                            <LineChart />
                                        </div>
                                    </div>
                                </div> */}
                            {/* ./card */}

                            <div className="card h-100">
                                <div className="card-title">
                                    <h1>State Bid</h1>
                                </div>
                                <div className="card-body">
                                    <PiChart data={statsData?.state_bid} />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row mt-4">
                        <div className="col-sm-8">
                            <div className="card h-100">
                                <div className="card-title">
                                    <h1>Competitive Performance</h1>
                                </div>
                                <div className="card-body">
                                    <AccessibleLineChart data={statsData?.comp_performance} />
                                </div>
                            </div>
                            {/* ./card */}
                        </div>
                        <div className="col-sm-4">
                            <div className="card h-100">
                                <div className="card-title">
                                    <h1>Top Competitors & their Organization distribution</h1>
                                </div>
                                <div className="card-body">
                                    <div className="Overview-491">
                                        {renderTopComp ? renderTopComp : null}
                                    </div>
                                    {/* ./Overview-491 */}
                                </div>
                            </div>
                            {/* ./card */}
                        </div>
                    </div>
                    {/* ./row */}
                    <div className="row mt-4">
                        <div className="col-sm-5">
                            <div className="card h-100">
                                <div className="card-title">
                                    <h1>Sector Bid</h1>
                                </div>
                                <div className="card-body">
                                    <AdvancePiChart data={statsData?.sector_bid} />
                                </div>
                            </div>
                            {/* ./card */}
                        </div>
                        {/* <div className="col-sm-7">
                                <div className="card h-100">
                                    <div className="card-title">
                                        <h1>State Bid</h1>
                                    </div>
                                    <div className="card-body">
                                        <div className="row">
                                            <div className="col-sm-6">
                                                <PiChart data={statsData?.state_bid} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> */}
                    </div>
                </div>
                {/* ./container */}
            </section>
            {/* :
                <div style={{ height: '500px', display: 'flex', justifyContent: 'center', alignItems: "center" }}>

                    <span className='wrong_msg'>{errormsg ? errormsg : "Register Your GST with us To Know Your Stats"}</span>
                </div>

            } */}


        </>
    )
}

export default Stats;








