// @ts-nocheck
import ROUTES from 'Constants/Routes';
import { statGridAction } from 'Redux/actions/common/authAction';
import { userStatInfoAction } from 'Redux/actions/common/userInfoAction';
import { StatAuthServices } from 'Services/statgrid/statauth/StatLogin';
import { Button, Input, Tooltip } from 'antd'
import React, { useEffect, useRef, useState } from 'react'
import { useDispatch } from 'react-redux';
import { toast } from 'react-toastify';
import { Link, useNavigate } from 'react-router-dom';
import STATROUTES from 'Statgrid/router/statgridRoutes';
import axios from 'axios';

const initialState = {
  email: "",
  password: ""
}

const Login = () => {
  const [data, setData] = useState(initialState)
  const [showPassword, setShowPassword] = useState(false);
  const [loader, setLoader] = useState(false)
  const dispatch = useDispatch()
  const emailInputRef = useRef(null);
  const [message, setMessage] = useState('');
  const navigate = useNavigate()
  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
    handleCheckMsg();
  }
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);


  const handleKeyDown = () => {
    handleCheckMsg();
    // if (e.key === " ") {
    //   e.preventDefault();
    // }
  };
  const handleCheckMsg = () => {
    const emailRegex = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    if (data.email.length === 0) {
      setMessage('');
    } else {
      if (emailRegex?.test(data.email)) {
        setMessage('');
      } else {
        setMessage('Please enter a valid email!');
      }
    }
  }

  useEffect(() => {
    handleCheckMsg()
  }, [data?.email])

  useEffect(() => {
    if (emailInputRef.current) {
      emailInputRef?.current?.focus();
    }
  }, []);

  const checkAuth = () => {
    let authForLogin = localStorage.getItem('statToken');
    if (authForLogin) {
      const currentPath = window.location.pathname;
      if (currentPath === `/${STATROUTES?.PLACEHOLDER}/${STATROUTES?.STAT_LOGIN}`) {
        navigate(`/${STATROUTES?.PLACEHOLDER}/${STATROUTES?.STATDASHBOARD}`, { replace: true })
        // return <Redirect to={STATROUTES.TENDER_GRID} replace />;
        // window.open(`/${STATROUTES.PLACEHOLDER}/${STATROUTES.STATDASHBOARD}`, "_blank")
      }
    }
  };
//   const checkAuth = () => {
//     let authForLogin = localStorage.getItem('statToken');
//     const currentPath = window.location.pathname;
//     console.log(currentPath,"ccccccc");
//     if (!authForLogin && currentPath !== `${STATROUTES?.PLACEHOLDER}/${STATROUTES.STAT_PLANS}`) {
//         navigate(ROUTES.STAT_LOGIN, { replace: true });
//     } else if (authForLogin && currentPath === ROUTES.STAT_LOGIN) {
//         navigate(ROUTES.STATDASHBOARD, { replace: true });
//         // window.location.reload()
//         window.open(ROUTES.STATDASHBOARD, "_blank");
//     }
// };

  useEffect(() => {
    checkAuth();
  })

  const getIP = async () => {
    try {
      const res = await axios?.get("https://api.ipify.org/?format=json");
      // setIP(res.data.ip);
      return res.data.ip;
    } catch (error) {
      console.error("Error fetching IP:", error);
      return null;
    }
  };



  const handleLogin = async (e) => {
    e.preventDefault()
    if (data?.email === "" && data?.password === "") {
      notify('please fill all the fields')
    }
    else if (data.email === '') {
      notify('please fill email')
    } else if (data.password === '') {
      notify('please fill password')
    }
    else {
      setLoader(true)
      const addStatLoginData = new URLSearchParams();
      addStatLoginData.append("email", data?.email)
      addStatLoginData.append("password", data?.password)

      try {
        const res = await StatAuthServices?.StatLogin(addStatLoginData)
        // const resip = await StatAuthServices?.addIpAddress(ipFormData)
        if (res?.data?.status === "1") {
          dispatch(statGridAction(res?.data?.data))
          localStorage.setItem('statToken', res?.data?.token)
          let ipAddressData = await getIP();
          if (ipAddressData) {
            const ipFormData = new URLSearchParams();
            ipFormData.append("ip_address", ipAddressData)
            let addIpAddressResult = await StatAuthServices?.addIpAddress(ipFormData);

          }
          // console.log('ipAddressData======>>',ipAddressData);

          try {
            const response = await StatAuthServices?.getUserDetails();
            if (response?.data?.status === "1") {
              const userStatInfoData = response?.data?.data;
              console.log(userStatInfoData,"userStatInfoData");
              dispatch(userStatInfoAction({
                ...userStatInfoData,
                // Add other properties from userBidInfo as needed
              }));

            }

            navigate(ROUTES?.STATDASHBOARD)
            notifySuccess("Login successfull")  // Static untill messages come from backend correctly.
          }


          catch (error) {
            console.log(error, 'api error');
          }
        }
        else {
          notify("not authorised")  // Static untill messages come from backend correctly.
        }



      } catch (error) {

      }
    }

  }

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleLogin(e);
    }
  };

  return (
    <main className='position-relative'>
      <div className="row w-100 g-0">
        <div className="col-12 col-lg-6 col-xl-7">
          <div className='d-flex align-items-center justify-content-center h-100'>
            <div className='login-content'>
              <img className='mb-5' src={require("../../assets/img/logo-dark.png")} width={220} />
              <h1 className='mb-3'>Login to your account</h1>
              <p className='text-secondary mb-5'>Enter your email and password for login</p>
              <div className='mb-4'>
                <p className='mb-2'>Email</p>
                <Input
                  ref={emailInputRef}
                  placeholder="Enter your username"
                  size='large'
                  name="email"
                  onChange={handleChange} // Use onChange event instead of onInput
                  onKeyDown={handleKeyDown} // Attach handleKeyDown to the onKeyDown event
                  onKeyPress={handleKeyPress}
                  value={data?.email}
                  className='brand-outlined-input w-100 '
                  suffix={
                    <svg width="20" height="19" viewBox="0 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path fill-rule="evenodd" clip-rule="evenodd" d="M0.666504 4.28691V14.9536C0.666504 15.6608 0.947455 16.3391 1.44755 16.8392C1.94765 17.3393 2.62593 17.6202 3.33317 17.6202H16.6665C17.3737 17.6202 18.052 17.3393 18.5521 16.8392C19.0522 16.3391 19.3332 15.6608 19.3332 14.9536V4.28691C19.3332 3.57966 19.0522 2.90138 18.5521 2.40129C18.052 1.90119 17.3737 1.62024 16.6665 1.62024H3.33317C2.62593 1.62024 1.94765 1.90119 1.44755 2.40129C0.947455 2.90138 0.666504 3.57966 0.666504 4.28691Z" stroke="#7E7E7E" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M3.3335 5.62024L10.0002 9.62024L16.6668 5.62024" stroke="#7E7E7E" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                  }
                />
                <div className='message' style={{ color: 'red' }}>
                  {message}
                </div>
              </div>

              <div className='mb-4'>
                <p className='mb-2'>Password</p>
                <Input
                  placeholder="*********"
                  size='large'
                  type='password'
                  name='password'
                  onKeyPress={handleKeyPress}
                  value={data?.password}
                  onInput={handleChange}
                  type={showPassword ? "text" : "password"}
                  className='brand-outlined-input w-100'
                  suffix={
                    <Tooltip title="show password">

                      {showPassword ? (
                        <svg onClick={togglePasswordVisibility} width="22" height="23" viewBox="0 0 22 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M2.57108 12.3284L2.25621 11.6202L2.57108 10.9121C3.29564 9.28162 4.47756 7.89628 5.97361 6.92398C7.46965 5.95168 9.21559 5.43417 10.9998 5.43417C12.7841 5.43417 14.53 5.95168 16.0261 6.92398C17.5221 7.89628 18.704 9.28162 19.4286 10.9121L19.7421 11.6202L19.4272 12.3284C18.7025 13.9585 17.5206 15.3434 16.0247 16.3154C14.5288 17.2874 12.7831 17.8048 10.9991 17.8048C9.21519 17.8048 7.46952 17.2874 5.97363 16.3154C4.47774 15.3434 3.29582 13.9585 2.57108 12.3284ZM0.687334 10.0747L0.329834 10.8791C0.22601 11.1127 0.172363 11.3654 0.172363 11.6209C0.172363 11.8765 0.22601 12.1292 0.329834 12.3627L0.687334 13.1657C1.57419 15.1603 3.02039 16.8548 4.85074 18.0441C6.68109 19.2333 8.81705 19.8663 10.9998 19.8663C13.1826 19.8663 15.3186 19.2333 17.1489 18.0441C18.9793 16.8548 20.4255 15.1603 21.3123 13.1657L21.6698 12.3627C21.7739 12.129 21.8276 11.8761 21.8276 11.6202C21.8276 11.3644 21.7739 11.1115 21.6698 10.8777L21.3123 10.0747C20.4255 8.08024 18.9793 6.38571 17.1489 5.19643C15.3186 4.00716 13.1826 3.37418 10.9998 3.37418C8.81705 3.37418 6.68109 4.00716 4.85074 5.19643C3.02039 6.38571 1.57419 8.08024 0.687334 10.0747ZM13.0623 11.6202C13.0623 12.1673 12.845 12.6919 12.4582 13.0787C12.0714 13.4655 11.5468 13.6827 10.9998 13.6827C10.4528 13.6827 9.92822 13.4655 9.54143 13.0787C9.15463 12.6919 8.93733 12.1673 8.93733 11.6202C8.93733 11.0732 9.15463 10.5486 9.54143 10.1618C9.92822 9.77505 10.4528 9.55775 10.9998 9.55775C11.5468 9.55775 12.0714 9.77505 12.4582 10.1618C12.845 10.5486 13.0623 11.0732 13.0623 11.6202ZM15.1248 11.6202C15.1248 12.7143 14.6902 13.7635 13.9166 14.5371C13.1431 15.3107 12.0939 15.7452 10.9998 15.7452C9.90582 15.7452 8.85661 15.3107 8.08302 14.5371C7.30943 13.7635 6.87483 12.7143 6.87483 11.6202C6.87483 10.5262 7.30943 9.47702 8.08302 8.70343C8.85661 7.92985 9.90582 7.49525 10.9998 7.49525C12.0939 7.49525 13.1431 7.92985 13.9166 8.70343C14.6902 9.47702 15.1248 10.5262 15.1248 11.6202Z" fill="#7E7E7E" />
                        </svg>
                      ) : (
                        <svg onClick={togglePasswordVisibility} width="22" height="23" viewBox="0 0 22 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M2.57108 12.3284L2.25621 11.6202L2.57108 10.9121C3.29564 9.28162 4.47756 7.89628 5.97361 6.92398C7.46965 5.95168 9.21559 5.43417 10.9998 5.43417C12.7841 5.43417 14.53 5.95168 16.0261 6.92398C17.5221 7.89628 18.704 9.28162 19.4286 10.9121L19.7421 11.6202L19.4272 12.3284C18.7025 13.9585 17.5206 15.3434 16.0247 16.3154C14.5288 17.2874 12.7831 17.8048 10.9991 17.8048C9.21519 17.8048 7.46952 17.2874 5.97363 16.3154C4.47774 15.3434 3.29582 13.9585 2.57108 12.3284ZM0.687334 10.0747L0.329834 10.8791C0.22601 11.1127 0.172363 11.3654 0.172363 11.6209C0.172363 11.8765 0.22601 12.1292 0.329834 12.3627L0.687334 13.1657C1.57419 15.1603 3.02039 16.8548 4.85074 18.0441C6.68109 19.2333 8.81705 19.8663 10.9998 19.8663C13.1826 19.8663 15.3186 19.2333 17.1489 18.0441C18.9793 16.8548 20.4255 15.1603 21.3123 13.1657L21.6698 12.3627C21.7739 12.129 21.8276 11.8761 21.8276 11.6202C21.8276 11.3644 21.7739 11.1115 21.6698 10.8777L21.3123 10.0747C20.4255 8.08024 18.9793 6.38571 17.1489 5.19643C15.3186 4.00716 13.1826 3.37418 10.9998 3.37418C8.81705 3.37418 6.68109 4.00716 4.85074 5.19643C3.02039 6.38571 1.57419 8.08024 0.687334 10.0747ZM13.0623 11.6202C13.0623 12.1673 12.845 12.6919 12.4582 13.0787C12.0714 13.4655 11.5468 13.6827 10.9998 13.6827C10.4528 13.6827 9.92822 13.4655 9.54143 13.0787C9.15463 12.6919 8.93733 12.1673 8.93733 11.6202C8.93733 11.0732 9.15463 10.5486 9.54143 10.1618C9.92822 9.77505 10.4528 9.55775 10.9998 9.55775C11.5468 9.55775 12.0714 9.77505 12.4582 10.1618C12.845 10.5486 13.0623 11.0732 13.0623 11.6202ZM15.1248 11.6202C15.1248 12.7143 14.6902 13.7635 13.9166 14.5371C13.1431 15.3107 12.0939 15.7452 10.9998 15.7452C9.90582 15.7452 8.85661 15.3107 8.08302 14.5371C7.30943 13.7635 6.87483 12.7143 6.87483 11.6202C6.87483 10.5262 7.30943 9.47702 8.08302 8.70343C8.85661 7.92985 9.90582 7.49525 10.9998 7.49525C12.0939 7.49525 13.1431 7.92985 13.9166 8.70343C14.6902 9.47702 15.1248 10.5262 15.1248 11.6202Z" fill="#7E7E7E" />
                        </svg>
                      )}


                    </Tooltip>
                  }
                />
              </div>
              <div className='d-flex justify-content-end mb-5' >
                <Link to={`/${STATROUTES.PLACEHOLDER}/${STATROUTES?.STAT_FORGOT_PASSWORD}`} className='brand-link'>Forgot Password</Link>
              </div>

              <Button type='primary' size='large' className='brand-solid-btn w-100 mb-5' shape='round' onClick={handleLogin}>Login</Button>
              <p className='t-c-t mt-5 text-center'>Our <Link to="/statgrid/terms-and-conditions">Terms and Conditions</Link> and <Link  to="/statgrid/privacy-policy">Privacy Policies</Link> </p>
            </div>
          </div>
        </div>
        <div className="col-12 col-lg-6 col-xl-5">
          <img src={require("../../assets/img/login-bg.png")} className='w-100 loginBanner' />
        </div>
      </div>
    </main>
  )
}

export default Login