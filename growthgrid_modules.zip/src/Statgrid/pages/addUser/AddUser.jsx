import React from 'react';
import { Form, Input, Button, Row, Col } from 'antd';
import { userByAdminService } from 'Services/statgrid/userByAdmin/userByAdmin';
import { EyeOutlined, EyeInvisibleOutlined } from '@ant-design/icons';
import { toast } from 'react-toastify';

const AddUser = () => {
    const [form] = Form.useForm();
    const notify = (err) => toast.error(err);
    const notifySuccess = (msg) => toast.success(msg);

    const handleUserSubmit = async (values) => {
        try {
            const formData = new URLSearchParams();
            formData.append('userfullname', values?.userfullname);
            formData.append('email', values?.email);
            formData.append('contactnumber', values?.contactnumber);
            formData.append('password', values?.password);

            let result = await userByAdminService.userAddByAdmin(formData);

            if (result?.data?.status === '1') {
                form.resetFields();
                notifySuccess('User added successfully');   // Static untill messages come from backend correctly.
            }
            else{
                notify('Something went wrong, Please try again.')   // Static untill messages come from backend correctly.
            }
        }
        catch (error) {
            console.log('in error==>>', error);
        }

    };

    return (
        <div className="container-fluid">
            <h3>Add User</h3>
            <div className="container mt-4">
                <Form
                    form={form}
                    name="addUserForm"
                    onFinish={handleUserSubmit}
                    labelCol={{ span: 24 }}
                    wrapperCol={{ span: 24 }}
                >
                    <Row gutter={[16, 16]}>
                        <Col xs={24} lg={12}>
                            <Form.Item
                                label="User name"
                                name="userfullname"
                                rules={[{ required: true, message: 'Please enter the name!' }]}
                            >
                                <Input size="large" placeholder="Enter user name" />
                            </Form.Item>
                        </Col>
                        <Col xs={24} lg={12}>
                            <Form.Item
                                label="Email"
                                name="email"
                                rules={[{ required: true, message: 'Please enter email!', type: 'email' }]}
                            >
                                <Input size="large" placeholder="Enter Email" />
                            </Form.Item>
                        </Col>
                        <Col xs={24} lg={12}>
                            <Form.Item
                                label="Phone"
                                name="contactnumber"
                                rules={[{ required: true, message: 'Please enter phone number!' },
                                { pattern: /^[0-9]+$/, message: 'Please enter a valid number' },
                                ]}

                            >
                                <Input size="large" placeholder="Enter Phone" type='number' />
                            </Form.Item>
                        </Col>
                        <Col xs={24} lg={12}>
                            <Form.Item
                                label="Password"
                                name="password"
                                rules={[{ required: true, message: 'Please enter password!' }]}
                            >
                                <Input.Password
                                    size="large"
                                    placeholder="Enter password"
                                    iconRender={(visible) => (visible ? <EyeOutlined /> : <EyeInvisibleOutlined />)}
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                    <Row justify="end" gutter={[16, 16]}>
                        <Col>
                            <Button htmlType="reset" className='brand-outlined-btn'>Reset</Button>
                        </Col>
                        <Col>
                            <Button type="primary" htmlType="submit" className='brand-outlined-btn'>Submit</Button>
                        </Col>
                    </Row>
                </Form>
            </div>
        </div>
    );
};

export default AddUser;
