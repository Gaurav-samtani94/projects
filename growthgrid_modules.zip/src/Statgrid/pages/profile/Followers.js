import { SearchSvg } from 'Statgrid/utils/Svgs'
import { Input, Pagination } from 'antd'
import React from 'react'
import { Link } from 'react-router-dom'

const Followers = ({ title }) => {

    const items = [
        {
            no: 1,
            id: 3232,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 31,
            isLocked: false

        },
        {
            no: 2,
            id: 3662,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 35,
            isLocked: false

        },
        {
            no: 3,
            id: 3112,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 41,
            isLocked: true

        },
        {
            no: 1,
            id: 3232,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 31,
            isLocked: false

        },
        {
            no: 2,
            id: 3662,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 35,
            isLocked: false

        },
        {
            no: 3,
            id: 3112,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 41,
            isLocked: true

        },
        {
            no: 1,
            id: 3232,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 31,
            isLocked: false

        },
        {
            no: 2,
            id: 3662,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 35,
            isLocked: false

        },
        {
            no: 3,
            id: 3112,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 41,
            isLocked: true

        },
        {
            no: 1,
            id: 3232,
            name: "L N Malviya Infra Projects Private Limited",
            commonBids: 31,
            isLocked: false

        },
    ]
    return (
        <section className='py-4'>
            <div className='d-flex gap-3 justify-content-between align-items-center mb-4 '>
                <h3>{title}</h3>
                <Input
                    placeholder={`Search for ${title}...`}
                    prefix={<SearchSvg color='#7E7E7E' w={20} h={20} />}
                    className="g-search-input py-2 w-fit rounded-pill d-none d-lg-flex"
                />
            </div>
            <div className="d-flex gap-4 flex-column">
                {items && items.map((item, index) => (
                    <div className="d-flex gap-4 align-items-top competitor_list mb-4">
                        <div className="w-50 flex-grow-1 d-flex justify-content-between align-items-center">
                            <div>
                                <h5 className='mb-2 glow'><Link to="/" className='brand-link'>{item?.name}</Link></h5>
                                <div className="text-secondary">Common Bids: {item?.commonBids}</div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            <Pagination defaultCurrent={6} total={500} className='d-flex justify-content-end mt-4' />
        </section>
    )
}

export default Followers