// @ts-nocheck
import React, { useState } from 'react'
import { Button, Input, Select, Form } from 'antd'
import { useSelector } from 'react-redux'

const EditProfile = () => {
    const [isEditable, setIsEditable] = useState(false)
    const { userStatInfo } = useSelector((state) => state.userDetails)
    console.log(userStatInfo, "userBidInfo");
    return (
        <div className='bg-white my-4'>

            <Form
                layout='vertical'
            >
                <div className="d-flex gap-3 justify-content-between mb-4">
                    <h4 className='mb-0'>Profile</h4>
                    <div className="d-flex gap-3">
                        {isEditable
                            ? <>
                                <Button type='link' danger >Reset</Button>
                                <Button type='default' className='brand-outlined-btn' onClick={() => setIsEditable(false)}>Save</Button>
                            </>
                            : <Button type='default' onClick={() => setIsEditable(true)} className='brand-outlined-btn'>Edit</Button>
                        }

                    </div>
                </div>
                <div
                    className="row g-4"
                >
                    <div className="col-12 col-lg-6">
                        <Form.Item
                            label="Name"
                            name="name"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your Name!',
                                },
                            ]}

                        >

                            <Input className='brand-outlined-input' size="large" defaultValue={userStatInfo?.username} placeholder="Enter Name" disabled={!isEditable} />
                        </Form.Item>
                    </div>
                    <div className="col-12 col-lg-6">
                        <Form.Item
                            label="Location"
                            name="location"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your location!',
                                },
                            ]}

                        >

                            <Input className='brand-outlined-input' size="large" defaultValue={"742 Cedar Ridge Road Littleton, CO 80127"} placeholder="Enter Location" disabled={!isEditable} />
                        </Form.Item>
                    </div>
                    <div className="col-12 col-lg-6">
                        <Form.Item
                            label="Email"
                            name="Email"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your Email!',
                                },
                            ]}

                        >

                            <Input className='brand-outlined-input' size="large" defaultValue={userStatInfo?.email} placeholder="Enter Email" disabled={!isEditable} />
                        </Form.Item>
                    </div>
                    <div className="col-12 col-lg-6">
                        <Form.Item
                            label="Mobile No."
                            name="phone"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your Phone No.!',
                                },
                            ]}

                        >

                            <Input className='brand-outlined-input' size="large" defaultValue={'8987383739434'} placeholder="Enter Mobile No." disabled={!isEditable} />
                        </Form.Item>
                    </div>
                    <div className="col-12 col-lg-4">
                        <Form.Item
                            label="Country"
                            name="country"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input your Email!',
                                },
                            ]}>
                            <Select
                                showSearch
                                size='large'
                                className='brand-outlined-select w-100'
                                placeholder="Select Country"
                                optionFilterProp="children"
                                defaultValue={userStatInfo?.country_name}
                                // mode="multiple"
                                disabled={!isEditable}
                                value="2"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                filterSort={(optionA, optionB) =>
                                    (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                }
                                options={[
                                    {
                                        value: '1',
                                        label: 'Not Identified',
                                    },
                                    {
                                        value: '2',
                                        label: 'India',
                                    }
                                ]}
                            />
                        </Form.Item>
                    </div>
                    <div className="col-12 col-lg-4">
                        <Form.Item
                            label="Sector"
                            name="sector"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please Select at least one Sector!',
                                },
                            ]}>
                            <Select
                                showSearch
                                size='large'
                                className='brand-outlined-select w-100'
                                placeholder="Select Sector"
                                optionFilterProp="children"
                                // defaultValue={userStatInfo?.country_name}
                                mode="multiple"
                                disabled={!isEditable}
                                // value="2"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                filterSort={(optionA, optionB) =>
                                    (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                }
                                options={[
                                    {
                                        value: '1',
                                        label: 'example 1',
                                    },
                                    {
                                        value: '2',
                                        label: 'example 2',
                                    },
                                    {
                                        value: '3',
                                        label: 'example 3',
                                    },
                                    {
                                        value: '4',
                                        label: 'example 4',
                                    },
                                    {
                                        value: '5',
                                        label: 'example 5',
                                    }
                                ]}
                            />
                        </Form.Item>
                    </div>
                    <div className="col-12 col-lg-4">
                        <Form.Item
                            label="States"
                            name="states"
                            rules={[
                                {
                                    required: true,
                                    message: 'Please Select at least one State!',
                                },
                            ]}>
                            <Select
                                showSearch
                                size='large'
                                className='brand-outlined-select w-100'
                                placeholder="Select State"
                                optionFilterProp="children"
                                // defaultValue={userStatInfo?.country_name}
                                mode="multiple"
                                disabled={!isEditable}
                                // value="2"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                filterSort={(optionA, optionB) =>
                                    (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                }
                                options={[
                                    {
                                        value: '1',
                                        label: 'example 1',
                                    },
                                    {
                                        value: '2',
                                        label: 'example 2',
                                    },
                                    {
                                        value: '3',
                                        label: 'example 3',
                                    },
                                    {
                                        value: '4',
                                        label: 'example 4',
                                    },
                                    {
                                        value: '5',
                                        label: 'example 5',
                                    }
                                ]}
                            />
                        </Form.Item>
                    </div>
                    <div className="col-12">
                        <Form.Item
                            label="Bio"
                            name="description"
                            rules={[
                                {
                                    required: true,
                                    message: "Bio can't be empty!",
                                },
                            ]}>
                            <Input.TextArea className='brand-outlined-input' size='large' disabled={!isEditable} rows={4} placeholder="Bio" maxLength={6} />
                        </Form.Item>
                    </div>
                </div>
            </Form>
        </div>
    )
}

export default EditProfile