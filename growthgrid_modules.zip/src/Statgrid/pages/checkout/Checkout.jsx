// @ts-nocheck
import { ChevronLeft } from '@mui/icons-material'
import React, { useEffect, useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import '../../assets/styles/checkout.scss';
import { Button, Divider, Input } from 'antd';
import { PlanListApi } from 'Services/statgrid/PlanList/PlanListApi';
import { Log } from '@icon-park/react';
import dayjs from "dayjs";
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
const Checkout = () => {
  const navigation = useNavigate()
  const [coupon, setCoupon] = useState([])
  const [checkCoupon, setCheckCoupon] = useState([])
  const [subscData, setSubscData] = useState([])
  const { statSubPlan, type } = useSelector(state => state?.statCheckoutData)
  const [amount, setAmount] = useState(null)
  const [couponId, setCouponId] = useState(null)
  const [amountCoupn, setAmountCoupn] = useState([null])
  const location = useLocation();
  const val = location.state?.val;
  const couponVal = coupon?.find((val) => val?.coupon_id == couponId)
  const notifySuccess = (msg) => toast.success(msg);
  const notify = (error) => toast.error(error);
  const [appliedCoupon, setAppliedCoupon] = useState(null);

  const getCouponData = async () => {
    if (localStorage?.getItem("statToken") !== "") {
      try {
        const res = await PlanListApi?.getCouponList()
        if (res?.data?.status === "1") {
          setCoupon(res?.data?.data)
        } else {
          setCoupon([])
        }

      } catch (error) {

      }
    }
  }

  const subscriptionDetailApi = async () => {
    try {
      const response = await PlanListApi?.getSubsDetails()
      setSubscData(response?.data?.data)
    } catch {
      console.log("error")
    }

  }

  // const handleCouponCheck = async (e) => {
  //   const couponCode = new URLSearchParams()
  //   console.log(checkCoupon, "checkCoupon");
  //   couponCode.append('coupon_code', checkCoupon)
  //   const enteredCouponCode = e.target.value;
  //   if (enteredCouponCode !== '') {
  //     try {
  //       const res = await PlanListApi?.StatCouponCheck(couponCode)
  //       if (res?.data?.status === "1") {
  //         // if(res?.data?.data)
  //         console?.log("bbkbjk")
  //       }
  //     } catch (error) {

  //     }
  //   }


  // }


  const handleCouponCheck = async (couponItem , couponCode) => {
    setCouponId(couponItem?.coupon_id);
    
    if (couponCode !== "") {
      try {
        const couponData = new URLSearchParams();
        couponData.append('coupon_code', couponCode);
        const res = await PlanListApi?.StatCouponCheck(couponData);
        if (res?.data?.status === "1") {
         notifySuccess("Coupon Applied.");
         setAppliedCoupon(couponItem.coupon_id)

        } else {
          notify("Coupon is not valid.");

        }
      } catch (error) {
        console.error("Error while checking coupon:", error);
      
      }
    } else {
      console.log("Please enter a coupon code.");
      
    }
  };

  const isCouponApplied = (couponId) => {
    return couponId === appliedCoupon;
  };

  useEffect(() => {
    if (type === 'plan') {
      let newAmount = statSubPlan?.plan_rate
      setAmount(newAmount)
    } else {
      setAmount(null)
    }

  }, [type, statSubPlan])
  useEffect(() => {
    getCouponData()
    subscriptionDetailApi()
  }, [])


  const calculateGst = () => {
    let percentageAmt = 0;
    if (couponVal?.coupon_type !== 1 ) {
      percentageAmt = (18 / 100) * amount
  
    } else {
      let discountedGst = amount - ((couponVal?.discount_amount / 100) * amount)
      percentageAmt = (18 / 100) * discountedGst

    }
    return parseFloat(percentageAmt.toFixed(2))
  }

  
  const getTotalAmount = () => {
    let total = 0

    if (couponVal?.coupon_type === 1) {
      if (calDiscountedval(couponVal?.discount_amount) > parseInt(amount)) {
        total = (calDiscountedval(couponVal?.discount_amount) - parseInt(amount)) + calculateGst()
        //  setAmount(calDiscountedval(coupon?.discount_amount) - parseInt(amount))

      } else {
      
        total = (parseInt(amount) - calDiscountedval(couponVal?.discount_amount)) + calculateGst()
      }
    } else {
      // setAmountCoupn(Number(amount))
      total = calculateGst() + Number(amount)
    }
    return total.toFixed(2)
  }

  const calDiscountedval = (val) => {
    let discountAmt = (val / 100) * amount
    return parseFloat(discountAmt)
  }

  const handleChange = (e) => {

    let inputValue = e?.target?.value;
    inputValue = inputValue?.replace(/\s/g, "")?.toUpperCase();
    inputValue = inputValue?.replace(/[^0-9]/g, "");
    if (inputValue?.startsWith('0')) {
      inputValue = inputValue?.substring(1);
    }

    inputValue = inputValue?.slice(0, 10);
    if (/^[0-9]{1,10}$/.test(inputValue) || inputValue === '') {

      setAmount(inputValue);
    } else {
      console.log("Please enter a valid 10-digit number.");
    }
  };



  const blockInvalidChar = e => {
    ['e', 'E', '+', '-', '.'].includes(e?.key) && e?.preventDefault()
    if (e?.key === 'Enter') {
      e.preventDefault();
      handleChange();
    }
  };

  return (
    <main>
      <div className='p-4'>
        <div onClick={() => navigation(-1)} className='d-flex gap-1 align-items-center cursor-pointer'>
          <ChevronLeft sx={{ width: "42px", height: "42px" }} />
          <h4 className='fw-normal'>Back</h4>
        </div>
      </div>
      <div className="container my-4">
        <div className="row">
          <div className="col-md-6">
            <div className="coupon-col">
              <h3 className='fw-normal mb-3'>Coupon</h3>
              {/* <Input
                placeholder='Type Coupon Name'
                className='brand-input mb-4'
                size='large'
                onChange={(e) => setCheckCoupon(e?.target?.value)}
                name='coupon'
                suffix={
                  <Button size='small' type='primary' className='brand-solid-btn' onClick={handleCouponCheck}>
                    Apply
                  </Button>
                }
              /> */}
              <div className="d-flex gap-4 flex-column">
                {coupon?.length > 0 ?
                  coupon?.map((item, index) => {
                    return (
                      <div className="coupon-card" key={index}>
                        <div className="coupon-main">
                          <div className="co-img d-flex flex-column align-items-center">
                            <img src={require('../../assets/img/logo-small.png')} alt="" className='mb-2' />
                            <h3 className='codename fw-normal'>{item?.coupon_code}</h3>
                          </div>
                          <div className="vertical"></div>
                          <div className="content">
                            <h1>
                              {item?.coupon_type == '1' ? item?.discount_amount + "%" : item?.coupon_type == '2' ? item?.duration_days + " Days Increase " : item?.limit_extended + " Unlock Limit"}
                              <br />
                              <span>
                                {item?.coupon_type == '1' ? ' Flat Off' : item?.coupon_type == '2' ? "Duration" : 'Limit Increase'}

                              </span>
                            </h1>
                            <p className='mb-3'>Valid till {dayjs(item?.to_date).format("DD MMM YYYY")}</p>
                            <Button
                              size='small'
                              type='primary'
                              className='brand-solid-btn'

                              value={item?.coupon_code}
                              onClick={() => handleCouponCheck(item, item?.coupon_code)}
                            >
                            {isCouponApplied(item.coupon_id) ? "Applied" : "Apply"}
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })
                  :
                  <span style={{ color: 'gray' }}>No coupons available at the time</span>
                }
              </div>

            </div>
          </div>
          <div className="col-md-6">
            <div className="amount-card">
              <div className="d-flex justify-content-end mb-2">
                <div>
                  <h4 className="fw-normal text-end">3232.32</h4>
                  <p className='text-secondary text-end'>Availabe Points</p>
                </div>
              </div>
              <h3 className='fw-normal mb-3'>Enter Amount</h3>
              <Input
                placeholder='Enter Amount'
                className='brand-input '
                size='large'
                disabled={type === 'plan'}
                type="number"
                onChange={handleChange}
                onKeyDown={blockInvalidChar}
                value={amount}
              />
              <Divider className='my-4' />

              <div className="d-flex justify-content-between align-items-center mb-2">
                <p>Amount</p>
                <p>₹ {amount || 0}</p>
                {/* <p>₹ {couponVal?.coupon_type === 1 ? getTotalAmount() : amount || 0}</p> */}
                           </div>
                           {couponVal?.coupon_type === 1 && (
                  <div className="d-flex justify-content-between align-items-center mb-3">
                    <p>Coupon Applied Discount</p>
                    <p>₹ {calDiscountedval(couponVal?.discount_amount) - parseInt(amount)}</p>
                  </div>
                )}   
              <div className="d-flex justify-content-between align-items-center mb-2">
                <p>CGST @9%</p>
                <p><span>	₹ {calculateGst() / 2} </span></p>
              </div>
              <div className="d-flex justify-content-between align-items-center mb-4">
                <p>SGST @9%</p>
                <p><span>	₹ {calculateGst() / 2} </span></p>
              </div>
              <div className="d-flex justify-content-between align-items-center">
                <h4 className='fw-normal'>Total</h4>
                <p>₹ {getTotalAmount()}</p>
              </div>
              <Divider className='my-4' />
              <h4 className='fw-normal mb-2'>Disclaimer</h4>
              <p className='text-secondary mb-1'>Your accumulated points will expire in 365 days</p>
              <p className='text-secondary'>1 point = 1 Rupee</p>
              <Divider className='my-4' />
              <Button className='brand-outlined-btn w-100' size='large'>
                Add Points
              </Button>
            </div>
          </div>
        </div>
      </div>
    </main>

  )
}

export default Checkout