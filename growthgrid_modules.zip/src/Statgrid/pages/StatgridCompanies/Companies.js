// @ts-nocheck
import React, { useState, useRef, useEffect } from 'react'
import { useLocation } from 'react-router-dom';
import { Backdrop, Tooltip } from '@mui/material';
import SearchIcon from "@mui/icons-material/Search";
import LockOpenOutlinedIcon from "@mui/icons-material/LockOpenOutlined";
import LockOpenIcon from '@mui/icons-material/LockOpen';
import ClearIcon from '@mui/icons-material/Clear';
import Skeleton from 'react-loading-skeleton'
import dayjs from 'dayjs';
import "react-loading-skeleton/dist/skeleton.css";
import '../../../assests/tenderStatCommonCss/company/companyList.css'
import { useDraggable } from "react-use-draggable-scroll";
import useFilters from 'customHook/useFilters';
import Breadcrumb from 'common/components/Breadcrumb/Breadcrumb';
import CompanyFilter from 'Tendergrids/components/Filters/CompanyFilter';
import CompanyStatGrid from 'Statgrid/components/CompanyStatGrid';
import { FilterServices } from 'Services/common/filters/FilterServices';

const Companies = () => {
    const [tenderKeyword, setTenderKeyword] = useState('')
    const [open, setOpen] = React.useState(false);
    const [skeleton, setSkeleton] = useState(false)
    const { filters, setFilterApi, chips } = useFilters('companies')

    const location = useLocation()
    const val = location.pathname;
    const str = val.replace('/', '')

    useEffect(() => {
        window.scrollTo(0, 0);
    }, []);

    const handleFilterChange = (e) => {
        setTenderKeyword(e.target.value)
        if (e.key === 'Enter') {
            e.preventDefault();
            searchClick()
        }
    };

    const searchClick = () => {
        const obj = {
            ...filters,
            tender_keyword: tenderKeyword,
            page_number: 0,
            limit: 50
        }
        setFilterApi(obj)
    }

    const handleDrawerOpen = () => {
        setOpen(true);
        handleToggle()
    };
    const handleDrawerClose = () => {
        setOpen(false);
    };
    const handleToggle = () => {
        setOpen(!open);
    }

    const deleteChipsFilter = (e, id, keyword) => {
        e.preventDefault()
        const formdata = new FormData()
        if (keyword === 'country_id') {
            let state_chip_id = chips?.find(val => val.filter_keyword === 'state_id')
            formdata.append('filter_chip_id', `${id.toString()}, ${state_chip_id.fld_id.toString()}`)
        } else {
            formdata.append('filter_chip_id', id)
        }
        try {
            FilterServices.deleteTenderFilter(formdata).then(res => {
                if (res?.data?.status === 1) {
                    if (keyword === 'country_id') {
                        const obj = {
                            ...filters,
                            [keyword]: "",
                            state_id: '',
                        }
                        setFilterApi(obj)
                    } else {
                        const obj = {
                            ...filters,
                            [keyword]: "",
                        }
                        setFilterApi(obj)
                    }
                }
            })
        } catch (error) {
            console.log(error)
        }
    }
    const resetEachValue = () => {
        setTenderKeyword('')
        const obj = {
            page_number: 0,
            lock_unlock: 0,
            limit: 50,
            state_id: "",
            tender_keyword: "",
            country_id: "",
            funding_agency_id: "",
            financial_year: '',
            estm_value: "",
            amnt_custrange_operator: "",
            amnt_custrange_amount: "",
            custrange_denomination: "",
            no_bid: "",
        }
        setFilterApi(obj)
    }

    const showAllCompany = () => {
        const obj = {
            ...filters,
            lock_unlock: 0,
            page_number: 0,
            limit: 50
        }
        setFilterApi(obj)
    }
    const showUnlockedCompany = () => {
        const obj = {
            ...filters,
            lock_unlock: 1,
            page_number: 0,
            limit: 50
        }
        setFilterApi(obj)
    }


    useEffect(() => {
        setSkeleton(true)
        const timer = setTimeout(() => setSkeleton(false), 1000);
        return () => {
            clearTimeout(timer)
        }
    }, [filters])

    const ref = useRef();
    const { events } = useDraggable(ref);

    return (
        <>
            <Breadcrumb data={str} />
            <section className="companyList_wrapper">
                <div className="company_sidebar_cont">
                    <div className="flexGrid" style={{ display: 'block' }}>
                        <div className="section-title">
                            <h1>
                                Companies <span className="one-text">List</span>
                            </h1>
                        </div>
                        <main>
                            <div className="serachWrapper">

                                <div className="inner_flex">

                                    <div className="d-flex">
                                        <input type="text" onChange={handleFilterChange} name='tender_keyword' value={tenderKeyword} placeholder="Enter Keyword" />
                                        <div className="search_icon" onClick={searchClick}><button className='mainButton whiteButton'><SearchIcon /></button></div>

                                    </div>
                                    <div>
                                        <button className="mainButton ghostButton" type="button" onClick={handleDrawerOpen}>Advance Search</button>
                                    </div>
                                    <div className="buttonGrp">
                                        <button onClick={resetEachValue} className="mainButton whiteButton" type="button">Reset</button>
                                    </div>
                                </div>
                                {/* ./inner_flex */}
                                <div className="tagsContainer">
                                    <div className="search_tags" {...events} ref={ref}>
                                        {chips?.filter(val =>
                                            val.filter_val !== ''
                                            && val.filter_keyword !== 'tender_status'
                                            && val.filter_keyword !== 'no_bid'
                                            && val.filter_keyword !== 'tender_keyword'
                                            && val.filter_keyword !== 'page_number'
                                            && val.filter_keyword !== 'limit'
                                            && val.filter_keyword !== 'lock_unlock'
                                            && val.filter_keyword !== 'wishlist_category_id'
                                        ).map((item, index) => {
                                            let filter_latest_val;
                                            if (item?.filter_keyword === 'from_date' || item?.filter_keyword === "pubdate_cust_from_date" || item?.filter_keyword === "expdate_cust_from_date") {
                                                ;
                                                filter_latest_val = dayjs(item.filter_text).format("DD MMM YYYY");
                                            } else if (item.filter_keyword === 'to_date' || item.filter_keyword === "pubdate_cust_to_date" || item.filter_keyword === "expdate_cust_to_date") {
                                                filter_latest_val = dayjs(item.filter_text).format("DD MMM YYYY");
                                            } else {
                                                filter_latest_val = item?.filter_text;
                                            }
                                            console.log(item?.fld_id, "item?.fld_id...", item.filter_keyword, "item.filter_keyword")
                                            return (
                                                <>
                                                    {!skeleton ?
                                                        <Tooltip className="subHiding" title={item?.filter_keyword} placement="bottom">
                                                            <div className="tagItem" key={index}>
                                                                <div className="flexBox">
                                                                    <div className="tTex">{filter_latest_val}</div>
                                                                    <ClearIcon onClick={(e) => deleteChipsFilter(e, item?.fld_id, item.filter_keyword)} />
                                                                </div>
                                                            </div>
                                                        </Tooltip>
                                                        :
                                                        <>
                                                            <Skeleton width={160} height={32} />
                                                        </>
                                                    }
                                                </>

                                            )
                                        })}
                                    </div>
                                </div>
                            </div>
                            {/* ./serachWrapper */}
                            <div className="listActionButtons">
                                <div className="sortBy">
                                    {/* <label style={{color: "#474747"}}>Showing 1 to 20 of 729 Results</label> */}
                                </div>
                                <div className="grpGroupButton">

                                    {filters?.lock_unlock === 0 ?
                                        <div className="mainButton ghostButton" onClick={showUnlockedCompany}>
                                            <LockOpenIcon fontSize="inherit" /> Show Unlocked
                                            Companies
                                        </div>
                                        :
                                        <div className="mainButton ghostButton" onClick={showAllCompany}>
                                            <LockOpenOutlinedIcon fontSize="inherit" /> Show All
                                            Companies
                                        </div>
                                    }

                                </div>
                            </div>
                            {/* ./listActionButtons */}

                            <CompanyStatGrid setFilterApi={setFilterApi} filters={filters} />
                        </main>

                    </div>
                </div>
                {/* ./container */}
            </section>

            <Backdrop
                sx={{ color: '#fff', zIndex: '1000' }}
                open={open}
                onClick={handleDrawerClose}
            >
            </Backdrop>

            {/* <BasicFilter open={open} getAdvanceFilterValues={getAdvanceFilterValues} advanceFilterObj={advanceFilterObj} handleDrawerOpen={handleDrawerOpen} handleDrawerClose={handleDrawerClose} resetEachValue={resetEachValue} /> */}
            <CompanyFilter open={open} handleDrawerClose={handleDrawerClose} handleDrawerOpen={handleDrawerOpen} setFilterApi={setFilterApi} filters={filters} />
        </>
    )
}

export default Companies
