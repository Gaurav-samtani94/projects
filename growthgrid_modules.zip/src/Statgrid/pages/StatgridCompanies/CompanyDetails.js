// @ts-nocheck

import React, { useEffect, useState } from 'react'
import '../../../assests/tenderStatCommonCss/company/companyList.css'
import '../../../assests/tenderStatCommonCss/company/companyDetails.css'
import CompanyName from 'Statgrid/components/CompanyName';
import RefineSearch from 'Statgrid/components/RefineSearch';
import { useLocation } from 'react-router-dom';
import { CompanyService } from 'Services/statgrid/CompanyServices';
import { useSelector } from 'react-redux';
import Breadcrumb from 'common/components/Breadcrumb/Breadcrumb';
import { useParams } from 'react-router-dom';
const CompanyDetails = () => {
   const [activeState, setActiveState] = useState(1)
   const [data, setData] = useState({})
   const { userData } = useSelector((state) => state.loginData)
   const location = useLocation()
   const handleTab = (tab) => {
      setActiveState(tab)
   }
   console.log('company details')

   const val = location.pathname;
   const str = val.replace('/', '')
   const { id } = useParams();

   const getCompanyDetails = () => {
      const formdata = new FormData()
      formdata.append('user_id', userData?.user_data?.loginid)
      formdata.append('company_id', id)
      formdata.append('fin_year', '2023-2024')
      CompanyService.getCompanyDetail(formdata).then(res => {
         setData(res?.data?.data)
      })
   }
   useEffect(() => {
      getCompanyDetails()
   }, [])
   useEffect(() => {
      window.scrollTo(0, 0);
   }, []);
   return (
      <>
         <Breadcrumb data={str} />
         <section className="companyList_wrapper companyDetails_wrapper company-details-tab">
            <div className='container-fluid'>
               <div className="heading_flex">
                  <h1 className="headTitle">{data?.company_name}</h1>
                  {/* <button className="mainButton ghostButton"><i className="fas fa-hand-point-right"></i> Follow</button> */}
               </div>
               <div className="features-tab">
                  <div className="nav nav-tabs nav-justified" id="nav-tab" role="tablist">
                     <a onClick={() => setActiveState(1)} className={`nav-item nav-link ${activeState === 1 && "active"}`} id="tab-1-tab" data-bs-toggle="pill" href="#tab-1" role="tab" aria-controls="tab-1" aria-selected="true">Company Details</a>
                     <a onClick={() => setActiveState(2)} className={`nav-item nav-link ${activeState === 2 && "active"}`} id="tab-1-tab" data-bs-toggle="pill" href="#tab-2" role="tab" aria-controls="tab-2" aria-selected="false">Refine Search</a>
                     {/* <a onClick={() => setActiveState(3)} className={`nav-item nav-link ${activeState===3 && "active"}`}id="tab-1-tab" data-bs-toggle="pill" href="#tab-3" role="tab" aria-controls="tab-3" aria-selected="false">Organization Comparison</a>
                     <a onClick={() => setActiveState(4)} className={`nav-item nav-link ${activeState===4 && "active"}`} id="tab-1-tab" data-bs-toggle="pill" href="#tab-4" role="tab" aria-controls="tab-4" aria-selected="false">Contact Information</a> */}
                  </div>
                  <div className="tab-content mt-3" id="nav-tabContent">
                     {
                        activeState === 1 &&
                        <CompanyName handleTab={handleTab} companyDetailsData={data} />
                     }
                     {
                        activeState === 2 &&
                        <RefineSearch data={data?.redefine_search} />
                     }
                     {/* {
                        activeState === 3 &&
                           <OrgnizationSearch />
                     }

                     {
                        activeState === 4 &&
                           <ContactSearch />
                     } */}
                  </div>
               </div>
            </div>
            {/* ./container */}
         </section>

      </>
   )
}

export default CompanyDetails








