// @ts-nocheck
import { PlanListApi } from 'Services/statgrid/PlanList/PlanListApi'
import React, { useEffect, useState } from 'react'

function AboutUs() {

    const[aboutData, setAboutData] = useState([])
    const getAboutUsData = async() => {
        try {
            const res =  await PlanListApi?.AboustUsList()
         if(res?.data?.status === "1"){
            setAboutData(res?.data?.data)
         }
         else{
            setAboutData([])
         }
            
        } catch (error) {
            console.log(error,"error");
        }
    }

    useEffect(() => {
        getAboutUsData()
    },[])


    const getHtmlValue = (htmlContent) => {
        const dangerouslyRenderedHTML = { __html: htmlContent };
        return dangerouslyRenderedHTML
      }
  return (
    <main className='position-relative py-4'>
    <div className="container">
      {
        aboutData?.map((item, index) => (
          <div key={index}>
            <h1 dangerouslySetInnerHTML={getHtmlValue(item.title)}></h1>
            <div className="seo_text" dangerouslySetInnerHTML={getHtmlValue(item.long_desc)}>
              {/* {seoContentData.content} */}
            </div>
          </div>
        ))
      }


    </div>
  </main>
  )
}

export default AboutUs
