// @ts-nocheck

import React, { useEffect, useState } from 'react'
import '../../../assests/tenderStatCommonCss/company/companyList.css'
import '../../../assests/tenderStatCommonCss/result/resultList.css'
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { useSelector } from 'react-redux';
import { CompanyService } from 'Services/statgrid/CompanyServices';
import { CSVLink } from "react-csv";
import 'react-loading-skeleton/dist/skeleton.css'
import SearchIcon from "@mui/icons-material/Search";
import Breadcrumb from 'common/components/Breadcrumb/Breadcrumb';
import { useLocation } from 'react-router-dom';
import { Backdrop } from '@mui/material';
import ResultStatGrid from 'Statgrid/components/ResultStatGrid';
import TenderFilter from 'Tendergrids/components/Filters/TenderFilter';
import useFilters from 'customHook/useFilters';
import { FilterServices } from 'Services/common/filters/FilterServices';
import { useRef } from 'react';
import { useDraggable } from "react-use-draggable-scroll";
import dayjs from 'dayjs';
import Tooltip from "@mui/material/Tooltip";
import ClearIcon from '@mui/icons-material/Clear';
import Skeleton from 'react-loading-skeleton';
const headers = [
   { label: "Tender Detail", key: "tender_details" },
   { label: "city", key: "city_name" },
   { label: "state", key: "state_name" },
   { label: "country", key: "country_name" },
   { label: "Tender Stage", key: "tender_stage" },
   { label: "Published Date", key: "published" },
   { label: "Amount", key: "amount" },
   { label: "Tender Ref Id", key: "tnd_ref_id" },
   { label: "Tender Gov Id", key: "tender_gov_id" }
]

const ResultList = () => {
   const [skeleton, setSkeleton] = useState(false)
   const [open, setOpen] = React.useState(false);
   const [tenderKeyword, setTenderKeyword] = useState('')
   const { filters, setFilterApi, chips } = useFilters('resultList')
   const [sort, setSort] = React.useState('');
   const [allStage, setAllStage] = useState([])
   const location = useLocation()
   const [tenderResult, setTenderResult] = useState({})
   const values = location.pathname;

   const str = values.replace('/', '')

   const handleChange = (event) => {
      setSort(event.target.value);
   };

   const csvReport = {
      data: tenderResult?.data ? tenderResult?.data : [],
      headers: headers,
      filename: 'tenderResult.csv'
   };

   const handleFilterChange = (e) => {
      setTenderKeyword(e.target.value)
      if (e.key === 'Enter') {
         e.preventDefault();
         searchClick()
      }
   };

   const searchClick = () => {
      const obj = {
         ...filters,
         tender_keyword: tenderKeyword,
         page_number: 0,
         limit: 50
      }
      setFilterApi(obj)
   }

   const resetEachValue = () => {
      setTenderKeyword('')
      const obj = {
         state_id: "",
         tnd_ref_id: "",
         tnd_id: '',
         tnd_govt_id: '',
         client_id: "",
         tender_keyword: "",
         tender_docs: "",
         sector_id: "",
         country_id: "",
         region_id: "",
         funding_agency_id: "",
         financial_year: '',
         from_date: "",
         to_date: "",
         latest_activity: '',
         published_date: "",
         close_exp_date: "",
         estm_value: "",
         estm_value_emd: "",
         pubdate_cust_from_date: "",
         pubdate_cust_to_date: "",
         expdate_cust_from_date: "",
         expdate_cust_to_date: "",
         amnt_custrange_operator: "",
         amnt_custrange_amount: "",
         custrange_denomination: "",
         amnt_custrange_operator_emd: "",
         amnt_custrange_amount_emd: "",
         custrange_denomination_emd: "",
         limit: 50,
         page_name: '',
         tender_status: 'active',
         no_bid: '',
         wishlist_category_id: '',
         page_number: 0,
      }
      setFilterApi(obj)
   }

   function toggleSidebar() {
      setIsActive(!isActive);
   }

   const deleteChipsFilter = (e, id, keyword) => {
      e.preventDefault()
      const formdata = new FormData()
      if (keyword === 'country_id') {
         let state_chip_id = chips?.find(val => val.filter_keyword === 'state_id')
         formdata.append('filter_chip_id', `${id.toString()}, ${state_chip_id.fld_id.toString()}`)
      } else {
         formdata.append('filter_chip_id', id)
      }
      try {
         FilterServices.deleteTenderFilter(formdata).then(res => {
            if (res?.data?.status === 1) {
               if (keyword === 'country_id') {
                  const obj = {
                     ...filters,
                     [keyword]: "",
                     state_id: '',
                  }
                  setFilterApi(obj)
               } else {
                  const obj = {
                     ...filters,
                     [keyword]: "",
                  }
                  setFilterApi(obj)
               }
            }
         })
      } catch (error) {
         console.log(error)
      }
   }


   useEffect(() => {
      setSkeleton(true)
      const timer = setTimeout(() => setSkeleton(false), 1000);
      return () => {
         clearTimeout(timer)
      }
   }, [filters])

   useEffect(() => {
      window.scrollTo(0, 0);
   }, []);


   const [isActive, setIsActive] = useState(false);

   function toggleSidebar() {
      setIsActive(!isActive);
   }



   const handleDrawerOpen = () => {
      setOpen(true);
      handleToggle()
   };

   const handleDrawerClose = () => {
      setOpen(false);
   };
   const handleToggle = () => {
      setOpen(!open);
   }

   const ref = useRef();
   const { events } = useDraggable(ref);

   const getAlltenderStage = () => {
      try {
         CompanyService.getAlltenderStage().then((res) => {
            if (res?.data?.status === 1) {
               setAllStage(res?.data?.data)
            }
         })
      } catch (error) {
         console.log(error);
      }
   }

   useEffect(() => {
      getAlltenderStage()
   }, [])

   return (
      <>
         <Breadcrumb data={str} />
         <section className="companyList_wrapper resultList">
            <div className='company_sidebar_cont'>
               {/* <div class="toggle-btn" onClick={toggleSidebar}>
                  <FilterAltIcon />
               </div> */}
               <div className='flexGrid' style={{ display: 'block' }}>
                  <div className="section-title" >
                     <h1>Tender <span className="one-text">Results</span></h1>
                  </div>

                  <main>
                     <div className="serachWrapper">

                        <div className="inner_flex">

                           <div className="d-flex">
                              <input type="text" onChange={handleFilterChange} name='tender_keyword' value={tenderKeyword} placeholder="Enter Keyword" />
                              <div className="search_icon" onClick={searchClick}><button className='mainButton whiteButton'><SearchIcon /></button></div>

                           </div>
                           <div>
                              <button className="mainButton ghostButton" type="button" onClick={handleDrawerOpen}>Advance Search</button>
                           </div>
                           <div className="buttonGrp">
                              <button onClick={resetEachValue} className="mainButton whiteButton" type="button">Reset</button>
                           </div>
                        </div>
                        {/* ./inner_flex */}
                        <div className="tagsContainer">
                           <div className="search_tags" {...events} ref={ref}>
                              {chips?.filter(val =>
                                 val.filter_val !== ''
                                 && val.filter_keyword !== 'tender_status'
                                 && val.filter_keyword !== 'no_bid'
                                 && val.filter_keyword !== 'tender_keyword'
                                 && val.filter_keyword !== 'page_number'
                                 && val.filter_keyword !== 'limit'
                                 && val.filter_keyword !== 'wishlist_category_id'
                              ).map((item, index) => {
                                 let filter_latest_val;
                                 if (item?.filter_keyword === 'from_date' || item?.filter_keyword === "pubdate_cust_from_date" || item?.filter_keyword === "expdate_cust_from_date") {
                                    ;
                                    filter_latest_val = dayjs(item.filter_text).format("DD MMM YYYY");
                                 } else if (item.filter_keyword === 'to_date' || item.filter_keyword === "pubdate_cust_to_date" || item.filter_keyword === "expdate_cust_to_date") {
                                    filter_latest_val = dayjs(item.filter_text).format("DD MMM YYYY");
                                 } else {
                                    filter_latest_val = item?.filter_text;
                                 }
                                 return (
                                    <>
                                       {!skeleton ?
                                          <Tooltip className="subHiding" title={item?.filter_keyword} placement="bottom">
                                             <div className="tagItem" key={index}>
                                                <div className="flexBox">
                                                   <div className="tTex">{filter_latest_val}</div>
                                                   <ClearIcon onClick={(e) => deleteChipsFilter(e, item?.fld_id, item.filter_keyword)} />
                                                </div>
                                             </div>
                                          </Tooltip>
                                          :
                                          <>
                                             <Skeleton width={160} height={32} />
                                          </>
                                       }
                                    </>

                                 )
                              })}
                           </div>
                        </div>
                     </div>
                     {/* ./serachWrapper */}

                     <div className="listActionButtons">
                        <div className="grpGroupButton">
                           <CSVLink {...csvReport}>    <div className="downButton"><i className="fas fa-download"></i> Download Details</div></CSVLink>
                           <div className="reportButton"><i className="fas fa-flag"></i> My bids</div>
                        </div>
                        <div className="sortBy">
                           <label>Sort By:</label>
                           <FormControl sx={{ minWidth: 120 }}>
                              <Select
                                 value={sort}
                                 onChange={handleChange}
                                 displayEmpty
                                 inputProps={{ 'aria-label': 'Without label' }}
                              >
                                 <MenuItem value="">
                                    <em>None</em>
                                 </MenuItem>
                                 <MenuItem value={10}>Updated (Latest)</MenuItem>
                                 <MenuItem value={20}>Twenty</MenuItem>
                                 <MenuItem value={30}>Thirty</MenuItem>
                              </Select>
                           </FormControl>
                        </div>
                     </div>
                     <ResultStatGrid setFilterApi={setFilterApi} filters={filters} allStage={allStage} />

                  </main>
               </div>

            </div>
         </section>

         <Backdrop
            sx={{ color: '#fff', zIndex: '1000' }}
            open={open}
            onClick={handleDrawerClose}
         >
         </Backdrop>

         <TenderFilter open={open} handleDrawerClose={handleDrawerClose} handleDrawerOpen={handleDrawerOpen} setFilterApi={setFilterApi} filters={filters} allStage={allStage} />

      </>
   )
}

export default ResultList


