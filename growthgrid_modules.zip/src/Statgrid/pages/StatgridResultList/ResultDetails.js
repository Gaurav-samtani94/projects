// @ts-nocheck

import React, { useEffect, useState } from 'react'
import '../../../assests/tenderStatCommonCss/result/resultDetails.css'
import Box from "@mui/material/Box";
import { DataGrid } from "@mui/x-data-grid";
import Col from 'react-bootstrap/Col';
import Nav from 'react-bootstrap/Nav';
import Row from 'react-bootstrap/Row';
import Tab from 'react-bootstrap/Tab';
import { useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { CompanyService } from 'Services/statgrid/CompanyServices';
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'
import Pagination from 'Statgrid/components/Pagination';
import Breadcrumb from 'common/components/Breadcrumb/Breadcrumb';
import EmptyBox from '../../../assests/img/empty-box.png'
import { useParams } from 'react-router-dom';
import dayjs from 'dayjs';
import ROUTES from 'Constants/Routes';

const ResultDetails = () => {
   const { id } = useParams();
   const [skeletonTime, setSkeletonTime] = useState(false);
   setTimeout(() => {
      setSkeletonTime(true)
   }, 2000)


   const [currentPage, setCurrentPage] = useState(1);
   const itemsPerPage = 2; // number of items to display per page

   const paginate = (items, pageNumber, pageSize) => {
      const startIndex = (pageNumber - 1) * pageSize;
      return items?.slice(startIndex, startIndex + pageSize);
   };
   const handlePageChange = (pageNumber) => {
      setCurrentPage(pageNumber);
   };

   const [firstPage, setCurrentFirstPage] = useState(1);
   const itemsfirstPage = 2; // number of items to display per page

   const paginateFirst = (items, pageNumber, pageSize) => {
      const startIndex = (pageNumber - 1) * pageSize;
      return items?.slice(startIndex, startIndex + pageSize);
   };
   const handlefirstPageChange = (pageNumber) => {
      setCurrentFirstPage(pageNumber);
   };
   const location = useLocation();
   const [data, setData] = useState({})
   const [stage, setStage] = useState([])
   const { userData } = useSelector((state) => state.loginData)
   const [bidYear, setBidYear] = useState([])
   const [tenderYear, setTenderYear] = useState([])
   const [tenderDoc, setTenderDoc] = useState([])
   const [tenderAward, setTenderAward] = useState([])
   const [similerResult, setSimilerResult] = useState([])
   const [allStage, setAllStage] = useState([])

   const GetSpecificData = () => {

      const formdata = new FormData()
      formdata.append('user_id', userData?.user_data?.loginid)
      formdata.append('tender_id', id)
      try {
         CompanyService.getTenderResultDetail(formdata).then((res) => {
            if (res?.data?.status === 1) {
               setData(res?.data?.data)
            } else {
               console.log('Not Found')
            }
         })
      } catch {
         console.log("error")
      }

   }
   useEffect(() => {
      window.scrollTo(0, 0);
   }, []);

   let date = dayjs(data?.published).format("DD MMM YYYY");


   const getStageDetails = () => {
      try {
         CompanyService.getAlltenderStage().then(res => {
            if (res?.data?.status === 1) {
               setStage(res?.data?.data)
            } else {
               console.log("not found")
            }
         })
      } catch (error) {
         console.log(error)
      }
   }

   const getBidYear = () => {
      const formdata = new FormData()
      formdata.append('user_id', userData?.user_data?.loginid)
      formdata.append('tender_id', id)
      try {
         CompanyService.getTenderBidderListfinYear(formdata).then((res) => {
            if (res?.data?.status === 1) {
               setTenderYear(res?.data?.data)
            } else {
               console.log("not found")
            }
         })
      } catch {
         console.log("error year")
      }

   }

   const val = location.pathname;
   const str = val.replace('/', '')

   const getCompatitor = () => {
      try {
         CompanyService.getAllCompetitor().then(res => {
            if (res?.data?.status === 1) {
               setBidYear(res?.data?.data)
            } else {
               console.log("not found")
            }
         })
      } catch (error) {
         console.log(error)
      }
   }
   const getStagesList = () => {
      try {
         CompanyService.getAlltenderStage().then((res) => {
            setAllStage(res?.data?.data)
         })
      } catch (error) {
         console.log(error)
      }
   }
   useEffect(() => {

      getStagesList()

   }, [])
   const getCompanyTenderDoc = () => {
      const formdata = new FormData()
      formdata.append('user_id', userData?.user_data?.loginid)
      formdata.append('tender_id', id)
      try {
         CompanyService.getCompanyDoc(formdata).then((res) => {

            if (res?.data?.status === 1) {
               setTenderDoc(res?.data?.data)
            }
         })
      } catch {
         console.log("error year")
      }

   }

   const getCompanyTenderAward = () => {
      const formdata = new FormData()
      formdata.append('user_id', userData?.user_data?.loginid)
      formdata.append('tender_id', id)
      try {
         CompanyService.getTenderAward(formdata).then((res) => {
            if (res?.data?.status === 1) {
               setTenderAward(res?.data?.data)
            } else {
               console.log('Not Found')
            }



         })
      } catch {
         console.log("error year")
      }

   }

   const getCompanySimilerResultTender = () => {
      const formdata = new FormData()
      formdata.append('user_id', userData?.user_data?.loginid)
      formdata.append('tender_id', id)
      try {
         CompanyService.getSimilerTenderResult(formdata).then((res) => {
            if (res?.data?.status === 1) {
               setSimilerResult(res?.data?.data)
            } else {
               console.log('Not Found')
            }
         })
      } catch {
         console.log("error year")
      }

   }
   useEffect(() => {
      getStageDetails()
      GetSpecificData()
      getBidYear()
      getCompatitor()
      getCompanyTenderDoc()
      getCompanyTenderAward()
      getCompanySimilerResultTender()
   }, [])


   const columns = [
      { field: "tender_id", headerName: "Sr. No", width: 70 },
      {
         field: "bidder_name",
         headerName: "Bidder Name",
         width: 350,
         editable: true,
         renderCell: (val) => {
            let comName = tenderAward.map((item, index) => {
               let innerCom = bidYear.filter((val) => val.fld_id === item.bidder_id).map((item) => { return (item.bidder_name) })
               return (
                  innerCom
               )
            })
            return (
               comName
            )
         }
      },
      {
         field: "work_completion_period",
         headerName: "Contract Day",
         width: 150,
         editable: true,
      },
      {
         field: "contract_value",
         headerName: "Work Value",
         width: 130,
         editable: true,
      },
      {
         field: "contract_date",
         headerName: "Contract date",
         width: 160,
         editable: true,
      },
   ];


   return (
      <>
         <Breadcrumb data={str} />
         <section className="resultDetails_wrapper">
            <div className="reultItemDetails profile-foreground">
               <div className='container'>
                  {skeletonTime ?

                     <div className="row">
                        <div className="col-md-8">
                           <div>
                              <h3 className="tc-white">{data?.tender_details}</h3>
                              <div className="locationTex"><i className="fas fa-map-marker-alt"></i>
                                 {data?.city_name || data?.state_name || data?.country_name ? (
                                    `${data?.city_name || ''}${data?.city_name && data?.state_name ? ', ' : ''}${data?.state_name || ''}${(data?.city_name || data?.state_name) && data?.country_name ? ', ' : ''}${data?.country_name || ''}`
                                 ) : null}
                              </div>
                           </div>
                        </div>
                        <div className="col-md-4">
                           <div className="actionButtons">
                              <div className='acItem'>
                                 <i className="far fa-file-alt"></i>
                                 <span className="badge bg-secondary align-self-center">Document Download</span>
                              </div>
                              <div className='acItem'>
                                 <i className="fas fa-download"></i>
                                 <span className="badge bg-secondary align-self-center">Document Details</span>
                              </div>
                           </div>
                        </div>
                     </div>
                     :
                     <div className="row">
                        <div className="col-md-8">
                           <div>
                              <h3 className="tc-white"><Skeleton height={30} /></h3>
                              <div className="locationTex"><Skeleton width={160} height={16} /></div>
                              {/* <div onClick={() => navigate(ROUTES.TENDER_LIST)} className="mainButton ghostButton" >View All Tenders</div> */}
                           </div>
                        </div>
                        <div className="col-md-4">
                           <div className="actionButtons">
                              <div className='acItem'>
                                 <Skeleton width={160} height={26} />
                              </div>
                              <div className='acItem'>
                                 <Skeleton width={160} height={26} />
                              </div>
                           </div>
                        </div>
                     </div>
                  }

               </div>
            </div>
            {/* ./reultItemDetails */}
            <div className='container'>
               <div className="containerWrapper">
                  <Tab.Container id="left-tabs-example" defaultActiveKey="Overview">
                     <Row className='mt-5'>
                        <Col sm={3}>
                           <Nav variant="pills" className="flex-column">
                              <Nav.Item>
                                 <Nav.Link eventKey="Overview">Overview</Nav.Link>
                              </Nav.Item>
                              <Nav.Item>
                                 <Nav.Link eventKey="Information">Bidder's Information</Nav.Link>
                              </Nav.Item>
                              <Nav.Item>
                                 <Nav.Link eventKey="Documents">Documents</Nav.Link>
                              </Nav.Item>
                              <Nav.Item>
                                 <Nav.Link eventKey="Document_bidder">
                                    Bidder's Info
                                 </Nav.Link>
                              </Nav.Item>
                           </Nav>
                        </Col>
                        <Col sm={9}>
                           <Tab.Content>
                              <Tab.Pane eventKey="Overview">
                                 <div className="tabWrapper tab-pane fade show active">
                                    <div className="section-title" >
                                       <h1>Overview</h1>
                                    </div>
                                    <div className="row mt-4">
                                       <div className="col-sm-7">
                                          <div className="card">
                                             <div className="card-title">
                                                <h1>Technical Bid Opening</h1>
                                             </div>
                                             {skeletonTime ?
                                                <div className="card-body">
                                                   <div className="listItem">
                                                      <label>Reference Number :</label>
                                                      <div className="text-dark">{data?.tnd_ref_id}</div>
                                                   </div>
                                                   <div className="listItem">
                                                      <label>Tender Gov ID :</label>
                                                      <div className="text-dark">{data?.tender_gov_id}</div>
                                                   </div>
                                                   <div className="listItem">
                                                      <label>Published on :</label>
                                                      <div className="text-dark">{date}</div>
                                                   </div>
                                                   <div className="listItem">
                                                      <label>Organization :</label>
                                                      <div className="text-dark">{data?.client_name}</div>
                                                   </div>
                                                   <div className="listItem">
                                                      <label>State :</label>
                                                      <div className="text-dark">{data?.state_name}</div>
                                                   </div>
                                                </div>
                                                :
                                                <div className="card-body">
                                                   <div className="listItem">
                                                      <label>Reference Number :</label>
                                                      <div className="text-dark"><Skeleton height={20} /></div>
                                                   </div>
                                                   <div className="listItem">
                                                      <label>Tender ID :</label>
                                                      <div className="text-dark"><Skeleton width={150} height={20} /></div>
                                                   </div>
                                                   <div className="listItem">
                                                      <label>Published on :</label>
                                                      <div className="text-dark"><Skeleton width={80} height={20} /></div>
                                                   </div>
                                                   <div className="listItem">
                                                      <label>Organization :</label>
                                                      <div className="text-dark"><Skeleton height={20} /></div>
                                                   </div>
                                                   <div className="listItem">
                                                      <label>State :</label>
                                                      <div className="text-dark"><Skeleton width={100} height={20} /></div>
                                                   </div>
                                                </div>
                                             }
                                          </div>
                                          {/* ./card */}
                                       </div>
                                       <div className="col-sm-5">
                                          <div className="card">
                                             <div className="card-title">
                                                <h1>Result Status</h1>
                                             </div>
                                             <div className="card-body">
                                                <div className="time-line">
                                                   {stage?.map((item, index) => {
                                                      return (
                                                         <>
                                                            {skeletonTime ?
                                                               <div key={index} className={`ant-timeline-item-content ${data?.tender_stage === item.fld_id ? "active" : null}`}>
                                                                  <h6 className="text-dark mb-0"><b>{item.stage_name}</b></h6>
                                                               </div>
                                                               :
                                                               <div key={index} className={`ant-timeline-item-content ${data?.tender_stage === item.fld_id ? "active" : null}`}>
                                                                  <h6 className="text-dark mb-0"><Skeleton height={20} /></h6>
                                                               </div>
                                                            }
                                                         </>
                                                      )
                                                   })}
                                                </div>
                                             </div>
                                          </div>
                                          {/* ./card */}
                                       </div>
                                    </div>
                                    {/* ./row */}
                                 </div>
                              </Tab.Pane>
                              <Tab.Pane eventKey="Information">
                                 <div className="tabWrapper tab-pane">
                                    <div className="section-title" >
                                       <h1>Bidder's Information</h1>
                                    </div>

                                    <table id="table_id" className="display table dataTable w-100">
                                       <thead>
                                          <tr>
                                             <th>Bidder Name</th>
                                             <th>Bidder Status</th>
                                             <th>Bid Amount</th>
                                             <th>Bid Rank</th>
                                          </tr>
                                       </thead>
                                       <tbody>


                                          {
                                             tenderYear?.map((item, index) => {
                                                let compName = bidYear?.filter((val) => val.fld_id === item.bidder_id).map((item) => { return (item.bidder_name) })
                                                return (
                                                   <tr>
                                                      <td><div className="bidderName" key={index}>{item?.bidder_name}</div></td>
                                                      <td>
                                                         <div className="conContent">

                                                            <div className="statusText"><span>Status:</span> {item?.bidder_status}</div>
                                                         </div>
                                                      </td>
                                                      <td><i className="fas fa-rupee-sign me-1"></i> {item.amount}</td>
                                                      <td>{item.rank}</td>
                                                   </tr>
                                                )
                                             })
                                          }

                                          {/* <td>
                                                <div className="conContent">
                                                   <div className="bidderName">L N MALVIYA INFRA PROJECTS PVT LTD</div>
                                                   <div className="statusText"><span>Status:</span> Admitted-Fee/PreQual/Technical/Finance</div>
                                                </div>
                                             </td>
                                             <td><i className="fas fa-rupee-sign me-1"></i> 2000</td>
                                             <td>102</td>
                                          </tr>
                                          <tr>
                                             <td>
                                                <div className="conContent">
                                                   <div className="bidderName">AICONS Engineering Pvt. Ltd</div>
                                                   <div className="statusText"><span>Status:</span> Admitted-Fee/PreQual/Technical/Finance</div>
                                                </div>
                                             </td>
                                             <td><i className="fas fa-rupee-sign me-1"></i> 2000</td>
                                             <td>102</td>
                                          </tr>
                                          <tr>
                                             <td>
                                                <div className="conContent">
                                                   <div className="bidderName">Consulting Engineers Group Ltd</div>
                                                   <div className="statusText"><span>Status:</span> Admitted-Fee/PreQual/Technical/Finance</div>
                                                </div>
                                             </td>
                                             <td><i className="fas fa-rupee-sign me-1"></i> 2000</td>
                                             <td>102</td>
                                          </tr>
                                          <tr>
                                             <td>
                                                <div className="conContent">
                                                   <div className="bidderName">Monarch Surveyors and Engg Consultants Pvt Ltd</div>
                                                   <div className="statusText"><span>Status:</span> Admitted-Fee/PreQual/Technical/Finance</div>
                                                </div>
                                             </td>
                                             <td><i className="fas fa-rupee-sign me-1"></i> 2000</td>
                                             <td>102</td>
                                          </tr>
                                          <tr>
                                             <td>
                                                <div className="conContent">
                                                   <div className="bidderName">LnT Infrastructure Engineering Limited</div>
                                                   <div className="statusText"><span>Status:</span> Admitted-Fee/PreQual/Technical/Finance</div>
                                                </div>
                                             </td>
                                             <td><i className="fas fa-rupee-sign me-1"></i> 2000</td>
                                             <td>102</td>
                                          </tr> */}
                                       </tbody>
                                    </table>
                                    <div className="noteText">Note: Tender status of Technical Evaluation or less. Might not have bid amount specified.</div>
                                 </div>
                              </Tab.Pane>
                              <Tab.Pane eventKey="Documents">
                                 <div className="tabWrapper tab-pane">
                                    <div className="section-title" >
                                       <h1>Documents</h1>
                                    </div>
                                    <div className="card mt-4">
                                       <div className="card-body">
                                          <ul className="docList">
                                             {
                                                tenderDoc.length !== 0 ?

                                                   <>
                                                      {tenderDoc?.map((item, index) => (
                                                         <li className=""><i className="fas fa-file-alt"></i> <a href={item.full_path} target='_blank'  >{item.file_name}</a></li>
                                                      ))
                                                      }
                                                   </>
                                                   :

                                                   <div className="spinerWrap">
                                                      <div>
                                                         <img src={EmptyBox} width={120} />
                                                         <div style={{ textAlign: "center", fontSize: 14, marginTop: 15 }}>No Data Found</div>
                                                      </div>
                                                   </div>

                                             }

                                          </ul>
                                       </div>
                                    </div>
                                    {/* ./card */}
                                 </div>
                              </Tab.Pane>
                              <Tab.Pane eventKey="Document_bidder">
                                 <div className="tabWrapper tab-pane">
                                    <div className="card paymentHistory">
                                       <h5 className="card-title"><b>Bidder's List</b></h5>
                                       <div className="card-body">
                                          {(tenderAward.length !== 0 && tenderAward[0].tender_id !== null) ?
                                             <Box sx={{ height: 400, width: "100%" }}>
                                                <DataGrid
                                                   rows={tenderAward}
                                                   columns={columns}
                                                   getRowId={(itemData) => itemData?.tender_id}
                                                   initialState={{
                                                      pagination: {
                                                         paginationModel: {
                                                            pageSize: 5,
                                                         },
                                                      },
                                                   }}
                                                   pageSizeOptions={[5]}
                                                   disableRowSelectionOnClick
                                                />
                                             </Box>

                                             :

                                             <div className="spinerWrap">
                                                <div>
                                                   <img src={EmptyBox} width={120} />
                                                   <div style={{ textAlign: "center", fontSize: 14, marginTop: 15 }}>No Data Found</div>
                                                </div>
                                             </div>

                                          }

                                       </div>
                                    </div>
                                    {/* ./card */}
                                 </div>
                              </Tab.Pane>
                           </Tab.Content>
                        </Col>
                     </Row>
                  </Tab.Container>
               </div>
            </div>
            {/* ./container */}
         </section>

         <section className="tenders_cont similarResults ">
            <div className="resultList">
               <div className="section-title">
                  <h1>
                     Similar <span className="one-text">Results</span>
                  </h1>
               </div>
               {paginateFirst(
                  similerResult?.similar_result_tenders,
                  firstPage,
                  itemsfirstPage
               )?.map((item, index) => {
                  return (
                     <>
                        <div className="" key={index}>
                           <div className="comCard">
                              <div className="topCard">
                                 <div className="locationTex">
                                    <i className="fas fa-map-marker-alt"></i>{" "}
                                    {item?.city_name}, {item?.state_name},{" "}
                                    {item?.country_name}
                                 </div>
                                 <div className="cilpBage">{stage?.filter(val => val.fld_id === item.tender_stage).map(items => { return (items.stage_name) })}</div>
                              </div>
                              <div className="clientName">{item?.client_name}</div>
                              <div className="serviceName">
                                 <i className="fas fa-hotel me-2"></i>{" "}
                                 {item?.tender_details}
                              </div>
                              <div className="d-flex">
                                 <div className="bidDate">
                                    <span className="sub">
                                       <i className="fas fa-calendar-alt me-1"></i> Published
                                       on
                                    </span>
                                    <span>{dayjs(item?.published).format("DD MMM YYYY")} </span>
                                 </div>
                                 <div className="bidNumber">
                                    <i className="fas fa-rupee-sign me-1"></i> Amount{" "}
                                    <span>{item?.cost}</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </>
                  );
               })}

               <div className="pagination">
                  {similerResult?.similar_result_tenders && similerResult?.similar_result_tenders.length > itemsPerPage && (
                     <Pagination
                        firstPage={firstPage}
                        itemsfirstPage={itemsfirstPage}
                        totalItems={similerResult?.similar_result_tenders.length}
                        onPageChange={handlefirstPageChange}
                     />
                  )}
               </div>
               {/* ./pagination */}
            </div>

            <div className="resultList">
               <div className="section-title">
                  <h1>
                     Similar Live <span className="one-text">Tenders</span>
                  </h1>
               </div>
               {paginate(
                  similerResult?.similar_live_tenders,
                  currentPage,
                  itemsPerPage
               )?.map((item, index) => {
                  return (
                     <>
                        <div className="" key={index}>
                           <div className="comCard">
                              <div className="topCard">
                                 <div className="locationTex">
                                    <i className="fas fa-map-marker-alt"></i>{" "}
                                    {item?.city_name}, {item?.state_name},{" "}
                                    {item?.country_name}
                                 </div>
                                 <div className="cilpBage">{stage?.filter(val => val.fld_id === item.tender_stage).map(item => { return (item.stage_name) })}</div>
                              </div>
                              <div className="clientName">{item?.client_name}</div>
                              <div className="serviceName">
                                 <i className="fas fa-hotel me-2"></i>{" "}
                                 {item?.tender_details}
                              </div>
                              <div className="d-flex">
                                 <div className="bidDate">
                                    <span className="sub">
                                       <i className="fas fa-calendar-alt me-1"></i> Published
                                       on
                                    </span>
                                    <span>{dayjs(item?.published).format("DD MMM YYYY")} </span>
                                 </div>
                                 <div className="bidNumber">
                                    <i className="fas fa-rupee-sign me-1"></i> Amount{" "}
                                    <span>{item?.cost}</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </>
                  );
               })}

               <div className="pagination">
                  {similerResult?.similar_live_tenders && similerResult?.similar_live_tenders.length > itemsPerPage && (
                     <Pagination
                        currentPage={currentPage}
                        itemsPerPage={itemsPerPage}
                        totalItems={similerResult?.similar_live_tenders}
                        onPageChange={handlePageChange}
                     />
                  )}
               </div>
               {/* ./pagination */}
            </div>
         </section>

      </>
   )
}

export default ResultDetails


