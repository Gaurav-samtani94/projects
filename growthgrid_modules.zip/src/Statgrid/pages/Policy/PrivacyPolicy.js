// @ts-nocheck
import { PlanListApi } from 'Services/statgrid/PlanList/PlanListApi'
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';

function PrivacyPolicy() {
  const { slug } = useParams();
  const [data, setData] = useState([])
  const getPrivacyData = async () => {
    const formData = new URLSearchParams()

    try {
      formData?.append("slug", slug)
      const res = await PlanListApi?.PolicyData(formData)
      if (res?.data?.status === "1") {
        setData(res?.data?.data)
      }
      else{
        setData([])
      }
    } catch (error) {

    }

  }

  useEffect(() => {
    getPrivacyData()
  }, [])

  const getHtmlValue = (htmlContent) => {
    const dangerouslyRenderedHTML = { __html: htmlContent };
    return dangerouslyRenderedHTML
  }
  return (
    <main className='position-relative py-4'>
      <div className="container">
        {
          data?.map((item, index) => (
            <div key={index}>
              <h1 dangerouslySetInnerHTML={getHtmlValue(item.type_slug)}></h1>
              <div className="seo_text" dangerouslySetInnerHTML={getHtmlValue(item.policy_text)}>
                {/* {seoContentData.content} */}
              </div>
            </div>
          ))
        }


      </div>
    </main>
  )
}

export default PrivacyPolicy
