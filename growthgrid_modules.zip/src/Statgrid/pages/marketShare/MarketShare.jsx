// @ts-ignore
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Chart from 'chart.js/auto';
import { Avatar, Checkbox, Col, Dropdown, Input, List, Modal, Row, Select, Space, Tabs, Tooltip } from 'antd';
import { Switch } from 'antd'
import { Pagination } from 'antd';
// @ts-ignore
import { Drawer, Button } from 'antd';
import SearchBar from 'Statgrid/components/searchBar/SearchBar';
import FilteredTagsAndSearchResult from 'Statgrid/components/UI/FilteredTagsAndSearchResult';
import CompanyCard from 'Statgrid/components/cards/CompanyCard';
import { useNavigate } from 'react-router-dom';
import ROUTES from 'Statgrid/router/statgridRoutes';
import DurationFilterDropDown from 'Statgrid/components/UI/DurationFilterDropDown';
import { CloseOutlined, DownOutlined } from '@ant-design/icons';

import { uniqueColors } from 'Statgrid/utils/Colors';
import { motion } from 'framer-motion'
import { SearchSvg } from 'Statgrid/utils/Svgs';


const competitorsData = [
    {
        "id": "16459234398290011014",
        "title": "NH Consulting Private Limited",
        "checked": false,
        "lastBidDate": "2024-01-12"
    },
    {
        "id": "11620294049939283879",
        "title": "Water Power Consultants India Private Limited",
        "checked": false,
        "lastBidDate": "2024-03-06"
    },
    {
        "id": "9797662158353016526",
        "title": "JS Environics Consultants Private Limited",
        "checked": false,
        "lastBidDate": "2021-04-06"
    },
    {
        "id": "5358618297381794835",
        "title": "Highway Consulting Engineers Private Limited",
        "checked": false,
        "lastBidDate": "2024-03-06"
    },
    {
        "id": "16676685917132825680",
        "title": "The Building Consultant & Technological Service Cooperative Society Limited T 1054",
        "checked": false,
        "lastBidDate": "2024-03-21"
    },
    {
        "id": "15112791841539220679",
        "title": "BE Water - Marine Equipment Suppliers & Consultants Limited Liability Partnership",
        "checked": false,
        "lastBidDate": "2024-03-23"
    },
    {
        "id": "1550128554243587760",
        "title": "Samarth Water Consultants Private Limited",
        "checked": false,
        "lastBidDate": "2024-05-02"
    },
    {
        "id": "13628854555286072399",
        "title": "Plan & Build Consultants Limited Liability Partnership",
        "checked": false,
        "lastBidDate": "2022-09-28"
    },
    {
        "id": "1318944168367674180",
        "title": "Beml Limited",
        "checked": false,
        "lastBidDate": "2024-05-20"
    },
    {
        "id": "3201726696673297303",
        "title": "Ela Green Buildings & Infrastructure Consultants Private Limited",
        "checked": false,
        "lastBidDate": "2024-04-12"
    },
    {
        "id": "12486379351258418073",
        "title": "Nilkamal Limited",
        "checked": false,
        "lastBidDate": "2024-05-21"
    },
    {
        "id": "16156151659280471609",
        "title": "Aimil Limited",
        "checked": false,
        "lastBidDate": "2024-05-20"
    },
    {
        "id": "17519508457613661198",
        "title": "Gmmco Limited",
        "checked": false,
        "lastBidDate": "2024-05-21"
    },
    {
        "id": "1314213118176246689",
        "title": "Instrumentation Limited",
        "checked": false,
        "lastBidDate": "2024-05-22"
    },
    {
        "id": "14020991117347056779",
        "title": "Wapcos Limited",
        "checked": false,
        "lastBidDate": "2024-05-22"
    },
    {
        "id": "1943872258643201488",
        "title": "Cipla Limited",
        "checked": false,
        "lastBidDate": "2024-05-17"
    },
    {
        "id": "3788113158514624235",
        "title": "Flowmore Limited",
        "checked": false,
        "lastBidDate": "2024-05-17"
    },
    {
        "id": "5261102140399498075",
        "title": "Ncc Limited",
        "checked": false,
        "lastBidDate": "2024-05-22"
    },
    {
        "id": "13143490727865502806",
        "title": "Gee Limited",
        "checked": false,
        "lastBidDate": "2024-05-22"
    },
    {
        "id": "11470918495031144966",
        "title": "Thermax Limited",
        "checked": false,
        "lastBidDate": "2024-05-17"
    }
];

const authorities = ['Agency for Development of Aquaculture Kerala', 'Agriculture Department Maharashtra', 'Balmer Lawries & Co. Ltd.', "Bank Note Paper Mill India Private Limited", "Cane Development (Ganna Vikas Vibhag) Department Uttar Pradesh", "Ce Water Resources Department Gosikurda Project Nagpur", "Dakshin Gujarat Vij Company Ltd. (DGVCL)", "Deendayal Port Authority (DPA) (Gujarat)", "East Central Rly", "Election Department Uttar Pradesh", "Fatehgarh Sahib (Punjab)", "Finance Department Maharashtra", "Garden Reach Shipbuilders & Engineers Limited", "General Administration Department (GAD) Jammu and Kashmir", "Handloom and Textile Industry Department Uttar Pradesh", "Hazaribag (Jharkhand)", "Ignp (Rajasthan)", "India Tourism Development Corporation Ltd. (Delhi)", "J.l.n. Medical College, Ajmer (Rajasthan)", "Jaipur Vidyut Vitran Nigam Limited (Rajasthan)", "Kamrup Metro District Judiciary (Assam)", "Karnataka Co-operative Milk Producers Federation Limited (Karnataka)"]

const sectors = ['Accounting & Auditing Tenders', 'Adhesives & Sealants Tenders', 'Advance Engineering Services Tenders', 'Advertisement Tenders', 'Agricultural & forestry Tenders', 'Aircraft Tenders', 'Airport Tenders', 'Animal Husbandry and Dairying Tenders', 'Arts & Crafts Tenders', 'Atomic & Nuclear Energy Machinery & Equipment Tenders', 'Audio & Visual Tenders', 'Automotive Specialty Tools Tenders', 'Bakery Products Tenders', 'Banking & Investment Tenders', 'Batteries & Cells Component Tenders', 'Bearing & Wheel Tenders', 'Beverage Tenders', 'Bridge Tenders', 'Buildings & Housing tenders', 'Business Administration Services Tenders', 'Camping & Accessories Tenders', 'Castings Tenders']

function Marketshare() {
    const navigation = useNavigate()
    const [showAside, setShowAside] = useState(false)
    const [currentLabels, setCurrentLabels] = useState(authorities)

    const [selectedDataSets, setSelectedDataSets] = useState([
        {
            label: 'Total Amount',
            data: authorities.map(() => Math.floor(Math.random() * 400) + 100),
            backgroundColor: uniqueColors[0],
            borderColor: uniqueColors[0],
        },
        {
            label: 'Your Share',
            data: authorities.map(() => Math.floor(Math.random() * 100) + 1),
            backgroundColor: uniqueColors[1],
            borderColor: uniqueColors[1],
        }
    ])

    useEffect(() => {
        const dogHuntBarCanvas = document.getElementById('quarterChart');

        if (dogHuntBarCanvas) {
            // @ts-ignore
            const ctx = dogHuntBarCanvas.getContext('2d');
            Chart.getChart(ctx)?.destroy();

            new Chart(ctx, {
                // @ts-ignore
                type: 'bar',
                data: {
                    labels: currentLabels,
                    datasets: selectedDataSets,
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    interaction: {
                        mode: 'y',
                        // intersect: false
                    },
                    scales: {
                        x: {
                            stacked: true, display: true, position: 'top',
                            ticks: {
                                callback: function (value) {
                                    return "₹ " + value + "cr";
                                }
                            }
                        }, // Set to true for a stacked bar chart
                        y: {
                            stacked: true, display: true,
                            ticks: {
                                callback: function (value) {
                                    const stringValue = currentLabels[value];
                                    const maxLength = 25; // Set the maximum length for y-axis labels
                                    return stringValue.length > maxLength ? stringValue.slice(0, maxLength) + '...' : stringValue;
                                }
                            }
                        },
                    },
                    plugins: {
                        legend: {
                            display: false,
                        },
                        tooltip: {
                        }
                    }
                },

            });
        }
    }, [selectedDataSets, currentLabels]);

    const tabItems = [
        {
            key: 'authorities',
            label: 'Authorities',
        },
        {
            key: 'sector',
            label: 'Sector',
        },
    ];

    const onTabChange = (key) => {
        console.log(key);
        if (key.trim() == 'authorities') {
            setCurrentLabels(authorities)
        } else if (key.trim() == 'sector') {
            setCurrentLabels(sectors)
        }
    };



    const [searchQuery, setSearchQuery] = useState('');
    const [data, setData] = useState(competitorsData);

    const filteredData = useMemo(() => {
        const query = searchQuery.toLowerCase();
        return data.filter(item => item.title.toLowerCase().includes(query));
    }, [searchQuery, data]);

    const handleSearch = useCallback((e) => {
        setSearchQuery(e.target.value);
    }, []);

    const handleItemClick = useCallback((id) => {
        setData(prevData =>
            prevData.map(item => {
                if (item.id === id) {
                    const isChecked = !item.checked;
                    if (isChecked) {
                        setSelectedDataSets(prevSelected => [
                            ...prevSelected,
                            {
                                label: item.title,
                                data: authorities.map(() => Math.floor(Math.random() * 100) + 1), // Example data
                                backgroundColor: uniqueColors[prevSelected.length % uniqueColors.length],
                                borderColor: uniqueColors[prevSelected.length % uniqueColors.length],
                            }
                        ]);
                    } else {
                        setSelectedDataSets(prevSelected =>
                            prevSelected.filter(dataset => dataset.label !== item.title)
                        );
                    }
                    return { ...item, checked: isChecked };
                }
                return item;
            })
        );
    }, []);

    return (
        <section className='d-flex gap-4 align-items-start'>
            <article className='w-50 flex-grow-1'>
                <div className="container-fluid px-4 pb-0 pt-5">
                    <h2 className='fw-normal'>Market Share</h2>
                </div>
                <div className='container-fluid p-4 pb-0 market-share-header mb-5'>
                    <div className="d-flex justify-content-between gap-4 align-items-center mb-3">
                        <Tabs
                            defaultActiveKey="1"
                            items={tabItems}
                            onChange={onTabChange}
                            className='comparison-tabs w-100'
                            indicator={{ size: (origin) => origin - 20, align: "center" }}
                        />
                        <Button type='default' className='brand-outlined-btn d-flex gap-3' onClick={() => setShowAside(!showAside)} size='large' >
                            Compare
                        </Button>
                    </div>
                    <div className='label-sec pb-3'>
                        {selectedDataSets?.map((item, i) => {
                            return (
                                <Tooltip placement="top" title={item?.label}>
                                    <div className='d-flex gap-3 align-items-center cursor-pointer'>
                                        <div
                                            style={{
                                                width: '24px',
                                                height: '24px',
                                                borderRadius: '24px',
                                                backgroundColor: `${uniqueColors[i]}`,
                                            }}
                                        ></div>
                                        <p className='comp-label'>{item?.label?.length > 18 ? item?.label.slice(0, 18) + "..." : item?.label}</p>
                                    </div>
                                </Tooltip>
                            )
                        })}
                    </div>
                </div>
                <div className='px-4'>
                    <canvas id="quarterChart"></canvas>
                </div>
            </article>
            <motion.aside
                className={`competitor-aside`}
                initial={{
                    width: 0
                }}
                animate={{
                    width: showAside ? 350 : 0
                }}
                transition={{
                    delay: showAside ? 0 : 0.5
                }}
            >
                <motion.div
                    initial={{
                        opacity: 0
                    }}
                    animate={{
                        opacity: showAside ? 1 : 0
                    }}
                    transition={{
                        delay: showAside ? 0.5 : 0
                    }}
                    className='p-4'
                >
                    {/* <Checkbox
                        checked={selectedDataSets.nhConsulting}
                        onChange={(e) => onChange(e, 'nhConsulting')}
                    >
                        NH Consulting Private Limited
                    </Checkbox>
                    <Checkbox
                        checked={selectedDataSets.unitedRailRoad}
                        onChange={(e) => onChange(e, 'unitedRailRoad')}
                    >
                        United Rail Road Consultants Private Limited
                    </Checkbox> */}
                    <div className='d-flex gap-3'>
                        <Input
                            placeholder="Search for competitor"
                            prefix={<SearchSvg color='#7E7E7E' w={20} h={20} />}
                            className="g-search-input py-2 w-fit rounded-pill mb-2 w-50 flex-grow-1"
                            onChange={handleSearch}
                            value={searchQuery}
                        />
                        <Tooltip title="Close">
                            <Button onClick={() => setShowAside(false)} size='large' className=' d-flex align-items-center justify-content-center' shape="circle" icon={<CloseOutlined />} />
                        </Tooltip>
                    </div>
                    <List
                        itemLayout="horizontal"
                        dataSource={filteredData}
                        renderItem={(item, index) => (
                            <List.Item className='cursor-pointer d-flex gap-3' onClick={() => handleItemClick(item.id)}>
                                <List.Item.Meta
                                    className='w-50 flex-grow-1'
                                    avatar={<Avatar src={`https://api.dicebear.com/7.x/miniavs/svg?seed=${index}`} />}
                                    title={item.title}
                                    description={`Last Bid Date: ${item?.lastBidDate}`}
                                />
                                {item?.checked &&
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" width={28} height={28}>
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                                    </svg>
                                }
                            </List.Item>
                        )}
                    />
                </motion.div>
            </motion.aside>
        </section>
    )
}


export default Marketshare