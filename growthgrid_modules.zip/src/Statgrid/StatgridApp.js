// @ts-nocheck
import React, { lazy, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, useNavigate } from 'react-router-dom';

// import ROUTES from './router/statgridRoutes';
import ROUTES from 'Constants/Routes';

// ** init... ** //
import Error404 from 'common/pages/Error404/Error404';
import RootLayout from './layouts/RootLayout';
import STATROUTES from './router/statgridRoutes';
import UserListStat from './pages/userList/UserListStat';
import AddUser from './pages/addUser/AddUser';
import Profile from './pages/profile/Profile';

import StatForgotPassword from './pages/fogotpassowrd/StatForgotPassword';
import Roles from './pages/roles/Roles';
import StatGridDropDown from 'Includes/StatGridDropDown';
import ContactUs from './pages/contact/ContactUs';
import Support from './pages/support/Support';
import Wallet from './pages/wallet/Wallet';
import InnerPlan from './pages/plan/InnerPlan';
import Checkout from './pages/checkout/Checkout';
import SGTenderList from './pages/tenders/SGTenderList';
import AuthoritiesList from './pages/authorities/AuthoritiesList';
import AuthoritiesCompare from './pages/authorities/AuthoritiesCompare';
import TenderSuggestion from './pages/tender-suggestion/TenderSuggestion';
import UnlockCompany from './pages/unlockCompany';

// ** init... ** //


// ** pages ** //
const DashboardMain = lazy(() => import('Statgrid/pages/dashboard/DashboardMain'))
const Login = lazy(() => import('Statgrid/pages/login/Login'))
const Signup = lazy(() => import('Statgrid/pages/signup/Signup'))

const CompanyList = lazy(() => import('Statgrid/pages/companies/CompanyList'))
const CompanyDashboard = lazy(() => import('Statgrid/pages/companies/CompanyDashboard'))
const CompanyCompare =lazy(() => import('Statgrid/pages/companies/CompanyCompare'))
const TopCompetitor = lazy(() => import('Statgrid/pages/topCompetitor'))

const Performance = lazy(() => import('Statgrid/pages/performance/Performance'))
const PerformanceDetails = lazy(() => import('Statgrid/pages/performance/PerformanceDetail'))

const ResultList = lazy(() => import('Statgrid/pages/result/ResultList'))
const ResultDetail = lazy(() => import('Statgrid/pages/result/ResultDetail'))
const MissedOpportunity = lazy(() => import('Statgrid/pages/missedOpportunity'))

const MarketShare = lazy(() => import('Statgrid/pages/marketShare/MarketShare'))

const TenderCalender = lazy(() => import('Statgrid/pages/tenderCalender/TenderCalender'))
const SaveSearch = lazy(() => import('Statgrid/pages/savedSearch/SaveSearch'))
const Reminder = lazy(() => import('Statgrid/pages/reminder/Reminder'))
const Plans = lazy(() => import('Statgrid/pages/plan/Plan'))
const Privacy = lazy(() => import('Statgrid/pages/Policy/PrivacyPolicy'))
const About = lazy(() => import('Statgrid/pages/about/AboutUs'))

// ** pages ** //






const StatgridApp = () => {
    const navigate = useNavigate();

    const currentPath = window.location.pathname;
    // const checkAuth = () => {
    //     let authForLogin = localStorage.getItem('statToken')

    //     if (currentPath.split('/')?.[2] !== STATROUTES.PLAN  && currentPath.split('/')?.[2] !== "terms-and-conditions" && currentPath.split('/')?.[2] !== "privacy-policy")  {
    //         if (authForLogin) {
    //             if (currentPath === ROUTES.STAT_LOGIN) {
    //                 navigate(ROUTES.STATDASHBOARD, { replace: true })
    //                 // window.location.reload()
    //                 window.open(ROUTES.STATDASHBOARD, "_blank")
    //             }
    //         } 
    //         else {
    //             navigate(ROUTES.STAT_LOGIN, { replace: true })
    //         }
    //     }
    // };



    // const checkAuth = async () => {
    //     let authForLogin = await localStorage.getItem('statToken')
    //     if (authForLogin) {
    //         if (currentPath === ROUTES.STAT_LOGIN) {
    //             navigate(ROUTES.STATDASHBOARD, { replace: true })
    //             // window.location.reload()
    //             window.open(ROUTES.STATDASHBOARD, "_blank")
    //         }
    //     }
    //     else {
    //         if (currentPath.split('/')?.[2] === STATROUTES.PLAN || currentPath.split('/')?.[2] === STATROUTES.WALLET || currentPath.split('/')?.[2] === STATROUTES.CHECKOUT || currentPath.split('/')?.[2] === "terms-and-conditions" || currentPath.split('/')?.[2] === "privacy-policy") {
    //             navigate(currentPath, { replace: true })
    //             // window.location.reload()
    //             window.open(currentPath, "_blank")
    //         } else {
    //             navigate(ROUTES.STAT_LOGIN, { replace: true })

    //         }
    //     }
    // };

    // useEffect(() => {
    //     checkAuth()
    // }, [])


    return (
        <>

            <StatGridDropDown />
            <RootLayout>

                <Routes>

                    <Route path='*' element={<Error404 />} />
                    <Route path={STATROUTES?.STAT_LOGIN} element={<Login />} />
                    <Route path={STATROUTES?.STAT_SIGNUP} element={<Signup />} />
                    <Route path={STATROUTES?.STAT_FORGOT_PASSWORD} element={<StatForgotPassword />} />

                    <Route path={STATROUTES?.STATDASHBOARD} element={<DashboardMain />} />


                    <Route path={STATROUTES?.COMPANIES} element={<CompanyList />} />
                    <Route path={STATROUTES?.COMPANY_DETAIL + "/:id"} element={<CompanyDashboard />} />
                    <Route path={STATROUTES?.COMPANY_COMPARE} element={<CompanyCompare />} />

                    <Route path={STATROUTES?.TOP_COMPETITOR} element={<TopCompetitor />} />
                    <Route path={STATROUTES?.UNLOCK_COMPANY} element={<UnlockCompany />} />

                    <Route path={STATROUTES?.PERFORMANCE} element={<Performance />} />
                    <Route path={STATROUTES?.PERFORMANCE_DETAIL + "/:id"} element={<PerformanceDetails />} />

                    <Route path={STATROUTES?.RESULTS} element={<ResultList />} />
                    <Route path={STATROUTES?.RESULT_DETAIL + "/:id"} element={<ResultDetail />} />
                    <Route path={STATROUTES?.MISSED_OPPORTUNITY} element={<MissedOpportunity />} />
                    <Route path={STATROUTES?.AUTHORITIES_LIST} element={<AuthoritiesList />} />
                    <Route path={STATROUTES?.AUTHORITIES_COMPARE} element={<AuthoritiesCompare />} />

                    <Route path={STATROUTES?.MARKET_SHARE} element={<MarketShare />} />

                    <Route path={STATROUTES?.TENDER_CALENDER} element={<TenderCalender />} />
                    <Route path={STATROUTES?.REMINDER} element={<Reminder />} />
                    <Route path={STATROUTES?.SAVED_SEARCH} element={<SaveSearch />} />
                    <Route path={STATROUTES?.USERLIST} element={<UserListStat />} />
                    <Route path={STATROUTES?.ADDUSER} element={<AddUser />} />
                    <Route path={STATROUTES?.PROFILES} element={<Profile />} />
                    <Route path={STATROUTES?.STAT_ROLES_AND_PERMISSION} element={<Roles />} />
                    <Route path={STATROUTES?.PLAN} element={<Plans />} />
                    <Route path={STATROUTES?.NEWSLUG} element={<Privacy />} />
                    <Route path={STATROUTES?.CONTACT} element={<ContactUs />} />
                    <Route path={STATROUTES?.SUPPORT} element={<Support />} />
                    <Route path={STATROUTES?.WALLET} element={<Wallet />} />
                    <Route path={STATROUTES?.ABOUT_US} element={<About />} />
                    <Route path={STATROUTES?.INNER_PLAN} element={<InnerPlan />} />
                    <Route path={STATROUTES?.CHECKOUT} element={<Checkout />} />

                    <Route path={STATROUTES?.TENDERLIST} element={<SGTenderList />} />
                    <Route path={STATROUTES?.TENDERSUGGESTION} element={<TenderSuggestion />} />

                    {/* // TODO: old routs do as you wish */}
                    {/* <Route path='/' element={<Stats />} />
                <Route path={ROUTES?.COMPANIES} element={<Companies />} />
                <Route path={ROUTES?.STAT_TENDER_RESULT} element={<StatTenderResult />} />
                <Route path={ROUTES?.COMPANY_DETAILS} element={<CompanyDetails />} />
                <Route path={ROUTES?.RESULT_DETAILS} element={<ResultDetails />} />
                <Route path={ROUTES?.MARKET_SHARE_DETAILS} element={<MarketShareDetails />} />
                <Route path={ROUTES?.RESULT_DETAILS_PAGE} element={<Resultdeatail />} /> */}
                    {/* // TODO: old routs do as you wish */}
                </Routes>
            </RootLayout>
        </>
    )
}

export default StatgridApp
