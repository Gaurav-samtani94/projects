// @ts-nocheck
import React from "react";
import { useEffect, useRef } from 'react';
// Import Highcharts
import Highcharts from "highcharts/highcharts.js";
import highchartsMore from "highcharts/highcharts-more.js";
import solidGauge from "highcharts/modules/solid-gauge.js";
import HighchartsReact from "highcharts-react-official";

highchartsMore(Highcharts);
solidGauge(Highcharts);

function renderIcons() {

    this.series[0].icon = this.renderer.path(['M', -4, 0, 'L', 4, 0, 'M', 0, -4, 'L', 4, 0, 0, 4])
        .attr({
            stroke: '#303030',
            'stroke-linecap': 'round',
            'stroke-linejoin': 'round',
            'stroke-width': 2,
            zIndex: 10
        })
        .add(this.series[0].group);

    this.series[0].icon.translate(
        this.chartWidth / 2 - 10,
        this.plotHeight / 2 - this.series[0].points[0].shapeArgs.innerR -
        (this.series[0].points[0].shapeArgs.r - this.series[0].points[0].shapeArgs.innerR) / 2
    );

    // Exercise icon
}
const options = {
    chart: {
        type: 'solidgauge',
        height: '100%',
        events: {
            render: renderIcons
        }
    },

    title: {
        text: '',
        style: {
            fontSize: '18px'
        }
    },

    tooltip: {
        borderWidth: 0,
        backgroundColor: 'none',
        shadow: false,
        style: {
            fontSize: '12px'
        },
        valueSuffix: '%',
        pointFormat: '{series.name}<br><span style="font-size:16px; color: {point.color}; font-weight: bold">{point.y}</span>',
        positioner: function (labelWidth) {
            return {
                x: (this.chart.chartWidth - labelWidth) / 2,
                y: (this.chart.plotHeight / 2) + 15
            };
        }
    },

    pane: {
        startAngle: 0,
        endAngle: 360,
        background: [{ // Track for Move
            outerRadius: '90%',
            innerRadius: '65%',
            backgroundColor: Highcharts.color(Highcharts.getOptions().colors[0])
                .setOpacity(0.3)
                .get(),
            borderWidth: 0
        }]
    },

    yAxis: {
        min: 0,
        max: 100,
        lineWidth: 0,
        tickPositions: []
    },

    plotOptions: {
        solidgauge: {
            dataLabels: {
                enabled: false
            },
            linecap: 'round',
            stickyTracking: false,
            rounded: true
        }
    },

    series: [{
        name: '',
        data: [{
            color: Highcharts.getOptions().colors[0],
            radius: '90%',

            innerRadius: '65%',
            y: 20
        }]
    }]
};
const SolidGuage = () => {
    const refContainer = useRef("chartComponent1");
    return (
        <div className="solid_chart">
            {/* <h2>Highcharts</h2> */}
            <div className="row">
                <div className="col-sm-12">
                    <HighchartsReact
                        constructorType={'chart'}
                        highcharts={Highcharts}
                        options={options}
                        ref={refContainer}
                    />
                </div>
                {/* <div className="col-sm-4">
                    <HighchartsReact
                    constructorType={'chart'}
                    highcharts={Highcharts}
                    options={options}
                    ref={refContainer}
                />
                </div>
                <div className="col-sm-4">
                    <HighchartsReact
                    constructorType={'chart'}
                    highcharts={Highcharts}
                    options={options}
                    ref={refContainer}
                />
                </div> */}
            </div>
        </div>
    )
}

export default SolidGuage;

