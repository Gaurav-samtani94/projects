// @ts-nocheck
import React from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
const CompanyPopup = (props) => {

  
  return (
    <>
      <Modal
        {...props}
        size="md"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Body className="p-0">
          <div className="Get-Quote">
            <div className="box">
              <div className="body">
                <Row>
                  <Col md={12}>
                    <div className="text-center">
                      <div className="modal_heading mb-4">Unlock Company</div>
                      <p>
                        Thia action will cost you one company credits. You will
                        be able to see past bids of the company and more
                        information about it.
                      </p>
                      <div className="">
                        <strong className="comp_credit">Company credits: </strong> Used : 
                        <strong className="comp_credit">
                            103</strong> of <strong className="comp_credit">400</strong>
                      </div>
                    </div>
                    <p className="mt-3 text-decoration-underline text-center">Do you want to Continue?</p>
                    <div className="login_popup">
                      <button onClick={props.onHide} className="mainButton">
                        Cancel
                      </button>
                      <button className="mainButton ghostButton">
                        Confirm
                      </button>
                    </div>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
};

export default CompanyPopup;
