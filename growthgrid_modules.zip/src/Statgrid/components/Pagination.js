import React from 'react';

const Pagination = ({ currentPage, itemsPerPage, totalItems, onPageChange }) => {
   const totalPages = Math.ceil(totalItems / itemsPerPage);

   const pageNumbers = [];
   for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(i);
   }

   const handlePreviousPage = () => {
      if (currentPage > 1) {
         onPageChange(currentPage - 1);
      }
   };

   const handleNextPage = () => {
      if (currentPage < totalPages) {
         onPageChange(currentPage + 1);
      }
   };

   return (
      <ul className="pagination">
         <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
            <button className="page-link" onClick={handlePreviousPage}>
               Prev
            </button>
         </li>
         {pageNumbers.map((number) => (
            <li key={number} className={`page-item ${number === currentPage ? 'active' : ''}`}>
               <button className="page-link" onClick={() => onPageChange(number)}>
                  {number}
               </button>
            </li>
         ))}
         <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
            <button className="page-link" onClick={handleNextPage}>
               Next
            </button>
         </li>
      </ul>
   );
};

export default Pagination;
