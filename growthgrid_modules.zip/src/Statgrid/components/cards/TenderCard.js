import React from 'react';
import dayjs from 'dayjs'
import ROUTES from 'Statgrid/router/statgridRoutes';

// icons
import { Select, Form } from 'antd'
import { Round, LocalTwo, PaperMoneyTwo, PieFour, CollectionFiles, CircleRightUp, Down, Info } from '@icon-park/react';
import { Route, useLocation, Link } from "react-router-dom";

const options = [
    {
        label: 'Unmarked',
        value: 'unmarked',
        icon: <Round theme="filled" size="16" fill="#cecece" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
        label: 'Rejected',
        value: 'rejected',
        icon: <Round theme="filled" size="16" fill="#f54646" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
        label: 'Tentative',
        value: 'tentative',
        icon: <Round theme="filled" size="16" fill="#f6bd16" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
        label: 'Shortlisted',
        value: 'shortlisted',
        icon: <Round theme="filled" size="16" fill="#0ebd66" strokeWidth={3} strokeLinecap="butt" />,
    },
];

const TenderCard = ({ isGridView, status = ("stated" || "success" || "canceled"), alertType = ("secondary" || "warning"), alertContent = "", item }) => {
    const location = useLocation();
    return (
        <div className={`bid-card ${isGridView ? "gridView" : "listView"}`}>
            <div className="tnd_det">
                <div className="d-flex">
                    <div className="gap-3 align-items-center">
                        <div className="tender__id">#329682</div>
                    </div>
                    <div className="icons">
                        <div className="tc_item status_select">
                            <small>Mark tender as</small>
                            <Form.Item
                                name=""
                                label=""
                                rules={[
                                    {
                                        required: true,
                                    },
                                ]}
                            >
                                <Select
                                    suffixIcon={<Down theme="outline" size="18" strokeWidth={3} fill="#9b9b9b" />}
                                    placeholder="Select option"
                                    defaultValue={['unmarked']}
                                    style={{
                                        width: 180,
                                    }}
                                    options={options}
                                    optionRender={(option) => (
                                        <div className="status__option">
                                            {option.data.icon}
                                            <p>
                                               {option.data.label}
                                            </p>    
                                        </div>
                                    )}
                                />
                            </Form.Item>
                        </div>
                        <div>
                            <CollectionFiles theme="filled" size="26" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                        </div>
                        <div className="view__tender">
                            <CircleRightUp theme="filled" size="26" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                        </div>

                    </div>
                </div>
                {/* <h5 className="tender__name">{item?.tnd_title}</h5> */}
                <h5 className="tender__name">GROUP: D- Reproductive Medicine Time Lapse Incubator with Integrated Cell Culture Monitoring System Witnessing System Alarm System for Incubator & Embryology Lab (Air Quality Control Device) CASA (Computer Assisted Semen Analysis System Office Hysteroscopy with all operative accessory with Master Resectoscope USG- 3D Laparoscope Set with 4K with Printer & reporting System Co2 Incubator with Multiple doors Genetics (Cytogenetics Lab) Teaching Aid</h5>

                <div className="client__name">
                    <PieFour theme="two-tone" size="16" fill={['#9b9b9b', '#9b9b9b']} strokeWidth={3} strokeLinecap="butt" />
                    Forest Department
                </div>

            </div>


            <div className="tnd_flex">
                <div className="tnd_content_left">
                    {location.pathname.includes(ROUTES.RESULT_DETAIL) ?
                        null
                        :
                        <div className="tc_item">
                            <small>Location</small>
                            <div>
                                <LocalTwo theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                Uttar Pradesh , India
                            </div>
                        </div>
                    }


                    <div className="tc_item">
                        <small>Tender cost</small>
                        <div>
                            <PaperMoneyTwo theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                            ₹ 9.90 lakh
                        </div>
                    </div>

                    {location.pathname.includes(ROUTES.RESULT_DETAIL) ?
                        null
                        :
                        <div className="tc_item">
                            <small>EMD value</small>
                            <div>
                                <PaperMoneyTwo theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                ₹ 19,800
                            </div>
                        </div>
                    }

                </div>

                {
                    !isGridView &&
                    <div className="tnd_content_right">

                        <div className="tc_item">
                            <small>Bid submission End Date</small>
                            <div className="end">
                                {dayjs(item?.created_date).format('MMM D, YYYY')}
                            </div>
                        </div>
                        {location.pathname.includes(ROUTES.RESULT_DETAIL) ?
                            null
                            :
                            <div className="tc_item tnd__status">
                                <small>Tender Status</small>
                                <div>
                                    <span>Financial Evaluation</span>
                                </div>
                            </div>
                        }

                    </div>
                }

            </div>
            {
                isGridView &&
                <div className="d-flex algin-items-center justify-content-between py-3 px-3">
                    <div className="tc_item">
                        <small>Bid submission End Date</small>
                        <div className="end">
                            {dayjs(item?.created_date).format('MMM D, YYYY')}
                        </div>
                    </div>
                    <div className="tc_item tnd__status">
                        <small>Tender Status</small>
                        <div>
                            <span>Financial Evaluation</span>
                        </div>
                    </div>
                </div>
            }
            {alertContent &&
                <div className={`bidAlert  ${alertType}`}>
                    {alertType === "secondary" && <Info theme="outline" size="24" fill="#0c66e4" strokeWidth={3} strokeLinecap="butt"/>}
                    {alertType === "warning" && <Info theme="outline" size="24" fill="#f45a2f" strokeWidth={3} strokeLinecap="butt"/>}
                    <p className='pb-0'>
                        {/* {alertContent} */}
                        Theme Engineering Services Pvt Ltd won with bid of ₹3.034 Crores
                    </p>
                </div>
            }
        </div>
    )
}

export default TenderCard