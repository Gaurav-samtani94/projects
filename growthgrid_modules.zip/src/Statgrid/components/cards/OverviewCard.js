import React from 'react'

const OverviewCard = (props) => {
    return (
        <div className="overview-card">
            <h5 className='mb-3'>{props.cartTitle}</h5>
            {props.details.map((item) => (
                <>
                    <h2 className='mb-0'>{item.value}</h2>
                    <p className='mb-3'>{item.label}</p>
                </>
            ))}
            <div className="details_btn">
                <button>See Detail</button>
            </div>
        </div>
    )
}

export default OverviewCard