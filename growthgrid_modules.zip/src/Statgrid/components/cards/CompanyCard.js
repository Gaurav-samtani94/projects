import React from 'react';
import { CalendarThree, DocDetail, LocalTwo, PieFour, Ranking, TableReport } from '@icon-park/react';
import { Avatar, Checkbox } from '@mui/material';
import { AnnouncementSvg, PerformanceSvg } from 'Statgrid/utils/Svgs';
import { Divider, Modal } from 'antd';

import dayjs from 'dayjs'


const CompanyCard = ({ cardFor = ("company" || "authorities"), isLocked = false, isChecked = false, isGridView, item, isComparing = false }) => {
    let {
        imgUrl,
        name,
        state,
        sectors,
        num_bids,
        last_bid_date,
        following,
        total_tenders,
        live_tender,
    } = item
    // const stateres = () => {
    //     // Check if all data is available
    //     if (item?.tbl_countries && item?.tbl_states && item?.tbl_cities) {
    //         // All data is available, display all
    //         return item.tbl_countries.map((country, index) => (
    //             <div key={index} className='state_tab_top 1'>


    //                 <p> {item.tbl_cities[index]?.city_name ? item.tbl_cities[index]?.city_name + "," : ""}{item.tbl_states[index]?.state_name ? item.tbl_states[index]?.state_name + "," : ""}{country?.country_name}</p>
    //             </div>
    //         ));
    //     } else {
    //         // At least one of the data is missing, display individual values
    //         const country = item?.tbl_countries?.[0]?.country_name;
    //         const state = item?.tbl_states?.[0]?.state_name;
    //         const city = item?.tbl_cities?.[0]?.city_name;
    //         const locationString = `${country ? country + ',' : ''} ${state ? state + ',' : ''} ${city ? city : ''}`;
    //         return (
    //             <div className='state_tab_top 2'>
    //                 {locationString}

    //             </div>
    //         );
    //     }
    // };

    return (
        // <div className={`company_one ${isLocked ? "" : "unlocked-company"}`}>

        //     <h4>{item?.company_name}</h4>
        //     <div className='icon_text'>
        //         {/* <img src={vectortext} alt="" /> */}
        //         <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
        //             <g clip-path="url(#clip0_84_295)">
        //                 <path d="M3.5 3V1C3.5 0.867392 3.55268 0.740215 3.64644 0.646447C3.74021 0.552678 3.86739 0.5 4 0.5H12.5C12.6326 0.5 12.7598 0.552678 12.8536 0.646447C12.9473 0.740215 13 0.867392 13 1V5M7.5 3H10.5M0.909998 12.56L0.499998 5.56C0.491473 5.48948 0.49807 5.41796 0.519351 5.35019C0.540631 5.28242 0.576107 5.21996 0.623415 5.16698C0.670723 5.11399 0.728777 5.0717 0.793711 5.0429C0.858645 5.01411 0.928969 4.99949 0.999998 5H5.61C5.72208 5.00069 5.83081 5.03829 5.91938 5.10698C6.00795 5.17567 6.07143 5.27162 6.1 5.38L6.5 7H13C13.0692 6.99978 13.1376 7.01391 13.2011 7.0415C13.2645 7.06909 13.3215 7.10954 13.3685 7.16029C13.4155 7.21105 13.4514 7.271 13.4741 7.33635C13.4967 7.40171 13.5055 7.47105 13.5 7.54L13.11 12.54C13.0898 12.7911 12.9757 13.0254 12.7903 13.1959C12.6049 13.3665 12.3619 13.4608 12.11 13.46H1.91C1.66123 13.4612 1.42093 13.3697 1.23602 13.2033C1.05111 13.0369 0.934872 12.8075 0.909998 12.56Z" stroke="#7E7E7E" stroke-linecap="round" stroke-linejoin="round" />
        //             </g>
        //             <defs>
        //                 <clipPath id="clip0_84_295">
        //                     <rect width="14" height="14" fill="white" />
        //                 </clipPath>
        //             </defs>
        //         </svg>
        //         <p>{item?.company_desc}</p>
        //     </div>
        //     <div className={`d-flex gap-3 bid_spans  ${isGridView ? "flex-column" : " align-items-center"}`}>
        //         <span>Contact No - {item?.contact_no}</span>
        //         {!isGridView &&
        //             <span> | </span>
        //         }
        //         <span>email -{item?.email_id}</span>
        //     </div>
        //         {stateres()}
        //     {/* <div className='state_tab_top'>
        //     </div> */}
        //         {/* <p>{stateres()}</p> */}
        //     <div className='left_border_lock'>
        //         <svg width="100" height="85" viewBox="0 0 100 85" fill="none" xmlns="http://www.w3.org/2000/svg">
        //             <path d="M25.7576 0H0C25.7576 0 25.7576 21.8939 25.7576 21.8939V0Z" fill="white" />
        //             <path d="M100 63.1061H74.2424C100 63.1061 100 85 100 85V63.1061Z" fill="white" />
        //             <path d="M25.7576 0H100V63.1061H57.7576C40.0845 63.1061 25.7576 48.7792 25.7576 31.1061V0Z" fill="white" />
        //         </svg>
        //     </div>
        //     <div className='icon_lock'>
        //         {isLocked 
        //         ?
        //              <svg width="49" height="48" viewBox="0 0 49 48" fill="none" xmlns="http://www.w3.org/2000/svg" 

        //             >
        //                 <path d="M19.5307 21.3333V18.6667C19.5307 14.9853 21.1453 12 24.7431 12C28.341 12 29.9556 14.9853 29.9556 18.6667V21.3333M13.6667 31.7333V25.6C13.6667 24.1067 13.6667 23.36 13.9508 22.7907C14.2005 22.2884 14.5992 21.88 15.0897 21.624C15.6475 21.3347 16.3772 21.3347 17.8367 21.3347H31.6496C33.1091 21.3347 33.8388 21.3347 34.3965 21.624C34.8869 21.8797 35.2856 22.2876 35.5355 22.7893C35.8195 23.36 35.8195 24.1067 35.8195 25.6V31.7333C35.8195 33.2267 35.8195 33.9733 35.5355 34.544C35.2856 35.0457 34.8869 35.4537 34.3965 35.7093C33.8388 36 33.1091 36 31.6496 36H17.8367C16.3772 36 15.6475 36 15.0897 35.7093C14.5994 35.4537 14.2007 35.0457 13.9508 34.544C13.6667 33.9747 13.6667 33.228 13.6667 31.7333Z" stroke="#FC7878" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        //                 <path d="M48.1597 24C48.1597 36.8357 37.6806 47.25 24.7431 47.25C11.8055 47.25 1.32642 36.8357 1.32642 24C1.32642 11.1643 11.8055 0.75 24.7431 0.75C37.6806 0.75 48.1597 11.1643 48.1597 24Z" stroke="#FC7878" stroke-width="1.5" />
        //             </svg>

        //             : <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        //                 <circle cx="24" cy="24" r="23.25" stroke="#1D9E49" stroke-width="1.5" />
        //                 <path d="M18.8235 21.4116V18.8234C18.8235 15.2503 20.4269 12.3528 24 12.3528C26.7099 12.3528 28.2874 14.0196 28.8918 16.3827M29.1765 26.5881V30.4704M13 31.5057V25.5528C13 24.1034 13 23.3787 13.2821 22.8261C13.53 22.3386 13.926 21.9422 14.4132 21.6937C14.9671 21.4129 15.6918 21.4129 17.1412 21.4129H30.8588C32.3082 21.4129 33.0329 21.4129 33.5868 21.6937C34.0738 21.9419 34.4697 22.3378 34.7179 22.8248C35 23.3787 35 24.1034 35 25.5528V31.5057C35 32.9551 35 33.6798 34.7179 34.2337C34.4697 34.7207 34.0738 35.1166 33.5868 35.3648C33.0329 35.6469 32.3082 35.6469 30.8588 35.6469H17.1412C15.6918 35.6469 14.9671 35.6469 14.4132 35.3648C13.9262 35.1166 13.5303 34.7207 13.2821 34.2337C13 33.6811 13 32.9564 13 31.5057Z" stroke="#1D9E49" stroke-width="1.86353" stroke-linecap="round" stroke-linejoin="round" />
        //             </svg>

        //         }
        //     </div>
        //     {/* {isGridView && index % 2 === 1 && <div style={{ margin: '16px 0' }} />} */}
        // </div>
        <div className="company_card">
            <div className="det">
                <div className="d-flex justify-content-between align-items-start">
                    <div className="d-flex align-items-center gap-3">
                        <Avatar
                            alt={name + ' logo'}
                            src={imgUrl}
                            sx={{ width: "52px", height: "52px" }}
                        >
                            {name.slice(0, 1)}
                        </Avatar>
                        <div className="company__det">
                            <h5>{name}</h5>
                            {sectors && <p className='description_text'>{sectors ? sectors.slice(0, 4).join(", ") : ""}{sectors && sectors.length > 4 && '...'}</p>}
                        </div>
                    </div>
                    {cardFor === 'company' && <>
                        {isLocked
                            ?
                            <svg width="40" height="40" viewBox="0 0 49 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.5307 21.3333V18.6667C19.5307 14.9853 21.1453 12 24.7431 12C28.341 12 29.9556 14.9853 29.9556 18.6667V21.3333M13.6667 31.7333V25.6C13.6667 24.1067 13.6667 23.36 13.9508 22.7907C14.2005 22.2884 14.5992 21.88 15.0897 21.624C15.6475 21.3347 16.3772 21.3347 17.8367 21.3347H31.6496C33.1091 21.3347 33.8388 21.3347 34.3965 21.624C34.8869 21.8797 35.2856 22.2876 35.5355 22.7893C35.8195 23.36 35.8195 24.1067 35.8195 25.6V31.7333C35.8195 33.2267 35.8195 33.9733 35.5355 34.544C35.2856 35.0457 34.8869 35.4537 34.3965 35.7093C33.8388 36 33.1091 36 31.6496 36H17.8367C16.3772 36 15.6475 36 15.0897 35.7093C14.5994 35.4537 14.2007 35.0457 13.9508 34.544C13.6667 33.9747 13.6667 33.228 13.6667 31.7333Z" stroke="#FC7878" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                <path d="M48.1597 24C48.1597 36.8357 37.6806 47.25 24.7431 47.25C11.8055 47.25 1.32642 36.8357 1.32642 24C1.32642 11.1643 11.8055 0.75 24.7431 0.75C37.6806 0.75 48.1597 11.1643 48.1597 24Z" stroke="#FC7878" stroke-width="1.5" />
                            </svg>
                            :
                            <svg width="40" height="40" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="24" cy="24" r="23.25" stroke="#1D9E49" stroke-width="1.5" />
                                <path d="M18.8235 21.4116V18.8234C18.8235 15.2503 20.4269 12.3528 24 12.3528C26.7099 12.3528 28.2874 14.0196 28.8918 16.3827M29.1765 26.5881V30.4704M13 31.5057V25.5528C13 24.1034 13 23.3787 13.2821 22.8261C13.53 22.3386 13.926 21.9422 14.4132 21.6937C14.9671 21.4129 15.6918 21.4129 17.1412 21.4129H30.8588C32.3082 21.4129 33.0329 21.4129 33.5868 21.6937C34.0738 21.9419 34.4697 22.3378 34.7179 22.8248C35 23.3787 35 24.1034 35 25.5528V31.5057C35 32.9551 35 33.6798 34.7179 34.2337C34.4697 34.7207 34.0738 35.1166 33.5868 35.3648C33.0329 35.6469 32.3082 35.6469 30.8588 35.6469H17.1412C15.6918 35.6469 14.9671 35.6469 14.4132 35.3648C13.9262 35.1166 13.5303 34.7207 13.2821 34.2337C13 33.6811 13 32.9564 13 31.5057Z" stroke="#1D9E49" stroke-width="1.86353" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        }
                    </>}
                    {cardFor === 'authorities' && isComparing &&
                        <Checkbox size='medium' checked={isChecked} />
                    }
                </div>
                <div className="d-flex gap-3 align-items-center mt-2">
                    {state &&
                        <div className="tc_item">
                            {/* <small>Location</small> */}
                            <div>
                                <LocalTwo theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                {state ? state.slice(0, 4).join(", ") : ""}
                            </div>
                        </div>
                    }
                    {following &&
                        <div className="followers_chip">
                            <PieFour theme="filled" size="17" fill="#067bc9" strokeWidth={3} strokeLinecap="butt" />
                            {following} followers
                        </div>
                    }
                </div>
            </div>
            <div className="company-stats">

                <div className="d-flex flex-wrap gap-5 justify-content-between align-items-center">
                    {num_bids &&
                        <>
                            <div className="cStat_item">
                                <Ranking theme="filled" size="30" fill="#067bc9" strokeWidth={3} strokeLinecap="butt" />
                                <div>
                                    <small>Estimated No of Bids</small>
                                    {num_bids}
                                </div>
                            </div>
                        </>
                    }
                    {last_bid_date &&
                        <>
                            <div className="cStat_item">
                                <CalendarThree theme="outline" size="30" fill="#f54646" strokeWidth={3} strokeLinecap="butt" />
                                <div>
                                    <small>Last Bid On</small>
                                    {dayjs(item?.last_bid_date).format('MMM D, YYYY')}
                                    {/* {last_bid_date.slice(0, 10)} */}
                                </div>
                            </div>
                        </>
                    }

                    {total_tenders &&
                        <>
                            <div className="cStat_item">
                                <TableReport theme="outline" size="30" fill="#067bc9" strokeWidth={3} strokeLinecap="butt" />
                                <div>
                                    <small>All Tenders</small>
                                    {total_tenders}
                                </div>
                            </div>
                            <Divider type='vertical' className='bg-secondary' style={{ height: "30px" }} />
                        </>
                    }
                    {live_tender &&
                        <>
                            <div className="cStat_item">
                                <DocDetail theme="outline" size="30" fill="#067bc9" strokeWidth={3} strokeLinecap="butt" />
                                <div>
                                    <small>Live Tenders</small>
                                    {live_tender}
                                </div>
                            </div>
                        </>
                    }
                </div>
            </div>
        </div>
    )
}

export default CompanyCard