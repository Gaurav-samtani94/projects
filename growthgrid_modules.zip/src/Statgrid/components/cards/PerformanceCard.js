import { FolderOpenOutlined } from '@ant-design/icons'
import { Trophy } from '@icon-park/react';
import { Chart } from 'chart.js/auto';
import React, { useEffect } from 'react'

const PerformanceCard = ({ id }) => {
    const names = {
        label1: "Neither is L1 76%",
        label2: "You’re L1 6%",
        label3: "Competior is L1 76%",
    }

    useEffect(() => {
        const dogHuntData = {
            labels: [names?.label1, names?.label2, names?.label3],
            datasets: [{
                data: [10, 7, 3],
                backgroundColor: ['#B8D9FF', '#A2E9BA', '#FC7878'],
                borderColor: ['#B8D9FF', '#A2E9BA', '#FC7878'],
                borderWidth: 1,
            }],
        };

        const dogHuntDoughnutCanvas = document.getElementById(id);

        if (dogHuntDoughnutCanvas) {
            // @ts-ignore
            const ctx = dogHuntDoughnutCanvas.getContext('2d');
            Chart.getChart(ctx)?.destroy();
            new Chart(ctx, {
                type: 'doughnut',
                data: dogHuntData,
                options: {
                    maintainAspectRatio: false,
                    // responsive: true,
                    responsive: true,
                    plugins: {
                        title: {
                            display: false,
                        },
                        tooltip: {
                            callbacks: {
                                title: (tooltipItem, data) => {
                                    return '';
                                },
                            },
                        },
                        legend: {
                            position: 'right',
                        },
                    },
                },
            });
        }
    }, []);

    return (
        <div className="prformnce_com_stat_sub">
            <div className="prfomnce_left_stat">
                <div className="state_name_chip">new delhi, uttar pradesh</div>
                <h2>Lea Associates South Asia Private Limited</h2>
                <p><FolderOpenOutlined className='folder_icon' />Consultancy services, Consulting Engineers, consulting engineers</p>
                <div className="win_status">
                    <div className="total_win">
                        <div className="total_loss_img">
                            <Trophy theme="outline" size="24" fill="#0ebd66" strokeWidth={3} strokeLinecap="butt" />
                            <span className='total_win_span'>3</span>
                        </div>
                        <span className="text_text">You’re L1 </span>
                    </div>
                    <div className="total_loss">
                        <div className="total_loss_img">
                            <Trophy theme="outline" size="24" fill="#f54646" strokeWidth={3} strokeLinecap="butt" />
                            <span className='total_win_span'>1</span>
                        </div>
                        <span className="text_text">Competitor is L1</span>
                    </div>
                    <div className="total_common_bids">
                        <h3 className='common_bid_name'>17 (93)</h3>
                        <span className="text_text">Total Common Bids</span>
                    </div>
                </div>
            </div>
            <div className='prformnce_right_stat'>
                <canvas id={id} height="auto" ></canvas>
            </div>
        </div>
    )
}

export default PerformanceCard