import { RightSmallUp } from '@icon-park/react'
import React from 'react'

const LiveStatsCard = ({ title, stats, des, icon, type }) => {
    return (
        <div className={`tender_status ${type}`}>
            <div className="view_link"><RightSmallUp theme="outline" size="24" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt"/></div>
            <div className="tender_count">
                <h5>{title}</h5>
                <div className="tender_count_details">
                    <h2 className='count_digit mb-1'>{stats}</h2>
                    {des &&
                        <span className='tender_des'>{des}</span>
                    }
                </div>
            </div>
            <span className='tender_icon'>{icon}</span>
        </div>
    )
}

export default LiveStatsCard