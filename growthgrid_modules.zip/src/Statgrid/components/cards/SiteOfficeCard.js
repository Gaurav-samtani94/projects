import React from 'react';
import { Button } from 'antd';

const SiteOfficeCard = ({ data, onEdit, onDelete, hasEditAndDelete = false }) => {
    const {
        country,
        state,
        city,
        officeManager,
        contactPerson,
        companyAddress,
        contactNumber,
        email
    } = data;

    return (
        <div className='company-card border b-small'>
            <div className="row g-0 ">
                <div className='col-12 d-flex align-items-center gap-3 p-3'>
                    <div className='company-details'>
                        <small><span>{country}</span>, <span>{state}</span>, <span>{city}</span></small>
                        <h6 className='mb-2 mt-2'>Office Manger: <h6 className='mb-1 brand-glow d-inline text-secondary'>{officeManager}</h6></h6>
                        <h6 className='mb-2'>Contact Person: <h6 className='mb-1 brand-glow d-inline text-secondary'>{contactPerson}</h6></h6>
                        <h6 className='mb-2'>Contact Number: <h6 className='mb-1 brand-glow d-inline text-secondary'>{contactNumber}</h6></h6>
                        <h6 className='mb-2'>email: <h6 className='mb-1 brand-glow d-inline text-secondary'>{email}</h6></h6>
                        <p className='mt-3 text-secondary'>{companyAddress}</p>
                    </div>
                    <div className='actions d-flex flex-md-column gap-4'>
                        {hasEditAndDelete &&
                            <>
                                <Button onClick={onEdit} type='link' className='brand-link'>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                        <g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                                            <path d="M7 7H6a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2v-1" />
                                            <path d="M20.385 6.585a2.1 2.1 0 0 0-2.97-2.97L9 12v3h3l8.385-8.415zM16 5l3 3" />
                                        </g>
                                    </svg>
                                </Button>
                                <Button onClick={onDelete} type='link' danger>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 20 20">
                                        <path fill="currentColor" d="m9.129 0l1.974.005c.778.094 1.46.46 2.022 1.078c.459.504.7 1.09.714 1.728h5.475a.69.69 0 0 1 .686.693a.689.689 0 0 1-.686.692l-1.836-.001v11.627c0 2.543-.949 4.178-3.041 4.178H5.419c-2.092 0-3.026-1.626-3.026-4.178V4.195H.686A.689.689 0 0 1 0 3.505c0-.383.307-.692.686-.692h5.47c.014-.514.205-1.035.554-1.55C7.23.495 8.042.074 9.129 0Zm6.977 4.195H3.764v11.627c0 1.888.52 2.794 1.655 2.794h9.018c1.139 0 1.67-.914 1.67-2.794l-.001-11.627ZM6.716 6.34c.378 0 .685.31.685.692v8.05a.689.689 0 0 1-.686.692a.689.689 0 0 1-.685-.692v-8.05c0-.382.307-.692.685-.692Zm2.726 0c.38 0 .686.31.686.692v8.05a.689.689 0 0 1-.686.692a.689.689 0 0 1-.685-.692v-8.05c0-.382.307-.692.685-.692Zm2.728 0c.378 0 .685.31.685.692v8.05a.689.689 0 0 1-.685.692a.689.689 0 0 1-.686-.692v-8.05a.69.69 0 0 1 .686-.692ZM9.176 1.382c-.642.045-1.065.264-1.334.662c-.198.291-.297.543-.313.768l4.938-.001c-.014-.291-.129-.547-.352-.792c-.346-.38-.73-.586-1.093-.635l-1.846-.002Z" />
                                    </svg>
                                </Button>
                            </>
                        }
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SiteOfficeCard;