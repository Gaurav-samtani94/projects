import React, { useState, useEffect } from 'react'
import '../../assests/tenderStatCommonCss/company/companyList.css'
import "../../assests/tenderStatCommonCss/company/companyDetails.css"
import { useNavigate } from 'react-router-dom';
import { CompanyService } from 'Services/statgrid/CompanyServices';
import SearchIcon from "@mui/icons-material/Search";
import { useSelector } from 'react-redux';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from '@mui/material/FormControlLabel';
import ROUTES from 'Statgrid/router/statgridRoutes';
import { DropdownValuesServices } from 'Services/common/dropdown/dropdownValues';

const initialState = {
   tender_keyword: '',
   tender_docs: '',
   sector_id: '',
   country_id: 1,
   region_id: "",
   state_id: "",
   client_id: "",
   funding_agency_id: "",
   financial_year: "",
   tender_status: 'active',
   published_date: '',
   close_exp_date: '',
   pubdate_cust_from_date: '',
   pubdate_cust_to_date: '',
   expdate_cust_from_date: '',
   expdate_cust_to_date: '',
   amnt_custrange_operator: '',
   amnt_custrange_amount: '',
   custrange_denomination: '',
   amnt_custrange_operator_emd: '',
   amnt_custrange_amount_emd: '',
   custrange_denomination_emd: '',
}

const RefineSearch = (props) => {
   const navigate = useNavigate();
   const [stage, setStage] = useState([])
   const [search, setSearch] = useState("");
   // @ts-ignore
   const { dropdownValues } = useSelector((state) => state.dropdownCalVal);
   const [data, setData] = useState(initialState);
   const [stateVal, setStateVal] = useState([])


   const getStageDetails = () => {
      try {
         CompanyService.getAlltenderStage().then(res => {
            if (res?.data?.status === 1) {
               setStage(res?.data?.data)
            } else {
               console.log("not found")
            }
         })
      } catch (error) {
         console.log(error)
      }
   }

   const getStateDrpValue = () => {
      const PayloadData = new FormData()

      try {
         // @ts-ignore
         if (data.country_id === 1) {
            PayloadData.append('country_id', "1")
            DropdownValuesServices.getState(PayloadData).then((response) => {
               setStateVal(response?.data?.data)
            })
         }

      } catch {
         console.log('error')
         setStateVal([])
      }

   }

   useEffect(() => {
      if (data?.country_id) {
         getStateDrpValue()
      }

   }, [data.country_id])

   const handleFilterChange = (e) => {
      if (e.key === 'Enter') {
         e.preventDefault();

      } else {
         if (e.target.name === 'country_id') {
            setData((prevState) => {
               const resetKey1 = { ...prevState, [e.target.name]: e.target.value, region_id: '', state_id: '' };
               return resetKey1;
            });
         } else {
            setData({ ...data, [e.target.name]: e.target.value });
         }
      }
   };

   useEffect(() => {
      getStageDetails()
   }, [])
   const [isActive, setIsActive] = useState(false);

   function toggleSidebar() {
      setIsActive(!isActive);
   }

   const handleChangeSearch = (e) => {
      setSearch(e.target.value.trimStart());
   };


   return (
      <>
         <div className="company_details">
            {/* <div className="toggle-btn" onClick={toggleSidebar}>
               <FilterAltIcon />
            </div> */}
            <div className='flexGrid'>
               <div id='sidebar' className={isActive ? 'filterWarp active' : 'filterWarp'} style={{ borderRadius: 10 }}>
                  <h5 className="card-title"><i className="fas fa-filter"></i> Filter</h5>
                  <div className="accordion filters-left" id="accordionExample">
                     <div className="accordion-item">
                        <h2 className="accordion-header" id="headingTwo">
                           <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                              Basic Filter
                           </button>
                        </h2>
                        <div id="collapseOne" className="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                           <div className="accordion-body">
                              <div className="col-12">
                                 <FormControl fullWidth className="mt-4">
                                    <Autocomplete
                                       value={dropdownValues?.client?.find((item) => item.fld_id === data?.client_id) || null}
                                       onChange={(event, newValue) => {
                                          handleFilterChange({
                                             target: {
                                                name: 'client_id',
                                                value: newValue ? newValue.fld_id : ''
                                             }
                                          });
                                       }}
                                       options={dropdownValues?.client?.sort((a, b) => a.client_name > b.client_name ? 1 : -1) || []}
                                       getOptionLabel={(option) => (option.client_name.charAt(0).toUpperCase() + option.client_name.slice(1).toLowerCase())}
                                       // getOptionSelected={(option, value) => option.fld_id === value.fld_id}
                                       renderInput={(params) => (
                                          <TextField
                                             {...params}
                                             label="--Client--"
                                             name="client_id"
                                             className="form-input"
                                          />
                                       )}
                                    />
                                 </FormControl>
                              </div>



                           </div>
                        </div>

                     </div>

                     {/* ./accordion-item */}
                     <div className="accordion-item">
                        <h2 className="accordion-header" id="headingTwo">
                           <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseBidValue" aria-expanded="false" aria-controls="collapseBidValue">
                              Bid Value
                           </button>
                        </h2>
                        <div id="collapseBidValue" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                           <div className="accordion-body">

                              <div className="row" style={{ alignItems: 'center' }}>
                                 <div className="col-12">
                                    <h5 className="labelText inputLabel" style={{ fontSize: 14, marginTop: 20 }}>Operator</h5>
                                    <FormControl fullWidth>
                                       <Select
                                          defaultValue=''
                                          labelId="demo-simple-select-label"
                                          id="demo-simple-select"
                                          label="Sector"
                                          className="form-input"
                                          name="amnt_custrange_operator"
                                          onChange={handleFilterChange}
                                       >
                                          <MenuItem value=''>--All--</MenuItem>
                                          <MenuItem value='<='>{`<=`}</MenuItem>
                                          <MenuItem value='>='>{`>=`}</MenuItem>
                                          {/* <MenuItem value='between'>Between</MenuItem> */}
                                          <MenuItem value=''>Not Specified</MenuItem>
                                       </Select>
                                    </FormControl>
                                 </div>
                                 <div className="col-12">
                                    <h5 className="labelText inputLabel" style={{ fontSize: 14, marginTop: 20 }}>Amount Value</h5>
                                    <TextField name="amnt_custrange_amount" label="Amount" variant="outlined" fullWidth className="form-input" onChange={handleFilterChange} />
                                 </div>
                                 <div className="col-12">
                                    <h5 className="labelText inputLabel" style={{ fontSize: 14, marginTop: 20 }}>Denomination</h5>
                                    <FormControl fullWidth>
                                       <Select
                                          defaultValue=''
                                          labelId="demo-simple-select-label"
                                          id="demo-simple-select"
                                          label="Sector"
                                          className="form-input"
                                          name="custrange_denomination"
                                          onChange={handleFilterChange}
                                       >
                                          <MenuItem value=''>--All--</MenuItem>
                                          <MenuItem value='hundred'>Hundred</MenuItem>
                                          <MenuItem value='thousand'>Thousand</MenuItem>
                                          <MenuItem value='lakhs'>Lakhs</MenuItem>
                                          <MenuItem value='crores'>Crores</MenuItem>
                                          <MenuItem value='million'>Million</MenuItem>
                                          <MenuItem value='billion'>Billion</MenuItem>
                                          <MenuItem value='trillion'>Trillion</MenuItem>

                                       </Select>
                                    </FormControl>
                                 </div>
                              </div>

                           </div>
                        </div>
                     </div>
                     {/* ./accordion-item */}
                     <div className="accordion-item">
                        <h2 className="accordion-header" id="headingTwo">
                           <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsePublished" aria-expanded="false" aria-controls="collapsePublished">
                              Published Date
                           </button>
                        </h2>
                        <div id="collapsePublished" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                           <div className="accordion-body">
                              <FormControl>
                                 <RadioGroup
                                    className='radioFlex'
                                    aria-labelledby="demo-controlled-radio-buttons-group"
                                    name="published_date"
                                    value={data?.published_date}
                                    onChange={handleFilterChange}
                                 >
                                    <FormControlLabel value="today" control={<Radio />} label="Today" />
                                    <FormControlLabel value="yesterday" control={<Radio />} label="Yesterday" />
                                    <FormControlLabel value="last_7_days" control={<Radio />} label="Last 7 Days" />
                                    <FormControlLabel value="last_30_days" control={<Radio />} label="Last 30 Days" />
                                    <FormControlLabel value="this_month" control={<Radio />} label="This Month" />
                                    <FormControlLabel value="last_month" control={<Radio />} label="Last Month" />
                                    <FormControlLabel value="custom_date" control={<Radio />} label="Custom Dates" />

                                 </RadioGroup>

                              </FormControl>
                              {data?.published_date === 'custom_date' ? <div className="grp_wrap" id='calander'>
                                 <div className="row">
                                    <div className="col-6">
                                       <h5 className="labelText inputLabel">Latest Activity From Date</h5>
                                       <TextField id="outlined-basic" type="date" variant="outlined" fullWidth className="form-input" name="pubdate_cust_from_date" autoComplete="off" onChange={handleFilterChange} />
                                    </div>
                                    <div className="col-6">
                                       <h5 className="labelText inputLabel">Latest Activity To Date</h5>
                                       <TextField id="outlined-basic" type="date" variant="outlined" fullWidth className="form-input" name="pubdate_cust_to_date" autoComplete="off" inputProps={{ min: data?.pubdate_cust_from_date }} onChange={handleFilterChange} />
                                    </div>
                                 </div>
                              </div>
                                 :
                                 ''
                              }
                           </div>
                        </div>
                     </div>
                     {/* ./accordion-item */}
                     <div className="accordion-item">
                        <h2 className="accordion-header" id="headingTwo">
                           <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseOne">
                              States
                           </button>
                        </h2>
                        <div id="collapseTwo" className="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                           <div className="accordion-body">

                              <div className="col-12">
                                 <FormControl fullWidth className="mt-4">
                                    <Autocomplete
                                       value={stateVal?.find((item) => item.state_id === data?.state_id) || null}
                                       onChange={(event, newValue) => {
                                          handleFilterChange({
                                             target: {
                                                name: 'state_id',
                                                value: newValue ? newValue.state_id : ''
                                             }
                                          });
                                       }}
                                       options={stateVal?.sort((a, b) => a.state_name > b.state_name ? 1 : -1) || []}
                                       getOptionLabel={(option) => option.state_name}
                                       // getOptionSelected={(option, value) => option.stateVal === value.stateVal}
                                       renderInput={(params) => (
                                          <TextField
                                             {...params}
                                             label="--State--"
                                             name="state_id"
                                             className="form-input"
                                          />
                                       )}
                                    />

                                 </FormControl>
                              </div>



                           </div>
                        </div>

                     </div>
                     {/* <div className="accordion-item">
                        <h2 className="accordion-header" id="headingTwo">
                           <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseStatus" aria-expanded="false" aria-controls="collapseStatus">
                              States
                           </button>
                        </h2>
                        <div id="collapseStatus" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                           <div className="accordion-body">

                           </div>
                        </div>
                     </div> */}
                     {/* ./accordion-item */}
                     <div className="accordion-item">
                        <h2 className="accordion-header" id="headingTwo">
                           <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseBidValue" aria-expanded="false" aria-controls="collapseBidValue">
                              GEM
                           </button>
                        </h2>
                        <div id="collapseBidValue" className="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                           <div className="accordion-body">

                           </div>
                        </div>
                     </div>
                     {/* ./accordion-item */}
                     <div className="text-center flex_btn flex-row footer_wrap">
                        <button className='mainButton ghostButton'>Filter</button>
                     </div>
                  </div>
               </div>
               {/* ./filterWarp */}

               <main style={{ paddingTop: 0 }}>
                  <div className="serachWrapper">
                     <div className="inner_flex">
                        <div className="section-title" >
                           <h1>Refine <span className="one-text">Search</span></h1>
                        </div>
                        <div className="d-flex">
                           <input type="text" placeholder="Enter Keyword" value={search} onChange={handleChangeSearch} />
                           <div className="search_icon"><button className='mainButton whiteButton'><SearchIcon /></button></div>
                        </div>
                     </div>
                  </div>
                  {/* ./serachWrapper */}


                  <div className="comList">
                     {props?.data?.map((item, index) => {
                        let stageName = stage.filter((val) => val.fld_id === item.stage).map(newVal => { return (newVal.stage_name) })
                        return (
                           <div key={index} className="comCard" onClick={() => navigate(ROUTES.RESULT_DETAILS)}>
                              <div className='topCard'>
                                 <div className="locationTex"><i className="fas fa-map-marker-alt"></i> {item?.location}</div>
                                 <div className="cilpBage"><i className="fas fa-calendar-alt me-1"></i>{item?.date}</div>
                              </div>
                              <div className='clientName'>{item?.tender_name}</div>
                              <div className='serviceName'><i className="fas fa-hotel me-2"></i> {item?.client_name}</div>
                              <div className='d-flex align-items-center'>
                                 <div className='bidDate'>
                                    <span>Admitted-Finance | L2</span>
                                 </div>
                                 <div className='bidNumber'><i className="fas fa-rupee-sign me-1"></i> Amount <span>{item?.amount}</span></div>
                                 <div className="btn_Text">{stageName}</div>
                              </div>
                           </div>
                        )
                     })}

                  </div>
                  {/* ./comList */}
               </main>
            </div>
         </div>
      </>
   )
}

export default RefineSearch
