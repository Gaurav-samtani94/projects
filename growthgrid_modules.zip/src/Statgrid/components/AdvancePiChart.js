// @ts-nocheck
import * as React from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import highchartsDrilldown from 'highcharts/modules/drilldown';

highchartsDrilldown(Highcharts);
function AdvancePiChart({ data }) {
  const [piChartData, setPiChartData] = React.useState([])

  const getAdvanceData = () => {
    if (data) {
      let newData = Object.entries(data)?.map(([key, value]) => ({
        name: key,
        y: value,
        drilldown: key
      }))
      setPiChartData(newData)
    }else{
      setPiChartData([])
    }

  }

  React.useEffect(()=>{
    getAdvanceData()
  },[data])


  const chartOptions = {
    chart: {
      type: 'column'
    },
    title: {
      text: '',
      align: 'left'
    },


    accessibility: {
      announceNewData: {
        enabled: true
      },
      point: {
        valueSuffix: '%'
      }
    },

    plotOptions: {
      series: {
        dataLabels: {
          enabled: true,
          format: '{point.name}: {point.y:.1f}%'
        }
      }
    },

    tooltip: {
      headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
      pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
    },

    series: [
      {
        name: 'Browsers',
        colorByPoint: true,
        data: piChartData,
      }
    ],
    drilldown: {
      series: [
        {
          name: 'Chrome',
          id: 'Chrome',
          // color: "#c6c6c6",
          data: [
            [
              'v97.0',
              36.89
            ],
            [
              'v96.0',
              18.16
            ],
            [
              'v95.0',
              0.54
            ],
          ]
        },
        {
          name: 'Safari',
          id: 'Safari',
          // color: "#c6c6c6",
          data: [
            [
              'v15.3',
              0.1
            ],
            [
              'v15.2',
              2.01
            ],
            [
              'v15.1',
              2.29
            ],
          ]
        },
        {
          name: 'Edge',
          id: 'Edge',
          // color: "#c6c6c6",
          data: [
            [
              'v97',
              6.62,
            ],
            [
              'v96',
              2.55,
            ],
            [
              'v95',
              0.15
            ]
          ]
        },
        {
          name: 'Firefox',
          id: 'Firefox',
          // color: "#c6c6c6",
          data: [
            [
              'v96.0',
              4.17
            ],
            [
              'v95.0',
              3.33
            ],
          ]
        }
      ]
    }
  };
  return <HighchartsReact highcharts={Highcharts} options={chartOptions} />;
}

export default AdvancePiChart;
