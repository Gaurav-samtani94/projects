import DurationFilterDropDown from 'Statgrid/components/UI/DurationFilterDropDown';
import { uniqueColors } from 'Statgrid/utils/Colors';
import { Divider } from 'antd';
import { Chart } from 'chart.js/auto';
import React, { useEffect, useState } from 'react'

const StateAndSectorDonutChart = ({id}) => {
    const [activeBids, setActiveBids] = useState('state')

    const [myDonutData, setMyDonutData] = useState([
        { "name": "Andhra Pradesh", "value": 45 },
        { "name": "Arunachal Pradesh", "value": 21 },
        { "name": "Assam", "value": 38 },
        { "name": "Bihar", "value": 50 },
        { "name": "Chhattisgarh", "value": 27 },
        { "name": "Goa", "value": 32 },
        { "name": "Gujarat", "value": 55 },
        { "name": "Haryana", "value": 47 },
        { "name": "Himachal Pradesh", "value": 36 },
        { "name": "Jharkhand", "value": 29 },
        { "name": "Karnataka", "value": 60 },
        { "name": "Kerala", "value": 58 },
        { "name": "Madhya Pradesh", "value": 53 },
        { "name": "Maharashtra", "value": 65 },
        { "name": "Manipur", "value": 24 },
    ])

    const handleConvertToSector = () => {
        setMyDonutData([{ "name": "Technology", "value": 45 },
        { "name": "Healthcare", "value": 32 },
        { "name": "Education", "value": 58 },
        { "name": "Finance", "value": 50 },
        { "name": "Agriculture", "value": 27 },
        { "name": "Tourism", "value": 39 },
        { "name": "Manufacturing", "value": 55 },
        { "name": "Transportation", "value": 47 },
        { "name": "Construction", "value": 36 },
        { "name": "Retail", "value": 29 },
        { "name": "Entertainment", "value": 62 },
        { "name": "Energy", "value": 58 },
        { "name": "Telecommunications", "value": 53 },
        { "name": "Real Estate", "value": 65 },
        { "name": "Textiles", "value": 44 },
        { "name": "Automobile", "value": 39 },
        { "name": "Hospitality", "value": 45 },])
    }
    
    const handleConvertToState = () => {
        setMyDonutData([
            { "name": "Andhra Pradesh", "value": 45 },
            { "name": "Arunachal Pradesh", "value": 21 },
            { "name": "Assam", "value": 38 },
            { "name": "Bihar", "value": 50 },
            { "name": "Chhattisgarh", "value": 27 },
            { "name": "Goa", "value": 32 },
            { "name": "Gujarat", "value": 55 },
            { "name": "Haryana", "value": 47 },
            { "name": "Himachal Pradesh", "value": 36 },
            { "name": "Jharkhand", "value": 29 },
            { "name": "Karnataka", "value": 60 },
            { "name": "Kerala", "value": 58 },
            { "name": "Madhya Pradesh", "value": 53 },
            { "name": "Maharashtra", "value": 65 },
            { "name": "Manipur", "value": 24 },
        ])
    }

    useEffect(() => {
        const dogHuntData = {
            labels: myDonutData.map((item) => item.name),
            datasets: [{
                data: myDonutData.map((item) => item.value),
                backgroundColor: uniqueColors.slice(0, myDonutData.length)
            }],
        };

        const dogHuntDoughnutCanvas = document.getElementById(id);

        if (dogHuntDoughnutCanvas) {
            // @ts-ignore
            const ctx = dogHuntDoughnutCanvas.getContext('2d');
            Chart.getChart(ctx)?.destroy();
            new Chart(ctx, {
                type: 'polarArea',
                data: dogHuntData,
                options: {
                    responsive: true,
                    plugins: {
                        tooltip: {
                            callbacks: {
                                title: (tooltipItem, data) => {
                                    return tooltipItem?.label;
                                },
                            },
                        },
                        legend: {
                            display: false,
                            position: 'bottom',
                            
                        },
                    },
                },
            });
        }
    }, [myDonutData]);

    return (
        <>
            <div className="d-flex gap-3 align-items-center justify-content-end">
                <button onClick={() => { setActiveBids('state'); handleConvertToState() }} className={`tabs-btn ${activeBids === 'state' ? "active" : ""}`}>State Bids</button>
                <button onClick={() => { setActiveBids('sector'); handleConvertToSector() }} className={`tabs-btn ${activeBids === 'sector' ? "active" : ""}`}>Sector Bids</button>
                <Divider type='vertical' className='bg-black border-black' style={{ height: "30px", borderColor: "gray" }} />
                <DurationFilterDropDown />
            </div>
            <div className="dashboard_tender_chart p-lg-5">
                <canvas id={id}></canvas>
            </div>
        </>
    )
}

export default StateAndSectorDonutChart