import { ArrowDownOutlined, CalendarOutlined, DownOutlined } from '@ant-design/icons';
import { Button, DatePicker, Dropdown, Input, Space } from 'antd'
import dayjs from 'dayjs';
import React, { useState } from 'react'

const DurationFilterDropDown = () => {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false)
    const dateFormat = 'YYYY/MM/DD';
    const items = [
        {
            key: '1',
            label: (
                <button className='duration-dropdown-items'>
                    Last Week
                </button>
            ),
        },
        {
            key: '2',
            label: (
                <button className='duration-dropdown-items'>
                    Last Month
                </button>
            ),
        },
        {
            key: '3',
            label: (
                <button className='duration-dropdown-items active'>
                    Last 6 Month
                </button>
            ),
        },
        {
            key: '4',
            label: (
                <button className='duration-dropdown-items'>
                    Last Year
                </button>
            ),
        },
        {
            key: '5',
            label: (
                <div>
                    <span className='text-secondary'>Custom</span>
                    <DatePicker
                        // defaultValue={dayjs('2015/01/01', dateFormat)}
                        placeholder='From Date'
                        format={dateFormat}
                        className='w-100 d-block mb-2 brand-outline-input'
                    />
                    <DatePicker
                        // defaultValue={dayjs('01/01/2015', dateFormat)}
                        placeholder='To Date'
                        format={dateFormat}
                        className='w-100 d-block mb-2 brand-outline-input'
                    />
                </div>
            ),
        },
    ];
    return (
        <Dropdown
            menu={{ items }}
            placement="bottomRight"
            trigger={['click']}
            open={isDropdownOpen} >
            <Button className='brand-outlined-btn' size='large' onClick={() => setIsDropdownOpen(!isDropdownOpen)}>
                <Space>
                    Last 6 Month
                    <DownOutlined />
                </Space>
            </Button>
        </Dropdown>
    )
}

export default DurationFilterDropDown