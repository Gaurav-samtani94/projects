import { Button, Input } from 'antd'
import React, { useState } from 'react'
import TenderSearchFilter from '../TenderSearchFilter/TenderSearchFilter'

const SearchBar = () => {
  const [showDrawer, setShowDrawer] = useState(false)
  return (
    <>
      <div className="search_bar">
        {/* <Input placeholder="Search for bids or sector..." type='search' className='search_bar_input' /> */}
        <input placeholder="Search for bids or sector..." type='text' className='search_bar_input' />
        <div className="d-flex gap-2">
          <Button size='large' shape='round' className='brand-ghost-btn'>Search</Button>
          <Button size='large' shape="round" className='filter-btn d-flex align-items-center gap-2' onClick={() => setShowDrawer(!showDrawer)}>
            <svg width="18" height="18" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M3 4H13.226M4.70434 7.12462H11.5217M6.74954 10.2492H9.47648" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
            Filter
          </Button>
        </div>

      </div>
      <TenderSearchFilter showDrawer={showDrawer} setShowDrawer={setShowDrawer} />
    </>
  )
}

export default SearchBar