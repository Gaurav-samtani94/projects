// @ts-nocheck
import * as React from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
function AccessibleLineChart({data}) {

  const [piChartData, setPiChartData] = React.useState([])

  const getAdvanceData = () => {
    if (data) {
      const modifiedArray = data?.map(obj => {
        return { 
          name: obj.name,
          data: obj.data.map(str => parseInt(str))
        };
      });
      setPiChartData(modifiedArray)
    }else{
      setPiChartData([])
    }

  }

  React.useEffect(()=>{
    getAdvanceData()
  },[data])

  const chartOptions = {
    chart: {
      type: 'spline'
    },
    title: {
      text: ''
    },
    subtitle: {
      text: ''
    },
    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      accessibility: {
        description: ''
      }
    },
    yAxis: {
      title: {
        text: ''
      },
      labels: {
        formatter: function () {
          return this.value;
        }
      }
    },
    tooltip: {
      crosshairs: true,
      shared: true
    },
    plotOptions: {
      spline: {
        marker: {
          radius: 4,
          lineColor: '#fff',
          lineWidth: 1
        }
      }
    },
    series:piChartData
  };
  return <HighchartsReact highcharts={Highcharts} options={chartOptions} />;
}

export default AccessibleLineChart;
