// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Checkbox, Collapse, Button, Segmented, Radio, DatePicker, Space, Select, Input, Modal, Row, Col, Form } from 'antd'
import { useSelector } from 'react-redux';
import { statGridFilterApi } from 'Services/statgrid/filter/StatGridFilterApi';
import { StatStateTypeAction } from 'Redux/actions/common/DropdownAction';
import { useDispatch } from 'react-redux';
import { statFilterAction } from 'Redux/actions/statgrid/statFilterAction';
import { Down, Search } from '@icon-park/react';


function TenderSearchFilter({ showDrawer, setShowDrawer }) {

  const handleClose = () => {
    setShowDrawer(false)
  };

  const onActive = (key) => {
    console.log(key);
  };

  const [currentTab, setCurrentTab] = useState('Basic Filter')
  const [stateVal, setStateVal] = useState([])
  const [cityVal, setCityVal] = useState([])
  const [value, setValue] = useState("All");
  const { StatClient } = useSelector((state) => state?.statDropdownCalVal)
  const { StatFunding } = useSelector((state) => state?.statDropdownCalVal)
  const { StatTenderCat } = useSelector((state) => state?.statDropdownCalVal)
  const { StatColuntry } = useSelector((state) => state?.statDropdownCalVal)
  const { StatSector } = useSelector((state) => state?.statDropdownCalVal)
  const { statFilterValues } = useSelector((state => state.StatFilter))
  const dispatch = useDispatch()
  const [showAllCountries, setShowAllCountries] = useState(false);
  const [showAllSector, setShowAllSector] = useState(false);
  const initialCountryCount = 100;


  const [filter, setFilter] = useState({

    client_id: '',
    funding_id: "",
    category_id: "",
    country_id: "",
    state_id: "",
    city_it: "",
    sector_id: ""

  })


  const getStateDrpValue = async () => {
    try {
      const PayloadData = new URLSearchParams();
      const countryId = parseInt(filter.country_id)
      PayloadData.append('country_id', countryId);
      const response = await statGridFilterApi?.statStateList(PayloadData);
      if (response?.data?.status === "1") {
        const newData = response?.data?.data?.filter(val => val?.state_name !== 'NA');
        dispatch(StatStateTypeAction(response?.data?.data))
        setStateVal(newData);
      } else {
        setStateVal([]);
      }
    } catch (error) {
      console.log(error);
      setStateVal([]);
    }
  };


  const getCityDropValue = async () => {
    try {
      const PayloadData = new URLSearchParams();
      const stateId = parseInt(filter.state_id)
      PayloadData.append('state_id', stateId);
      const response = await statGridFilterApi?.statCityList(PayloadData);
      if (response?.data?.status === "1") {
        console.log(response?.data?.data);
        const newCityData = response?.data?.data?.filter(val => val?.state_name !== 'NA');
        dispatch(StatStateTypeAction(response?.data?.data), "citydata")
        setCityVal(newCityData)
      } else {
        setCityVal([]);
      }
    } catch (error) {
      console.log(error);
      setCityVal([]);
    }
  };

  useEffect(() => {
    getStateDrpValue();
    getCityDropValue()
  }, [filter?.country_id, filter?.state_id]);

  const handleSelectChange = (name, value) => {
    setFilter((old) => ({
      ...old,
      [name]: value
    }))
    console.log(value, "value");
  }
  const onChange = (e) => {
    console.log('radio checked', e.target.value);
    setValue(e.target.value);
  };

  const toggleShowAllCountries = () => {
    setShowAllCountries(!showAllCountries);
  };
  const toggleShowAllSector = () => {
    setShowAllSector(!showAllSector);
  };


  const filterStatData = () => {
    let obj = {
      ...statFilterValues,
      client_id: filter?.client_id,
      funding_id: filter?.funding_id,
      category_id: filter?.category_id,
      country_id: filter?.country_id,
      state_id: filter?.state_id,
      city_it: filter?.city_id,
      sector_id: filter?.sector_id,
      page: 1,
      limit: 25
    }
    dispatch(statFilterAction.statFilterUpdateAllKeys(obj))
    handleClose()
  }
  const handleReset = () => {
    setFilter({
      client_id: '',
      funding_id: '',
      category_id: '',
      country_id: '',
      state_id: '',
      city_id: '',
      sector_id: '',
    });


    let obj = {
      ...statFilterValues,
      client_id: '',
      funding_id: "",
      category_id: "",
      country_id: "",
      state_id: "",
      city_it: "",
      sector_id: "",
      page: 1,
      limit: 25
    }
    dispatch(statFilterAction?.staFilterResetKeys(obj))
  }

  const items = [
    {
      key: 1,
      label: "Country",
      extra: <Down theme="outline" size="30" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
      children: (
        <div className="tenderDrawer_content">
          <div className="d-flex gap-4 align-items-center mb-4">
            <Input
              placeholder="Search for tenders and companies and etc..."
              prefix={<Search theme="outline" size="24" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />}
              className="g-search-input w-fit rounded-pill d-none d-lg-flex"
            />
            <div className="d-flex gap-3 align-item-center w-50 flex-grow-1 ">
              <button className="selectAllBtn">Select all</button>
              <button className="resetBtn">Reset</button>
              <button className='tenderAll_btn' onClick={toggleShowAllCountries}>
                {showAllCountries ? 'See Less' : 'See All'}
              </button>
            </div>
          </div>

          <div className="filter_fields">
            {StatColuntry?.slice(0, showAllCountries ? StatColuntry.length : initialCountryCount).map((item, index) => (
              <label key={index} className='tenderDrawer_checkbox'>
                <span className="label__text">{item?.country_name}</span>
                <Checkbox
                  value={item.country_id} // Pass country_id as value
                  onChange={(e) => handleSelectChange('country_id', e.target.checked ? e.target.value : '')} // Handle checkbox change
                />
              </label>
            ))}
          </div>
        </div>
      )
    }

    ,
    {
      key: 2,
      label: "States",
      extra: <Down theme="outline" size="30" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
      children:
        <div className="tenderDrawer_content">
          <div className="d-flex gap-4 align-items-center mb-4">
            <Input
              placeholder="Search for tenders and companies and etc..."
              prefix={<Search theme="outline" size="24" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />}
              className="g-search-input w-fit rounded-pill d-none d-lg-flex"
            />
            <div className="d-flex gap-3 align-item-center w-50 flex-grow-1 ">
              <button className="selectAllBtn">Select all</button>
              <button className="resetBtn">Reset</button>
              <button className='tenderAll_btn' onClick={toggleShowAllCountries}>
                {showAllCountries ? 'See Less' : 'See All'}
              </button>
            </div>
          </div>
          <div className="filter_fields">
            {stateVal?.map((item, index) => (
              <label key={index} className='tenderDrawer_checkbox'>
                <span className="label__text">{item?.state_name}</span>
                <Checkbox
                  value={item.state_id} // Pass state_id as value
                  onChange={(e) => handleSelectChange('state_id', e.target.checked ? e.target.value : '')} // Handle checkbox change
                />
              </label>
            ))}
          </div>
        </div>
    },
    {
      key: 3,
      label: "City",
      extra: <Down theme="outline" size="30" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
      children:
        <div className="tenderDrawer_content">
          <div className="d-flex gap-4 align-items-center mb-4">
            <Input
              placeholder="Search for tenders and companies and etc..."
              prefix={<Search theme="outline" size="24" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />}
              className="g-search-input w-fit rounded-pill d-none d-lg-flex"
            />
            <div className="d-flex gap-3 align-item-center w-50 flex-grow-1 ">
              <button className="selectAllBtn">Select all</button>
              <button className="resetBtn">Reset</button>
              <button className='tenderAll_btn' onClick={toggleShowAllCountries}>
                {showAllCountries ? 'See Less' : 'See All'}
              </button>
            </div>
          </div>
          <div className="filter_fields">
            {cityVal?.map((item, index) => (
              <label key={index} className='tenderDrawer_checkbox'>
                <span className="label__text">{item?.city_name}</span>
                <Checkbox
                  value={item.city_id} // Pass state_id as value
                  onChange={(e) => handleSelectChange('city_id', e.target.checked ? e.target.value : '')} // Handle checkbox change
                />
              </label>
            ))}
          </div>
        </div>
    },
    {
      key: 4,
      label: "Sector",
      extra: <Down theme="outline" size="30" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
      children:
        <div className="tenderDrawer_content">
          <div className="d-flex gap-4 align-items-center mb-4">
            <Input
              placeholder="Search for tenders and companies and etc..."
              prefix={<Search theme="outline" size="24" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />}
              className="g-search-input w-fit rounded-pill d-none d-lg-flex"
            />
            <div className="d-flex gap-3 align-item-center w-50 flex-grow-1 ">
              <button className="selectAllBtn">Select all</button>
              <button className="resetBtn">Reset</button>
              <button className='tenderAll_btn' onClick={toggleShowAllSector}>
                {showAllCountries ? 'See Less' : 'See All'}
              </button>
            </div>
          </div>
          <div className="filter_fields">
            {StatSector?.slice(0, showAllSector ? StatSector?.length : 3).map((item, index) => (
              <label key={index} className='tenderDrawer_checkbox'>
                <span className="label__text">{item?.sectName}</span>
                <Checkbox
                  value={item.fld_id} // Pass state_id as value
                  onChange={(e) => handleSelectChange('sector_id', e.target.checked ? e.target.value : '')} // Handle checkbox change
                />
              </label>
            ))}
          </div>
        </div>
    },
    {
      key: 5,
      label: "Other",
      extra: <Down theme="outline" size="30" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
      children:
        <div className="tenderDrawer_content">
          <Row gutter={20}>

            <Col span={6}>
              <Form.Item
                name=""
                label=""
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Select
                  suffixIcon={<Down theme="outline" size="18" strokeWidth={3} fill="#9b9b9b" />}
                  placeholder="Financial Year"
                  className='w-100'
                  options={[
                    {
                      value: '2024-2025',
                      label: '2024-2025',
                    },
                    {
                      value: '2023-2024',
                      label: '2023-2024',
                    },
                  ]} />
              </Form.Item>
            </Col>

            <Col span={6}>
              <Form.Item
                name=""
                label=""
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Select
                  suffixIcon={<Down theme="outline" size="18" strokeWidth={3} fill="#9b9b9b" />}
                  placeholder="Category Type"
                  className='w-100'
                  onChange={(value) => handleSelectChange('category_id', value)}
                  // value={parseInt(filter?.category_id) || ''}
                  options={StatTenderCat?.map((item, index) => {
                    return {
                      value: item?.fld_id,
                      label: item?.field_name
                    }
                  })} />
              </Form.Item>
            </Col>

            <Col span={6}>
              <Form.Item
                name=""
                label=""
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Select
                  suffixIcon={<Down theme="outline" size="18" strokeWidth={3} fill="#9b9b9b" />}
                  placeholder="Founding Agencies"
                  className='w-100'
                  onChange={(value) => handleSelectChange('funding_id', value)}
                  // value={parseInt(filter?.funding_id) || ''}
                  options={StatFunding.map((item, index) => {
                    return {
                      value: item?.id,
                      label: item?.funding_org
                    }
                  })} />
              </Form.Item>
            </Col>

            <Col span={6}>
              <Form.Item
                name=""
                label=""
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Select
                  suffixIcon={<Down theme="outline" size="18" strokeWidth={3} fill="#9b9b9b" />}
                  placeholder="Authority"
                  className='w-100'
                  onChange={(value) => handleSelectChange('client_id', value)}
                  // value={parseInt(filter?.client_id) || ''}
                  options={StatClient.map((item, index) => {
                    return {
                      value: item?.fld_id,
                      label: item?.client_name
                    }
                  })} />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                name=""
                label=""
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Input placeholder='Govt. Id' />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                name=""
                label=""
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Input placeholder='Tender Id' />
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                name=""
                label="Tender Documents"
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Radio.Group defaultValue="a">
                  <Space direction="vertical">
                    <Radio className='flex-grow-1' value="a">All</Radio>
                    <Radio className='flex-grow-1' value="b">Available</Radio>
                    <Radio className='flex-grow-1' value="c">Not Available</Radio>
                  </Space>
                </Radio.Group>
              </Form.Item>
            </Col>

            <Col span={12}>
              <Form.Item
                name=""
                label="Latest Activity"
                rules={[
                  {
                    required: true,
                  },
                ]}
              >
                <Radio.Group defaultValue="updates">
                  <Space direction="vertical">
                    <Radio className='flex-grow-1' value="Live Tenders">Live Tenders</Radio>
                    <Radio className='flex-grow-1' value="updates">Updates</Radio>
                  </Space>
                </Radio.Group>
              </Form.Item>
            </Col>

          </Row>
        </div>
    },
  ]

  const AdvancedFilters = [
    {
      key: 1,
      label: "Publication Date:",
      extra: <Down theme="outline" size="30" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
      children:
        <div className="tenderDrawer_content">
          <Form.Item
            name=""
            label=""
            rules={[
              {
                required: true,
              },
            ]}
          >
            <Radio.Group className="d-flex gap-5" onChange={onChange} value={value}>
              <Radio value={"All"}>All</Radio>
              <Radio value={"Today"}>Today</Radio>
              <Radio value={"Yesterday"}>Yesterday</Radio>
              <Radio value={"Last 7 Days"}>Last 7 Days</Radio>
              <Radio value={"Custom"}>Custom</Radio>
            </Radio.Group>
          </Form.Item>

          <Form.Item
            name=""
            label=""
            rules={[
              {
                required: true,
              },
            ]}
          >
            <DatePicker.RangePicker className='w-50' />
          </Form.Item>

        </div>
    },
    {
      key: 2,
      label: "Tender Value",
      extra: <Down theme="outline" size="30" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
      children:
        <div className="tenderDrawer_content">
          <Form.Item
            name=""
            label=""
            rules={[
              {
                required: true,
              },
            ]}
          >
            <Radio.Group className="d-flex gap-5" onChange={onChange} value={value}>
              <Radio value={"All"}>All</Radio>
              <Radio value={"Today"}>Below 1 Lac</Radio>
              <Radio value={"Yesterday"}>1 Lac to 1 Cr</Radio>
              <Radio value={"Last 7 Days"}>1 Cr to 10 Cr</Radio>
              <Radio value={"Custom"}>Custom</Radio>
            </Radio.Group>
          </Form.Item>

          <Form.Item
            name=""
            label=""
            rules={[
              {
                required: true,
              },
            ]}
          >
            <Space.Compact>
              <Select suffixIcon={<Down theme="outline" size="18" strokeWidth={3} fill="#9b9b9b" />}
                placeholder="Operator"
                options={[
                  {
                    value: '<=',
                    label: '<=',
                  },
                  {
                    value: '>=',
                    label: '>=',
                  },
                ]} />
              <Input defaultValue="" placeholder='Enter Amount' />
              <Select suffixIcon={<Down theme="outline" size="18" strokeWidth={3} fill="#9b9b9b" />}
                placeholder="Denomination"
                options={[
                  {
                    value: 'Hundred',
                    label: 'Hundred',
                  },
                  {
                    value: 'Thousand',
                    label: 'Thousand',
                  },
                  {
                    value: 'Lakhs',
                    label: 'Lakhs',
                  },
                  {
                    value: 'Crores',
                    label: 'Crores',
                  },
                  {
                    value: 'Million',
                    label: 'Million',
                  },
                  {
                    value: 'Thousand',
                    label: 'Thousand',
                  },
                  {
                    value: 'Billion',
                    label: 'Billion',
                  },
                  {
                    value: 'Trillion',
                    label: 'Trillion',
                  },
                ]} />
            </Space.Compact>
          </Form.Item>

          {/* <DatePicker.RangePicker className='mt-4 w-50' /> */}
        </div>
    },
  ]

  return (
    <>
      <Modal
        title={null}
        centered
        open={showDrawer}
        footer={null}
        onCancel={handleClose}
        className='filter-drawer'
        width={1400}
      >

        <div className="filter__header">
          <div className="d-flex align-items-center gap-5">
            {/* <h4>Filters</h4> */}
            <Segmented
              size='large'
              options={['Basic Filter', 'Advanced Filter']}
              value={currentTab}
              onChange={(value) => {
                setCurrentTab(value)
              }}
            />
          </div>
          <div className="d-flex justify-content-end gap-2">
            <Button className='reset-btn' size='large' shape='round' onClick={handleReset}>Reset</Button>
            <Button className='brand-ghost-btn' size='large' shape='round' onClick={filterStatData}>Apply</Button>
          </div>
        </div>

        {currentTab === "Basic Filter" &&
          <Form
            layout="vertical"
          >
            <Collapse defaultActiveKey={['1', '2', '3', '4', '5']} size='large' ghost items={items} onChange={onActive} />
          </Form>

        }
        {currentTab === "Advanced Filter" &&
          <Collapse defaultActiveKey={['1', '2',]} size='large' items={AdvancedFilters} onChange={onActive} />
        }

      </Modal>

    </>

  )
}

export default TenderSearchFilter