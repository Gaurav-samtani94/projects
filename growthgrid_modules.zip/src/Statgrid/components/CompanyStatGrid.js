// @ts-nocheck
import React, { useState, useEffect } from "react";
import dayjs from "dayjs";
import Tooltip from "@mui/material/Tooltip";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { CompanyService } from "Services/statgrid/CompanyServices";
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'
import { FilterCompanyAction } from "Redux/actions/tendergrid/FilterCompanyAction";
import EmptyBox from '../../assests/img/empty-box.png'
import TablePagination from "@mui/material/TablePagination";

import useFilters from "customHook/useFilters";
import { Link } from 'react-router-dom';
import _ from "lodash";
import CompanyPopup from "./CompanyPopup";
import ROUTES from "Constants/Routes";

export default function CompanyStatGrid({ setFilterApi, filters }) {
    const { companyList } = useSelector((state) => state.companyData);
    // const nettingData = useSelector((state) => state.nettingData)
    const render = [1, 2, 3, 4, 5]
    const [open, setOpen] = useState(false)
    const [isInitialRender, setIsInitialRender] = useState(true);
    const navigate = useNavigate()
    const [page, setPage] = React.useState(filters?.page_number ? filters?.page_number : 0);
    const [rowsPerPage, setRowsPerPage] = useState(filters?.limit ? filters?.limit : 50);
    const [skeletonTime, setSkeletonTime] = useState(true);
    const dispatch = useDispatch()
    const [isLock, setIsLoack] = useState(false);


    const recalledLatestTenderApi = () => {

        setSkeletonTime(true)
        let no_bid_str = filters.no_bid
        let no_bid_val;
        if (no_bid_str?.length === 1) {
            no_bid_val = [no_bid_str]
        } else if (no_bid_str.length > 2) {
            no_bid_val = no_bid_str.split(',')
        } else {
            no_bid_val = []
        }
        const formdata = new FormData
        formdata.append('limit', filters?.limit ? parseInt(filters?.limit) : 50)
        formdata.append('page_number', filters?.page_number ? parseInt(filters?.page_number) : 0)
        formdata.append("user_id", localStorage.getItem('user_id'))
        formdata.append("tender_keyword", filters?.tender_keyword)
        formdata.append("country_id", filters?.country_id)
        formdata.append("state_id", filters?.state_id)
        formdata.append('no_bid', no_bid_val)
        formdata.append('fin_year', filters?.financial_year || '2023-2024')
        formdata.append("funding_agency_id", filters?.funding_agency_id)
        formdata.append("estm_value", filters?.estm_value)
        formdata.append('amnt_custrange_operator', filters?.amnt_custrange_operator)
        formdata.append('amnt_custrange_amount', filters?.amnt_custrange_amount)
        formdata.append('custrange_denomination', filters?.custrange_denomination)
        formdata.append('lock_unlock', parseInt(filters?.lock_unlock))

        try {
            CompanyService.getAllCompetitor(formdata).then(
                (res) => {
                    if (res?.data?.status === 1) {
                        setTimeout(() => {
                            setSkeletonTime(false)
                        }, 2000);

                        dispatch(FilterCompanyAction(res?.data?.data));
                    } else {
                        console.log("no record found")
                    }
                }
            );
        } catch {
            console.log("error");
        }

    }

    useEffect(() => {
        if (!_.isEmpty(filters)) {
            recalledLatestTenderApi()
            setRowsPerPage(parseInt(filters?.limit))
            setPage(parseInt(filters?.page_number))
        }
    }, [filters])



    const handleClickNavigate = (event, id) => {
        event.preventDefault();
        setOpen(true)

    };


    const handleChangePage = (event, newPage) => {
        setPage(newPage);
        const obj = {
            ...filters,
            page_number: parseInt(newPage),
            limit: rowsPerPage
        }
        setFilterApi(obj)
        window.scrollTo({
            top: 0,
        });
    };

    const handleChangeRowsPerPage = (event) => {
        let newLimit = parseInt(event.target.value, 10)
        if (newLimit < parseInt(rowsPerPage)) {
            const obj = {
                ...filters,
                page_number: 0,
                limit: parseInt(event.target.value, 10)
            }
            setFilterApi(obj)
            setPage(0);
            window.scrollTo({
                top: 0,
            });
        } else {
            const obj = {
                ...filters,
                page_number: 0,
                limit: parseInt(event.target.value, 10)
            }
            setFilterApi(obj)
            setPage(0);
        }

    };


    return (
        <>
            {companyList?.data?.length !== 0 ?
                <div className="comList">
                    {
                        !skeletonTime ?
                            <>
                                {companyList?.data?.map((item, index) => {
                                    // let date = dayjs(item.last_bid).format("DD MM YYYY");
                                   
                                    let date = item.last_bid ? dayjs(item.last_bid).format("DD MMM YYYY") : "Not Available";
                                    return (
                                        <>
                                            <Link key={index} className="comCard" to={ROUTES.COMPANY_DETAILS.replace(':id', item.fld_id)} >
                                                <Tooltip title="Unlock Company Perks with ">
                                                    <div className={item?.lock_unlcok === 0 ? "btnLock locked" : "btnLock unlocked"} onClick={handleClickNavigate} >
                                                        <span className="lock"></span>
                                                    </div>
                                                </Tooltip>
                                                <div className="locationTex">
                                                    <i className="fas fa-map-marker-alt"></i>
                                                    {item?.comp_address}
                                                </div>
                                                <div className="clientName">{item.bidder_name}</div>
                                                <div className="serviceName">
                                                    Engineering Consutancy Services
                                                </div>
                                                <div className="d-flex">
                                                    <div className="bidDate">
                                                        <span className="sub">
                                                            <i className="fas fa-calendar-alt me-2"></i>{" "}
                                                            Last bid on
                                                        </span>
                                                        <span>{date}</span>
                                                    </div>
                                                    <div className="bidNumber">
                                                        Number of Bids <span>{item?.no_bid}</span>
                                                    </div>
                                                </div>
                                            </Link>

                                        </>
                                    );
                                })}
                            </>
                            :
                            <>
                                {render.map((item, index) => {
                                    return (
                                        <div key={index} className="comCard">
                                            <div className="btnLock" style={{ background: "transparent" }} >
                                                <Skeleton width={35} height={35} circle={true} />
                                            </div>
                                            <div className="locationTex">
                                                <Skeleton width={370} height={30} />
                                            </div>
                                            <div className="clientName">
                                                <Skeleton height={15} />
                                            </div>
                                            <div className="serviceName">
                                                <Skeleton height={15} />
                                            </div>
                                            <div className="d-flex">
                                                <div className="bidDate">
                                                    <span className="sub">
                                                        <Skeleton width={98} height={15} />
                                                    </span>
                                                    <span>
                                                        <Skeleton width={80} height={15} />
                                                    </span>
                                                </div>
                                                <div className="bidNumber">
                                                    <Skeleton width={98} height={15} />{" "}
                                                    <span>
                                                        <Skeleton width={40} height={15} />
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                })}
                            </>

                    }

                </div>
                :
                <div className="spinerWrap">
                    <div>
                        <img src={EmptyBox} width={120} style={{ margin: 'auto', display: 'block' }} />
                        <div>
                            <p style={{ textAlign: "center", fontSize: '18px', marginTop: '15px' }}>
                                No record found
                            </p>
                        </div>
                    </div>
                </div>
            }
            <TablePagination
                rowsPerPageOptions={[50, 100, 250, 500]}
                component="div"
                count={companyList?.count_filtered}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
            <CompanyPopup show={open} onHide={() => setOpen(false)} />
        </>
    );
}



