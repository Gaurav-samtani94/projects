import React, {useState} from 'react'
import {Drawer} from 'antd';
function CalendarSidebar({openDrawer, setOpenDrawer}) {
    
    // const [open, setOpen] = useState(false);
    // const showDrawer = () => {
    //   setOpen(true);
    // };
    const handleClose = () => {
        setOpenDrawer(false);
    };
  
  return (

    <Drawer title="Calendar Details" onClose={handleClose} open={openDrawer} width={550}>
      Some Content Here.....
  </Drawer>
  )
}

export default CalendarSidebar