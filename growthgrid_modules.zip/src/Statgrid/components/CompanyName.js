// @ts-nocheck
import React from 'react'
import '../../assests/tenderStatCommonCss/company/companyList.css'
import "../../assests/tenderStatCommonCss/company/companyDetails.css"
import SolidGuage from './SolidGuage';
import PiChart from './PiChart';
import AreaSplineChart from './AreaSplineChart';
import MoreHorizOutlinedIcon from '@mui/icons-material/MoreHorizOutlined';

const CompanyName = (props) => {
   console.log(props?.companyDetailsData?.top_competitor, 'company name')
   var renderTopComp = Object.entries(props?.companyDetailsData?.top_competitor ? props?.companyDetailsData?.top_competitor : {}).map(([key, value], index) => {
      return (
         <div className="OverviewList" key={key}>
            <span className="number-table">{index + 1}</span>
            <span className='top-competitor-middle'> {key}</span>
            <span className='top-competitor-middle'> {value}</span>
         </div>
      )
   }

   )
   return (
      <>
         <div className="company_details">
            <div className='cardFiltHead'>
               <div className="filText">All Time</div>
               <div className="endFlex">
                  <div className="cd_btnGroup">
                     <a href="javascript:void(0);" className="statsButton active" aria-current="page">All Time</a>
                     <a href="javascript:void(0);" className="statsButton">Year</a>
                     <a href="javascript:void(0);" className="statsButton">Month</a>
                  </div>
                  <div className="input-daterange position-relative">
                     <div className="input-group" id="input-daterange">
                        <input type="date" className="form-control input-new text-start" placeholder="From date" />
                        <div className="input-group-addon mx-2 text-greyDark align-self-center"><i className="fas fa-angle-double-right"></i></div>
                        <input type="date" className="form-control input-new text-start" placeholder="To date" />
                     </div>
                  </div>
               </div>
               {/* ./endFlex */}
            </div>
            {/* ./cardFiltHead */}
            <div className="row mt-4">
               <div className="col-md-3">
                  <div className="comCard">
                     <div className='cardFiltHead'>
                        <b className="text-dark">Number of Bids</b>
                        <button className="linkButton" onClick={() => props.handleTab(2)}><MoreHorizOutlinedIcon fontSize='inherit' /></button>
                     </div>

                     <div className="row mt-4 align-items-center">
                        <div className="col-6">
                           <div className="countsNumber">
                              Total Bids <span>{props?.companyDetailsData?.no_of_bids?.total_bid === null ? 0 : props?.companyDetailsData?.no_of_bids?.total_bid}</span>
                           </div>
                           <hr />
                           <div className="countsNumber">
                              Winning Bids (L1) <span>{props?.companyDetailsData?.no_of_bids?.total_won === null ? 0 : props?.companyDetailsData?.no_of_bids?.total_won}</span>
                           </div>
                        </div>
                        <div className="col-6 text-end">
                           <SolidGuage />
                        </div>
                     </div>
                  </div>
               </div>
               <div className="col-md-3">
                  <div className="comCard">
                     <div className='cardFiltHead'>
                        <b className="text-dark">Total Bid Amount</b>
                        <button className="linkButton"><MoreHorizOutlinedIcon fontSize='inherit' /></button>
                     </div>

                     <div className="row mt-4 align-items-center">
                        <div className="col-6">
                           <div className="countsNumber">
                              Total Amount  <span>{props?.companyDetailsData?.total_amount?.total_bid_amount === null ? 0 : props?.companyDetailsData?.total_amount?.total_bid_amount}</span>
                           </div>
                           <hr />
                           <div className="countsNumber">
                              Amount won (L1) <span>{props?.companyDetailsData?.total_amount?.total_amount_won === null ? 0 : props?.companyDetailsData?.total_amount?.total_amount_won}</span>
                           </div>
                        </div>
                        <div className="col-6 text-end">
                           <SolidGuage />
                        </div>
                     </div>
                  </div>
               </div>
               <div className="col-md-3">
                  <div className="comCard">
                     <div className='cardFiltHead'>
                        <b className="text-dark">Organizations Bid</b>
                        <button className="linkButton"><MoreHorizOutlinedIcon fontSize='inherit' /></button>
                     </div>

                     <div className="row mt-4 align-items-center">
                        <div className="col-6">
                           <div className="countsNumber">
                              Organization bid <span>{props?.companyDetailsData?.org_bid?.org_bid_comp === null ? 0 : props?.companyDetailsData?.org_bid?.org_bid_comp}</span>
                           </div>
                           <hr />
                           <div className="countsNumber">
                              Common Orgs <span>{props?.companyDetailsData?.org_bid?.common_org === null ? 0 : props?.companyDetailsData?.org_bid?.common_org}</span>
                           </div>
                        </div>
                        <div className="col-6 text-end">
                           <SolidGuage />
                        </div>
                     </div>
                  </div>
               </div>
               <div className="col-md-3">
                  <div className="comCard">
                     <div className='cardFiltHead'>
                        <b className="text-dark">Company</b>
                        <button className="linkButton"><MoreHorizOutlinedIcon fontSize='inherit' /></button>
                     </div>

                     <div className="row mt-4 align-items-center">
                        <div className="col-6">
                           <div className="countsNumber">
                              No. of competitors <span>{props?.companyDetailsData?.comp?.no_of_comp === null ? 0 : props?.companyDetailsData?.comp?.no_of_comp}</span>
                           </div>
                           <hr />
                           <div className="countsNumber">
                              No. of contacts <span>{props?.companyDetailsData?.comp?.no_of_contract === null ? 0 : props?.companyDetailsData?.comp?.no_of_contract}</span>
                           </div>
                        </div>
                        <div className="col-6 text-end">
                           <SolidGuage />
                        </div>
                     </div>
                  </div>
               </div>
            </div>

            <div className="row mt-5">
               <div className="col-md-4">
                  <div className="card h-100">
                     <div className="card-title">
                        <h1>Overview</h1>
                     </div>
                     <div className="card-body">
                        <div className="countsNumber" style={{ marginTop: "30px" }}>
                           Location <span>{props?.companyDetailsData?.overview?.Location}</span>
                        </div>
                        <hr className="mb-4 mt-4" />
                        <div className="countsNumber">
                           Last bid on <span>{props?.companyDetailsData?.overview?.last_bid}</span>
                        </div>
                        <hr className="mb-4 mt-4" />
                        <div className="countsNumber">
                           Records available since <span>{props?.companyDetailsData?.overview?.prev_bid}</span>
                        </div>
                        <hr className="mb-4 mt-4" />
                        <div className="countsNumber">
                           Company Description <span>{props?.companyDetailsData?.overview?.comp_desc}</span>
                        </div>
                     </div>
                  </div>
                  {/* ./card */}

               </div>
               <div className="col-md-8">
                  <div className="card h-100">
                     <div className="card-title">
                        <h1>State Wise Bids</h1>
                        <div className="endFlex">
                           <div className="cd_btnGroup">
                              <a href="javascript:void(0);" className="statsButton active" aria-current="page">All Time</a>
                              <a href="javascript:void(0);" className="statsButton">Year</a>
                              <a href="javascript:void(0);" className="statsButton">Month</a>
                           </div>
                           <div className="input-daterange position-relative">
                              <div className="input-group" id="input-daterange">
                                 <input type="date" className="form-control input-new text-start" placeholder="From date" />
                                 <div className="input-group-addon mx-2 text-greyDark align-self-center"><i className="fas fa-angle-double-right"></i></div>
                                 <input type="date" className="form-control input-new text-start" placeholder="To date" />
                              </div>
                           </div>
                        </div>
                        {/* ./endFlex */}

                     </div>
                     <div className="card-body">

                        <div className="PiChart_wrapper">
                           <PiChart data={props?.companyDetailsData?.state_bid?.state_wise_bids} />
                        </div>
                     </div>
                  </div>
                  {/* ./card */}

               </div>
            </div>

            <div className="row mt-5">
               <div className="col-md-4">
                  <div className="card h-100">
                     <div className="card-title">
                        <h1>Top Competitors</h1>
                     </div>
                     <div className="card-body">
                        <div className="Overview-491">

                           {renderTopComp ? renderTopComp : null}
                        </div>
                     </div>
                  </div>
                  {/* ./card */}
               </div>
               <div className="col-md-8">
                  <div className="card h-100">
                     <div className="card-title">
                        <h1>Bidding Timeline</h1>
                        <div className="endFlex">
                           <div className="cd_btnGroup">
                              <a href="javascript:void(0);" className="statsButton active" aria-current="page">All Time</a>
                              <a href="javascript:void(0);" className="statsButton">5 Year</a>
                              <a href="javascript:void(0);" className="statsButton">Year</a>
                              <a href="javascript:void(0);" className="statsButton">Month</a>
                           </div>
                           <div className="input-daterange position-relative">
                              <div className="input-group" id="input-daterange">
                                 <input type="date" className="form-control input-new text-start" placeholder="From date" />
                                 <div className="input-group-addon mx-2 text-greyDark align-self-center"><i className="fas fa-angle-double-right"></i></div>
                                 <input type="date" className="form-control input-new text-start" placeholder="To date" />
                              </div>
                           </div>
                        </div>
                        {/* ./endFlex */}

                     </div>
                     <div className="card-body">
                        <div className="">
                           <AreaSplineChart data={props?.companyDetailsData} />
                        </div>
                     </div>
                  </div>
                  {/* ./card */}
               </div>
            </div>

         </div>

      </>
   )
}

export default CompanyName
