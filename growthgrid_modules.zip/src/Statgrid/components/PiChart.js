// @ts-nocheck
import * as React from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
function PiChart({data}) {
  const [dataArr, setDataArr] = React.useState([])

  const getDataOfPieChart = () => {
    if (data) {
      const entry = Object.entries(data)
      setDataArr(entry)
    }else{
      setDataArr([])
    }
  }
  React.useEffect(() => {
    getDataOfPieChart()
  }, [data])

  const chartOptions = {
    chart: {
      type: "pie",
      options3d: {
        enabled: true,
        alpha: 45
      },
    },
    exporting: false,
    credits: false,
    legend: {
      align: "right",
      layout: "vertical",
      verticalAlign: "top",
      x: -80,
      y: 80,
      itemMarginBottom: 10
    },
    title: {
      text: "",
      align: "left"
    },
    plotOptions: {
      pie: {
        innerSize: 100,
        depth: 45,
        dataLabels: {
          enabled: false
        }
      }
    },
    series: [
      {
        name: "State Wise Bids",
        data: dataArr,
        showInLegend: true
      }
    ]
  };
  return <HighchartsReact highcharts={Highcharts} options={chartOptions} />;
}

export default PiChart;
