// @ts-nocheck
import * as React from "react";
import Highcharts from "highcharts";
import dayjs from "dayjs";
import HighchartsReact from "highcharts-react-official";
function AreaSplineChart({data}) {
  const [splineData , setSplineData] = React.useState([])
  const [splineXAxis , setSplineDataXAxis] = React.useState([])

  function generateDayWiseTimeSeries() {  
    if(data?.bidding_timeline){
      const series = Object?.entries(data?.bidding_timeline)?.map(([key , value]) => [key , value])
      setSplineData(series.map(item => item[1]))
      setSplineDataXAxis(series.map(item=> dayjs(item[0]).format('DD/MM/YYYY')))
      
    
    }else{
      setSplineData([])
      setSplineDataXAxis([])
    }
  }
  React.useEffect(()=>{
    generateDayWiseTimeSeries()
  },[data?.bidding_timeline])


  const chartOptions = {
    chart: {
      type: 'spline'
    },
    title: {
      text: 'U.S Solar Employment Growth by Job Category, 2010-2030',
      align: 'left'
    },

    subtitle: {
      text: 'Source: <a href="https://irecusa.org/programs/solar-jobs-census/" target="_blank">IREC</a>',
      align: 'left'
    },

    yAxis: {
      title: {
        text: 'Bidding timeline'
      }
    },

    xAxis: {
      categories: splineXAxis,
      ccessibility: {
        description: 'Months of the year'
      }
    },

    legend: {
      layout: 'vertical',
      align: 'right',
      verticalAlign: 'middle'
    },

    plotOptions: {
      series: {
        label: {
          connectorAllowed: false
        },
      }
    },

    series: [{
      name: data?.company_name,
      data: splineData
    }],

    responsive: {
      rules: [{
        condition: {
          maxWidth: 500
        },
        chartOptions: {
          legend: {
            layout: 'horizontal',
            align: 'center',
            verticalAlign: 'bottom'
          }
        }
      }]
    }
  };
  return <HighchartsReact highcharts={Highcharts} options={chartOptions} />;
}

export default AreaSplineChart;
