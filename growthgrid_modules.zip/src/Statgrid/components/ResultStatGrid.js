// @ts-nocheck
import React, { useEffect, useState } from 'react'
import dayjs from "dayjs";
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import Skeleton from 'react-loading-skeleton'
import { CompanyService } from 'Services/statgrid/CompanyServices';
import EmptyBox from '../../assests/img/empty-box.png'
import _ from 'lodash';
import TablePagination from "@mui/material/TablePagination";
import ROUTES from 'Constants/Routes';
function ResultStatGrid({ setFilterApi, filters, allStage }) {
    const dispatch = useDispatch()
    const render = [1, 2, 3, 4, 5]
    const [page, setPage] = React.useState(filters?.page_number ? filters?.page_number : 0);
    const [rowsPerPage, setRowsPerPage] = useState(filters?.limit ? filters?.limit : 50);
    const [skeletonTime, setSkeletonTime] = useState(false);
    const navigate = useNavigate();
    const [resultList, setResultList] = useState({})
    const getTenderResults = () => {
        setSkeletonTime(true)
        const resultData = new FormData()
        resultData.append('limit', filters?.limit ? parseInt(filters?.limit) : 50)
        resultData.append('page_number', filters?.page_number ? parseInt(filters?.page_number) : 0)
        resultData.append('country_id', filters?.country_id)
        resultData.append('state_id', filters?.state_id)
        resultData.append('client_id', filters?.client_id ? filters?.client_id : "")
        resultData.append('amnt_custrange_operator', filters?.amnt_custrange_operator)
        resultData.append('amnt_custrange_amount', filters?.amnt_custrange_amount)
        resultData.append('custrange_denomination', filters?.custrange_denomination)
        try {
            CompanyService.getTenderStageListbyfinYear(resultData).then((res) => {
                if (res?.data?.status == 1) {
                    setTimeout(() => {
                        setSkeletonTime(false)
                    }, 2000);
                    setResultList(res?.data?.data)
                } else {
                    console.log("no record found")
                }
            })
        } catch (error) {
            console.log(error)
        }
    }

    setTimeout(() => {
        setSkeletonTime(true)
    }, 2000)



    const handleChangePage = (event, newPage) => {
        setPage(newPage);
        const obj = {
            ...filters,
            page_number: parseInt(newPage),
            limit: rowsPerPage
        }
        setFilterApi(obj)
        window.scrollTo({
            top: 0,
        });
    };

    const handleChangeRowsPerPage = (event) => {
        let newLimit = parseInt(event.target.value, 10)
        if (newLimit < parseInt(rowsPerPage)) {
            const obj = {
                ...filters,
                page_number: 0,
                limit: parseInt(event.target.value, 10)
            }
            setFilterApi(obj)
            setPage(0);
            window.scrollTo({
                top: 0,
            });
        } else {
            const obj = {
                ...filters,
                page_number: 0,
                limit: parseInt(event.target.value, 10)
            }
            setFilterApi(obj)
            setPage(0);
        }

    };
    useEffect(() => {
        if (!_.isEmpty(filters)) {
            getTenderResults()
            setRowsPerPage(parseInt(filters?.limit))
            setPage(parseInt(filters?.page_number))
        }
    }, [filters])
    const handleNavigation = (id) => {
        navigate(ROUTES.RESULT_DETAILS.replace(":id", id))

    };



    return (
        <>
            {resultList?.data?.length !== 0 ?
                <div className="comList">
                    {
                        skeletonTime ?
                            <>
                                {resultList?.data?.map((item, index) => {
                                    let date = dayjs(item.published).format("DD MMM YYYY");
                                    return (
                                        <>
                                            <div key={index} className="comCard" onClick={() => handleNavigation(item?.fld_id)}>
                                                <div className='topCard'>
                                                    <div className="locationTex"><i className="fas fa-map-marker-alt"></i>{item.city_name + ` , ` + item.state_name + ` , ` + item.country_name}</div>
                                                    <div className="cilpBage">{allStage?.filter(val => val.fld_id === item.tender_stage).map(items => { return (items.stage_name) })}</div>
                                                </div>
                                                <div className='clientName'>{item.tender_details?.charAt(0)?.toUpperCase() + item.tender_details?.slice(1)?.toLowerCase()}</div>
                                                <div className='serviceName'><i className="fas fa-hotel me-2"></i> {item.client_name?.charAt(0).toUpperCase() + item?.client_name?.slice(1)?.toLowerCase()}</div>

                                                <div className='d-flex'>
                                                    <div className='bidDate'>
                                                        <span className='sub'><i className="fas fa-calendar-alt me-1"></i> Published on</span>
                                                        <span className='date_value'>{date}</span>
                                                    </div>
                                                    <div className='bidNumber'><i className="fas fa-rupee-sign me-1"></i> Contract Amount <span className='date_value'> {item?.contract_value}</span></div>
                                                </div>
                                            </div>

                                        </>
                                    );
                                })}
                            </>
                            :
                            <>
                                {render.map((item, index) => {
                                    return (
                                        <div key={index} className="comCard">
                                            <div className="btnLock" style={{ background: "transparent" }} >
                                                <Skeleton width={35} height={35} circle={true} />
                                            </div>
                                            <div className="locationTex">
                                                <Skeleton width={370} height={30} />
                                            </div>
                                            <div className="clientName">
                                                <Skeleton height={15} />
                                            </div>
                                            <div className="serviceName">
                                                <Skeleton height={15} />
                                            </div>
                                            <div className="d-flex">
                                                <div className="bidDate">
                                                    <span className="sub">
                                                        <Skeleton width={98} height={15} />
                                                    </span>
                                                    <span>
                                                        <Skeleton width={80} height={15} />
                                                    </span>
                                                </div>
                                                <div className="bidNumber">
                                                    <Skeleton width={98} height={15} />{" "}
                                                    <span>
                                                        <Skeleton width={40} height={15} />
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                })}
                            </>

                    }

                </div>
                :
                <div className="spinerWrap">
                    <div>
                        <img src={EmptyBox} width={120} style={{ margin: 'auto', display: 'block' }} />
                        <div>
                            <p style={{ textAlign: "center", fontSize: '18px', marginTop: '15px' }}>
                                No record found
                            </p>
                        </div>
                    </div>
                </div>
            }
            <TablePagination
                rowsPerPageOptions={[50, 100, 250, 500]}
                component="div"
                count={resultList?.count_filtered}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
        </>
    )
}

export default ResultStatGrid
