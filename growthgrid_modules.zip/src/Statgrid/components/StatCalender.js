// @ts-nocheck
import React, { useEffect, useState } from 'react'
import DeleteIcon from '@mui/icons-material/Delete';
import { FilterOutlined, FlagOutlined } from '@ant-design/icons';
import { Chip, Stack } from '@mui/material';
import { Badge, Calendar } from 'antd';
import dayjs from 'dayjs';
import SearchBar from './searchBar/SearchBar';
import CalendarSidebar from './calendarSidebar/CalendarSidebar';


const monthData = [
    {
        id: 1,
        value: "option1",
        name: "Last 2 month"
    },
    {
        id: 2,
        value: "option2",
        name: "Last 4 month"
    },

    {
        id: 3,
        value: "option3",
        name: "Last 6 month"
    }

]

function StatCalender() {
    const [age, setAge] = React.useState('');
    const [selectedOption, setSelectedOption] = React.useState('Option 1');
    const [value, setValue] = useState(() => dayjs());
    const [selectedValue, setSelectedValue] = useState(() => dayjs());
    const [calendarValues, setCalendarValues] = useState([dayjs()]);
    const [openDrawer , setOpenDrawer]= useState(false);

    const calculateStartDates = (selectedOption) => {
        const currentDate = dayjs();
        let startDates = [];

        switch (selectedOption) {
            case 'Option 1':
                startDates = [currentDate, currentDate.subtract(1, 'month')];
                break;
            case 'Option 2':
                startDates = [
                    currentDate,
                    currentDate.subtract(1, 'month'),
                    currentDate.subtract(2, 'month'),
                    currentDate.subtract(3, 'month'),
                ];
                break;
            case 'Option 3':
                startDates = [
                    currentDate,
                    currentDate.subtract(1, 'month'),
                    currentDate.subtract(2, 'month'),
                    currentDate.subtract(3, 'month'),
                    currentDate.subtract(4, 'month'),
                    currentDate.subtract(5, 'month'),
                ];
                break;
            default:
                startDates = [currentDate];
                break;
        }

        return startDates;
    };

    // const calculateStartDates = (selectedOption) => {
    //     const currentDate = dayjs();
    //     let startDates = [];

    //     switch (selectedOption) {
    //         case 'Option 1':
    //             startDates = [currentDate.subtract(1, 'month'), currentDate];
    //             break;
    //         case 'Option 2':
    //             startDates = [
    //                 currentDate,
    //                 currentDate.subtract(1, 'month'),
    //                 currentDate.subtract(2, 'month'),
    //                 currentDate.subtract(3, 'month'),
    //             ];
    //             break;
    //         case 'Option 3':
    //             startDates = [
    //                 currentDate,
    //                 currentDate.subtract(1, 'month'),
    //                 currentDate.subtract(2, 'month'),
    //                 currentDate.subtract(3, 'month'),
    //                 currentDate.subtract(4, 'month'),
    //             ];
    //             break;
    //         default:
    //             startDates = [currentDate];
    //             break;
    //     }

    //     return startDates;
    // };

    useEffect(() => {

        setSelectedOption('Option 1');
        setCalendarValues(calculateStartDates('Option 1'));
    }, []);
    // const calculateStartDates = (selectedOption) => {
    //     const currentDate = dayjs();
    //     let startDates = [];

    //     switch (selectedOption) {
    //         case 'Option 1':
    //             startDates = [currentDate.subtract(1, 'month'), currentDate];
    //             break;
    //         case 'Option 2':
    //             startDates = [
    //                 currentDate.subtract(3, 'month'),
    //                 currentDate.subtract(2, 'month'),
    //                 currentDate.subtract(1, 'month'),
    //                 currentDate,
    //             ];
    //             break;
    //         case 'Option 3':
    //             startDates = [
    //                 currentDate.subtract(4, 'month'),
    //                 currentDate.subtract(3, 'month'),
    //                 currentDate.subtract(2, 'month'),
    //                 currentDate.subtract(1, 'month'),
    //                 currentDate,
    //             ];
    //             break;
    //         default:
    //             startDates = [currentDate];
    //             break;
    //     }

    //     return startDates;
    // };

    const onSelect = (newValue) => {
        console.log(newValue, "newValue");
        setValue(newValue);
        setSelectedValue(newValue);
    };
    const onPanelChange = (value, mode) => {
        console.log(value.format('YYYY-MM-DD'), mode);
    };
    const handleChange = (event) => {
        setAge(event.target.value);
    };
    const handleClick = () => {
        console.info('You clicked the Chip.');
    };

    const handleDelete = () => {
        console.info('You clicked the delete icon.');
    };

    const handleChangeDropdown = (event) => {
        const newSelectedOption = event.target.value;
        const newStartDates = calculateStartDates(newSelectedOption);

        // Update the corresponding calendar value state
        setCalendarValues(newStartDates);

        // Update the selected option for the corresponding calendar
        setSelectedOption(newSelectedOption);
    };


    const headerRender = ({ value }) => (
        <div style={{ textAlign: 'center', padding: '10px 0' }}>
            <span style={{ fontSize: '18px', fontWeight: 'bold' }}>
                {value.format('MMMM YYYY')}
            </span>
        </div>
    );
    return (
        <>
            <div className='container'>
                <div className='stat_calender_main'>
                    <SearchBar />

                    {/* <div className='stat_searchBar'>
                        <input className='stat_input' placeholder='search.....' />
                        <div className='stat_icons'>
                            <button type="submit" className='search_button'>
                                Search
                            </button>
                            <button className="Stat_filter_icon" type="button"  >
                                <FilterOutlined /></button>
                        </div>
                    </div> */}
                    <div className='stat_heading'>
                        <div className='stat_calender_title'>
                            <h2>Tender Calender</h2>
                        </div>
                        {/* <div className='stat_dropdown'>
                            <Box sx={{ minWidth: 100 }}>
                                <FormControl >
                                    <InputLabel id="demo-simple-select-label">Month</InputLabel>
                                    <Select
                                        labelId="demo-simple-select-label"
                                        id="demo-simple-select"
                                        value={age}
                                        label="Month"
                                        onChange={handleChange}
                                    >
                                        <MenuItem value={10}>2 Month</MenuItem>
                                        <MenuItem value={20}>4 month</MenuItem>
                                        <MenuItem value={30}>6 month</MenuItem>
                                    </Select>
                                </FormControl>
                            </Box>
                        </div> */}

                        <div className="headings_right_side_dropdown">
                            <select value={selectedOption} onChange={(event) => handleChangeDropdown(event, 1)} className='tab_select_box'>
                                <option value="Option 1">Last 2 Months</option>
                                <option value="Option 2">Last 4 Months</option>
                                <option value="Option 3">Last 6 Months</option>
                            </select>
                        </div>
                        <div>

                        </div>

                    </div>
                    <div className='stat_chips'>
                        <Stack direction="row" spacing={1}>
                            <Chip
                                label="Custom delete icon"
                                onClick={handleClick}
                                onDelete={handleDelete}
                                deleteIcon={<DeleteIcon />}
                                variant="outlined"
                            />
                            <Chip
                                label="Custom delete icon"
                                onClick={handleClick}
                                onDelete={handleDelete}
                                deleteIcon={<DeleteIcon />}
                                variant="outlined"
                            />
                            <Chip
                                label="Custom delete icon"
                                onClick={handleClick}
                                onDelete={handleDelete}
                                deleteIcon={<DeleteIcon />}
                                variant="outlined"
                            />
                            <Chip
                                label="Custom delete icon"
                                onClick={handleClick}
                                onDelete={handleDelete}
                                deleteIcon={<DeleteIcon />}
                                variant="outlined"
                            />
                            <Chip
                                label="Custom delete icon"
                                onClick={handleClick}
                                onDelete={handleDelete}
                                deleteIcon={<DeleteIcon />}
                                variant="outlined"
                            />
                        </Stack>

                    </div>
                    <div className='stat_flag my-4'>
                        <div className='flag_details'>
                            <FlagOutlined />
                            <p className='reminder mt-0'>Remider with15 days</p>
                        </div>
                        <div className='flag_details_1'>
                            <FlagOutlined />
                            <p className='reminder_1 mt-0'>  with15 days</p>
                        </div>
                        <div className='flag_details_2'>
                            <FlagOutlined />
                            <p className='reminder_2 mt-0'>Remider with15 days</p>
                        </div>
                        <div className='flag_details_3'>
                            <FlagOutlined />
                            <p className='reminder_3 mt-0'>Shortlisted Tender</p>
                        </div>

                    </div>
                    {/* <div className='stat_calender'>
                        <Calendar
                         value={value} 
                         onSelect={onSelect} 
                         onPanelChange={onPanelChange}  
                         headerRender={headerRender}/>
                    </div> */}
                    <div className='row g-5'>
                        {calendarValues.map((calendarValue, index) => (
                            <div key={index} className='col-12 col-lg-6' onClick={()=>setOpenDrawer(!openDrawer)}> 
                                <Calendar
                                    value={calendarValue}
                                    onSelect={(newValue) => onSelect(newValue, index)}
                                    onPanelChange={onPanelChange}
                                    headerRender={headerRender}
                                />
                            </div>
                        ))}
                    </div>

                    <CalendarSidebar openDrawer={openDrawer} setOpenDrawer= {setOpenDrawer}/>
                   



                    {/* 

                    <div className='stat_search_bar'>

                        <input className='stat_input' type="text" placeholder="Search..." />
                        <div className='stat_button'>
                        
                        </div>

                    </div>
                    <div className='stat_heading'>
                        <div className='stat_calender_title'>
                            <h2>Tender Calender</h2>
                        </div>
                        <div>

                        </div>

                    </div> */}
                </div>
            </div>
        </>
    )
}

export default StatCalender
