// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { DownOutlined, UploadOutlined, UserOutlined } from '@ant-design/icons'
import { Dropdown, Input, Menu, Upload, Button } from 'antd'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { BarsSvg, CalendarSvg, ReminderSvg, SavedSearchSvg, SearchSvg, WalletSvg } from 'Statgrid/utils/Svgs'
// import STATROUTES from 'Statgrid/router/statgridRoutes'
import { useDispatch } from 'react-redux';
import Avatar from '@mui/material/Avatar';
import { Calendar, FolderSearch, GoStart, Remind, Search, GoEnd } from '@icon-park/react';
import { LogoutOutlined } from '@ant-design/icons';
import { userStatLogoutAction } from 'Redux/actions/common/authAction';

import { useSelector } from 'react-redux'
import { GroupAddOutlined, GroupOutlined, KeyOutlined } from '@mui/icons-material'
import STATROUTES from 'Statgrid/router/statgridRoutes'
import { CompanyListApi } from 'Services/statgrid/companylist/CompanyListApi'
import axios from 'axios'
import { StatAuthServices } from 'Services/statgrid/statauth/StatLogin'
import ROUTES from 'Constants/Routes'
import { CompanyBalanceAction } from 'Redux/actions/statgrid/statBalanceAction'
import { ChevronLeftRounded } from '@mui/icons-material';
import DefaultImage from '../../../assests/img/user.png';
import CreditIcon from "../../assets/img/payment.png"
import logoLarge from '../../assets/img/logo-large.png'

const Header = ({ showSidebar, isSidebarVisible }) => {

    const { companyBalance } = useSelector((state) => state?.companyStatBalance)
    const { userStatInfo } = useSelector((state) => state.userDetails)
    const location = useLocation()
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const [balance, setBalance] = useState()
    const [iP, setIP] = useState(null);

    const getIP = async () => {
        try {
            const res = await axios.get("https://api.ipify.org/?format=json");
            setIP(res.data.ip);
            return res.data.ip;
        } catch (error) {
            console.error("Error fetching IP:", error);
            return null;
        }
    };

    const getIpDataDetails = async () => {
        try {
            const response = await StatAuthServices?.getIpAddress();
            if (response?.data?.status === "1") {
                const newData = response?.data?.data?.ip_address;
                if (iP && iP !== newData) {
                    if (isLoggedIn()) {
                        localStorage.removeItem("statToken");
                        navigate(ROUTES?.STAT_LOGIN);
                    }
                }
            }
        } catch (error) {
            console.error("Error fetching IP data details:", error);
        }
    };

    const isLoggedIn = () => {
        return !!localStorage.getItem("statToken");
    };

    useEffect(() => {
        getIP().then(() => {
            getIpDataDetails();
            const intervalId = setInterval(getIpDataDetails, 20000);
            return () => clearInterval(intervalId);
        });
    }, []);

    useEffect(() => {
        getIpDataDetails();
    }, []);



    const handleLogoutAction = () => {

        console.log(dispatch(userStatLogoutAction()), "dispatch(userStatLogoutAction())");
        dispatch(userStatLogoutAction());
        navigate(ROUTES?.STAT_LOGIN)
    };

    const getBalanceData = async () => {
        const response = await CompanyListApi?.getCompanyBalance()
        if (response?.data?.status === "1") {
            setBalance(response?.data?.data)
            dispatch(CompanyBalanceAction(response?.data?.data))
        }
    }


    useEffect(() => {
        getBalanceData()
    }, [dispatch])
    const menu = (
        <Menu>
            <Menu.Item className='m-2 py-2 px-3 rounded-pill' key="1" icon={<UserOutlined />} onClick={() => navigate(`/${STATROUTES.PLACEHOLDER}/${STATROUTES?.PROFILES}`)}>Profile</Menu.Item>
            <Menu.Item className='m-2 py-2 px-3 rounded-pill' key="2" icon={<GroupOutlined />} onClick={() => navigate(`/${STATROUTES.PLACEHOLDER}/${STATROUTES?.USERLIST}`)}>UserList</Menu.Item>
            <Menu.Item className='m-2 py-2 px-3 rounded-pill' key="3" icon={<GroupAddOutlined />} onClick={() => navigate(`/${STATROUTES.PLACEHOLDER}/${STATROUTES?.ADDUSER}`)}>Add User</Menu.Item>
            <Menu.Item className='m-2 py-2 px-3 rounded-pill' key="4" icon={<KeyOutlined />} onClick={() => navigate(`/${STATROUTES.PLACEHOLDER}/${STATROUTES?.STAT_ROLES_AND_PERMISSION}`)}>Roles & Permissions</Menu.Item>
            <Menu.Item className='m-2 py-2 px-3 rounded-pill' key="5" danger icon={<LogoutOutlined />} onClick={handleLogoutAction}>
                LogOut
            </Menu.Item>
        </Menu>
    );
    const headerMenu = [
        {
            id: 1,
            icon: <FolderSearch theme="outline" size="28" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
            label: "Saved Searches",
            url: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.SAVED_SEARCH}`,
        },
        {
            id: 2,
            icon: <Remind theme="outline" size="26" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
            url: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.REMINDER}`,
        },
    ]



    return (
        <>
            <header className='main-header'>
                <nav className="header_sections">
                    <div className={`brand__logo d-flex flex-column gap-4`}>
                        <img src={logoLarge} className='w-100 cursor-pointer' alt="brand logo" onClick={() => navigate("/statgrid")} />
                        {/* <div className='radial-line'></div> */}
                    </div>
                    <div className="toggle-button" onClick={showSidebar}>
                        {isSidebarVisible ?
                            <GoEnd theme="filled" size="30" fill="#848484" strokeWidth={4} strokeLinecap="butt" />
                            :
                            <GoStart theme="filled" size="30" fill="#848484" strokeWidth={4} strokeLinecap="butt" />
                        }

                    </div>
                    <div className="credit_icons cursor-pointer" onClick={() => navigate(`/${STATROUTES.PLACEHOLDER}/${STATROUTES.WALLET}`)}>
                        {/* <WalletSvg /> */}
                        {/* <img src={CreditIcon} />
                         */}
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" width={24} height={24}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a2.25 2.25 0 0 0-2.25-2.25H15a3 3 0 1 1-6 0H5.25A2.25 2.25 0 0 0 3 12m18 0v6a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 18v-6m18 0V9M3 12V9m18 0a2.25 2.25 0 0 0-2.25-2.25H5.25A2.25 2.25 0 0 0 3 9m18 0V6a2.25 2.25 0 0 0-2.25-2.25H5.25A2.25 2.25 0 0 0 3 6v3" />
                        </svg>
                        <span>
                            <b className='d-none d-lg-inline'>Credits - </b>
                            {companyBalance?.map((item, index) => (
                                <span key={index}>{item?.total_count_limit !== null ? item?.total_count_limit : "0"} / {item?.limit_comp_unlock}</span>
                            ))}
                        </span>
                    </div>
                    <div className="menu_calendar">
                        <Link to={`/${STATROUTES.PLACEHOLDER}/${STATROUTES.TENDER_CALENDER}`}>
                            <Calendar theme="outline" size="20" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                            Tender calendar
                        </Link>
                    </div>
                    <div className='p-2 text-black d-block d-lg-none' onClick={showSidebar}>
                        <BarsSvg w={32} h={32} />
                    </div>
                    <div className="header_right_sec w-50 flex-grow-1 ">
                        <Input
                            placeholder="Search for tenders and companies and etc..."
                            prefix={<Search theme="outline" size="24" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />}
                            className="g-search-input w-fit rounded-pill d-none d-lg-flex"
                        />
                        {headerMenu.map((item) => {
                            return (
                                <Link key={item.id} to={item.url} className={location.pathname === item.url ? 'header-link active' : 'header-link'}>
                                    {item.icon}
                                </Link>
                            )
                        })}
                        <Dropdown overlay={menu} trigger={['click']}>
                            <span style={{ cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
                                {userStatInfo?.profileimg ?
                                    <img alt='' className="img-thumbnail rounded-circle"
                                        src={userStatInfo?.profileimg !== null ? `https://testing.growthgrids.com/${userStatInfo.profileimg_path}/${userStatInfo.profileimg}` : DefaultImage}
                                    /> :
                                    <Avatar style={{ width: '40px', height: '40px' }}>
                                        {userStatInfo?.firstname !== null ?
                                            userStatInfo?.firstname?.charAt(0) : userStatInfo?.userfullname?.charAt(0)}
                                    </Avatar>
                                }
                                {/* <Avatar
                                    sx={{ bgcolor: "#925FFF" }}
                                    alt={userStatInfo?.userfullname}
                                    src={`https://testing.growthgrids.com/${userStatInfo?.path}/${userStatInfo?.profileimg}`}
                                /> */}
                                <DownOutlined style={{ marginLeft: '8px' }} />
                            </span>
                        </Dropdown>

                    </div>

                </nav>
            </header>
        </>

    )
}

export default Header;