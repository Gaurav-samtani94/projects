// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import logoLarge from '../../assets/img/logo-large.png'
import logoSmall from '../../assets/img/logo-small.png'
import { AnnouncementSvg, AuthoritiesSvg, CompaniesSvg, DashboardSvg, MarketShareSvg, MissedOpportunitySvg, PerformanceSvg, PlansSvg, ResultSvg, SupportSvg, TopCompetitorSvg, UnlockSvg } from 'Statgrid/utils/Svgs';
import { LogoutOutlined } from '@ant-design/icons';
import { ChevronLeftRounded } from '@mui/icons-material';
import { Button, Tooltip } from 'antd';
import STATROUTES from 'Statgrid/router/statgridRoutes';
import { useDispatch } from 'react-redux';
import { userStatLogoutAction } from 'Redux/actions/common/authAction';

const menuItems = [
    { id: 1, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.STATDASHBOARD}`, text: 'Dashboard', icon: <DashboardSvg />, type: "home" },
    { id: 2, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.COMPANIES}`, text: 'Companies', icon: <CompaniesSvg />, type: "organization" },
    { id: 3, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.TOP_COMPETITOR}`, text: 'Top Competitor', icon: <TopCompetitorSvg />, type: "organization" },
    { id: 3, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.UNLOCK_COMPANY}`, text: 'Unlock These', icon: <UnlockSvg />, type: "organization" },
    { id: 3, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.TENDERLIST}`, text: 'Tenders', icon: <AnnouncementSvg />, type: "discover" },
    { id: 3, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.AUTHORITIES_LIST}`, text: 'Authorities', icon: <AuthoritiesSvg />, type: "discover" },
    { id: 4, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.MISSED_OPPORTUNITY}`, text: 'Missed Opportunity', icon: <MissedOpportunitySvg />, type: "discover" },
    { id: 5, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.RESULTS}`, text: 'Result', icon: <ResultSvg />, type: "discover" },
    { id: 6, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.TENDERSUGGESTION}`, text: 'Tender Suggestion', icon: <ResultSvg />, type: "discover" },
    { id: 7, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.PERFORMANCE}`, text: 'Performance', icon: <PerformanceSvg />, type: "analytics" },
    { id: 8, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.MARKET_SHARE}`, text: 'Market Share', icon: <MarketShareSvg />, type: "analytics" },
    { id: 9, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES.INNER_PLAN}`, text: 'Plans', icon: <PlansSvg />, type: "settings" },
    { id: 10, href: `/${STATROUTES.PLACEHOLDER}/${STATROUTES?.SUPPORT}`, text: 'Support', icon: <SupportSvg />, type: "settings" }
];

const SideBar = ({ isSidebarVisible, hideSidebar }) => {
    const navigate = useNavigate()
    const location = useLocation()
    const dispatch = useDispatch()

    const [homeMenu, setHomeMenu] = useState([]);
    const [discoverMenu, setDiscoverMenu] = useState([]);
    const [organizationMenu, setOrganizationMenu] = useState([]);
    const [analyticsMenu, setAnalyticsMenu] = useState([]);
    const [settingsMenu, setSettingsMenu] = useState([]);

    useEffect(() => {
        const home = [];
        const organization = [];
        const discover = [];
        const analytics = [];
        const settings = [];

        menuItems.forEach((item) => {
            if (item.type === 'home') {
                home.push(item);
            } else if (item.type === 'organization') {
                organization.push(item);
            } else if (item.type === 'discover') {
                discover.push(item);
            } else if (item.type === 'analytics') {
                analytics.push(item);
            } else if (item.type === 'settings') {
                settings.push(item);
            }
        });

        setHomeMenu(home);
        setOrganizationMenu(organization);
        setDiscoverMenu(discover);
        setAnalyticsMenu(analytics);
        setSettingsMenu(settings);
    }, []);

    return (
        <div className='aside'>
            <div className={`sidebar ${isSidebarVisible ? 'expanded' : ''} ${isSidebarVisible ? "show" : ""}`}>
                {/* <div className={`brand__logo d-flex flex-column gap-4`}>
                    <img src={isSidebarVisible ? logoLarge : logoSmall} className='w-100 cursor-pointer' alt="brand logo" onClick={() => navigate("/statgrid")} />
                    <div className='radial-line'></div>
                </div> */}
                <div className='stat-menus'>
                    {isSidebarVisible &&
                        <small className='sidebar-label'>home</small>
                    }
                    {homeMenu.map((item) => (
                        <Tooltip title={item.text} placement="right">
                            <Link key={item.id} to={item.href} className={`stat-nav-link-main ${item.href === location.pathname ? "active" : ""}`}>
                                <span>{item.icon}</span>
                                {isSidebarVisible &&
                                    <p>{item.text}</p>
                                }
                            </Link>
                        </Tooltip>
                    ))}
                    {isSidebarVisible &&
                        <small className='sidebar-label'>organization</small>
                    }
                    {organizationMenu.map((item) => (
                        <Tooltip title={item.text} placement="right">
                            <Link key={item.id} to={item.href} className={`stat-nav-link-main ${item.href === location.pathname ? "active" : ""}`}>
                                <span>{item.icon}</span>
                                {isSidebarVisible &&
                                    <p>{item.text}</p>
                                }
                            </Link>
                        </Tooltip>
                    ))}
                    {isSidebarVisible &&
                        <small className='sidebar-label'>discover</small>
                    }
                    {discoverMenu.map((item) => (
                        <Tooltip title={item.text} placement="right">
                            <Link key={item.id} to={item.href} className={`stat-nav-link-main ${item.href === location.pathname ? "active" : ""}`}>
                                <span>{item.icon}</span>
                                {isSidebarVisible &&
                                    <p>{item.text}</p>
                                }
                            </Link>
                        </Tooltip>
                    ))}
                    {isSidebarVisible &&
                        <small className='sidebar-label'>analytics</small>
                    }
                    {analyticsMenu.map((item) => (
                        <Tooltip title={item.text} placement="right">
                            <Link key={item.id} to={item.href} className={`stat-nav-link-main ${item.href === location.pathname ? "active" : ""}`}>
                                <span>{item.icon}</span>
                                {isSidebarVisible &&
                                    <p>{item.text}</p>
                                }
                            </Link>
                        </Tooltip>
                    ))}
                    {isSidebarVisible &&
                        <small className='sidebar-label'>settings</small>
                    }
                    {settingsMenu.map((item) => (
                        <Tooltip title={item.text} placement="right">
                            <Link key={item.id} to={item.href} className={`stat-nav-link-main ${item.href === location.pathname ? "active" : ""}`}>
                                <span>{item.icon}</span>
                                {isSidebarVisible &&
                                    <p>{item.text}</p>
                                }
                            </Link>
                        </Tooltip>
                    ))}
                </div>
                {/* <Button className="mt-auto" danger shape="round" icon={<LogoutOutlined />} size={'large'} onClick={handleLogout}>
                    {expanded && "LogOut"}

                </Button> */}
            </div>
            {isSidebarVisible &&
                <div className='overlap' onClick={hideSidebar}></div>
            }
        </div>
    );


};

export default SideBar;
