// @ts-nocheck
import { useLocation } from "react-router-dom";
import "../assets/statgridapp.scss"
import React, { Suspense, lazy, useState } from 'react'
import STATROUTES from "Statgrid/router/statgridRoutes";
const Header = lazy(() => import('Statgrid/layouts/sharedLayouts/Header'));
const Sidebar = lazy(() => import('Statgrid/layouts/sharedLayouts/Sidebar'));
const RootLayout = ({ children }) => {
    const [isSidebarVisible, setIsSidebarVisible] = useState(false)
    const location = useLocation()



    const isOffLayoutRoute = (
        location.pathname !== `/${STATROUTES.PLACEHOLDER}/${STATROUTES.STAT_LOGIN}`
        && location.pathname !== `/${STATROUTES.PLACEHOLDER}/${STATROUTES.STAT_SIGNUP}`
        && location.pathname !== `/${STATROUTES.PLACEHOLDER}/${STATROUTES.STAT_FORGOT_PASSWORD}`
        && location.pathname !== `/${STATROUTES.PLACEHOLDER}/${STATROUTES.PLAN}`
        && location.pathname !== `/${STATROUTES.PLACEHOLDER}/${STATROUTES.CONTACT}`
        && location.pathname !== `/${STATROUTES.PLACEHOLDER}/${STATROUTES.SUPPORT}`
        // && location.pathname !== `/${STATROUTES.PLACEHOLDER}/${STATROUTES.WALLET}`
        && location.pathname !== `/${STATROUTES.PLACEHOLDER}/${STATROUTES.CHECKOUT}`
    )

    return (
        <>
            {isOffLayoutRoute &&
                <Header isSidebarVisible={isSidebarVisible} showSidebar={() => setIsSidebarVisible(!isSidebarVisible)} />
            }
            <div className='d-flex gap-0'>
                <Suspense fallback={<div></div>}>
                    {isOffLayoutRoute &&
                        <Sidebar hideSidebar={() => setIsSidebarVisible(false)} isSidebarVisible={isSidebarVisible} />
                    }

                    <div className='w-50 flex-grow-1 '>
                        {children}
                    </div>
                </Suspense>
            </div>
        </>
    )
}

export default RootLayout