export const EXTENSIONS = {
    XLS: 'xls',
    PDF: 'pdf',
}