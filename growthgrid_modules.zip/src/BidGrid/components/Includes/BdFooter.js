import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";

function BdFooter() {
    const currentYear = new Date().getFullYear();

    return (
        <div className="bd_footerSection">©2021-{currentYear}  <Link to={""}>Growth Grids</Link>, All Rights Reserved.</div>
    )
}

export default BdFooter
