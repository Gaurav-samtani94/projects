// @ts-nocheck
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AccessTimeIcon from '@mui/icons-material/AccessTime';

import BIDGRIDROUTES from 'BidGrid/bidRoute/bidRoutes';
import { Avatar } from "antd";
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";

import { DownOutlined } from '@ant-design/icons';
import { Dropdown, Space, Divider, Button, theme } from 'antd';

import { DashboardOne, SettingTwo, DocumentFolder, AddOne, ViewList, ShareOne, UserBusiness, FolderClose } from '@icon-park/react';
import { docurlchat } from "utils/configurable";
// images
import profileImg from "../../assets/images/icons/profile.png"
import whishlistImg from "../../assets/images/icons/fave.png"
import logoutImg from "../../assets/images/icons/logout.png"
import briefcaseImg from "../../assets/images/icons/archive.png";
import { useLocation } from "react-router-dom";
import { useSelector } from 'react-redux'
import { userBidLogoutAction } from "Redux/actions/common/authAction";
import { useDispatch } from "react-redux";
import ROUTES from "Constants/Routes";
import { navigationData } from "Redux/actions/bidgrid/navigationData";
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import DefaultImage from '../../../assests/img/user.png';
import { DashboardServiceApi } from "Services/bidgrid/dashboard/DashboardAPi";
import dayjs from "dayjs";
const { useToken } = theme;

function useScrollDirection() {
    const [scrollDirection, setScrollDirection] = useState(null);

    useEffect(() => {
        let lastScrollY = window.pageYOffset;

        const updateScrollDirection = () => {
            const scrollY = window.pageYOffset;
            const direction = scrollY > lastScrollY ? "down" : "up";
            if (
                direction !== scrollDirection &&
                (scrollY - lastScrollY > 10 || scrollY - lastScrollY < -10)
            ) {
                setScrollDirection(direction);
            }
            lastScrollY = scrollY > 0 ? scrollY : 0;
        };
        window.addEventListener("scroll", updateScrollDirection); // add event listener
        return () => {
            window.removeEventListener("scroll", updateScrollDirection); // clean up
        };
    }, [scrollDirection]);

    return scrollDirection;
}

const arr = [
    { name: 'Add Unit', link: BIDGRIDROUTES?.ADDUNIT },
    { name: 'Job Grade', link: BIDGRIDROUTES?.JOBTITLE },
    { name: 'Prefix', link: BIDGRIDROUTES?.PREFIX },

    { name: 'Role', link: BIDGRIDROUTES?.ROLE },
    { name: 'Department', link: BIDGRIDROUTES?.DEPARTMENT_MANAGE },
    { name: 'Designation', link: BIDGRIDROUTES?.DESIGNATION },
    // { name: 'Team Requisition Designation', link: BIDGRIDROUTES?.TeamRequisitionDesignation },
    // { name: 'Team Requisition Designation Category', link: BIDGRIDROUTES?.TeamRequisitionDesignationCategory },

    { name: 'Currency', link: BIDGRIDROUTES?.CURRENCY },
    { name: 'Language', link: BIDGRIDROUTES?.LANGUAGE },
    { name: 'Timezone', link: BIDGRIDROUTES?.TIMEZONE },
    { name: 'Assign Sector', link: BIDGRIDROUTES?.ASSIGNSECTOR },
    { name: 'Keyword', link: BIDGRIDROUTES?.KEYWORD },
    // { name: 'Company', link: BIDGRIDROUTES?.COMPANY },
    { name: 'Logo', link: BIDGRIDROUTES?.LOGO },
    { name: 'Country', link: BIDGRIDROUTES?.COUNTRYLIST },
    { name: 'Sub-sector', link: BIDGRIDROUTES?.SUBSECTOR },
    { name: 'phase', link: BIDGRIDROUTES?.PHASE },
    { name: 'Tender Scope', link: BIDGRIDROUTES?.TENDER_SCOPE },
    { name: 'Funding Agency', link: BIDGRIDROUTES?.FUNDING_AGENCY },
    { name: 'State', link: BIDGRIDROUTES?.STATELIST },
    { name: 'city', link: BIDGRIDROUTES?.CITYLIST },
    { name: 'Continent', link: BIDGRIDROUTES?.CONTINENTLIST },
    { name: 'Region', link: BIDGRIDROUTES?.REGIONLIST },
    // { name: 'Employee', link: BIDGRIDROUTES?.EMPLOYEE },
    { name: 'Employee Status', link: BIDGRIDROUTES?.EMPLOYEE_STATUS },
    { name: 'Blood Group', link: BIDGRIDROUTES?.BLOODGROUP },
    { name: 'Tender Services', link: BIDGRIDROUTES?.TENDER_SERVICES },
    { name: 'Nationality', link: BIDGRIDROUTES?.NATIONALITY },
    { name: 'Gender', link: BIDGRIDROUTES?.GENDER },
    { name: 'Client', link: BIDGRIDROUTES?.BD_CLIENT },
    { name: 'Consortium', link: BIDGRIDROUTES?.CONSORTIUM },
    { name: 'Tender Status', link: BIDGRIDROUTES?.TENDER_STATUS },
    { name: 'Doctrol', link: BIDGRIDROUTES?.DOCTROL },
    { name: 'add Bank', link: BIDGRIDROUTES?.BANK },
]

let arrVal = arr?.sort((a, b) => a?.name?.localeCompare(b?.name))


const BdHeader = () => {
    const location = useLocation();
    const scrollDirection = useScrollDirection();
    const path = location.pathname;
    const { userBidInfo } = useSelector((state) => state.userDetails)
    const { socket, isConnected } = useSelector((state) => state.socket);
    const [notificationHistory, setNotificationHistory] = useState([])
    const navigate = useNavigate()



    //notification states
    const [notification, setNotification] = useState([])
    const [designation, setDesignation] = useState()


    const dispatch = useDispatch();
    const [menuList, setMenuList] = useState({
        master: false,
        add: false,
        profile: false,
        tender: false,
        personal: false

    })
    const [activeMenu, setActiveMenu] = useState(localStorage.getItem('activeItem') || null)

    const [overlayShow, setOverlayShow] = useState(false)

    const handleMenu = (e, name) => {
        setMenuList({
            master: name === "master" ? !menuList.master : false,
            add: name === "add" ? !menuList.add : false,
            tender: name === "tender" ? !menuList.tender : false,
            profile: name === "profile" ? !menuList.profile : false,
            personal: name === "personal" ? !menuList.personal : false,

        });
        setActiveMenu(name)
        localStorage.setItem('activeItem', name);
    };
    useEffect(() => {
        if (menuList.master === true || menuList.add === true || menuList.profile === true || menuList.tender === true || menuList.personal === true) {
            setOverlayShow(true)
        } else {
            setOverlayShow(false)
        }
    }, [menuList])


    const handleClickOutside = (e) => {
        const headerLastElement = document.getElementsByClassName("bd_profileMenu")[0];
        const headerMasterElement = document.getElementsByClassName("Master_menu")[0];
        const headerAddElement = document.getElementsByClassName("Add_menu")[0];
        const headerTenderElement = document.getElementsByClassName("tender_detail")[0];
        const headerPersonalElement = document.getElementsByClassName("personal")[0];



        if (
            (!headerLastElement || !headerLastElement.contains(e.target)) &&
            (!headerMasterElement || !headerMasterElement.contains(e.target)) &&
            (!headerAddElement || !headerAddElement.contains(e.target)) &&
            (!headerTenderElement || !headerTenderElement.contains(e.target)) &&
            (!headerPersonalElement || !headerPersonalElement.contains(e.target))


        ) {
            setMenuList({
                master: false,
                add: false,
                profile: false,
                tender: false,
                personal: false
            });
            setOverlayShow(false)
        }
    };


    useEffect(() => {
        document.addEventListener("mousedown", handleClickOutside);

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    useEffect(() => {
        const storedActiveItem = localStorage.getItem('activeItem');
        if (storedActiveItem) {
            setActiveMenu(storedActiveItem);
        }
    }, []);

    useEffect(() => {
        let pathname = window.location.pathname.split('/')[2];
        setActiveMenu(pathname)
    }, [window.location.pathname])

    const handleLogout = () => {
        dispatch(userBidLogoutAction());

    };

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
        });
    };
    const scrollToBottom = () => {
        const targetPosition = Math.max(
            0,
            document.documentElement.scrollHeight - window.innerHeight - 0
        );

        window.scroll({
            top: targetPosition,
            behavior: "smooth",
        });
    };


    const handleNavigate = async (item) => {

        if (item.category_types === 'tender_todo_comments' || item.category_types === 'tender_comments' || item.category_types === 'meeting_schedule' || item.category_types === 'tender_request') {
            const obj = {
                item: item,
                type: item.category_types,
                key: item?.category_id
            }
            dispatch(navigationData.setNavigationDataAction(obj))
            // navigate(ROUTES.BD_TENDERDETAILS.replace(':id', item?.tender_id));


        } else if (item.category_types === 'to_do_comments') {
            navigate('/bidgrid/todo');
        }
        try {
            const formData = new URLSearchParams()
            formData.append('notification_id', item?.id)
            const response = await DashboardServiceApi.seenNotification(formData)
            if (response?.data?.status === '1') {
                getUserHistoryApi()
            }
        } catch (error) {

        }

    }
    function convertHtmlToText(item) {
        return item?.replace(/<[^>]*>/g, '')
    }

    const items = notification.map((item, index) => ({
        label: <div className={`notiItem ${item.is_viewed !== '1' ? "view_is" : ''}`} key={index} onClick={() => handleNavigate(item)}>
            <span>{item?.mentioned_by}</span>{convertHtmlToText(item?.category_details)}
            <div className="date">{dayjs(item?.created_at).format('YYYY-MM-DD')}</div>
        </div>,
        key: index.toString(), // Use a unique key for each menu item
    }));

    useEffect(() => {
        if (isConnected) {
            socket.on(Number(userBidInfo?.id), (data) => {
                console.log("user notification Data", data)
                setNotification(prevComments => [data, ...prevComments.slice(0)]);
            });
        }
    }, [isConnected])

    const getUserHistoryApi = async () => {
        try {
            const response = await DashboardServiceApi.fetchNotifications()
            if (response?.data?.status === '1') {
                setNotification(response?.data?.data)
            } else {
                setNotification([])
            }
        } catch (error) {
            setNotification([])
        }
    }

    const fetchDesignation = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('designation_id', userBidInfo?.designation_id)
            const response = await DashboardServiceApi.getDeisgnationOfUser(formData)
            if (response?.data?.status === '1') {
                setDesignation(response?.data?.data?.designation_name)
            }
        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        if (localStorage.getItem('bidToken')) {
            getUserHistoryApi()
            fetchDesignation()
        }
    }, [localStorage.getItem('bidToken')])

    const { token } = useToken();
    const contentStyle = {
        backgroundColor: token.colorBgElevated,
        borderRadius: token.borderRadiusLG,
        boxShadow: token.boxShadowSecondary,
    };
    const menuStyle = {
        boxShadow: 'none',
    };




    return (
        <>
            <div
                className="bd_topScoll"
                onClick={scrollToTop}
                style={{ display: scrollDirection === "down" ? "flex" : "none" }}
            >
                <ArrowUpwardIcon />
            </div>
            <div
                className="bd_downScoll"
                onClick={scrollToBottom}
                style={{ display: scrollDirection === "up" ? "flex" : "none" }}
            >
                <ArrowDownwardIcon />
            </div>

            {path !== ROUTES.BD_LOGIN && (
                <div className="bg_header">
                    <div className="bd_brand_img" onClick={(e) => handleMenu(e, "dashboard")}>
                        {/* {userBidInfo?.docname && userBidInfo?.docpath ? (
                            <Link to={BIDGRIDROUTES?.DASHBOARD}>
                                <img
                                    className="bd_main_sub_s_img"
                                    src={`https://web.growthgrids.com/${userBidInfo.docpath}/${userBidInfo.docname}`}
                                    alt={userBidInfo.docname}
                                    width={180}
                                />
                            </Link>
                        ) : (
                            <p style={{ border: 'dashed', width: 180, textAlign: 'center' }}>
                                <Link to={BIDGRIDROUTES?.LOGO}>Upload your company logo here</Link>
                            </p>
                        )} */}
                        {userBidInfo?.docpath && userBidInfo?.docname ? (
                            <Link to={BIDGRIDROUTES?.DASHBOARD}>
                                <img
                                    className="bd_main_sub_s_img"
                                    src={`${docurlchat}${userBidInfo.docpath}/${userBidInfo.docname}`}
                                    alt={userBidInfo.docname}
                                    width={180}
                                />
                            </Link>
                        ) : (
                            <Skeleton width={180} height={50} />
                            // <p style={{ border: 'dashed', width: 180,textAlign: 'center' }}>
                            //     <Link to={BIDGRIDROUTES?.LOGO}>Upload your company logo here</Link>
                            // </p>
                        )}
                    </div>
                    <div className="Header_center">
                        <ul className="mainMenuNew">

                            <Link to={BIDGRIDROUTES?.DASHBOARD} className={activeMenu === "dashboard" ? "nav-item active" : "nav-item "}>
                                <span className="nav-link" onClick={(e) => handleMenu(e, "dashboard")}><DashboardOne theme="outline" size="22" fill="#98a1b3" strokeWidth={3} strokeLinecap="butt" />Dashboard</span>
                            </Link>

                            <li className={activeMenu === "master" ? "nav-item Master_menu active" : "nav-item Master_menu "}>
                                <span className="nav-link" onClick={(e) => handleMenu(e, "master")}>
                                    <SettingTwo theme="outline" size="22" fill="#98a1b3" strokeWidth={3} strokeLinecap="butt" />Master
                                    <span className="dropIcon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M5 7.5L10 12.5L15 7.5" stroke="#636363" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </span>
                                </span>

                                <div className={
                                    menuList.master ? "bg_megamenu Bd_menu_visible" : "bg_megamenu "
                                }
                                >
                                    <div className="rowGridFlex">
                                        {
                                            arrVal?.map((item, index) => {
                                                return (
                                                    <React.Fragment key={index}>
                                                        <div className="grid_sm">
                                                            <span onClick={(e) => { handleMenu(e, "master") }} className="megaLink">
                                                                <Link to={item?.link}>
                                                                    {item?.name}
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                                        <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                                    </svg>
                                                                </Link>
                                                            </span>
                                                        </div>
                                                    </React.Fragment>
                                                )
                                            })
                                        }
                                    </div>
                                </div>
                            </li>

                            <li className={activeMenu === "add" || activeMenu === 'livetender' || activeMenu === 'prospectivetender' || activeMenu === 'AddTender' ? "nav-item Add_menu active" : "nav-item Add_menu "}>
                                <span className="nav-link" onClick={(e) => handleMenu(e, "add")}>
                                    <AddOne theme="outline" size="22" fill="#98a1b3" strokeWidth={3} strokeLinecap="butt" />Add
                                    <span className="dropIcon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M5 7.5L10 12.5L15 7.5" stroke="#636363" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </span>
                                </span>

                                <div className={
                                    menuList.add ? "bg_megamenu Bd_menu_visible" : "bg_megamenu "
                                }>
                                    <div className="rowGridFlex">
                                        <div className="megaLink" onClick={(e) => handleMenu(e, "add")}>
                                            <Link to={BIDGRIDROUTES?.LIVE_TENDERS}>
                                                Live Tender
                                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                    <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </Link>
                                        </div>
                                        <div className="megaLink" onClick={(e) => handleMenu(e, "add")}><Link to={BIDGRIDROUTES?.PROSPECTIVE_TENDER}>Prospective Tender
                                            <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                            </svg>
                                        </Link>
                                        </div>
                                        <div className="megaLink" onClick={(e) => handleMenu(e, "add")}>
                                            <Link to={BIDGRIDROUTES?.COMPANY}>
                                                Company
                                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                    <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </Link>
                                        </div>
                                        <div className="megaLink" onClick={(e) => handleMenu(e, "add")}>
                                            <Link to={BIDGRIDROUTES?.BANKGUARANTEE}>
                                                Bank Guarantee
                                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                    <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </li>


                            <li className={activeMenu === "tender" || activeMenu === "newassigne" || activeMenu === "bdtenderdetails" || activeMenu === "mis" ? "nav-item active tender_detail" : "nav-item tender_detail"}>
                                <span className="nav-link" onClick={(e) => handleMenu(e, "tender")}>
                                    <DocumentFolder theme="outline" size="22" fill="#98a1b3" strokeWidth={3} strokeLinecap="butt" /> Tenders
                                    <span className="dropIcon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M5 7.5L10 12.5L15 7.5" stroke="#636363" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </span>
                                </span>

                                <div className={
                                    menuList.tender ? "bg_megamenu Bd_menu_visible" : "bg_megamenu "
                                }>
                                    <div className="rowGridFlex">
                                        <div className="megaLink" onClick={(e) => handleMenu(e, "tender")}>
                                            <Link to={BIDGRIDROUTES?.New_assigne} >All Tender
                                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                    <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </Link>
                                        </div>


                                        <div className="megaLink" onClick={(e) => handleMenu(e, "tender")}>
                                            <Link to={BIDGRIDROUTES?.MIS} > MIS
                                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                    <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </Link>
                                        </div>
                                        <div className="megaLink" onClick={(e) => handleMenu(e, "tender")}>
                                            <Link to={BIDGRIDROUTES?.Trash} > Trash
                                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                    <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li className={activeMenu === "personal" || activeMenu === "todo" || activeMenu === "wishlist" || activeMenu === "reminder" ? "nav-item active personal" : "nav-item personal"}>
                                <span className="nav-link" onClick={(e) => handleMenu(e, "personal")}>
                                    <ViewList theme="outline" size="22" fill="#98a1b3" strokeWidth={3} strokeLinecap="butt" /> Personal
                                    <span className="dropIcon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M5 7.5L10 12.5L15 7.5" stroke="#636363" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </span>
                                </span>

                                <div className={
                                    menuList.personal ? "bg_megamenu Bd_menu_visible" : "bg_megamenu "
                                }>
                                    <div className="rowGridFlex">
                                        <div className="megaLink" onClick={(e) => handleMenu(e, "personal")}>
                                            <Link to={BIDGRIDROUTES?.ToDo} >Todo
                                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                    <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </Link>

                                        </div>

                                        <div className="megaLink" onClick={(e) => handleMenu(e, "personal")}>
                                            <Link to={BIDGRIDROUTES?.WISHLIST}>  Wishlist

                                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                    <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </Link>
                                        </div>

                                        <div className="megaLink" onClick={(e) => handleMenu(e, "personal")}>
                                            <Link to={BIDGRIDROUTES?.Personal_reminder}>Reminder

                                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                                    <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                                </svg>
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            </li>



                            {/* <Link to={BIDGRIDROUTES?.WORKLOAD_DISTRIBUTION} className="nav-item ">
                                <span className={activeMenu === "workdistribution" ? "nav-link active" : "nav-link "} onClick={(e) => handleMenu(e, "workdistribution")}><SummarizeIcon />Reports</span>
                            </Link> */}


                            <Link to={BIDGRIDROUTES?.briefcase} className={activeMenu === "briefcase" ? "nav-item active" : "nav-item "}>
                                <span className="nav-link" onClick={(e) => handleMenu(e, "briefcase")}>
                                    <FolderClose theme="outline" size="22" fill="#98a1b3" />
                                    Briefcase
                                </span>
                            </Link>


                            <Link to={BIDGRIDROUTES?.EMPLOYEELIST} className={activeMenu === "employeelist" ? "nav-item active" : "nav-item "}>
                                <span className="nav-link" onClick={(e) => handleMenu(e, "employeelist")} ><UserBusiness theme="outline" size="22" fill="#98a1b3" strokeWidth={3} strokeLinecap="butt" />Employee List</span>
                            </Link>

                            {/* <Link to={BIDGRIDROUTES?.PDF} className="nav-item">
                                <span className={activeMenu === "mis" ? "nav-link active" : "nav-link "} onClick={(e) => handleMenu(e, "pdf")} >PDF</span>
                            </Link> */}
                        </ul>
                    </div>
                    <div className="bd_profileMenu" onClick={(e) => handleMenu(e, "profile")}>
                        <div className="bd_userProfile">
                            {/* <img src={ProfileIMage} alt="bdimg" /> */}
                            {userBidInfo?.profileimg ?
                                <img alt='' className="img-thumbnail rounded-circle"
                                    src={userBidInfo?.profileimg !== null ? `${docurlchat}${userBidInfo.profileimg_path}/${userBidInfo.profileimg}` : DefaultImage}
                                /> :
                                <Avatar style={{ width: '40px', height: '40px' }}>
                                    {userBidInfo?.firstname !== null ?
                                        userBidInfo?.firstname?.charAt(0) : userBidInfo?.userfullname?.charAt(0)}
                                </Avatar>
                            }
                        </div>

                        <div className="bd_para">
                            <h4>{userBidInfo?.userfullname} </h4>
                            <p>{designation}</p>
                        </div>
                        <div style={{ paddingLeft: 10, marginLeft: "auto" }}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M5 7.5L10 12.5L15 7.5" stroke="#636363" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                        </div>

                        <div className={
                            menuList.profile ? "bg_megamenu Bd_menu_visible" : "bg_megamenu"
                        }>
                            <div className="rowGridFlex">
                                <div className="megaLink">
                                    <Link to={BIDGRIDROUTES?.PROFILE} onClick={(e) => handleMenu(e, "profile")}>
                                        <span>
                                            <img src={profileImg} alt="" />
                                            Profile
                                        </span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                            <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </Link>
                                </div>

                                {/* <div className="megaLink" onClick={(e) => handleMenu(e, "profile")}>
                                    <Link to={BIDGRIDROUTES?.Task_assigine}>
                                        <span>
                                            <img src={taskImg} alt="" />
                                            TaskManage
                                        </span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                            <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </Link>
                                </div> */}

                                {/* <div className="megaLink" onClick={(e) => handleMenu(e, "profile")}>
                                    <Link to={BIDGRIDROUTES?.PROFILE}>
                                        <span>
                                            <img src={ChatImg} alt="" />
                                            Chat
                                        </span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                            <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </Link>
                                </div> */}
                                <div className="megaLink">
                                    <Link to={BIDGRIDROUTES?.SETTINGS}>
                                        <span>
                                            <img src={whishlistImg} alt="" />
                                            Setting
                                        </span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                            <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </Link>
                                </div>

                                <div className="megaLink" >
                                    <Link to={BIDGRIDROUTES?.MEETING}>
                                        <span>
                                            <AccessTimeIcon style={{ width: '25', height: '25' }} />
                                            Meeting Schedule
                                        </span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                            <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </Link>

                                </div>
                                <div className="megaLink" >
                                    <Link to={BIDGRIDROUTES?.document_share}>
                                        <span>
                                            <ShareOne theme="outline" size="22" fill="#98a1b3" strokeWidth={3} strokeLinecap="butt" />Document Share
                                        </span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                            <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </Link>


                                </div>

                                <div className="megaLink" >
                                    <Link to={BIDGRIDROUTES?.REQUEST}>
                                        <span>
                                            <img src={briefcaseImg} style={{ width: 22, opacity: ".6" }} />
                                            Request
                                        </span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                            <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </Link>

                                </div>
                                <div className="megaLink" onClick={(e) => handleMenu(e, "profile")}>
                                    <a >
                                        <span onClick={handleLogout}>
                                            <img src={logoutImg} alt="" />
                                            Logoutddd
                                        </span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="19" height="18" viewBox="0 0 19 18" fill="none">
                                            <path d="M7 13.5L11.5 9L7 4.5" stroke="#DADADA" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="notification_wrap">
                        <Dropdown
                            menu={{
                                items,
                            }}
                            dropdownRender={(menu) => (
                                <div className="notification_Dropdown">
                                    <div className="noti_header">Notification</div>
                                    {React.cloneElement(menu, {
                                        // style: menuStyle,
                                    })}
                                </div>
                            )}
                            trigger={['click']}
                            placement="bottomRight"
                        // arrow
                        >
                            <div>
                                <span className="countNum">{notification?.length}</span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24">
                                    <path fill="currentColor" d="M10.146 3.248a2 2 0 0 1 3.708 0A7.003 7.003 0 0 1 19 10v4.697l1.832 2.748A1 1 0 0 1 20 19h-4.535a3.501 3.501 0 0 1-6.93 0H4a1 1 0 0 1-.832-1.555L5 14.697V10c0-3.224 2.18-5.94 5.146-6.752zM10.586 19a1.5 1.5 0 0 0 2.829 0h-2.83zM12 5a5 5 0 0 0-5 5v5a1 1 0 0 1-.168.555L5.869 17H18.13l-.963-1.445A1 1 0 0 1 17 15v-5a5 5 0 0 0-5-5z" />
                                </svg>
                            </div>
                        </Dropdown>
                    </div>
                </div>
            )}

            <div className="bd_overly" style={overlayShow ? { display: "block" } : { display: "none" }}></div>
        </>
    )
}
export default BdHeader;