// @ts-nocheck
import React, { useState } from 'react';
import { Button, Flex, Form, Input, Modal, Select } from 'antd';
import { Down } from '@icon-park/react';
import { factSheet } from 'Services/bidgrid/factSheet/factSheet';
import html2pdf from 'html2pdf.js';
import ReactDOMServer from 'react-dom/server';
import { docurlchat } from 'utils/configurable';
import dayjs from 'dayjs';
import { saveAs } from 'file-saver';
import { toast } from 'react-toastify';




const FactSheetEmailModal = (props) => {
    const { isModalOpen, setFactsheetEmailModalOpen, projectId, userListData } = props
    const [form] = Form?.useForm();
    const [sheetTypeVal, setSheetTypeVal] = useState(null);

    const notifySuccess = (msg, id) => toast.success(msg, { toastId: id });


    const handleCancel = () => {
        setFactsheetEmailModalOpen(false);
    };

    const handleReset = () => {
        form?.resetFields();
    };



    // Factsheet content
    const createHtmlContentForDoc = (contentData) => {
        const regex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;

        return `
                <html lang="en">
                    <head>
                    </head>
                    <body>
                        <div class="fact_sheet_main">
                            <div class="logo_ggpl" style="text-align: center">
                                <img  src="${docurlchat + contentData?.logo}" width="100" height="100" alt="logo"  />

                            </div>
                            <div class="heading_fact_sheet">
                                <h2 style="text-align: center;
                                font-weight: 700;
                                font-size: 26px;
                                margin-block: 10px;">${contentData?.comp_name}</h2>
                                <div class="ref_no_wraper" style="display: flex;
                                align-items: center;
                                justify-content: space-between;">
                                    <div>
                                        <p>${contentData?.ref_no}</p>
                                    </div>
                                    <div>
                                        <p>Date: ${dayjs(contentData?.bid_date).subtract(dayjs(contentData?.bid_date).utcOffset(), 'minute').format("DD MMM YYYY")}</p>
                                    </div>


                                </div>
                            </div>
                            <div class="project_name" style="border: 1px solid black;
                            border-bottom: 0;
                            background: #deeaf6;
                            padding: 20px; width: 1000">
                                <p>SUB : ${contentData?.subject},
                                </p>
                            </div>
                            <table class="table_one_factsheet">
                                <thead>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Description</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                ${contentData?.comp_assign_desc_arr?.map(item => `
                                <tr>
                                    <td>${item?.sr_no}</td>
                                    <td>${item?.desc_name}:</td>
                                    <td>${regex.test(item?.fs_desc_remark) ? dayjs(item?.fs_desc_remark).subtract(dayjs(item?.fs_desc_remark).utcOffset(), 'minute').format("DD MMM YYYY") : item?.fs_desc_remark}</td>
                                </tr>
                            `).join('')}
                                                                    
                                </tbody>
                            </table>
                            <div class="notes_fact_sheet" style="border: 1px solid black;">
                                <p style=" font-weight: 100;
                                margin: 0;
                                padding: 8px;">Notes-${contentData?.notes}</p>
                            </div>
                            <div class="preparedby_fact_sheet" style="padding-bottom: 50px;
                            border: 1px solid black;
                            display: flex;
                            gap: 150px;
                            padding-top: 10px;
                            border-bottom: 0;
                            border-top: 0;
                            padding-left: 10px;">
                                <p style="font-weight: 100; margin: 0;">Prepared By</p>
                                <p style="font-weight: 100; margin: 0;">Regional In-charge</p>
                                <p style="font-weight: 100; margin: 0;">Director</p>
                            </div>
                            <table class="table_two_fs" style="width: 100%;
                            border-collapse: collapse;">
                                <tr>
                                    <th></th>
                                    <th></th>
                                </tr>
                                <tr>
                                    <td>HO Contracts:</td>
                                    <td>${contentData?.ho_contract}</td>
                                </tr>
                            </table>
                            <div class="bottam_divfact_sheet" style="border: 1px solid black;
                            height: 20px;
                            border-top: 0;">

                            </div>
                        </div>
                    </body>
                </html>`
    }

    const createHtmlContentForPdf = (contentData, base64Image) => {

        return (
            <>
                <div class="fact_sheet_main">
                    <div class="logo_ggpl">
                        <img src={base64Image} alt="logo" />

                    </div>
                    <div class="heading_fact_sheet">
                        <h2>{contentData?.comp_name}</h2>
                        <div class="ref_no_wraper">
                            <div>
                                <p>{contentData?.ref_no}</p>
                            </div>
                            <div>
                                <p>Date: {dayjs(contentData?.bid_date).format('DD/MM/YYYY')}</p>
                            </div>


                        </div>
                    </div>
                    <div class="project_name">
                        <p>SUB : {contentData?.subject},
                        </p>
                    </div>
                    <table class="table_one_factsheet">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Description</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                contentData?.comp_assign_desc_arr?.map((item) => {

                                    return (
                                        <tr>
                                            <td>{item?.sr_no}</td>
                                            <td>{item?.desc_name}:</td>
                                            <td>{item?.fs_desc_remark}
                                            </td>
                                        </tr>
                                    )
                                })
                            }


                        </tbody>
                    </table>
                    <div class="notes_fact_sheet">
                        <p>Notes-{contentData?.notes}</p>
                    </div>
                    <div class="preparedby_fact_sheet">
                        <p>Prepared By</p>
                        <p>Regional In-charge</p>
                        <p>Director</p>
                    </div>
                    <table class="table_two_fs">
                        <tr>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>HO Contracts:</td>
                            <td>{contentData?.ho_contract}</td>
                        </tr>
                    </table>
                    <div class="bottam_divfact_sheet">

                    </div>
                </div>
            </>

        )
        //    }
    }

    const uploadFs = async (pId, fileBlob, type) => {
        console.log('type===========>>',type);

        try {
            const uploadFileData = new FormData();
            uploadFileData.append('project_id', pId);
            uploadFileData.append('files', new File([fileBlob], `factsheet.${type}`, { type: `application/${type}` }));

            let uploadResult = await factSheet.preparedFsUpload(uploadFileData);
            console.log('uploadResult==217===', uploadResult);
            if(uploadResult?.data?.status==1){
                notifySuccess(uploadResult?.data?.message);
            }
        } catch (error) {
            console.log(error);
        }

    }

    const handleSubmit = async (values) => {
        // setSheetTypeVal(values?.sheet_type);
        try {
            const formData = new URLSearchParams();
            formData.append('project_id', projectId);
            formData.append('assign_to', values?.assign_to);
            formData.append('subject', values?.subject);
            formData.append('remark', values?.remark);
            formData.append('ho_contract', values?.ho_contract);
            formData.append('sheet_type', values?.sheet_type);

            let response = await factSheet.fsPrepareEmail(formData);
            if (response?.data?.status == 1) {
                handleReset();
                handleCancel();

                const formDataTemplate = new URLSearchParams();
                formDataTemplate.append('project_id', projectId);
                let downloadTemplateResponse = await factSheet.fsPrepareTemplate(formDataTemplate);


                const transformedData = downloadTemplateResponse?.data?.data.reduce((result, item) => {
                    Object.keys(item).forEach(key => {
                        result[key] = item[key];
                    });
                    return result;
                }, {});


                if (transformedData) {
                    if (values?.sheet_type == 2) {        // 2 value for Pdf
                        try {
                            const response = await fetch(docurlchat + transformedData?.logo);

                            if (!response.ok) {
                                throw new Error(`Failed to fetch image: ${response.statusText}`);
                            }
                            else {
                                const blob = await response.blob();
                                const reader = new FileReader();
                                reader.readAsDataURL(blob);
                                reader.onloadend = () => {
                                    const htmlContentt = createHtmlContentForPdf(transformedData, reader.result);
                                    const element = document.createElement('div');
                                    element.innerHTML = ReactDOMServer.renderToString(htmlContentt);

                                    // html2pdf(element, {
                                    //     margin: 10,
                                    //     filename: 'factsheet.pdf',
                                    //     image: { type: 'jpeg', quality: 0.98 },
                                    //     html2canvas: { scale: 2 },
                                    //     jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
                                    // });


                                    const opt = {
                                        margin: 10,
                                        filename: 'factsheet.pdf',
                                        image: { type: 'jpeg', quality: 0.98 },
                                        html2canvas: { scale: 2 },
                                        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
                                    };

                                    // Create the PDF and convert it to a Blob
                                    html2pdf().from(element).set(opt).outputPdf('blob').then((pdfBlob) => {
                                        // Save the PDF to the user's computer
                                        saveAs(pdfBlob, 'factsheet.pdf');

                                        // Upload the generated PDF Blob to the server
                                        uploadFs(projectId, pdfBlob, 'pdf');

                                    }).catch(error => {
                                        console.error('Error generating PDF:', error);
                                    });
                                };


                            }
                        } catch (error) {
                            console.error('Error converting image to base64:', error);
                        }

                    }
                    else {                              // 1 value for Doc
                        console.log('===311====');
                        const htmlContentt = createHtmlContentForDoc(transformedData);
                        if (htmlContentt) {
                        console.log('===314====');
                            const blob = new Blob(['\ufeff', htmlContentt], { type: 'application/msword' });
                            saveAs(blob, 'factsheet.doc');
                        console.log('===317====');
                            uploadFs(projectId, blob , 'doc');
                        }
                    }
                }

            }
        } catch (error) {
            console.log('error', error);
        }

    }


    return (
        <>
            <Modal title="Fact Sheet Download" open={isModalOpen} footer={false} onCancel={handleCancel}>
                <Form form={form} name="validateOnly" layout="vertical" autoComplete="off" onFinish={handleSubmit}

                >
                    <Form.Item name='subject' label="Subject" rules={[{ required: true, message: 'Subject is required' }]}>
                        <Input

                            placeholder='Enter here...'
                        />
                    </Form.Item>
                    <Form.Item name='sheet_type' label="Sheet Type:" rules={[{ required: true, message: 'Sheet type is required' }]}>
                        <Select
                            showSearch
                            options={[
                                {
                                    value: '1',
                                    label: 'DOC',
                                },
                                {
                                    value: '2',
                                    label: 'PDF',
                                },
                            ]}
                            placeholder="Select"
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            filterOption={(input, option) =>
                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                        </Select>
                    </Form.Item>

                    <Form.Item name='assign_to' label="Bid Manager:" rules={[{ required: true, message: 'Role is required' }]}>
                        <Select
                            showSearch
                            mode='multiple'
                            options={userListData?.map((item, index) => {
                                return {
                                    value: item?.id,
                                    label: item?.userfullname
                                }
                            })}

                            placeholder="Select"
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            filterOption={(input, option) =>
                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                        </Select>
                    </Form.Item>

                    <Form.Item name='remark' label="Remark" rules={[{ required: true, message: 'Remark is required' }]}>
                        <Input
                            // value={editModalData?.unit_name}
                            placeholder='Enter here...'
                        // onChange={(e) => handleSelectChange('unit_name', e.target.value)}
                        />
                    </Form.Item>

                    <Form.Item name='ho_contract' label="Ho Contracts" rules={[{ required: true, message: 'Ho Contract is required' }]}>
                        <Input

                            // value={editModalData?.unit_name}
                            placeholder='Enter here...'
                        // onChange={(e) => handleSelectChange('unit_name', e.target.value)}
                        />
                    </Form.Item>
                    <Flex justify='flex-end' align='center'>
                        <Button key="back"
                            onClick={() => handleReset()}
                            className='BG_ghostButton' >
                            Reset
                        </Button>
                        <button key="submit" style={{ marginLeft: '20px' }} className='BG_mainButton'>
                            Submit
                        </button>
                    </Flex>
                </Form>
            </Modal>
        </>
    )
}


export default FactSheetEmailModal;