// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Select, Form, Modal, Input, Button } from 'antd';
import { Down } from '@icon-park/react';
import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';

const { Option } = Select;
const initialState = {
    collection_name: ''
}

function TenderWishListModal({ isModalOpen, handleCancel, setIsModalOpen, itemId, getActionListApi }) {
    const [form] = Form.useForm();
    const [collect, setCollect] = useState(false)
    const [selectedItem, setSelectedItem] = useState({
        tender_id: '',
        collection_id: [],
        share_id: [],
        person_ids: [],
    });
    const [selected, setSelected] = useState(null);
    const [wishListAdd, setWishListAdd] = useState('')
    const [datasource, setDatasource] = useState()
    const [privacyList, setprivacyList] = useState()
    const [userList, setUserList] = useState()
    const [showNotification, setShowNotification] = useState(false);
    const [loadings, setLoadings] = useState(false)

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const { bidgridData } = useSelector((state) => state.loginData)

    const handleCollection = () => {
        setCollect(true)
        setIsModalOpen(false)
    }
    const handleClose = () => {
        setCollect(false)
        setIsModalOpen(true)
        form.resetFields()
    }
    const handleChange = (value) => {
        setSelected(value);
    };

    const WishlistCollectionList = async () => {
        try {
            const response = await tenderCycle?.bdwishlistCollection()
            if (response?.data?.status == 1) {
                setDatasource(response?.data?.data)
                // notifySuccess(response?.data?.message)
            }
        } catch (error) {
            console.log('Api Error', error);
            notify('Error')

        }
    }

    // add collection api
    const AddToWishListData = async () => {
        setLoadings(true)
        if (wishListAdd) {
            try {
                const formdata = new URLSearchParams()
                formdata.append('collection_name', wishListAdd)
                const response = await tenderCycle?.bdwishlist(formdata)

                if (response?.data?.status == 1) {
                    // await WishlistCollectionList()
                    setCollect(false)
                    setIsModalOpen(true)
                    handleReset()
                    notifySuccess(response?.data?.message)
                    form.resetFields()

                }
                else {
                    notify(response?.response?.data?.message)

                    // handleReset()
                }
            } catch (error) {
                notify('Error')

            }

            setTimeout(() => {
                setLoadings(false)

            }, 2000)
        }

    }

    // user list api 
    const AllUserList = async () => {
        try {
            const response = await bidEmployeeList?.getUserList()
            if (response?.data?.status === '1') {
                setUserList(response?.data?.data)
            }
        } catch (error) {

        }
    }

    // privacy list api 
    const getPrivacyList = async () => {
        try {
            const response = await tenderCycle?.bdPrivacyList()
            if (response?.data?.status === '1') {
                setprivacyList(response?.data?.data)
            }
        } catch (error) {
            console.log('Api Error');
        }
    }

    const ids = datasource?.map((item, index) => {
        return {
            value: item?.id
        }
    })


    // useEffect(() => {
    //     AllUserList()
    // }, [privacyList])

    useEffect(() => {
        if (isModalOpen === true) {
            WishlistCollectionList();
            getPrivacyList()
        }
    }, [isModalOpen])

    const handleModalInput = (e) => {
        setWishListAdd(e?.target?.value)
    }
    const handleReset = () => {
        setWishListAdd('')
        form?.resetFields()
    };

    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            AddToWishListData()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleSelectChange = (key, value) => {
        if (key === "person_ids") {
            setSelectedItem({
                ...selectedItem, [key]: value
            })
        } else if (key === 'share_id') {
            setSelectedItem({
                ...selectedItem, [key]: value
            })
            if (key === 'share_id' && value === 3) {
                setSelected(value);
                AllUserList();
            }
            else {
                setSelected(null)
            }
        } else {
            setSelectedItem({
                ...selectedItem, [key]: value
            })
            if (key === 'share_id' && value === 3) {
                setSelected(value);
                AllUserList();
            }
        }

    }

    const handleSubmit = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('tender_id', itemId);
            formData.append('collection_id', selectedItem.collection_id);
            formData.append('share_id', selectedItem.share_id);
            formData.append('person_ids', selectedItem.person_ids);

            let result = await tenderCycle.bdAddToWishList(formData);

            if (result?.data?.data?.status === '1') {
                notifySuccess(result?.data?.message)
                setIsModalOpen(false)
                setSelectedItem((pre) => {
                    return {
                        ...pre,
                        tender_id: '',
                        collection_id: [],
                        share_id: [],
                        person_ids: [],
                    }
                })
                form?.resetFields()
                setSelected(null)
                getActionListApi();

            } else {
                if (!showNotification) {
                    notify(result?.response?.data?.message)
                    setShowNotification(true);

                    setTimeout(() => {
                        setShowNotification(false);
                    }, 2500);
                }
            }

        }
        catch (e) {
            notify("Server Error!!");
        }
    }
    const handleCloseModal = () => {
        setSelectedItem((pre) => {
            return {
                ...pre,
                tender_id: '',
                collection_id: [],
                share_id: [],
                person_ids: [],
            }
        })
        form?.resetFields()
        setIsModalOpen(false)
    }

    return (
        <>
            <Modal className='bd_model_main' title="WishList" open={isModalOpen} onCancel={handleCloseModal}
                footer={[
                    <button key="submit" className='BG_ghostButton' onClick={handleCollection}>
                        Create Collection
                    </button>,
                    <button key="back" className={(selectedItem.collection_id == '' || selectedItem.share_id == '') ? 'disabledBtn' : 'BG_mainButton'} disabled={(selectedItem.collection_id == '' || selectedItem.share_id == '') ? true : false} onClick={handleSubmit} >
                        Submit
                    </button>
                ]}
            >
                <Form name="validateOnly" name="control-hooks" layout="vertical" autoComplete="off" >
                    <Form.Item label="My Collection" rules={[{ required: true }]} >
                        <Select
                            showSearch
                            allowClear={true}
                            placeholder="Select Collection"
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            options={datasource?.map((item, index) => ({
                                value: item?.id,
                                label: item?.collection_name,
                            }))}
                            name='collection_id'
                            value={selectedItem?.collection_id}
                            onChange={(e) => handleSelectChange('collection_id', e)}
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            filterOption={(input, option) =>
                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        ></Select>
                    </Form.Item>

                    <Form.Item label="Select Privacy" rules={[{ required: true }]}>
                        <Select
                            showSearch
                            placeholder="-Select Privacy-"
                            optionFilterProp="children"
                            filterOption={(input, option) => (option?.label ?? '').includes(input)}
                            filterSort={(optionA, optionB) =>
                                (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                            }
                            suffixIcon={<Down theme="outline" size="20" fill="#636363" />}
                            options={privacyList?.map((item, index) => {
                                return {
                                    label: item?.privacy,
                                    value: item?.id
                                }
                            })}
                            name='share_id'
                            value={selectedItem?.share_id}
                            onChange={(e) => handleSelectChange('share_id', e)}
                            filterOption={(input, option) =>
                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }

                        />
                    </Form.Item>

                    {
                        selected === 3 && (
                            <Form.Item label="Shared" rules={[{ required: true }]} >
                                <Select
                                    mode='multiple'
                                    showSearch
                                    placeholder="Select Option"
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    options={userList?.filter((item) => item?.id !== bidgridData?.data?.id).map((item, index) => {
                                        return {
                                            label: item?.userfullname,
                                            value: item?.id
                                        }
                                    })}
                                    name='person_ids'
                                    value={selectedItem?.person_ids}
                                    onChange={(e) => handleSelectChange('person_ids', e)}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                />

                            </Form.Item>

                        )}
                </Form>


            </Modal>


            <Modal className='bd_model_main' title="Add Collection" open={collect} onCancel={() => { setCollect(false); form.resetFields(); }}
                footer={[
                    <button key="back" className='BG_ghostButton' onClick={handleClose}>
                        Close
                    </button>,
                    <Button className='BG_mainButton' type="primary" htmlType="submit" loading={loadings} disabled={loadings} onClick={AddToWishListData}>
                        Save
                    </Button>

                ]}>
                <Form form={form} name="validateOnly" layout="vertical" autoComplete="off" onKeyDown={handleKeyPress} >
                    <Form.Item label="Add Collection" name='collection_name' rules={[{ required: true }]} >
                        <Input
                            placeholder="Enter Here"
                            name='collection_name'
                            value={wishListAdd}
                            onChange={(e) => handleModalInput(e)}
                        />
                    </Form.Item>
                </Form>


            </Modal>
        </>
    )
}

export default TenderWishListModal