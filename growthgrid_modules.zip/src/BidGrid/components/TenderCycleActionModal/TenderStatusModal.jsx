import { Down } from '@icon-park/react'
import { Form, Input, Modal, Select } from 'antd'
import React from 'react'


function TenderStatusModal({ tenderStatusOpen, tenderStatus }) {
    return (
        <Modal className='bd_model_main' title="Assign Project Status" open={tenderStatusOpen} onCancel={tenderStatus}
            footer={[
                <button key="back" className='BG_ghostButton' >
                    Reset
                </button>,
                <button key="submit" className='BG_mainButton' >
                    Submit
                </button>

            ]}
        >
            <Form name="validateOnly" layout="vertical" autoComplete="off" >

                <Form.Item label="Project Status" name='subject' rules={[{ required: true }]}>
                    <Select
                        showSearch
                        placeholder="Select"
                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                    ></Select>
                </Form.Item>


            </Form>

        </Modal>
    )
}

export default TenderStatusModal