import { Modal } from 'antd'
import React from 'react'

function TenderSubmitModal({ submitOpen, handleSubmitCancel }) {
  return (
    <div style={{ marginTop: "0px" }}>

      <Modal
        className="bd_delete_model"
        onCancel={handleSubmitCancel}
        open={submitOpen}
        footer={[
          <button className='BG_ghostButton' key="cancel" >
            Cancel
          </button>,
          <button className='BG_deleteButton' key="delete">
            Submit
          </button>
        ]}
      >
        <div className='bd_delete_container'>
          <span className='bd_delete_spn'>Are you sure you want to Submit this Tender ? </span>
          <p>Tender Status would be changed to submitted !</p>
        </div>
      </Modal>
    </div>
  )
}

export default TenderSubmitModal