// @ts-nocheck
import React, { useState } from 'react'
import { Select, Button, Form, Modal, Input, DatePicker, Row, Col } from 'antd';
import { Down } from '@icon-park/react';
import { toast } from 'react-toastify';
import dayjs from 'dayjs';
import { ReminderList } from 'Services/bidgrid/Reminder/bidreminder';

const initialestate = {
    reminder_date: '',
    reminder_subject: '',
    reminder_message: '',
    tender_id: '',
}
function TenderRemainderModal({ remind, handleRemindCancel, itemId, getActionListApi }) {
    const [disableBtn, setDisableBtn] = useState(false)
    const [form] = Form.useForm();
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [sectorName, setSectorName] = useState(initialestate)

    const createHandler = async () => {
        setDisableBtn(true)
        form.validateFields();

        if (
            sectorName?.reminder_date &&
            sectorName?.reminder_subject &&
            sectorName?.reminder_message

        ) {
            const formData = new URLSearchParams();

            formData.append('reminder_date', dayjs(sectorName?.reminder_date)?.format('YYYY-MM-DD'));

            formData.append('reminder_message', sectorName?.reminder_message)
            formData.append('reminder_subject', sectorName?.reminder_subject)
            formData.append('tender_id', itemId) // itemId?.id
            try {
                const response = await ReminderList.addReminder(formData)
                if (response?.data?.status == 1) {
                    //   getreminder()
                    notifySuccess(response?.data?.message);
                    // notifySuccess("Reminder created successfully");

                    handleRemindCancel()
                    handleReset()
                    getActionListApi()

                } else {
                    notify(response?.response?.data?.message);
                    handleReset()
                }
            } catch (error) {
                handleReset()
                console.log('Api Error', error)
            }
        }
        setTimeout(() => {
            setDisableBtn(false)
        }, 2000);

    }

    const handleReset = () => {

        setSectorName('');
        form.resetFields()
    };

    const handleInputChange = (name, value) => {

        setSectorName({
            ...sectorName,
            [name]: value
        })
    };
    return (
        <Modal className='bd_model_main' title="Add Reminder" open={remind} onCancel={handleRemindCancel}
            footer={[
                <button key="back" className='BG_ghostButton' onClick={handleReset}>
                    Reset
                </button>,
                <button key="submit" className='BG_mainButton' onClick={createHandler} disabled={disableBtn}>
                    Submit
                </button>

            ]}
        >
            <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" >
                <Row gutter={30}>
                    <Col span={12}>
                        <Form.Item label=" Reminder Date" name='reminder_date' rules={[{ required: true, message: 'Date is required' }]} >
                            <DatePicker
                                showTime
                                placeholder="Select date"
                                name='reminder_date'
                                value={sectorName?.reminder_date}
                                onChange={(e) => handleInputChange('reminder_date', e)}
                                disabledDate={(current) => current && current < dayjs().startOf('day')}
                                disabledTime={(current) =>
                                    current && current < dayjs()
                                        ? {
                                            disabledHours: () =>
                                                Array.from({ length: dayjs().hour() }).map((_, i) => i),
                                            disabledMinutes: () =>
                                                Array.from({ length: dayjs().minute() }).map((_, i) => i),
                                            disabledSeconds: () =>
                                                Array.from({ length: dayjs().second() }).map((_, i) => i),
                                        }
                                        : {}
                                }
                            />

                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item label="Subject" name='reminder_subject'
                            rules={[{ required: true, message: 'subject is required' }]}>
                            <Input
                                name='reminder_subject'
                                placeholder="Enter here.."
                                onChange={(e) => handleInputChange("reminder_subject", e.target.value)}
                                value={sectorName?.reminder_subject}
                            ></Input>
                        </Form.Item>
                    </Col>

                    <Col span={24}>
                        <Form.Item label="Message" name='reminder_message' rules={[{ required: true, message: ' Message is required' }]}>
                            <Input.TextArea
                                placeholder="Enter here.."
                                value={sectorName?.reminder_message}
                                onChange={(e) => handleInputChange('reminder_message', e.target.value)} />
                        </Form.Item>
                    </Col>
                    {/* <Col span={24}>
                        <Form.Item label="Tender Id" name='Remainder_Id' rules={[{ required: true ,message: 'Tender Id is required'}]}>
                            <Input
                                name='tender_id'
                                placeholder="Tender Id"
                                // onChange={(e) => handleInputChange("Remainder_Id", e.target.value)}
                                value={itemId}
                            
                            ></Input>
                        </Form.Item>
                    </Col> */}
                </Row>
            </Form>

        </Modal>
    )
}

export default TenderRemainderModal