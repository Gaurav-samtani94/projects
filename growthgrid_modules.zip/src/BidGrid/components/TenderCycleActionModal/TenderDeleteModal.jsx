// @ts-nocheck
import { Modal } from 'antd'
import React from 'react'
import { toast } from 'react-toastify';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi'
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import ROUTES from 'Constants/Routes';

function TenderDeleteModal({ deleteOpen, handleDelete, itemId, setdeleteOpen, getTenders, setTenders, getAllTenders }) {
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);

  const navigate = useNavigate()
  const handleCloseModel = () => {
    setdeleteOpen(false)
  }

  const handleDeleteTender = async () => {
    const formData = new URLSearchParams();
    formData.append("tender_id", itemId);
    try {
      const response = await TenderApi.DeleteTender(formData);
      if (response?.data?.status === '1') {
        navigate(ROUTES.New_assigne)
        setdeleteOpen(false);
        getAllTenders()
        notifySuccess(response?.data?.message);
      } else {
        notify(response?.data?.message);
      }
    } catch (err) {
      console.log(err)
    }
  }

  return (
    <div style={{ marginTop: "0px" }}>

      <Modal
        className="bd_delete_model"
        open={deleteOpen}
        onCancel={handleCloseModel}
        footer={[
          <button className='BG_ghostButton' key="cancel" onClick={handleCloseModel} >
            Cancel
          </button>,
          <button className='BG_deleteButton' key="delete"
            onClick={handleDeleteTender}
          >
            Delete
          </button>
        ]}
      >
        <div className='bd_delete_container'>
          <span className='bd_delete_spn'>Are you sure you want to delete this ?</span>
          <p>If you delete the file, you can't recover it.</p>
        </div>
      </Modal>
    </div>
  )
}

export default TenderDeleteModal