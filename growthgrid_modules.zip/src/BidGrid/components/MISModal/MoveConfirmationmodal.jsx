import React from "react";
import { Modal } from 'antd'


const MoveConfirmationModal = (props) => {
    const { confirmationModal, item, statusChange, setConfirmationModal, handleSubmitTender, move, handleSubmitMultipleTender, selectedItems, onChangeScopeId, singleDropDownList, multiDropDownList } = props

    const handleCloseModel = () => {
        setConfirmationModal(false)
    }

    const handleDeleteTender = () => {
        move == "SINGLE" ? handleSubmitTender(statusChange, item?.id) : handleSubmitMultipleTender(onChangeScopeId, selectedItems)
    }

    // const stageName = move =='SINGLE' ? singleDropDownList?.find(sdropVal=>sdropVal?.id==statusChange)?.cycle_name :  multiDropDownList?.find(mdropVal=>mdropVal?.id==onChangeScopeId)?.cycle_name ;

    const stageMyName = () => {
        let stageName = '';
        if (move === 'SINGLE') {
            stageName = singleDropDownList?.find(sdropVal => sdropVal?.id == statusChange)?.cycle_name;
        }
        else if (move === 'MULTIPLE') {
            stageName = multiDropDownList?.find(mdropVal => mdropVal?.id == onChangeScopeId)?.cycle_name;
        }
        return stageName ? 'into' + ' ' + stageName : '';
    }

    return (
        <>
            <div style={{ marginTop: "0px" }}>

                <Modal
                    className="bd_delete_model"
                    open={confirmationModal}
                    onCancel={handleCloseModel}
                    footer={[
                        <button className='BG_ghostButton' key="cancel" onClick={handleCloseModel} >
                            Cancel
                        </button>,
                        <button className='BG_deleteButton' key="delete"
                            onClick={handleDeleteTender}
                        >
                            Move
                        </button>
                    ]}
                >
                    <div className='bd_delete_container'>
                        <span className='bd_delete_spn'>Are you sure, Want to move this tender {stageMyName()} ?</span>
                        {/* <p>If You Move The Tender, You Can't Recover It.</p> */}
                    </div>
                </Modal>
            </div>
        </>
    )
}

export default MoveConfirmationModal;