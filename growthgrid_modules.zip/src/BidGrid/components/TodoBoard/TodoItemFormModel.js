// @ts-nocheck
import { useEffect, useRef, useState, useMemo } from 'react';
import { Button, Form, Input, Radio, Select, Modal, Col, Row, DatePicker, Upload, Card, Avatar, Flex } from 'antd';
import { Down } from '@icon-park/react';
import dayjs from 'dayjs';
import { TodoServices } from 'Services/bidgrid/todo/TodoServices';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { docurlchat } from 'utils/configurable';
import { CloseOutlined } from '@ant-design/icons';
export const TaskboardItemFormValues = {
    title: '',
    description: '',
};
const { Option } = Select;

const hashtasgs = [
    {
        id: 94,
        hashtag_name: "#ssssssssss"
    },
    {
        id: 87,
        hashtag_name: "#stand"
    },
]

function TodoItemFormModel(props) {
    const { initialState, visible, assignTask, setAssignTask, setRecordData, dropdownValState, setOpen, recordData, setIsCreatedAndUpdate, documentData, setIsUpdate, projectId, setDropdownValState } = props;

    const [file, setFile] = useState([])
    const [form] = Form.useForm();
    const inputRef = useRef(null);
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const { userBidInfo } = useSelector((state) => state?.userDetails)
    const [loadingTask, setLoadingTask] = useState(false);

    const beforeUpload = (file) => {
        const allowedFileTypes = ['image/jpeg', 'image/png', 'application/pdf', 'text/html'];


        if (!allowedFileTypes.includes(file.type)) {
            notify('You can only upload JPG, PNG, PDF, or HTML files!');
            return false;
        }


        return true;
    };

    const getBase64 = (file, callback) => {
        const reader = new FileReader();
        reader.addEventListener('load', () => callback(reader.result));
        reader.addEventListener('error', () => callback(null)); // Handle error case
        reader.readAsDataURL(file);
    };

    const handleDoc = (info) => {
        if (info.file.status === 'uploading') {
            Promise.all(info.fileList.map(file => new Promise((resolve, reject) => {
                getBase64(file.originFileObj, (url) => {
                    if (url) {
                        resolve({
                            uid: file.uid,
                            name: file.name,
                            status: 'done',
                            originFileObj: file.originFileObj,
                            url: url
                        });
                    } else {
                        reject(new Error('File is corrupted or invalid'));
                    }
                });
            })))
                .then(fileList => {
                    setFile(fileList);
                })
                .catch(error => {
                    console.error('Error processing files:', error);
                    // Handle the error, notify the user, etc.
                });
        }
    };

    const handleSelectChange = (name, value) => {
        if (name == "hash_tags") {
            const uniqueArray = [...new Set(value)];
            const formattedValue = uniqueArray?.map(tag => {
                return tag.startsWith('#') ? tag : '#' + tag;
            });
            setAssignTask(prevState => ({ ...prevState, [name]: formattedValue }));
        }

        else if (name === "assign_type" && value == "1") {
            setAssignTask(prevState => ({
                ...prevState,
                [name]: value,
                assigned_to_users: []
            }));
        }
        else {
            setAssignTask(prevState => ({ ...prevState, [name]: value }));
        }
    }



    const handleSubmit = async (value) => {
        // add Tender todo

        if (projectId) {
            if (recordData?.task_name) {
                setLoadingTask(true)
                const formData = new URLSearchParams();
                formData.append('task_id', recordData?.id);
                formData.append('task_type', 2);
                formData.append('task_name', value?.task_name);
                formData.append('task_priority', value?.task_priority);
                formData.append('hash_tags', assignTask?.hash_tags?.join(','));
                formData.append('current_scope', value?.current_scope);
                formData.append('assign_type', value?.assign_type);
                formData.append('assigned_to_users', assignTask?.assigned_to_users?.join(','));
                formData.append('task_description', value?.task_description);
                formData.append('project_id', projectId);
                formData.append('deadline_date', assignTask?.deadline_date ? dayjs(assignTask?.deadline_date)?.format('YYYY-MM-DD HH:mm:ss') : '');
                try {
                    await form.validateFields();
                    const response = await TenderApi.updateProjectTodo(formData)

                    if (response?.data?.status === "1") {

                        setRecordData({})
                        setOpen(false)
                        setAssignTask(initialState);
                        notifySuccess("Task Update Successfully")
                        setIsUpdate(true)
                        setLoadingTask(false)
                    } else {
                        notifySuccess(response?.response?.data?.message)
                        setLoadingTask(false)
                    }
                }
                catch (error) {
                    console.log(error)
                    setLoadingTask(false)
                }
            } else {
                setLoadingTask(true)
                const formData = new URLSearchParams();
                formData.append('task_name', value?.task_name);
                formData.append('task_description', value?.task_description);
                formData.append('task_type', 2);
                formData.append('project_id', projectId);
                formData.append('assign_type', value?.assign_type);
                formData.append('assigned_to_users', assignTask?.assigned_to_users);
                formData.append('hash_tags', assignTask?.hash_tags?.join(','));
                formData.append('current_scope', value?.current_scope);
                formData.append('task_priority', value?.task_priority);
                formData.append('deadline_date', assignTask?.deadline_date ? dayjs(assignTask?.deadline_date)?.format('YYYY-MM-DD HH:mm:ss') : '');
                try {
                    await form.validateFields();
                    const response = await TenderApi.addProjectTodoTask(formData)
                    if (response?.data?.status === "1") {
                        setAssignTask(initialState);
                        notifySuccess("Task Add Successfully")
                        setOpen(false)
                        setLoadingTask(false)
                        const formData = new FormData();
                        formData.append('task_id', response?.data?.data?.id);
                        formData.append('project_id', projectId);
                        file?.forEach((file, index) => {
                            formData.append('files', file.originFileObj);
                        });
                        form.resetFields()
                        try {
                            const response = await TenderApi.AddProjectDoc(formData)
                            setFile([])
                            setIsCreatedAndUpdate(true)
                        }
                        catch (error) {
                            setIsCreatedAndUpdate(true)
                        }
                    } else {
                        notify(response?.response?.data?.message)
                        setLoadingTask(false)
                    }

                } catch (error) {
                    console.log(error, "api error")
                    setLoadingTask(false)
                }
            }


        } else {
            // todo 
            if (recordData?.task_name) {
                setLoadingTask(true)
                const formData = new URLSearchParams();
                formData.append('task_id', recordData?.id);
                formData.append('task_type', 1);
                formData.append('task_name', value?.task_name);
                formData.append('task_priority', value?.task_priority);
                formData.append('hash_tags', assignTask?.hash_tags?.join(','));
                formData.append('current_scope', assignTask?.current_scope);
                formData.append('assign_type', assignTask?.assign_type);
                formData.append('assigned_to_users', assignTask?.assigned_to_users?.join(','));
                formData.append('task_description', value?.task_description);
                formData.append('deadline_date', assignTask?.deadline_date ? dayjs(assignTask?.deadline_date)?.format('YYYY-MM-DD HH:mm:ss') : '');
                try {
                    await form.validateFields();
                    const response = await TodoServices.UpdateTaskUpd(formData)

                    if (response?.data?.status === "1") {
                        setRecordData({})
                        setOpen(false)
                        // setIsUpdate(true)
                        setLoadingTask(false)
                        if (file?.length > 0) {
                            const formData = new FormData();
                            formData.append('task_id', recordData?.id);
                            file?.forEach((file, index) => {
                                formData.append('files', file.originFileObj);
                            });
                            try {
                                const response = await TodoServices.todoDocumentUpdate(formData)
                                setFile([])
                                setIsUpdate(true)
                            }
                            catch (error) {
                                console.log(error, 'api error')
                                setIsUpdate(true)
                            }
                        } else {
                            setIsUpdate(true)
                        }
                        setAssignTask(initialState);
                        notifySuccess("Task Update Successfully")
                    } else {
                        notifySuccess(response?.response?.data?.message)
                        setLoadingTask(false)
                    }
                }
                catch (error) {
                    console.log(error)
                    setLoadingTask(false)
                }
            } else {
                setLoadingTask(true)
                const formData = new URLSearchParams();
                formData.append('task_name', value?.task_name);
                formData.append('task_description', value?.task_description);
                formData.append('task_type', 1);
                formData.append('assign_type', value?.assign_type);
                formData.append('assigned_to_users', assignTask?.assigned_to_users);
                formData.append('hash_tags', assignTask?.hash_tags?.join(','));
                formData.append('current_scope', value?.current_scope);
                formData.append('task_priority', value?.task_priority);
                assignTask?.hash_tags && formData.append('deadline_date', assignTask?.deadline_date ? dayjs(assignTask?.deadline_date)?.format('YYYY-MM-DD HH:mm:ss') : '');
                try {
                    await form.validateFields();
                    const response = await TodoServices.postTodoCreateTask(formData)
                    if (response?.data?.status === "1") {
                        setAssignTask(initialState);
                        notifySuccess("Task Add Successfully")
                        setLoadingTask(false)
                        if (file?.length > 0) {
                            const formData = new FormData();
                            formData.append('task_id', response?.data?.data?.id);
                            file?.forEach((file, index) => {
                                formData.append('files', file.originFileObj);
                            });
                            form.resetFields()
                            try {
                                const response = await TodoServices.postDocumentUpdate(formData)
                                setFile([])
                                setIsCreatedAndUpdate(true)
                            }
                            catch (error) {
                                setIsCreatedAndUpdate(true)
                            }
                        } else {
                            setIsCreatedAndUpdate(true)
                        }
                        setOpen(false)
                    } else {
                        notify(response?.response?.data?.message)
                        setLoadingTask(false)
                    }
                } catch (error) {
                    console.log(error, "api error")
                    setLoadingTask(false)
                }
            }
        }
    }

    useEffect(() => {
        if (visible) {
            inputRef.current?.focus();
            form.resetFields();
        }
    }, [form, visible]);


    const predefinedValues = () => {
        let allUserList = recordData?.assign_user_list?.filter((val => val?.assigned_to_userid !== userBidInfo?.id))?.map((taskEmp) => {
            return dropdownValState?.assigned_to_users?.find(item => item?.id === taskEmp?.assigned_to_userid)
        })

        let newObj = {
            task_name: recordData?.task_name || '',
            task_description: recordData?.task_description || '',
            task_priority: recordData?.task_priority || '',
            hash_tags: recordData?.hash_tags?.split(',') || [],
            current_scope: Number(recordData?.current_scope) || '',
            assign_type: recordData?.assign_type,
            assigned_to_users: allUserList?.filter(item => item.isactive == 1)?.map(item => item?.id) || [],
            project_id: projectId || '',
            deadline_date: recordData?.deadline_date !== null ? dayjs(recordData?.deadline_date) : null
        }
        setAssignTask((prevState) => {
            return {
                ...prevState,
                ...newObj,
            };
        });
        form.setFieldsValue(newObj);

    }


    useEffect(() => {
        if (recordData?.task_name) {
            predefinedValues()
        }
    }, [recordData])



    const handleReset = () => {
        if (recordData?.task_name) {
            setRecordData({})
            setAssignTask(initialState);
            setFile([]);
            form.resetFields();
        }
        else {
            setAssignTask(initialState);
            setFile([]);

        }
        form.resetFields()
    };

    const handleRemove = (item) => {
        const newFileList = file.filter((f) => f.uid !== item.uid);
        setFile(newFileList);
    };

    // Function to disable previous hours and minutes
    const disabledTime = (selected, meetingDate) => {
        if (!meetingDate || !dayjs(meetingDate).isSame(dayjs(), 'day')) {
            // No restrictions if the date is not the current date
            return {};
        }

        const currentHour = dayjs().hour();
        const currentMinute = dayjs().minute();
        const currentSecond = dayjs().second();

        if (selected && selected.hour() === currentHour && selected.minute() === currentMinute) {
            // Disable hours and minutes before the current time
            return {
                disabledHours: () => Array.from({ length: currentHour }).map((_, i) => i),
                disabledMinutes: () => Array.from({ length: currentMinute }).map((_, i) => i),
                disabledSeconds: () => Array.from({ length: currentSecond }).map((_, i) => i),
            };
        }
        // No restrictions for other cases
        return {};
    };


    const handleSpace = (name, e) => {
        const trimmedValue = e.target.value.trimStart(); // Trim leading spaces
        form.setFieldsValue({ [name]: trimmedValue }); //
    }

    const tagRender = (props) => {
        const { label, value, closable, onClose } = props;
        return (
            <div style={{ display: 'inline-flex', alignItems: 'center' }}>
                <span>{value?.startsWith('#') ? value : '#' + value}</span>
                {closable && <CloseOutlined onClick={(e) => onClose(e)} />}
            </div>
        );
    };


    return (
        <Modal
            className='model_tagss'
            title={recordData?.task_name ? 'Edit Task Assignment' : 'New Task Assignment'}
            visible={visible}
            destroyOnClose
            onCancel={() => { handleReset(); setOpen(false) }}
            // onCancel={onCancel}
            forceRender
            footer={false}
        >
            <Form
                autoComplete="off"
                form={form}
                layout="vertical"
                onFinish={handleSubmit}
            >
                <Form.Item label="Task Name" name='task_name' rules={[{ required: true, message: 'Task name is required' }]}  >
                    <Input ref={inputRef} placeholder="Enter here" onChange={(e) => handleSpace('task_name', e)}
                    />
                </Form.Item>

                <Form.Item label="Description" name='task_description' rules={[{ required: true, message: 'Description is required' }]}>
                    <Input.TextArea rows={3} placeholder="Enter here" onChange={(e) => handleSpace('task_description', e)}
                    />
                </Form.Item>


                <Form.Item label="Assignment Recipient" name='assign_type' rules={[{ required: true, message: 'Assignment recipient is required' }]}>
                    <Select
                        allowClear
                        showSearch
                        placeholder="Select Assignment Recipient  "
                        value={assignTask?.assign_type}
                        onChange={(value) => handleSelectChange('assign_type', value)}
                        filterOption={(input, option) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }
                    >
                        {
                            dropdownValState?.assign_type?.map((item, index) => {

                                return (
                                    <>

                                        <Option key={index} value={item?.value}>{item?.label}</Option>
                                    </>
                                )

                            })
                        }
                    </Select>
                </Form.Item>

                {assignTask?.assign_type === 2 ? (<Form.Item
                    noStyle
                    label="Team Members"

                    shouldUpdate={(prevValues, currentValues) => prevValues.assign_type !== currentValues.assign_type}
                >

                    <Form.Item label="Team Members" name='assigned_to_users' rules={[{ required: true, message: 'Select team members' }]} >
                        <Select
                            showSearch={true}
                            mode="multiple"
                            placeholder="Select Members"
                            name="assigned_to_users"
                            onChange={(value) => handleSelectChange('assigned_to_users', value)}
                            value={assignTask?.assigned_to_users}
                            suffixIcon={<Down theme="outline" size="20" fill="#636363" />}
                            optionFilterProp="children"
                            filterOption={(input, option) =>
                                option?.children?.props?.children[1]?.props?.children?.toLowerCase()?.indexOf(input.toLowerCase()) >= 0
                            }
                        >
                            {
                                dropdownValState?.assigned_to_users?.filter(item => item?.id !== userBidInfo?.id && item.isactive == 1)?.map((item, index) => {

                                    return (
                                        <Option value={item?.id} key={index}>
                                            <div className='avatar_box'>
                                                <div className='user_avatar'>
                                                    <Avatar
                                                        src={docurlchat + item?.profileimg_path + "/" + item?.profileimg}
                                                        // style={{ backgroundColor: '#f56a00' }}
                                                        size="large"
                                                    >
                                                        {item?.userfullname?.charAt(0)}
                                                    </Avatar>
                                                </div>
                                                <div className='user_name'>{item?.userfullname}</div>
                                            </div>
                                        </Option>
                                    )
                                })
                            }
                        </Select>
                    </Form.Item>

                </Form.Item>
                ) : null
                }
                <Form.Item
                    label="Task Scope" name="current_scope" rules={[{ required: true, message: 'Task scope is required' }]}
                >
                    <Select
                        allowClear
                        placeholder="Select Task Scope"
                        // name="current_scope"
                        onChange={(value) => handleSelectChange('current_scope', value)}
                        value={assignTask?.current_scope}
                        showSearch={true}
                        optionFilterProp="children"
                    >
                        {dropdownValState?.current_scope?.map((item, index) => {

                            return (
                                <Option
                                    key={index}
                                    value={item?.value}
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                >
                                    {item?.label}
                                </Option>
                            );
                        })}

                    </Select>
                </Form.Item>

                <Form.Item
                    label="Tags"
                    name="hash_tags" rules={[{ required: true, message: 'Hashtag is required' }]}
                >
                    <Select
                        mode="tags"
                        placeholder="Select Hash Tags"
                        onChange={(value) => handleSelectChange('hash_tags', value)}
                        value={assignTask?.hash_tags}
                        suffixIcon={<Down theme="outline" />}
                        filterOption={(input, option) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }
                        showSearch={true}
                        optionFilterProp="children"
                        tokenSeparators={[' ']}
                        tagRender={tagRender}
                    >
                        {dropdownValState?.hash_tags?.filter(val => val.hashtag_name.trim() !== '#' && val.hashtag_name.trim() !== '')
                            ?.map((item, index) => {

                                const value = item?.hashtag_name?.startsWith('#') ? item.hashtag_name : '#' + item.hashtag_name
                                return (
                                    <Option key={index} value={value}>
                                        {value}
                                    </Option>
                                )
                            })}

                    </Select>

                </Form.Item>


                <Row gutter={30}>

                    <Col sm={12}>
                        <Form.Item label="Priority" name="task_priority" rules={[{ required: true, message: 'Priority is required' }]}>
                            <Select placeholder="Select Priority"
                                value={assignTask?.task_priority}
                                allowClear
                                onChange={(value) => handleSelectChange('task_priority', value)}
                                showSearch={true}
                                optionFilterProp="children"
                            >
                                {
                                    dropdownValState?.task_priority?.map((item, index) => {
                                        return (
                                            <>
                                                <Option key={index} value={item?.id}
                                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}>{item?.task_priority_name}</Option>
                                            </>
                                        )

                                    })
                                }
                            </Select>
                        </Form.Item>
                    </Col>

                    <Col sm={12}>
                        <Form.Item label="Deadline"

                        >
                            <DatePicker
                                showTime={{
                                    defaultValue: dayjs('00:00:00', 'HH:mm:ss'),
                                }}
                                placeholder='Select Date'
                                // value={assignTask?.deadline_date}
                                value={assignTask?.deadline_date ? dayjs(assignTask.deadline_date) : null}
                                onChange={(value) => handleSelectChange('deadline_date', value)}
                                format="YYYY-MM-DD HH:mm:ss"
                                disabledDate={(current) => current && current < dayjs().startOf('day')}
                                disabledTime={(current) =>
                                    current && current < dayjs()
                                        ? {
                                            disabledHours: () =>
                                                Array.from({ length: dayjs().hour() }).map((_, i) => i),
                                            disabledMinutes: () =>
                                                Array.from({ length: dayjs().minute() }).map((_, i) => i),
                                            disabledSeconds: () =>
                                                Array.from({ length: dayjs().second() }).map((_, i) => i),
                                        }
                                        : {}
                                }
                            />
                        </ Form.Item>
                    </Col>
                </Row>

                <Form.Item label="Attach file  (Max 20 MB)"
                    name="attachment"

                >

                    <Upload
                        listType="picture"
                        name='files'
                        fileList={file}
                        multiple={true}
                        onChange={handleDoc}
                        beforeUpload={beforeUpload}
                        onRemove={handleRemove}
                    >
                        <Button className='todo_choosen_btn'>Choose file </Button>
                    </Upload>
                </ Form.Item>

                <Row>
                    <Col sm={24}>
                        {documentData?.filter(item => item?.id === recordData?.id)?.map(task => task?.todo_comment_documents)?.map((innerArray, outerIndex) => (
                            <div key={outerIndex}>
                                {innerArray?.map((doc, innerIndex) => (
                                    <Card
                                        style={{
                                            margin: 20,
                                            paddingBlock: 0,
                                        }}

                                    >
                                        <span style={{ display: 'flex', justifyContent: 'space-between' }} key={innerIndex}> {doc?.doc_name}</span>
                                    </Card>
                                ))}
                            </div>
                        ))}
                    </Col>
                </Row>

                <Flex justify='flex-end' align='center'>
                    <Button key="cancel" onClick={handleReset} className="BG_ghostButton">
                        Reset
                    </Button>
                    <Button key="ok" type="primary" className="BG_mainButton" style={{ marginLeft: '20px' }}
                        htmlType="submit" loading={loadingTask} disabled={loadingTask}
                    >
                        {recordData?.task_name ? 'Update' : 'Submit'}
                    </Button>
                </Flex>
            </Form>
        </Modal>
    );
}

export default TodoItemFormModel;