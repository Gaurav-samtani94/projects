// @ts-nocheck
import { Droppable, Draggable } from 'react-beautiful-dnd';
import styled from 'styled-components';
import { Card } from 'antd';
import { TodoTypes } from './TodoTypes';
import TodoItemCard from './TodoItemCard';
import { colors } from '../SharedHooks/SharedUtils';
import { useRef, useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { navigationData } from 'Redux/actions/bidgrid/navigationData';
const TaskboardColRoot = styled(Card)`
  user-select: none;
  flex: 1;
  margin: 0.5rem;
  display: flex;
  flex-direction: column;
  min-width: 0;
  > .ant-card-body {
    overflow: hidden;
    height: 100%;
    padding: 0;
  }
`;

const DroppableRoot = styled.div`
  height: 100%;
  overflow-y: auto;
  background-color: ${colors?.primary[1]};
`;


export const TaskboardColProps = {
    onDelete: null,
    items: [],
    status: TodoTypes?.TO_DO,
    onClickAdd: null,
};

function TodoCol(props) {
    const { items, status, onDelete, dropdownValState, open, setOpen, todoBoardProp, selectedFilterData, documentData, isUpdate, setRecordData, recordData, skeletonVisible, setSkeletonVisible, assigntype, setAssignTask, searchData, projectId, setFetchCurrentId, setIsCreatedAndUpdate } = props;
    const highlightedRef = useRef(null);
    const location = useLocation();
    const [isActive, setIsActive] = useState(true)
    const { navigateData } = useSelector((state) => state.navigationData)
    const dispatch = useDispatch()
    const filteredItems = items
        ?.filter(item => item?.task_name.includes(searchData))
        ?.filter(item => {
            const isPriorityMatch = selectedFilterData?.priority ? item?.task_priority === selectedFilterData?.priority : true;
            const isAssignTypeMatch = selectedFilterData?.assigntype ? item?.assign_type === selectedFilterData?.assigntype : true;

            return isPriorityMatch && isAssignTypeMatch;
        });

    const sendPropData = (item) => {
        todoBoardProp(item);
    };

    useEffect(() => {
        if (items?.length > 0) {

            setIsActive(true)
            const tmScroll = setTimeout(() => {
                if (highlightedRef.current) {
                    highlightedRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    window.history.replaceState({}, '')
                } else {
                    window.history.replaceState({}, '')
                }
            }, 700);
            const activeTm = setTimeout(() => {
                setIsActive(false)
                dispatch(navigationData.setNavigationDataAction({}))
            }, 3000);

            return () => {
                clearTimeout(activeTm);
                clearTimeout(tmScroll)
            }
        }

    }, [items, navigateData?.key]);


    return (
        <TaskboardColRoot
            className='bd_title_name_assign todo-card-container'
            title={
                <>
                    {status} <span className="todo_number_assign">{filteredItems?.length || 0}</span>
                </>
            }
        >
            <Droppable droppableId={status}>
                {(provided, snapshot) => (
                    <DroppableRoot ref={provided?.innerRef} {...provided?.droppableProps}>
                        {/* {items
                            ?.filter(item => item?.task_name.includes(searchData))
                            ?.filter(item => {
                                const isPriorityMatch = selectedFilterData?.priority
                                    ? item?.task_priority === selectedFilterData?.priority
                                    : true;

                                const isAssignTypeMatch = selectedFilterData?.assigntype
                                    ? item?.task_type !== selectedFilterData?.assigntype
                                    : true;

                                return isPriorityMatch && isAssignTypeMatch;
                            }) */}
                        {filteredItems?.map((item, index) => (
                            <Draggable key={item?.id} draggableId={item?.id.toString()} index={index}>
                                {(provided, snapshot) => (
                                    <div
                                        key={item.id}
                                        ref={provided?.innerRef}
                                        {...provided?.draggableProps}
                                        {...provided?.dragHandleProps}
                                    >
                                        <div key={item.id} className={(isActive && navigateData?.key == item?.id) ? 'isActive cardUpper' : 'cardUpper'} ref={navigateData?.key == item.id ? highlightedRef : null}>
                                            <TodoItemCard
                                                item={item}
                                                location={location}
                                                status={status}
                                                onDelete={onDelete}
                                                dropdownValState={dropdownValState}
                                                open={open}
                                                setOpen={setOpen}
                                                sendPropData={sendPropData}
                                                documentData={documentData}
                                                isUpdate={isUpdate}
                                                recordData={recordData}
                                                setRecordData={setRecordData}
                                                skeletonVisible={skeletonVisible}
                                                setSkeletonVisible={setSkeletonVisible}
                                                setAssignTask={setAssignTask}
                                                assigntype={assigntype}
                                                projectId={projectId}
                                                setFetchCurrentId={setFetchCurrentId}
                                                setIsCreatedAndUpdate={setIsCreatedAndUpdate}

                                            />
                                        </div>
                                    </div>
                                )}
                            </Draggable>
                        ))}
                        {provided?.placeholder}
                    </DroppableRoot>
                )}
            </Droppable>
        </TaskboardColRoot>
    );
}

export default TodoCol;
