// @ts-nocheck
import React from 'react'
import { ClockCircleOutlined, ConsoleSqlOutlined, DownloadOutlined, DeleteOutlined } from '@ant-design/icons';
import { Drawer, Card, Avatar } from 'antd';
import skipBack from "../../assets/images/skip-back.png";
import dayjs from 'dayjs';
import { TodoServices } from 'Services/bidgrid/todo/TodoServices';
import { docurlchat } from 'utils/configurable';
import { toast } from 'react-toastify';
import byUserImg from "../../assets/images/profile2.jpg"
import { TimeConverter } from '../TimeConverter/TimeConverter';

function TodoDetail(props) {
    const { setTaskId, detail, setTodoDetail, recordData, setRecordData, dropdownValState, documentData, setHashTagSearch, setGetsinglehashtag, setHashtag, setAssignTask, setIsCreatedAndUpdate } = props
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const assignName = recordData?.assigned_users?.map((item) => item?.assigned_to_userid) || [];

    const AssignBy = dropdownValState?.assigned_to_users?.filter((item) => assignName.includes(item.id))
    // const documents = documentData?.filter((doc) => recordData?.task_name?.includes(doc?.task_name))

    // filter assigned user 
    const assignedUserIds = recordData?.assign_user_list?.map(val => val?.assigned_to_userid);
    const filteredUserObjects = dropdownValState?.assigned_to_users?.filter(user => assignedUserIds?.includes(user?.id));
    const handleHashTag = async (item) => {
        setTodoDetail(false)
        setGetsinglehashtag(item)
        const formData = new URLSearchParams();
        formData.append('hashtag', item);

        try {
            const response = await TodoServices.HastagSearch(formData)

            if (response?.data?.status === '1') {
                setHashTagSearch(response?.data?.data)
                setHashtag(true)

            } else {
                console.log('api error')
            }

        } catch (error) {
            console.log(error, "api error")
        }

    }

    // const TodoEdit = async () => {
    //     const formData = new URLSearchParams();
    //     formData.append('task_id', taskId)
    //     try {
    //         const response = await TodoServices?.todoEdit(formData)
    //         if (response?.data?.status == 1) {
    //             setDetailData(response?.data?.data)
    //             // getbidRoleTender()
    //             // handleReset()
    //             // notifySuccess(response?.data?.message)

    //         }
    //         else {
    //             // handleReset()
    //             // notify(response?.response?.data?.message)
    //         }
    //     } catch (error) {
    //         console.log(error, 'Api Error')
    //     }
    // }

    // useEffect(() => {
    //     TodoEdit()
    // }, [taskId])

    const handleClose = () => {
        setRecordData({})
        setTodoDetail(false)
        setTaskId('')
        setAssignTask('')
    }

    const documentBlobReq = async (doc_name, apiUrl) => {
        const fullUrl = window.location.href;
        const urlObject = new URL(fullUrl);
        const protocol = urlObject.protocol;
        const hostname = urlObject.host;
        const domain = `${protocol}//${hostname}`;
        const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
        const response = await fetch(proxyUrl)
        const blobData = await response?.blob()
        const fileURL = window.URL.createObjectURL(blobData);
        let alink = document.createElement("a");
        alink.href = fileURL;
        alink.download = doc_name;
        alink.click();
    }

    // Document Download

    const documentDownload = (item) => {
        const apiUrl = `${docurlchat}${item?.doc_path}/${item?.doc_name}`;
        documentBlobReq(item?.doc_name, apiUrl)
    };

    // Document delete

    const documentDelete = async (item) => {
        try {
            const formData = new URLSearchParams()
            formData.append('document_id', item?.id)
            const response = await TodoServices.TodoDocDelete(formData)
            if (response?.data?.status == 1) {
                notifySuccess('Document Deleted Successfully')
                setTodoDetail(false)
                setIsCreatedAndUpdate(true)
            } else {
                notify(response?.response?.data?.message)
                setTodoDetail(false)
            }
        } catch {
        }
    }
    const actionColor = dropdownValState?.task_priority?.find(val => val?.id === recordData?.task_priority)?.task_priority_name === "High"
        ? "#E64649"
        : dropdownValState?.task_priority?.find(val => val?.id === recordData?.task_priority)?.task_priority_name === "Low"
            ? "#329B57"
            : dropdownValState?.task_priority?.find(val => val?.id === recordData?.task_priority)?.task_priority_name === "Medium"
                ? "#CD7014"
                : ""

    return (
        <>
            <Drawer className='todo_Detail' closeIcon={<img src={skipBack} alt='' />}
                title={recordData?.task_name} placement="right" onClose={handleClose}
                extra={
                    <div className={`prioity_todo_list ${dropdownValState?.task_priority?.find(val => val?.id === recordData?.task_priority)?.task_priority_name === "High"
                        ? "highPriority"
                        : dropdownValState?.task_priority?.find(val => val?.id === recordData?.task_priority)?.task_priority_name === "Low"
                            ? "lowPriority"
                            : dropdownValState?.task_priority?.find(val => val?.id === recordData?.task_priority)?.task_priority_name === "Medium"
                                ? "mediumPriority"
                                : ""
                        }`}>
                        <div className='priority-col'>
                            Priority: {dropdownValState?.task_priority?.find(val => val?.id === recordData?.task_priority)?.task_priority_name}
                        </div>
                        <div className='box-content'>
                            {
                                recordData?.deadline_date !== null ?
                                    <div className='date-box'>
                                        <div className='icon-title'>
                                            <ClockCircleOutlined className='date-box-icon' /> Deadline:
                                        </div>
                                        <div>
                                            <span> {recordData?.deadline_date !== null ? `${dayjs(recordData?.deadline_date)?.format('YYYY-MM-DD')} ${TimeConverter(recordData?.deadline_date)}` : ' - '}
                                            </span>
                                        </div>
                                    </div>
                                    :
                                    <></>
                            }
                        </div>
                    </div>

                }
                open={detail} width={700}
            >
                <div className=''>
                    <div className="todo_det">
                        <span className='detail_heading'>Task Description</span>
                        {recordData?.task_description}
                    </div>

                    <div className="assign_by">
                        <span className='detail_heading'>Assigned by</span>
                        <div className="byText">
                            <Avatar size={22} src={docurlchat + dropdownValState?.assigned_to_users?.find(item => item?.id === recordData?.created_by)?.profileimg_path + "/" + dropdownValState?.assigned_to_users?.find(item => item?.id === recordData?.created_by)?.profileimg}>
                                {dropdownValState?.assigned_to_users?.find(item => item?.id === recordData?.created_by)?.userfullname?.charAt(0)}
                            </Avatar>
                            {dropdownValState?.assigned_to_users?.find(item => item?.id === recordData?.created_by)?.userfullname}
                        </div>
                    </div>

                    <div className="assign_user">
                        <span className='detail_heading'>Assign to user:</span>
                        <div className="userAssigned">
                            {
                                filteredUserObjects?.filter(val => val?.id !== recordData?.user_creater_id)?.map((item) => {
                                    return (
                                        <div className="d-flex">
                                            <Avatar size={22} src={docurlchat + item?.profileimg_path + "/" + item?.profileimg}>
                                                {item?.userfullname?.charAt(0)}
                                            </Avatar>
                                            <p className='assign_user_pera'>{item.userfullname}</p>
                                        </div>
                                    )
                                })
                            }
                        </div>
                    </div>




                    <div className='todo_hashtag_container'>
                        {/* <p className='detail_heading'>Hashtags -</p> */}
                        {
                            recordData?.hash_tags?.split(',')?.map((item, index) => {
                                return (
                                    <>
                                        <div className='todo_hashtag' onClick={() => handleHashTag(item)} key={index} >
                                            <span >{item}</span>
                                        </div>
                                    </>
                                )
                            })
                        }

                    </div>

                    <div className="todo_doc_wrap">
                        <p className='detail_heading'>Documents</p>
                        <div>
                            {
                                documentData.filter(val => val?.task_name === recordData?.task_name)?.map(item => item?.todo_comment_documents)?.map((innerArray, outerIndex) => (
                                    <div key={outerIndex}>
                                        {innerArray?.map((doc, innerIndex) => (
                                            <div className="download_doc">
                                                <span style={{ display: 'flex', justifyContent: 'space-between' }} key={innerIndex}> {doc?.doc_name}
                                                    <div style={{ cursor: 'pointer' }} onClick={() => documentDownload(doc)}><DownloadOutlined /></div>
                                                    <div style={{ cursor: 'pointer' }} onClick={() => documentDelete(doc)}><DeleteOutlined /></div>
                                                </span>

                                            </div>
                                        ))}
                                    </div>
                                ))
                            }
                        </div>
                    </div>

                </div>
            </Drawer >
        </>
    )
}

export default TodoDetail