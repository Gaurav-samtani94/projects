// @ts-nocheck
import React, { useCallback, useEffect, useState } from 'react';
import { Card, Typography, } from 'antd';
import styled from 'styled-components';
import { Avatar, Tooltip } from 'antd';
import { ClockCircleOutlined } from '@ant-design/icons';
import attachment from '../../assets/images/icons/file_present.png';
import Comments from '../../assets/images/icons/fluent_chat-24-filled.png';
import TodoHashtag from '../Drawer/TodoHashtag';
import TodoComments from '../Drawer/TodoComment';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import dayjs from 'dayjs';
import { TodoServices } from 'Services/bidgrid/todo/TodoServices';
import TodoDocumentViewModal from '../TodoModal/TodoDocumentViewModal';
import { useSelector } from 'react-redux';
import TodoDetail from './TodoDetail';
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { TodoTypes } from './TodoTypes';
import produce from 'immer';
import { useSyncedState } from '../SharedHooks/SharedHooks';
import { docurlchat } from 'utils/configurable';
import { Write, PreviewOpen, UpdateRotation } from '@icon-park/react';
import { TimeConverter } from '../TimeConverter/TimeConverter';

const StyledCard = styled(Card)`
margin: 0.5rem;
padding: 0.5rem;
background-color: ${({ isDragging }) => (isDragging ? '#fafafa' : '#fff')};
`;

const TaskboardItemCardTitle = styled(Typography.Title)`
white-space: pre-wrap;
margin-right: 0.25rem;
`;

function TodoItemCard(props) {
    const [hashtag, setHashtag] = useState(false)
    const [hashTagSearch, setHashTagSearch] = useState([])
    const [comment, setComment] = useState(false)
    const [viewStatus, setViewStatus] = useState(false)
    const [detail, setTodoDetail] = useState(false)
    const [viewModelStatus, setViewModelStatus] = useState(0)
    const [getDocumentData, setGetDocumentData] = useState([])
    const [taskId, setTaskId] = useState('')
    const [getsinglehashtag, setGetsinglehashtag] = useState('')
    const { socket, isConnected } = useSelector((state) => state.socket);

    const { item, isDragging, dropdownValState, setOpen, sendPropData, documentData, isUpdate, skeletonVisible, setSkeletonVisible, recordData, setRecordData, assigntype, setAssignTask, projectId, setFetchCurrentId, setIsCreatedAndUpdate } = props;
    const [cardData, setTodoCard] = useState(item)
    const [assignedModelData, setAssignedModelData] = useState([])
    const { userBidInfo } = useSelector((state) => state?.userDetails)
    useEffect(() => {
        if (isUpdate === false) {
            setTodoCard(item)
        }
    }, [isUpdate])

    const handleDetail = (id) => {
        setTaskId(id)
        sendPropData(item)
        setTodoDetail(true)
    }
    const handleHashtag = async (item) => {
        setTodoDetail(false)
        setGetsinglehashtag(item)
        const formData = new URLSearchParams();
        formData.append('hashtag', item);
        if (projectId) {
            try {
                const response = await TenderApi.projectHashSearch(formData)
                if (response?.data?.status === '1') {
                    setHashTagSearch(response?.data?.data)
                    setHashtag(true)
                } else {
                    console.log('api error')
                }

            } catch (error) {
                console.log(error, "api error")
            }
        } else {
            try {
                const response = await TodoServices.HastagSearch(formData)
                if (response?.data?.status === '1') {
                    setHashTagSearch(response?.data?.data)
                    setHashtag(true)

                } else {
                    console.log('api error')
                }

            } catch (error) {
                console.log(error, "api error")
            }
        }
    }

    const handleComment = () => {
        setTodoDetail(false)
        setComment(true)
        setFetchCurrentId(cardData?.id)
    }


    const getDocData = (data) => {
        setViewModelStatus(1)
        setGetDocumentData(data)
        setViewStatus(true)
        setHashtag(false)
    }

    const handleEditTask = (item) => {
        setTodoDetail(false)
        sendPropData(item)
        setOpen(true)
    }

    const fetchAssignedUserList = async (id) => {
        setViewModelStatus(2)

        if (filteredUserObjects?.length > 1) {
            setViewStatus(true)

        }
        setHashtag(false)
        if (projectId) {
            const formData = new URLSearchParams();
            formData.append('task_id', id)
            formData.append('project_id', projectId)
            try {
                const response = await TenderApi.projectUserList(formData)
                if (response?.data?.status === '1') {
                    setAssignedModelData(response?.data?.data)

                } else {
                    setAssignedModelData([])
                }
            } catch (error) {
                return []
            }
        } else {
            const formData = new URLSearchParams();
            formData.append('task_id', id)
            try {
                const response = await TodoServices.showAssignedUserList(formData)
                if (response?.data?.status === '1') {
                    setAssignedModelData(response?.data?.data)

                } else {
                    setAssignedModelData([])
                }
            } catch (error) {
                return []
            }
        }

    }
    const assignedUserIds = cardData?.assign_user_list?.map(val => val?.assigned_to_userid);
    const filteredUserObjects = dropdownValState?.assigned_to_users?.filter(user => assignedUserIds?.includes(user?.id));
    const fetchUser = useCallback(() => {
        if (dropdownValState?.assigned_to_users?.length > 0) {
            const fetchAvatar = dropdownValState?.assigned_to_users?.find((val) => val.id === cardData?.assign_user_list?.[0]?.assigned_to_userid)
            return fetchAvatar?.userfullname
        }

    }, [dropdownValState]);

    useEffect(() => {
        if (isConnected) {
            socket.on(cardData?.id, async (data) => {
                setTodoCard((prevState) => ({
                    ...prevState,
                    ['taskcommentCount']: data?.total_comment,
                }));
            });
        }
    }, [isConnected])


    const avatarColor = "#8d8d8d"

    const actionColor = dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name === "High"
        ? "#E64649"
        : dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name === "Low"
            ? "#329B57"
            : dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name === "Medium"
                ? "#CD7014"
                : ""

    return (
        <>
            {
                skeletonVisible ?
                    <StyledCard

                        className={`todo_card-box-bd ${dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name === "High"
                            ? "highPriority"
                            : dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name === "Low"
                                ? "lowPriority"
                                : dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name === "Medium"
                                    ? "mediumPriority"
                                    : ""
                            }`}
                        isDragging={isDragging}
                        size="small"
                        title={
                            <span>
                                <TaskboardItemCardTitle level={5} ellipsis={{ rows: 2 }}>
                                    <div className='prioity_todo_list'>
                                        <div className='todo_prioity_level'>
                                            <span>Priority</span>
                                            <div className='todo_level_token todo_low_token'>
                                                <Skeleton width={100} height={20} />
                                            </div>
                                        </div>
                                        {
                                            userBidInfo?.id === cardData?.user_creater_id ?
                                                <div>
                                                    <div className='todo_edit_span'>
                                                        <button className='BG_todo_edit' onClick={() => handleEditTask(cardData)}><Write theme="outline" size="24" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" /></button>

                                                    </div>

                                                </div>

                                                :
                                                <></>
                                        }
                                    </div>
                                </TaskboardItemCardTitle>
                            </span>
                        }
                    >
                        <div className='todo_heading_coont'>
                            <Skeleton width={100} height={20} />
                        </div>
                        <div className='pra-box'>

                            <Skeleton width={200} height={20} />

                        </div>

                        <div className='todo_hashtag_container'>
                            {
                                cardData?.hash_tags?.split(',')?.map((item, index) => {
                                    return (
                                        <>
                                            <Skeleton width={100} height={20} />
                                        </>
                                    )
                                })
                            }

                        </div>
                        <div className='card-box'>
                            <div className='box-content'>
                                <div className='date-box'>
                                    <div className='icon-title'>
                                        <ClockCircleOutlined className='date-box-icon' /> Deadline:
                                    </div>
                                    <div>
                                        <Skeleton width={80} height={20} />
                                    </div>
                                </div>

                                <div className='date-box'>
                                    <div className='time-title'>
                                        <UpdateRotation theme="outline" size="18" fill="#038e03" strokeWidth={3} strokeLinecap="butt" />  Updated At:
                                    </div>
                                    <div>
                                        <Skeleton width={80} height={20} />
                                    </div>
                                </div>
                                <div className='bd_avatar_grp'>
                                    <div>
                                        <Avatar.Group
                                            // maxCount={1}
                                            maxPopoverTrigger="click"
                                            size="large"
                                            maxStyle={{ color: '#f56a00', backgroundColor: '#fde3cf', cursor: 'pointer' }}
                                        >
                                            {
                                                filteredUserObjects?.filter(val => val?.id !== cardData?.user_creater_id)?.map((item, index) => {
                                                    return (
                                                        <>
                                                            <Skeleton width={50} height={20} />
                                                        </>
                                                    )
                                                })
                                            }
                                        </Avatar.Group>
                                    </div>
                                    <div className='todo_attachment_cont'>
                                        {
                                            documentData?.filter(val => val?.task_name === cardData?.task_name)?.map(item => item?.todo_comment_documents?.length) > 0 ?
                                                <div className='todo_attachment_span' onClick={() => getDocData(documentData?.filter(val => val?.task_name === cardData?.task_name))} >
                                                    <img src={attachment} width={25} alt='attach file' />
                                                    <span>{documentData?.filter(val => val?.task_name === cardData?.task_name)?.map(item => item?.todo_comment_documents?.length)}</span>
                                                </div>
                                                :
                                                <></>
                                        }
                                        {
                                            cardData?.taskcommentCount !== 0 ?
                                                <div className='todo_comment_span'>
                                                    <img src={Comments} alt='comment' width={25} onClick={handleComment} />
                                                    <span>{cardData?.taskcommentCount}</span>
                                                </div>
                                                :
                                                <div className='todo_comment_span'>
                                                    <img src={Comments} alt='comment' width={25} onClick={handleComment} />
                                                </div>
                                        }
                                    </div>
                                </div>
                            </div>
                        </div >
                    </StyledCard >
                    :
                    <div isDragging={isDragging} className={`todo_card_container ${dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name === "High"
                        ? "highPriority"
                        : dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name === "Low"
                            ? "lowPriority"
                            : dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name === "Medium"
                                ? "mediumPriority"
                                : ""
                        }`}
                    >
                        <StyledCard
                            className={`todo_card-box-bd position-relative`}
                            isDragging={isDragging}
                            size="small"
                            title={
                                <>
                                    <div className='priority-col'>
                                        Priority: {dropdownValState?.task_priority?.find(val => val?.id === cardData?.task_priority)?.task_priority_name}
                                    </div>

                                    <div className='todo_edit_span'>
                                        {
                                            userBidInfo?.id === cardData?.user_creater_id ?
                                                <button className='BG_todo_edit' onClick={() => handleEditTask(cardData)}>
                                                    <Write theme="outline" size="20" fill="#000" strokeWidth={3} strokeLinecap="butt" />
                                                </button>
                                                :
                                                <></>
                                        }
                                        <button className='BG_todo_edit' onClick={() => handleDetail(cardData?.id)}>
                                            <PreviewOpen theme="outline" size="24" fill="#000" strokeWidth={3} strokeLinecap="butt" />
                                        </button>
                                    </div>

                                </>
                            }
                        >
                            <div className='todo_heading_coont'>
                                <span>{cardData?.task_name}</span>
                            </div>
                            <div className='pra-box'>
                                <p> {capitalizeExceptPrepositionsAndLowerCase(cardData?.task_description)}</p>
                            </div>
                            <div className='todo_hashtag_container'>
                                {cardData?.hash_tags?.split(',')?.slice(0, 4).map((item, index) => (
                                    <div className='todo_hashtag' onClick={() => handleHashtag(item)} key={index} >
                                        <span>{item}</span>
                                    </div>
                                ))}
                                {cardData?.hash_tags?.split(',')?.length > 4 && (
                                    <div className='todo_hashtag' onClick={() => handleHashtag(cardData?.hash_tags?.split(',').slice(4).join(','))}>
                                        <span>...+{cardData?.hash_tags?.split(',').length - 4}</span>
                                    </div>
                                )}
                            </div>
                            <div className='card-box'>
                                <div className='box-content'>
                                    {
                                        cardData?.updated_at !== null ?
                                            <div className='date-box'>
                                                <div className='time-title'>
                                                    <UpdateRotation theme="outline" size="18" fill="#038e03" strokeWidth={3} strokeLinecap="butt" />  Updated At:
                                                </div>
                                                <div className="d-flex" style={{ flex: 1 }}>
                                                    <span> {cardData?.updated_at !== null ? `${dayjs(cardData?.updated_at)?.format('YYYY-MM-DD')} ${TimeConverter(cardData?.updated_at)}` : ' - '}
                                                    </span>
                                                    <span style={{ marginLeft: "auto" }}>
                                                        {cardData?.modified_by !== null && 'By'}   {dropdownValState?.assigned_to_users?.find(item => item?.id === cardData?.modified_by)?.userfullname}
                                                    </span>
                                                </div>
                                            </div>

                                            :
                                            <></>
                                    }

                                    {
                                        cardData?.deadline_date !== null ?
                                            <div className='date-box'>
                                                <div className='icon-title'>
                                                    <ClockCircleOutlined className='date-box-icon' /> Deadline:
                                                </div>
                                                <div>
                                                    <span> {cardData?.deadline_date !== null ? `${dayjs(cardData?.deadline_date)?.format('YYYY-MM-DD')} ${TimeConverter(cardData?.deadline_date)}` : ' - '}
                                                    </span>
                                                </div>
                                            </div>

                                            :
                                            <></>
                                    }
                                    <div className='bd_avatar_grp'>
                                        <div onClick={() => handleDetail(cardData?.id)}>
                                            <Avatar.Group
                                                // maxCount={1}
                                                maxPopoverTrigger="click"
                                                size="large"
                                                maxStyle={{ color: avatarColor, backgroundColor: avatarColor, cursor: 'pointer' }}
                                            >
                                                {
                                                    filteredUserObjects?.slice(0, 2).map((item, index) => (
                                                        <Tooltip key={index} title={item?.userfullname} placement="top">
                                                            <Avatar src={docurlchat + item?.profileimg_path + "/" + item?.profileimg}
                                                                style={{ backgroundColor: !item?.profileimg && avatarColor }}>
                                                                {item?.userfullname.charAt(0)}
                                                            </Avatar>
                                                        </Tooltip>
                                                    ))
                                                }
                                                {filteredUserObjects && filteredUserObjects.length > 2 && (
                                                    <Tooltip title={filteredUserObjects?.slice(2)?.map(item => item?.userfullname).join(', ')} placement="right">

                                                        <Avatar style={{ backgroundColor: avatarColor }}>
                                                            +{filteredUserObjects?.length - 2}
                                                        </Avatar>
                                                    </Tooltip>
                                                )}
                                            </Avatar.Group>
                                        </div>


                                        <div className='todo_attachment_cont'>
                                            {
                                                documentData?.filter(val => val?.task_name === cardData?.task_name)?.map(item => item?.todo_comment_documents?.length) > 0 ?
                                                    <div className='todo_attachment_span' style={{ border: `1px solid ${actionColor}`, borderRadius: 6, padding: 6 }} onClick={() => handleDetail(cardData?.id)} >
                                                        {/* <img src={attachment} alt='attack file' width={25} /> */}
                                                        <svg width="14" height="15" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <g clip-path="url(#clip0_2324_729)">
                                                                <path d="M0.560059 0.630371V5.39034C0.560059 5.95141 0.782945 6.48951 1.17969 6.88625C1.57643 7.28299 2.11452 7.50588 2.6756 7.50588C3.23667 7.50588 3.77477 7.28299 4.17151 6.88625C4.56825 6.48951 4.79114 5.95141 4.79114 5.39034V2.21703C4.79114 1.93649 4.6797 1.66744 4.48132 1.46907C4.28295 1.2707 4.01391 1.15926 3.73337 1.15926C3.45283 1.15926 3.18378 1.2707 2.98541 1.46907C2.78704 1.66744 2.6756 1.93649 2.6756 2.21703V5.91922M6.37779 1.15926H13.2533C13.5338 1.15926 13.8029 1.2707 14.0013 1.46907C14.1996 1.66744 14.3111 1.93649 14.3111 2.21703V14.9103C14.3111 15.1908 14.1996 15.4599 14.0013 15.6582C13.8029 15.8566 13.5338 15.968 13.2533 15.968H2.6756C2.39506 15.968 2.12601 15.8566 1.92764 15.6582C1.72927 15.4599 1.61783 15.1908 1.61783 14.9103V9.09253M11.6666 5.39034H7.43556M11.6666 8.56365H7.43556M11.6666 11.737H4.26225" stroke={actionColor} stroke-width="1.05777" />
                                                            </g>
                                                            <defs>
                                                                <clipPath id="clip0_2324_729">
                                                                    <rect width="15.8665" height="15.8665" fill="white" transform="translate(0.0307617 0.630371)" />
                                                                </clipPath>
                                                            </defs>
                                                        </svg>

                                                        <span className='ms-1' style={{ color: actionColor, fontSize: 11 }}>{documentData?.filter(val => val?.task_name === cardData?.task_name)?.map(item => item?.todo_comment_documents?.length)}</span>
                                                    </div>
                                                    :
                                                    <></>
                                            }
                                            {
                                                cardData?.taskcommentCount !== 0 ?
                                                    <div style={{ border: `1px solid ${actionColor}`, borderRadius: 6, padding: 6 }} className='todo_comment_span' onClick={handleComment}>
                                                        {/* <img src={Comments} alt='comment' width={25} onClick={handleComment} /> */}
                                                        <svg width="18" height="18" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M6.09313 11.8032H14.357C14.4743 11.8032 14.5726 11.7638 14.652 11.685C14.7308 11.6057 14.7701 11.5073 14.7701 11.39C14.7701 11.2726 14.7308 11.1743 14.652 11.095C14.5726 11.0162 14.4743 10.9768 14.357 10.9768H6.09313C5.97578 10.9768 5.87744 11.0162 5.79811 11.095C5.71933 11.1743 5.67994 11.2726 5.67994 11.39C5.67994 11.5073 5.71933 11.6057 5.79811 11.685C5.87744 11.7638 5.97578 11.8032 6.09313 11.8032ZM6.09313 9.32403H14.357C14.4743 9.32403 14.5726 9.28464 14.652 9.20586C14.7308 9.12652 14.7701 9.02818 14.7701 8.91084C14.7701 8.79349 14.7308 8.69515 14.652 8.61582C14.5726 8.53704 14.4743 8.49765 14.357 8.49765H6.09313C5.97578 8.49765 5.87744 8.53704 5.79811 8.61582C5.71933 8.69515 5.67994 8.79349 5.67994 8.91084C5.67994 9.02818 5.71933 9.12652 5.79811 9.20586C5.87744 9.28464 5.97578 9.32403 6.09313 9.32403ZM6.09313 6.84488H14.357C14.4743 6.84488 14.5726 6.80549 14.652 6.72671C14.7308 6.64738 14.7701 6.54904 14.7701 6.43169C14.7701 6.31434 14.7308 6.216 14.652 6.13667C14.5726 6.05789 14.4743 6.0185 14.357 6.0185H6.09313C5.97578 6.0185 5.87744 6.05789 5.79811 6.13667C5.71933 6.216 5.67994 6.31434 5.67994 6.43169C5.67994 6.54904 5.71933 6.64738 5.79811 6.72671C5.87744 6.80549 5.97578 6.84488 6.09313 6.84488ZM4.12221 14.6955C3.74207 14.6955 3.42474 14.5683 3.17021 14.3137C2.91514 14.0587 2.7876 13.741 2.7876 13.3609V4.46077C2.7876 4.08063 2.91514 3.7633 3.17021 3.50877C3.42474 3.2537 3.74207 3.12616 4.12221 3.12616H16.3279C16.708 3.12616 17.0253 3.2537 17.2799 3.50877C17.535 3.7633 17.6625 4.08063 17.6625 4.46077V15.6318C17.6625 15.9293 17.5256 16.1345 17.2518 16.2475C16.978 16.3604 16.7367 16.3125 16.5279 16.1037L15.1197 14.6955H4.12221ZM15.4726 13.8691L16.8361 15.2277V4.46077C16.8361 4.33406 16.7832 4.21754 16.6774 4.11121C16.5711 4.00543 16.4546 3.95254 16.3279 3.95254H4.12221C3.99549 3.95254 3.87897 4.00543 3.77265 4.11121C3.66687 4.21754 3.61398 4.33406 3.61398 4.46077V13.3609C3.61398 13.4876 3.66687 13.6041 3.77265 13.7105C3.87897 13.8162 3.99549 13.8691 4.12221 13.8691H15.4726Z" fill={actionColor} />
                                                        </svg>
                                                        <span className='ms-1' style={{ color: actionColor, fontSize: 11 }}>{cardData?.taskcommentCount}</span>
                                                    </div>
                                                    :
                                                    <div style={{ border: `1px solid ${actionColor}`, borderRadius: 6, padding: 6 }} className='todo_comment_span' onClick={handleComment}>
                                                        {/* <img src={Comments} alt='comment' width={25} onClick={handleComment} /> */}
                                                        <svg width="18" height="18" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M6.09313 11.8032H14.357C14.4743 11.8032 14.5726 11.7638 14.652 11.685C14.7308 11.6057 14.7701 11.5073 14.7701 11.39C14.7701 11.2726 14.7308 11.1743 14.652 11.095C14.5726 11.0162 14.4743 10.9768 14.357 10.9768H6.09313C5.97578 10.9768 5.87744 11.0162 5.79811 11.095C5.71933 11.1743 5.67994 11.2726 5.67994 11.39C5.67994 11.5073 5.71933 11.6057 5.79811 11.685C5.87744 11.7638 5.97578 11.8032 6.09313 11.8032ZM6.09313 9.32403H14.357C14.4743 9.32403 14.5726 9.28464 14.652 9.20586C14.7308 9.12652 14.7701 9.02818 14.7701 8.91084C14.7701 8.79349 14.7308 8.69515 14.652 8.61582C14.5726 8.53704 14.4743 8.49765 14.357 8.49765H6.09313C5.97578 8.49765 5.87744 8.53704 5.79811 8.61582C5.71933 8.69515 5.67994 8.79349 5.67994 8.91084C5.67994 9.02818 5.71933 9.12652 5.79811 9.20586C5.87744 9.28464 5.97578 9.32403 6.09313 9.32403ZM6.09313 6.84488H14.357C14.4743 6.84488 14.5726 6.80549 14.652 6.72671C14.7308 6.64738 14.7701 6.54904 14.7701 6.43169C14.7701 6.31434 14.7308 6.216 14.652 6.13667C14.5726 6.05789 14.4743 6.0185 14.357 6.0185H6.09313C5.97578 6.0185 5.87744 6.05789 5.79811 6.13667C5.71933 6.216 5.67994 6.31434 5.67994 6.43169C5.67994 6.54904 5.71933 6.64738 5.79811 6.72671C5.87744 6.80549 5.97578 6.84488 6.09313 6.84488ZM4.12221 14.6955C3.74207 14.6955 3.42474 14.5683 3.17021 14.3137C2.91514 14.0587 2.7876 13.741 2.7876 13.3609V4.46077C2.7876 4.08063 2.91514 3.7633 3.17021 3.50877C3.42474 3.2537 3.74207 3.12616 4.12221 3.12616H16.3279C16.708 3.12616 17.0253 3.2537 17.2799 3.50877C17.535 3.7633 17.6625 4.08063 17.6625 4.46077V15.6318C17.6625 15.9293 17.5256 16.1345 17.2518 16.2475C16.978 16.3604 16.7367 16.3125 16.5279 16.1037L15.1197 14.6955H4.12221ZM15.4726 13.8691L16.8361 15.2277V4.46077C16.8361 4.33406 16.7832 4.21754 16.6774 4.11121C16.5711 4.00543 16.4546 3.95254 16.3279 3.95254H4.12221C3.99549 3.95254 3.87897 4.00543 3.77265 4.11121C3.66687 4.21754 3.61398 4.33406 3.61398 4.46077V13.3609C3.61398 13.4876 3.66687 13.6041 3.77265 13.7105C3.87897 13.8162 3.99549 13.8691 4.12221 13.8691H15.4726Z" fill={actionColor} />
                                                        </svg>
                                                    </div>
                                            }

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </StyledCard>
                    </div>
            }



            {
                hashtag ?
                    <TodoHashtag
                        hashtag={hashtag}
                        setHashtag={setHashtag}
                        hashTagSearch={hashTagSearch}
                        dropdownValState={dropdownValState}
                        documentData={documentData}
                        getsinglehashtag={getsinglehashtag}
                        getDocData={getDocData}
                        viewStatus={viewStatus}
                        viewModelStatus={viewModelStatus}
                        setViewStatus={setViewStatus}
                        getDocumentData={getDocumentData}
                        assignedModelData={assignedModelData}
                        setGetsinglehashtag={setGetsinglehashtag}
                        setHashTagSearch={setHashTagSearch}
                        comment={comment}
                        setComment={setComment}
                        item={cardData}
                        fetchAssignedUserList={fetchAssignedUserList}
                        projectId={projectId}
                        sendPropData={sendPropData}
                        recordData={recordData}
                        setRecordData={setRecordData}
                        setIsCreatedAndUpdate={setIsCreatedAndUpdate}
                        setAssignTask={setAssignTask}
                        itemData={item}
                        setFetchCurrentId={setFetchCurrentId}


                    /> : ""
            }

            {
                comment ?
                    <TodoComments
                        comment={comment}
                        setComment={setComment}
                        dropdownValState={dropdownValState?.assigned_to_users}
                        item={cardData}
                        setTenderCommentData={() => { }}
                        projectId={projectId}
                        onCloseOfComment={() => { }}
                    /> : ""
            }
            {/* <TodoDocumentViewModal viewStatus={viewStatus} viewModelStatus={viewModelStatus} setViewStatus={setViewStatus} getDocumentData={getDocumentData} assignedModelData={assignedModelData} /> */}
            <TodoDetail
                setTaskId={setTaskId}
                taskId={taskId}
                detail={detail}
                setTodoDetail={setTodoDetail}
                recordData={recordData}
                setRecordData={setRecordData}
                dropdownValState={dropdownValState}
                documentData={documentData}
                setHashTagSearch={setHashTagSearch}
                setGetsinglehashtag={setGetsinglehashtag}
                setHashtag={setHashtag}
                setAssignTask={setAssignTask}
                setIsCreatedAndUpdate={setIsCreatedAndUpdate}

            />

        </>

    );
}
// TodoItemCard.whyDidYouRender = true
export default TodoItemCard;
