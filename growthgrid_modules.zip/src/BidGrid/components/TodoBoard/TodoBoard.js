// @ts-nocheck
import { DragDropContext } from 'react-beautiful-dnd';
import { useEffect, useMemo, useState } from 'react';
import produce from 'immer';
import styled from 'styled-components';
import { TodoTypes } from '../TodoBoard/TodoTypes';
import TodoItemFormModel from '../TodoBoard/TodoItemFormModel';
import TodoCol from '../TodoBoard/TodoCol';
import { useSyncedState } from '../SharedHooks/SharedHooks';
import { TodoServices } from 'Services/bidgrid/todo/TodoServices';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { useDispatch } from 'react-redux';


const TaskboardRoot = styled.div`
  min-height: 0;
  height: 100%;
  min-width: 800px;
  max-width: 1400px;
  margin: auto;
`;

const TaskboardContent = styled.div`
  height: 100%;
  padding: 0.5rem;
  display: flex;
  justify-content: space-around;
`;

const defaultItems = {
    [TodoTypes.TO_DO]: [],
    [TodoTypes.IN_PROGRESS]: [],
    [TodoTypes.DONE]: [],
};
const initArr = {
    [TodoTypes.TO_DO]: [],
    [TodoTypes.IN_PROGRESS]: [],
    [TodoTypes.DONE]: [],
}

const initialState = {
    task_name: '',
    task_description: '',
    task_type: 1,
    task_priority: null,
    hash_tags: [],
    current_scope: null,
    assign_type: null,
    assigned_to_users: [],
    project_id: null,
    deadline_date: null

}
function Todoboard({ open, onClosebtn, dropdownValState, setOpen, selectedFilterData, searchData, projectId, setDropdownValState }) {
    const [existingData, setExistingData] = useState(initArr)
    const [itemsByStatus, setItemsByStatus] = useSyncedState('itemsByStatus', defaultItems);
    const { socket, isConnected } = useSelector((state) => state.socket);
    const { navigateData } = useSelector((state) => state.navigationData)
    const [assignTask, setAssignTask] = useState(initialState);
    const [recordData, setRecordData] = useState({})
    const [isCreatedAndUpdate, setIsCreatedAndUpdate] = useState(false)
    const [documentData, setDocumentData] = useState([])
    const [isUpdate, setIsUpdate] = useState(false)
    const [skeletonVisible, setSkeletonVisible] = useState(true);
    const [taskComment, setTaskComment] = useState([])
    const [fetchCurrentId, setFetchCurrentId] = useState(null)


    //state for notification
    const [todoList, setTodoList] = useState(null)
    const [progressList, setProgressList] = useState(null)
    const [doneList, setDoneList] = useState(null)
    const notify = (error) => toast.error(error);

    useEffect(() => {

        if (isConnected) {
            socket.on(fetchCurrentId, async (data) => {
                const existingItem = taskComment.find((item) => item.task_id === data?.task_id);
                if (existingItem) {
                    const updatedArray = taskComment.map((item) =>
                        item.task_id === data?.task_id ? { ...item, total_comment: data?.total_comment } : item
                    );
                    setTaskComment(updatedArray);
                } else {
                    setTaskComment([...taskComment, data]);
                }
            })
        }
    }, [isConnected, fetchCurrentId])

    const updateSequence = async (newStatus, draft, destinationStatus) => {
        let obj = {};
        for (let i = 0; i < draft[destinationStatus].length; i++) {
            obj[i + 1] = draft[destinationStatus][i].id
        }
        let formDataObj = {
            scopeId: newStatus,
            sequence: obj
        }
        try {
            const response = await TodoServices.rearrangeOrder(formDataObj)
        } catch (error) {
            console.error('Error updating task status:', error);
        }
        return
    }
    //fetch documents
    const fetchDocumentTask = async () => {

        if (projectId) {
            const formData = new URLSearchParams();
            formData.append('project_id', projectId)
            try {
                const response = await TenderApi.projectDocList(formData)
                if (response?.data?.status === '1') {
                    setDocumentData(response?.data?.data)
                } else {
                    setDocumentData([])
                }
            } catch (error) {
                return []
            }
        } else {
            try {
                const response = await TodoServices.getTodoDocumentList()
                if (response?.data?.status === '1') {
                    setDocumentData(response?.data?.data)
                } else {
                    setDocumentData([])
                }
            } catch (error) {
                return []
            }
        }

    }
    //check weather task exist to show message or not
    const checKValidator = async () => {
        if (navigateData?.hasOwnProperty('item')) {
            let dataArrays = [todoList, progressList, doneList];
            let dataFound = false;
            for (let i = 0; i < dataArrays?.length; i++) {
                const found = dataArrays[i]?.find(obj => obj.id === navigateData?.key);
                if (found?.hasOwnProperty('id')) {
                    dataFound = true;
                    break;
                }
            }
            if (!dataFound) {
                if (navigateData?.item?.mentioned_by) {
                    notify(`Request ${navigateData?.item?.mentioned_by} to get 
                    enrolled into the ${navigateData?.item?.category_details}`);
                } else {
                    notify(`Request ${navigateData?.item?.assigned_users?.[0]?.user?.userfullname} to get 
                    enrolled into the ${navigateData?.item?.task_name}`);
                }
            } else {
                return
            }
        }
    }
    useEffect(() => {
        if (todoList !== null && progressList !== null && doneList !== null) {
            checKValidator();
        }
    }, [todoList, progressList, doneList]);

    // fetch todo task if any 
    const fetchToDoTask = async (id) => {
        console.log(id, 'id')
        try {
            let response, list = [];

            if (projectId) {
                const formData = new URLSearchParams();
                formData.append('project_id', projectId);

                if (id === TodoTypes.TO_DO) {
                    response = await TenderApi.ProjectTodoList(formData);
                } else if (id === TodoTypes.IN_PROGRESS) {
                    response = await TenderApi.ProjectProgressList(formData);
                } else if (id === TodoTypes.DONE) {
                    response = await TenderApi.ProjectDoneList(formData);
                }
                list = response?.data?.data ?? [];
            } else {
                if (id === TodoTypes.TO_DO) {
                    response = await TodoServices.getToDoList();
                } else if (id === TodoTypes.IN_PROGRESS) {
                    response = await TodoServices.getInProgressList();
                } else if (id === TodoTypes.DONE) {
                    response = await TodoServices.getDoneList();
                }

                list = response?.data?.data ?? [];
            }

            if (id === TodoTypes.TO_DO) {
                setTodoList(list);
            } else if (id === TodoTypes.IN_PROGRESS) {
                setProgressList(list);
            } else if (id === TodoTypes.DONE) {
                setDoneList(list);
            }

            setSkeletonVisible(false);
            return list;
        } catch (error) {
            console.error("Error fetching todo tasks:", error);
            return [];
        }
    };
    const storeAndCompareTasks = async () => {

        // const dataDocs = await fetchDocumentTask()
        const statuses = [TodoTypes.TO_DO, TodoTypes.IN_PROGRESS, TodoTypes.DONE];
        let processedStatusCount = 0;
        await Promise.all(statuses.map(async (status) => {
            try {
                const tasks = await fetchToDoTask(status);

                if (itemsByStatus[status] === undefined || itemsByStatus[status].length === 0) {
                    setItemsByStatus((current) =>
                        produce(current, (draft) => {
                            if (tasks?.length > 0) {
                                draft[status] = tasks?.map((task) => ({ ...task, id: task.id }));
                            } else {
                                draft[status] = []
                            }
                        })
                    );
                    setExistingData((current) =>
                        produce(current, (draft) => {
                            draft[status] = tasks?.map((task) => task.id);
                        })
                    );
                } else if (isUpdate) {
                    setItemsByStatus((current) =>
                        produce(current, (draft) => {
                            draft[status] = tasks?.map((task) => ({ ...task, id: task.id }));
                        })
                    );
                }
                else {
                    setItemsByStatus((current) =>
                        produce(current, (draft) => {
                            tasks?.forEach((task) => {
                                if (existingData[status].indexOf(task.id) < 0) {
                                    draft[status].unshift({ ...task, id: task.id });
                                    let index = statuses.indexOf(status) + 1;
                                    updateSequence(index, draft, status)
                                }
                            });
                        })
                    );

                    setExistingData((current) =>
                        produce(current, (draft) => {
                            tasks?.forEach((task) => {
                                if (existingData[status].indexOf(task.id) < 0) {
                                    draft[status].unshift(task.id);
                                }
                            });
                        })
                    );
                    if (isCreatedAndUpdate === true) {
                        setIsCreatedAndUpdate(false)
                    }
                }

            } catch (error) {
                console.error("Error fetching tasks:", error);
            }
            processedStatusCount++
            if (processedStatusCount === 2) {
                await fetchDocumentTask();
                setIsUpdate(false);
            }
        })
        )


    }

    useEffect(() => {
        storeAndCompareTasks()
    }, [])

    useEffect(() => {
        if (isCreatedAndUpdate) {
            storeAndCompareTasks()
        }
    }, [isCreatedAndUpdate])

    useEffect(() => {
        if (isUpdate) {
            storeAndCompareTasks()
        }
    }, [isUpdate])

    const updateTaskStatus = async (taskId, newStatus, draft, destinationStatus) => {
        if (projectId) {
            try {
                const formData = new URLSearchParams()
                formData.append('task_id', taskId)
                formData.append('tender_id', projectId)
                formData.append('current_scope', newStatus)
                const response = await TodoServices.UpdateTenderToDoScope(formData)
                return response;
            } catch (error) {
                console.error('Error updating task status:', error);
            }
        } else {
            try {
                const formData = new URLSearchParams()
                formData.append('task_id', taskId)
                formData.append('current_scope', newStatus)
                const response = await TodoServices.UpdateToDoScope(formData)
                return response;
            } catch (error) {
                console.error('Error updating task status:', error);
            }
        }

        // updateSequence(newStatus, draft, destinationStatus)


    };

    const handleDragEnd = ({ source, destination }) => {

        if (!destination) {
            return;
        }
        const sourceStatus = source.droppableId;
        const destinationStatus = destination.droppableId;
        const sourceIndex = source.index;
        const destinationIndex = destination.index;
        let scope = null;

        switch (destinationStatus) {
            case "TO DO":
                scope = 1
                break;
            case "IN PROGRESS":
                scope = 2
                break;
            case "DONE":
                scope = 3
                break;
            default:
                break;
        }

        if (sourceStatus === destinationStatus) {
            setItemsByStatus((current) =>
                produce(current, (draft) => {
                    const movedTask = draft[destinationStatus][destinationIndex];
                    const selectedTask = draft[sourceStatus][sourceIndex]
                    draft[sourceStatus][sourceIndex].taskcommentCount = taskComment?.find((task) => task.task_id === selectedTask?.id)?.total_comment ?? selectedTask?.taskcommentCount;
                    const [removed] = draft[sourceStatus]?.splice(sourceIndex, 1);
                    draft[destinationStatus]?.splice(destinationIndex, 0, removed);
                    let drafts = { ...draft }
                    updateTaskStatus(selectedTask.id, scope, drafts, destinationStatus)
                })
            );
        }
        if (
            sourceStatus === "TO DO" &&
            destinationStatus === "IN PROGRESS"
        ) {


            setItemsByStatus((current) =>
                produce(current, (draft) => {
                    if (!destination) {
                        return;
                    }
                    const movedTask = draft[destinationStatus][destinationIndex];
                    const selectedTask = draft[sourceStatus][sourceIndex]
                    draft[sourceStatus][sourceIndex].taskcommentCount = taskComment?.find((task) => task.task_id === selectedTask?.id)?.total_comment ?? selectedTask?.taskcommentCount;
                    draft[sourceStatus][sourceIndex].current_scope = "2";
                    const [removed] = draft[sourceStatus]?.splice(sourceIndex, 1);
                    draft[destinationStatus]?.splice(destinationIndex, 0, removed);
                    let drafts = { ...draft }
                    updateTaskStatus(selectedTask?.id, scope, drafts, destinationStatus)

                })
            );
        }
        else if (
            sourceStatus === "IN PROGRESS" &&
            destinationStatus === "DONE"
        ) {
            setItemsByStatus((current) =>
                produce(current, (draft) => {
                    if (!destination) {
                        return;
                    }
                    const movedTask = draft[destinationStatus][destinationIndex];
                    const selectedTask = draft[sourceStatus][sourceIndex]
                    draft[sourceStatus][sourceIndex].taskcommentCount = taskComment?.find((task) => task.task_id === selectedTask?.id)?.total_comment ?? selectedTask?.taskcommentCount
                    draft[sourceStatus][sourceIndex].current_scope = "3";
                    const [removed] = draft[sourceStatus]?.splice(sourceIndex, 1);
                    draft[destinationStatus]?.splice(destinationIndex, 0, removed);
                    let drafts = { ...draft }
                    updateTaskStatus(selectedTask.id, scope, drafts, destinationStatus)
                })
            );
        }
        else if (
            sourceStatus === "IN PROGRESS" &&
            destinationStatus === "TO DO"
        ) {
            setItemsByStatus((current) =>
                produce(current, (draft) => {
                    if (!destination) {
                        return;
                    }
                    const movedTask = draft[destinationStatus][destinationIndex];
                    const selectedTask = draft[sourceStatus][sourceIndex]
                    draft[sourceStatus][sourceIndex].taskcommentCount = taskComment?.find((task) => task.task_id === selectedTask?.id)?.total_comment ?? selectedTask?.taskcommentCount
                    draft[sourceStatus][sourceIndex].current_scope = "1";
                    const [removed] = draft[sourceStatus]?.splice(sourceIndex, 1);
                    draft[destinationStatus]?.splice(destinationIndex, 0, removed);
                    let drafts = { ...draft }
                    updateTaskStatus(selectedTask.id, scope, drafts, destinationStatus)
                })
            );
        }
        else if (
            sourceStatus === "DONE" &&
            destinationStatus === "IN PROGRESS"
        ) {
            setItemsByStatus((current) =>
                produce(current, (draft) => {
                    if (!destination) {
                        return;
                    }
                    const movedTask = draft[destinationStatus][destinationIndex];
                    const selectedTask = draft[sourceStatus][sourceIndex]
                    draft[sourceStatus][sourceIndex].taskcommentCount = taskComment?.find((task) => task.task_id === selectedTask?.id)?.total_comment ?? selectedTask?.taskcommentCount
                    draft[sourceStatus][sourceIndex].current_scope = "2";
                    const [removed] = draft[sourceStatus]?.splice(sourceIndex, 1);
                    draft[destinationStatus]?.splice(destinationIndex, 0, removed);
                    let drafts = { ...draft }
                    updateTaskStatus(selectedTask.id, scope, drafts, destinationStatus)
                })
            )
        }
        else if (
            sourceStatus === "DONE" &&
            destinationStatus === "TO DO"
        ) {
            setItemsByStatus((current) =>
                produce(current, (draft) => {
                    if (!destination) {
                        return;
                    }
                    const movedTask = draft[destinationStatus][destinationIndex];
                    const selectedTask = draft[sourceStatus][sourceIndex]
                    draft[sourceStatus][sourceIndex].taskcommentCount = taskComment?.find((task) => task.task_id === selectedTask?.id)?.total_comment ?? selectedTask?.taskcommentCount
                    draft[sourceStatus][sourceIndex].current_scope = "1";
                    const [removed] = draft[sourceStatus]?.splice(sourceIndex, 1);
                    draft[destinationStatus]?.splice(destinationIndex, 0, removed);
                    let drafts = { ...draft }
                    updateTaskStatus(selectedTask.id, scope, drafts, destinationStatus)
                })
            )
        }
        else if (
            sourceStatus === "TO DO" &&
            destinationStatus === "DONE"
        ) {
            setItemsByStatus((current) =>
                produce(current, (draft) => {
                    if (!destination) {
                        return;
                    }
                    const movedTask = draft[destinationStatus][destinationIndex];
                    const selectedTask = draft[sourceStatus][sourceIndex]
                    draft[sourceStatus][sourceIndex].taskcommentCount = taskComment?.find((task) => task.task_id === selectedTask?.id)?.total_comment ?? selectedTask?.taskcommentCount
                    draft[sourceStatus][sourceIndex].current_scope = "3";
                    const [removed] = draft[sourceStatus]?.splice(sourceIndex, 1);
                    draft[destinationStatus]?.splice(destinationIndex, 0, removed);
                    let drafts = { ...draft }
                    updateTaskStatus(selectedTask.id, scope, drafts, destinationStatus)
                })
            )
        }
    };


    const handleDelete = ({ status, itemToDelete }) =>
        setItemsByStatus((current) =>
            produce(current, (draft) => {
                draft[status] = draft[status].filter((item) => item.id !== itemToDelete.id);
            })
        );


    const todoBoardProp = (item) => {
        setRecordData(item);
    }

    return (
        <>
            <DragDropContext onDragEnd={handleDragEnd}>
                <TaskboardRoot>
                    <TaskboardContent>
                        {Object.values(TodoTypes)?.map((status) => (
                            <TodoCol
                                key={status}
                                status={status}
                                items={itemsByStatus[status]}
                                onDelete={handleDelete}
                                dropdownValState={dropdownValState}
                                selectedFilterData={selectedFilterData}
                                open={open}
                                setOpen={setOpen}
                                todoBoardProp={todoBoardProp}
                                documentData={documentData}
                                isUpdate={isUpdate}
                                recordData={recordData}
                                setRecordData={setRecordData}
                                skeletonVisible={skeletonVisible}
                                setSkeletonVisible={setSkeletonVisible}
                                setAssignTask={setAssignTask}
                                assignTask={assignTask}
                                searchData={searchData}
                                projectId={projectId}
                                setFetchCurrentId={setFetchCurrentId}
                                setIsCreatedAndUpdate={setIsCreatedAndUpdate}

                            />
                        ))}
                    </TaskboardContent>
                </TaskboardRoot>
            </DragDropContext>

            <TodoItemFormModel
                initialState={initialState}
                visible={open}
                onCancel={onClosebtn}
                setOpen={setOpen}
                recordData={recordData}
                setIsCreatedAndUpdate={setIsCreatedAndUpdate}
                setIsUpdate={setIsUpdate}
                setRecordData={setRecordData}
                documentData={documentData}
                fetchDocumentTask={fetchDocumentTask}
                setAssignTask={setAssignTask}
                assignTask={assignTask}
                projectId={projectId}
                dropdownValState={dropdownValState}
                setDropdownValState={setDropdownValState}
            />
        </>
    );
}

export default Todoboard;
