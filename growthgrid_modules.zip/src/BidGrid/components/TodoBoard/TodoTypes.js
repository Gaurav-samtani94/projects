export const TaskboardItem = {
    id: '',
    title: '',
    description: '',
};

export const TodoTypes = {
    TO_DO: 'TO DO',
    IN_PROGRESS: 'IN PROGRESS',
    DONE: 'DONE',
};
