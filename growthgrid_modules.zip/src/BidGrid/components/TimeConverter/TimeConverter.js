

// export function TimeConverter(dateString) {
//     console.log(dateString, 'date')
//     if (dateString) {
//         const date = new Date(dateString);
//         console.log(date, 'date and time')
//         let hours = date.getUTCHours();
//         const ampm = hours >= 12 ? 'PM' : 'AM';
//         hours = (hours % 12) || 12; // Convert hours to 12-hour format
//         const minutes = date.getUTCMinutes().toString().padStart(2, '0');
//         const seconds = date.getUTCSeconds().toString().padStart(2, '0');
//         return `${hours}:${minutes}:${seconds} ${ampm}`;
//     } else {
//         return '';
//     }
// }



export function TimeConverter(dateString) {
    if (dateString) {
        let date;

        // if date and time 
        if (dateString.includes('-')) {
            date = new Date(dateString);

            // if only time 
        } else if (dateString.includes(':')) {
            dateString = `1970-01-01T${dateString}Z`;
            date = new Date(dateString);
        } else {
            return ''; // Invalid format
        }

        if (!isNaN(date.getTime()) && date.getUTCHours() === 0 && date.getUTCMinutes() === 0 && date.getUTCSeconds() === 0) {
            return '';
        }
        let hours = date.getUTCHours();
        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = (hours % 12) || 12; // Convert hours to 12-hour format
        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
        const seconds = date.getUTCSeconds().toString().padStart(2, '0');
        return `${hours}:${minutes}:${seconds} ${ampm}`;
    } else {
        return '';
    }
}

