// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Row, Col, Form, Select, DatePicker, Input, Tabs, Button, Progress } from 'antd';
import { Down } from '@icon-park/react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { ProfileDetails } from 'Services/Profile/ProfileDetails';
import { useSelector } from 'react-redux'
import { userDetailsApi } from 'Services/bidgrid/master/profile/bidProfile';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import { AddTenderList } from 'Services/bidgrid/add/AddTender';
import { RoleList } from 'Services/bidgrid/master/role/bidRole';
import dayjs from 'dayjs';
import { AddUnitApiList } from 'Services/bidgrid/master/addUnit/AddUnit';
import { biddepartment } from 'Services/bidgrid/master/department/biddepartment';
import { DesignationList } from 'Services/bidgrid/master/designation/bidDesignation';
import { bidCompany } from 'Services/bidgrid/master/company/bidCompany';
import { JobGrid } from 'Services/bidgrid/master/jobGrid';
import PasswordChangeBids from 'BidGrid/pages/Profile/PasswordChangeBid';
import DefaultImage from '../../../assests/img/user.png'
import { useDispatch } from 'react-redux';
import { userBidInfoAction } from 'Redux/actions/common/userInfoAction';
import moment from 'moment';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import { useNavigate } from 'react-router-dom';
import ROUTES from 'Constants/Routes';
import { useParams } from 'react-router-dom';
import { docurlchat } from 'utils/configurable';
const { TextArea } = Input;

const intialState = {
    firstname: '',
    lastname: '',
    role_id: null,
    company_id: null,
    department_id: null,
    designation_id: null,
    jobgrade_id: null,
    reporting_mngr_id: null,
    email: '',
    contactnumber: '',
    unit_id: null,
    country_id: null,
    state_id: null,
    city_id: null,
    date_of_birth: null,
    full_address_1: '',
    zip_code: '',
    old_password: '',
    password: '',
    confirmPassword: "",
    isactive: null
}
const optionVal = {
    role: [],
    unit: [],
    department: [],
    designation: [],
    company: [],
    jobgrid: [],
    reporting_manager: []

}
const notify = (error) => toast.error(error);
const notifySuccess = (msg) => toast.success(msg);

const CustomProfile = (props) => {
    const { isPersonal } = props
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const { id } = useParams();
    const [form] = Form.useForm();
    const [formdata] = Form.useForm();

    const { bidgridData } = useSelector((state) => state.loginData)
    const { BidCountry } = useSelector((state) => state.bidDropdownCalVal)
    const { userBidInfo } = useSelector((state) => state.userDetails)

    const [dropdownData, setDropdownData] = useState(optionVal)
    const [skeleton, setSkeleton] = useState(false)
    const [personalInputData, setPersonalInputData] = useState(intialState)
    const [profileState, setProfileState] = useState([])
    const [profileCity, setProfileCity] = useState([])
    const [userDetails, setUserDetails] = useState([]);
    const [storageDetail, setStorageDetail] = useState({});
    const [getProgressPercentage, setProgressPercentage] = useState(null);


    const disabledDate = (current) => {
        return current && current > moment().endOf('day');
    };

    const BdUserdetails = async () => {

        const formData = new URLSearchParams();
        formData.append('user_id', isPersonal ? bidgridData?.data?.id : id)
        try {
            const response = await ProfileDetails.getuserdetails(formData);
            if (response?.data?.status == 1) {
                setUserDetails(response.data.data)
                if (isPersonal) {
                    dispatch(userBidInfoAction({
                        ...response.data.data,
                        docname: userBidInfo.docname,
                        docpath: userBidInfo.docpath,
                        thumbnailName: userBidInfo.thumbnailName,
                        thumbnailPath: userBidInfo.thumbnailPath,
                        profileimg: response.data.data?.profileimg,
                        profileimg_path: response.data.data?.profileimg_path
                    }));
                }

            }
            else {
                setUserDetails([])
                notify(response?.response?.data?.message)
            }
        } catch (error) {
            console.log(error, 'api error');
        }
    };

    const empDropdownValues = async () => {
        try {
            const [
                roleResponse,
                unitResponse,
                departmentResponse,
                designationResponse,
                companyResponse,
                jobGridResponse,
                reportingManagerResponse
            ] = await Promise.all([
                RoleList.getbidRole(),
                AddUnitApiList.getUnitList(),
                biddepartment.getAllDepartmentList(),
                DesignationList.getDesignationList(),
                bidCompany.getCompanyList(),
                JobGrid?.getJobGridList(),
                bidEmployeeList.getUserList()
            ]);
            setDropdownData(prev => ({
                ...prev,
                role: roleResponse?.data?.data,
                unit: unitResponse?.data?.data,
                department: departmentResponse?.data?.data,
                designation: designationResponse?.data?.data,
                company: companyResponse?.data?.data,
                jobgrid: jobGridResponse?.data?.data,
                reporting_manager: reportingManagerResponse?.data?.data
            }));
        } catch (error) {
            console.error(error);
        }
    };

    const userUpdatePersonal = async (value) => {
        try {
            const formdata = new URLSearchParams();
            formdata.append('update_user_id', isPersonal ? userDetails?.id : id)
            formdata.append('country_id', value?.country_id)
            formdata.append('state_id', value?.state_id)
            formdata.append('city_id', value?.city_id)
            formdata.append('full_address_1', value?.full_address_1)
            formdata.append('zip_code', value?.zip_code)
            formdata.append('date_of_birth', value?.date_of_birth !== null ? dayjs(value?.date_of_birth)?.format('YYYY-MM-DD') : '')
            const response = await userDetailsApi.updatePersonalInfo(formdata);
            if (response?.data?.status == 1) {
                BdUserdetails()
                notifySuccess(response?.data?.message)
                handleResetOfficial()
            }
            else {
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            console.log(error, 'Api Error');

        }
    }


    const userUpdateOfficial = async (value) => {
        try {
            const formdata = new URLSearchParams();
            formdata.append('update_user_id', isPersonal ? userDetails?.id : id)
            formdata.append('firstname', value?.firstname || '')
            formdata.append('lastname', value?.lastname || '')
            formdata.append('contactnumber', value?.contactnumber || '')
            formdata.append('emp_role_id', value?.role_id || '')
            formdata.append('company_id', value?.company_id !== null ? value?.company_id : '')
            formdata.append('department_id', value?.department_id !== null ? value?.department_id : '')
            formdata.append('designation_id', value?.designation_id || '')
            formdata.append('jobgrade_id', value?.jobgrade_id !== null ? value?.jobgrade_id : '')
            formdata.append('reporting_mngr_id', value?.reporting_mngr_id !== null ? value?.reporting_mngr_id : '')
            formdata.append('business_unit_id', value?.unit_id !== null ? value?.unit_id : '')
            formdata.append('email', value?.email)
            formdata.append('isactive', value?.isactive) // will need to make it dynamic
            // formdata.append('system_admin', 2)
            const response = await userDetailsApi.updateUserDetail(formdata);

            if (response?.data?.status == 1) {
                BdUserdetails()
                notifySuccess(response?.data?.message)
                handleResetPersonal()
            }
            else {
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            console.log(error, 'Api Error');
        }
    }

    const fetchStorageDetail = async () => {
        try {
            const response = await userDetailsApi.getStorageDetail(formdata);

            if (response?.data?.status == 1) {
                setStorageDetail(response?.data?.data);
                let storage = response?.data?.data;
                let progressPercentage = (storage?.UsedSpace / storage?.TotalLimit) * 100 ;
                setProgressPercentage(progressPercentage)

            }
            else {
                setStorageDetail({});
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            console.log(error, 'Api Error');
        }
    }


    useEffect(() => {
        BdUserdetails();
        fetchStorageDetail();

    }, [])

    useEffect(() => {
        empDropdownValues()
    }, [])


    // passord api --- khushbu
    const postPasswordChange = async (handleResetChangePassword) => {

        const { password, confirmPassword, old_password } = personalInputData;
        try {

            const formData = new URLSearchParams();
            formData.append('user_id', userBidInfo?.id)
            formData.append('old_password', old_password);
            const response = await userDetailsApi.oldPassword(formData);
            if (response.data.status === '1') {
                if (password === confirmPassword) {
                    const formData = new URLSearchParams();
                    formData.append('user_id', userBidInfo?.id)
                    formData.append('password', password);
                    const response = await userDetailsApi?.changePassword(formData);
                    if (response.data.status === '1') {
                        setPersonalInputData(response?.data?.message);
                        notifySuccess(response?.data?.message)
                        handleResetOfficial()
                        handleResetChangePassword()
                        setTimeout(() => {
                            navigate(ROUTES.BD_LOGIN)
                            localStorage.setItem('bidToken', '');
                        }, [1000])



                    }
                    else {
                        notify(response?.response?.data?.message);
                    }
                }
                else {
                    notify('Passwords do not match or do not meet criteria');
                }
            }
            else {
                console.log(response, 'response')
                notify("Old Password is incorrect!!");
            }
        } catch (error) {
            notify("Old Password is incorrect!!");
            console.log("Server error")
        }
    }

    // common functions


    const getUserStateLoc = async () => {
        const formData = new URLSearchParams();
        formData.append('country_id', personalInputData?.country_id);
        try {
            const response = await AddTenderList.getTenderStateList(formData)
            if (response?.data?.status === '1') {
                setProfileState(response?.data?.data)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const getUserCityLoc = async () => {
        const formData = new URLSearchParams();
        formData.append('state_id', personalInputData?.state_id);
        try {
            const response = await AddTenderList.getTenderCityList(formData)

            if (response?.data?.status === '1') {
                setProfileCity(response?.data?.data)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    useEffect(() => {
        if (personalInputData?.country_id) {
            getUserStateLoc()
        }
    }, [personalInputData?.country_id])

    useEffect(() => {
        if (personalInputData?.state_id) {
            getUserCityLoc()
        }
    }, [personalInputData?.state_id])

    const handleResetOfficial = () => {
        setPersonalInputData('');
        form.resetFields()
    };
    const handleResetPersonal = () => {
        // setPersonalInputData('');
        formdata?.resetFields()
    };

    const handleInputChange = (name, value, date) => {
        if (name === "country_id") {
            formdata?.setFieldsValue({
                state_id: null,
                city_id: null
            })
        }
        if (name === "state_id") {
            formdata?.setFieldsValue({
                city_id: null
            })
        }
        setPersonalInputData(
            {
                ...personalInputData,
                [name]: value
            })
    }

    const predefinedvalues = () => {

        const officialObj = {
            firstname: userDetails?.firstname || '',
            lastname: userDetails?.lastname || '',
            role_id: dropdownData?.role?.find(val => val?.id === userDetails?.bg_mstr_role?.id)?.hasOwnProperty('id') ? userDetails?.bg_mstr_role?.id : null,
            company_id: dropdownData?.company?.find(val => val?.id === userDetails?.company_id)?.hasOwnProperty('id') ? userDetails?.company_id : null,
            department_id: dropdownData?.department?.find(val => val?.id === userDetails?.department_id)?.hasOwnProperty('id') ? userDetails?.department_id : null,
            designation_id: dropdownData?.designation?.find(val => val?.id === userDetails?.designation_id)?.hasOwnProperty('id') ? userDetails?.designation_id : null,
            jobgrade_id: dropdownData?.jobgrid?.find(val => val?.id === userDetails?.jobgrade_id)?.hasOwnProperty('id') ? userDetails?.jobgrade_id : null,
            reporting_mngr_id: dropdownData?.reporting_manager?.find(val => val?.id === userDetails?.reporting_mngr_id)?.hasOwnProperty('id') ? userDetails?.reporting_mngr_id : null,
            email: userDetails?.email || '',
            contactnumber: userDetails?.contactnumber || '',
            unit_id: dropdownData?.unit?.find(val => val?.id === userDetails?.unit_id)?.hasOwnProperty('id') ? userDetails?.unit_id : null,
            isactive: userDetails?.isactive
        }

        const personalObj = {
            country_id: userDetails?.country_id || '',
            state_id: profileState?.find(val => val?.id === userDetails?.state_id)?.hasOwnProperty('id') ? userDetails?.state_id : null,
            city_id: profileCity?.find(val => val.id === userDetails?.city_id)?.hasOwnProperty('id') ? userDetails?.city_id : null,
            date_of_birth: userDetails?.date_of_birth !== null ? dayjs(userDetails?.date_of_birth) : null,
            full_address_1: userDetails?.full_address_1 || '',
            zip_code: userDetails?.zip_code,
            permanent_sys_adm: userDetails?.permanent_sys_adm
        }
        setPersonalInputData((prevState) => {
            return {
                ...prevState,
                ...officialObj,
                ...personalObj
            };
        });
        form.setFieldsValue(officialObj);
        formdata.setFieldsValue(personalObj);
    }

    useEffect(() => {
        predefinedvalues()
    }, [userDetails, dropdownData])

    const validateContactNumber = (_, value) => {
        const regex = /^\d{10}$/;

        if (!value || regex.test(value)) {
            return Promise.resolve();
        }

        return Promise.reject('Contact number must be a 10-digit number');
    };

    const handleProfileChange = (name, e) => {
        const trimmedValue = e.target.value.trimStart(); // Trim leading spaces
        form.setFieldsValue({ [name]: trimmedValue }); //
    };

    const updateProfilePicture = async (file) => {
        const formData = new FormData();
        formData.append('user_id', bidgridData?.data?.id)
        formData.append('files', file);
        try {
            const response = await userDetailsApi.updateUserProfilePic(formData);
            if (response?.data?.status === '1') {
                BdUserdetails()
                notifySuccess('Logo updated successfully');
            } else {
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            console.error('API Error:', error);
            notify('Error updating logo');
        }
    }

    function handleImageChange(event) {
        const file = event.target.files[0];
        updateProfilePicture(file)
    }
    // to edit employee info functions

    return (
        <>
            <div className="bd_profile_main">
                {!isPersonal && <div className='bd_main_profile_headings'>Employee Profile</div>}

                <div className='bd_main_add'>
                    <div className='bd_main_sub_add_profile'>
                        <div className='bd_main_sub_image'>
                            <img className="bd_main_sub_s_img" src={userDetails?.profileimg !== null ? `${docurlchat}${userDetails.profileimg_path}/${userDetails.profileimg}` : DefaultImage} alt="user" />
                            <label className='bd_main_update_profile_btn'>
                                Update Image
                                <input
                                    className='input_update_file'
                                    type="file"
                                    accept="image/*"
                                    onChange={handleImageChange}
                                />
                            </label>
                        </div>
                        <div className="line_through"></div>
                        <div className='bd_main_sub_info'>
                            {skeleton ?
                                <>

                                    <div className='sub_emp_id'>
                                        <Skeleton variant="rectangular" width={120} height={25} />
                                        <Skeleton variant="rectangular" width={100} height={25} />
                                    </div>
                                    <div className='sub_contact'>
                                        <p className='sub_pera'> <span className='sub_span'>Designation: </span> <Skeleton variant="rectangular" width={150} height={23} /></p>
                                        <p className='sub_pera'> <span className='sub_span'>Email:</span><Skeleton variant="rectangular" width={200} height={23} /></p>
                                        <p className='sub_pera'> <span className='sub_span'>Contact:</span><Skeleton variant="rectangular" width={200} height={23} /></p>
                                    </div>
                                </>
                                :
                                <>
                                    <div className='sub_emp_id'>
                                        <span className='sub_emp_head'>{userDetails.userfullname}</span>
                                        {/* <span className='sub_id'>{dropdownData?.role?.find(item => item?.role_id === userDetails?.role_id)?.role_name}</span> */}
                                    </div>
                                    <div className='sub_contact'>
                                        <p className='sub_pera'> <span className='sub_span'>Designation: </span>{dropdownData?.designation?.find(item => item?.id === userDetails?.designation_id)?.designation_name || 'Not Specified'}</p>
                                        <p className='sub_pera'> <span className='sub_span'>Email:</span> {userDetails?.email}</p>
                                        <p className='sub_pera'> <span className='sub_span'>Contact:</span>{userDetails?.contactnumber} </p>
                                    </div>
                                </>
                            }
                        </div>
                    </div>
                    <div className='bd_main_sub_add_details'>
                        {/* {skeleton ?
                            <>
                                <div className='add_details_headings'>
                                    <p className='add_details_p'>Company Details</p>
                                    <p className='add_details_p'><span className='add_details_span'>gst no:</span> <Skeleton variant="rectangular" width={100} height={25} /></p>
                                </div>
                                <div className='bd_main_sub_add_company'>
                                    <div className='bd_main_company_logo'>
                                        <Skeleton variant="rectangular" width={150} height={120} />
                                    </div>
                                    <div className='bd_main_sub_add_company_name'>
                                        <h3> <Skeleton variant="rectangular" width={220} height={25} /></h3>
                                        <p> <Skeleton variant="rectangular" width={220} height={25} /></p>
                                        <p>License No : <span>77-9083700</span></p>
                                    </div>
                                </div>
                                <div className="bd_main_subscription">
                                    <div className='start_date'>
                                        <span>Subscription Start Date</span>
                                        <p><Skeleton variant="rectangular" width={120} height={25} /></p>
                                    </div>
                                    <div className='end_date'>
                                        <span>Subscription End Date</span>
                                        <p><Skeleton variant="rectangular" width={120} height={25} /></p>
                                    </div>
                                    <div className='contact_person'>
                                        <span>Client Manager</span>
                                        <p><Skeleton variant="rectangular" width={200} height={25} /></p>
                                    </div>
                                </div>
                            </>

                            :
                            <>
                                <div className='add_details_headings'>
                                    <p className='add_details_p'>Company Details</p>
                                    <p className='add_details_p'>
                                        <span className='add_details_span'>gst no:</span>
                                        {userName?.gst}
                                    </p>
                                </div>
                                <div className='bd_main_sub_add_company'>
                                    <div className='bd_main_company_logo'>
                                        <img src={logo} alt='logo-company' />
                                    </div>
                                    <div className='bd_main_sub_add_company_name'>
                                        <h3>{personalInputData?.company?.map(item => item?.company_name)}</h3>
                                        <p>{userName?.full_address_1}</p>
                                        <p>License No : <span>77-9083700</span></p>
                                    </div>
                                </div>
                                <div className="bd_main_subscription">
                                    <div className='start_date'>
                                        <span>Subscription Start Date</span>
                                        <p>{userName?.sub_start_date}</p>
                                    </div>
                                    <div className='end_date'>
                                        <span>Subscription End Date</span>
                                        <p>{userName?.sub_end_date}</p>
                                    </div>
                                    <div className='contact_person'>
                                        <span>Client Manager</span>
                                        <p>{userName?.contact_person}</p>
                                    </div>
                                </div>
                            </>
                        } */}
                    </div>
                </div>

                <div className="storage_wrapper">
                    <div className="storage_stats">
                        <Progress percent={getProgressPercentage} showInfo={false} />
                        {/* <h5>3.68 GB of 15 GB used</h5> */}
                        <h5>{`${storageDetail?.UsedSpace} GB of ${storageDetail?.TotalLimit} GB used`}</h5>
                    </div>
                    <button className="BG_ghostButton upgrade_btn">Upgrade plan</button>
                </div>

                {/* <--------- tabs -------> */}
                <div className='bd_main_profile_tabs'>
                    <div className='profile_tabs_heading'>
                        <Tabs
                            defaultActiveKey="1"
                            items={[
                                {
                                    label: 'Official',
                                    key: '1',
                                    children: <div className='profile_detail_info_box'>
                                        <Form
                                            form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={userUpdateOfficial}
                                            layout="vertical"
                                        >
                                            <Row gutter={20}>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="First Name:" name="firstname" rules={[{ required: true, message: 'First name is required' }]}>
                                                        <Input
                                                            placeholder="Enter here"
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}
                                                            value={personalInputData?.firstname}
                                                            onChange={(e) => handleProfileChange('firstname', e)}
                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Last Name:" name='lastname' rules={[{ required: true, message: 'Last name is required' }]}>
                                                        <Input
                                                            value={personalInputData?.lastname}
                                                            placeholder="Enter here"
                                                            onChange={(e) => handleProfileChange('lastname', e)}
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}
                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Role:" name='role_id' rules={[{ required: true, message: 'Role is required' }]}>
                                                        <Select
                                                            placeholder="Select Role"
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}
                                                            onChange={(e) => handleInputChange('role_id', e)}
                                                            value={personalInputData?.role_id || ''}
                                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                            showSearch
                                                            optionFilterProp="children"
                                                            options={Object?.values(dropdownData?.role)?.map((item) => {
                                                                return {
                                                                    value: item?.id,
                                                                    label: item?.role_name
                                                                };
                                                            })}
                                                            filterOption={(input, option) =>
                                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                            }
                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Email :" name='email' rules={[{ required: true, message: 'Email is required' }]}>
                                                        <Input
                                                            value={personalInputData?.email}
                                                            placeholder="Enter here"
                                                            onChange={(e) => handleProfileChange('email', e)}
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}
                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24} >
                                                    <Form.Item label="Business Unit:" name='unit_id' rules={[{ required: true, message: 'Business Unit is required' }]}>
                                                        <Select
                                                            allowClear
                                                            placeholder="Select Business Unit"
                                                            onChange={(e) => handleInputChange('unit_id', e)}
                                                            value={personalInputData?.unit_id} suffixIcon={<Down theme="outline"
                                                                size="18" fill="#747474" />}
                                                            showSearch
                                                            optionFilterProp="children"
                                                            options={Object.values(dropdownData?.unit).map((item, index) => {
                                                                return {
                                                                    value: item?.id,
                                                                    label: item?.unit_name
                                                                }
                                                            })}
                                                            filterOption={(input, option) =>
                                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                            }
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}

                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Reporting Manager:" name='reporting_mngr_id' rules={[{ required: true, message: 'Reporting Manager is required' }]}>
                                                        <Select
                                                            allowClear
                                                            placeholder="Select Reporting Manager"
                                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                            showSearch
                                                            optionFilterProp="children"
                                                            options={dropdownData?.reporting_manager?.map((item, index) => ({
                                                                value: item?.id,
                                                                label: item?.userfullname
                                                            }))}
                                                            filterOption={(input, option) =>
                                                                option.label.toLowerCase().trim().indexOf(input.toLowerCase().trim()) >= 0
                                                            }
                                                            onChange={(e) => handleInputChange('reporting_mngr_id', e)}
                                                            value={personalInputData?.reporting_mngr_id}
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}

                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Company:" name='company_id' rules={[{ required: true, message: 'Company is required' }]}>
                                                        <Select
                                                            allowClear
                                                            placeholder="Select Company"
                                                            showSearch
                                                            optionFilterProp="children"
                                                            options={Object.values(dropdownData?.company)?.map((item, index) => {
                                                                return {
                                                                    value: item?.id,
                                                                    label: item?.company_name
                                                                }
                                                            })}
                                                            filterOption={(input, option) =>
                                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                            }
                                                            onChange={(e) => handleInputChange('company_id', e)}
                                                            value={personalInputData?.company_id}
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}

                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Department:" name='department_id' rules={[{ required: true, message: 'Department is required' }]}>
                                                        <Select
                                                            allowClear
                                                            placeholder="Select Department"
                                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                            showSearch
                                                            optionFilterProp="children"
                                                            options={Object.values(dropdownData?.department)?.map((item, index) => {
                                                                return {
                                                                    value: item?.id,
                                                                    label: item?.department_name
                                                                }
                                                            })}
                                                            filterOption={(input, option) =>
                                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                            }
                                                            onChange={(e) => handleInputChange('department_id', e)}
                                                            value={personalInputData?.department_id}
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}

                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Job Grade:" name='jobgrade_id' rules={[{ required: true, message: 'Job Grade is required' }]}>
                                                        <Select
                                                            allowClear
                                                            placeholder="Select Job Grade"
                                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                            showSearch
                                                            optionFilterProp="children"
                                                            options={Object.values(dropdownData?.jobgrid)?.map((item, index) => {
                                                                return {
                                                                    value: item?.id,
                                                                    label: item?.job_grade
                                                                }
                                                            })}
                                                            filterOption={(input, option) =>
                                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                            }
                                                            onChange={(e) => handleInputChange('jobgrade_id', e)}
                                                            value={personalInputData?.jobgrade_id}
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}

                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Designation:" name='designation_id' rules={[{ required: true, message: 'Designation is required' }]}>
                                                        <Select
                                                            placeholder="Select Designation"
                                                            showSearch
                                                            optionFilterProp="children"
                                                            options={Object.values(dropdownData?.designation)?.map((item, index) => {
                                                                return {
                                                                    value: item?.id,
                                                                    label: item?.designation_name
                                                                }
                                                            })}
                                                            filterOption={(input, option) =>
                                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                            }
                                                            onChange={(e) => handleInputChange('designation_id', e)}
                                                            value={personalInputData?.designation_id}
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}

                                                        />
                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Employee Status" name='isactive' rules={[{ required: true, message: 'Reporting Manager is required' }]}>
                                                        <Select
                                                            onChange={(e) => handleInputChange('isactive', e)}
                                                            value={personalInputData?.isactive}
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}
                                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                            options={[
                                                                { value: 1, label: 'Active' },
                                                                { value: 2, label: 'Inactive' },
                                                            ]}
                                                        />

                                                    </Form.Item>
                                                </Col>
                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="Contact Number:" name='contactnumber' rules={[{ required: true, message: 'Contact Number is required' }, { validator: validateContactNumber, }]}>
                                                        <Input
                                                            placeholder="Enter here"
                                                            type='number'
                                                            onChange={(e) => handleProfileChange('contactnumber', e)}
                                                            value={personalInputData?.contactnumber}
                                                            disabled={isPersonal && userDetails?.permanent_sys_adm !== '1'}

                                                        />
                                                    </Form.Item>
                                                </Col>

                                                <Col sm={12} md={6} xs={24}>
                                                    <Form.Item label="System Admin">
                                                        <Input value={userDetails?.bg_mstr_role?.role_name === 'System Admin' ? 'Yes' : 'No'} disabled={true} />
                                                    </Form.Item>
                                                </Col>

                                            </Row>
                                            {((isPersonal && userDetails?.permanent_sys_adm === '1') || !isPersonal) && <div className='profile_button_sec'>
                                                <Button className='BG_ghostButton' onClick={handleResetOfficial}>Reset</Button>
                                                {/* <Button className='BG_mainBtton'>Save & Change</Button> */}
                                                <button className='BG_mainButton' key="submit" >Save & Change</button>

                                            </div>}
                                        </Form>
                                    </div>,
                                },
                                {
                                    label: 'Personal',
                                    key: '2',
                                    children: <div className='profile_detail_info_box'>
                                        <div className='profile_sub_info'>
                                            <Form
                                                form={formdata} name="control-hooks" layout="vertical" autoComplete="off" onFinish={userUpdatePersonal}
                                            >
                                                <Row gutter={20}>
                                                    <Col sm={12} md={6} xs={24}>
                                                        <Form.Item label="DOB"
                                                            allowClear
                                                            name='date_of_birth'
                                                            rules={[{ required: true, message: 'DOB is required' }]}>
                                                            <DatePicker
                                                                placeholder="Date of birth"
                                                                value={personalInputData?.date_of_birth}
                                                                onChange={(value) => handleInputChange('date_of_birth', value)}
                                                                disabledDate={disabledDate}
                                                            />
                                                        </Form.Item>
                                                    </Col>

                                                    <Col sm={12} md={6} xs={24}>
                                                        <Form.Item
                                                            allowClear
                                                            label="Country"
                                                            rules={[{ required: true, message: 'Country is required' }]}
                                                            name='country_id'
                                                        >
                                                            <Select
                                                                allowClear
                                                                showSearch
                                                                value={personalInputData?.country_id}
                                                                onChange={(value) => handleInputChange('country_id', value)}
                                                                placeholder="Select Country"
                                                                options={BidCountry?.map((item, index) => {
                                                                    return {
                                                                        value: item?.id,
                                                                        label: item?.country_name
                                                                    }
                                                                })}
                                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                                filterOption={(input, option) =>
                                                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                                }
                                                            />
                                                        </Form.Item>
                                                    </Col>

                                                    <Col sm={12} md={6} xs={24}>
                                                        <Form.Item label="State "
                                                            rules={[{ required: true, message: 'State is required' }]}
                                                            name='state_id'
                                                        >
                                                            <Select
                                                                allowClear
                                                                showSearch
                                                                value={personalInputData.state_id}
                                                                onChange={(value) => handleInputChange('state_id', value)}
                                                                options={profileState?.map((item, index) => {
                                                                    return {
                                                                        value: item?.id,
                                                                        label: item?.state_name
                                                                    }
                                                                })}
                                                                placeholder="Select State"
                                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                                filterOption={(input, option) =>
                                                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                                }
                                                            >
                                                            </Select>
                                                        </Form.Item>
                                                    </Col>

                                                    <Col sm={12} md={6} xs={24}>
                                                        <Form.Item label="City / District"
                                                            rules={[{ required: true, message: 'City is required' }]}
                                                            name='city_id'
                                                        >
                                                            <Select
                                                                allowClear
                                                                showSearch
                                                                value={personalInputData.city_id}
                                                                onChange={(value) => handleInputChange('city_id', value)}
                                                                options={profileCity?.map((item, index) => {
                                                                    return {
                                                                        value: item?.id,
                                                                        label: item?.city_name
                                                                    }
                                                                })}
                                                                // name='city_id'
                                                                placeholder="Select City"
                                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                                filterOption={(input, option) =>
                                                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                                }
                                                            />

                                                        </Form.Item>
                                                    </Col>

                                                    <Col sm={12} md={6} xs={24}>
                                                        <Form.Item label="Zip Code"
                                                            name='zip_code'
                                                            rules={[
                                                                { required: true, message: 'Zip Code is required' },
                                                                {
                                                                    min: 6,
                                                                    message: 'Zip Code must be at least 6 characters long'
                                                                },

                                                            ]}
                                                        >
                                                            <Input
                                                                // name='zip_code'
                                                                placeholder="Zip Code"
                                                                value={personalInputData?.zip_code}
                                                                onChange={(e) => handleInputChange('zip_code', e.target.value)}
                                                                onKeyPress={(e) => {
                                                                    // Prevent the default action for non-numeric keys
                                                                    if (isNaN(Number(e?.key))) {
                                                                        e.preventDefault();
                                                                    }

                                                                    // Prevent entering more than 6 digits
                                                                    const { value } = e?.target;
                                                                    if (value?.length >= 6) {
                                                                        e.preventDefault();
                                                                    }
                                                                }}
                                                            />
                                                        </Form.Item>
                                                    </Col>

                                                    <Col sm={12} md={6} xs={24}>
                                                        <Form.Item label="Full Address"
                                                            rules={[{ required: true, message: 'Address is required' }]}
                                                            name='full_address_1'
                                                        >
                                                            <TextArea
                                                                // name='full_address_1'
                                                                placeholder="Full address"
                                                                value={personalInputData?.full_address_1}
                                                                onChange={(e) => handleInputChange('full_address_1', e.target.value)}
                                                            />
                                                        </Form.Item>
                                                    </Col>
                                                </Row >
                                                <div className='profile_button_sec'>
                                                    <Button className='BG_ghostButton' onClick={handleResetPersonal}>Reset</Button>
                                                    <button className='BG_mainButton' >Save & Change</button>
                                                </div>
                                            </Form >
                                        </div >

                                    </div >
                                },
                                {
                                    label: isPersonal && 'Change Password',
                                    key: '3',
                                    children: isPersonal &&
                                        <PasswordChangeBids
                                            form={form}
                                            personalInputData={personalInputData}
                                            handleInputChange={handleInputChange}
                                            handleReset={handleResetOfficial}
                                            postPasswordChange={postPasswordChange}
                                            setPersonalInputData={setPersonalInputData}
                                        />

                                },


                            ]}
                        />
                    </div>
                </div>
            </div>

        </>
    )
}

export default CustomProfile