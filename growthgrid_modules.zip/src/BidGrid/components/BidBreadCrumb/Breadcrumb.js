// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import ArrowForwardIosOutlinedIcon from '@mui/icons-material/ArrowForwardIosOutlined';
import { useDispatch } from 'react-redux';
import ROUTES from '../../../Constants/Routes';

import { Home, Right } from '@icon-park/react';

const Breadcrumb = ({ data }) => {

  const [isActive, setIsActive] = useState(false);
  const [bread, setBread] = useState('')
  const navigate = useNavigate()
  const handleNavigate = () => {

    navigate(ROUTES.DASHBOARD)
  }


  useEffect(() => {
    // if (data !== 'bidgrid/request') {
    //   const parts = data.split('/');
    //   const decodedParts = parts.map(part => decodeURIComponent(part.trim()));
    //   const reconstructedString = decodedParts.join('/');
    //   setBread(reconstructedString)
    // } else {
    const parts = data.split('/');
    if (parts?.length > 2) {
      const lastData = Number(parts[parts.length - 1])
      if (isNaN(lastData)) {
        const decodedParts = parts?.map(part => decodeURIComponent(part.trim()))[2];
        setBread(decodedParts?.charAt(0)?.toUpperCase() + decodedParts?.slice(1))
      } else {
        const decodedParts = parts[parts?.length - 2];
        setBread(decodedParts?.charAt(0)?.toUpperCase() + decodedParts?.slice(1))
      }

    } else {
      const decodedParts = parts?.map(part => decodeURIComponent(part.trim()))[1];
      setBread(decodedParts?.charAt(0)?.toUpperCase() + decodedParts?.slice(1))
    }

    // }

  }, [data])

  return (
    <>
      <ul className={isActive ? "breadcrumb remove-static-cls " : "breadcrumb"} >
        <li onClick={handleNavigate}><Home theme="outline" size="20" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" /></li>
        <Right theme="outline" size="22" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
        <li onClick={handleNavigate} className='active'>{bread}</li>
      </ul>
    </>
  );
};

export default Breadcrumb;
