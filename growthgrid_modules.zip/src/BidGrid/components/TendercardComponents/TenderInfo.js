// @ts-nocheck
import React, { useState } from 'react';
import { Checkbox, Select } from 'antd';
import Loaction from '../../assets/images/icons/location.png';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import { Down, Download } from '@icon-park/react';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import dayjs from "dayjs";
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import ROUTES from 'Constants/Routes';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import spinGif from '../../assets/images/spin.gif';
import { docAuth, docurlchat } from 'utils/configurable';
import MoveConfirmationModal from '../MISModal/MoveConfirmationmodal';
import { FALSE } from 'sass';
import { TimeConverter } from '../TimeConverter/TimeConverter';


const TenderInfo = (props) => {
    const { setChecked, item, index, skeleton, setSelectedItems, selectedItems,
        getTenders, singleDropDownList, setGenTenderId, handleSubmitTender,
        scopeAllData, dropdownSpinner, setCycleId, commonFilter, getServiceProvider } = props

    const { filterValues } = useSelector((state => state.cycleFilter));
    const { misFilterValues } = useSelector(state => state.misFilter);
    const [statusChange, setStatusChange] = useState();
    const [confirmationModal, setConfirmationModal] = useState(false);

    const AllScope = scopeAllData?.find((itm) => commonFilter == "CYCLE" ? Object?.keys(itm) == item?.cycle_id : Object?.keys(itm) == item?.bg_tenders_status_manage?.tender_status)
    const AllScopeArr = AllScope != null && AllScope != undefined && Object?.values(AllScope)

    const onChangeStatus = async (e) => {
        const id = commonFilter == "TRASH" ? item?.bg_tender_id : item?.id
        commonFilter != "TRASH" && setCycleId(e)
        commonFilter != "TRASH" && setGenTenderId(item?.id)
        setStatusChange(e);
        commonFilter == "MIS" && setConfirmationModal(true)
        commonFilter != "MIS" && handleSubmitTender(e, id, setStatusChange, item)
    };

    const handleCheckBox = (e) => {
        let isSelected = e.target.checked;
        let value = parseInt(e.target.value);
        if (isSelected) {
            setSelectedItems([...selectedItems, value]);
            if (selectedItems.length + 1 === getTenders?.length) {
                setChecked(true);
            }
        } else {
            setSelectedItems((prev) => prev.filter((id) => id !== value));
            setChecked(false);
        }
    }

    // const handleDownloadDoc = (item) => {
    //     console.log(item, "item");

    //     const apiUrl = `${item?.tender_docs?.tender_category == 1 ? docurlchat : docAuth}${item?.tender_docs?.doc_path}/${item?.tender_docs?.file_name}`;
    //     // const apiUrl = `${docAuth}${item?.file_doc_path ? item?.file_doc_path : item?.doc_path}/${item?.file_doc_name ? item?.file_doc_name : item?.document_name}`;

    //     const alink = document.createElement("a");
    //     alink.href = apiUrl;
    //     alink.download = item.id + "_" + (item?.tender_docs?.file_name);
    //     console.log(alink.download, "alink.download");
    //     document.body.appendChild(alink); // Append to body to make the link clickable
    //     alink.click();
    //     document.body.removeChild(alink); // Remove the link after clicking

    // };

    const handleDownloadDoc = (item) => {
        console.log(item, "item");

        const apiUrl = `${item?.tender_docs?.tender_category == 1 ? docurlchat : docAuth}${item?.tender_docs?.doc_path}/${item?.tender_docs?.file_name}`;

        // Open the file in a new tab
        const newTab = window.open(apiUrl, '_blank');
        if (newTab) {
            newTab.focus();
        } else {
            console.error("Failed to open new tab. Please check popup blocker settings.");
        }
    };


    const tenderNames = (str) => {
        const htmlTagPattern = /<[^>]*>/g;
        const htmlTags = str?.match(htmlTagPattern);
        if (htmlTags) {
            const stringWithoutHtmlTags = str.replace(htmlTagPattern, '');
            const capitalizedString = capitalizeExceptPrepositionsAndLowerCase(stringWithoutHtmlTags);
            return <span>{capitalizedString}</span>;
        } else {
            return <span>{capitalizeExceptPrepositionsAndLowerCase(str)}</span>;
        }
    }

    const showStatusColor = (scopeOrderSerial) => {
        switch (scopeOrderSerial) {
            case 1:
                return "one"

            case 2:
                return "two"

            case 3:
                return "three"

            case 4:
                return "four"

            case 5:
                return "five"

            case 6:
                return "six"

            case 7:
                return "seven"

            case 8:
                return "eight"

            default:
                break;
        }
    }
    return (
        <>
            <>
                {!skeleton ?
                    <>
                        <div className='bd_tenderCard_first' key={index}>
                            <div className="bd_cards_tender">
                                <div className='bd_cards_active'>
                                    {(commonFilter == "CYCLE" ? filterValues?.cycle_id == 0 : commonFilter == "MIS" ? misFilterValues?.orderSerial == "8" || misFilterValues?.orderSerial > 9 : commonFilter != "TRASH") ? <span style={{ color: "#636363" }}>{item?.bg_mstr_client?.client_name}</span> : <Checkbox checked={selectedItems?.includes(commonFilter == "TRASH" ? item.bg_tender_id : item?.id)} disabled={commonFilter == "CYCLE" ? item?.bg_assign_tndr_generated_id == null ? false : true : false} onChange={handleCheckBox} value={commonFilter == "TRASH" ? item.bg_tender_id : item.id} style={{ display: (commonFilter == "CYCLE" ? filterValues?.cycle_id == 0 : commonFilter == "MIS" ? misFilterValues?.orderSerial == "8" || misFilterValues?.orderSerial > 9 : commonFilter != "TRASH") ? "none" : "flex" }}> {item?.bg_mstr_client?.client_name} </Checkbox>}
                                    <div className={`bd_active_btn_sec ${showStatusColor(item?.bg_mstr_tndr_cycle?.order_sr)}`}>
                                        {!dropdownSpinner[item?.id] ? <div className={`status_select ${statusChange}`}>
                                            <Select
                                                defaultValue={commonFilter == "CYCLE" ? item?.bg_mstr_tndr_cycle?.cycle_name : commonFilter == "TRASH" ? "Trash" : item?.bg_tenders_status_manage?.bg_mstr_tndr_status?.status_name}
                                                value={commonFilter == "CYCLE" ? item?.bg_mstr_tndr_cycle?.cycle_name : item?.bg_tenders_status_manage?.bg_mstr_tndr_status?.status_name}
                                                onChange={onChangeStatus}
                                                // disabled={selectedItems.length > 0 ? true : false}
                                                disabled={commonFilter == "MIS" ? misFilterValues?.orderSerial == 9 ? selectedItems.length > 0 ? true : false : misFilterValues?.orderSerial == 8 ? AllScopeArr[0]?.[0]?.order_sr > 10 || AllScopeArr[0]?.[0] == null : true : selectedItems.length > 0 ? true : false}
                                                // disabled={commonFilter == "MIS" ? misFilterValues?.orderSerial == 9 ? false : misFilterValues?.orderSerial == 8 ? AllScopeArr[0]?.[0]?.order_sr == 10 || AllScopeArr[0]?.[0]?.order_sr > 10 ? true : false : false : false}
                                                suffixIcon={<Down theme="outline" size="18" fill="#78889b" />}
                                                options={(commonFilter == "CYCLE" ? filterValues?.cycle_id != 0 : commonFilter == "MIS" ? misFilterValues?.orderSerial != '8' : commonFilter == "TRASH") ? singleDropDownList?.map((item) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.cycle_name
                                                    }
                                                }) :
                                                    AllScopeArr[0]?.map((item) => {
                                                        return {
                                                            value: item?.id,
                                                            label: item?.cycle_name
                                                        }
                                                    })
                                                }
                                            />
                                        </div> : <img src={spinGif} width={30} />}
                                    </div>
                                </div>
                                <div className='bd_tender_card_location'>
                                    <img src={Loaction} width={13} alt='' />
                                    <span>
                                        {capitalizeExceptPrepositionsAndLowerCase(item?.bg_mstr_city?.city_name)}
                                        {item?.bg_mstr_city !== null && ","}
                                        {capitalizeExceptPrepositionsAndLowerCase(item?.bg_mstr_state?.state_name)}
                                        {item?.bg_mstr_state !== null && ","}
                                        {capitalizeExceptPrepositionsAndLowerCase(item?.bg_mstr_country?.country_name)}
                                    </span>
                                </div>
                            </div>
                            <div className='bd_tender_card_chips'>
                                <div className='bd_tender_chips'>
                                    <span>
                                        {capitalizeExceptPrepositionsAndLowerCase(item.bg_mstr_sector?.sector_name)}
                                    </span>
                                </div>
                            </div>
                            <div className='bd_tender_card_detail'>
                                <Link to={ROUTES.BD_TENDERDETAILS.replace(':id', commonFilter == "TRASH" ? item?.bg_tender_id : item?.id)} >
                                    {tenderNames(item?.tender_name)}
                                </Link>
                            </div>
                            <div>
                                {
                                    getServiceProvider?.filter((itm) => itm?.source_val == item?.source_id)?.map((item) => {
                                        return (
                                            <>
                                                <img src={`${docurlchat}uploads/service_provider_img/${item?.image_name}`} />
                                                <p>{item?.provider_name}</p>
                                            </>
                                        )
                                    })
                                }

                            </div>
                            <div className='bd_tender_card_expire'>
                                <EventBusyIcon />
                                <p>Expires on</p>
                                <span>
                                    {
                                        item.submission_end_date !== null ?
                                            `${dayjs(item.submission_end_date).subtract(dayjs(item?.submission_end_date).utcOffset(), 'minute').format("DD MMM YYYY")}  ${TimeConverter(item?.submission_end_date)}` : '-'
                                    }
                                </span>
                                <div className="blinkText">{item?.is_corri_update > 0 ? "New Update" : ""}</div>
                            </div>

                            <div className="additnal_info">
                                {item?.bg_assign_tndr_generated_id === null ? "" :
                                    <div className="textInfo"><span>Generate Id:</span>{item?.bg_assign_tndr_generated_id?.generated_tender_id}</div>
                                }
                                {item?.assign_tender === [] ? "" : item?.assign_tender?.map((item) => {

                                    return <div className="textInfo">
                                        <div className="textInfo">
                                            <span>{item?.bg_mstr_bd_role?.role_name}: </span>
                                            {item?.user?.userfullname}
                                        </div>
                                    </div>

                                })
                                }
                            </div>
                           
                                {
                                    item?.tender_docs !== null ?
                                    <div className="doc__info">
                                            <p> Doc :</p><a onClick={() => handleDownloadDoc(item)} href={null} download={item?.tender_docs?.file_name} target="_blank" > {item?.tender_docs?.file_name}</a>
                                            <Download theme="outline" size="18" fill="#684fd8" strokeWidth={3} strokeLinecap="butt" />
                                            {/* <p> Doc :</p><a href={`${item?.tender_docs?.tender_category == 1 ? docurlchat : docAuth}${item?.tender_docs?.doc_path}/${item?.tender_docs?.file_name}`} download={`${item?.tender_docs?.tender_category == 1 ? docurlchat : docAuth}${item?.tender_docs?.doc_path}/${item?.tender_docs?.file_name}`} target="_blank" > {item?.tender_docs?.file_name}</a>
                                            <Download theme="outline" size="18" fill="#684fd8" strokeWidth={3} strokeLinecap="butt" /> */}
                                        </div>
                                        : ""
                                }
                            {/* </div> */}
                        </div>

                    </>
                    :
                    <>
                        <div className='bd_tenderCard_first' key={index}>
                            <div className="bd_cards_tender">
                                <div className='bd_cards_active'>
                                    <Checkbox checked={false}>
                                        <Skeleton width={300} height={30} />
                                    </Checkbox>
                                    <div className="bd_active_btn_sec">
                                        <div>

                                            <Skeleton width={100} height={30} />
                                        </div>
                                    </div>
                                </div>
                                <div className='bd_tender_card_location'>
                                    <Skeleton width={100} height={30} />
                                </div>
                            </div>
                            <div className='bd_tender_card_chips'>
                                <div className='bd_tender_chips'>
                                    <Skeleton width={100} height={30} />
                                </div>
                            </div>
                            <div className='bd_tender_card_detail'>
                                <Skeleton width={500} height={30} />
                            </div>
                            <div className='bd_tender_card_expire'>
                                <Skeleton width={100} height={30} />
                            </div>
                        </div>
                    </>

                }
            </>
            <MoveConfirmationModal
                confirmationModal={confirmationModal}
                item={item} statusChange={statusChange}
                setConfirmationModal={setConfirmationModal}
                handleSubmitTender={handleSubmitTender}
                move={"SINGLE"}
                singleDropDownList={singleDropDownList}
            />
        </>

    )
}

export default TenderInfo