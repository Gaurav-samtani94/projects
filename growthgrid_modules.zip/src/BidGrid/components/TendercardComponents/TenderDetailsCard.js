// @ts-nocheck
import React, { useEffect, useState } from 'react';
import 'react-loading-skeleton/dist/skeleton.css'
import { Select } from 'antd';
import { Down } from '@icon-park/react';
import TenderInfo from './TenderInfo';
import TenderDetailComment from './TenderDetailComment';
import TenderDetailAction from './TenderDetailAction';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { Pagination } from 'antd';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import EmptyBox from '../../../assests/img/empty-box.png';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import { filterCycleActions } from 'Redux/actions/bidgrid/cycleFilterAction';
import { MisApi } from 'Services/bidgrid/tenderList/MIsApi';
import { misFilterActions } from 'Redux/actions/bidgrid/misFilterAction';
import { trashFilterAction } from 'Redux/actions/bidgrid/trashFilterAction';

const TenderDetailsCard = (props) => {

    const { skeleton, getAllTenders, setChecked, getTenders, setSelectedItems, selectedItems, setTenders, singleDropDownList,
        actionData, setGenerateNumOpen, handleSubmitTender, handleMoveTenderToAnotherScope, getActionInAll, scopeAllData,
        requestList, setGenTenderId, fetchRequestListForDrawer, userListData, setRoleOpen, setBidRoleOpen, getActionListApi, dropdownSpinner, setCycleId,
        setInActionPopup, tenderCount, commonFilter, inActionBtnList, page_Num, limit, cycleId, getServiceProvider } = props

    const { filterValues } = useSelector((state) => state.cycleFilter)
    const dispatch = useDispatch();
    const [getActionsList, setActionsList] = useState([]);
    const { Option } = Select;

    const handlePageChange = (page, pageSize) => {
        const obj = {
            limit: pageSize,
            page_number: page,
        }
        commonFilter == "CYCLE" ? dispatch(filterCycleActions?.filterUpdateIndividualKeys(obj)) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterUpdateIndividualKeys(obj)) : dispatch(trashFilterAction?.trashFilterUpdateIndividualKeys(obj))
    };
    const dummyArr = Array.from({ length: filterValues?.limit })

    const handlePageSizeChange = (value) => {
        const obj = {
            limit: value,
            page_number: 1,
        }
        commonFilter == "CYCLE" ? dispatch(filterCycleActions?.filterUpdateIndividualKeys(obj)) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterUpdateIndividualKeys(obj)) : dispatch(trashFilterAction?.trashFilterUpdateIndividualKeys(obj))
    }

    const getActionsBtnLIst = async () => {
        const formData = new URLSearchParams();
        formData.append('scope_id', Number(cycleId));
        let result = commonFilter == "CYCLE" ? await TenderApi.getTenderCycleInactionBtnList(formData) : await MisApi?.getMisInActionBtnList(formData);
        setActionsList(result?.data?.data)
    }

    useEffect(() => {
        getActionsBtnLIst();
    }, [cycleId])


    const showStatusColor = (cycleId) => {
        switch (cycleId) {
            case 1:
                return "one"

            case 2:
                return "two"

            case 3:
                return "three"

            case 4:
                return "four"

            case 5:
                return "five"

            case 6:
                return "six"

            case 7:
                return "seven"

            case 8:
                return "eight"

            default:
                break;
        }

    }

    return (
        <>
            {skeleton &&
                <>
                    {dummyArr?.map(() => {
                        return (
                            <div className='bd_tenderCard'>

                                <div className={`card`}>
                                    <TenderInfo
                                        skeleton={skeleton}
                                    />

                                    <TenderDetailComment
                                        skeleton={skeleton}

                                    />

                                    <TenderDetailAction
                                        skeleton={skeleton}
                                    />
                                </div>
                            </div>
                        )
                    })}

                </>
            }
            {!skeleton &&
                <>
                    {getTenders?.length > 0 ?
                        <>
                            {
                                getTenders?.map((item, index) => {
                                    return (
                                        <>
                                            <div className='bd_tenderCard'>

                                                <div className={`card ${showStatusColor(item?.bg_mstr_tndr_cycle?.order_sr)}`}>
                                                    <TenderInfo
                                                        setChecked={setChecked}
                                                        item={item}
                                                        index={index}
                                                        skeleton={skeleton}
                                                        setSelectedItems={setSelectedItems}
                                                        selectedItems={selectedItems}
                                                        getTenders={getTenders}
                                                        singleDropDownList={singleDropDownList}
                                                        setGenTenderId={setGenTenderId}
                                                        handleSubmitTender={handleSubmitTender}
                                                        scopeAllData={scopeAllData}
                                                        setCycleId={setCycleId}
                                                        dropdownSpinner={dropdownSpinner}
                                                        commonFilter={commonFilter}
                                                        getServiceProvider={getServiceProvider}
                                                    />

                                                    {commonFilter != "TRASH" && <TenderDetailComment
                                                        item={item}
                                                        requestList={requestList}
                                                        fetchRequestListForDrawer={fetchRequestListForDrawer}
                                                        actionData={actionData} userListData={userListData}
                                                        getActionListApi={getActionListApi}
                                                        skeleton={skeleton}
                                                        commonFilter={commonFilter}
                                                    />}

                                                    {commonFilter != "TRASH" && <TenderDetailAction
                                                        item={item}
                                                        getActionsList={commonFilter == "TRASH" ? inActionBtnList : getActionsList}
                                                        getTenders={getTenders}
                                                        setTenders={setTenders}
                                                        setGenerateNumOpen={setGenerateNumOpen}
                                                        setGenTenderId={setGenTenderId}
                                                        handleMoveTenderToAnotherScope={handleMoveTenderToAnotherScope}
                                                        actionData={actionData}
                                                        getActionInAll={getActionInAll}
                                                        setRoleOpen={setRoleOpen}
                                                        setBidRoleOpen={setBidRoleOpen}
                                                        getActionListApi={getActionListApi}
                                                        skeleton={skeleton}
                                                        // setCycleId={setCycleId}
                                                        setInActionPopup={setInActionPopup}
                                                        getAllTenders={getAllTenders}
                                                        commonFilter={commonFilter}
                                                    />}
                                                </div>
                                            </div>
                                        </>
                                    )

                                })
                            }
                            {getTenders?.length > 0 && <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 20, marginInline: 30 }}>
                                <Pagination
                                    current={page_Num}
                                    pageSize={limit}
                                    total={tenderCount?.totalItems}
                                    onChange={handlePageChange}
                                />
                                <div>
                                    <span>Showing</span>
                                    <Select
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        defaultValue={limit}
                                        style={{ width: 80, textAlign: "center" }}
                                        onChange={handlePageSizeChange}
                                    >
                                        <Option value={25}>25</Option>
                                        <Option value={50}>50</Option>
                                        <Option value={75}>75</Option>
                                        <Option value={100}>100</Option>
                                        <Option value={150}>150</Option>
                                        {commonFilter == "CYCLE" && filterValues?.orderSerial > '5' ? <Option value={1000}>ALL</Option> : ''}
                                    </Select>
                                </div>

                            </div>
                            }
                        </>
                        :
                        <>
                            <div className="spinerWrap">
                                <div className="data_foundDiv">
                                    <img src={EmptyBox} width={100} />
                                    <div style={{ textAlign: "center", fontSize: 16 }}>No Record Found</div>
                                </div>
                            </div>
                        </>

                    }
                </>
            }


        </>
    )
}

export default TenderDetailsCard;