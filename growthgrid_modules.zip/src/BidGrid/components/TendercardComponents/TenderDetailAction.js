// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Tooltip, Drawer, Modal } from 'antd';
import Link from '@mui/material/Link';
import TenderWishListModal from '../TenderCycleActionModal/TenderWishListModal';
import TenderRemainderModal from '../TenderCycleActionModal/TenderRemainderModal';
import TenderSubmitModal from '../TenderCycleActionModal/TenderSubmitModal';
import TenderDeleteModal from '../TenderCycleActionModal/TenderDeleteModal';
import TenderStatusModal from '../TenderCycleActionModal/TenderStatusModal';
import { useSelector } from 'react-redux';
import skipBack from "../../assets/images/skip-back.png"
import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
import { Bookmark, RemindDisable } from '@icon-park/react';
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'
import { toast } from 'react-toastify';
import { docurlchat } from 'utils/configurable';

const TenderDetailAction = (props) => {
    const { item, getActionsList, getTenders, setTenders, setGenerateNumOpen, setGenTenderId,
        handleMoveTenderToAnotherScope, actionData, getActionInAll, setRoleOpen, setBidRoleOpen,
        getActionListApi, skeleton, setInActionPopup, getAllTenders, commonFilter } = props

    const { misFilterValues } = useSelector((state => state.misFilter))
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [remind, setReminOpen] = useState(false);
    const [submitOpen, setSubmitOpen] = useState(false);
    const [deleteOpen, setdeleteOpen] = useState(false);
    const [tenderStatusOpen, setTenderStatusOpen] = useState(false);
    const [linkOpen, setLinkOpen] = useState(false)
    const [wishlistRemove, setWishlistRemove] = useState(false)
    const [reminderRemove, setReminderRemove] = useState(false)
    const path = `${docurlchat}uploads/inaction_image/item/${item?.bg_mstr_tndr_cycle_inact9ion?.image_name}`;
    const { filterValues } = useSelector((state => state.cycleFilter));
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const handleCancel = () => {
        setIsModalOpen(false);
    };

    const handleRemindCancel = () => {
        setReminOpen(false);
    };
    const handleCloseDrawer = (itemUrl) => {
        setLinkOpen(false)
        const iframe = document.getElementById('drawer_ifrm');
        if (iframe) {
            iframe.src = itemUrl;
        }
    }

    const handleSubmitCancel = () => {
        setSubmitOpen(false);
    };

    const tenderStatus = () => {
        setTenderStatusOpen(false)
    }

    let unitTenderIdForWishlist = actionData?.wishlist_tender?.find((itm) => itm?.tender_id === item?.id);
    let unitTenderIdForReminder = actionData?.reminder_tender?.find((itm) => itm?.tender_id === item?.id);
    let actionBtnForAll = getActionInAll?.filter((itm) => itm?.cycle_id == item?.cycle_id)

    const handleCallAction = (name, itm) => {
        switch (name) {
            case "Set Tender Generated ID": {
                if (item?.bg_assign_tndr_generated_id == null) {
                    setGenerateNumOpen()
                    setGenTenderId(item?.id)
                    setInActionPopup(true)
                }
                break;
            }
            case "Move": {
                handleMoveTenderToAnotherScope(item?.id, "Move");
                break;
            }
            case "Add Wishlist": {
                setIsModalOpen(true)
                break;
            }
            case "Add Reminder": {
                setReminOpen(true)
                break;
            }
            case "Move To Trash": {
                setdeleteOpen(true)
                break;
            }
            case "view Link": {
                setLinkOpen(true)
                break;
            }
            case "Set Key Client Manager": {
                if (item?.assign_tender?.every((ite) => ite?.bg_mstr_bd_role?.role_name != "Key Client Manager")) {
                    setBidRoleOpen(true)
                    setGenTenderId(item?.id)
                    setInActionPopup(true)
                }
                break;
            }
            case "Set Bid Manager": {
                if (item?.assign_tender?.every((ite) => ite?.bg_mstr_bd_role?.role_name != "Bid Manager")) {
                    setRoleOpen(true)
                    setGenTenderId(item?.id)
                    setInActionPopup(true)
                }
                break;
            }
            default: {
                console.log("not match")
                break;
            }
        }
    }

    const handleRemoveWhishlist = async () => {
        const formData = new URLSearchParams();
        formData.append('tender_id', item?.id);
        try {
            let result = await tenderCycle.removeFromWhishlist(formData);
            if (result?.data?.status === '1') {
                setWishlistRemove(false);
                notifySuccess(result?.data?.message);
                getActionListApi();
            }
            else {
                notify(result?.response?.data?.message);
            }
        } catch (error) {
            console.log(error)
        }

    }
    const handleRemoveReminder = async () => {
        const formData = new URLSearchParams();
        formData.append('tender_id', item?.id);
        let result = await tenderCycle.removeFromReminder(formData);
        if (result?.data?.status === '1') {
            setReminderRemove(false);
            notifySuccess(result?.data?.message);
            getActionListApi();
        }
        else {
            notify(result?.data?.message);

        }
    }

    const showModalForRemoveWhishList = () => {
        return (

            <Modal
                className="bd_delete_model"
                open={wishlistRemove}
                onCancel={() => setWishlistRemove(false)}
                footer={[
                    <button className='BG_ghostButton' key="cancel" onClick={() => setWishlistRemove(false)} >
                        Cancel
                    </button>,
                    <button className='BG_deleteButton' key="delete"
                        onClick={handleRemoveWhishlist}
                    >
                        Remove
                    </button>
                ]}
            >
                <div className='bd_delete_container'>
                    <span className='bd_delete_spn'>Are you sure you</span>
                    <p>Want to remove this from wishlist ?</p>
                </div>
            </Modal>
        )
    }
    const showModalForRemoveReminder = () => {
        return (
            <Modal
                className="bd_delete_model"
                open={reminderRemove}
                //  onCancel={handleDelete}
                footer={[
                    <button className='BG_ghostButton' key="cancel" onClick={() => setReminderRemove(false)} >
                        Cancel
                    </button>,
                    <button className='BG_deleteButton' key="delete"
                        onClick={handleRemoveReminder}
                    >
                        Delete
                    </button>
                ]}
            >
                <div className='bd_delete_container'>
                    <span className='bd_delete_spn'>Are you sure you</span>
                    <p>Want to remove this tender from reminder ?</p>
                </div>
            </Modal>
        )
    }

    // console.log(item, "item")
    return (
        <>
            {
                (commonFilter == "CYCLE" ? filterValues?.cycle_id != 0 : commonFilter == "MIS" ? misFilterValues?.orderSerial != 8 : commonFilter == "DETAIL" ? commonFilter == "DETAIL" : commonFilter == "TRASH") ?
                    <div className='d-flex gap-4 bd_tenderCrd_thrd' >
                        {/* {
                            getActionsList?.filter((actionItem) => actionItem?.bg_mstr_tndr_cycle_inaction != null)?.map((itm, index) => {
                                return (
                                    !skeleton ?
                                        <Link className={unitTenderIdForWishlist?.tender_id ? "import_export_data" : 'import_export'} >
                                            {
                                                itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'view Link' && item?.tnd_url === null ?
                                                    <></>
                                                    :
                                                    itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Wishlist' && unitTenderIdForWishlist?.tender_id ? <Tooltip title='Remove wishlist' > <Bookmark theme="filled" size="24" fill="#FF7835" onClick={() => setWishlistRemove(true)} /> </Tooltip>
                                                        :
                                                        itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Reminder' && unitTenderIdForReminder?.tender_id ? <Tooltip title='Remove reminder' > <RemindDisable theme="filled" size="24" fill="#FF7835" onClick={() => setReminderRemove(true)} /></Tooltip>
                                                            :
                                                            itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Set Key Client Manager' && item?.bg_assign_tndr_generated_id == null ? <></> :
                                                                itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Set Bid Manager' && item?.bg_assign_tndr_generated_id == null ? <></> :
                                                                    <Tooltip placement="bottom" title={itm?.bg_mstr_tndr_cycle_inaction?.inaction_name}  > <img src={`${docurlchat}uploads/inaction_image/${itm?.bg_mstr_tndr_cycle_inaction?.image_name}`}
                                                                        style={{ width: "20px" }} onClick={() => handleCallAction(itm?.bg_mstr_tndr_cycle_inaction?.inaction_name, itm)} />
                                                                    </Tooltip>
                                            }
                                        </Link>
                                        :
                                        <Link className="import_export_data">
                                            <Skeleton width={30} height={20} circle />
                                        </Link>
                                )
                            })
                        } */}
                        {
                            getActionsList?.filter((actionItem) => actionItem?.bg_mstr_tndr_cycle_inaction != null)?.map((itm, index) => {
                                // console.log(itm, "itm")
                                return (
                                    !skeleton ?
                                        <Link className={unitTenderIdForWishlist?.tender_id ? "import_export_data" : 'import_export'} >
                                            {
                                                itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'view Link' && item?.tnd_url === null ?
                                                    <></>
                                                    :
                                                    itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Wishlist' && unitTenderIdForWishlist?.tender_id ? <Tooltip title='Remove wishlist' > <Bookmark theme="filled" size="24" fill="#FF7835" onClick={() => setWishlistRemove(true)} /> </Tooltip>
                                                        :
                                                        itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Reminder' && unitTenderIdForReminder?.tender_id ? <Tooltip title='Remove reminder' > <RemindDisable theme="filled" size="24" fill="#FF7835" onClick={() => setReminderRemove(true)} /></Tooltip>
                                                            :
                                                            itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Set Key Client Manager' && item?.bg_assign_tndr_generated_id == null ? <Tooltip placement="bottom" title={itm?.bg_mstr_tndr_cycle_inaction?.inaction_name}  > <img src={`${docurlchat}uploads/inaction_image/${itm?.bg_mstr_tndr_cycle_inaction?.image_name}`}
                                                                style={{ width: "20px", opacity: ".3", cursor: "default" }} />
                                                            </Tooltip> :
                                                                itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Set Bid Manager' && item?.bg_assign_tndr_generated_id == null ? <Tooltip placement="bottom" title={itm?.bg_mstr_tndr_cycle_inaction?.inaction_name}  > <img src={`${docurlchat}uploads/inaction_image/${itm?.bg_mstr_tndr_cycle_inaction?.image_name}`}
                                                                    style={{ width: "20px", opacity: ".3", cursor: "default" }} />
                                                                </Tooltip> :
                                                                    <Tooltip placement="bottom" title={itm?.bg_mstr_tndr_cycle_inaction?.inaction_name}  > <img src={`${docurlchat}uploads/inaction_image/${itm?.bg_mstr_tndr_cycle_inaction?.image_name}`}
                                                                        style={{ width: "20px", cursor: "pointer" }} onClick={() => handleCallAction(itm?.bg_mstr_tndr_cycle_inaction?.inaction_name, itm)} />
                                                                    </Tooltip>
                                            }
                                        </Link>
                                        :
                                        <Link className="import_export_data">
                                            <Skeleton width={30} height={20} circle />
                                        </Link>
                                )
                            })
                        }
                    </div>
                    :
                    // Case for 'All'
                    <div className='d-flex gap-4 bd_tenderCrd_thrd'>
                        {
                            actionBtnForAll?.filter((actionItem) => actionItem?.bg_mstr_tndr_cycle_inaction != null)?.map((itm, index) => {
                                return (
                                    !skeleton ?
                                        <Link className={unitTenderIdForWishlist?.tender_id ? "import_export_data" : 'import_export'}  >
                                            {
                                                itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'view Link' && item?.tnd_url === null ?
                                                    <></>
                                                    :
                                                    itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Wishlist' && unitTenderIdForWishlist?.tender_id ? <Tooltip title='Remove wishlist' >  <Bookmark theme="filled" size="24" fill="#FF7835" onClick={() => setWishlistRemove(true)} /></Tooltip>
                                                        :
                                                        itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Reminder' && unitTenderIdForReminder?.tender_id ? <Tooltip title='Remove reminder' > <RemindDisable theme="filled" size="24" fill="#FF7835" onClick={() => setReminderRemove(true)} /></Tooltip> :
                                                            itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Set Key Client Manager' && item?.bg_assign_tndr_generated_id == null ? <Tooltip placement="bottom" title={itm?.bg_mstr_tndr_cycle_inaction?.inaction_name}  > <img src={`${docurlchat}uploads/inaction_image/${itm?.bg_mstr_tndr_cycle_inaction?.image_name}`}
                                                                style={{ width: "20px", opacity: ".3", cursor: "default" }} />
                                                            </Tooltip> :
                                                                itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Set Bid Manager' && item?.bg_assign_tndr_generated_id == null ? <Tooltip placement="bottom" title={itm?.bg_mstr_tndr_cycle_inaction?.inaction_name}  > <img src={`${docurlchat}uploads/inaction_image/${itm?.bg_mstr_tndr_cycle_inaction?.image_name}`}
                                                                    style={{ width: "20px", opacity: ".3", cursor: "default" }} />
                                                                </Tooltip> :
                                                                    <Tooltip placement="bottom" title={itm?.bg_mstr_tndr_cycle_inaction?.inaction_name}  > <img src={`${docurlchat}uploads/inaction_image/${itm?.bg_mstr_tndr_cycle_inaction?.image_name}`}
                                                                        style={{ width: "20px", cursor: "pointer" }} onClick={() => handleCallAction(itm?.bg_mstr_tndr_cycle_inaction?.inaction_name, itm)} />
                                                                    </Tooltip>
                                            }
                                        </Link>
                                        :
                                        <Link className="import_export_data">
                                            <Skeleton width={30} height={20} circle />
                                        </Link>
                                )
                            })
                        }
                    </div>
            }
            <Drawer className='drawer_save_temp' closeIcon={<img src={skipBack} alt='' />} title="Tender" placement="right" onClose={() => handleCloseDrawer(item?.tnd_url)} open={linkOpen} width="90%">
                <iframe id='drawer_ifrm' src={item?.tnd_url} title="W3Schools Free Online Web Tutorials" width="100%" ></iframe>
            </Drawer>



            <TenderWishListModal
                isModalOpen={isModalOpen}
                itemId={item?.id}
                handleCancel={handleCancel}
                setIsModalOpen={setIsModalOpen}
                getActionListApi={getActionListApi}

            />

            <TenderRemainderModal
                remind={remind}
                itemId={item?.id}
                handleRemindCancel={handleRemindCancel}
                getActionListApi={getActionListApi}
            />

            <TenderSubmitModal
                handleSubmitCancel={handleSubmitCancel}
                submitOpen={submitOpen}
                getAllTenders={getAllTenders}
            />
            <TenderDeleteModal //pending from backend
                deleteOpen={deleteOpen}
                setdeleteOpen={setdeleteOpen}
                itemId={item?.id}
                getTenders={getTenders}
                setTenders={setTenders}
                getAllTenders={getAllTenders}
            />

            <TenderStatusModal
                tenderStatusOpen={tenderStatusOpen}
                tenderStatus={tenderStatus}
            />

            {showModalForRemoveWhishList()}

            {showModalForRemoveReminder()}
        </>


    )
}

export default TenderDetailAction