// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Drawer, Select } from 'antd';
import Link from '@mui/material/Link';
import Comment from '../../../BidGrid/assets/images/icons/chat.png';
import GenerateRequest from '../Drawer/GenerateRequest.jsx';
import AddRequestDrawer from '../Drawer/AddRequestDrawer';
import RequestListDrawer from '../Drawer/RequestListDrawer';
import { DashboardServiceApi } from 'Services/bidgrid/dashboard/DashboardAPi';
import dayjs from 'dayjs';
import { useSelector, useDispatch } from 'react-redux';
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'
import TodoComments from '../Drawer/TodoComment';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import { filterCycleActions } from 'Redux/actions/bidgrid/cycleFilterAction';
import { misFilterActions } from 'Redux/actions/bidgrid/misFilterAction';
import { TimeConverter } from '../TimeConverter/TimeConverter';
const TenderDetailComment = ({ item, requestList, fetchRequestListForDrawer, actionData, userListData, getActionListApi, skeleton, commonFilter }) => {
    const [open, setOpen] = useState(false);
    const [requestsopen, setrequestsopen] = useState(false);
    const [recordData, setRecordData] = useState({})
    const [tenderRequestDetail, setTenderRequestDetail] = useState({})
    const [spinner, setSpinner] = useState(false)
    const [commentModal, setCommentModal] = useState(false)
    const [tenderComments, setTenderComments] = useState([])
    let requestCounts = actionData?.meeting_tender?.find((itm) => itm?.tender_id === item?.id)?.count_meeting;
    const dispatch = useDispatch()
    const showDrawer = () => {
        setOpen(true);

    };
    const replay = (req_id) => {
        setrequestsopen(true);
        handleAddRequestDrawer(req_id);

    }
    const onClose = () => {
        setOpen(false);
        setrequestsopen(false)
    };

    // Request List Drawer
    const [openStatsDrawer, setOpenStatsDrawer] = useState(false);
    const showRequestList = () => {
        setOpenStatsDrawer(true);
        fetchRequestListForDrawer(item?.id)
    };
    const onCloseDrawer = () => {
        setOpenStatsDrawer(false);
        getActionListApi();
    };

    const handleAddRequestDrawer = async (val) => {
        const formData = new URLSearchParams();
        formData.append('request_id', val)
        try {
            const response = await DashboardServiceApi?.requestsDetail(formData)
            if (response?.data?.status == 1) {
                setTenderRequestDetail(response?.data?.data)
            }
            else {
                console.log(response?.response?.data?.message)
            }
        } catch (error) {
            console.log(error, 'Api Error')
        }
    }

    function highlightAt(stringValue) {
        const words = stringValue.split(/\s+/);
        const highlightedWords = words.map(word => {
            if (word.includes('@')) {
                return `<span style="color: #41A6EC">${word}</span>`;
            }
            return word;
        });
        return highlightedWords.join(' ');
    }

    const handleModalComment = () => {
        setCommentModal(true)
    }

    const userGetCommentList = async (setGetUserCommentData) => {
        // console.log()
        const formData = new URLSearchParams();
        formData.append('tender_id', item?.id)
        try {
            const response = await TenderApi.tenderCommentList(formData)
            if (response?.data?.status === '1') {
                setTenderComments(response?.data?.data)
                setGetUserCommentData(response?.data?.data)
            } else {
                setGetUserCommentData([])
                setTenderComments([])
            }
        } catch (error) {
            console.log('error')
        }
    }



    const onCloseOfComment = () => {
        commonFilter == "CYCLE" ? dispatch(filterCycleActions.filterResetisUpdateTrue()) : dispatch(misFilterActions.misFilterResetisUpdateTrue())
    }

    return (
        <div className='bd_tenderCrd_sec'>
            <div className='bd_tendersec_cont'>
                {!skeleton ?
                    <div className='bd_tender_card_comment' onClick={handleModalComment}>
                        <img src={Comment} width={15} alt='' />
                        <span>Last comment</span>
                    </div> :
                    <div className='bd_tender_card_comment'>
                        <Skeleton width={150} height={15} />
                    </div>
                }

                {!skeleton ? <span className='bd_tender_commment' dangerouslySetInnerHTML={{ __html: item?.tender_comment != null ? highlightAt(item?.tender_comment.comment_txt) : 'No comment yet...' }}></span>
                    : <div className='bd_tender_commment'>
                        <Skeleton width={150} height={15} />
                    </div>
                }
                {!skeleton ? <div className='bd_tender_sec_by'>
                    <span>{`${item?.tender_comment != null ? 'By ' + item?.tender_comment?.user?.userfullname : ''}`}</span>
                    <div className='bd_tender_sec_time'>
                        <span>{`${item?.tender_comment != null ? `${dayjs(item?.tender_comment?.created_at).format('DD-MM-YYYY')} ${TimeConverter(item?.tender_comment?.created_at)}` : ''}`}</span>

                    </div>
                </div> : <div className='bd_tender_sec_by'>
                    <Skeleton width={100} height={15} />
                </div>}
            </div>
            <div className='bd_tender_facesheet'>
                {/* <div className="requestCount" onClick={() => (requestCounts == 0 || requestCounts == null || requestCounts == '') ? '' : showRequestList()}> */}
                <div className="requestCount" onClick={() => showRequestList()}>
                    {!skeleton ? <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24">
                        <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m4.5 19.5l15-15m0 0H8.25m11.25 0v11.25" />
                    </svg> : <Skeleton width={10} height={15} />}
                    {/* Requests <span>{requestCounts ? requestCounts : 0}</span> */}
                    {
                        !skeleton ? (<>Requests <span>{requestCounts ? requestCounts : 0}</span></>) : (<>
                            <Skeleton width={100} height={15} />
                        </>)
                    }
                </div>
                {/* <button onClick={showDrawer}>Add Request</button> */}
                <GenerateRequest open={open} setOpen={setOpen} onClose={onClose} id={item?.id} setRecordData={setRecordData} fetchRequestListForDrawer={fetchRequestListForDrawer} from={'TenderDetailCommentPage'} userListData={userListData} />
                <AddRequestDrawer requestsopen={requestsopen} setrequestsopen={setrequestsopen} onClose={onClose} tenderRequestDetail={tenderRequestDetail} setSpinner={setSpinner} />

            </div>

            <RequestListDrawer id={item?.id} replay={replay} showRequestList={showRequestList} onCloseDrawer={onCloseDrawer} setOpenStatsDrawer={setOpenStatsDrawer} openStatsDrawer={openStatsDrawer} requestList={requestList} userListData={userListData} handleAddRequestDrawer={handleAddRequestDrawer} showDrawer={showDrawer} fetchRequestListForDrawer={fetchRequestListForDrawer} />
            <TodoComments projectId={null} comment={commentModal} setComment={setCommentModal} isTodo={false} detailPage={true} item={item} dropdownValState={userListData} userGetCommentLists={userGetCommentList} setTenderCommentData={setTenderComments} onCloseOfComment={onCloseOfComment} />
        </div>

    )
}

export default TenderDetailComment