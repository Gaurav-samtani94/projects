// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Button, Modal, Form, Select } from 'antd';
import { Down } from '@icon-park/react';
import "../../assets/css/app.scss"

import { toast } from 'react-toastify';

const GernerateNumber = (props) => {
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const { open, close, generateData, loadingModalBtn, setLoadingModalBtn, getGenTenderId, tenderCycle, setModals, inActionPopup, getAllTenders, setInActionPopup } = props

    const [generateVal, setGenerateVal] = useState('')
    const [form] = Form.useForm();

    const handleSelectChange = (value) => {
        setGenerateVal(value)
    }
    const handleReset = () => {
        setGenerateVal('')
    }


    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            // handleSubmit();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleOnclickSubmit = async () => {

        setLoadingModalBtn(true);
        const formData = new URLSearchParams();
        formData.append('tender_id', getGenTenderId);
        formData.append('generate_type_id', generateVal);
        try {
            const response = await tenderCycle.getbdGenerateId(formData)
            if (response?.data?.status === '1') {

                setModals(prevModals => ({
                    ...prevModals,
                    generateNum: { visible: false, data: null },
                }));

                setGenerateVal('')
                setLoadingModalBtn(false);

                if (!inActionPopup) {
                    setModals(prevModals => ({
                        ...prevModals,
                        keyClientAssign: { visible: true, data: null },
                    }));
                    setInActionPopup(false)
                }
                await getAllTenders()
                notifySuccess(response?.data?.message);

            } else {
                setLoadingModalBtn(false);
                setGenerateVal('')
                notify(response?.data?.message);
                setModals(prevModals => ({
                    ...prevModals,
                    generateNum: { visible: false, data: null },
                }));
            }
        } catch (error) {
            console.log(error)
            notify("Error");

        }
    }
    return (
        <div>
            <Modal
                title={"Generate Number"}
                className='bd_model_main'
                open={open}
                onOk={close}
                onCancel={close}
                footer={[
                    <button key="back"
                        onClick={handleReset}
                        className='BG_ghostButton' >
                        Reset
                    </button>,
                    <Button key="submit"
                        onClick={handleOnclickSubmit}
                        className={generateVal === '' ? 'disabledBtn' : 'BG_mainButton'}
                        disabled={generateVal === '' ? true : false}
                        loading={loadingModalBtn}
                    >
                        Submit
                    </Button>

                ]}
            >
                <Form form={form} name="validateOnly" layout="vertical" autoComplete="off" onKeyDown={handleKeyPress} >
                    <Form.Item label="Generate Number">
                        <Select
                            showSearch
                            placeholder="Select"
                            options={generateData?.map((item, index) => {
                                return {
                                    label: item?.generated_type,
                                    value: item?.id
                                };
                            })}
                            value={generateVal}
                            name="generateVal"
                            onChange={(value) => handleSelectChange(value)}
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            filterOption={(input, option) =>
                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >

                        </Select>
                    </Form.Item>
                </Form>

            </Modal>
        </div>
    )
}

export default GernerateNumber;
