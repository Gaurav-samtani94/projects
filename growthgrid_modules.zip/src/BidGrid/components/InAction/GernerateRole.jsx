// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Button, Modal, Form, Select, Input } from 'antd';
import { Down } from '@icon-park/react';
import "../../assets/css/app.scss"
import { toast } from 'react-toastify';

const initialState = {
    bd_role_id: null,
    assign_to: null,
}

const GernerateRole = (props) => {
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);


    const { open, close, getGenTenderId, userListData, loadingModalBtn, setLoadingModalBtn, tenderCycle, setBdClientManagerData, setModals
        , inActionPopup, setInActionPopup, getAllTenders } = props

    const [selectOption, setSelectOption] = useState(initialState)
    const [form] = Form.useForm();

    const handleSelectChange = (name, value) => {
        console.log(value, "valu]")
        setSelectOption({ ...selectOption, [name]: value })
    }
    const handleReset = () => {
        setSelectOption(initialState)
    }


    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            // handleSubmit();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };
    const handleRole1Submit = async () => { // BID MANAGER POP-UP SUBMIT
        setLoadingModalBtn(true);
        const formData = new URLSearchParams();
        // formData.append('bd_role_id', data?.bd_role_id);
        formData.append('bd_role_id', 2);
        formData.append('tender_id', getGenTenderId);
        formData.append('assign_to', selectOption?.assign_to);
        try {
            const response = await tenderCycle.getBdRoleSubmit(formData)
            if (response?.data?.status === '1') {
                setBdClientManagerData(response?.data?.data)
                close()
                setLoadingModalBtn(false);
                setSelectOption({
                    bd_role_id: null,
                    assign_to: null,
                })
                // setBidRoleOpen(true)
                if (!inActionPopup) {
                    setModals(prevModals => ({
                        ...prevModals,
                        consortiumCompAssign: { visible: true, data: null },
                    }));
                    setInActionPopup(false)
                }
                await getAllTenders()
                notifySuccess(response?.data?.message);
            }
        } catch (error) {
            console.log(error)
            notify("Error");
        }
    }

    return (
        <div>
            <Modal
                // title={"Generate Role"}
                title={"Bid Manager"}
                className='bd_model_main'
                open={open}
                onOk={close}
                onCancel={close}
                footer={[
                    <button key="back"
                        onClick={handleReset}
                        className='BG_ghostButton' >
                        Reset
                    </button>,
                    // <button key="submit"
                    //     onClick={handleRole1Submit}
                    //     className='BG_mainButton' >
                    //     Submit
                    // </button>
                    <Button key="submit"
                        onClick={handleRole1Submit}
                        className='BG_mainButton'
                        disabled={loadingModalBtn}
                        loading={loadingModalBtn}
                    >
                        Submit
                    </Button>

                ]}
            >
                <Form form={form} name="validateOnly" layout="vertical" autoComplete="off" onKeyDown={handleKeyPress} >
                    <Form.Item label="Assign Role">
                        {/* <Select
                            showSearch
                            placeholder="Role "
                            options={roleListData?.map((item, index) => {
                                return {
                                    label: item?.role_name,
                                    value: item?.id
                                };
                            })}
                            value={selectOption?.bd_role_id}
                            name="bd_role_id"
                            onChange={(value) => handleSelectChange("bd_role_id", value)}
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            filterOption={(input, option) =>
                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >

                        </Select> */}
                        <Input
                            showSearch
                            placeholder="Role "
                            readOnly
                            value={'Bid Manager'}
                        // name="bd_role_id"

                        />


                    </Form.Item>
                    <Form.Item label="Assign User">
                        <Select
                            showSearch
                            placeholder="User"
                            options={userListData?.filter(item => item.isactive === 1)?.map((item, index) => {
                                return {
                                    label: item?.userfullname,
                                    value: item?.id
                                };
                            })}
                            value={selectOption?.assign_to}
                            name="assign_to"
                            onChange={(value) => handleSelectChange("assign_to", value)}
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            filterOption={(input, option) =>
                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >

                        </Select>
                    </Form.Item>
                </Form>

            </Modal>
        </div>
    )
}

export default GernerateRole;
