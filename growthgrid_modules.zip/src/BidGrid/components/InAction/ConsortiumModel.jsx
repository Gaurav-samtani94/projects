// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Button, Modal, Form, Select, Space, Checkbox, Row, Col } from 'antd';
import { Down } from '@icon-park/react';
import "../../assets/css/app.scss"
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';

const { Option } = Select;


const options = [];
for (let i = 10; i < 36; i++) {
    options.push({
        // label: i.toString(36) + i,
        // value: i.toString(36) + i,
    });
}

const intidata = {
    // lead_comp_id: [],
    lead_comp_id: null,
    associats_id: [],
    jvs_company: []
}


const initCompanyArr = {
    lead_comp_id: [],
    associats_id: [],
    jvs_company: []
}


const ConsortiumModel = (props) => {
    const notifySuccess = (msg) => toast.success(msg);
    const { loadingModalBtn, open, close, consortiumModelOpen, getGenTenderId, setModals, handleMoveTenderToAnotherScope, setLoadingModalBtn, conSubmitName, handleSubmitTender, cycleId, getAllTenders, id } = props

    // const [consortiumVal, setConsortiumVal] = useState([])
    const [form] = Form.useForm();
    const [soloStatus, setSoloStatus] = useState(false)
    const [dataOption, setDataOption] = useState(intidata)
    const [companyOptions, setCompanyOptions] = useState(initCompanyArr)
    const [disabledOption, setDisabledOption] = useState({
        disableLead: [],
        disableJvs: [],
        disableAssociative: []
    })
    const [disabledOptionComp, setDisabledOptionComp] = useState({
        disableLead: [],
        disableJvs: [],
        disableAssociative: []
    })
    const [consortiumVal, setConsortiumVal] = useState([])

    const { userBidInfo } = useSelector((state) => state?.userDetails)

    const notify = (error) => toast.error(error);



    // let skip;

    // const handleSelectChange = (name, value) => {
    //     setConsortiumVal(value)
    // }

    const handleReset = (isStatus) => {
        if (isStatus) {
            setModals(prevModals => ({
                ...prevModals,
                consortiumCompAssign: { visible: false, data: null },
            }));
        } else {
            setDataOption(intidata)
            setSoloStatus(false)
        }
        // setConsortiumVal([])


    }

    // chhaya code---
    // const handleOnclickSubmit = (skip) => {
    //     handleConsortiumSubmit(getGenTenderId, consortiumVal, setConsortiumVal, skip)
    // }

    const handleOnclickSubmit = (skip) => {
        handleConsortiumSubmit(getGenTenderId, dataOption, soloStatus, skip, setDataOption, intidata, setSoloStatus)
    }

    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            // handleSubmit();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleSoloChange = (e) => {
        setSoloStatus(e?.target?.checked)
    }

    const handleConsortiumChange = (name, value) => {
        // if (name === "lead_comp_id") {
        //     setErrorsCompanyMsg(false)
        // }

        setDataOption((prevDataOption) => ({
            ...prevDataOption,
            [name]: value === undefined ? null : value
        }));
    };


    const getconsortiumCompanyList = async () => {
        const formData = new URLSearchParams();
        formData.append('project_id', id)
        try {
            const response = await TenderApi?.CompetitorList(formData)
            if (response?.data?.status == 1) {
                setCompanyOptions((prevState) => ({
                    ...prevState,
                    lead_comp_id: response?.data?.data,
                    associats_id: response?.data?.data,
                    jvs_company: response?.data?.data
                }))

            }
            else {
            }
        } catch (error) {
            console.log(error)
        }
    };

    // assign consotitum list

    const fetchConsortiumStatus = async () => {

        const formData = new URLSearchParams();
        formData.append('project_id', id);
        try {
            const response = await TenderApi.updateConsortiumStatus(formData)

            if (response?.data?.status === '1') {
                if (response?.data?.is_solo === '1') {
                    getCompetitorList(true)
                    setSoloStatus(true)
                } else {
                    getCompetitorList(false)
                    setSoloStatus(false)
                }
            } else {
                getCompetitorList(false)
            }
        } catch (error) {
            console.log(error, 'api erorr')
            getCompetitorList(false)
        }
    }

    // competitor list
    const getCompetitorList = async (isSolo) => {

        const formData = new URLSearchParams();
        formData.append('project_id', id);
        try {
            const response = await TenderApi.competitorCompany(formData)
            if (response?.data?.status === '1') {

                let consortiumData = [];
                let comptitorData = [];

                response?.data?.data?.forEach(item => {
                    const leadCompanines = item.comptitor_assign_company_list.Lead_company;

                    leadCompanines?.forEach(val => {
                        if (val?.type_data === '1') {
                            consortiumData?.push(item)
                        } else if (val?.type_data === '2') {
                            comptitorData.push(item)
                        } else {
                            return
                        }
                    })
                })
                setConsortiumVal(consortiumData)
                disableCompetitorCompanies(comptitorData)

                if (consortiumData?.length > 0 && !isSolo) {
                    let leadData
                    let associativeData
                    let jvsData
                    consortiumData?.map(item => {
                        leadData = Number(item?.comptitor_assign_company_list?.Lead_company[0]?.company_id)
                        associativeData = item?.comptitor_assign_company_list?.associative_company?.map(item => Number(item?.company_id)) || [];
                        jvsData = item?.comptitor_assign_company_list?.jvs_company?.map(item => Number(item?.company_id)) || []
                    })
                    const newObj = {
                        lead_comp_id: leadData,
                        associats_id: associativeData,
                        jvs_company: jvsData
                    }

                    setDataOption((prevState) => {
                        return {
                            ...prevState,
                            ...newObj,
                        };
                    });
                    // setIsRefreshed(true)
                } else {
                    setDataOption((prevState) => {
                        return {
                            ...prevState,
                            lead_comp_id: [],
                            associats_id: [],
                            jvs_company: []
                        };
                    });
                }
            }
            else {

            }

        } catch (error) {
            console.log(error, "else")

        }
    }


    const disableCompetitorCompanies = (comptitor_data) => {
        let disableCompetitorIds = [];
        if (comptitor_data?.length > 0) {
            comptitor_data?.map(item => {
                disableCompetitorIds.push(Number(item?.comptitor_assign_company_list?.Lead_company[0]?.company_id))
                const associativeCompanyIds = item?.comptitor_assign_company_list?.associative_company?.map(item => Number(item?.company_id));

                if (associativeCompanyIds) {
                    disableCompetitorIds.push(...associativeCompanyIds);
                }
                const jvsCompanyIds = item?.comptitor_assign_company_list?.jvs_company?.map(item => Number(item?.company_id))

                if (jvsCompanyIds) {
                    disableCompetitorIds.push(...jvsCompanyIds);
                }
            })
        }
        const { disableLead, disableJvs, disableAssociative } = disabledOptionComp;

        let disableLead_new = [...disableLead, ...disableCompetitorIds];
        let disableJvs_new = [...disableJvs, ...disableCompetitorIds];
        let disableAssociative_new = [...disableAssociative, ...disableCompetitorIds];

        setDisabledOptionComp({
            disableLead: disableLead_new,
            disableJvs: disableJvs_new,
            disableAssociative: disableAssociative_new
        });
    }

    const predefinedVal = () => {
        const { disableLead, disableJvs, disableAssociative } = disabledOptionComp
        const existsAss = dataOption?.associats_id || [];
        const existsJvs = dataOption?.jvs_company || [];
        const existsLeadComp = dataOption?.lead_comp_id !== null ? dataOption?.lead_comp_id : [];

        let disableLead_new = [...existsAss, ...existsJvs, ...disableLead];
        let disableJvs_new = [existsLeadComp, ...existsAss, ...disableJvs];
        let disableAssociative_new = [existsLeadComp, ...existsJvs, ...disableAssociative];

        disableJvs_new?.filter(item => {
            if (item?.length === 0) {
                disableJvs_new.splice(0, 1)
            } else {
                return disableJvs_new
            }
        })

        disableAssociative_new?.filter(item => {
            if (item?.length === 0) {
                disableAssociative_new.splice(0, 1)
            } else {
                return disableAssociative_new
            }
        })

        setDisabledOption({
            disableLead: disableLead_new,
            disableJvs: disableJvs_new,
            disableAssociative: disableAssociative_new
        });

    }

    useEffect(() => {
        predefinedVal()
    }, [dataOption?.lead_comp_id, dataOption?.associats_id, dataOption?.jvs_company]);


    useEffect(() => {
        consortiumModelOpen && getconsortiumCompanyList(); fetchConsortiumStatus()

    }, [consortiumModelOpen])




    const handleConsortiumSubmit = async (id, dataOption, soloStatus, skip, setDataOption, intidata, setSoloStatus) => {

        if (skip === 'skip') {
            try {
                const formData = new URLSearchParams();
                formData.append('project_id', id)
                const response = await TenderApi?.updateConsortium(formData)
                if (response?.data?.status == 1) {
                    setModals(prevModals => ({
                        ...prevModals,
                        consortiumCompAssign: { visible: false, data: null },
                    }));
                    await getAllTenders()
                    setDataOption(intidata)
                    setSoloStatus(false)
                    if (conSubmitName === "Move") {
                        handleMoveTenderToAnotherScope(getGenTenderId)
                    } else {
                        handleSubmitTender(cycleId, id)
                    }
                }
            } catch (error) {
                console.log(error)

            }
            // setModals(prevModals => ({
            //     ...prevModals,
            //     consortiumCompAssign: { visible: false, data: null },
            // }));
            // await getAllTenders()
            // setDataOption(intidata)
            // setSoloStatus(false)
            // if (conSubmitName === "Move") {
            //     handleMoveTenderToAnotherScope(getGenTenderId)
            // } else {
            //     handleSubmitTender(cycleId, id)
            // }
        }
        else {


            if (!soloStatus && dataOption?.lead_comp_id === null) {
                return
            } else {


                setLoadingModalBtn(true);
                try {
                    const formData = new URLSearchParams();
                    formData.append('project_id', id)
                    if (soloStatus) {
                        formData.append('solo', soloStatus)
                    }
                    else {
                        formData.append('lead_comp_id', dataOption?.lead_comp_id)
                        { dataOption?.jvs_company?.length > 0 && formData.append('jvs_company', dataOption?.jvs_company) }
                        { dataOption?.associats_id?.length > 0 && formData.append('associats_id', dataOption?.associats_id) }
                    }
                    const response = await TenderApi?.updateConsortium(formData)
                    if (response?.data?.status == 1) {
                        setLoadingModalBtn(false);
                        notifySuccess(response?.data?.message);
                        setDataOption(intidata)
                        setSoloStatus(false)
                        setModals(prevModals => ({
                            ...prevModals,
                            consortiumCompAssign: { visible: false, data: null },
                        }));
                        await getAllTenders()
                        if (conSubmitName === "Move") {
                            handleMoveTenderToAnotherScope(getGenTenderId)
                        } else {
                            handleSubmitTender(cycleId, id)
                        }

                    }
                    else {
                        notify(response?.response?.data?.message);
                    }
                    // handleSubmitTender(cycleId, id)


                } catch (error) {
                    console.log('Api Error', error);
                }


            }
        }

    }



    return (
        <div>
            {/*chhaya code: <Modal
                title={"Lead Company"}
                className='bd_model_main'
                open={open}
                onOk={handleClose}
                onCancel={handleClose}
                footer={[
                    <button key="back"
                        onClick={handleReset}
                        className='BG_ghostButton' >
                        Reset
                    </button>,
                    <button key="submit"
                        onClick={() => handleOnclickSubmit(true)}
                        className='BG_mainButton' >
                        Submit
                    </button>,
                    <button key="submit"
                        onClick={() => handleOnclickSubmit(false)}
                        className='BG_mainButton' >
                        Skip
                    </button>

                ]}
            > */}

            { /* chhaya code <Form form={form} name="validateOnly" layout="vertical" autoComplete="off" onKeyDown={handleKeyPress} >
                    <Form.Item label="Select Company">
                        <Space
                            style={{
                                width: '100%',
                            }}
                            direction="vertical"
                        >
                            <Select
                                mode="multiple"
                                allowClear
                                style={{
                                    width: '100%',
                                }}
                                placeholder="Please select"
                                options={companyListData?.map((item, index) => {
                                    return {
                                        label: item?.company_name,
                                        value: item?.id
                                    };
                                })}
                                onChange={(value) => handleSelectChange("company_name", value)}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            />
                        </Space>

                    </Form.Item>
                </Form> */}
            <Modal
                title={"Consortium"}
                className='bd_model_main'
                open={open}
                onOk={close}
                onCancel={close}
                footer={[
                    <button key="back"
                        onClick={soloStatus || consortiumVal?.length > 0 ? () => handleReset(true) : () => handleReset(false)}

                        className='BG_ghostButton' >
                        {soloStatus || consortiumVal?.length > 0 ? 'Cancel' : 'Reset'}

                    </button>,
                    <button key="submit"
                        onClick={() => handleOnclickSubmit(dataOption)}
                        className='BG_mainButton' >
                        {soloStatus || consortiumVal?.length > 0 ? 'Update' : 'Submit'}
                    </button>,
                    <button key="submit"
                        onClick={() => handleOnclickSubmit('skip')}
                        className='BG_mainButton' >
                        Skip
                    </button>

                ]}
            >
                <div className='consotrium_forms'>
                    <Form
                        form={form}
                        layout="vertical"
                        // onFinish={ConsortiumUpdate}
                        autoComplete='off'
                        name="control-hooks"
                    >
                        <div className='checkbox_heading' style={{ marginBottom: '20px' }}><Checkbox
                            onChange={handleSoloChange}
                            checked={soloStatus}
                        >Sole Proprietor </Checkbox>
                            {soloStatus ? companyOptions?.lead_comp_id?.filter(item => item?.link_comp_id == userBidInfo?.comp_id)?.map(val => `(${val?.company_name})`) : ''}

                        </div>
                        {
                            soloStatus ?
                                <></>
                                :
                                <Row gutter={20}>
                                    <Col sm={24}>

                                        <Form.Item
                                            label="Lead"
                                            // name="lead_comp_id"
                                            rules={[{ required: true, message: "please enter a Lead Company" }]}
                                        >

                                            <Select
                                                placeholder='Select Lead...'
                                                // mode='multiple'
                                                // value={dataOption?.lead_comp_id?.map((id) =>
                                                //     companyOptions?.lead_comp_id.find((company) => company.id === Number(id))?.company_name
                                                // )}
                                                showSearch
                                                value={dataOption?.lead_comp_id}
                                                name='lead_comp_id'
                                                onChange={(value) => {
                                                    // const selectedIds = value?.map((name) =>
                                                    //     companyOptions?.lead_comp_id.find((company) => company.company_name === name)?.id
                                                    // );
                                                    handleConsortiumChange('lead_comp_id', value);
                                                }}

                                            // disabled={soloStatus}
                                            >

                                                {companyOptions?.lead_comp_id?.map((item) => {
                                                    return (
                                                        <Option key={item?.id} value={item?.id} disabled={disabledOption?.disableLead?.includes(item?.id)}>
                                                            {item?.company_name}
                                                        </Option>
                                                    )
                                                }
                                                )}
                                            </Select>
                                            {/* {errorsCompanyMsg ? <div className="col-md-12" style={{ color: '#ff4d4f' }}>please enter a Lead Company</div> : ''} */}

                                        </Form.Item>

                                    </Col>
                                    <Col sm={24}>
                                        <Form.Item label="JV"
                                        >
                                            <Select
                                                placeholder='Select JV...'
                                                mode='multiple'
                                                value={dataOption?.jvs_company?.map((id) =>
                                                    companyOptions?.jvs_company?.find((company) => company.id === Number(id))?.company_name
                                                )}
                                                name='jvs_company'
                                                onChange={(value) => {
                                                    const selectedIds = value.map((name) =>
                                                        companyOptions?.jvs_company?.find((company) => company.company_name === name)?.id
                                                    );
                                                    handleConsortiumChange('jvs_company', selectedIds);
                                                }}
                                            // disabled={soloStatus}
                                            >
                                                {companyOptions?.jvs_company?.map((item) => (
                                                    <Option key={item?.id} value={item?.company_name} disabled={disabledOption?.disableJvs?.includes(item?.id)}>
                                                        {item?.company_name}
                                                    </Option>
                                                ))}
                                            </Select>

                                        </Form.Item>
                                    </Col>

                                    <Col sm={24}>
                                        <Form.Item label="Associate"
                                        >
                                            <Select
                                                placeholder='Select Associate...'
                                                mode='multiple'
                                                value={dataOption?.associats_id?.map((id) =>
                                                    companyOptions?.associats_id.find((company) => company.id === Number(id))?.company_name
                                                )}
                                                name='associats_id'
                                                onChange={(value) => {
                                                    const selectedIds = value.map((name) =>
                                                        companyOptions?.associats_id.find((company) => company.company_name === name)?.id
                                                    );
                                                    handleConsortiumChange('associats_id', selectedIds);
                                                }}
                                            // disabled={soloStatus}
                                            >
                                                {companyOptions?.associats_id?.map((item) => (
                                                    <Option key={item?.id} value={item?.company_name} disabled={disabledOption?.disableAssociative?.includes(item?.id)}>
                                                        {item?.company_name}
                                                    </Option>
                                                ))}
                                            </Select>


                                        </Form.Item>
                                    </Col>
                                </Row>

                        }

                        {/* <div className='save_update_btn'>
                            <button className='BG_mainButton' >Save & Update</button>
                        </div> */}
                    </Form>
                </div>
            </Modal>

        </div>
    )
}

export default ConsortiumModel;
