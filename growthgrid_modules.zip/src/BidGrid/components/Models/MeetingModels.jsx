// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Button, Modal, Form, Upload, Card, Flex } from 'antd';
import { ArrowDownOutlined } from '@ant-design/icons';
import "../../assets/css/app.scss"
import { toast } from 'react-toastify';
import ReactQuill from 'react-quill'
import { MeetingApi } from 'Services/bidgrid/tenderList/MeetingApi';

const initialState = {
    editor: '',
    file: []
}

var modules = {
    toolbar: [
        [{ size: ["small", false, "large", "huge"] }],
        ["bold", "italic", "underline", "strike", "blockquote"],
        [{ list: "ordered" }, { list: "bullet" }],
        ["link", "image"],
        [
            { list: "ordered" },
            { list: "bullet" },
            { indent: "-1" },
            { indent: "+1" },
            { align: [] }
        ],
        [{ "color": ["#000000", "#e60000", "#ff9900", "#ffff00", "#008a00", "#0066cc", "#9933ff", "#ffffff", "#facccc", "#ffebcc", "#ffffcc", "#cce8cc", "#cce0f5", "#ebd6ff", "#bbbbbb", "#f06666", "#ffc266", "#ffff66", "#66b966", "#66a3e0", "#c285ff", "#888888", "#a10000", "#b26b00", "#b2b200", "#006100", "#0047b2", "#6b24b2", "#444444", "#5c0000", "#663d00", "#666600", "#003700", "#002966", "#3d1466", 'custom-color'] }],
    ]
};
var formats = [
    "header", "height", "bold", "italic",
    "underline", "strike", "blockquote",
    "list", "color", "bullet", "indent",
    "link", "image", "align", "size",
];

const MeetingModels = (props) => {

    const { documentFileDownload, modalData, setRecord, meeting, setmeeting, getMeetinglist, setSpinner, spinner } = props

    const [formFields, setFormFileds] = useState(initialState)
    const [editor, setEditor] = useState('')
    const [form] = Form.useForm();
    const [isCleared, setIsCleared] = useState(true);
    const notifySuccess = (msg) => toast.success(msg);
    const notify = (error) => toast.error(error);
    const [errormsg, setErrorMsg] = useState(false)

    useEffect(() => {
        if (modalData?.hasOwnProperty('description')) {
            setEditor(modalData?.description);
        }
    }, [modalData])



    const handleReset = () => {
        form.resetFields()
        setFormFileds({ ...formFields, file: [] })
        setErrorMsg(false)
        setEditor('')
    }


    const handleSubmit = async () => {
        if (editor !== null && editor !== undefined && editor?.trim()?.replace(/<[^>]*>/g, '') !== '') {
            setSpinner(true)
            const formData = new FormData()
            formData.append('meeting_id', modalData?.id)
            formFields?.file?.forEach((file, index) => {
                formData.append('file', file.originFileObj);
            });
            formData.append('description', editor)
            try {
                const response = await MeetingApi.addMinOfMeeting(formData)
                console.log(response)
                if (response?.data?.status === '1') {
                    notifySuccess('Minute of Meeting Added Successfully.')
                    await getMeetinglist()
                    setmeeting(false);
                    handleReset()
                } else {
                    notify('something went wrong!!')
                    setmeeting(false);
                    handleReset()
                    setSpinner(false)
                }
            } catch (error) {
                notify(error)
                setmeeting(false);
                handleReset()
                setSpinner(false)
            }
        } else {
            setErrorMsg(true)
        }

    }


    const handleUpdate = async () => {
        if (editor?.trim()?.replace(/<[^>]*>/g, '') !== '') {
            setSpinner(true)
            const formData = new FormData()
            formData.append('meeting_id', modalData?.meeting_id)
            formData.append('id', modalData?.id)
            formFields?.file?.forEach((file, index) => {
                formData.append('file', file.originFileObj);
            });
            formData.append('description', editor)
            try {
                const response = await MeetingApi.UpdateMinOfMeeting(formData)
                if (response?.data?.status == '1') {
                    notifySuccess('Minute of Meeting is added successfully.')
                    await getMeetinglist()
                    setmeeting(false);
                    handleReset()
                    setSpinner(false)
                } else {
                    notify('something went wrong!!')
                    setmeeting(false);
                    handleReset()
                    setSpinner(false)
                }
            } catch (error) {
                notify(error)
                handleReset()
                setmeeting(false);
                setSpinner(false)
            }
        } else {
            setErrorMsg(true)
        }

    }

    const handleKeyDown = (event) => {
        if (isCleared && event.key === ' ') {
            event.preventDefault();
        }
    };

    const handleEditorChange = (content) => {
        setEditor(content);
        setIsCleared(content.trim()?.replace(/<[^>]*>/g, '') === '');
        setErrorMsg(false)
    };

    const handleClose = () => {
        setmeeting(false);
        handleReset()
        setErrorMsg(false)
    };

    const handleDoc = (info) => {
        if (info.file.status === 'uploading') {
            Promise.all(info.fileList.map(file => new Promise((resolve, reject) => {
                getBase64(file.originFileObj, (url) => {
                    if (url) {
                        resolve({
                            uid: file.uid,
                            name: file.name,
                            status: 'done',
                            originFileObj: file.originFileObj,
                        });
                    } else {
                        reject(new Error('File is corrupted or invalid'));
                    }
                });
            })))
                .then(fileList => {
                    setFormFileds({ ...formFields, file: fileList });
                })
                .catch(error => {
                    console.error('Error processing files:', error);
                });
        }
    };
    const getBase64 = (file, callback) => {
        const reader = new FileReader();
        reader.addEventListener('load', () => callback(reader.result));
        reader.addEventListener('error', () => callback(null));
        reader.readAsDataURL(file);
    };
    const beforeUpload = (file) => {
        const allowedFileTypes = ['image/jpeg', 'image/png', 'application/pdf', 'text/html'];

        if (!allowedFileTypes.includes(file.type)) {
            notify('You can only upload JPG, PNG, PDF, or HTML files!');
            return false;
        }
        return true;
    };
    const handleRemove = (file) => {
        const newFileList = formFields.file.filter((f) => f.uid !== file.uid);
        setFormFileds({ ...formFields, file: newFileList });
    };


    const handleEditor = () => {
        if (editor?.trim()?.replace(/<[^>]*>/g, '') === '' && editor === undefined) {
            setErrorMsg(true);
        } else {
            setErrorMsg(false);
        }
    };

    return (
        <div>
            <Modal title="Mention Minute of Meeting" className='bd_model_main'
                open={meeting}
                onOk={handleClose}
                onCancel={handleClose}
                footer={false}

            >


                <Form
                    form={form}
                    name="control-hooks"
                    layout="vertical"
                    onFinish={() => { !modalData?.hasOwnProperty('bg_meeting_mom') ? handleUpdate() : handleSubmit() }}
                >
                    <Form.Item label={<span><span style={{ color: '#ff4d4f' }}>*</span>Description :</span>}>
                        <div className=" mb-4">
                            <div style={{ marginBottom: "85px", justifyContent: "center" }}>
                                <ReactQuill
                                    theme="snow"
                                    modules={modules}
                                    formats={formats}
                                    placeholder="write your content ...."
                                    name='project_name'
                                    onKeyDown={handleKeyDown}
                                    onChange={handleEditorChange}
                                    value={editor}
                                    style={{ height: "300px" }}
                                >
                                </ReactQuill>

                            </div>
                            {errormsg ? <div className="col-md-12" style={{ color: 'red' }}>Description is required</div> : ''}
                        </div>
                    </Form.Item>

                    <Form.Item
                        label="Attach file  (Max Size is 20 MB)"
                    >
                        <div className='todo_model_upload'>
                            <Upload
                                listType="picture"
                                name='files'
                                fileList={formFields?.file}
                                maxCount={1}
                                onChange={handleDoc}
                                beforeUpload={beforeUpload}
                                onRemove={handleRemove}
                            >
                                <Button className='todo_choosen_btn'>Choose file </Button>
                                <span className='file_choosen'>No file chosen</span>
                            </Upload>
                        </div>
                    </ Form.Item>

                    {formFields?.file?.length === 0 && !modalData?.hasOwnProperty('bg_meeting_mom') &&
                        <React.Fragment >
                            <span > View Existing Document</span>
                            <Card
                                style={{
                                    margin: 20,
                                    paddingBlock: 0,
                                }}

                            >
                                <span style={{ display: 'flex', justifyContent: 'space-between' }} onClick={() => documentFileDownload(modalData)}> {modalData?.file_name}  <ArrowDownOutlined /></span>
                            </Card>
                        </React.Fragment>

                    }
                    <Flex justify='flex-end' align='center'>
                        <Button key="back" onClick={modalData?.hasOwnProperty('description') ? () => { handleReset(); setRecord(null); setmeeting(false) } : () => handleReset()} className='BG_ghostButton' >
                            {modalData?.hasOwnProperty('description') ? 'Cancel' : 'Reset'}
                        </Button>
                        <Button key="submit"
                            type="primary" htmlType="submit" loading={spinner} disabled={spinner}
                            className='BG_mainButton' style={{ marginLeft: '20px' }} onClick={handleEditor} >
                            {modalData?.hasOwnProperty('description') ? 'Update' : 'Submit'}
                        </Button>
                    </Flex>

                </Form>

            </Modal>
        </div >
    )
}

export default MeetingModels;
