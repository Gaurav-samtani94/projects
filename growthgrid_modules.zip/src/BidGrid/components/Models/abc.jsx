


import React, { useState, useEffect } from 'react';
import { Button, Modal, Form, Input } from 'antd';

const ReminderModel = (props) => {
  const { open, handleClose, getreminderModalRowData } = props;

  const [data, setData] = useState({
    reminder_subject: getreminderModalRowData?.reminder_subject || '',
    reminder_message: getreminderModalRowData?.reminder_message || '',
  });

  useEffect(() => {
    setData({
      reminder_subject: getreminderModalRowData?.reminder_subject || '',
      reminder_message: getreminderModalRowData?.reminder_message || '',
    });
  }, [getreminderModalRowData]);

  const handleInputChange = (name, value) => {
    setData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = () => {
    handleClose();
  };


  return (
    <div>
      <Modal
        className='setMsg'
        visible={open} // Use visible instead of open
        onOk={handleClose}
        onCancel={handleClose}
      >
        <Form name="control-hooks" layout="vertical" autoComplete="off">
          <Form.Item label="Reminder Subject" rules={[{ required: true, message: 'Reminder subject is required' }]}>
            <Input
              name='reminder_subject'
              value={data.reminder_subject}
              type='text'
              placeholder='Enter here...'
              onChange={(e) => handleInputChange('reminder_subject', e.target.value)}
            />
          </Form.Item>
          <Form.Item label='Reminder Message'>
            <Input
              onChange={(e) => handleInputChange('reminder_message', e.target.value)}
              value={data.reminder_message}
              type='text'
              placeholder='Enter here...'
              name='reminder_message'
            />
          </Form.Item>
        </Form>
        <Button key="submit" onClick={handleSubmit} className='BG_mainButton'>
          Submit
        </Button>
      </Modal>
    </div>
  );
};

export default ReminderModel;
