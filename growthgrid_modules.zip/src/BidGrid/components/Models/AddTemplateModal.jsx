// @ts-nocheck
import React, { useState } from 'react';
import { Form, Modal, Input } from 'antd';
import { useSelector } from 'react-redux';
import dayjs from 'dayjs';
import { toast } from 'react-toastify';
import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
const AddTemplateModal = ({ close, open, generateChips, tempType, filterValChipsData }) => {
    const [saveTemplateData, setSaveTemplateData] = useState('')
    const { filetrChips } = useSelector((state) => state.cycleFilter)
    const notifySuccess = (msg) => toast.success(msg);
    const notify = (error) => toast.error(error);

    const chipsLength = filterValChipsData?.filter(item =>
        item?.value !== ''
        && item?.key !== 'limit'
        && item?.key !== 'page_number'
        && item?.key !== 'cycle_id'
        && item?.key !== 'orderSerial'
        && item?.key !== 'sort_key'
        && item?.key !== 'sort_val'

    ).length;

    const handleChange = (e) => {
        setSaveTemplateData(e.target.value)
    }
    const saveTemplate = () => {
        handleSubmitTemplate(saveTemplateData, setSaveTemplateData)

    }

    const handleSubmitTemplate = async (saveTemplateData, setSaveTemplateData) => {
        if (saveTemplateData) {
            const data = filterValChipsData?.filter(item =>
                item?.value !== ''
                && item?.key !== 'limit'
                && item?.key !== 'page_number'
                && item?.key !== 'cycle_id'
                && item?.key !== 'sort_key'
                && item?.key !== 'sort_val'
            )
            const keys = data?.map(obj => obj.key);
            const keysString = keys.join(',');

            const values = data?.map(obj => obj?.key === "from_date" || obj?.key === "to_date" ? dayjs(obj?.value).format('YYYY-MM-DD') : obj.value);
            const valuesString = values.join(',');
            const formData = new URLSearchParams();
            formData.append("template_type", tempType);
            formData.append("filter_field_name", keysString);
            formData.append("filter_field_value", (valuesString));
            formData.append("template_name", saveTemplateData);
            try {
                const response = await tenderCycle.getBdAddTemplateName(formData)
                if (response?.data?.status === '1') {
                    close()
                    setSaveTemplateData('')
                    notifySuccess(response?.data?.message);

                }
            } catch (error) {
                notify("Error");

                console.log(error)
            }
        }
    }
    return (
        <div>
            
            <Modal title='Add Template' className='bd_model_main'
                open={open}
                onCancel={close}
                footer={[

                    <button key="submit" disabled={(chipsLength < 1 || saveTemplateData == '') ? true : false} className={(chipsLength < 1 || saveTemplateData == '') ? 'disabledBtn' : 'BG_mainButton'} onClick={saveTemplate} >
                        Save Template
                    </button>


                ]}
            >
                <Form name="validateOnly" layout="vertical" autoComplete="off">
                    <Form.Item>
                        <Input placeholder='Enter here...' onChange={handleChange} value={saveTemplateData} />
                    </Form.Item>
                    <div className='cardtemplate_card2'>
                        <div className="bd_add_tamplate">
                            {/* {generateChips().map((chip, index) => (
                                <div key={index} style={{
                                    background: 'aliceblue',
                                    paddingLeft: '16px',
                                    paddingRight: '16px',
                                    paddingBlock: '8px',
                                    border: '1px solid #d2d2d2',
                                    borderRadius: '50px',
                                    margin: '0',
                                    cursor: 'grabbing',
                                    transition: '0.3s ease-in-out',
                                }}>
                                    {chip}
                                </div>
                            ))} */}
                            {generateChips('popup')}

                        </div>
                    </div>

                </Form>

            </Modal>
        </div>
    )
}

export default AddTemplateModal;
