// @ts-nocheck
import React, { useEffect, useState } from "react";
import { Button, Modal, Form, Input, Select, DatePicker, Flex } from 'antd';
import { Down, ToRight } from '@icon-park/react';
import { useSelector } from 'react-redux';
import { AddTenderList } from "Services/bidgrid/add/AddTender";
import { AddUnitApiList } from "Services/bidgrid/master/addUnit/AddUnit";
import { toast } from 'react-toastify';
import { useForm } from "antd/es/form/Form";

const UnitModel = (props) => {
    const { open, handleClose, getreminderModalRowData, setReminderModalRowData, getAddUnitHandler, businessUnitTimezone, setSpinner } = props;
    const [editModalData, setEditModalData] = useState({
        unit_name: '',
        country_id: null,
        state_id: null,
        city_id: null,
        timezone_id: null
    })
    const [statelist, setStateList] = useState([])
    const [cityList, setCityList] = useState([])
    const [disableBtn, setDisableBtn] = useState(false)
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const { BidCountry } = useSelector((state) => state.bidDropdownCalVal)
    const [form] = Form.useForm();
    const getBusinessUnitState = async () => {
        const formData = new URLSearchParams();
        formData.append('country_id', editModalData?.country_id);
        try {
            const res = await AddTenderList.getTenderStateList(formData)
            if (res?.data?.status == '1') {
                setStateList(res?.data?.data)
            } else {
                setStateList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const getBusinessUnitCity = async () => {
        const formData = new URLSearchParams();
        formData.append('state_id', editModalData?.state_id);
        try {
            const res = await AddTenderList.getTenderCityList(formData)
            if (res?.data?.status === '1') {
                setCityList(res?.data?.data)
            }
            else {
                setCityList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const handleSelectChange = (name, value) => {

        if (name === 'country_id') {
            form.setFieldsValue({
                state_id: null,
                city_id: null,
            });

            setCityList([])
        }

        if (name === 'state_id') {
            form.setFieldsValue({
                city_id: null,
            });
        }
        setEditModalData({ ...editModalData, [name]: value });

    }

    const handleReset = () => {
        // form.resetFields()
        // setEditModalData({
        //     unit_name: '',
        //     country_id: null,
        //     state_id: null,
        //     city_id: null,
        //     timezone_id: null
        // })

    }
    const handleSubmit = async (value) => {
        setDisableBtn(true)
        // if (editModalData?.unit_name !== '' && editModalData?.country_id !== null && editModalData?.state_id !== null && editModalData?.city_id !== null && editModalData?.timezone_id !== null) {
        try {
            const formData = new URLSearchParams()
            formData.append('unit_id', getreminderModalRowData?.id)
            formData.append('unit_name', value?.unit_name)
            formData.append('timezone_id', value?.timezone_id)
            formData.append('country_id', value?.country_id)
            formData.append('state_id', value?.state_id)
            formData.append('city_id', value?.city_id)
            await form.validateFields()
            const response = await AddUnitApiList.updateUnitList(formData)
            if (response?.data?.status === '1') {
                setSpinner(true)
                notifySuccess('Business Unit Updated Successfully')
                await getAddUnitHandler(false)
                handleClose();
                // getreminderModalRowData({})
            } else {
                notify(response?.response?.data?.message);
                setSpinner(false)
            }
        } catch (error) {
            notify("Server Error!!");
            setSpinner(false)
        }

        // } else {
        //     notify("All fields are Required")
        //     setSpinner(false)
        // }

        setTimeout(() => {
            setDisableBtn(false)
        }, 2000);

    }
    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            // createHandler()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };


    useEffect(() => {
        if (editModalData?.country_id !== null) {
            getBusinessUnitState()
        }
    }, [editModalData?.country_id])

    useEffect(() => {
        if (editModalData?.state_id !== null) {
            getBusinessUnitCity()
        }
    }, [editModalData?.state_id])


    // useEffect(() => {
    //     if (open === true) {
    //         let timeZoneData = businessUnitTimezone?.find(item => item?.timezone_name === getreminderModalRowData?.timezone_name)
    //         let countryData = BidCountry?.find(item => item?.country_name === getreminderModalRowData?.country)
    //         let stateData = getreminderModalRowData?.stateArr?.find(item => item?.state_name === getreminderModalRowData?.state)
    //         let cityData = getreminderModalRowData?.cityArr?.find(item => item?.city_name === getreminderModalRowData?.city)
    //         console.log(countryData, 'country')
    //         setEditModalData({
    //             unit_name: getreminderModalRowData?.unit_name ? getreminderModalRowData?.unit_name : '',
    //             country_id: countryData?.id ? countryData?.id : null,
    //             state_id: stateData?.id ? stateData?.id : null,
    //             timezone_id: timeZoneData?.id ? timeZoneData?.id : null,
    //             city_id: cityData?.id ? cityData?.id : null,
    //         })
    //     }

    // }, [open])

    const predefinedValues = () => {
        let timeZoneData = businessUnitTimezone?.find(item => item?.timezone_name === getreminderModalRowData?.timezone_name)
        let countryData = BidCountry?.find(item => item?.country_name === getreminderModalRowData?.country)
        let stateData = getreminderModalRowData?.stateArr?.find(item => item?.state_name === getreminderModalRowData?.state)
        let cityData = getreminderModalRowData?.cityArr?.find(item => item?.city_name === getreminderModalRowData?.city)

        let newObj = {
            unit_name: getreminderModalRowData?.unit_name || '',
            timezone_id: timeZoneData?.id || '',
            country_id: countryData?.id || '',
            state_id: stateData?.id || '',
            city_id: cityData?.id || '',
        }

        setEditModalData((prevState) => {
            return {
                ...prevState,
                ...newObj,
            };
        });
        form.setFieldsValue(newObj);

    }

    useEffect(() => {
        if (getreminderModalRowData?.id) {
            predefinedValues()
        }
    }, [getreminderModalRowData])
    const handleUnitChange = (name, e) => {
        const trimmedValue = e.target.value.trimStart();
        form.setFieldsValue({ [name]: trimmedValue });
    };

    return (
        <>
            <div>
                <Modal title={` Edit ${props?.title}`} className='bd_model_main'
                    centered
                    open={open}
                    onOk={handleClose}
                    onCancel={handleClose}
                    footer={null}

                >
                    <Form form={form} name="validateOnly" layout="vertical" autoComplete="off" onKeyDown={handleKeyPress} onFinish={handleSubmit}>
                        <Form.Item label="Business Unit:" name='unit_name' rules={[{ required: true, message: 'Business Unit is required' }]}>
                            <Input
                                // value={editModalData?.unit_name}
                                placeholder='Enter here' onChange={(e) => handleUnitChange('unit_name', e)}
                            // onChange={(e) => handleSelectChange('unit_name', e?.target?.value)}
                            />
                        </Form.Item>
                        <Form.Item label="Timezone:" name='timezone_id' rules={[{ required: true, message: 'timezone is required' }]}>
                            <Select
                                showSearch
                                // name='timezone_id'
                                value={editModalData?.timezone_id}
                                onChange={(value) => handleSelectChange('timezone_id', value)}
                                options={businessUnitTimezone?.map((item, index) => {
                                    return {
                                        value: item?.id,
                                        label: item?.timezone_name
                                    }
                                })}
                                placeholder="Select TimeZone"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            >
                            </Select>
                        </Form.Item>
                        <Form.Item label="Country:" name='country_id' rules={[{ required: true, message: 'country is required' }]}>
                            <Select
                                showSearch
                                value={editModalData?.country_id}
                                onChange={(value) => handleSelectChange('country_id', value)}
                                // name='country_id'
                                options={BidCountry?.map((item, index) => {
                                    return {
                                        value: item?.id,
                                        label: item?.country_name
                                    }
                                })}
                                placeholder="Select Country"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            >

                            </Select>
                        </Form.Item>
                        <Form.Item label="State:" name='state_id' rules={[{ required: true, message: 'State is required' }]}>
                            <Select
                                showSearch
                                // name='state_id'
                                value={editModalData?.state_id}
                                onChange={(value) => handleSelectChange('state_id', value)}
                                options={statelist?.map((item, index) => {
                                    return {
                                        value: item?.id,
                                        label: item?.state_name
                                    }
                                })}
                                placeholder="Select State"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            >

                            </Select>
                        </Form.Item>
                        <Form.Item label="City:" name='city_id' rules={[{ required: true, message: 'City is required' }]}>
                            <Select
                                showSearch
                                value={editModalData?.city_id}
                                onChange={(value) => handleSelectChange('city_id', value)}
                                // name='city_id'
                                options={cityList?.map((item, index) => {
                                    return {
                                        value: item?.id,
                                        label: item?.city_name
                                    }
                                })}
                                placeholder="Select City"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            >

                            </Select>


                        </Form.Item>

                        <Flex justify='flex-end' align='center'>
                            <Button key="back"
                                onClick={() => handleClose()}
                                className='BG_ghostButton' >
                                Cancel
                            </Button>
                            <button key="submit" className='BG_mainButton'
                                disabled={disableBtn}
                            >
                                Update
                            </button>
                        </Flex>
                    </Form>

                </Modal>
            </div>
        </>
    )
}

export default UnitModel;