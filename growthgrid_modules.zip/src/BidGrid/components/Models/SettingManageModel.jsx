// @ts-nocheck
import React, { useState } from 'react';
import { Form, Modal, Input, } from 'antd';
import { RoleList } from 'Services/bidgrid/master/role/bidRole';
import { toast } from 'react-toastify';
import { DeleteOutlined } from '@ant-design/icons';
import Delete from '../modalDelete/Delete';

const SettingManageModel = ({ templateManageClose, AddManageSetting, roleList, getbidRoleTender }) => {
    const [saveTemplateModel, setSaveTemplateModel] = useState('')
    const [deleteModal, setDeleteModal] = useState(false);
    const [modalData, setModalData] = useState({});
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    // const showActions = true;

    const handleChange = (e) => {
        setSaveTemplateModel(e?.target?.value)
    }
    const saveTemplate = async () => {
        const formData = new URLSearchParams();
        formData.append('role_name', saveTemplateModel)
        try {
            const response = await RoleList?.postbidRole(formData)
            if (response?.data?.status == 1) {
                await templateManageClose()
                await getbidRoleTender()
                setSaveTemplateModel('')
                notifySuccess(response?.data?.message)
            }
            else {
                notify(response?.response?.data?.message)
            }
        } catch (error) {
            console.log(error, 'Api Error')
        }
    }

    const DetelebidRoleTender = async (id) => {
        const formData = new URLSearchParams();
        formData.append('role_id', id)
        try {
            const response = await RoleList.deletebidRole(formData)
            if (response?.data?.status == 1) {
                // await getbidRoleTender()
                // await templateManageClose()
                notifySuccess(response?.data?.message)
            }
            else {
                notify(response?.response?.data?.message)

            }
        } catch (error) {
            console.log(error, 'Api Error')
        }
    }
    const showDeleteModal = (record) => {
        setDeleteModal(true)
        setModalData(record)
    }
    return (
        <div>
            <Modal title='Manage Role' className='bd_model_main setting_model'
                open={AddManageSetting}
                onCancel={templateManageClose}
                width={650}
                footer={[

                    <button key="submit" className='BG_mainButton' onClick={saveTemplate} disabled={saveTemplateModel !== '' ? false : true} >
                        Save Role
                    </button>

                ]}
            >
                <Form name="validateOnly" layout="vertical" autoComplete="off">
                    <Form.Item label='Role Name '>
                        <Input placeholder='Enter here...' onChange={handleChange} value={saveTemplateModel} />
                    </Form.Item>
                </Form>
                <div className='table__wrapper'>
                    <table className="table">
                        <thead>
                            <tr>
                                <th scope="col" width="10%">SNo.</th>
                                <th scope="col" width='20%'>User Role</th>
                                <th scope="col" width='55%'></th>
                                <th scope="col" width='15%'>Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            {
                                roleList?.map((item, index) => {
                                    return (
                                        <React.Fragment key={index}>
                                            <tr>
                                                <th scope="row">{index + 1}</th>
                                                <td>{item?.role_name}</td>
                                                <td>
                                                    <div className="infoDetText">
                                                        {item?.deletable !== '1' ? '  Default Role Cannot Be Deleted.' : '  Custom Role.'}

                                                    </div>
                                                </td>
                                                <td>
                                                    {
                                                        item?.deletable !== '1' ?
                                                            <></>
                                                            :
                                                            <div onClick={() => showDeleteModal(item)} style={{ cursor: 'pointer' }}>
                                                                <DeleteOutlined />
                                                            </div>
                                                    }

                                                </td>
                                            </tr>
                                        </ React.Fragment>
                                    )
                                })
                            }


                        </tbody>
                    </table>
                </div>
            </Modal>
            <Delete title={'Role'} open={deleteModal} handleDelete={DetelebidRoleTender} onClose={() => setDeleteModal(false)} modalData={modalData} />

        </div>
    )
}

export default SettingManageModel;

