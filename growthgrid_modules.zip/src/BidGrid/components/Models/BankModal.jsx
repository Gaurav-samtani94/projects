// @ts-nocheck
import React, { useEffect, useState } from "react";
import { Modal, Form, Input, Button, Flex } from 'antd';
import { TenderList } from "Services/bidgrid/master/tenderscope/tenderscope";
import { toast } from 'react-toastify';
import { BankApi } from "Services/bidgrid/master/bank/BidBank";


const BankModal = (props) => {
    const { open, handleClose, getreminderModalRowData, BankList, setSpinner } = props;
    const [showNotification, setShowNotification] = useState(false);
    const [editModalData, setEditModalData] = useState({
        bank_name: '',
        amount_allowed: '',
    })
    const [form] = Form.useForm();
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const handleInputChange = (name, value) => {
        setEditModalData({ ...editModalData, [name]: value });
    }

    const handleSubmit = async (val) => {
        setShowNotification(true);
        // if(editModalData?.amount_allowed !== '' && editModalData?.amount_allowed !== ''){
        const formData = new URLSearchParams();
        formData.append('bank_id', getreminderModalRowData?.id)
        formData.append("bank_name", val?.bank_name)
        formData.append("amount_allowed", val?.amount_allowed)
        try {
            const response = await BankApi.putBank(formData)
            if (response?.data?.status == 1) {
                setSpinner(true)
                notifySuccess("Bank Name Updated Successfully")
                await BankList(false)
                handleClose()
            }
            else {
                setSpinner(false)
                notify(response?.response?.data?.message)
            }
        } catch (error) {
            setSpinner(false)
        }
        // }else{
        //     if (!showNotification) {
        //         notify("All fields are required !!");
        //         setShowNotification(true);
        //         setSpinner(false)

        //         setTimeout(() => {
        //             setShowNotification(false);
        //         }, 2500);
        //     }
        // }


        setTimeout(() => {
            setShowNotification(false);
        }, 2000);

    }

    const handleReset = () => {
        setEditModalData({
            bank_name: '',
            amount_allowed: '',
        })
        form.resetFields()

    };

    const predefinedValues = () => {
        let newObj = {
            id: getreminderModalRowData?.id ? getreminderModalRowData?.id : '',
            bank_name: getreminderModalRowData?.bank_name ? getreminderModalRowData?.bank_name : '',
            amount_allowed: getreminderModalRowData?.amount_allowed ? getreminderModalRowData?.amount_allowed : '',
        }
        setEditModalData((prevState) => {
            return {
                ...prevState,
                ...newObj,
            };
        });
        form.setFieldsValue(newObj);

    }

    useEffect(() => {
        if (getreminderModalRowData?.id) {
            predefinedValues()
        }
    }, [getreminderModalRowData])
    const handlePrefixChange = (name, e) => {
        const trimmedValue = e?.target?.value?.trimStart();
        form.setFieldsValue({ [name]: trimmedValue });
    };
    const handleBankChange = (name, e) => {
        const trimmedValue = e?.target?.value?.trimStart();
        form.setFieldsValue({ [name]: trimmedValue });
    };

    return (
        <>
            <div>
                <Modal
                    title={` Edit ${props?.title}`}
                    centered
                    className='bd_model_main'
                    open={props?.open}
                    onOk={props?.handleClose}
                    onCancel={props?.handleClose}
                    footer={null}
                >
                    <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={handleSubmit}>
                        <Form.Item label="Bank Name:" name='bank_name' rules={[{ required: true, message: 'Bank name is required' }]}>
                            <Input
                                // value={editModalData?.bank_name}
                                placeholder='Enter here'
                                // onChange={(e) => handleInputChange('bank_name', e.target.value)}
                                onChange={(e) => handleBankChange('bank_name', e)}
                            />
                        </Form.Item>
                        <Form.Item label='Amount Allowed:' name='amount_allowed' rules={[{ required: true, message: 'Amount is required' },
                        { pattern: /^[0-9]+$/, message: 'Please enter a valid number' }]}>
                            <Input
                                // onChange={(e) => handleInputChange('amount_allowed', e.target.value.replace(/[^0-9]/g, ''))}
                                // onKeyDown={handleNumericInput}
                                // value={editModalData?.amount_allowed}
                                placeholder='Enter here'
                                type="number"
                                onChange={(e) => handleBankChange('amount_allowed', e)}
                            />
                        </Form.Item>
                        <Flex justify='flex-end' align='center'>
                            <Button key="back"
                                onClick={() => handleReset()}
                                className='BG_ghostButton' >
                                Reset
                            </Button>
                            <button key="submit" style={{ marginLeft: '20px' }} className='BG_mainButton' disabled={showNotification}>
                                Submit
                            </button>
                        </Flex>
                    </Form>

                </Modal>

            </div>

        </>
    )
}

export default BankModal;