// @ts-nocheck
import React from 'react';
import { Button, Modal, Form, Input, Select, DatePicker } from 'antd';
import { Down, ToRight } from '@icon-park/react';
import { useSelector } from 'react-redux';

const EditTenderModel = (props) => {
    const { open, handleClose } = props;
    return (
        <>
            <div>
                <Modal
                    // title={` Edit ${props?.title}`} 
                    className='bd_model_main'
                    open={open}
                    onOk={handleClose}
                    onCancel={handleClose}
                    footer={[
                        <button key="back"
                            // onClick={() => handleReset(true)}
                            className='BG_ghostButton' >
                            Reset
                        </button>,
                        <button key="submit"
                            // onClick={handleSubmit}
                            className='BG_mainButton'
                        // disabled={disableBtn}
                        >
                            Submit
                        </button>

                    ]}

                >
                    <Form name="validateOnly" layout="vertical" autoComplete="off"
                    // onKeyDown={handleKeyPress}
                    >
                        <Form.Item label="Reminder Subject" rules={[{ required: true, message: 'Reminder subject is required' }]}>
                            <Input
                                name='unit_name'
                                // value={editModalData?.unit_name}
                                placeholder='Enter here...'
                            // onChange={(e) => handleSelectChange('unit_name', e.target.value)}
                            />
                        </Form.Item>
                        <Form.Item label="TimeZone:">
                            <Select
                                showSearch
                                name='timezone_id'
                                // value={editModalData?.timezone_id}
                                // onChange={(value) => handleSelectChange('timezone_id', value)}
                                // options={businessUnitTimezone?.map((item, index) => {
                                //     return {
                                //         value: item?.id,
                                //         label: item?.timezone_name
                                //     }
                                // })}
                                placeholder="Select TimeZone"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            >
                            </Select>
                        </Form.Item>
                        <Form.Item label="Country:">
                            <Select
                                showSearch
                                // value={editModalData?.country_id}
                                // onChange={(value) => handleSelectChange('country_id', value)}
                                name='country_id'
                                // options={BidCountry?.map((item, index) => {
                                //     return {
                                //         value: item?.id,
                                //         label: item?.country_name
                                //     }
                                // })}
                                placeholder="Select Country"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            >

                            </Select>
                        </Form.Item>
                        <Form.Item label="State:">
                            <Select
                                showSearch
                                name='state_id'
                                // value={editModalData?.state_id}
                                // onChange={(value) => handleSelectChange('state_id', value)}
                                // options={statelist?.map((item, index) => {
                                //     return {
                                //         value: item?.id,
                                //         label: item?.state_name
                                //     }
                                // })
                                placeholder="Select State"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            >

                            </Select>
                        </Form.Item>
                        <Form.Item label="City:">
                            <Select
                                showSearch
                                // value={editModalData?.city_id}
                                // onChange={(value) => handleSelectChange('city_id', value)}
                                name='city_id'
                                // options={cityList?.map((item, index) => {
                                //     return {
                                //         value: item?.id,
                                //         label: item?.city_name
                                //     }
                                // })}
                                placeholder="Select City"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            >

                            </Select>
                        </Form.Item>
                    </Form>

                </Modal>
            </div>
        </>
    )
}

export default EditTenderModel;