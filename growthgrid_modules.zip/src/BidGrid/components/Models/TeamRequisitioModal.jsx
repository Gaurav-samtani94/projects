// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { PlusOutlined, ArrowDownOutlined } from '@ant-design/icons';
import { Down } from '@icon-park/react';
import { Modal, Upload, Form, Select, Row, Col, Flex, Button, DatePicker, Input, Card } from 'antd';
import { TeamReqApi } from 'Services/bidgrid/tenderList/TeamReqApi';
import { useParams } from 'react-router-dom';
import dayjs from 'dayjs';
import { toast } from 'react-toastify';
import { docurlchat } from 'utils/configurable';
// Resume upload
const uploadButton = (
    <button
        style={{
            border: 0,
            background: 'none',
        }}
        type="button"
    >
        <PlusOutlined />
        <div
            style={{
                marginTop: 8,
            }}
        >
            Upload
        </div>
    </button>
);

const initialState = {
    category_id: null,
    designation_id: null,
    fullname: '',
    date_of_birth: null,
    working_exp: null,
    remarks: '',
    can_resume: []
}
const { Option } = Select;

const TeamRequisitioModal = (props) => {
    const { teamRequisitionOpen, setTeamRequisitionOpen, categories, record, getTeamreqList, setRecord, getReqList, fetchRqListByDesg, setViewResume } = props
    const [drawerData, setDrawerData] = useState(initialState)
    const [designations, setDesignations] = useState([])
    // const [fileList, setFileList] = useState([]);
    const [error, setError] = useState(false)
    const [form] = Form.useForm();
    const { id } = useParams()
    const [loadingResume, setLoadingResume] = useState(false);

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const handleChangeDrawer = (name, value) => {

        if (name === 'category_id') {
            setDrawerData(prevState => ({
                ...prevState,
                designation_id: null,
                [name]: value
            }));
            form.setFieldsValue({
                designation_id: null
            })
        } else {
            setDrawerData(prevState => ({
                ...prevState,
                [name]: value
            }));
        }

        if (name === 'date_of_birth') {
            setError(false)

        }

    }
    const documentBlobReq = async (doc_name, apiUrl) => {
        const fullUrl = window.location.href;
        const urlObject = new URL(fullUrl);
        const protocol = urlObject.protocol;
        const hostname = urlObject.host;
        const domain = `${protocol}//${hostname}`;
        const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
        const response = await fetch(proxyUrl)
        const blobData = await response?.blob()
        const fileURL = window.URL.createObjectURL(blobData);
        let alink = document.createElement("a");
        alink.href = fileURL;
        alink.download = doc_name;
        alink.click();
    }
    const documentFileDownload = (item) => {
        const apiUrl = `${docurlchat}${item?.file_path}/${item?.can_resume}`;
        documentBlobReq(item?.can_resume, apiUrl)
    }

    // fetch designation

    const fetchDesignation = async () => {
        try {
            const formData = new URLSearchParams()
            formData.append('category_id', drawerData?.category_id)
            const response = await TeamReqApi.getRequisitionDesignationList(formData)
            if (response?.data?.status === '1') {
                setDesignations(response?.data?.data)
            } else {
                setDesignations([])
            }
        } catch (error) {
            setDesignations([])
        }
    }

    // edit upload resume

    const fetchRqEditData = async () => {
        try {
            const formData = new URLSearchParams()
            formData.append('project_id', id)
            formData.append('team_id', record?.team_id)

            const response = await TeamReqApi.teamRqEdit(formData)
            if (response?.data?.success == true) {

                // setRqEditData(response?.data?.data)
                form.setFieldsValue(response?.data?.data)

                const newObj = {
                    ...response?.data?.data,
                    can_resume: [],
                    // date_of_birth: dayjs(response?.data?.data?.date_of_birth).format('YYYY-MM-DD')

                }

                setDrawerData(newObj)

            } else {
                // setRqEditData([])
            }
        } catch (error) {
            // setRqEditData([])
        }
    }

    const handleKeyContainOnlyNumbers = (e) => {
        const allowedChars = /[0-9.]/;
        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        }
        else if (e.key === 'Enter') {
            e.preventDefault();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    }

    const handleRemove = (item) => {
        const newFileList = drawerData?.can_resume.filter((f) => f.uid !== item.uid);
        setDrawerData(prev => ({
            ...prev,
            can_resume: newFileList
        }));
    };
    const handleResume = async (value) => {
        if (record?.team_id !== null && drawerData?.date_of_birth !== null) {
            setLoadingResume(true)
            try {
                const formData = new FormData()
                formData.append('project_id', id)
                formData.append('tm_rq_members_id', record?.tm_rq_members_id)
                formData.append('team_id', record?.team_id)
                formData.append('category_id', record?.category_id)
                formData.append('designation_id', record?.designation_id)
                formData.append('fullname', value?.fullname)
                formData.append('date_of_birth', dayjs(drawerData?.date_of_birth).format('YYYY-MM-DD'))
                formData.append('working_exp', Number(value?.working_exp))
                formData.append('remarks', value?.remarks)
                drawerData?.can_resume?.forEach((file, index) => {
                    formData.append('can_resume', file.originFileObj);
                });
                const response = await TeamReqApi.teamRqUpdate(formData)

                if (response?.data?.status === '1') {
                    notifySuccess('Upload Resume Updated Successfully')
                    setTeamRequisitionOpen(false)
                    await getTeamreqList()
                    await getReqList()
                    await fetchRqListByDesg()
                    form.resetFields()
                    setRecord({})
                    setDrawerData(initialState)
                    setViewResume(true)
                    setLoadingResume(false)
                } else {
                    notify(response?.response?.data?.message)
                    setLoadingResume(false)
                }
            } catch (error) {
                setLoadingResume(false)
                notify(error)
            }
        } else {
            if (drawerData?.date_of_birth !== null) {
                setLoadingResume(true)
                try {

                    const formData = new FormData()
                    formData.append('project_id', id)
                    formData.append('tm_rq_members_id', record?.id)
                    formData.append('category_id', record?.category_id)
                    formData.append('designation_id', record?.designation_id)
                    formData.append('fullname', value?.fullname)
                    formData.append('date_of_birth', dayjs(drawerData?.date_of_birth).format('YYYY-MM-DD'))
                    formData.append('working_exp', Number(value?.working_exp))
                    formData.append('remarks', value?.remarks)
                    drawerData?.can_resume?.forEach((file, index) => {
                        formData.append('can_resume', file.originFileObj);
                    });
                    const response = await TeamReqApi.teamRqUploadResume(formData)

                    if (response?.data?.status === '1') {
                        notifySuccess('Upload Resume Successfully')
                        setTeamRequisitionOpen(false)
                        setLoadingResume(false)
                        await getTeamreqList()
                        // await getReqList()
                        form.resetFields()
                        setRecord({})
                        setDrawerData(initialState)
                    } else {
                        notify(response?.response?.data?.message)
                        setLoadingResume(false)
                    }
                } catch (error) {
                    setLoadingResume(false)
                    // notify(error)
                    console.log(error)
                }
            }

        }


    }

    const handleReset = () => {
        form.resetFields()
    }

    const handleDate = () => {
        if (drawerData?.date_of_birth !== null) {
            setError(false)
        } else {
            setError(true)
        }
    }

    useEffect(() => {
        if (record?.team_id) {
            fetchRqEditData()
        }

    }, [record])

    useEffect(() => {
        if (drawerData?.category_id !== null) {
            fetchDesignation()
        }
    }, [drawerData?.category_id])

    return (
        <Modal title="Upload Resume" className="bd_model_main resumeModal"
            open={teamRequisitionOpen}
            onOk={() => setTeamRequisitionOpen(false)}
            onCancel={() => { setTeamRequisitionOpen(false); setRecord({}); form.resetFields(); setDrawerData(initialState) }}
            footer={null}
        >
            <Form name="validateOnly" layout="vertical" autoComplete="off" form={form} onFinish={handleResume}>
                <Row gutter={30}>
                    <Col span={12}>
                        <Form.Item label="Full Name:" name='fullname' rules={[{ required: true, message: "please enter full name" }]}>
                            <Input value={drawerData?.fullname} onChange={(e) => handleChangeDrawer('fullname', e?.target?.value)} placeholder='Enter full name' />
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item label={<span><span style={{ color: '#ff4d4f' }}>*</span>DOB:</span>}>
                            <DatePicker
                                name='date_of_birth'
                                // value={drawerData?.date_of_birth}
                                value={drawerData?.date_of_birth !== null ? dayjs(drawerData?.date_of_birth) : null}
                                onChange={(e) => handleChangeDrawer('date_of_birth', e)}
                                placeholder='Enter Dob'
                                disabledDate={(current) => current && current > dayjs().startOf('day')}

                            />
                            {
                                error &&
                                <div className="col-md-12" style={{ color: '#ff4d4f' }}>Please Select DOB</div>
                            }
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item onKeyPress={handleKeyContainOnlyNumbers} label="Working Experience:" name='working_exp' rules={[{ required: true, message: "please enter work exp." }]}>
                            <Input value={drawerData?.working_exp} onChange={(e) => handleChangeDrawer('working_exp', e?.target?.value)} placeholder='Enter Working Experience' />
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item label="Remarks:" name='remarks' rules={[{ required: true, message: "please enter remarks" }]}>
                            <Input value={drawerData?.remarks} onChange={(e) => handleChangeDrawer('remarks', e?.target?.value)} placeholder='Enter remarks' />
                        </Form.Item>
                    </Col>

                </Row>

                <Form.Item style={{ marginBottom: 0 }} label="Resume" name='can_resume' rules={[{ required: true, message: 'Resume is required' }]}>
                    <Upload
                        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
                        listType="picture-card"
                        maxCount={1}
                        fileList={drawerData?.can_resume}
                        onChange={(info) => {
                            const fileList = info?.fileList?.map((file) => ({
                                uid: file?.uid,
                                name: file?.name,
                                status: 'done',
                                originFileObj: file?.originFileObj,
                            }));
                            handleChangeDrawer('can_resume', fileList);
                        }}
                        onRemove={handleRemove}
                    >
                        {drawerData?.can_resume && drawerData?.can_resume.length >= 1 ? null : uploadButton}
                    </Upload>
                </Form.Item>

                {drawerData?.can_resume?.length === 0 && record?.team_id !== null &&
                    <React.Fragment >
                        <span > View Existing Document</span>
                        <Card
                            style={{
                                margin: 20,
                                paddingBlock: 0,
                            }}

                        >
                            <span style={{ display: 'flex', justifyContent: 'space-between' }} onClick={() => documentFileDownload(record)}> {record?.can_resume}  <ArrowDownOutlined /></span>
                        </Card>
                    </React.Fragment>

                }

                <Flex justify='flex-end' align='center' className='mt-4'>
                    <Button key="back" className='BG_ghostButton' onClick={handleReset}>
                        Reset
                    </Button>
                    <Button key="submit" className='BG_mainButton' style={{ marginLeft: '20px' }} type="primary" htmlType="submit" loading={loadingResume} disabled={loadingResume} onClick={handleDate}>
                        {record?.team_id !== null ? 'Update' : 'Upload'}

                    </Button>
                </Flex>

            </Form>
        </Modal>
    )
}

export default TeamRequisitioModal
