// @ts-nocheck
import React, { useEffect, useState } from "react";
import { Modal, Form, Input, Button, Flex } from 'antd';
import { toast } from 'react-toastify';
import { bidprefix } from "Services/bidgrid/master/Prefix/bidprefix";


const PrefixModal = (props) => {
    const { open, handleClose, getreminderModalRowData, getdata, setSpinner } = props;
    const [showNotification, setShowNotification] = useState(false);

    const [form] = Form.useForm();
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);


    const handleSubmit = async (val) => {
        console.log(val, 'val')
        setShowNotification(true);
        // if(editModalData?.amount_allowed !== '' && editModalData?.amount_allowed !== ''){
        try {
            const formData = new URLSearchParams();
            formData.append('prefix_id', getreminderModalRowData?.id)
            formData.append("prefix", val?.prefix)
            const response = await bidprefix.updatePrefix(formData)

            if (response?.data?.status == 1) {
                setSpinner(true)
                await getdata(false)
                // notifySuccess(response?.data?.message)
                notifySuccess('Prefix Updated Successfully')
                handleClose()

            }
            else {
                setSpinner(false)
                notify(response?.response?.data?.message)
            }

        } catch (error) {
            setSpinner(false)
        }

        setTimeout(() => {
            setShowNotification(false);
        }, 2000);

    }

    const handleReset = () => {

        form.resetFields()

    };

    const predefinedValues = () => {
        let newObj = {
            id: getreminderModalRowData?.id ? getreminderModalRowData?.id : '',
            prefix: getreminderModalRowData?.prefix ? getreminderModalRowData?.prefix : '',
        }

        form.setFieldsValue(newObj);

    }

    useEffect(() => {
        if (getreminderModalRowData?.id) {
            predefinedValues()
        }
    }, [getreminderModalRowData])



    return (
        <>
            <div>
                <Modal
                    title={` Edit ${props?.title}`}
                    className='bd_model_main'
                    open={open}
                    onOk={props?.handleClose}
                    onCancel={props?.handleClose}
                    footer={false}

                >
                    <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={handleSubmit}>
                        <Form.Item label="Prefix:" name='prefix' rules={[{ required: true, message: 'Prefix is required' }]}>
                            <Input
                                placeholder='Enter here'
                            />
                        </Form.Item>

                        <Flex justify='flex-end' align='center'>
                            <Button key="back"
                                onClick={() => handleReset()}
                                className='BG_ghostButton' >
                                Reset
                            </Button>
                            <button key="submit" style={{ marginLeft: '20px' }} className='BG_mainButton' disabled={showNotification}>
                                Submit
                            </button>
                        </Flex>
                    </Form>

                </Modal>

            </div>

        </>
    )
}

export default PrefixModal;