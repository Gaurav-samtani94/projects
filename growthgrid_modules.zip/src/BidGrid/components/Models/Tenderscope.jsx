// @ts-nocheck
import React, { useEffect, useState } from "react";
import { Modal, Form, Input, Button, Flex } from 'antd';
import { TenderList } from "Services/bidgrid/master/tenderscope/tenderscope";
import { toast } from 'react-toastify';


const TenderScopeModel = (props) => {
    const { open, handleClose, getreminderModalRowData, tenderList, setSpinner } = props;
    const [editModalData, setEditModalData] = useState({
        scope_name: '',
        order: '',
    })
    const [form] = Form.useForm();
    const [showNotification, setShowNotification] = useState(false);
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const handleInputChange = (name, value) => {
        setEditModalData({ ...editModalData, [name]: value });
    }

    const handleSubmit = async (value) => {
        setShowNotification(true);
        const formData = new URLSearchParams()
        formData.append('scope_id', getreminderModalRowData?.id)
        formData.append('scope_name', value?.scope_name)
        formData.append('order', value?.order)
        try {
            const response = await TenderList.updateTenderList(formData)
            if (response?.data?.status === '1') {
                setSpinner(true)
                // notifySuccess(response?.data?.message);
                notifySuccess("Tender Scope updated Successfully")
                await tenderList(false)

                handleClose();
            } else {
                setSpinner(false)
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            setSpinner(false)
        }
        setTimeout(() => {
            setShowNotification(false);
        }, 2000);
    }

    const handlenum = (e) => {
        const numregex = /[^0-9]/;
        if (e.key === 'Enter') {
            e.preventDefault();
            //   handleCreate();
        }
        else if (numregex.test(e.key) && e.key !== 'Backspace') {
            e.preventDefault();
        }
        else if (e.key !== 'Backspace' && e.target.selectionStart > 0) {
            e.preventDefault();
        }
        else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    }

    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            // createHandler()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleReset = () => {
        setEditModalData({
            scope_name: '',
            order: '',
        })
        form.resetFields()
        // handleClose()
    };

    // useEffect(() => {
    //     setEditModalData({
    //         id: getreminderModalRowData?.id ? getreminderModalRowData?.id : '',
    //         scope_name: getreminderModalRowData?.scope_name ? getreminderModalRowData?.scope_name : '',
    //         order: getreminderModalRowData?.order_sr ? getreminderModalRowData?.order_sr : '',
    //     })
    // }, [open])
    // console.log(getreminderModalRowData, "getreminderModalRowData")
    const predefinedValues = () => {
        let newObj = {
            id: getreminderModalRowData?.id ? getreminderModalRowData?.id : '',
            scope_name: getreminderModalRowData?.scope_name ? getreminderModalRowData?.scope_name : '',
            order: getreminderModalRowData?.order_sr ? getreminderModalRowData?.order_sr : '',
        }
        setEditModalData((prevState) => {
            return {
                ...prevState,
                ...newObj,
            };
        });
        form.setFieldsValue(newObj);

    }

    useEffect(() => {
        if (getreminderModalRowData?.id) {
            predefinedValues()
        }
    }, [getreminderModalRowData])
    const handleScopeChange = (name, e) => {
        const trimmedValue = e.target.value.trimStart();
        form.setFieldsValue({ [name]: trimmedValue });
    };

    return (
        <>
            <div>
                <Modal
                    title={` Edit ${props?.title}`}
                    centered
                    className='bd_model_main'
                    open={props?.open}
                    onOk={props?.handleClose}
                    onCancel={props?.handleClose}
                    footer={null}

                >
                    <Form form={form} name="validateOnly" layout="vertical" autoComplete="off" onFinish={handleSubmit} >
                        <Form.Item label="Tender Scope" name='scope_name' rules={[{ required: true, message: 'Tender Scope is required' }]}>
                            <Input
                                // value={editModalData?.scope_name}
                                placeholder='Enter here...' onChange={(e) => handleScopeChange('scope_name', e)}
                            // onChange={(e) => handleInputChange('scope_name', e.target.value)}
                            />
                        </Form.Item>
                        <Form.Item label='Tender Order' name='order' rules={[{ required: true, message: 'Tender order is required !!' }]}>
                            <Input
                                // onChange={(e) => handleInputChange('order', e.target.value)}
                                // onKeyDown={handlenum}
                                // value={editModalData?.order}
                                placeholder='Enter here...' type="number" onChange={(e) => handleScopeChange('order', e)}
                            />
                        </Form.Item>
                        <Flex justify='flex-end' align='center'>
                            <Button key="back"
                                onClick={() => handleReset()}
                                className='BG_ghostButton' >
                                Reset
                            </Button>
                            <button key="submit" style={{ marginLeft: '20px' }}
                                className='BG_mainButton' disabled={showNotification}>
                                Submit
                            </button>
                        </Flex>
                    </Form>

                </Modal>

            </div>

        </>
    )
}

export default TenderScopeModel;