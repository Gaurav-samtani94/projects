// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Modal, Form, Input, DatePicker, Button, Flex } from 'antd';
import { ReminderList } from 'Services/bidgrid/Reminder/bidreminder';
import { toast } from 'react-toastify';
import dayjs from 'dayjs';

const ReminderModel = (props) => {
  const { open, handleClose, getreminderModalRowData, getreminder } = props;
  const [editModalData, setEditModalData] = useState({
    reminder_date: '',
    reminder_subject: '',
    reminder_message: '',
  })
  const [form] = Form.useForm();
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);
  const [loadings, setLoadings] = useState(false);

  const handleInputChange = (name, value) => {
    setEditModalData({ ...editModalData, [name]: value });
  }

  const handleSubmit = async (value) => {
    setLoadings(true)
    try {
      const formData = new URLSearchParams()
      formData.append('reminder_id', getreminderModalRowData?.reminder_id)
      formData.append('reminder_subject', value?.reminder_subject)
      formData.append('reminder_message', value?.reminder_message)
      formData.append('reminder_date', dayjs(value?.reminder_date)?.format('YYYY-MM-DD'))

      const response = await ReminderList.updateReminder(formData)
      if (response?.data?.status === '1') {
        notifySuccess(response?.data?.message);
        await getreminder()
        setLoadings(false)
      } else {
        notify(response?.response?.data?.message);
        setLoadings(false)
      }
    } catch (error) {
      notify("Server Error!!");
      setLoadings(false)
    }
    handleClose();
  }

  const handleKeyPress = (e) => {
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      handleSubmit();
    } else if (e.key === ' ' && e.target.selectionStart === 0) {

      e.preventDefault();
    }
  };

  const handleReset = () => {
    setEditModalData({
      reminder_date: '',
      reminder_subject: '',
      reminder_message: '',
    })
    form.resetFields()
  };

  useEffect(() => {
    setEditModalData({
      reminder_id: getreminderModalRowData?.id ? getreminderModalRowData?.id : '',
      reminder_date: dayjs(getreminderModalRowData?.reminder_date) ? dayjs(getreminderModalRowData?.reminder_date) : '',
      reminder_subject: getreminderModalRowData?.reminder_subject ? getreminderModalRowData?.reminder_subject : '',
      reminder_message: getreminderModalRowData?.reminder_message ? getreminderModalRowData?.reminder_message : '',
    })
    form.setFieldsValue({
      // reminder_id: getreminderModalRowData?.id ? getreminderModalRowData?.id : '',
      reminder_date: dayjs(getreminderModalRowData?.reminder_date) ? dayjs(getreminderModalRowData?.reminder_date) : '',
      reminder_subject: getreminderModalRowData?.reminder_subject ? getreminderModalRowData?.reminder_subject : '',
      reminder_message: getreminderModalRowData?.reminder_message ? getreminderModalRowData?.reminder_message : '',
    })
  }, [open])
  return (
    <div>
      <Modal title={` Edit ${props?.title}`} className='bd_model_main'
        centered
        open={props?.open}
        onOk={props?.handleClose}
        onCancel={props?.handleClose}
        footer={null}
      >
        <Form form={form} name="validateOnly" layout="vertical" autoComplete="off" onKeyDown={handleKeyPress} onFinish={handleSubmit}>
          <Form.Item label="Reminder Date " name='reminder_date' rules={[{ required: true, message: 'Reminder date is required' }]}>
            <DatePicker placeholder='dd/mm/yyyy'
            // name='reminder_date'
            // value={editModalData?.reminder_date}
            // onChange={(e) => handleInputChange('reminder_date', e)}
            />
          </Form.Item>
          <Form.Item label="Reminder Subject" name='reminder_subject' rules={[{ required: true, message: 'Reminder subject is required' }]}>
            <Input

              value={editModalData?.reminder_subject}
              type='text' placeholder='Enter here...'
              onChange={(e) => handleInputChange('reminder_subject', e.target.value)}
            />
          </Form.Item>
          <Form.Item label='Reminder Message' name='reminder_message' rules={[{ required: true, message: 'Reminder message is required' }]}>
            <Input
              onChange={(e) => handleInputChange('reminder_message', e.target.value)}
              value={editModalData?.reminder_message}
              type='text' placeholder='Enter here...'

            />
          </Form.Item>
          <Flex justify='flex-end' align='center'>
            <Button key="back"
              onClick={() => handleReset()}
              className='BG_ghostButton' >
              Cancel
            </Button>
            <button key="submit" style={{ marginLeft: '20px' }} className='BG_mainButton' loading={loadings} disabled={loadings}>
              Submit
            </button>
          </Flex>
        </Form>

      </Modal>
    </div>
  );
}

export default ReminderModel;

