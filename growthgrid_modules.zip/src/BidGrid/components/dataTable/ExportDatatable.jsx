// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Form, Select } from 'antd';
import { Down } from '@icon-park/react';
import { View, Text, Document, Page, StyleSheet, PDFDownloadLink } from '@react-pdf/renderer';
import { saveAs } from 'file-saver';
import InvoicePdf from 'common/components/InvoicePdf/InvoicePdf';
import { pdf } from '@react-pdf/renderer';
import { useLocation } from 'react-router-dom';
const { Option } = Select;

const ExportDatatable = ({ printSectionRef, dataSource, columnLabels }) => {

    const location = useLocation()
    const pdfName = location?.pathname?.split('/')
    const getPdfName = pdfName[pdfName?.length - 1]
    const [originalContent, setOriginalContent] = useState(document.body.innerHTML)

    const generatePdfDocument = async (datasource, format) => {
        if (datasource?.length > 0) {
            const blob = await pdf((
                <InvoicePdf
                    dataSource={datasource}
                    columnLabels={columnLabels}
                    optionVal={format}
                />
            )).toBlob();
            saveAs(blob, String(getPdfName.charAt(0).toUpperCase() + getPdfName.slice(1)))
        } else {
            return;
        }
    };

    const generateCSVData = (data, columnLabels) => {
        if (data?.length > 0) {
            const csvData = [];
            const headerRow = ['Sr. No.', ...Object.keys(columnLabels).map(key => columnLabels[key].name)];
            csvData.push(headerRow);
            data?.forEach((item, index) => {
                const row = [index + 1, ...Object.keys(columnLabels).map(key => item[key])];
                csvData.push(row);
            });
            return csvData;
        }
    };

    const handleSelectExportData = (format) => {
        // console.log()
        if (format === 'PDF') {
            generatePdfDocument(dataSource, format);
        } else if (format === 'CSV') {
            if (dataSource?.length > 0) {
                const csvData = generateCSVData(dataSource, columnLabels);
                const csvContent = csvData.map(row => row.join(',')).join('\n');
                const csvBlob = new Blob([csvContent], { type: 'text/csv' });
                const csvUrl = URL.createObjectURL(csvBlob);
                window.open(csvUrl);
            }
        } else {
            // const printContents = printSectionRef.current.innerHTML;
            window.print()
            // const originalContents = document.body.innerHTML;
            // console.log(originalContents === printContents)
            // // document.body.innerHTML = printContents;
            // const printWindow = window.open("http://localhost:3000/bidgrid/master/bank", "anotherWindow", "width=1400,height=1500");
            // printWindow.addEventListener('load', function () {
            //     printWindow.document.write(printContents)
            //     setTimeout(() => {
            //         printWindow.print()
            //         printWindow.close()
            //     }, 1500);
            // })
            // printWindow.addEventListener('load', function () {
            // })
        }
    };


    return (
        <>

            <Form.Item className="export">
                <Select
                    placeholder="Export"
                    style={{ width: 120 }}
                    suffixIcon={<Down theme="outline" size="20" fill="#636363" />}
                    onChange={(e) => handleSelectExportData(e)}
                    options={[
                        { value: 'PDF', label: 'PDF' },
                        { value: 'CSV', label: 'CSV' },
                        { value: 'Print', label: 'Print' },
                    ]}
                />
            </Form.Item>

        </>
    )
}

export default ExportDatatable 
