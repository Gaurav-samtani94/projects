// @ts-nocheck
import React, { useEffect, useState } from 'react';
import "../../assets/css/app.scss"
import { Menu, Select, Table, Input, Form, Dropdown, Spin } from 'antd';
import { Down, More, Record } from '@icon-park/react';
import { ClockCircleOutlined, DownloadOutlined, CommentOutlined } from '@ant-design/icons';
import { saveAs } from 'file-saver';
import InvoicePdf from 'common/components/InvoicePdf/InvoicePdf';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { DashboardServiceApi } from 'Services/bidgrid/dashboard/DashboardAPi';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import GenerateRequest from '../Drawer/GenerateRequest';
import { pdfjs } from 'react-pdf';
import ExportDatatable from './ExportDatatable';
import Delete from '../modalDelete/Delete';
import AddRequestDrawer from '../Drawer/AddRequestDrawer';
import { docurlchat } from 'utils/configurable';

// import capitalizeExceptPrepositionsAndLowerCase from '../../../common/components/CapitalLetter/CapitalLetterWithoutPrepositions'
const { Search } = Input;
const { Option } = Select;
const RequestTable = (props) => {

  const { title, setgenerateReqDrawer, generateReqDrawer, dataSource, TenderId, setShowReminderModal,
    showActions, handleDelete, getPropDataVal, meetingSchedule, spinner, setSpinner,
    listRequest, columnLabels, setRecordData, recordData, employeeListVal } = props;
  const [pageSize, setPageSize] = useState(10);
  const [searchText, setSearchText] = useState('');
  const [sortedInfo, setSortedInfo] = useState({});
  const [modalData, setModalData] = useState({});
  const [deleteModal, setDeleteModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);


  // comment Drawer
  const [addRequestDrawer, setAddRequestDrawer] = useState(false)
  const [tenderRequestDetail, setTenderRequestDetail] = useState({})
  const { userBidInfo } = useSelector((state) => state?.userDetails)
  const location = useLocation();
  const val = location?.pathname;
  const str = val?.replace('/', '')

  const pdfName = location?.pathname?.split('/')
  const getPdfName = pdfName[pdfName?.length - 1]

  const filteredData = props?.dataSource?.filter((item) => {

    return Object.values(item).some((value) =>

      String(value).toLowerCase().includes(searchText.toLowerCase())
    );
  })
    ?.map((item, index) => ({
      ...item,
      srNo: pageSize * (currentPage - 1) + index + 1,
    }));

  const generatePdfDocument = async (datasource, format) => {
    const dataa = [datasource]
    if (dataa?.length === 1) {
      const blob = await pdfjs((
        <InvoicePdf
          dataSource={dataa}
          columnLabels={columnLabels}
          optionVal={format}
        />

      )).toBlob();
      saveAs(blob, String(getPdfName.charAt(0).toUpperCase() + getPdfName.slice(1)))
    }

  };

  const showDeleteModal = (record) => {
    setDeleteModal(true)
    setModalData(record)
  }

  const handleReminderModal = (record) => {
    setShowReminderModal(true)
  }

  const showCommentModal = async (record) => {
    setAddRequestDrawer(true)
    const formData = new URLSearchParams();
    formData.append('request_id', record?.id)
    try {
      const response = await DashboardServiceApi?.requestsDetail(formData)
      if (response?.data?.status == 1) {
        setTenderRequestDetail(response?.data?.data)
      }
      else {
        console.log(response?.response?.data?.message)
      }
    } catch (error) {
      console.log(error, 'Api Error')
    }
  }


  // setOpenMeeting
  const showModal = (record) => {
    getPropDataVal(record, true)

  };

  const handlePageSizeChange = (value) => {
    setPageSize(value);
    setCurrentPage(1);
  };

  const documentBlobReq = async (doc_name, apiUrl) => {
    const fullUrl = window.location.href;
    const urlObject = new URL(fullUrl);
    const protocol = urlObject.protocol;
    const hostname = urlObject.host;
    const domain = `${protocol}//${hostname}`;
    const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
    const response = await fetch(proxyUrl)
    const blobData = await response?.blob()
    const fileURL = window.URL.createObjectURL(blobData);
    let alink = document.createElement("a");
    alink.href = fileURL;
    alink.download = doc_name;
    alink.click();
  }

  const documentFileDownload = (item) => {
    const apiUrl = `${docurlchat}${item?.file_path}/${item?.file_data}`;
    documentBlobReq(item?.file_data, apiUrl)
  }



  const columns = [
    {
      title: 'Sr. No',
      dataIndex: 'srNo',
      key: 'srNo',
      sorter: (a, b) => a.srNo - b.srNo,
      sortOrder: sortedInfo.columnKey === 'srNo' && sortedInfo.order,
      width: 120,
    },

    ...Object.keys(columnLabels).map((key) => ({
      title: columnLabels[key].name,
      dataIndex: key,
      key: key,
      sorter: (a, b) => {
        const valueA = a[key];
        const valueB = b[key];

        if (key === 'tender_name') {
          const valueA = JSON.stringify(a[key]);
          const valueB = JSON.stringify(b[key]);

          if (typeof valueA === 'string' && typeof valueB === 'string') {
            // Sort strings
            return valueA.localeCompare(valueB);
          }
        }

        if (typeof valueA === 'string' && typeof valueB === 'string') {
          // Sort strings
          return valueA.localeCompare(valueB);
        } else if (valueA instanceof Date && valueB instanceof Date) {
          // Sort dates
          return valueA - valueB;
        } else if (valueA instanceof Number && valueB instanceof Number) {
          // Sort numbers
          return valueA - valueB;
        } else {
          // Fallback to default comparison
          return valueA - valueB;
        }
      },
      width: columnLabels[key].width,
      sortOrder: sortedInfo.columnKey === key && sortedInfo.order,
      render: (text) => ({
        children: capitalizeExceptPrepositionsAndLowerCase(text),
      }),
    })),
  ];


  if (showActions) {
    columns.push({
      title: 'Actions',
      key: 'actions',
      // @ts-ignore
      render: (record) => {
        return (
          <>
            <Dropdown
              placement='bottomRight'
              overlay={
                <Menu className="bd_tableAction">

                  {str === "bidgrid/request" ?
                    <>
                      <Menu.Item key="delete" onClick={() => showCommentModal(record)}>
                        <CommentOutlined />  Comment
                      </Menu.Item>
                    </>
                    :
                    <>
                    </>
                  }

                  {
                    record?.status !== "Approval" ?
                      <>
                        {
                          record?.created_by === userBidInfo?.id && (
                            <Menu.Item key="edit" onClick={() => showModal(record)} className='bd_view_btn'>
                              <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_221_1663)">
                                  <path d="M8.25 3H3C2.60218 3 2.22064 3.15804 1.93934 3.43934C1.65804 3.72064 1.5 4.10218 1.5 4.5V15C1.5 15.3978 1.65804 15.7794 1.93934 16.0607C2.22064 16.342 2.60218 16.5 3 16.5H13.5C13.8978 16.5 14.2794 16.342 14.5607 16.0607C14.842 15.7794 15 15.3978 15 15V9.75" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                  <path d="M13.875 1.87505C14.1734 1.57668 14.578 1.40906 15 1.40906C15.422 1.40906 15.8266 1.57668 16.125 1.87505C16.4234 2.17342 16.591 2.57809 16.591 3.00005C16.591 3.422 16.4234 3.82668 16.125 4.12505L9 11.25L6 12L6.75 9.00005L13.875 1.87505Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                </g>
                                <defs>
                                  <clipPath id="clip0_221_1663">
                                    <rect width="18" height="18" fill="white" />
                                  </clipPath>
                                </defs>
                              </svg>
                              Edit
                            </Menu.Item>

                          )
                        }
                      </>
                      :
                      <></>
                  }



                  <Menu.Item key="download" className='bd_view_btn' onClick={() => documentFileDownload(record)}>
                    <DownloadOutlined />
                    Download
                  </Menu.Item>

                  {str === `bidgrid/bdtenderdetails/${TenderId}` ?
                    (record?.created_by === userBidInfo?.id || record?.request_id === userBidInfo?.id) && (
                      <>
                        <Menu.Item key="delete" onClick={() => showDeleteModal(record)} className='bd_delete_btn'>
                          <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M2.25 4.5H3.75H15.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72064 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path d="M7.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path d="M10.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                          </svg>
                          Delete
                        </Menu.Item>
                      </>
                    )
                    :
                    <>

                    </>
                  }
                  {
                    (record?.created_by === userBidInfo?.id || record?.request_id === userBidInfo?.id) && (
                      <Menu.Item key="remainder" onClick={() => handleReminderModal(record)} className='bd_delete_btn'>
                        <ClockCircleOutlined />
                        Set Reminder

                      </Menu.Item>

                    )
                  }

                </Menu>

              }
            >
              <a onClick={(e) => e.preventDefault()}>
                <More theme="outline" size="25" fill="#95a6b6" strokeWidth={3} />
              </a>
            </Dropdown >
          </>

        )
      }

      ,
      width: 120,
    });
  }

  const selectOptions = {
    pdf: 'PDF',
    csv: 'CSV',
    print: 'Print',
  };

  const handleKeyPress = (e) => {
    const alphabeticChars = /[a-zA-Z]/;
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key) && alphabeticChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      //  handleProjectInfo()
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };



  return (
    <>
      <div className="table_wrap">
        <div className="tableHead_wrap">
          <Search
            placeholder="Search"
            allowClear
            onChange={(e) => setSearchText(e.target.value)}
            style={{ width: 340 }}
            onKeyPress={handleKeyPress}
          />
          <div className="showPrPage">
            {/* <ExportDatatable
              dataSource={dataSource}
              columnLabels={columnLabels}
            /> */}

            <div className="showPrPage">
              <Form.Item className="export">
                <ExportDatatable
                  dataSource={dataSource}
                  columnLabels={columnLabels}
                />
              </Form.Item>
            </div>

            <span>Showing</span>
            <Select
              suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
              defaultValue={pageSize}
              style={{ width: 70 }}
              onChange={handlePageSizeChange}
            >

              <Option value={10}>10</Option>
              <Option value={20}>20</Option>
              <Option value={30}>30</Option>
              <Option value={40}>40</Option>
            </Select>
            <span>of {filteredData?.length} results</span>

          </div>
        </div>

        <div className="tableBody_wrap">
          {spinner ? (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '40vh' }}>
              <Spin size="small" />
            </div>
          ) : (

            <Table
              bordered
              columns={columns}
              dataSource={filteredData?.length === 0 ? null : filteredData}
              pagination={{
                pageSize: pageSize,
              }}
              scroll={{ x: 'max-content' }}
              onChange={(pagination, filters, sorter) => setSortedInfo(sorter)}
            />
          )}
        </div>
      </div>

      <Delete title={title} open={deleteModal} handleDelete={handleDelete} getList={props.getList} onClose={() => setDeleteModal(false)} modalData={modalData} />

      <AddRequestDrawer documentBlobReq={documentBlobReq} onClose={() => setAddRequestDrawer(false)} setAddRequestDrawer={setAddRequestDrawer} addRequestDrawer={addRequestDrawer} tenderRequestDetail={tenderRequestDetail} employeeListVal={employeeListVal} />
      {
        str === "bidgrid/request" ?
          <GenerateRequest open={generateReqDrawer} onClose={() => setgenerateReqDrawer(false)} id={recordData?.tender_id} employeeListVal={employeeListVal} recordData={recordData} setRecordData={setRecordData} employeeListVal={employeeListVal} fetchRequestList={listRequest} />

          :
          <></>
      }

    </>

  )
}
export default RequestTable;



