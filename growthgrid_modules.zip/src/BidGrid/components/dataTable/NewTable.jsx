// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { Table, Input, Form, Row, Col, Space, Drawer, Dropdown, Select, DatePicker, InputNumber, Spin, Flex } from 'antd';
import { ToRight, Up, Down, Plus, More, ToLeft, Excel, Key } from '@icon-park/react';
import { DownOutlined } from '@ant-design/icons';
import DataTable from "BidGrid/components/dataTable/DataTable";
import pic from '../../assets/images/profile.jpg'
import pic2 from '../../assets/images/profile2.jpg'
import { useLocation } from 'react-router';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import DownloadOutlined from '@ant-design/icons';
const { Search } = Input;
const { Option } = Select;
// const filteredData = [
//     {
//         srNo: 1,
//         tenderName: 'CEG',
//         employee: 'HO',
//         employeeRole: 'Aadhar Housing Finance Limited',
//         location: 'Building & Housing',
//         expirydate: 'Asian Development Bank',
//     }
// ]

const NewDataTable = () => {
    const [searchText, setSearchText] = useState('');
    const [pageSize, setPageSize] = useState(5);




    // const totalResults = 90
    // const showEditDrawer = (items) => {
    //     console.log(items, "items")

    // };
    // const getDropdownItems = (reference) => {
    //     return [
    //         {
    //             key: '1',
    //             label: (<div onClick={() => { showEditDrawer(reference) }}></div>),
    //         },
           
    //     ];
    // }

    // const changeOrder = (direction) => () => {
    //     setOrderDirection(direction);
    // };

    const columns = [
        {
            title: "SR NO",
            dataIndex: 'srNo',
        },
        {
            srNo: 1,
            title: "FILE OR FOLDER", 
        },
        {
            srNo: 2,
            title: "TITLE",
        },
        {
            srNo: 3,
            title: "MESSAGE",
        },
        {
            srNo: 5,
            title: "EMAIL TO",
     
        },
        {
            srNo: 6,
            title: "Expiry Date",
        },
        {
            srNo: 7,
            title: "Action",
            dataIndex: '',
            render: ((item) => {
                return (
                    <h1>
                    <DownloadOutlined /> 
                    </h1>
                )
            }
            ),
        }
    ];

    const handlePageSizeChange = (value) => {
        setPageSize(value);
    }

  

    const location = useLocation();

    const val = location?.pathname;
    const str = val?.replace('/', '');

    const selectOptions = {
        pdf: 'PDF',
        csv: 'CSV',
        print: 'Print',
    };


    return (
        <>
            {/* <Breadcrumb data={str} /> */}
            <div className="bd_workdistribution_main">
                {/* <div className="bd_workdistribution_header">
                    Work Load Distribution
                </div> */}
                <div className="bd_workdistribution_profile">
                    <div className="bd_workdistribution_profile_div" style={{display:'flex', justifyContent:'space-between'}}>
                      
                       <DatePicker  /> <DatePicker  />
                    </div>

                    <div className="bd_workdistribution_btn">
                        <button className='BG_ghostButton'>Submit</button>
                        {/* <button className='BG_mainButton'><span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-funnel" viewBox="0 0 16 16">
                            <path d="M1.5 1.5A.5.5 0 0 1 2 1h12a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.128.334L10 8.692V13.5a.5.5 0 0 1-.342.474l-3 1A.5.5 0 0 1 6 14.5V8.692L1.628 3.834A.5.5 0 0 1 1.5 3.5v-2zm1 .5v1.308l4.372 4.858A.5.5 0 0 1 7 8.5v5.306l2-.666V8.5a.5.5 0 0 1 .128-.334L13.5 3.308V2h-11z" />
                        </svg></span>Filter</button> */}
                    </div>

                </div>
                <div className="table_wrap">
                    <div className="tableHead_wrap">
                        <Search
                            placeholder="Search"
                            allowClear
                            onChange={(e) => setSearchText(e.target.value)}
                            style={{ width: 340 }}
                        />

                        <div className="showPrPage">
                            <Form.Item className="export">
                                <Select placeholder="Export" style={{ width: 120 }} suffixIcon={<Down theme="outline" size="20" fill="#636363" />}>
                                    {Object.entries(selectOptions).map(([value, label]) => (
                                        <Option key={value} value={value}>
                                            {label}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                            <span>Showing</span>
                            <Select
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                defaultValue={pageSize}
                                style={{ width: 70 }}
                                onChange={handlePageSizeChange}
                            >
                                <Option value={10}>10</Option>
                                <Option value={20}>20</Option>
                                <Option value={30}>30</Option>
                                <Option value={40}>40</Option>
                            </Select>
                    
                        </div>
                    </div>
                    {/* <DataTable /> */}
                    <div className="tableBody_wrap">
                        <Table
                            // bordered
                            columns={columns}
                            // dataSource={filteredData}
                            pagination={{
                                pageSize: pageSize,
                            }}
                        />
                    </div>

                </div>
            </div>
        </>
    );
}

// @ts-ignore
export default NewDataTable;
