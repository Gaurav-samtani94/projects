// @ts-nocheck
import React, { useRef, useState } from 'react';
import "../../assets/css/app.scss"
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { Menu, Select, Table, Input, Dropdown, Spin, Modal, Card, Collapse, Button } from 'antd';
import { Down, More } from '@icon-park/react';
import { ArrowDownOutlined, CopyOutlined, CarryOutFilled, ClockCircleOutlined, DownloadOutlined, SearchOutlined } from '@ant-design/icons';
import Model from '../Models/Model';
import Delete from '../modalDelete/Delete';
import ExportDatatable from './ExportDatatable';
import { bidProspective } from 'Services/bidgrid/prospective/bidProspective';
import { AddTenderList } from 'Services/bidgrid/add/AddTender';
import { saveAs } from 'file-saver';
import InvoicePdf from 'common/components/InvoicePdf/InvoicePdf';
import { pdf } from '@react-pdf/renderer';
import ReminderModel from '../Models/ReminderModel';
import TenderScopeModel from '../Models/Tenderscope';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import UnitModel from '../Models/AddUnitEditModel';
import { useSelector } from 'react-redux';
import MeetingModels from '../Models/MeetingModels';
import { PlusOutlined } from '@ant-design/icons';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import BankModal from '../Models/BankModal';
import ROUTES from 'Constants/Routes';
import PrefixModal from '../Models/PrefixModal';
import { docurlchat } from 'utils/configurable';

const { Search } = Input;
const { Option } = Select;
const DataTable = (props) => {

  const { title, setOpenMeeting, setOpenDrawer, setgenerateReqDrawer, generateReqDrawer, columnLabels, dataSource, TenderId, setShowReminderModal,
    handleOpenEditDrawer, showActions, showExpire, handleDelete, handleUpdate, sectorOptions, getPropData, tenderList, getreminder, getAddUnitHandler,
    businessUnitTimezone, ActionIcon, setDoctrolOpen, TenderDetailid, getPropDataVal, meetingSchedule, spinner, setSpinner, BankList, setTeamRequisitionOpen,
    teamReqAccordianShow, dataSourceAccordian, columnsAccordian, modalButtonName, infoId, getMeetinglist, tenderData, tenderKeywordApi, setRecords, getdata } = props;
  const [pageSize, setPageSize] = useState(10);
  const [tenderPageSize, setTenderPageSize] = useState(20);
  const printSectionRef = useRef(null);

  const [searchText, setSearchText] = useState('');
  // const [loadingData, setLoadingData] = useState(true);
  const [sortedInfo, setSortedInfo] = useState({});
  const [open, setOpen] = useState(false);
  const [modalData, setModalData] = useState({});
  const [deleteModal, setDeleteModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [viewModal, setViewModal] = useState(false)
  const [viewModalData, setViewModalData] = useState([])
  // const [spinner, setSpinner] = useState(false)
  const [reminderModalRowData, setReminderModalRowData] = useState({})
  const [tick, setTick] = useState()
  const [meeting, setmeeting] = useState(false)
  const [tenderSearch, setTenderSearch] = useState('')

  // comment Drawer
  const navigate = useNavigate()
  const { id } = useParams();
  const location = useLocation();
  const val = location?.pathname;
  const str = val?.replace('/', '')
  const { BidCountry } = useSelector((state) => state.bidDropdownCalVal)
  const { userBidInfo } = useSelector((state) => state?.userDetails)

  const pdfName = location?.pathname?.split('/')
  const getPdfName = pdfName[pdfName?.length - 1]

  const filteredData = props?.dataSource?.filter((item) => {

    return Object.values(item).some((value) =>

      String(value).toLowerCase().includes(searchText.toLowerCase())
    );
  })
    ?.map((item, index) => ({
      ...item,
      srNo: <>{str === 'bidgrid/livetender' ? tenderPageSize * (currentPage - 1) + index + 1 : pageSize * (currentPage - 1) + index + 1}</>,
    }));

  const generatePdfDocument = async (datasource, format) => {
    const dataa = [datasource]
    if (dataa?.length === 1) {
      const blob = await pdf((
        <InvoicePdf
          dataSource={dataa}
          columnLabels={columnLabels}
          optionVal={format}
        />

      )).toBlob();
      saveAs(blob, String(getPdfName.charAt(0).toUpperCase() + getPdfName.slice(1)))
    }

  };


  const showDeleteModal = (record) => {
    setDeleteModal(true)
    setModalData(record)
  }

  const ShowViewModal = (record) => {
    setViewModalData(record)
    setViewModal(true)
  }
  const handleReminderModal = (record) => {
    setShowReminderModal(true)
  }



  const getCity = async (data, val) => {
    const formData = new URLSearchParams();
    formData.append('state_id', data?.id);
    try {
      const res = await AddTenderList.getTenderCityList(formData)
      if (res?.data?.status === '1') {
        val['cityArr'] = res?.data?.data
        setReminderModalRowData(val)
        setOpen(true);
      } else {
        val['cityArr'] = []
        setReminderModalRowData(val)
        setOpen(true);
      }
    } catch (error) {
      val['cityArr'] = []
      setReminderModalRowData(val)
      setOpen(true);
    }

  }

  const handleDownloadPdf = (format, record) => {
    generatePdfDocument(record, format);
  }

  const getState = async (data, val) => {
    const formData = new URLSearchParams()
    formData.append('country_id', data?.id)
    try {
      const res = await bidProspective.getStateList(formData)
      if (res?.data?.status === '1') {
        val['stateArr'] = res?.data?.data
        // setReminderModalRowData(val)
        const cityData = res?.data?.data?.find(item => item?.state_name === val?.state)
        getCity(cityData, val)
      }
    } catch (error) {
      console.log(error, 'api erorr')
    }
  }

  const handleCopyLink = (data) => {
    setTick(data?.srNo)
    setTimeout(() => {
      setTick()
    }, 1000);
    const tempInput = document.createElement('input');
    tempInput.value = data?.link?.props?.href;
    document.body.appendChild(tempInput);
    tempInput.select();
    tempInput.setSelectionRange(0, 99999);
    document.execCommand('copy');
    document.body.removeChild(tempInput);
  };

  // setOpenMeeting
  const showModal = (record) => {
    const newStr = str?.split('/')?.slice(0, 2)?.join('/')
    if (str === `bidgrid/bdtenderdetails/${id}` && meetingSchedule === true) {
      setOpenMeeting?.(true)
    }
    if (str === `bidgrid/bdtenderdetails/${id}`) {
      getPropDataVal(record, true)
      return;
    }
    if (str === "bidgrid/livetender") {
      let str = ROUTES.BD_TENDERDETAILS.replace(':id', record?.id)
      navigate(str)
    }
    if (str === "bidgrid/master/addUnit") {
      let bidCountryFilterData = BidCountry?.find(item => item?.country_name === record?.country)
      getState(bidCountryFilterData, record);
      return
    }

    if (newStr === "bidgrid/bdtenderdetails" || newStr === "bidgrid/bankguarantee") {
      getPropDataVal(record, true)
      return
    }
    if (val === ROUTES.PREFIXNO) {
      setRecords(record)
      setOpen(false);
    }
    else {
      setReminderModalRowData(record)

      if (getPropData) {
        getPropData(record);
        setOpen(false);
      } else {
        setModalData(record);
        setOpen(true);

      }
    }
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handlePageSizeChange = (value) => {
    setTenderPageSize(value)
    setPageSize(value);
    setCurrentPage(1);

  };
  const documentBlobReq = async (doc_name, apiUrl) => {
    const fullUrl = window.location.href;
    const urlObject = new URL(fullUrl);
    const protocol = urlObject.protocol;
    const hostname = urlObject.host;
    const domain = `${protocol}//${hostname}`;
    const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
    const response = await fetch(proxyUrl)
    const blobData = await response?.blob()
    const fileURL = window.URL.createObjectURL(blobData);
    let alink = document.createElement("a");
    alink.href = fileURL;
    alink.download = doc_name;
    alink.click();
  }

  const documentDownload = (item) => {
    const apiUrl = `${docurlchat}${item?.doc_path}/${item?.doc_name}`;
    documentBlobReq(item?.doc_name, apiUrl)
  }
  const documentFileDownload = (item) => {
    const apiUrl = `${docurlchat}${item?.file_path}/${item?.file_data}`;
    documentBlobReq(item?.file_data, apiUrl)
  }

  const handleReminderModalUpdate = (updatedData) => {
    setOpen(false);
  };

  const customLocale = {
    sorter: {
      ascend: 'Click to sort by ascending order.',
      descend: 'Click to sort by descending order.',
    },
  };

  const columns = [
    {
      title: 'S. No',
      dataIndex: 'srNo',
      key: 'srNo',
      // sorter: (a, b) => a.srNo - b.srNo,
      sorter: (a, b) => {
        const valueA = parseInt(a?.srNo?.props?.children);
        const valueB = parseInt(b?.srNo?.props?.children);
        return valueA - valueB;
      },
      sortOrder: sortedInfo.columnKey === 'srNo' && sortedInfo.order,
      width: 120,
    },

    ...Object.keys(columnLabels).map((key) => ({
      title: columnLabels[key].name,
      dataIndex: key,
      key: key,
      sorter: (a, b) => {
        const valueA = a[key];
        const valueB = b[key];

        if (key === 'tender_name') {
          const valueA = JSON.stringify(a[key]);
          const valueB = JSON.stringify(b[key]);

          if (typeof valueA === 'string' && typeof valueB === 'string') {
            // Sort strings
            return valueA.localeCompare(valueB);
          }
        }

        if (typeof valueA === 'string' && typeof valueB === 'string') {
          // Sort strings


          return valueA.localeCompare(valueB);

        } else if (valueA instanceof Date && valueB instanceof Date) {
          // Sort dates
          return valueA - valueB;
        } else if (valueA instanceof Number && valueB instanceof Number) {
          // Sort numbers
          return valueA - valueB;
        } else {
          // Fallback to default comparison
          return valueA - valueB;
        }




      },
      width: columnLabels[key].width,
      sortOrder: sortedInfo.columnKey === key && sortedInfo.order,
      render: (text) => ({
        children: capitalizeExceptPrepositionsAndLowerCase(text),
      }),
    })),
  ];

  if (showExpire) {
    columns.push({
      title: 'Expiry Date',
      key: 'expireDate',
      sorter: (a, b) => a.expireDate - b.expireDate,
      sortOrder: sortedInfo.columnKey === 'expireDate' && sortedInfo.order,
      render: (record) => (
        <>
          <div className='expire_date_doc'>
            {record?.doc_expiry_days}
          </div>
        </>
      )
    })
  }



  const handlemeeting = (val) => {
    setmeeting(true)
    setModalData(val)

  }


  // if(val === ROUTES.val !== ROUTES?.PREFIX){

  // }


  if (showActions) {
    columns.push({
      title: 'Actions',
      key: 'actions',
      // @ts-ignore
      render: (record) => {
        if (record.hasOwnProperty('is_varified')) {
          if (record?.is_varified === "2") {
            return (
              <>
                {
                  str === "bidgrid/document" ? record?.all_emails === '-' ? record?.srNo === tick ?
                    <div className='doc_copy_arrow_div'> <CarryOutFilled /></div> :
                    <div className='doc_copy_arrow_div'><CopyOutlined className='doc_arrow_div_icon' onClick={() => handleCopyLink(record)} /> </div>
                    : <div className='doc_arrow_div'> <ArrowDownOutlined className='doc_arrow_div_icon' onClick={(e) => handleDownloadPdf(e, record)} />
                      <p>Download</p></div>
                    :
                    <>
                      <Dropdown
                        placement='bottomRight'
                        overlay={
                          <Menu className="bd_tableAction">


                            <Menu.Item key="edit" onClick={() => showModal(record)} className='bd_view_btn'>
                              <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_221_1663)">
                                  <path d="M8.25 3H3C2.60218 3 2.22064 3.15804 1.93934 3.43934C1.65804 3.72064 1.5 4.10218 1.5 4.5V15C1.5 15.3978 1.65804 15.7794 1.93934 16.0607C2.22064 16.342 2.60218 16.5 3 16.5H13.5C13.8978 16.5 14.2794 16.342 14.5607 16.0607C14.842 15.7794 15 15.3978 15 15V9.75" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                  <path d="M13.875 1.87505C14.1734 1.57668 14.578 1.40906 15 1.40906C15.422 1.40906 15.8266 1.57668 16.125 1.87505C16.4234 2.17342 16.591 2.57809 16.591 3.00005C16.591 3.422 16.4234 3.82668 16.125 4.12505L9 11.25L6 12L6.75 9.00005L13.875 1.87505Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                </g>
                                <defs>
                                  <clipPath id="clip0_221_1663">
                                    <rect width="18" height="18" fill="white" />
                                  </clipPath>
                                </defs>
                              </svg>
                              Edit
                            </Menu.Item>

                            <Menu.Item key="delete" onClick={() => showDeleteModal(record)} className='bd_delete_btn'>
                              <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M2.25 4.5H3.75H15.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                <path d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72064 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                <path d="M7.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                <path d="M10.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                              </svg>
                              Delete
                            </Menu.Item>


                          </Menu>

                        }
                      >
                        <a onClick={(e) => e.preventDefault()}>
                          <More theme="outline" size="25" fill="#95a6b6" strokeWidth={3} />
                        </a>
                      </Dropdown >
                    </>
                }
              </>
            )
          } else {
            return null;
          }
        } else {
          return (
            <>
              {
                str === "bidgrid/document" ? record?.all_emails === '-' ? record?.srNo === tick ?
                  <div className='doc_copy_arrow_div'> <CarryOutFilled /></div> :
                  <div className='doc_copy_arrow_div'><CopyOutlined className='doc_arrow_div_icon' onClick={() => handleCopyLink(record)} /> </div>
                  : <div className='doc_arrow_div'> <ArrowDownOutlined className='doc_arrow_div_icon' onClick={(e) => handleDownloadPdf(e, record)} />
                    <p>Download</p></div>
                  :
                  <>
                    {
                      record?.permanent_sys_adm !== '1' ?
                        <Dropdown
                          placement='bottomRight'
                          overlay={
                            <Menu className="bd_tableAction">
                              {
                                props?.locationVal === '/bidgrid/prospectivetender' ?
                                  <>
                                    <Menu.Item key="view" onClick={() => ShowViewModal(record)} className='bd_view_btn'>
                                      <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_1080_1716)">
                                          <path d="M0.666748 8.49996C0.666748 8.49996 3.33341 3.16663 8.00008 3.16663C12.6667 3.16663 15.3334 8.49996 15.3334 8.49996C15.3334 8.49996 12.6667 13.8333 8.00008 13.8333C3.33341 13.8333 0.666748 8.49996 0.666748 8.49996Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                          <path d="M8 10.5C9.10457 10.5 10 9.60457 10 8.5C10 7.39543 9.10457 6.5 8 6.5C6.89543 6.5 6 7.39543 6 8.5C6 9.60457 6.89543 10.5 8 10.5Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                        </g>
                                        <defs>
                                          <clipPath id="clip0_1080_1716">
                                            <rect width="16" height="16" fill="white" transform="translate(0 0.5)" />
                                          </clipPath>
                                        </defs>
                                      </svg>
                                      View
                                    </Menu.Item>
                                  </>
                                  :
                                  <></>
                              }
                              {
                                (str === `bidgrid/bdtenderdetails/${id}` && meetingSchedule === true && record?.bg_meeting_mom?.type !== 'button') ?

                                  <Menu.Item key="" className='bd_view_btn' onClick={() => handlemeeting(record)}>
                                    <AccessTimeIcon style={{ fontSize: "22" }} />
                                    Min .of meeting
                                  </Menu.Item> : <></>
                              }
                              {/* {
                str === `bidgrid/dashboard` ?

                  <Menu.Item key="" className='bd_view_btn' onClick={() => handleAddRequestDrawer(record?.id)}>
                    <RemoveRedEyeOutlinedIcon style={{ fontSize: "22" }} />

                    View Detail
                  </Menu.Item> : <></>
              } */}
                              {/* {
                str === `bidgrid/dashboard` ?

                  <Menu.Item key="" className='bd_view_btn' onClick={() => handleAddRequestDrawer(record?.id)}>
                    <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <g clip-path="url(#clip0_221_1663)">
                        <path d="M8.25 3H3C2.60218 3 2.22064 3.15804 1.93934 3.43934C1.65804 3.72064 1.5 4.10218 1.5 4.5V15C1.5 15.3978 1.65804 15.7794 1.93934 16.0607C2.22064 16.342 2.60218 16.5 3 16.5H13.5C13.8978 16.5 14.2794 16.342 14.5607 16.0607C14.842 15.7794 15 15.3978 15 15V9.75" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M13.875 1.87505C14.1734 1.57668 14.578 1.40906 15 1.40906C15.422 1.40906 15.8266 1.57668 16.125 1.87505C16.4234 2.17342 16.591 2.57809 16.591 3.00005C16.591 3.422 16.4234 3.82668 16.125 4.12505L9 11.25L6 12L6.75 9.00005L13.875 1.87505Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                      </g>
                      <defs>
                        <clipPath id="clip0_221_1663">
                          <rect width="18" height="18" fill="white" />
                        </clipPath>
                      </defs>
                    </svg>
                    Reply
                  </Menu.Item> : <></>
              } */}

                              {
                                str === 'bidgrid/employeelist' ?
                                  <>


                                    <Menu.Item key="edit" onClick={() => showModal(record)} className='bd_view_btn'>
                                      <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_221_1663)">
                                          <path d="M8.25 3H3C2.60218 3 2.22064 3.15804 1.93934 3.43934C1.65804 3.72064 1.5 4.10218 1.5 4.5V15C1.5 15.3978 1.65804 15.7794 1.93934 16.0607C2.22064 16.342 2.60218 16.5 3 16.5H13.5C13.8978 16.5 14.2794 16.342 14.5607 16.0607C14.842 15.7794 15 15.3978 15 15V9.75" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                          <path d="M13.875 1.87505C14.1734 1.57668 14.578 1.40906 15 1.40906C15.422 1.40906 15.8266 1.57668 16.125 1.87505C16.4234 2.17342 16.591 2.57809 16.591 3.00005C16.591 3.422 16.4234 3.82668 16.125 4.12505L9 11.25L6 12L6.75 9.00005L13.875 1.87505Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                        </g>
                                        <defs>
                                          <clipPath id="clip0_221_1663">
                                            <rect width="18" height="18" fill="white" />
                                          </clipPath>
                                        </defs>
                                      </svg>
                                      Edit
                                    </Menu.Item>



                                  </>

                                  :
                                  <>
                                    {
                                      str !== "bidgrid/dashboard" && str !== `bidgrid/bdtenderdetails/${infoId}` ?
                                        <Menu.Item key="edit" onClick={() => showModal(record)} className='bd_view_btn'>
                                          <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_221_1663)">
                                              <path d="M8.25 3H3C2.60218 3 2.22064 3.15804 1.93934 3.43934C1.65804 3.72064 1.5 4.10218 1.5 4.5V15C1.5 15.3978 1.65804 15.7794 1.93934 16.0607C2.22064 16.342 2.60218 16.5 3 16.5H13.5C13.8978 16.5 14.2794 16.342 14.5607 16.0607C14.842 15.7794 15 15.3978 15 15V9.75" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                              <path d="M13.875 1.87505C14.1734 1.57668 14.578 1.40906 15 1.40906C15.422 1.40906 15.8266 1.57668 16.125 1.87505C16.4234 2.17342 16.591 2.57809 16.591 3.00005C16.591 3.422 16.4234 3.82668 16.125 4.12505L9 11.25L6 12L6.75 9.00005L13.875 1.87505Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            </g>
                                            <defs>
                                              <clipPath id="clip0_221_1663">
                                                <rect width="18" height="18" fill="white" />
                                              </clipPath>
                                            </defs>
                                          </svg>
                                          Edit
                                        </Menu.Item>
                                        : <></>}
                                  </>
                              }


                              {str === `bidgrid/bdtenderdetails/${TenderId}` ?
                                <Menu.Item key="download" className='bd_view_btn' onClick={() => documentFileDownload(record)}>
                                  <DownloadOutlined />
                                  Download
                                </Menu.Item>
                                :
                                <></>
                              }
                              {str !== "bidgrid/livetender" && str !== "bidgrid/dashboard" && str !== "bidgrid/employeelist" && str !== `bidgrid/bdtenderdetails/${TenderId}` && str !== 'bidgrid/master/prefixNo' ?
                                <>
                                  <Menu.Item key="delete" onClick={() => showDeleteModal(record)} className='bd_delete_btn'>
                                    <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                      <path d="M2.25 4.5H3.75H15.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                      <path d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72064 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                      <path d="M7.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                      <path d="M10.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    Delete
                                  </Menu.Item>
                                </>
                                :
                                <>

                                </>
                              }
                              {str === `bidgrid/bdtenderdetails/${TenderId}` ?
                                <>
                                  <Menu.Item key="delete" onClick={() => handleReminderModal(record)} className='bd_delete_btn'>
                                    <ClockCircleOutlined />
                                    Remainder
                                  </Menu.Item>
                                </>
                                :
                                <>
                                </>
                              }

                            </Menu>

                          }
                        >
                          <a onClick={(e) => e.preventDefault()}>
                            <More theme="outline" size="25" fill="#95a6b6" strokeWidth={3} />
                          </a>
                        </Dropdown >
                        :
                        <></>

                    }
                  </>
              }
            </>
          )
        }

      },


      width: 120,
    });
  }



  const handleViewCancel = () => {
    setViewModal(false);
  };

  const handleKeyPress = (e) => {
    const alphabeticChars = /[a-zA-Z]/;
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key) && alphabeticChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      //  handleProjectInfo()
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };

  const handleSearchFun = () => {
    tenderKeywordApi(false, tenderSearch)
  }

  const handleResetFun = () => {
    tenderKeywordApi(false, '')
    setTenderSearch('')

  }

  return (
    <>

      <div className="table_wrap">
        <div className="tableHead_wrap">
          {
            str === 'bidgrid/livetender' || str === 'bidgrid/prospectivetender' ?

              <div className="table_wrap mt-0 position-relative">
                <Search
                  placeholder="Search"
                  allowClear={false}
                  className='specialInput'
                  value={tenderSearch}
                  onChange={(e) => setTenderSearch(e?.target?.value)}
                />
                <div className="search-btn-icon " onClick={() => handleSearchFun()}><button><SearchOutlined /></button>
                </div>
              </div>

              :
              <Search
                placeholder="Search"
                allowClear
                onChange={(e) => setSearchText(e.target.value)}
                style={{ width: 340 }}
                onKeyPress={handleKeyPress}
              />

          }

          <div className="showPrPage">
            {
              (str === 'bidgrid/livetender' || str === 'bidgrid/prospectivetender') &&
              <Button className='BG_ghostButton' onClick={() => handleResetFun()}>
                Reset
              </Button>

            }

            <ExportDatatable
              printSectionRef={printSectionRef}

              dataSource={dataSource}
              columnLabels={columnLabels}
            />
            <span>Rows per page</span>
            {
              str === 'bidgrid/livetender' ?
                <Select
                  suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                  defaultValue={tenderPageSize}
                  style={{ width: 70 }}
                  onChange={handlePageSizeChange}
                >
                  <Option value={20}>20</Option>
                  <Option value={50}>50</Option>
                  <Option value={100}>100</Option>
                  <Option value={500}>500</Option>
                </Select>
                :
                <Select
                  suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                  defaultValue={pageSize}
                  style={{ width: 70 }}
                  onChange={handlePageSizeChange}
                >

                  <Option value={10}>10</Option>
                  <Option value={20}>20</Option>
                  <Option value={30}>30</Option>
                  <Option value={40}>40</Option>
                </Select>
            }

            {/* <span>of {str === 'bidgrid/livetender' ? tenderData?.totalItems : filteredData?.length} results</span> */}
            <span>of {filteredData?.length} results</span>
            {/* {(filteredData?.length > pageSize) ? pageSize :filteredData?.length}/ */}
            {title == "Team Requisition" &&
              <button className='BG_mainButton' onClick={() => setTeamRequisitionOpen(true)}><PlusOutlined style={{ color: "white" }} /> Add Designation Category</button>
            }
          </div>
        </div>

        <div ref={printSectionRef} className="tableBody_wrap">
          {spinner ? (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '40vh' }}>
              <Spin size="small" />
            </div>
          ) : (

            <Table
              bordered
              columns={columns}
              dataSource={filteredData?.length === 0 ? null : filteredData}
              pagination={{
                pageSize: str === 'bidgrid/livetender' ? tenderPageSize : pageSize,
              }}
              scroll={{ x: 'max-content' }}
              locale={customLocale}
              onChange={(pagination, filters, sorter) => setSortedInfo(sorter)}
            />
          )}
        </div>
      </div>

      <div>
        {
          str !== "bidgrid/reminder" && str !== "bidgrid/master/addUnit" && str !== "bidgrid/master/tenderscope" && str !== "bidgrid/livetender" && str !== "bidgrid/master/bank" && str !== 'bidgrid/master/prefix' ?
            <Model title={title} sectorOptions={sectorOptions} handleUpdate={handleUpdate} open={open} getList={props?.getList} handleClose={handleClose} columnLabels={columnLabels} modalData={modalData} /> :
            str !== "bidgrid/master/addUnit" && str !== "bidgrid/master/tenderscope" && str !== "bidgrid/livetender" && str !== "bidgrid/master/bank" && str !== 'bidgrid/master/prefix' ?
              <ReminderModel title={title} open={open} handleClose={handleClose} getreminderModalRowData={reminderModalRowData} getPropData={handleReminderModalUpdate} setReminderModalRowData={setReminderModalRowData} getreminder={getreminder} /> :
              str !== "bidgrid/master/tenderscope" && str !== "bidgrid/livetender" && str !== "bidgrid/master/bank" && str !== 'bidgrid/master/prefix' ?
                <UnitModel title={title} open={open} handleClose={handleClose} getreminderModalRowData={reminderModalRowData} setReminderModalRowData={setReminderModalRowData} getAddUnitHandler={getAddUnitHandler} businessUnitTimezone={businessUnitTimezone} setSpinner={setSpinner} /> :
                str !== "bidgrid/livetender" && str !== "bidgrid/master/bank" && str !== 'bidgrid/master/prefix' ?
                  <TenderScopeModel title={title} open={open} handleClose={handleClose} getreminderModalRowData={reminderModalRowData} setReminderModalRowData={setReminderModalRowData} tenderList={tenderList} setSpinner={setSpinner} /> :
                  str !== "bidgrid/livetender" && str !== 'bidgrid/master/prefix' ?
                    <BankModal title={title} open={open} handleClose={handleClose} getreminderModalRowData={reminderModalRowData} setReminderModalRowData={setReminderModalRowData} BankList={BankList} setSpinner={setSpinner} />
                    : str === 'bidgrid/master/prefix' ?
                      <PrefixModal title={title} open={open} handleClose={handleClose} setSpinner={setSpinner} getreminderModalRowData={reminderModalRowData} setReminderModalRowData={setReminderModalRowData} getdata={getdata} /> : ''

        }
      </div>

      <Delete title={title} open={deleteModal} handleDelete={handleDelete} getList={props.getList} onClose={() => setDeleteModal(false)} modalData={modalData} />

      {/* View Modal */}

      <Modal title="View Document" open={viewModal} className="bd_model_main shareModal"
        centered
        onCancel={handleViewCancel}
        footer={null}
      >
        {
          viewModalData?.documentData?.length > 0 ?
            <>
              {
                viewModalData?.documentData?.map((item, index) => {
                  return (
                    <React.Fragment key={index}>
                      <Card
                        style={{
                          margin: 20,
                          paddingBlock: 0,
                        }}

                      >
                        <span style={{ display: 'flex', justifyContent: 'space-between' }} onClick={() => documentDownload(item)}> {item?.doc_name}  <ArrowDownOutlined /></span>
                      </Card>
                    </React.Fragment>
                  )
                })
              }
            </>
            :
            <>
              <p style={{ padding: '20px 0px 20px 15px' }}>Document Not Available</p>
            </>
        }
      </Modal>
      <MeetingModels getMeetinglist={getMeetinglist} modalData={modalData} meeting={meeting} setmeeting={setmeeting} onClose={() => setmeeting(false)} setOpen={setOpen} />


    </>

  )
}
export default DataTable;



