// @ts-nocheck
import React, { useEffect, useState, useRef } from 'react'
import { Select, Table, Input, Spin } from 'antd';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import { SearchOutlined } from '@ant-design/icons';
import ExportDatatable from './ExportDatatable';
import { Down, More } from '@icon-park/react';
import Delete from '../modalDelete/Delete';

const { Search } = Input;
const { Option } = Select;

const SettingTable = (props) => {
    const { title, handleDeleteApi, columnLabels, dataSource,
        showActions, spinner, record, deleteModal, setDeleteModal, actionBtns } = props
    const [page, setPage] = useState(1);
    const printSectionRef = useRef(null);

    const [rowPerPage, setRowPerPage] = useState(10);
    const [searchText, setSearchText] = useState('');
    const [sortedInfo, setSortedInfo] = useState({});
    const handleSearchFun = () => {

    }

    const handlePageSizeChange = (value) => {
        setRowPerPage(value)
        setPage(1);
    };

    const filteredData = dataSource?.filter((item) => {
        return Object.values(item).some((value) =>
            String(value).toLowerCase().includes(searchText.toLowerCase())
        );
    });


    const columns = [
        {
            title: 'Sr. No',
            dataIndex: 'srNo',
            key: 'srNo',
            width: 120,
            render: (text, record, index) => {
                const pageSize = rowPerPage;
                let maxPage = Math.ceil(filteredData.length / rowPerPage)
                let currentPage = page
                if (page > maxPage) {
                    currentPage = maxPage
                    setPage(maxPage);
                }
                const serialNumber = (currentPage - 1) * pageSize + index + 1;
                return <span>{serialNumber}</span>;
            }
        },
        ...Object.keys(columnLabels).map((key) => ({
            title: columnLabels[key].name,
            dataIndex: key,
            key: key,
            width: columnLabels[key].width,
            sorter: (a, b) => {
                const valueA = a[key];
                const valueB = b[key];
                if (typeof valueA === 'string' && typeof valueB === 'string') {
                    // Sort strings
                    return valueA.localeCompare(valueB);
                } else if (valueA instanceof Date && valueB instanceof Date) {
                    // Sort dates
                    return valueA - valueB;
                } else if (valueA instanceof Number && valueB instanceof Number) {
                    // Sort numbers
                    return valueA - valueB;
                } else {
                    // Fallback to default comparison
                    return valueA - valueB;
                }
            },
            sortOrder: sortedInfo.columnKey === key && sortedInfo.order,
            // showSorterTooltip: sortedInfo.columnKey === key && sortedInfo.order === 'ascend' ? 'Click to sort by ascending order.' : 'Click to sort by descending order.',

            render: key === 'code' ?
                (text) => ({
                    children: text,
                }) :
                (text) => ({
                    children: capitalizeExceptPrepositionsAndLowerCase(text),
                }),

        })),


        // ...Object.keys(columnLabels).map((key) => {
        //     console.log(key, 'key')
        //     return (
        //         <></>
        //     )


        // }),
    ]


    if (showActions) {
        columns.push(actionBtns);
    }

    return (
        <>
            <div className="table_wrap">
                <div className="tableHead_wrap">
                    <div className="table_wrap mt-0 position-relative">
                        <Search
                            placeholder="Search"
                            allowClear={false}
                            className='specialInput'
                            value={searchText}
                            onChange={(e) => setSearchText(e?.target?.value)}
                        />
                        <div className="search-btn-icon " onClick={() => handleSearchFun()}><button><SearchOutlined /></button>
                        </div>
                    </div>
                    <div className="showPrPage">
                        <ExportDatatable
                            printSectionRef={printSectionRef}
                            dataSource={dataSource}
                            columnLabels={columnLabels}
                        />
                        <span>Row per page</span>
                        <Select
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            defaultValue={rowPerPage}
                            style={{ width: 70 }}
                            onChange={handlePageSizeChange}
                        >
                            <Option value={10}>10</Option>
                            <Option value={20}>20</Option>
                            <Option value={30}>30</Option>
                            <Option value={40}>40</Option>
                        </Select>
                        <span>of {filteredData?.length} results</span>
                    </div>
                </div>

                <div ref={printSectionRef} className="tableBody_wrap">
                    {spinner ? (
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '40vh' }}>
                            <Spin size="small" />
                        </div>
                    ) : (

                        <Table
                            bordered
                            columns={columns}
                            dataSource={filteredData?.length === 0 ? null : filteredData}
                            pagination={{
                                current: page,
                                pageSize: rowPerPage,
                                total: filteredData?.length,
                                onChange: (newPage) => setPage(newPage),
                            }}
                            scroll={{ x: 'max-content' }}

                            onChange={(pagination, filters, sorter) => setSortedInfo(sorter)}
                        />
                    )}
                </div>
            </div>
            <Delete title={title} open={deleteModal} handleDelete={handleDeleteApi} onClose={() => setDeleteModal(false)} modalData={record} />
        </>
    )
}

export default SettingTable
