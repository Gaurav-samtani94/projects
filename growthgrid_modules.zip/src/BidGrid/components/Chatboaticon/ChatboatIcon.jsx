// @ts-nocheck
import React, { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { bidgridChatApi } from 'Services/bidgrid/chat/chatapi';
import ChatIcon from '@mui/icons-material/Chat';
import GgLogoweb from '../../assets/images/3.jpg';
import CloseIcon from '@mui/icons-material/Close';
import SendIcon from '@mui/icons-material/Send';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import CallMadeIcon from '@mui/icons-material/CallMade';
import ChatProfile from '../../assets/images/profile2.jpg';
import { useSelector } from 'react-redux';
import attach from "../../assets/images/attach.png";
import { Tooltip, Input, Tabs, Avatar } from 'antd';
import { ArrowLeftOutlined } from '@ant-design/icons';
import { DownloadOutlined } from '@ant-design/icons';
import ROUTES from "Constants/Routes";
import { UserOutlined } from '@ant-design/icons';
import { bidBaseUrl, chat_socket_url, docurlchat } from "utils/configurable";
import io from 'socket.io-client';
import { AnimatePresence, motion } from 'framer-motion'
const { Search } = Input;
const authorization = localStorage.getItem('bidToken');
const ChatboatIcon = () => {
    const { bidgridData } = useSelector((state) => state.loginData)
    // const socket = io(`${chat_socket_url}`, {
    //     transports: ['websocket'],
    //     query: {
    //         user_id: bidgridData?.data?.id
    //     }
    // });
    const { socket, isConnected } = useSelector((state) => state?.socket);
    const [onlineUsers, setOnlineUsers] = useState([]);
    const location = useLocation();
    const [isChatIconVisible, setIsChatIconVisible] = useState(true)
    const navigate = useNavigate()
    const [searchText, setSearchText] = useState('');
    const [openChat, setOpenChat] = useState(false);
    const [showChatIcon, setShowChatIcon] = useState(location?.pathname)
    const [chatOverlay, setChatOverlay] = useState(false)
    const [getuserlist, setuserListl] = useState([])
    const [Getgropelist, setGetgropelist] = useState([])
    const [messagesList, setchatingmsg] = useState([]);
    const [messagesListgroup, setmessagesListgroup] = useState([]);
    const [GetuserId, setuserId] = useState(null);
    const [message, setMessage] = useState('');
    const [getgroupmsg, setgroupmsg] = useState([]);
    const [recipient, setRecipient] = useState([]);
    // const [socket, setSocket] = useState(null);
    const [error, setError] = useState(null);
    const [hide, setHide] = useState(false)
    const [messages, setMessages] = useState([]);
    const [getsingleChatimageUpload, setsingleChatimageUpload] = useState([]);
    const [getsingleChatfileUpload, setsingleChatfileUpload] = useState([]);
    const [uploadFilePopup, setUploadFilePopup] = useState(false);
    const [modalImageSrc, setModalImageSrc] = useState();
    const [isImageModalOpen, setIsImageModalOpen] = useState(false);
    const [getsortinguserids, setsortinguserids] = useState(false);
    const [Gettypinguser, Settypinguser] = useState('');
    const [getidsFortick, SetidsFortick] = useState(null);
    const fileInputRef = useRef(null);
    useEffect(() => {
        if (isConnected) {
            socket.emit('join', bidgridData?.data?.id);
            socket.on('userStatus', (data) => {

                setOnlineUsers(data)
            });
        }
    }, [isConnected]);
    const [selectedFile, setSelectedFile] = useState(null);
    const handleFileChange = (event) => {
        setSelectedFile(event.target.files[0]);
    };
    const sendMessage = () => {

        if (socket && socket.connected) {
            if (((getsingleChatfileUpload.length > 0) || (getsingleChatimageUpload.length > 0)) && (GetuserId.user_id)) {
                const formData = new FormData();
                if (getsingleChatimageUpload.length > 0) {
                    getsingleChatimageUpload.forEach(fileWithPath => {
                        formData.append('file_type', fileWithPath.type);
                        formData.append('files', fileWithPath.file);
                    });
                } else if (getsingleChatfileUpload.length > 0) {
                    getsingleChatfileUpload.forEach(fileWithPath => {
                        formData.append('file_type', fileWithPath.type);
                        formData.append('files', fileWithPath.file);
                    });
                }
                formData.append('to_user_id', GetuserId.user_id);
                bidgridChatApi.singlecahtApifileuploading(formData)
                    .then(response => {
                        if (response?.data?.status == 1) {
                            const data_single_chat = response?.data?.data;
                            setUploadFilePopup(false);
                            setsingleChatimageUpload([])
                            setsingleChatfileUpload([])
                            socket.emit('send_file', { to_user_id: GetuserId.user_id, comp_id: bidgridData?.data?.comp_id, from_user_id: bidgridData?.data?.id, single_chat_image: data_single_chat[0].file_name, created_at: data_single_chat[0].created_at, file_type: data_single_chat[0].file_type, original_file_name: data_single_chat[0].original_file_name, authorization: authorization });
                        }
                    })
                    .catch(error => {
                        console.error("Error:", error);
                    });
            } else if (((getsingleChatfileUpload.length > 0) || (getsingleChatimageUpload.length > 0)) && (GetuserId.group_id)) {
                const formData = new FormData();
                if (getsingleChatimageUpload.length > 0) {
                    getsingleChatimageUpload.forEach(fileWithPath => {
                        formData.append('file_type', fileWithPath.type);
                        formData.append('files', fileWithPath.file);
                    });
                } else if (getsingleChatfileUpload.length > 0) {
                    getsingleChatfileUpload.forEach(fileWithPath => {
                        formData.append('file_type', fileWithPath.type);
                        formData.append('files', fileWithPath.file);
                    });
                }
                formData.append('group_id', GetuserId.group_id);
                bidgridChatApi.groupcahtApifileuploading(formData)
                    .then(response => {
                        if (response?.data?.status == 1) {
                            const data_single_chat = response?.data?.data;
                            setUploadFilePopup(false);
                            setsingleChatimageUpload([])
                            setsingleChatfileUpload([])
                            // socket.emit('joinRoom_file', getUserId.group_id);
                            socket.emit('send_group_file', {
                                group_id: GetuserId.group_id,
                                single_chat_image: data_single_chat[0].file_name,
                                file_type: data_single_chat[0].file_type,
                                created_at: data_single_chat[0].created_at,
                                original_file_name: data_single_chat[0].original_file_name,
                            });
                        }
                    })
                    .catch(error => {
                        console.error("Error:", error);
                    });

            }

            if ((message) && (GetuserId.user_id)) {
                socket.emit('send', { to_user_id: GetuserId.user_id, comp_id: bidgridData?.data?.comp_id, from_user_id: bidgridData?.data?.id, message, authorization: authorization });

                setMessages(
                    (prevMessages) =>
                        [...prevMessages, { from: 'Me', message }]);
                setMessage('');
            }
            if ((message) && (GetuserId.group_id)) {
                socket.emit('joinRoom', GetuserId.group_id);
                socket.emit('send_group_message', {
                    group_id: GetuserId.group_id,
                    message: message,
                });
                setMessages(
                    (prevMessages) =>
                        [...prevMessages, { from: 'Me', message }]);
                setMessage('');
            }



        } else {
            console.log(socket, 'not connected')
            setError('Socket is not connected');
        }
        setHide(true)

    };
    useEffect(() => {

        if (isConnected) {
            socket.on('connect_error', (err) => {
                setError(`Connection error: ${err.message}`);
            });

            socket.on('receive', (data) => {
                setRecipient([data]);
            });
            socket.on('received', (data) => {
                setRecipient([data]);
            });
            socket.on('receive_group_message', (data) => {
                setgroupmsg([data]);
            });
            socket.on('received_group_message', (data) => {
                setgroupmsg([data]);
            });

            socket.on('receive_sorting_ids', (data) => {
                setsortinguserids([data]);
            });
            socket.on('received_sorting_ids', (data) => {
                setsortinguserids([data]);
            });
            socket.on('received_typing_event_start', (data) => {
                Settypinguser(data)
            });
            socket.on('received_typing_event_end', (data) => {
                Settypinguser('')
            });
            socket.on('received_track_select_user', (data) => {
                SetidsFortick(data)

            })
        }

        // setSocket(socket);
        return () => {
            socket?.disconnect();
        };

    }, [isConnected]);
    useEffect(() => {
        if (isConnected) {
            socket.emit('typing_event_start', { to_user_id: GetuserId?.user_id, from_user_id: bidgridData?.data?.id });
        }
    }, [message]);

    useEffect(() => {
        if (isConnected && (!message)) {
            socket.emit('typing_event_End', { to_user_id: GetuserId?.user_id, from_user_id: bidgridData?.data?.id });
        }
    }, [!message]);
    const showImageModal = (imgUrl) => {
        setModalImageSrc(imgUrl)
        setIsImageModalOpen(true);
    };
    const handleImageModalOk = () => {
        setIsImageModalOpen(false);
    };


    const handleImageModalCancel = () => {
        setIsImageModalOpen(false);
    };

    const conversationDataRealTime_Single = async () => {
        try {

            if (recipient[0]?.from_user_id == bidgridData?.data?.id) {
                setchatingmsg([...messagesList, ...recipient]);
            }
            if (GetuserId?.user_id == recipient[0]?.from_user_id) {
                setchatingmsg([...messagesList, ...recipient]);
            }

        }
        catch (error) {
            console.log(error, 'api error');
        }

    };
    useEffect(() => {
        conversationDataRealTime_Single();
    }, [(recipient)]);

    const conversationDataRealTim_GRoup = async () => {
        try {
            // if (getgroupmsg[0].group_id === GetuserId?.group_id) {
            if (getgroupmsg.length > 1) {
                const newMessagesList = [...messagesListgroup];
                newMessagesList[0] = getgroupmsg[0];
                setmessagesListgroup([...newMessagesList, ...getgroupmsg.slice(1)]);
            } else if (getgroupmsg.length == 1) {
                setmessagesListgroup([...messagesListgroup, ...getgroupmsg]);
            }
            else {
                setmessagesListgroup([]);
            }
            // }
        } catch (error) {
            console.log(error, 'api error');
        }

    };
    useEffect(() => {
        conversationDataRealTim_GRoup();
    }, [getgroupmsg]);

    // const handleBotChat = () => {
    //     setBotChat(!botChat);
    //     setIsVisible(!isVisible);
    //     setIsVisiblehader(!isVisiblehader);
    //     setShowBotIcon(true);
    //     // setChatOverlay(true);
    //     setChatOverlay(!chatOverlay);
    //     getUserList()
    //     getgroupList()
    // };

    const handleOpenChatBox = () => {
        setIsChatIconVisible(false)
        getUserList()
        getgroupList()
    }

    const handleCloseChat = () => {
        getUserList();
        getgroupList();
        setOpenChat(false);

    }
    const handleBoatChange = () => {
        setIsChatIconVisible(true)
        navigate('chatboat', { state: { data: GetuserId } })
        // setBotChat(!botChat);
        // setChatOverlay(!chatOverlay);
    }

    const handleOpenChat = () => {
        setOpenChat(true);
    }

    const handleUserClick = (selectUserid) => {

        setuserId(selectUserid)
        setOpenChat(true);
    }

    const onChange = (key) => {
        console.log(key);
    };

    const messagesRef = useRef(null);
    useEffect(() => {
        if (messagesRef.current) {
            messagesRef.current.scrollTop = messagesRef.current.scrollHeight;
        }
    }, [messagesList, messagesListgroup]);

    const conversationDataHistory = async () => {
        try {
            if (GetuserId?.user_id) {
                const formData = new URLSearchParams()
                formData.append('user_id', GetuserId?.user_id)
                const response = await bidgridChatApi.getUserchatList(formData);
                if (response?.data?.status === "1") {
                    const secondObject = response?.data?.data
                    // setchatingmsg(secondObject);
                    setchatingmsg(secondObject);
                    if ((isConnected) && (!getidsFortick)) {
                        socket.emit('track_select_user', { to_user_id: GetuserId?.user_id, from_user_id: bidgridData?.data?.id });
                    }
                    SetidsFortick(null)

                } else {
                    setchatingmsg([]);
                }
            }

        } catch (error) {
            console.log(error, 'api error');
        }

    };
    useEffect(() => {
        conversationDataHistory();
    }, [GetuserId?.user_id]);
    useEffect(() => {
        if (getidsFortick) {
            conversationDataHistory();
        }
        SetidsFortick(null)
    }, [getidsFortick]);


    useEffect(() => {
        conversationDataRealTime_Single();
    }, [(recipient)]);
    const conversationDataHistorygroup = async () => {
        try {
            if (GetuserId?.group_id) {
                const formData = new URLSearchParams()
                formData.append('group_id', GetuserId?.group_id)
                const response = await bidgridChatApi.getGroupChatingList(formData);
                if (response?.data?.status === "1") {
                    const secondObject = response?.data?.data
                    setmessagesListgroup(secondObject);

                } else {
                    setmessagesListgroup([]);
                }

            }
        } catch (error) {
            console.log(error, 'api error');
        }

    };
    useEffect(() => {
        conversationDataHistorygroup()
    }, [GetuserId?.group_id])

    const getUserList = async () => {
        try {
            const response = await bidgridChatApi.chatuserList()
            if (response?.data?.status == "1") {
                setuserListl(response?.data?.data)
            } else {
                setuserListl([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }
    useEffect(() => {
        if (getsortinguserids) {
            getUserList();
        }
    }, [getsortinguserids]);
    const getgroupList = async () => {
        try {
            const response = await bidgridChatApi.getgroupList()
            if (response?.data?.status == "1") {
                setGetgropelist(response?.data?.data)
            } else {
                setGetgropelist([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }
    useEffect(() => {
        if (getgroupmsg) {
            getgroupList()
        }
    }, [getgroupmsg])


    const filteredgroupList = Getgropelist?.filter((item) =>
        item?.chats_group_member?.chats_mstr_group?.group_name?.toLowerCase()?.includes(searchText?.toLowerCase())
    );

    const filtereduserList = getuserlist?.filter((item) =>
        item?.user?.userfullname?.toLowerCase()?.includes(searchText.toLowerCase())
    );
    function valueExistsInArrays_online(array, value) {
        if (!array || !array.data || array.data.length === 0) {
            return false;
        }
        const data_match = value;
        const isIdMatched = array.data.includes(data_match);
        return isIdMatched;
    }

    const formatDateTime = (dateString) => {
        const date = new Date(dateString);
        const today = new Date();
        const options = { hour12: true, hour: 'numeric', minute: 'numeric' };
        if (
            date.getDate() === today.getDate() &&
            date.getMonth() === today.getMonth() &&
            date.getFullYear() === today.getFullYear()
        ) {
            return date.toLocaleTimeString('en-US', options);
        } else {
            return date.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: 'numeric', hour12: true });
        }
    };
    const exists_online_offline = valueExistsInArrays_online(onlineUsers, `${GetuserId?.user_id}`);
    const handleDownload = (fileUrl) => {
        fetch(fileUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.blob();
            })
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', '');
                document.body.appendChild(link);
                link.click();
                link.parentNode.removeChild(link);
            })
    };
    const handleButtonClick = () => {
        document.getElementById('fileInput').click();
    };
    const items = [
        {

            key: '1',
            label: ' User',
            children:
                <div className="chat_message_div" >
                    {(filtereduserList.length > 0) ? (

                        filtereduserList.map((item, index) => (
                            <div className="chat_bot_msg" onClick={() => handleUserClick({ user_id: item.user_id, username: item?.user?.userfullname, file_name: (item?.user?.profileimg) ? item?.user?.profileimg : "", file_path: (item?.user?.profileimg_path) ? item?.user?.profileimg_path : '' })} key={index}>
                                <div className="chatProfile_image">
                                    {(item?.user?.profileimg && item?.user?.profileimg_path) ?
                                        <>
                                            <img src={`${docurlchat}${item?.user?.profileimg_path}/${item?.user?.profileimg}`} alt="Profile" />
                                            <div className={(valueExistsInArrays_online(onlineUsers, `${item.user_id}`)) ? "pointOnline" : ""} >

                                            </div>
                                        </>
                                        :

                                        <>
                                            <Avatar size="large" icon={<UserOutlined />} />
                                            <div className={(valueExistsInArrays_online(onlineUsers, `${item.user_id}`)) ? "pointOnline" : ""} >
                                            </div>
                                        </>
                                    }

                                </div>
                                <div className="chat_name_msg">
                                    <div className="chat_msg_time_cont">
                                        <span>{item?.user?.userfullname}</span>
                                        <div className="chat_time_msg">
                                            <span>{(item?.last_message?.created_at) ? formatDateTime(item?.last_message?.created_at) : ""}</span>
                                        </div>
                                    </div>
                                    <div className="chat_para_mas_count">
                                        {
                                            (item?.last_message?.message) ? (
                                                <p>{item?.last_message?.message}</p>
                                            ) : item?.last_message?.file_name ? (
                                                <p>files</p>
                                            ) : ""
                                        }

                                        {/* <div className="count_number_msg"> */}
                                        {/* {((item.user_id == GetuserId?.user_id) && (recipient?.length > 0)) ? setRecipient([]) : ""} */}
                                        {/* {((recipient[0]?.to_user_id == bidgridData?.data?.id) && (item.user_id !== GetuserId?.user_id)) ? (
                                                (recipient[0]?.from_user_id == item.user_id) ?
                                                    <>  {console.log("Incremented chat_unread_count and cleared recipient state", recipient)}
                                                        {item.chat_unread_count += 1, setRecipient([])}
                                                    </>
                                                    : ""
                                            ) : ((item.user_id == GetuserId?.user_id)) ? item.chat_unread_count = 0 : item.chat_unread_count
                                            } */}
                                        {/* <span>{item.chat_unread_count != 0 ? item.chat_unread_count : ""}</span>
                                        </div> */}
                                        <div className="count_number_msg">
                                            {item.chat_unread_count !== 0 && (
                                                <span>{item.chat_unread_count}</span>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : <div>No records found</div>}
                </div >
        },
        {
            key: '2',
            label: 'Group',
            children: <div className="chat_groupsCont">
                {(filteredgroupList.length > 0) ? (
                    filteredgroupList.map((item, index) => (
                        <div className="chat_bot_msg" onClick={() => handleUserClick({ group_id: item.group_id, group_name: item?.chats_group_member?.chats_mstr_group?.group_name, file: item.chats_group_member?.chats_mstr_group?.group_profile })} key={index}>
                            <div className="chatProfile_image">
                                {(item.chats_group_member?.chats_mstr_group?.group_profile) ?
                                    <img src={`${docurlchat}${item.chats_group_member?.chats_mstr_group?.group_profile}`} alt='' />
                                    :
                                    <Avatar size="large" icon={<UserOutlined />} alt='' />
                                }
                            </div>
                            <div className="chat_name_msg">
                                <div className="chat_msg_time_cont">
                                    <span>{item?.chats_group_member?.chats_mstr_group?.group_name}</span>
                                    <div className="chat_time_msg">
                                        <span>{formatDateTime(item?.last_message?.created_at)}</span>
                                    </div>
                                </div>
                                <div className="chat_para_mas_count">
                                    {
                                        (item?.last_message?.message) ? (
                                            <p>{item?.last_message?.message}</p>
                                        ) : item?.last_message?.file_name ? (
                                            <p>files</p>
                                        ) : ""
                                    }
                                    <div className="count_number_msg">
                                        {item.chat_unread_count !== 0 && (
                                            <span>{item.chat_unread_count}</span>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))

                ) : <div>No records found</div>}
            </div>,
        },
    ];


    const design = (
        <>
            {/* {
                showChatIcon !== ROUTES?.CHATBOAT ?
                    <div className={isVisible ? 'visible chats_bid' : 'hidden chats_bid'} onClick={handleBotChat}>
                        <button> <ChatIcon /></button>
                    </div>
                    :
                    ''
            } */}
            {(isChatIconVisible && location.pathname !== ROUTES?.CHATBOAT) &&
                <div className="visible chats_bid" onClick={handleOpenChatBox}>
                    <button><ChatIcon /></button>
                </div>
            }
            {/* ref={botIconsDivRef */}
            {!isChatIconVisible &&
                <div className="chatOverlay" onClick={() => setIsChatIconVisible(true)}></div>
            }
            <AnimatePresence>
                {!isChatIconVisible &&
                    <motion.div
                        initial={{ opacity: 0, x: 500 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, type: "spring" }}
                        className="botIcons_div"
                    // exit="hidden"
                    >
                        {/* <div style={{ position: "relative" }}> */}
                        {/* </div> */}

                        <div className="chat_profile">
                            <div>
                                <div className="chat-title">
                                    <div className="d-flex gap-3">
                                        <img src={GgLogoweb} className="simple-avator" />
                                        <h1>BidGrid Chat </h1>
                                    </div>
                                    <div className='botChat_cross'>
                                        <Tooltip title="Close"> <CloseIcon onClick={() => setIsChatIconVisible(true)} /></Tooltip>
                                    </div>
                                </div>
                                <div className="chat_profile_search">
                                    <div className="tableHead_wrap">
                                        <Search
                                            placeholder="Search"
                                            allowClear
                                            onChange={(e) => setSearchText(e.target.value)}
                                            style={{ width: 345 }}
                                        />
                                    </div>
                                    {/* <div className="chat_meassges_spn">
                                    <span>Messages</span>
                                </div> */}
                                    <Tabs defaultActiveKey="1" items={items} onChange={onChange} />
                                </div>
                            </div>
                        </div>
                        <div className="botIcon" style={{ display: openChat === true ? "block" : "none" }}>
                            <div className="bot_Iconss_container">
                                <div className="chat-title">
                                    <div className="botChat_arrow">
                                        <ArrowLeftOutlined onClick={handleCloseChat} />
                                    </div>
                                    <div className="heading_spaned">
                                        <h1>{(GetuserId?.group_name) ? GetuserId?.group_name : GetuserId?.username}</h1>
                                        {GetuserId?.group_name ? '' :
                                            (exists_online_offline ? (Gettypinguser?.from_user_id === GetuserId?.user_id) ? <span>Typing...</span> : <span>Online</span> : <span>Offline</span>)}
                                    </div>
                                    <div className='botChat_cross'>
                                        <Tooltip title="Chat with Us"><CallMadeIcon onClick={handleBoatChange} /></Tooltip>
                                        <Tooltip title="Close"> <CloseIcon onClick={() => setIsChatIconVisible(true)} /></Tooltip>
                                    </div>
                                </div>
                                <div className="messages" ref={messagesRef}>
                                    {/* <div className="date_frameChat">
                                    <span>Yesterday</span>
                                </div> */}
                                    {GetuserId?.user_id
                                        ? (
                                            messagesList?.map((item, index) => (
                                                <div key={index} className="messages-content">
                                                    <div className='message_botIcon'>
                                                        {item.from_user_id !== bidgridData?.data?.id ? (
                                                            <>
                                                                <div className='message_bot_logo'>
                                                                    <img src={GgLogoweb} width={15} />
                                                                </div>
                                                                {item.is_file == 1 ? (
                                                                    <>
                                                                        {(item.file_type == 'image') ? (
                                                                            <div className='uploaded-image' >
                                                                                <div onClick={() => showImageModal(docurlchat + item.file_name)}>
                                                                                    <img className='w-100' src={docurlchat + item.file_name} />

                                                                                </div>
                                                                                <div className='file-details_image'>
                                                                                    <button onClick={() => handleDownload(docurlchat + item.file_name)}><DownloadOutlined /></button>
                                                                                </div>
                                                                            </div>
                                                                        ) : (
                                                                            <div className='uploaded-image'>
                                                                                <div className='doc-img'>
                                                                                    <span>{item.original_file_name}</span>
                                                                                </div>
                                                                                <div className='file-details'>
                                                                                    <button onClick={() => handleDownload(docurlchat + item.file_name)}><DownloadOutlined /></button>
                                                                                </div>
                                                                            </div>
                                                                        )}
                                                                    </>
                                                                ) : (
                                                                    <>

                                                                        <div className='message_botIcons_div'>
                                                                            <div className="text">{item.message}</div>
                                                                        </div>
                                                                        <div className="time">{formatDateTime(item.created_at)}
                                                                        </div>
                                                                    </>
                                                                )}
                                                            </>
                                                        ) : (
                                                            <div className='message_user'>
                                                                {item.is_file == 1 ? (
                                                                    <>
                                                                        {(item.file_type == 'image') ? (
                                                                            <div className='uploaded-image' >
                                                                                <div onClick={() => showImageModal(docurlchat + item.file_name)}>
                                                                                    <img className='w-100' src={docurlchat + item.file_name} />

                                                                                </div>
                                                                                <div className='file-details_image'>
                                                                                    <button onClick={() => handleDownload(docurlchat + item.file_name)}><DownloadOutlined /></button>
                                                                                </div>
                                                                            </div>
                                                                        ) : (
                                                                            <div className='uploaded-image'>
                                                                                <div className='doc-img'>
                                                                                    <span>{item.original_file_name}</span>
                                                                                </div>
                                                                                <div className='file-details'>
                                                                                    <button onClick={() => handleDownload(docurlchat + item.file_name)}><DownloadOutlined /></button>
                                                                                </div>
                                                                            </div>
                                                                        )}
                                                                    </>
                                                                ) : (
                                                                    <>
                                                                        {((item.read == '1') && (bidgridData?.data?.id == item.from_user_id)) ?
                                                                            <div>&#10004;&#10004;</div>
                                                                            :
                                                                            ""
                                                                        }
                                                                        {((item.read == '0') && (bidgridData?.data?.id == item.from_user_id)) ?
                                                                            <div>&#10004;</div>
                                                                            :
                                                                            ""
                                                                        }
                                                                        <div className='message_botIcons_div'>
                                                                            <div className="text">{item.message}</div>
                                                                        </div>
                                                                        <div className="time">{formatDateTime(item.created_at)}
                                                                        </div>
                                                                    </>

                                                                )}
                                                            </div>
                                                        )}

                                                    </div>
                                                </div>
                                            ))
                                        )
                                        : GetuserId?.group_id
                                            ? (
                                                messagesListgroup?.map((item, index) => (
                                                    <div key={index} className="messages-content">
                                                        <div className='message_botIcon'>
                                                            {item.from_user_id !== bidgridData?.data?.id ? (
                                                                <>
                                                                    <div className='message_bot_logo'>
                                                                        <img src={GgLogoweb} width={15} />
                                                                    </div>
                                                                    <div className='message_botIcons_div'>
                                                                        <div dangerouslySetInnerHTML={{
                                                                            __html: (bidgridData?.data?.id ===
                                                                                item.from_user_id) ? 'You :<br>' + item.message : item.user.userfullname + ' :<br>' + item.message
                                                                        }} />
                                                                    </div>
                                                                    <div className="time">{formatDateTime(item.created_at)}
                                                                    </div>
                                                                </>
                                                            ) : (

                                                                <div className='message_user'>
                                                                    <div className='message_botIcons_div'>
                                                                        <div className="text">
                                                                            {item.message}</div>
                                                                    </div>
                                                                    <div className="time">{formatDateTime(item.created_at)}
                                                                    </div>
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                ))
                                            )
                                            : (
                                                ""
                                            )
                                    }

                                    {/* <div className='message_botIcon'>
                                    <div className='message_bot_logo'>
                                        <img src={GgLogoweb} width={15} />
                                    </div>
                                    <div className='message_botIcons_div'>
                                        <MoreHorizIcon />
                                    </div>
                                </div> */}
                                </div>
                            </div>
                            {/* <button type="button" className="uploadFileIcon p-2" onClick={handleButtonClick}  >
                            <img src={attach} alt="Attach" />
                        </button> */}
                            <div>
                                <form onSubmit={(e) => {
                                    e.preventDefault(); // Prevent the default form submission behavior
                                    sendMessage();
                                }} className="message-box">
                                    {/* <input type="file"
                                    id="fileInput"
                                    onChange={handleFileChange}
                                    style={{ display: 'none' }}
                                />
                                <button type="button" className="uploadFileIcon p-2" onClick={handleButtonClick}  >
                                    <img src={attach} alt="Attach" />
                                </button> */}
                                    <input type="text" className="message-input" placeholder="Type message..."
                                        value={message} onChange={(e) => setMessage(e.target.value)} onKeyDown={(e) => {
                                            if (e.key === 'Enter') {
                                                e.preventDefault(); // Prevent the default behavior (e.g., form submission)
                                                sendMessage();
                                            }
                                        }} />
                                    <button type="submit" className="message-submit sound-on-click"
                                    ><SendIcon /></button>
                                </form>
                            </div>

                        </div>
                    </motion.div>
                }
            </AnimatePresence>

            {/* <div className='botIcons_div' style={{ display: botChat ? "block" : "none" }} >

            </div> */}
        </>
    );
    return design;

}

export default ChatboatIcon;