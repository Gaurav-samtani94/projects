// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { Input, Form, Row, Col, Upload, Drawer, Select, Card, Button } from 'antd';
import skipBack from '../../assets/images/skip-back.png'
import { Down } from '@icon-park/react';
import { DeleteFilled, UploadOutlined } from '@ant-design/icons';
import _ from 'lodash';
import { toast } from 'react-toastify';
import { bidProspective } from 'Services/bidgrid/prospective/bidProspective';
import { useSelector } from 'react-redux';
import 'quill/dist/quill.snow.css'
import ReactQuill from 'react-quill'
import { docurlchat } from 'utils/configurable';

var modules = {
    toolbar: [
        [{ size: ["small", false, "large", "huge"] }],
        ["bold", "italic", "underline", "strike", "blockquote"],
        [{ list: "ordered" }, { list: "bullet" }],
        ["link", "image"],
        [
            { list: "ordered" },
            { list: "bullet" },
            { indent: "-1" },
            { indent: "+1" },
            { align: [] }
        ],
        [{ "color": ["#000000", "#e60000", "#ff9900", "#ffff00", "#008a00", "#0066cc", "#9933ff", "#ffffff", "#facccc", "#ffebcc", "#ffffcc", "#cce8cc", "#cce0f5", "#ebd6ff", "#bbbbbb", "#f06666", "#ffc266", "#ffff66", "#66b966", "#66a3e0", "#c285ff", "#888888", "#a10000", "#b26b00", "#b2b200", "#006100", "#0047b2", "#6b24b2", "#444444", "#5c0000", "#663d00", "#666600", "#003700", "#002966", "#3d1466", 'custom-color'] }],
    ]
};
var formats = [
    "header", "height", "bold", "italic",
    "underline", "strike", "blockquote",
    "list", "color", "bullet", "indent",
    "link", "image", "align", "size",
];

const initialState = {
    files: [],
    client_id: null,
    country_id: null,
    state_id: null,
    tender_value: '',
    sector_id: null,
    funding_id: null,
    lead_comp_ids: null,
    jv_ids: null,
    associative_ids: null
}
const DrawerSection = (props) => {
    const { companyList } = props

    const [form] = Form.useForm();
    // form fileds
    const [selectedOption, setSelectedOption] = useState(initialState);
    // state as per country
    const [statelist, setStateList] = useState([])
    // document state
    const [documentDataVal, setDocumentDataVal] = useState([])
    // dropdown values
    const { BidClient, BidFundingClientAgency, BidCountry, BidSector } = useSelector((state) => state.bidDropdownCalVal)

    // editor state
    const [editor, setEditor] = useState('')
    const [isCleared, setIsCleared] = useState(true);
    //comapny states
    const [leadComData, setLeadComData] = useState(companyList)
    // const [associateData, setAssociateData] = useState(companyList)
    const [jvdData, setJvdData] = useState(companyList)

    // error states
    const [errormsg, setErrorMsg] = useState(false)

    //notifications
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    // onchange behaviour
    const handleSelectChange = (name, value) => {
        console.log('====80===', value);
        setSelectedOption({ ...selectedOption, [name]: value === undefined ? null : value });
    }

    useEffect(() => {
        if (companyList?.length > 0) {
            setLeadComData(companyList)
            setJvdData(companyList)
        }
    }, [companyList])
    // state List
    const fetchStatesByCountry = async () => {
        const formData = new URLSearchParams()
        formData.append('country_id', selectedOption?.country_id)
        try {
            const res = await bidProspective.getStateList(formData)
            if (res?.data?.status == '1') {
                setStateList(res?.data?.data)
            } else {
                setStateList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    // handle submit for update and new
    const handleSubmit = async (value) => {
        if (props?.propData?.hasOwnProperty('id')) {
            if (editor?.trim()?.replace(/<[^>]*>/g, '') === '') {
                setErrorMsg(true)
            } else {
                const formData = new FormData();
                formData.append('project_id', props?.propData?.id);
                formData.append('project_name', editor);
                value?.client_id && formData.append('client_id', value?.client_id);
                value?.funding_id && formData.append('funding_id', value?.funding_id);
                formData.append('tender_value', value?.tender_value);
                formData.append('country_id', value?.country_id);
                value?.state_id && formData.append('state_id', value?.state_id);
                formData.append('sector_id', value?.sector_id);
                value?.lead_comp_ids && formData.append('lead_comp_ids', value?.lead_comp_ids);
                selectedOption?.files?.forEach((file, index) => {
                    formData.append('files', file.originFileObj);
                });
                formData.append('jv_ids', value?.jv_ids || '');
                // formData.append('associative_ids', value?.associative_ids);
                try {
                    const response = await bidProspective.updateProspectiveList(formData)
                    if (response?.data?.status == "1") {
                        props?.onClose()
                        props?.setSpinner(true)
                        notifySuccess("Tender Updated Successfully");
                        props?.getProspectiveListData(false)
                        setStateList([])
                        setErrorMsg(false)
                        form.resetFields()
                        setSelectedOption({
                            files: [],
                            client_id: null,
                            country_id: null,
                            state_id: null,
                            tender_value: '',
                            sector_id: null,
                            funding_id: null,
                            lead_comp_ids: null,
                        })

                    } else {
                        props?.setSpinner(false)
                        notify(response?.response?.data?.message);
                    }
                } catch (error) {
                    props?.setSpinner(false)
                    console.log(error, "api error")
                }
            }
        }
        else {
            if (editor?.trim()?.replace(/<[^>]*>/g, '') === '') {
                setErrorMsg(true)
            } else {
                const formData = new FormData();
                formData.append('client_id', value?.client_id || '');
                formData.append('funding_id', value?.funding_id || '');
                formData.append('tender_value', value?.tender_value);
                formData.append('country_id', value?.country_id);
                formData.append('state_id', value?.state_id || '');
                formData.append('sector_id', value?.sector_id);
                formData.append('jv_ids', value?.jv_ids || '');
                // formData.append('associative_ids', value?.associative_ids || '');
                formData.append('lead_comp_ids', value?.lead_comp_ids || '');
                selectedOption?.files?.forEach((file, index) => {
                    formData.append('files', file.originFileObj);
                });

                formData.append('project_name', editor);
                try {
                    const response = await bidProspective.addProspectiveList(formData)
                    if (response?.data?.status == "1") {
                        props?.onClose()
                        props?.setSpinner(true)
                        notifySuccess("Tender Added Successfully");
                        props?.getProspectiveListData(false)
                        setSelectedOption({
                            files: [],
                            client_id: null,
                            country_id: null,
                            state_id: null,
                            tender_value: '',
                            sector_id: null,
                            funding_id: null,
                            lead_comp_ids: null,
                        })
                        setEditor("")
                        setStateList([])
                        form.resetFields()
                        setErrorMsg(false)
                    } else {
                        notify(response?.response?.data?.message);
                        props?.setSpinner(false)
                    }
                } catch (error) {
                    console.log(error, "api error")
                    props?.setSpinner(false)

                }
            }


        }
    }

    // reset all fields of drawer
    const handleResetFun = () => {
        setSelectedOption({
            files: [],
            project_name: '',
            client_id: null,
            country_id: null,
            state_id: null,
            tender_value: '',
            sector_id: null,
            funding_id: null,
            lead_comp_ids: null,
        })

        setEditor('')
        form.resetFields();
    }

    // delete Document  
    const handleDeleteDocument = async (deleteItem) => {
        const formData = new URLSearchParams()
        formData.append('project_id', props?.propData?.id)
        formData.append('docs_id', deleteItem?.prospective_doc_id)
        try {
            const res = await bidProspective.deleteProspectiveDocument(formData)
            if (res?.data?.status == '1') {
                notifySuccess(res?.data?.message);
                setDocumentDataVal(prevData => {
                    const newData = prevData
                        ?.map(item => item)
                        ?.filter(val => val?.doc_name !== deleteItem?.doc_name);
                    return newData;
                });
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }


    // if propdata does't have country than call country api
    useEffect(() => {
        if (selectedOption?.country_id !== null) {
            fetchStatesByCountry()
        }
    }, [selectedOption?.country_id])


    // initialize predefined values from propDatas
    const predefinedValues = () => {

        // extract jvs company
        let jvsData = props?.propData?.jvs_id?.length > 0 ? props?.propData?.jvs_id : null

        const jvsArray = jvsData?.map((companyName, index) => ({
            id: (index + 1).toString(),
            company_name: companyName.trim()
        }));

        // let associativeData = props?.propData?.associative_id?.split(',')
        // const associativeArray = associativeData?.map((companyName, index) => ({
        //     id: (index + 1).toString(),
        //     company_name: companyName.trim()
        // }));

        let bidClientFilterData = BidClient?.map(items => items)?.filter(item => item?.client_name === props?.propData?.clientData)
        let bidFundingClientFilterData = BidFundingClientAgency?.map(items => items)?.filter(item => item?.funding_org_name === props?.propData?.fundingAgencyData)
        let bidCountryFilterData = BidCountry?.find(item => item?.country_name === props?.propData?.countryData)
        let bidStateFilterData = props?.propData?.stateArr?.map(items => items)?.filter(item => item?.state_name === props?.propData?.StateData)

        let bidLeadCompanyFilterData = companyList?.filter(item => item?.company_name === props?.propData?.leadCompanyData)
        let bidSectorFilterData = BidSector?.map(items => items)?.filter(item => item?.sector_name === props?.propData?.sector)
        let bidjvsFilterData = companyList.filter(arrItem => {
            return jvsArray?.some(jvsItem => arrItem.company_name.includes(jvsItem.company_name));
        });
        // let bidassociativeFilterData = companyList.filter(arrItem => {
        //     return associativeArray?.some(jvsItem => arrItem.company_name.includes(jvsItem.company_name));
        // });

        setEditor(props?.propData?.project_name)
        let newObj = {
            files: [],
            // project_name: props?.propData?.project_name ? props?.propData?.project_name : '',
            client_id: bidClientFilterData?.length > 0 ? bidClientFilterData?.map(item => item?.id) : null,
            country_id: bidCountryFilterData?.id ? bidCountryFilterData?.id : null,
            state_id: bidStateFilterData?.length > 0 ? bidStateFilterData?.map(item => item?.id) : null,
            tender_value: props?.propData?.tender_value ? props?.propData?.tender_value : '',
            sector_id: bidSectorFilterData?.length > 0 ? bidSectorFilterData?.map(item => item?.id) : null,
            funding_id: bidFundingClientFilterData?.length > 0 ? bidFundingClientFilterData?.map(item => item?.id) : null,
            lead_comp_ids: bidLeadCompanyFilterData?.length > 0 ? bidLeadCompanyFilterData[0]?.id : null,
            jv_ids: bidjvsFilterData?.length > 0 ? bidjvsFilterData?.map(item => item?.id) : null,
            // associative_ids: bidassociativeFilterData?.map(item => item?.id) ? bidassociativeFilterData?.map(item => item?.id) : null,

        }

        setSelectedOption((prevState) => {
            return {
                ...prevState,
                ...newObj,
            };
        });
        form.setFieldsValue(newObj);
    }

    // weather to fill or empty states while drawer open
    useEffect(() => {

        if (props?.propData?.hasOwnProperty('id')) {
            predefinedValues()
        } else {
            setSelectedOption({
                files: [],
                client_id: null,
                country_id: null,
                state_id: null,
                tender_value: '',
                sector_id: null,
                funding_id: null,
                lead_comp_ids: null,
            })
            form.resetFields()
            setEditor('')
        }
    }, [props?.propData, companyList])



    useEffect(() => {
        // Filter leadCompData based on selected associative_ids and jv_ids
        const filteredLeadComData = companyList?.filter((item) => {
            const existsAssociative = Array.isArray(selectedOption?.associative_ids) && selectedOption?.associative_ids?.some((id) => id === item.id);
            const existsJvd = Array.isArray(selectedOption?.jv_ids) && selectedOption?.jv_ids?.some((id) => id === item.id);
            return !(existsAssociative || existsJvd);
        });

        // Filter associateData based on selected lead_comp_ids and jv_ids
        const filteredAssociateData = companyList?.filter((item) => {
            const existsLeadComp = selectedOption?.lead_comp_ids === item.id;
            const existsJvd = Array.isArray(selectedOption?.jv_ids) && selectedOption?.jv_ids?.some((id) => id === item.id);
            return !(existsLeadComp || existsJvd);
        });

        // Filter jvdData based on selected lead_comp_ids and associative_ids
        const filteredJvdData = companyList?.filter((item) => {
            const existsLeadComp = selectedOption?.lead_comp_ids === item.id;
            const existsAssociative = Array.isArray(selectedOption?.associative_ids) && selectedOption?.associative_ids?.some((id) => id === item.id);
            return !(existsLeadComp || existsAssociative);
        });

        // Update state with filtered data
        setLeadComData(filteredLeadComData);
        // setAssociateData(filteredAssociateData);
        setJvdData(filteredJvdData);
    }, [selectedOption?.jv_ids, selectedOption?.lead_comp_ids]);

    // useEffect(() => {
    //     console.log("selectedOption", selectedOption)
    // }, [selectedOption])

    useEffect(() => {
        setDocumentDataVal(props?.propData?.documentData)
    }, [props?.propData])

    const handleKeyDown = (event) => {
        if (isCleared && event.key === ' ') {
            event.preventDefault();
        }
    };

    const handleEditorChange = (content, delta, source, editor) => {
        setEditor(content);
        setIsCleared(content?.trim()?.replace(/<[^>]*>/g, '') === '');
        setErrorMsg(false)
    };
    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            //  onFinish()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };
    const exceptSymbol = ['e', 'E', '+', '-', '.'];

    const handleEditor = () => {
        if (editor?.trim()?.replace(/<[^>]*>/g, '') === '') {
            setErrorMsg(true)
        } else {
            setErrorMsg(false)
        }
    }

    const handleKeyContainOnlyNumbers = (e) => {
        const allowedChars = /[0-9.]/;
        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        }
        else if (e.key === 'Enter') {
            e.preventDefault();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    }
    return (
        <Drawer className='bd_drawer_main' closeIcon={<img src={skipBack} alt='' />} title={props?.propData?.hasOwnProperty('id') ? 'Edit Prospective Tender' : "Prospective  Tender"} placement="right" onClose={() => { props?.onClose(); setStateList([]); form.resetFields(); setErrorMsg(false); props?.setPropData({}) }} open={props?.open} width={1000}>
            <div className='bd_prospective_drawer'>
                <div>
                    <div className='bd_drawer_prospective_box'>
                        <Form
                            form={form}
                            layout="vertical"
                            onFinish={handleSubmit}
                            autoComplete='off'
                            name="control-hooks"
                        >
                            <Row gutter={20}>
                                <Col sm={24}>
                                    <Form.Item label="* Tender Name:"

                                    >
                                        {/* <div className="bd_editor">
                                            <div className="bd_editor_heading">
                                                Tender Name:
                                            </div>
                                        </div> */}

                                        <div className=" mb-4">
                                            <div style={{ marginBottom: "85px", justifyContent: "center" }}>
                                                <ReactQuill
                                                    theme="snow"
                                                    modules={modules}
                                                    formats={formats}
                                                    placeholder="write your content ...."
                                                    name='project_name'
                                                    onKeyDown={handleKeyDown}
                                                    onChange={handleEditorChange}
                                                    value={editor}
                                                    style={{ height: "300px" }}
                                                >
                                                </ReactQuill>
                                            </div>
                                            {errormsg ? <div className="col-md-12" style={{ color: '#ff4d4f' }}>Tender name is required</div> : <p></p>}

                                        </div>
                                    </Form.Item>
                                </Col>

                                <Col sm={8}>
                                    <Form.Item label="Client:"
                                        name="client_id"
                                        onKeyPress={handleKeyPress}
                                    >
                                        <Select
                                            allowClear
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder="Select client"

                                            options={BidClient
                                                ?.sort((a, b) => a.client_name.localeCompare(b.client_name))
                                                ?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.client_name
                                                    }
                                                })}
                                            value={selectedOption?.client_id}
                                            onChange={(value) => handleSelectChange('client_id', value)}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>

                                <Col sm={8}>
                                    <Form.Item label=" Funding Agency:"
                                        name='funding_id'
                                        // rules={[
                                        //     { required: true, message: "Please enter a funding agency" }
                                        // ]}
                                        onKeyPress={handleKeyPress}
                                    >
                                        <Select
                                            allowClear
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder="Select funding"
                                            options={BidFundingClientAgency
                                                ?.sort((a, b) => a.funding_org_name.localeCompare(b.funding_org_name))
                                                ?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.funding_org_name
                                                    }
                                                })}
                                            value={selectedOption?.funding_id}
                                            onChange={(value) => handleSelectChange('funding_id', value)}

                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>
                                <Col sm={8}>
                                    <Form.Item label="Tender Value :"
                                        name='tender_value'
                                        rules={[
                                            { required: true, message: "Please enter a  tender value" }
                                        ]}
                                        onKeyPress={handleKeyContainOnlyNumbers}
                                    >
                                        <Input
                                            placeholder='Enter here'
                                            type='number'
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={8}>
                                    <Form.Item label="Country:"
                                        name="country_id"
                                        rules={[
                                            { required: true, message: "Please enter a Country" }
                                        ]}
                                    >
                                        <Select
                                            allowClear
                                            showSearch
                                            placeholder="Select Country"
                                            value={selectedOption?.country_id}
                                            onChange={(value) => handleSelectChange('country_id', value)}
                                            options={BidCountry
                                                ?.sort((a, b) => a.country_name.localeCompare(b.country_name))
                                                ?.map((item, index) => {
                                                    return { label: item?.country_name, value: item?.id };
                                                })}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>
                                <Col sm={8}>
                                    <Form.Item label="State:"
                                        name="state_id"
                                    //     rules={[
                                    //         { required: true, message: "Please enter a State" }
                                    //     ]}
                                    // // onKeyPress={handleKeyPress}
                                    >
                                        <Select
                                            allowClear
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder="Select state"
                                            // name='state_id'
                                            options={statelist
                                                ?.sort((a, b) => a.state_name.localeCompare(b.state_name))
                                                ?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.state_name
                                                    }
                                                })}
                                            value={selectedOption?.state_id}
                                            onChange={(value) => handleSelectChange('state_id', value)}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>
                                <Col sm={8}>
                                    <Form.Item label="Lead Company:"
                                        name="lead_comp_ids"
                                        rules={[
                                            { required: true, message: "Please select a Company" }
                                        ]}
                                    >
                                        <Select
                                            allowClear
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder="Select company"
                                            // mode="multiple"
                                            // name='lead_comp_ids'
                                            options={leadComData
                                                ?.sort((a, b) => a.company_name.localeCompare(b.company_name))
                                                .map((item, index) => ({
                                                    value: item?.id,
                                                    label: item?.company_name
                                                }))
                                            }
                                            value={selectedOption?.lead_comp_ids}
                                            onChange={(value) => handleSelectChange('lead_comp_ids', value)}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>

                                <Col sm={8}>
                                    <Form.Item label="Sector:"
                                        name="sector_id"
                                        rules={[
                                            { required: true, message: "Please enter Sector" }
                                        ]}
                                    // onKeyPress={handleKeyPress}
                                    >
                                        <Select
                                            allowClear
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder="Select sector"
                                            options={BidSector
                                                ?.sort((a, b) => a.sector_name.localeCompare(b.sector_name))
                                                ?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.sector_name
                                                    }
                                                })}
                                            // name='sector_id'
                                            value={selectedOption?.sector_id}
                                            onChange={(value) => handleSelectChange('sector_id', value)}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>
                                {/* <Col sm={8}>
                                    <Form.Item label="Associative Id:" name='associative_ids'
                                        rules={[
                                            { required: true, message: "Please select a associative" }
                                        ]}
                                        onKeyPress={handleKeyPress}>
                                        <Select
                                            // showSearch={true}
                                            showSearch
                                            placeholder='Select associative id'
                                            mode="multiple"
                                            // allowClear
                                            allowClear
                                            className='prosp_multupledd'
                                            optionFilterProp="children"
                                            options={associateData?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.company_name
                                                }
                                            })}
                                            filterOption={(input, option) =>
                                                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                            placeholder="Select Multiple Associative Id"
                                            name='associative_ids'
                                            value={selectedOption?.associative_ids}
                                            onChange={(value) => handleSelectChange('associative_ids', value)}
                                            suffixIcon={<Down theme="outline" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>

                                    </Form.Item>
                                </Col> */}

                                <Col sm={8}>
                                    <Form.Item label="Joint Venture:"
                                        name='jv_ids'
                                        // rules={[
                                        //     { required: true, message: "Please select a joint venture" }
                                        // ]}
                                        onKeyPress={handleKeyPress} >
                                        <Select
                                            showSearch
                                            allowClear
                                            placeholder='Select joint venture'
                                            mode="multiple"
                                            optionFilterProp="children"
                                            className='prosp_multupledd'
                                            options={jvdData
                                                ?.sort((a, b) => a.company_name.localeCompare(b.company_name))
                                                ?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.company_name
                                                    }
                                                })}
                                            // name='jv_ids'
                                            value={selectedOption?.jv_ids}
                                            onChange={(value) => handleSelectChange('jv_ids', value)}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>

                                <Col sm={8}>
                                    <Form.Item label="Upload file:">
                                        <Upload
                                            listType="picture"
                                            name='files'
                                            fileList={selectedOption?.files}
                                            multiple={true}
                                            onChange={(info) => {
                                                const fileList = info?.fileList?.map((file) => ({
                                                    uid: file?.uid,
                                                    name: file?.name,
                                                    status: 'done',
                                                    originFileObj: file?.originFileObj,
                                                }));
                                                handleSelectChange('files', fileList);
                                            }}
                                        >
                                            <Button icon={<UploadOutlined />}>Upload</Button>
                                        </Upload>
                                    </Form.Item>
                                </Col>
                                <Col sm={12}>
                                    {
                                        props?.propData?.hasOwnProperty('id') ?
                                            <>
                                                {
                                                    documentDataVal?.map((item, index) => {
                                                        return (
                                                            <>

                                                                <Card
                                                                    style={{
                                                                        margin: 20,
                                                                        paddingBlock: 0,
                                                                    }}
                                                                >
                                                                    <p style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                                        <img src={`${docurlchat}${item?.doc_path}/${item?.doc_name}`} width={50} />  {item?.doc_name}
                                                                        <span onClick={() => handleDeleteDocument(item)}>
                                                                            <DeleteFilled /></span></p>

                                                                </Card>
                                                            </>
                                                        )
                                                    })
                                                }
                                            </>

                                            :
                                            <></>
                                    }

                                </Col>


                            </Row>
                            <div className="bd_drawerFoot">
                                <Button className='BG_ghostButton'
                                    onClick={() => { props?.propData?.hasOwnProperty('id') ? predefinedValues() : handleResetFun(); props?.propData?.hasOwnProperty('id') && props?.onClose() }} >
                                    {props?.propData?.hasOwnProperty('id') ? 'Cancel' : 'Reset'}</Button>
                                <button className='BG_mainButton' key="submit" onClick={handleEditor}
                                // disabled={disableBtn}
                                >{props?.propData?.hasOwnProperty('id') ? 'Update' : 'Create'}</button>
                            </div>
                        </Form>
                    </div>



                </div>
            </div>
        </Drawer>
    )

}
export default DrawerSection