// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { Input, Form, Row, Col, Upload, Drawer, Select, Card, Button, Space } from 'antd';
import skipBack from '../../assets/images/skip-back.png'
import { Down } from '@icon-park/react';
import { DeleteFilled, UploadOutlined } from '@ant-design/icons';
import _ from 'lodash';
import { toast } from 'react-toastify';
import { bidProspective } from 'Services/bidgrid/prospective/bidProspective';
import { useSelector } from 'react-redux';
import 'quill/dist/quill.snow.css'
import ReactQuill from 'react-quill'
import { RequestApi } from 'Services/bidgrid/tenderList/RequestApi';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import { docurlchat } from 'utils/configurable';
const { Option } = Select;

// const options = [];
// for (let i = 10; i < 36; i++) {
//     options.push({
//         label: i.toString(36) + i,
//         value: i.toString(36) + i,
//     });
// }

const createdByOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }, { value: '3', label: 'Approval' }]
const assignedToOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }]


const initialState = {
    subject: '',
    curr_status: null,
    req_from_userid: '',
    req_to_userid: null,
    comment_txt: '',
    request_file: [],

}

const GenerateRequest = (props) => {
    const [form] = Form.useForm();
    const { id, employeeListVal, recordData, setRecordData, fetchRequestList, fetchRequestListForDrawer, from, userListData } = props
    const [requestData, setRequestData] = useState(initialState);
    // const [documentDataVal, setDocumentDataVal] = useState([])
    const [disableBtn, setDisableBtn] = useState(false)
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [editor, setEditor] = useState('')
    const [isCleared, setIsCleared] = useState(true);
    const [showNotification, setShowNotification] = useState(false);
    const [employeeList, setEmployeeList] = useState([])
    const [errormsg, setErrorMsg] = useState(false)
    const userDetail = useSelector((state) => (state?.userDetails))
    const [loadingsRes, setLoadingsRes] = useState(false);
    const { socket, isConnected } = useSelector((state) => state.socket);
    const { userBidInfo } = useSelector((state) => state?.userDetails)



    var modules = {
        toolbar: [
            [{ size: ["small", false, "large", "huge"] }],
            ["bold", "italic", "underline", "strike", "blockquote"],
            [{ list: "ordered" }, { list: "bullet" }],
            ["link", "image"],
            [
                { list: "ordered" },
                { list: "bullet" },
                { indent: "-1" },
                { indent: "+1" },
                { align: [] }
            ],
            [{ "color": ["#000000", "#e60000", "#ff9900", "#ffff00", "#008a00", "#0066cc", "#9933ff", "#ffffff", "#facccc", "#ffebcc", "#ffffcc", "#cce8cc", "#cce0f5", "#ebd6ff", "#bbbbbb", "#f06666", "#ffc266", "#ffff66", "#66b966", "#66a3e0", "#c285ff", "#888888", "#a10000", "#b26b00", "#b2b200", "#006100", "#0047b2", "#6b24b2", "#444444", "#5c0000", "#663d00", "#666600", "#003700", "#002966", "#3d1466", 'custom-color'] }],
        ]
    };

    var formats = [
        "header", "height", "bold", "italic",
        "underline", "strike", "blockquote",
        "list", "color", "bullet", "indent",
        "link", "image", "align", "size",
    ];

    const handleEditorChange = (content, delta, source, editor) => {
        setEditor(content);
        setIsCleared(content?.trim()?.replace(/<[^>]*>/g, '') === '');
        setErrorMsg(false)

    };
    const handleChange = (name, value) => {
        setRequestData({ ...requestData, [name]: value });

    };

    const beforeUpload = (file) => {
        const allowedFileTypes = ['image/jpeg', 'image/png', 'application/pdf', 'text/html'];

        if (!allowedFileTypes.includes(file.type)) {
            notify('You can only upload JPG, PNG, PDF, or HTML files!');
            return false;
        }
        return true;
    };

    const getBase64 = (file, callback) => {
        const reader = new FileReader();
        reader.addEventListener('load', () => callback(reader.result));
        reader.addEventListener('error', () => callback(null));
        reader.readAsDataURL(file);
    };

    const handleDoc = (info) => {
        if (info.file.status === 'uploading') {
            Promise.all(info.fileList.map(file => new Promise((resolve, reject) => {
                getBase64(file.originFileObj, (url) => {
                    if (url) {
                        resolve({
                            uid: file.uid,
                            name: file.name,
                            status: 'done',
                            originFileObj: file.originFileObj,
                        });
                    } else {
                        reject(new Error('File is corrupted or invalid'));
                    }
                });
            })))
                .then(fileList => {
                    setRequestData({ ...requestData, request_file: fileList });
                })
                .catch(error => {
                    console.error('Error processing files:', error);
                });
        }
    };

    const handleRemove = (file) => {
        const newFileList = requestData.request_file.filter((f) => f.uid !== file.uid);
        setRequestData({ ...requestData, request_file: newFileList });
    };

    // add request list
    const handleSubmit = async (value) => {
        setLoadingsRes(true)
        if (recordData?.id && editor !== '') {
            const formData = new FormData();
            formData.append('tender_id', id)
            formData.append('request_id', recordData?.id)
            formData.append('subject', value?.subject)
            formData.append('desc_details', editor)
            formData.append('req_from_userid', userDetail?.userBidInfo?.id)
            formData.append('curr_status', Number(requestData?.curr_status))
            formData.append('comment_txt', value?.comment_txt)
            formData.append('req_to_userid', value?.req_to_userid)
            requestData?.request_file?.forEach((file, index) => {
                formData.append('request_file', file.originFileObj);
            });

            try {
                const response = await RequestApi.updateRequest(formData)
                if (response?.data?.status === "1") {
                    // setSpinner(true)
                    await fetchRequestList(false)
                    notifySuccess('Request update successfully')
                    setRecordData({})
                    setLoadingsRes(false)
                    setRequestData(initialState)
                    props?.onClose()
                    setEditor('')
                    form.resetFields();
                    const data = response?.data?.data
                    let socketTenderFReq = { tender_id: id, tender_req_id: data?.id, ping_users_info: String(value?.req_to_userid), request_subject: value?.subject }
                    if (isConnected) {
                        socket.emit('tender_request', socketTenderFReq);
                    }
                    console.log("socketTenderFReq", socketTenderFReq)
                } else {
                    notify(response?.response?.data?.message)
                    setLoadingsRes(false)
                    // setSpinner(false)
                }
            } catch (error) {
                setLoadingsRes(false)
                // setSpinner(false)
            }

        } else {
            if (editor !== '') {
                const formData = new FormData();
                formData.append('tender_id', id)
                formData.append('subject', value?.subject)
                formData.append('desc_details', editor)
                formData.append('req_from_userid', userDetail?.userBidInfo?.id)
                formData.append('curr_status', Number(requestData?.curr_status))
                formData.append('comment_txt', value?.comment_txt)
                formData.append('req_to_userid', value?.req_to_userid)

                requestData?.request_file?.forEach((file, index) => {
                    formData.append('request_file', file.originFileObj);
                });
                try {
                    const response = await RequestApi.requestAdd(formData)
                    if (response?.data?.status === "1") {
                        if (from != undefined) {
                            await fetchRequestListForDrawer(id)
                            notifySuccess('Request add successfully')
                            setRequestData(initialState)
                            props?.onClose()
                            form.resetFields()
                            setLoadingsRes(false)
                            // setSpinner(true)
                        }
                        else {
                            // await fetchRequestListForDrawer(id)
                            props?.onClose()
                            form.resetFields()
                            setLoadingsRes(false)
                            // setSpinner(true)
                            await fetchRequestList(false)
                            setEditor('')
                            notifySuccess('Request add successfully')
                            setRequestData(initialState)
                            const data = response?.data?.data
                            let socketTenderFReq = { tender_id: id, tender_req_id: data?.id, ping_users_info: String(value?.req_to_userid), request_subject: value?.subject }
                            socket?.emit('tender_request', socketTenderFReq);
                        }
                    } else {
                        notify(response?.response?.data?.message)
                        setLoadingsRes(false)
                        // setSpinner(false)
                    }
                } catch (error) {
                    // setSpinner(false)
                }
            }

        }
    }

    const handleKeyDown = (event) => {
        if (isCleared && event.key === ' ') {
            event.preventDefault();
        }
    };

    // edit meeting api

    // const handleEdit = async (requestid) => {
    //     const formData = new URLSearchParams();
    //     formData.append('request_id', requestid)
    //     formData.append('tender_id', id)

    //     try {
    //         const response = await RequestApi.editRequest(formData)
    //         if (response?.data?.status == 1) {

    //             setEditor(response?.data?.data?.map(item => item?.desc_details)?.join(''))
    //             const responseData = response?.data?.data;

    //             if (responseData && Array.isArray(responseData) && responseData.length > 0) {
    //                 const singleObject = responseData.reduce((accumulator, currentObject) => {
    //                     return { ...accumulator, ...currentObject };
    //                 }, {});

    //                 setRequestData(singleObject);
    //             } else {
    //                 console.error("Invalid or empty data in the response");
    //                 // Handle the case where responseData is not an array or is empty
    //             }

    //         }

    //     } catch (error) {
    //         console.log(error, 'Api Error')
    //     }
    // }


    const predefinedValues = () => {

        let newObj = {
            subject: recordData?.subject,
            curr_status: recordData?.req_status === 'Pending' ? '1' : '2',
            req_to_userid: recordData?.request_id,
            comment_txt: recordData?.comment_txt,

        }

        setRequestData((prevState) => {
            return {
                ...prevState,
                ...newObj,
            };
        });

        setEditor(recordData?.desc_details)
        form.resetFields(newObj)

    }
    const handleReset = () => {
        setRequestData(initialState)
        setEditor('')
        // setRecordData({})
        form.resetFields()
        setErrorMsg(false)
    }

    useEffect(() => {
        if (recordData?.id) {
            // If editing an existing record, pre-fill form fields
            form.setFieldsValue({
                subject: recordData.subject,
                curr_status: recordData.req_status,
                req_to_userid: employeeListVal?.find(item => item.id === Number(recordData.request_id) && item.isactive == 1)?.hasOwnProperty('id') ? recordData.request_id : null,
                comment_txt: recordData.comment_txt,
            });
            setEditor(recordData.desc_details);
        }
    }, [recordData]);

    let employeeListData = employeeListVal || userListData;


    const handleContainOnlyText = (e) => {
        // const alphabeticChars = /[a-zA-Z]/;
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            //  handleProjectInfo()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };
    const handleEditor = () => {
        if (editor?.trim()?.replace(/<[^>]*>/g, '') === '') {
            setErrorMsg(true)
        } else {
            setErrorMsg(false)
        }
    }
    const handleKeyPress = (e) => {
        const alphabeticChars = /[a-zA-Z]/;
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key) && alphabeticChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            //  handleProjectInfo()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };
    return (
        <Drawer className='bd_drawer_main'
            closeIcon={<img src={skipBack} alt='' />}
            title={recordData?.id ? "Edit Request" : 'Generate Request:'}

            placement="right" onClose={() => { props?.onClose(); setRecordData({}); setEditor(''); setRequestData(initialState); form.resetFields(); setErrorMsg(false) }}
            open={props?.open} width={1000}>
            <div className='bd_prospective_drawer'>
                <div>

                    <div className="bd_editor">
                        <div className="bd_editor_heading">
                            <span style={{ color: "#ff4d4f" }}>*</span> Description:
                        </div>
                    </div>
                    <Form
                        layout="vertical"
                        name='control-hooks'
                        form={form}
                        onFinish={handleSubmit} >
                        <Row gutter={20}>
                            <Col sm={24}>
                                <Form.Item
                                    // name="desc_details"
                                    rules={[{ required: true, message: "please enter a Description" }]}
                                >
                                    <div style={{ marginBottom: "65px", justifyContent: "center" }}>
                                        <ReactQuill
                                            theme="snow"
                                            modules={modules}
                                            formats={formats}
                                            placeholder="write your content ...."
                                            name='desc_details'
                                            onKeyDown={handleKeyDown}
                                            onChange={handleEditorChange}
                                            value={editor}
                                            style={{ height: "300px" }}
                                            readOnly={userBidInfo?.id === recordData?.request_id ? true : false}
                                        >
                                        </ReactQuill>
                                    </div>

                                    {
                                        errormsg ?
                                            <div className="col-md-12" style={{ color: '#ff4d4f' }}>Description is required</div>
                                            // <p>error</p>
                                            :
                                            <p></p>
                                    }
                                    {/* {showError ?
                                        <div className="col-md-12" style={{ color: `${showError ? "green" : 'red'}` }}> {showError ? "Description is required" : ""} </div>
                                        : null} */}
                                    {/* <div className="col-md-12" style={{ color: `${showError ? "green" : 'red'}` }}> Description is required  </div> */}
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Subject:"
                                    name="subject" rules={[{ required: true, message: "please enter a Subject" }]}
                                    onKeyPress={handleKeyPress}
                                >
                                    <Input
                                        name='subject'
                                        value={requestData?.subject}
                                        placeholder="Enter here"
                                        onChange={(e) => handleChange('subject', e.target.value?.trimStart())}
                                        disabled={userBidInfo?.id === recordData?.request_id ? true : false}

                                    />

                                </Form.Item>
                            </Col>

                            {/* <Col sm={12}>
                                <Form.Item label=" requesed from User">
                                    <Input
                                        name="req_from_userid"
                                        placeholder="Enter here"
                                        onChange={(e) => handleChange('req_from_userid', e.target.value)}
                                        value={employeeListVal?.filter(item => item?.id === userDetail?.userBidInfo?.id)?.map(items => items?.userfullname).join('')}
                                    />

                                </Form.Item>
                            </Col> */}
                            <Col sm={12}>
                                <Form.Item label="Comment Text:" name="comment_txt" rules={[{ required: true, message: "please enter a Comment Text" }]} onKeyPress={handleKeyPress}>
                                    <Input
                                        name="comment_txt"
                                        placeholder="Enter here"
                                        value={requestData?.comment_txt}
                                        onChange={(e) => handleChange('comment_txt', e.target.value?.trimStart())}
                                        disabled={userBidInfo?.id === recordData?.request_id ? true : false}

                                    />

                                </Form.Item>
                            </Col>
                            <Col sm={12} >
                                <Form.Item label=" Request to User" name="req_to_userid" rules={[{ required: true, message: "please enter a Request" }]} onKeyPress={handleContainOnlyText}>
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        onChange={(e) => handleChange('req_to_userid', e)}
                                        name='req_to_userid'
                                        placeholder="Select User"
                                        value={requestData?.req_to_userid}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.children.toLowerCase().replace(/\s/g, '').indexOf(input.toLowerCase().replace(/\s/g, '')) >= 0
                                        }
                                        disabled={userBidInfo?.id === recordData?.request_id ? true : false}

                                    >
                                        {employeeListData?.filter(item => item?.id !== userBidInfo?.id && item?.isactive === 1)?.map((item, index) => {
                                            return (
                                                <>
                                                    <Option key={index} value={item?.id}
                                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}>{item?.userfullname}</Option>
                                                </>
                                            )
                                        })}
                                    </Select>
                                </Form.Item>
                            </Col>
                            <Col sm={24}>

                                <Form.Item label="Attach file  (Max Size is 20 MB)"
                                >
                                    <div className='todo_model_upload'>
                                        <Upload
                                            listType="picture"
                                            // name='files'
                                            fileList={requestData?.request_file}
                                            // multiple={true}
                                            onChange={handleDoc}
                                            beforeUpload={beforeUpload}
                                            onRemove={handleRemove}
                                            name="files"
                                            disabled={userBidInfo?.id === recordData?.request_id ? true : false}

                                        >
                                            <Button className='todo_choosen_btn'>Choose file </Button>
                                            <span className='file_choosen'>No file chosen</span>
                                        </Upload>
                                    </div>
                                </ Form.Item>
                            </Col>

                        </Row>
                        <div className="bd_drawerFoot">
                            <Button className='BG_ghostButton' onClick={handleReset}>Reset</Button>
                            <Button className='BG_mainButton'
                                // onClick={handleSubmit} 
                                type="primary" htmlType="submit" loading={loadingsRes} disabled={loadingsRes}
                                onClick={handleEditor}
                            >{recordData?.id ? 'Update' : 'Submit'}</Button>
                        </div>
                    </Form>

                    {
                        userBidInfo?.id === recordData?.request_id ?
                            <></>
                            :
                            <>
                                {
                                    recordData?.id &&

                                    <Row>
                                        <Col sm={24}>
                                            <Card
                                                style={{
                                                    margin: 20,
                                                    paddingBlock: 0,
                                                }}

                                            >
                                                <img src={`${docurlchat}${recordData?.file_path}/${recordData?.file_data}`} width={50} />     <span style={{ display: 'flex', justifyContent: 'space-between' }}> {recordData?.file_data}  <DeleteFilled /></span>
                                            </Card>
                                        </Col>
                                    </Row>

                                }

                            </>

                    }





                </div>
            </div>
        </Drawer>
    )

}
export default GenerateRequest