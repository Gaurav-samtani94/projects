// @ts-nocheck
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Drawer, Collapse, Space, Radio } from 'antd';
import skipBack from "../../assets/images/skip-back.png"
import 'react-loading-skeleton/dist/skeleton.css'
import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
import { toast } from 'react-toastify';
import { useDispatch } from 'react-redux';
import { filterCycleActions } from 'Redux/actions/bidgrid/cycleFilterAction';
import { misFilterActions } from 'Redux/actions/bidgrid/misFilterAction';
import { trashFilterAction } from 'Redux/actions/bidgrid/trashFilterAction';
import EmptyBox from '../../../assests/img/empty-box.png';

const notify = (error) => toast.error(error);
const notifySuccess = (msg) => toast.success(msg);

const FilterChipsTemplateDrawer = (props) => {
    const { open, close, collapseActiveKeyTemp, handleUpdateFilter, setApplyTemp, applyFilter, setModals
        , handleAccordionChange, handleRadioChange, accGenerateChips, setCollapseActiveKeyTemp, tempType, commonFilter, getScopeList } = props

    const [accordianList, setAccordianList] = useState([])
    const dispatch = useDispatch()
    const handleDelete = async () => {
        const formData = new URLSearchParams();
        formData.append("template_type", tempType);
        formData.append("template_name", collapseActiveKeyTemp);
        try {
            const response = await tenderCycle.bdDeleteAccordian(formData)
            if (response?.data?.status == '1') {
                await handleGetAccordian()
                console.log(accordianList?.length, "accordianList?.length")
                if (accordianList?.length == 1) {
                    setModals(prevModals => ({
                        ...prevModals,
                        saveTemplate: { visible: false, data: null },
                    }))
                }
                notifySuccess(response?.data?.message);
                // notifySuccess('Deleted successfully');
            }
        } catch (error) {
            notify("Error");
            console.log(error)
        }
    }

    const handleGetAccordian = async () => {
        const formData = new URLSearchParams();
        formData.append("template_type", tempType);
        try {
            const response = await tenderCycle?.getAccordianLableList(formData)
            if (response?.data?.status === '1') {
                setAccordianList(response?.data?.data)

            } else {
                setAccordianList([])
            }

        } catch (error) {
            console.log(error)
        }
    }

    const handleAccApplyFilter = () => {
        setApplyTemp(true)
        commonFilter == "CYCLE" ? dispatch(filterCycleActions.filterUpdateAllKeys(applyFilter)) : commonFilter == "MIS" ? dispatch(misFilterActions.misFilterUpdateAllKeys(applyFilter)) : dispatch(trashFilterAction.trashFilterUpdateAllKeys(applyFilter));
        setModals(prevModals => ({
            ...prevModals,
            saveTemplate: { visible: false, data: null },
        }));
        setCollapseActiveKeyTemp()
    }

    useEffect(() => {
        if (open) {
            handleGetAccordian()
        }
    }, [open])

    return (
        <>

            <Drawer className='drawer_save_temp' closeIcon={<img src={skipBack} alt='' />} title="Saved Templates" placement="right"
                onClose={close}
                open={open} width={600}
                footer={  // Add footer content here
                    <div className='newTender_drawer_btn' style={{ display: collapseActiveKeyTemp !== undefined ? "flex" : "none" }} >

                        <button className="BG_Delete" disabled={collapseActiveKeyTemp === [] || collapseActiveKeyTemp === undefined ? true : false} onClick={handleDelete} >Delete</button>
                        <button className="BG_Edit" disabled={collapseActiveKeyTemp === [] || collapseActiveKeyTemp === undefined ? true : false} onClick={handleUpdateFilter} >Edit</button>
                        <button className="BG_Close" onClick={() => { close(); setCollapseActiveKeyTemp() }} >Close</button>
                        <button className="BG_mainButton BG_Add" disabled={collapseActiveKeyTemp === [] || collapseActiveKeyTemp === undefined ? true : false} onClick={handleAccApplyFilter} >Apply</button>
                    </div>
                }
            >
                {
                    accordianList?.length > 0 ?
                        <>
                            <Space direction="vertical">
                                {accordianList?.map(item => (
                                    <Collapse
                                        key={item.template_name}
                                        className="custom-collapse"
                                        collapsible="header"
                                        activeKey={collapseActiveKeyTemp}
                                        onChange={handleAccordionChange}
                                        items={[
                                            {
                                                key: item?.template_name,
                                                label: item?.template_name,
                                                extra: (
                                                    <>
                                                        <Radio
                                                            onChange={(e) => handleRadioChange(e, item?.template_name)}
                                                            checked={collapseActiveKeyTemp === item?.template_name}
                                                            value={item?.template_name}
                                                            style={{ color: 'green' }}
                                                        />
                                                    </>
                                                ),
                                                children:
                                                    <div className="bd_cards_tender">
                                                        {accGenerateChips(false)}
                                                    </div>
                                            },
                                        ]}
                                    />
                                ))}
                            </Space>
                        </>
                        :
                        <>
                            <div className="spinerWrap">
                                <div className="data_foundDiv">
                                    <img src={EmptyBox} width={100} />
                                    <div style={{ textAlign: "center", fontSize: 16 }}>No Template Found</div>
                                </div>
                            </div>
                        </>
                }

            </Drawer>




        </>

    )
}

export default FilterChipsTemplateDrawer
