// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Down } from '@icon-park/react';
import { Col, Drawer, Form, Row, Select, DatePicker, Radio, InputNumber } from 'antd';
import skipBack from "../../assets/images/skip-back.png";
import dayjs from 'dayjs';
import { useSelector } from 'react-redux';
import { filterCycleActions } from 'Redux/actions/bidgrid/cycleFilterAction';
import { useDispatch } from 'react-redux';
import moment from 'moment/moment';
import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { misFilterActions } from 'Redux/actions/bidgrid/misFilterAction';
import { trashFilterAction } from 'Redux/actions/bidgrid/trashFilterAction';


function Bd_advanceFilter({ showDrawer, advanceOpen, onAdvanceClose, updateFilter, updateFilterData, collapseActiveKeyTemp, setOpen, commonFilter, filterValData, tempType }) {


    const [filterDataValue, setFilterDataValue] = useState({
        published_date: '',
        close_exp_date: '',
        estm_value: '',
        estm_value_emd: '',
        pubdate_cust_from_date: '',
        pubdate_cust_to_date: '',
        expdate_cust_from_date: '',
        expdate_cust_to_date: '',
        amnt_custrange_operator: '',
        amnt_custrange_amount: '',
        custrange_denomination: '',
        amnt_custrange_operator_emd: '',
        amnt_custrange_amount_emd: '',
        custrange_denomination_emd: '',

    })
    const { filterValues } = useSelector((state) => state?.cycleFilter)
    const { misFilterValues } = useSelector((state => state.misFilter))
    const { trashFilterValues } = useSelector((state => state.trashFilter))


    const dispatch = useDispatch()

    const handleChangeRadio = (e) => {
        if (e.target.name === 'published_date' && e.target.value !== 'custom_date') {

            setFilterDataValue((prevState) => {
                const resetKey1 = { ...prevState, [e.target.name]: e.target?.value?.trimStart() };
                const resetKey2 = { ...resetKey1, pubdate_cust_from_date: '' };
                const resetKey3 = { ...resetKey2, pubdate_cust_to_date: '' };
                return resetKey3;
            });
        } else if (e.target.name === 'close_exp_date' && e.target.value !== 'custom_date') {
            setFilterDataValue((prevState) => {
                const resetKey1 = { ...prevState, [e.target.name]: e.target?.value?.trimStart() };
                const resetKey2 = { ...resetKey1, expdate_cust_from_date: '' };
                const resetKey3 = { ...resetKey2, expdate_cust_to_date: '' };
                return resetKey3;
            });
        }
        else if (e.target.name === 'estm_value' && e.target.value !== 'custom_range') {
            setFilterDataValue((prevState) => {
                const resetKey1 = { ...prevState, [e.target.name]: e.target?.value?.trimStart() };
                const resetKey2 = { ...resetKey1, amnt_custrange_operator: '' };
                const resetKey3 = { ...resetKey2, amnt_custrange_amount: '' };
                const resetKey4 = { ...resetKey3, custrange_denomination: '' };
                return resetKey4;

            })
        } else if (e.target.name === 'estm_value_emd' && e.target.value !== 'custom_range') {
            setFilterDataValue((prevState) => {
                const resetKey1 = { ...prevState, [e.target.name]: e.target?.value?.trimStart() };
                const resetKey2 = { ...resetKey1, amnt_custrange_operator_emd: '' };
                const resetKey3 = { ...resetKey2, amnt_custrange_amount_emd: '' };
                const resetKey4 = { ...resetKey3, custrange_denomination_emd: '' };
                return resetKey4;

            })
        }

        else {
            setFilterDataValue({ ...filterDataValue, [e.target.name]: e.target?.value?.trimStart() })
        }
    }

    const handleChange = (name, value) => {
        setFilterDataValue({ ...filterDataValue, [name]: value })

    };
    useEffect(() => {
        setFilterDataValue((prevState) => {
            const resetKey1 = { ...prevState, published_date: updateFilter?.hasOwnProperty('published_date') ? updateFilter?.published_date : '' };
            const resetKey2 = { ...resetKey1, close_exp_date: updateFilter?.hasOwnProperty('close_exp_date') ? updateFilter?.close_exp_date : '' };
            const resetKey3 = { ...resetKey2, estm_value: updateFilter?.hasOwnProperty('estm_value') ? updateFilter?.estm_value : '' };
            const resetKey4 = { ...resetKey3, estm_value_emd: updateFilter?.hasOwnProperty('estm_value_emd') ? updateFilter?.estm_value_emd : '' };
            const resetKey5 = { ...resetKey4, pubdate_cust_from_date: updateFilter?.hasOwnProperty('pubdate_cust_from_date') ? dayjs(updateFilter?.pubdate_cust_from_date) : '' };
            const resetKey6 = { ...resetKey5, expdate_cust_from_date: updateFilter?.hasOwnProperty('expdate_cust_from_date') ? dayjs(updateFilter?.expdate_cust_from_date) : '' };
            const resetKey7 = { ...resetKey6, pubdate_cust_to_date: updateFilter?.hasOwnProperty('pubdate_cust_to_date') ? dayjs(updateFilter?.pubdate_cust_to_date) : '' };
            const resetKey8 = { ...resetKey7, expdate_cust_to_date: updateFilter?.hasOwnProperty('expdate_cust_to_date') ? dayjs(updateFilter?.expdate_cust_to_date) : '' };
            const resetKey9 = { ...resetKey8, amnt_custrange_operator: updateFilter?.hasOwnProperty('amnt_custrange_operator') ? updateFilter?.amnt_custrange_operator : '' };
            const resetKey10 = { ...resetKey9, amnt_custrange_amount: updateFilter?.hasOwnProperty('amnt_custrange_amount') ? updateFilter?.amnt_custrange_amount : '' };
            const resetKey11 = { ...resetKey10, custrange_denomination: updateFilter?.hasOwnProperty('custrange_denomination') ? updateFilter?.custrange_denomination : '' };
            const resetKey12 = { ...resetKey11, amnt_custrange_operator_emd: updateFilter?.hasOwnProperty('amnt_custrange_operator_emd') ? updateFilter?.amnt_custrange_operator_emd : '' };
            const resetKey13 = { ...resetKey12, amnt_custrange_amount_emd: updateFilter?.hasOwnProperty('amnt_custrange_amount_emd') ? updateFilter?.amnt_custrange_amount_emd : '' };
            const resetKey14 = { ...resetKey13, custrange_denomination_emd: updateFilter?.hasOwnProperty('custrange_denomination_emd') ? updateFilter?.custrange_denomination_emd : '' };
            return resetKey14;
        });
    }, [updateFilter])

    useEffect(() => {
        setFilterDataValue((prevState) => {
            const resetKey1 = { ...prevState, published_date: filterValData?.published_date };
            const resetKey2 = { ...resetKey1, close_exp_date: filterValData?.close_exp_date };
            const resetKey3 = { ...resetKey2, estm_value: filterValData?.estm_value };
            const resetKey4 = { ...resetKey3, estm_value_emd: filterValData?.estm_value_emd };
            const resetKey5 = { ...resetKey4, pubdate_cust_from_date: filterValData?.pubdate_cust_from_date === "" ? filterValData?.pubdate_cust_from_date : dayjs(filterValData?.pubdate_cust_from_date) };
            const resetKey6 = { ...resetKey5, expdate_cust_from_date: filterValData?.expdate_cust_from_date === "" ? filterValData?.expdate_cust_from_date : dayjs(filterValData?.expdate_cust_from_date) };
            const resetKey7 = { ...resetKey6, pubdate_cust_to_date: filterValData?.pubdate_cust_to_date === "" ? filterValData?.pubdate_cust_to_date : dayjs(filterValData?.pubdate_cust_to_date) };
            const resetKey8 = { ...resetKey7, expdate_cust_to_date: filterValData?.expdate_cust_to_date === "" ? filterValData?.expdate_cust_to_date : dayjs(filterValData?.expdate_cust_to_date) };
            const resetKey9 = { ...resetKey8, amnt_custrange_operator: filterValData?.amnt_custrange_operator };
            const resetKey10 = { ...resetKey9, amnt_custrange_amount: filterValData?.amnt_custrange_amount };
            const resetKey11 = { ...resetKey10, custrange_denomination: filterValData?.custrange_denomination };
            const resetKey12 = { ...resetKey11, amnt_custrange_operator_emd: filterValData?.amnt_custrange_operator_emd };
            const resetKey13 = { ...resetKey12, amnt_custrange_amount_emd: filterValData?.amnt_custrange_amount_emd };
            const resetKey14 = { ...resetKey13, custrange_denomination_emd: filterValData?.custrange_denomination_emd };
            return resetKey14;
        });
    }, [commonFilter == "CYCLE" ? filterValues : commonFilter == "MIS" ? misFilterValues : trashFilterValues])

    const handleCreate = async () => {
        if (updateFilterData) {
            const nonEmptyKeyValuePairs = Object.entries(filterDataValue)?.filter(([key, value]) => value !== '').map(([key, value]) => {
                if (key === 'pubdate_cust_from_date' || key === 'pubdate_cust_to_date' || key === 'expdate_cust_from_date' || key === 'expdate_cust_to_date') {

                    let val = dayjs(value)?.format('YYYY-MM-DD')
                    return { [key]: val }
                } else {
                    return { [key]: value }
                }
            })
            const nonEmptyKeysString = nonEmptyKeyValuePairs.map(obj => Object.keys(obj)[0]).join(',');
            const nonEmptyValuesString = nonEmptyKeyValuePairs.map(obj => Object.values(obj)[0]).join(',');
            const formData = new URLSearchParams();
            formData.append("template_type", tempType);
            formData.append('filter_field_name', nonEmptyKeysString);
            formData.append('filter_field_value', nonEmptyValuesString);
            formData.append('template_name', collapseActiveKeyTemp);
            const response = await tenderCycle.bdUpdateTempFilterChips(formData)
            if (response?.data?.status === '1') {
                // setcollapseActiveKeyTemp()
                onAdvanceClose()
                setOpen(true)
                // onClose();
            }

        }
        else {
            let obj = {
                ...filterValData,
                published_date: filterDataValue?.published_date ? filterDataValue?.published_date : '',
                close_exp_date: filterDataValue?.close_exp_date ? filterDataValue?.close_exp_date : '',
                estm_value: filterDataValue?.estm_value ? filterDataValue?.estm_value : '',
                estm_value_emd: filterDataValue?.estm_value_emd ? filterDataValue?.estm_value_emd : '',
                pubdate_cust_from_date: filterDataValue?.pubdate_cust_from_date ? filterDataValue?.pubdate_cust_from_date === "" ? filterDataValue?.pubdate_cust_from_date : dayjs(filterDataValue?.pubdate_cust_from_date).format('YYYY-MM-DD') : '',
                pubdate_cust_to_date: filterDataValue?.pubdate_cust_to_date ? filterDataValue?.pubdate_cust_to_date === "" ? filterDataValue?.pubdate_cust_to_date : dayjs(filterDataValue?.pubdate_cust_to_date).format('YYYY-MM-DD') : '',
                expdate_cust_from_date: filterDataValue?.expdate_cust_from_date ? filterDataValue?.expdate_cust_from_date === "" ? filterDataValue?.expdate_cust_from_date : dayjs(filterDataValue?.expdate_cust_from_date).format('YYYY-MM-DD') : '',
                expdate_cust_to_date: filterDataValue?.expdate_cust_to_date ? filterDataValue?.expdate_cust_to_date === "" ? filterDataValue?.expdate_cust_to_date : dayjs(filterDataValue?.expdate_cust_to_date).format('YYYY-MM-DD') : '',
                amnt_custrange_operator: filterDataValue?.amnt_custrange_operator ? filterDataValue?.amnt_custrange_operator : '',
                amnt_custrange_amount: filterDataValue?.amnt_custrange_amount ? filterDataValue?.amnt_custrange_amount : '',
                custrange_denomination: filterDataValue?.custrange_denomination ? filterDataValue?.custrange_denomination : '',
                amnt_custrange_operator_emd: filterDataValue?.amnt_custrange_operator_emd ? filterDataValue?.amnt_custrange_operator_emd : '',
                amnt_custrange_amount_emd: filterDataValue?.amnt_custrange_amount_emd ? filterDataValue?.amnt_custrange_amount_emd : '',
                custrange_denomination_emd: filterDataValue?.custrange_denomination_emd ? filterDataValue?.custrange_denomination_emd : '',


                page_number: 0,
                limit: 25,
            }


            commonFilter === 'CYCLE' ? dispatch(filterCycleActions.filterUpdateIndividualKeys(obj)) : commonFilter === 'MIS' ? dispatch(misFilterActions.misFilterUpdateIndividualKeys(obj)) : dispatch(trashFilterAction.trashFilterUpdateIndividualKeys(obj));
            onAdvanceClose();
        }

    };


    const handleReset = () => {
        let objArr = Object.keys(filterDataValue).map(key => {
            return key.toString()
        })
        commonFilter == "CYCLE" ? dispatch(filterCycleActions?.filterResetIndividualKeys(objArr)) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterResetIndividualKeys(objArr)) : dispatch(trashFilterAction?.trashFilterResetIndividualKeys(objArr))
        onAdvanceClose()
    }
    const maxDate = moment().endOf('day');
    const disabledDate = current => current && current > maxDate;

    const handleChangeDate = (name, value) => {

        if (name === "pubdate_cust_from_date") {
            const date = new Date();
            const year = date?.getFullYear();
            const month = (date?.getMonth() + 1)?.toString()?.padStart(2, "0");
            const day = date?.getDate().toString().padStart(2, "0");
            const nextDate = `${year}-${month}-${day}`
            setFilterDataValue((pre) => ({
                ...pre,
                pubdate_cust_from_date: value,
                pubdate_cust_to_date: dayjs(nextDate)
            }))
        }
        else {
            setFilterDataValue((pre) => ({
                ...pre,
                [name]: value
            }))
        }


        if (name === "expdate_cust_from_date") {
            const nextDay = dayjs(value).add(1, 'day');
            // const nextDate = `${year}-${month}-${nextDay}`
            setFilterDataValue((pre) => ({
                ...pre,
                expdate_cust_from_date: value,
                expdate_cust_to_date: dayjs(nextDay)
            }))
        }
        else {
            setFilterDataValue((pre) => ({
                ...pre,
                [name]: value
            }))
        }
    }

    return (
        <Drawer className='bd_drawer_main bd-advanceFilter' closeIcon={<img src={skipBack} alt='' />}
            title={updateFilterData === false ? "Advance Filter" : "Edit Advance Filter"} placement="right" onClose={onAdvanceClose} open={advanceOpen}
            width={700}
            extra={
                <button className='BG_mainButton' onClick={showDrawer}> Basic Filter</button>
            }
            footer={
                <div className="bd_drawerFoot">
                    <button className='BG_ghostButton' onClick={handleReset}>Reset</button>
                    <button className='BG_mainButton' onClick={handleCreate}>{updateFilterData === false ? 'Filter' : 'Update'}</button>
                </div>
            }
        >
            <div>
                <Form
                    layout="vertical"
                >

                    <Form.Item label="Publication Date:" >
                        <Radio.Group onChange={handleChangeRadio} name="published_date" value={filterDataValue?.published_date}>
                            <Row gutter={[8, 16]}>
                                <Col span={8}>
                                    <Radio value="today"> Today </Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="yesterday"> Yesterday </Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="last_7_days"> Last 7 Days </Radio>
                                </Col>

                                <Col span={8}>
                                    <Radio value="last_30_days">Last 30 Days</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="this_month">This Month</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="last_month">Last Month</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="custom_date" >Custom Dates</Radio>
                                </Col>
                            </Row>

                        </Radio.Group>
                        {filterDataValue.published_date === 'custom_date' ?
                            <div className='bd_customOption' style={filterDataValue?.published_date ? { display: "block" } : { display: "none" }}>

                                <Row gutter={24}>
                                    <Col span={12}>
                                        <Form.Item label="From Date">
                                            <DatePicker
                                                name='pubdate_cust_from_date'
                                                disabledDate={disabledDate}
                                                onChange={(value) => {
                                                    handleChangeDate('pubdate_cust_from_date', value)
                                                }}
                                                // onChange={(e) => {
                                                //     setFilterDataValue({ ...filterDataValue, pubdate_cust_from_date: e })
                                                // }}
                                                value={filterDataValue?.pubdate_cust_from_date}

                                            />
                                        </Form.Item>
                                    </Col>
                                    <Col span={12}>
                                        <Form.Item label="To Date">
                                            <DatePicker
                                                name='pubdate_cust_to_date'
                                                disabledDate={disabledDate}
                                                onChange={(value) => {
                                                    handleChangeDate('pubdate_cust_to_date', value)
                                                }}
                                                // onChange={(e) => {
                                                //     setFilterDataValue({ ...filterDataValue, pubdate_cust_to_date: e })
                                                // }}
                                                value={filterDataValue?.pubdate_cust_to_date}
                                            />
                                        </Form.Item>
                                    </Col>
                                </Row>

                            </div> : ''}
                    </Form.Item>

                    <Form.Item label="Closing Date:">
                        <Radio.Group onChange={handleChangeRadio} name="close_exp_date" value={filterDataValue?.close_exp_date}>
                            <Row gutter={[8, 16]}>
                                <Col span={8}>
                                    <Radio value="today"> Today </Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="tomorrow"> Tomorrow </Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="upcome_7_days"> Upcoming 7 Days </Radio>
                                </Col>

                                <Col span={8}>
                                    <Radio value="upcome_30_days">Upcoming 30 Days</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="upcome_month">Upcoming Month</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="last_month">Last Month</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="custom_date">Custom Dates</Radio>
                                </Col>
                            </Row>
                        </Radio.Group>
                        {filterDataValue.close_exp_date === 'custom_date' ?
                            <div className='bd_customOption' style={filterDataValue?.close_exp_date ? { display: "block" } : { display: "none" }}>

                                <Row gutter={24}>
                                    <Col span={12}>
                                        <Form.Item label="From Date">
                                            <DatePicker
                                                name='expdate_cust_from_date'
                                                onChange={(value) => {
                                                    handleChangeDate('expdate_cust_from_date', value)
                                                }}


                                                value={filterDataValue?.expdate_cust_from_date}
                                            />
                                        </Form.Item>
                                    </Col>
                                    <Col span={12}>
                                        <Form.Item label="To Date">
                                            <DatePicker
                                                name='expdate_cust_to_date'
                                                onChange={(e) => {
                                                    setFilterDataValue({ ...filterDataValue, expdate_cust_to_date: e })
                                                }}
                                                value={filterDataValue?.expdate_cust_to_date}
                                            />
                                        </Form.Item>
                                    </Col>
                                </Row>

                            </div> : ''}
                    </Form.Item>

                    <Form.Item label="Tender Value:">
                        <Radio.Group onChange={handleChangeRadio} name="estm_value" value={filterDataValue?.estm_value} >
                            <Row gutter={[8, 16]}>
                                <Col span={8}>
                                    <Radio value="not_specified">Not Specified </Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="1-99999">Below 1 Lac</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="100000-9999999">1 Lac to 1 Cr</Radio>
                                </Col>

                                <Col span={8}>
                                    <Radio value="10000000-99999999">1 Cr to 10 Cr</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="100000000-499999999">10 Cr to 50 Cr</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="500000000-999999999">50 Cr to 100 Cr</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="1000000000">Above 100 Cr</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="custom_range">Custom Range</Radio>
                                </Col>
                            </Row>
                        </Radio.Group>
                        {filterDataValue.estm_value === 'custom_range' ?
                            <div className='bd_customOption' style={filterDataValue.estm_value ? { display: "block" } : { display: "none" }}>
                                <Row gutter={24}>
                                    <Col span={8}>
                                        <Form.Item label="Operator">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select operator"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                options={[
                                                    {
                                                        value: '',
                                                        label: '--Select--',
                                                    },
                                                    {
                                                        value: '<=',
                                                        label: '<=',
                                                    },
                                                    {
                                                        value: '>=',
                                                        label: '>=',
                                                    },
                                                ]}
                                                name="amnt_custrange_operator"
                                                value={filterDataValue?.amnt_custrange_operator}
                                                onChange={(value) => handleChange('amnt_custrange_operator', value)}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>
                                    <Col span={8}>
                                        <Form.Item label="Amount">
                                            <InputNumber value={filterDataValue?.amnt_custrange_amount} name='amnt_custrange_amount' onChange={(value) => handleChange('amnt_custrange_amount', value)} />
                                        </Form.Item>
                                    </Col>
                                    <Col span={8}>
                                        <Form.Item label="Denomination">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select denomination"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                options={[
                                                    {
                                                        value: '',
                                                        label: '--All--',
                                                    },
                                                    {
                                                        value: 'hundred',
                                                        label: 'Hundred',
                                                    },
                                                    {
                                                        value: 'thousand',
                                                        label: 'Thousand',
                                                    },
                                                    {
                                                        value: 'lakhs',
                                                        label: 'Lakhs',
                                                    },
                                                    {
                                                        value: 'crores',
                                                        label: 'Crores',
                                                    },
                                                    {
                                                        value: 'million',
                                                        label: 'Million',
                                                    },
                                                    {
                                                        value: 'billion',
                                                        label: 'Billion',
                                                    },
                                                    {
                                                        value: 'trillion',
                                                        label: 'Trillion',
                                                    },
                                                ]}
                                                name="custrange_denomination"
                                                value={filterDataValue?.custrange_denomination}
                                                onChange={(value) => handleChange('custrange_denomination', value)}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>
                                </Row>
                            </div> : ''}
                    </Form.Item>


                    <Form.Item label="Tender EMD Value:">
                        <Radio.Group onChange={handleChangeRadio} name='estm_value_emd' value={filterDataValue?.estm_value_emd}>
                            <Row gutter={[8, 16]}>
                                <Col span={8}>
                                    <Radio value="not_specified">Not Specified </Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="1-99999">Below 1 Lac</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="100000-9999999">1 Lac to 1 Cr</Radio>
                                </Col>

                                <Col span={8}>
                                    <Radio value="10000000-99999999">1 Cr to 10 Cr</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="100000000-499999999">10 Cr to 50 Cr</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="500000000-999999999">50 Cr to 100 Cr</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="1000000000">Above 100 Cr</Radio>
                                </Col>
                                <Col span={8}>
                                    <Radio value="custom_range">Custom Range</Radio>
                                </Col>
                            </Row>
                        </Radio.Group>
                        {filterDataValue.estm_value_emd === 'custom_range' ?
                            <div className='bd_customOption' style={filterDataValue.estm_value_emd ? { display: "block" } : { display: "none" }}>

                                <Row gutter={24}>
                                    <Col span={8}>
                                        <Form.Item label="Operator">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select operator"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                options={[
                                                    {
                                                        value: '',
                                                        label: '--Select--',
                                                    },
                                                    {
                                                        value: '<=',
                                                        label: '<=',
                                                    },
                                                    {
                                                        value: '>=',
                                                        label: '>=',
                                                    },
                                                ]}
                                                name="amnt_custrange_operator_emd"
                                                value={filterDataValue?.amnt_custrange_operator_emd}
                                                onChange={(value) => handleChange('amnt_custrange_operator_emd', value)}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>
                                    <Col span={8}>
                                        <Form.Item label="Amount">
                                            <InputNumber name='amnt_custrange_amount_emd' value={filterDataValue.amnt_custrange_amount_emd} onChange={(value) => handleChange('amnt_custrange_amount_emd', value)} />
                                        </Form.Item>
                                    </Col>
                                    <Col span={8}>
                                        <Form.Item label="Denomination">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select denomination"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                options={[
                                                    {
                                                        value: '',
                                                        label: '--All--',
                                                    },
                                                    {
                                                        value: 'hundred',
                                                        label: 'Hundred',
                                                    },
                                                    {
                                                        value: 'thousand',
                                                        label: 'Thousand',
                                                    },
                                                    {
                                                        value: 'lakhs',
                                                        label: 'Lakhs',
                                                    },
                                                    {
                                                        value: 'crores',
                                                        label: 'Crores',
                                                    },
                                                    {
                                                        value: 'million',
                                                        label: 'Million',
                                                    },
                                                    {
                                                        value: 'billion',
                                                        label: 'Billion',
                                                    },
                                                    {
                                                        value: 'trillion',
                                                        label: 'Trillion',
                                                    },
                                                ]}
                                                name="custrange_denomination_emd"
                                                value={filterDataValue?.custrange_denomination_emd}
                                                onChange={(value) => handleChange('custrange_denomination_emd', value)}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>
                                </Row>

                            </div>
                            : ''}
                    </Form.Item>
                </Form>
            </div>
        </Drawer>
    )
}

export default Bd_advanceFilter
