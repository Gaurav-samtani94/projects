// @ts-nocheck
import React, { useCallback, useRef, useState, useEffect } from 'react';
import { Drawer, Avatar, Mentions, Modal, Upload, Button, message } from 'antd';
import { CloseOutlined, UploadOutlined, SendOutlined } from '@ant-design/icons';
import debounce from 'lodash/debounce';
import skipBack from "../../assets/images/skip-back.png";
import docIcon from "../../assets/images/icons/file_present.png"
import emptyCommentImg from "../../assets/images/chat.png"

import { TodoServices } from 'Services/bidgrid/todo/TodoServices';
import { useSelector } from 'react-redux';
import dayjs from 'dayjs';
import { Write, Close } from '@icon-park/react';
import { chat_socket_url } from 'utils/configurable';
import { docurlchat } from 'utils/configurable';
import { TimeConverter } from '../TimeConverter/TimeConverter';
const getBase64 = (file) =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
    });




function TodoComments(props) {
    const { comment, setComment, dropdownValState, item, detailPage, userGetCommentLists, setTenderCommentData, projectId, onCloseOfComment } = props
    const [users, setUsers] = useState();
    const [inputValue, setInputValue] = useState('');
    const [parentId, setParentId] = useState(0)
    const [editId, setEditId] = useState(null)
    const [getUserCommentData, setGetUserCommentData] = useState([])
    const { socket, isConnected } = useSelector((state) => state.socket);
    const replyfocus = useRef(null);
    const [replyStatus, setReplyStatus] = useState(false);
    const { userBidInfo } = useSelector((state) => state?.userDetails)
    const [replyUser, setReplyUser] = useState({})
    // Upload
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
    const [fileList, setFileList] = useState([]);

    useEffect(() => {
        if (isConnected) {
            if (comment) {
                const socketListener = (data) => {
                    console.log("comment drawer socketdata", data)
                    setGetUserCommentData(prevComments => {
                        const existingIndex = prevComments.findIndex(comment => comment.id === data.id);
                        if (existingIndex !== -1) {
                            return prevComments.map((comment, index) =>
                                index === existingIndex ? data : comment
                            );
                        } else {
                            return [...prevComments, data];
                        }
                    });
                    setTenderCommentData(prevComments => {
                        const existingIndex = prevComments.findIndex(comment => comment.id === data.id);
                        if (existingIndex !== -1) {
                            return prevComments.map((comment, index) =>
                                index === existingIndex ? data : comment
                            );
                        } else {
                            return [...prevComments, data];
                        }
                    });
                }

                socket.on(item?.id, socketListener);
                return () => {
                    socket.off(item?.id, socketListener);
                };
            }
        } else {
            return
        }
    }, [isConnected, comment])

    useEffect(() => {
        let usersMapped = dropdownValState?.filter(item => item.isactive === 1)?.map((val) => {
            const inputString = val.userfullname
            const words = inputString?.toLowerCase()?.split(' ');
            const result = words?.map((word, index) => (index === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)))?.join('');
            return { id: val?.id, userfullname: result, profileimg: val?.profileimg, profileimg_path: val?.profileimg_path }
        })
        setUsers(usersMapped)
    }, [dropdownValState])

    const onSearch = useCallback(
        debounce(async (search) => {
            const filteredUsers = users?.filter(item => item?.id !== userBidInfo?.id)?.map((item) => {
                let userfullnameInp = item?.userfullname
                if (userfullnameInp?.includes(search?.toLowerCase())) {
                    return item
                }
            })
        }, 300),
        []
    );

    const userGetCommentList = async () => {
        if (detailPage) {
            userGetCommentLists(setGetUserCommentData)
        } else if (projectId) {

            const formData = new URLSearchParams();
            formData.append('task_id', item?.id)
            formData.append('tender_id', projectId)
            try {
                const response = await TodoServices.TenderTodoCommentList(formData)
                if (response?.data?.status === '1') {
                    setGetUserCommentData(response?.data?.data)
                } else {
                    setGetUserCommentData([])
                }
            } catch (error) {
                console.log('error')
            }
        } else {
            const formData = new URLSearchParams();
            formData.append('task_id', item?.id)
            try {
                const response = await TodoServices.userCommentList(formData)
                if (response?.data?.status === '1') {
                    setGetUserCommentData(response?.data?.data)
                } else {
                    setGetUserCommentData([])
                }
            } catch (error) {
                console.log('error')
            }
        }

    }

    const AddComment = async () => {

        if (inputValue !== '') {
            let userVar = []
            inputValue?.split(' ')?.filter((val) => val?.includes('@'))
                ?.map((item) => {
                    return users?.filter((elem) => '@' + elem.userfullname === item)?.forEach((value) => {
                        userVar.push(value.id)
                    });
                });
            const uniqueArray = [...new Set(userVar)];
            if (isConnected) {
                if (projectId) {
                    let socketTenderTodoShare = { comment_id: editId, file: fileList, tender_id: projectId, task_id: item?.id, comment_txt: inputValue, parent_id: parentId, ping_users_info: uniqueArray?.join(',') }
                    socket.emit('tender_todo_comment', socketTenderTodoShare);
                    console.log("socketTenderTodoShare", socketTenderTodoShare)
                } else if (detailPage) {
                    let socketDetailShare = { comment_id: editId, file: fileList, tender_id: item?.id, parent_id: parentId, comment_txt: inputValue, ping_users_info: uniqueArray?.join(',') }
                    socket.emit('tender_comment', socketDetailShare);
                    console.log("socketDetailShare", socketDetailShare)
                    // await userGetCommentLists(setGetUserCommentData)
                } else {
                    let socketTodoShare = { comment_id: editId, file: fileList, task_id: item?.id, comment_txt: inputValue, parent_id: parentId, ping_users_info: uniqueArray?.join(',') }
                    socket.emit('comment', socketTodoShare);
                    console.log("socketTodoShare", socketTodoShare)
                }
            }
            handleCancelReply()
        }
    }

    const handleChangeComment = (value) => {
        if (value.startsWith(' ')) {
            setInputValue(value.trimStart());
        } else {
            setInputValue(value);
        }
    };

    useEffect(() => {
        if (comment === true) {
            userGetCommentList()
        }
    }, [comment])



    const commentSection = (inputValue) => {
        let inputArr = inputValue?.split(' ')
        return (
            <>
                {
                    inputArr?.map((item, index) => {
                        return (
                            <span className={item.includes('@') ? "userTag" : ""} key={index}>{item}&nbsp;</span>
                        )
                    })
                }
            </>
        )
    }


    const handleCancel = () => setPreviewOpen(false);
    const handlePreview = async (file) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj);
        }
        setPreviewImage(file.url || file.preview);
        setPreviewOpen(true);
        setPreviewTitle(
            file.name || file.url.substring(file.url.lastIndexOf('/') + 1)
        );
    };

    const propss = {
        name: 'file',
        action: 'https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188',
        headers: {
            authorization: 'authorization-text',
        },
        onChange(info) {
            if (info.file.status !== 'uploading') {
                console.log(info.file, info.fileList);
            }
            if (info.file.status === 'done') {
                setFileList(info.fileList)
                message.success(`${info.file.name} file uploaded successfully`);
            } else if (info.file.status === 'error') {
                setFileList([])
                message.error(`${info.file.name} file upload failed.`);
            }
        },
    };
    const handleChange = ({ fileList: newFileList }) => setFileList(newFileList);
    const uploadButton = (
        <button
            style={{
                border: 0,
                background: 'none',
            }}
            type="button"
        >
            <UploadOutlined />
        </button>
    );
    const documentBlobReq = async (doc_name, apiUrl) => {
        const fullUrl = window.location.href;
        const urlObject = new URL(fullUrl);
        const protocol = urlObject.protocol;
        const hostname = urlObject.host;
        const domain = `${protocol}//${hostname}`;
        const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
        const response = await fetch(proxyUrl)
        const blobData = await response?.blob()
        const fileURL = window.URL.createObjectURL(blobData);
        let alink = document.createElement("a");
        alink.href = fileURL;
        alink.download = doc_name;
        alink.click();
    }

    const documentDownload = (item) => {
        const apiUrl = `${docurlchat}${item?.file_path}/${item?.file_name}`;
        documentBlobReq(item?.file_name, apiUrl)
    }
    const handleCancelReply = () => {
        setReplyUser({})
        setReplyStatus(false)
        setEditId(null);
        setInputValue('')
        setParentId(0)
        setFileList([])
    }
    const handleReply = (item) => {
        setEditId(null);
        setInputValue('')
        setParentId(item?.id);
        setReplyUser(item)
        replyfocus.current.focus()
        setReplyStatus(true)
    }
    const handleEditParent = (item) => {
        setEditId(item?.id);
        setParentId(0);
        setFileList([])
        setInputValue(item?.comment_txt)
        setReplyUser(item)
        setReplyStatus(true)
        replyfocus.current.focus()
    }

    const handleEditChild = (item) => {
        console.log(item)
        setEditId(item?.id);
        setParentId(item?.parent_id);
        setInputValue(item?.comment_txt)
        setReplyUser(item)
        setReplyStatus(true)
        replyfocus.current.focus()
    }
    return (
        <Drawer className='bs_todo_drawer_comment' closeIcon={<img src={skipBack} alt='' />} title="Comments" placement="right" onClose={() => { setComment(false); onCloseOfComment() }}
            open={comment} width={600}
            footer={[
                <>
                    {replyStatus &&
                        <div className="reply_wrap">
                            {editId ? 'Edit comment' :
                                <span> Reply to : {dropdownValState?.filter(val => val?.id === parseInt(replyUser?.created_by))?.map(currentElem => currentElem?.userfullname)}</span>}

                        </div>
                    }
                    <div className='input_comment'>

                        <Upload
                            // action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
                            listType="picture-card"
                            fileList={fileList}
                            onPreview={handlePreview}
                            beforeUpload={() => false}
                            onChange={handleChange}
                        >
                            {fileList.length >= 1 ? null : uploadButton}
                        </Upload>
                        <Modal
                            open={previewOpen}
                            title={previewTitle}
                            footer={null}
                            onCancel={handleCancel}
                        >
                            <img
                                alt="example"
                                style={{
                                    width: '100%',
                                }}
                                src={previewImage}
                            />
                        </Modal>
                        <Mentions
                            ref={replyfocus}
                            onSearch={onSearch}
                            placeholder={replyStatus ? editId ? 'Edit Comment..' : 'Reply Comment..' : 'Type Comment..'}
                            value={inputValue}
                            onChange={(value) => handleChangeComment(value)}
                            options={users?.filter(item => item?.id !== userBidInfo?.id)?.map(({ userfullname, profileimg, profileimg_path }) => ({
                                key: userfullname,
                                value: userfullname,
                                className: 'antd-demo-dynamic-option',
                                label: (
                                    <div className="tagUser_det">
                                        {
                                            profileimg !== null ?
                                                <img src={`${docurlchat}${profileimg_path}/${profileimg}`} alt='' />
                                                :
                                                <Avatar
                                                    style={{ backgroundColor: !profileimg && '#f56a00' }}
                                                    size="medium"
                                                    src={docurlchat + profileimg_path + "/" + profileimg}
                                                >
                                                    {userfullname?.charAt(0)}
                                                </Avatar>
                                        }

                                        <span >{userfullname}</span>
                                    </div>
                                ),
                            }))}
                        />
                        {replyStatus && <button className="close_text" onClick={handleCancelReply}>
                            <Close theme="outline" size="16" fill="#000" strokeWidth={3} strokeLinecap="butt" />
                        </button>}
                        <div className="send_icon" onClick={AddComment}> <SendOutlined /></div>
                    </div >
                </>
            ]}
        >


            {
                getUserCommentData?.length > 0 ?
                    <div className='todo_comments_cont'>
                        {
                            getUserCommentData?.filter((val) => val.parent_id == 0)?.map((item, index) => {
                                const createdBy = dropdownValState?.find(val => val?.id === parseInt(item?.created_by))
                                return (
                                    <div className='todo_comments' key={index}>
                                        <div className='todo_comment_img'>

                                            <Avatar src={docurlchat + createdBy?.profileimg_path + "/" + createdBy?.profileimg} style={{ backgroundColor: !createdBy?.profileimg && '#f56a00' }} size="large"  >
                                                {createdBy?.userfullname?.charAt(0)}
                                            </Avatar>
                                        </div>
                                        <div className='todo_comment_main_cont'>
                                            <div className='todo_comment_name'>
                                                <span>{dropdownValState?.filter(val => val?.id === parseInt(item?.created_by))?.map(currentElem => currentElem?.userfullname)}</span>
                                                <div className="d-flex" style={{ gap: 15 }}>
                                                    <p>{dayjs(item?.created_at).format('MMMM DD, YYYY h:mm A')}</p>
                                                    {item?.created_by === userBidInfo?.id && <button className="editComment" onClick={() => handleEditParent(item)}>
                                                        <Write theme="outline" size="16" fill="#9b9b9b" strokeWidth={4} strokeLinecap="butt" />
                                                    </button>}
                                                </div>
                                            </div>
                                            <div className='todo_comment_para'>
                                                <div> {commentSection(item?.comment_txt)}</div>
                                                {item?.file_name &&
                                                    <div onClick={() => documentDownload(item)}>
                                                        <img src={docIcon} alt="" />
                                                    </div>
                                                }
                                            </div>

                                            <div className="btn_flex">
                                                <button onClick={() => handleReply(item)}>Reply</button>
                                            </div>

                                            {getUserCommentData?.filter((val) => val?.parent_id == item?.id)?.map((elem, index) => {
                                                const createdByChild = dropdownValState?.find(val => val?.id === parseInt(elem?.created_by))
                                                return (
                                                    <div className='todo_comments_reply' key={index}>
                                                        <div className='todo_reply_img'>
                                                            <Avatar src={docurlchat + createdByChild?.profileimg_path + "/" + createdByChild?.profileimg}
                                                                style={{ backgroundColor: !createdByChild?.profileimg && '#f56a00' }} size="large"  >
                                                                {createdByChild?.userfullname?.charAt(0)}
                                                            </Avatar>
                                                        </div>
                                                        <div className='todo_reply_main_cont'>
                                                            <div className='todo_reply_name'>
                                                                <span>{dropdownValState?.filter(val => val?.id === parseInt(elem?.created_by))?.map(currentElem => currentElem?.userfullname)}</span>

                                                                <div className="d-flex" style={{ gap: 15 }}>
                                                                    <p>{elem?.created_at !== null ? `${dayjs(elem?.created_at).format('MMMM DD, YYYY')} ${TimeConverter(elem?.created_at)}` : '-'}</p>
                                                                    <button className="editComment" onClick={() => handleEditChild(elem)}>
                                                                        <Write theme="outline" size="16" fill="#9b9b9b" strokeWidth={4} strokeLinecap="butt" />
                                                                    </button>
                                                                </div>
                                                            </div>
                                                            <div className='todo_reply_para'>
                                                                <p>{commentSection(elem?.comment_txt)}</p>
                                                                {elem?.file_name !== null &&
                                                                    <div onClick={() => documentDownload(item)}>
                                                                        <img src={docIcon} alt="" />
                                                                    </div>
                                                                }
                                                            </div>
                                                        </div>
                                                    </div>
                                                )
                                            })}

                                        </div>
                                    </div >
                                )
                            })
                        }


                    </div>

                    :
                    <div className="noComment_wrap">
                        <img src={emptyCommentImg} alt="" />
                        <p>Not Comment Yet...</p>
                    </div>
            }

        </Drawer >
    )
}

export default TodoComments
