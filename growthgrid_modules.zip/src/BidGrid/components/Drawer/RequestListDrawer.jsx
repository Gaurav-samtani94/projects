// @ts-nocheck
import React, { useEffect, useMemo, useState } from 'react';
import Comment from '../../../BidGrid/assets/images/icons/chat.png';
import GenerateRequest from '../Drawer/GenerateRequest.jsx';
import AddRequestDrawer from '../Drawer/AddRequestDrawer';
import downloadFileIcon from "../../assets/images/download.png";
import skipBack from '../../assets/images/skip-back.png';
import { Drawer, Select } from 'antd';
import { RequestApi } from 'Services/bidgrid/tenderList/RequestApi';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import dayjs from 'dayjs';
import { Down } from '@icon-park/react';
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { docurlchat } from 'utils/configurable';
import { TimeConverter } from '../TimeConverter/TimeConverter';
const createdByOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }, { value: '3', label: 'Approval' }]
const assignedToOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }]


const RequestListDrawer = ({ id, replay, showRequestList, onCloseDrawer, setOpenStatsDrawer, openStatsDrawer, requestList, userListData, showDrawer, fetchRequestListForDrawer }) => {

    const { userBidInfo } = useSelector((state) => state?.userDetails)
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);


    const tenderNames = (str) => {
        const htmlTagPattern = /<[^>]*>/g;
        const htmlTags = str?.match(htmlTagPattern);

        if (htmlTags) {
            const stringWithoutHtmlTags = str.replace(htmlTagPattern, '');
            const capitalizedString = capitalizeExceptPrepositionsAndLowerCase(stringWithoutHtmlTags);
            return <span>{capitalizedString}</span>;
        } else {
            return <span>{capitalizeExceptPrepositionsAndLowerCase(str)}</span>;
        }
    }

    const downloadFile = async (url) => {
        try {
            const response = await fetch(url);
            const blob = await response.blob();
            const href = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = href;
            link.setAttribute('download', '');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (error) {
            console.error('Error downloading file:', error);
        }
    };
    // request status
    const requestStatus = async (val, e, index) => {
        const formData = new FormData();
        formData.append('tender_id', val?.tender_id)
        formData.append('request_id', val?.id)
        formData.append('subject', val?.subject)
        formData.append('desc_details', val?.desc_details?.replace(/<[^>]*>/g, ''))
        formData.append('req_from_userid', val?.req_from_userid)
        formData.append('curr_status', Number(e))
        formData.append('comment_txt', val?.comment_txt)
        formData.append('req_to_userid', val?.req_to_userid)


        try {
            const response = await RequestApi.updateRequest(formData)
            if (response?.data?.status === "1") {
                notifySuccess('Status update successfully')
                await fetchRequestListForDrawer(val?.tender_id)

            } else {
                notify(response?.response?.data?.message)
                // setSpinner(false)
            }
        } catch (error) {
            // setSpinner(false)
        }
    }


    // useEffect(() => {
    //     // Initialize statusData with initial status for each request item
    //     setStatusData(requestList?.map(item => item?.curr_status));
    // }, [requestList]);

    const showAllRequestList = () => {
        return (
            requestList?.length > 0 ? requestList?.map((item, index) => {

                let createdBy = userListData?.find((userItem) => userItem.id == item.req_from_userid)?.userfullname;

                let RequestTo = userListData?.find((userItem) => userItem.id == item.req_to_userid)?.userfullname;

                let fileUrl = `${docurlchat}${item?.file_path}/${item?.file_name}`;
                return (
                    <div className='bd_req_drw_main dashBorad_request'>
                        <div className="subject">Subject - <span>{item?.subject}</span></div>

                        <div className='desc_req_drawer'>

                            <div className='tenderTitle'>
                                {tenderNames(item?.desc_details)}
                            </div>
                            <a href="#" className="downloadFile" onClick={() => downloadFile(fileUrl)}>
                                <span><img src={downloadFileIcon} /></span>
                                Download File
                            </a>
                        </div>

                        <div className="req_flex" onClick={() => replay(item?.id)}>
                            <div className='desc_pera_drwer'>Request To - <span>{RequestTo}</span></div>
                            <div className='desc_pera_drwer'>Created By - <span>{createdBy}</span></div>
                        </div>

                        <div className='bd_rq_drawer'>
                            <div>
                                <Select
                                    className={item?.curr_status === "3" ? 'approved' : item?.curr_status === "1" ? 'pending' : 'submitted'} placeholder="Enter here"
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    optionFilterProp="label"
                                    options={userBidInfo?.id === item?.created_by ? createdByOption : (userBidInfo?.id === item?.req_to_userid && item?.curr_status !== '3') ? assignedToOption : createdByOption}
                                    onChange={(e) => requestStatus(item, e, index)}
                                    value={item?.curr_status}
                                    // disabled={item?.curr_status === '3' ? true : false}
                                    disabled={(userBidInfo?.id !== item?.created_by && userBidInfo?.id !== item?.req_to_userid) || item?.curr_status === '3' ? true : false}
                                />
                            </div>
                            {/* <div className={`req_status ${item?.status === 'Pending' ? 'pending' : item?.status === 'Approved' ? 'approved' : 'cancel'}`}>{item?.status}</div> */}
                            <div className="reqDate">Date - <span>{item?.created_at !== null ? `${dayjs(item?.created_at).format('D MMMM YYYY')} ${TimeConverter(item?.created_at)}` : '-'}</span></div>
                        </div>
                    </div>
                )
            })
                :
                <h5>No request yet...</h5>

        )
    }


    return (
        <Drawer title="Request List" className="bd_Drawer_request" closeIcon={<img src={skipBack} alt='' />} onClose={onCloseDrawer} open={openStatsDrawer} width={650} extra={
            <>
                <button className='BG_mainButton' onClick={showDrawer}>Add Request</button>
            </>
        }>

            {showAllRequestList()}
        </Drawer>
    )
}



export default RequestListDrawer;