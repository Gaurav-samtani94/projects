// @ts-nocheck
import React, { useCallback, useEffect, useState } from 'react'
import { Down } from '@icon-park/react';
import { Col, Drawer, Form, Row, Select, Input, DatePicker } from 'antd';
import skipBack from "../../assets/images/skip-back.png";
import { useSelector } from 'react-redux';
import { DropdownValuesServices } from 'Services/common/dropdown/dropdownValues';
import { useDispatch } from 'react-redux';
import { filterCycleActions } from 'Redux/actions/bidgrid/cycleFilterAction';
import moment from 'moment';
import dayjs from 'dayjs';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';



import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { bidTenderResultStatusAction, dropdownValAction } from 'Redux/actions/common/DropdownAction';
import { misFilterActions } from 'Redux/actions/bidgrid/misFilterAction';
import { trashFilterAction } from 'Redux/actions/bidgrid/trashFilterAction';
import { AddTenderList } from 'Services/bidgrid/add/AddTender';

const notifySuccess = (msg) => toast.success(msg);


const { Search } = Input;

const tenderStatusList = [
    {
        id: 1,
        status_name: "Active"
    },
    {
        id: 2,
        status_name: "Inactive"
    },
    {
        id: "ALL",
        status_name: "ALL"
    }
]

const locationList = [
    {
        id: 1,
        location_name: "National"
    },
    {
        id: 2,
        location_name: "International"
    }
]

const initialState = {
    sector_id: '',
    client_id: '',
    currency_id: '',
    funding_id: '',
    tender_status: '',
    country_id: '',
    state_id: '',
    from_date: '',
    to_date: '',
    tender_keyword: '',
    // tender_result_id: '',
    generated_type: '',
    bid_manager_filter: '',
    key_manager_filter: '',
    // to_cycle_id: '',
    tender_activity_status: '',
    located: '',
    filter_fin_year: '',
    ping_users: ''
}


function Bd_basicFilter(props) {

    const { showDrawerAdvance, open, close, updateFilter, updateFilterData, collapseActiveKeyTemp,
        setCollapseActiveKeyTemp, getScopeList, setApplyTemp, setUpdateFilter, commonFilter, filterValData, tempType } = props

    const { filterValues } = useSelector((state => state.cycleFilter))
    const { misFilterValues } = useSelector((state => state.misFilter))
    const { trashFilterValues } = useSelector((state => state.trashFilter))

    const { BidClient, BidFundingClientAgency, BidCountry, BidSector, BidCurrency, BidAllUsers, BidGenerateId } = useSelector((state) => state.bidDropdownCalVal)

    const [form] = Form.useForm();
    const PayloadData = new FormData();
    const dispatch = useDispatch();
    const maxDate = moment().endOf('day');
    const disabledDate = current => current && current > maxDate;

    const [filter, setFilter] = useState(initialState)
    const [stateVal, setStateVal] = useState([])
    const [tenderResultStatus, setTenderResultStatus] = useState([])
    const [financialYears, setFinancialYears] = useState([])


    const getCurrentFinancialYear = useCallback(() => {
        const today = new Date();
        const currentYear = today.getFullYear();
        const startYear = 2015;
        // const startMonth = 4; // 

        let financialYears = [];

        for (let year = startYear; year <= currentYear; year++) {
            const nextYear = year + 1;
            const financialYear = {
                label: `${year}-${nextYear}`,
                value: `${year}-${nextYear}`
            };
            financialYears.push(financialYear);
        }

        return financialYears;
    }, [open]);

    //calling state api
    const getStateDrpValue = async (country_id) => {
        const formData = new URLSearchParams();
        try {
            if (country_id) {
                formData.append('country_id', country_id);
                // const response = await DropdownValuesServices.getStateDataByCountryId(PayloadData)   //Tender grid APi (don't use it in bidGrid)
                const response = await AddTenderList.getTenderStateList(formData)

                if (response?.data?.status == 1) {
                    const newData = response?.data?.data?.filter(val => val?.state_name !== 'NA')
                    setStateVal(newData)
                } else {
                    setStateVal([])
                }
            } else {
                setStateVal([])
            }
        } catch {
            console.log("error")
            setStateVal([])
        }
    }


    const getTenderResultList = async () => {

        try {
            const response = await TenderApi?.getTenderResultStatus()
            if (response?.data?.status == 1) {
                setTenderResultStatus(response?.data?.data)
                dispatch(bidTenderResultStatusAction(response?.data?.data));
            }
        } catch (error) {
            console.log(error);
        }
    }
    useEffect(() => {
        getTenderResultList();

    }, [])

    useEffect(() => {

        setFilter((prevState) => {
            const resetKey1 = { ...prevState, sector_id: updateFilter?.hasOwnProperty('sector_id') ? updateFilter?.sector_id : '' };
            const resetKey3 = { ...resetKey1, tender_status: updateFilter?.hasOwnProperty('tender_status') ? updateFilter?.tender_status : '' };
            const resetKey4 = { ...resetKey3, country_id: updateFilter?.hasOwnProperty('country_id') ? updateFilter?.country_id : '' };
            const resetKey5 = { ...resetKey4, state_id: updateFilter?.hasOwnProperty('state_id') ? updateFilter?.state_id : '' };
            const resetKey6 = { ...resetKey5, currency_id: updateFilter?.hasOwnProperty('currency_id') ? updateFilter?.currency_id : '' };
            const resetKey7 = { ...resetKey6, funding_id: updateFilter?.hasOwnProperty('funding_id') ? updateFilter?.funding_id : '' };
            const resetKey8 = { ...resetKey7, client_id: updateFilter?.hasOwnProperty('client_id') ? updateFilter?.client_id : '' };
            const resetKey9 = { ...resetKey8, from_date: updateFilter?.hasOwnProperty('from_date') ? dayjs(updateFilter?.from_date) : '' };
            const resetKey10 = { ...resetKey9, to_date: updateFilter?.hasOwnProperty('to_date') ? dayjs(updateFilter?.to_date) : '' };
            const resetKey11 = { ...resetKey10, tender_keyword: updateFilter?.hasOwnProperty('tender_keyword') ? updateFilter?.tender_keyword : '' };
            const resetKey12 = { ...resetKey11, tender_activity_status: updateFilter?.hasOwnProperty('tender_activity_status') ? updateFilter?.tender_activity_status : '' };
            const resetKey13 = { ...resetKey12, located: updateFilter?.hasOwnProperty('located') ? updateFilter?.located : '' };
            // const resetKey12 = { ...resetKey11, tender_result_id: updateFilter?.hasOwnProperty('tender_result_id') ? updateFilter?.tender_result_id : '' };
            const resetKey14 = { ...resetKey13, ping_users: updateFilter?.hasOwnProperty('ping_users') ? updateFilter?.ping_users : '' };
            const resetKey15 = commonFilter == "MIS" && { ...resetKey14, generated_type: updateFilter?.hasOwnProperty('generated_type') ? updateFilter?.generated_type : '' };
            const resetKey16 = commonFilter == "MIS" && { ...resetKey15, bid_manager_filter: updateFilter?.hasOwnProperty('bid_manager_filter') ? updateFilter?.bid_manager_filter : '' };
            const resetKey17 = commonFilter == "MIS" && { ...resetKey16, key_manager_filter: updateFilter?.hasOwnProperty('key_manager_filter') ? updateFilter?.key_manager_filter : '' };
            const resetKey18 = commonFilter == "MIS" && { ...resetKey17, filter_fin_year: updateFilter?.hasOwnProperty('filter_fin_year') ? updateFilter?.filter_fin_year : '' };
            return commonFilter == "MIS" ? resetKey18 : commonFilter == "CYCLE" ? resetKey14 : resetKey14;
        });

    }, [updateFilter])

    useEffect(() => {
        if (updateFilter?.country_id) {
            getStateDrpValue(updateFilter?.country_id)
        }
    }, [updateFilterData])

    useEffect(() => {
        setFilter((prevState) => {
            const resetKey1 = { ...prevState, sector_id: filterValData?.sector_id };
            const resetKey3 = { ...resetKey1, tender_status: filterValData?.tender_status };
            const resetKey4 = { ...resetKey3, country_id: filterValData.country_id };
            const resetKey5 = { ...resetKey4, state_id: filterValData?.state_id };
            const resetKey6 = { ...resetKey5, currency_id: filterValData?.currency_id };
            const resetKey7 = { ...resetKey6, funding_id: filterValData?.funding_id };
            const resetKey8 = { ...resetKey7, client_id: filterValData?.client_id };
            const resetKey9 = { ...resetKey8, from_date: filterValData?.from_date === "" ? filterValData?.from_date : dayjs(filterValData?.from_date) };
            const resetKey10 = { ...resetKey9, to_date: filterValData?.to_date === "" ? filterValData?.to_date : dayjs(filterValData?.to_date) };
            const resetKey11 = { ...resetKey10, tender_keyword: filterValData?.tender_keyword };
            const resetKey12 = { ...resetKey11, tender_activity_status: filterValData?.tender_activity_status };
            const resetKey13 = { ...resetKey12, located: filterValData?.located };
            // const resetKey12 = { ...resetKey11, tender_result_id: commonFilter == "CYCLE" ? filterValues?.tender_result_id : misFilterValues?.tender_result_id };
            const resetKey14 = { ...resetKey13, ping_users: filterValData?.ping_users };

            const resetKey15 = commonFilter == "MIS" && { ...resetKey14, generated_type: filterValData?.generated_type };
            const resetKey16 = commonFilter == "MIS" && { ...resetKey15, bid_manager_filter: filterValData?.bid_manager_filter };
            const resetKey17 = commonFilter == "MIS" && { ...resetKey16, key_manager_filter: filterValData?.key_manager_filter };
            const resetKey18 = commonFilter == "MIS" && { ...resetKey17, filter_fin_year: filterValData?.filter_fin_year };

            return commonFilter == "MIS" ? resetKey18 : commonFilter == "CYCLE" ? resetKey14 : resetKey14;
        });
    }, [commonFilter == 'CYCLE' ? filterValues : commonFilter == 'MIS' ? misFilterValues : trashFilterValues])




    const handleSelectChange = (name, value) => {

        if (name === 'country_id') {
            setFilter((old) => ({
                ...old,
                state_id: ""
            }))
            getStateDrpValue(value)
        }
        if (name === 'from_date') {
            const date = new Date();
            const year = date?.getFullYear();
            const month = (date?.getMonth() + 1)?.toString()?.padStart(2, "0");
            const day = date?.getDate()?.toString()?.padStart(2, "0");
            const nextDate = `${year}-${month}-${day}`
            setFilter((old) => ({
                ...old,
                from_date: value,
                to_date: dayjs(nextDate)
            }))
        } else {
            setFilter((old) => ({
                ...old,
                [name]: value
            }))
        }
    }



    // Create Basic filter

    const handleSubmit = async () => {
        setApplyTemp(false)

        if (updateFilterData) {
            const nonEmptyKeyValuePairs = Object.entries(filter)?.filter(([key, value]) => value !== '').map(([key, value]) => {
                if (key === 'from_date' || key === 'to_date') {

                    let val = dayjs(value)?.format('YYYY-MM-DD')
                    return { [key]: val }
                } else {
                    return { [key]: value }
                }
            })
            const nonEmptyKeysString = nonEmptyKeyValuePairs.map(obj => Object.keys(obj)[0]).join(',');
            const nonEmptyValuesString = nonEmptyKeyValuePairs.map(obj => Object.values(obj)[0]).join(',');
            const formData = new URLSearchParams();
            formData.append("template_type", tempType);
            formData.append('filter_field_name', nonEmptyKeysString);
            formData.append('filter_field_value', nonEmptyValuesString);
            formData.append('template_name', collapseActiveKeyTemp);
            const response = await tenderCycle.bdUpdateTempFilterChips(formData)
            if (response?.data?.status === '1') {
                setCollapseActiveKeyTemp()
                close();
                notifySuccess(response?.data?.message)

                setFilter({
                    sector_id: '',
                    client_id: '',
                    currency_id: '',
                    funding_id: '',
                    tender_status: '',
                    country_id: '',
                    state_id: '',
                    from_date: '',
                    to_date: '',
                    tender_keyword: '',
                    generated_type: '',
                    bid_manager_filter: '',
                    key_manager_filter: '',
                    tender_activity_status: '',
                    located: '',
                    filter_fin_year: '',
                    ping_users: ''
                })
            }

        }
        else {
            let obj = commonFilter == "CYCLE" || commonFilter == "TRASH" ? {
                ...filterValues,
                page_number: '1',
                sector_id: filter.sector_id ? filter.sector_id : '',
                tender_status: filter.tender_status ? filter.tender_status : '',
                country_id: filter.country_id ? filter.country_id : '',
                currency_id: filter.currency_id ? filter.currency_id : '',
                funding_id: filter.funding_id ? filter.funding_id : '',
                client_id: filter.client_id ? filter.client_id : '',
                state_id: filter.state_id ? filter.state_id : '',
                from_date: filter.from_date ? filter.from_date === "" ? filter.from_date : dayjs(filter.from_date)?.format('YYYY-MM-DD') : '',
                to_date: filter.to_date ? filter.to_date === "" ? filter.to_date : dayjs(filter.to_date)?.format('YYYY-MM-DD') : '',
                tender_keyword: filter.tender_keyword ? filter.tender_keyword : '',
                tender_activity_status: filter.tender_activity_status ? filter.tender_activity_status : '1',
                located: filter.located ? filter.located : '',
                ping_users: filter.ping_users ? filter.ping_users : '',
            } :
                {
                    ...misFilterValues,
                    page_number: '1',
                    sector_id: filter.sector_id ? filter.sector_id : '',
                    tender_status: filter.tender_status ? filter.tender_status : '',
                    country_id: filter.country_id ? filter.country_id : '',
                    currency_id: filter.currency_id ? filter.currency_id : '',
                    funding_id: filter.funding_id ? filter.funding_id : '',
                    client_id: filter.client_id ? filter.client_id : '',
                    state_id: filter.state_id ? filter.state_id : '',
                    from_date: filter.from_date ? filter.from_date === "" ? filter.from_date : dayjs(filter.from_date)?.format('YYYY-MM-DD') : '',
                    to_date: filter.to_date ? filter.to_date === "" ? filter.to_date : dayjs(filter.to_date)?.format('YYYY-MM-DD') : '',
                    tender_keyword: filter.tender_keyword ? filter.tender_keyword : '',
                    tender_activity_status: filter.tender_activity_status ? filter.tender_activity_status : '',
                    located: filter.located ? filter.located : '',
                    ping_users: filter.ping_users ? filter.ping_users : '',
                    // tender_result_id: filter?.tender_result_id,
                    generated_type: filter?.generated_type ? filter?.generated_type || misFilterValues?.generated_type : '',
                    bid_manager_filter: filter?.bid_manager_filter ? filter?.bid_manager_filter || misFilterValues?.bid_manager_filter : '',
                    key_manager_filter: filter?.key_manager_filter ? filter?.key_manager_filter || misFilterValues?.key_manager_filter : '',
                    filter_fin_year: filter?.filter_fin_year ? filter?.filter_fin_year || misFilterValues?.filter_fin_year : '',

                }
            commonFilter == 'CYCLE' ? dispatch(filterCycleActions.filterUpdateAllKeys(obj)) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterUpdateAllKeys(obj)) : dispatch(trashFilterAction?.trashFilterUpdateAllKeys(obj));

            setFilter({
                sector_id: '',
                client_id: '',
                currency_id: '',
                funding_id: '',
                tender_status: '',
                country_id: '',
                state_id: '',
                from_date: '',
                to_date: '',
                tender_keyword: '',
                generated_type: '',
                bid_manager_filter: '',
                key_manager_filter: '',
                tender_activity_status: '',
                located: '',
                filter_fin_year: '',
                ping_users: ''
            })
            close();
        }
        setUpdateFilter()
    }

    const resetBdBasicFilter = () => {
        let objArr = Object.keys(filter).map(key => {
            return key.toString()
        })
        commonFilter == 'CYCLE' ? dispatch(filterCycleActions.filterResetIndividualKeys(objArr)) : commonFilter == "MIS" ? dispatch(misFilterActions.misFilterResetIndividualKeys(objArr)) : dispatch(trashFilterAction.trashFilterResetIndividualKeys(objArr));
        close();
        setFilter({
            from_date: '',
            to_date: ''
        })
    }

    return (
        <Drawer className='bd_drawer_main' closeIcon={<img src={skipBack} alt='' />} title={updateFilterData ? "Edit Basic Filter" : "Basic Filter"} placement="right" onClose={close}
            open={open} width={700}
            extra={
                <button className='BG_mainButton' onClick={showDrawerAdvance}>
                    Advance Filter
                </button>
            }
            footer={
                <div className="bd_drawerFoot">
                    <button className='BG_ghostButton' onClick={resetBdBasicFilter}>Reset</button>
                    <button className='BG_mainButton' onClick={handleSubmit}>{!updateFilterData ? 'Filter' : 'Update'}</button>
                </div>
            }
        >

            <div className='bd_prospective_drawer'>
                <div>
                    <div className='bd_drawer_prospective_box'>
                        <Form
                            form={form}
                            name='control-hooks'
                            layout="vertical"
                        >
                            <div className="table_wrap mb-4 mt-0">
                                <Search
                                    placeholder="Search"
                                    allowClear
                                    value={filter?.tender_keyword}
                                    onChange={(e) => setFilter({ ...filter, tender_keyword: e.target.value })}
                                    style={{ width: 635 }}
                                />
                            </div>
                            <Row gutter={16}>
                                <Col sm={12}>
                                    <Form.Item label="Sector">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            placeholder="Select sector"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            options={BidSector?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.sector_name
                                                }
                                            })}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                            name='sector_id'
                                            value={(parseInt(filter?.sector_id) || '')}
                                            onChange={(value) => handleSelectChange('sector_id', value)}
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>

                                <Col sm={12}>
                                    <Form.Item label="Authority">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            placeholder="Select Marked"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            options={BidClient.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.client_name
                                                }
                                            })}
                                            onChange={(value) => handleSelectChange('client_id', value)}
                                            value={parseInt(filter?.client_id) || ''}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>
                                <Col sm={12}>
                                    <Form.Item label="Currency">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            options={BidCurrency?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.name
                                                }
                                            })}
                                            onChange={(value) => handleSelectChange('currency_id', value)}
                                            value={parseInt(filter?.currency_id) || ''}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>
                                <Col sm={12}>
                                    <Form.Item label="Funding Agency">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            options={BidFundingClientAgency.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.funding_org_name
                                                }
                                            })}
                                            onChange={(value) => handleSelectChange('funding_id', value)}
                                            value={parseInt(filter?.funding_id) || ""}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>
                                {(commonFilter == "CYCLE" ? (filterValues.cycle_id === '0' || updateFilter?.tender_status !== undefined) && commonFilter == "CYCLE" : commonFilter == "TRASH") && <Col sm={12}>
                                    <Form.Item label="Tender Scope">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            placeholder="Select Marked"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            options={getScopeList?.filter((item) => item?.id !== 0)?.map((itm) => {
                                                return {
                                                    value: itm?.id,
                                                    label: commonFilter == "CYCLE" ? itm?.scope_name : itm?.cycle_name
                                                }
                                            })
                                            }
                                            onChange={(value) => handleSelectChange('tender_status', value)}
                                            value={parseInt(filter?.tender_status) || ""}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>}

                                {/* {((filterValues.orderSerial == 8 || updateFilter?.tender_result_id !== undefined) && commonFilter ==
                                    "CYCLE") &&
                                    <Col sm={12}>
                                        <Form.Item label="Tender Result">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select Marked"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                options={tenderResultStatus?.filter((item) => item?.id !== 0)?.map((itm) => {
                                                    return {
                                                        value: itm?.id,
                                                        label: itm?.status_name
                                                    }
                                                })
                                                }
                                                onChange={(value) => handleSelectChange('tender_result_id', value)}
                                                value={parseInt(filter?.tender_result_id) || ""}
                                                filterOption={(input, option) =>
                                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                }
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>} */}
                                <Col sm={12}>
                                    <Form.Item label="Country">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            placeholder="Select Country"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            name='country_id'
                                            options={BidCountry.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.country_name
                                                }
                                            })}
                                            value={parseInt(filter?.country_id) || ""}
                                            onChange={(value) => handleSelectChange('country_id', value)}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>
                                <Col sm={12}>
                                    <Form.Item label="State">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            placeholder="Select State"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}

                                            // value={stateVal?.find((item) => item.state_id === filter?.state_id) || null}
                                            options={stateVal.map((item, index) => {
                                                return {
                                                    value: parseInt(item?.id),
                                                    label: item?.state_name
                                                }
                                            })}

                                            value={parseInt(filter?.state_id) || ""}
                                            onChange={(value) => handleSelectChange('state_id', value)}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                        </Select>
                                    </Form.Item>
                                </Col>
                                {commonFilter == "CYCLE" && <Col sm={12}>
                                    <Form.Item label="Tender Status">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            options={tenderStatusList.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.status_name
                                                }
                                            })}
                                            // defaultValue="Active"
                                            onChange={(value) => handleSelectChange('tender_activity_status', value)}
                                            value={(filter?.tender_activity_status != "ALL" ? parseInt(filter?.tender_activity_status) : filter?.tender_activity_status) || 1}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>}
                                <Col sm={12}>
                                    <Form.Item label="Located">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            options={locationList.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.location_name
                                                }
                                            })}
                                            onChange={(value) => handleSelectChange('located', value)}
                                            value={parseInt(filter?.located) || ""}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>
                                {commonFilter == "CYCLE" && <Col sm={12}>
                                    <Form.Item label="Pin User">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            options={BidAllUsers.map((item, index) => {
                                                return {
                                                    value: parseInt(item?.id),
                                                    label: item?.userfullname
                                                }
                                            })}
                                            onChange={(value) => handleSelectChange('ping_users', value)}
                                            value={parseInt(filter?.ping_users) || ''}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>}



                                {commonFilter == "MIS" && <Col sm={12}>
                                    <Form.Item label="Generate Id">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            placeholder="Select Generate Id"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            // name='generated_type'
                                            // value={stateVal?.find((item) => item.state_id === filter?.state_id) || null}
                                            options={BidGenerateId.map((item, index) => {
                                                return {
                                                    value: parseInt(item?.id),
                                                    label: item?.generated_type
                                                }
                                            })}

                                            value={parseInt(filter?.generated_type) || ""}
                                            onChange={(value) => handleSelectChange('generated_type', value)}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                        </Select>
                                    </Form.Item>
                                </Col>}
                                {commonFilter == "MIS" && <Col sm={12}>
                                    <Form.Item label="Bid Manager">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            placeholder="Select Bid Manager"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            // value={stateVal?.find((item) => item.state_id === filter?.state_id) || null}
                                            options={BidAllUsers.map((item, index) => {
                                                return {
                                                    value: parseInt(item?.id),
                                                    label: item?.userfullname
                                                }
                                            })}
                                            value={parseInt(filter?.bid_manager_filter) || ""}
                                            onChange={(value) => handleSelectChange('bid_manager_filter', value)}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                        </Select>
                                    </Form.Item>
                                </Col>}
                                {commonFilter == "MIS" && <Col sm={12}>
                                    <Form.Item label="Key Manager">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            placeholder="Select Key Manager"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            // value={stateVal?.find((item) => item.state_id === filter?.state_id) || null}
                                            options={BidAllUsers.map((item, index) => {
                                                return {
                                                    value: parseInt(item?.id),
                                                    label: item?.userfullname
                                                }
                                            })}
                                            value={parseInt(filter?.key_manager_filter) || ""}
                                            onChange={(value) => handleSelectChange('key_manager_filter', value)}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                        </Select>
                                    </Form.Item>
                                </Col>}
                                {commonFilter == "MIS" && <Col sm={12}>
                                    <Form.Item label="Financial Year">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            allowClear
                                            placeholder="Select Financial year"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            // defaultValue={'2024-2025'}
                                            value={filter?.filter_fin_year || '2024-2025'}
                                            options={getCurrentFinancialYear().map((item, index) => {
                                                return {
                                                    value: item?.value,
                                                    label: item?.label
                                                }
                                            })}

                                            onChange={(value) => handleSelectChange('filter_fin_year', value)}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                        </Select>
                                    </Form.Item>
                                </Col>}
                                {/* {commonFilter == "TRASH" && <Col sm={12}>
                                    <Form.Item label="Tender Cycle">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder="Tender Cycle"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            // value={stateVal?.find((item) => item.state_id === filter?.state_id) || null}
                                            options={getScopeList.map((item, index) => {
                                                return {
                                                    value: parseInt(item?.id),
                                                    label: item?.cycle_name
                                                }
                                            })}
                                            value={parseInt(filter?.to_cycle_id) || trashFilterValues?.to_cycle_id}
                                            onChange={(value) => handleSelectChange('to_cycle_id', value)}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                        </Select>
                                    </Form.Item>
                                </Col>} */}
                            </Row>
                            <hr />
                            <div>
                                <h6>Latest Activity</h6>
                                <Row gutter={24}>
                                    <Col span={12}>
                                        <Form.Item label="From Date">
                                            <DatePicker
                                                allowClear
                                                name='from_date'
                                                disabledDate={disabledDate}
                                                // disabled={true}
                                                value={filter?.from_date}
                                                onChange={(value) => handleSelectChange('from_date', value)}

                                            />
                                        </Form.Item>
                                    </Col>
                                    <Col span={12}>
                                        <Form.Item label="To Date">
                                            <DatePicker
                                                allowClear
                                                name='to_date'
                                                value={filter?.to_date}
                                                disabledDate={disabledDate}
                                                onChange={(value) => handleSelectChange('to_date', value)}
                                            />
                                        </Form.Item>
                                    </Col>
                                </Row>
                            </div>

                        </Form>

                    </div>
                </div>
            </div>

        </Drawer >
    )
}


export default Bd_basicFilter
