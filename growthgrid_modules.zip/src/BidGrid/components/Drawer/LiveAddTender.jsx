// @ts-nocheck
import React, { useState, useRef, useEffect } from 'react';
import { Input, Button, Form, Row, Col, Upload, message, Drawer, Select } from 'antd';
import skipBack from '../../assets/images/skip-back.png'

import { DatePicker } from 'antd';
import { Down, UploadOne } from '@icon-park/react';
import { Editor } from "@tinymce/tinymce-react";
import _ from 'lodash';
import { bidProspective } from 'Services/bidgrid/prospective/bidProspective';
const Clientoptions = [
    { value: 'stocks', },
    { value: 'john', },
    { value: 'rozer', },
];

const Locatedoptions = [
    { value: 'jaipur', },
    { value: 'delhi', },
    { value: 'indore', },
];

const cityoptions = [
    { value: 'mp', },
    { value: 'up', },
    { value: 'hp', },
];

const stateoption = [
    { value: 'rajsthan', },
    { value: 'himachal', },
    { value: 'goa', },
];

const contryoption = [
    { value: 'india', },
    { value: 'usa', },
    { value: 'uk', },
];

const currencyoption = [
    { value: 'rupee', },
    { value: 'doller', },
    { value: 'euro', },
];

const sectortender = [
    { value: 'it', },
    { value: 'construcation', },
    { value: 'ai', },
];

const typetender = [
    { value: 'software', },
    { value: 'buildding', },
    { value: 'machine learning', },
];


const initialstate = {
    located: "",
    city: "",
    currency: "",
    tendertype: "",
    bid_submission_date: "",
    tendercost: "",
    url: "",
    files: '',
    project_name: '',
    client_id: null,
    country_id: "",
    state_id: null,
    tender_value: '',
    sector_id: null,
    funding_id: null,
    lead_comp_ids: null
}
const LiveAddTender = (props) => {
    const [selectedOption, setSelectedOption] = useState(initialstate);
    const [clientlist, setClientList] = useState([])
    const [fundingClientlist, setFundingClientList] = useState([])
    const [countrylist, setCountryList] = useState([])
    const [Statelist, setStateList] = useState([])
    const [leadCompanylist, setLeadCompanyList] = useState([])
    const [sectorlist, setSectorList] = useState([])
    // const [addProspectiveData, setAddProspectiveData] = useState({
    //     files: '',
    //     project_name: '',
    //     client_id: null,
    //     country_id: null,
    //     state_id: null,
    //     tender_value: '',
    //     sector_id: null,
    //     funding_id: null,
    //     lead_comp_ids: null
    // })

    const handleSelectChange = (name, value) => {
        setSelectedOption({ ...selectedOption, [name]: value });
    }

    // client List
    const getClient = async () => {
        try {
            const res = await bidProspective.getClientList()
            if (res?.data?.status === '1') {
                setClientList(res?.data?.data)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    // funding client List
    const getFundlingClient = async () => {
        try {
            const res = await bidProspective.getFundingAgencyList()
            if (res?.data?.status === '1') {
                setFundingClientList(res?.data?.data)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    // country List
    // const getCountry = async () => {
    //     try {
    //         const res = await bidProspective.getCountryList();
    //         if (res?.data?.status === '1') {
    //             const countryNames = res?.data?.data;
    //             console.log(countryNames, "countryNames");

    //             if (Array.isArray(countryNames)) {
    //                 const countryOptions = countryNames.map(country => ({ label: country, value: country }));
    //                 console.log(countryOptions, "countryOptions");
    //                 setCountryList(countryOptions);
    //             } else {
    //                 console.error('Country names is not an array:', countryNames);
    //             }
    //         }
    //     } catch (error) {
    //         console.log(error, 'api error');
    //     }
    // }
    const getCountry = async () => {
        try {
            const res = await bidProspective.getCountryList();
            if (res?.data?.status === '1') {
                const countryNames = res?.data?.data;
                if (Array.isArray(countryNames)) {
                    const countryOptions = countryNames.map(country => ({ label: country?.country_name, value: country?.id }));
                    setCountryList(countryOptions);
                } else {
                    console.error('Country names is not an array:', countryNames);
                }
            }
        } catch (error) {
            console.log(error, 'api error');
        }
    }

    // const getCountry = async () => {
    //     try {
    //         const res = await bidProspective.getCountryList()
    //         if (res?.data?.status === '1') {
    //             console.log(res?.data?.data, "pppppp")
    //             setCountryList(res?.data?.data)
    //         }
    //     } catch (error) {
    //         console.log(error, 'api erorr')
    //     }
    // }

    // state List
    const getState = async () => {
        try {
            const formData = new URLSearchParams()
            formData.append('country_id', selectedOption?.country_id)
            const res = await bidProspective.getStateList(formData)
            if (res?.data?.status === '1') {
                const stateNames = res?.data?.data;
                // setStateList(res?.data?.data)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    // sector List
    const getSector = async () => {
        try {
            const res = await bidProspective.getSectorList()
            if (res?.data?.status === '1') {
                setSectorList(res?.data?.data)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }


    // lead company List
    const getLeadCompany = async () => {
        try {
            const res = await bidProspective.getLeadCompanyList()
            if (res?.data?.status === '1') {
                setLeadCompanyList(res?.data?.data)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }



    const handleSubmit = () => {

        // api call
        props?.editViewState(selectedOption, props?.isEditFields?.srNo)
        props?.setOpen(false)
    }


    // console.log(selectedOption, "abc")
    function formatDate(dateString) {
        if (dateString) {
            const date = new Date(dateString);
            const year = date.getFullYear();
            const month = (date.getMonth() + 1).toString().padStart(2, "0");
            const day = date.getDate().toString().padStart(2, "0");
            return `${year}-${month}-${day}`;
        } else {
            return ''
        }
    }

    useEffect(() => {
        setSelectedOption({
            ...selectedOption,
            tendertype: props?.isEditFields?.tendertype
            //rest fields
        });
    }, [props?.isEditFields])

    useEffect(() => {
        getClient()
        getFundlingClient()
        getCountry()
        getSector()
        getLeadCompany()
    }, [])

    useEffect(() => {
        getState()
    }, [selectedOption?.country_id])



    return (
        <Drawer className='bd_drawer_main' closeIcon={<img src={skipBack} alt='' />} title="Add  Tender" placement="right" onClose={props?.onClose} open={props?.open} width={1000}>
            <div className='bd_prospective_drawer'>
                <div>
                    <div className="bd_editor">
                        <div className="bd_editor_heading">
                            Tender Name
                        </div>
                    </div>
                    <div className='bd_drawer_prospective_box'>
                        <Form
                            layout="vertical"
                        >
                            <Row gutter={20}>
                                {
                                    _.has(props?.columnLabels, 'tender_type') &&
                                    <Col sm={6}>
                                        <Form.Item label="Tender Type:">
                                            <Select
                                                showSearch
                                                options={typetender}
                                                value={selectedOption?.tendertype}
                                                name='tendertype'
                                                placeholder="Select Type"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                onChange={(value) => handleSelectChange('tendertype', value)}
                                            >
                                            </Select>
                                        </Form.Item>
                                    </Col>
                                }
                                {_.has(props?.columnLabels, 'tender_sector') &&
                                    <Col sm={6}>
                                        <Form.Item label="Tender Sector:">
                                            <Select
                                                showSearch
                                                // value={demo === true ? data?.sector : selectedOption?.sector}
                                                options={sectortender}
                                                value={selectedOption?.sector}
                                                name='sector'
                                                placeholder="Select Sector"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                onChange={(value) => handleSelectChange('sector', value)}
                                            >
                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'bid_submission_date') &&
                                    <Col sm={6}>
                                        <Form.Item label="Bid Submission">
                                            <DatePicker
                                                placeholder='dd/mm/yyyy'
                                                value={selectedOption?.bid_submission_date}
                                                name='bid_submission_date'
                                                format='DD/MM/YYYY'
                                                mode='calendar'
                                                onChange={(e) => {
                                                    setSelectedOption({ ...selectedOption, bid_submission_date: formatDate(e) })
                                                }}
                                            />
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'url') &&
                                    <Col sm={6}>
                                        <Form.Item label="Tender URL:">
                                            <Input
                                                // value={demo === true ? data?.url : selectedOption?.url}
                                                value={selectedOption?.url}
                                                name='url'
                                                onChange={(value) => handleSelectChange(value.target.name, value.target.value)}
                                            />

                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'currency') &&
                                    <Col sm={6}>
                                        <Form.Item label="Tender Currency:">
                                            <Select
                                                // value={demo === true ? data?.currency : selectedOption?.currency}
                                                value={selectedOption?.currency}
                                                onChange={(value) => handleSelectChange('currency', value)}
                                                options={currencyoption}
                                                name='currency'
                                                placeholder="Select Currency"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}

                                            >
                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'tendercost') &&
                                    <Col sm={6}>
                                        <Form.Item label="Tender Value:">
                                            <Input
                                                // value={demo === true ? data?.tendercost : selectedOption?.tendercost}
                                                value={selectedOption?.tendercost}
                                                onChange={(value) => handleSelectChange(value.target.name, value.target.value)}
                                                name='tendercost'

                                            />
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'country') &&
                                    <Col sm={6}>
                                        <Form.Item label="Country:">
                                            <Select
                                                showSearch
                                                value={selectedOption?.country}
                                                onChange={(value) => handleSelectChange(value?.target?.name, value?.target?.value)}
                                                name='country'
                                                options={countrylist}
                                                placeholder="Select Country"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            />
                                        </Form.Item>
                                    </Col>
                                }
                                {_.has(props?.columnLabels, 'state') &&
                                    <Col sm={6}>
                                        <Form.Item label="State:">
                                            <Select
                                                showSearch
                                                // value={demo === true ? data?.state : selectedOption?.state}
                                                value={selectedOption.state}
                                                onChange={(value) => handleSelectChange('state', value)}
                                                // options={stateoption}
                                                placeholder="Select State"
                                                name='state'
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'city') &&
                                    <Col sm={6}>
                                        <Form.Item label="City:">
                                            <Select
                                                showSearch
                                                // value={demo === true ? data?.city : selectedOption?.city}
                                                value={selectedOption.city}
                                                onChange={(value) => handleSelectChange('city', value)}
                                                options={cityoptions}
                                                name='city'
                                                placeholder="Select City"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'located') &&
                                    <Col sm={6}>
                                        <Form.Item label="Located:">
                                            <Select
                                                showSearch
                                                // value={demo === true ? data?.located : selectedOption?.located}
                                                value={selectedOption.located}
                                                name='located'
                                                onChange={(value) => handleSelectChange('located', value)}
                                                options={Locatedoptions}
                                                placeholder="National"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'client') &&
                                    <Col sm={6}>
                                        <Form.Item label="Client:">
                                            <Select
                                                showSearch
                                                // value={demo === true ? data?.client : selectedOption?.client}
                                                value={selectedOption.client}
                                                onChange={(value) => handleSelectChange('client', value)}
                                                name='client'
                                                options={Clientoptions}
                                                placeholder="Select Client"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >
                                            </Select>
                                        </Form.Item>
                                    </Col>}

                                {_.has(props?.columnLabels, 'clientData') &&
                                    <Col sm={8}>
                                        <Form.Item label="Client">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select Client"
                                                options={clientlist?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.client_name
                                                    }
                                                })}
                                                value={selectedOption?.client_id}
                                                name="client_id"
                                                onChange={(value) => handleSelectChange('client_id', value)}
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'fundingAgencyData') &&
                                    <Col sm={8}>
                                        <Form.Item label="Select Client Funding Agency">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select Funding"
                                                options={fundingClientlist?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.funding_org_name
                                                    }
                                                })}
                                                value={selectedOption?.funding_id}
                                                onChange={(value) => handleSelectChange('funding_id', value)}
                                                name='funding_id'
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'tenderValue') &&
                                    <Col sm={8}>
                                        <Form.Item label="Tender Value (Cr.)">
                                            <Input
                                                name='tender_value'
                                                value={selectedOption?.tender_value}
                                                onChange={(e) => handleSelectChange('tender_value', e.target.value)}
                                                placeholder='tender Value'
                                            />
                                        </Form.Item>
                                    </Col>}

                                <Col sm={8}>
                                    <Form.Item label="Country">
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder="Select Country"
                                            options={countrylist?.map((item, index) => ({
                                                value: item?.id, // replace with the correct property for the value
                                                label: item?.country_name
                                            }))}
                                            name='country_id'
                                            value={selectedOption?.country_id}
                                            onChange={(value) => handleSelectChange('country_id', value)}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        />
                                    </Form.Item>
                                </Col>


                                {_.has(props?.columnLabels, 'StateData') &&
                                    <Col sm={8}>
                                        <Form.Item label="State">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select State"
                                                name='state_id'
                                                options={Statelist?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.state_name
                                                    }
                                                })}
                                                value={selectedOption?.state_id}
                                                onChange={(value) => handleSelectChange('state_id', value)}
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'leadCompanyData') &&
                                    <Col sm={8}>
                                        <Form.Item label="Lead Company">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="NCC Limited"
                                                name='lead_comp_ids'
                                                options={leadCompanylist?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.company_name
                                                    }
                                                })}
                                                value={selectedOption?.lead_comp_ids}
                                                onChange={(value) => handleSelectChange('lead_comp_ids', value)}
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'jointVentureData') &&
                                    <Col sm={8}>
                                        <Form.Item label="Joint Venture">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select Joint Venture"
                                                options={Clientoptions}
                                                value={selectedOption?.jointVentureData}
                                                onChange={(value) => handleSelectChange('jointVentureData', value)}
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'tenderType') &&
                                    <Col sm={8}>
                                        <Form.Item label="Tender Type">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select Tender Type"
                                                options={Clientoptions}
                                                value={selectedOption?.tenderType}
                                                onChange={(value) => handleSelectChange('tenderType', value)}
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'sector') &&
                                    <Col sm={8}>
                                        <Form.Item label="Sector">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select Sector"
                                                options={sectorlist?.map((item, index) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.sector_name
                                                    }
                                                })}
                                                name='sector_id'
                                                value={selectedOption?.sector_id}
                                                onChange={(value) => handleSelectChange('sector_id', value)}
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {_.has(props?.columnLabels, 'categ') &&
                                    <Col sm={12}>
                                        <Form.Item label="Company name">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select Designation"
                                                options={Clientoptions}
                                                // value={selectedOption?.sector}
                                                onChange={(value) => handleSelectChange('Designation', value)}
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>}
                                {/* {_.has(props?.columnLabels, 'fundingAgencyData') &&
                                    <Col sm={8}>
                                        <Form.Item label="Choose File">
                                            <Upload {...props}>
                                                <Button >Choose File</Button>
                                                No File Choosen
                                            </Upload>
                                        </Form.Item> */}


                                {_.has(props?.columnLabels, 'categ') &&
                                    <Col sm={12}>
                                        <Form.Item label="Designation">
                                            <Select
                                                showSearch
                                                optionFilterProp="children"
                                                placeholder="Select Designation"
                                                options={Clientoptions}
                                                // value={selectedOption?.sector}
                                                onChange={(value) => handleSelectChange('Designation', value)}
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>
                                }
                                {
                                    props?.showUploadFiled === true ?
                                        <Col sm={8}>
                                            <Form.Item label="Upload file">
                                                <Upload
                                                    action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                                                    listType="picture"
                                                    maxCount={1}
                                                    name='files'
                                                    value={selectedOption?.files}
                                                    onChange={(e) => handleSelectChange(e?.file?.name)}
                                                >
                                                    <button className="uploadButton">
                                                        <UploadOne theme="outline" size="24" fill="#95a6b6" strokeWidth={3} strokeLinecap="butt" /> Upload
                                                    </button>
                                                </Upload>
                                            </Form.Item>
                                        </Col>
                                        : <></>

                                }

                            </Row>
                        </Form>
                    </div>
                    <div className="">
                        <Editor
                            // apiKey="your-api-key"
                            // content={editorContent}
                            // onChange={() => handleSelectChange('project_name', editorRef?.current?.getContent())}
                            // onInit={(evt, editor) => editorRef.current = editor}
                            // initialValue={selectedOption?.project_name}
                            // name='project_name'
                            init={{
                                height: 300,
                                menubar: false,
                                plugins: [
                                    "advlist",
                                    "autolink",
                                    "lists",
                                    "link",
                                    "image",
                                    "charmap",
                                    "preview",
                                    "anchor",
                                    "searchreplace",
                                    "visualblocks",
                                    "code",
                                    "fullscreen",
                                    "insertdatetime",
                                    "media",
                                    "table",
                                    "code",
                                    "help",
                                    "wordcount",
                                ],
                                toolbar:
                                    "undo redo | blocks | " +
                                    "bold italic forecolor | alignleft aligncenter " +
                                    "alignright alignjustify | bullist numlist outdent indent | " +
                                    "removeformat | help",
                                content_style:
                                    "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }",
                            }}
                        />
                    </div>

                    <div className="bd_drawerFoot">
                        <button className='BG_ghostButton' onClick={() => setSelectedOption(initialstate)} >Reset</button>
                        <button className='BG_mainButton'
                            onClick={handleSubmit}
                        >Create</button>
                    </div>
                </div>
            </div>
        </Drawer>
    )

}
export default LiveAddTender