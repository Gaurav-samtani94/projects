// @ts-nocheck
import React, { useEffect, useState, useMemo } from 'react'
import { Menu, Select, Table, Input, Dropdown, Modal, Upload, Drawer, Form, Row, Col, Flex, Button } from 'antd';
import { Down, AddOne } from '@icon-park/react';
import skipBack from '../../assets/images/skip-back.png'
import ROUTES from 'Constants/Routes';
import { TeamReqApi } from 'Services/bidgrid/tenderList/TeamReqApi';
import { toast } from 'react-toastify';
import { useNavigate, useParams } from 'react-router-dom';
const { TextArea } = Input;

const initialState = {
    category_id: null,
    designation_id: [],
    age_limit: null,
    man_months: null,
    construction_months: null,
    development_months: null,
    om_months: null,
    remarks: null,
    weightage_marks: null
}
const { Option } = Select;

const TeamRequisitionDrawer = (props) => {
    const { onClose, openDrawer, getTeamreqList, categories, record, setRecord } = props

    const [form] = Form.useForm();
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const navigate = useNavigate()
    const { id } = useParams()

    const [drawerData, setDrawerData] = useState(initialState)
    const [designations, setDesignations] = useState([])
    const [loadingReq, setLoadingReq] = useState(false);

    const handleSubmit = async (value) => {
        if (record?.id) {
            setLoadingReq(true)
            try {
                const formData = new URLSearchParams()
                formData.append('project_id', id)
                formData.append('tm_rq_negotiation_members_id', record?.id)
                // formData.append('category_id', value?.category_id)
                // formData.append('designation_id', value?.designation_id)
                value?.age_limit && formData.append('age_limit', Number(value?.age_limit))
                value?.man_months && formData.append('man_months', Number(value?.man_months))
                value?.construction_months && formData.append('construction_months', Number(value?.construction_months))
                value?.development_months && formData.append('development_months', Number(value?.development_months))
                value?.om_months && formData.append('om_months', Number(value?.om_months))
                value?.remarks && formData.append('remarks', value?.remarks)
                value?.weightage_marks && formData.append('weightage_marks', Number(value?.weightage_marks))
                const response = await TeamReqApi.teamRqNegociationUpdate(formData)

                if (response?.data?.status === '1') {
                    notifySuccess('Team Requisition Updated Successfully')
                    onClose()
                    setLoadingReq(false)
                    await getTeamreqList()
                    form.resetFields()
                    setDrawerData(initialState)
                    setRecord({})
                } else {
                    notify(response?.response?.data?.message)
                    setLoadingReq(false)
                }
            } catch (error) {
                setLoadingReq(false)
                notify(error)
            }
        } else {
            setLoadingReq(true)
            try {
                const formData = new URLSearchParams()
                formData.append('category_id', value?.category_id)
                formData.append('designation_id', value?.designation_id)
                formData.append('project_id', id)
                formData.append('age_limit', Number(value?.age_limit) || '')
                formData.append('man_months', Number(value?.man_months) || '')
                formData.append('construction_months', Number(value?.construction_months) || '')
                formData.append('development_months', Number(value?.development_months) || '')
                formData.append('om_months', Number(value?.om_months) || '')
                formData.append('remarks', value?.remarks || '')

                formData.append('weightage_marks', Number(value?.weightage_marks) || '')
                const response = await TeamReqApi.teamRqNegociationCreate(formData)
                if (response?.data?.status === '1') {
                    notifySuccess('Team Requisition Added Successfully')
                    onClose()
                    form.resetFields()
                    setDrawerData(initialState)
                    await getTeamreqList()
                    setLoadingReq(false)

                } else {
                    notify(response?.response?.data?.message)
                    setLoadingReq(false)
                }
            } catch (error) {
                setLoadingReq(false)
                notify(error)
            }
        }

    }

    const handleNavigate = (url) => {
        navigate(url)
    }
    const handleChangeDrawer = (name, value) => {

        if (name === 'category_id') {
            setDrawerData(prevState => ({
                ...prevState,
                designation_id: [],
                [name]: value
            }));
            form.setFieldsValue({
                designation_id: []
            })
        } else {
            setDrawerData(prevState => ({
                ...prevState,
                [name]: value
            }));
        }

    }

    const fetchDesignation = async () => {
        try {
            const formData = new URLSearchParams()
            formData.append('category_id', drawerData?.category_id)
            const response = await TeamReqApi.getRequisitionDesignationList(formData)
            if (response?.data?.status === '1') {
                setDesignations(response?.data?.data)
            } else {
                setDesignations([])
            }
        } catch (error) {
            setDesignations([])
        }
    }

    const handleKeyContainOnlyNumbers = (e) => {
        const allowedChars = /[0-9.]/;
        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        }
        else if (e.key === 'Enter') {
            e.preventDefault();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    }
    const handleReset = () => {
        form.resetFields()
        setDrawerData(initialState)
    }

    useEffect(() => {
        if (drawerData?.category_id) {
            fetchDesignation()
        }
    }, [drawerData?.category_id])

    useEffect(() => {
        if (record?.hasOwnProperty('id')) {
            form.setFieldsValue({
                category_id: record?.category_id,
                designation_id: record?.designation_id,
                age_limit: record?.age_limit,
                man_months: String(record?.man_months),
                construction_months: String(record?.construction_months),
                development_months: String(record?.development_months),
                om_months: String(record?.om_months),
                remarks: String(record?.remarks),
                weightage_marks: Number(record?.weightage_marks)
            });
            // const obj = {
            //     designation_id: record?.designation_id,
            // }
            // setDrawerData(obj)
        }
    }, [record])

    useEffect(() => {
        console.log(drawerData)
    }, [drawerData])

    return (
        <Drawer title={record?.id ? '"Edit Requisition"  ' : "Add Requisition"} className="teamRequisition_drawer" closeIcon={<img src={skipBack} alt='' />} onClose={() => { onClose(); setRecord({}); form.resetFields(); setDrawerData(initialState) }} open={openDrawer} width={760}>
            <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={handleSubmit} >
                <Row gutter={30}>

                    {
                        !record?.id ?
                            <>
                                <Col span={12}>
                                    <div className="addItemButton" onClick={() => handleNavigate(ROUTES.TeamRequisitionDesignationCategory)}>
                                        <AddOne theme="filled" size="22" fill="#ff7043" strokeWidth={3} strokeLinecap="butt" />
                                    </div>
                                    <Form.Item label="Category:" name="category_id" rules={[{ required: true, message: "please choose a category" }]}>

                                        <Select
                                            allowClear
                                            showSearch
                                            name='category_id'
                                            placeholder='Select Category'
                                            optionFilterProp="children"
                                            options={categories?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.category_name
                                                }
                                            })}
                                            value={drawerData?.category_id}
                                            onChange={(e) => handleChangeDrawer('category_id', e)}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>

                                <Col span={12}>
                                    <div className="addItemButton" onClick={() => handleNavigate(ROUTES.TeamRequisitionDesignation)}>
                                        <AddOne theme="filled" size="22" fill="#ff7043" strokeWidth={3} strokeLinecap="butt" />
                                    </div>
                                    <Form.Item label="Designation:" name='designation_id' rules={[{ required: true, message: "please select a designation" }]}>

                                        <Select
                                            allowClear
                                            showSearch
                                            placeholder='Search here...'
                                            mode='multiple'
                                            filterOption={(input, option) =>
                                                option?.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                            value={drawerData?.designation_id?.map((id) => designations?.find((designation) => designation.id === Number(id))?.id)}
                                            name='designation_id'
                                            onChange={(value) => {
                                                const selectedIds = value?.map((id) =>
                                                    designations.find((des) => des.id === id)?.id
                                                );
                                                handleChangeDrawer('designation_id', selectedIds);
                                            }}
                                        // options={designations?.map((item, index) => {
                                        //     return {
                                        //         value: item?.id,
                                        //         label: item?.designation_name
                                        //     }
                                        // })}
                                        >
                                            {designations?.map((item) => (
                                                <Select.Option key={item?.id} value={item?.id}>
                                                    {item?.designation_name}
                                                </Select.Option>
                                            ))}
                                        </Select>
                                    </Form.Item>
                                </Col>
                            </>

                            :
                            <></>

                    }

                    <Col span={12}>
                        <Form.Item onKeyPress={handleKeyContainOnlyNumbers} label="Age Limit:" name='age_limit'
                        // rules={[{ required: true, message: "please enter age limit" }]}
                        >
                            <Input value={drawerData?.age_limit} onChange={(e) => handleChangeDrawer('age_limit', e.target.value)} placeholder='Enter age limit' />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item onKeyPress={handleKeyContainOnlyNumbers} label="Man months:"
                            name='man_months'
                        //  rules={[{ required: true, message: "please enter man months" }]}
                        >
                            <Input value={drawerData?.man_months} onChange={(e) => handleChangeDrawer('man_months', e.target.value)} placeholder='Enter man months' />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item onKeyPress={handleKeyContainOnlyNumbers} label="Construction Months:" name='construction_months'
                        // rules={[{ required: true, message: "please enter Construction Months" }]}
                        >
                            <Input value={drawerData?.construction_months} onChange={(e) => handleChangeDrawer('construction_months', e.target.value)} placeholder='Enter Construction Months' />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item onKeyPress={handleKeyContainOnlyNumbers} label="Development Months:" name='development_months'
                        //  rules={[{ required: true, message: "please enter Development Months" }]}
                        >
                            <Input value={drawerData?.development_months} onChange={(e) => handleChangeDrawer('development_months', e.target.value)} placeholder='Enter Development Months' />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item onKeyPress={handleKeyContainOnlyNumbers} label="O&M Months :" name='om_months'
                        //  rules={[{ required: true, message: "please enter om months" }]}
                        >
                            <Input value={drawerData?.om_months} onChange={(e) => handleChangeDrawer('om_months', e.target.value)} placeholder='Enter operations & maintenance months' />
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item onKeyPress={handleKeyContainOnlyNumbers} label="Weightage Marks :" name='weightage_marks'
                        //  rules={[{ required: true, message: "please enter om months" }]}
                        >
                            <Input value={drawerData?.weightage_marks} onChange={(e) => handleChangeDrawer('weightage_marks', e.target.value)} placeholder='Enter weightage marks' />
                        </Form.Item>
                    </Col>

                    <Col span={12}>
                        <Form.Item label="Remarks :" name='remarks'
                        //  rules={[{ required: true, message: "please enter om months" }]}
                        >
                            <TextArea value={drawerData?.remarks} onChange={(e) => handleChangeDrawer('remarks', e.target.value)} placeholder='Enter remarks' />
                        </Form.Item>
                    </Col>
                </Row>

                <Flex justify='flex-end' align='center'>
                    <Button key="back" className='BG_ghostButton' onClick={handleReset}>
                        Reset
                    </Button>
                    <Button key="submit" className='BG_mainButton' style={{ marginLeft: '20px' }} type="primary" htmlType="submit" loading={loadingReq} disabled={loadingReq}>
                        {record?.id ? 'Update' : 'Submit'}

                    </Button>
                </Flex>
            </Form>
        </Drawer>
    )
}

export default TeamRequisitionDrawer
