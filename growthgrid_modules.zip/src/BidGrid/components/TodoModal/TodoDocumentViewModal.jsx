// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Modal, Card } from 'antd'
import { DownloadOutlined } from '@ant-design/icons';
import { docurlchat } from 'utils/configurable';

// import { FALSE } from 'sass';

function TodoDocumentViewModal({ viewStatus, setViewStatus, getDocumentData, viewModelStatus, assignedModelData }) {
    // console.log(assignedModelData, ">>>>>><<<<<<<<<<")
    const outputArray = [{
        assign_by: assignedModelData[0]?.assin_by?.userfullname,
        assigned: assignedModelData?.map(item => ({ userfullname: item?.user?.userfullname }))
    }];
    const [downloadLink, setDownloadLink] = useState(null);

    const documentBlobReq = async (doc_name, apiUrl) => {
        const fullUrl = window.location.href;
        const urlObject = new URL(fullUrl);
        const protocol = urlObject.protocol;
        const hostname = urlObject.host;
        const domain = `${protocol}//${hostname}`;
        const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
        const response = await fetch(proxyUrl)
        const blobData = await response?.blob()
        const fileURL = window.URL.createObjectURL(blobData);
        let alink = document.createElement("a");
        alink.href = fileURL;
        alink.download = doc_name;
        alink.click();
    }

    const documentDownload = (item) => {
        const apiUrl = `${docurlchat}${item?.doc_path}/${item?.doc_name}`;
        documentBlobReq(item?.doc_name, apiUrl)
    };

    useEffect(() => {
        if (!viewStatus) {
            setDownloadLink(null);
        }
    }, [viewStatus]);
    return (
        <Modal className='bd_model_main' title={viewModelStatus === 1 ? "View Document" : 'View Assigned User'} open={viewStatus} onCancel={() => setViewStatus(false)}
            footer={null}
        >
            {
                viewModelStatus === 1 ?
                    <>
                        {getDocumentData?.map(task => task?.todo_comment_documents)?.map((innerArray, outerIndex) => (
                            <div key={outerIndex}>
                                {innerArray?.map((doc, innerIndex) => (
                                    <Card
                                        style={{
                                            margin: 20,
                                            paddingBlock: 0,
                                        }}

                                    >
                                        <span style={{ display: 'flex', justifyContent: 'space-between' }} key={innerIndex}> {doc?.doc_name}
                                            <div style={{ cursor: 'pointer' }} onClick={() => documentDownload(doc)}><DownloadOutlined /></div>
                                        </span>
                                    </Card>
                                ))}
                            </div>
                        ))}
                    </>
                    :
                    viewModelStatus === 2 ?
                        <>


                            {
                                outputArray?.map((item, index) => {
                                    return (
                                        <>
                                            <h5 key={index} className='fw-normal d-flex gap-2 mb-3'>Assigned By:  <h5 className='text-secondary'>{item?.assign_by}</h5></h5>
                                            <div className='d-flex gap-2'>
                                                <h5 className='fw-normal'>Assigned To: </h5>
                                                <p>
                                                    {item?.assigned?.map(item => item?.userfullname).join(",  ")}
                                                </p>
                                            </div>
                                        </>

                                    )
                                })
                            }

                        </>
                        :
                        <></>
            }

        </Modal >
    )
}

export default TodoDocumentViewModal