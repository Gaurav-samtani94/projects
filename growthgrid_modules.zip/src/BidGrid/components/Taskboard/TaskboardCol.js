// @ts-nocheck
import { Droppable, Draggable } from 'react-beautiful-dnd';
import styled from 'styled-components';
import { Button, Card } from 'antd';
import { TaskboardItemStatus } from './TaskboardTypes';
import TaskboardItemCard from './TaskboardItemCard';
import { colors } from '../SharedHooks/SharedUtils';
import { PlusCircleOutlined } from '@ant-design/icons';
const TaskboardColRoot = styled(Card)`
  user-select: none;
  flex: 1;
  margin: 0.5rem;
  display: flex;
  flex-direction: column;
  min-width: 0;
  > .ant-card-body {
    overflow: hidden;
    height: 100%;
    padding: 0;
  }
`;

const DroppableRoot = styled.div`
  height: 100%;
  overflow-y: auto;
  background-color: ${colors?.primary[1]};
`;

export const TaskboardColProps = {
    onEdit: null,
    onDelete: null,
    items: [],
    status: TaskboardItemStatus?.TO_DO,
    onClickAdd: null,
};

function TaskboardCol(props) {
    const { items, status, onClickAdd, onEdit, onDelete } = props;

    return (
        <TaskboardColRoot className='bd_title_name_assigine'
            title={`${status} (${items?.length})`}
            extra={
                onClickAdd && (
                    <Button className="bd_title_btn" type="primary" onClick={onClickAdd}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 33 33" fill="none">
                            <path d="M16.6667 3.39355C9.30668 3.39355 3.33334 9.36689 3.33334 16.7269C3.33334 24.0869 9.30668 30.0602 16.6667 30.0602C24.0267 30.0602 30 24.0869 30 16.7269C30 9.36689 24.0267 3.39355 16.6667 3.39355ZM23.3333 18.0602H18V23.3936H15.3333V18.0602H10V15.3936H15.3333V10.0602H18V15.3936H23.3333V18.0602Z" fill="#FF7835" />
                        </svg>
                    </Button>
                )
            }
        >
            <Droppable droppableId={status}>
                {(provided, snapshot) => (
                    <DroppableRoot
                        ref={provided?.innerRef}
                        {...provided?.droppableProps}
                    >
                        {items.map((item, index) => {
                            return (
                                <Draggable key={item?.id} draggableId={item?.id} index={index}>
                                    {(provided, snapshot) => (
                                        <div
                                            key={item.id}
                                            ref={provided?.innerRef}
                                            {...provided?.draggableProps}
                                            {...provided?.dragHandleProps}
                                        >
                                            <TaskboardItemCard
                                                item={item}
                                                status={status}
                                                onEdit={onEdit}
                                                onDelete={onDelete}
                                            />
                                        </div>
                                    )}
                                </Draggable>
                            );
                        })}
                        {provided?.placeholder}
                    </DroppableRoot>
                )}
            </Droppable>
        </TaskboardColRoot>
    );
}

export default TaskboardCol;
