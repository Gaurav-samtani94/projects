// @ts-nocheck
import React from 'react';
import { Button, Card, Modal, Typography, Dropdown, Menu } from 'antd';
import { ClockCircleOutlined } from '@ant-design/icons';
import { red } from '@ant-design/colors';
import styled from 'styled-components';
import { BaseTooltip } from '../SharedHooks/BaseTooltip';
import { TaskboardItemStatus } from './TaskboardTypes';
import { DeleteOutlined, EditOutlined, MoreOutlined } from '@ant-design/icons';
import { Avatar, Divider, Tooltip } from 'antd';
import { AntDesignOutlined, UserOutlined } from '@ant-design/icons';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
const StyledCard = styled(Card)`
  margin: 0.5rem;
  padding: 0.5rem;
  background-color: ${({ isDragging }) => (isDragging ? '#fafafa' : '#fff')};
`;

const TaskboardItemCardTitle = styled(Typography.Title)`
  white-space: pre-wrap;
  margin-right: 0.25rem;
`;

const DeleteMenuItem = styled(Menu.Item)`
  color: ${red.primary};
`;

function TaskboardItemCard(props) {
    const { item, status, isDragging, onEdit, onDelete } = props;

    return (
        <StyledCard className='card-box-bd'
            isDragging={isDragging}
            size="small"
            title={
                <BaseTooltip overlay={item?.title}>
                    <span>
                        <TaskboardItemCardTitle level={5} ellipsis={{ rows: 2 }}>
                            {/* {item?.title} */}
                            <div className='headding-img'>
                                {/* <img src={ProjectImage} /> */}
                                <p>South Western Railway</p>
                            </div>


                        </TaskboardItemCardTitle>
                    </span>
                </BaseTooltip>
            }
            extra={
                <Dropdown
                    overlay={
                        <Menu>
                            <Menu.Item icon={<EditOutlined />} onClick={() => onEdit(item)}>
                                Edit
                            </Menu.Item>
                            <DeleteMenuItem
                                icon={<DeleteOutlined />}
                                onClick={() =>
                                    Modal.confirm({
                                        title: 'Delete?',
                                        content: `Are you sure to delete "${item.title}"?`,
                                        onOk: () =>
                                            onDelete({
                                                status,
                                                itemToDelete: item,
                                            }),
                                    })
                                }
                            >
                                Delete
                            </DeleteMenuItem>
                        </Menu>
                    }
                    trigger={['click']}
                >
                    <Button size="small" icon={<MoreOutlined />} />
                </Dropdown>
            }
        >
            <BaseTooltip overlay={item?.description}>
                {/* {item?.description}
                     */}
                <div className='pra-box'>
                    {
                        // capitalizeExceptPrepositionsAndLowerCase(<p> dashboard UI design is a visually engaging and intuitively structured interface tailored to streamline project management</p>)
                        <p>{capitalizeExceptPrepositionsAndLowerCase('dashboard UI design is a visually engaging and intuitively structured interface tailored to streamline project management')}</p>
                    }    </div>
            </BaseTooltip>
            <div className='card-box'>
                <div className='box-content'>


                    <div className='date-box'>
                        <div className='icon-title'>
                            <ClockCircleOutlined className='date-box-icon' /> Deadline:
                        </div>
                        <div>
                            <span> 11th 15aug 2023
                            </span>
                        </div>
                    </div>
                    <div className='bd_avatar_grp'>
                        <Avatar.Group
                            maxCount={2}
                            maxPopoverTrigger="click"
                            size="large"
                            maxStyle={{ color: '#f56a00', backgroundColor: '#fde3cf', cursor: 'pointer' }}
                        >
                            <Avatar src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />
                            <Avatar style={{ backgroundColor: '#f56a00' }}>K</Avatar>
                            <Tooltip title="Ant User" placement="top">
                                <Avatar style={{ backgroundColor: '#87d068' }} icon={<UserOutlined />} />
                            </Tooltip>
                            <Avatar style={{ backgroundColor: '#1677ff' }} icon={<AntDesignOutlined />} />
                        </Avatar.Group>
                    </div>
                </div>
            </div>
        </StyledCard>
    );
}

export default TaskboardItemCard;
