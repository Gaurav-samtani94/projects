export const TaskboardItem = {
    id: '',
    title: '',
    description: '',
};

export const TaskboardItemStatus = {
    TO_DO: 'Today’s Tasks' ,
    IN_PROGRESS: 'Upcoming Tasks',
    DONE: 'Completed Tasks',
};
