import React from "react";
import dayjs from 'dayjs';
import * as XLSX from 'xlsx';

const ExcelComp = (props) => {

    const { tenderData } = props
    // console.log(tenderData, "tenderData")


    // For converting html tag value into normal html.
    const stripHtmlTags = (htmlContent) => {
        var doc = new DOMParser().parseFromString(htmlContent, 'text/html');
        return doc.body.textContent || "";
    }

    /* To formate the Excel */
    const formattedData = tenderData?.map((item) => {

        return {
            'Id': item?.id,
            'Name': stripHtmlTags(item?.tender_name),
            'Cost': item?.tender_cost,
            'Tender Emd Amount': item?.tender_emd_amnt_val,
            'Submission start date': dayjs(item?.submission_start_date)?.format('YYYY-MM-DD'),
            'Submission End date': dayjs(item?.submission_end_date)?.format('YYYY-MM-DD'),
        };
    })

    const downloadExcel = () => {
        if (tenderData?.length > 0) {
            const ws = XLSX.utils.json_to_sheet(formattedData);

            const blankRow = {};
            for (let i = 1; i <= 6; i++) {
                blankRow[`A2`] = { v: '' };
            }
            XLSX.utils.sheet_add_json(ws, [blankRow], { skipHeader: true, header: ['A', 'B', 'C', 'D', 'E', 'F'] });
            const colWidths = [
                { wch: 7 },
                { wch: 40 },
                { wch: 10 },
                { wch: 20 },
                { wch: 20 },
                { wch: 20 },
            ];

            ws['!cols'] = colWidths;

            const rowHeights = formattedData.map(() => ({ hpx: 30 }));
            ws['!rows'] = rowHeights;

            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

            const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
            const dataBlob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

            const downloadLink = document.createElement('a');
            const url = URL.createObjectURL(dataBlob);
            downloadLink.href = url;
            downloadLink.download = 'TenderList.xlsx';
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }

    };
    return (
        <>
            {downloadExcel()}
        </>
    )
}

export default ExcelComp;