// @ts-nocheck
import React, { useEffect, useState } from "react";
import { Tooltip } from 'antd';
import { CloseOutlined, ConsoleSqlOutlined } from '@ant-design/icons';
import dayjs from 'dayjs';
import { filterCycleActions } from "Redux/actions/bidgrid/cycleFilterAction";
import { useSelector, useDispatch } from 'react-redux';
import { DropdownValuesServices } from "Services/common/dropdown/dropdownValues";
import { misFilterActions } from "Redux/actions/bidgrid/misFilterAction";
import { trashFilterAction } from "Redux/actions/bidgrid/trashFilterAction";
import { AddTenderList } from "Services/bidgrid/add/AddTender";


const GenerateChips = (props) => {
    const { filterData, getScopeList, setTenderSearch, showCross, GenerateVal, setMisTenderSearch, commonFilter, setActiveOrderColor, val } = props
    const { BidSector, BidClient, BidCurrency, BidFundingClientAgency, BidCountry, BidTenderResultStatus, BidAllUsers, BidGenerateId, BidServiceProviders } = useSelector((state) => state.bidDropdownCalVal)

    const [stateVal, setStateVal] = useState([]);

    const tenderStatusList = [
        {
            id: '1',
            status_name: "Active"
        },
        {
            id: '2',
            status_name: "Inactive"
        },
        {
            id: "ALL",
            status_name: "ALL"
        }
    ]

    const locationList = [
        {
            id: '1',
            location_name: "National"
        },
        {
            id: '2',
            location_name: "International"
        }
    ]

    const dispatch = useDispatch()

    const FilterValueLables = {
        oneToNinten: "1 to 99 thousand",
        onelakhToOneCr: "1 Lac to 1 Cr",
        oneCrToTenCr: "1 Cr to 10 Cr",
        tenCrTOFifCr: "10 Cr to 50 Cr",
        fifCrToHundred: "50 Cr to 100 Cr",
        hunCRAbove: "100 Cr >"
    };

    function capitalizeWords(inputString) {
        return inputString?.split(' ')?.map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    }

    const getFinancialYears = () => {
        const today = new Date();
        const currentYear = today.getFullYear();
        const startYear = 2015;
        // const startMonth = 4; // 

        let financialYears = [];

        for (let year = startYear; year <= currentYear; year++) {
            const nextYear = year + 1;
            const financialYear = {
                label: `${year}-${nextYear}`,
                value: `${year}-${nextYear}`
            };
            financialYears.push(financialYear);
        }
        return financialYears;
    }

    useEffect(() => {
        // This effect will run only once when country_id is available
        const countryItem = filterData.find(item => item.key === 'country_id');
        if (countryItem?.value) {
            getStateDrpValue(countryItem.value);
        }
    }, [filterData]); // Dependency on filterData changes


    const getStateDrpValue = async (country_id) => {
        const formData = new URLSearchParams();
        try {
            formData.append('country_id', country_id);
            const response = await AddTenderList.getTenderStateList(formData)
            if (response?.data?.status == 1) {
                setStateVal(response?.data?.data?.filter(val => val?.state_name !== 'NA'))
            }
            else {
                setStateVal([]);
            }
        } catch {
            console.log("error")
            setStateVal([])
        }
    }


    const chipClose = (e, item) => {
        if (item.key === 'tender_keyword') {
            commonFilter == "CYCLE" ? setTenderSearch('') : commonFilter == "MIS" ? setMisTenderSearch('') : setTenderSearch('');
        }
        if (item.key === 'published_date' && item.value === 'custom_date') {
            commonFilter == "CYCLE" ? dispatch(filterCycleActions.filterResetIndividualKeys(['pubdate_cust_from_date', 'pubdate_cust_to_date', item?.key])) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterResetIndividualKeys(['pubdate_cust_from_date', 'pubdate_cust_to_date', item?.key])) : dispatch(trashFilterAction?.trashFilterResetIndividualKeys(['pubdate_cust_from_date', 'pubdate_cust_to_date', item?.key]));
        }
        else if (item.key === 'close_exp_date' && item.value === 'custom_date') {
            commonFilter == "CYCLE" ? dispatch(filterCycleActions.filterResetIndividualKeys(['expdate_cust_from_date', 'expdate_cust_to_date', item?.key])) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterResetIndividualKeys(['expdate_cust_from_date', 'expdate_cust_to_date', item?.key])) : dispatch(trashFilterAction?.trashFilterResetIndividualKeys(['expdate_cust_from_date', 'expdate_cust_to_date', item?.key]));
        }
        else if (item.key === 'estm_value' && item.value === 'custom_range') {
            commonFilter == "CYCLE" ? dispatch(filterCycleActions.filterResetIndividualKeys(['amnt_custrange_operator', 'amnt_custrange_amount', 'custrange_denomination', item?.key])) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterResetIndividualKeys(['amnt_custrange_operator', 'amnt_custrange_amount', 'custrange_denomination', item?.key])) : dispatch(trashFilterAction?.trashFilterResetIndividualKeys(['amnt_custrange_operator', 'amnt_custrange_amount', 'custrange_denomination', item?.key]));
        }
        else if (item.key === 'estm_value_emd' && item.value === 'custom_range') {
            commonFilter == "CYCLE" ? dispatch(filterCycleActions.filterResetIndividualKeys(['amnt_custrange_operator_emd', 'amnt_custrange_amount_emd', 'custrange_denomination_emd', item?.key])) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterResetIndividualKeys(['amnt_custrange_operator_emd', 'amnt_custrange_amount_emd', 'custrange_denomination_emd', item?.key])) : dispatch(trashFilterAction?.trashFilterResetIndividualKeys(['amnt_custrange_operator_emd', 'amnt_custrange_amount_emd', 'custrange_denomination_emd', item?.key]));
        }
        else if ((item.key == 'sort_key' && (item.value == 'tender_emd_amnt_val' || item.value == 'tender_amnt_val' || item.value == 'published_date' || item.value == 'submission_end_date')) || (item.key == 'sort_val' && (item.value == 'asc' || item.value == 'desc'))) {
            console.log('item======= inner', item);
            commonFilter == "CYCLE" ? dispatch(filterCycleActions.filterResetIndividualKeys(['sort_val', 'sort_key', item?.key])) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterResetIndividualKeys([item?.key, 'state_id'])) : dispatch(trashFilterAction?.trashFilterResetIndividualKeys([item?.key, 'state_id']));
            localStorage.removeItem('sortBy')
            setActiveOrderColor()
        }
        else if (item.key === 'country_id') {
            commonFilter == "CYCLE" ? dispatch(filterCycleActions.filterResetIndividualKeys([item?.key, 'state_id'])) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterResetIndividualKeys([item?.key, 'state_id'])) : dispatch(trashFilterAction?.trashFilterResetIndividualKeys([item?.key, 'state_id']));
        }
        else {
            commonFilter == "CYCLE" ? dispatch(filterCycleActions.filterResetIndividualKeys([item?.key])) : commonFilter == "MIS" ? dispatch(misFilterActions?.misFilterResetIndividualKeys([item?.key])) : dispatch(trashFilterAction?.trashFilterResetIndividualKeys([item?.key]));
        }

    }

    return filterData?.filter(item =>
        item?.value !== ''
        && item?.value !== undefined
        && item?.key !== 'limit'
        && item?.key !== 'page_number'
        && item?.key !== 'cycle_id'
        && item?.key !== 'orderSerial'
        && (val !== 'popup' || (item?.key !== 'sort_key' && item?.key !== 'sort_val'))
    )?.map((item) => {
        let chipsVal;

        if (item.key === 'sector_id') {
            const chipsValreturn = BidSector?.filter(val => val.id == item.value)?.map(item => item?.sector_name)
            // console.log(chipsValreturn, "chipsValreturn")
            chipsVal = chipsValreturn
        }
        else if (item.key === 'generated_type') {
            const chipsValreturn = BidGenerateId?.filter(val => val.id == item.value)?.map(item => item?.generated_type)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'ping_users') {
            const chipsValreturn = BidAllUsers?.filter(val => val.id == item.value)?.map(item => item?.userfullname)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'bid_manager_filter') {
            const chipsValreturn = BidAllUsers?.filter(val => val.id == item.value)?.map(item => item?.userfullname)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'filter_fin_year') {
            const chipsValreturn = getFinancialYears()?.filter(val => val.value == item.value)?.map(item => item?.label)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'tender_activity_status') {
            const chipsValreturn = tenderStatusList?.filter(val => val.id == item.value)?.map(item => item?.status_name)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'located') {
            const chipsValreturn = locationList?.filter(val => val.id == item.value)?.map(item => item?.location_name)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'key_manager_filter') {
            const chipsValreturn = BidAllUsers?.filter(val => val.id == item.value)?.map(item => item?.userfullname)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'state_id') {
            const chipsValreturn = stateVal?.filter(val => val.id == item.value)?.map(item => item?.state_name)
            chipsVal = chipsValreturn
        }
        else if (item?.key === 'tender_status') {
            const chipsValreturn = getScopeList?.filter(val => val?.id == Number(item.value))?.map(item => commonFilter == "CYCLE" ? item?.scope_name : item?.cycle_name)
            chipsVal = chipsValreturn
        }
        else if (item?.key === 'tender_result_id') {
            const chipsValreturn = BidTenderResultStatus?.filter(val => val?.id == Number(item.value))?.map(item => item?.status_name)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'client_id') {
            const chipsValreturn = BidClient?.filter(val => val.id == item.value)?.map(item => item?.client_name)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'currency_id') {
            const chipsValreturn = BidCurrency?.filter(val => val.id == item.value)?.map(item => item?.name)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'funding_id') {
            const chipsValreturn = BidFundingClientAgency?.filter(val => val.id == item.value)?.map(item => item?.funding_org_name)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'country_id') {
            const chipsValreturn = BidCountry?.filter(val => val.id == item.value)?.map(item => item?.country_name)
            chipsVal = chipsValreturn
        }
        else if (item.key === 'from_date' || item.key === 'to_date' || item.key === 'expdate_cust_from_date' || item.key === 'expdate_cust_to_date' || item.key === 'pubdate_cust_from_date' || item.key === 'pubdate_cust_from_date' || item.key === 'pubdate_cust_to_date') {
            const chipsValreturn = item?.value
            chipsVal = chipsValreturn
        }
        else {
            function convertUnits() {
                switch (item?.value) {
                    case "1-99999":
                        return FilterValueLables.oneToNinten;
                    case "100000-9999999":
                        return FilterValueLables?.onelakhToOneCr;
                    case "10000000-99999999":
                        return FilterValueLables?.oneCrToTenCr;
                    case "100000000-499999999":
                        return FilterValueLables?.tenCrTOFifCr;
                    case "500000000-999999999":
                        return FilterValueLables?.fifCrToHundred;
                    case "1000000000":
                        return FilterValueLables?.hunCRAbove;
                    default:
                        return item?.value;
                }
            }
            let label = convertUnits(item.value);
            chipsVal = label;
        }
        let newKey = item?.key;
        let newValue = chipsVal;

        newValue = newValue?.toString().replace(/_/g, ' ');
        newKey = newKey?.replace(/_/g, ' ');
        if (newKey == "sort key") {
            newValue = `Sort by ${newValue}`
        }
        if (newKey == "sort val") {
            newValue = newValue == "asc" ? "Ascending Order" : "Descending Order"
        }
        if (newKey?.endsWith('id')) {
            newKey = newKey?.slice(0, -2);
        }

        return (
            <>
                <Tooltip title={newKey}>
                    <div className='chip'>{newKey == "sort val" || newKey == "sort key" ? `${capitalizeWords(newValue)}` : `${newKey} - ${capitalizeWords(newValue)}`}
                        {showCross && <CloseOutlined className='cross_icon' onClick={(e) => chipClose(e, item)} />}
                    </div>
                </Tooltip>
            </>
        )
    })

}

export default GenerateChips;