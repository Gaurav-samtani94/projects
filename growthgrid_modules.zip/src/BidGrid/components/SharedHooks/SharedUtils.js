import { geekblue } from '@ant-design/colors';

export const colors = {
    primary: geekblue,
};
