// @ts-nocheck
import { Tooltip, TooltipProps } from 'antd';
import React from 'react';
export function BaseTooltip(props) {
    return React.createElement(Tooltip, Object.assign({ mouseEnterDelay: 1.5 }, props));
}

