// @ts-nocheck

import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import React, { useEffect, useState } from "react";
import { useLocation } from 'react-router';
import TenderRequest from "./BdTenderDetails/TenderRequest";
import { bidEmployeeList } from "Services/bidgrid/employeeList/bidEmployeeList";

const Request = () => {
    const [employeeList, setEmployeeList] = useState([])

    const location = useLocation();
    const val = location?.pathname;
    const str = val.replace('/', '')
    const fetchUserList = async () => {
        try {
            const response = await bidEmployeeList.getUserList()
            if (response?.data?.status === "1") {
                setEmployeeList(response?.data?.data)
            } else {
                setEmployeeList([])
            }
        } catch (error) {

        }
    }

    useEffect(() => {
        fetchUserList()
    }, [])



    return (
        <div className="requestMain_wrapper" style={{ paddingBlock: 40 }}>
            <TenderRequest employeeListVal={employeeList} />
        </div>
    )
}
export default Request;