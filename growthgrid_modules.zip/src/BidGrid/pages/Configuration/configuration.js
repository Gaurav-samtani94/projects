// @ts-nocheck
import React, { useState, useEffect } from 'react';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import { useLocation } from 'react-router';
import '../../assets/css/app.scss';
import { Button, message, Steps, theme, Form, Row, Select, Col} from 'antd';
import { Down } from '@icon-park/react';

const steps = [
    {
        title: 'First',
        content: (
            <Form
                name='control-hooks'
                layout="vertical"
            >
                <Row gutter={16}>
                    <Col sm={8}>
                        <Form.Item label="Sector">
                            <Select
                                showSearch
                                optionFilterProp="children"
                                placeholder="Select sector"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                name='sector_id'
                            >
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col sm={8}>
                        <Form.Item label="Authority">
                            <Select
                                showSearch
                                optionFilterProp="children"
                                placeholder="Select Marked"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            >
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col sm={8}>
                        <Form.Item label="Currency">
                            <Select
                                showSearch
                                optionFilterProp="children"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            >
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col sm={8}>
                        <Form.Item label="Funding Agency">
                            <Select
                                showSearch
                                optionFilterProp="children"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            >
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col sm={8}>
                        <Form.Item label="Tender Status">
                            <Select
                                showSearch
                                optionFilterProp="children"
                                placeholder="Select Marked"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            >
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col sm={8}>
                        <Form.Item label="Country">
                            <Select
                                showSearch
                                optionFilterProp="children"
                                placeholder="Select Country"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                name='country_id'
                            >
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col sm={8}>
                        <Form.Item label="State">
                            <Select
                                showSearch
                                optionFilterProp="children"
                                placeholder="Select State"
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            >
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>
            </Form>

        ),
    },
    {
        title: 'Second',
        content: 'Second-content',
    },
    {
        title: 'Third',
        content: 'Third-content',
    },
    {
        title: 'Forth',
        content: 'Forth-content',
    },
    {
        title: 'Last',
        content: 'Last-content',
    },
];

const Configuration = () => {
    const location = useLocation();
    const val = location?.pathname;
    const str = val.replace('/', '');
    const { token } = theme.useToken();
    const [current, setCurrent] = useState(0);
    const next = () => {
        setCurrent(current + 1);
    };
    const prev = () => {
        setCurrent(current - 1);
    };
    const items = steps.map((item) => ({
        key: item.title,
        title: item.title,
    }));
    const contentStyle = {
        lineHeight: '260px',
        textAlign: 'center',
        // color: token.colorTextTertiary,
        // backgroundColor: token.colorFillAlter,
        borderRadius: token.borderRadiusLG,
        border: `1px solid ${token.colorBorder}`,
        marginTop: 50,
        padding: 30,
    };

    useEffect(() => {
    }, []);

    return (
        <>
            <Breadcrumb data={str} />
            <div className='configuration_container'>
                <div className='bd_Configuration_title'>
                    <h5>Configuration Form</h5>
                </div>
                <Steps current={current} items={items} />
                <div style={contentStyle}>{steps[current].content}</div>
                <div className='steps_btns'
                    style={{
                        marginTop: 24,
                    }}
                >
                    {current < steps.length - 1 && (
                        <Button className=" BG_mainButton" onClick={() => next()}>
                            Next
                        </Button>
                    )}
                    {current === steps.length - 1 && (
                        <Button className='BG_mainButton' onClick={() => message.success('Processing complete!')}>
                            Done
                        </Button>
                    )}
                    {current > 0 && (
                        <Button className='BG_ghostButton'
                            style={{
                                margin: '0 8px',
                            }}
                            onClick={() => prev()}
                        >
                            Previous
                        </Button>
                    )}
                </div>
            </div>
        </>
    );
}

export default Configuration;
