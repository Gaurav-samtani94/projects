import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
// const socketInstance = io('http://localhost:8486', {
//     transports: ['websocket'],
// });
const ChatApp = () => {
    const [socket, setSocket] = useState(null);
    const [error, setError] = useState(null);
    const [message, setMessage] = useState('');
    const [messages, setMessages] = useState([]);
    const [recipient, setRecipient] = useState([]);
    const [recipientId, setRecipientId] = useState();
    // useEffect(() => {
    //     socketInstance.on('connect_error', (err) => {
    //         setError(`Connection error: ${err.message}`);
    //     });
    //     socketInstance.on('receive', (data) => {
    //         setRecipient((prevMessages) =>
    //             [...prevMessages, data.data.message]);
    //         // const receivedMessage = data.data.message;
    //         // const fromUserId = 10
    //         // if (fromUserId === recipientId) {
    //         //     setMessages((prevMessages) => [...prevMessages, { from: 'Other', message: receivedMessage }]);
    //         // }

    //         console.log('Received "received" event:', data);
    //         // Handle the received event on the client side
    //     });


    //     setSocket(socketInstance);
    //     return () => {
    //         socketInstance.disconnect();
    //     };
    // }, []);
    const sendMessage = () => {
        if (socket && socket.connected) {
            socket.emit('send', { to_user_id: 1, message, authorization: 1 });
            setMessages(
                (prevMessages) =>
                    [...prevMessages, { from: 'Me', message }]);
            setMessage('');
        } else {
            console.log(socket, 'not connected')
            setError('Socket is not connected');
        }

    };

    return (

        <div>
            <div>
                <label>
                    Recipient:

                    <ul>
                        {recipient.map((msg, index) => (
                            <li key={index}>
                                <strong>Received:</strong> {msg}
                            </li>
                        ))}
                    </ul>
                    {/* onChange={(e) => setRecipient(e.target.value)}  */}
                    {/* <input type="text" value={recipient} /> */}

                    Recipient ID:
                    {/* <input type="text" value={recipientId} onChange={(e) => setRecipientId(e.target.value)} /> */}

                </label>
            </div>
            <div>
                <ul>
                    {messages.map((msg, index) => (
                        <li key={index}>
                            <strong>{msg.from}:</strong> {msg.message}
                        </li>
                    ))}
                </ul>
            </div>
            <div>
                <input type="text" value={message} onChange={(e) => setMessage(e.target.value)} />
                <button onClick={sendMessage}>Send</button>
            </div>
        </div>
    );
};


export default ChatApp;
