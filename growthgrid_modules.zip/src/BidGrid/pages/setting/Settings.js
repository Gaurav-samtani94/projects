// @ts-nocheck
import React, { useEffect, useState } from 'react';
import ROUTES from 'Constants/Routes';

import { Link, NavLink, useNavigate } from "react-router-dom";
import { useSelector } from 'react-redux';

// const { TabPane } = Tabs;
// ---------- Menus
const navMenus = [
    {
        key: "master",
        label: "Master",
        children: [
            { label: 'Business Unit', link: ROUTES?.ADDUNIT },
            { label: 'Job Grade', link: ROUTES?.JOBTITLE },
            // { label: 'Prefix', link: ROUTES?.PREFIX },
            { label: 'Tender Prefix', link: ROUTES?.PREFIXNO },
            { label: 'User Role', link: ROUTES?.ROLE },
            { label: 'Department', link: ROUTES?.DEPARTMENT_MANAGE },
            { label: 'Designation', link: ROUTES?.DESIGNATION },

            { label: 'Currency', link: ROUTES?.CURRENCY },
            // { label: 'Language', link: ROUTES?.LANGUAGE },
            { label: "Company", link: ROUTES.COMPANY },
            // { label: 'Time Zone', link: ROUTES?.TIMEZONE },
            { label: 'Tender Sector', link: ROUTES?.ASSIGNSECTOR },
            // { label: 'Keyword', link: ROUTES?.KEYWORD },
            { label: 'Logo', link: ROUTES?.LOGO },
            { label: "Tender Company", link: ROUTES.TENDER_COMPANY },
            { label: 'Country', link: ROUTES?.COUNTRYLIST },
            // { label: 'Sub-sector', link: ROUTES?.SUBSECTOR },
            { label: 'Phase', link: ROUTES?.TENDER_PHASE },
            { label: 'Tender Phase', link: ROUTES?.TENDER_SCOPE },
            { label: 'Funding Agency', link: ROUTES?.FUNDING_AGENCY },
            { label: 'State', link: ROUTES?.STATELIST },
            { label: 'City', link: ROUTES?.CITYLIST },
            // { label: 'Continent', link: ROUTES?.CONTINENTLIST },
            { label: 'Region', link: ROUTES?.REGIONLIST },
            // { label: 'Employee Status', link: ROUTES?.EMPLOYEE_STATUS },
            // { label: 'Blood Group', link: ROUTES?.BLOODGROUP },
            { label: 'Tender Services', link: ROUTES?.TENDER_SERVICES },
            { label: 'Nationality', link: ROUTES?.NATIONALITY },
            // { label: 'Gender', link: ROUTES?.GENDER },
            { label: 'Client', link: ROUTES?.BD_CLIENT },
            { label: 'Consortium', link: ROUTES?.CONSORTIUM },
            { label: 'Tender Status', link: ROUTES?.TENDER_STATUS },
            { label: 'Files', link: ROUTES?.DOCTROL },
            { label: 'Bank', link: ROUTES?.BANK },
            { label: 'Roles & Permissions', link: ROUTES?.ROLEPERMISSIONS },
            { label: 'Widget Management', link: ROUTES?.WIDGETSACTION },
            { label: 'Tender Quick Actions', link: ROUTES?.TENDERCYCLEACTION },
            { label: 'Configuration', link: ROUTES?.CONFIGURATIONLEVEL },


        ]
    },
]

const Settings = ({ listName }) => {

    const { bidMenu } = useSelector((state) => state?.bidMenuVal)
    const settingMenu = bidMenu?.find(item => item?.menu_name === 'Setting')

    const menuList = [
        {
            key: "master",
            label: "Master",
            child: settingMenu?.children?.filter(val => val.is_view === '0')?.map(item => {
                return {
                    label: item?.menu_name, link: item?.action_url
                }
            })
        }

    ]

    const filteredItems = menuList[0]?.child?.filter(item => item?.label?.toLowerCase()?.includes(listName?.toLowerCase()));

    return (
        <>
            <ul>
                {filteredItems?.sort((a, b) => a?.label?.localeCompare(b?.label))?.map((item, index) =>
                    <li key={index}>
                        <NavLink to={item.link}>{item.label}</NavLink>
                    </li>
                )}
            </ul>
        </>
    )
}

export default Settings;


