// @ts-nocheck
import React, { Suspense, lazy, useState } from 'react'
import { Link, useNavigate } from "react-router-dom";
import { Drawer, Form, Select, Input, Checkbox, Collapse, Space, Radio, Tooltip } from 'antd';
import { SearchOutlined } from '@ant-design/icons';
import Settings from './Settings';


const { Search } = Input;

const SettingsLayout = ({ children }) => {
    const [listName , setListName] = useState('')

    const handleChange = (e)=>{
        setListName(e.target.value)
    }
    console.log(listName ,"listName")
    
    return (
        <>
            <div className="setting-container">
                <div className="seeting_tabsMenu">
                    <div className="fixed_wrap">
                        <div className="headding-title">
                            <h2>Settings</h2>
                            <div className="bd_seacrh_box">
                                <Input
                                    placeholder="Search"
                                    style={{ width: "100%" }}
                                    onChange={handleChange}
                                />
                                <div className="search_icon"><button><SearchOutlined /></button></div>
                            </div>
                        </div>
                        <Settings listName={listName}/>
                    </div>
                </div>
                <div className="w-50 flex-grow-1">
                    {children}
                </div>
            </div>
        </>
    )
}

export default SettingsLayout;


