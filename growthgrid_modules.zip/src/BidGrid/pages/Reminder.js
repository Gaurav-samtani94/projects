// @ts-nocheck
import React, { useState, useEffect, useMemo } from 'react'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap';
import { Input, Form, Row, Col, Spin, Button, DatePicker } from 'antd';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { ReminderList } from 'Services/bidgrid/Reminder/bidreminder';
import dayjs from 'dayjs';
const notify = (error) => toast.error(error);
const notifySuccess = (msg) => toast.success(msg);

const columnLabels = {
  reminder_date: { name: 'Date', required: true },
  reminder_subject: { name: 'Title', required: true },
  reminder_message: { name: 'Purpose', required: true },

};
const initialestate = {
  reminder_date: '',
  reminder_subject: '',
  reminder_message: '',
  reminder_id: '',
}
const Reminder = () => {
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState()
  const [sectorName, setSectorName] = useState(initialestate)
  const [loading, setLoading] = useState(true)
  const [getFinalData, setGetFinalData] = useState([])
  const location = useLocation();
  const val = location?.pathname;
  const str = val.replace('/', '')
  const showActions = true;


  const ReminderTableData = useMemo(() => {
    return getFinalData;
  }, [getFinalData]);

  const getreminder = async () => {
    try {
      const response = await ReminderList.getReminder()
      if (response?.data?.status == 1) {
        setDataSource(response?.data?.data)
      } else {
        setDataSource([])
        console.log(response?.response?.data?.message, 'api error')
      }
    } catch (error) {
      notify("Api Erorr!!");
      console.log(error, 'api erorr')
    }
  }

  const createHandler = async () => {
    if (
      sectorName?.reminder_date &&
      sectorName?.reminder_subject &&
      sectorName?.reminder_message &&
      sectorName?.tender_id
    ) {
      const formData = new URLSearchParams();

      formData.append('reminder_date', dayjs(sectorName?.reminder_date)?.format('YYYY-MM-DD'));

      formData.append('reminder_message', sectorName?.reminder_message)
      formData.append('reminder_subject', sectorName?.reminder_subject)
      formData.append('tender_id', sectorName?.tender_id)
      try {
        const response = await ReminderList.addReminder(formData)
        if (response?.data?.status == 1) {
          await getreminder()
          notifySuccess(response?.data?.message);
          handleReset()

        } else {
          notify(response?.response?.data?.message);
          handleReset()
        }
      } catch (error) {
        handleReset()
        console.log('Api Error', error)
      }
    }
  }

  const updateHandler = async (val) => {

    try {
      const formData = new URLSearchParams();

      formData.append('reminder_date', dayjs(sectorName?.reminder_date).format('YYYY-MM-DD'));
      formData.append('reminder_message', sectorName?.reminder_message);
      formData.append('reminder_subject', sectorName?.reminder_subject);
      formData.append('reminder_id', val?.id);

      const response = await ReminderList.updateReminder(formData);

      if (response?.data?.status == 1) {
        notifySuccess(response?.data?.message);
        await getreminder();
      } else {
        notify(response?.response?.data?.message);
      }
    } catch (error) {

      console.log('Api Error', error)
    }
  };


  const deletehandler = async (id) => {
    try {
      const formData = new URLSearchParams()
      formData.append('reminder_id', id)

      const response = await ReminderList.deleteReminder(formData)
      if (response?.data?.status == 1) {
        notifySuccess(response?.data.message);
        await getreminder()

      } else {
        notify(response?.response?.data?.message);
      }

    } catch {
      console.log('Api Error', 'error')

    }

  }

  const handleInputChange = (name, value) => {

    setSectorName({
      ...sectorName,
      [name]: value
    })
  };

  const handleReset = () => {

    setSectorName('');
    form.resetFields()
  };
  useEffect(() => {
    const finalVal = dataSource?.map(item => ({ id: item?.reminder_id, ...item }));
    setGetFinalData(finalVal)
  }, [dataSource])

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      getreminder()
      setLoading(false)
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [])


  const handleKeyPress = (e) => {
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      createHandler();
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };



  const handlenum = (e) => {
    const numregex = /[^0-9]/;
    if (e.key === 'Enter') {
      e.preventDefault();
      createHandler();
    }
    else if (numregex.test(e.key) && e.key !== 'Backspace') {
      e.preventDefault();

    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  }

  return (
    <>
      {/* <Breadcrumb data={str} /> */}
      <div className='BD_master_wrapper'>
        <Row gutter={40}>
          <Col span={6}>
            <div className='bd_model_left'>
              <h3>Reminders</h3>

              <Form form={form} name="control-hooks" layout="vertical" autoComplete="off"  >
                <Form.Item name="reminder_date" label="Date"
                  onKeyDown={handleKeyPress}
                  rules={[{ required: true, message: ' Date is required' },
                  ]}
                >
                  <DatePicker placeholder='dd/mm/yyyy'
                    type="date"
                    name='reminder_date'
                    value={sectorName?.reminder_date}
                    onChange={(e) => handleInputChange('reminder_date', e)}
                    disabledDate={(current) => current && current < dayjs().startOf('day')}



                  />
                </Form.Item>
                <Form.Item name="reminder_subject" label="Title"
                  onKeyDown={handleKeyPress}
                  rules={[{ required: true, message: 'Title is required' }]}>
                  <Input value={sectorName?.reminder_subject} type='text' placeholder='Enter here...'
                    onChange={(e) => handleInputChange("reminder_subject", e.target.value)} />
                </Form.Item>

                <Form.Item name="reminder_message" label="Purpose"

                  onKeyDown={handleKeyPress}
                  rules={[{ required: true, message: 'Purpose is required', }]}>
                  <Input value={sectorName?.reminder_message} type='text' placeholder='Enter here...'
                    onChange={(e) => handleInputChange('reminder_message', e.target.value)}
                  />
                </Form.Item>

                <Form.Item onKeyDown={handlenum}
                  name="tender_id"
                  label="Tender Id"

                  rules={[{ required: true, message: 'Tender id is required', }]}>
                  <Input value={sectorName?.tender_id} placeholder='Enter here...'
                    onChange={(e) => handleInputChange('tender_id', e.target.value)}


                  />
                </Form.Item>

                <div className='bd_model_button'>
                  <Button onClick={handleReset} key="back" className='BG_ghostButton'>
                    Reset
                  </Button>
                  <button key="submit" className='BG_mainButton' onClick={createHandler}>
                    Submit
                  </button>
                </div>

              </Form>
            </div>
          </Col>
          <Col span={18}>
            <DataTable
              title="Reminder"
              getreminder={getreminder}
              handleUpdate={updateHandler}
              handleDelete={deletehandler}
              columnLabels={columnLabels}
              dataSource={ReminderTableData}
              showActions={showActions} />
          </Col>
        </Row>
      </div>
    </>


  )
}

export default Reminder;
