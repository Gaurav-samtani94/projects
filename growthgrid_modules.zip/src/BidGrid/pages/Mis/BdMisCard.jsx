// @ts-nocheck
import React, { useCallback, useRef, useEffect, useState } from 'react';
import { Down, SaveOne, Add, UpOne, DownOne, SortOne } from '@icon-park/react';
import { DownloadOutlined, SearchOutlined } from '@ant-design/icons'
import ExportDatatable from 'BidGrid/components/dataTable/ExportDatatable'
import { Checkbox, Select, Collapse, Form, Menu, Dropdown } from 'antd'
import { useSelector, useDispatch } from 'react-redux';
import ExcelJS from 'exceljs';
import Search from 'antd/es/input/Search'
import { useDraggable } from "react-use-draggable-scroll";
import FilterImage from '../../assets/images/icons/filter 1.png';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import dayjs from 'dayjs';
import * as XLSX from 'xlsx';
import { toast } from 'react-toastify';
import GenerateChips from 'BidGrid/components/GenerateChips/GenerateChips';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import { misFilterActions } from 'Redux/actions/bidgrid/misFilterAction';
import Bd_basicFilter from 'BidGrid/components/Drawer/Bd_basicFilter';
import Bd_advanceFilter from 'BidGrid/components/Drawer/Bd_advanceFilter';
import { MisApi } from 'Services/bidgrid/tenderList/MIsApi';
import { bidAllUserAction, bidGenerateIDAction } from 'Redux/actions/common/DropdownAction';
import { DropdownValuesServices } from 'Services/common/dropdown/dropdownValues';
import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
import { RequestApi } from 'Services/bidgrid/tenderList/RequestApi';
import TenderDetailsCard from 'BidGrid/components/TendercardComponents/TenderDetailsCard';
import AddTemplateModal from 'BidGrid/components/Models/AddTemplateModal';
import FilterChipsTemplateDrawer from 'BidGrid/components/Drawer/FilterChipsTemplateDrawer';
import MoveConfirmationModal from 'BidGrid/components/MISModal/MoveConfirmationmodal';

const initialModalState = {
    bdBasicFilter: { visible: false, data: null },
    createTemplate: { visible: false, data: null },
    saveTemplate: { visible: false, data: null },
    bdAdvanceFilter: { visible: false, data: null },
    generateNum: { visible: false, data: null },
    keyClientAssign: { visible: false, data: null },
    consortiumCompAssign: { visible: false, data: null },
    bidManager: { visible: false, data: null }
}

const columnLabels = {
    gg_tenderID: { name: 'GG Tender ID', required: true, width: 400 },
    tender_name: { name: 'Tender Name', required: true, width: 400 },
    tender_emd_amnt_val: { name: 'Tender amount value', required: true, width: 400 },
    submission_start_date: { name: 'Start Date', required: true, width: 400 },
    submission_end_date: { name: 'End Date', required: true, width: 400 },
}
const initialSortingState = [
    { name: 'Tender Value', orderType: 'none', value: 'tender_amnt_val' },
    { name: 'Tender Emd Value', orderType: 'none', value: 'tender_emd_amnt_val' },
    { name: 'Deadline', orderType: 'none', value: 'submission_end_date' },
    { name: 'Published Date', orderType: 'none', value: 'published_date' },
]

const BdMisCard = (props) => {
    const { getScopeListData, checked, setChecked, selectedItems, setSelectedItems } = props
    const { misFilterValues, misFilterChips, isUpdate } = useSelector((state => state.misFilter))
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const ref = useRef();
    const { events } = useDraggable(ref);
    const dispatch = useDispatch();
    const [getMisTender, setMisTender] = useState([])
    const [updateFilterData, setUpdateFilterData] = useState(false)
    const [applyTemp, setApplyTemp] = useState(false);
    const [skeleton, setSkeleton] = useState(false);
    const [MisTenderSearch, setMisTenderSearch] = useState('');
    const [misFilter, setMisFilter] = useState('');
    const [userListData, setUserListData] = useState([])
    const [misSingleDropDownList, setMisSingleDropDownList] = useState([])
    const [misBulkDropDownList, setMisBulkDropDownList] = useState([])
    const [misTenderId, setMisTenderId] = useState()
    const [stateVal, setStateVal] = useState([])
    const [collapseActiveKeyTemp, setCollapseActiveKeyTemp] = useState();
    const [misStatusChange, setMisStatusChange] = useState()
    const [misActionData, setMisActionData] = useState([]);
    const [misSubmittedDropDownList, setMisSubmittedDropDownList] = useState([]);
    const [misTenderCount, setMisTenderCount] = useState()
    const [misRequestList, setMisRequestList] = useState([])
    const [misSubmittedBtnData, setMisSubmittedBtnData] = useState([])
    const [applyFilter, setApplyFilter] = useState()
    const [accdChipData, setAccdChipData] = useState([])
    const [misDropdownSpinner, setMisDropdownSpinner] = useState(false);
    const [modals, setModals] = useState(initialModalState);
    const [updateFilter, setUpdateFilter] = useState()
    const [confirmationModal, setConfirmationModal] = useState(false)
    const [onChangeScopeId, setOnChangeScopeId] = useState();
    const [sortData, setSortData] = useState()
    const [sort, setSort] = useState(initialSortingState)
    const [activeOrderColor, setActiveOrderColor] = useState()

    const defaultValues = 'Select'
    const getUserList = async () => {
        try {
            const response = await bidEmployeeList?.getUserList()
            if (response?.data?.status == 1) {
                setUserListData(response?.data?.data)
                dispatch(bidAllUserAction(response?.data?.data))
            }
        } catch (error) {
            console.log(error)
        }
    }

    const getGenerateIdList = async () => {
        try {
            const response = await MisApi?.getGenerateList()
            if (response?.data?.status == 1) {
                dispatch(bidGenerateIDAction(response?.data?.data))
            }
        } catch (error) {
            console.log(error)
        }
    }

    const getMisAllList = async () => {
        try {
            const response = await MisApi?.getMisAllInActionBtnList()
            if (response?.data?.status == 1) {
                setMisSubmittedBtnData(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const handleSubmitTender = async (val, itemId) => {
        let scopeName;
        if (misFilterValues?.cycle_id != 0) {
            scopeName = misSingleDropDownList?.find(item => item.id == val)?.cycle_name;

        }
        setMisDropdownSpinner(prevState => ({
            ...prevState,
            [itemId]: true
        }));
        const formData = new URLSearchParams();
        formData.append("tender_id", itemId);
        formData.append("cycle_id", Number(val));
        try {
            const response = await MisApi?.moveTenderToNextScope(formData)
            if (response?.data?.status === '1') {
                getMisAllTender()
                notifySuccess(`Tender moved into ${scopeName ? scopeName : 'next'} stage`)
                setMisDropdownSpinner(prevState => ({
                    ...prevState,
                    [itemId]: false
                }));
            }
        } catch (error) {
            console.log(error)
        }
    }

    const fetchRequestListForDrawer = async (val) => {
        const formData = new URLSearchParams();
        formData.append('tender_id', val)
        try {
            const response = await RequestApi.requestList(formData)
            if (response?.data?.status === "1") {

                const updatedArr = response?.data?.data?.map((item) => {
                    let items = item
                    if (items?.curr_status === "1") {
                        items['curr_status'] = 'Pending'
                    } else if (items?.curr_status === "2") {
                        items['curr_status'] = 'Approved'
                    }
                    else if (items?.curr_status === "3") {
                        items['curr_status'] = 'Cancelled'
                    }
                    else {
                        items['curr_status'] = 'Pending'
                    }
                    return items
                })
                setMisRequestList(updatedArr)
            } else {
                setMisRequestList([])
            }
        } catch (error) {

        }
    }
    const getMisSingleDropDownValues = async () => {
        const formData = new URLSearchParams();
        formData.append('cycle_id', misFilterValues?.cycle_id);
        let result = await MisApi.getTenderCycleNextList(formData);
        setMisSingleDropDownList(result?.data?.data);
        let tempArr = result?.data?.data.filter(item => item.order_sr <= 6);
        setMisBulkDropDownList(result?.data?.data);
    }

    const handleCheckAll = () => {
        if (getMisTender.length === selectedItems.length || selectedItems.length > getMisTender?.length) {
            setChecked(false)
            setSelectedItems([]);
        }
        else {
            const postIds = getMisTender.map((item) => {
                return item.id;
            })
            setChecked(true);
            setSelectedItems(postIds);
        }
    }

    const getActionListApi = async () => {
        try {
            const response = await tenderCycle.bdActionListTender()
            if (response?.data?.status === '1') {
                setMisActionData(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const getSubmittedList = async () => {
        try {
            const response = await MisApi.getMisSubmittedList()
            if (response?.data?.status === '1') {
                setMisSubmittedDropDownList(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const getStateDrpValue = async () => {
        try {
            if (misFilterValues?.country_id) {
                const PayloadData = new FormData()
                PayloadData.append('country_id', misFilterValues.country_id)
                const response = await DropdownValuesServices.getStateDataByCountryId(PayloadData)
                if (response?.data?.status === 1) {
                    setStateVal(response?.data?.data?.filter(val => val?.state_name !== 'NA'))

                } else {
                    setStateVal([])
                }
            } else {
                setStateVal([])
            }
        } catch {
            console.log("error")
            setStateVal([])
        }
    }

    const handleUpdateFilter = () => {
        setUpdateFilterData(true)
        setModals(prevModals => ({
            ...prevModals,
            saveTemplate: { visible: false, data: null },
        }));
        setModals(prevModals => ({
            ...prevModals,
            bdBasicFilter: { visible: true, data: null },
        }));
    }

    const handleAccordionChange = (key) => {
        setCollapseActiveKeyTemp(key[key.length - 1])
        handleShowChipInAcc(key[key.length - 1])
    };

    const showDrawerAdvance = () => {
        setModals(prevModals => ({
            ...prevModals,
            bdBasicFilter: { visible: false, data: null },
            bdAdvanceFilter: { visible: true, data: null }
        }));
    }

    const onAdvanceClose = () => {
        setModals(prevModals => ({
            ...prevModals,
            bdAdvanceFilter: { visible: false, data: null }
        }));
    };

    const showDrawer = () => {
        setUpdateFilterData(false)
        setModals(prevModals => ({
            ...prevModals,
            bdBasicFilter: { visible: true, data: null },
            bdAdvanceFilter: { visible: false, data: null }
        }));
        setMisFilter('MIS')
    };

    const showChipDrawer = () => {
        setCollapseActiveKeyTemp()
        setModals(prevModals => ({
            ...prevModals,
            saveTemplate: { visible: true, data: null },
        }));
    }

    const handleShowChipInAcc = async (val) => {
        const formData = new URLSearchParams();
        formData.append("template_type", '2');
        formData.append("template_name", val);
        try {
            const response = await tenderCycle.bdShowChipstemp(formData)
            if (response?.data?.status === '1') {
                let resData = response?.data?.data
                let newArr = []
                resData?.map((obj) => {
                    const objVal = {
                        key: obj["filter_field_name"],
                        value: obj.filter_field_name === "from_date" || obj?.filter_field_name === "to_date" ? obj?.["filter_field_value"] : obj?.["filter_field_value"]
                    }
                    newArr.push(objVal)
                })
                convertArrToObj(response?.data?.data)
                setAccdChipData(newArr)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const convertArrToObj = (val) => {
        let outputObject = {};
        val?.forEach(item => {
            outputObject[item.filter_field_name] = item.filter_field_value;
        });
        setApplyFilter((old) => ({
            ...misFilterValues,
            ...outputObject,
        })
        )
        setUpdateFilter(outputObject)

    }

    const handleRadioChange = (e, key) => {
        setCollapseActiveKeyTemp(key)
        handleShowChipInAcc(key)
    };

    const handleFilterChange = (e) => {
        setMisTenderSearch(e.target.value)
        if (e.key === 'Enter') {
            e.preventDefault();
            handleSearchFun()
        }
    };
    const handleSearchFun = (e) => {
        let obj = {
            ...misFilterValues,
            tender_keyword: MisTenderSearch
        }
        MisTenderSearch && dispatch(misFilterActions.misFilterUpdateAllKeys(obj));
    }

    const handleReset = () => {
        const data = misFilterChips?.filter(item =>
            item?.value !== ''
            && item?.key !== 'limit'
            && item?.key !== 'page_number'
            && item?.key !== 'cycle_id'
            && item?.key !== 'orderSerial'
        )
        const isValue = data?.some((item) => item?.value != '');
        setMisTenderSearch('');
        isValue && dispatch(misFilterActions.misFilterResetKeys())

    }
    const handleMoveTenderToAnotherScope = async (itemID, name) => {
        const formData = new URLSearchParams();
        formData.append('tender_id', itemID);
        try {
            const response = await tenderCycle.getBdMoveTender(formData)
            if (response?.data?.status === "1") {
                getMisAllTender()
                const indexToRemove = selectedItems.indexOf(itemID);
                if (indexToRemove !== -1) {
                    selectedItems.splice(indexToRemove, 1);
                }
                notifySuccess('Tender  moved into next stage')
            }
            else {
                notify("Error");
            }
        } catch (error) {
            console.log(error)
        }

    }

    const stripHtmlTags = (htmlContent) => {
        var doc = new DOMParser().parseFromString(htmlContent, 'text/html');
        return doc.body.textContent || "";
    };

    const formattedData = getMisTender?.map((item, index) => {
        let assignDate = item?.assign_tender?.find(item => item?.bd_role_id == 2)?.created_at;
        assignDate = dayjs(assignDate).subtract(dayjs(assignDate).utcOffset(), 'minute').format("DD MMM YYYY");

        let consortiumCompName = item?.bg_tenders_lead?.main_company?.company_name ? item?.bg_tenders_lead?.main_company?.company_name : '';
        let jvs = item?.bg_tenders_jvs.length > 0 && item?.bg_tenders_jvs?.map(item => item?.main_company?.company_name).toString();
        jvs = jvs ? jvs : '';

        let associatives = item?.bg_tenders_associatives.length > 0 && item?.bg_tenders_associatives?.map(item => item?.main_company?.company_name).toString();
        associatives = associatives ? associatives : '';

        return {
            'Sr No.': (index + 1).toString(),
            'Date Of Submission': dayjs(item.submission_end_date).subtract(dayjs(item.submission_end_date).utcOffset(), 'minute').format("DD MMM YYYY"),
            'Tender Id': item?.bg_assign_tndr_generated_id?.generated_tender_id ? item?.bg_assign_tndr_generated_id?.generated_tender_id : '-',
            'Tender Details': stripHtmlTags(item?.tender_name),
            'National/International': item?.national_intern == 1 ? "National" : "International",
            'EOI/Proposal': item?.bg_assign_tndr_generated_id?.bg_mstr_tndr_generated_type?.generated_type ? item?.bg_assign_tndr_generated_id?.bg_mstr_tndr_generated_type?.generated_type : '-',
            'Funding Agency': item?.funding_agency ? item?.funding_agency : '-',
            'Country': item?.bg_mstr_country?.country_name ? item?.bg_mstr_country?.country_name : '-',
            'State': item?.bg_mstr_state?.state_name ? item?.bg_mstr_state?.state_name : '-',
            'Client': item?.bg_mstr_client?.client_name ? item?.bg_mstr_client?.client_name : '-',
            'Client Address': item?.client_cont_address ? item?.client_cont_address : '-',
            'Client Contact Person/Email': item?.client_cont_person ? item?.client_cont_person : '-',
            'Assign Date': assignDate ? assignDate : '-',
            'Proposal Manager': item?.assign_tender[1]?.user?.userfullname ? item?.assign_tender[1]?.user?.userfullname : '-',
            'Date Of Prebid': item?.pre_bid_meeting_date ? item?.pre_bid_meeting_date : '-',
            'Prebid Attended by': item?.pre_bid_attend ? item?.pre_bid_attend : '-',
            'Consortium Details': consortiumCompName + (consortiumCompName && '-') + jvs + '-' + associatives,
            'Submitted/Dropped': item?.bg_tenders_status_manage?.bg_mstr_tndr_status?.status_name,
            'Proposal/EOI Follow up by': item?.assign_tender[0]?.user?.userfullname,
            'Comments': item?.tender_comment?.comment_txt ? item?.tender_comment?.comment_txt : '-',
        };
    });

    const downloadExcel = async () => {
        if (getMisTender?.length > 0) {
            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet('Sheet1');

            // Add headers
            const headers = [
                'Sr No.', 'Date Of Submission', 'Tender Id', 'Tender Details', 'National/International', 'EOI/Proposal',
                'Funding Agency', 'Country', 'State', 'Client', 'Client Address', 'Client Contact Person/Email',
                'Assign Date', 'Proposal Manager', 'Date Of Prebid', 'Prebid Attended by', 'Consortium Details',
                'Submitted/Dropped', 'Proposal/EOI Follow up by', 'Comments'
            ];
            worksheet.addRow(headers);

            // Style headers
            worksheet.getRow(1).eachCell((cell) => {
                cell.font = { bold: true, size: 11, };
                // cell.fill = {
                //     type: 'pattern',
                //     pattern: 'solid',
                //     fgColor: { argb: 'FF000000' }
                // };
                cell.alignment = { horizontal: 'center', vertical: 'middle' };
                cell.border = {
                    top: { style: 'thin' },
                    left: { style: 'thin' },
                    bottom: { style: 'thin' },
                    right: { style: 'thin' }
                };
            });

            // Add data rows
            formattedData.forEach((data) => {
                worksheet.addRow(Object.values(data));
            });

            // Set column widths
            const colWidths = [10, 20, 20, 40, 25, 15, 20, 15, 15, 30, 40, 40, 20, 25, 30, 20, 30, 20, 25, 30];
            colWidths.forEach((width, index) => {
                worksheet.getColumn(index + 1).width = width;
            });

            // Set row heights
            worksheet.getRow(1).height = 40; // Header row height
            worksheet.eachRow((row, rowNumber) => {
                if (rowNumber !== 1) {
                    row.height = 30; // Data rows height
                }
            });

            const buffer = await workbook.xlsx.writeBuffer();
            const dataBlob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

            const downloadLink = document.createElement('a');
            const url = URL.createObjectURL(dataBlob);
            downloadLink.href = url;
            downloadLink.download = misFilterValues?.orderSerial == '8' ? "Submitted" : `${getMisTender[0]?.bg_tenders_status_manage?.bg_mstr_tndr_status?.status_name}`;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }
    };

    const showScopeName = (scope_id) => {
        return getScopeListData?.find(item => item.id == scope_id.toString())?.cycle_name;
    }

    const handleSubmitMultipleTender = async (e, selectedItems) => {
        let scopeName = misBulkDropDownList?.find(item => item.id == e)?.cycle_name;
        const formData = new URLSearchParams();
        formData.append('tender_id', selectedItems);
        formData.append('cycle_id', e);
        try {
            let result = await MisApi.moveMultipleTender(formData);
            if (result?.data?.status === '1') {
                getMisAllTender()
                setSelectedItems([]);
                setChecked(false)
                setConfirmationModal(false)
                setMisStatusChange(defaultValues)
                notifySuccess(`Tender moved into ${scopeName ? scopeName : 'next'} stage`)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const onChangeStatus = (e) => {
        setOnChangeScopeId(e)
        setConfirmationModal(true)
    }

    const getMisAllTender = async () => {
        if (!misFilterValues?.cycle_id) {
            return
        } else {
            setSkeleton(true)
            const formData = new URLSearchParams();
            misFilterValues?.orderSerial != 8 && formData.append('cycle_id', misFilterValues?.cycle_id);
            formData.append('sector_id', misFilterValues?.sector_id ? misFilterValues?.sector_id : "");
            formData.append("tender_keyword", misFilterValues?.tender_keyword ? misFilterValues?.tender_keyword : "")
            formData.append("country_id", misFilterValues?.country_id ? misFilterValues?.country_id : "")
            formData.append("funding_id", misFilterValues?.funding_id)
            formData.append("from_date", misFilterValues?.from_date ? misFilterValues?.from_date : "")
            formData.append("to_date", misFilterValues?.to_date ? misFilterValues?.to_date : "")
            formData.append("published_date", misFilterValues?.published_date ? misFilterValues?.published_date : "")
            formData.append("close_exp_date", misFilterValues?.close_exp_date ? misFilterValues?.close_exp_date : "")
            formData.append("estm_value", misFilterValues?.estm_value ? misFilterValues?.estm_value : "")
            formData.append("estm_value_emd", misFilterValues?.estm_value_emd ? misFilterValues?.estm_value_emd : "")
            formData.append('amnt_custrange_operator', misFilterValues?.amnt_custrange_operator ? misFilterValues?.amnt_custrange_operator : "")
            formData.append('amnt_custrange_amount', misFilterValues?.amnt_custrange_amount ? misFilterValues?.amnt_custrange_amount : "")
            formData.append('custrange_denomination', misFilterValues?.custrange_denomination ? misFilterValues?.custrange_denomination : "")
            formData.append('amnt_custrange_operator_emd', misFilterValues?.amnt_custrange_operator_emd ? misFilterValues?.amnt_custrange_operator_emd : "")
            formData.append('amnt_custrange_amount_emd', misFilterValues?.amnt_custrange_amount_emd ? misFilterValues?.amnt_custrange_amount_emd : "")
            formData.append('custrange_denomination_emd', misFilterValues?.custrange_denomination_emd ? misFilterValues?.custrange_denomination_emd : "")
            formData.append("state_id", misFilterValues?.state_id ? misFilterValues?.state_id : "")
            formData.append("client_id", misFilterValues?.client_id ? misFilterValues?.client_id : "")
            formData.append("currency_id", misFilterValues?.currency_id ? misFilterValues?.currency_id : "")
            formData.append("pubdate_cust_from_date", misFilterValues?.pubdate_cust_from_date ? misFilterValues?.pubdate_cust_from_date : "")
            formData.append("pubdate_cust_to_date", misFilterValues?.pubdate_cust_to_date ? misFilterValues?.pubdate_cust_to_date : "")
            formData.append("expdate_cust_from_date", misFilterValues?.expdate_cust_from_date ? misFilterValues?.expdate_cust_from_date : "")
            formData.append("expdate_cust_to_date", misFilterValues?.expdate_cust_to_date ? misFilterValues?.expdate_cust_to_date : "")
            formData.append("tender_result_id", misFilterValues?.tender_result_id ? misFilterValues?.tender_result_id : "")
            formData.append("tender_status", misFilterValues?.tender_status ? misFilterValues?.tender_status : "")
            formData.append("generated_type", misFilterValues?.generated_type ? misFilterValues?.generated_type : "")
            formData.append("key_manager_filter", misFilterValues?.key_manager_filter ? misFilterValues?.key_manager_filter : "")
            formData.append("bid_manager_filter", misFilterValues?.bid_manager_filter ? misFilterValues?.bid_manager_filter : "")
            // formData.append("tender_activity_status", misFilterValues?.tender_activity_status ? misFilterValues?.tender_activity_status : "")
            formData.append("located", misFilterValues?.located ? misFilterValues?.located : "")
            formData.append("filter_fin_year", misFilterValues?.filter_fin_year ? misFilterValues?.filter_fin_year : "")
            formData.append("sort_key", misFilterValues?.sort_key ? misFilterValues?.sort_key : "")
            formData.append("sort_val", misFilterValues?.sort_val ? misFilterValues?.sort_val : "")
            formData.append('limit', misFilterValues?.limit ? parseInt(misFilterValues?.limit) : 25)
            formData.append('page_number', misFilterValues?.page_number ? misFilterValues?.page_number : "1")
            try {
                let result = await MisApi.getMisTenderList(formData);
                if (checked) {
                    const postIds = result?.data?.data?.map((item) => {
                        return item.id;
                    })
                    setChecked(true);
                    let filteredArray1 = postIds.filter(element => !selectedItems.includes(element));
                    setSelectedItems([...selectedItems, ...filteredArray1]);
                }
                dispatch(misFilterActions.misFilterResetisUpdate())
                setSkeleton(false)
                setMisTender(result?.data?.data)
                setMisTenderCount(result?.data)

            } catch (error) {
                setSkeleton(false)
                setMisTender([])
                console.log(error)
            }
        }
    }

    const accGenerateChips = useCallback((showCross) => {
        if (accdChipData !== null && accdChipData !== []) {
            return (
                <GenerateChips
                    filterData={accdChipData}
                    stateVal={stateVal}
                    getScopeList={getScopeListData}
                    setTenderSearch={setMisTenderSearch}
                    showCross={showCross}
                />
            )
        }
    }, [accdChipData]);

    const MisGenerateChips = useCallback((val) => {
        return (

            <GenerateChips
                filterData={misFilterChips}
                stateVal={stateVal}
                setMisTenderSearch={setMisTenderSearch}
                showCross={true}
                commonFilter={"MIS"}
                val={val}
            />
        )

    }, [misFilterChips]);

    useEffect(() => {
        getActionListApi()
        getSubmittedList()
        if (misFilterValues?.orderSerial == 8) {
            getMisAllList()
        }
    }, [misFilterValues?.cycle_id])

    useEffect(() => {
        getStateDrpValue()
    }, [misFilterValues?.country_id])

    useEffect(() => {
        getUserList()
        getGenerateIdList()
    }, [])

    useEffect(() => {
        if (isUpdate) {
            getMisAllTender()
            getMisSingleDropDownValues()
        }

    }, [misFilterValues, isUpdate])

    useEffect(() => {
        const storedSort = JSON.parse(localStorage.getItem('sortByMis'));
        if (storedSort) {
            setSort(storedSort);
        }
    }, [misFilterValues])

    const handleSort = (val, data) => {
        // if (data) {
        setSortData(val)
        let newArray = sort.map(item => {
            return { ...item, orderType: 'none' };
        });
        let orderValue = '';
        if (val?.orderType === 'none') {
            newArray = newArray.map(item => {
                if (item.value === val.value) {
                    return { ...item, orderType: 'asc' };
                }
                return item;
            });
            orderValue = 'asc'
            setActiveOrderColor(orderValue)
        } else if (val?.orderType === 'asc') {
            setActiveOrderColor("ASC")
            newArray = newArray.map(item => {
                if (item.value === val.value) {
                    return !data && val != undefined ? { ...item, orderType: 'asc' } : { ...item, orderType: 'desc' };
                }
                return item;
            });
            orderValue = !data && val != undefined ? 'asc' : 'desc'
            setActiveOrderColor(orderValue)
        } else if (val?.orderType === 'desc') {
            setActiveOrderColor("DESC")
            newArray = newArray.map(item => {
                if (item.value === val.value) {
                    return !data && val != undefined ? { ...item, orderType: 'desc' } : { ...item, orderType: 'asc' };
                }
                return item;
            })
            orderValue = !data && val != undefined ? 'desc' : 'asc'
            setActiveOrderColor(orderValue)
        } else {
            newArray = newArray
            orderValue = ''
        }
        const obj = {
            ...misFilterValues,
            sort_key: val?.value == undefined ? "" : val?.value,
            sort_val: orderValue
        }
        localStorage.setItem('sortByMis', JSON.stringify(newArray));
        dispatch(misFilterActions.misFilterUpdateAllKeys(obj))

    }

    const menu = (
        <Menu>
            {sort?.map(item => (
                <Menu.Item key={item.value} onClick={() => handleSort(item, true)}>
                    <div className="sort_item">
                        {item.name}
                        <div className="icon_drop">
                            <UpOne theme="filled" size="22" fill={activeOrderColor != undefined && activeOrderColor == "desc" && sortData?.value == item?.value ? "#000" : "#d0d0d0"} strokeWidth={3} strokeLinecap="butt" />
                            <DownOne theme="filled" size="22" fill={activeOrderColor != undefined && activeOrderColor == "asc" && sortData?.value == item?.value ? "#000" : "#d0d0d0"} strokeWidth={3} strokeLinecap="butt" />
                        </div>
                    </div>
                </Menu.Item>
            ))}
        </Menu>
    );

    return (
        <>
            <div className="bd_tenderWapper">
                <div className="fixed_wrapper">
                    <div className="bd_newTender_heading">
                        <div className="headding-title">
                            {!skeleton ? (<h2>{showScopeName(misFilterValues?.cycle_id)} Tenders</h2>) : <Skeleton width={200} height={30} />}
                        </div>

                        <div className='bd_seacrh_box'>
                            <div className="table_wrap mt-0">
                                <Search
                                    placeholder="Search"
                                    allowClear
                                    value={MisTenderSearch}
                                    onChange={handleFilterChange}
                                    onKeyDown={handleFilterChange}

                                />
                                <div className="search_icon" onClick={() => handleSearchFun()}><button><SearchOutlined /></button>
                                </div>
                            </div>
                            <button className="BG_ghostButton" onClick={() => handleReset()}>Reset</button>
                            <button className="BG_mainButton" onClick={showDrawer}><img src={FilterImage} width={20} alt='' />Filter</button>
                        </div>

                    </div>

                    <div className="bd_tenderFilter">
                        <div className="card">
                            <div className="bd_cards_select">
                                <Checkbox
                                    checked={checked} disabled={getMisTender?.length === 0 || getMisTender?.length === undefined ? true : false} onChange={handleCheckAll} style={{ display: misFilterValues?.orderSerial == 8 || misFilterValues?.orderSerial > 9 ? "none" : "flex" }}
                                >
                                    Select all
                                </Checkbox>

                                <div className='navbar_middle'
                                    style={{ display: selectedItems.length > 0 ? 'block' : 'none' }}
                                >
                                    <div className='bd_tender_important'>
                                        <div>
                                            <span style={{ padding: "20" }}>{`${selectedItems?.length} ${selectedItems?.length > 1 ? 'Tenders' : 'Tender'} Selected`}</span>
                                        </div>
                                        <div className="bd_active_btn_sec" >
                                            <div className={`status_select ${misStatusChange}`}>
                                                {/* {!dropdownSpinnerForBulkPopUP ?  */}
                                                <Select
                                                    defaultValue={defaultValues}
                                                    value={misStatusChange}
                                                    onChange={onChangeStatus}
                                                    suffixIcon={<Down theme="outline" size="18" fill="#78889b" />}

                                                    options={misBulkDropDownList?.map((item) => ({
                                                        value: item.id,
                                                        label: item.cycle_name
                                                    }))}
                                                />
                                            </div>
                                        </div>
                                        {/* <div className='delete_select_bd' onClick={() => handleDeleteBulkTender(selectedItems)} >
                                        {!bulkDeleteSpinner ?
                                            <button> <DeleteOutlineIcon width={18} />Delete</button>
                                            : <img src={spinGif} width={30} />}
                                    </div> */}
                                    </div>
                                </div>

                            </div>
                            <div className="bd_new_button">
                                <button className='BG_ghostButton excelExport' onClick={downloadExcel}>
                                    <DownloadOutlined /> Excel
                                </button>
                                <div className="showPrPage">
                                    <Form.Item className="export">
                                        <ExportDatatable
                                            dataSource={getMisTender}
                                            columnLabels={columnLabels}
                                        />
                                    </Form.Item>
                                </div>
                                <Dropdown
                                    className="sorting_wrap"
                                    // menu={{
                                    //     items,
                                    // }}
                                    overlay={menu}
                                    dropdownRender={(menu) => (

                                        <div className="sorting_dropdown_wrap">
                                            {React.cloneElement(menu)}
                                        </div>
                                    )}
                                    placement="bottomRight"
                                >
                                    <a onClick={(e) => e.preventDefault()}>
                                        <span>
                                            <SortOne theme="outline" size="22" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                            SORT BY
                                        </span>
                                        <Down theme="outline" size="21" fill="#9b9b9b" strokeWidth={3}
                                            strokeLinecap="butt" />
                                    </a>
                                </Dropdown>
                                <button className="saveTempletes" onClick={showChipDrawer}>
                                    <div className="iconFlex">
                                        <SaveOne theme="outline" size="20" fill="#3bba61" strokeWidth={3} strokeLinecap="butt" />
                                    </div>
                                    Saved Templates
                                </button>
                            </div>
                        </div>

                    </div>
                </div>
                <div className='card mt-4 add_template_card' style={{
                    display: misFilterChips && misFilterChips.some(item =>
                        item.value !== '' && !['page_number', 'cycle_id', 'limit', 'orderSerial'].includes(item.key)
                    ) ? "block" : "none"
                }} >
                    <div className="bd_cards_tender" {...events} ref={ref}>
                        {MisGenerateChips()}
                    </div>
                    <button className="BG_addTemplate"
                        onClick={() => setModals(prevModals => ({
                            ...prevModals,
                            createTemplate: { visible: true, data: null },
                        }))}
                        style={{ display: applyTemp === true ? "none" : "" }} >
                        <Add theme="outline" size="22" fill="#684fd8" strokeWidth={3} strokeLinecap="butt" />Add Template
                    </button>
                </div>

                <TenderDetailsCard
                    skeleton={skeleton}
                    setChecked={setChecked}
                    getTenders={getMisTender}
                    setSelectedItems={setSelectedItems}
                    selectedItems={selectedItems}
                    setTenders={setMisTender}
                    singleDropDownList={misSingleDropDownList}
                    handleSubmitTender={handleSubmitTender}
                    handleMoveTenderToAnotherScope={handleMoveTenderToAnotherScope}
                    actionData={misActionData}
                    getActionInAll={misSubmittedBtnData}
                    scopeAllData={misSubmittedDropDownList}
                    requestList={misRequestList}
                    fetchRequestListForDrawer={fetchRequestListForDrawer}
                    userListData={userListData}
                    getActionListApi={getActionListApi}
                    getAllTenders={getMisAllTender}
                    dropdownSpinner={misDropdownSpinner}
                    tenderCount={misTenderCount}
                    commonFilter={'MIS'}
                    page_Num={misFilterValues?.page_number}
                    limit={misFilterValues?.limit}
                    cycleId={misFilterValues?.cycle_id}
                />

                <FilterChipsTemplateDrawer
                    open={modals?.saveTemplate?.visible}
                    close={() => {
                        setModals(prevModals => ({
                            ...prevModals,
                            saveTemplate: { visible: false, data: null },
                        }))
                    }}
                    setModals={setModals}
                    applyFilter={applyFilter}
                    setApplyTemp={setApplyTemp}
                    setCollapseActiveKeyTemp={setCollapseActiveKeyTemp}
                    collapseActiveKeyTemp={collapseActiveKeyTemp}
                    handleUpdateFilter={handleUpdateFilter}
                    handleAccordionChange={handleAccordionChange}
                    handleRadioChange={handleRadioChange}
                    accGenerateChips={accGenerateChips}
                    tempType={"2"}
                    commonFilter={"MIS"}

                />

                < Bd_basicFilter
                    open={modals?.bdBasicFilter?.visible}
                    close={() =>
                        setModals(prevModals => ({
                            ...prevModals,
                            bdBasicFilter: { visible: false, data: null },
                        }))
                    }
                    showDrawerAdvance={showDrawerAdvance}
                    updateFilter={updateFilter}
                    setUpdateFilter={setUpdateFilter}
                    updateFilterData={updateFilterData}
                    collapseActiveKeyTemp={collapseActiveKeyTemp}
                    setCollapseActiveKeyTemp={setCollapseActiveKeyTemp}
                    getScopeList={getScopeListData}
                    setApplyTemp={setApplyTemp}
                    commonFilter={misFilter}
                    filterValData={misFilterValues}
                    tempType={"2"}
                />

                <Bd_advanceFilter
                    showDrawer={showDrawer}
                    advanceOpen={modals?.bdAdvanceFilter?.visible}
                    onAdvanceClose={onAdvanceClose}
                    collapseActiveKeyTemp={collapseActiveKeyTemp}
                    updateFilterData={updateFilterData}
                    updateFilter={updateFilter}
                    setOpen={handleUpdateFilter}
                    commonFilter={misFilter}
                    filterValData={misFilterValues}
                    tempType={"2"}
                />

                <AddTemplateModal
                    close={() => setModals(prevModals => ({
                        ...prevModals,
                        createTemplate: { visible: false, data: null },
                    }))}
                    open={modals?.createTemplate?.visible}
                    generateChips={MisGenerateChips}
                    tempType={"2"}
                    filterValChipsData={misFilterChips}
                />

                <MoveConfirmationModal
                    confirmationModal={confirmationModal}
                    handleSubmitMultipleTender={handleSubmitMultipleTender}
                    move={"MULTIPLE"}
                    selectedItems={selectedItems}
                    onChangeScopeId={onChangeScopeId}
                    setConfirmationModal={setConfirmationModal}
                    multiDropDownList={misSingleDropDownList}
                />
            </div>
        </>
    )
}

export default BdMisCard