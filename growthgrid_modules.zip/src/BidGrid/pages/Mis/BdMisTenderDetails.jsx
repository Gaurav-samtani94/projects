// @ts-nocheck
import React, { useState, useEffect } from 'react'
import BdMisInfo from './BdMisInfo'
import { Select } from 'antd';
import { Down } from '@icon-park/react';
import BdMisComments from './BdMisComments'
import { Pagination } from 'antd';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import BdMisTenderAction from './BdMisTenderActions'
import EmptyBox from '../../../assests/img/empty-box.png';
import { MisApi } from 'Services/bidgrid/tenderList/MIsApi';
import { misFilterActions } from 'Redux/actions/bidgrid/misFilterAction';
import TenderDetailComment from 'BidGrid/components/TendercardComponents/TenderDetailComment';
import TenderDetailAction from 'BidGrid/components/TendercardComponents/TenderDetailAction';
import TenderInfo from 'BidGrid/components/TendercardComponents/TenderInfo';

const BdMisTenderDetails = (props) => {
    const dispatch = useDispatch();

    const { getMisTender, setCycleId, setMisTender, setGenTenderId, skeleton, misSingleDropDownList, handleMoveTenderToAnotherScope, setPaginatedDataList, setChecked, selectedItems, setSelectedItems, misAllTendersLength, setMisTenderId, setMisCycleId, handleSubmitTender, misActionData, misSubmittedDropDownList, current, setCurrent, pageSize, setPageSize, misTenderCount, requestList, actionData, getActionListApi, userListData, fetchRequestListForDrawer, misSubmittedBtnData, misDropdownSpinner, commonFilter } = props
    const { misFilterValues } = useSelector((state => state.misFilter))

    const [misActionsList, setMisActionsList] = useState([]);
    const startIndex = (current - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    // const paginatedData = getMisTender
    const { Option } = Select;

    useEffect(() => {
        setPaginatedDataList(getMisTender);
    }, [getMisTender, current, pageSize])

    const getMisActionsBtnLIst = async () => {
        const formData = new URLSearchParams();
        formData.append('scope_id', Number(misFilterValues.cycle_id));
        let result = await MisApi?.getMisInActionBtnList(formData)
        console.log(result, "result?.data?.data")
        // setChecked(false)
        // setSelectedItems([])
        setMisActionsList(result?.data?.data)
    }

    useEffect(() => {
        getMisActionsBtnLIst();
    }, [misFilterValues.cycle_id])

    const handlePageChange = (page, pageSize) => {
        setCurrent(page);
        setPageSize(pageSize)
        const obj = {
            limit: pageSize,
            page_number: page,
        }
        dispatch(misFilterActions?.misFilterUpdateIndividualKeys(obj))

    };

    useEffect(() => {
        setCurrent(misFilterValues?.page_number)
        setPageSize(misFilterValues?.limit)
        const obj = {
            limit: misFilterValues?.limit,
            page_number: misFilterValues?.page_number,
        }
        dispatch(misFilterActions?.misFilterUpdateIndividualKeys(obj))
    }, [])

    const handlePageSizeChange = (value) => {
        setPageSize(value);
        const obj = {
            limit: value,
            page_number: current,
        }
        dispatch(misFilterActions?.misFilterUpdateIndividualKeys(obj))
    }

    return (
        <>
            {getMisTender && getMisTender?.length !== 0 ?

                <>

                    {
                        getMisTender?.map((item, index) => {
                            return (
                                <>
                                    <div className='bd_tenderCard'>
                                        <div className='card'>
                                            {/* <BdMisInfo
                                                item={item}
                                                skeleton={skeleton}
                                                misSingleDropDownList={misSingleDropDownList}
                                                setMisTenderId={setMisTenderId}
                                                setMisCycleId={setMisCycleId}
                                                handleSubmitTender={handleSubmitTender}
                                                setChecked={setChecked}
                                                setSelectedItems={setSelectedItems}
                                                selectedItems={selectedItems}
                                                misAllTendersLength={misAllTendersLength}
                                                misSubmittedDropDownList={misSubmittedDropDownList}
                                            /> */}
                                            <TenderInfo
                                                setChecked={setChecked}
                                                item={item}
                                                index={index}
                                                skeleton={skeleton}
                                                setSelectedItems={setSelectedItems}
                                                selectedItems={selectedItems}
                                                getTenders={misAllTendersLength}
                                                singleDropDownList={misSingleDropDownList}
                                                setGenTenderId={setMisTenderId}
                                                handleSubmitTender={handleSubmitTender}
                                                scopeAllData={misSubmittedDropDownList}
                                                setCycleId={setMisCycleId}
                                                dropdownSpinner={misDropdownSpinner}
                                                commonFilter={commonFilter}
                                            />
                                            {/* <BdMisComments item={item} skeleton={skeleton} /> */}
                                            <TenderDetailComment
                                                item={item}
                                                requestList={requestList}
                                                fetchRequestListForDrawer={fetchRequestListForDrawer}
                                                actionData={actionData}
                                                userListData={userListData}
                                                getActionListApi={getActionListApi}
                                                skeleton={skeleton}
                                            />
                                            {/* <BdMisTenderAction
                                                item={item}
                                                misActionsList={misActionsList}
                                                misActionData={misActionData}
                                            /> */}
                                            <TenderDetailAction
                                                item={item}
                                                getActionsList={misActionsList}
                                                getTenders={getMisTender}
                                                setTenders={setMisTender}
                                                // setGenerateNumOpen={setGenerateNumOpen}
                                                setGenTenderId={setGenTenderId}
                                                handleMoveTenderToAnotherScope={handleMoveTenderToAnotherScope}
                                                actionData={misActionData}
                                                getActionInAll={misSubmittedBtnData}
                                                // setRoleOpen={setRoleOpen}
                                                // setBidRoleOpen={setBidRoleOpen}
                                                getActionListApi={getActionListApi}
                                                skeleton={skeleton}
                                                setCycleId={setCycleId}
                                            // setInActionPopup={setInActionPopup}

                                            />
                                        </div>
                                    </div>

                                </>

                            )
                        })

                    }
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 20 }}>
                        <Pagination
                            current={current}
                            pageSize={pageSize}
                            total={misTenderCount?.totalItems}
                            // total={getMisTender?.length}
                            onChange={handlePageChange}
                        />
                        <div>
                            <span>Showing</span>
                            <Select
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                defaultValue={pageSize}
                                style={{ width: 70 }}
                                onChange={handlePageSizeChange}
                            >
                                <Option value={5}>5</Option>
                                <Option value={10}>10</Option>
                                <Option value={20}>20</Option>
                                <Option value={30}>30</Option>
                                <Option value={40}>40</Option>
                            </Select>
                        </div>

                    </div>

                </>
                :
                <div className="spinerWrap">
                    <div className="data_foundDiv">
                        <img src={EmptyBox} width={100} />
                        <div style={{ textAlign: "center", fontSize: 16 }}>No Record Found</div>
                    </div>
                </div>
            }
        </>

    )
}

export default BdMisTenderDetails