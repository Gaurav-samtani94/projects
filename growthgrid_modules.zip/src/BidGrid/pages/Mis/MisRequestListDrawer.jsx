import { Drawer } from 'antd'
import React from 'react'
import skipBack from '../../assets/images/skip-back.png';
const MisRequestListDrawer = (props) => {
  return (
    <Drawer title="Request List" className="bd_Drawer_request" closeIcon={<img src={skipBack} alt='' />} onClose={props?.onCloseDrawer} 
// @ts-ignore
    open={props?.open}
     width={650} extra={
      <>
       <button className='BG_mainButton' onClick={props?.showGenrateRequestDrawer}>Add Request</button>
      </>
   }>

       {/* {showAllRequestList()} */}
   </Drawer>
  )
}

export default MisRequestListDrawer