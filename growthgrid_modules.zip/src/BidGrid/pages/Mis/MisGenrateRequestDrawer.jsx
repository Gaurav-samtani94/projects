
import React, { useState } from 'react'
import { Input, Form, Row, Col, Upload, Drawer, Select, Card, Button, Space } from 'antd';
import skipBack from '../../assets/images/skip-back.png'
import { Down } from '@icon-park/react';
import ReactQuill from 'react-quill';
import { DeleteOutlined } from '@ant-design/icons';

const initialState = {
    subject: '',
    curr_status: null,
    req_from_userid: '',
    req_to_userid: null,
    comment_txt: '',
    request_file: [],

}

const MisGenrateRequest = (props) => {
    const [form] = Form.useForm();
    const [isCleared, setIsCleared] = useState(true);
    const [errormsg, setErrorMsg] = useState(false);
    const [requestData, setRequestData] = useState(initialState);
    const [editor, setEditor] = useState('')
    var modules = {
        toolbar: [
            [{ size: ["small", false, "large", "huge"] }],
            ["bold", "italic", "underline", "strike", "blockquote"],
            [{ list: "ordered" }, { list: "bullet" }],
            ["link", "image"],
            [
                { list: "ordered" },
                { list: "bullet" },
                { indent: "-1" },
                { indent: "+1" },
                { align: [] }
            ],
            [{ "color": ["#000000", "#e60000", "#ff9900", "#ffff00", "#008a00", "#0066cc", "#9933ff", "#ffffff", "#facccc", "#ffebcc", "#ffffcc", "#cce8cc", "#cce0f5", "#ebd6ff", "#bbbbbb", "#f06666", "#ffc266", "#ffff66", "#66b966", "#66a3e0", "#c285ff", "#888888", "#a10000", "#b26b00", "#b2b200", "#006100", "#0047b2", "#6b24b2", "#444444", "#5c0000", "#663d00", "#666600", "#003700", "#002966", "#3d1466", 'custom-color'] }],
        ]
    };

    var formats = [
        "header", "height", "bold", "italic",
        "underline", "strike", "blockquote",
        "list", "color", "bullet", "indent",
        "link", "image", "align", "size",
    ];

    // const handleEditorChange = (content, delta, source, editor) => {
    //     setEditor(content);
    //     setIsCleared(content?.trim()?.replace(/<[^>]*>/g, '') === '');
    //     setErrorMsg(false)

    // };
    const handleKeyDown = (event) => {
        if (isCleared && event.key === ' ') {
            event.preventDefault();
        }
    };
    const handleChange = (name, value) => {
        setRequestData({ ...requestData, [name]: value });

    };
    const handleReset = () => {
        setRequestData(initialState)
        setEditor('')
        form.resetFields()
        setErrorMsg(false)
    }
    const handleContainOnlyText = (e) => {
        // const alphabeticChars = /[a-zA-Z]/;
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            //  handleProjectInfo()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };
    const handleEditor = () => {
        if (editor?.trim()?.replace(/<[^>]*>/g, '') === '') {
            setErrorMsg(true)
        } else {
            setErrorMsg(false)
        }
    }
    return (
        <Drawer className='bd_drawer_main'
            onClose={() => { props?.onClose() }}
            open={props?.generateRequestOpen}
            closeIcon={<img src={skipBack} alt='' />}
            title='Generate Request:'
            placement="right"
            // open={} 
            width={1000}>
            <div className='bd_prospective_drawer'>
                <div>

                    <div className="bd_editor">
                        <div className="bd_editor_heading">
                            <span style={{ color: "#ff4d4f" }}>*</span> Description:
                        </div>
                    </div>
                    <Form
                        layout="vertical"
                        name='control-hooks'
                        form={form}
                    >
                        <Row gutter={20}>
                            <Col sm={24}>
                                <Form.Item
                                    // name="desc_details"
                                    rules={[{ required: true, message: "please enter a Description" }]}
                                >
                                    <div style={{ marginBottom: "65px", justifyContent: "center" }}>
                                        <ReactQuill
                                            theme="snow"
                                            modules={modules}
                                            formats={formats}
                                            placeholder="write your content ...."
                                            // name='desc_details'
                                            onKeyDown={handleKeyDown}
                                            // onChange={handleEditorChange}
                                            // value={editor}
                                            style={{ height: "300px" }}
                                        >
                                        </ReactQuill>
                                    </div>

                                    {
                                        errormsg ?
                                            <div className="col-md-12" style={{ color: '#ff4d4f' }}>Description is required</div>
                                            :
                                            <p></p>
                                    }
                                    {/* {showError ?
                                <div className="col-md-12" style={{ color: `${showError ? "green" : 'red'}` }}> {showError ? "Description is required" : ""} </div>
                                : null} */}
                                    {/* <div className="col-md-12" style={{ color: `${showError ? "green" : 'red'}` }}> Description is required  </div> */}
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Subject:" name="subject" rules={[{ required: true, message: "please enter a Subject" }]}
                                    // @ts-ignore
                                    onKeyPress={handleContainOnlyText}>
                                    <Input
                                        name='subject'
                                        placeholder="Enter here"
                                        value={requestData?.subject}
                                        onChange={(e) => handleChange('subject', e.target.value?.trimStart())}
                                    />

                                </Form.Item>
                            </Col>

                            <Col sm={12}>
                                <Form.Item name='curr_status' rules={[{ required: true, message: "please select status" }]} label="Status:">
                                    <Select
                                        placeholder="Enter here"
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        showSearch
                                        optionFilterProp="label"
                                        options={[{ value: '1', label: 'Pending' }, { value: '2', label: 'Approval' }]}
                                        onChange={(e) => handleChange('curr_status', e)}
                                        // name='curr_status'
                                        value={requestData?.curr_status}
                                    />
                                </Form.Item>
                            </Col>

                            <Col sm={12}>
                                <Form.Item label="Comment Text:" name="comment_txt" rules={[{ required: true, message: "please enter a Comment Text" }]}
                                    // @ts-ignore
                                    onKeyPress={handleContainOnlyText}>
                                    <Input
                                        name="comment_txt"
                                        placeholder="Enter here"
                                        value={requestData?.comment_txt}
                                        onChange={(e) => handleChange('comment_txt', e.target.value?.trimStart())}
                                    />

                                </Form.Item>
                            </Col>
                            <Col sm={12} >
                                <Form.Item label=" Request to User" name="req_to_userid" rules={[{ required: true, message: "please enter a Request" }]}
                                    // @ts-ignore
                                    onKeyPress={handleContainOnlyText}>
                                    <Select
                                        showSearch
                                        optionFilterProp="children"
                                        onChange={(e) => handleChange('req_to_userid', e)}
                                        // name='req_to_userid'
                                        placeholder="Select User"
                                        value={requestData?.req_to_userid}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    // filterOption={(input, option) =>
                                    //     option.children.toLowerCase().replace(/\s/g, '').indexOf(input.toLowerCase().replace(/\s/g, '')) >= 0
                                    // }
                                    >

                                    </Select>
                                </Form.Item>
                            </Col>
                            <Col sm={24}>

                                <Form.Item label="Attach file  (Max Size is 20 MB)"
                                >
                                    <div className='todo_model_upload'>
                                        <Upload
                                            listType="picture"
                                            // name='files'
                                            fileList={requestData?.request_file}
                                            name="files"
                                        >
                                            <Button className='todo_choosen_btn'>Choose file </Button>
                                            <span className='file_choosen'>No file chosen</span>
                                        </Upload>
                                    </div>
                                </ Form.Item>
                            </Col>

                        </Row>
                        <div className="bd_drawerFoot">
                            <Button className='BG_ghostButton' onClick={handleReset}>Reset</Button>
                            <Button className='BG_mainButton'
                                // onClick={handleSubmit} 
                                type="primary" htmlType="submit"
                                onClick={handleEditor}
                            >Submit</Button>
                        </div>
                    </Form>

                    {
                        <Row>
                            <Col sm={24}>
                                <Card
                                    style={{
                                        margin: 20,
                                        paddingBlock: 0,
                                    }}

                                >
                                    <img src={""} width={50} />     <span style={{ display: 'flex', justifyContent: 'space-between' }}><DeleteOutlined /></span>
                                </Card>
                            </Col>
                        </Row>

                    }




                </div>
            </div>
        </Drawer>
    )
}

export default MisGenrateRequest