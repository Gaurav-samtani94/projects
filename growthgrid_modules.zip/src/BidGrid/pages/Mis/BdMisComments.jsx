import React, { useState } from 'react'
import Comment from '../../../BidGrid/assets/images/icons/chat.png';
import MisGenrateRequest from './MisGenrateRequestDrawer';
import MisRequestListDrawer from './MisRequestListDrawer';
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'
import dayjs from 'dayjs';

const BdMisComments = (props) => {
    const { item, skeleton } = props
    const [open, setOpen] = useState(false);
    const [generateRequestOpen, setGenerateRequestOpen] = useState(false)
    const onCloseDrawer = () => {
        setOpen(false)
    };
    const showRequestDrawer = () => {
        setOpen(!open)
    }
    const showGenrateRequestDrawer = () => {
        setGenerateRequestOpen(true)
    }
    function highlightAt(stringValue) {
        const words = stringValue.split(/\s+/);
        const highlightedWords = words.map(word => {
            if (word.includes('@')) {
                return `<span style="color: #41A6EC">${word}</span>`;
            }
            return word;
        });
        return highlightedWords.join(' ');
    }
    const onClose = () => {
        setGenerateRequestOpen(false)
    }
    return (

        <div className='bd_tenderCrd_sec'>
            <div className='bd_tendersec_cont'>
                {!skeleton ? <div className='bd_tender_card_comment'>
                    <img src={Comment} width={15} alt='' />
                    <span>Last comment</span>
                </div> :
                    <div className='bd_tender_card_comment'>
                        <Skeleton width={150} height={15} />
                    </div>
                }

                {!skeleton ? <span className='bd_tender_commment' dangerouslySetInnerHTML={{ __html: item?.tender_comment != null ? highlightAt(item?.tender_comment.comment_txt) : 'No comment yet...' }}></span>
                    : <div className='bd_tender_commment'>
                        <Skeleton width={150} height={15} />
                    </div>
                }
                {!skeleton ? <div className='bd_tender_sec_by'>
                    <span>{`${item?.tender_comment != null ? 'By ' + item?.tender_comment?.user?.userfullname : ''}`}</span>
                    <div className='bd_tender_sec_time'>
                        <span>{`${item?.tender_comment != null ? dayjs(item?.tender_comment?.created_at).format('DD-MM-YYYY HH:mm:ss') : ''}`}</span>

                    </div>
                </div> : <div className='bd_tender_sec_by'>
                    <Skeleton width={100} height={15} />
                </div>}
            </div>
            <div className='bd_tender_facesheet'
            // onClick={()=> setOpen(!open)}
            >
                <div className="requestCount" >
                    {!skeleton ? <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24">
                        <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m4.5 19.5l15-15m0 0H8.25m11.25 0v11.25" />
                    </svg> : <Skeleton width={10} height={15} />}
                    {/* Requests <span>{requestCounts ? requestCounts : 0}</span> */}
                    {
                        !skeleton ? (<>Requests </>) : (<>
                            <Skeleton width={100} height={15} />
                        </>)
                    }
                </div>
                <MisGenrateRequest generateRequestOpen={generateRequestOpen} setGenerateRequestOpen={setGenerateRequestOpen} onClose={onClose} />
            </div>
            <MisRequestListDrawer open={open} setOpen={setOpen} showRequestDrawer={showRequestDrawer} onCloseDrawer={onCloseDrawer} showGenrateRequestDrawer={showGenrateRequestDrawer} />
        </div>
    )
}

export default BdMisComments