// @ts-nocheck
import React, { useState } from 'react';
import { Checkbox, Select } from 'antd';
import Location from '../../assets/images/icons/location.png';
import EventBusyIcon from '@mui/icons-material/EventBusy';
import spinGif from '../../assets/images/spin.gif';
import { Down } from '@icon-park/react';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import dayjs from "dayjs";
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import ROUTES from 'Constants/Routes';

const BdMisInfo = (props) => {
    const { item, skeleton, misSingleDropDownList, setChecked, selectedItems, misAllTendersLength, setSelectedItems, setMisTenderId, setMisCycleId, handleSubmitTender, misSubmittedDropDownList } = props
    const { misFilterValues } = useSelector(state => state.misFilter);

    const AllScope = misSubmittedDropDownList?.find((itm) => Object?.keys(itm) == item?.bg_tenders_status_manage?.tender_status)
    const AllScopeArr = AllScope != null && AllScope != undefined && Object?.values(AllScope)

    let dateApend = item.submission_end_date !== null ? dayjs(item.submission_end_date).subtract(dayjs(item.submission_end_date).utcOffset(), 'minute').format("DD MMM YYYY") : '-';
    const [misStatusChange, setMisStatusChange] = useState()

    const handleCheckBox = (e) => {
        let isSelected = e.target.checked;
        let value = parseInt(e.target.value);
        if (isSelected) {
            console.log("if")
            setSelectedItems([...selectedItems, value]);
            if (selectedItems.length + 1 === misAllTendersLength) {
                console.log("nested if")
                setChecked(true);
            }
        } else {
            console.log("else")
            setSelectedItems((prev) => prev.filter((id) => id !== value));
            setChecked(false);
        }
    }
    const tenderNames = (str) => {
        const htmlTagPattern = /<[^>]*>/g;
        const htmlTags = str?.match(htmlTagPattern);
        if (htmlTags) {
            const stringWithoutHtmlTags = str.replace(htmlTagPattern, '');
            const capitalizedString = capitalizeExceptPrepositionsAndLowerCase(stringWithoutHtmlTags);
            return <span>{capitalizedString}</span>;
        } else {
            return <span>{capitalizeExceptPrepositionsAndLowerCase(str)}</span>;
        }
    }

    const onChangeStatus = async (e) => {
        console.log(e, "eeeeeeeeeeee")
        setMisTenderId(item?.id)
        setMisCycleId(e)
        setMisStatusChange(e)
        handleSubmitTender(e, item?.id, setMisStatusChange, item)
    }

    return (
        <>
            {
                !skeleton ?

                    <div className='bd_tenderCard_first'>
                        <div className="bd_cards_tender">
                            <div className='bd_cards_active'>
                                <Checkbox checked={selectedItems?.includes(item.id)} onChange={handleCheckBox} value={item.id} style={{ display: misFilterValues?.orderSerial == 8 ? "none" : "flex" }}><p>{item.bg_mstr_client?.client_name}</p></Checkbox>
                                <div className="bd_active_btn_sec">
                                    {/* <div className={`bd_active_btn_sec ${showStatusColor(item?.bg_mstr_tndr_cycle?.order_sr)}`}> */}
                                    {/* {!dropdownSpinner[item.id] ?  */}
                                    <div className={`status_select ${misStatusChange}`}>
                                        <Select
                                            defaultValue={item?.bg_tenders_status_manage?.bg_mstr_tndr_status?.status_name}
                                            value={item?.bg_tenders_status_manage?.bg_mstr_tndr_status?.status_name}
                                            onChange={onChangeStatus}
                                            // disabled={selectedItems.length > 0 ? true : false}
                                            suffixIcon={<Down theme="outline" size="18" fill="#78889b" />}
                                            options={misFilterValues?.orderSerial != 8 ? misSingleDropDownList?.map((item) => {
                                                return {
                                                    value: item.id,
                                                    label: item.cycle_name
                                                }
                                            })
                                                :
                                                AllScopeArr[0]?.map((item) => {
                                                    return {
                                                        value: item.id,
                                                        label: item.cycle_name
                                                    }
                                                })

                                            }
                                        />
                                    </div>
                                    {/* : <img src={spinGif} width={30} />} */}
                                    {/* </div> */}
                                    {/* <div className="status_select">
                                        <Select
                                            options={[
                                                {
                                                    value: 'applied',
                                                    label: 'Applied',
                                                },
                                                {
                                                    value: 'phone-screen',
                                                    label: 'Phone Screen',
                                                },
                                                {
                                                    value: 'interview',
                                                    label: 'Interview',
                                                },
                                                {
                                                    value: 'hired',
                                                    label: 'Hired',
                                                },
                                                {
                                                    value: 'rejected',
                                                    label: 'Rejected',
                                                },
                                            ]}
                                            placeholder="select status"
                                            suffixIcon={<Down theme="outline" size="18" fill="#78889b" />}
                                        />
                                    </div> */}
                                    {/* <img src={spinGif} width={30} /> */}
                                </div>
                            </div>
                            <div className='bd_tender_card_location'>
                                <img src={Location} width={13} alt='' />
                                <span>
                                    {capitalizeExceptPrepositionsAndLowerCase(item.bg_mstr_city?.city_name)}
                                    {item?.bg_mstr_city !== null && ","}
                                    {capitalizeExceptPrepositionsAndLowerCase(item.bg_mstr_state?.state_name)}
                                    {item?.bg_mstr_state !== null && ","}
                                    {capitalizeExceptPrepositionsAndLowerCase(item.bg_mstr_country.country_name)}
                                </span>
                            </div>
                        </div>
                        <div className='bd_tender_card_chips'>
                            <div className='bd_tender_chips'>
                                <span>
                                    {capitalizeExceptPrepositionsAndLowerCase(item.bg_mstr_sector?.sector_name)}
                                </span>
                            </div>
                        </div>
                        <div className='bd_tender_card_detail'>
                            <Link to={ROUTES.BD_TENDERDETAILS.replace(':id', item?.id)} >

                                {tenderNames(item?.tender_name)}
                            </Link>
                        </div>
                        <div className='bd_tender_card_expire'>
                            <EventBusyIcon />
                            <p>Expires on</p>
                            <span>{dateApend}</span>
                        </div>
                        <div className="additnal_info">
                            {item?.bg_assign_tndr_generated_id === null ? "" :
                                <div className="textInfo"><span>Generate Id:</span>{item?.bg_assign_tndr_generated_id?.generated_tender_id}</div>
                            }
                            {item?.assign_tender === [] ? "" : item?.assign_tender?.map((item) => {

                                return <div className="textInfo">
                                    {/* {console.log(item, "dd")} */}
                                    {item?.bg_mstr_bd_role?.role_name
                                    } : {item?.user?.userfullname}
                                </div>

                            })
                            }
                        </div>
                    </div>
                    :

                    <div className='bd_tenderCard_first'>
                        <div className="bd_cards_tender">
                            <div className='bd_cards_active'>
                                <Checkbox >
                                    <Skeleton width={300} height={30} />
                                </Checkbox>
                                <div className="bd_active_btn_sec">
                                    <div className={`status_select`}>
                                        {/* <Select
                                    defaultValue={item?.bg_mstr_tndr_cycle?.cycle_name}
                                    onChange={onChangeStatus}
                                    suffixIcon={<Down theme="outline" size="18" fill="#78889b" />}
                                    options={[
                                        {
                                            value: 'applied',
                                            label: 'Applied',
                                        },
                                        {
                                            value: 'phone-screen',
                                            label: 'Phone Screen',
                                        },
                                        {
                                            value: 'interview',
                                            label: 'Interview',
                                        },
                                        {
                                            value: 'hired',
                                            label: 'Hired',
                                        },
                                        {
                                            value: 'rejected',
                                            label: 'Rejected',
                                        },
                                    ]}
                                /> */}
                                        <Skeleton width={100} height={30} />
                                    </div>
                                </div>
                            </div>
                            <div className='bd_tender_card_location'>
                                <Skeleton width={100} height={30} />
                            </div>
                        </div>
                        <div className='bd_tender_card_chips'>
                            <div className='bd_tender_chips'>
                                <Skeleton width={100} height={30} />
                            </div>
                        </div>
                        <div className='bd_tender_card_detail'>
                            <Skeleton width={500} height={30} />
                        </div>
                        <div className='bd_tender_card_expire'>
                            <Skeleton width={100} height={30} />
                        </div>
                    </div>

            }
        </>
    );
}

export default BdMisInfo;