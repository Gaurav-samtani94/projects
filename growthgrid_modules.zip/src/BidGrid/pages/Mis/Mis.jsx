// @ts-nocheck
import { Collapse } from 'antd'
import React, { useEffect, useState } from 'react'
import BdMisCard from './BdMisCard';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import { misFilterActions } from 'Redux/actions/bidgrid/misFilterAction';
import 'react-loading-skeleton/dist/skeleton.css'
import { MisApi } from 'Services/bidgrid/tenderList/MIsApi';
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'


const Mis = () => {

    const { misFilterValues } = useSelector(state => state.misFilter);
    const dispatch = useDispatch();

    const [selectedItems, setSelectedItems] = useState([]);
    const [getScopeListData, setScopeListdata] = useState([]);
    const [collapseItem, setCollapseItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [checked, setChecked] = useState(false);

    const [currentCycleId, setCurrentCycleID] = useState(null)


    const CollapseSkeleton = () => {
        return (
            <div>
                {Array.from({ length: 6 }, (_, index) => (
                    <div key={index} className="skeleton-line" style={{ marginBottom: '20px' }}>
                        <Skeleton width={300} height={50} />
                    </div>
                ))}
            </div>
        );
    };

    const handleOnClickTab = (tab, serialNumber) => {
        if (tab?.length > 0) {
            setChecked(false)
            setSelectedItems([])
            setCurrentCycleID(tab?.toString())
            const myObj = getScopeListData?.find((item) => (item.id.toString()) === tab?.toString());
            const MisTenderBody = {
                limit: 25,
                page_number: 1,
                cycle_id: tab?.toString(),
                orderSerial: serialNumber?.toString() || myObj?.order_sr?.toString(),
            }
            dispatch(misFilterActions?.misFilterUpdateIndividualKeys(MisTenderBody))

        } else {
            return;
        }

    }

    useEffect(() => {
        if (!misFilterValues?.cycle_id) {
            const MisTenderBody = {
                cycle_id: currentCycleId,
            }
            dispatch(misFilterActions.misFilterUpdateIndividualKeys(MisTenderBody))
        }
    }, [misFilterValues?.cycle_id])

    const getMisTenderScopeList = async () => {
        try {
            const response = await MisApi?.getMisTenderscope()
            if (response?.data?.status == 1) {
                setScopeListdata(response?.data?.data)
                setLoading(false)

                let activeScopeId = misFilterValues?.cycle_id ? [misFilterValues?.cycle_id?.toString()] : [response?.data?.data[0].id.toString()]
                let serialNum = response?.data?.data?.filter((item) => item?.id == activeScopeId[0]).map((ite) => ite?.order_sr)
                handleOnClickTab(activeScopeId, serialNum)
            } else {
                setLoading(true)
                setScopeListdata([])
            }
            const dynamicItems = response?.data?.data.map((item) => {

                return {
                    key: item.id.toString(),
                    label: (
                        <div className="custom-header-class">
                            <span>{item.cycle_name}</span>
                        </div>
                    ),
                };
            });
            setCollapseItems(dynamicItems);
        } catch (error) {
            console.log(error)
            setCollapseItems([])
            setScopeListdata([])
        }
    }

    useEffect(() => {
        getMisTenderScopeList()
    }, [])

    return (
        <>
            <div className='bd_new_tender'>
                <div className='d-flex'>
                    <div className='bd_new_tender_cont'>
                        {
                            loading ?
                                <CollapseSkeleton />
                                :
                                <div className="bd_new_tender_sidebar">
                                    {misFilterValues?.cycle_id && <Collapse accordion activeKey={[misFilterValues?.cycle_id]} items={collapseItem} onChange={handleOnClickTab} >
                                    </Collapse>
                                    }
                                </div>
                        }
                    </div>
                    <BdMisCard
                        getScopeListData={getScopeListData}
                        checked={checked}
                        setChecked={setChecked}
                        selectedItems={selectedItems}
                        setSelectedItems={setSelectedItems}
                    />
                </div>
            </div>
        </>

    )
}

export default Mis