// @ts-nocheck
import React, { useState } from 'react';
import { Tooltip, Drawer, Button } from 'antd';
import { ClockCircleOutlined, CloseOutlined, LinkOutlined, SwapOutlined } from '@ant-design/icons';
import skipBack from "../../assets/images/skip-back.png";
import Skeleton from 'react-loading-skeleton';
import Link from '@mui/material/Link';

import 'react-loading-skeleton/dist/skeleton.css';
import { Bookmark, Margin, RemindDisable } from '@icon-park/react';
import TenderWishListModal from 'BidGrid/components/TenderCycleActionModal/TenderWishListModal';
import TenderRemainderModal from 'BidGrid/components/TenderCycleActionModal/TenderRemainderModal';
import TenderSubmitModal from 'BidGrid/components/TenderCycleActionModal/TenderSubmitModal';
import TenderDeleteModal from 'BidGrid/components/TenderCycleActionModal/TenderDeleteModal';
import TenderStatusModal from 'BidGrid/components/TenderCycleActionModal/TenderStatusModal';
// import "../../assets/css/styles/newTender.scss"


const BdMisTenderAction = (props) => {

    const { item, misActionsList, misActionData } = props

    const [linkOpen, setLinkOpen] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [remind, setReminOpen] = useState(false);
    const [submitOpen, setSubmitOpen] = useState(false);
    const [deleteOpen, setdeleteOpen] = useState(false);
    const [tenderStatusOpen, setTenderStatusOpen] = useState(false);

    let unitTenderIdForWishlist = misActionData?.wishlist_tender?.find((itm) => itm?.tender_id === item?.id);
    let unitTenderIdForReminder = misActionData?.reminder_tender?.find((itm) => itm?.tender_id === item?.id);

    const handleCallAction = (action) => {
        switch (action) {
            case "Add Wishlist":
                setIsModalOpen(true);
                break;
            case "Add Reminder":
                setReminOpen(true);
                break;
            case "Move": {
                // handleMoveTenderToAnotherScope(item?.id, "Move");
                break;
            }
            case "No Go":
                setdeleteOpen(true);
                break;
            case "view Link":
                setLinkOpen(true);
                break;
            default:
                console.log("Action not recognized");
                break;
        }
    };
    const showModal = () => {
        setIsModalOpen(true);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };

    const showRemainder = () => {
        setReminOpen(true)

    }
    const handleRemindCancel = () => {
        setReminOpen(false);
    };
    const handleCloseDrawer = () => {
        setLinkOpen(false)
    }
    const showSubmit = () => {
        setSubmitOpen(true)

    }
    const handleSubmitCancel = () => {
        setSubmitOpen(false);
    };
    const showDelete = (item) => {
        setdeleteOpen(true)
        // setCycleId(item)
    }
    const handleDelete = () => {
        setdeleteOpen(false);
    };
    const showTenderStatus = () => {
        setTenderStatusOpen(true)
    }
    const tenderStatus = () => {
        setTenderStatusOpen(false)
    }

    return (
        <>
            {/* <div className='bd_tenderCrd_thrd' >
                <Tooltip placement="bottom" title="Add Wishlist">
                    <Button type="link" icon={<Bookmark />} onClick={() => handleCallAction("Add Wishlist")} />
                </Tooltip>
                <Tooltip placement="bottom" title="Add Reminder">
                    <Button type="link" icon={<ClockCircleOutlined />} onClick={() => handleCallAction("Add Reminder")} />
                </Tooltip>
                <Tooltip placement="bottom" title="Move">
                    <Button type="link" icon={<SwapOutlined />} onClick={() => handleCallAction(" Move")} />
                </Tooltip>
                <Tooltip placement="bottom" title="No Go">
                    <Button type="link" icon={<CloseOutlined />} onClick={() => handleCallAction("No Go")} />
                </Tooltip>
                <Tooltip placement="bottom" title="view Link">
                    <Button type="link" icon={<LinkOutlined />} onClick={() => handleCallAction("view Link")} />
                </Tooltip>
            </div> */}
            <div className='bd_tenderCrd_thrd' >
                {/* {filterValues?.orderSerial == 6 && <button className='blink_button_checkout'></button>} */}
                {
                    misActionsList?.filter((actionItem) => actionItem?.bg_mstr_tndr_cycle_inaction != null)?.map((itm, index) => {

                        return (
                            // !skeleton ? <Tooltip placement="bottom" title={itm?.bg_mstr_tndr_cycle_inaction?.inaction_name}  >
                            //     <Link className={unitTenderIdForWishlist?.tender_id ? "import_export_data" : 'import_export'} onClick={() => handleCallAction(itm?.bg_mstr_tndr_cycle_inaction?.inaction_name, itm)}  >
                            //         {
                            //             itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'view Link' && item?.tnd_url === null ?
                            //                 <></>
                            //                 :
                            //                 itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Wishlist' && unitTenderIdForWishlist?.tender_id ? <Bookmark theme="filled" size="24" fill="#FF7835" />

                            //                     :

                            //                     itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Reminder' && unitTenderIdForReminder?.tender_id ? <RemindDisable theme="filled" size="24" fill="#FF7835" />
                            //                         : <img src={`https://web.growthgrids.com/uploads/inaction_image/${itm?.bg_mstr_tndr_cycle_inaction?.image_name}`}
                            //                             style={{ width: "20px" }} />

                            //         }


                            //     </Link>
                            // </Tooltip> :
                            //     <Link className="import_export_data">
                            //         <Skeleton width={30} height={20} circle />
                            //     </Link>
                            <Tooltip placement="bottom" title={itm?.bg_mstr_tndr_cycle_inaction?.inaction_name}  >
                                <Link className={unitTenderIdForWishlist?.tender_id ? "import_export_data" : 'import_export'} onClick={() => handleCallAction(itm?.bg_mstr_tndr_cycle_inaction?.inaction_name, itm)}  >
                                    {
                                        itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'view Link' && item?.tnd_url === null ?
                                            <></>
                                            :
                                            itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Wishlist' && unitTenderIdForWishlist?.tender_id ? <Bookmark theme="filled" size="24" fill="#FF7835" />

                                                :

                                                itm?.bg_mstr_tndr_cycle_inaction?.inaction_name === 'Add Reminder' && unitTenderIdForReminder?.tender_id ? <RemindDisable theme="filled" size="24" fill="#FF7835" />
                                                    : <img src={`${docurlchat}uploads/inaction_image/${itm?.bg_mstr_tndr_cycle_inaction?.image_name}`}
                                                        style={{ width: "20px" }} />

                                    }


                                </Link>
                            </Tooltip>
                        )
                    })
                }
            </div>
            <Drawer className='drawer_save_temp' closeIcon={<img src={skipBack} alt='' />} title="Tender" placement="right" onClose={() => setLinkOpen(false)} open={linkOpen} width="90%">
                <iframe src={item?.tnd_url} title="W3Schools Free Online Web Tutorials" width="100%" ></iframe>
            </Drawer>


            <TenderWishListModal
                isModalOpen={isModalOpen}
                //   itemId={item.id}
                handleCancel={handleCancel}
                setIsModalOpen={setIsModalOpen}
            //   getActionList={getActionList}
            />
            <TenderRemainderModal
                remind={remind}
                // itemId={item.id}
                handleRemindCancel={() => setReminOpen(false)}
            />
            <TenderSubmitModal
                submitOpen={submitOpen}
                handleSubmitCancel={() => setSubmitOpen(false)}
            />
            <TenderDeleteModal //pending from backend
                deleteOpen={deleteOpen}
                handleDelete={handleDelete}
                setdeleteOpen={setdeleteOpen}
            // itemId={item.id}
            // cycleId={cycleId}
            // getTenders={getTenders}
            // setTenders={setTenders}
            />
            <TenderStatusModal
                tenderStatusOpen={tenderStatusOpen}
                tenderStatus={() => setTenderStatusOpen(false)}
            />

        </>

    );
};

export default BdMisTenderAction;
