// @ts-nocheck
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { capitalizeExceptPrepositionsAndLowerCase } from "common/components/CapitalLetter/CapitalLetterWithoutPrepositions";
import { Divider, Drawer, Select, Card, Typography, } from "antd";
import skipBack from "../../assets/images/skip-back.png";
import { Link, useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import { DashboardServiceApi } from "Services/bidgrid/dashboard/DashboardAPi";
import { TodoServices } from "Services/bidgrid/todo/TodoServices";
import styled from 'styled-components';
import file from '../../assets/images/file.png'
import ROUTES from 'Constants/Routes';
import { ClockCircleOutlined } from '@ant-design/icons';
import { Down } from '@icon-park/react';
import { Avatar, Tooltip } from 'antd';
import attachment from '../../assets/images/icons/file_present.png';
import { useDispatch } from "react-redux";
import Comments from '../../assets/images/icons/fluent_chat-24-filled.png';
import arrowIcon from "../../assets/images/arrow-right.png"
import { navigationData } from "Redux/actions/bidgrid/navigationData";
import { useSelector } from "react-redux";
import { RequestApi } from "Services/bidgrid/tenderList/RequestApi";
import { toast } from 'react-toastify';
import { docurlchat } from 'utils/configurable';
import { TimeConverter } from "BidGrid/components/TimeConverter/TimeConverter";

const StyledCard = styled(Card)`
margin: 0.5rem;
padding: 0.5rem;
`;

const TaskboardItemCardTitle = styled(Typography.Title)`
white-space: pre-wrap;
margin-right: 0.25rem;
`;

const createdByOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }, { value: '3', label: 'Approved' }]
const assignedToOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }]
// calendar month
const fetchDataForMonth = async (GMT_DATE, prev) => {

    let orgDate;
    let date;
    const today = moment();
    if (GMT_DATE !== null) {
        orgDate = dayjs(GMT_DATE)
        date = dayjs(GMT_DATE).format('YYYY-MM')
    } else {
        date = today.format('YYYY-MM')
    }
    const dateArr = date?.split('-')
    let FinalDate;
    if (prev === true) {
        if (parseInt(dateArr[1] > 11)) {
            FinalDate = orgDate.add(1, 'year');
        }
        FinalDate = orgDate.add(1, 'month');
    } else if (prev === false) {
        if (parseInt(dateArr[1] > 2)) {
            FinalDate = orgDate.subtract(1, 'year');
        }
        FinalDate = orgDate.subtract(1, 'month');
    } else {

        FinalDate = GMT_DATE === null ? date : orgDate
    }




    const formData = new URLSearchParams();
    formData.append('month', GMT_DATE === null ? FinalDate : FinalDate?.format('YYYY-MM'));
    try {
        let result = await DashboardServiceApi.calendarByMonth(formData);
        if (result?.data?.status === '1') {
            // meeting list
            let meetingList = []
            let tenderDataList = []
            let tenderReqList = []
            let todoTaskList = []
            let tenderTodoTaskList = []
            let prebid_data = []
            if (result?.data?.data?.meetingList?.length !== 0) {
                const uniqueDatesSetMeeting = new Set();
                meetingList = result?.data?.data?.meetingList?.reduce((accumulator, item) => {
                    const meetingStartDate = dayjs(item?.meeting_date).format('YYYY-MM-DD');

                    if (!uniqueDatesSetMeeting.has(meetingStartDate)) {
                        uniqueDatesSetMeeting.add(meetingStartDate);

                        const startDate = new Date(meetingStartDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'meetingList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);
                // meetingList = meetingList[0]
            } else {
                meetingList = []
            }

            if (result?.data?.data?.tenderDataList?.length !== 0) {
                const uniqueDatesSetTndData = new Set();
                tenderDataList = result?.data?.data?.tenderDataList?.reduce((accumulator, item) => {
                    const tndDataStartDate = dayjs(item?.submission_end_date).format('YYYY-MM-DD');

                    if (!uniqueDatesSetTndData.has(tndDataStartDate)) {
                        uniqueDatesSetTndData.add(tndDataStartDate);

                        const startDate = new Date(tndDataStartDate);

                        accumulator.push({
                            id: item?.tender_id,
                            title: '',
                            type: 'tenderDataList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);

            } else {
                tenderDataList = []
            }

            if (result?.data?.data?.tenderReqList?.length !== 0) {
                const uniqueDatesSetReq = new Set();
                tenderReqList = result?.data?.data?.tenderReqList?.reduce((accumulator, item) => {
                    const tndReqStartDate = dayjs(item?.created_at).format('YYYY-MM-DD');

                    if (!uniqueDatesSetReq.has(tndReqStartDate)) {
                        uniqueDatesSetReq.add(tndReqStartDate);

                        const startDate = new Date(tndReqStartDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'tenderReqList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);
            } else {
                tenderReqList = []
            }
            if (result?.data?.data?.toDoTaskList?.length !== 0) {
                const uniqueDatesSetTodoTask = new Set();
                todoTaskList = result?.data?.data?.toDoTaskList?.reduce((accumulator, item) => {
                    const todoTaskStartDate = dayjs(item?.created_at).format('YYYY-MM-DD');

                    if (!uniqueDatesSetTodoTask.has(todoTaskStartDate)) {
                        uniqueDatesSetTodoTask.add(todoTaskStartDate);

                        const startDate = new Date(todoTaskStartDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'toDoTaskList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);

            } else {
                todoTaskList = []
            }
            if (result?.data?.data?.tenderTodoTaskList?.length !== 0) {
                const combinedDataSet = [...result?.data?.data?.toDoTaskList, ...result?.data?.data?.tenderTodoTaskList]
                const uniqueDatesSetTndTodoTask = new Set();
                tenderTodoTaskList = combinedDataSet?.reduce((accumulator, item) => {
                    const todoTaskStartDate = dayjs(item?.created_at).format('YYYY-MM-DD');

                    if (!uniqueDatesSetTndTodoTask.has(todoTaskStartDate)) {
                        uniqueDatesSetTndTodoTask.add(todoTaskStartDate);

                        const startDate = new Date(todoTaskStartDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'toDoTaskList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);
                todoTaskList = [...tenderTodoTaskList]
            } else {
                todoTaskList = [...todoTaskList]
            }
            if (result?.data?.data?.prebid_data?.length !== 0) {
                const uniqueDatesSetPreBidData = new Set();
                prebid_data = result?.data?.data?.prebid_data?.reduce((accumulator, item) => {
                    const preBidEndDate = dayjs(item?.pre_bid_meeting_date).format('YYYY-MM-DD');

                    if (!uniqueDatesSetPreBidData.has(preBidEndDate)) {
                        uniqueDatesSetPreBidData.add(preBidEndDate);

                        const endDate = new Date(preBidEndDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'prebid_data',
                            start: endDate,
                            end: endDate
                        });
                    }

                    return accumulator;
                }, []);
            } else {
                prebid_data = []
            }
            const calendarEvents = {
                month: FinalDate.$d.toString(),
                events: [...meetingList, ...tenderDataList, ...tenderReqList, ...todoTaskList, ...prebid_data]
            }

            return calendarEvents

        }
    } catch (error) {
        const calendarEvents = {
            month: FinalDate.$d.toString(),
            events: []
        }

        return calendarEvents
    }


};

// dept calendar

const fetchDeptCalendar = async (GMT_DATE, prev, userVal) => {

    let orgDate = dayjs(GMT_DATE)
    let date = dayjs(GMT_DATE).format('YYYY-MM')
    const dateArr = date?.split('-')
    let FinalDate;
    if (prev === true) {
        if (parseInt(dateArr[1] > 11)) {
            FinalDate = orgDate.add(1, 'year');
        }
        FinalDate = orgDate.add(1, 'month');
    } else if (prev === false) {
        if (parseInt(dateArr[1] > 2)) {
            FinalDate = orgDate.subtract(1, 'year');
        }
        FinalDate = orgDate.subtract(1, 'month');
    } else {
        FinalDate = orgDate
    }

    const formData = new URLSearchParams();
    formData.append('month', FinalDate?.format('YYYY-MM'));
    userVal?.length > 0 && formData.append('user_id', userVal?.join(','));
    try {
        let result = await DashboardServiceApi.deptCalendarByMonth(formData);

        if (result?.data?.status === '1') {
            const extractedData = result?.data?.data?.filter(item => item !== null)

            let meetingList = []
            let tenderDataList = []
            let tenderReqList = []
            let todoTaskList = []
            let tenderTodoTaskList = []
            let prebid_data = []

            extractedData?.map((item) => {
                if (item?.meetingList?.length > 0) {
                    item.meetingList?.map((val) => {
                        meetingList.push(val)
                    })
                }
                if (item?.tenderDataList?.length > 0) {
                    item.tenderDataList?.map((val) => {
                        tenderDataList.push(val)
                    })
                }
                if (item?.tenderReqList?.length > 0) {
                    item.tenderReqList?.map((val) => {
                        tenderReqList.push(val)
                    })
                }
                if (item?.todoTaskList?.length > 0) {
                    item.todoTaskList?.map((val) => {
                        todoTaskList.push(val)
                    })
                }
                if (item?.tenderTodoTaskList?.length > 0) {
                    item.tenderTodoTaskList?.map((val) => {
                        tenderTodoTaskList.push(val)
                    })
                }
                if (item?.prebid_data?.length > 0) {
                    item.prebid_data?.map((val) => {
                        prebid_data.push(val)
                    })
                }

            })
            let meetingLists = []
            let tenderDataLists = []
            let tenderReqLists = []
            let todoTaskLists = []
            let tenderTodoTaskLists = []
            let prebid_datas = []

            if (meetingList?.length !== 0) {
                const uniqueDatesSetMeeting = new Set();
                meetingLists = meetingList?.reduce((accumulator, item) => {
                    const meetingStartDate = dayjs(item?.meeting_date).format('YYYY-MM-DD');

                    if (!uniqueDatesSetMeeting.has(meetingStartDate)) {
                        uniqueDatesSetMeeting.add(meetingStartDate);

                        const startDate = new Date(meetingStartDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'meetingList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);
            } else {
                meetingLists = []
            }

            // tenderDataList

            if (tenderDataList?.length !== 0) {
                const uniqueDatesSetTndData = new Set();
                tenderDataLists = tenderDataList?.reduce((accumulator, item) => {
                    const tndDataStartDate = dayjs(item?.submission_end_date).format('YYYY-MM-DD');

                    if (!uniqueDatesSetTndData.has(tndDataStartDate)) {
                        uniqueDatesSetTndData.add(tndDataStartDate);

                        const startDate = new Date(tndDataStartDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'tenderDataList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);

            } else {
                tenderDataLists = []
            }

            // tenderReq

            if (tenderReqList?.length !== 0) {
                const uniqueDatesSetReq = new Set();
                tenderReqLists = tenderReqList?.reduce((accumulator, item) => {
                    const tndReqStartDate = dayjs(item?.created_at).format('YYYY-MM-DD');

                    if (!uniqueDatesSetReq.has(tndReqStartDate)) {
                        uniqueDatesSetReq.add(tndReqStartDate);

                        const startDate = new Date(tndReqStartDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'tenderReqList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);
            } else {
                tenderReqLists = []
            }

            // todo task

            if (todoTaskList?.length !== 0) {
                const uniqueDatesSetTodoTask = new Set();
                todoTaskLists = todoTaskList?.reduce((accumulator, item) => {
                    const todoTaskStartDate = dayjs(item?.created_at).format('YYYY-MM-DD');

                    if (!uniqueDatesSetTodoTask.has(todoTaskStartDate)) {
                        uniqueDatesSetTodoTask.add(todoTaskStartDate);

                        const startDate = new Date(todoTaskStartDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'toDoTaskList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);

            } else {
                todoTaskLists = []
            }

            // tender todoTask


            if (tenderTodoTaskList?.length !== 0) {
                const combinedDataSet = [...todoTaskLists, ...tenderTodoTaskList]
                const uniqueDatesSetTndTodoTask = new Set();
                tenderTodoTaskLists = combinedDataSet?.reduce((accumulator, item) => {
                    const todoTaskStartDate = dayjs(item?.created_at).format('YYYY-MM-DD');

                    if (!uniqueDatesSetTndTodoTask.has(todoTaskStartDate)) {
                        uniqueDatesSetTndTodoTask.add(todoTaskStartDate);

                        const startDate = new Date(todoTaskStartDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'toDoTaskList',
                            start: startDate,
                            end: startDate
                        });
                    }

                    return accumulator;
                }, []);
                todoTaskLists = [...tenderTodoTaskLists]
            } else {
                todoTaskLists = [...todoTaskList]
            }

            // prebid


            if (prebid_data?.length !== 0) {
                const uniqueDatesSetPreBidData = new Set();
                prebid_datas = prebid_data?.reduce((accumulator, item) => {
                    const preBidEndDate = dayjs(item?.pre_bid_meeting_date).format('YYYY-MM-DD');

                    if (!uniqueDatesSetPreBidData.has(preBidEndDate)) {
                        uniqueDatesSetPreBidData.add(preBidEndDate);

                        const endDate = new Date(preBidEndDate);

                        accumulator.push({
                            id: item?.id,
                            title: '',
                            type: 'prebid_data',
                            start: endDate,
                            end: endDate
                        });
                    }

                    return accumulator;
                }, []);
            } else {
                prebid_datas = []
            }
            const calendarEvents = {
                month: FinalDate.$d.toString(),
                events: [...meetingLists, ...tenderDataLists, ...tenderReqLists, ...todoTaskLists, ...prebid_datas]
            }
            return calendarEvents
        }
    } catch (error) {
        const calendarEvents = {
            month: FinalDate.$d.toString(),
            events: []
        }
        return calendarEvents
    }
}



// Custom Toolbar
const CustomToolbar = ({ fetchEventsFromCalendar, activeTabKey, userVal, ...props }) => {
    // previous activeTabKey
    const date = new Date(props?.date);

    const goToBack = async () => {
        props?.onNavigate("PREV");
        let calendarEvents
        if (activeTabKey === '1') {
            calendarEvents = await fetchDataForMonth(date.toString(), false)
        } else if (activeTabKey === '2') {
            calendarEvents = await fetchDeptCalendar(date.toString(), false, userVal)
        } else {
            return;
        }
        fetchEventsFromCalendar(calendarEvents)
    };

    // next tab active key
    const goToNext = async () => {

        props?.onNavigate("NEXT");
        let calendarEvents
        if (activeTabKey === '1') {
            calendarEvents = await fetchDataForMonth(date.toString(), true)
        } else if (activeTabKey === '2') {
            calendarEvents = await fetchDeptCalendar(date.toString(), true, userVal)
        } else {
            return;
        }
        fetchEventsFromCalendar(calendarEvents)
    };

    const today = moment();
    const formattedToday = today.format("dddd, MMMM D, YYYY");

    return (
        <div className="rbc-toolbar-main">
            <div className="rbc-toolbar">
                <span className="rbc-toolbar-label">{props?.label}</span>
                <span onClick={goToBack} className="rbc-btn-group">
                    <button type="button">
                        &lt;
                    </button>
                </span>
                <span onClick={goToNext} className="rbc-btn-group">
                    <button type="button" >
                        &gt;
                    </button>
                </span>
                <br />
                <span className="current-date">{`Today is ${formattedToday}`} </span>

            </div>

            <div className="calenderEvent_info">
                <div className="cei_item preBid">
                    <span /> Pre-Bid Meeting
                </div>
                <div className="cei_item tenderTask">
                    <span /> Bid Submission
                </div>
                <div className="cei_item meeting">
                    <span /> Meetings
                </div>
                <div className="cei_item tenderRequest">
                    <span /> Tender Request
                </div>
                <div className="cei_item todoTask">
                    <span /> To-Do List
                </div>
            </div>

        </div>
    );
};

const localizer = momentLocalizer(moment);



const CustomCalendar = ({ activeTabKey, userVal, employeeList, userOptions, employeeListTeam }) => {

    const currentDate = moment(); // Define the current date
    const [selectedDate, setSelectedDate] = useState(null);
    const [calenderDetail, setCalenderDetail] = useState(false);
    const [calendarData, setCalendarData] = useState([])
    const [priorityList, setPriorityList] = useState([])
    const [filterEvent, setFilterEvent] = useState('all')
    const [events, setEvents] = useState([])
    const [deptData, setDeptData] = useState([])
    const [extractUser, setExtractUser] = useState(null)
    const [checkDateWhileToggle, setCheckDateWhileToggle] = useState(null)
    const navigate = useNavigate()
    const [filterVal, setFilterVal] = useState([])
    const firstDayOfMonth = moment(currentDate).startOf('month');
    const lastDayOfMonth = moment(currentDate).endOf('month');
    const [documentData, setDocumentData] = useState([])
    const [statusData, setStatusData] = useState('')
    const { userBidInfo } = useSelector((state) => state?.userDetails)
    const dispatch = useDispatch()
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    // get today date event
    useEffect(() => {
        const today = moment();
        setSelectedDate(today);
    }, []);

    // priority List
    const getPriorityList = async () => {
        try {
            const response = await TodoServices.getTaskPriorityList()
            if (response?.data?.status === "1") {
                setPriorityList(response?.data?.data)
            }
        } catch (error) {

        }
    }


    const fetchCalendardata = async (val) => {
        if (activeTabKey === '1') {
            const formData = new URLSearchParams();
            formData.append('date', val);
            try {
                let result = await DashboardServiceApi.calendarByDate(formData);
                if (result?.data?.status === '1') {
                    const { meetingList, prebid_data, tenderDataList, tenderReqList, tenderTodoTaskList, toDoTaskList } = result?.data?.data

                    const obj = {
                        meetingList: meetingList,
                        prebid_data: prebid_data,
                        tenderDataList: tenderDataList,
                        tenderReqList: tenderReqList,
                        toDoTaskList: [...toDoTaskList, ...tenderTodoTaskList],
                    }
                    setCalendarData(obj)
                    setFilterVal(obj)
                    await getPriorityList()
                    // await fetchDataForMonth(monthVal)
                } else {
                    setCalendarData([])
                }
            } catch (error) {
                console.log('error')
            }
        } else if (activeTabKey === '2') {

            const formData = new URLSearchParams();
            formData.append('date', val);
            // formData.append('user_id', userVal)
            userVal?.length > 0 && formData.append('user_id', userVal?.join(','))


            try {
                let result = await DashboardServiceApi.deptCalendarByDate(formData);
                if (result?.data?.status === '1') {
                    const extractedData = result?.data?.data?.filter(item => item !== null)
                    setDeptData(extractedData)
                    return extractedData
                } else {
                    setDeptData([])
                }
            } catch (error) {
                console.log('error')
                setDeptData([])
            }
        } else {
            return;
        }

    }

    const filterDataByUser = () => {
        if (extractUser?.length > 0) {
            const filteredUser = deptData?.filter(item => extractUser?.includes(item?.id))

            let filterMeetingList = []
            let filterTenderDataList = []
            let filterTenderReqList = []
            let filterTodoTaskList = []
            let filterTenderTodoTaskList = []
            let filterPrebid_data = []

            filteredUser?.map((item) => {
                if (item?.meetingList?.length > 0) {
                    item?.meetingList?.map((val) => {
                        filterMeetingList.push(val)
                    })
                }
                if (item?.tenderDataList?.length > 0) {
                    item?.tenderDataList?.map((val) => {
                        filterTenderDataList.push(val)
                    })
                }
                if (item?.tenderReqList?.length > 0) {
                    item?.tenderReqList?.map((val) => {
                        filterTenderReqList.push(val)
                    })
                }
                if (item?.todoTaskList?.length > 0) {
                    item?.todoTaskList?.map((val) => {
                        filterTodoTaskList.push(val)
                    })
                }
                if (item?.tenderTodoTaskList?.length > 0) {
                    item?.tenderTodoTaskList?.map((val) => {
                        filterTenderTodoTaskList.push(val)
                    })
                }
                if (item?.prebid_data?.length > 0) {
                    item.prebid_data?.map((val) => {
                        filterPrebid_data.push(val)
                    })
                }

            })
            const obj = {
                meetingList: filterMeetingList,
                prebid_data: filterPrebid_data,
                tenderDataList: filterTenderDataList,
                tenderReqList: filterTenderReqList,
                toDoTaskList: [...filterTodoTaskList, ...filterTenderTodoTaskList],
            }

            setCalendarData(obj)
            setFilterVal(obj)


            getPriorityList()
        } else {
            setCalendarData([])
            setFilterVal([])
        }

    }


    useEffect(() => {
        if (extractUser !== undefined && extractUser !== null) {
            filterDataByUser()
        }
    }, [extractUser])

    // get event on click
    const handleSelect = async (event) => {

        const dateVal = dayjs(event?.slots[0]).format('YYYY-MM-DD');
        const clickMonth = dayjs(event?.slots[0]).format('MMMM');
        const date = new Date(checkDateWhileToggle);
        const options = { month: 'long' };
        const formattedMonth = date.toLocaleDateString('en-US', options);
        const selectedDate = moment(event?.slots[0]);
        setSelectedDate(selectedDate);

        if (clickMonth === formattedMonth) {

            const response = await fetchCalendardata(dateVal)
            if (activeTabKey === '2') {
                let userlistt
                if (userVal?.length > 0) {
                    userlistt = userOptions?.filter(item => userVal.includes(item?.value)).map(cur => cur?.value)
                } else {
                    userlistt = response?.filter(item => {
                        return (
                            item.meetingList.length > 0 ||
                            item.prebid_data.length > 0 ||
                            item.tenderDataList.length > 0 ||
                            item.tenderReqList.length > 0 ||
                            item.tenderTodoTaskList.length > 0 ||
                            item.toDoTaskList.length > 0
                        )
                    }).map(cur => cur?.id)
                }
                setExtractUser(userlistt)
            }
            setCalenderDetail(true)
        } else {
            setCalenderDetail(false)
            setExtractUser(null)
        }
    };


    //date format
    const { formats } = useMemo(
        () => ({
            formats: {
                dateFormat: (date, culture, localizer) =>
                    localizer.format(date, 'D', culture),
            },
        }),
        []

    )
    const dayPropGetter = (date) => {


        const dayProps = {};
        if (selectedDate && date.getDate() === selectedDate?.date() && selectedDate?.month() === date?.getMonth()) {
            dayProps.className = 'your-custom-class';
        }
        return dayProps;
    };
    // prebid_data
    const eventPropGetter = useCallback(

        (event) =>
        ({
            ...(event.type === "meetingList" && {
                className: 'green',
            }),

            ...(event.type === "tenderDataList" && {
                className: 'orange',
            }),

            ...(event.type === "tenderReqList" && {
                className: 'blue',
            }),

            ...((event.type === "toDoTaskList") && {
                className: 'yellow',
            }),
            ...(event.type === "prebid_data" && {
                className: 'grey',
            }),
        }),
        []
    )

    const handleFilterEvent = (e) => {
        setFilterEvent(e)
        if (e === 'all') {
            setCalendarData(filterVal)
        } else {
            setCalendarData({ [e]: filterVal[e] })
        }
    }


    const handleDownloadPdf = async (item) => {
        const apiUrl = `${docurlchat}${item?.file_path}/${item?.file_name}`;
        const fullUrl = window.location.href;
        const urlObject = new URL(fullUrl);
        const protocol = urlObject.protocol;
        const hostname = urlObject.host;
        const domain = `${protocol}//${hostname}`;
        const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
        const response = await fetch(proxyUrl)
        const blobData = await response?.blob()
        const fileURL = window.URL.createObjectURL(blobData);
        let alink = document.createElement("a");
        alink.href = fileURL;
        alink.download = item?.file_name;
        alink.click();

    }



    const fetchInitialPersonalCalendar = async () => {
        const date = new Date();
        const dateString = date.toString();
        let finalAccelatedDate = checkDateWhileToggle ? checkDateWhileToggle : dateString
        const fetchInitialEvents = await fetchDataForMonth(finalAccelatedDate, null)
        fetchEventsFromCalendar(fetchInitialEvents)
    }

    const fetchInitialDeptCalendar = async () => {
        const date = new Date();
        const dateString = date.toString();
        let finalAccelatedDate = checkDateWhileToggle ? checkDateWhileToggle : dateString
        const fetchInitialEvents = await fetchDeptCalendar(finalAccelatedDate, null, userVal)
        fetchEventsFromCalendar(fetchInitialEvents)
    }

    useEffect(() => {
        if (activeTabKey === '1') {
            fetchInitialPersonalCalendar()
        }
    }, [activeTabKey])

    useEffect(() => {
        if (activeTabKey === '2') {
            fetchInitialDeptCalendar()
        }
    }, [userVal, activeTabKey])

    // problem is when userval is changed then the calender api is taking in the current date

    const fetchEventsFromCalendar = (calendarEvents) => {
        setEvents(calendarEvents?.events)
        setCheckDateWhileToggle(calendarEvents?.month)
    }

    const handleUserChange = (e) => {
        setExtractUser(e)
        // filterDataByUser(e)
    }
    function formatDateUtcWithMonthName(dateString) {
        if (dateString) {
            const monthNames = [
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'Sept', 'Oct', 'Nov', 'Dec'
            ];

            const date = new Date(dateString);
            const day = date.getUTCDate().toString().padStart(2, '0');
            const month = monthNames[date.getUTCMonth()];
            const year = date.getUTCFullYear();
            // const hours = date.getUTCHours().toString().padStart(2, '0');
            // const minutes = date.getUTCMinutes().toString().padStart(2, '0');
            // const seconds = date.getUTCSeconds().toString().padStart(2, '0');
            return `${day} ${month} ${year}`;
        } else {
            return '';
        }
    }

    const renderCalendar = useMemo(() => {
        return (
            <Calendar
                localizer={localizer}
                views={["month"]}
                components={{
                    toolbar: (toolbarProps) => (
                        <CustomToolbar
                            {...toolbarProps}
                            fetchEventsFromCalendar={fetchEventsFromCalendar}
                            activeTabKey={activeTabKey}
                            userVal={userVal}
                        />
                    ),
                }}
                defaultView="month"
                events={events}
                style={{ height: 500 }}
                selectable
                onSelectSlot={handleSelect}
                dayPropGetter={dayPropGetter}
                min={firstDayOfMonth.toDate()}
                max={lastDayOfMonth.toDate()}
                showAllEvents
                tooltipAccessor='description'
                formats={formats}
                eventPropGetter={eventPropGetter}


            />
        )
    }, [events])


    // fetch todo document list
    const fetchDocumentTask = async () => {
        try {
            const response = await TodoServices.getTodoDocumentList()
            if (response?.data?.status === '1') {
                setDocumentData(response?.data?.data)
            } else {
                setDocumentData([])
            }
        } catch (error) {
            return []
        }

    }

    useEffect(() => {
        if (calenderDetail) {
            fetchDocumentTask()
        }
    }, [calenderDetail])


    // todo navigation tender and normal
    const handleNavigate = (val) => {

        if (val?.project_id) {
            const obj = {
                item: val,
                type: 'tender_todo_comments',
                key: val.id
            }
            dispatch(navigationData.setNavigationDataAction(obj))

            navigate(ROUTES.BD_TENDERDETAILS.replace(':id', val?.project_id));
        } else {
            const obj = {
                item: val,
                type: null,
                key: val.id
            }
            dispatch(navigationData.setNavigationDataAction(obj))
            navigate('/bidgrid/todo');
        }
    }
    // request navigation 
    const handleRequestNavigate = (val) => {
        const obj = {
            item: val,
            type: 'tender_request',
            key: val.id
        }
        dispatch(navigationData.setNavigationDataAction(obj))
        navigate(ROUTES.BD_TENDERDETAILS.replace(':id', val?.tender_id));
    }

    const handleMeetingNavigate = (val) => {
        const obj = {
            item: val,
            type: 'meeting_schedule',
            key: val.id
        }
        dispatch(navigationData.setNavigationDataAction(obj))
        navigate(ROUTES.BD_TENDERDETAILS.replace(':id', val?.project_id));
    }


    const avatarColor = "#8d8d8d"

    const actionColor = "#8d8d8d"


    useEffect(() => {

        if (calendarData?.tenderReqList?.length > 0) {
            // Initialize statusData with initial status for each request item
            setStatusData(calendarData?.tenderReqList?.map(item => item?.curr_status));
        }
    }, [calendarData]);

    useEffect(() => {
        console.log(employeeList)
    }, [employeeList])
    return (
        <>
            <div className="bd_dashboard_calendar_event">
                {/* {refresh()} */}
                {renderCalendar}
            </div>


            <Drawer className='bd_Drawer_calendar' closeIcon={<img src={skipBack} alt='' />} title={selectedDate !== null ? selectedDate?.format("MMMM D, YYYY") : ''} placement="right" onClose={() => { setCalenderDetail(false); setFilterEvent('all'); setExtractUser(null) }}
                open={calenderDetail} width={660}
                extra={
                    activeTabKey === '2' ?

                        <div>
                            <Select
                                showSearch
                                allowClear
                                mode="multiple"
                                optionFilterProp="children"
                                placeholder='Filter by User'
                                options={
                                    userVal?.length > 0 ?
                                        userOptions?.filter(item => userVal.includes(item?.value))
                                        :
                                        deptData.filter(item => {
                                            return (
                                                item.meetingList.length > 0 ||
                                                item.prebid_data.length > 0 ||
                                                item.tenderDataList.length > 0 ||
                                                item.tenderReqList.length > 0 ||
                                                item.tenderTodoTaskList.length > 0 ||
                                                item.toDoTaskList.length > 0
                                            )
                                        })?.map((item) => (
                                            {
                                                label: item?.userfullname,
                                                value: item?.id

                                            }
                                        ))

                                }
                                value={extractUser}
                                onChange={(e) => handleUserChange(e)}
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            />
                        </div>
                        :
                        <></>
                }

            >

                <div className='filterTab_btn'>
                    {(filterVal?.meetingList?.length > 0 || filterVal?.tenderDataList?.length > 0 || filterVal?.tenderReqList?.length > 0 || filterVal?.toDoTaskList?.length > 0) &&
                        < button className={filterEvent === 'all' ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => handleFilterEvent('all')} >All </button>
                    }
                    {filterVal?.meetingList?.length > 0 && <button className={filterEvent === 'meetingList' ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => handleFilterEvent('meetingList')}>Meetings {`(${filterVal?.meetingList?.length})`}</button>}
                    {filterVal?.prebid_data?.length > 0 && <button className={filterEvent === 'prebid_data' ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => handleFilterEvent('prebid_data')}>Pre Bid Data {`(${filterVal?.prebid_data?.length})`}</button>}
                    {filterVal?.tenderDataList?.length > 0 && <button className={filterEvent === 'tenderDataList' ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => handleFilterEvent('tenderDataList')}>Tender Data {`(${filterVal?.tenderDataList?.length})`}</button>}
                    {filterVal?.tenderReqList?.length > 0 && <button className={filterEvent === 'tenderReqList' ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => handleFilterEvent('tenderReqList')}>Tender Request {`(${filterVal?.tenderReqList?.length})`}</button>}
                    {filterVal?.toDoTaskList?.length > 0 && <button className={filterEvent === 'toDoTaskList' ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => handleFilterEvent('toDoTaskList')}>ToDo Task {`(${filterVal?.toDoTaskList?.length})`}</button>}
                </div>



                <div className="todo_container" style={{ padding: 0 }}>

                    {
                        calendarData?.meetingList?.length > 0 || calendarData?.prebid_data?.length > 0 || calendarData?.tenderDataList?.length > 0 || calendarData?.tenderReqList?.length > 0 || calendarData?.toDoTaskList?.length > 0 ?


                            <div className="p-4">
                                {/* meeting data */}

                                {calendarData?.meetingList?.length > 0 ? <h4 className="event_title"> <img src={arrowIcon} /> Meeting List</h4> : ''}
                                {
                                    calendarData?.meetingList?.map((item, index) => {
                                        return (
                                            <>
                                                <div onClick={() => handleMeetingNavigate(item)} className="Calender_Zoom_Meeting">
                                                    <div className="wrap_Zoom">
                                                        <div className="Zoom_date">
                                                            <h3>Type - <span>{item?.meeting_type === '1' ? 'Online' : 'Offline'}</span></h3>
                                                            <h3>Date - <span>{item?.meeting_date !== null ? `${dayjs(item?.meeting_date).format('YYYY-MM-DD')} ${TimeConverter(item?.start_time)}` : '-'}</span></h3>

                                                        </div>
                                                        <div className="Zoom_title"><h2>{item?.meeting_title} </h2></div>
                                                        <div className="Zoom_detail">
                                                            <p>{item?.meeting_discerption}</p>
                                                        </div>
                                                        <Divider />

                                                        {

                                                            item?.meeting_type === '1' ?
                                                                <div className="Zoom_link"><span> </span> <Link to={item?.meeting_link} target="_blank">{item?.meeting_link}</Link></div>
                                                                :
                                                                <p><span>Address - </span>{item?.meeting_address}</p>
                                                        }

                                                    </div>

                                                </div>

                                            </>
                                        )
                                    })

                                }

                                {/* pre bid data List */}

                                {calendarData?.prebid_data?.length > 0 ? <h4 className="event_title"> <img src={arrowIcon} /> Pre Bid Data List</h4> : ''}

                                {
                                    calendarData?.prebid_data?.map((item, index) => {
                                        return (
                                            <>

                                                <Link to={ROUTES.BD_TENDERDETAILS.replace(':id', item?.id)} >

                                                    <div className="bd_dashboard_calendar_eventdetails mb-4 mt-3">
                                                        <div className="event-details">

                                                            <div className="event_inner_wrapper">
                                                                <div className="bd_dpt_card tndDataBorder">
                                                                    <h5 className="bd_dpt_card_info_heading">{item?.tender_name?.replace(/<[^>]*>/g, '')}</h5>
                                                                    <hr />
                                                                    <div className="bd_submit_date">
                                                                        <span className="bd_dpt_card_info">Submission End Date : </span>
                                                                        <span className="bd_dpt_card_info"> {item?.submission_end_date !== null ? dayjs(item?.submission_end_date).format('YYYY-MM-DD') : '-'}</span>
                                                                    </div>

                                                                </div>


                                                            </div >
                                                        </div >
                                                    </div >
                                                </Link >
                                            </>
                                        )
                                    })
                                }

                                {/* Tender Data List */}

                                {calendarData?.tenderDataList?.length > 0 ? <h4 className="event_title"> <img src={arrowIcon} /> Tender Data List</h4> : ''}

                                {
                                    calendarData?.tenderDataList?.map((item, index) => {
                                        return (
                                            <>

                                                <Link to={ROUTES.BD_TENDERDETAILS.replace(':id', item?.id)} >

                                                    <div className="bd_dashboard_calendar_eventdetails mb-4 mt-3">
                                                        <div className="event-details">

                                                            <div className="event_inner_wrapper">
                                                                <div className="bd_dpt_card tndDataBorder">
                                                                    <span className="bd_dpt_card_info">{item?.generated_tender_id}</span>
                                                                    <h5 className="bd_dpt_card_info_heading">{item?.tender_name?.replace(/<[^>]*>/g, '')}</h5>
                                                                    {/* <p className="bd_dpt_card_info">{item?.tender_name?.replace(/<[^>]*>/g, '')}</p> */}
                                                                    <hr />
                                                                    <div className="bd_submit_date">
                                                                        <span className="bd_dpt_card_info">Submission End Date : </span>
                                                                        <span className="bd_dpt_card_info"> {item?.submission_end_date !== null ? dayjs(item?.submission_end_date).format('YYYY-MM-DD') : '-'}</span>
                                                                    </div>

                                                                </div>


                                                            </div>
                                                        </div>
                                                    </div>
                                                </Link>
                                            </>
                                        )
                                    })
                                }


                                {/* Tender Request List */}

                                {calendarData?.tenderReqList?.length > 0 ? <h4 className="event_title"><img src={arrowIcon} /> Tender Request List</h4> : ''}

                                {
                                    calendarData?.tenderReqList?.map((item, index) => {
                                        const requestTo = employeeList?.filter(val => val?.id === item?.req_to_userid)?.map(items => items?.userfullname)

                                        const createdBy = employeeList?.filter(val => val?.id === item?.created_by)?.map(items => items?.userfullname)

                                        return (
                                            <>
                                                <div className='bd_req_drw_main dashBorad_request' onClick={() => handleRequestNavigate(item)}>
                                                    <div className="subject">Subject - <span>{item?.subject} </span></div>

                                                    <div className='desc_req_drawer'>
                                                        <div className='tenderTitle'>{item?.desc_details.replace(/<[^>]*>/g, '')}</div>
                                                        <div className='desc_pera_drwer'>Comment Text - <span>{item?.comment_txt}</span></div>
                                                        <div className='desc_pera_drwer'>
                                                            <div style={{ cursor: 'pointer' }} onClick={() => handleDownloadPdf(item)}>
                                                                <img className='img_bg_color' src={file} style={{ marginRight: '10px' }} />
                                                                Download Attached File
                                                            </div>
                                                        </div>


                                                    </div>

                                                    <div className="req_flex">
                                                        <div className='desc_pera_drwer'>Request To - <span>{requestTo}</span></div>
                                                        <div className='desc_pera_drwer'>Created By - <span>{createdBy}</span></div>
                                                    </div>

                                                    <div className='bd_rq_drawer'>
                                                        {/* <div>
                                                            <Select
                                                                className={item?.curr_status === "3" ? 'approved' : item?.curr_status === "1" ? 'pending' : 'submitted'}
                                                                placeholder="Enter here"
                                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                                optionFilterProp="label"
                                                                options={userBidInfo?.id === item?.created_by ? createdByOption : (userBidInfo?.id === item?.req_to_userid && item?.curr_status !== '3') ? assignedToOption : createdByOption}
                                                                onChange={(e) => requestStatus(item, e)}
                                                                value={item?.curr_status}
                                                                disabled={(userBidInfo?.id !== item?.created_by && userBidInfo?.id !== item?.req_to_userid) || item?.curr_status === '3' ? true : false}
                                                            />
                                                        </div> */}
                                                        <div className={`req_status ${item?.curr_status === '1' ? 'pending' : item?.curr_status === '2' ? 'submitted' : 'approval'}`}>{item?.curr_status === '1' ? 'Pending' : item?.curr_status === '2' ? 'Submitted' : 'Approval'}</div>
                                                        <div className="reqDate">Date - <span>{item?.created_at !== null ? `${dayjs(item?.created_at).format('YYYY-MM-DD')} ${TimeConverter(item?.created_at)}` : '-'}</span></div>
                                                    </div>
                                                </div>

                                            </>
                                        )
                                    })
                                }


                                {/*  Todo task List */}
                                {calendarData?.toDoTaskList?.length > 0 ? <h4 className="event_title"><img src={arrowIcon} /> Todo Task List</h4> : ''}

                                {
                                    calendarData?.toDoTaskList?.map((item, index) => {
                                        const assignedUserIds = item?.hasOwnProperty('assign_user_list') ? item?.assign_user_list?.map(val => val?.assigned_to_userid) : item?.assigned_users?.map(val => val?.assigned_to_userid)
                                        const filteredUserObjects = employeeList?.filter(user => assignedUserIds?.includes(user?.id));
                                        return (
                                            <>


                                                <StyledCard
                                                    onClick={() => handleNavigate(item)}
                                                    className={`todo_card-box-bd border ${priorityList?.find(val => val?.id === item?.task_priority)?.task_priority_name === "High"
                                                        ? "borderRed highPriority"
                                                        : priorityList?.find(val => val?.id === item?.task_priority)?.task_priority_name === "Low"
                                                            ? "borderGreen lowPriority"
                                                            : priorityList?.find(val => val?.id === item?.task_priority)?.task_priority_name === "Medium"
                                                                ? "borderOrange mediumPriority"
                                                                : ""
                                                        }`}
                                                    size="small"
                                                    title={
                                                        // <span>
                                                        //     <TaskboardItemCardTitle level={5} ellipsis={{ rows: 2 }}>
                                                        //         <div className='prioity_todo_list'>
                                                        //             <div className='todo_prioity_level'>
                                                        //                 <span>Priority</span>
                                                        //                 <div className='todo_level_token todo_low_token'>
                                                        //                     <span>{priorityList?.find(val => val?.id === item?.task_priority)?.task_priority_name}</span>
                                                        //                 </div>
                                                        //             </div>
                                                        //         </div>

                                                        //     </TaskboardItemCardTitle>
                                                        // </span>

                                                        <div className='priority-col'>
                                                            Priority: {priorityList?.find(val => val?.id === item?.task_priority)?.task_priority_name}
                                                        </div>
                                                    }
                                                >
                                                    <div className='todo_heading_coont'>
                                                        <span>{item?.task_name}</span>
                                                    </div>
                                                    <div className='pra-box'>

                                                        <p> {capitalizeExceptPrepositionsAndLowerCase(item?.task_description)}</p>

                                                    </div>

                                                    <div className='todo_hashtag_container'>
                                                        {item?.hash_tags?.split(',')?.slice(0, 4).map((item, index) => (
                                                            <div className='todo_hashtag' >
                                                                <span>{item}</span>
                                                            </div>
                                                        ))}
                                                        {item?.hash_tags?.split(',')?.length > 4 && (
                                                            <div className='todo_hashtag'>
                                                                <span>...+{item?.hash_tags?.split(',').length - 4}</span>
                                                            </div>
                                                        )}
                                                    </div>


                                                    <div className='card-box'>
                                                        <div className='box-content'>

                                                            {
                                                                item?.updated_at !== null ?
                                                                    <div className='date-box'>
                                                                        <div className='icon-title'>
                                                                            <ClockCircleOutlined className='date-box-icon' /> Last Updated:
                                                                        </div>
                                                                        <div>
                                                                            <span> {item?.updated_at !== null ? `${formatDateUtcWithMonthName(item?.updated_at)} ${TimeConverter(item?.updated_at)}` : ' - '} {item?.modified_by !== null && 'By'}  {employeeList?.find(val => val?.id === item?.modified_by)?.userfullname}
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    :
                                                                    <></>
                                                            }

                                                            {
                                                                item?.deadline_date !== null ?
                                                                    <div className='date-box'>
                                                                        <div className='icon-title'>
                                                                            <ClockCircleOutlined className='date-box-icon' /> Deadline:
                                                                        </div>
                                                                        <div>
                                                                            <span> {item?.deadline_date !== null ? `${formatDateUtcWithMonthName(item?.deadline_date)} ${TimeConverter(item?.deadline_date)}` : ' - '}
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    :
                                                                    <></>
                                                            }



                                                            <div className='bd_avatar_grp'>
                                                                <div>
                                                                    <Avatar.Group
                                                                        // maxCount={1}
                                                                        maxPopoverTrigger="click"
                                                                        size="large"
                                                                        maxStyle={{ color: avatarColor, backgroundColor: avatarColor, cursor: 'pointer' }}
                                                                    >
                                                                        {
                                                                            filteredUserObjects?.slice(0, 2).map((item, index) => (
                                                                                <Tooltip key={index} title={item?.userfullname} placement="top">
                                                                                    <Avatar style={{ backgroundColor: avatarColor }}>
                                                                                        {item?.userfullname.charAt(0)}
                                                                                    </Avatar>
                                                                                </Tooltip>
                                                                            ))
                                                                        }
                                                                        {filteredUserObjects && filteredUserObjects.length > 2 && (
                                                                            <Tooltip title={filteredUserObjects?.slice(2)?.map(item => item?.userfullname).join(', ')} placement="right">

                                                                                <Avatar style={{ backgroundColor: avatarColor }}>
                                                                                    +{filteredUserObjects?.length - 2}
                                                                                </Avatar>
                                                                            </Tooltip>
                                                                        )}
                                                                    </Avatar.Group>
                                                                </div>


                                                                <div className='todo_attachment_cont'>
                                                                    {
                                                                        documentData?.filter(val => val?.task_name === item?.task_name)?.map(item_a => item_a?.todo_comment_documents?.length) > 0 ?
                                                                            <div className='todo_attachment_span' style={{ border: `1px solid ${actionColor}`, borderRadius: 6, padding: 6 }} >
                                                                                {/* <img src={attachment} alt='attack file' width={25} /> */}
                                                                                <svg width="14" height="15" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <g clip-path="url(#clip0_2324_729)">
                                                                                        <path d="M0.560059 0.630371V5.39034C0.560059 5.95141 0.782945 6.48951 1.17969 6.88625C1.57643 7.28299 2.11452 7.50588 2.6756 7.50588C3.23667 7.50588 3.77477 7.28299 4.17151 6.88625C4.56825 6.48951 4.79114 5.95141 4.79114 5.39034V2.21703C4.79114 1.93649 4.6797 1.66744 4.48132 1.46907C4.28295 1.2707 4.01391 1.15926 3.73337 1.15926C3.45283 1.15926 3.18378 1.2707 2.98541 1.46907C2.78704 1.66744 2.6756 1.93649 2.6756 2.21703V5.91922M6.37779 1.15926H13.2533C13.5338 1.15926 13.8029 1.2707 14.0013 1.46907C14.1996 1.66744 14.3111 1.93649 14.3111 2.21703V14.9103C14.3111 15.1908 14.1996 15.4599 14.0013 15.6582C13.8029 15.8566 13.5338 15.968 13.2533 15.968H2.6756C2.39506 15.968 2.12601 15.8566 1.92764 15.6582C1.72927 15.4599 1.61783 15.1908 1.61783 14.9103V9.09253M11.6666 5.39034H7.43556M11.6666 8.56365H7.43556M11.6666 11.737H4.26225" stroke={actionColor} stroke-width="1.05777" />
                                                                                    </g>
                                                                                    <defs>
                                                                                        <clipPath id="clip0_2324_729">
                                                                                            <rect width="15.8665" height="15.8665" fill="white" transform="translate(0.0307617 0.630371)" />
                                                                                        </clipPath>
                                                                                    </defs>
                                                                                </svg>

                                                                                <span className='ms-1' style={{ color: actionColor, fontSize: 11 }}>{documentData?.filter(val => val?.task_name === item?.task_name)?.map(item_b => item_b?.todo_comment_documents?.length)}</span>
                                                                            </div>
                                                                            :
                                                                            <></>
                                                                    }
                                                                    {
                                                                        item?.taskcommentCount !== 0 ?
                                                                            <div style={{ border: `1px solid ${actionColor}`, borderRadius: 6, padding: 6 }} className='todo_comment_span'>
                                                                                {/* <img src={Comments} alt='comment' width={25} onClick={handleComment} /> */}
                                                                                <svg width="18" height="18" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M6.09313 11.8032H14.357C14.4743 11.8032 14.5726 11.7638 14.652 11.685C14.7308 11.6057 14.7701 11.5073 14.7701 11.39C14.7701 11.2726 14.7308 11.1743 14.652 11.095C14.5726 11.0162 14.4743 10.9768 14.357 10.9768H6.09313C5.97578 10.9768 5.87744 11.0162 5.79811 11.095C5.71933 11.1743 5.67994 11.2726 5.67994 11.39C5.67994 11.5073 5.71933 11.6057 5.79811 11.685C5.87744 11.7638 5.97578 11.8032 6.09313 11.8032ZM6.09313 9.32403H14.357C14.4743 9.32403 14.5726 9.28464 14.652 9.20586C14.7308 9.12652 14.7701 9.02818 14.7701 8.91084C14.7701 8.79349 14.7308 8.69515 14.652 8.61582C14.5726 8.53704 14.4743 8.49765 14.357 8.49765H6.09313C5.97578 8.49765 5.87744 8.53704 5.79811 8.61582C5.71933 8.69515 5.67994 8.79349 5.67994 8.91084C5.67994 9.02818 5.71933 9.12652 5.79811 9.20586C5.87744 9.28464 5.97578 9.32403 6.09313 9.32403ZM6.09313 6.84488H14.357C14.4743 6.84488 14.5726 6.80549 14.652 6.72671C14.7308 6.64738 14.7701 6.54904 14.7701 6.43169C14.7701 6.31434 14.7308 6.216 14.652 6.13667C14.5726 6.05789 14.4743 6.0185 14.357 6.0185H6.09313C5.97578 6.0185 5.87744 6.05789 5.79811 6.13667C5.71933 6.216 5.67994 6.31434 5.67994 6.43169C5.67994 6.54904 5.71933 6.64738 5.79811 6.72671C5.87744 6.80549 5.97578 6.84488 6.09313 6.84488ZM4.12221 14.6955C3.74207 14.6955 3.42474 14.5683 3.17021 14.3137C2.91514 14.0587 2.7876 13.741 2.7876 13.3609V4.46077C2.7876 4.08063 2.91514 3.7633 3.17021 3.50877C3.42474 3.2537 3.74207 3.12616 4.12221 3.12616H16.3279C16.708 3.12616 17.0253 3.2537 17.2799 3.50877C17.535 3.7633 17.6625 4.08063 17.6625 4.46077V15.6318C17.6625 15.9293 17.5256 16.1345 17.2518 16.2475C16.978 16.3604 16.7367 16.3125 16.5279 16.1037L15.1197 14.6955H4.12221ZM15.4726 13.8691L16.8361 15.2277V4.46077C16.8361 4.33406 16.7832 4.21754 16.6774 4.11121C16.5711 4.00543 16.4546 3.95254 16.3279 3.95254H4.12221C3.99549 3.95254 3.87897 4.00543 3.77265 4.11121C3.66687 4.21754 3.61398 4.33406 3.61398 4.46077V13.3609C3.61398 13.4876 3.66687 13.6041 3.77265 13.7105C3.87897 13.8162 3.99549 13.8691 4.12221 13.8691H15.4726Z" fill={actionColor} />
                                                                                </svg>
                                                                                <span className='ms-1' style={{ color: actionColor, fontSize: 11 }}>{item?.taskcommentCount}</span>
                                                                            </div>
                                                                            :
                                                                            <div style={{ border: `1px solid ${actionColor}`, borderRadius: 6, padding: 6 }} className='todo_comment_span'>
                                                                                {/* <img src={Comments} alt='comment' width={25} onClick={handleComment} /> */}
                                                                                <svg width="18" height="18" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M6.09313 11.8032H14.357C14.4743 11.8032 14.5726 11.7638 14.652 11.685C14.7308 11.6057 14.7701 11.5073 14.7701 11.39C14.7701 11.2726 14.7308 11.1743 14.652 11.095C14.5726 11.0162 14.4743 10.9768 14.357 10.9768H6.09313C5.97578 10.9768 5.87744 11.0162 5.79811 11.095C5.71933 11.1743 5.67994 11.2726 5.67994 11.39C5.67994 11.5073 5.71933 11.6057 5.79811 11.685C5.87744 11.7638 5.97578 11.8032 6.09313 11.8032ZM6.09313 9.32403H14.357C14.4743 9.32403 14.5726 9.28464 14.652 9.20586C14.7308 9.12652 14.7701 9.02818 14.7701 8.91084C14.7701 8.79349 14.7308 8.69515 14.652 8.61582C14.5726 8.53704 14.4743 8.49765 14.357 8.49765H6.09313C5.97578 8.49765 5.87744 8.53704 5.79811 8.61582C5.71933 8.69515 5.67994 8.79349 5.67994 8.91084C5.67994 9.02818 5.71933 9.12652 5.79811 9.20586C5.87744 9.28464 5.97578 9.32403 6.09313 9.32403ZM6.09313 6.84488H14.357C14.4743 6.84488 14.5726 6.80549 14.652 6.72671C14.7308 6.64738 14.7701 6.54904 14.7701 6.43169C14.7701 6.31434 14.7308 6.216 14.652 6.13667C14.5726 6.05789 14.4743 6.0185 14.357 6.0185H6.09313C5.97578 6.0185 5.87744 6.05789 5.79811 6.13667C5.71933 6.216 5.67994 6.31434 5.67994 6.43169C5.67994 6.54904 5.71933 6.64738 5.79811 6.72671C5.87744 6.80549 5.97578 6.84488 6.09313 6.84488ZM4.12221 14.6955C3.74207 14.6955 3.42474 14.5683 3.17021 14.3137C2.91514 14.0587 2.7876 13.741 2.7876 13.3609V4.46077C2.7876 4.08063 2.91514 3.7633 3.17021 3.50877C3.42474 3.2537 3.74207 3.12616 4.12221 3.12616H16.3279C16.708 3.12616 17.0253 3.2537 17.2799 3.50877C17.535 3.7633 17.6625 4.08063 17.6625 4.46077V15.6318C17.6625 15.9293 17.5256 16.1345 17.2518 16.2475C16.978 16.3604 16.7367 16.3125 16.5279 16.1037L15.1197 14.6955H4.12221ZM15.4726 13.8691L16.8361 15.2277V4.46077C16.8361 4.33406 16.7832 4.21754 16.6774 4.11121C16.5711 4.00543 16.4546 3.95254 16.3279 3.95254H4.12221C3.99549 3.95254 3.87897 4.00543 3.77265 4.11121C3.66687 4.21754 3.61398 4.33406 3.61398 4.46077V13.3609C3.61398 13.4876 3.66687 13.6041 3.77265 13.7105C3.87897 13.8162 3.99549 13.8691 4.12221 13.8691H15.4726Z" fill={actionColor} />
                                                                                </svg>
                                                                            </div>
                                                                    }

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </StyledCard>


                                            </>
                                        )
                                    })
                                }

                            </div >

                            :
                            <p> No Data Found</p>


                    }
                </div >



            </Drawer >
        </>
    );
};

export default CustomCalendar;
