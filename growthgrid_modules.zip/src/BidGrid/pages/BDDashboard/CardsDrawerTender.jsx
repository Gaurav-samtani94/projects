import React from 'react'
import { Drawer } from 'antd';
import 'react-loading-skeleton/dist/skeleton.css'
import skipBack from '../../assets/images/skip-back.png';
import ROUTES from 'Constants/Routes';
import dayjs from 'dayjs';
import { Link } from 'react-router-dom';
import { convertToIndianCurrencyFormat } from 'Tendergrids/components/convertAmt/convertToIndianCurrencyFormat';
import { TimeConverter } from 'BidGrid/components/TimeConverter/TimeConverter';

const CardsDrawerTender = (props) => {

    const { drawerTitle, onClose, setCardsType, cardsDetailDrawer, cardsType, cardRender, cardsDrawerData } = props


    function formatDateUtcWithMonthName(dateString) {
        if (dateString) {
            const monthNames = [
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'Sept', 'Oct', 'Nov', 'Dec'
            ];

            const date = new Date(dateString);
            const day = date.getUTCDate().toString().padStart(2, '0');
            const month = monthNames[date.getUTCMonth()];
            const year = date.getUTCFullYear();
            return `${day} ${month} ${year}`;
        } else {
            return '';
        }
    }

    return (
        <Drawer title={`${drawerTitle} Tenders`}
            className="bd_Drawer_calendar"
            closeIcon={<img src={skipBack} alt='' />}
            onClose={() => { onClose(); setCardsType('All') }}
            open={cardsDetailDrawer}
            width={600}

        >
            <>

                <div className="filterTab_btn">
                    <button className={cardsType === 'All' ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => setCardsType('All')} >All </button>
                    {
                        drawerTitle === 'To Be Submit' ?

                            <>
                                {
                                    Object.entries(cardRender?.filteredToBeSubmit)?.map(([key, value]) => ({ label: key?.slice(-3), value }))?.map(item => {
                                        return (
                                            <>

                                                {
                                                    item?.value !== 0 ?
                                                        <button className={cardsType === item?.label ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => setCardsType(item?.label)}>{`${item?.label} (${item?.value})`}</button>

                                                        :
                                                        <></>

                                                }

                                            </>
                                        )
                                    })
                                }
                            </>

                            :
                            drawerTitle === 'Submitted' ?

                                <>
                                    {
                                        Object.entries(cardRender?.filteredSubmitted)?.map(([key, value]) => ({ label: key?.slice(-3), value }))?.map(item => {
                                            return (
                                                <>

                                                    {
                                                        item?.value !== 0 ?
                                                            <button className={cardsType === item?.label ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => setCardsType(item?.label)}>{`${item?.label} (${item?.value})`}</button>

                                                            :
                                                            <></>

                                                    }

                                                </>
                                            )
                                        })
                                    }
                                </>

                                :
                                drawerTitle === 'Result Awaiting' ?


                                    <>
                                        {
                                            Object.entries(cardRender?.filteredAwaiting)?.map(([key, value]) => ({ label: key?.slice(-3), value }))?.map(item => {
                                                return (
                                                    <>

                                                        {
                                                            item?.value !== 0 ?
                                                                <button className={cardsType === item?.label ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => setCardsType(item?.label)}>{`${item?.label} (${item?.value})`}</button>

                                                                :
                                                                <></>

                                                        }

                                                    </>
                                                )
                                            })
                                        }
                                    </>

                                    :
                                    drawerTitle === 'Won' ?

                                        <>
                                            {
                                                Object.entries(cardRender?.filteredWon)?.map(([key, value]) => ({ label: key?.slice(-3), value }))?.map(item => {
                                                    return (
                                                        <>

                                                            {
                                                                item?.value !== 0 ?
                                                                    <button className={cardsType === item?.label ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => setCardsType(item?.label)}>{`${item?.label} (${item?.value})`}</button>

                                                                    :
                                                                    <></>

                                                            }

                                                        </>
                                                    )
                                                })
                                            }
                                        </>

                                        :
                                        <></>


                    }

                </div>

                <div className="p-4">
                    {cardsDrawerData?.filter((val) => cardsType !== 'All' ? val?.bg_assign_tndr_generated_id?.bg_mstr_tndr_generated_type?.generated_type === cardsType : val)?.map((item) => {
                        var createTextVersion = item?.tender_name.replace(/<[^>]*>/g, '');
                        return (
                            <Link to={ROUTES.BD_TENDERDETAILS.replace(':id', item?.id)} >
                                <div className="bd_dashboard_calendar_eventdetails mb-4">
                                    <div className="event-details">

                                        <div className="event_inner_wrapper">
                                            <div className="bd_dpt_card tndDataBorder">
                                                <h5 className="bd_dpt_card_info_heading">{createTextVersion}</h5>
                                                <hr />
                                                <div className="bd_submit_date">
                                                    <span className="bd_dpt_card_info">Tender Amount :  </span>
                                                    <span className="bd_dpt_card_info">{convertToIndianCurrencyFormat(item?.tender_emd_amnt_val)}</span>
                                                </div>
                                                <div className="bd_submit_date">
                                                    <span className="bd_dpt_card_info">Generated Tender : </span>
                                                    <span className="bd_dpt_card_info">{item?.bg_assign_tndr_generated_id?.bg_mstr_tndr_generated_type?.generated_type}</span>
                                                </div>
                                                <div className="bd_submit_date">
                                                    <span className="bd_dpt_card_info">Submission End Date : </span>
                                                    {/* <span className="bd_dpt_card_info">{item?.submission_end_date !== null ? dayjs(item?.submission_end_date).format('YYYY-MM-DD') : '-'}</span> */}
                                                    <span className="bd_dpt_card_info">{item?.submission_end_date !== null ? `${formatDateUtcWithMonthName(item?.submission_end_date)} ${TimeConverter(item?.submission_end_date)}` : '-'}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Link>
                        )
                    })}

                </div>

            </>



        </Drawer>
    )
}

export default CardsDrawerTender
