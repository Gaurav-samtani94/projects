// @ts-nocheck
import React, { useState, useEffect, useCallback } from 'react'
import { Select, Empty } from 'antd';
import { Avatar, Divider, Drawer, Row, Col, Form, Tabs } from 'antd';
import { Down } from '@icon-park/react';
import CustomCalendar from './CustomCalendar';
import PiChart from 'Statgrid/components/PiChart';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import skipBack from '../../assets/images/skip-back.png';
import ROUTES from 'Constants/Routes';
import { useSelector } from 'react-redux';
import { DashboardServiceApi } from 'Services/bidgrid/dashboard/DashboardAPi';
import TeamTaskDetail from './TeamTaskDetail';
import TenderRequest from '../BdTenderDetails/TenderRequest';
import ToDoDashBoard from './ToDoDashBoard';
import { LogoApi } from 'Services/bidgrid/master/company Logo/bidLogo';
import { userBidInfoAction } from 'Redux/actions/common/userInfoAction';
import { useDispatch } from 'react-redux';
import dayjs from 'dayjs';
import { Link } from 'react-router-dom';
import indiaIMg from '../../assets/images/icons/india.png';
import uaeImg from '../../assets/images/icons/uae.png';
import ukImg from '../../assets/images/icons/uk.png';
import { convertToIndianCurrencyFormat } from 'Tendergrids/components/convertAmt/convertToIndianCurrencyFormat';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import CardsDrawerTender from './CardsDrawerTender';
import { docurlchat } from 'utils/configurable';

const cardState = {
    filteredToBeSubmit: [],
    filteredSubmitted: [],
    filteredAwaiting: [],
    filteredWon: []
}

const initState = {
    india: '',
    uk: '',
    dubai: ''
}
const Dashboard = () => {
    // console.log("rendered")
    //states regarding the skeletons of the cards
    const [skeletonToBe, setSkeletonToBe] = useState(true)
    const [skeletonSub, setSkeletonSub] = useState(true)
    const [skeletonAwait, setSkeletonAwait] = useState(true)
    const [skeletonWon, setSkeletonWon] = useState(true)

    //Skeleton on My Task
    const [loading, setLoading] = useState(false);

    //drawer open
    const [teamTaskDrawerOpen, setTeamTaskDrawerOpen] = useState(false)
    const [cardsDetailDrawer, setCardsDetailDrawer] = useState(false);

    //containers used across dashboard
    const [widgetsByRoleList, setWidgetsByRoleList] = useState([]);
    const [employeeList, setEmployeeList] = useState([])
    const [employeeListTeam, setEmployeeListTeam] = useState([])
    //team task conatiners
    const [teamTaskWidget, setTeamTaskWidget] = useState({})
    const [teamTaskWidgetDetail, setTeamTaskWidgetDetail] = useState([])
    const [teamTaskBtn, setTeamTaskBtn] = useState('all')
    const [teamTaskHeaderBtn, setTamTaskHeaderBtn] = useState([])

    // redux containers of following user
    const { bidgridData } = useSelector((state) => state.loginData);
    const { userBidInfo } = useSelector((state) => state.userDetails)

    // hooks initialization
    const dispatch = useDispatch();

    // store day message
    const [message, setMessage] = useState('')

    //card tender state 
    const [toBeSubmitData, setToBeSubmitData] = useState({})
    const [submitedData, setSubmitedData] = useState({})
    const [resultAwaitingData, setResultAwaitingData] = useState({})
    const [wonData, setWonData] = useState({})
    const [cardsDrawerData, setCardsDrawerData] = useState([])
    const [cardsType, setCardsType] = useState('All')
    const [drawerTitle, setDrawerTitle] = useState('')
    const [cardRender, setCardRender] = useState(cardState)

    //calendar states
    const [activeCalendarBtn, setActiveCalendarBtn] = useState('1');
    const tabs = ["All", "On Going", "Submitted", "Awaiting", "Won", "Lost", "Cancelled"];
    const [activeTab, setActiveTab] = useState(0);

    // handle change states
    const [selectedEmployee, setSelectedEmployee] = useState([])

    // timezone states
    const [timeData, setTimeData] = useState(initState);
    // todo type change state
    const [todoTypeBtn, setTodoTypeBtn] = useState("1");


    // fetch widgets to render
    const fetchWidgetsByRole = async () => {
        setLoading(true)
        const user_role_id = bidgridData?.data?.emp_role_id;
        const formData = new URLSearchParams();
        formData.append('role_id', user_role_id);
        let result = await DashboardServiceApi.getWidgetByRole(formData);
        if (result?.data?.status === '1') {
            setLoading(false)
            let widgetsList = result?.data?.data?.map(item => item?.bg_mstr_widget?.widget_name);
            setWidgetsByRoleList(widgetsList);
        } else {
            console.log(result?.data?.message)
        }
    }

    // user list
    const fetchUserList = async () => {
        try {
            const response = await bidEmployeeList.getUserList()
            if (response?.data?.status === "1") {
                setEmployeeList(response?.data?.data)
            }
        } catch (error) {

        }
    }
    const fetchUserListByTeam = async () => {
        try {
            const response = await bidEmployeeList.getUserListTeam()
            if (response?.data?.status === "1") {
                setEmployeeListTeam(response?.data?.data)
            }
        } catch (error) {

        }
    }
    // team task list
    const fetchTeamTask = async () => {
        let result = await DashboardServiceApi.teamTaskList();
        if (result?.data?.status === '1') {
            setTeamTaskWidget(result?.data)
        } else {
            console.log(result?.data?.message)
        }

    }

    // team task detail 
    const fetchTeamTaskDetail = async (id) => {
        const formData = new URLSearchParams();
        formData.append('assign_to', id);
        let response = await DashboardServiceApi.teamTaskDetail(formData);
        if (response?.data?.status == 1) {
            const updatedData = response?.data?.data?.map(item => ({
                ...item,
                bg_mstr_bd_role: item?.bg_mstr_bd_role !== null
                    ? item?.bg_mstr_bd_role
                    : { role_name: 'Not Specified' }
            }));


            const counts = {};

            updatedData.forEach(item => {
                const roleName = item.bg_mstr_bd_role.role_name;
                counts[roleName] = (counts[roleName] || 0) + 1;
            });
            const resultArray = Object.entries(counts).map(([label, value]) => ({ label, value }));

            setTamTaskHeaderBtn(resultArray);
            setTeamTaskWidgetDetail(updatedData);
        } else {
            setTeamTaskWidgetDetail([])
        }

    }

    //Company Logo api 
    const CompanyLogo = async () => {
        try {
            const response = await LogoApi.getLogo()
            const responseThumb = await LogoApi.addThumbnail();
            if (response?.data?.status == 1 && responseThumb?.data?.status == 1) {
                dispatch(userBidInfoAction({
                    ...userBidInfo,
                    thumbnailPath: responseThumb?.data?.data?.thumbnail_file_path,
                    thumbnailName: responseThumb?.data?.data?.thumbnail_file_name,
                    docname: response.data.data?.logo_file_name,
                    docpath: response.data.data?.logo_file_path
                }))
            }
        } catch (error) {
            console.log(error)
        }
    };


    const userOptions = employeeListTeam?.map(item => {
        return {
            value: item?.id,
            label: item?.userfullname
        }
    })

    const handleUserName = (e) => {
        setSelectedEmployee(e)
    }


    const tabItems = [
        widgetsByRoleList?.includes('Personal Calendar') &&
        {
            key: '1',
            label: 'Personal Calendar',
            children: <div className="bd_calender">
                <div className="bd_dashboard_scheduler_calendar">
                    {activeCalendarBtn === '1' && <CustomCalendar employeeList={employeeList} activeTabKey={activeCalendarBtn} />}
                </div>
            </div>,
        },
        widgetsByRoleList?.includes('Department Calendar') &&
        {
            key: '2',
            label: 'Team Calendar',
            children: <div className="bd_calender">
                <div className="bd_dashboard_department_calendar">
                    <div className="d-flex">
                        <Form.Item>
                            <Select
                                allowClear
                                showSearch
                                mode="multiple"
                                // defaultValue={employeeListVal?.find(item => item?.id === userBidInfo?.id)?.id}
                                value={selectedEmployee}
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                placeholder="Search User"
                                optionFilterProp="children"
                                filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                                options={userOptions}
                                onChange={handleUserName}
                            />
                        </Form.Item>
                    </div>

                    <div className="custom-tabs">
                        {tabs?.map((tab, index) => (
                            <button
                                key={index}
                                className={`tab ${index === activeTab ? "active" : ""}`}
                                onClick={() => setActiveTab(index)}
                            >
                                {tab}
                            </button>
                        ))}
                    </div>

                </div>
                <div className="bd_dashboard_scheduler_calendar">
                    {activeCalendarBtn === '2' &&
                        <CustomCalendar activeTabKey={activeCalendarBtn} employeeList={employeeList} employeeListTeam={employeeListTeam} userVal={selectedEmployee} userOptions={userOptions} />}

                </div>
            </div>,
        },
    ];

    const updateLoader = (val) => {
        setLoading(val)
    }


    const taskTabItems = [
        widgetsByRoleList?.includes('My Task') &&
        {
            key: '1',
            label: 'My Task',
            children: <div style={{ position: "relative" }}>
                {
                    loading ?
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20 }}>
                            <Skeleton variant="rectangular" width={"100%"} height={240} />
                            <Skeleton variant="rectangular" width={"100%"} height={240} />
                            <Skeleton variant="rectangular" width={"100%"} height={240} />
                        </div>
                        :
                        <>
                            {todoTypeBtn == '1' ? <ToDoDashBoard getWidgetList={widgetsByRoleList} todoKey={todoTypeBtn} userOptions={userOptions} employeeListVal={employeeList} updateLoader={updateLoader} /> : null}</>
                }

            </div>,
        },
        widgetsByRoleList?.includes('My Team') &&
        {
            key: '2',
            label: 'Team Task',
            children: <div style={{ position: "relative" }}>
                {
                    loading ?
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20 }}>
                            <Skeleton variant="rectangular" width={"100%"} height={240} />
                            <Skeleton variant="rectangular" width={"100%"} height={240} />
                            <Skeleton variant="rectangular" width={"100%"} height={240} />
                        </div>
                        :
                        <>
                            {todoTypeBtn == '2' ? <ToDoDashBoard getWidgetList={widgetsByRoleList} todoKey={todoTypeBtn} userOptions={userOptions} employeeListVal={employeeList} updateLoader={updateLoader} /> : null}</>
                }

            </div>,
        },
    ];


    const handleChangeCounter = (e, val, rows, name) => {
        e.stopPropagation();
        setCardsType(val)
        setCardsDrawerData(rows)
        setCardsDetailDrawer(true);
        setDrawerTitle(name)
    }


    const fetchCardSubmittedDetails = async () => {
        try {
            setSkeletonSub(true)
            let result = await DashboardServiceApi.fetchSubmittedTenders();
            if (result?.data?.status === '1') {
                setSubmitedData(result?.data?.data)
                setSkeletonSub(false)
            } else {
                setSubmitedData([])
                setSkeletonSub(false)
            }
        } catch (error) {
            setSubmitedData([])
            setSkeletonSub(false)
            console.log(error)
        }
    }
    const fetchCardToBeSubmittedDetails = async () => {
        try {
            setSkeletonToBe(true)
            let result = await DashboardServiceApi.fetchToBeSubmittedTenders();
            if (result?.data?.status === '1') {

                setToBeSubmitData(result?.data?.data)
                setSkeletonToBe(false)
            } else {
                setToBeSubmitData([])
                setSkeletonToBe(false)
            }
        } catch (error) {
            setToBeSubmitData([])
            setSkeletonToBe(false)
            console.log(error)
        }
    }

    const fetchCardResultAwaiting = async () => {
        try {
            setSkeletonAwait(true)
            let result = await DashboardServiceApi.fetchAwaitingTenders();
            if (result?.data?.status === '1') {
                setResultAwaitingData(result?.data?.data)
                setSkeletonAwait(false)
            } else {
                setResultAwaitingData([])
                setSkeletonAwait(false)
            }
        } catch (error) {
            setResultAwaitingData([])
            setSkeletonAwait(false)
            console.log(error)
        }
    }
    const fetchCardResultWon = async () => {
        try {
            setSkeletonWon(true)
            let result = await DashboardServiceApi.fetchWonTenders();
            if (result?.data?.status === '1') {
                setWonData(result?.data?.data)
                setSkeletonWon(false)
            } else {
                setWonData([])
                setSkeletonWon(false)
            }
        } catch (error) {
            setWonData([])
            setSkeletonWon(false)
            console.log(error)
        }
    }


    useEffect(() => {
        let filteredToBeSubmit = {};
        let filteredSubmitted = {};
        let filteredAwaiting = {};
        let filteredWon = {};
        if (toBeSubmitData) {
            Object.keys(toBeSubmitData)?.forEach(key => {
                if (key !== 'toBeSubmittedAll') {
                    filteredToBeSubmit[key] = toBeSubmitData[key];
                }
            });
        }
        if (submitedData) {
            Object.keys(submitedData)?.forEach(key => {
                if (key !== 'toBeSubmittedAll') {
                    filteredSubmitted[key] = submitedData[key];
                }
            });
        }
        if (resultAwaitingData) {
            Object.keys(resultAwaitingData)?.forEach(key => {
                if (key !== 'count' && key !== 'rowdata') {
                    filteredAwaiting[key] = resultAwaitingData[key];
                }
            });
        }
        if (wonData) {
            Object.keys(wonData)?.forEach(key => {
                if (key !== 'count' && key !== 'rowdata') {
                    filteredWon[key] = wonData[key];
                }
            });
        }

        setCardRender({
            ...cardRender,
            filteredToBeSubmit: filteredToBeSubmit,
            filteredSubmitted: filteredSubmitted,
            filteredAwaiting: filteredAwaiting,
            filteredWon: filteredWon
        })

    }, [toBeSubmitData, submitedData, resultAwaitingData, wonData])


    // calling each apis of dashboard which will render first
    useEffect(() => {
        fetchWidgetsByRole();
        fetchTeamTask();
        fetchUserList();
        fetchUserListByTeam()
        CompanyLogo();
        fetchCardSubmittedDetails()
        fetchCardToBeSubmittedDetails()
        fetchCardResultAwaiting()
        fetchCardResultWon()

    }, [])

    // dashboard message effects
    useEffect(() => {
        const currentHour = new Date().getHours();
        const morningStart = 6; // 6:00 AM
        const noonStart = 12; // 12:00 PM
        const eveningStart = 18; // 6:00 PM

        // Check the current time against the defined time segments
        if (currentHour >= morningStart && currentHour < noonStart) {
            setMessage('Good Morning')
        } else if (currentHour >= noonStart && currentHour < eveningStart) {
            setMessage('Good Afternoon')
        } else {
            setMessage('Good Evening')
        }
    }, [])
    const getMinuteFromDate = (dateString) => {
        if (!dateString) {
            return null;
        }
        const minute = dateString.match(/\d{2}:\d{2}/)?.[0].split(':')[1];
        return minute ? parseInt(minute, 10) : null;
    };
    const fetchTime = useCallback(() => {
        const now = new Date();
        const indiaDate = now.toLocaleString('en-IN', {
            timeZone: 'Asia/Kolkata',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
        });
        const ukDate = now.toLocaleString('en-GB', {
            timeZone: 'Europe/London',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
        });
        const dubaiDate = now.toLocaleString('en-US', {
            timeZone: 'Asia/Dubai',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
        });

        const parts = dubaiDate?.split('/');
        const [timePart, amPmPart] = parts[2].split(',');
        const rearrangedUsaDate = `${parts[1]}/${parts[0]}/${timePart.toLowerCase()},${amPmPart.toLowerCase()}`;

        const prevMinute = getMinuteFromDate(timeData.india);
        const currentMinute = getMinuteFromDate(indiaDate);

        if (prevMinute !== currentMinute) {
            setTimeData({
                ...timeData,
                india: indiaDate,
                uk: ukDate,
                dubai: rearrangedUsaDate,
            });
        }
    }, [timeData]);

    // timezone updates
    useEffect(() => {
        const intervalId = setInterval(fetchTime, 1000);
        return () => clearInterval(intervalId);
    }, [fetchTime]);

    const handleTabChangeTodo = (key) => {
        setTodoTypeBtn(key);
    };

    const handleTabChangeCalendar = (key) => {
        setActiveCalendarBtn(key);
    };

    const handleDrawerTeamTask = () => {
        setTeamTaskDrawerOpen(true)
    }

    // card functions
    const showDrawer = (val, name) => {
        setCardsType('All')
        setDrawerTitle(name)
        setCardsDrawerData(val)
        if (val?.length > 0) {
            setCardsDetailDrawer(true);
        } else {
            setCardsDetailDrawer(false);
        }
    };
    const onClose = () => {
        setCardsDrawerData([])
        setCardsDetailDrawer(false);
    };

    useEffect(() => {
        if (widgetsByRoleList?.includes('Personal Calendar')) {
            setActiveCalendarBtn('1')
        } else {
            setActiveCalendarBtn('2')
        }
    }, [widgetsByRoleList])

    useEffect(() => {

        if (widgetsByRoleList?.includes('My Task')) {
            setTodoTypeBtn('1')
        } else {
            setTodoTypeBtn('2')
        }
    }, [widgetsByRoleList])
    return (
        <>
            {/* <Breadcrumb data={str} /> */}
            <div className='bd_main' >
                {/* card section */}
                <div className='bd_herosection'>
                    <div className='bd_heading'>
                        <h2>{message} {userBidInfo?.userfullname}</h2>
                        <div className='time_dashboard'>
                            <span><img src={indiaIMg} />{timeData?.india}</span>
                            <span><img src={uaeImg} />{timeData?.dubai}</span>
                            <span><img src={ukImg} />{timeData?.uk}</span>
                        </div>
                    </div>
                    <div className='bd_card_wrapper mt-5'>
                        <Row gutter={0}>

                            {
                                widgetsByRoleList?.includes('OnGoing Bidding Graph') ?
                                    <Col span={6}>
                                        {skeletonToBe ?
                                            <div className="bd_cards bg1">
                                                <div className="d-flex">
                                                    <Skeleton variant="rectangular" width={80} height={55} />
                                                    <span className='bd_cards_heading'>Submissions Pending</span>
                                                </div>
                                                <div style={{ display: 'flex', gap: '20px', paddingTop: '20px' }}>

                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                </div>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="128" height="106" viewBox="0 0 128 106" fill="none">
                                                    <rect x="36.9" y="-38.9" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="-0.9" y="0.9" width="84.6" height="84.6" transform="matrix(-1 0 0 1 131.4 -27.2)" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="58.5" y="-13.7001" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                </svg>
                                            </div>
                                            :
                                            <div className="bd_cards bg1" onClick={() => showDrawer(toBeSubmitData?.toBeSubmittedAll?.rows, 'To Be Submited')}>
                                                <div className="d-flex">
                                                    <h2>{toBeSubmitData?.toBeSubmittedAll?.count !== null && toBeSubmitData?.toBeSubmittedAll?.count !== 0 ? toBeSubmitData?.toBeSubmittedAll?.count : 0}</h2>
                                                    <span className='bd_cards_heading'>Submissions Pending</span>
                                                </div>
                                                <div className='bd_cards_content'>
                                                    <div className='bd_cards_btn'>
                                                        {
                                                            Object.entries(cardRender?.filteredToBeSubmit)?.map(([key, value]) => ({ label: key?.slice(-3), value }))?.map(item => {
                                                                return (
                                                                    <>
                                                                        {
                                                                            item?.value !== 0 ?
                                                                                <span onClick={(e) => handleChangeCounter(e, item?.label, toBeSubmitData?.toBeSubmittedAll?.rows, 'To Be Submited')}>{item?.label} <b>{item?.value || 0}</b></span>
                                                                                :
                                                                                <></>
                                                                        }
                                                                    </>
                                                                )
                                                            })
                                                        }
                                                    </div>
                                                </div>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="128" height="106" viewBox="0 0 128 106" fill="none">
                                                    <rect x="36.9" y="-38.9" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="-0.9" y="0.9" width="84.6" height="84.6" transform="matrix(-1 0 0 1 131.4 -27.2)" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="58.5" y="-13.7001" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                </svg>
                                            </div>
                                        }
                                    </Col>
                                    :
                                    <></>
                            }

                            {
                                widgetsByRoleList?.includes('Submitted Graph') ?

                                    <Col span={6}>
                                        {skeletonSub ?
                                            <div className="bd_cards bg2">
                                                <div className="d-flex">
                                                    <Skeleton variant="rectangular" width={80} height={55} />
                                                    <span className='bd_cards_heading'>Submissions Completed</span>
                                                </div>
                                                <div style={{ display: 'flex', gap: '20px', paddingTop: '20px' }}>

                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                </div>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="128" height="106" viewBox="0 0 128 106" fill="none">
                                                    <rect x="36.9" y="-38.9" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="-0.9" y="0.9" width="84.6" height="84.6" transform="matrix(-1 0 0 1 131.4 -27.2)" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="58.5" y="-13.7001" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                </svg>
                                            </div>
                                            :
                                            <div className="bd_cards bg2" onClick={() => showDrawer(submitedData?.toBeSubmittedAll?.rows, 'Submitted')}>
                                                <div className="d-flex">
                                                    <h2>{submitedData?.toBeSubmittedAll?.count !== null && submitedData?.toBeSubmittedAll?.count !== 0 ? submitedData?.toBeSubmittedAll?.count : '0'}</h2>
                                                    <span className='bd_cards_heading'>Submissions Completed</span>
                                                </div>
                                                <div className='bd_cards_content'>
                                                    <div className='bd_cards_btn'>
                                                        {
                                                            Object.entries(cardRender?.filteredSubmitted)?.map(([key, value]) => ({ label: key?.slice(-3), value }))?.map(item => {
                                                                return (
                                                                    <>
                                                                        {
                                                                            item?.value !== 0 ?
                                                                                <span onClick={(e) => handleChangeCounter(e, item?.label, submitedData?.toBeSubmittedAll?.rows, 'Submitted')}>{item?.label} <b>{item?.value || 0}</b></span>
                                                                                :
                                                                                <></>
                                                                        }
                                                                    </>
                                                                )
                                                            })
                                                        }
                                                    </div>
                                                </div>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="128" height="106" viewBox="0 0 128 106" fill="none">
                                                    <rect x="36.9" y="-38.9" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="-0.9" y="0.9" width="84.6" height="84.6" transform="matrix(-1 0 0 1 131.4 -27.2)" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="58.5" y="-13.7001" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                </svg>
                                            </div>
                                        }
                                    </Col>
                                    :
                                    <></>
                            }
                            {
                                widgetsByRoleList?.includes('Awaiting Graph') ?

                                    <Col span={6}>
                                        {skeletonAwait ?
                                            <div className="bd_cards bg3" >
                                                <div className="d-flex">
                                                    <Skeleton variant="rectangular" width={80} height={55} />
                                                    <span className='bd_cards_heading'>Results Pending</span>
                                                </div>
                                                <div style={{ display: 'flex', gap: '20px', paddingTop: '20px' }}>

                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                </div>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="128" height="106" viewBox="0 0 128 106" fill="none">
                                                    <rect x="36.9" y="-38.9" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="-0.9" y="0.9" width="84.6" height="84.6" transform="matrix(-1 0 0 1 131.4 -27.2)" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="58.5" y="-13.7001" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                </svg>
                                            </div>
                                            :
                                            <div className='bd_cards bg3' onClick={() => showDrawer(resultAwaitingData?.rowdata, 'Result Awaiting')}>
                                                <div className="d-flex">
                                                    <h2>{resultAwaitingData?.count !== null && resultAwaitingData?.count !== 0 ? resultAwaitingData?.count : '0'}</h2>
                                                    <span className='bd_cards_heading'>Results Pending</span>
                                                </div>
                                                <div className='bd_cards_content'>
                                                    <div className='bd_cards_btn'>
                                                        {
                                                            Object.entries(cardRender?.filteredAwaiting)?.map(([key, value]) => ({ label: key?.slice(-3), value }))?.map(item => {
                                                                return (
                                                                    <>
                                                                        {
                                                                            item?.value !== 0 ?
                                                                                <span onClick={(e) => handleChangeCounter(e, item?.label, resultAwaitingData?.rowdata, 'Result Awaiting')}>{item?.label} <b>{item?.value || 0}</b></span>
                                                                                :
                                                                                <></>
                                                                        }
                                                                    </>
                                                                )
                                                            })
                                                        }
                                                    </div>
                                                </div>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="128" height="106" viewBox="0 0 128 106" fill="none">
                                                    <rect x="36.9" y="-38.9" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="-0.9" y="0.9" width="84.6" height="84.6" transform="matrix(-1 0 0 1 131.4 -27.2)" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="58.5" y="-13.7001" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                </svg>
                                            </div>
                                        }
                                    </Col>
                                    :
                                    <></>
                            }

                            {
                                widgetsByRoleList?.includes('Won Graph') ?
                                    <Col span={6}>
                                        {skeletonWon ?
                                            <div className="bd_cards bg4">
                                                <div className="d-flex">
                                                    <Skeleton variant="rectangular" width={80} height={55} />
                                                    <span className='bd_cards_heading'>Won</span>
                                                </div>
                                                <div style={{ display: 'flex', gap: '20px', paddingTop: '20px' }}>

                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                    <Skeleton variant="rectangular" width={70} height={30} />
                                                </div>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="128" height="106" viewBox="0 0 128 106" fill="none">
                                                    <rect x="36.9" y="-38.9" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="-0.9" y="0.9" width="84.6" height="84.6" transform="matrix(-1 0 0 1 131.4 -27.2)" stroke="#F2F2F2" strokeWidth="1.8" />
                                                    <rect x="58.5" y="-13.7001" width="84.6" height="84.6" stroke="#F2F2F2" strokeWidth="1.8" />
                                                </svg>
                                            </div>
                                            :
                                            <div className='bd_cards bg4' onClick={() => showDrawer(wonData?.rowdata, 'Won')}>
                                                <div className="d-flex">
                                                    {skeletonToBe ? <h2><Skeleton variant="rectangular" width={80} height={35} /></h2> :
                                                        <h2>{wonData?.count !== null && wonData?.count !== 0 ? wonData?.count : '0'}</h2>}
                                                    <span className='bd_cards_heading'>Won</span>
                                                </div>
                                                <div className='bd_cards_content'>
                                                    <div className='bd_cards_btn'>
                                                        {
                                                            Object.entries(cardRender?.filteredWon)?.map(([key, value]) => ({ label: key?.slice(-3), value }))?.map(item => {
                                                                return (
                                                                    <>
                                                                        {
                                                                            item?.value !== 0 ?
                                                                                <span onClick={(e) => handleChangeCounter(e, item?.label, wonData?.rowdata, 'Won')}>{item?.label} <b>{item?.value || 0}</b></span>
                                                                                :
                                                                                <></>
                                                                        }
                                                                    </>
                                                                )
                                                            })
                                                        }
                                                    </div >
                                                </div>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="128" height="106" viewBox="0 0 128 106" fill="none">
                                                    <rect x="37.4" y="-38.9" width="84.6" height="84.6" stroke="white" strokeWidth="1.8" />
                                                    <rect x="-0.9" y="0.9" width="84.6" height="84.6" transform="matrix(-1 0 0 1 131.9 -27.2)" stroke="white" strokeWidth="1.8" />
                                                    <rect x="59" y="-13.7001" width="84.6" height="84.6" stroke="white" strokeWidth="1.8" />
                                                </svg>
                                            </div>
                                        }
                                    </Col>
                                    :
                                    <></>
                            }
                        </Row>
                    </div>
                </div>

                {/* calendar section */}


                <div className='bd_dashboard_calendar'>
                    <div className="">
                        <Tabs
                            defaultActiveKey={todoTypeBtn}
                            items={tabItems}
                            activeKey={activeCalendarBtn}
                            onChange={handleTabChangeCalendar}
                        />
                    </div>
                </div>


                {/* Team Tasks List */}

                <div className="bd_dashboard_datatable">
                    <Row gutter={40}>
                        {/* {widgetsByRoleList?.includes('Financial Year Wise Amount') ? <Col span={12}>
                            <div className='bd_dashboard_datatable_card'>
                                <h5>Financial Year Wise Amount</h5>
                                <PiChart />
                            </div>
                        </Col> : null} */}
                        {widgetsByRoleList?.includes('Team Tasks List') ?
                            (<Col span={24}>
                                <div className='bd_dashboard_team'>
                                    <h5>{teamTaskWidget?.heading}</h5>
                                </div>

                                <div className='bd_dashboard_datatable_card bd_dashboard_team_card'>

                                    {
                                        teamTaskWidget?.data?.length > 0 ?
                                            teamTaskWidget?.data?.map((item, index) => {
                                                const createdByChild = employeeList?.find(val => val?.id === parseInt(item?.assign_to))

                                                return (
                                                    <>
                                                        <div className='bd_dashboard_head' onClick={() => { handleDrawerTeamTask(); fetchTeamTaskDetail(item?.assign_to) }} key={index}>
                                                            <div className='bd_dashborad_image'>
                                                                <Avatar
                                                                    style={{
                                                                        backgroundColor: createdByChild?.profileimg_path ? null : '#f56a00',
                                                                        // verticalAlign: 'middle',
                                                                    }}
                                                                    src={docurlchat + createdByChild?.profileimg_path + "/" + createdByChild?.profileimg}
                                                                    size="large"
                                                                >
                                                                    {item?.user?.userfullname.charAt(0)}
                                                                </Avatar>
                                                                <div className='bd_dashboard_pname' >
                                                                    <h6>{item?.user?.userfullname}  {item?.user?.bg_mstr_designation !== null ? <span className='dashboard_designation'> ({item?.user?.bg_mstr_designation?.designation_name})</span> : ""}</h6>

                                                                    <div className='bd_dashboard_keyRole'>
                                                                        {/* <div className="subTitle">Key Role</div> */}
                                                                        <div className="d-flex">
                                                                            {
                                                                                item?.userRoleResp?.map(item => <span onClick={() => setTeamTaskBtn(item?.bg_mstr_bd_role?.role_name)}>{item?.bg_mstr_bd_role?.role_name}</span>)
                                                                            }
                                                                            {/* <span>{item?.num_tender_assign}</span> */}
                                                                            {/* <span>Sub user</span> */}
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>

                                                            <div className='bd_dashboard_keyRole'>
                                                                {/* <div className="subTitle">Project Count</div> */}
                                                                <div className="d-flex">
                                                                    <span>{item?.num_tender_assign}</span>
                                                                    {/* <span>Sub user</span> */}
                                                                </div>
                                                            </div>

                                                        </div>
                                                        <Divider />

                                                    </>
                                                )
                                            })
                                            :
                                            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                                    }



                                </div>
                            </Col>) : ''
                        }
                    </Row>
                </div>

                {/* Tender Request */}

                {widgetsByRoleList?.includes('Tender Request ') && <TenderRequest employeeListVal={employeeList} />}

                {/* Todo */}

                <div className="taskRoleWrapper bd_dashboard_calendar">

                    <Tabs defaultActiveKey={todoTypeBtn} items={taskTabItems} activeKey={todoTypeBtn} onChange={handleTabChangeTodo} />
                </div>

            </div>

            {/*team task drawer */}
            <TeamTaskDetail setOpen={setTeamTaskDrawerOpen} open={teamTaskDrawerOpen} teamTaskDetail={teamTaskWidgetDetail} dynamicBtnData={teamTaskHeaderBtn} btnFilter={teamTaskBtn} setBtnFilter={setTeamTaskBtn} />

            {/* cards Drawer */}
            <CardsDrawerTender drawerTitle={drawerTitle} onClose={onClose} setCardsType={setCardsType} cardsDetailDrawer={cardsDetailDrawer} cardsType={cardsType} cardRender={cardRender} cardsDrawerData={cardsDrawerData} />

        </>
    )

}
export default Dashboard


