// @ts-nocheck
import React from 'react'
import { Empty, Form } from 'antd';
import { Select } from 'antd';
import { Down } from '@icon-park/react';
import { useState, useEffect } from 'react';
import { TodoServices } from 'Services/bidgrid/todo/TodoServices';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import styled from 'styled-components';
import { Card, Typography, } from 'antd';
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'
import { useSelector } from 'react-redux';
import { Avatar, Tooltip } from 'antd';
import { ClockCircleOutlined } from '@ant-design/icons';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import attachment from '../../assets/images/icons/file_present.png';
import Comments from '../../assets/images/icons/fluent_chat-24-filled.png';
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
import { useDispatch } from 'react-redux';
import { navigationData } from 'Redux/actions/bidgrid/navigationData';
import { docurlchat } from 'utils/configurable';
import { TimeConverter } from 'BidGrid/components/TimeConverter/TimeConverter';
const StyledCard = styled(Card)`
margin: 0.5rem;
padding: 0.5rem;
background-color:'#fff')};
`;

const TaskboardItemCardTitle = styled(Typography.Title)`
white-space: pre-wrap;
margin-right: 0.25rem;
`;
const optionsVal = {
    assign_type: [{ label: 'Self', value: 1 }, { label: 'By-IO', value: 2 }],
    task_priority: [],
    hash_tags: [],
    current_scope: [{ label: 'To DO', value: 1 }, { label: 'In Progress', value: 2 }, { label: 'Complete', value: 3 }],
    assigned_to_users: [],
    project: [{ label: 'Project1', value: 1 }, { label: 'Project2', value: 2 }, { label: 'Project3', value: 3 }, { label: 'Project4', value: 4 }],

}

function SampleNextArrow(props) {
    const { className, onClick } = props;
    return (
        <div className={className} onClick={onClick}>
            <span aria-label="Next">›</span>
        </div>
    );
}

function SamplePrevArrow(props) {
    const { className, onClick } = props;
    return (
        <div className={className} onClick={onClick}>
            <span aria-label="Previous">‹</span>
        </div>
    );
}

const ToDoDashBoard = (props) => {
    const { getWidgetList, todoKey, userOptions, employeeListVal, updateLoader } = props

    const [changeStatus, setChangeStatus] = useState('1')
    const [documentData, setDocumentData] = useState([])
    const [dropdownValState, setDropdownValState] = useState(optionsVal);
    const [selectedFilterData, setSelectedFilterData] = useState({
        priority: null,
        assigntype: null
    })
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const { userBidInfo } = useSelector((state) => state?.userDetails)
    const [filteredData, setFilteredData] = useState([])
    const [userIds, setUserIds] = useState(null)
    const [skeleton, setSkeleton] = useState(false);
    var settings = {
        dots: false,
        infinite: true,
        speed: 600,
        autoplay: false,
        autoplaySpeed: 2000,
        slidesToShow: 3,
        slidesToScroll: 1,
        cssEase: "linear",
        nextArrow: <SampleNextArrow />,
        prevArrow: <SamplePrevArrow />,
    };
    // fetch todo document list
    const fetchDocumentTask = async () => {
        try {
            const response = await TodoServices.getTodoDocumentList()
            if (response?.data?.status === '1') {
                setDocumentData(response?.data?.data)
            } else {
                setDocumentData([])
            }
        } catch (error) {
            return []
        }

    }

    // filters for todo data
    const todoFilteredVal = (data) => {

        if (todoKey === '1') {

            const filteredItems = data
                ?.filter(item => {
                    const isPriorityMatch = selectedFilterData?.priority ? item?.task_priority === selectedFilterData?.priority : true;
                    const isAssignTypeMatch = selectedFilterData?.assigntype ? item?.assign_type === selectedFilterData?.assigntype : true;

                    return isPriorityMatch && isAssignTypeMatch;
                });
            setFilteredData(filteredItems)
            setSkeleton(false)
        } else {
            let arr = []
            data?.map((value) => {
                if (value?.todo_tasks?.length > 0) {
                    return value?.todo_tasks?.map((item) => {
                        arr.push(item)
                    })
                }
            })
            const filteredItems = arr
                ?.filter(item => {
                    const isPriorityMatch = selectedFilterData?.priority ? item?.task_priority === selectedFilterData?.priority : true;
                    const isAssignTypeMatch = selectedFilterData?.assigntype ? item?.assign_type === selectedFilterData?.assigntype : true;

                    return isPriorityMatch && isAssignTypeMatch;
                });
            setFilteredData(filteredItems)
            setSkeleton(false)
        }

    }

    //api call regarding todos
    const changeStatusTodo = async () => {

        setSkeleton(true)
        try {
            let response;
            if (todoKey === '1') {
                switch (changeStatus) {
                    case '1':
                        response = await TodoServices.getToDoList()
                        break;
                    case '2':
                        response = await TodoServices.getInProgressList()
                        break;
                    case '3':
                        response = await TodoServices.getDoneList()
                        break;
                    default:
                        setFilteredData([]);
                        break;
                }
            } else {
                const searchParams = new URLSearchParams()
                searchParams.append('todo_scope', changeStatus)
                userIds?.length > 0 && searchParams.append("user_id", userIds)
                response = await TodoServices.TodoDepartment(searchParams);
                updateLoader(false)
            }

            if (response?.data?.status === '1') {

                await fetchDocumentTask();
                todoFilteredVal(response?.data?.data);
                updateLoader(false)
            } else {
                setSkeleton(false)
                setFilteredData([]);
                updateLoader(false)

            }
        } catch (error) {
            setFilteredData([]);
            console.log(error)
            setSkeleton(false)
            updateLoader(false)

        }
    }

    //card specific render data needed api calls
    const getDropdownVal = async () => {

        // task Priority
        try {
            const res = await TodoServices.getTaskPriorityList()
            if (res?.data?.status === '1') {
                setDropdownValState(prevState => ({ ...prevState, task_priority: res?.data?.data }))

            } else {
                setDropdownValState(prevState => ({ ...prevState, task_priority: [] }))
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }

        //HasgTag List
        try {
            const res = await TodoServices.gethashlist()
            if (res?.data?.status === '1') {
                setDropdownValState(prevState => ({ ...prevState, hash_tags: res?.data?.data }))
            } else {
                setDropdownValState(prevState => ({ ...prevState, hash_tags: [] }))
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }

    }

    //update then assigned to users as per the userlist fetched
    useEffect(() => {
        if (employeeListVal?.length > 0) {
            setDropdownValState(prevState => ({ ...prevState, assigned_to_users: employeeListVal }))
        }
    }, [employeeListVal])

    // while change in status , todo key , userIds ,assign type and priority

    useEffect(() => {

        changeStatusTodo()

    }, [todoKey, userIds, selectedFilterData, changeStatus])


    useEffect(() => {
        getDropdownVal()
    }, []);


    const handleReset = () => {

        if (selectedFilterData?.priority || selectedFilterData?.assigntype || changeStatus !== '1' || userIds?.length > 0) {
            setSelectedFilterData({
                priority: null,
                assigntype: null
            })
            setChangeStatus('1')
            setUserIds([])
        }
    }

    const handleNavigate = (val) => {

        if (todoKey === '1') {
            const obj = {
                item: val,
                type: null,
                key: val.id
            }
            dispatch(navigationData.setNavigationDataAction(obj))
            navigate('/bidgrid/todo');
        }
    }

    //handle multiple user dropdown value
    const handleDepartment = (val) => {
        setUserIds(val)
    }

    // handle status change
    const handleChange = (value) => {
        setChangeStatus(value)
    };

    // handle change of assign and priority
    const handleChangeType = (name, value) => {
        setSelectedFilterData({ ...selectedFilterData, [name]: value })
    };


    const avatarColor = "#8d8d8d"

    const actionColor = "#8d8d8d"


    return (
        <div className='todo_container' style={{ padding: 0 }}>
            <div className='bd_dashboard_tasked'>

                <div className='bd_dashboard_title teamTaskedFlex'>
                    {todoKey === '2' ? 'Team Task' : 'My Task'}
                    {
                        todoKey === "2" ?
                            <Form.Item>
                                <Select
                                    allowClear
                                    mode="multiple"
                                    showSearch
                                    style={{ minWidth: 250, maxWidth: 500 }}
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    placeholder="Search User"
                                    optionFilterProp="children"
                                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                    options={userOptions}
                                    onChange={handleDepartment}
                                    value={userIds}
                                />

                            </Form.Item> : ''
                    }

                </div>

                <div className='todo_search_container'>
                    <div className="flex_button">
                        <div className='bdTask_filterFlex'>
                            <Select
                                allowClear
                                defaultValue="Task Status"
                                style={{
                                    minWidth: 130,
                                }}
                                value={changeStatus}
                                onChange={handleChange}
                                options={[
                                    {
                                        value: '1',
                                        label: 'To Do'
                                    },
                                    {
                                        value: '2',
                                        label: 'In Progress'
                                    },
                                    {
                                        value: '3',
                                        label: 'Done'
                                    },
                                ]}
                            />

                            <Select
                                allowClear
                                style={{
                                    minWidth: 130,
                                }}
                                name='assigntype'
                                value={selectedFilterData?.assigntype}
                                onChange={(value) => handleChangeType('assigntype', value)}
                                options={dropdownValState?.assign_type?.map((item, index) => {
                                    return {
                                        value: item?.value,
                                        label: item?.label
                                    }
                                })}
                                placeholder='Assignment Recipient'
                            />
                            <Select
                                allowClear
                                style={{
                                    minWidth: 130,
                                }}
                                name='priority'
                                value={selectedFilterData?.priority}
                                onChange={(value) => handleChangeType('priority', value)}
                                options={dropdownValState?.task_priority?.map((item, index) => {
                                    return {
                                        value: item?.id,
                                        label: item?.task_priority_name
                                    }
                                })}
                                placeholder='Priority'
                            />

                        </div>
                        <button className='BG_ghostButton' onClick={handleReset}>Reset</button>
                    </div>
                </div>

                {
                    skeleton ?
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20 }}>
                            <Skeleton variant="rectangular" width={"100%"} height={240} />
                            <Skeleton variant="rectangular" width={"100%"} height={240} />
                            <Skeleton variant="rectangular" width={"100%"} height={240} />
                        </div>
                        :
                        <>
                            {
                                filteredData?.length === 0 ?
                                    <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
                                    :
                                    <Slider {...settings} centerMode={false} infinite={filteredData.length <= 3 ? false : true} className='dashboard-todo' >

                                        {filteredData?.map?.((item, index) => {
                                            const assignedUserIds = item?.hasOwnProperty('assign_user_list') ? item?.assign_user_list?.map(val => val?.assigned_to_userid) : item?.assigned_users?.map(val => val?.assigned_to_userid)

                                            const filteredUserObjects = dropdownValState?.assigned_to_users?.filter(user => assignedUserIds?.includes(user?.id));
                                            return (
                                                <StyledCard
                                                    key={index}
                                                    onClick={() => handleNavigate(item)}
                                                    className={`todo_card-box-bd ${dropdownValState?.task_priority?.find(val => val?.id === item?.task_priority)?.task_priority_name === "High"
                                                        ? "borderRed highPriority"
                                                        : dropdownValState?.task_priority?.find(val => val?.id === item?.task_priority)?.task_priority_name === "Low"
                                                            ? "borderGreen lowPriority"
                                                            : dropdownValState?.task_priority?.find(val => val?.id === item?.task_priority)?.task_priority_name === "Medium"
                                                                ? "borderOrange mediumPriority"
                                                                : ""
                                                        }`}
                                                    size="small"
                                                    title={
                                                        // <span>
                                                        //     <TaskboardItemCardTitle level={5} ellipsis={{ rows: 2 }}>
                                                        //         <div className='prioity_todo_list'>
                                                        //             <div className='todo_prioity_level'>
                                                        //                 <span>Priority</span>
                                                        //                 <div className='todo_level_token todo_low_token'>
                                                        //                     <span>{dropdownValState?.task_priority?.find(val => val?.id === item?.task_priority)?.task_priority_name}</span>
                                                        //                 </div>
                                                        //             </div>
                                                        //         </div>

                                                        //     </TaskboardItemCardTitle>
                                                        // </span>


                                                        <div className='priority-col'>
                                                            Priority: {dropdownValState?.task_priority?.find(val => val?.id === item?.task_priority)?.task_priority_name}
                                                        </div>
                                                    }
                                                >
                                                    <div className='todo_heading_coont'>
                                                        <span>{item?.task_name}</span>
                                                    </div>
                                                    <div className='pra-box'>

                                                        <p> {capitalizeExceptPrepositionsAndLowerCase(item?.task_description)}</p>

                                                    </div>

                                                    <div className='todo_hashtag_container'>
                                                        {item?.hash_tags?.split(',')?.slice(0, 4).map((item, index) => (
                                                            <div className='todo_hashtag' >
                                                                <span>{item}</span>
                                                            </div>
                                                        ))}
                                                        {item?.hash_tags?.split(',')?.length > 4 && (
                                                            <div className='todo_hashtag'>
                                                                <span>...+{item?.hash_tags?.split(',').length - 4}</span>
                                                            </div>
                                                        )}
                                                    </div>


                                                    <div className='card-box'>
                                                        <div className='box-content'>
                                                            {
                                                                item?.updated_at !== null ?
                                                                    <div className='date-box'>
                                                                        <div className='icon-title'>
                                                                            <ClockCircleOutlined className='date-box-icon' /> Last Updated:
                                                                        </div>
                                                                        <div>
                                                                            <span> {item?.updated_at !== null ? `${dayjs(item?.updated_at)?.format('YYYY-MM-DD')} ${TimeConverter(item?.updated_at)}` : ' - '} {item?.modified_by !== null && 'By'} {dropdownValState?.assigned_to_users?.find(val => val?.id === item?.modified_by)?.userfullname}
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    :
                                                                    <></>
                                                            }
                                                            {
                                                                item?.deadline_date !== null ?
                                                                    <div className='date-box'>
                                                                        <div className='icon-title'>
                                                                            <ClockCircleOutlined className='date-box-icon' /> Deadline:
                                                                        </div>
                                                                        <div>
                                                                            <span> {item?.deadline_date !== null ? `${dayjs(item?.deadline_date)?.format('YYYY-MM-DD')} ${TimeConverter(item?.deadline_date)}` : ' - '}
                                                                            </span>
                                                                        </div>
                                                                    </div>
                                                                    :
                                                                    <></>
                                                            }
                                                            <div className='bd_avatar_grp'>
                                                                <div>
                                                                    <Avatar.Group
                                                                        // maxCount={1}
                                                                        maxPopoverTrigger="click"
                                                                        size="large"
                                                                        maxStyle={{ color: avatarColor, backgroundColor: avatarColor, cursor: 'pointer' }}
                                                                    >
                                                                        {
                                                                            filteredUserObjects?.slice(0, 2).map((item, index) => (
                                                                                <Tooltip key={index} title={item?.userfullname} placement="top">
                                                                                    <Avatar src={docurlchat + item?.profileimg_path + "/" + item?.profileimg}
                                                                                        style={{ backgroundColor: !item?.profileimg && avatarColor }}
                                                                                    >
                                                                                        {item?.userfullname.charAt(0)}
                                                                                    </Avatar>
                                                                                </Tooltip>
                                                                            ))
                                                                        }
                                                                        {filteredUserObjects && filteredUserObjects.length > 2 && (
                                                                            <Tooltip title={filteredUserObjects?.slice(2)?.map(item => item?.userfullname).join(', ')} placement="right">

                                                                                <Avatar style={{ backgroundColor: avatarColor }}>
                                                                                    +{filteredUserObjects?.length - 2}
                                                                                </Avatar>
                                                                            </Tooltip>
                                                                        )}
                                                                    </Avatar.Group>
                                                                </div>


                                                                <div className='todo_attachment_cont'>
                                                                    {
                                                                        documentData?.filter(val => val?.task_name === item?.task_name)?.map(item_a => item_a?.todo_comment_documents?.length) > 0 ?
                                                                            <div className='todo_attachment_span' style={{ border: `1px solid ${actionColor}`, borderRadius: 6, padding: 6 }} >
                                                                                {/* <img src={attachment} alt='attack file' width={25} /> */}
                                                                                <svg width="14" height="15" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <g clip-path="url(#clip0_2324_729)">
                                                                                        <path d="M0.560059 0.630371V5.39034C0.560059 5.95141 0.782945 6.48951 1.17969 6.88625C1.57643 7.28299 2.11452 7.50588 2.6756 7.50588C3.23667 7.50588 3.77477 7.28299 4.17151 6.88625C4.56825 6.48951 4.79114 5.95141 4.79114 5.39034V2.21703C4.79114 1.93649 4.6797 1.66744 4.48132 1.46907C4.28295 1.2707 4.01391 1.15926 3.73337 1.15926C3.45283 1.15926 3.18378 1.2707 2.98541 1.46907C2.78704 1.66744 2.6756 1.93649 2.6756 2.21703V5.91922M6.37779 1.15926H13.2533C13.5338 1.15926 13.8029 1.2707 14.0013 1.46907C14.1996 1.66744 14.3111 1.93649 14.3111 2.21703V14.9103C14.3111 15.1908 14.1996 15.4599 14.0013 15.6582C13.8029 15.8566 13.5338 15.968 13.2533 15.968H2.6756C2.39506 15.968 2.12601 15.8566 1.92764 15.6582C1.72927 15.4599 1.61783 15.1908 1.61783 14.9103V9.09253M11.6666 5.39034H7.43556M11.6666 8.56365H7.43556M11.6666 11.737H4.26225" stroke={actionColor} stroke-width="1.05777" />
                                                                                    </g>
                                                                                    <defs>
                                                                                        <clipPath id="clip0_2324_729">
                                                                                            <rect width="15.8665" height="15.8665" fill="white" transform="translate(0.0307617 0.630371)" />
                                                                                        </clipPath>
                                                                                    </defs>
                                                                                </svg>

                                                                                <span className='ms-1' style={{ color: actionColor, fontSize: 11 }}>{documentData?.filter(val => val?.task_name === item?.task_name)?.map(item_b => item_b?.todo_comment_documents?.length)}</span>
                                                                            </div>
                                                                            :
                                                                            <></>
                                                                    }
                                                                    {
                                                                        item?.taskcommentCount !== 0 ?
                                                                            <div style={{ border: `1px solid ${actionColor}`, borderRadius: 6, padding: 6 }} className='todo_comment_span'>
                                                                                {/* <img src={Comments} alt='comment' width={25} onClick={handleComment} /> */}
                                                                                <svg width="18" height="18" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M6.09313 11.8032H14.357C14.4743 11.8032 14.5726 11.7638 14.652 11.685C14.7308 11.6057 14.7701 11.5073 14.7701 11.39C14.7701 11.2726 14.7308 11.1743 14.652 11.095C14.5726 11.0162 14.4743 10.9768 14.357 10.9768H6.09313C5.97578 10.9768 5.87744 11.0162 5.79811 11.095C5.71933 11.1743 5.67994 11.2726 5.67994 11.39C5.67994 11.5073 5.71933 11.6057 5.79811 11.685C5.87744 11.7638 5.97578 11.8032 6.09313 11.8032ZM6.09313 9.32403H14.357C14.4743 9.32403 14.5726 9.28464 14.652 9.20586C14.7308 9.12652 14.7701 9.02818 14.7701 8.91084C14.7701 8.79349 14.7308 8.69515 14.652 8.61582C14.5726 8.53704 14.4743 8.49765 14.357 8.49765H6.09313C5.97578 8.49765 5.87744 8.53704 5.79811 8.61582C5.71933 8.69515 5.67994 8.79349 5.67994 8.91084C5.67994 9.02818 5.71933 9.12652 5.79811 9.20586C5.87744 9.28464 5.97578 9.32403 6.09313 9.32403ZM6.09313 6.84488H14.357C14.4743 6.84488 14.5726 6.80549 14.652 6.72671C14.7308 6.64738 14.7701 6.54904 14.7701 6.43169C14.7701 6.31434 14.7308 6.216 14.652 6.13667C14.5726 6.05789 14.4743 6.0185 14.357 6.0185H6.09313C5.97578 6.0185 5.87744 6.05789 5.79811 6.13667C5.71933 6.216 5.67994 6.31434 5.67994 6.43169C5.67994 6.54904 5.71933 6.64738 5.79811 6.72671C5.87744 6.80549 5.97578 6.84488 6.09313 6.84488ZM4.12221 14.6955C3.74207 14.6955 3.42474 14.5683 3.17021 14.3137C2.91514 14.0587 2.7876 13.741 2.7876 13.3609V4.46077C2.7876 4.08063 2.91514 3.7633 3.17021 3.50877C3.42474 3.2537 3.74207 3.12616 4.12221 3.12616H16.3279C16.708 3.12616 17.0253 3.2537 17.2799 3.50877C17.535 3.7633 17.6625 4.08063 17.6625 4.46077V15.6318C17.6625 15.9293 17.5256 16.1345 17.2518 16.2475C16.978 16.3604 16.7367 16.3125 16.5279 16.1037L15.1197 14.6955H4.12221ZM15.4726 13.8691L16.8361 15.2277V4.46077C16.8361 4.33406 16.7832 4.21754 16.6774 4.11121C16.5711 4.00543 16.4546 3.95254 16.3279 3.95254H4.12221C3.99549 3.95254 3.87897 4.00543 3.77265 4.11121C3.66687 4.21754 3.61398 4.33406 3.61398 4.46077V13.3609C3.61398 13.4876 3.66687 13.6041 3.77265 13.7105C3.87897 13.8162 3.99549 13.8691 4.12221 13.8691H15.4726Z" fill={actionColor} />
                                                                                </svg>
                                                                                <span className='ms-1' style={{ color: actionColor, fontSize: 11 }}>{item?.taskcommentCount}</span>
                                                                            </div>
                                                                            :
                                                                            <div style={{ border: `1px solid ${actionColor}`, borderRadius: 6, padding: 6 }} className='todo_comment_span'>
                                                                                {/* <img src={Comments} alt='comment' width={25} onClick={handleComment} /> */}
                                                                                <svg width="18" height="18" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M6.09313 11.8032H14.357C14.4743 11.8032 14.5726 11.7638 14.652 11.685C14.7308 11.6057 14.7701 11.5073 14.7701 11.39C14.7701 11.2726 14.7308 11.1743 14.652 11.095C14.5726 11.0162 14.4743 10.9768 14.357 10.9768H6.09313C5.97578 10.9768 5.87744 11.0162 5.79811 11.095C5.71933 11.1743 5.67994 11.2726 5.67994 11.39C5.67994 11.5073 5.71933 11.6057 5.79811 11.685C5.87744 11.7638 5.97578 11.8032 6.09313 11.8032ZM6.09313 9.32403H14.357C14.4743 9.32403 14.5726 9.28464 14.652 9.20586C14.7308 9.12652 14.7701 9.02818 14.7701 8.91084C14.7701 8.79349 14.7308 8.69515 14.652 8.61582C14.5726 8.53704 14.4743 8.49765 14.357 8.49765H6.09313C5.97578 8.49765 5.87744 8.53704 5.79811 8.61582C5.71933 8.69515 5.67994 8.79349 5.67994 8.91084C5.67994 9.02818 5.71933 9.12652 5.79811 9.20586C5.87744 9.28464 5.97578 9.32403 6.09313 9.32403ZM6.09313 6.84488H14.357C14.4743 6.84488 14.5726 6.80549 14.652 6.72671C14.7308 6.64738 14.7701 6.54904 14.7701 6.43169C14.7701 6.31434 14.7308 6.216 14.652 6.13667C14.5726 6.05789 14.4743 6.0185 14.357 6.0185H6.09313C5.97578 6.0185 5.87744 6.05789 5.79811 6.13667C5.71933 6.216 5.67994 6.31434 5.67994 6.43169C5.67994 6.54904 5.71933 6.64738 5.79811 6.72671C5.87744 6.80549 5.97578 6.84488 6.09313 6.84488ZM4.12221 14.6955C3.74207 14.6955 3.42474 14.5683 3.17021 14.3137C2.91514 14.0587 2.7876 13.741 2.7876 13.3609V4.46077C2.7876 4.08063 2.91514 3.7633 3.17021 3.50877C3.42474 3.2537 3.74207 3.12616 4.12221 3.12616H16.3279C16.708 3.12616 17.0253 3.2537 17.2799 3.50877C17.535 3.7633 17.6625 4.08063 17.6625 4.46077V15.6318C17.6625 15.9293 17.5256 16.1345 17.2518 16.2475C16.978 16.3604 16.7367 16.3125 16.5279 16.1037L15.1197 14.6955H4.12221ZM15.4726 13.8691L16.8361 15.2277V4.46077C16.8361 4.33406 16.7832 4.21754 16.6774 4.11121C16.5711 4.00543 16.4546 3.95254 16.3279 3.95254H4.12221C3.99549 3.95254 3.87897 4.00543 3.77265 4.11121C3.66687 4.21754 3.61398 4.33406 3.61398 4.46077V13.3609C3.61398 13.4876 3.66687 13.6041 3.77265 13.7105C3.87897 13.8162 3.99549 13.8691 4.12221 13.8691H15.4726Z" fill={actionColor} />
                                                                                </svg>
                                                                            </div>
                                                                    }

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </StyledCard>
                                            )
                                        })}

                                    </Slider>

                            }
                        </>

                }





            </div>
        </div>
    )
}

export default ToDoDashBoard
