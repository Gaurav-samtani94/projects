import { Drawer } from 'antd';
import React from 'react'
import SkipBack from '../../../BidGrid/assets/images/skip-back.png'
import dayjs from 'dayjs';
import ROUTES from 'Constants/Routes';

import { Link } from 'react-router-dom';
import { TimeConverter } from 'BidGrid/components/TimeConverter/TimeConverter';

function TeamTaskDetail(props) {
  const { setOpen, open, teamTaskDetail, dynamicBtnData, btnFilter, setBtnFilter } = props



  const handleFilterEvent = (e) => {
    setBtnFilter(e)
  }

  function formatDateUtcWithMonthName(dateString) {
    if (dateString) {
      const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'Sept', 'Oct', 'Nov', 'Dec'
      ];

      const date = new Date(dateString);
      const day = date.getUTCDate().toString().padStart(2, '0');
      const month = monthNames[date.getUTCMonth()];
      const year = date.getUTCFullYear();
      return `${day} ${month} ${year}`;
    } else {
      return '';
    }
  }

  return (
    <Drawer className='bd_Drawer_calendar' closeIcon={<img src={SkipBack} alt='' />} title="Team Tasks List" placement="right" onClose={() => { setOpen(false); handleFilterEvent('all'); }} open={open} width={760}>


      <div className='filterTab_btn'>

        <button className={btnFilter === 'all' ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => handleFilterEvent('all')} >All </button>
        {
          dynamicBtnData?.map(item => <button className={btnFilter === item?.label ? 'BG_mainButton' : "BG_ghostButton"} onClick={() => handleFilterEvent(item?.label)} >{`${item?.label} (${item?.value})`}</button>
          )
        }

      </div>
      <div className="p-4">
        {
          teamTaskDetail?.length > 0 ? teamTaskDetail?.filter(val => btnFilter !== 'all' ? val?.bg_mstr_bd_role?.role_name === btnFilter : 'all')?.map((item, index) => {
            return (
              <>
                <Link to={ROUTES.BD_TENDERDETAILS.replace(':id', item?.tender_id)} >

                  <div className="bd_dashboard_calendar_eventdetails mb-4 mt-3" key={index}>

                    <div className="event-details">
                      <div className="event_inner_wrapper">
                        <div className="bd_dpt_card tndDataBorder">
                          <span className="bd_dpt_card_info">{item?.tender_Data?.bg_mstr_client?.Client_name}</span>
                          <h5 className="bd_dpt_card_info_heading">{item?.tender_Data?.tender_name.replace(/<[^>]*>/g, '')}</h5>
                          <hr />
                          <div className="bd_submit_date">
                            <span className="bd_dpt_card_info">Generated Tender : </span>
                            <span className="bd_dpt_card_info"> {item?.tender_Data?.tender_ger_id?.generated_tender_id}</span>
                          </div>

                          <div className="bd_submit_date">
                            <span className="bd_dpt_card_info">Role : </span>
                            <span className="bd_dpt_card_info"> {item?.bg_mstr_bd_role?.role_name}</span>
                          </div>
                          <div className="bd_submit_date">
                            <span className="bd_dpt_card_info">Submission End Date : </span>
                            <span className="bd_dpt_card_info"> {item?.tender_Data?.submission_end_date !== null ? `${formatDateUtcWithMonthName(item?.tender_Data?.submission_end_date)} ${TimeConverter(item?.tender_Data?.submission_end_date)}` : '-'}</span>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                </Link>
              </>
            )
          })

            :
            <p>No Data Found</p>
        }
      </div>
    </Drawer >
  )
}

export default TeamTaskDetail