// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Tabs, Switch } from 'antd';
import TabPane from 'antd/es/tabs/TabPane';
import { SettingOutlined } from '@ant-design/icons';
import SettingManageModel from 'BidGrid/components/Models/SettingManageModel';
import { settingApi } from 'Services/bidgrid/masterSetting/settingApi';
import { RoleList } from 'Services/bidgrid/master/role/bidRole';

const WidgetTab = () => {
    const [AddManageSetting, setAddManageSetting] = useState(false);
    const [widgetList, setWidgetList] = useState([])
    const [getRoleId, setGetRoleId] = useState('')
    const [roleList, setRoleList] = useState([])
    const [widgetRoleList, setWidgetRoleList] = useState([])
    const handleSettingManage = () => {
        setAddManageSetting(true);
    }

    const templateManageClose = () => {
        setAddManageSetting(false);
    };

    const getbidRoleTender = async () => {
        // debugger;
        try {
            const response = await RoleList.getbidRole()
            if (response?.data?.status == 1) {
                setRoleList(response?.data?.data)
                await getWidgetRoleList(response?.data?.data[0]?.id)
            }
            else {
                setRoleList([])
                // notify(response?.response?.data?.message)
            }
        } catch (error) {
            console.log(error)
        }
    };

    const handleChange = async (name, checked, widgetId) => {
        console.log(checked, widgetId, "widgit Id")
        if (checked) {
            const formData = new URLSearchParams();
            formData.append('role_id', getRoleId)
            formData.append('widget_id', widgetId)
            try {
                const response = await settingApi.updateWidgetsRole(formData)
                if (response?.data?.status === '1') {
                    await getWidgetRoleList(getRoleId)
                }
                else {
                    console.log(response?.response?.data?.message)
                }
            } catch (error) {
                console.log(error)
            }

        } else {
            const formData = new URLSearchParams();
            formData.append('role_id', getRoleId)
            formData.append('widget_id', widgetId)
            try {
                const response = await settingApi.deleteWidgetsRole(formData)
                if (response?.data?.status === '1') {
                    await getWidgetRoleList(getRoleId)
                }
                else {
                    console.log(response?.response?.data?.message)

                }
            } catch (error) {
                console.log(error)
            }
        }

    }
    // widget list
    const getwidgetList = async () => {
        try {
            const response = await settingApi.Widgetslist()
            if (response?.data?.status === '1') {
                setWidgetList(response?.data?.data)
            }
            else {
                setWidgetList([])
            }
        } catch (error) {
            console.log(error)
        }
    };

    // widget role list
    const getWidgetRoleList = async (id) => {
        // debugger;
        setGetRoleId(id)
        const formData = new URLSearchParams();
        formData.append('role_id', id)
        try {
            const response = await settingApi.getWidgetsRole(formData)
            if (response?.data?.status === '1') {
                setWidgetRoleList(response?.data?.data)
            }
            else {
                setWidgetRoleList([])
            }
        } catch (error) {
            console.log(error)
        }
    };

    const filterWidgetRole = widgetRoleList?.map(item => item?.widget_id)
    useEffect(() => {
        getwidgetList();
        getbidRoleTender();
    }, []);
    return (
        <>

            <div className="roleManagement_wrapper">

                <div className="heading_flex">
                    <h1 className="head_title">Widget</h1>
                    <button className='BG_mainButton' onClick={handleSettingManage} ><SettingOutlined />Manage Role</button>
                </div>

                <div className="tenderCycle_main">
                    <Tabs
                        tabPosition="left"
                        className="custom-tabs-container"
                    >
                        {
                            roleList?.map((item, index) => {
                                return (
                                    <TabPane
                                        tab={
                                            <div className='tab-item' key={item?.id} onClick={() => getWidgetRoleList(item?.id)} defaultActiveKey="1">
                                                <span >{item?.role_name}</span>
                                            </div>
                                        }
                                        key={index}
                                    >
                                        <div className="permissions_access_widget">
                                            {
                                                widgetList?.map((val, index) => {
                                                    return (
                                                        <div className='widgets_cards' key={index}>
                                                            <span>{val?.widget_name}</span>
                                                            <Switch checked={filterWidgetRole?.includes(val?.id)} onChange={(checked) => handleChange(val?.widget_name, checked, val?.id)} />
                                                        </div>
                                                    )
                                                })
                                            }
                                        </div>
                                    </TabPane>
                                )
                            })
                        }
                    </Tabs>
                </div>
            </div>


            <SettingManageModel templateManageClose={templateManageClose} AddManageSetting={AddManageSetting} roleList={roleList} getbidRoleTender={getbidRoleTender} />
        </>
    )
}

export default WidgetTab;


