// @ts-nocheck

import React, { useEffect, useMemo, useState } from 'react'
import 'bootstrap';
import { Table, Input, Form, Row, Col, Spin, Modal, Button } from 'antd';
import TextArea from 'antd/es/input/TextArea';

import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { bidtimezone } from "Services/bidgrid/master/timeZone/bidtimezone"
import { toast } from 'react-toastify';
const intialState = {
  timezone_name: '',
  timezone_abbr: '',
  // offset_value: '',

}
const columnLabels = {
  timezone_name: { name: 'Timezone', required: true },
  timezone_abbr: { name: 'Abbreviation', required: true },
};


const Timezone = () => {
  const [form] = Form.useForm();
  const showActions = false;
  const [msgerr, setErrorMsg] = useState(false)
  const [dataSource, setDataSource] = useState([]);
  const [timezone, setTimezone] = useState(intialState)
  const [spinner, setSpinner] = useState(false)
  const [showNotification, setShowNotification] = useState(false);
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);

  const location = useLocation();

  const val = location?.pathname;
  const str = val.replace('/', '')
  const getTimezonedata = useMemo(() => {
    return dataSource
  }, [dataSource])

  const getdata = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    try {
      const response = await bidtimezone.getTimezone()

      if (response?.data?.status == 1) {
        if (response?.data?.data.length > 0) {
          setDataSource(response?.data?.data?.sort((a, b) => a?.timezone_name?.localeCompare(b?.timezone_name)))
          setSpinner(false)
        } else {
          setDataSource([])
          setSpinner(false)
          notify(response?.response?.data?.message)
        }
      } else {
        setSpinner(false)
      }
    } catch (error) {
      setDataSource([])
      setSpinner(false)
      console.log(error, 'api erorr')
    }
  }

  const addTimezoneList = async (value) => {
    setShowNotification(true);
    const formdata = new URLSearchParams()
    formdata?.append('timezone_name', value?.timezone_name)
    formdata?.append('timezone_abbr', value?.timezone_abbr)
    try {
      const response = await bidtimezone.addTimezone(formdata)
      if (response?.data?.status == 1) {
        setSpinner(true)
        await getdata(false)
        handleReset()
        notifySuccess('Timezone Added Successfully')
      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      console.log('Api Error', error);
      setSpinner(false)
    }

    setTimeout(() => {
      setShowNotification(false);
    }, 2000);
  }

  const handleReset = () => {
    setTimezone('')
    form?.resetFields();
  };


  const handleInputChange = (name, value) => {
    setTimezone((oldData) => {
      return ({ ...oldData, [name]: value })
    })
  };

  useEffect(() => {
    getdata(true)
  }, [])

  const handleKeyPress = (e) => {
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      addTimezoneList()
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };

  const handleTimezoneChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart();
    form.setFieldsValue({ [name]: trimmedValue });
  };
  // Modal 
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  return (
    <>
      <div className='BD_master_wrapper'>

        <div className='bd_model_left'>
          <div className="heading_title">

            <h3>Time Zone</h3>
            <button className="BG_mainButton" onClick={showModal}>Add Time Zone</button>
          </div>

        </div>

        <DataTable
          columnLabels={columnLabels}
          dataSource={getTimezonedata}
          showActions={showActions}
          spinner={spinner}
          setSpinner={setSpinner}
        />
      </div>
      <Modal title="Add New Time Zone" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} centered>
        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={addTimezoneList}>
          <Form.Item label="Time Zone Name:" rules={[{ required: true, message: 'Time Zone name is required' }]} name='timezone_name' >
            <Input placeholder='Enter here' onChange={(e) => handleTimezoneChange('timezone_name', e)} />
          </Form.Item>
          <Form.Item label="Time Zone Abbreviation:" rules={[{ required: true, message: 'Time Zone abbreviationis required' }]} name='timezone_abbr' >
            <Input placeholder='Enter here' onChange={(e) => handleTimezoneChange('timezone_abbr', e)} />
          </Form.Item>
          <div className='btn_flex'>
            <Button key="back" className='BG_ghostButton'
              onClick={handleReset}
            >
              Reset
            </Button>
            <button key="submit" className='BG_mainButton' disabled={showNotification}>
              Submit
            </button>
          </div>
        </Form>
      </Modal>
    </>
  );

}

export default Timezone;
