import React, { useEffect, useMemo, useState } from 'react';
import { Spin, Row, Col, Button, Form, Input, Modal } from 'antd';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import { bidprefix } from 'Services/bidgrid/master/Prefix/bidprefix';
import { toast } from 'react-toastify';
// import 'antd/dist/antd.css';
const columnLabels = {
  prefix: { name: 'Prefix', required: true },
  verified_status: { name: 'veriified', required: true },

};

const Prefix = () => {
  const showActions = true;
  const [dataSource, setDataSource] = useState([]);
  const [form] = Form.useForm();
  const [spinner, setSpinner] = useState(false)
  const [flattenedProjects, setFlattenedProjects] = useState([]);
  const [showNotification, setShowNotification] = useState(false);

  useEffect(() => {
    const flattenedData = dataSource?.map(project => ({
      ...project,
      verified_status: project?.is_varified === '1' ? 'No' : 'Yes'
    }));

    if (flattenedData?.length > 0) {
      setFlattenedProjects(flattenedData);
    } else {
      setFlattenedProjects([])
    }
  }, [dataSource]);

  const getprefixdata = useMemo(() => {
    return flattenedProjects;
  }, [flattenedProjects]);

  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);



  // prefix list
  const getdata = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    try {
      const response = await bidprefix.getprefix();
      if (response?.data?.status === '1') {
        if (response?.data?.data.length > 0) {
          setDataSource(response?.data?.data?.sort((a, b) => a?.prefix?.localeCompare(b?.prefix)));
          setSpinner(false)
        } else {
          setSpinner(false)
          setDataSource([])
          notify(response?.response?.data?.message);
        }

      } else {
        setSpinner(false)
        setDataSource([])
      }
    } catch (error) {
      setSpinner(false)
      setDataSource([])
      console.log(error, 'api error');
    }
  };


  // prefix add
  const postPrefix = async (value) => {
    setShowNotification(true);
    const formData = new URLSearchParams();
    formData.append('prefix', value.prefix)
    try {
      await form.validateFields();
      const response = await bidprefix?.prefixAdd(formData)
      if (response?.data?.status == 1) {
        setSpinner(true)
        await getdata(false)
        notifySuccess('Prefix Added Successfully')
        handleReset()
        handleCancel()

      }
      else {
        handleCancel()

        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      handleCancel()

      console.log(error, 'Api Error')
      setSpinner(false)

    }


    setTimeout(() => {
      setShowNotification(false);
    }, 2000);

  }

  // prefix delete

  const deletePrefixData = async (modalVal) => {
    const formData = new URLSearchParams();
    formData.append('prefix_id', modalVal?.id)
    formData.append('prefix', modalVal?.prefix)

    try {
      const response = await bidprefix.deletePrefix(formData)
      if (response?.data?.status == 1) {
        setSpinner(true)
        notifySuccess('Prefix Deleted Successfully')
        await getdata(false)
      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      setSpinner(false)
    }
  }

  // prefix Update


  // const updatePrefixData = async (val) => {
  //   try {
  //     const formData = new URLSearchParams();
  //     formData.append('prefix_id', val?.id)
  //     formData.append("prefix", val?.prefix)
  //     const response = await bidprefix.updatePrefix(formData)

  //     if (response?.data?.status == 1) {
  //       setSpinner(true)
  //       await getdata(false)
  //       // notifySuccess(response?.data?.message)
  //       notifySuccess('Role Updated Successfully')

  //     }
  //     else {
  //       setSpinner(false)
  //       notify(response?.response?.data?.message)
  //     }

  //     return response;
  //   } catch (error) {
  //     setSpinner(false)
  //   }
  // }



  useEffect(() => {
    getdata(true);
  }, []);



  const handleReset = () => {
    form?.resetFields()
  };
  const handleKeyPress = (e) => {
    const forbiddenChars = /[{}.\[\]""''`~;:,\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      postPrefix({ prefix: e?.target?.value })
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };


  const handlePrefixChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart();
    form.setFieldsValue({ [name]: trimmedValue });
  };
  // Modal 
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  return (
    <>
      <div className="BD_master_wrapper">

        <div className="heading_title">

          <h3>Prefix</h3>
          <button className="BG_mainButton" onClick={showModal}>Add Prefix</button>

        </div>



        <div className="bd_model_right">
          <DataTable title="Prefix" columnLabels={columnLabels} dataSource={getprefixdata} showActions={showActions} spinner={spinner} setSpinner={setSpinner} handleDelete={deletePrefixData} getdata={getdata} />
        </div>

      </div>
      <Modal title="Add Prefix" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} centered>
        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={postPrefix} onKeyDown={handleKeyPress}>
          <Form.Item label="Prefix: " rules={[{ required: true, message: 'Please enter a prefix' }]} name='prefix' >
            <Input placeholder='Enter here' onChange={(e) => handlePrefixChange('prefix', e)} />
          </Form.Item>

          <div className='btn_flex'>
            <Button onClick={handleReset} key="back" className='BG_ghostButton'>
              Reset
            </Button>
            <button key="submit" className='BG_mainButton' disabled={showNotification}>
              Submit
            </button>
          </div>
        </Form>

      </Modal>
    </>
  );
};

export default Prefix;







