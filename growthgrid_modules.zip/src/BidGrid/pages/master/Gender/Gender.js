// @ts-nocheck
import React, { useEffect, useMemo, useState } from 'react'
import 'bootstrap';
import { Table, Input, Form, Row, Col, Spin, Button, Modal } from 'antd';
import TextArea from 'antd/es/input/TextArea';

import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { bidgender } from "../../../../Services/bidgrid/master/gender/bidgender"
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const Gender = () => {
  const showActions = false;
  const [dataSource, setDataSource] = useState([]);
  const [form] = Form.useForm();
  const [genderName, setGenderName] = useState('')
  const [spinner, setSpinner] = useState(false)

  const [showNotification, setShowNotification] = useState(false);
  const getGenderdata = useMemo(() => {
    return dataSource
  }, [dataSource])

  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);


  const handleInputChange = (e) => {
    const inputValue = e.target.value;
    if (inputValue.startsWith(' ')) {
      return;
    } else {
      if (/^\d+$/.test(inputValue)) {
        return;
      }
    }
    setGenderName(inputValue);
  };

  const getdata = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    try {
      const response = await bidgender.getgender()
      if (response?.data?.status == 1) {
        if (response?.data?.data?.length > 0) {
          setDataSource(response?.data?.data?.sort((a, b) => a?.unit_name?.localeCompare(b?.unit_name)))
          setSpinner(false)
        } else {
          setDataSource([])
          setSpinner(false)
        }
      } else {
        setSpinner(false)
      }
    } catch (error) {
      setDataSource([])
      setSpinner(false)
      console.log(error, 'api erorr')
    }
  }

  const postGender = async (value) => {
    setShowNotification(true);
    const formData = new URLSearchParams();
    formData.append('gender_name', value?.gender)
    try {
      await form.validateFields();
      const response = await bidgender?.genderAdd(formData)
      if (response?.data?.status == 1) {
        setSpinner(true)
        await getdata(false)
        notifySuccess('Gender Added Successfully')
        handleReset()

      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      setSpinner(false)
    }

    setTimeout(() => {
      setShowNotification(false);
    }, 2000);
  }

  useEffect(() => {
    getdata(true)
  }, [])



  const columnLabels = {
    gender_name: { name: 'Gender', required: true },

  };

  const location = useLocation();

  const val = location?.pathname;
  const str = val.replace('/', '')

  const handleReset = () => {
    form.resetFields()
  };
  const handleKeyPress = (e) => {
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      postGender()
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };

  useEffect(() => {
    const handleClickOutsideForm = (event) => {
      const genderErrors = form.getFieldError('gender');

      if (genderErrors.length > 0) {
        form.setFields([
          {
            name: 'gender',
            errors: [],
          },
        ]);
      }
    };

    document.addEventListener('click', handleClickOutsideForm);

    return () => {
      // Cleanup the event listener when the component unmounts
      document.removeEventListener('click', handleClickOutsideForm);
    };
  }, [form]);
  const handleGenderChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart();
    form.setFieldsValue({ [name]: trimmedValue });
  };
  // Modal 
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  return (
    <>
      <div className='BD_master_wrapper'>

        <div className="heading_title">

          <h3>Gender</h3>
          <button className="BG_mainButton" onClick={showModal}>Gender</button>
        </div>


        <div className='bd_model_right'>
          <DataTable columnLabels={columnLabels} dataSource={getGenderdata} showActions={showActions}
            spinner={spinner}
            setSpinner={setSpinner}
          />
        </div>

      </div>
      <Modal title="Add Gender" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} centered>

        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" className='bd_model_form' onFinish={postGender}>
          <Form.Item label="Gender" name='gender' rules={[{ required: true, message: 'Please enter a gender.' }]}>
            <Input placeholder='Enter here' onChange={(e) => handleGenderChange('gender', e)} />

          </Form.Item>

          <div className='btn_flex'>
            <Button onClick={handleReset} key="back" className='BG_ghostButton' >
              Reset
            </Button>
            <button key="submit" className='BG_mainButton' disabled={showNotification}>
              Submit
            </button>
          </div>
        </Form>
      </Modal>
    </>

  )
}

export default Gender;
