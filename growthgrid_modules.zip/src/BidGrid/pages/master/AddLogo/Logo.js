// @ts-nocheck
import React, { useEffect, useState } from 'react';
import user from '../../../assets/images/profile.jpg';
import { Form, Row, Col, Upload } from 'antd';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import { useLocation } from 'react-router';
import { LogoApi } from 'Services/bidgrid/master/company Logo/bidLogo';
import { toast } from 'react-toastify';
import { useSelector, useDispatch } from 'react-redux';
import { userBidInfoAction } from 'Redux/actions/common/userInfoAction';
import { docurlchat } from 'utils/configurable';

const Logo = () => {
    const { userBidInfo } = useSelector((state) => state?.userDetails)
    const dispatch = useDispatch();

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const location = useLocation();

    const val = location?.pathname;
    const str = val.replace('/', '')


    const CompanyLogo = async () => {
        try {
            const response = await LogoApi.getLogo()
            if (response?.data?.status == 1) {
                dispatch(userBidInfoAction({
                    ...userBidInfo,
                    thumbnailPath: userBidInfo.thumbnailPath,
                    thumbnailName: userBidInfo.thumbnailName,
                    docname: response.data.data.logo_file_name,
                    docpath: response.data.data.logo_file_path
                }));
            }
            else {
                notify(response?.response?.data?.message)
            }
        } catch (error) {
            console.log(error)
        }
    };

    const handleImageChange = async (e) => {
        const selectedImage = e.target.files[0];
        const formData = new FormData();
        formData.append('logo_file', selectedImage);

        try {
            const response = await LogoApi.addLogo(formData);
            if (response?.data?.status === '1') {
                notifySuccess('Logo Updated Successfully');
                CompanyLogo();
            } else {
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            console.error('API Error:', error);
            notify('Error updating logo');
        }
    };


    const updateThumbnail = async (e, isUpDate) => {
        const selectedImage = e?.target?.files[0];
        const formData = new FormData();

        {
            isUpDate &&
                formData.append('thumbnail_file', selectedImage);
        }

        try {
            const response = await LogoApi.addThumbnail(formData);
            if (response?.data?.status === '1') {
                if (isUpDate) {
                    notifySuccess('Thumbnail Updated Successfully');
                }
                dispatch(userBidInfoAction({
                    ...userBidInfo,
                    docname: userBidInfo.docname,
                    docpath: userBidInfo.docpath,
                    thumbnailPath: response?.data?.data?.thumbnail_file_path,
                    thumbnailName: response?.data?.data?.thumbnail_file_name,

                }));
            } else {
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            console.error('API Error:', error);
        }
    };



    useEffect(() => {
        CompanyLogo();
        updateThumbnail(false)
    }, []);

    return (
        <>
            <div className="BD_master_wrapper">
                <h3>Add Logo</h3>
                <Form
                    layout="vertical"
                >
                    <Row gutter={20}>
                        <Col sm={8}>
                            <div className='bd_logo_image'>
                                <img className="bd_main_sub_s_img"
                                    src={`${docurlchat}${userBidInfo.docpath}/${userBidInfo.docname}`}
                                    alt={userBidInfo.docname} />

                            </div>
                        </Col>

                        <Col sm={4}>
                            <label className='BG_ghostButton' style={{ justifyContent: "center" }}>
                                Update Logo
                                <input
                                    className='input_update_file'
                                    type="file"
                                    accept="image/*"
                                    onChange={handleImageChange}
                                />
                            </label>
                        </Col>

                        <Col sm={8}>
                            <div className='bd_logo_image'>
                                <img className="bd_main_sub_s_img"
                                    src={`${docurlchat}${userBidInfo.thumbnailPath}/${userBidInfo.thumbnailName}`}
                                    alt={userBidInfo.thumbnailName} />

                            </div>
                        </Col>

                        <Col sm={4}>
                            <label className='BG_ghostButton' style={{ justifyContent: "center" }}>
                                Thumbnail
                                <input
                                    className='input_update_file'
                                    type="file"
                                    accept="image/*"
                                    onChange={(e) => updateThumbnail(e, true)}
                                />
                            </label>
                        </Col>

                    </Row>

                </Form>
            </div>
        </>
    )

};
export default Logo;
