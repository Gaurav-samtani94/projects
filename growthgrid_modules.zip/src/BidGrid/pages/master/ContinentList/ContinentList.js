// @ts-nocheck
import React, { useEffect, useMemo, useState } from 'react'
import 'bootstrap';
import { Table, Input, Form, Row, Col, Modal, Button, Space, Drawer, Dropdown, Select, DatePicker, InputNumber, Spin } from 'antd';
import TextArea from 'antd/es/input/TextArea';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { RoleList } from "Services/bidgrid/master/role/bidRole"
import DrawerSection from 'BidGrid/components/Drawer/Drawer';
import { bidContinent } from 'Services/bidgrid/continent/bidContinent';
const { Search } = Input;
const { Option } = Select;

const notify = (error) => toast.error(error);
const notifySuccess = (msg) => toast.success(msg);
const columnLabels = {
  continent_name: { name: 'continent', required: true },
};


const ContinentList = () => {
  const showActions = true;
  const [form] = Form.useForm();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const [isEditFields, setIsEditFields] = useState({})
  const [spinner, setSpinner] = useState(false)

  const [showNotification, setShowNotification] = useState(false);
  const [continentName, setContinentName] = useState('')
  const val = location?.pathname;
  const str = val.replace('/', '')

  // new dec. state 
  const [dataSource, setDataSource] = useState([])
  const tableContinentData = useMemo(() => {
    return dataSource
  }, [dataSource])

  const onClose = () => {
    setOpen(false);
  };


  const getdata = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    try {
      const response = await bidContinent.getContinent()
      if (response?.data?.status == 1) {
        if (response?.data?.data.length > 0) {
          setDataSource(response?.data?.data)
          setSpinner(false)
        } else {
          setSpinner(false)
          setDataSource([])
          notify(response?.response?.data?.message)
        }

      } else {
        setSpinner(false)
      }
    } catch (error) {
      setSpinner(false)
      setDataSource([])
      console.log(error, 'api erorr')
    }
  }

  const addContinentList = async (value) => {
    setShowNotification(true);
    const formdata = new URLSearchParams()
    formdata?.append('continent_name', value.continentName)
    try {
      const response = await bidContinent.addContinent(formdata)
      if (response?.data?.status == 1) {
        setSpinner(true)
        await getdata(false)
        notifySuccess('Continent Added Successfully')
        handleReset()
      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      setSpinner(false)
    }
    setTimeout(() => {
      setShowNotification(false);
    }, 2000);
  }


  useEffect(() => {
    getdata(true)
  }, [])


  const handleKeyPress = (e) => {
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      addContinentList();
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };
  const handleInputChange = (e) => {
    setContinentName(e.target.value);
  };

  const handleReset = () => {
    setContinentName('');
    form.resetFields()
  };
  useEffect(() => {
    const handleClickOutsideForm = (event) => {
      const ContinentErrors = form.getFieldError('continentName');

      if (ContinentErrors.length > 0) {
        form.setFields([
          {
            name: 'continentName',
            errors: [],
          },
        ]);
      }
    };

    document.addEventListener('click', handleClickOutsideForm);

    return () => {
      // Cleanup the event listener when the component unmounts
      document.removeEventListener('click', handleClickOutsideForm);
    };
  }, [form]);
  const handleContinentChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart();
    form.setFieldsValue({ [name]: trimmedValue });
  };
  // Modal 
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  return (

    <>
      <div className='BD_master_wrapper'>

        <div className='bd_model_left'>
          <div className="heading_title">

            <h3> Continent </h3>
            <button className="BG_mainButton" onClick={showModal}>Add Continent</button>
          </div>

        </div>

        <DataTable
          setOpen={setOpen}
          columnLabels={columnLabels}
          dataSource={tableContinentData}
          spinner={spinner}
          setSpinner={setSpinner}
        />

      </div>
      <Modal title="Add New Continent" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} centered>

        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" className='bd_model_form' onFinish={addContinentList}>
          <Form.Item label="Continent" name='continentName' rules={[{ required: true, message: 'Continent name is required' }]}>
            <Input placeholder='Enter here' onChange={(e) => handleContinentChange('continentName', e)} />
          </Form.Item>
          <div className='btn_flex'>
            <Button key="back" className='BG_ghostButton' onClick={handleReset} >
              Reset
            </Button>
            <button key="submit" className='BG_mainButton' disabled={showNotification}>
              Submit
            </button>
          </div>
        </Form>
      </Modal>
    </>
  )
}

export default ContinentList;
