// @ts-nocheck
import React, { useEffect, useMemo, useState } from 'react'
import 'bootstrap';
import { Table, Input, Form, Row, Col, Spin, Button, Modal } from 'antd';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { bidemployees } from "../../../../Services/bidgrid/master/employeeStatus/employeeStatus"
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const columnLabels = {
  employeement_status_name: { name: 'Employee Status', required: true },

};

const EmployeeStatus = () => {

  const showActions = false;
  const [dataSource, setDataSource] = useState([]);
  const [form] = Form.useForm();
  const [employeeStatus, setemployestatus] = useState('')
  const [spinner, setSpinner] = useState(false)
  const [showNotification, setShowNotification] = useState(false);
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);
  const location = useLocation();
  const val = location?.pathname;
  const str = val.replace('/', '')
  const getemployeesdata = useMemo(() => {
    return dataSource
  }, [dataSource])

  const handleInputChange = (e) => {
    const inputValue = e.target.value;
    if (inputValue.startsWith(' ')) {
      return;
    } else {
      if (/^\d+$/.test(inputValue)) {
        return;
      }
    }
    setemployestatus(inputValue);
  };

  const getdata = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    try {
      const response = await bidemployees.getemployeestatus()

      if (response?.data?.status == 1) {
        if (response?.data?.data?.length > 0) {
          setDataSource(response?.data?.data?.sort((a, b) => a?.unit_name?.localeCompare(b?.unit_name)))
          setSpinner(false)
        } else {
          setDataSource([])
          setSpinner(false)
        }
      } else {
        setSpinner(false)
      }
    } catch (error) {
      setDataSource([])
      setSpinner(false)
      console.log(error, 'api erorr')
    }
  }

  const postemployeestatus = async (value) => {
    setShowNotification(true);
    const formData = new URLSearchParams();
    formData.append('employeement_status_name', value?.employeeStatus)
    try {
      await form.validateFields();
      const response = await bidemployees?.postemployeeAdd(formData)
      if (response?.data?.status == 1) {
        setSpinner(true)
        getdata(false)
        notifySuccess('Employee Status Added Successfully')
        handleReset()


      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      setSpinner(false)
    }
    setTimeout(() => {
      setShowNotification(false);
    }, 2000);
  }



  useEffect(() => {
    getdata(true)
  }, [])

  const handleReset = () => {
    form.resetFields()
  };
  const handleKeyPress = (e) => {
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      postemployeestatus()
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };

  useEffect(() => {
    const handleClickOutsideForm = (event) => {
      const employeeStatusErrors = form.getFieldError('employeeStatus');

      if (employeeStatusErrors.length > 0) {
        form.setFields([
          {
            name: 'employeeStatus',
            errors: [],
          },
        ]);
      }
    };

    document.addEventListener('click', handleClickOutsideForm);

    return () => {
      // Cleanup the event listener when the component unmounts
      document.removeEventListener('click', handleClickOutsideForm);
    };
  }, [form]);
  const handleStatusChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart();
    form.setFieldsValue({ [name]: trimmedValue });
  };
  // Modal 
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  return (
    <>
      <div className='BD_master_wrapper'>

        <div className="heading_title">

          <h3>Employee Status</h3>
          <button className="BG_mainButton" onClick={showModal}>Employee status</button>

        </div>


        <div className='bd_model_right'>
          <DataTable columnLabels={columnLabels} dataSource={getemployeesdata} showActions={showActions}
            spinner={spinner}
            setSpinner={setSpinner}
          />
        </div>

      </div>
      <Modal title="Create Employee Status" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} centered>


        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" className='bd_model_form' onFinish={postemployeestatus}>
          <Form.Item label="Employee Status: " name='employeeStatus' rules={[{ required: true, message: 'Please enter an employee status.' }]} >
            <Input placeholder='Enter here' onChange={(e) => handleStatusChange('employeeStatus', e)}
            />

          </Form.Item>

          <div className='btn_flex'>
            <Button onClick={handleReset} key="back" className='BG_ghostButton'>
              Reset
            </Button>
            <button key="submit" className='BG_mainButton' disabled={showNotification}>
              Submit
            </button>
          </div>
        </Form>
      </Modal>
    </>

  )
}

export default EmployeeStatus;
