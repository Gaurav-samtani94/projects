//@ts-nocheck
import React, { useEffect, useState, useMemo } from 'react'
import 'bootstrap';
import { Input, Form, Modal, Button, Select } from 'antd';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SettingTable from 'BidGrid/components/dataTable/SettingTable';
import { bidRegion } from 'Services/bidgrid/master/region/region';
import { useSelector } from 'react-redux';

const columnLabels = {
  region_name: { name: 'Region Name' },
};

const initialState = {
  region_name: "",
  country_id: 1
}

const RegionList = () => {
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState([])
  const [modalForm, setModalForm] = useState(initialState)
  const [spinner, setSpinner] = useState(false)
  const [modal, setModal] = useState(false);
  const [countryVal, setCountryVal] = useState([])
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);
  const { BidCountry } = useSelector((state) => state.bidDropdownCalVal)

  const tableData = useMemo(() => {
    return dataSource;
  }, [dataSource]);

  const getRegion = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    const formData = new URLSearchParams();
    formData.append('country_id', modalForm?.country_id);
    try {
      const response = await bidRegion.getRegionList(formData)
      if (response?.data?.data?.length > 0) {
        setDataSource(response?.data?.data?.sort((a, b) => a?.unit_name?.localeCompare(b?.unit_name)))
      } else {
        setDataSource([])
      }
    } catch (error) {
      setDataSource([])
    } finally {
      setSpinner(false)
    }
  }


  const addHandler = async () => {
    setSpinner(true);
    const formData = new URLSearchParams();
    formData.append("country_id", modalForm?.country_id);
    formData.append("region_name", modalForm?.region_name);
    try {
      const response = await bidRegion.createRegion(formData)
      if (response?.data?.status === '1') {
        await getRegion(false);
        notifySuccess('Region Added Successfully')
        handleCancel()
      } else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      setSpinner(false)
      notify(error)
    }
  }

  useEffect(() => {
    getRegion(true)

  }, [])
  const handleRegionChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart()
    form.setFieldsValue({ [name]: trimmedValue });
    setModalForm({
      ...modalForm,
      [name]: trimmedValue
    })
  };
  const handleCountry = (name, e) => {
    form.setFieldsValue({ [name]: e });
    setModalForm({
      ...modalForm,
      [name]: e
    })
  }

  const showModal = () => {
    setModal(true);
  };

  const hideModal = () => {
    setModal(false)
  }

  const handleReset = () => {
    setModalForm(initialState)
    form.resetFields()
  }

  const handleCancel = () => {
    hideModal();
    handleReset()
  };
  return (

    <>
      <div className='BD_master_wrapper'>

        <div className='bd_model_left'>
          <div className="heading_title">

            <h3>Region</h3>
            <button className="BG_mainButton" onClick={showModal}>Add Region</button>
          </div>

        </div>

        <SettingTable
          title='Country Detail'
          columnLabels={columnLabels}
          dataSource={tableData}
          showActions={false}
          spinner={spinner}
        />
      </div>
      <Modal title="Add Region" open={modal} onCancel={handleCancel} footer={null} centered>

        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={addHandler}>
          <Form.Item label="Country:" name='country_id' rules={[{ required: true, message: 'Country is required !' }]}>
            <Select
              allowClear
              showSearch
              placeholder="Select country"
              value={modalForm?.country_id}
              onChange={(value) => handleCountry('country_id', value)}
              options={BidCountry?.map((item, index) => {
                return {
                  value: item?.id,
                  label: item?.country_name
                }
              })}
              filterOption={(input, option) =>
                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >

            </Select>
          </Form.Item>
          <Form.Item label="Region:" name='region_name'
            rules={[{ required: true, message: 'Region name is required' }]}>
            <Input placeholder='Enter here' value={modalForm?.region_name} onChange={(e) => handleRegionChange('region_name', e)} />
          </Form.Item>

          <div className='btn_flex'>
            <Button disabled={spinner} onClick={() => handleReset()} key="back" className='BG_ghostButton'>
              Reset
            </Button>
            <Button className='BG_mainButton' type="primary" htmlType="submit" loading={spinner} disabled={spinner} > Submit </Button>
          </div>
        </Form>
      </Modal>
    </>
  )
}

export default RegionList;
