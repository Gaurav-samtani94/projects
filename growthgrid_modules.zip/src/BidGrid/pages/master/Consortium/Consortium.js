// @ts-nocheck
import React, { useState, useEffect, useMemo } from 'react'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap';
import SettingTable from 'BidGrid/components/dataTable/SettingTable';
import { ConsortiumList } from 'Services/bidgrid/master/consortium/Consortium';

const notify = (error) => toast.error(error);

const columnLabels = {
    consortium_type: { name: 'Consortium', required: true },
};

const Consortium = () => {

    const [dataSource, setDataSource] = useState()
    const [spinner, setSpinner] = useState(false)


    const tableData = useMemo(() => {
        return dataSource;
    }, [dataSource]);

    const getConsortium = async (initial) => {
        if (initial) {
            setSpinner(true)
        }
        try {
            const response = await ConsortiumList.getConsortiumList()
            if (response?.data?.status == 1) {
                if (response?.data?.data?.length > 0) {
                    setDataSource(response?.data?.data?.sort((a, b) => a?.unit_name?.localeCompare(b?.unit_name)))
                } else {
                    setDataSource([])
                }
            }
        } catch (error) {
            setDataSource([])
            notify(error);
        } finally {
            setSpinner(false)

        }
    }

    useEffect(() => {
        getConsortium(true)
    }, [])

    return (
        <>
            <div className='BD_master_wrapper'>
                <div className="heading_title">
                    <h3>Consortium List</h3>
                </div>
                <SettingTable
                    title='Consortium Detail'
                    columnLabels={columnLabels}
                    dataSource={tableData}
                    showActions={false}
                    spinner={spinner}
                />
            </div>
        </>
    )
}

export default Consortium;
