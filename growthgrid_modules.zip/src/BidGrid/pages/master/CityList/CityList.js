// @ts-nocheck
import React, { useEffect, useMemo, useState } from 'react'
import 'bootstrap';
import { Form, Row, Col, Select, Input, Button, Modal } from 'antd';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import 'react-toastify/dist/ReactToastify.css';
import { Locations } from '../../../../Services/bidgrid/master/locations/index'
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';
import SettingTable from 'BidGrid/components/dataTable/SettingTable';

const columnLabels = {
  city_name: { name: 'City Name' },
};
const initialState = {
  country_name: null,
  state_name: null,
}

const initialFilter = {
  country_name: null,
  state_name: null,
  city_name: ""

}

const CityList = () => {
  const [form] = Form.useForm();
  const [modalForm, setModalForm] = useState(initialState)
  const [cityFilter, setCityFilter] = useState(initialFilter)
  const [modal, setModal] = useState(false);
  const [dataSource, setDataSource] = useState([])
  const [stateVal, setStateVal] = useState([])
  const [filterStateList, setFilterStateList] = useState([])
  const [spinner, setSpinner] = useState(false)
  const { BidCountry } = useSelector((state) => state.bidDropdownCalVal)

  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);

  const tableData = useMemo(() => {
    return dataSource
  }, [dataSource])




  //get state
  const getModalState = async () => {
    const formData = new URLSearchParams();
    formData.append("country_id", modalForm?.country_name);
    try {
      const response = await Locations.GetStateList(formData)
      if (response?.data?.data.length > 0) {
        setStateVal(response?.data?.data)
      } else {
        setStateVal([])
      }
    } catch (error) {
      setStateVal([])
    }
  }

  //fetch city list
  const getCity = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    const formData = new URLSearchParams();
    formData.append("state_id", cityFilter?.state_name);
    try {
      const response = await Locations.GetCityList(formData)
      if (response?.data?.data.length > 0) {
        setDataSource(response?.data?.data)
      } else {
        setDataSource([])
      }
    } catch (error) {
      setDataSource([])
    } finally {
      setSpinner(false)
    }
  }

  const handleCityChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart();
    form.setFieldsValue({ [name]: trimmedValue });
    setModalForm({
      ...modalForm,
      city_name: trimmedValue
    })
  };

  // filter functions 


  const getFilterState = async () => {

    const formData = new URLSearchParams();
    formData.append("country_id", cityFilter?.country_name);
    try {
      const response = await Locations.GetStateList(formData)
      if (response?.data?.status === '1') {
        setFilterStateList(response?.data?.data)
      } else {
        setFilterStateList([])
      }
    } catch (error) {
      setFilterStateList([])
    }
  }


  // filter handle change 
  const handleChangeFilter = (name, value) => {
    if (name === 'country_name') {
      setCityFilter({
        ...cityFilter,
        [name]: value,
        state_name: null
      })
      setFilterStateList(null)
    } else {
      setCityFilter({
        ...cityFilter,
        [name]: value,
      })

    }
  }

  // modal handle change 
  const handleModalChange = (name, value) => {
    if (name === 'country_name') {
      setModalForm({
        ...modalForm,
        [name]: value,
        state_name: null
      })
      setStateVal(null)
      form.setFieldsValue({ [name]: value, state_name: null });

    } else {
      setModalForm({
        ...modalForm,
        [name]: value,
      })
      form.setFieldsValue({ [name]: value });

    }
  }


  // inital filter country render
  useEffect(() => {
    if (BidCountry?.length > 0) {
      setCityFilter({
        ...cityFilter,
        country_name: BidCountry[0]?.id,
      })
    }
  }, [])

  // initial filter state render
  useEffect(() => {
    if (cityFilter?.country_name) {
      getFilterState();
    }
  }, [cityFilter?.country_name])

  // inital filter state render
  useEffect(() => {
    if (filterStateList?.length > 0) {
      setCityFilter({
        ...cityFilter,
        state_name: filterStateList[0]?.id,
      })
    }
  }, [filterStateList])

  // initial get city list
  useEffect(() => {
    if (cityFilter?.state_name) {
      getCity(true)
    }
  }, [cityFilter?.state_name])

  // modal state values
  useEffect(() => {
    if (modalForm?.country_name) {
      getModalState();
    }
  }, [modalForm?.country_name])


  const showModal = () => {
    setModal(true);
  };



  const addHandler = async () => {
    setSpinner(true)
    const formData = new URLSearchParams();
    formData.append('state_id', modalForm?.state_name)
    formData.append('city_name', modalForm?.city_name)
    try {
      const response = await Locations?.postCityList(formData)
      if (response?.data?.status === '1') {
        await getCity(false)
        notifySuccess('City Added Successfully')
        hideModal()
      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      notify(error)
      setSpinner(false)
    }
  }

  const hideModal = () => {
    setModal(false);
    form.resetFields()
    setModalForm(initialState)
  }
  return (
    <>
      <div className='BD_master_wrapper'>

        <div className="heading_title">

          <div className="d-flex">
            <h3>City</h3>
            <Form.Item >
              <Select
                allowClear
                showSearch
                style={{
                  width: 155,
                }}
                value={cityFilter?.country_name}
                name='country_name'
                onChange={(value) => handleChangeFilter('country_name', value)}
                options={BidCountry?.map((item, index) => {
                  return { label: item?.country_name, value: item?.id };
                })}
                filterOption={(input, option) =>
                  option?.label?.toLowerCase()?.indexOf(input?.toLowerCase()) >= 0
                }
              />
            </Form.Item>

            <Form.Item >
              <Select
                allowClear
                showSearch
                style={{
                  width: 155,
                }}
                value={cityFilter?.state_name}
                name='state_name'
                onChange={(value) => handleChangeFilter('state_name', value)}
                options={filterStateList?.map((item, index) => {
                  return { label: item?.state_name, value: item?.id };
                })}
                filterOption={(input, option) =>
                  option?.label?.toLowerCase().indexOf(input?.toLowerCase()) >= 0
                }
              />
            </Form.Item>
          </div>
          <button className="BG_mainButton" onClick={showModal}>Add City</button>
        </div>

        <SettingTable
          title='City Detail'
          columnLabels={columnLabels}
          dataSource={tableData}
          showActions={false}
          spinner={spinner}
        />


      </div>
      <Modal title="Add City" open={modal} onCancel={hideModal} footer={null} centered>

        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" className='bd_model_form' onFinish={addHandler}>
          <Form.Item label="Country:" rules={[{ required: true, message: 'Country name is required' }]} name='country_name'>
            <Select
              allowClear
              showSearch
              placeholder="Select Country"
              value={modalForm?.country_name}
              onChange={(value) => handleModalChange('country_name', value)}
              options={BidCountry.map((item, index) => {
                return { label: item?.country_name, value: item?.id };
              })}
              filterOption={(input, option) =>
                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            />
          </Form.Item>
          <Form.Item label="State:" rules={[{ required: true, message: 'State name is required' }]} name='state_name'>
            <Select
              allowClear
              showSearch
              placeholder="Select State"
              value={modalForm?.state_name}
              onChange={(value) => handleModalChange('state_name', value)}
              options={stateVal?.map((item, index) => {
                return { label: item?.state_name, value: item?.id };
              })}
              filterOption={(input, option) =>
                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            />
          </Form.Item>
          <Form.Item label="City: " rules={[{ required: true, message: 'City name is required' }]} name='city_name'>
            <Input placeholder='Enter here' onChange={(e) => handleCityChange('city_name', e)}
            />

          </Form.Item>

          <div className='btn_flex'>
            <Button onClick={() => { setModalForm(initialState); form.resetFields() }} disabled={spinner} key="back" className='BG_ghostButton'>
              Reset
            </Button>
            <Button className='BG_mainButton' type="primary" htmlType="submit" loading={spinner} disabled={spinner} > Submit</Button>
          </div>
        </Form>

      </Modal>

    </>
  )
}

export default CityList;

