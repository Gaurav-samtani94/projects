// @ts-nocheck
import React, { useEffect, useMemo, useState } from 'react'
import 'bootstrap';
import { Table, Button, Input, Form, Row, Modal, Col, Space, Drawer, Dropdown, Select, DatePicker, InputNumber, Spin } from 'antd';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { bidLanguage } from 'Services/bidgrid/master/Language/bidlanguage';
import { toast } from 'react-toastify';


const Language = () => {
    const [form] = Form.useForm();
    const showActions = false;
    const [dataSource, setDataSource] = useState([])
    const [languageName, setLanguageName] = useState('')
    const [spinner, setSpinner] = useState(false)
    const [showNotification, setShowNotification] = useState(false);
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const columnLabels = {
        language_name: { name: 'Language', required: true },
    };


    const location = useLocation();

    const val = location?.pathname;
    const str = val.replace('/', '')




    const getliveTenders = useMemo(() => {
        return dataSource
    }, [dataSource])


    const getdata = async (initial) => {
        if (initial) {
            setSpinner(true)
        }
        try {
            const response = await bidLanguage.getLanguage()
            if (response?.data?.status == 1) {
                if (response?.data?.data.length > 0) {
                    setDataSource(response?.data?.data?.sort((a, b) => a?.language_name?.localeCompare(b?.language_name)))
                    setSpinner(false)
                } else {
                    setSpinner(false)
                    setDataSource([])
                    notify(response?.response?.data?.message)
                }
            } else {
                setSpinner(false)
            }
        } catch (error) {
            setSpinner(false)
            setDataSource([])
            console.log(error, 'api erorr')
        }
    }

    const addLanguage = async (value) => {
        setShowNotification(true);
        const formdata = new URLSearchParams()
        formdata?.append('language_name', value.language)
        try {
            const response = await bidLanguage.postLanguage(formdata)
            if (response?.data?.status == 1) {
                setSpinner(true)
                await getdata(false)
                notifySuccess('Language Added Successfully')
                handleReset()

            }
            else {
                notify(response?.response?.data?.message)
                // handleReset()
                setSpinner(false)
            }
        } catch (error) {
            console.log('Api Error', error);
            setSpinner(false)

        }

        setTimeout(() => {
            setShowNotification(false);
        }, 2000);
    }

    const handleReset = () => {
        form.resetFields()
    };

    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            addLanguage();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleInputChange = (e) => {
        const value = e.target.value;
        setLanguageName(value);
    }

    useEffect(() => {
        getdata(true)
        // addLanguage()
    }, [])

    // remove validation error click on outside form 
    useEffect(() => {
        const handleClickOutsideForm = (event) => {
            const languageErrors = form.getFieldError('language');

            if (languageErrors.length > 0) {
                form.setFields([
                    {
                        name: 'language',
                        errors: [],
                    },
                ]);
            }
        };

        document.addEventListener('click', handleClickOutsideForm);

        return () => {
            // Cleanup the event listener when the component unmounts
            document.removeEventListener('click', handleClickOutsideForm);
        };
    }, [form]);




    // <Form.Item label="Tender Value (Cr.)">
    //   <Input
    //     name='tender_value'
    //     value={selectedOption?.tender_value}
    //     onChange={(e) => handleSelectChange('tender_value', e.target.value.replace(/[^0-9.]/g, ''))}
    //   />
    // </Form.Item>
    const handleLanguageChange = (name, e) => {
        const trimmedValue = e.target.value.trimStart();
        form.setFieldsValue({ [name]: trimmedValue });
    };
    // Modal 
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = () => {
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
    };
    return (
        <>
            <Breadcrumb data={str} />
            <div className='BD_master_wrapper'>

                <div className='bd_model_left'>
                    <div className="heading_title">

                        <h3>Language</h3>
                        <button className="BG_mainButton" onClick={showModal}>Language</button>

                    </div>
                </div>
                <DataTable
                    columnLabels={columnLabels}
                    dataSource={getliveTenders}
                    showActions={showActions}
                    spinner={spinner}
                    setSpinner={setSpinner}
                />

            </div >
            <Modal title="Add New Language" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} centered>

                <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={addLanguage}>
                    <Form.Item label="Language:" rules={[{ required: true, message: 'Language name is required.' }]} name='language' >
                        <Input placeholder='Enter here' onChange={(e) => handleLanguageChange('language', e)} />
                    </Form.Item>
                    <div className='btn_flex'>
                        <Button key="back" className='BG_ghostButton' onClick={handleReset} >
                            Reset
                        </Button>
                        <button key="submit" className='BG_mainButton' disabled={showNotification}>
                            Submit
                        </button>
                    </div>
                </Form>
            </Modal>
        </>

    )
}

export default Language;
