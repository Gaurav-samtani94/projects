import React from 'react'
import 'bootstrap';
import { Table, Input, Form, Row, Col, Space, Drawer, Dropdown, Select, DatePicker, InputNumber, Spin } from 'antd';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { Down } from '@icon-park/react';

const Keyword = () => {
    const showActions = false;

    const columnLabels = {
        // srNo: '#',
        categ: { name: "Sector Name", required: true },
        subCateg: { name: 'Keywords', required: true },


    };


    const dataSource = [
        {
            srNo: 1,
            categ: 'Buildings & Housingr',
            subCateg: 'AIMS',
        },
        {
            srNo: 2,
            categ: 'Buildings & Housing',
            subCateg: 'airport',
        },
        {
            srNo: 3,
            categ: 'Buildings & Housing',
            subCateg: 'metro',
        },
        {
            srNo: 4,
            categ: 'Water & Environmental',
            subCateg: 'port',
        },
        {
            srNo: 5,
            categ: 'Metals and Mining',
            subCateg: 'airport',
        },
        {
            srNo: 6,
            categ: 'Road and Highway',
            subCateg: 'Aims',
        },

    ];
    const location = useLocation();

    const val = location?.pathname;
    const str = val.replace('/', '')

    return (
        <>
            <div className='BD_master_wrapper'>
                <h3>keyword List</h3>
                <Row gutter={60}>
                    <Col span={24}>
                        <div className='bd_model_right'>
                            <DataTable columnLabels={columnLabels} dataSource={dataSource} showActions={showActions} />
                        </div>
                    </Col>
                </Row>
            </div>
        </>

    )
}

export default Keyword;
