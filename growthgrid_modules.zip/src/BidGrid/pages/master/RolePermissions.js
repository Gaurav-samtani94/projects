// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Switch, Tabs, Collapse, Result } from 'antd';
import { CrownOutlined, SettingOutlined } from '@ant-design/icons';
import { RoleList } from 'Services/bidgrid/master/role/bidRole';
import { settingApi } from 'Services/bidgrid/masterSetting/settingApi';
import SettingManageModel from 'BidGrid/components/Models/SettingManageModel';
import { Down, Right, ViewGridDetail, Info, FileExcel, Bookshelf, WalletThree } from '@icon-park/react';
import { toast } from 'react-toastify';


const { TabPane } = Tabs;
const { Panel } = Collapse;

const RolePermissions = () => {
    const [AddManageSetting, setAddManageSetting] = useState(false);
    const [getRoleId, setGetRoleId] = useState(null)
    const [roleList, setRoleList] = useState([])
    const [menuData, setMenuData] = useState([])
    const [disableOption, setDisableOption] = useState(false)

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const handleSettingManage = () => {
        setAddManageSetting(true);
    }

    const templateManageClose = () => {
        setAddManageSetting(false);
    };

    const getbidRoleTender = async () => {
        try {
            const response = await RoleList.getbidRole()
            if (response?.data?.status == 1) {
                setRoleList(response?.data?.data)
                setGetRoleId(response?.data?.data[0]?.id)
            }
            else {
                setRoleList([])
            }
        } catch (error) {
            console.log(error)
        }
    };
    // menu list
    const fetchMenuList = async () => {
        const formData = new URLSearchParams();
        formData.append('role_id', getRoleId !== null ? getRoleId : roleList[0]?.id)
        // formData.append('role_id', '1')


        try {
            const response = await RoleList.menuList(formData)
            if (response?.data?.status == 1) {

                let dataVal = response?.data?.data;

                const newData = dataVal?.filter(val => val?.parent_menu_id === 0)?.map(item => {
                    const children = dataVal?.filter(child => child?.parent_menu_id === item?.id);
                    return {
                        ...item,
                        children: children?.length > 0 ? children : []
                    };
                });
                setMenuData(newData);
            }
            else {
                setMenuData([])
            }
        } catch (error) {
            console.log(error)
        }

    }

    // update menu list
    const updateMenuData = async (id, name, callList) => {
        const formData = new URLSearchParams();
        formData.append('role_id', getRoleId)
        formData.append('menu_id', id)
        formData.append('event_name', name)
        try {
            const response = await RoleList.setMenus(formData)
            if (response?.data?.status === '1') {
                if (callList) {
                    fetchMenuList()
                }
            }
        } catch (error) {
            console.log(error)
        }
    }

    const handleChange = async (id, name, checked, data) => {
        if ((name === 'is_view' && data?.is_view === '0')) {
            data?.is_add === '0' && await updateMenuData(id, 'is_add', false)
            data?.is_delete === '0' && await updateMenuData(id, 'is_delete', false)
            data?.is_update === '0' && await updateMenuData(id, 'is_update', false)
            await updateMenuData(id, name, true)
        }
        else if (
            (
                (name === 'is_add' && data?.is_add !== '0') ||
                (name === 'is_delete' && data?.is_delete !== '0') ||
                (name === 'is_update' && data?.is_update !== '0')
            ) &&
            data?.is_view !== '0'
        ) {
            await updateMenuData(id, 'is_view', false)
            await updateMenuData(id, name, true)
        } else {
            await updateMenuData(id, name, true)
        }
    }

    const handleRoleTab = (id) => {
        setGetRoleId(id)
    }

    const [panelStates, setPanelStates] = useState({
        Dashboard: true,
        Add: true,
        Tenders: true,
        Personal: true,
        Briefcase: true,
        'Employee List': true,
        'Meeting Schedule': true,
        Request: true,
        'Document Share': true,
        Setting: true,
    });

    const togglePanel = (panelKey) => {
        setPanelStates((prevState) => ({

            Dashboard: false,
            Add: false,
            Tenders: false,
            Personal: false,
            Briefcase: false,
            'Employee List': false,
            'Meeting Schedule': false,
            Request: false,
            'Document Share': false,
            Setting: false,

            [panelKey]: !prevState[panelKey],
        }));
    };


    useEffect(() => {
        getbidRoleTender()
    }, [])

    useEffect(() => {
        if (getRoleId !== null) {
            fetchMenuList()
        }


    }, [getRoleId])



    return (
        <>

            <div className="roleManagement_wrapper">

                <div className="heading_flex">
                    <h1 className="head_title">Roles & Permission</h1>
                    <button className='BG_mainButton' onClick={handleSettingManage} ><SettingOutlined />Manage Role</button>
                </div>

                <div className="tenderCycle_main">
                    <Tabs
                        tabPosition="left"
                        className="custom-tabs-container"
                    >
                        {/* {
                            roleList?.map((item, index) => {
                                return (
                                    <>
                                        <TabPane
                                            tab={
                                                <div className='tab-item' key={item?.id} defaultActiveKey="1" onClick={() => handleRoleTab(item?.id)}>
                                                    <span >{item?.role_name}</span>
                                                </div>
                                            }
                                            key={index}>
                                            <div className="permissions_access_wrap">
                                                <Collapse onChange={() => togglePanel('projectBasicDetail')} defaultActiveKey={1} >
                                                    <Panel
                                                        key="1"
                                                        header={
                                                            <div className='collapse_flex'>
                                                                <div className="d-flex">
                                                                    Basic Details
                                                                </div>
                                                                {panelStates?.projectBasicDetail ?
                                                                    <Down theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                                                    :
                                                                    <Right theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                                                }
                                                            </div>
                                                        }
                                                    >
                                                        {
                                                            allModuleListData.map((cur, index) => {
                                                                return (
                                                                    <>
                                                                        <div className="page_permission" key={index}>
                                                                            <div className="title">{cur?.modules_name}</div>
                                                                            <>
                                                                                <div className='switched_grp' key={index}>
                                                                                    <div className='swtich'>
                                                                                        <label>Add</label>
                                                                                        <Switch name='add_perm' checked={cur?.action_perm_role?.add_perm === '1'} disabled={cur?.action_perm_role?.add_perm === '0'} onChange={(checked) => handleChange(cur?.id, "add_perm", checked)} />
                                                                                    </div>
                                                                                    <div className='swtich'>
                                                                                        <label>View</label>
                                                                                        <Switch name='view_perm' checked={cur?.action_perm_role?.view_perm === '1'} disabled={cur?.action_perm_role?.view_perm === '0'} onChange={(checked) => handleChange(cur?.id, "view_perm", checked)} />
                                                                                    </div>
                                                                                    <div className='swtich'>
                                                                                        <label>Edit</label>
                                                                                        <Switch name='edit_perm' checked={cur?.action_perm_role?.edit_perm === '1'} disabled={cur?.action_perm_role?.edit_perm === '0'} onChange={(checked) => handleChange(cur?.id, "edit_perm", checked)} />
                                                                                    </div>

                                                                                    <div className='swtich'>
                                                                                        <label>Delete</label>
                                                                                        <Switch name='delete_perm' checked={cur?.action_perm_role?.delete_perm === '1'} disabled={cur?.action_perm_role?.delete_perm === '0'} onChange={(checked) => handleChange(cur?.id, "delete_perm", checked)} />
                                                                                    </div>
                                                                                </div>
                                                                            </>
                                                                        </div>
                                                                    </>
                                                                )
                                                            })
                                                        }
                                                    </Panel>
                                                </Collapse>
                                            </div>
                                        </TabPane>
                                    </>
                                )
                            })
                        } */}


                        {
                            roleList?.map((item, index) => {
                                return (
                                    <>
                                        <TabPane
                                            tab={
                                                <div className='tab-item' key={item?.id} defaultActiveKey="1" onClick={() => handleRoleTab(item?.id)}>
                                                    <span >{item?.role_name}</span>
                                                </div>
                                            }
                                            key={index}>


                                            <div className="permissions_access_wrap">

                                                {
                                                    menuData?.filter(val => val.is_view !== '2')?.map((val, index) => {
                                                        return (
                                                            <>
                                                                <Collapse onChange={() => togglePanel(val?.menu_name)} defaultActiveKey={1} >
                                                                    <Panel
                                                                        key="1"
                                                                        header={
                                                                            <div className='collapse_flex'>
                                                                                <div className="d-flex">
                                                                                    {val?.children?.length > 0 ? val?.menu_name : (val?.is_add === '2' && val?.is_delete === '2' && val?.is_update === '2' && val?.is_view === '2') ? '' : val?.menu_name}
                                                                                </div>
                                                                                {panelStates?.val?.menu_name ?
                                                                                    <Down theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                                                                    :
                                                                                    <Right theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                                                                }
                                                                            </div>
                                                                        }
                                                                    >
                                                                        {
                                                                            val?.children?.length > 0 ?
                                                                                <>

                                                                                    {
                                                                                        val?.children?.map((cur, index) => {
                                                                                            return (
                                                                                                <div className="page_permission" key={index}>
                                                                                                    <div className="title">{cur?.menu_name}</div>
                                                                                                    <>
                                                                                                        <div className='switched_grp' key={index}>
                                                                                                            {
                                                                                                                cur?.is_add !== '2' &&
                                                                                                                <div className='swtich'>
                                                                                                                    <label>Add</label>
                                                                                                                    <Switch name='add_perm' checked={cur?.is_add === '0'} onChange={(checked) => handleChange(cur?.id, "is_add", checked, cur)} />
                                                                                                                </div>
                                                                                                            }

                                                                                                            {
                                                                                                                cur?.is_view !== '2' &&
                                                                                                                <div className='swtich'>
                                                                                                                    <label>View</label>
                                                                                                                    <Switch name='view_perm' checked={cur?.is_view === '0'} onChange={(checked) => handleChange(cur?.id, "is_view", checked, cur)} />
                                                                                                                </div>
                                                                                                            }
                                                                                                            {
                                                                                                                cur?.is_update !== '2' &&
                                                                                                                <div className='swtich'>
                                                                                                                    <label>Edit</label>
                                                                                                                    <Switch name='edit_perm' checked={cur?.is_update === '0'} onChange={(checked) => handleChange(cur?.id, "is_update", checked, cur)} />
                                                                                                                </div>
                                                                                                            }
                                                                                                            {
                                                                                                                cur?.is_delete !== '2' &&

                                                                                                                <div className='swtich'>
                                                                                                                    <label>Delete</label>
                                                                                                                    <Switch name='delete_perm' checked={cur?.is_delete === '0'} onChange={(checked) => handleChange(cur?.id, "is_delete", checked, cur)} />
                                                                                                                </div>
                                                                                                            }
                                                                                                        </div>
                                                                                                    </>
                                                                                                </div>
                                                                                            )
                                                                                        })
                                                                                    }

                                                                                </>
                                                                                :
                                                                                <>
                                                                                    <div className="page_permission" key={index}>
                                                                                        <>
                                                                                            <div className='switched_grp' key={index}>
                                                                                                {
                                                                                                    val?.is_add !== '2' &&
                                                                                                    <div className='swtich'>
                                                                                                        <label>Add</label>
                                                                                                        <Switch name='add_perm' checked={val?.is_add === '0'} onChange={(checked) => handleChange(val?.id, "is_add", checked, val)} />
                                                                                                    </div>
                                                                                                }
                                                                                                {
                                                                                                    val?.is_view !== '2' &&
                                                                                                    <div className='swtich'>
                                                                                                        <label>View</label>
                                                                                                        <Switch name='view_perm' checked={val?.is_view === '0'} onChange={(checked) => handleChange(val?.id, "is_view", checked, val)} />
                                                                                                    </div>
                                                                                                }
                                                                                                {
                                                                                                    val?.is_update !== '2' &&
                                                                                                    <div className='swtich'>
                                                                                                        <label>Edit</label>
                                                                                                        <Switch name='edit_perm' checked={val?.is_update === '0'} onChange={(checked) => handleChange(val?.id, "is_update", checked, val)} />
                                                                                                    </div>
                                                                                                }
                                                                                                {
                                                                                                    val?.is_delete !== '2' &&
                                                                                                    <div className='swtich'>
                                                                                                        <label>Delete</label>
                                                                                                        <Switch name='delete_perm' checked={val?.is_delete === '0'} onChange={(checked) => handleChange(val?.id, "is_delete", checked, val)} />
                                                                                                    </div>
                                                                                                }
                                                                                            </div>
                                                                                        </>
                                                                                    </div>
                                                                                </>
                                                                        }
                                                                    </Panel>
                                                                </Collapse>
                                                            </>
                                                        )
                                                    })
                                                }

                                            </div>
                                        </TabPane>
                                    </>
                                )
                            })
                        }



                    </Tabs>
                </div >
            </div>



            <SettingManageModel templateManageClose={templateManageClose} AddManageSetting={AddManageSetting} roleList={roleList} getbidRoleTender={getbidRoleTender} />

            {/* <div className="tabContent_wrapper">{renderTabContent()}</div> */}
        </>
    )
}

export default RolePermissions;


