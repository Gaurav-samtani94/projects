//@ts-nocheck
import React, { useEffect, useState, useMemo } from 'react'
import 'bootstrap';
import { Input, Form, Modal, Button, Select } from 'antd';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SettingTable from 'BidGrid/components/dataTable/SettingTable';
import { bidnationality } from 'Services/bidgrid/master/nationality/bidnationality';

const columnLabels = {
  nationality_name: { name: 'Nationality' },
};

const initialState = {
  nationality_name: "",

}
const Nationality = () => {
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState([])
  const [modalForm, setModalForm] = useState(initialState)
  const [spinner, setSpinner] = useState(false)
  const [modal, setModal] = useState(false);
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);

  const tableData = useMemo(() => {
    return dataSource;
  }, [dataSource]);


  const getNationality = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    try {
      const response = await bidnationality.getnationality()
      if (response?.data?.data?.length > 0) {
        setDataSource(response?.data?.data?.sort((a, b) => a?.unit_name?.localeCompare(b?.unit_name)))
      } else {
        setDataSource([])
      }
    } catch (error) {
      setDataSource([])
      console.log(error, 'api erorr')
    } finally {
      setSpinner(false)
    }
  }

  const addHandler = async () => {
    setSpinner(true);
    const formData = new URLSearchParams();
    formData.append('nationality_name', modalForm?.nationality_name)
    try {
      const response = await bidnationality?.nationalityAdd(formData)
      if (response?.data?.status == 1) {
        await getNationality(false)
        handleCancel()
        notifySuccess('Nationality Added Successfully')
      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      setSpinner(false)
      notify(error)
    }
  }

  useEffect(() => {
    getNationality(true)
  }, [])

  const handleChange = (name, e) => {
    const value = e.target.value.trimStart();
    form.setFieldsValue({ [name]: value });
    setModalForm({
      ...modalForm,
      [name]: value
    })
  }

  const handleNoInt = (e) => {
    const key = e?.key;
    if (!/[a-zA-Z]/.test(key)) {
      e.preventDefault();
    }
  };

  const showModal = () => {
    setModal(true);
  };

  const hideModal = () => {
    setModal(false)
  }

  const handleReset = () => {
    setModalForm(initialState)
    form.resetFields()
  }

  const handleCancel = () => {
    hideModal();
    handleReset()
  };

  return (
    <>
      <div className='BD_master_wrapper'>
        <div className="heading_title">

          <h3>Nationality</h3>
          <button className="BG_mainButton" onClick={showModal}>Add Nationality</button>
        </div>

        <div className='bd_model_right'>

          <SettingTable
            title='Nationality Detail'
            columnLabels={columnLabels}
            dataSource={tableData}
            showActions={false}
            spinner={spinner}
          />
        </div>

      </div>
      <Modal title="Add Nationality" open={modal} onCancel={handleCancel} footer={null} centered>
        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={addHandler}>
          <Form.Item label="Nationality Name: " rules={[{ required: true, message: 'Please enter a nationality.' }]} name='nationality_name' >
            <Input placeholder='Enter here' value={modalForm?.nationality_name} onChange={(e) => handleChange('nationality_name', e)} onKeyPress={handleNoInt} />
          </Form.Item>
          <div className='btn_flex'>
            <Button disabled={spinner} onClick={() => handleReset()} key="back" className='BG_ghostButton'>
              Reset
            </Button>
            <Button className='BG_mainButton' type="primary" htmlType="submit" loading={spinner} disabled={spinner} > Submit </Button>
          </div>
        </Form>
      </Modal>
    </>
  )
}

export default Nationality;
