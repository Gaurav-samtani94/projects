// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Space, Table, Tooltip } from 'antd';
import { CheckOutlined, CloseOutlined } from '@ant-design/icons';
import { settingApi } from 'Services/bidgrid/masterSetting/settingApi';

const ConfigurationLab = () => {
    const [configurList, setConfigurList] = useState([])
    const configurationList = async (id) => {
        try {
            const response = await settingApi?.getConfigurationList()
            if (response?.data?.status === '1') {
                setConfigurList(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    };

    const setConfigurationListFun = async (id) => {
        try {
            const response = await settingApi?.setConfigurationListApi()
            if (response?.data?.status === '1') {
                configurationList()
            }
        } catch (error) {
            console.log(error)
        }
    };

    const columns = [
        {
            title: 'Roles and Permissions',
            dataIndex: 'rolesPermission',
            key: 'rolesPermission',
            render: (text) => <a>{text}</a>,
        },
        {
            title: 'Actions',
            key: 'action',
            render: ((record) => {
                console.log(record, "record")
                return (
                    <>
                        <Space size="middle">
                            {/* {record?.isDone == 1 ?
                                <div style={{ color: 'green' }}><CheckOutlined /><span style={{ fontSize: '16px' }}>Done</span></div>
                                :
                                <div style={{ color: 'red' }}><CloseOutlined /><span style={{ fontSize: '16px' }}>Not Done</span></div>
                            } */}

                            {record?.isDone == 1 ?
                                <div style={{ color: 'green' }}><CheckOutlined /></div>
                                :
                                <div style={{ color: 'red' }}><CloseOutlined /></div>
                            }
                        </Space>
                    </>
                )
            })

            ,
        },
    ];
    const data = [
        ...configurList?.filter((itm) => itm?.configuration_master != null)?.map((item, index) => {
            return (
                {
                    key: index,
                    rolesPermission: item?.configuration_master?.config_name,
                    isDone: item?.is_done

                }
            )
        })
    ];


    useEffect(() => {
        setConfigurationListFun()
    }, []);

    return (
        <>
            <div className="roleManagement_wrapper">
                <div className="heading_flex">
                    <h1 className="head_title">Configuration Checklist</h1>
                </div>

                <div className="tenderCycle_main">
                    <Table columns={columns} dataSource={data} />
                </div>
            </div>
        </>
    )
}

export default ConfigurationLab;