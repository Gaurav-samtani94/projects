// @ts-nocheck
import React, { useEffect, useMemo, useState } from 'react'
import 'bootstrap';
import { Table, Input, Form, Row, Col, Space, Drawer, Dropdown, Select, DatePicker, InputNumber, Spin } from 'antd';
import TextArea from 'antd/es/input/TextArea';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { RoleList } from "Services/bidgrid/master/role/bidRole"
import DrawerSection from 'BidGrid/components/Drawer/Drawer';
const { Search } = Input;
const { Option } = Select;


const columnLabels = {
  role_name: { name: 'Employee', required: true },
};


const Employee = () => {
  const showActions = true;
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState([])
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const [isEditFields, setIsEditFields] = useState({})
  const [spinner, setSpinner] = useState(false)

  const [newRole, setNewRole] = useState('')
  const val = location?.pathname;
  const str = val.replace('/', '')

  const onClose = () => {
    setOpen(false);
  };

  const handleInputChange = (e) => {
    setNewRole(e.target.value);
  };

  const handleKeyPress = (e) => {
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };


  return (

    <>
      <div className='BD_master_wrapper'>
        <Row gutter={60}>
          <Col span={6}>

            <h3>Employee</h3>

            <Form layout="vertical" autoComplete="off" className='bd_model_form' onKeyDown={handleKeyPress}>
              <Form.Item label="Employee Name: " >
                <Input placeholder='Enter here'
                  value={newRole}
                  onChange={handleInputChange} />
              </Form.Item>

              <div className='bd_model_button'>
                <button key="back" className='BG_ghostButton'>
                  Reset
                </button>
                <button key="submit" className='BG_mainButton'
                >
                  Submit
                </button>
              </div>
            </Form>
          </Col>
          <Col span={18}>
            <div className='bd_model_right'>
              <DataTable
                title="Employee"
                // dataSource={newRole}
                columnLabels={columnLabels}
                showActions={showActions}
                spinner={spinner}
                setSpinner={setSpinner}
              />
            </div>
          </Col>
        </Row>
      </div>
    </>
  )
}

export default Employee;
