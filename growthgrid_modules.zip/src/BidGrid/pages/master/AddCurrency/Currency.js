//@ts-nocheck
import React, { useEffect, useState, useMemo } from 'react'
import 'bootstrap';
import { Input, Form, Modal, Button, Select } from 'antd';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SettingTable from 'BidGrid/components/dataTable/SettingTable';
import { bidcurrency } from 'Services/bidgrid/master/currency/bidcurrency';
const columnLabels = {
  name: { name: 'Currency Name' },
  code: { name: 'Currency Code' },
};

const initialState = {
  name: "",
  code: "",

}

const Currency = () => {
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState([])
  const [modalForm, setModalForm] = useState(initialState)
  const [spinner, setSpinner] = useState(false)
  const [modal, setModal] = useState(false);
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);

  const tableData = useMemo(() => {
    return dataSource;
  }, [dataSource]);
  // currency Api 

  const getCurrency = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    try {
      const response = await bidcurrency.getcurrency()
      if (response?.data?.data.length > 0) {
        setDataSource(response?.data?.data?.sort((a, b) => a?.name?.localeCompare(b?.name)))
      } else {
        setDataSource([])
      }
    } catch (error) {
      setDataSource([])
    } finally {
      setSpinner(false)
    }
  }

  const addHandler = async () => {
    setSpinner(true)

    const formData = new URLSearchParams();
    formData.append("name", modalForm?.name);
    formData.append("code", modalForm?.code?.toUpperCase());

    try {
      const response = await bidcurrency.createCurrency(formData)
      if (response?.data?.status === '1') {
        await getCurrency(false);
        notifySuccess('Currency Added Successfully')
        handleCancel()
      } else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      notify(error)
      setSpinner(false)
    }
  }

  useEffect(() => {
    getCurrency(true)
  }, [])



  const handleCurrencyChange = (name, e) => {
    const value = e.target.value.trimStart();
    if (name === 'currency_code') {
      if (/^\d{0,3}$/.test(value)) {
        form.setFieldsValue({ [name]: value });
        setModalForm({
          ...modalForm,
          [name]: value
        })
      }
    } else {
      form.setFieldsValue({ [name]: value });
      setModalForm({
        ...modalForm,
        [name]: value
      })
    }
  };


  const handleCurrencyKey = (e) => {
    const key = e?.key;
    if (!/[a-zA-Z]/.test(key)) {
      e.preventDefault();
    }
  };

  const showModal = () => {
    setModal(true);
  };

  const hideModal = () => {
    setModal(false)
  }

  const handleReset = () => {
    setModalForm(initialState)
    form.resetFields()
  }

  const handleCancel = () => {
    hideModal();
    handleReset()
  };
  return (
    <>
      <div className='BD_master_wrapper'>
        <div className="heading_title">

          <h3>Currency</h3>
          <button className="BG_mainButton" onClick={showModal}>Add Currency</button>
        </div>


        <SettingTable
          title='Currency Detail'
          columnLabels={columnLabels}
          dataSource={tableData}
          showActions={false}
          spinner={spinner}
        />

      </div>
      <Modal title="Add New Currency" open={modal} onCancel={handleCancel} footer={null} centered>
        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={addHandler}>
          <Form.Item label="Currency Name: " rules={[{ required: true, message: 'Currency name is required' }]} name='name' >
            <Input placeholder='Enter here' value={modalForm?.name} onChange={(e) => handleCurrencyChange('name', e)} onKeyPress={handleCurrencyKey} />

          </Form.Item>
          <Form.Item label="Currency Code: "
            rules={[{ required: true, message: 'Currency code is required' },
            {
              validator: (_, value) => {
                if (value && value.length < 3) {
                  return Promise.reject('Currency code cannot be less than 3 characters');
                }
                return Promise.resolve();
              }
            },

            ]}
            name='code' >
            <Input placeholder='Enter here' value={modalForm?.code} onChange={(e) => handleCurrencyChange('code', e)} maxLength={3} onKeyPress={handleCurrencyKey}
            />

          </Form.Item>

          <div className='btn_flex'>
            <Button disabled={spinner} onClick={() => handleReset()} key="back" className='BG_ghostButton'>
              Reset
            </Button>
            <Button className='BG_mainButton' type="primary" htmlType="submit" loading={spinner} disabled={spinner} > Submit </Button>
          </div>
        </Form>
      </Modal>
    </>

  )
}

export default Currency
