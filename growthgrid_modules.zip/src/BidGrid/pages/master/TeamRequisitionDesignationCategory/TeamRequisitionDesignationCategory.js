//@ts-nocheck
import React, { useState, useRef, useEffect, useMemo } from 'react'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap';
import { Input, Form, Row, Col, Spin, Button, Modal } from 'antd';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import DrawerSection from 'BidGrid/components/Drawer/Drawer';
import { TeamReqApi } from 'Services/bidgrid/tenderList/TeamReqApi';
const notify = (error) => toast.error(error);
const notifySuccess = (msg) => toast.success(msg);

const columnLabels = {
    category_name: { name: 'Category', required: true },
};

const TeamRequisitionDesignationCategory = () => {
    const [form] = Form.useForm();
    const [dataSource, setDataSource] = useState()
    const [designationName, setDesignationName] = useState('')
    const [spinner, setSpinner] = useState(false)

    // const [btnDis, setBtnDis] = useState(false)
    const [showNotification, setShowNotification] = useState(false);
    const location = useLocation();
    const val = location?.pathname;
    const str = val.replace('/', '')
    const showActions = true;


    const designationTableData = useMemo(() => {
        // return dataSource;
        return Array.isArray(dataSource) ? dataSource : [];

    }, [dataSource]);

    // Designation list api
    const getDesignation = async (initial) => {
        if (initial) {
            setSpinner(true)
        }
        const formData = new URLSearchParams();

        try {
            const response = await TeamReqApi.getDesignationCategoryList()
            if (response?.data?.status == 1) {
                if (response?.data?.data.length > 0) {

                    setDataSource(response?.data?.data?.sort((a, b) => a?.category_name?.localeCompare(b?.category_name)))
                    setSpinner(false)
                } else {
                    setDataSource([])
                    setSpinner(false)
                }
            } else {
                setSpinner(false)
                setDataSource([])
            }
        } catch (error) {
            setDataSource([])
            setSpinner(false)
            notify("Api Erorr!!");
            console.log(error, 'api erorr')
        }
    }


    // add Designation api
    const createHandler = async (value) => {
        setShowNotification(true);
        const formData = new URLSearchParams();
        formData.append('category_name', value.designationName);

        try {
            form.validateFields()
            const response = await TeamReqApi.addDesignationCategoryList(formData)
            if (response?.data?.status == 1) {
                setSpinner(true)
                handleCancel()
                await getDesignation(false)
                // setDataSource([response?.data?.data, ...dataSource])
                notifySuccess('Designation Added Successfully')
                handleReset()

            } else {
                handleCancel()

                notify(response?.response?.data?.message);
                setSpinner(false);
            }
        } catch (error) {
            handleCancel()

            notify("Server Error!!");
            setSpinner(false);
        }
        setTimeout(() => {
            setShowNotification(false);
        }, 3000);
    }

    // update Designation api
    const updateHandler = async (val) => {
        try {
            const formData = new URLSearchParams()
            formData.append('category_id', val?.id)

            formData.append('category_name', val?.category_name)
            const response = await TeamReqApi.updateDesignationCategoryList(formData)
            if (response?.data?.status == 1) {
                setSpinner(true)
                await getDesignation(false)
                // notifySuccess(response?.data?.message);
                notifySuccess('Designation Updated Successfully')

            } else {
                notify(response?.response?.data?.message);
                setSpinner(false)
            }
            return response;
        } catch (error) {
            notify("Server Error!!");
            setSpinner(false)
        }
    }

    // delete designation api
    const deletehandler = async (id) => {
        try {
            const formData = new URLSearchParams()
            formData.append('category_id', id)
            const response = await TeamReqApi.deleteDesignationCategoryList(formData)
            if (response?.data?.status == 1) {
                setSpinner(true)
                notifySuccess('Designation Deleted Successfully');
                await getDesignation(false)

            } else {
                setSpinner(false)
                notify(response?.response?.data?.message);
            }

        } catch (error) {
            setSpinner(false)
        }

    }

    // const handleKeyPress = (e) => {
    //     const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    //     if (forbiddenChars.test(e.key)) {
    //         e.preventDefault();
    //     } else if (e.key === 'Enter') {
    //         e.preventDefault();
    //         createHandler();
    //     } else if (e.key === ' ' && e.target.selectionStart === 0) {
    //         e.preventDefault();
    //     }
    // }

    // useEffect
    useEffect(() => {
        getDesignation(true)
    }, [])

    // const handleInputChange = (e) => {
    //     setDesignationName(e.target.value);
    // };

    const handleReset = () => {
        setDesignationName('');
        form.resetFields()
    };

    const handleDesignationChange = (name, e) => {
        const trimmedValue = e.target.value.trimStart();
        form.setFieldsValue({ [name]: trimmedValue });
    };
    // Modal 
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = () => {
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
    };
    return (
        <>
            <div className='BD_master_wrapper'>

                <div className='bd_model_left'>
                    <div className="heading_title">

                        <h3>Requisition Category </h3>
                        <button className="BG_mainButton" onClick={showModal}>Add Category</button>
                    </div>

                </div>

                <DataTable
                    title='Team Requisition Designation Category'
                    handleUpdate={updateHandler}
                    handleDelete={deletehandler}
                    columnLabels={columnLabels}
                    dataSource={designationTableData}
                    showActions={showActions}
                    spinner={spinner}
                    setSpinner={setSpinner}
                />

            </div>
            <Modal title="Add Team Requisition Designation Category" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} centered>


                <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={createHandler}>
                    <Form.Item label="Category:" name="designationName" rules={[{ required: true, message: 'Category is required' }]} >
                        <Input placeholder='Enter here' onChange={(e) => handleDesignationChange('designationName', e)} />
                    </Form.Item>

                    <div className='btn_flex'>
                        <Button onClick={handleReset} key="back" className='BG_ghostButton'>
                            Reset
                        </Button>
                        <button key="submit" className='BG_mainButton' disabled={showNotification}>
                            Submit
                        </button>
                    </div>
                </Form>
            </Modal>
        </>
    )
}

export default TeamRequisitionDesignationCategory;
