// @ts-nocheck
import React, { useEffect, useMemo, useState } from 'react'
import { Button, Form, Input, Drawer } from 'antd/es';
import TextArea from 'antd/es/input/TextArea';
import { Down, UploadOne } from '@icon-park/react';
import { Row, Col, Select, Table, Dropdown, Spin, Modal } from 'antd';
import DataTable from '../../../components/dataTable/DataTable.jsx'
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import skipBack from "../../../assets/images/skip-back.png"
import { useLocation } from 'react-router-dom/dist';
import { bidCompany } from 'Services/bidgrid/master/company/bidCompany.js';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Item from 'antd/es/list/Item.js';
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'
import { bidSubSector } from 'Services/bidgrid/master/subSector/bidSubSector.js';
const { Search } = Input;
const { Option } = Select;


const columnLabels = {
    subsector_name: { name: 'Sub-Sector Name', required: true },

};


const SubSector = () => {
    const [form] = Form.useForm();
    const showActions = true;
    const [dataSource, setDataSource] = useState([])
    const [subSectorName, setSubSectorName] = useState('')
    const [selectedSector, setSelectedSector] = useState('')
    const [subSectorId, setSubSectorId] = useState([])
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [skeletonTime, setSkeletonTime] = useState(true)
    const [showNotification, setShowNotification] = useState(false);

    const SubsectorData = useMemo(() => {
        return dataSource;
    }, [dataSource]);


    // get company list api
    const getSubsectorList = async () => {
        // setSkeletonTime(true)
        const formData = new URLSearchParams();
        // formData.append("sector_id", selectedSector);
        try {
            const response = await bidSubSector.getSubSectorList();
            if (response?.data?.status === '1') {
                // setSkeletonTime(false)
                setDataSource(response?.data?.data)

            }
            else {
                setDataSource([])

            }

        } catch (error) {
            console.log(error, 'api error');
        }
    };




    // company add list api 
    const subSectorAddList = async () => {
        if (subSectorName) {
            setSkeletonTime(true)
            const formData = new URLSearchParams();
            formData.append("subsector_name", subSectorName);
            formData.append("sector_id", selectedSector);

            try {
                const response = await bidSubSector?.addSubSectorList(formData);
                if (response?.data?.status == 1) {
                    setSkeletonTime(false)
                    getSubsectorList()
                    handleReset()
                    notifySuccess(response?.data?.message)
                }
                else {
                    console.log('api error');
                    handleReset()
                    notify(response?.response?.data?.message)
                }
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        }
        else {
            if (!showNotification) {
                notify(" All fields are required!!");
                setShowNotification(true);

                setTimeout(() => {
                    setShowNotification(false);
                }, 2500);
            }
        }

    }
    // edit company api
    const editSubSector = async (val) => {
        setSkeletonTime(true)
        try {
            const formData = new URLSearchParams();
            formData.append('subsector_id', val?.id)
            formData.append('subsector_name', val?.subsector_name)
            const response = await bidSubSector?.editSubSectorList(formData)
            if (response?.data?.status == 1) {
                setSkeletonTime(false)
                await getSubsectorList()
                // notifySuccess(response?.data?.message)
                notifySuccess("Sub-Sector updated !!")

            }
            else {
                notify(response?.response?.data?.message)
            }
        } catch (error) {
            console.log('Api Error', error);
        }
    }

    const deleteSubSectorList = async (id) => {
        setSkeletonTime(true)
        try {
            const formData = new URLSearchParams();
            formData.append('subsector_id', id)
            const response = await bidSubSector?.handleDeleteSubSector(formData)
            if (response?.data?.status == 1) {
                setSkeletonTime(false)
                await getSubsectorList()
                notifySuccess('Company Delete Successfully')
            }
        } catch (error) {
            console.log('Api Error', error);
        }
    }


    const getSubSector = async (id) => {
        setSkeletonTime(true)
        setSelectedSector(id)
        try {
            const formData = new URLSearchParams();
            formData.append('subsector_id', id)
            const response = await bidSubSector?.getSubSectorId(formData)
            if (response?.data?.status == 1) {

                setSubSectorId(response?.data?.data)
                setSkeletonTime(false)
                await getSubsectorList()
            }
        } catch (error) {

        }
    }
    const handleChange = (e) => {
        getSubSector(e)
    }


    useEffect(() => {
        getSubSector()
    }, []);


    useEffect(() => {
        getSubsectorList()
    }, [selectedSector]);

    const handleReset = () => {
        setSubSectorName('');
        form?.resetFields()
    };
    const handleInputChange = (e) => {
        form?.setFieldValue({ subsector_name: e.target.value })
        setSubSectorName(e.target.value);
    };

    const location = useLocation();
    const val = location?.pathname;
    const str = val.replace('/', '')




    // Modal 
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = () => {
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
    };
    return (
        <>
            {/* {skeletonTime ?
                (<Skeleton width={120} height={22} />)
                :
                ( */}
            <>

                <div className='BD_master_wrapper'>

                    <div className='bd_model_left'>
                        <div className="heading_title">

                            <h3>Sub-Sector</h3>
                            <button className="BG_mainButton" onClick={showModal}>Add Sub-Sector</button>

                        </div>
                    </div>

                    <div className='bd_wishlist_search_dropdown'>
                        <div className='bd_wishlist_collection'>
                            {/* <Form.Item>
                                        <h3>Sub-Sector</h3>
                                        <Select
                                            style={{
                                                width: 155,
                                            }}
                                            defaultValue="select tender"
                                            onChange={handleChange}
                                            options={subSectorId.map((item, index) => {
                                                return { label: item?.sector_name, value: item?.id };
                                            })}
                                        /> */}

                            {/* <Select
                                            defaultValue="Tender Status"
                                            style={{
                                                width: 165,
                                            }}
                                            onChange={handleChange}
                                            options={[
                                                {
                                                    value: '1',
                                                    label: 'All',
                                                },
                                                {
                                                    value: '2',
                                                    label: 'Important Tender',
                                                },
                                                {
                                                    value: '3',
                                                    label: 'Not Important Tender',
                                                },
                                                {
                                                    value: '4',
                                                    label: 'In Review Tender',
                                                },
                                                {
                                                    value: '5',
                                                    label: 'NO Go Tender',
                                                },
                                                {
                                                    value: '6',
                                                    label: 'Ongoing Tender',
                                                },
                                                {
                                                    value: '7',
                                                    label: 'Submitted Tender',
                                                },
                                                {
                                                    value: '8',
                                                    label: 'Not Submitted Tender',
                                                },
                                            ]}
                                        /> */}
                            {/* </Form.Item> */}
                        </div>
                    </div>
                    <DataTable
                        handleUpdate={editSubSector}
                        handleDelete={deleteSubSectorList}
                        columnLabels={columnLabels}
                        dataSource={SubsectorData}
                        showActions={showActions}
                    />

                </div>
                <Modal title="Add Sub-Sector" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} centered>
                    <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" >
                        <Form.Item label="Sub-Sector Name :">
                            <Input value={subSectorName} placeholder='Enter here...' onChange={handleInputChange} />
                        </Form.Item>
                        <Form.Item label="Sector :">
                            <Select
                                showSearch
                                defaultValue="select sector"
                                onChange={handleChange}
                                options={subSectorId.map((item, index) => {
                                    return { label: item?.sector_name, value: item?.id };
                                })}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                            />
                        </Form.Item>
                        {/* </Form> */}
                        <div className='btn_flex'>
                            <Button onClick={handleReset} key="back" className='BG_ghostButton'>
                                Reset
                            </Button>
                            <button key="submit" className='BG_mainButton' onClick={subSectorAddList}>
                                Submit
                            </button>
                        </div>
                    </Form>
                </Modal>
            </>
            {/* )

            } */}
        </>
    )
}
export default SubSector;