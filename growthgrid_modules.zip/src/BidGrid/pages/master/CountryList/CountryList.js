//@ts-nocheck
import React, { useEffect, useState, useMemo } from 'react'
import 'bootstrap';
import { Input, Form, Modal, Button, Select } from 'antd';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SettingTable from 'BidGrid/components/dataTable/SettingTable';
import { bidContinent } from 'Services/bidgrid/continent/bidContinent';
import { Locations } from 'Services/bidgrid/master/locations';


const columnLabels = {
  country_name: { name: 'Country' },
};

const initialState = {
  Continent_id: '',
  country_name: '',
}
const CountryList = () => {
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState([])
  const [modalForm, setModalForm] = useState(initialState)
  const [spinner, setSpinner] = useState(false)
  const [modal, setModal] = useState(false);
  const [continentlist, setContinentList] = useState([])
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);
  const tableData = useMemo(() => {
    return dataSource;
  }, [dataSource]);



  const getContinent = async () => {

    try {
      const response = await bidContinent.getContinent()
      if (response?.data?.data.length > 0) {
        setContinentList(response?.data?.data?.sort((a, b) => a?.continent_name?.localeCompare(b?.continent_name)))
      } else {
        setContinentList([])
      }

    } catch (error) {
      setContinentList([])

    }
  }

  const getCountry = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    try {
      const response = await Locations.getCountryLIst();

      if (response?.data?.data.length > 0) {
        setDataSource(response?.data?.data?.sort((a, b) => a?.country_name?.localeCompare(b?.country_name)));
      } else {
        setDataSource([])
      }
    } catch (error) {
      setDataSource([])
    } finally {
      setSpinner(false)
    }
  };


  const addHandler = async () => {
    setSpinner(true)
    const formData = new URLSearchParams();
    formData.append('continent_id', modalForm?.Continent_id)
    formData.append('country_name', modalForm?.country_name)
    try {
      const response = await Locations?.postCountryList(formData)
      if (response?.data?.status == 1) {
        await getCountry(false)
        notifySuccess('Country Added Successfully')
        handleCancel()
      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      notify(error)
      setSpinner(false)
    }
  }


  useEffect(() => {
    getCountry(true)
    getContinent()
  }, [])


  const handleCountryChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart()
    form.setFieldsValue({ [name]: trimmedValue });
    setModalForm({
      ...modalForm,
      [name]: trimmedValue
    })
  };
  const handleContinent = (name, e) => {
    form.setFieldsValue({ [name]: e });
    setModalForm({
      ...modalForm,
      [name]: e
    })
  }

  const showModal = () => {
    setModal(true);
  };

  const hideModal = () => {
    setModal(false)
  }

  const handleReset = () => {
    setModalForm(initialState)
    form.resetFields()
  }

  const handleCancel = () => {
    hideModal();
    handleReset()
  };
  return (

    <>
      <div className='BD_master_wrapper'>

        <div className="heading_title">

          <h3>Country</h3>
          {/* <button className="BG_mainButton" onClick={showModal}>Add Country</button> */}

        </div>


        <div className='bd_model_right'>
          <SettingTable
            title='Country Detail'
            columnLabels={columnLabels}
            dataSource={tableData}
            showActions={false}
            spinner={spinner}
          />
        </div>

      </div>
      <Modal title="Add New Country" open={modal} onCancel={handleCancel} footer={null} centered>
        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" className='bd_model_form' onFinish={addHandler}>
          <Form.Item label="Continent:" rules={[{ required: true, message: 'Continent Name is required' }]} name='Continent_id'>
            <Select
              allowClear
              showSearch
              placeholder="Select Continent"
              onChange={(e) => handleContinent('Continent_id', e)}
              value={modalForm?.Continent_id}
              options={continentlist.map((item, index) => {
                return { label: item?.continent_name, value: item?.id };
              })}
              filterOption={(input, option) =>
                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            />
          </Form.Item>

          <Form.Item label="Country: " name='country_name' rules={[{ required: true, message: 'Country name is required' }]} >
            <Input placeholder='Enter here' value={modalForm?.country_name} onChange={(e) => handleCountryChange('country_name', e)} />
          </Form.Item>
          <div className='btn_flex'>
            <Button disabled={spinner} onClick={() => handleReset()} key="back" className='BG_ghostButton'>
              Reset
            </Button>
            <Button className='BG_mainButton' type="primary" htmlType="submit" loading={spinner} disabled={spinner} > Submit </Button>
          </div>
        </Form>
      </Modal>
    </>
  )
}


export default CountryList;
