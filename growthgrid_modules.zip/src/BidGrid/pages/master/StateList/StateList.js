
//@ts-nocheck
import React, { useEffect, useState, useMemo } from 'react'
import 'bootstrap';
import { Input, Form, Modal, Button, Select } from 'antd';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SettingTable from 'BidGrid/components/dataTable/SettingTable';
import { bidContinent } from 'Services/bidgrid/continent/bidContinent';
import { Locations } from 'Services/bidgrid/master/locations';
import { useSelector } from 'react-redux';
import { bidRegion } from 'Services/bidgrid/master/region/region';
const columnLabels = {
  state_name: { name: 'State Name' },
};
const initialState = {
  country_name: null,
  region_name: null,
  state_name: '',
}

const StateList = () => {

  const { BidCountry } = useSelector((state) => state.bidDropdownCalVal)
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState([])
  const [modalForm, setModalForm] = useState(initialState)
  const [spinner, setSpinner] = useState(false)
  const [modal, setModal] = useState(false);
  const [regionVal, setRegionVal] = useState([])
  const [selectCountry, setSelectCountry] = useState(BidCountry[0]?.id)
  const [modalRegion, setModalRegion] = useState([])
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);


  const tableData = useMemo(() => {
    return dataSource;
  }, [dataSource]);




  const getRegion = async () => {

    const formData = new URLSearchParams();
    formData.append('country_id', modalForm?.country_name);
    try {
      const response = await bidRegion.getRegionList(formData)
      if (response?.data?.status === '1') {
        if (response?.data?.data.length > 0) {
          setRegionVal(response?.data?.data)
        } else {
          setRegionVal([])
        }
      } else {
        setRegionVal([])
      }
    } catch (error) {
      console.log(error, 'api erorr')
    }
  }


  const getState = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    const formData = new URLSearchParams();
    formData.append("country_id", selectCountry);
    try {
      const response = await Locations.GetStateList(formData)
      if (response?.data?.data.length > 0) {
        setDataSource(response?.data?.data)
      } else {
        setDataSource([])
      }
    } catch (error) {
      setDataSource([])
    } finally {
      setSpinner(false)
    }
  }


  const addHandler = async () => {
    setSpinner(true)
    const formData = new URLSearchParams();
    formData.append('country_id', modalForm?.country_name)
    formData.append('region_id', modalForm?.region_name)
    formData.append('state_name', modalForm?.state_name)
    try {
      const response = await Locations?.postStateList(formData)
      if (response?.data?.status == 1) {
        await getState(false)
        notifySuccess('State Added Successfully')
        handleCancel()
      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      setSpinner(false)
      notify(error)
    }
  }

  useEffect(() => {
    if (selectCountry) {
      getState()
    }
  }, [selectCountry])


  useEffect(() => {
    if (modalForm?.country_name) {
      getRegion();
    }
  }, [modalForm?.country_name])

  const handleChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart()
    form.setFieldsValue({ [name]: trimmedValue });
    setModalForm({
      ...modalForm,
      [name]: trimmedValue
    })
  };
  const handleSelect = (name, e) => {
    if (name === 'country_name') {
      form.setFieldsValue({ [name]: e, region_name: null });
      setModalForm({
        ...modalForm,
        [name]: e,
        region_name: null,
      })
    } else {
      form.setFieldsValue({ [name]: e });
      setModalForm({
        ...modalForm,
        [name]: e,
      })
    }

  }

  const showModal = () => {
    setModal(true);
  };

  const hideModal = () => {
    setModal(false)
  }

  const handleReset = () => {
    setModalForm(initialState)
    form.resetFields()
  }

  const handleCancel = () => {
    hideModal();
    handleReset()
  };
  return (
    <>
      <div className='BD_master_wrapper'>

        <div className="heading_title">

          <h3> State</h3>
          <button className="BG_mainButton" onClick={showModal}>Add State</button>

        </div>


        <div className='bd_model_right'>
          <Form.Item label="Country" >
            <Select
              allowClear
              showSearch
              style={{
                width: 155,
              }}
              value={selectCountry}
              name='country_name'
              onChange={(value) => setSelectCountry(value)}
              options={BidCountry.map((item, index) => {
                return { label: item?.country_name, value: item?.id };
              })}
              filterOption={(input, option) =>
                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            />
          </Form.Item>

          <SettingTable
            title='State Detail'
            columnLabels={columnLabels}
            dataSource={tableData}
            showActions={false}
            spinner={spinner}
          />
        </div>


      </div>
      <Modal title="Add New State" open={modal} onCancel={handleCancel} footer={null} centered>

        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" className='bd_model_form' onFinish={addHandler}>
          <Form.Item label="Country Name" rules={[{ required: true, message: 'Country is required' }]} name='country_name'>
            <Select
              allowClear
              showSearch
              placeholder="Select Country"
              value={modalForm?.country_name}
              onChange={(value) => handleSelect('country_name', value)}
              options={BidCountry.map((item, index) => {
                return { label: item?.country_name, value: item?.id };
              })}
              filterOption={(input, option) =>
                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            />
          </Form.Item>
          <Form.Item label="Region Name" rules={[{ required: true, message: 'Region is required' }]} name='region_name'>
            <Select
              allowClear
              showSearch
              placeholder="Select Region"
              value={modalForm?.region_name}
              onChange={(value) => handleSelect('region_name', value)}
              options={regionVal?.map((item, index) => {
                return { label: item?.region_name, value: item?.id };
              })}
              filterOption={(input, option) =>
                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            />
          </Form.Item>
          <Form.Item label="State Name : " rules={[{ required: true, message: 'State is required' }]} name='state_name' >
            <Input placeholder='Enter state here' value={modalForm?.state_name} onChange={(e) => handleChange('state_name', e)}
            />

          </Form.Item>

          <div className='btn_flex'>
            <Button disabled={spinner} onClick={() => handleReset()} key="back" className='BG_ghostButton'>
              Reset
            </Button>
            <Button className='BG_mainButton' type="primary" htmlType="submit" loading={spinner} disabled={spinner} > Submit </Button>
          </div>
        </Form>
      </Modal>
    </>
  )

}


export default StateList;
