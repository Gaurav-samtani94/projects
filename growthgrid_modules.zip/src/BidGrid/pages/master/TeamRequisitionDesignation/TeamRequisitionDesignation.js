//@ts-nocheck
import React, { useState, useRef, useEffect, useMemo } from 'react'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap';
import { Input, Form, Row, Col, Spin, Button, Select, Modal } from 'antd';
import { Down } from '@icon-park/react';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import DrawerSection from 'BidGrid/components/Drawer/Drawer';
import { TeamReqApi } from 'Services/bidgrid/tenderList/TeamReqApi';
const notify = (error) => toast.error(error);
const notifySuccess = (msg) => toast.success(msg);

const columnLabels = {
    designation_name: { name: 'Designation', required: true },
};

const TeamRequisitionDesignationCategory = () => {
    const [form] = Form.useForm();
    const [dataSource, setDataSource] = useState()
    const [designationName, setDesignationName] = useState('')
    const [spinner, setSpinner] = useState(false)
    const [categoryList, setCategoryList] = useState([])
    const [addCategory, setAddCategory] = useState([])
    const [categoryDrop, setCategoryDrop] = useState(null)
    // const [btnDis, setBtnDis] = useState(false)
    const [showNotification, setShowNotification] = useState(false);
    const location = useLocation();
    const val = location?.pathname;
    const str = val.replace('/', '')
    const showActions = true;

    const designationTableData = useMemo(() => {
        return dataSource;
    }, [dataSource]);

    // category list 

    const fetchCategoryList = async () => {
        try {
            const response = await TeamReqApi.getDesignationCategoryList()
            if (response?.data?.status === '1') {
                setCategoryList(response?.data?.data)
                const dataVal = response?.data?.data[0]
                setCategoryDrop(dataVal?.id)

            } else {
                setCategoryList([])
            }
        }
        catch (error) {
            console.log(error, 'api erorr')
        }
    }

    // Designation list api
    const getDesignation = async (initial) => {
        if (initial) {
            setSpinner(true)
        }
        // if (categoryDrop === null) {
        //     setCategoryDrop(categoryList[0]?.id)
        // }

        try {
            const formData = new URLSearchParams();
            formData.append('category_id', categoryDrop === null ? categoryList[0]?.id : categoryDrop);
            const response = await TeamReqApi.getRequisitionDesignationList(formData)
            if (response?.data?.status == 1) {
                if (response?.data?.data.length > 0) {
                    setDataSource(response?.data?.data?.sort((a, b) => a?.designation_name?.localeCompare(b?.designation_name)))
                    setSpinner(false)
                } else {
                    setDataSource([])
                    setSpinner(false)
                }
                // console.log(setDataSource, "responseresponse")
            } else {
                setSpinner(false)
                setDataSource([])
            }
        } catch (error) {
            setDataSource([])
            setSpinner(false)
            notify("Api Erorr!!");
            console.log(error, 'api erorr')
        }
    }
    // add Designation api
    const createHandler = async (value) => {
        setShowNotification(true);
        const formData = new URLSearchParams();
        formData.append('category_id', addCategory);
        formData.append('designation_name', value?.designationName);


        try {
            form.validateFields()
            const response = await TeamReqApi.addRequisitionDesignationList(formData)
            if (response?.data?.status == 1) {
                setSpinner(true)
                form.resetFields()
                await getDesignation(false)
                handleCancel()
                // setDataSource([response?.data?.data, ...dataSource])
                notifySuccess('Designation Added Successfully')
                handleReset()

            } else {
                handleCancel()

                notify(response?.response?.data?.message);
                setSpinner(false);
            }
        } catch (error) {
            handleCancel()

            notify("Server Error");
            setSpinner(false);
        }
        setTimeout(() => {
            setShowNotification(false);
        }, 2000);
    }

    // update Designation api
    const updateHandler = async (val) => {
        try {
            const formData = new URLSearchParams()
            formData.append('designation_id', val?.id)
            formData.append('designation_name', val?.designation_name)
            const response = await TeamReqApi.updateRequisitionDesignationList(formData)
            if (response?.data?.status == 1) {
                setSpinner(true)
                notifySuccess('Designation Updated Successfully')
                await getDesignation(false)
                // notifySuccess(response?.data?.message);

            } else {
                notify(response?.response?.data?.message);
                setSpinner(false)
            }
            return response;
        } catch (error) {
            notify("Server Error!!");
            setSpinner(false)
        }
    }

    // delete designation api
    const deletehandler = async (id) => {
        try {
            const formData = new URLSearchParams()
            formData.append('designation_id', id)
            const response = await TeamReqApi.deleteRequisitionDesignationList(formData)
            if (response?.data?.status == 1) {
                setSpinner(true)
                notifySuccess('Designation Deleted Successfully');
                await getDesignation(false)

            } else {
                setSpinner(false)
                notify(response?.response?.data?.message);
            }

        } catch (error) {
            setSpinner(false)
        }

    }

    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            createHandler();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    // useEffect
    useEffect(() => {
        fetchCategoryList()

    }, [])

    useEffect(() => {
        getDesignation()

    }, [categoryDrop])
    const handleInputChange = (e) => {
        setDesignationName(e.target.value);
    };

    const handleReset = () => {
        // setDesignationName('');
        form.resetFields()
        setAddCategory([])
    };

    // remove validation error click on outside form 
    useEffect(() => {
        const handleClickOutsideForm = (event) => {
            const designationErrors = form.getFieldError('designationName');

            if (designationErrors.length > 0) {
                form.setFields([
                    {
                        name: 'designationName',
                        errors: [],
                    },
                ]);
            }
        };

        document.addEventListener('click', handleClickOutsideForm);

        return () => {
            // Cleanup the event listener when the component unmounts
            document.removeEventListener('click', handleClickOutsideForm);
        };
    }, [form]);


    useEffect(() => {
        const handleClickOutsideForm = (event) => {
            const designationErrors = form.getFieldError('designationName');
            const categoryErrors = form.getFieldError('category_id');
            const updatedFields = [];

            if (designationErrors.length > 0) {
                updatedFields.push({
                    name: 'designationName',
                    errors: [],
                });
            }

            if (categoryErrors.length > 0) {
                updatedFields.push({
                    name: 'category_id',
                    errors: [],
                });
            }

            if (updatedFields.length > 0) {
                form.setFields(updatedFields);
            }
        };

        document.addEventListener('click', handleClickOutsideForm);

        return () => {
            // Cleanup the event listener when the component unmounts
            document.removeEventListener('click', handleClickOutsideForm);
        };
    }, [form]);
    const handleDesignationChange = (name, e) => {
        const trimmedValue = e.target.value.trimStart();
        form.setFieldsValue({ [name]: trimmedValue });
    };
    // Modal 
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = () => {
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
    };
    return (
        <>
            <Breadcrumb data={str} />
            <div className='BD_master_wrapper'>

                <div className='bd_model_left'>
                    <div className="heading_title">

                        <h3>Team Requisitions</h3>
                        <button className="BG_mainButton" onClick={showModal}>Add Position Information</button>

                    </div>
                </div>


                <div className='bd_model_right'>

                    <Form.Item >
                        <Select
                            showSearch
                            style={{
                                width: 155,
                            }}
                            value={categoryDrop}
                            name='category_id'
                            onChange={(value) => setCategoryDrop(value)}
                            options={categoryList?.map((item, index) => {
                                return {
                                    value: item?.id,
                                    label: item?.category_name
                                }
                            })}
                            filterOption={(input, option) =>
                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                            placeholder='Select Category'
                        />
                    </Form.Item>

                    <DataTable
                        title='Team Requisition Designation Category'
                        handleUpdate={updateHandler}
                        handleDelete={deletehandler}
                        columnLabels={columnLabels}
                        dataSource={designationTableData}
                        showActions={showActions}
                        spinner={spinner}
                        setSpinner={setSpinner}
                    />

                </div>


            </div>
            <Modal title="Add Team Requisition Designation Category " open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} centered>
                <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={createHandler} onKeyDown={handleKeyPress}>

                    <Form.Item
                        label="Category"
                        name="category_id"
                        rules={[
                            {
                                required: true,
                                message: 'Category is required',
                            },
                        ]}
                    >
                        <Select
                            allowClear
                            showSearch
                            placeholder='Select Category'
                            optionFilterProp="children"
                            options={categoryList?.map((item, index) => {
                                return {
                                    value: item?.id,
                                    label: item?.category_name
                                }
                            })}
                            value={addCategory}
                            onChange={(e) => setAddCategory(e)}
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                            filterOption={(input, option) =>
                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >

                        </Select>

                    </Form.Item>

                    <Form.Item label="Designation:" name="designationName" rules={[{ required: true, message: 'Designation is required' }]} >
                        <Input placeholder='Enter here' />
                    </Form.Item>


                    <div className='btn_flex'>
                        <Button onClick={handleReset} key="back" className='BG_ghostButton'>
                            Reset
                        </Button>
                        <button key="submit" className='BG_mainButton' disabled={showNotification}>
                            Submit
                        </button>
                    </div>
                </Form>

            </Modal>
        </>
    )
}

export default TeamRequisitionDesignationCategory;
