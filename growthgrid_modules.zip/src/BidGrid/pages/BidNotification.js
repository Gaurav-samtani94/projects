// @ts-nocheck
import { Avatar, Col, Row, Upload, Modal, Mentions } from 'antd'
import React, { useEffect, useState, useRef } from 'react';
import { useCallback } from 'react';
import { debounce } from 'lodash';
import profileImg from "../assets/images/profile2.jpg"
import { DashboardServiceApi } from 'Services/bidgrid/dashboard/DashboardAPi';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import { docurlchat } from 'utils/configurable';
import { TimeConverter } from 'BidGrid/components/TimeConverter/TimeConverter';
import { useDispatch } from 'react-redux';
import { navigationData } from 'Redux/actions/bidgrid/navigationData';
import { useNavigate } from 'react-router-dom';
import ROUTES from 'Constants/Routes';
import { useSelector } from 'react-redux';
import { SendOutlined, UploadOutlined } from '@ant-design/icons';
import { Close } from '@icon-park/react';
import { useLocation, useParams } from 'react-router-dom';

const getBase64 = (file) =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
    });

function BidNotification() {
    const [notification, setNotification] = useState({})
    const [employeeList, setEmployeeList] = useState([])
    const [fileList, setFileList] = useState([]);
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
    const [binaryData, setBinaryData] = React.useState(null);
    const [rearrangedUserList, setRearrangedUserList] = useState();
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const [notiItem, setNotiItem] = useState([0, 1, 2, 3, 4, 5])
    const handleCancel = () => setPreviewOpen(false);
    const [replyStatus, setReplyStatus] = useState(false);
    const [editId, setEditId] = useState(null)
    const [inputValue, setInputValue] = useState('');
    const { socket, isConnected } = useSelector((state) => state.socket);
    const { id } = useParams()


    // notification list 

    const getUserHistoryApi = async () => {
        try {
            const response = await DashboardServiceApi.fetchNotifications()
            if (response?.data?.status === '1') {
                const dataVal = response?.data?.data
                let all = [];
                let mention = [];
                let request = [];
                let meeting = [];
                dataVal?.map((item) => {
                    all.push(item)
                    if (item?.category_types === 'meeting_schedule') {
                        meeting.push(item);
                    }
                    if (item?.category_types === 'tender_comments' || item?.category_types === 'tender_todo_comments' || item?.category_types === 'to_do_comments') {
                        mention.push(item);
                    }
                    if (item?.category_types === 'tender_request') {
                        request.push(item);
                    }
                });
                setNotification({
                    all,
                    mention,
                    request,
                    meeting

                })



            } else {
                setNotification([])
            }
        } catch (error) {
            setNotification([])
        }
    }
    // user list
    const fetchUserList = async () => {
        try {
            const response = await bidEmployeeList.getUserList()
            if (response?.data?.status === "1") {
                setEmployeeList(response?.data?.data)
            } else {
                setEmployeeList([])
            }
        } catch (error) {

        }
    }

    // navigate function
    const handleNavigate = async (item) => {
        const obj = {
            item: item,
            type: item.category_types,
            key: item?.category_id
        }
        dispatch(navigationData.setNavigationDataAction(obj))
        if (item.category_types === 'tender_todo_comments' || item.category_types === 'tender_comments' || item.category_types === 'meeting_schedule' || item.category_types === 'tender_request') {
            navigate(ROUTES.BD_TENDERDETAILS.replace(':id', item?.tender_id));
        } else if (item.category_types === 'to_do_comments') {
            navigate('/bidgrid/todo');
        }
        try {
            const formData = new URLSearchParams()
            formData.append('notification_id', item?.id)
            const response = await DashboardServiceApi.notificationClicked(formData)

            if (response?.data?.status === '1') {
                getUserHistoryApi(false)
            }
        } catch (error) {

        }

    }

    const replyfocus = useRef(null);
    const [parentId, setParentId] = useState(0)
    // const [editId, setEditId] = useState(null)
    const [replyUser, setReplyUser] = useState({})
    const { userBidInfo } = useSelector((state) => state?.userDetails)

    useEffect(() => {
        getUserHistoryApi()
        fetchUserList()
    }, [])

    // date format
    function formatDateUtcWithMonthName(dateString) {
        if (dateString) {
            const monthNames = [
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'Sept', 'Oct', 'Nov', 'Dec'
            ];

            const date = new Date(dateString);
            const day = date.getUTCDate().toString().padStart(2, '0');
            const month = monthNames[date.getUTCMonth()];
            const year = date.getUTCFullYear();

            return `${day} ${month} ${year}`;
        } else {
            return '';
        }
    }

    const [isReplyBoxVisible, setReplyBoxVisible] = useState(false);

    const toggleReply = () => {
        setReplyBoxVisible(!isReplyBoxVisible);
    };

    const handlePreview = async (file) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj);
        }
        setPreviewImage(file.url || file.preview);
        setPreviewOpen(true);
        setPreviewTitle(
            file.name || file.url.substring(file.url.lastIndexOf('/') + 1)
        );
    };

    const handleChange = ({ fileList: newFileList }) => {
        setFileList(newFileList)
        if (fileList.length === 1) {
            const file = fileList[0];
            const reader = new FileReader();
            reader.onload = () => {
                setBinaryData(reader.result); // Store the binary data in state
            };
            reader.readAsArrayBuffer(file.originFileObj); // Read file as ArrayBuffer
        }
    };

    const AddComment = async () => {

        if (inputValue !== '') {
            let userVar = []
            inputValue?.split(' ')?.filter((val) => val?.includes('@'))
                ?.map((item) => {
                    return rearrangedUserList?.filter((elem) => '@' + elem.userfullname === item)?.forEach((value) => {
                        userVar.push(value.id)
                    });
                });

            const uniqueArray = [...new Set(userVar)];
            let socketDetailShare = { comment_id: editId, file: fileList, tender_id: id, parent_id: parentId, comment_txt: inputValue, ping_users_info: uniqueArray?.join(',') }
            if (isConnected) {
                socket.emit('tender_comment', socketDetailShare);
            }
            console.log(socketDetailShare)
            // await userGetCommentList()
            handleCancelReply()
        }

    }

    const handleCancelReply = () => {
        setReplyUser({})
        setReplyStatus(false)
        setEditId(null);
        setInputValue('')
        setParentId(0)
        setFileList([])
    }

    const uploadButton = (
        <button
            style={{
                border: 0,
                background: 'none',
            }}
            type="button"
        >
            <UploadOutlined />
        </button>
    );

    const onSearch = useCallback(
        debounce(async (search) => {
            const filteredUsers = rearrangedUserList?.map((item) => {
                let userfullnameInp = item?.userfullname
                if (userfullnameInp?.includes(search?.toLowerCase())) {
                    return item
                }
            })
        }, 300),
        []
    );

    const handleChangeComment = (value) => {
        if (value.startsWith(' ')) {
            setInputValue(value.trimStart());
        } else {
            setInputValue(value);
        }
    };

    return (
        <div className="notification_wrapper">
            <h4 className="page__title">Notifications</h4>

            <Row gutter={40}>
                <Col span={24}>
                    <div className="box__title">All notifications <span>{notification?.all?.length}</span></div>
                    <div className="noti__block bg__noti">

                        {notification?.all?.map((item, index) => {
                            const selectedUser = employeeList?.find(val => val?.id === item?.created_by)
                            return (
                                <>
                                    <div className="noti__item" onClick={() => handleNavigate(item)}>

                                        <Avatar
                                            src={docurlchat + item?.profileimg_path + "/" + item?.profileimg}
                                            // style={{ backgroundColor: '#f56a00' }}
                                            size="large"
                                        >
                                            {selectedUser?.userfullname?.charAt(0)}
                                        </Avatar>


                                        <div>
                                            <div className="text__det"><span>@{selectedUser?.userfullname}</span> {item?.category_details?.replace(/<[^>]*>/g, '')} </div>
                                            <div className='chips_time'>
                                                <div className="date_text">{formatDateUtcWithMonthName(item?.created_at)} {TimeConverter(item?.created_at)}</div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            )
                        }
                            // use this class {unSeen_bg} for unread notifications

                        )}

                    </div>
                </Col>
                <Col span={12}>
                    <div className="box__title mt-5">My Comments<span>{notification?.mention?.length}</span></div>
                    <div className="noti__block bg__noti" style={{ borderColor: "#f47125" }}>


                        {notification?.mention?.map((item, index) => {
                            const selectedUser = employeeList?.find(val => val?.id === item?.created_by)
                            return (
                                <>
                                    <div className="noti__item">

                                        <Avatar
                                            src={docurlchat + item?.profileimg_path + "/" + item?.profileimg}
                                            // style={{ backgroundColor: '#f56a00' }}
                                            size="large"
                                            className='comments_img'
                                        >
                                            {selectedUser?.userfullname?.charAt(0)}
                                        </Avatar>


                                        <div>
                                            <div className="text__det"><span>@{selectedUser?.userfullname}</span> {item?.category_details?.replace(/<[^>]*>/g, '')} </div>
                                            <div className='chips_time'>
                                                <div className='text_chips' onClick={toggleReply}>
                                                    <span>Reply</span>
                                                </div>
                                                <div className="date_text">{formatDateUtcWithMonthName(item?.created_at)} {TimeConverter(item?.created_at)}</div>
                                            </div>
                                            {isReplyBoxVisible && (
                                                <div className="comment_wrapper">
                                                    <Upload
                                                        action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
                                                        listType="picture-card"
                                                        fileList={fileList}
                                                        onPreview={handlePreview}
                                                        onChange={handleChange}
                                                    >
                                                        {fileList.length >= 1 ? null : uploadButton}
                                                    </Upload>
                                                    <Modal
                                                        open={previewOpen}
                                                        title={previewTitle}
                                                        footer={null}
                                                        onCancel={handleCancel}
                                                    >
                                                        <img
                                                            alt="example"
                                                            style={{
                                                                width: '100%',
                                                            }}
                                                            src={previewImage}
                                                        />
                                                    </Modal>
                                                    <div className='comment_box'>
                                                        <Mentions
                                                            ref={replyfocus}
                                                            onSearch={onSearch}
                                                            value={inputValue}
                                                            onChange={(value) => handleChangeComment(value)}
                                                            options={rearrangedUserList?.filter(item => item?.id !== userBidInfo?.id)?.map(({ userfullname, profileimg, profileimg_path }) => ({
                                                                key: userfullname,
                                                                value: userfullname,
                                                                className: 'antd-demo-dynamic-option',
                                                                label: (
                                                                    <>
                                                                        {
                                                                            profileimg !== null ?
                                                                                <img src={`${docurlchat}${profileimg_path}/${profileimg}`} alt='' />
                                                                                :
                                                                                <Avatar

                                                                                    style={{ backgroundColor: '#f56a00' }}
                                                                                    size="large"
                                                                                >
                                                                                    {userfullname?.charAt(0)}
                                                                                </Avatar>
                                                                        }
                                                                        <span>{userfullname}</span>
                                                                    </>
                                                                ),
                                                            }))}
                                                            placeholder={replyStatus ? editId ? 'Edit Comment..' : 'Reply Comment..' : 'Type Comment..'}
                                                        >
                                                        </Mentions>
                                                        {replyStatus &&
                                                            <button className="close_text" onClick={handleCancelReply}>
                                                                <Close theme="outline" size="16" fill="#000" strokeWidth={3} strokeLinecap="butt" />
                                                            </button>}
                                                        <div className='reply_icons'>
                                                            <div onClick={AddComment} style={{ lineHeight: "100%" }}> <SendOutlined /></div>
                                                        </div>

                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </>
                            )
                        }
                        )}

                    </div>
                </Col>
                <Col span={12}>
                    <div className="box__title mt-5">My Comments<span>{notification?.mention?.length}</span></div>
                    <div className="noti__block bg__noti" style={{ borderColor: "#f47125" }}>


                        {notification?.mention?.map((item, index) => {
                            const selectedUser = employeeList?.find(val => val?.id === item?.created_by)
                            return (
                                <>
                                    <div className="noti__item" onClick={() => handleNavigate(item)}>

                                        <Avatar
                                            src={docurlchat + item?.profileimg_path + "/" + item?.profileimg}
                                            // style={{ backgroundColor: '#f56a00' }}
                                            size="large"
                                            className='comments_img'
                                        >
                                            {selectedUser?.userfullname?.charAt(0)}
                                        </Avatar>


                                        <div>
                                            <div className='text_mention'>@harshsinghRajawat</div>
                                            <div className='text_desclimer'>Construction of Baba Sarsai Nath Government Medical College, Sirsa, Haryana</div>
                                            <div className="text__det"><span>@{selectedUser?.userfullname}</span> {item?.category_details?.replace(/<[^>]*>/g, '')} </div>
                                            <div className='chips_time'>
                                                <div className='text_chips'>
                                                    <span>Progress</span>
                                                </div>
                                                <div className="date_text">{formatDateUtcWithMonthName(item?.created_at)} {TimeConverter(item?.created_at)}</div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            )
                        }
                            // use this class {unSeen_bg} for unread notifications

                        )}

                    </div>
                </Col>
                <Col span={12}>
                    <div className="box__title mt-5">Requests notifications <span>{notification?.request?.length}</span></div>
                    <div className="noti__block bg__noti">
                        {notification?.request?.map((item, index) => {
                            const selectedUser = employeeList?.find(val => val?.id === item?.created_by)
                            return (
                                <>
                                    <div className="noti__item" onClick={() => handleNavigate(item)}>

                                        <Avatar
                                            src={docurlchat + item?.profileimg_path + "/" + item?.profileimg}
                                            // style={{ backgroundColor: '#f56a00' }}
                                            size="large"
                                        >
                                            {selectedUser?.userfullname?.charAt(0)}
                                        </Avatar>


                                        <div>
                                            <div className="text__det"><span>@{selectedUser?.userfullname}</span> {item?.category_details} </div>
                                            <div className='chips_time'>
                                                <div className="date_text">{formatDateUtcWithMonthName(item?.created_at)} {TimeConverter(item?.created_at)}</div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            )
                        }
                            // use this class {unSeen_bg} for unread notifications

                        )}


                    </div>
                </Col>
                <Col span={12}>
                    <div className="box__title mt-5">Meeting notifications <span>{notification?.meeting?.length}</span></div>
                    <div className="noti__block bg__noti" style={{ borderColor: "#00c4f0" }}>

                        {notification?.meeting?.map((item, index) => {
                            const selectedUser = employeeList?.find(val => val?.id === item?.created_by)
                            return (
                                <>
                                    <div className="noti__item" onClick={() => handleNavigate(item)}>

                                        <Avatar
                                            src={docurlchat + item?.profileimg_path + "/" + item?.profileimg}
                                            // style={{ backgroundColor: '#f56a00' }}
                                            size="large"
                                        >
                                            {selectedUser?.userfullname?.charAt(0)}
                                        </Avatar>


                                        <div>
                                            <div className="text__det"><span>@{selectedUser?.userfullname}</span> {item?.category_details} </div>
                                            <div className='chips_time'>
                                                <div className="date_text">{formatDateUtcWithMonthName(item?.created_at)} {TimeConverter(item?.created_at)}</div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            )
                        }
                            // use this class {unSeen_bg} for unread notifications

                        )}


                    </div>
                </Col>
            </Row>
        </div>
    )
}

export default BidNotification
