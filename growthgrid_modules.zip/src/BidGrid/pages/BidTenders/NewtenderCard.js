// @ts-nocheck
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Down, SaveOne, Add, SortOne, UpOne, DownOne, HamburgerButton } from '@icon-park/react';
import { Form, Select, Input, Checkbox, Tooltip, Dropdown, Menu, Button } from 'antd';
import { DownloadOutlined, } from '@ant-design/icons';
import ExcelJS from 'exceljs';
import FilterImage from '../../assets/images/icons/filter 1.png';
import TenderDetailsCard from '../../components/TendercardComponents/TenderDetailsCard';
import AddTemplateModal from 'BidGrid/components/Models/AddTemplateModal';
import { useDraggable } from "react-use-draggable-scroll";
import Bd_basicFilter from 'BidGrid/components/Drawer/Bd_basicFilter';
import Bd_advanceFilter from 'BidGrid/components/Drawer/Bd_advanceFilter';
import { useSelector, useDispatch } from 'react-redux';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { filterCycleActions } from 'Redux/actions/bidgrid/cycleFilterAction';
import { SearchOutlined } from '@ant-design/icons';
import ExportDatatable from 'BidGrid/components/dataTable/ExportDatatable';
import { DropdownValuesServices } from 'Services/common/dropdown/dropdownValues';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import dayjs from 'dayjs';
import * as XLSX from 'xlsx';
import GernerateNumber from 'BidGrid/components/InAction/GernerateNumber';
import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
import GernerateRole from 'BidGrid/components/InAction/GernerateRole';
import GernerateRole2 from 'BidGrid/components/InAction/GernerateRole2';
import ConsortiumModel from 'BidGrid/components/InAction/ConsortiumModel';
import { toast } from 'react-toastify';
import GenerateChips from 'BidGrid/components/GenerateChips/GenerateChips';
import { RequestApi } from 'Services/bidgrid/tenderList/RequestApi';
import spinGif from '../../assets/images/spin.gif';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import CloseIcon from '@mui/icons-material/Close';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import FilterChipsTemplateDrawer from 'BidGrid/components/Drawer/FilterChipsTemplateDrawer';
import { AddTenderList } from 'Services/bidgrid/add/AddTender';

const notify = (error) => toast.error(error);
const notifySuccess = (msg) => toast.success(msg);

const { Search } = Input;

const columnLabels = {
    gg_tenderID: { name: 'GG Tender ID', required: true, width: 400 },
    tender_name: { name: 'Tender Name', required: true, width: 400 },
    tender_emd_amnt_val: { name: 'Tender amount value', required: true, width: 400 },
    submission_start_date: { name: 'Start Date', required: true, width: 400 },
    submission_end_date: { name: 'End Date', required: true, width: 400 },
}

const initialModalState = {
    bdBasicFilter: { visible: false, data: null },
    createTemplate: { visible: false, data: null },
    saveTemplate: { visible: false, data: null },
    bdAdvanceFilter: { visible: false, data: null },
    generateNum: { visible: false, data: null },
    keyClientAssign: { visible: false, data: null },
    consortiumCompAssign: { visible: false, data: null },
    bidManager: { visible: false, data: null }
}

const initialSortingState = [
    { name: 'Tender Value', orderType: 'none', value: 'tender_amnt_val' },
    { name: 'Tender Emd Value', orderType: 'none', value: 'tender_emd_amnt_val' },
    { name: 'Deadline', orderType: 'none', value: 'submission_end_date' },
    { name: 'Published Date', orderType: 'none', value: 'published_date' },
]

const NewTenderCard = (props) => {
    const { getScopeList, checkedAll, setCheckedAll, checkedTender, setCheckedTender } = props
    const { filetrChips } = useSelector((state) => state.cycleFilter)
    const { filterValues, isUpdate } = useSelector((state => state.cycleFilter));
    const ref = useRef();
    const { events } = useDraggable(ref);

    // modals states
    const [modals, setModals] = useState(initialModalState);
    // if already saved values in filterValues then on keypress of edit it will apply on basic filter saved template
    const [updateFilterData, setUpdateFilterData] = useState(false)

    // loaders 
    const [dropdownSpinner, setDropdownSpinner] = useState(false);
    const [dropdownSpinnerForBulkPopUP, setDropdownSpinnerForBulkPopUP] = useState(false);
    const [bulkDeleteSpinner, setBulkDeleteSpinner] = useState(false);
    const [skeleton, setSkeleton] = useState(true);
    const [loadingModalBtn, setLoadingModalBtn] = useState(false);

    // switch between multiple inactions modals
    const [inActionPopup, setInActionPopup] = useState(false)

    // not familiar ??
    const [applyTemp, setApplyTemp] = useState(false);
    const [collapseActiveKeyTemp, setCollapseActiveKeyTemp] = useState();

    // tender list
    const [getTenders, setTenders] = useState([]);
    const [tenderCount, setTenderCount] = useState()

    //onchange of search 
    const [tenderSearch, setTenderSearch] = useState('')

    // dropdown values 
    const [stateVal, setStateVal] = useState([])
    const defaultValues = 'Select'
    const [statusChange, setStatusChange] = useState(defaultValues);

    const [singleDropDownList, setSingleDropDownList] = useState([]);
    const [bulkDropDownList, setBulkDropDownList] = useState([]);
    const [generateData, setGenerateData] = useState([])
    const [getGenTenderId, setGenTenderId] = useState()

    const [roleListData, setRoleListData] = useState([])
    const [userListData, setUserListData] = useState([])
    const [getBdClientManagerData, setBdClientManagerData] = useState([])

    const [cycleId, setCycleId] = useState()
    const [conSubmitName, setConSubmitName] = useState("")

    const [accdChipData, setAccdChipData] = useState([])
    const [applyFilter, setApplyFilter] = useState()
    const [updateFilter, setUpdateFilter] = useState()
    const [actionData, setActionData] = useState([]);
    const [getActionInAll, setActionInAll] = useState([]);
    const [scopeAllData, setScopeAllData] = useState([]);
    const [requestList, setRequestList] = useState([])
    const [activeOrderColor, setActiveOrderColor] = useState()

    const [bdFilter, setBdFilter] = useState('');
    const [sortData, setSortData] = useState()
    const [sort, setSort] = useState(initialSortingState)
    const [getServiceProvider, setServiceProvider] = useState(initialSortingState)


    const dispatch = useDispatch()

    const getGenerateList = async () => {
        try {
            const response = await tenderCycle.bdGenerateNum()
            if (response?.data?.status === '1') {
                setGenerateData(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const getUserListData = async () => {
        try {
            const response = await bidEmployeeList?.getUserList()
            if (response?.data?.status) {
                setUserListData(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const getRoleList = async () => {
        try {
            const response = await tenderCycle.getBdRoleList()
            if (response?.data?.status === '1') {
                setRoleListData(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const fetchRequestListForDrawer = async (val) => {
        const formData = new URLSearchParams();
        formData.append('tender_id', val)
        try {
            const response = await RequestApi.requestList(formData)
            if (response?.data?.status === "1") {

                const updatedArr = response?.data?.data?.map((item) => {
                    let items = item
                    if (items?.curr_status === '1') {
                        items['status'] = 'Pending'
                    } else if (items?.curr_status === '2') {
                        items['status'] = 'Submitted'
                    } else {
                        items['status'] = 'Approval'
                    }
                    return items
                })
                setRequestList(updatedArr)
            } else {
                setRequestList([])
            }
        } catch (error) {

        }
    }

    const handleMoveTenderToAnotherScope = async (itemID, name) => {

        setGenTenderId(itemID)
        setConSubmitName(name)
        const formData = new URLSearchParams();
        formData.append('tender_id', itemID);
        try {
            const response = await tenderCycle.getBdMoveTender(formData)
            if (response?.data?.status === "1") {
                getAllTenders()
                const indexToRemove = checkedTender.indexOf(itemID);
                if (indexToRemove !== -1) {
                    checkedTender.splice(indexToRemove, 1);
                }
                // notifySuccess(`Tender moved into ${currScopeName ? currScopeName : 'next'} stage`)
                notifySuccess(response?.data?.message)
            } else if (response?.response?.data?.stage == 5) {
                setModals(prevModals => ({
                    ...prevModals,
                    generateNum: { visible: true, data: null },
                }));
            } else if (response?.response?.data?.stage == 6) {
                setModals(prevModals => ({
                    ...prevModals,
                    keyClientAssign: { visible: true, data: null },
                }));

            }
            else if (response?.response?.data?.stage == 7) {
                setModals(prevModals => ({
                    ...prevModals,
                    bidManager: { visible: true, data: null },
                }));
            }
            else if (response?.response?.data?.stage == 11) {
                setModals(prevModals => ({
                    ...prevModals,
                    consortiumCompAssign: { visible: true, data: null },
                }));
            }
            else {
                notify(response?.data?.message);
            }
        } catch (error) {
            console.log(error)
        }

    }
    // change the tender scope from one to another
    const handleSubmitTender = async (val, itemID, setStatusChange, item) => {
        console.log("handle submit===========")
        setInActionPopup(false)
        setDropdownSpinner(prevState => ({
            ...prevState,
            [itemID]: true
        }));
        setCycleId(val)
        setConSubmitName("")
        const formData = new URLSearchParams();
        formData.append("tender_id", itemID);
        formData.append("cycle_id", Number(val));
        try {
            const response = await TenderApi.getTransferTender(formData)
            if (response?.data?.status === '1') {
                getAllTenders()
                // notifySuccess(`Tender moved into ${scopeName ? scopeName : 'next'} stage`)
                notifySuccess(response?.data?.message)
                setDropdownSpinner(prevState => ({
                    ...prevState,
                    [itemID]: false
                }));
            }
            else if (response?.response?.data?.stage == 5) {

                setModals(prevModals => ({
                    ...prevModals,
                    generateNum: { visible: true, data: null },
                }));
                setStatusChange(defaultValues)
                setDropdownSpinner(prevState => ({
                    ...prevState,
                    [itemID]: false
                }));
            } else if (response?.response?.data?.stage == 6) {
                setModals(prevModals => ({
                    ...prevModals,
                    keyClientAssign: { visible: true, data: null },
                }));
                setStatusChange(defaultValues)
                setDropdownSpinner(prevState => ({
                    ...prevState,
                    [itemID]: false
                }));
            }
            else if (response?.response?.data?.stage == 7) {
                setModals(prevModals => ({
                    ...prevModals,
                    bidManager: { visible: true, data: null },
                }));
                setStatusChange(defaultValues)
                setDropdownSpinner(prevState => ({
                    ...prevState,
                    [itemID]: false
                }));
            }
            else if (response?.response?.data?.stage == 11) {
                setModals(prevModals => ({
                    ...prevModals,
                    consortiumCompAssign: { visible: true, data: null },
                }));
                setStatusChange(defaultValues)
                setDropdownSpinner(prevState => ({
                    ...prevState,
                    [itemID]: false
                }));
            }
            else {
                notify(response?.data?.message);
                setDropdownSpinner(prevState => ({
                    ...prevState,
                    [itemID]: false
                }));
            }
        } catch (error) {
            console.log(error)
            setDropdownSpinner(prevState => ({
                ...prevState,
                [itemID]: false
            }));
        }
    }

    //  Common API for whishlist check, Remainder check and Request count.
    const getActionListApi = async () => {
        try {
            const response = await tenderCycle.bdActionListTender()
            if (response?.data?.status === '1') {
                setActionData(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const getActionListForAll = async () => {
        try {
            const response = await TenderApi.getAllTenderCycleInactionBtnList();
            if (response?.data?.status === '1') {
                setActionInAll(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const handleShowChipInAcc = async (val) => {
        const formData = new URLSearchParams();
        formData.append("template_type", '1');
        formData.append("template_name", val);
        try {
            const response = await tenderCycle.bdShowChipstemp(formData)
            if (response?.data?.status === '1') {
                let resData = response?.data?.data
                let newArr = []
                resData?.map((obj) => {
                    const objVal = {
                        key: obj["filter_field_name"],
                        value: obj.filter_field_name === "from_date" || obj?.filter_field_name === "to_date" ? obj?.["filter_field_value"] : obj?.["filter_field_value"]
                    }
                    newArr.push(objVal)
                })
                convertArrToObj(response?.data?.data)
                setAccdChipData(newArr)
            }
        } catch (error) {
            console.log(error)
        }
    }
    const convertArrToObj = (val) => {
        let outputObject = {};
        val?.forEach(item => {
            outputObject[item.filter_field_name] = item.filter_field_value;
        });
        setApplyFilter((old) => ({
            ...filterValues,
            ...outputObject,
        })
        )
        setUpdateFilter(outputObject)
    }

    const handleDeleteBulkTender = async (val) => {
        setBulkDeleteSpinner(true)
        const formData = new URLSearchParams();
        formData.append("tender_ids", val);
        try {
            const response = await tenderCycle.bdDeleteBulkTender(formData)
            if (response?.data?.status == 1) {
                // setBulkDeleteSpinner(false)
                getAllTenders()
                setCheckedTender([]);
                setCheckedAll(false)
                setStatusChange(defaultValues)
                notifySuccess(response?.data?.message)
                setBulkDeleteSpinner(false);

            } else {
                setBulkDeleteSpinner(false)
                setCheckedTender([]);
                setCheckedAll(false)
                notify("Tender not deleted, try again later") // static for now
            }
        } catch (error) {
            console.log(error, "error")
        }
    }

    const getSelectScopeForAll = async () => {
        try {
            const response = await tenderCycle.bdSelectScopeAll();
            if (response?.data?.status == 1) {
                setScopeAllData(response?.data?.data)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const handleUpdateFilter = () => {
        setUpdateFilterData(true)
        setModals(prevModals => ({
            ...prevModals,
            saveTemplate: { visible: false, data: null },
        }));

        setModals(prevModals => ({
            ...prevModals,
            bdBasicFilter: { visible: true, data: null },
        }));

    }

    const showDrawerAdvance = () => {
        setModals(prevModals => ({
            ...prevModals,
            bdBasicFilter: { visible: false, data: null },
            bdAdvanceFilter: { visible: true, data: null }
        }));
    }

    const onChangeStatus = async (e) => {
        let scopeName = bulkDropDownList?.find(item => item.id == e)?.cycle_name;
        setDropdownSpinnerForBulkPopUP(true);
        const formData = new URLSearchParams();
        formData.append('tender_id', checkedTender);
        formData.append('cycle_id', e);
        let result = await TenderApi.bulkTendesTransfer(formData);
        if (result?.data?.status === '1') {
            setDropdownSpinnerForBulkPopUP(false);
            getAllTenders()
            setCheckedTender([]);
            setCheckedAll(false)
            setStatusChange(defaultValues)
            notifySuccess(result?.data?.message)
        } else {
            notify(result?.data?.message);
        }
    };

    const handleAccordionChange = (key) => {
        setCollapseActiveKeyTemp(key[key.length - 1])
        handleShowChipInAcc(key[key.length - 1])
    };

    const handleRadioChange = (e, key) => {
        setCollapseActiveKeyTemp(key)
        handleShowChipInAcc(key)
    };

    const onAdvanceClose = () => {
        setModals(prevModals => ({
            ...prevModals,
            bdAdvanceFilter: { visible: false, data: null }
        }));
    };

    const showDrawer = () => {
        setUpdateFilter()
        setUpdateFilterData(false)
        setModals(prevModals => ({
            ...prevModals,
            bdBasicFilter: { visible: true, data: null },
            bdAdvanceFilter: { visible: false, data: null }
        }));
        setBdFilter('CYCLE')
    };

    const showChipDrawer = () => {
        setCollapseActiveKeyTemp()
        setModals(prevModals => ({
            ...prevModals,
            saveTemplate: { visible: true, data: null },
        }));
    }
    const handleCheckAll = () => {
        if (getTenders.length === checkedTender.length || checkedTender.length > getTenders?.length) {
            setCheckedAll(false)
            setCheckedTender([]);
        }
        else {
            const postIds = getTenders?.map((item) => {
                return item.id;
            })
            setCheckedAll(true);
            setCheckedTender(postIds);
        }
    }
    const getServiceProviderList = async () => {
        try {
            let response = await AddTenderList?.getServiceProviderApi();
            if (response?.data?.status == 1) {
                setServiceProvider(response?.data?.data)
            }
        } catch (error) {
            console.log(error, "error")
        }

    }

    const getAllTenders = async () => {

        if (!filterValues?.cycle_id) {
            return
        } else {
            setSkeleton(true)
            const formData = new URLSearchParams();
            filterValues?.cycle_id != 0 && filterValues?.cycle_id != null && formData.append('cycle_id', filterValues.cycle_id);
            formData.append('sector_id', filterValues.sector_id ? filterValues.sector_id : "");
            formData.append("tender_keyword", filterValues?.tender_keyword ? filterValues?.tender_keyword : "")
            formData.append("country_id", filterValues?.country_id ? filterValues?.country_id : "")
            formData.append("funding_id", filterValues?.funding_id ? filterValues?.funding_id : "")
            formData.append("from_date", filterValues?.from_date ? filterValues?.from_date : "")
            formData.append("to_date", filterValues?.to_date ? filterValues?.to_date : "")
            formData.append("published_date", filterValues?.published_date ? filterValues?.published_date : "")
            formData.append("close_exp_date", filterValues?.close_exp_date ? filterValues?.close_exp_date : "")
            formData.append("estm_value", filterValues?.estm_value ? filterValues?.estm_value : "")
            formData.append("estm_value_emd", filterValues?.estm_value_emd ? filterValues?.estm_value_emd : "")
            formData.append('amnt_custrange_operator', filterValues?.amnt_custrange_operator ? filterValues?.amnt_custrange_operator : "")
            formData.append('amnt_custrange_amount', filterValues?.amnt_custrange_amount ? filterValues?.amnt_custrange_amount : "")
            formData.append('custrange_denomination', filterValues?.custrange_denomination ? filterValues?.custrange_denomination : "")
            formData.append('amnt_custrange_operator_emd', filterValues?.amnt_custrange_operator_emd ? filterValues?.amnt_custrange_operator_emd : "")
            formData.append('amnt_custrange_amount_emd', filterValues?.amnt_custrange_amount_emd ? filterValues?.amnt_custrange_amount_emd : "")
            formData.append('custrange_denomination_emd', filterValues?.custrange_denomination_emd ? filterValues?.custrange_denomination_emd : "")
            formData.append("state_id", filterValues?.state_id ? filterValues?.state_id : "")
            formData.append("client_id", filterValues?.client_id ? filterValues?.client_id : "")
            formData.append("currency_id", filterValues?.currency_id ? filterValues?.currency_id : "")
            formData.append("pubdate_cust_from_date", filterValues?.pubdate_cust_from_date ? filterValues?.pubdate_cust_from_date : "")
            formData.append("pubdate_cust_to_date", filterValues?.pubdate_cust_to_date ? filterValues?.pubdate_cust_to_date : "")
            formData.append("expdate_cust_from_date", filterValues?.expdate_cust_from_date ? filterValues?.expdate_cust_from_date : "")
            formData.append("expdate_cust_to_date", filterValues?.expdate_cust_to_date ? filterValues?.expdate_cust_to_date : "")
            formData.append("tender_status", filterValues?.tender_status ? filterValues?.tender_status : "")
            formData.append("tender_activity_status", filterValues?.tender_activity_status ? filterValues?.tender_activity_status : "")
            // formData.append("tender_activity_status", filterValues?.tender_activity_status ? (filterValues?.tender_activity_status != 3 ? filterValues?.tender_activity_status : "ALL") : "")
            formData.append("located", filterValues?.located ? filterValues?.located : "")
            formData.append("sort_key", filterValues?.sort_key ? filterValues?.sort_key : "");
            formData.append("sort_val", filterValues?.sort_val ? filterValues?.sort_val : "");
            formData.append("ping_users", filterValues?.ping_users ? filterValues?.ping_users : "");
            formData.append('limit', filterValues?.limit ? parseInt(filterValues?.limit) : 25);
            formData.append('page_number', filterValues?.page_number ? filterValues?.page_number : "1")
            try {
                let result = await TenderApi.getTenderList(formData);
                if (checkedAll) {
                    const postIds = result?.data?.data?.map((item) => {
                        return item.id;
                    })
                    setCheckedAll(true);
                    let filteredArray1 = postIds.filter(element => !checkedTender.includes(element));
                    setCheckedTender([...checkedTender, ...filteredArray1]);
                }
                dispatch(filterCycleActions.filterResetisUpdate())
                setSkeleton(false)
                setTenders(result?.data?.data);
                setTenderCount(result?.data)
            } catch (error) {
                setTenders([]);
                setSkeleton(false)
            }
        }
    }


    useEffect(() => {
        if (isUpdate) {
            getAllTenders();
            getSingleDropDownValues();
            getServiceProviderList()
        }
    }, [filterValues, isUpdate]);

    // fetch state values based on country
    const getStateDrpValue = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('country_id', filterValues?.country_id);
            const response = await AddTenderList.getTenderStateList(formData)
            if (response?.data?.status === 1) {
                setStateVal(response?.data?.data?.filter(val => val?.state_name !== 'NA'))
            } else {
                setStateVal([])
            }
        } catch {
            console.log("error")
            setStateVal([])
        }
    }

    /* Function for the dropdown values to move tender from one scope to another*/
    const getSingleDropDownValues = async () => {

        const formData = new URLSearchParams();
        formData.append('cycle_id', filterValues.cycle_id);
        let result = await TenderApi.getDropDownValuesSingle(formData);

        if (result?.data?.status === '1') {
            setSingleDropDownList(result?.data?.data);
            let tempArr = result?.data?.data?.filter(item => item.order_sr <= 6);
            setBulkDropDownList(tempArr);
        }
    }



    const handleFilterChange = (e) => {
        setTenderSearch(e.target.value)
        if (e.key === 'Enter') {
            e.preventDefault();
            handleSearchFun()
        }
    };

    const handleSearchFun = (e) => {

        let obj = {
            ...filterValues,
            tender_keyword: tenderSearch
        }
        tenderSearch && dispatch(filterCycleActions.filterUpdateAllKeys(obj));
    }

    const handleReset = () => {

        const data = filetrChips?.filter(item =>
            // console.log()
            item?.value !== ''
            && (item?.key !== 'limit' || item?.value != '25')
            && (item?.key !== 'page_number' || item?.value != '1')
            && item?.key !== 'cycle_id'
            && item?.key !== 'orderSerial'
        )
        const isValue = data?.some((item) => item?.value != '');

        setTenderSearch('');
        isValue && dispatch(filterCycleActions.filterResetKeys())
        localStorage.removeItem('sortBy')
        setActiveOrderColor()

    }

    // For converting html tag value into normal html.
    const stripHtmlTags = (htmlContent) => {
        var doc = new DOMParser().parseFromString(htmlContent, 'text/html');
        return doc.body.textContent || "";
    }

    const formattedData = getTenders?.map((item, index) => {
        let assignDate = item?.assign_tender?.find(item => item?.bd_role_id == 2)?.created_at;
        assignDate = dayjs(assignDate).subtract(dayjs(assignDate).utcOffset(), 'minute').format("DD MMM YYYY");

        let consortiumCompName = item?.bg_tenders_lead?.main_company?.company_name ? item?.bg_tenders_lead?.main_company?.company_name : '';
        let jvs = item?.bg_tenders_jvs?.length > 0 && item?.bg_tenders_jvs?.map(item => item?.main_company?.company_name).toString();
        jvs = jvs ? jvs : '';

        let associatives = item?.bg_tenders_associatives?.length > 0 && item?.bg_tenders_associatives?.map(item => item?.main_company?.company_name).toString();
        associatives = associatives ? associatives : '';

        return {
            'Sr No.': (index + 1).toString(),
            'Date Of Submission': dayjs(item.submission_end_date).subtract(dayjs(item.submission_end_date).utcOffset(), 'minute').format("DD MMM YYYY"),
            'Tender Id': item?.bg_assign_tndr_generated_id?.generated_tender_id ? item?.bg_assign_tndr_generated_id?.generated_tender_id : '-',
            'Tender Details': stripHtmlTags(item?.tender_name),
            'National/International': item?.national_intern == 1 ? "National" : "International",
            'EOI/Proposal': item?.bg_assign_tndr_generated_id?.bg_mstr_tndr_generated_type?.generated_type ? item?.bg_assign_tndr_generated_id?.bg_mstr_tndr_generated_type?.generated_type : '-',
            'Funding Agency': item?.funding_agency != null ? item?.funding_agency?.funding_org_name : '-',
            'Country': item?.bg_mstr_country?.country_name ? item?.bg_mstr_country?.country_name : '-',
            'State': item?.bg_mstr_state?.state_name ? item?.bg_mstr_state?.state_name : '-',
            'Client': item?.bg_mstr_client?.client_name ? item?.bg_mstr_client?.client_name : '-',
            'Client Address': item?.client_cont_address ? item?.client_cont_address : '-',
            'Client Contact Person/Email': item?.client_cont_person ? item?.client_cont_person : '-',
            'Assign Date': assignDate ? assignDate : '-',
            'Proposal Manager': item?.assign_tender[1]?.user?.userfullname ? item?.assign_tender[1]?.user?.userfullname : '-',
            'Date Of Prebid': item?.pre_bid_meeting_date != null ? item?.pre_bid_meeting_date : '-',
            'Prebid Attended by': item?.pre_bid_attend != null ? item?.pre_bid_attend : '-',
            'Consortium Details': consortiumCompName + (consortiumCompName && '-') + jvs + '-' + associatives,
            'Proposal/EOI Follow up by': item?.assign_tender[0]?.user?.userfullname,
            'Comments': item?.tender_comment?.comment_txt ? item?.tender_comment?.comment_txt : '-',
        };
    });


    const downloadExcel = async () => {

        if (getTenders?.length > 0) {
            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet('Sheet1');

            // Add headers
            const headers = [
                'Sr No.', 'Date Of Submission', 'Tender Id', 'Tender Details', 'National/International', 'EOI/Proposal',
                'Funding Agency', 'Country', 'State', 'Client', 'Client Address', 'Client Contact Person/Email',
                'Assign Date', 'Proposal Manager', 'Date Of Prebid', 'Prebid Attended by', 'Consortium Details',
                'Proposal/EOI Follow up by', 'Comments'
            ];
            worksheet.addRow(headers);

            // Style headers
            worksheet.getRow(1).eachCell((cell) => {
                cell.font = { bold: true, size: 11, };
                // cell.fill = {
                //     type: 'pattern',
                //     pattern: 'solid',
                //     fgColor: { argb: 'FF000000' }
                // };
                cell.alignment = { horizontal: 'center', vertical: 'middle' };
                cell.border = {
                    top: { style: 'thin' },
                    left: { style: 'thin' },
                    bottom: { style: 'thin' },
                    right: { style: 'thin' }
                };
            });

            // Add data rows
            formattedData.forEach((data) => {
                worksheet.addRow(Object.values(data));
            });

            // Set column widths
            const colWidths = [10, 20, 20, 40, 25, 15, 20, 15, 15, 30, 40, 40, 20, 25, 30, 20, 30, 25, 30];
            colWidths.forEach((width, index) => {
                worksheet.getColumn(index + 1).width = width;
            });

            // Set row heights
            worksheet.getRow(1).height = 40; // Header row height
            worksheet.eachRow((row, rowNumber) => {
                if (rowNumber !== 1) {
                    row.height = 30; // Data rows height
                }
            });

            const buffer = await workbook.xlsx.writeBuffer();
            const dataBlob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

            const downloadLink = document.createElement('a');
            const url = URL.createObjectURL(dataBlob);
            downloadLink.href = url;
            downloadLink.download = filterValues?.orderSerial == '0' ? "All" : `${getTenders[0]?.bg_mstr_tndr_cycle?.cycle_name}`;
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }

    };

    useEffect(() => {
        modals?.generateNum?.visible && getGenerateList()
        modals?.keyClientAssign?.visible && getRoleList()
    }, [modals?.generateNum?.visible, modals?.keyClientAssign?.visible])

    useEffect(() => {
        getUserListData()
    }, [])

    useEffect(() => {
        getActionListApi()
        getActionListForAll()
        if (filterValues?.cycle_id == '0') {
            getSelectScopeForAll()
        }
    }, [filterValues?.cycle_id])

    useEffect(() => {
        if (filterValues?.country_id) {
            getStateDrpValue()
        }
    }, [filterValues?.country_id])

    const generateChips = useCallback((val) => {
        return (
            <GenerateChips
                filterData={filetrChips}
                stateVal={stateVal}
                getScopeList={getScopeList}
                setTenderSearch={setTenderSearch}
                showCross={true}
                commonFilter={"CYCLE"}
                setActiveOrderColor={setActiveOrderColor}
                val={val}
            />
        )
    }, [stateVal, filetrChips]);

    const accGenerateChips = useCallback((showCross) => {
        if (accdChipData !== null && accdChipData !== []) {
            return (
                <GenerateChips
                    filterData={accdChipData}
                    stateVal={stateVal}
                    getScopeList={getScopeList}
                    setTenderSearch={setTenderSearch}
                    commonFilter={"CYCLE"}
                    showCross={showCross}
                />
            )
        }
    }, [accdChipData]);


    const showScopeName = (scope_id) => {
        return getScopeList?.find(item => item.id == scope_id?.toString())?.scope_name;
    }

    const closeMultiSelectPopUp = () => {
        setCheckedTender([]);
        setCheckedAll(false)
    }

    useEffect(() => {
        const storedSort = JSON.parse(localStorage.getItem('sortBy'));
        if (storedSort) {
            setSort(storedSort);
        }
    }, [filterValues])

    useEffect(() => {
        const storedSort = JSON.parse(localStorage.getItem('sortBy'));
        const filData = storedSort?.find((item) => item?.orderType != 'none')
        handleSort(filData, false)
    }, [])

    const handleSort = (val, data) => {
        setSortData(val)
        let newArray = sort.map(item => {
            return { ...item, orderType: 'none' };
        });
        let orderValue = '';
        if (val?.orderType === 'none') {
            newArray = newArray.map(item => {
                if (item.value === val.value) {
                    return { ...item, orderType: 'asc' };
                }
                return item;
            });
            orderValue = 'asc'
            setActiveOrderColor(orderValue)
        } else if (val?.orderType === 'asc') {
            setActiveOrderColor("ASC")
            newArray = newArray.map(item => {
                if (item.value === val.value) {
                    return !data && val != undefined ? { ...item, orderType: 'asc' } : { ...item, orderType: 'desc' };
                }
                return item;
            });
            orderValue = !data && val != undefined ? 'asc' : 'desc'
            setActiveOrderColor(orderValue)
        } else if (val?.orderType === 'desc') {
            setActiveOrderColor("DESC")
            newArray = newArray.map(item => {
                if (item.value === val.value) {
                    return !data && val != undefined ? { ...item, orderType: 'desc' } : { ...item, orderType: 'asc' };
                }
                return item;
            })
            orderValue = !data && val != undefined ? 'desc' : 'asc'
            setActiveOrderColor(orderValue)
        } else {
            newArray = newArray
            orderValue = ''
        }
        const obj = {
            ...filterValues,
            sort_key: val?.value == undefined ? "" : val?.value,
            sort_val: orderValue
        }
        localStorage.setItem('sortBy', JSON.stringify(newArray));
        dispatch(filterCycleActions.filterUpdateAllKeys(obj))
    }


    const menu = (
        <Menu>
            {sort?.map(item => (
                <Menu.Item key={item.value} onClick={() => handleSort(item, true)}>
                    <div className="sort_item">
                        {item.name}
                        <div className="icon_drop">
                            <UpOne theme="filled" size="22" fill={activeOrderColor != undefined && activeOrderColor == "desc" && sortData?.value == item?.value ? "#000" : "#d0d0d0"} strokeWidth={3} strokeLinecap="butt" />
                            <DownOne theme="filled" size="22" fill={activeOrderColor != undefined && activeOrderColor == "asc" && sortData?.value == item?.value ? "#000" : "#d0d0d0"} strokeWidth={3} strokeLinecap="butt" />
                        </div>
                    </div>
                </Menu.Item>
            ))}
        </Menu>
    );

    return (
        <>
            <div className="bd_tenderWapper">
                <div className="fixed_wrapper">
                    <div className="bd_newTender_heading">
                        <div className="headding-title">
                            <button onClick={props.toggleCollapsed}>
                                {props.collapsed ?
                                    <HamburgerButton theme="filled" size="24" fill="#858585" strokeWidth={3} strokeLinecap="butt" />
                                    :
                                    <HamburgerButton theme="filled" size="24" fill="#858585" strokeWidth={3} strokeLinecap="butt" />
                                }
                            </button>
                            {!skeleton ? (<h2>{showScopeName(filterValues?.cycle_id)} Tenders</h2>) : <Skeleton width={200} height={30} />}
                        </div>
                        <div className='bd_seacrh_box'>
                            <div className="table_wrap mt-0">
                                <Search
                                    placeholder="Search"
                                    allowClear
                                    value={tenderSearch}
                                    onChange={handleFilterChange}
                                    onKeyDown={handleFilterChange}
                                />
                                <div className="search_icon" onClick={() => handleSearchFun()}><button><SearchOutlined /></button>
                                </div>
                            </div>
                            <button className="BG_ghostButton" onClick={() => handleReset()}>Reset</button>
                            <button className="BG_mainButton" onClick={showDrawer}><img src={FilterImage} width={20} alt='' />Filter</button>
                        </div>

                    </div>

                    <div className="bd_tenderFilter">
                        <div className="card">
                            <div className="bd_cards_select">
                                <Checkbox checked={checkedAll} disabled={getTenders?.length === 0 || getTenders?.length === undefined ? true : false} onChange={handleCheckAll} style={{ display: filterValues?.cycle_id == 0 || filterValues?.orderSerial == 6 || filterValues?.orderSerial == 7 ? "none" : "flex" }} >
                                    Select all
                                </Checkbox>
                                <div className='navbar_middle' style={{ display: checkedTender.length > 0 ? 'block' : 'none' }}>
                                    <div className='bd_tender_important'>
                                        <div>
                                            <span style={{ padding: "20" }}>{`${checkedTender?.length} ${checkedTender?.length > 1 ? 'Tenders' : 'Tender'} Selected`}</span>
                                        </div>
                                        <div className="bd_active_btn_sec" >
                                            <div className={`status_select ${statusChange}`}>
                                                {!dropdownSpinnerForBulkPopUP ? <Select
                                                    defaultValue={defaultValues}
                                                    value={statusChange}
                                                    onChange={onChangeStatus}
                                                    suffixIcon={<Down theme="outline" size="18" fill="#78889b" />}

                                                    options={bulkDropDownList?.map((item) => ({
                                                        value: item.id,
                                                        label: item.cycle_name
                                                    }))}
                                                /> : <img src={spinGif} class="mt-2" width={30} />}
                                            </div>
                                        </div>
                                        <div className='delete_select_bd' onClick={() => handleDeleteBulkTender(checkedTender)} style={{ display: filterValues?.orderSerial == 7 ? "none" : "flex" }} >
                                            {!bulkDeleteSpinner ?
                                                <button> <DeleteOutlineIcon width={18} />Delete</button>
                                                : <img src={spinGif} width={30} />}
                                        </div>
                                        <span><Tooltip title="Close"> <CloseIcon onClick={() => closeMultiSelectPopUp()} /></Tooltip></span>
                                    </div>
                                </div>

                            </div>
                            <div className="bd_new_button">
                                <button className='BG_ghostButton excelExport' onClick={downloadExcel}>  <DownloadOutlined /> Excel</button>
                                <div className="showPrPage">
                                    <Form.Item className="export">
                                        {/* <Select placeholder="Export" style={{ width: 120 }} suffixIcon={<Down theme="outline" size="20" fill="#636363" />}>
                                            {Object.entries(selectOptions)?.map(([value, label]) => (
                                                <Option key={value} value={value}>
                                                    {label}
                                                </Option>
                                            ))}
                                        </Select> */}
                                        <ExportDatatable
                                            dataSource={getTenders}
                                            columnLabels={columnLabels}
                                        />
                                    </Form.Item>
                                </div>
                                <Dropdown
                                    className="sorting_wrap"
                                    // menu={{
                                    //     items,
                                    // }}
                                    overlay={menu}
                                    dropdownRender={(menu) => (

                                        <div className="sorting_dropdown_wrap">
                                            {React.cloneElement(menu)}
                                        </div>
                                    )}
                                    placement="bottomRight"
                                >
                                    <a onClick={(e) => e.preventDefault()}>
                                        <span>
                                            <SortOne theme="outline" size="22" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                            SORT BY
                                        </span>
                                        <Down theme="outline" size="21" fill="#9b9b9b" strokeWidth={3}
                                            strokeLinecap="butt" />
                                    </a>
                                </Dropdown>
                                <button className="saveTempletes" onClick={showChipDrawer}>
                                    <div className="iconFlex">
                                        <SaveOne theme="outline" size="20" fill="#3bba61" strokeWidth={3} strokeLinecap="butt" />
                                    </div>
                                    Saved Templates
                                </button>
                            </div>
                        </div>

                    </div>
                </div>

                <div className='card mt-4 add_template_card' style={{
                    display: filetrChips && filetrChips.some(item =>
                        item.value !== '' && !['page_number', 'cycle_id', 'limit', 'orderSerial'].includes(item.key)
                    ) ? "block" : "none"
                }} >
                    <div className="bd_cards_tender" {...events} ref={ref}>
                        {generateChips()}
                    </div>
                    <button className="BG_addTemplate"
                        onClick={() => setModals(prevModals => ({
                            ...prevModals,
                            createTemplate: { visible: true, data: null },
                        }))}
                        style={{ display: applyTemp === true ? "none" : "" }} >
                        <Add theme="outline" size="22" fill="#684fd8" strokeWidth={3} strokeLinecap="butt" />Add Template
                    </button>
                </div>

                <TenderDetailsCard
                    skeleton={skeleton}
                    setChecked={setCheckedAll}
                    getTenders={getTenders}
                    setSelectedItems={setCheckedTender}
                    selectedItems={checkedTender}
                    setTenders={setTenders}
                    singleDropDownList={singleDropDownList}
                    setGenerateNumOpen={() => setModals(prevModals => ({
                        ...prevModals,
                        generateNum: { visible: true, data: null },
                    }))}
                    setGenTenderId={setGenTenderId}
                    handleSubmitTender={handleSubmitTender}
                    handleMoveTenderToAnotherScope={handleMoveTenderToAnotherScope}
                    actionData={actionData}
                    getActionInAll={getActionInAll}
                    scopeAllData={scopeAllData}
                    setRoleOpen={() => setModals(prevModals => ({
                        ...prevModals,
                        bidManager: { visible: true, data: null },
                    }))}
                    setBidRoleOpen={() => setModals(prevModals => ({
                        ...prevModals,
                        keyClientAssign: { visible: true, data: null },
                    }))}
                    requestList={requestList}
                    fetchRequestListForDrawer={fetchRequestListForDrawer}
                    userListData={userListData}
                    getActionListApi={getActionListApi}
                    getAllTenders={getAllTenders}
                    dropdownSpinner={dropdownSpinner}
                    setCycleId={setCycleId}
                    setInActionPopup={setInActionPopup}
                    tenderCount={tenderCount}
                    getActionListForAll={getActionListForAll}
                    commonFilter={'CYCLE'}
                    handleCheckAll={handleCheckAll}
                    page_Num={filterValues?.page_number}
                    limit={filterValues?.limit}
                    cycleId={filterValues?.cycle_id}
                    getServiceProvider={getServiceProvider}
                />

            </div >

            <FilterChipsTemplateDrawer
                open={modals?.saveTemplate?.visible}
                close={() => {
                    setModals(prevModals => ({
                        ...prevModals,
                        saveTemplate: { visible: false, data: null },
                    }))
                }}
                setModals={setModals}
                applyFilter={applyFilter}
                setApplyTemp={setApplyTemp}
                setCollapseActiveKeyTemp={setCollapseActiveKeyTemp}
                collapseActiveKeyTemp={collapseActiveKeyTemp}
                handleUpdateFilter={handleUpdateFilter}
                handleAccordionChange={handleAccordionChange}
                handleRadioChange={handleRadioChange}
                accGenerateChips={accGenerateChips}
                getScopeList={getScopeList}
                tempType={"1"}
                commonFilter={"CYCLE"}
            />
            {/* Basic Filter Drawer*/}
            <GernerateNumber
                open={modals?.generateNum?.visible}
                close={() => setModals(prevModals => ({
                    ...prevModals,
                    generateNum: { visible: false, data: null },
                }))}
                generateData={generateData}
                getGenTenderId={getGenTenderId}
                tenderCycle={tenderCycle}
                setModals={setModals}
                inActionPopup={inActionPopup}
                getAllTenders={getAllTenders}
                setInActionPopup={setInActionPopup}
                loadingModalBtn={loadingModalBtn}
                setLoadingModalBtn={setLoadingModalBtn}
            />
            <GernerateRole  // BID MANAGER
                open={modals?.bidManager?.visible}
                close={() => setModals(prevModals => ({
                    ...prevModals,
                    bidManager: { visible: false, data: null },
                }))}
                getGenTenderId={getGenTenderId}
                userListData={userListData}

                tenderCycle={tenderCycle}
                setBdClientManagerData={setBdClientManagerData}
                setModals={setModals}
                inActionPopup={inActionPopup}
                setInActionPopup={setInActionPopup}
                getAllTenders={getAllTenders}

                loadingModalBtn={loadingModalBtn}
                setLoadingModalBtn={setLoadingModalBtn}

            />
            <GernerateRole2 // KEY CLIENT MANAGER
                open={modals?.keyClientAssign?.visible}
                close={() => setModals(prevModals => ({
                    ...prevModals,
                    keyClientAssign: { visible: false, data: null },
                }))}
                getGenTenderId={getGenTenderId}
                userListData={userListData}

                tenderCycle={tenderCycle}
                setModals={setModals}
                inActionPopup={inActionPopup}
                setInActionPopup={setInActionPopup}
                getAllTenders={getAllTenders}
                loadingModalBtn={loadingModalBtn}
                setLoadingModalBtn={setLoadingModalBtn}
            />
            {/* lead company modal */}
            <ConsortiumModel
                open={modals?.consortiumCompAssign?.visible}
                close={() => setModals(prevModals => ({
                    ...prevModals,
                    consortiumCompAssign: { visible: false, data: null },
                }))}
                getGenTenderId={getGenTenderId}
                getAllTenders={getAllTenders}
                consortiumModelOpen={modals?.consortiumCompAssign?.visible}
                handleMoveTenderToAnotherScope={handleMoveTenderToAnotherScope}
                setModals={setModals}
                loadingModalBtn={loadingModalBtn}
                setLoadingModalBtn={setLoadingModalBtn}
                conSubmitName={conSubmitName}
                handleSubmitTender={handleSubmitTender}
                cycleId={cycleId}
            />
            < Bd_basicFilter
                open={modals?.bdBasicFilter?.visible}
                close={() =>
                    setModals(prevModals => ({
                        ...prevModals,
                        bdBasicFilter: { visible: false, data: null },
                    }))
                }
                showDrawerAdvance={showDrawerAdvance}

                updateFilter={updateFilter}
                setUpdateFilter={setUpdateFilter}
                updateFilterData={updateFilterData}
                collapseActiveKeyTemp={collapseActiveKeyTemp}
                setCollapseActiveKeyTemp={setCollapseActiveKeyTemp}
                getScopeList={getScopeList}
                setApplyTemp={setApplyTemp}
                commonFilter={bdFilter}
                filterValData={filterValues}
                tempType={"1"}
            />
            <Bd_advanceFilter
                showDrawer={showDrawer}
                advanceOpen={modals?.bdAdvanceFilter?.visible}
                onAdvanceClose={onAdvanceClose}
                collapseActiveKeyTemp={collapseActiveKeyTemp}
                updateFilterData={updateFilterData}
                updateFilter={updateFilter}
                setOpen={handleUpdateFilter}
                commonFilter={bdFilter}
                filterValData={filterValues}
                tempType={"1"}
            />

            <AddTemplateModal
                close={() => setModals(prevModals => ({
                    ...prevModals,
                    createTemplate: { visible: false, data: null },
                }))}
                open={modals?.createTemplate?.visible}
                generateChips={generateChips}
                tempType={"1"}
                filterValChipsData={filetrChips}
            />

        </>
    )
}

export default NewTenderCard;

