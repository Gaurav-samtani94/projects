// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Input, Select } from 'antd';
import TodoBoard from 'BidGrid/components/TodoBoard/TodoBoard';
import { useLocation } from 'react-router';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import ROUTES from 'Constants/Routes';
import { TodoServices } from 'Services/bidgrid/todo/TodoServices';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';

import { Plus } from '@icon-park/react';

// const { Option } = Select;
const { Search } = Input;


const optionsVal = {
    assign_type: [{ label: 'Self', value: 1 }, { label: 'As-IO', value: 2 }],
    task_priority: [],
    hash_tags: [],
    current_scope: [{ label: 'To DO', value: 1 }, { label: 'In Progress', value: 2 }, { label: 'Complete', value: 3 }],
    assigned_to_users: [],
    project: [{ label: 'Project1', value: 1 }, { label: 'Project2', value: 2 }, { label: 'Project3', value: 3 }, { label: 'Project4', value: 4 }],

}
function Todo({ id }) {
    const [open, setOpen] = useState(false);
    const [dropdownValState, setDropdownValState] = useState(optionsVal);
    const [search, setSearch] = useState('')
    const [selectedFilterData, setSelectedFilterData] = useState({
        priority: null,
        assigntype: null
    })

    const showTodoDrawer = () => {
        setOpen(true);
    };

    const handleChangeType = (name, value) => {
        setSelectedFilterData({ ...selectedFilterData, [name]: value })
    };

    const onClosebtn = () => {
        setOpen(false);
    };

    const getPriority = async () => {
        // task Priority
        try {
            const res = await TodoServices.getTaskPriorityList()
            if (res?.data?.status === '1') {
                setDropdownValState(prevState => ({ ...prevState, task_priority: res?.data?.data }))

            } else {
                setDropdownValState(prevState => ({ ...prevState, task_priority: [] }))
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }
    const getHashtags = async () => {
        //HasgTag List
        try {
            const res = await TodoServices.gethashlist()
            if (res?.data?.status === '1') {
                setDropdownValState(prevState => ({ ...prevState, hash_tags: res?.data?.data }))
            } else {
                setDropdownValState(prevState => ({ ...prevState, hash_tags: [] }))
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }
    const getUserList = async () => {
        // Assign user list
        try {
            const res = await bidEmployeeList.getUserList()
            if (res?.data?.status === '1') {
                setDropdownValState(prevState => ({ ...prevState, assigned_to_users: res?.data?.data }))
            } else {
                setDropdownValState(prevState => ({ ...prevState, assigned_to_users: [] }))
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }


    useEffect(() => {
        if (open) {
            getHashtags()
        }
    }, [open])


    useEffect(() => {
        getUserList()
        getHashtags()
        getPriority()
    }, []);

    const handlefilter = () => {
        setSelectedFilterData({
            priority: null,
            assigntype: null
        })
        setSearch('')
    }



    return (
        <>

            <div className='todo_container'>
                <div className='todo_assign_cont'>
                    <div className='todo_search_container'>
                        <div className='bd_seacrh_box'>
                            <Search
                                placeholder="Search"
                                allowClear
                                style={{ width: 400 }}
                                onChange={(e) => setSearch(e?.target?.value?.trimStart())}
                                value={search}
                            />
                        </div>
                        <div className='bd_wishlist_collection'>

                            <Select
                                allowClear
                                style={{
                                    width: 200,
                                }}
                                name='assigntype'
                                value={selectedFilterData?.assigntype}
                                onChange={(value) => handleChangeType('assigntype', value)}
                                options={dropdownValState?.assign_type?.map((item, index) => {
                                    return {
                                        value: item?.value,
                                        label: item?.label
                                    }
                                })}
                                placeholder='Assignment Recipient
                                '
                            />
                            <Select
                                allowClear
                                style={{
                                    width: 155,
                                }}
                                name='priority'
                                value={selectedFilterData?.priority}
                                onChange={(value) => handleChangeType('priority', value)}
                                options={dropdownValState?.task_priority?.map((item, index) => {
                                    return {
                                        value: item?.id,
                                        label: item?.task_priority_name
                                    }
                                })}
                                placeholder='Priority'
                            />
                        </div>
                    </div>
                    <div className='comment_btned'>
                        <button className='BG_ghostButton' onClick={handlefilter}>Reset</button>
                        <button className='BG_mainButton' onClick={showTodoDrawer}><Plus theme="outline" size="24" fill="#fff" strokeWidth={3} strokeLinecap="butt" /> Create Task</button>
                    </div>

                </div>

                <div className="bd-progress-head">
                    <div className='bd_tool_task'>
                        <TodoBoard open={open} setOpen={setOpen} onClosebtn={onClosebtn} dropdownValState={dropdownValState} showTodoDrawer={showTodoDrawer} selectedFilterData={selectedFilterData} searchData={search} projectId={id} setDropdownValState={setDropdownValState} />
                    </div>
                </div>
            </div>
        </>
    )
}
// Todo.whyDidYouRender = true
export default Todo
