
import React, { useEffect, useState, useMemo } from 'react';
import { Button, Input, Select, Dropdown, Menu, DatePicker, Drawer, Form, Row, Col, Radio, TimePicker } from 'antd';
import { Down } from '@icon-park/react';
import { More } from '@icon-park/react';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import SettingTable from 'BidGrid/components/dataTable/SettingTable';
import DataTable from "BidGrid/components/dataTable/DataTable";
import SkipBack from '../../BidGrid/assets/images/skip-back.png'
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import { toast } from 'react-toastify';
import { MeetingApi } from 'Services/bidgrid/tenderList/MeetingApi';
import { EditOutlined } from '@ant-design/icons';
import MeetingModels from 'BidGrid/components/Models/MeetingModels';
import { useSelector } from 'react-redux';
import { docurlchat } from 'utils/configurable';
import { Avatar } from '@mui/material';

import dayjs from 'dayjs';
import downloadFileIcon from "../assets/images/download.png";
import skipBack from '../assets/images/skip-back.png';



const { TextArea } = Input;
const showActions = true;
const meetingSchedule = true;
const { Option } = Select;

const initialState = {
  meeting_type: '',
  meeting_date: null,
  start_time: null,
  end_time: null,
  meeting_discerption: '',
  meeting_host: null,
  reminder_before_val: '',
  send_invitation: null,
  reminder_before_type: null,
  meeting_link: '',
  meeting_address: '',
  meeting_title: '',
  send_invitation_other: ''

}


const columnLabels = {
  meeting_type: { name: 'Meeting Type' },
  meeting_val: { name: 'Link / Address' },
  meeting_title: { name: 'Meeting Title' },
  created_by: { name: 'Created By' },
  hostname: { name: 'Meeting Host' },
  meeting_date: { name: 'Date' },
  meeting_status: { name: 'Status' },
  bg_meeting_mom: { name: 'Meeting Minutes' },

};


const MeetingSchedules = ({ id }) => {
  const [meetResp, setMeetResp] = useState([])
  const [openMeetDrawer, setOpenMeetDrawer] = useState(false)
  const [meetingList, setMeetingList] = useState([])
  const { userBidInfo } = useSelector((state) => state?.userDetails)
  const { socket, isConnected } = useSelector((state) => state.socket);
  const [addMeeting, setAddMeeting] = useState(initialState)
  const [employeeList, setEmployeeList] = useState([])
  const [filterByDate, setFilterByDate] = useState(null)
  const [openStatsDrawer, setOpenStatsDrawer] = useState(false);
  const [record, setRecord] = useState({})
  const [meeting, setMeeting] = useState(false)
  const [form] = Form.useForm();
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);
  const [spinner, setSpinner] = useState(true)
  const [deleteModal, setDeleteModal] = useState(false);


  const handleAddMeeting = (name, value) => {
    if (name === "meeting_type") {
      setAddMeeting(prevState => ({
        ...prevState,
        [name]: value,
        meeting_link: value === '2' ? '' : prevState.meeting_link,
        meeting_address: value === '1' ? '' : prevState.meeting_address
      }));
    }
    else {
      setAddMeeting({ ...addMeeting, [name]: value })
    }
  }


  // user list
  const getUserList = async () => {
    try {
      const response = await bidEmployeeList.getUserList()
      if (response?.data?.status === "1") {
        setEmployeeList(response?.data?.data)
      }
    } catch (error) {
      console.log(error)
    }
  }

  // list meeting shedule
  const getMeetinglist = async (initial) => {

    if (initial) {
      setSpinner(true)
    }
    const formData = new URLSearchParams();
    formData.append('project_id', id)
    try {
      const response = await MeetingApi?.MeetingList(formData)
      if (response?.data?.data?.length > 0) {
        const updatedArr = response?.data?.data?.map((item) => {
          let items = item
          if (items.meeting_type === '1') {
            items['meeting_type'] = 'Online'
          } else {
            items['meeting_type'] = 'Offline'
          }

          if (items?.meeting_status === "1") {
            items['meeting_status'] = 'Waiting'
          }
          else if (items?.meeting_status === "2") {
            items['meeting_status'] = 'Live'
          }
          else if (items?.meeting_status === "3") {
            items['meeting_status'] = 'Finished'
          } else {
            items['meeting_status'] = 'Cancelled'
          }
          return items
        })
        setSpinner(false)
        setMeetingList(updatedArr)
        setMeetResp(updatedArr)
      }
      else {
        setMeetingList([])
        setMeetResp([])
        setSpinner(false)
      }
    } catch (error) {
      console.log(error)
      setMeetingList([])
      setMeetResp([])
      setSpinner(false)
    }
  }

  // add meeting

  const handleAddMeetReset = () => {
    form.resetFields()
    setAddMeeting(initialState)
    // setOpenMeetDrawer(false)
  }

  const addHandler = async () => {
    setSpinner(true)
    const formData = new URLSearchParams();
    formData.append('project_id', id);
    formData.append('meeting_type', Number(addMeeting?.meeting_type));
    formData.append('meeting_date', dayjs(addMeeting?.meeting_date).format('YYYY-MM-DD'));
    formData.append('start_time', dayjs(addMeeting?.start_time, 'HH:mm:ss').format('HH:mm:ss') || '');
    formData.append('end_time', addMeeting?.end_time !== null ? dayjs(addMeeting?.end_time, 'HH:mm:ss').format('HH:mm:ss') : '');
    formData.append('meeting_discerption', addMeeting?.meeting_discerption);
    formData.append('meeting_host', addMeeting?.meeting_host);
    formData.append('reminder_before_val', Number(addMeeting?.reminder_before_val));
    formData.append('send_invitation', addMeeting?.send_invitation?.join(',') || '');
    formData.append('reminder_before_type', addMeeting?.reminder_before_type);
    formData.append('meeting_link', addMeeting?.meeting_link !== undefined ? addMeeting?.meeting_link : '');
    formData.append('meeting_address', addMeeting?.meeting_address || '');
    formData.append('meeting_title', addMeeting?.meeting_title);
    formData.append('send_invitation_other', addMeeting?.send_invitation_other || '');
    try {
      const response = await MeetingApi?.addMeeting(formData)
      if (response?.data?.status === '1') {
        const data = response?.data?.data
        let socketMeet = { meeting_id: data?.id, meeting_title: data?.meeting_title, tender_id: id, ping_users_info: addMeeting?.send_invitation?.join(',') }
        if (isConnected) {
          socket.emit('meeting_scheduled', socketMeet);
        }
        await getMeetinglist(false)
        handleCancel()
        notifySuccess("New Meeting Created Successfully.")
      } else {
        notify(response?.response?.data?.message)
        setSpinner(false)
      }
    } catch (error) {
      notify(error)
      setSpinner(false)
    }
  }

  const editHandler = async () => {
    setSpinner(true)
    const formData = new URLSearchParams();
    formData.append('project_id', id);
    formData.append('meeting_id', record?.id);
    formData.append('meeting_type', Number(addMeeting?.meeting_type));
    formData.append('meeting_date', dayjs(addMeeting?.meeting_date).format('YYYY-MM-DD'));
    formData.append('start_time', dayjs(addMeeting?.start_time, 'HH:mm:ss').format('HH:mm:ss'));
    formData.append('end_time', addMeeting?.end_time !== null ? dayjs(addMeeting?.end_time, 'HH:mm:ss').format('HH:mm:ss') : null);
    formData.append('meeting_discerption', addMeeting?.meeting_discerption);
    formData.append('meeting_host', addMeeting?.meeting_host);
    formData.append('reminder_before_val', Number(addMeeting?.reminder_before_val));
    formData.append('send_invitation', addMeeting?.send_invitation?.join(',') || '');
    formData.append('reminder_before_type', addMeeting?.reminder_before_type);
    formData.append('meeting_link', addMeeting?.meeting_link || '');
    formData.append('meeting_address', addMeeting?.meeting_address || '');
    formData.append('meeting_title', addMeeting?.meeting_title);
    formData.append('send_invitation_other', addMeeting?.send_invitation_other ? addMeeting?.send_invitation_other : '');

    try {
      const response = await MeetingApi?.updateMeeting(formData)
      if (response?.data?.status === '1') {
        const data = response?.data?.data
        let socketMeet = { meeting_id: data?.id, meeting_title: data?.meeting_title, tender_id: id, ping_users_info: addMeeting?.send_invitation?.join(',') }
        if (isConnected) {
          socket.emit('meeting_scheduled', socketMeet);
        }
        await getMeetinglist(false)
        handleCancel()
        notifySuccess('Meeting Updated Successfully.')
      } else {
        notify(response?.response?.data?.message)
        setSpinner(false)
      }
    } catch (error) {
      notify(error)
      setSpinner(false)
    }
  }


  // delete meeting api
  const deleteHandler = async () => {
    setSpinner(true)
    const formData = new URLSearchParams();
    formData.append('project_id', id)
    formData.append('meeting_id', record?.id)
    try {
      const response = await MeetingApi.deleteMeeting(formData)
      if (response?.data?.status == 1) {
        await getMeetinglist(false)
        setRecord(null)
        notifySuccess("Meeting Deleted")
      }
      else {
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      notify(error)
    }
  }

  // fetch Detail meeting api
  const handleEdit = async (records) => {
    const formData = new URLSearchParams();
    formData.append('project_id', id)
    formData.append('meeting_id', records?.id)
    try {
      const response = await MeetingApi.editMeeting(formData)
      if (response?.data?.status == 1) {
        const meetDetail = response?.data?.data
        let allUserList = meetDetail?.bg_meeting_invitations?.map((meet) => {
          return employeeList?.find(item => item.id === Number(meet?.send_invitation))
        })
        const meetingHost = employeeList?.find(item => item.id === Number(meetDetail?.meeting_host) && item.isactive == 1)?.hasOwnProperty('id') ? meetDetail?.meeting_host : null
        const filterInviteUser = allUserList?.length > 0 ? allUserList?.filter(val => val.isactive === 1)?.map(items => items?.id) : []
        const filterEmail = meetDetail?.bg_meeting_invitations?.filter(item => item?.send_invitation_other !== '')?.map(items => items?.send_invitation_other)
        let newObj = {
          ...meetDetail,
          meeting_host: meetingHost,
          send_invitation: filterInviteUser,
          send_invitation_other: filterEmail.join(' , '),
          meeting_date: dayjs(meetDetail?.meeting_date),
          start_time: dayjs(dayjs().format('YYYY-MM-DD') + ' ' + meetDetail?.start_time, 'YYYY-MM-DD HH:mm:ss'),
          end_time: dayjs(dayjs().format('YYYY-MM-DD') + ' ' + meetDetail?.end_time, 'YYYY-MM-DD HH:mm:ss'),
        }
        setRecord(meetDetail)
        setAddMeeting({
          ...addMeeting,
          ...newObj
        })
        form.setFieldsValue(newObj);
        setOpenMeetDrawer(true)
      }
    } catch (error) {
      console.log(error, 'Api Error')
    }
  }

  const originalDateTime = (project) => {
    const originalDateTimes = project?.meeting_date + " " + project?.start_time;
    const dateObject = new Date(originalDateTimes);
    const formattedDate = dateObject.getDate(); // Get the day of the month (10)
    const formattedMonth = dateObject.toLocaleString('default', { month: 'long' }); // Get the month name (June)
    const formattedYear = dateObject.getFullYear(); // Get the year (2024)
    let formattedTime = dateObject.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true });
    return `${formattedDate} ${formattedMonth} ${formattedYear} ${formattedTime}`

  }

  const tableData = useMemo(() => {
    const flattenedData = meetingList?.map(project => {
      const hostname = employeeList?.find(item => item?.id == project?.hostname?.id)
      const created_by = employeeList?.find(item => item?.id == project?.created_by)


      return {
        id: project?.id,
        meeting_type: project?.meeting_type,
        meeting_val: project?.meeting_type === "Online" ? project?.meeting_link : project?.meeting_address,
        meeting_title: project?.meeting_title,
        created_by: <div className="empFlex">
          <Avatar
            sizes=''
            sx={{ width: 32, height: 32 }}
            src={docurlchat + created_by?.profileimg_path + '/' + created_by?.profileimg}
          >
            {created_by?.userfullname.slice(0, 1)}
          </Avatar>
          <span>{created_by?.userfullname}</span>
        </div>,
        hostname:
          <div className="empFlex">
            <Avatar
              sizes=''
              sx={{ width: 32, height: 32 }}
              src={docurlchat + hostname?.profileimg_path + '/' + hostname?.profileimg}
            >
              {hostname?.userfullname.slice(0, 1)}
            </Avatar>
            <span>{project?.hostname?.userfullname}</span>
          </div>,
        meeting_date: originalDateTime(project),
        meeting_status: project?.meeting_status,
        bg_meeting_mom: project?.bg_meeting_mom?.hasOwnProperty('id') ? <a onClick={() => { setRecord(project?.bg_meeting_mom); setOpenStatsDrawer(true) }}>View MOM</a> : null,
        // created_by: project?.created_by
      }

    });;
    return flattenedData
  }, [meetingList]);


  const handleDateChange = (e) => {
    if (e) {
      const formattedDate = dayjs(e).format('YYYY-MM-DD');
      setFilterByDate(e);
      // Filter the projects based on the selected date
      const filteredProjects = meetResp?.filter(item => dayjs(item?.meeting_date).format('YYYY-MM-DD') === formattedDate);
      setMeetingList(filteredProjects)
    } else {
      setFilterByDate(null);

      setMeetingList(meetResp)

    }
  }


  const handleKeyPressSelectedItem = (e) => {
    // const alphabeticChars = /[a-zA-Z]/;
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (!forbiddenChars.test(e.key)) {
      e.preventDefault();
    }
    else if (e.key === 'Enter') {
      e.preventDefault();
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };

  const handleKeyPress = (e) => {
    const alphabeticChars = /[a-zA-Z]/;
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key) && alphabeticChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      //  handleProjectInfo()
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };

  const handleContainOnlyText = (e) => {
    // const alphabeticChars = /[a-zA-Z]/;
    const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (forbiddenChars.test(e.key)) {
      e.preventDefault();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      //  handleProjectInfo()
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };


  useEffect(() => {
    getMeetinglist(true)
  }, [])

  useEffect(() => {
    getUserList()
  }, [])


  const onCloseDrawer = () => {
    setOpenStatsDrawer(false);
  };


  const disabledTime = (selected, meetingDate, start_time) => {
    if (!meetingDate || !dayjs(meetingDate).isSame(dayjs(), 'day')) {
      // No restrictions if the date is not the current date
      return {};
    }

    const currentHour = dayjs().hour();
    const currentMinute = dayjs().minute();
    const currentSecond = dayjs().second();

    if (
      selected &&
      selected.hour() === currentHour &&
      selected.minute() === currentMinute
    ) {
      // Disable hours and minutes before the current time
      return {
        disabledHours: () => Array.from({ length: currentHour }).map((_, i) => i),
        disabledMinutes: () =>
          Array.from({ length: currentMinute }).map((_, i) => i),
        disabledSeconds: () =>
          Array.from({ length: currentSecond }).map((_, i) => i),
      };
    }

    if (
      start_time &&
      selected &&
      selected.isSame(dayjs(meetingDate).startOf('day'), 'day') &&
      selected.isBefore(dayjs(start_time), 'hour') ||
      (selected.isSame(dayjs(start_time), 'hour') &&
        selected.isBefore(dayjs(start_time), 'minute'))
    ) {
      // Disable hours and minutes before the selected Start Time
      return {
        disabledHours: () => Array.from({ length: dayjs(start_time).hour() }).map((_, i) => i),
        disabledMinutes: () => Array.from({ length: dayjs(start_time).minute() }).map((_, i) => i),
      };
    }

    // No restrictions for other cases
    return {};
  };


  const documentBlobReq = async (doc_name, apiUrl) => {
    const fullUrl = window.location.href;
    const urlObject = new URL(fullUrl);
    const protocol = urlObject.protocol;
    const hostname = urlObject.host;
    const domain = `${protocol}//${hostname}`;
    const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
    const response = await fetch(proxyUrl)
    const blobData = await response?.blob()
    const fileURL = window.URL.createObjectURL(blobData);
    let alink = document.createElement("a");
    alink.href = fileURL;
    alink.download = doc_name;
    alink.click();
  }
  const documentFileDownload = (item) => {
    const apiUrl = `${docurlchat}${item?.file_path}/${item?.file_name}`;
    documentBlobReq(item?.file_name, apiUrl)
  }

  // filter user
  let assignedUserIds = addMeeting?.send_invitation?.map(val => val);


  const handleCancel = () => {
    setOpenMeetDrawer(false);
    setAddMeeting(initialState);
    setRecord(null)
    form.resetFields();
  }


  const handleDelete = (record) => {
    setRecord(record)
    setDeleteModal(true)
  }


  const actionBtns = {
    title: 'Actions',
    key: 'actions',
    render: (record) => {
      return (
        <>
          {record?.created_by == userBidInfo?.id &&
            <Dropdown
              placement='bottomRight'
              overlay={
                <Menu className="bd_tableAction">
                  <Menu.Item key="" className='bd_view_btn'
                    onClick={() => { setRecord(record); setMeeting(true) }}
                  >
                    <AccessTimeIcon style={{ fontSize: "22" }} />
                    Min .of meeting
                  </Menu.Item>
                  <Menu.Item key="edit" onClick={() => handleEdit(record)} className='bd_view_btn'>
                    <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <g clip-path="url(#clip0_221_1663)">
                        <path d="M8.25 3H3C2.60218 3 2.22064 3.15804 1.93934 3.43934C1.65804 3.72064 1.5 4.10218 1.5 4.5V15C1.5 15.3978 1.65804 15.7794 1.93934 16.0607C2.22064 16.342 2.60218 16.5 3 16.5H13.5C13.8978 16.5 14.2794 16.342 14.5607 16.0607C14.842 15.7794 15 15.3978 15 15V9.75" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M13.875 1.87505C14.1734 1.57668 14.578 1.40906 15 1.40906C15.422 1.40906 15.8266 1.57668 16.125 1.87505C16.4234 2.17342 16.591 2.57809 16.591 3.00005C16.591 3.422 16.4234 3.82668 16.125 4.12505L9 11.25L6 12L6.75 9.00005L13.875 1.87505Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                      </g>
                      <defs>
                        <clipPath id="clip0_221_1663">
                          <rect width="18" height="18" fill="white" />
                        </clipPath>
                      </defs>
                    </svg>
                    Edit
                  </Menu.Item>
                  <Menu.Item key="delete" onClick={() => handleDelete(record)} className='bd_delete_btn'>
                    <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M2.25 4.5H3.75H15.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72064 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M7.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M10.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    Delete
                  </Menu.Item>
                </Menu>

              }
            >
              <a onClick={(e) => e.preventDefault()}>
                <More theme="outline" size="25" fill="#95a6b6" strokeWidth={3} />
              </a>
            </Dropdown >
          }
        </>
      )
    },
    width: 120,
  }


  return (
    <>
      <div className="bd_emplist_main meetingSchedule_wraper">
        <div className="bd_empHeader">
          <div className="bd_emplist_main_header">Meeting Schedules</div>
          <div className="buttonFlex">
            <Form.Item rules={[{ required: true, message: "Last Name is Required" }]} onKeyPress={handleKeyPressSelectedItem}>
              <DatePicker placeholder='Filter by '
                onChange={handleDateChange}
                value={filterByDate}
              />
            </Form.Item>
            <button className="BG_mainButton" onClick={() => { setOpenMeetDrawer(true) }}>
              Add Meeting
            </button>
          </div>
        </div>

        <SettingTable
          title='Meeting Detail'
          handleDeleteApi={deleteHandler}
          columnLabels={columnLabels}
          dataSource={tableData}
          showActions={true}
          spinner={spinner}
          record={record}
          deleteModal={deleteModal}
          setDeleteModal={setDeleteModal}
          actionBtns={actionBtns}
        />
      </div>

      <Drawer closeIcon={<img src={SkipBack} alt='' />} title={record?.id ? 'Edit Meeting' : "Add Meeting"} placement="right"
        onClose={handleCancel} open={openMeetDrawer} width={1300}>
        <Form
          form={form}
          name="control-hooks"
          layout="vertical"
          onFinish={() => { record?.id ? editHandler() : addHandler() }}
        >
          <Row gutter={20}>

            <Col sm={6} >
              <Form.Item label="Meeting Type:" name="meeting_type" rules={[{ required: true, message: "Please select meeting type" }]}>
                <Radio.Group onChange={(e) => handleAddMeeting('meeting_type', e?.target?.value)} name='meeting_type' value={addMeeting?.meeting_type}>
                  <Radio value='1'>Online</Radio>
                  <Radio value='2'>Offline</Radio>
                </Radio.Group>
              </Form.Item>
            </Col>

            <Col sm={6}>
              <Form.Item
                name='meeting_date'
                rules={[{ required: true, message: "Please select meeting date" }]}
                label='Date:'
              >
                <DatePicker placeholder='Select Date'
                  onChange={(e) => handleAddMeeting('meeting_date', e)}
                  // name='meeting_date'
                  value={addMeeting?.meeting_date !== null ? dayjs(addMeeting?.meeting_date) : null}
                  disabledDate={(current) => current && current < dayjs().startOf('day')}

                />
              </Form.Item>
            </Col>

            <Col sm={6} >
              <Form.Item name='start_time'
                rules={[{ required: true, message: "Please add meeting start time" }]}
                label='Start Time:'>
                <TimePicker
                  onChange={(e) => handleAddMeeting('start_time', e)}
                  name='start_time'
                  value={addMeeting?.start_time !== null ? dayjs(addMeeting?.start_time, 'HH:mm:ss') : null}
                  disabledTime={(selected) => disabledTime(selected, addMeeting?.meeting_date, addMeeting?.start_time)}
                />

              </Form.Item>

            </Col>

            <Col sm={6} >
              <Form.Item name='end_time'
                label="End Time:" >
                <TimePicker
                  onChange={(e) => handleAddMeeting('end_time', e)}
                  name='end_time'
                  value={addMeeting?.end_time !== null ? dayjs(addMeeting?.end_time, 'HH:mm:ss') : null}
                  disabledTime={(selected) => disabledTime(selected, addMeeting?.meeting_date, addMeeting?.start_time)}
                />

              </Form.Item>
            </Col>
            {addMeeting?.meeting_type === '1' && (
              <>
                <Col sm={12} >
                  <Form.Item label="Link:" name="meeting_link" rules={[{ required: true, message: "Please enter link" }]} onKeyPress={handleKeyPress}>
                    <Input
                      type='text'
                      placeholder='Enter here'
                      onChange={(e) => handleAddMeeting('meeting_link', e?.target?.value?.trim())}
                      // name='meeting_link'
                      value={addMeeting?.meeting_link}
                    />
                  </Form.Item>
                </Col>
              </>
            )}

            {addMeeting?.meeting_type === '2' && (
              <>
                <Col sm={12} >
                  <Form.Item label="Address:" name="meeting_address" rules={[{ required: true, message: "Please enter address" }]} onKeyPress={handleKeyPress}>
                    <Input
                      type='text'
                      placeholder='Enter here'
                      onChange={(e) => handleAddMeeting('meeting_address', e?.target?.value?.trimStart())}
                      // name='meeting_address'
                      value={addMeeting?.meeting_address}
                    />
                  </Form.Item>
                </Col>
              </>
            )}

            <Col sm={12} >
              <Form.Item label="Meeting Title:" name="meeting_title" rules={[{ required: true, message: "please enter a Meeting Title" }]} onKeyPress={handleKeyPress}>
                <Input
                  type='text'
                  placeholder='Enter here'
                  onChange={(e) => handleAddMeeting('meeting_title', e?.target?.value?.trimStart())}
                  name='meeting_title'
                  value={addMeeting?.meeting_title}
                />

              </Form.Item>
            </Col>

            <Col sm={12} >
              <Form.Item label="Description:" name="meeting_discerption" rules={[{ required: true, message: "Please enter description" }]} onKeyPress={handleKeyPress}>
                <TextArea placeholder="Enter here"
                  onChange={(e) => handleAddMeeting('meeting_discerption', e?.target?.value?.trimStart())}
                  value={addMeeting?.meeting_discerption} />

              </Form.Item>
            </Col>


            <Col sm={8} >
              <Form.Item label="Meeting Host:" name="meeting_host" rules={[{ required: true, message: "Please select meeting host" }]} onKeyPress={handleContainOnlyText}>
                <Select
                  allowClear
                  showSearch
                  optionFilterProp="children"
                  onChange={(e) => handleAddMeeting('meeting_host', e)}
                  placeholder="Select Host"
                  value={addMeeting?.meeting_host}
                  suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                  filterOption={(input, option) =>
                    option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {

                    employeeList?.filter(user => !assignedUserIds?.includes(user?.id) && user?.isactive !== 2)?.map((item, index) => {
                      return (
                        <>
                          <Option key={index} value={item?.id}
                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}>{item?.userfullname}</Option>
                        </>
                      )
                    })

                  }
                </Select>
              </Form.Item>
            </Col>
            <Col sm={8} >
              <Form.Item label="Send Invitation:" onKeyPress={handleContainOnlyText}>
                <Select
                  showSearch
                  mode="multiple"
                  optionFilterProp="children"
                  onChange={(e) => handleAddMeeting('send_invitation', e)}
                  // name='send_invitation'
                  value={addMeeting?.send_invitation}
                  suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                  filterOption={(input, option) =>
                    option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  placeholder='Select User'
                >
                  {employeeList?.filter(item => item?.id !== addMeeting?.meeting_host && item?.isactive !== 2)?.map((item, index) => {
                    return (
                      <>
                        <Option key={index} value={item?.id}
                          suffixIcon={<Down theme="outline" size="18" fill="#747474" />}>{item?.userfullname}</Option>
                      </>
                    )
                  })}
                </Select>
              </Form.Item>
            </Col>
            <Col sm={8} >
              <Form.Item label="Send Invitation (Add Email):"
                name="send_invitation_other"
                onKeyPress={handleKeyPress}
              >
                <Input
                  placeholder="Enter here"
                  onChange={(e) => handleAddMeeting('send_invitation_other', e?.target?.value?.trimStart())}
                  value={addMeeting?.send_invitation_other}
                />
              </Form.Item>
            </Col>
            <>

              <Col sm={8}>
                <Form.Item label="Reminder Type:" name="reminder_before_type" rules={[{ required: true, message: "Please select reminder type" }]} onKeyPress={handleContainOnlyText}>
                  <Select
                    allowClear
                    placeholder="Enter here"
                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                    showSearch
                    optionFilterProp="label"
                    options={[{ value: 'hours', label: 'Hours' }, { value: 'minutes', label: 'Minutes' }]}
                    onChange={(e) => handleAddMeeting('reminder_before_type', e)}
                    name='reminder_before_type'
                    value={addMeeting?.reminder_before_type}
                  />
                </Form.Item>
              </Col>
              <Col sm={8} >
                <Form.Item label="Reminder Before:" name="reminder_before_val" rules={[{ required: true, message: "Please enter reminder before" }]} onKeyPress={handleKeyPressSelectedItem}>
                  <Input
                    type='text'
                    placeholder='Enter here'
                    onChange={(e) => handleAddMeeting('reminder_before_val', e?.target?.value?.replace(/[^0-9]/g, ''))}
                    name='reminder_before_val'
                    value={addMeeting?.reminder_before_val}
                  />

                </Form.Item>
              </Col>
            </>

          </Row>

          <div className="bd_drawerFoot">
            <Button disabled={spinner} onClick={() => { record?.id ? handleCancel() : handleAddMeetReset() }} key="back" className='BG_ghostButton'>
              {record?.id ? "Cancel" : "Reset"}
            </Button>
            <Button className='BG_mainButton' type="primary" htmlType="submit" loading={spinner} disabled={spinner} >{record?.id ? "Update" : "Submit"} </Button>
          </div>
        </Form>

      </Drawer>
      <Drawer title="Minutes of Meeting" className="mom_details" closeIcon={<img src={skipBack} alt='' />} onClose={onCloseDrawer} open={openStatsDrawer} width={750}
        extra={
          <div className="d-flex">
            <button onClick={() => { onCloseDrawer(); setMeeting(true); }}><EditOutlined /></button>
          </div>
        }>
        <div className="mom_card">
          <div className="disc_text">
            <p>{record?.description?.replace(/<[^>]*>/g, '')}</p>
          </div>

          <a onClick={() => documentFileDownload()} href="#" className="downloadFile">
            <span><img src={downloadFileIcon} /></span>
            Download File
          </a>
        </div>
      </Drawer>
      <MeetingModels documentFileDownload={documentFileDownload} modalData={record} setRecord={setRecord} meeting={meeting} setmeeting={setMeeting} onClose={() => setMeeting(false)} getMeetinglist={getMeetinglist} setSpinner={setSpinner} spinner={spinner} />
    </>
  )
}

export default MeetingSchedules
