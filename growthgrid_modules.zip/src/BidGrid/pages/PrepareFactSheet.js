import React, { useState } from 'react'
import ".././assets/css/styles/preparefact.scss"
import { Progress, Avatar, Tooltip } from 'antd';
import Taskboard from 'BidGrid/components/Taskboard/Taskboard';
import { AntDesignOutlined, UserOutlined } from '@ant-design/icons';
import { useLocation } from 'react-router';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import { Button, Input, Select, DatePicker, Drawer, Form, Row, Col, TimePicker, Flex } from 'antd';
import dayjs from 'dayjs';
const { TextArea } = Input;


function PrepareFactSheet() {
    const [active, setActive] = useState(1)

    const location = useLocation();

    const val = location?.pathname;
    const str = val.replace('/', '')





    const handleProjectClick = (step) => {
        setActive(step);

    };

    const handleNext = () => {
        if (active < 5) {
            setActive(active + 1);
        }
    };

    const handlePrevious = () => {
        if (active > 1) {
            setActive(active - 1);
        }
    };
    return (
        <>
            <Breadcrumb data={str} />
            <div className="bd_task__wrapper">
                <div className="bd_task_project_left_sheet ">
                    <div className='bd_project_name' >
                        <h5>Prepare Fact Sheet</h5>
                        <p>Fill up required details</p>
                    </div>


                    {/* <div className={`bd_project_list active ${active === 2 ? 'active' : ''}`} onClick={() => handleProjectClick(2)}> */}

                    <div className={`bd_project_list ${active === 1 ? 'active' : ''}`} onClick={() => handleProjectClick(1)}>
                        <h2>Projact Information Note (Pin)</h2>
                        <p>Step 1 </p>
                    </div>
                    {/* </div> */}

                    <div className={`bd_project_list ${active === 2 ? 'active' : ''}`} onClick={() => handleProjectClick(2)}>
                        <h2>Projact Information Note (Pin)</h2>
                        <p>Step 2 </p>
                    </div>
                    <div className={`bd_project_list ${active === 3 ? 'active' : ''}`} onClick={() => handleProjectClick(3)}>
                        <h2>Projact Information Note (Pin)</h2>
                        <p>Step 3 </p>
                    </div>
                    <div className={`bd_project_list ${active === 4 ? 'active' : ''}`} onClick={() => handleProjectClick(4)}>
                        <h2>Projact Information Note (Pin)</h2>
                        <p>Step 4 </p>
                    </div>
                    <div className={`bd_project_list ${active === 5 ? 'active' : ''}`} onClick={() => handleProjectClick(5)}>
                        <h2>Projact Information Note (Pin)</h2>
                        <p>Step 5 </p>
                    </div>
                </div>

                <div className="bd-progress-head_sheet">
                    <h1>Step 1. Projact Information Note (Pin)</h1>
                    <Row gutter={20}>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Type of submission :"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Lead/RFP Number"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Input />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="No.of Copies"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Name of Client"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>


                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Contry"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Contact Person Name/Department"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Input />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Funding Agency"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Date & Time Pre-bid Confernece"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <DatePicker />
                                </Form.Item>
                            </Form>
                        </Col>


                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Date of Bid Submission"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Date input!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Tender Document / Processing Fee"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Input />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="EMD/Bid Security"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Consultancy Cost"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <DatePicker />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Fee Type"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Date input!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Expected Commencement Date"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Input />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Bid Evaluaction Method /Selection Criteria"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Competition"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <TextArea rows={4} />
                                </Form.Item>
                            </Form>
                        </Col>

                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Do we have Requisite Experince,Certificates etc.? if No,Partnership Required ?"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Date input!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="jV patner allowed or not"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Input />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Partner JV/Associates,information"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <TextArea rows={4} />

                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Currency of Payment & restriction on consversion of local currency to u$$ /INR"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />

                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Mobillization Advance,if any"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Date input!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Escalation if permitted,specify the details"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Input />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Evaluction Criteria"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <TextArea rows={4} />

                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Staff Months"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />

                                </Form.Item>
                            </Form>
                        </Col>

                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Duration of Project (Months)"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Date input!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="SWOT Analysis"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <TextArea rows={4} />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Risk Assessment"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <Select />

                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Objective/ Scope of Work "
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <TextArea rows={4} />

                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Facilities for consultant"
                                    name="username"

                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <TextArea rows={4} />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Contract doucment"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <TextArea rows={4} />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Payment to consultant(Trems)"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <TextArea rows={4} />
                                </Form.Item>
                            </Form>
                        </Col>
                        <Col sm={6}>
                            <Form>
                                <Form.Item
                                    label="Bidding/ Pricing Strategy"
                                    name="username"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your username!',
                                        },
                                    ]}
                                    labelCol={{ span: 24 }}
                                    wrapperCol={{ span: 24 }}
                                >
                                    <TextArea rows={4} />
                                </Form.Item>
                            </Form>
                        </Col>
                    </Row>
                    <div className='bd_model_button_sheet'>
                        <Button key="back" className='BG_ghostButton' onClick={handlePrevious}>
                            Previous
                        </Button>
                        <button key="submit" className='BG_mainButton' onClick={handleNext}>
                            Save & Next
                        </button>
                    </div>
                </div>

            </div>



        </>
    )
}

export default PrepareFactSheet
