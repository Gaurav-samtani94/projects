// @ts-nocheck
import React from 'react'

import CustomProfile from 'BidGrid/components/Profile/CustomProfile';

const UpdateProfile = () => {

    return (
        <>
            <CustomProfile isPersonal={false} />
        </>
    )
}

export default UpdateProfile