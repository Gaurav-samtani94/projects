// @ts-nocheck
import React, { useEffect } from 'react';
import { Collapse } from 'antd';
import { useLocation } from 'react-router';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import 'react-loading-skeleton/dist/skeleton.css'
import NewTrashCard from './NewTrashCard';
import { trashFilterAction } from 'Redux/actions/bidgrid/trashFilterAction';
const { Panel } = Collapse;

const items = [
    {
        key: '1',
        label: (
            <div className="tabText_block">
                <span>Trash</span>
            </div>
        ),
    },
]

const TrashFile = () => {
    const { trashFilterValues } = useSelector(state => state.trashFilter);

    const location = useLocation();
    const val = location?.pathname;
    const str = val.replace('/', '');
    const dispatch = useDispatch();

    useEffect(() => {
        const TenderBody = {
            limit: trashFilterValues?.limit ? trashFilterValues?.limit : 5,
            page_number: trashFilterValues?.page_number ? trashFilterValues?.page_number : 1,
        }
        dispatch(trashFilterAction.trashFilterUpdateIndividualKeys(TenderBody))
    }, [])

    return (
        <>
            <div className='bd_new_tender'>
                <div className="d-flex">
                    {/* <div className='bd_new_tender_cont'>
                        <div className='bd_new_tender_sidebar'>
                            <Collapse accordion activeKey="1" items={items}></Collapse>
                        </div>
                    </div> */}
                    <NewTrashCard />
                </div>

            </div>
        </>
    )
}

export default TrashFile;