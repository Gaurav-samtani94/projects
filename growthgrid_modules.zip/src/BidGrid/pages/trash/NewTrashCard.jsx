// @ts-nocheck
import React, { useCallback, useRef, useState, useEffect } from 'react';
import { Down, SaveOne, Add } from '@icon-park/react';
import { Drawer, Form, Select, Input, Checkbox, Tooltip } from 'antd';
import { DownloadOutlined, SearchOutlined } from '@ant-design/icons';
import ExportDatatable from 'BidGrid/components/dataTable/ExportDatatable';
import FilterImage from '../../assets/images/icons/filter 1.png';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import spinGif from '../../assets/images/spin.gif';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import * as XLSX from 'xlsx';
import { useDraggable } from "react-use-draggable-scroll";
import dayjs from 'dayjs';
import CloseIcon from '@mui/icons-material/Close';
import { useSelector, useDispatch } from 'react-redux';
import { toast } from 'react-toastify';
import { TrashServices } from 'Services/bidgrid/trash/TrashServices';
import TenderDetailsCard from 'BidGrid/components/TendercardComponents/TenderDetailsCard';
import { trashFilterAction } from 'Redux/actions/bidgrid/trashFilterAction';
import Bd_basicFilter from 'BidGrid/components/Drawer/Bd_basicFilter';
import GenerateChips from 'BidGrid/components/GenerateChips/GenerateChips';
import { DropdownValuesServices } from 'Services/common/dropdown/dropdownValues';
import Bd_advanceFilter from 'BidGrid/components/Drawer/Bd_advanceFilter';
import AddTemplateModal from 'BidGrid/components/Models/AddTemplateModal';
import FilterChipsTemplateDrawer from 'BidGrid/components/Drawer/FilterChipsTemplateDrawer';
import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
const { Search } = Input;

const columnLabels = {
    gg_tenderID: { name: 'GG Tender ID', required: true, width: 400 },
    tender_name: { name: 'Tender Name', required: true, width: 400 },
    tender_emd_amnt_val: { name: 'Tender amount value', required: true, width: 400 },
    submission_start_date: { name: 'Start Date', required: true, width: 400 },
    submission_end_date: { name: 'End Date', required: true, width: 400 },

}
const initialModalState = {
    bdBasicFilter: { visible: false, data: null },
    createTemplate: { visible: false, data: null },
    saveTemplate: { visible: false, data: null },
    bdAdvanceFilter: { visible: false, data: null },
    generateNum: { visible: false, data: null },
    keyClientAssign: { visible: false, data: null },
    consortiumCompAssign: { visible: false, data: null },
    bidManager: { visible: false, data: null }
}
const NewTrashCard = () => {

    const { trashFilterValues, trashFilterChips, isUpdate } = useSelector(state => state.trashFilter);
    const dispatch = useDispatch()
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const ref = useRef();
    const { events } = useDraggable(ref);
    const [skeleton, setSkeleton] = useState(true);
    const [checkedAll, setCheckedAll] = useState(false);
    const [tenderSearch, setTenderSearch] = useState('')
    const [checkedTender, setCheckedTender] = useState([]);
    const [getTrashTender, setTrashTender] = useState([]);
    const [tenderCount, setTenderCount] = useState()
    const [dropdownSpinner, setDropdownSpinner] = useState(false);
    const [dropdownList, setDropdownList] = useState([]);
    const [inActionBtnList, setInActionBtnList] = useState([]);
    const [dropdownSpinnerForBulkPopUP, setDropdownSpinnerForBulkPopUP] = useState(false);
    const [modals, setModals] = useState(initialModalState);
    const [bdFilter, setBdFilter] = useState('');
    const [stateVal, setStateVal] = useState([])
    const [accdChipData, setAccdChipData] = useState([])
    const [applyTemp, setApplyTemp] = useState(false);
    const [collapseActiveKeyTemp, setCollapseActiveKeyTemp] = useState();
    const [updateFilter, setUpdateFilter] = useState()
    const [applyFilter, setApplyFilter] = useState()
    const [updateFilterData, setUpdateFilterData] = useState(false)

    const defaultValues = 'Select'
    const [statusChange, setStatusChange] = useState(defaultValues);
    const trashSingleDropDownFun = async () => {
        try {
            const response = await TrashServices?.getTrashDropDownApi()
            if (response?.data?.status == 1) {
                setDropdownList(response?.data?.data)
            }

        } catch (error) {
            console.log(error)
        }
    }

    const trashInactionBtnFun = async () => {
        try {
            const response = await TrashServices?.getInActionBtnApi()
            if (response?.data?.status == 1) {
                setInActionBtnList(response?.data?.data)
            }

        } catch (error) {
            console.log(error)
        }

    }

    const handleSubmitTender = async (val, itemID, setStatusChange, item) => {
        let scopeName;
        scopeName = dropdownList?.find(item => item.id == val)?.cycle_name;
        setDropdownSpinner(prevState => ({
            ...prevState,
            [itemID]: true
        }));
        const formData = new URLSearchParams();
        formData.append("tender_id", itemID);
        formData.append("to_cycle_id", Number(val));
        try {
            const response = await TrashServices.moveTenderFromTrash(formData)
            if (response?.data?.status === '1') {
                getAllTrashTenders()
                notifySuccess(`Tender moved into ${scopeName ? scopeName : 'next'} stage`)
                setDropdownSpinner(prevState => ({
                    ...prevState,
                    [itemID]: false
                }));
            }
        } catch (error) {
            console.log(error)
            setDropdownSpinner(prevState => ({
                ...prevState,
                [itemID]: false
            }));
        }
    }

    const getStateDrpValue = async () => {
        try {
            if (trashFilterValues?.country_id) {
                const PayloadData = new FormData()
                PayloadData.append('country_id', trashFilterValues.country_id)
                const response = await DropdownValuesServices.getStateDataByCountryId(PayloadData)
                if (response?.data?.status === 1) {
                    setStateVal(response?.data?.data?.filter(val => val?.state_name !== 'NA'))
                } else {
                    setStateVal([])
                }
            } else {
                setStateVal([])
            }
        } catch {
            console.log("error")
            setStateVal([])
        }
    }

    const handleShowChipInAcc = async (val) => {
        const formData = new URLSearchParams();
        formData.append("template_type", '3');
        formData.append("template_name", val);
        try {
            const response = await tenderCycle.bdShowChipstemp(formData)
            if (response?.data?.status === '1') {
                let resData = response?.data?.data
                let newArr = []
                resData?.map((obj) => {
                    const objVal = {
                        key: obj["filter_field_name"],
                        value: obj.filter_field_name === "from_date" || obj?.filter_field_name === "to_date" ? obj?.["filter_field_value"] : obj?.["filter_field_value"]
                    }
                    newArr.push(objVal)
                })
                convertArrToObj(response?.data?.data)
                setAccdChipData(newArr)
                console.log(newArr, "newArr")
            }
        } catch (error) {
            console.log(error)
        }
    }

    const handleAccordionChange = (key) => {
        setCollapseActiveKeyTemp(key[key.length - 1])
        handleShowChipInAcc(key[key.length - 1])
    };

    const handleRadioChange = (e, key) => {
        setCollapseActiveKeyTemp(key)
        handleShowChipInAcc(key)
    };

    const getAllTrashTenders = async () => {
        setSkeleton(true)
        const formData = new URLSearchParams();
        formData.append('sector_id', trashFilterValues.sector_id ? trashFilterValues.sector_id : "");
        formData.append("tender_keyword", trashFilterValues?.tender_keyword ? trashFilterValues?.tender_keyword : "")
        formData.append("country_id", trashFilterValues?.country_id ? trashFilterValues?.country_id : "")
        formData.append("funding_id", trashFilterValues?.funding_id ? trashFilterValues?.funding_id : "")
        formData.append("from_date", trashFilterValues?.from_date ? trashFilterValues?.from_date : "")
        formData.append("to_date", trashFilterValues?.to_date ? trashFilterValues?.to_date : "")
        formData.append("published_date", trashFilterValues?.published_date ? trashFilterValues?.published_date : "")
        formData.append("close_exp_date", trashFilterValues?.close_exp_date ? trashFilterValues?.close_exp_date : "")
        formData.append("estm_value", trashFilterValues?.estm_value ? trashFilterValues?.estm_value : "")
        formData.append("estm_value_emd", trashFilterValues?.estm_value_emd ? trashFilterValues?.estm_value_emd : "")
        formData.append('amnt_custrange_operator', trashFilterValues?.amnt_custrange_operator ? trashFilterValues?.amnt_custrange_operator : "")
        formData.append('amnt_custrange_amount', trashFilterValues?.amnt_custrange_amount ? trashFilterValues?.amnt_custrange_amount : "")
        formData.append('custrange_denomination', trashFilterValues?.custrange_denomination ? trashFilterValues?.custrange_denomination : "")
        formData.append('amnt_custrange_operator_emd', trashFilterValues?.amnt_custrange_operator_emd ? trashFilterValues?.amnt_custrange_operator_emd : "")
        formData.append('amnt_custrange_amount_emd', trashFilterValues?.amnt_custrange_amount_emd ? trashFilterValues?.amnt_custrange_amount_emd : "")
        formData.append('custrange_denomination_emd', trashFilterValues?.custrange_denomination_emd ? trashFilterValues?.custrange_denomination_emd : "")
        formData.append("state_id", trashFilterValues?.state_id ? trashFilterValues?.state_id : "")
        formData.append("client_id", trashFilterValues?.client_id ? trashFilterValues?.client_id : "")
        formData.append("currency_id", trashFilterValues?.currency_id ? trashFilterValues?.currency_id : "")
        formData.append("pubdate_cust_from_date", trashFilterValues?.pubdate_cust_from_date ? trashFilterValues?.pubdate_cust_from_date : "")
        formData.append("pubdate_cust_to_date", trashFilterValues?.pubdate_cust_to_date ? trashFilterValues?.pubdate_cust_to_date : "")
        formData.append("expdate_cust_from_date", trashFilterValues?.expdate_cust_from_date ? trashFilterValues?.expdate_cust_from_date : "")
        formData.append("expdate_cust_to_date", trashFilterValues?.expdate_cust_to_date ? trashFilterValues?.expdate_cust_to_date : "")
        formData.append("tender_status", trashFilterValues?.tender_status ? trashFilterValues?.tender_status : "")
        formData.append('limit', trashFilterValues?.limit ? parseInt(trashFilterValues?.limit) : 5)
        formData.append('page_number', trashFilterValues?.page_number ? trashFilterValues?.page_number : "1")
        try {
            let result = await TrashServices?.getTrashListApi(formData);
            if (checkedAll) {
                const postIds = result?.data?.data?.map((item) => {
                    return item.id;
                })
                setCheckedAll(true);
                let filteredArray1 = postIds.filter(element => !checkedTender.includes(element));
                setCheckedTender([...checkedTender, ...filteredArray1]);
            }
            dispatch(trashFilterAction.trashFilterResetisUpdate())
            setSkeleton(false)
            setTrashTender(result?.data?.data);
            setStatusChange(defaultValues)
            setTenderCount(result?.data)
        } catch (error) {
            setTrashTender([]);
            setSkeleton(false)
        }
    }

    const handleUpdateFilter = () => {
        setUpdateFilterData(true)
        setModals(prevModals => ({
            ...prevModals,
            saveTemplate: { visible: false, data: null },
        }));
        setModals(prevModals => ({
            ...prevModals,
            bdBasicFilter: { visible: true, data: null },
        }));
    }

    const showChipDrawer = () => {
        setCollapseActiveKeyTemp()
        setModals(prevModals => ({
            ...prevModals,
            saveTemplate: { visible: true, data: null },
        }));
    }

    const convertArrToObj = (val) => {
        let outputObject = {};
        val?.forEach(item => {
            outputObject[item.filter_field_name] = item.filter_field_value;
        });
        setApplyFilter((old) => ({
            ...trashFilterValues,
            ...outputObject,
        })
        )
        setUpdateFilter(outputObject)
    }

    const showDrawer = () => {
        setUpdateFilter()
        setUpdateFilterData(false)
        setModals(prevModals => ({
            ...prevModals,
            bdBasicFilter: { visible: true, data: null },
            bdAdvanceFilter: { visible: false, data: null }
        }));
        setBdFilter('TRASH')
    };

    const handleSearchFun = (e) => {

        let obj = {
            ...trashFilterValues,
            tender_keyword: tenderSearch
        }
        tenderSearch && dispatch(trashFilterAction?.trashFilterUpdateAllKeys(obj));
    }

    const handleReset = () => {

        const data = trashFilterChips?.filter(item =>
            item?.value !== ''
            && item?.key !== 'limit'
            && item?.key !== 'page_number'
            && item?.key !== 'cycle_id'
            // && item?.key !== 'orderSerial'
        )
        const isValue = data?.some((item) => item?.value != '');

        setTenderSearch('');
        isValue && dispatch(trashFilterAction?.trashFilterResetKeys())
        // dispatch(filterCycleActions.filterResetKeys())
    }

    const handleFilterChange = (e) => {
        setTenderSearch(e.target.value)
        if (e.key === 'Enter') {
            e.preventDefault();
            handleSearchFun()
        }
    };

    const showDrawerAdvance = () => {
        setModals(prevModals => ({
            ...prevModals,
            bdBasicFilter: { visible: false, data: null },
            bdAdvanceFilter: { visible: true, data: null }
        }));

    }

    const onChangeStatus = async (e) => {
        let scopeName = dropdownList?.find(item => item.id == e)?.cycle_name;
        setDropdownSpinnerForBulkPopUP(true);
        const formData = new URLSearchParams();
        formData.append('tender_ids', checkedTender);
        formData.append('to_cycle_id', e);
        let result = await TrashServices.moveBulkTenderFromTrash(formData);
        if (result?.data?.status === '1') {
            setDropdownSpinnerForBulkPopUP(false);
            // const restData = getTenders?.filter(obj => !selectedItems?.includes(obj.id));
            // setTenders(restData)
            getAllTrashTenders()
            setCheckedTender([]);
            setCheckedAll(false)
            setStatusChange(defaultValues)
            notifySuccess(`Tender moved into ${scopeName ? scopeName : 'next'} stage`)
        } else {
            notify("Error");
        }
    };

    const onAdvanceClose = () => {
        setModals(prevModals => ({
            ...prevModals,
            bdAdvanceFilter: { visible: false, data: null }
        }));
    };

    const handleCheckAll = () => {
        if (getTrashTender.length === checkedTender.length || checkedTender.length > getTrashTender?.length) {
            setCheckedAll(false)
            setCheckedTender([]);
        }
        else {
            const postIds = getTrashTender.map((item) => {
                return item.bg_tender_id;
            })
            setCheckedAll(true);
            setCheckedTender(postIds);
        }
    }

    const stripHtmlTags = (htmlContent) => {
        var doc = new DOMParser().parseFromString(htmlContent, 'text/html');
        return doc.body.textContent || "";
    }

    const formattedData = getTrashTender?.map((item) => {
        return {
            'Id': item?.bg_tender_id,
            'Name': stripHtmlTags(item?.tender_name),
            'Cost': item?.tender_cost,
            'Tender Emd Amount': item?.tender_emd_amnt_val,
            'Submission start date': dayjs(item?.submission_start_date)?.format('YYYY-MM-DD'),
            'Submission End date': dayjs(item?.submission_end_date)?.format('YYYY-MM-DD'),
        };
    })

    const downloadExcel = () => {
        if (getTrashTender?.length > 0) {
            const ws = XLSX.utils.json_to_sheet(formattedData);

            const blankRow = {};
            for (let i = 1; i <= 6; i++) {
                blankRow[`A2`] = { v: '' };
            }
            XLSX.utils.sheet_add_json(ws, [blankRow], { skipHeader: true, header: ['A', 'B', 'C', 'D', 'E', 'F'] });
            const colWidths = [
                { wch: 7 },
                { wch: 40 },
                { wch: 10 },
                { wch: 20 },
                { wch: 20 },
                { wch: 20 },
            ];

            ws['!cols'] = colWidths;

            const rowHeights = formattedData.map(() => ({ hpx: 30 }));
            ws['!rows'] = rowHeights;

            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

            const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
            const dataBlob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

            const downloadLink = document.createElement('a');
            const url = URL.createObjectURL(dataBlob);
            downloadLink.href = url;
            downloadLink.download = 'TenderList.xlsx';
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }
    };

    const accGenerateChips = useCallback((showCross) => {
        if (accdChipData !== null && accdChipData !== []) {
            return (
                <GenerateChips
                    filterData={accdChipData}
                    stateVal={stateVal}
                    getScopeList={dropdownList}
                    setTenderSearch={setTenderSearch}
                    showCross={showCross}
                />
            )
        }
    }, [accdChipData]);

    const TrashGenerateChips = useCallback(() => {
        return (
            <GenerateChips
                filterData={trashFilterChips}
                stateVal={stateVal}
                getScopeList={dropdownList}
                setTenderSearch={setTenderSearch}
                showCross={true}
                // GenerateVal={false}
                commonFilter={"TRASH"}
            />
        )
    }, [trashFilterChips]);

    useEffect(() => {
        getStateDrpValue()
    }, [trashFilterValues?.country_id])

    useEffect(() => {
        // if (isUpdate) {
        getAllTrashTenders()
        // }
    }, [trashFilterValues, isUpdate])

    useEffect(() => {
        trashSingleDropDownFun()
        trashInactionBtnFun()
        setCheckedTender([])
        setCheckedAll(false)
    }, [])

    const closeMultiSelectPopUp = () => {
        setCheckedTender([]);
        setCheckedAll(false)
    }

    return (
        <>
            <div className="bd_tenderWapper">
                <div className="fixed_wrapper">
                    <div className="bd_newTender_heading">
                        <div className="headding-title">
                            {!skeleton ? (<h2>Trash Tenders</h2>) : <Skeleton width={200} height={30} />}
                        </div>
                        <div className='bd_seacrh_box'>
                            <div className="table_wrap mt-0">
                                <Search
                                    placeholder="Search"
                                    allowClear
                                    value={tenderSearch}
                                    onChange={handleFilterChange}
                                    onKeyDown={handleFilterChange}
                                />
                                <div className="search_icon" onClick={() => handleSearchFun()} ><button><SearchOutlined /></button>
                                </div>
                            </div>
                            <button className="BG_ghostButton" onClick={() => handleReset()}>Reset</button>
                            <button className="BG_mainButton" onClick={showDrawer}><img src={FilterImage} width={20} alt='' />Filter</button>
                        </div>
                    </div>
                    <div className="bd_tenderFilter">
                        <div className="card">
                            <div className="bd_cards_select">
                                <Checkbox
                                    disabled={getTrashTender?.length === 0 || getTrashTender?.length === undefined ? true : false}
                                    checked={checkedAll}
                                    onChange={handleCheckAll}
                                >
                                    Select all
                                </Checkbox>
                                <div className='navbar_middle'
                                    style={{ display: checkedTender.length > 0 ? 'block' : 'none' }}
                                >
                                    <div className='bd_tender_important'>
                                        <div>
                                            <span style={{ padding: "20" }}>{`${checkedTender?.length} ${checkedTender?.length > 1 ? 'Tenders' : 'Tender'} Selected`}</span>
                                        </div>
                                        <div className="bd_active_btn_sec" >
                                            <div className={`status_select ${statusChange}`}>
                                                {!dropdownSpinnerForBulkPopUP ?
                                                    <Select
                                                        defaultValue={defaultValues}
                                                        value={statusChange}
                                                        onChange={onChangeStatus}
                                                        suffixIcon={<Down theme="outline" size="18" fill="#78889b" />}
                                                        options={dropdownList?.map((item) => ({
                                                            value: item.id,
                                                            label: item.cycle_name
                                                        }))}
                                                    />
                                                    : <img src={spinGif} class="mt-2" width={30} />}
                                            </div>
                                        </div>
                                        <span><Tooltip title="Close"> <CloseIcon onClick={() => closeMultiSelectPopUp()} /></Tooltip></span>
                                    </div>
                                </div>
                            </div>
                            <div className="bd_new_button">
                                <button className='BG_ghostButton excelExport'
                                    onClick={downloadExcel}
                                >
                                    <DownloadOutlined /> Excel
                                </button>
                                <div className="showPrPage">
                                    <Form.Item className="export">
                                        <ExportDatatable
                                            dataSource={getTrashTender}
                                            columnLabels={columnLabels}
                                        />
                                    </Form.Item>
                                </div>
                                <button className="saveTempletes" onClick={showChipDrawer}>
                                    <div className="iconFlex">
                                        <SaveOne theme="outline" size="20" fill="#3bba61" strokeWidth={3} strokeLinecap="butt" />
                                    </div>
                                    Save Templates
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='card mt-4 add_template_card' style={{
                    display: trashFilterChips && trashFilterChips.some(item =>
                        item.value !== '' && !['page_number', 'cycle_id', 'limit', 'orderSerial'].includes(item.key)
                    ) ? "block" : "none"
                }} >
                    <div className="bd_cards_tender" {...events} ref={ref}>
                        {TrashGenerateChips()}
                    </div>
                    <button className="BG_addTemplate"
                        onClick={() => setModals(prevModals => ({
                            ...prevModals,
                            createTemplate: { visible: true, data: null },
                        }))}
                        style={{ display: applyTemp === true ? "none" : "" }} >
                        <Add theme="outline" size="22" fill="#684fd8" strokeWidth={3} strokeLinecap="butt" />Add Template
                    </button>
                </div>

                <TenderDetailsCard
                    skeleton={skeleton}
                    setChecked={setCheckedAll}
                    getTenders={getTrashTender}
                    setSelectedItems={setCheckedTender}
                    selectedItems={checkedTender}
                    setTenders={setTrashTender}
                    singleDropDownList={dropdownList}
                    handleSubmitTender={handleSubmitTender}
                    getAllTenders={getAllTrashTenders}
                    dropdownSpinner={dropdownSpinner}
                    tenderCount={tenderCount}
                    commonFilter={'TRASH'}
                    inActionBtnList={inActionBtnList}
                    page_Num={trashFilterValues?.page_number}
                    limit={trashFilterValues?.limit}
                />
                <FilterChipsTemplateDrawer
                    open={modals?.saveTemplate?.visible}
                    close={() => {
                        setModals(prevModals => ({
                            ...prevModals,
                            saveTemplate: { visible: false, data: null },
                        }))
                    }}
                    setModals={setModals}
                    applyFilter={applyFilter}
                    setApplyTemp={setApplyTemp}
                    setCollapseActiveKeyTemp={setCollapseActiveKeyTemp}
                    collapseActiveKeyTemp={collapseActiveKeyTemp}
                    handleUpdateFilter={handleUpdateFilter}
                    handleAccordionChange={handleAccordionChange}
                    handleRadioChange={handleRadioChange}
                    accGenerateChips={accGenerateChips}
                    tempType={"3"}
                    commonFilter={"TRASH"}
                />
                < Bd_basicFilter
                    open={modals?.bdBasicFilter?.visible}
                    close={() =>
                        setModals(prevModals => ({
                            ...prevModals,
                            bdBasicFilter: { visible: false, data: null },
                        }))
                    }
                    showDrawerAdvance={showDrawerAdvance}
                    updateFilter={updateFilter}
                    setUpdateFilter={setUpdateFilter}
                    updateFilterData={updateFilterData}
                    collapseActiveKeyTemp={collapseActiveKeyTemp}
                    setCollapseActiveKeyTemp={setCollapseActiveKeyTemp}
                    getScopeList={dropdownList}
                    setApplyTemp={setApplyTemp}
                    commonFilter={bdFilter}
                    filterValData={trashFilterValues}
                    tempType={"3"}
                />
                <Bd_advanceFilter
                    showDrawer={showDrawer}
                    advanceOpen={modals?.bdAdvanceFilter?.visible}
                    onAdvanceClose={onAdvanceClose}
                    collapseActiveKeyTemp={collapseActiveKeyTemp}
                    updateFilterData={updateFilterData}
                    updateFilter={updateFilter}
                    setOpen={handleUpdateFilter}
                    commonFilter={bdFilter}
                    filterValData={trashFilterValues}
                    tempType={"3"}
                />
                <AddTemplateModal
                    close={() => setModals(prevModals => ({
                        ...prevModals,
                        createTemplate: { visible: false, data: null },
                    }))}
                    open={modals?.createTemplate?.visible}
                    generateChips={TrashGenerateChips}
                    tempType={"3"}
                    filterValChipsData={trashFilterChips}
                />
            </div >
        </>
    )
}

export default NewTrashCard;