// @ts-nocheck
import React from 'react'
import { useNavigate } from 'react-router-dom'
import BIDGRIDROUTES from 'BidGrid/bidRoute/bidRoutes';
import { Link } from "react-router-dom";
function TaskManager() {
    const navigate = useNavigate();

    return (
        <div>
            <Link to={BIDGRIDROUTES?.Task_assigine}>TaskManage</Link>
        </div>
    )
}

export default TaskManager
