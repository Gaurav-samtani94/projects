// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { Collapse, Button, Menu } from 'antd';
import NewTenderCard from './BidTenders/NewtenderCard';
import { useLocation } from 'react-router';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import { TenderApi } from '../../Services/bidgrid/tenderList/TenderApi';
import { useDispatch } from 'react-redux';
import { filterCycleActions } from 'Redux/actions/bidgrid/cycleFilterAction';
import { useSelector } from 'react-redux';
import Skeleton from 'react-loading-skeleton'
import 'react-loading-skeleton/dist/skeleton.css'

import { AllApplication } from '@icon-park/react';


function NewTenderAssigine() {
  const location = useLocation();
  const { filterValues } = useSelector((state => state.cycleFilter)) //line to be copied
  const val = location?.pathname;
  const str = val.replace('/', '');
  const dispatch = useDispatch();
  const [collapseItems, setCollapseItems] = useState([]);
  const [getScopeList, setScopeList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentCycleId, setCurrentCycleID] = useState(null)
  const [checkedAll, setCheckedAll] = useState(false);
  const [checkedTender, setCheckedTender] = useState([]);

  // Skeleton component
  const CollapseSkeleton = () => {
    return (
      <div>
        {Array.from({ length: 9 }, (_, index) => (
          <div key={index} className="skeleton-line" style={{ marginBottom: '20px' }}>
            <Skeleton width={300} height={50} />
          </div>
        ))}
      </div>
    );
  };

  const handleTabClick = (tab, serialNumber) => {
    if (tab?.key) {
      setCheckedAll(false)
      setCheckedTender([])
      setCurrentCycleID(tab?.key?.toString())
      const myObj = getScopeList?.find((item) => item.id.toString() === tab?.key?.toString());
      const TenderBody = {
        // limit: filterValues?.limit ? filterValues?.limit == 1000 && filterValues?.orderSerial < 6 ? 25 : filterValues?.limit : 25,
        // limit: filterValues?.limit ? (filterValues?.limit == 1000 && myObj?.order_sr?.toString() < 6) ? 25 : filterValues?.limit : 25,
        limit: 25,
        // page_number: filterValues?.page_number ? filterValues?.page_number : 1,
        page_number: 1,
        cycle_id: tab?.key?.toString(),
        orderSerial: serialNumber?.toString() || myObj?.order_sr?.toString(),
      }
      dispatch(filterCycleActions.filterUpdateIndividualKeys(TenderBody))
    } else {
      return
    }

  };

  useEffect(() => {
    if (!filterValues?.cycle_id) {
      const TenderBody = {
        cycle_id: currentCycleId ? currentCycleId : '0',
      }
      dispatch(filterCycleActions.filterUpdateIndividualKeys(TenderBody))
    }
  }, [filterValues?.cycle_id])

  const getAllScopes = async () => {

    try {
      let result = await TenderApi.getScopList();
      if (result?.data?.status === '1') {
        var newObject = {
          "id": 0,
          "scope_name": "ALL",
          "order_sr": '0'
        };
        result?.data?.data.splice(0, 0, newObject);

        setScopeList(result?.data?.data?.filter(val => val?.scope_name !== 'NA'));

        setLoading(false);
        let firstScopeListId = filterValues?.cycle_id ? [filterValues?.cycle_id] : ['0'];
        let serialNum = result?.data?.data?.filter((item) => item?.id == firstScopeListId[0]).map((ite) => ite?.order_sr)

        handleTabClick(firstScopeListId, serialNum)
      }
      else {
        setLoading(true);
        setScopeList([])
      }

      const dynamicItems = result?.data?.data.map((item) => {

        return {
          key: item.id.toString(),
          label: (
            <div className="tabText_block">
              <span>{item.scope_name}</span>
            </div>
          ),
        };
      });

      setCollapseItems(dynamicItems);

    } catch (error) {
      console.log('error in getAllScopes in NewTenderAssign sceen', error);
      setCollapseItems([]);
      setScopeList([])
    }

  };

  useEffect(() => {
    getAllScopes();
  }, [])

  // === 
  const [collapsed, setCollapsed] = useState(false);
  const toggleCollapsed = () => {
    setCollapsed(!collapsed);
  };

  const showItems = () => {
    return getScopeList?.map((item, index) => {
      return {

        key: item?.id,
        icon: <AllApplication theme="outline" size="20" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />,
        label: item?.scope_name,

      }
    })
  }


  return (
    <>
      <div className='bd_new_tender'>
        <div className="d-flex">
          <div className='bd_new_tender_cont'>

            {
              loading ? (
                <CollapseSkeleton />

              ) : (
                <div className='bd_new_tender_sidebar'>
                  {/* {filterValues?.cycle_id && */}
                  <Menu
                    defaultSelectedKeys={['ALL']}
                    selectedKeys={[filterValues?.cycle_id ? filterValues?.cycle_id : '0']}
                    mode="inline"
                    inlineCollapsed={collapsed}
                    items={showItems()}
                    onSelect={handleTabClick}
                  />
                  {/* } */}
                </div>
              )
            }



            {/* {
              loading ? (
                <CollapseSkeleton />

              ) : (
                <div className='bd_new_tender_sidebar'>

                  {filterValues?.cycle_id &&
                    <Collapse accordion activeKey={[filterValues?.cycle_id]} items={collapseItems}
                      onChange={handleTabClick}
                    >
                    </Collapse>}
                </div>
              )
            } */}
          </div>


          <NewTenderCard
            getScopeList={getScopeList}
            checkedAll={checkedAll}
            setCheckedAll={setCheckedAll}
            checkedTender={checkedTender}
            setCheckedTender={setCheckedTender}
            toggleCollapsed={toggleCollapsed}
            collapsed={collapsed}
          />

        </div>

      </div>
    </>
  )
}

export default NewTenderAssigine
