// @ts-nocheck
import React from 'react'
// @ts-nocheck
import { useState, useEffect, useMemo } from 'react'
import { PlusOutlined } from '@ant-design/icons';
import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap';
import { Input, Form, Row, Col, Radio, Space, Button } from 'antd';
import { useLocation } from 'react-router';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import { useSelector } from 'react-redux';
import { Upload } from 'antd';
import { DocumentShareService } from 'Services/bidgrid/documentShare/DocumentShareApi';
import dayjs from 'dayjs';
import xlsImg from '../../assests/img/xls.png'
import coregImg from "../../assests/img/pdf.png"
import fileImg from '../../assests/img/file.png'


const columnLabels = {
    doc_filename: { name: 'File Name', required: true },
    link: { name: 'Link', required: true },
    title: { name: "Title", required: true },
    message: { name: 'Message', required: true },
    all_emails: { name: 'Email To', required: true },
    // doc_expiry_days: { name: 'EXPIRE DATE', required: true },
};

const Fileshare = () => {

    const [form] = Form.useForm();
    const [selectedOption, setSelectedOption] = useState({
        mailIds: [],
        title: '',
        message: '',
        files: [],
        get_link: 0
    });

    const [dataSource, setDataSource] = useState()
    const [disableCopyBtn, setDisableCopyBtn] = useState(false);
    const [copyLinkData, setCopyLinkData] = useState('')
    const [value, setValue] = useState();
    const [disableGetAlinkBtn, setdisableGetAlinkBtn] = useState(false);

    const location = useLocation();
    const val = location?.pathname;
    const str = val?.replace('/', '')
    const showActions = true;
    const showExpire = true;

    const onChange = (e) => {
        setValue(e.target.value);
    };

    const Date_diff = (item, days) => {
        const given_date = dayjs(item)
        const newDate = given_date.add(days, 'day');
        const final_date = newDate?.format('YYYY-MM-DD')
        return final_date
    }

    const handleCopyLink = () => {
        if (copyLinkData !== '') {
            const tempInput = document.createElement('input');
            tempInput.value = copyLinkData;
            document.body.appendChild(tempInput);
            tempInput.select();
            tempInput.setSelectionRange(0, 99999);
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            setDisableCopyBtn(true)
        }
    };

    const getFileImage = (fileExtension) => {
        switch (fileExtension) {
            case 'xls':
                return xlsImg;
            case 'pdf':
                return coregImg;
            default:
                return fileImg;
        }
    };

    const getAddDocument = useMemo(() => {

        const created_date = dataSource?.map((item) => {

            const fileExtension = item?.link.slice(-3); // Extract file extension
            const imgUrl = getFileImage(fileExtension);
            return {
                doc_filename: item?.doc_filename === "" ? '-' : item?.doc_filename,
                link: item.all_emails === "" ? <a href={`${item.link}`} target='blank'><img src={imgUrl} alt="File Icon" width={30} /> {fileExtension}</a> : '-',
                title: item?.title === "" ? '-' : item?.title,
                message: item?.message === "" ? '-' : item?.message,
                all_emails: item?.to_email === "" ? '-' : item?.all_emails,
                doc_expiry_days: item?.doc_expiry_days === "" ? '-' : Date_diff(item?.created_at, item?.doc_expiry_days)
            }

        })
        return created_date
    }, [dataSource])

    const getAllDocumentData = async () => {
        const formData = new URLSearchParams();
        formData.append('user_id', '1');
        try {
            const response = await DocumentShareService.getDocumentsList(formData);
            if (response?.data?.status === '1') {
                let tempArr = response?.data?.data;
                let basePath = response?.data?.basepath;
                tempArr = tempArr.map((item, index) => {
                    return { ...item, link: basePath + item.doc_path + '/' + item.doc_filename }
                })
                setDataSource(tempArr);
            } else {
                console.log(response?.data?.error);
            }

        } catch (err) {
            console.log(err, "====error")
        }
    }

    const handleSelectChange = (fieldName, value) => {
        if (fieldName === 'mailIds') {
            const mailIdsArray = value.split(',').map(email => email.trim());
            setSelectedOption(prevState => ({ ...prevState, mailIds: mailIdsArray }));

        } else {
            if (selectedOption?.files?.length === 0) {
                setValue()
                setCopyLinkData('')
                setDisableCopyBtn(false)
            }
            setSelectedOption(prevState => ({ ...prevState, [fieldName]: value }));
        }

        // setSelectedOption(prevState => ({ ...prevState, [fieldName]: mailIdsArray || value }));
    };


    const handleTranfer = async (val) => {
        setdisableGetAlinkBtn(true)
        if ((selectedOption?.title !== '' && selectedOption?.message !== '' && selectedOption?.files !== []) || selectedOption?.get_link === 0) {
            const formData = new FormData();
            const mailIdsArray = Array.isArray(selectedOption?.mailIds)
                ? selectedOption.mailIds
                : [selectedOption?.mailIds];

            mailIdsArray.forEach((item, index) => {
                formData.append('mailIds[]', item);
            });

            formData.append('title', selectedOption?.title);
            formData.append('message', selectedOption?.message);
            formData.append('files', selectedOption?.files[0]?.originFileObj);
            if (val === 'get_link') formData.append('get_link', '1')

            let result = await DocumentShareService?.postDocument(formData);

            // Get link case
            if (result?.data?.status === '1' && result?.data?.link) {
                setCopyLinkData(result?.data?.link)
                setdisableGetAlinkBtn(false)
                getAllDocumentData()
                handleReset();
            }
            /// email case
            else if (result?.data?.status === '1' && !result?.data?.link) {
                setSelectedOption({
                    mailIds: [],
                    title: '',
                    message: '',
                    files: [],
                    get_link: 0
                })
                getAllDocumentData();
            }
        }

    }

    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            handleTranfer()
            handleReset()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleReset = () => {
        form.resetFields()
    };

    useEffect(() => {
        getAllDocumentData()
    }, [])

    const beforeUpload = (file) => {
        setSelectedOption((prev) => ({ ...prev, fileList: [file] }));
        return false;
    };

    return (
        <>
            <div className='documentShare_wrapper'>
                <Row gutter={0}>

                    <Col span={17}>
                        <div className="docList_wrap">
                            <DataTable columnLabels={columnLabels} showActions={showActions} showExpire={showExpire} dataSource={getAddDocument} />
                        </div>
                    </Col>
                    <Col span={7}>

                        <div className="bd_model_left">
                            {/* <h3>Document Share</h3> */}
                            <div className="title-div">
                                {/* <Upload beforeUpload={beforeUpload} fileList={selectedOption.fileList}>  */}
                                <Upload
                                    listType="picture"
                                    name="files"
                                    fileList={selectedOption?.files}
                                    beforeUpload={beforeUpload}
                                    onChange={(e) => handleSelectChange('files', e.fileList)
                                    }
                                >
                                    <div className="icon-box">
                                        <PlusOutlined className='plus_icon' />
                                        <div className="text">
                                            <h5>Upload File</h5>
                                            <p>Or Select Your Folder</p>
                                        </div>
                                    </div>
                                </Upload>
                            </div>

                            {
                                value === 2 && selectedOption?.files?.length > 0 && (
                                    <div className='doc_action'>
                                        <Form name="validateOnly" className='doc_form' layout="vertical" autoComplete="off"  >
                                            <Form.Item label="Email to"
                                                rules={[{ required: true, message: 'Email is required' }]}>
                                                <Input placeholder='Enter here...' name='mailIds'
                                                    value={selectedOption.mailIds}
                                                    onChange={(e) => handleSelectChange('mailIds', e.target.value)} />
                                            </Form.Item>
                                            <Form.Item label="Title" rules={[{ required: true, message: 'Title is required' }]} onKeyDown={handleKeyPress}>
                                                <Input placeholder='Enter here...' name='title' value={selectedOption?.title} onChange={(e) => handleSelectChange('title', e.target.value)} />
                                            </Form.Item>
                                            <Form.Item label="Message" onKeyDown={handleKeyPress}>
                                                <textarea name="message" id="" rows="3" placeholder='Type Here' style={{ padding: 15 }} onChange={(e) => handleSelectChange('message', e.target.value)} style={{ width: "100%" }} ></textarea>
                                            </Form.Item>
                                            <div className='bd_model_button'>
                                                <button key="submit" className='BG_mainButton' onClick={() => handleTranfer('transfer')}  >
                                                    Transfer
                                                </button>
                                            </div>
                                        </Form>
                                    </div>
                                )
                            }
                            {
                                value === 1 && selectedOption?.files?.length > 0 && (
                                    <div className='doc_action'>
                                        <Form name="validate" className='doc_form' layout="vertical" autoComplete="off" onKeyDown={handleKeyPress} >
                                            <Form.Item label="" rules={[{ required: true, message: 'Title is required' }]}>
                                                <Input className='doc_input' placeholder='' name='link' value={selectedOption?.files?.length === 0 ? setCopyLinkData('') : copyLinkData} />
                                            </Form.Item>
                                            <div className='bd_model_button_doc'>
                                                <Button key="submit" className={copyLinkData === '' ? 'BG_mainButton' : 'BG_mainButton_doc'} onClick={() => handleTranfer('get_link')} disabled={copyLinkData === '' ? false : true} loading={disableGetAlinkBtn}

                                                >
                                                    Get a link
                                                </Button>
                                                <button key="submit" className={copyLinkData === '' ? 'BG_mainButton_doc' : 'BG_mainButton'} onClick={handleCopyLink} disabled={copyLinkData === ''} >
                                                    {disableCopyBtn ? "Copied" : "Copy Link"}
                                                </button>
                                            </div>
                                        </Form>


                                    </div>
                                )
                            }
                            <div className='doc_action'>
                                <Radio.Group className='doc_radio_option' disabled={selectedOption?.files?.length === 0 ? true : false} onChange={onChange} value={value}>
                                    <Space direction="horizontal">
                                        <Radio value={selectedOption?.files?.length === 0 ? '' : 1}>Get a link</Radio>
                                        <Radio value={selectedOption?.files?.length === 0 ? '' : 2}>Send email</Radio>
                                    </Space>
                                </Radio.Group>
                            </div>
                        </div>

                    </Col>
                </Row>
            </div >
        </>

    )
}


export default Fileshare;

