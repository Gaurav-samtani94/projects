// @ts-nocheck
import React from 'react'
import CustomProfile from 'BidGrid/components/Profile/CustomProfile'


const Profile = () => {

    return (
        <>
            <CustomProfile isPersonal={true} />
        </>
    )
}

export default Profile