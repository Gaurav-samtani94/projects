// @ts-nocheck
import DataTable from 'BidGrid/components/dataTable/DataTable';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import { Input, Form, Row, Col, Drawer, DatePicker, Select, Button } from 'antd';
import React, { useEffect, useMemo, useState } from 'react'
import { useLocation } from 'react-router-dom';
import skipBack from "../../../assets/images/skip-back.png"
import dayjs from 'dayjs';
import { Down } from '@icon-park/react';
import { bgdetail } from 'Services/bidgrid/add/BG detail/BgdetailApi';
import { BankApi } from 'Services/bidgrid/master/bank/BidBank';
import { toast } from 'react-toastify';
import moment from 'moment';
const { useForm } = Form;
const showActions = true;
const columnLabels = {
    bg_types: { name: 'BG Type', required: true },
    bg_bank_val: { name: 'Bank name', required: true },
    bg_title: { name: 'Title', required: true },
    bg_amount: { name: 'Amount ', required: true },
    bg_number: { name: 'BG number', required: true },
    bg_start_date: { name: 'start date', required: true },
    bg_validity: { name: 'Validity', required: true },
    bg_status_val: { name: 'Status', required: true },
    amount_received: { name: 'Amount Received', required: true },
};

const initialstate = {
    bg_type: null,
    bg_bank: null,
    bg_title: '',
    bg_amount: null,
    bg_number: null,
    bg_start_date: null,
    bg_validity: null,
    bg_status: null,
    amount_received: null,
}

function BankGuarantee() {
    const [form] = Form.useForm();
    const [selectedOption, setSelectedOption] = useState(initialstate);
    const [dataSource, setDataSource] = useState([])
    const [flattenedProjects, setFlattenedProjects] = useState([]);
    const [bankName, setBankName] = useState([])
    const [recordData, setRecordData] = useState({})
    const [open, setOpen] = useState(false);
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [spinner, setSpinner] = useState(false)

    const handleSelectChange = (name, value) => {
        setSelectedOption(prevFormData => ({
            ...prevFormData, [name]: value,
        }))
    }

    // get bg list api
    const BgdetailList = async (initial) => {
        if (initial) {
            setSpinner(true)
        }
        try {
            const response = await bgdetail.Bglist();
            if (response?.data?.status == 1) {
                setSpinner(false)
                setDataSource(response?.data?.data)
            }
            else {
                setSpinner(false)
                setDataSource([])
            }
        } catch (error) {
            setSpinner(false)
            console.log(error, 'api error');
        }
    };

    // bank list
    const BankList = async () => {
        try {
            const response = await BankApi.getBank()
            if (response?.data?.status == 1) {
                setBankName(response?.data?.data)
            }
            else {
                setBankName([])
            }
        } catch (error) {
            setBankName([])
            console.log(error)
        }
    };

    // BG add list api 
    const onFinish = async (value) => {
        if (recordData?.id) {
            setSpinner(true)
            const formData = new URLSearchParams();
            formData.append("bg_id", recordData?.id);
            formData.append("bg_type", value?.bg_type);
            formData.append("bg_bank", value?.bg_bank);
            formData.append("bg_title", value?.bg_title);
            formData.append("bg_amount", value?.bg_amount);
            formData.append("bg_status", value?.bg_status);
            formData.append("bg_number", value?.bg_number);
            formData.append("bg_start_date", dayjs(value?.bg_start_date).format('YYYY-MM-DD'));
            formData.append("bg_validity", dayjs(value?.bg_validity).format('YYYY-MM-DD'));
            formData.append("amount_received", value?.amount_received);
            try {
                await form.validateFields();
                const response = await bgdetail?.updateBg(formData);
                if (response?.data?.status == 1) {

                    notifySuccess('Bank Guarantee Updated Successfully')
                    await BgdetailList(false)
                    setOpen(false)
                    setSelectedOption(initialstate)
                    form.resetFields()
                    setRecordData({})
                }
                else {
                    setSpinner(false)
                    notify(response?.response?.data?.message)
                }
            } catch (error) {
                setSpinner(false)
                console.error('Error fetching data:', error);
            }
        }
        else {
            setSpinner(true)
            const formData = new URLSearchParams();
            formData.append("bg_type", Number(value?.bg_type));
            formData.append("bg_bank", value?.bg_bank);
            formData.append("bg_title", value?.bg_title);
            formData.append("bg_amount", value?.bg_amount);
            formData.append("bg_status", value?.bg_status);
            formData.append("bg_number", value?.bg_number);
            formData.append("bg_start_date", dayjs(value?.bg_start_date).format('YYYY-MM-DD'));
            formData.append("bg_validity", dayjs(value?.bg_validity).format('YYYY-MM-DD'));
            formData.append("amount_received", value?.amount_received);
            try {
                await form.validateFields();
                const response = await bgdetail?.addBg(formData);
                if (response?.data?.status == 1) {
                    notifySuccess('Bank Guarantee Added Successfully')
                    await BgdetailList(false)
                    setOpen(false)
                    setSelectedOption(initialstate)
                    form.resetFields()
                    // setDataSource([response?.data?.data, ...dataSource])

                }
                else {
                    setSpinner(false)
                    notify(response?.response?.data?.message)
                }
            } catch (error) {
                setSpinner(false)
                console.error('Error fetching data:', error);
            }
        }

    }


    const deleteBgdetail = async (id) => {
        try {
            const formData = new URLSearchParams();
            formData.append('bg_id', id)
            const response = await bgdetail?.Bgdelete(formData)
            if (response?.data?.status == 1) {
                setSpinner(true)
                notifySuccess('Bank Guarantee Deleted Successfully')
                await BgdetailList(false)
            }
        } catch (error) {
            setSpinner(false)
            console.log("Api Error", error);
        }
    }


    const getPropDataVal = (record, status) => {
        setOpen(status)
        setRecordData(record)
    }

    const predefinedValues = () => {
        const getbgBankName = bankName?.find(val => val.id === recordData?.bg_bank)
        let newObj = {
            bg_type: recordData?.bg_type,
            bg_bank: getbgBankName ? getbgBankName?.id : null,
            bg_title: recordData?.bg_title,
            bg_amount: recordData?.bg_amount,
            bg_number: recordData?.bg_number,
            bg_start_date: dayjs(recordData?.bg_start_date),
            bg_validity: dayjs(recordData?.bg_validity),
            bg_status: recordData?.bg_status,
            amount_received: recordData?.amount_received,
        }
        form.setFieldsValue(newObj);
    }

    useEffect(() => {
        if (recordData?.id) {
            predefinedValues()
        }
    }, [recordData])

    useEffect(() => {
        const flattenedData = dataSource?.map(project => ({
            id: project?.id,
            bg_types: project?.bg_type == 1 ? 'ABG' : 'PGB',
            bg_bank_val: bankName?.filter(item => item?.id == project?.bg_bank)?.map((value) => value?.bank_name),
            bg_title: project?.bg_title,
            bg_amount: project?.bg_amount,
            bg_number: project?.bg_number !== null ? project?.bg_number : "-",
            bg_start_date: dayjs(project?.bg_start_date).format('YYYY-MM-DD'),
            bg_validity: dayjs(project?.bg_validity).format('YYYY-MM-DD'),
            bg_status_val: project?.bg_status == 1 ? 'Expired' : 'Ongoing',
            amount_received: project?.amount_received,
            bg_type: project?.bg_type,
            bg_status: project?.bg_status,
            bg_bank: project?.bg_bank,
        }));
        if (flattenedData?.length > 0) {
            setFlattenedProjects(flattenedData);
        }
    }, [dataSource]);

    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            //  onFinish()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };
    const handleKeyPressSelectedItem = (e) => {
        // const alphabeticChars = /[a-zA-Z]/;
        const allowedChars = /[0-9/]/;
        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        }
        else if (e.key === 'Enter') {
            e.preventDefault();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };
    const handleKeyContainOnlyNumbers = (e) => {
        const allowedChars = /[0-9.]/;

        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
        } else if ((e.key === ' ' && e.target.selectionStart === 0) || (e.key === '0' && e.target.selectionStart === 0 && e.target.value === '0')) {
            e.preventDefault();
        } else if (e.target.selectionStart === 0 && e.key === '0') {
            e.preventDefault();
        }
    };

    const handleReset = () => {
        setSelectedOption(initialstate)
        form.resetFields();
    };

    const exceptSymbol = ['e', 'E', '+', '-', ''];

    useEffect(() => {
        BankList()
        BgdetailList(true)
    }, []);

    const handleClose = () => {
        setOpen(false);
        setSelectedOption(initialstate);
        setRecordData(initialstate);
        form.resetFields()
    }

    return (
        <>
            <div className="bd_prospective_tender">
                <div className="bd_procpective_header">
                    <div className="bd_left_head">
                        Bank Guarantee
                    </div>
                    <button className="BG_mainButton"
                        onClick={() => setOpen(true)}
                    >
                        <span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM17 13H13V17H11V13H7V11H11V7H13V11H17V13Z" fill="white" />
                        </svg></span>Add BG
                    </button>
                </div>

                <div>
                    <DataTable
                        title="bank guarantee"
                        handleDelete={deleteBgdetail}
                        getPropDataVal={getPropDataVal}
                        columnLabels={columnLabels}
                        dataSource={flattenedProjects}
                        showActions={showActions}
                        spinner={spinner}
                        setSpinner={setSpinner}

                    />
                </div>
            </div>

            <Drawer className='bd_drawer_main' closeIcon={<img src={skipBack} alt='' />} title={recordData?.id ? "Edit  BG" : "Add  BG"} placement="right" onClose={() => handleClose()} open={open} width={800}>
                <div className='bd_prospective_drawer'>
                    <div>
                        <div className='bd_drawer_prospective_box'>
                            <Form
                                form={form}
                                layout="vertical"
                                onFinish={onFinish}
                                autoComplete='off'
                                name="control-hooks"

                            >
                                <Row gutter={20}>

                                    <Col sm={12}>
                                        <Form.Item
                                            label="BG Type:"
                                            name="bg_type"
                                            rules={[
                                                { required: true, message: "Please enter BG Type" }
                                            ]}
                                            onKeyPress={handleKeyPress}

                                        >
                                            <Select
                                                allowClear
                                                showSearch
                                                name='bg_type'
                                                value={selectedOption?.bg_type}
                                                onChange={(value) => handleSelectChange('bg_type', value)}
                                                options={[{ value: '1', label: 'ABG' }, { value: '2', label: 'PBG' }]}
                                                placeholder="Select BG Type"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                filterOption={(input, option) => option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                                            />
                                        </Form.Item>

                                    </Col>


                                    <Col sm={12}>
                                        <Form.Item label="Bank Name:" name="bg_bank"
                                            onKeyPress={handleKeyPress}
                                            rules={[
                                                { required: true, message: "Please enter BG Bank" }
                                            ]}>
                                            <Select
                                                allowClear
                                                showSearch
                                                placeholder="Select Here..."
                                                value={selectedOption?.bg_bank}
                                                onChange={(value) => handleSelectChange('bg_bank', value)}
                                                name='bg_bank'
                                                options={bankName?.map((item) => {
                                                    return {
                                                        value: item?.id,
                                                        label: item?.bank_name
                                                    }
                                                })}
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                filterOption={(input, option) =>
                                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                }
                                            >

                                            </Select>
                                        </Form.Item>
                                    </Col>
                                    <Col sm={12}>
                                        <Form.Item label="Title:" name="bg_title" rules={[{
                                            required: true, message: "Please enter a Title"
                                        }]}
                                            onKeyPress={handleKeyPress}

                                        >
                                            <Input
                                                placeholder='Enter Title'
                                                value={selectedOption?.bg_title}
                                                // onKeyDown={(e) => { exceptSymbol.includes(e?.key) && e.preventDefault() }}
                                                type='text'
                                                onChange={(e) => handleSelectChange('bg_title', e?.target?.value)}
                                                name='bg_title'

                                            />
                                        </Form.Item>
                                    </Col>
                                    {/* <Col sm={12}> */}
                                    {/* <Form.Item label="Amount Received:"
                                            onKeyPress={handleKeyContainOnlyNumbers}
                                            name="amount_received" rules={[{
                                                required: true,
                                                message: "Please enter a Amount Received"
                                            }]}
                                        >
                                            <Input
                                                placeholder='Enter Amount'
                                                value={selectedOption?.amount_received}
                                                onKeyDown={(e) => { exceptSymbol.includes(e?.key) && e.preventDefault() }}
                                                type='number'
                                                onChange={(e) => handleSelectChange('amount_received', e?.target?.value)}
                                            // name='amount_received'   

                                            />
                                        </Form.Item> */}


                                    {/* </Col> */}


                                    <Col sm={12}>
                                        <Form.Item label="Amount:"
                                            name="bg_amount"
                                            rules={[
                                                {
                                                    required: true,
                                                    message: "Please enter a Amount"
                                                },
                                                ({ getFieldValue }) => ({
                                                    validator(_, value) {
                                                        if (/^[1-9][0-9]*$/.test(value)) {
                                                            return Promise.resolve();
                                                        }
                                                        if (/^0[0-9]*$/.test(value)) {
                                                            return Promise.reject(new Error('Amount cannot start with zero'));
                                                        }
                                                        return Promise.reject(new Error('Invalid amount'));
                                                    },
                                                }),
                                            ]}
                                            validateTrigger={['onChange', 'onBlur']}
                                            validateFirst
                                            getValueFromEvent={(e) => {
                                                const value = e.target.value;
                                                if (/^0[0-9]*$/.test(value)) {
                                                    e.target.setCustomValidity('Amount cannot start with zero');
                                                } else {
                                                    e.target.setCustomValidity('');
                                                }
                                                return value;
                                            }}
                                            onKeyPress={handleKeyContainOnlyNumbers}
                                        >
                                            <Input
                                                placeholder='Enter Amount'
                                                value={selectedOption?.bg_amount}
                                                onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                                type='number'
                                                onChange={(e) => handleSelectChange('bg_amount', e?.target?.value)}
                                                name='bg_amount'

                                            />
                                        </Form.Item>
                                    </Col>
                                    <Col sm={12}>
                                        <Form.Item label="BG Number: "
                                            name="bg_number" rules={[{
                                                required: true, message: "Please enter a BG Number"
                                            }]}
                                            onKeyPress={handleKeyContainOnlyNumbers}
                                        >
                                            <Input
                                                placeholder='Enter Number'
                                                value={selectedOption?.bg_number}
                                                onKeyDown={(e) => { exceptSymbol.includes(e?.key) && e.preventDefault() }}
                                                type='number'
                                                name='bg_number'
                                                onChange={(e) => handleSelectChange('bg_number', e?.target?.value)}
                                            />

                                        </Form.Item>
                                    </Col>
                                    <Col sm={12}>
                                        <Form.Item label="Status"
                                            name="bg_status" rules={[{
                                                required: true, message: "Please enter a status"
                                            }]}
                                            onKeyPress={handleKeyPress}
                                        >
                                            <Select
                                                allowClear
                                                placeholder="Enter Here"
                                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                showSearch
                                                optionFilterProp="label"

                                                options={[{ value: '1', label: 'Expired' }, { value: '2', label: 'Ongoing' }]}
                                                onChange={(e) => handleSelectChange('bg_status', e)}
                                                name='bg_status'
                                                value={selectedOption?.bg_status}
                                            />
                                        </Form.Item>
                                    </Col>

                                    {selectedOption?.bg_status == 1 || recordData?.bg_status == 1 ? <Col sm={12} >
                                        <Form.Item
                                            label="Amount Received:"
                                            name="amount_received"
                                            rules={[

                                                ({ getFieldValue }) => ({
                                                    validator(_, value) {
                                                        if (/^[1-9][0-9]*$/.test(value)) {
                                                            return Promise.resolve();
                                                        }
                                                        if (/^0[0-9]*$/.test(value)) {
                                                            return Promise.reject(new Error('Amount cannot start with zero'));
                                                        }
                                                        return Promise.reject(new Error('Invalid amount'));
                                                    },
                                                }),
                                            ]}
                                            validateTrigger={['onChange', 'onBlur']}
                                            validateFirst
                                            getValueFromEvent={(e) => {
                                                const value = e.target.value;
                                                if (/^0[0-9]*$/.test(value)) {
                                                    e.target.setCustomValidity('Amount cannot start with zero');
                                                } else {
                                                    e.target.setCustomValidity('');
                                                }
                                                return value;
                                            }}
                                            onKeyPress={handleKeyContainOnlyNumbers}
                                        >
                                            <Input
                                                placeholder='Enter Amount'
                                                type='number'
                                            />
                                        </Form.Item>
                                    </Col> : ''}

                                    <Col sm={12}>
                                        <Form.Item label="Start Date:"
                                            name="bg_start_date" rules={[{
                                                required: true, message: "Please enter a Start Date"
                                            }]}
                                            onKeyPress={handleKeyPressSelectedItem}
                                        >
                                            <DatePicker placeholder='Start Date' name='bg_start_date'
                                                // onKeyDown={(e) => { exceptSymbol.includes(e?.key) && e.preventDefault() }}
                                                // value={selectedOption?.bg_start_date} 
                                                // disabledDate={(current) => current && current < dayjs().startOf('day')}

                                                value={selectedOption?.bg_start_date !== null ? dayjs(selectedOption?.bg_start_date) : null}
                                                onChange={(e) => handleSelectChange('bg_start_date', e)} />

                                        </Form.Item>
                                    </Col>

                                    <Col sm={12}>
                                        <Form.Item label="Validity: "
                                            name="bg_validity" rules={[{
                                                required: true, message: "Please enter a Validity"
                                            }]}
                                            onKeyPress={handleKeyPressSelectedItem}
                                        >
                                            <DatePicker placeholder='End Date' name='bg_validity'
                                                onKeyDown={(e) => { exceptSymbol.includes(e?.key) && e.preventDefault() }}
                                                //  value={selectedOption?.bg_validity} 
                                                type="date"
                                                disabledDate={(current) =>
                                                    selectedOption?.bg_start_date &&
                                                    current &&
                                                    current.isBefore(dayjs(selectedOption?.bg_start_date).startOf('day'))
                                                }
                                                value={selectedOption?.bg_validity !== null ? dayjs(selectedOption?.bg_validity) : null}
                                                onChange={(e) => handleSelectChange('bg_validity', e)} />
                                        </Form.Item>
                                    </Col>

                                </Row>
                                <div className="bd_drawerFoot">
                                    <Button className='BG_ghostButton'
                                        // onClick={() => setSelectedOption(initialstate)}
                                        onClick={() => { recordData?.id ? predefinedValues() : handleReset(); recordData?.id && handleClose() }}
                                    >{recordData?.id ? 'Cancel' : 'Reset'}</Button>
                                    <button className='BG_mainButton' type="submit">{selectedOption?.id ? 'Update' : 'Submit'} </button>
                                </div>
                            </Form>
                        </div>



                    </div>
                </div>
            </Drawer>


        </>
    )
}
// BankGuarantee.whyDidYouRender = true

export default BankGuarantee
