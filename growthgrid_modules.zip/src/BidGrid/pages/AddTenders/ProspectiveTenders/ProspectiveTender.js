// @ts-nocheck
import React, { useState, useEffect, useMemo } from 'react';
import DataTable from "BidGrid/components/dataTable/DataTable";

import DrawerSection from 'BidGrid/components/Drawer/Drawer';
import { useLocation } from 'react-router';
import { bidProspective } from 'Services/bidgrid/prospective/bidProspective';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';
import { ChartPie, LocalTwo, PaperMoneyTwo, Funds, BuildingOne, FileConversion, DeleteFour, FileEditing, PreviewOpen } from '@icon-park/react';
import ROUTES from 'Constants/Routes';
import { Link, useNavigate } from 'react-router-dom';
import { Pagination } from 'antd';
import Delete from 'BidGrid/components/modalDelete/Delete';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { Select, Input, Skeleton } from 'antd';
import { Down } from '@icon-park/react';
import { SearchOutlined } from '@ant-design/icons';
import EmptyBox from '../../../../assests/img/empty-box.png';
const { Search } = Input;
const { Option } = Select;


const ProspectiveTender = () => {
    const { BidCountry } = useSelector((state) => state.bidDropdownCalVal)
    const [isEditFields] = useState({})
    const [page, setPage] = useState(1)
    const [limit, setLimit] = useState(25)
    const [searchText, setSearchText] = useState('');
    const dummyArr = Array.from({ length: limit });





    // drawer open
    const [open, setOpen] = useState(false);
    const [deleteModal, setDeleteModal] = useState(false);
    // state to store api data
    const [prospectiveListVal, setProspectiveListVal] = useState([])
    const [companyList, setCompanyList] = useState([])
    // this will be the data which is to be filtered from obj of mapped list 
    const [propData, setPropData] = useState({})

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [spinner, setSpinner] = useState(true)

    const getProspectiveListData = async (isCleared) => {

        setSpinner(true)
        const formData = new URLSearchParams();
        formData.append('page_number', page);
        formData.append('limit', limit);
        formData.append('tender_keyword', isCleared ? '' : searchText);

        try {
            const response = await bidProspective.getProspectiveList(formData)
            if (response?.data?.status === "1") {
                setProspectiveListVal(response?.data)
                setSpinner(false)
            } else {
                setProspectiveListVal([])
                setSpinner(false)
            }
        } catch (error) {
            console.log(error, 'api erorr')
            setSpinner(false)
        }
    }

    const deletehandler = async (id) => {

        try {
            const formData = new URLSearchParams()
            formData.append('project_id', id)
            const response = await bidProspective.deleteprospectiveList(formData)
            if (response?.data?.status === '1') {
                setSpinner(true)
                notifySuccess('Tender Deleted Successfully');
                await getProspectiveListData(false)
            } else {
                setSpinner(false)
                notify(response?.response?.data?.message);
            }

        } catch {
            setSpinner(false)
            console.log('error')
        }

    }
    useEffect(() => {
        getProspectiveListData(false)
    }, [page, limit])


    const showDrawer = (isUpdate, isDrawer, project) => {

        const flattenedData = {
            id: project?.project_id,
            project_name: project?.project_name.replace(/<[^>]*>/g, ''),
            tender_value: Number(project?.tender_value),
            countryData: project?.bg_mstr_country?.country_name,
            StateData: project?.bg_mstr_state?.state_name,
            clientData: project?.bg_mstr_client?.client_name,
            sector: project?.bg_mstr_sector?.sector_name,
            fundingAgencyData: project?.bg_mstr_funding_agency?.funding_org_name,
            documentData: project?.bg_prospective_documents,
            leadCompanyData: project?.bg_prospective_partner?.main_company?.company_name,
            jvs_id: project?.bg_prospective_tenders_jvs?.map(item => item?.main_company?.company_name),
            stateArr: []
        }
        if (!isUpdate && !isDrawer) {
            setDeleteModal(true)
            setPropData(flattenedData)
            return
        }
        if (!isUpdate && isDrawer) {
            handleCompanyList()
            setOpen(true);
            setPropData({})
            return
        }
        if (isUpdate && isDrawer) {
            handleCompanyList(project?.project_id)
            manipulateStateVal(flattenedData)
            return
        }

    };


    const getState = async (data, val) => {
        const formData = new URLSearchParams()
        formData.append('country_id', data?.id)
        try {
            const res = await bidProspective.getStateList(formData)
            if (res?.data?.status == '1') {
                val['stateArr'] = res?.data?.data
                setPropData(val)
                setOpen(true)
            } else {
                setPropData(val)
                setOpen(true)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const manipulateStateVal = async (val) => {
        let bidCountryFilterData = BidCountry?.find(item => item?.country_name === val?.countryData)
        await getState(bidCountryFilterData, val)
    }

    const onClose = () => {
        setOpen(false);
        setPropData({})
    };

    const handlePageChange = (page, pageSize) => {
        setPage(page)
    };

    const handlePageSizeChange = (value) => {
        setPage(1)
        setLimit(value)
    }

    const handleCompanyList = async (id) => {
        const formData = new URLSearchParams()
        formData.append('project_id', id)
        let response
        try {
            if (id) {
                response = await TenderApi?.CompetitorList(formData)
            } else {
                response = await TenderApi?.getAllCompanyList()
            }
            if (response?.data?.status == 1) {
                setCompanyList(response?.data?.data)
            }
            else {
                setCompanyList([])
            }
        } catch (error) {
            console.log(error)
        }
        return
    }

    return (
        <>
            <div className="bd_prospective_tender">
                <div className="bd_procpective_header">
                    <div className="bd_left_head">
                        Prospective Tender
                    </div>
                    <button className="BG_mainButton" onClick={() => showDrawer(false, true)}>
                        <span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM17 13H13V17H11V13H7V11H11V7H13V11H17V13Z" fill="white" />
                        </svg></span>Add Prospective Tender
                    </button>
                </div>
                <div className="tableHead_wrap mt-4">
                    <div className="d-flex" style={{ gap: 20 }}>
                        <div className="bd_seacrh_box table_wrap mt-0">
                            <Search
                                placeholder="Search"
                                value={searchText}
                                onChange={(e) => setSearchText(e.target.value)}
                                style={{ width: 450 }}
                            />
                            <div onClick={() => getProspectiveListData(false)} className="search_icon"><button><SearchOutlined /></button>
                            </div>
                        </div>
                        <button class="BG_ghostButton" onClick={() => { setSearchText(''); getProspectiveListData(true) }}>Reset</button>
                    </div>
                    <div className='show_doctrol_list'>
                        <div className="showPrPage">
                            <span>Showing</span>
                            <Select
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                defaultValue={limit}
                                style={{ width: 70 }}
                                onChange={handlePageSizeChange}
                            >
                                <Option value={25}>25</Option>
                                <Option value={50}>50</Option>
                                <Option value={75}>75</Option>
                                <Option value={100}>100</Option>
                                <Option value={150}>150</Option>
                            </Select>
                            <span>of <b>{prospectiveListVal?.totalItems}</b> results</span>
                        </div>
                    </div>
                </div>
                <div className="cardTender_wrapper">

                    {spinner ?
                        <>
                            {dummyArr?.map((index) => {
                                return <div key={index} className="tender_cardBlock">
                                    <Skeleton
                                        active
                                        paragraph={{
                                            rows: 4,
                                        }} />
                                </div>
                            })}
                        </>
                        :
                        <>
                            {prospectiveListVal?.data?.length > 0 ?
                                <>
                                    {prospectiveListVal?.data?.map((val) => {
                                        return (
                                            <div className="tender_cardBlock">
                                                <div className="d-flex">
                                                    <div className="tc_client"><span>Client name:</span> {val?.bg_mstr_client?.client_name}</div>
                                                    <div className="tc_action">

                                                        <div>
                                                            <FileEditing onClick={() => showDrawer(true, true, val)} theme="filled" size="22" fill="#9b9b9b" strokeLinecap="butt" />
                                                        </div>
                                                        <div>
                                                            <DeleteFour onClick={() => showDrawer(false, false, val)} theme="filled" size="22" fill="#9b9b9b" strokeLinecap="butt" />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="tc_title">{val?.project_name?.replace(/<[^>]*>/g, '')}</div>
                                                <div className="tc_sector">
                                                    <ChartPie theme="filled" size="16" fill="#ff7043" strokeWidth={3} strokeLinecap="butt" />
                                                    Sector name : {val?.bg_mstr_sector?.sector_name}
                                                </div>

                                                <div className="tc_additonalInfo">
                                                    <div className="item">
                                                        <small>Tender value</small>
                                                        <div>
                                                            <PaperMoneyTwo theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                                            {val?.tender_value || 'Not Specified'}
                                                        </div>
                                                    </div>
                                                    <div className="item">
                                                        <small>Location</small>
                                                        <div>
                                                            <LocalTwo theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                                            {val?.bg_mstr_state?.state_name ? `${val?.bg_mstr_state?.state_name} ,` : 'Not Specified'} {val?.bg_mstr_country?.country_name ? val?.bg_mstr_country?.country_name : ''}
                                                        </div>
                                                    </div>
                                                    <div className="item">
                                                        <small>Funding agencies</small>
                                                        <div>
                                                            <Funds theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                                            {val?.bg_mstr_funding_agency?.funding_org_name || 'Not Specified'}
                                                        </div>
                                                    </div>
                                                    <div className="item">
                                                        <small>Lead Company</small>
                                                        <div>
                                                            <BuildingOne theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                                            {val?.bg_prospective_partner?.main_company?.company_name || 'Not Specified'}
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="tc_foot">
                                                    <div className="tc_jointVenture">
                                                        <FileConversion theme="filled" size="20" fill="#684fd8" strokeWidth={3} strokeLinecap="butt" />
                                                        <span>Joint Venture:</span>
                                                        {val?.bg_prospective_tenders_jvs?.length > 0 ?
                                                            <>
                                                                {val?.bg_prospective_tenders_jvs?.map((item) => {
                                                                    return (
                                                                        <p>{item?.main_company?.company_name} <span>&nbsp; | &nbsp;</span>
                                                                        </p>
                                                                    )
                                                                })}
                                                            </>
                                                            :
                                                            'Not Specified'
                                                        }

                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    })}
                                </>
                                :
                                <div className="spinerWrap">
                                    <div className="data_foundDiv">
                                        <img src={EmptyBox} width={100} />
                                        <div style={{ textAlign: "center", fontSize: 16 }}>No Record Found</div>
                                    </div>
                                </div>
                            }
                        </>
                    }


                </div>

                {prospectiveListVal?.data?.length > 0 && <Pagination
                    current={page}
                    pageSize={limit}
                    total={prospectiveListVal?.totalItems}
                    onChange={handlePageChange}
                />}
            </div>

            <Delete title={'tender'} open={deleteModal} handleDelete={deletehandler} onClose={() => setDeleteModal(false)} modalData={propData} />

            <DrawerSection companyList={companyList} setSpinner={setSpinner} propData={propData} getProspectiveListData={getProspectiveListData} setOpen={setOpen} open={open} onClose={onClose} setPropData={setPropData} />
        </>
    );
}


export default ProspectiveTender;

// chhaya