// @ts-nocheck

import React, { useState, useRef, useEffect } from 'react';
import { Pagination, Skeleton, Input, Select } from 'antd';
import { ChartPie, LocalTwo, PaperMoneyTwo, UserBusiness, PeopleSafeOne, FileEditing, Down } from '@icon-park/react';
import { AddTenderList } from 'Services/bidgrid/add/AddTender';
import LiveTenderDrawer from './liveTenderDrawer';
import dayjs from 'dayjs';
import { useNavigate } from 'react-router-dom';
import ROUTES from 'Constants/Routes';
import { SearchOutlined } from '@ant-design/icons';
import EmptyBox from '../../../../assests/img/empty-box.png';
const { Search } = Input;
const { Option } = Select;

const AddTender = () => {
    const [dataSource, setDataSource] = useState([])
    const [open, setOpen] = useState(false);
    const [page, setPage] = useState(1)
    const [limit, setLimit] = useState(25)
    const editorRef = useRef(null);
    const [skeleton, setSkeleton] = useState(true)
    const [tenderCycle, setTenderCycle] = useState([])
    const [searchText, setSearchText] = useState('')
    const dummyArr = Array.from({ length: limit })
    const navigate = useNavigate()

    const getAddtender = async (isCleared) => {
        setSkeleton(true)
        const formData = new URLSearchParams();
        formData.append('limit', limit);
        formData.append('page_number', page);
        formData.append('tender_keyword', isCleared ? '' : searchText);
        try {
            // const response = await AddTenderList.getAddTenderList(formData)
            const response = await AddTenderList.getAddTenderListNew(formData)
            if (response?.data?.status === '1') {
                setDataSource(response?.data)
                setSkeleton(false)
            } else {
                setSkeleton(false)
                setDataSource([])
            }
        } catch (error) {
            setSkeleton(false)
            console.log(error, 'api erorr')
        }
    }

    const getAddTenderCycle = async () => {
        try {
            const res = await AddTenderList.getTenderCycleList()
            if (res?.data?.status === '1') {
                setTenderCycle(res?.data?.data?.filter((item) => item?.order_sr <= 7))
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }
    const handlePageChange = (page, pageSize) => {
        setPage(page)
    };

    const handlePageSizeChange = (value) => {
        setPage(1)
        setLimit(value)
    }

    const handleFilterChange = (e) => {
        setSearchText(e.target.value)
        if (e.key === 'Enter') {
            e.preventDefault();
            getAddtender(false)
            // handleSearchFun()
        }
    }

    const handleResetFilter = () => {
        if (searchText != '') {
            setSearchText('')
            getAddtender(true)
        }
    }

    useEffect(() => {
        getAddTenderCycle()
    }, [])

    useEffect(() => {
        getAddtender()
    }, [page, limit])


    const showStatusColor = (scopeOrderSerial) => {
        switch (scopeOrderSerial) {
            case 1:
                return "one"

            case 2:
                return "two"

            case 3:
                return "three"

            case 4:
                return "four"

            case 5:
                return "five"

            case 6:
                return "six"

            case 7:
                return "seven"

            case 8:
                return "eight"

            default:
                break;
        }

    }

    const handleNavigate = (id) => {
        navigate(ROUTES.BD_TENDERDETAILS.replace(':id', id))
    }
    return (
        <>
            <div className="bd_prospective_tender">
                <div className="bd_procpective_header">


                </div>
                <div className="bd_procpective_header">
                    <div className="bd_left_head">
                        Tenders List
                    </div>

                    <button className="BG_mainButton"
                        onClick={() => setOpen(true)}
                    >
                        <span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM17 13H13V17H11V13H7V11H11V7H13V11H17V13Z" fill="white" />
                        </svg></span>Add  Tender
                    </button>
                </div>
                {/* form fields */}

                <div className="tableHead_wrap mt-4">
                    <div className="d-flex" style={{ gap: 20 }}>
                        <div className="bd_seacrh_box table_wrap mt-0">
                            <Search
                                placeholder="Search"
                                allowClear
                                value={searchText}
                                onChange={(e) => handleFilterChange(e)}
                                onKeyDown={(e) => handleFilterChange(e)}
                                style={{ width: 450 }}
                            />
                            <div onClick={() => getAddtender(false)} className="search_icon"><button><SearchOutlined /></button>
                            </div>
                        </div>
                        <button class="BG_ghostButton" onClick={() => handleResetFilter()}>Reset</button>
                    </div>

                    <div className='show_doctrol_list'>
                        <div className="showPrPage">
                            <span>Showing</span>
                            <Select
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                defaultValue={limit}
                                style={{ width: 70 }}
                                onChange={handlePageSizeChange}
                            >
                                <Option value={10}>25</Option>
                                <Option value={20}>50</Option>
                                <Option value={30}>75</Option>
                                <Option value={40}>100</Option>
                                <Option value={40}>150</Option>
                            </Select>
                            <span>of <b>{dataSource?.totalItems}</b> results</span>
                        </div>
                    </div>
                </div>

                <div className="cardTender_wrapper">

                    {!skeleton ?
                        <>
                            {dataSource?.data?.length > 0 ?
                                <>
                                    {dataSource?.data?.map((item, index) => {
                                        const getStatus = tenderCycle?.find((val) => val.id == item.cycle_id)
                                        return (
                                            <div onClick={() => handleNavigate(item?.id)} key={index} className="tender_cardBlock">
                                                <div className="d-flex">
                                                    <div className="tc_client"><span>Client Name:</span> {item?.bg_mstr_client?.client_name || 'Not Specified'}</div>
                                                    <div className="tc_action">
                                                        {item?.is_corri_update !== 0 && <div className="updateTender">New Update</div>}
                                                        <div className="editBtn">
                                                            <FileEditing theme="filled" size="20" fill="#9b9b9b" strokeLinecap="butt" />
                                                            Edit
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="tc_title">
                                                    {item?.tender_name?.replace(/<[^>]*>/g, '')}
                                                </div>
                                                {item?.bg_mstr_sector?.sector_name &&
                                                    <div className="tc_sector">
                                                        <ChartPie theme="filled" size="16" fill="#ff7043" strokeWidth={3} strokeLinecap="butt" />
                                                        {item?.bg_mstr_sector?.sector_name}
                                                    </div>
                                                }

                                                <div className="tc_additonalInfo">
                                                    <div className="item">
                                                        <small>Tender Value</small>
                                                        <div>
                                                            <PaperMoneyTwo theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                                            {item?.tender_cost || 'Not Specified'}
                                                        </div>
                                                    </div>
                                                    {/* <div className="item">
                                                        <small>EMD value</small>
                                                        <div>
                                                            <PaperMoneyTwo theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                                            {item?.tender_emd_amnt_val || 'Not Specified'}
                                                        </div>
                                                    </div> */}
                                                    <div className="item">
                                                        <small>Location</small>
                                                        <div>
                                                            <LocalTwo theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                                            {item?.bg_mstr_state?.state_name ? `${item?.bg_mstr_state?.state_name} ,` : ''} {item?.bg_mstr_country?.country_name ? item?.bg_mstr_country?.country_name : ''}
                                                        </div>
                                                    </div>
                                                    {item?.assign_tender?.find(val => val.bd_role_id === 1)?.hasOwnProperty('user')
                                                        &&
                                                        <div className="item">
                                                            <small>Key Client Manager</small>
                                                            <div>
                                                                {item?.assign_tender?.filter(val => val.bd_role_id === 1)?.map((item) => {
                                                                    return (
                                                                        <>
                                                                            <UserBusiness theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                                                            {item?.user?.userfullname}
                                                                        </>
                                                                    )
                                                                })}
                                                            </div>
                                                        </div>
                                                    }

                                                    {item?.assign_tender?.find(val => val.bd_role_id === 2)?.hasOwnProperty('user')
                                                        &&
                                                        <div className="item">
                                                            <small>Bid Manager</small>
                                                            <div>
                                                                {item?.assign_tender?.filter(val => val.bd_role_id === 2)?.map((item) => {
                                                                    return (
                                                                        <>
                                                                            <PeopleSafeOne theme="filled" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                                                                            {item?.user?.userfullname}
                                                                        </>
                                                                    )
                                                                })}

                                                            </div>
                                                        </div>
                                                    }
                                                    {item?.bg_assign_tndr_generated_id?.generated_tender_id && <div className="item id_generated">
                                                        <small>Generated Id</small>
                                                        <div>
                                                            {item?.bg_assign_tndr_generated_id?.generated_tender_id}
                                                        </div>
                                                    </div>}
                                                </div>

                                                <div className="tc_foot">
                                                    <div className="d-flex">
                                                        <div className="tc_submissionDate">
                                                            <span>Bid Submission Start Date:</span>
                                                            {dayjs(item?.submission_start_date).format("DD MMMM YYYY")}
                                                        </div>
                                                        <div className="tc_submissionDate endText">
                                                            <span>Bid Submission End Date:</span>
                                                            <div className="d-flex" style={{ gap: 10 }}>
                                                                {dayjs(item?.submission_end_date).format("DD MMMM YYYY")}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className={`status ${showStatusColor(getStatus?.order_sr)}`}>{getStatus?.scope_name}</div>
                                                </div>
                                            </div>
                                        )
                                    })}
                                </>
                                :
                                <div className="spinerWrap">
                                    <div className="data_foundDiv">
                                        <img src={EmptyBox} width={100} />
                                        <div style={{ textAlign: "center", fontSize: 16 }}>No Record Found</div>
                                    </div>
                                </div>
                            }

                        </>
                        :
                        <>
                            {dummyArr?.map((index) => {
                                return <div key={index} className="tender_cardBlock">
                                    <Skeleton
                                        active
                                        paragraph={{
                                            rows: 4,
                                        }} />
                                </div>
                            })}
                        </>

                    }



                    {/* ./tender_cardBlock */}

                    {dataSource?.data?.length > 0 && <Pagination
                        current={page}
                        pageSize={limit}
                        total={dataSource?.totalItems}
                        onChange={handlePageChange}
                    />}
                </div>
            </div>

            <LiveTenderDrawer open={open} setOpen={setOpen} getAddtender={getAddtender} tenderCycle={tenderCycle} />
        </>
    );
}
export default AddTender;

