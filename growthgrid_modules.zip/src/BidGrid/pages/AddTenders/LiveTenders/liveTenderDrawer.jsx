// @ts-nocheck
import React, { useEffect, useState, useRef } from 'react';
import { Input, Form, Row, Col, Upload, Drawer, DatePicker, Select, Button } from 'antd';
import { useSelector } from 'react-redux';
import { UploadOutlined } from '@ant-design/icons';
import { Down } from '@icon-park/react';
import skipBack from "../../../assets/images/skip-back.png"
import 'quill/dist/quill.snow.css'
import ReactQuill from 'react-quill'
import dayjs from 'dayjs';
import { AddTenderList } from 'Services/bidgrid/add/AddTender';
import { ChartPie, LocalTwo, PaperMoneyTwo, UserBusiness, PeopleSafeOne, FileConversion, DeleteFour, FileEditing, PreviewOpen } from '@icon-park/react';
import { toast } from 'react-toastify';
import 'quill/dist/quill.snow.css'
import { files } from 'jszip';


var modules = {
    toolbar: [
        [{ size: ["small", false, "large", "huge"] }],
        ["bold", "italic", "underline", "strike", "blockquote"],
        [{ list: "ordered" }, { list: "bullet" }],
        ["link", "image"],
        [
            { list: "ordered" },
            { list: "bullet" },
            { indent: "-1" },
            { indent: "+1" },
            { align: [] },
            // { pdf: 'PDF' }
        ],
        [{ "color": ["#000000", "#e60000", "#ff9900", "#ffff00", "#008a00", "#0066cc", "#9933ff", "#ffffff", "#facccc", "#ffebcc", "#ffffcc", "#cce8cc", "#cce0f5", "#ebd6ff", "#bbbbbb", "#f06666", "#ffc266", "#ffff66", "#66b966", "#66a3e0", "#c285ff", "#888888", "#a10000", "#b26b00", "#b2b200", "#006100", "#0047b2", "#6b24b2", "#444444", "#5c0000", "#663d00", "#666600", "#003700", "#002966", "#3d1466", 'custom-color'] }],
    ],
};

var formats = [
    "header", "height", "bold", "italic",
    "underline", "strike", "blockquote",
    "list", "color", "bullet", "indent",
    "link", "image", "align", "size",
];


const initialstate = {
    tender_cost: "",
    client_id: null,
    currency_id: null,
    country_id: null,
    city_id: null,
    cycle_id: null,
    bg_mstr_tndr_cycle: null,
    national_intern: null,
    submission_start_date: null,
    submission_end_date: null,
    bg_mstr_sector: null,
    state_id: null,
    files: [],
}
const LiveTenderDrawer = (props) => {
    const { getAddtender, open, setOpen, tenderCycle } = props;
    const [form] = Form.useForm();
    const [selectedOption, setSelectedOption] = useState(initialstate);
    const [tenderState, setTenderState] = useState([])

    const [editData, setEditData] = useState()
    const [editNameData, setEditNameData] = useState()
    const [isCleared, setIsCleared] = useState(true);
    const [tenderName, setTenderName] = useState('')
    const [errormsg, setErrorMsg] = useState(false)
    const { BidClient, BidFundingClientAgency, BidCountry, BidSector, BidCurrency } = useSelector((state) => state.bidDropdownCalVal)
    const [spinner, setSpinner] = useState(false)

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    //unused code for now

    // const [tenderCity, setTenderCity] = useState([])
    // const [tenderRegion, setTenderRegion] = useState([])
    const [dateDiff, setDateDiff] = useState()

    // const [tenderData, setTenderData] = useState({})
    // const editorRef = useRef(null);
    // const disabledDate = (current) => {
    //     const fromDate = selectedOption.submission_start_date;
    //     return current && (current < fromDate || current.isSame(fromDate, 'day'));
    // };


    // const calculateDateDiff = (fromDate, toDate) => {
    //     if (fromDate && toDate) {
    //         const from_datediff = dayjs(fromDate).format('YYYY-MM-DD');
    //         const to_datediff = dayjs(toDate).format('YYYY-MM-DD');
    //         const differenceInDays = dayjs(to_datediff).diff(dayjs(from_datediff), 'day');
    //         setDateDiff(differenceInDays);
    //     } else if (!fromDate && toDate) {
    //         setDateDiff(0);
    //         setSelectedOption({
    //             ...selectedOption,
    //             submission_start_date: null
    //         })
    //     } else if (fromDate && !toDate) {
    //         setDateDiff(0);
    //         setSelectedOption({
    //             ...selectedOption,
    //             submission_end_date: null
    //         })
    //     } else {
    //         setDateDiff(0);
    //     }
    // };

    // const getRegionList = async () => {
    //     const formData = new URLSearchParams()
    //     formData.append('country_id', selectedOption?.country_id)
    //     try {
    //         const res = await AddTenderList.getTenderRegionList(formData)
    //         // console.log(res, "res")
    //         if (res?.data?.status === '1') {
    //             setTenderRegion(res?.data?.data)
    //         }
    //     } catch (error) {
    //         console.log(error)
    //     }
    // }

    // const getAddTenderCity = async () => {
    //     const formData = new URLSearchParams();
    //     formData.append('state_id', selectedOption?.state_id);
    //     try {
    //         const res = await AddTenderList.getTenderCityList(formData)

    //         if (res?.data?.status === '1') {
    //             setTenderCity(res?.data?.data)
    //         }
    //     } catch (error) {
    //         console.log(error, 'api erorr')
    //     }
    // }


    // useEffect(() => {
    //     if (selectedOption?.state_id !== null) {
    //         getAddTenderCity()

    //     }
    // }, [selectedOption?.state_id])


    const handleSelectChange = (name, value) => {
        console.log(value, "value============")
        if (name === 'submission_start_date') {
            const nextDay = value != null ? dayjs(value).add(1, 'day') : null;
            setSelectedOption((prevFormData) => ({
                ...prevFormData,
                submission_start_date: value,
                submission_end_date: nextDay,
            }));
            form.setFieldsValue({
                submission_end_date: nextDay,
            });
        }
        if (name === "country_id") {
            form.setFieldsValue({
                state_id: null
            })
            setSelectedOption((prevFormData) => ({
                ...prevFormData,
                [name]: value,
            }));
        }
        // if (name === "state_id") {
        //     setSelectedOption((prevFormData) => ({
        //         ...prevFormData,
        //         [name]: value,
        //     }));
        // } 
        else {
            setSelectedOption((prevFormData) => ({
                ...prevFormData,
                [name]: value === undefined ? null : value,
            }));
        }
    }

    const disabledEndDate = (current) => {
        return current && current < dayjs(selectedOption.submission_start_date).endOf('day');
    };

    const handleEditorChange = (content, delta, source, editor) => {

        if (content === '<p><br></p>' && tenderName === '') {
            setErrorMsg(true)
        } else {
            setErrorMsg(false)
        }
        setTenderName(content);
        setIsCleared(content?.trim()?.replace(/<[^>]*>/g, '') === '');
    };

    const handleKeyDown = (event) => {
        if (isCleared && event.key === ' ') {
            event.preventDefault();
        }
    };
    const getAddTenderState = async () => {
        const formData = new URLSearchParams();
        formData.append('country_id', selectedOption?.country_id);
        try {
            const res = await AddTenderList.getTenderStateList(formData)
            if (res?.data?.status === '1') {
                setTenderState(res?.data?.data)
                // getRegionList()
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    useEffect(() => {
        if (selectedOption?.country_id !== null) {
            getAddTenderState()
        }
    }, [selectedOption?.country_id])

    const exceptSymbol = ['e', 'E', '+', '-', '.'];
    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();

        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleReset = () => {
        form.resetFields();
        setSelectedOption(initialstate)
        setErrorMsg(false)
        setTenderName('')
    }

    const handleKeyPressSelectedItem = (e) => {

        const allowedChars = /[0-9/]/;
        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        }
        else if (e.key === 'Enter') {
            e.preventDefault();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleEditor = () => {
        if (tenderName?.trim()?.replace(/<[^>]*>/g, '') === '') {
            setErrorMsg(true)
        } else {
            setErrorMsg(false)
        }
    }

    const onFinish = async (value) => {
        if (errormsg) {
            return
        }
        setSpinner(true)

        const formData = new FormData();
        if (editNameData) (formData.append('tender_id', editData?.id))
        formData.append('tender_name', tenderName);
        formData.append('tender_cost', Number(value?.tender_cost));
        formData.append('country_id', value?.country_id);
        formData.append('state_id', value?.state_id || '');
        formData.append('sector_id', value?.bg_mstr_sector);
        formData.append('cycle_id', value?.bg_mstr_tndr_cycle);
        formData.append('client_id', value?.client_id || '');
        formData.append('currency_id', value?.currency_id || '');
        formData.append('submission_start_date', value?.submission_start_date);
        formData.append('submission_end_date', value?.submission_end_date);
        selectedOption?.files?.forEach((file, index) => {
            formData.append('files', file?.originFileObj);
        });
        try {
            const response = editNameData ? await AddTenderList.updateAddTenderList(formData) : await AddTenderList.AddLiveTenderList(formData)
            if (response?.data?.status === '1') {
                onClose();
                notifySuccess("Tender Added Successfully");
                await getAddtender(false);
                setSpinner(false)
                setTenderName('')
                setTenderState([])
                setSelectedOption({
                    tender_cost: "",
                    client_id: null,
                    currency_id: null,
                    country_id: null,
                    cycle_id: null,
                    bg_mstr_tndr_cycle: null,
                    national_intern: null,
                    submission_start_date: null,
                    submission_end_date: null,
                    bg_mstr_sector: null,
                    state_id: null,
                    files: []
                });

            } else {
                setSpinner(false)
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            onClose();
            notify(error)
            setSpinner(false)
            console.log(error, "api error")
        }

    }

    const beforeUpload = (file) => {
        setSelectedOption((prev) => ({ ...prev, fileList: [file] }));
        return false;
    };


    const onClose = () => {
        setEditData()
        setEditNameData()
        setOpen(false);
        setSelectedOption({
            tender_cost: "",
            client_id: null,
            currency_id: null,
            country_id: null,
            cycle_id: null,
            bg_mstr_tndr_cycle: null,
            national_intern: null,
            submission_start_date: null,
            submission_end_date: null,
            bg_mstr_sector: null,
            state_id: null,
            files: []
        });
        setTenderName('')
        form.resetFields()
        setErrorMsg(false)
    };


    const dateFormat = 'DD-MM-YYYY';
    return (
        <Drawer className='bd_drawer_main' closeIcon={<img src={skipBack} alt='' />} title={editNameData ? "Edit Tender" : "Add  Tender"} placement="right" onClose={onClose} open={open} width={1100}>
            <div className='bd_prospective_drawer'>
                <div>
                    <div className='bd_drawer_prospective_box'>
                        <Form
                            form={form}
                            layout="vertical"
                            onFinish={onFinish}
                            autoComplete='off'
                            name="control-hooks"
                        >
                            <Row gutter={20}>
                                <Col sm={24}>
                                    <Form.Item label="Tender Name:"
                                    >
                                        <div className="bd_editor">
                                            <div className="">
                                                <div style={{ marginBottom: "85px", justifyContent: "center" }}>
                                                    <ReactQuill
                                                        theme="snow"
                                                        modules={modules}
                                                        formats={formats}
                                                        placeholder="Enter Tender Name                                                        "
                                                        name='tender_name'
                                                        onKeyDown={handleKeyDown}
                                                        onChange={handleEditorChange}
                                                        value={tenderName}
                                                        style={{ height: "300px" }}
                                                    >

                                                    </ReactQuill>
                                                </div>
                                                {errormsg ? <div className="col-md-12" style={{ color: '#ff4d4f' }}>Please enter tender name</div> : <p></p>}
                                            </div>
                                        </div>
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Tender Sector:" name="bg_mstr_sector"
                                        rules={[{ required: true, message: "Please select tender sector." }]}
                                        onKeyPress={handleKeyPress}
                                    >
                                        <Select
                                            showSearch
                                            allowClear
                                            value={selectedOption?.bg_mstr_sector}
                                            onChange={(value) => handleSelectChange('bg_mstr_sector', value)}
                                            name='bg_mstr_sector'
                                            options={BidSector?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.sector_name
                                                }
                                            })}
                                            placeholder="Select Sector"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Bid Submission Start Date:" name='submission_start_date' rules={[{ required: true, message: "Please select bid submission start date" }]}
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <DatePicker placeholder='Select Date' name='submission_start_date'
                                            value={selectedOption.submission_start_date}
                                            onChange={(value) => handleSelectChange('submission_start_date', value)}
                                            format={dateFormat}
                                        // disabledDate={(current) => current && current < dayjs().startOf('day')}

                                        />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Bid Submission End Date:" name='submission_end_date' rules={[{ required: true, message: "Please select bid submission end date" }]} onKeyPress={handleKeyPressSelectedItem}>
                                        <DatePicker placeholder='End Date' name='submission_end_date'
                                            disabled={selectedOption?.submission_start_date == null}
                                            value={selectedOption?.submission_end_date} onChange={(value) => handleSelectChange('submission_end_date', value)}
                                            disabledDate={disabledEndDate}
                                            format={dateFormat}

                                        />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Tender Currency:"
                                        onKeyPress={handleKeyPress}
                                        rules={[{ required: true, message: "Please select tender currency." }]}
                                        name="currency_id"

                                    >
                                        <Select
                                            showSearch
                                            allowClear
                                            value={selectedOption?.currency_id}
                                            onChange={(value) => handleSelectChange('currency_id', value)}
                                            options={BidCurrency?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.name
                                                }
                                            })}
                                            placeholder="Select Currency"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>

                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Tender Value:"
                                        name="tender_cost"
                                        rules={[{ required: true, message: "Please select tender value." }]}
                                    >
                                        <Input
                                            value={selectedOption?.tender_cost}
                                            onKeyDown={(e) => { exceptSymbol.includes(e?.key) && e.preventDefault() }}
                                            type='number'
                                            onChange={(value) => handleSelectChange('tender_cost', value.target.value)}
                                            name='tender_cost'
                                            placeholder='Enter Value'
                                        />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Country:"
                                        name="country_id"
                                        onKeyPress={handleKeyPress}
                                        rules={[{ required: true, message: "Please enter country." }]}
                                    >
                                        <Select
                                            showSearch
                                            allowClear
                                            value={selectedOption?.country_id}
                                            onChange={(value) => handleSelectChange('country_id', value)}
                                            name='country_id'
                                            options={BidCountry?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.country_name
                                                }
                                            })}
                                            placeholder="Select Country"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="State:"
                                        name="state_id"
                                        onKeyPress={handleKeyPress}
                                    >
                                        <Select
                                            showSearch
                                            allowClear
                                            value={selectedOption.state_id}
                                            onChange={(value) => handleSelectChange('state_id', value)}
                                            options={tenderState?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.state_name
                                                }
                                            })}
                                            placeholder="Select State"
                                            name='state_id'
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Client: "
                                        name="client_id"
                                    >
                                        <Select
                                            showSearch
                                            allowClear
                                            onKeyPress={handleKeyPress}
                                            value={selectedOption.client_id}
                                            onChange={(value) => handleSelectChange('client_id', value)}
                                            name='client_id'
                                            options={BidClient?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.client_name
                                                }
                                            })}
                                            placeholder="Select Client"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >
                                        </Select>
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label="Tender Cycle:"
                                        name="bg_mstr_tndr_cycle"
                                        onKeyPress={handleKeyPress}
                                        rules={[{ required: true, message: "Please select tender cycle." }]}
                                    >
                                        <Select
                                            showSearch
                                            allowClear
                                            value={selectedOption?.bg_mstr_tndr_cycle}
                                            onChange={(value) => handleSelectChange('bg_mstr_tndr_cycle', value)}
                                            name='bg_mstr_tndr_cycle'
                                            options={tenderCycle?.filter(fItem => fItem?.order_sr <= 6).map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.scope_name
                                                }
                                            })}
                                            placeholder="Select Tender Cycle"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        >

                                        </Select>

                                    </Form.Item>
                                </Col>
                                <Col sm={8}>
                                    <Form.Item label="Upload file:">
                                        <Upload
                                            listType="picture"
                                            name='files'
                                            fileList={selectedOption?.files}
                                            multiple={true}
                                            beforeUpload={() => false}
                                            onChange={(info) => {
                                                const fileList = info?.fileList?.map((file) => ({
                                                    uid: file?.uid,
                                                    name: file?.name,
                                                    status: 'done',
                                                    originFileObj: file?.originFileObj,
                                                }));
                                                handleSelectChange('files', fileList);
                                            }}
                                        >
                                            <Button icon={<UploadOutlined />}>Upload</Button>
                                        </Upload>
                                    </Form.Item>
                                </Col>
                            </Row>
                            <div className="bd_drawerFoot">
                                <Button className='BG_ghostButton'
                                    onClick={handleReset}
                                // onClick={() => setSelectedOption(initialstate)}

                                >Reset</Button>
                                <button className='BG_mainButton'
                                    onClick={handleEditor}
                                    disabled={spinner}
                                >{editNameData ? "Update" : "Create"}</button>
                            </div>
                        </Form>
                    </div>



                </div>
            </div>
        </Drawer>
    )
}

export default LiveTenderDrawer
