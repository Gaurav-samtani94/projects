//@ts-nocheck
import React, { useEffect, useState, useMemo } from 'react'
import 'bootstrap';
import { Menu, Input, Form, Modal, Dropdown, Button } from 'antd';
import { More } from '@icon-park/react';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import SettingTable from 'BidGrid/components/dataTable/SettingTable';
import { bidCompany } from 'Services/bidgrid/master/company/bidCompany';
const columnLabels = {
  company_name: { name: 'Company Name', required: true },
};

const initialState = {
  company_name: '',
}

const Company = () => {
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState([])
  const [modalForm, setModalForm] = useState(initialState)
  const [spinner, setSpinner] = useState(false)
  const [modal, setModal] = useState(false);
  const [record, setRecord] = useState(null)
  const [deleteModal, setDeleteModal] = useState(false);

  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);


  const tableData = useMemo(() => {
    return dataSource;
  }, [dataSource]);


  // get company list api
  const getCompany = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    try {
      const response = await bidCompany.getCompanyList();
      if (response?.data?.data.length > 0) {
        setDataSource(response?.data?.data?.sort((a, b) => a?.company_name?.localeCompare(b?.company_name)))
      } else {
        setDataSource([])
      }
    } catch (error) {
      console.log(error)
    } finally {
      setSpinner(false)
    }
  };

  // company add list api 
  const addHandler = async () => {
    setSpinner(true)
    const formData = new URLSearchParams();
    formData.append("company_name", modalForm?.company_name);
    try {
      const response = await bidCompany?.addCompanyList(formData);
      if (response?.data?.status == 1) {
        await getCompany(false)
        notifySuccess('Company Added Successfully')
        handleCancel()
      }
      else {
        notify(response?.response?.data?.message)
        setSpinner(false)
      }
    } catch (error) {
      setSpinner(false)
      notify(error);
    }
  }

  // edit company api
  const editHandler = async () => {
    if (record?.company_name === modalForm?.company_name) {
      handleCancel()
      return
    }
    setSpinner(true)
    try {
      const formData = new URLSearchParams();
      formData.append('company_id', record?.id)
      formData.append('company_name', modalForm?.company_name)
      const response = await bidCompany?.editCompanyList(formData)
      if (response?.data?.status == 1) {
        await getCompany(false)
        notifySuccess('Company Updated Successfully')
        handleCancel()
      }
      else {
        setSpinner(false)
        notify(response?.response?.data?.message);
      }
    } catch (error) {
      setSpinner(false)
      notify(error)
    }
  }

  const deleteHandler = async () => {
    setSpinner(true)
    try {
      const formData = new URLSearchParams();
      formData.append('company_id', record?.id)
      const response = await bidCompany?.handleDeleteCompany(formData)
      if (response?.data?.status == 1) {
        await getCompany(false)
        notifySuccess('Company Deleted Successfully')
        setRecord(null)
      } else {
        setSpinner(false)
      }
    } catch (error) {
      setSpinner(false)
      notify(error)
    }
  }


  useEffect(() => {
    getCompany(true)
  }, []);



  const handleCompanyChange = (name, e) => {
    const trimmedValue = e.target.value.trimStart();
    form.setFieldsValue({ [name]: trimmedValue });
    setModalForm({
      ...modalForm,
      [name]: trimmedValue
    })
  };

  const showModal = () => {
    setModal(true);
  };

  const hideModal = () => {
    setModal(false)
  }

  const handleReset = () => {
    setModalForm(initialState)
    setRecord(null)
    form.resetFields()
  }

  const handleCancel = () => {
    hideModal();
    handleReset()
  };

  const handleEdit = (record) => {
    setRecord(record)
    const obj = {
      company_name: record?.company_name,
    }
    setModalForm({
      ...modalForm,
      ...obj
    })
    form.setFieldsValue(obj);
    showModal()
  }

  const handleDelete = (record) => {
    setRecord(record)
    setDeleteModal(true)
  }

  const actionBtns = {
    title: 'Actions',
    key: 'actions',
    render: (record) => {
      return (
        <>
          <Dropdown
            placement='bottomRight'
            overlay={
              <Menu className="bd_tableAction">
                <Menu.Item key="edit" onClick={() => handleEdit(record)} className='bd_view_btn'>
                  <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <g clip-path="url(#clip0_221_1663)">
                      <path d="M8.25 3H3C2.60218 3 2.22064 3.15804 1.93934 3.43934C1.65804 3.72064 1.5 4.10218 1.5 4.5V15C1.5 15.3978 1.65804 15.7794 1.93934 16.0607C2.22064 16.342 2.60218 16.5 3 16.5H13.5C13.8978 16.5 14.2794 16.342 14.5607 16.0607C14.842 15.7794 15 15.3978 15 15V9.75" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M13.875 1.87505C14.1734 1.57668 14.578 1.40906 15 1.40906C15.422 1.40906 15.8266 1.57668 16.125 1.87505C16.4234 2.17342 16.591 2.57809 16.591 3.00005C16.591 3.422 16.4234 3.82668 16.125 4.12505L9 11.25L6 12L6.75 9.00005L13.875 1.87505Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </g>
                    <defs>
                      <clipPath id="clip0_221_1663">
                        <rect width="18" height="18" fill="white" />
                      </clipPath>
                    </defs>
                  </svg>
                  Edit
                </Menu.Item>
                <Menu.Item key="delete" onClick={() => handleDelete(record)} className='bd_delete_btn'>
                  <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2.25 4.5H3.75H15.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    <path d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72064 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    <path d="M7.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    <path d="M10.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                  </svg>
                  Delete
                </Menu.Item>
              </Menu>

            }
          >
            <a onClick={(e) => e.preventDefault()}>
              <More theme="outline" size="25" fill="#95a6b6" strokeWidth={3} />
            </a>
          </Dropdown >
        </>
      )
    },
    width: 120,
  }
  return (
    <>
      <div className='BD_master_wrapper'>
        <div className="heading_title">
          <h3>Company List</h3>
          <button className="BG_mainButton" onClick={showModal}>Add Company</button>
        </div>
        <div className='bd_model_right'>
          <SettingTable
            title='Company Detail'
            handleDeleteApi={deleteHandler}
            columnLabels={columnLabels}
            dataSource={tableData}
            showActions={true}
            spinner={spinner}
            record={record}
            deleteModal={deleteModal}
            setDeleteModal={setDeleteModal}
            actionBtns={actionBtns}
          />
        </div>
      </div>
      <Modal title={record?.id ? "Edit Company" : "Add Company"} open={modal} onCancel={() => { !spinner && handleCancel() }} footer={null} centered>
        <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" className='bd_model_form' onFinish={record?.id ? editHandler : addHandler}>
          <Form.Item label="Company Name:" name='company_name' rules={[{ required: true, message: 'Company name is required' }]}>
            <Input placeholder='Enter Company name' value={modalForm?.company_name} onChange={(e) => handleCompanyChange('company_name', e)}
            />
          </Form.Item>

          <div className='btn_flex'>
            <Button disabled={spinner} onClick={() => { record?.id ? handleCancel() : handleReset() }} key="back" className='BG_ghostButton'>
              {record?.id ? "Cancel" : "Reset"}
            </Button>
            <Button className='BG_mainButton' type="primary" htmlType="submit" loading={spinner} disabled={spinner} >{record?.id ? "Update" : "Submit"} </Button>
          </div>
        </Form>
      </Modal >
    </>
  )
}
Company.whyDidYouRender = true
export default Company;
