import React from "react";
import { Scheduler } from "@aldabil/react-scheduler";
import { useLocation } from 'react-router';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";

//chhaya
const Calendar = () => {
    const location = useLocation();

    const val = location?.pathname;
    const str = val.replace('/', '')
    return (
        <>
            <Breadcrumb data={str} />
            <div className="bd_inner_wrapper bd_calendar_wrapper">
                <div className="bd_title">Calendar</div>
            </div>
            <Scheduler
                deletable={true}
                fields={[
                    {
                        name: "Description",
                        type: "input",
                        default: "Default Value...",
                        config: { label: "Details", multiline: true, rows: 4 }
                    },
                    {
                        name: "anotherdate",
                        type: "date",
                        config: {
                            label: "Other Date",
                            md: 6,
                            type: "datetime"
                        }
                    }
                ]}
            />
        </>

    );
}

export default Calendar

//chhaya