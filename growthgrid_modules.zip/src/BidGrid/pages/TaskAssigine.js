import React from 'react'
import ProjectImage from "../assets/images/profile.jpg"
import { Progress, Avatar, Tooltip } from 'antd';
import Taskboard from 'BidGrid/components/Taskboard/Taskboard';
import { AntDesignOutlined, UserOutlined } from '@ant-design/icons';
import { useLocation } from 'react-router';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
function TaskAssigine() {
    const location = useLocation();

    const val = location?.pathname;
    const str = val.replace('/', '')
    return (
        <>
            <Breadcrumb data={str} />
            <div className="bd_task__wrapper">
                <div className="bd_task_project_left_side">
                    <div className='bd_project_name' >
                        <h5>Project</h5>
                    </div>
                    <div className='bd_project_list active' >
                        <div className='bd_project_image'>
                            <img src={ProjectImage} />
                            <div className='project_name'>
                                Project X
                            </div>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M10 12C10 12.5304 10.2107 13.0391 10.5858 13.4142C10.9609 13.7893 11.4696 14 12 14C12.5304 14 13.0391 13.7893 13.4142 13.4142C13.7893 13.0391 14 12.5304 14 12C14 11.4696 13.7893 10.9609 13.4142 10.5858C13.0391 10.2107 12.5304 10 12 10C11.4696 10 10.9609 10.2107 10.5858 10.5858C10.2107 10.9609 10 11.4696 10 12ZM10 6C10 6.53043 10.2107 7.03914 10.5858 7.41421C10.9609 7.78929 11.4696 8 12 8C12.5304 8 13.0391 7.78929 13.4142 7.41421C13.7893 7.03914 14 6.53043 14 6C14 5.46957 13.7893 4.96086 13.4142 4.58579C13.0391 4.21071 12.5304 4 12 4C11.4696 4 10.9609 4.21071 10.5858 4.58579C10.2107 4.96086 10 5.46957 10 6ZM10 18C10 18.5304 10.2107 19.0391 10.5858 19.4142C10.9609 19.7893 11.4696 20 12 20C12.5304 20 13.0391 19.7893 13.4142 19.4142C13.7893 19.0391 14 18.5304 14 18C14 17.4696 13.7893 16.9609 13.4142 16.5858C13.0391 16.2107 12.5304 16 12 16C11.4696 16 10.9609 16.2107 10.5858 16.5858C10.2107 16.9609 10 17.4696 10 18Z" fill="#636363" />
                        </svg>

                    </div>

                    <div className='bd_project_list ' >
                        <div className='bd_project_image'>
                            <img src={ProjectImage} />
                            <div className='project_name'>
                                Project X
                            </div>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M10 12C10 12.5304 10.2107 13.0391 10.5858 13.4142C10.9609 13.7893 11.4696 14 12 14C12.5304 14 13.0391 13.7893 13.4142 13.4142C13.7893 13.0391 14 12.5304 14 12C14 11.4696 13.7893 10.9609 13.4142 10.5858C13.0391 10.2107 12.5304 10 12 10C11.4696 10 10.9609 10.2107 10.5858 10.5858C10.2107 10.9609 10 11.4696 10 12ZM10 6C10 6.53043 10.2107 7.03914 10.5858 7.41421C10.9609 7.78929 11.4696 8 12 8C12.5304 8 13.0391 7.78929 13.4142 7.41421C13.7893 7.03914 14 6.53043 14 6C14 5.46957 13.7893 4.96086 13.4142 4.58579C13.0391 4.21071 12.5304 4 12 4C11.4696 4 10.9609 4.21071 10.5858 4.58579C10.2107 4.96086 10 5.46957 10 6ZM10 18C10 18.5304 10.2107 19.0391 10.5858 19.4142C10.9609 19.7893 11.4696 20 12 20C12.5304 20 13.0391 19.7893 13.4142 19.4142C13.7893 19.0391 14 18.5304 14 18C14 17.4696 13.7893 16.9609 13.4142 16.5858C13.0391 16.2107 12.5304 16 12 16C11.4696 16 10.9609 16.2107 10.5858 16.5858C10.2107 16.9609 10 17.4696 10 18Z" fill="#636363" />
                        </svg>

                    </div>


                    <div className='bd_project_list ' >
                        <div className='bd_project_image'>
                            <img src={ProjectImage} />
                            <div className='project_name'>
                                Project X
                            </div>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M10 12C10 12.5304 10.2107 13.0391 10.5858 13.4142C10.9609 13.7893 11.4696 14 12 14C12.5304 14 13.0391 13.7893 13.4142 13.4142C13.7893 13.0391 14 12.5304 14 12C14 11.4696 13.7893 10.9609 13.4142 10.5858C13.0391 10.2107 12.5304 10 12 10C11.4696 10 10.9609 10.2107 10.5858 10.5858C10.2107 10.9609 10 11.4696 10 12ZM10 6C10 6.53043 10.2107 7.03914 10.5858 7.41421C10.9609 7.78929 11.4696 8 12 8C12.5304 8 13.0391 7.78929 13.4142 7.41421C13.7893 7.03914 14 6.53043 14 6C14 5.46957 13.7893 4.96086 13.4142 4.58579C13.0391 4.21071 12.5304 4 12 4C11.4696 4 10.9609 4.21071 10.5858 4.58579C10.2107 4.96086 10 5.46957 10 6ZM10 18C10 18.5304 10.2107 19.0391 10.5858 19.4142C10.9609 19.7893 11.4696 20 12 20C12.5304 20 13.0391 19.7893 13.4142 19.4142C13.7893 19.0391 14 18.5304 14 18C14 17.4696 13.7893 16.9609 13.4142 16.5858C13.0391 16.2107 12.5304 16 12 16C11.4696 16 10.9609 16.2107 10.5858 16.5858C10.2107 16.9609 10 17.4696 10 18Z" fill="#636363" />
                        </svg>

                    </div>
                </div>
                {/* ./bd_task_project_left_side */}

                <div className="bd-progress-head">
                    <div className='bd_task_project'>
                        <div className='bg_task_head'>
                            <div className='bd_progress_bar'>
                                <img src={ProjectImage} />
                                <div className='project_name_title'>
                                    <div className='project_title'>
                                        Project X
                                    </div>

                                    <Progress percent={50} status="active" className='prograss-bar' />
                                </div>
                            </div>

                            <div className='avtar_group'>
                                <Avatar.Group
                                    maxCount={2}
                                    maxStyle={{
                                        color: '#f56a00',
                                        backgroundColor: '#fde3cf',
                                    }}
                                >
                                    <Avatar src="https://xsgames.co/randomusers/avatar.php?g=pixel&key=2" />
                                    <Avatar
                                        style={{
                                            backgroundColor: '#f56a00',
                                        }}
                                    >
                                        K
                                    </Avatar>
                                    <Tooltip title="Ant User" placement="top">
                                        <Avatar
                                            style={{
                                                backgroundColor: '#87d068',
                                            }}
                                            icon={<UserOutlined />}
                                        />
                                    </Tooltip>
                                    <Avatar
                                        style={{
                                            backgroundColor: '#1677ff',
                                        }}
                                        icon={<AntDesignOutlined />}
                                    />
                                </Avatar.Group>

                                <button className='add_emp_btn'>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                        <path d="M13.1667 6.16634H8.16675V1.16634C8.16675 0.945327 8.07895 0.733366 7.92267 0.577086C7.76639 0.420805 7.55443 0.333008 7.33341 0.333008C7.1124 0.333008 6.90044 0.420805 6.74416 0.577086C6.58788 0.733366 6.50008 0.945327 6.50008 1.16634V6.16634H1.50008C1.27907 6.16634 1.06711 6.25414 0.910826 6.41042C0.754546 6.5667 0.666748 6.77866 0.666748 6.99967C0.666748 7.22069 0.754546 7.43265 0.910826 7.58893C1.06711 7.74521 1.27907 7.83301 1.50008 7.83301H6.50008V12.833C6.50008 13.054 6.58788 13.266 6.74416 13.4223C6.90044 13.5785 7.1124 13.6663 7.33341 13.6663C7.55443 13.6663 7.76639 13.5785 7.92267 13.4223C8.07895 13.266 8.16675 13.054 8.16675 12.833V7.83301H13.1667C13.3878 7.83301 13.5997 7.74521 13.756 7.58893C13.9123 7.43265 14.0001 7.22069 14.0001 6.99967C14.0001 6.77866 13.9123 6.5667 13.756 6.41042C13.5997 6.25414 13.3878 6.16634 13.1667 6.16634Z" fill="#636363" />
                                    </svg>
                                </button>

                            </div>

                        </div>
                    </div>
                    <div className='bd_tool_task'>
                        <Taskboard />
                    </div>
                </div>
                {/* ./bd-progress-head */}
            </div>

        </>
    )
}

export default TaskAssigine
