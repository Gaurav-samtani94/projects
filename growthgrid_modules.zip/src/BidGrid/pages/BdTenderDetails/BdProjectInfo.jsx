// @ts-nocheck
import React, { useEffect, useState, useMemo } from 'react'
import 'quill/dist/quill.snow.css'
import ReactQuill from 'react-quill';
import { Form, Select, Row, Col, Input, DatePicker, Divider, Collapse, Button, TimePicker, InputNumber, Modal, Upload, Table, Flex } from 'antd';
import { MinusCircleOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { Down, Right, ViewGridDetail, Info, FileExcel, Bookshelf, WalletThree } from '@icon-park/react';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { toast } from 'react-toastify';
import { useSelector } from 'react-redux';
import editBtn from '../../assets/images/icons/editbtn.png';
import deleteBtn from '../../assets/images/icons/deleteTable.png';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import dayjs from 'dayjs';
import { BankApi } from 'Services/bidgrid/master/bank/BidBank';
import { bgdetail } from 'Services/bidgrid/add/BG detail/BgdetailApi';
import moment from 'moment';
import 'dayjs/locale/fr'; // Import locale if not using the default locale
import { bidProspective } from 'Services/bidgrid/prospective/bidProspective';
import { AddTenderList } from 'Services/bidgrid/add/AddTender';
import { bidnationality } from 'Services/bidgrid/master/nationality/bidnationality';

const { Panel } = Collapse;


const initialstate = {
    basic_info: {
        tender_basic_details: {
            pre_bid_meeting_date: null,
            bid_validity_date: null,
            submission_start_date: null,
            submission_end_date: null,
            national_intern: null,
            client_id: null,
            funding_id: null,
            sector_id: null,
            country_id: null,
            state_id: null,
            city_id: null,
            tender_cost: '',
        }
    },
    tender_date: {
        tnd_published_date: null,
        tnd_published_time: null,
        bid_opening_date: null,
        bid_opening_time: null,
        doc_download_start_date: null,
        doc_download_start_time: null,
        doc_download_end_date: null,
        doc_download_end_time: null,
        clarification_start_date: null,
        clarification_start_time: null,
        clarification_end_date: null,
        clarification_end_time: null,
        bid_submission_start_date: null,
        bid_submission_start_time: null,
        bid_submission_end_date: null,
        bid_submission_end_time: null,
    },
    tender_emd: {
        emd_amount: '',
        currency: null,
        emd_fee_type: '',
        emd_payable_to: '',
        emd_payable_at: '',
        emd_percentage: '',
        emd_through_BG_ST_orEMD_exemption_allowed: '',
    },
    tender_feeinfo: {
        tnd_fee: '',
        currency: null,
        processing_fee: '',
        fee_payable_to: '',
        fee_payable_at: '',
        tnd_fee_exemption_allowed: null,
    }
}

const columnLabels = {
    cover_type: { name: 'Cover Type', required: true },
    description: { name: 'Description', required: true },
    doc_type: { name: 'Doc Type', required: true },

};


const ProjectInfo = ({ id, activeTabKey }) => {
    const { BidClient, BidFundingClientAgency, BidCurrency, BidCountry, BidLeadCompany, BidSector } = useSelector((state) => state.bidDropdownCalVal)
    const showActions = true;
    const [projectInfo, setProjectInfo] = useState(initialstate)
    const [inputVal, setInputVal] = useState({})
    const [projectCoverInfo, setProjectCoverInfo] = useState({
        cover_type: '',
        description: '',
        doc_type: '',
    })
    const [addOpenModal, setAddOpenModal] = useState(false)
    const [panelStates, setPanelStates] = useState({
        projectBasicDetail: true,
        projectInfoData: true,
        projectEmdDetail: true,
        projectFeeInfo: true,
        projectCoverInfo: true,
        // pbgAbgDetail: true,
        // keyDetails: false,
        // financialDetail: false
    });

    // bank state

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [form] = Form.useForm();
    const [form1] = Form.useForm();
    const [formDetail] = Form.useForm();
    const [formInfo] = Form.useForm();
    const [formemd] = Form.useForm();
    const [formfee] = Form.useForm();
    const [errorMessage, setErrorMessage] = useState("");
    const [showError, setShowError] = useState(false)

    const [statelist, setStateList] = useState([])
    const [cityList, setCityList] = useState([])
    const [nationalityList, setNationalityList] = useState([])

    const [errorsMsg, setErrorsMsg] = useState({
        tnd_published_date: false,
        tnd_published_time: false,
        bid_submission_start_date: false,
        bid_submission_start_time: false,
        bid_submission_end_date: false,
        bid_submission_end_time: false,
    });

    const [errorsBasicMsg, setErrorsBasicMsg] = useState(false)

    const [loadings, setLoadings] = useState({
        loadingBasic: false,
        loadingDate: false,
        loadingEmd: false,
        loadingFee: false,
        loadingCover: false,
    });

    const togglePanel = (panelKey) => {
        setPanelStates((prevState) => ({

            projectBasicDetail: false,
            projectInfoData: false,
            projectEmdDetail: false,
            projectFeeInfo: false,
            projectCoverInfo: false,
            pbgAbgDetail: false,
            keyDetails: false,
            financialDetail: false
            ,
            [panelKey]: !prevState[panelKey],
        }));
    };

    const handleChange = (name, value) => {
        if (name === "submission_end_date") {
            setErrorsBasicMsg(false)
        }

        if (name === "country_id") {
            setProjectInfo(prec => ({
                basic_info: {
                    tender_basic_details: {
                        ...prec?.basic_info?.tender_basic_details,
                        'state_id': '',
                        'city_id': ''
                    }
                }
            }))
            formDetail.setFieldsValue({
                state_id: '',
                city_id: ''
            });
        }
        if (name === "state_id") {
            setProjectInfo(prec => ({
                basic_info: {
                    tender_basic_details: {
                        ...prec?.basic_info?.tender_basic_details,
                        'city_id': ''
                    }
                }
            }))
        }
        setProjectInfo(prevState => ({
            ...prevState,
            basic_info: {
                tender_basic_details: {
                    ...prevState?.basic_info?.tender_basic_details,
                    [name]: value
                }

            },
            tender_date: {
                ...prevState?.tender_date,
                [name]: value
            },
            tender_emd: {
                ...prevState?.tender_emd,
                [name]: value
            },
            tender_feeinfo: {
                ...prevState?.tender_feeinfo,
                [name]: value
            }

        }));

        setErrorsMsg(prevErrorsMsg => ({
            ...prevErrorsMsg,
            [name]: false
        }));
    }

    // nationality api

    const getNationality = async () => {
        try {
            const response = await bidnationality.getnationality()
            if (response?.data?.status == 1) {
                if (response?.data?.data?.length > 0) {
                    setNationalityList(response?.data?.data?.sort((a, b) => a?.unit_name?.localeCompare(b?.unit_name)))
                } else {
                    setNationalityList([])
                }
            }
        } catch (error) {
            setNationalityList([])
            console.log(error, 'api erorr')
        }
    }

    // state api
    const getState = async () => {
        const formData = new URLSearchParams()
        formData.append('country_id', projectInfo?.basic_info?.tender_basic_details?.country_id)
        try {
            const res = await bidProspective.getStateList(formData)
            if (res?.data?.status === '1') {
                setStateList(res?.data?.data)
            } else {
                setStateList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    // city api
    const getCity = async () => {
        const formData = new URLSearchParams()
        formData.append('state_id', projectInfo?.basic_info?.tender_basic_details?.state_id)
        try {
            const res = await AddTenderList.getTenderCityList(formData)
            if (res?.data?.status === '1') {
                setCityList(res?.data?.data)
            } else {
                setCityList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    useEffect(() => {
        if (projectInfo?.basic_info?.tender_basic_details?.country_id !== null) {
            getState()
        }
    }, [projectInfo?.basic_info?.tender_basic_details?.country_id])

    useEffect(() => {
        if (projectInfo?.basic_info?.tender_basic_details?.state_id !== null) {
            getCity()
        }
    }, [projectInfo?.basic_info?.tender_basic_details?.state_id])

    const handleCoverChange = (e) => {
        // console.log(name,value , "name+value")
        const { name, value } = e.target;
        if (name === 'doc_type') {
            if (!value.startsWith('.')) {
                setErrorMessage("Doc Type must start with a dot.");
                setShowError(true);
            } else if (value.includes(' ')) {
                setErrorMessage("Spaces are not allowed after the dot.");
                setShowError(true);
            } else {
                setErrorMessage("");
                setShowError(false);
                setProjectCoverInfo({ ...projectCoverInfo, [name]: value });
            }
        }
        else {
            setProjectCoverInfo({ ...projectCoverInfo, [name]: value });
        }
    };

    const validateDocType = (_, value) => {
        const minLength = 1; // You might want to adjust this based on your requirements
        const startsWithDotRegex = /^\./;
        const spaceAfterDotRegex = /^\.\s/;

        if (!value) {
            return Promise.reject('');
        }

        if (value.length < minLength) {
            return Promise.reject('Doc Type must have at least 1 character');
        }

        if (!startsWithDotRegex.test(value)) {
            return Promise.reject('Doc Type must start with a dot');
        }

        if (spaceAfterDotRegex.test(value)) {
            return Promise.reject('Dot must not be followed by a space');
        }

        return Promise.resolve();
    };
    const handleProjectInfoData = async () => {
        const formData = new URLSearchParams();
        formData.append('project_id', id);
        try {
            const response = await TenderApi.projectInfoData(formData)
            if (response?.data?.status === '1') {
                setInputVal(response?.data?.data)

            } else {
                console.log(response?.response?.data?.message)
            }

        } catch (error) {

            console.log(error, "else")

        }
    }
    useEffect(() => {
        if (activeTabKey === '3') {
            handleProjectInfoData()
        }

    }, [activeTabKey])

    // function updateTheState(obj, module) {
    //     console.log(obj, 'obj')
    //     console.log(module, 'module')

    //     Object?.entries(obj)?.map(([key, value]) => {
    //         setProjectInfo(prevState => ({
    //             ...prevState,
    //             [module]: {
    //                 ...prevState?.[module],
    //                 [key]: value
    //             },
    //         }));

    //     })
    //     return
    // }
    function updateTheState(obj, module) {
        if (module === "basic_info") {
            formDetail.setFieldsValue(obj);
            Object?.entries(obj)?.map(([key, value]) => {
                // setProjectInfo(prevState => ({
                //     ...prevState,
                //     'basic_info': {
                //         ...prevState['basic_info'],
                //         [key]: value
                //     },
                // }));

                //     let newObj = {
                //         [key]:obj[key]
                //     }
                //     const submissionEndDate = new Date(newObj?.submission_end_date);
                //     const formattedDate = `${submissionEndDate.getUTCFullYear()}/${(submissionEndDate.getUTCMonth() + 1).toString().padStart(2, '0')}/${submissionEndDate.getUTCDate().toString().padStart(2, '0')}`;
                //    console.log(newObj, 'newObj')
                setProjectInfo(prevState => ({
                    ...prevState,
                    basic_info: {
                        ...prevState.basic_info,
                        tender_basic_details: {
                            ...prevState.basic_info.tender_basic_details,
                            [key]: value
                        }
                    }
                }));

            })
        }
        if (module === 'tender_feeinfo') {
            formfee.setFieldsValue(obj);
            Object?.entries(obj)?.map(([key, value]) => {
                setProjectInfo(prevState => ({
                    ...prevState,
                    'tender_feeinfo': {
                        ...prevState['tender_feeinfo'],
                        [key]: value
                    },
                }));
            })
        }
        if (module === 'tender_emd') {
            formemd.setFieldsValue(obj);
            Object?.entries(obj)?.map(([key, value]) => {
                setProjectInfo(prevState => ({
                    ...prevState,
                    'tender_emd': {
                        ...prevState['tender_emd'],
                        [key]: value
                    },
                }));
            })
        }

        if (module === 'tender_date') {
            Object?.entries(obj)?.map(([key, value]) => {
                setProjectInfo(prevState => ({
                    ...prevState,
                    'tender_date': {
                        ...prevState['tender_date'],
                        [key]: value
                    },
                }));
            })
        }


    }
    useEffect(() => {
        if (inputVal?.basic_info !== null && inputVal?.basic_info !== undefined) {
            updateTheState(inputVal?.basic_info?.tender_basic_details, 'basic_info')
        } else {
            formDetail.setFieldValue(prevState => ({
                ...prevState,
                basic_info: initialstate?.basic_info,
            }));

            setProjectInfo(prevState => ({
                ...prevState,
                basic_info: initialstate.basic_info // Assuming basic_info contains tender_basic_details
            }));
        }

        if (inputVal?.tender_date !== null && inputVal?.tender_date !== undefined) {
            updateTheState(inputVal?.tender_date, 'tender_date')
        } else {
            formInfo.setFieldValue(prevState => ({
                ...prevState,
                tender_date: initialstate?.tender_date,
            }));

            setProjectInfo(prevState => ({
                ...prevState,
                tender_date: initialstate?.tender_date,
            }));
        }

        if (inputVal?.tender_emd !== null && inputVal?.tender_emd !== undefined) {
            updateTheState(inputVal?.tender_emd, 'tender_emd')
        } else {
            setProjectInfo(prevState => ({
                ...prevState,
                tender_emd: initialstate?.tender_emd,
            }));
            formemd.setFieldValue(prevState => ({
                ...prevState,
                tender_emd: initialstate?.tender_emd,
            }));
        }

        if (inputVal?.tender_feeinfo !== null && inputVal?.tender_feeinfo !== undefined) {

            updateTheState(inputVal?.tender_feeinfo, 'tender_feeinfo')
        } else {
            setProjectInfo(prevState => ({
                ...prevState,
                tender_feeinfo: initialstate?.tender_feeinfo,
            }));
            formfee.setFieldValue(prevState => ({
                ...prevState,
                tender_feeinfo: initialstate?.tender_feeinfo,
            }));
        }

    }, [inputVal])


    const coverInfoTableData = useMemo(() => {
        return inputVal?.tender_cover_info;
    }, [inputVal]);

    const handleLoading = (key, value) => {
        setLoadings(prevLoadings => ({
            ...prevLoadings,
            [key]: value
        }));
    };

    // add project besic detail
    const handleBasicDetail = async (value) => {
        if (projectInfo?.basic_info?.tender_basic_details?.submission_end_date === null) {
            setErrorsBasicMsg(true)
        } else {
            handleLoading('loadingBasic', true);
            const formData = new URLSearchParams();
            formData.append('project_id', id);
            formData.append('prebid_meeting_date', projectInfo?.basic_info?.tender_basic_details?.pre_bid_meeting_date !== null ? dayjs(projectInfo?.basic_info?.tender_basic_details?.pre_bid_meeting_date)?.format("YYYY-MM-DD") : null);
            formData.append('bid_validity_date', projectInfo?.basic_info?.tender_basic_details?.bid_validity_date !== null ? dayjs(projectInfo?.basic_info?.tender_basic_details?.bid_validity_date)?.format("YYYY-MM-DD") : null);
            formData.append('submission_start_date', projectInfo?.basic_info?.tender_basic_details?.submission_start_date ? dayjs(projectInfo?.basic_info?.tender_basic_details?.submission_start_date)?.format('YYYY-MM-DD') : '');
            formData.append('submission_end_date', dayjs(projectInfo?.basic_info?.tender_basic_details?.submission_end_date)?.format('YYYY-MM-DD'));
            formData.append('client', value?.client_id);
            formData.append('funding_agency', projectInfo?.basic_info?.tender_basic_details?.funding_id !== null ? projectInfo?.basic_info?.tender_basic_details?.funding_id : '');
            formData.append('sector', value?.sector_id);
            formData.append('country', value?.country_id);
            formData.append('state', value?.state_id);
            formData.append('tender_estimated_cost', value?.tender_cost);
            formData.append('city', projectInfo?.basic_info?.tender_basic_details?.city_id !== null ? projectInfo?.basic_info?.tender_basic_details?.city_id : null);
            try {
                const response = await TenderApi.projectBasicDetail(formData)
                if (response?.data?.status === '1') {
                    notifySuccess('Basic Detail Update Successfully')
                    handleLoading('loadingBasic', false);
                    await handleProjectInfoData()
                } else {
                    notify(response?.response?.data?.message)
                    handleLoading('loadingBasic', false);
                }

            } catch (error) {
                handleLoading('loadingBasic', false);
                console.log(error, "else")

            }
        }

    };
    // add project info date
    const handleProjectInfo = async () => {
        const requiredFields = ['tnd_published_date', 'tnd_published_time', 'bid_submission_start_date', 'bid_submission_start_time', 'bid_submission_end_date', 'bid_submission_end_time'];

        let isAnyFieldEmpty = false;

        for (const key of requiredFields) {
            if (!projectInfo?.tender_date[key]) {
                isAnyFieldEmpty = true;
                break;
            }
        }

        if (isAnyFieldEmpty) {
            setErrorsMsg(prevErrorsMsg => ({
                ...prevErrorsMsg,
                tnd_published_date: !projectInfo?.tender_date?.tnd_published_date,
                tnd_published_time: !projectInfo?.tender_date?.tnd_published_time,
                bid_submission_start_date: !projectInfo?.tender_date?.bid_submission_start_date,
                bid_submission_start_time: !projectInfo?.tender_date?.bid_submission_start_time,
                bid_submission_end_date: !projectInfo?.tender_date?.bid_submission_end_date,
                bid_submission_end_time: !projectInfo?.tender_date?.bid_submission_end_time,
            }));
            return;
        }
        else {
            handleLoading('loadingDate', true);
            const formData = new URLSearchParams();
            formData.append('project_id', id);
            formData.append('tnd_published_date', dayjs(projectInfo?.tender_date?.tnd_published_date).format('YYYY-MM-DD'));
            formData.append('tnd_published_time', dayjs(projectInfo?.tender_date?.tnd_published_time, 'HH:mm:ss').format('HH:mm:ss'));
            formData.append('bid_opening_date', projectInfo?.tender_date?.bid_opening_date ? dayjs(projectInfo?.tender_date?.bid_opening_date).format('YYYY-MM-DD') : '');
            formData.append('bid_opening_time', projectInfo?.tender_date?.bid_opening_time ? dayjs(projectInfo?.tender_date?.bid_opening_time, 'HH:mm:ss').format('HH:mm:ss') : '');
            formData.append('doc_download_start_date', projectInfo?.tender_date?.doc_download_start_date ? dayjs(projectInfo?.tender_date?.doc_download_start_date).format('YYYY-MM-DD') : '');
            formData.append('doc_download_start_time', projectInfo?.tender_date?.doc_download_start_time ? dayjs(projectInfo?.tender_date?.doc_download_start_time, 'HH:mm:ss').format('HH:mm:ss') : '');
            formData.append('doc_download_end_date', projectInfo?.tender_date?.doc_download_end_date ? dayjs(projectInfo?.tender_date?.doc_download_end_date).format('YYYY-MM-DD') : '');
            formData.append('doc_download_end_time', projectInfo?.tender_date?.doc_download_end_time ? dayjs(projectInfo?.tender_date?.doc_download_end_time, 'HH:mm:ss').format('HH:mm:ss') : '');
            formData.append('clarification_start_date', projectInfo?.tender_date?.clarification_start_date ? dayjs(projectInfo?.tender_date?.clarification_start_date).format('YYYY-MM-DD') : '');
            formData.append('clarification_start_time', projectInfo?.tender_date?.clarification_start_time ? dayjs(projectInfo?.tender_date?.clarification_start_time, 'HH:mm:ss').format('HH:mm:ss') : '');
            formData.append('clarification_end_date', projectInfo?.tender_date?.clarification_end_date ? dayjs(projectInfo?.tender_date?.clarification_end_date).format('YYYY-MM-DD') : '');
            formData.append('clarification_end_time', projectInfo?.tender_date?.clarification_end_time ? dayjs(projectInfo?.tender_date?.clarification_end_time, 'HH:mm:ss').format('HH:mm:ss') : '');
            formData.append('bid_submission_start_date', dayjs(projectInfo?.tender_date?.bid_submission_start_date).format('YYYY-MM-DD'));
            formData.append('bid_submission_start_time', dayjs(projectInfo?.tender_date?.bid_submission_start_time, 'HH:mm:ss').format('HH:mm:ss'));
            formData.append('bid_submission_end_date', dayjs(projectInfo?.tender_date?.bid_submission_end_date).format('YYYY-MM-DD'));
            formData.append('bid_submission_end_time', dayjs(projectInfo?.tender_date?.bid_submission_end_time, 'HH:mm:ss').format('HH:mm:ss'));

            try {
                const response = await TenderApi.projectInfo(formData);
                if (response?.data?.status === '1') {
                    notifySuccess("Date Update Successfully");
                    handleLoading('loadingDate', false);
                    await handleProjectInfoData();
                } else {
                    notify(response?.response?.data?.message);
                    handleLoading('loadingDate', false);
                }
            } catch (error) {
                console.log(error, "catch");
                handleLoading('loadingDate', false);
            }
        }

    };


    // add project info Emd
    const handleProjectEmd = async (value) => {
        handleLoading('loadingEmd', true);
        const formData = new URLSearchParams();
        formData.append('project_id', id);
        formData.append('emd_amount', value?.emd_amount);
        formData.append('currency', projectInfo?.tender_emd?.currency !== null ? projectInfo?.tender_emd?.currency : '');
        formData.append('emd_fee_type', projectInfo?.tender_emd?.emd_fee_type !== null ? projectInfo?.tender_emd?.emd_fee_type : '');
        formData.append('emd_payable_to', projectInfo?.tender_emd?.emd_payable_to !== null ? projectInfo?.tender_emd?.emd_payable_to : '');
        formData.append('emd_payable_at', projectInfo?.tender_emd?.emd_payable_at !== null ? projectInfo?.tender_emd?.emd_payable_at : '');
        formData.append('emd_percentage', projectInfo?.tender_emd?.emd_percentage !== null ? projectInfo?.tender_emd?.emd_percentage : '');
        formData.append('emd_through_BG_ST_orEMD_exemption_allowed', projectInfo?.tender_emd?.emd_through_BG_ST_orEMD_exemption_allowed !== null ? projectInfo?.tender_emd?.emd_through_BG_ST_orEMD_exemption_allowed : '');

        try {
            const response = await TenderApi.projectEmdData(formData)
            if (response?.data?.status === '1') {
                notifySuccess('Project Emd Update Successfully')
                handleLoading('loadingEmd', false);
                await handleProjectInfoData()
            } else {
                notify(response?.response?.data?.message)
                handleLoading('loadingEmd', false);
            }

        } catch (error) {
            handleLoading('loadingEmd', false);
            console.log(error, "else")

        }

    }
    // add project fee info
    const handleProjectFeeInfo = async () => {
        handleLoading('loadingFee', true);
        const formData = new URLSearchParams();
        formData.append('project_id', id);
        formData.append('tnd_fee', projectInfo?.tender_feeinfo?.tnd_fee !== null ? projectInfo?.tender_feeinfo?.tnd_fee : '');
        formData.append('currency', projectInfo?.tender_feeinfo?.currency !== null ? projectInfo?.tender_feeinfo?.currency : '');
        formData.append('processing_fee', projectInfo?.tender_feeinfo?.processing_fee !== null ? projectInfo?.tender_feeinfo?.processing_fee : '');
        formData.append('fee_payable_to', projectInfo?.tender_feeinfo?.fee_payable_to !== null ? projectInfo?.tender_feeinfo?.fee_payable_to : '');
        formData.append('fee_payable_at', projectInfo?.tender_feeinfo?.fee_payable_at !== null ? projectInfo?.tender_feeinfo?.fee_payable_at : '');
        formData.append('tnd_fee_exemption_allowed', projectInfo?.tender_feeinfo?.tnd_fee_exemption_allowed !== null ? projectInfo?.tender_feeinfo?.tnd_fee_exemption_allowed : null);

        try {
            const response = await TenderApi.projectFeeInfo(formData)
            if (response?.data?.status === '1') {
                notifySuccess('Project Fee Info Update Successfully')
                handleLoading('loadingFee', false);
                await handleProjectInfoData()
            } else {
                notify(response?.response?.data?.message)
                handleLoading('loadingFee', false);
            }

        } catch (error) {
            handleLoading('loadingFee', false);
            console.log(error, "else")

        }

    }

    // add project cover info
    const handleProjectCoverInfo = async (value) => {
        handleLoading('loadingCover', true);
        if (projectCoverInfo?.bg_tender_id) {
            try {
                const formData = new URLSearchParams();
                formData.append('cover_id', projectCoverInfo?.id);
                formData.append('project_id', id);
                formData.append('cover_type', value?.cover_type);
                formData.append('description', value?.description);
                formData.append('doc_type', value?.doc_type);
                const response = await TenderApi.editProjectCoverInfo(formData);
                if (response?.data?.status == 1) {
                    notifySuccess('Project Cover Update Successfully')
                    handleLoading('loadingCover', false);
                    setLoadings(false)
                    await handleProjectInfoData()
                    setAddOpenModal(false)
                    form1.resetFields()
                } else {
                    notify(response?.response?.data?.message);
                    setAddOpenModal(true)
                    setLoadings(false)
                    handleLoading('loadingCover', false);
                    form1.resetFields()
                }
            } catch (error) {
                form1.resetFields()
                console.log(error, "Api");
                setLoadings(false)
                handleLoading('loadingCover', false);
            }
        } else {

            // if (projectCoverInfo?.cover_type !== '' && projectCoverInfo?.description !== '' && projectCoverInfo?.doc_type !== '') {
            const formData = new URLSearchParams();
            formData.append('project_id', id);
            formData.append('cover_type', value?.cover_type);
            formData.append('description', value?.description);
            formData.append('doc_type', value?.doc_type);
            try {
                const response = await TenderApi.projectCoverInfo(formData)
                if (response?.data?.status === '1') {
                    notifySuccess(response?.data?.message)
                    setLoadings(false)
                    await handleProjectInfoData()
                    setProjectCoverInfo({
                        cover_type: '',
                        description: '',
                        doc_type: '',
                    });
                    setAddOpenModal(false)
                    form1.resetFields()
                } else {
                    notify(response?.response?.data?.message)
                    setAddOpenModal(true)
                    setLoadings(false)
                }
            } catch (error) {
                console.log(error, "else")
                setLoadings(false)
            }
            // } else {
            //     notify('All fields are required')
            // }
        }

    }

    // edit project cover info

    // const handleUpdate = async (val) => {
    //     try {
    //         const formData = new URLSearchParams();
    //         formData.append('cover_id', val?.id);
    //         formData.append('project_id', id);
    //         formData.append('cover_type', val?.cover_type);
    //         formData.append('description', val?.description);
    //         formData.append('doc_type', val?.doc_type);
    //         const response = await TenderApi.editProjectCoverInfo(formData);
    //         if (response?.data?.status == 1) {
    //             notifySuccess(response?.data?.message)
    //             await handleProjectInfoData()
    //         } else {
    //             notify(response?.response?.data?.message);
    //         }
    //     } catch (error) {
    //         console.log(error, "Api");
    //     }
    // };

    // delete project cover info


    const handleDelete = async (val) => {
        const formData = new URLSearchParams();
        formData.append('project_id', id);
        formData.append('cover_id', val);

        try {
            const response = await TenderApi.deleteProjectCoverInfo(formData);
            if (response?.data?.status == 1) {
                notifySuccess(response?.data?.message);
                await handleProjectInfoData()
            } else {
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            console.log(error, "Api");
        }
    };


    const getPropDataVal = (record, status) => {
        setProjectCoverInfo(record)
        // form1.setFieldValue(record)
        form1.setFieldsValue({
            cover_type: record.cover_type,
            description: record.description,
            doc_type: record.doc_type
        });
        setAddOpenModal(status)
    }

    // Reset filleds

    const handleResetBasicDetail = () => {

        setProjectInfo(prev => ({
            ...prev,
            basic_info: {
                tender_basic_details: {
                    pre_bid_meeting_date: null,
                    bid_validity_date: null,
                    submission_start_date: null,
                    submission_end_date: null,
                    national_intern: null,
                    client_id: null,
                    funding_id: null,
                    sector_id: null,
                    country_id: null,
                    state_id: null,
                    city_id: null,
                    tender_cost: '',
                }

            },
        }))
        formDetail?.resetFields()
        setErrorsBasicMsg(false)
    }
    const resetProjectInfo = () => {
        setProjectInfo(prevState => ({
            ...prevState,
            tender_date: {
                tnd_published_date: null,
                tnd_published_time: null,
                bid_opening_date: null,
                bid_opening_time: null,
                doc_download_start_date: null,
                doc_download_start_time: null,
                doc_download_end_date: null,
                doc_download_end_time: null,
                clarification_start_date: null,
                clarification_start_time: null,
                clarification_end_date: null,
                clarification_end_time: null,
                bid_submission_start_date: null,
                bid_submission_start_time: null,
                bid_submission_end_date: null,
                bid_submission_end_time: null,
            },
        }));
        setErrorsMsg(prevState => ({
            ...prevState,
            tnd_published_date: false,
            tnd_published_time: false,
            bid_submission_start_date: false,
            bid_submission_start_time: false,
            bid_submission_end_date: false,
            bid_submission_end_time: false,
        }));
    }
    const resetEmdInfo = () => {
        setProjectInfo(prevState => ({
            ...prevState,
            tender_emd: {
                emd_amount: '',
                currency: null,
                emd_fee_type: '',
                emd_payable_to: '',
                emd_payable_at: '',
                emd_percentage: '',
                emd_through_BG_ST_orEMD_exemption_allowed: '',
            }
        }));
        formemd.resetFields();
    }
    const resetFeeInfo = () => {
        setProjectInfo(prevState => ({
            ...prevState,
            tender_feeinfo: {
                tnd_fee: '',
                currency: null,
                processing_fee: '',
                fee_payable_to: '',
                fee_payable_at: '',
                tnd_fee_exemption_allowed: '',
            }
        }));
        formfee.resetFields();
    }


    const handleModalAdd = () => {
        setAddOpenModal(true)
    }

    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            //  handleProjectInfo()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleKeyPressSelectedItem = (e) => {
        // const alphabeticChars = /[a-zA-Z]/;
        const allowedChars = /[0-9/]/;
        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        }
        else if (e.key === 'Enter') {
            e.preventDefault();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleKeyContainOnlyNumbers = (e) => {
        const allowedChars = /[0-9.]/;
        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        }
        else if (e.key === 'Enter') {
            e.preventDefault();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    }

    const exceptSymbol = ['e', 'E', '+', '-', '.'];

    const handleEmployeeChange = (name, e) => {
        const trimmedValue = e.target.value.trimStart(); // Trim leading spaces
        form1.setFieldsValue({ [name]: trimmedValue }); //
    };

    // useEffect(() => {
    //     getNationality()
    // }, [])

    const basicDetaildate = () => {
        if (projectInfo?.basic_info?.tender_basic_details?.submission_end_date === null) {
            setErrorsBasicMsg(true)
        }
        else {
            setErrorsBasicMsg(false)
        }
    }

    return (
        <div className='bid_projectInfo'>

            <Collapse onChange={() => togglePanel('projectBasicDetail')} defaultActiveKey={1} >
                <Panel
                    key="1"
                    header={
                        <div className='collapse_flex'>
                            <div className="d-flex">
                                <div className="iconBox">
                                    <ViewGridDetail theme="outline" size="22" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                </div>
                                Basic Details
                            </div>
                            {panelStates?.projectBasicDetail ?
                                <Down theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                :
                                <Right theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                            }
                        </div>
                    }
                >
                    <div className="project_info_form">
                        <div className="tender_profile_fields">
                            <div className="profile_fields_name">
                                <span>Pre-Bid Meeting Date :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Bid Validity Date :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Bid Submission Start Date :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Bid Submission End Date :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Client :</span>
                                <p>Chhattisgarh Police Housing Corporation Ltd (CGPHC)</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Funding Agency :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Sector :</span>
                                <p>Road and Highway Tenders</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Country :</span>
                                <p>Iceland</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>State :</span>
                                <p>Andaman And Nicobar Islands</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>City :</span>
                                <p>Howraghat</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Tender Estimated Cost :</span>
                                <p>₹24510</p>
                            </div>
                        </div>
                        <div className='bd_model_button info_btn'>
                            <Button className='BG_mainButton' type="primary">
                                Edit
                            </Button>
                        </div>
                        <Form
                            style={{ display: "none" }}
                            form={formDetail}
                            layout="vertical"
                            onFinish={handleBasicDetail}
                            autoComplete='off'
                            name="control-hooks">
                            <Row gutter={20}>
                                <Col sm={6}>
                                    {/* <Form.Item label="Pre Bid Meeting" rules={[{ required: true, message: 'Reminder subject is required' }]}>
                                        <DatePicker
                                            // name='reminder_subject'
                                            // placeholder='dd/mm/yyyy'
                                            // onChange={(e) => handleChange(e, 'pre_bid_meeting')}
                                            // value={projectInfo?.basic_info?.pre_bid_meeting_date}

                                            placeholder='dd/mm/yyyy'
                                            name='pre_bid_meeting_date'
                                            type="date"
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.basic_info?.tender_basic_details !== null && projectInfo?.basic_info?.tender_basic_details?.pre_bid_meeting_date !== null ? dayjs(projectInfo?.basic_info?.tender_basic_details.pre_bid_meeting_date) : null}
                                            onChange={(e) => handleChange('pre_bid_meeting_date', e)}
                                        />
                                    </Form.Item> */}
                                    <Form.Item label="Pre-Bid Meeting Date">
                                        <DatePicker
                                            placeholder='dd/mm/yyyy'
                                            name='pre_bid_meeting_date'
                                            type="date"
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.basic_info?.tender_basic_details?.pre_bid_meeting_date !== null ? dayjs(projectInfo.basic_info?.tender_basic_details.pre_bid_meeting_date) : null}
                                            onChange={(e) => handleChange('pre_bid_meeting_date', e)}
                                        />
                                    </Form.Item>

                                </Col>
                                <Col sm={6}>
                                    <Form.Item label='Bid Validity Date' >
                                        <DatePicker
                                            placeholder='dd/mm/yyyy'
                                            name='bid_validity_date'
                                            type="date"
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.basic_info?.tender_basic_details !== null && projectInfo?.basic_info?.tender_basic_details?.bid_validity_date !== null && projectInfo?.basic_info?.tender_basic_details?.bid_validity_date !== null ? dayjs(projectInfo?.basic_info?.tender_basic_details?.bid_validity_date) : null}
                                            onChange={(e) => handleChange('bid_validity_date', e)}

                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label="Bid Submission Start Date" rules={[{ required: true, message: 'Please select Bid submission start date' }]}>
                                        <DatePicker
                                            placeholder='dd/mm/yyyy'
                                            name='submission_start_date'
                                            type="date"
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.basic_info?.tender_basic_details !== null && projectInfo?.basic_info?.tender_basic_details !== null && projectInfo?.basic_info?.tender_basic_details?.submission_start_date !== null ? dayjs(projectInfo?.basic_info?.tender_basic_details?.submission_start_date) : null}
                                            onChange={(e) => handleChange('submission_start_date', e)}
                                        // disabledDate={(current) => current && current < dayjs().startOf('day')}
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label={<span><span style={{ color: '#ff4d4f' }}>*</span>Bid Submission End Date</span>}>
                                        <DatePicker
                                            placeholder='dd/mm/yyyy'
                                            name='submission_end_date'
                                            type="date"
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.basic_info?.tender_basic_details !== null && projectInfo?.basic_info?.tender_basic_details?.submission_end_date !== null ? dayjs(projectInfo?.basic_info?.tender_basic_details?.submission_end_date) : null}
                                            onChange={(e) => handleChange('submission_end_date', e)}
                                        // disabledDate={(current) => current && current < dayjs().startOf('day')}
                                        />
                                        {errorsBasicMsg ? <div className="col-md-12" style={{ color: '#ff4d4f' }}>Please Select a Published Date</div> : ''}
                                    </Form.Item>
                                </Col>
                                {/* <Col sm={6}>
                                    <Form.Item label='Location' >
                                        <Select
                                            showSearch
                                            value={projectInfo?.basic_info?.tender_basic_details?.national_intern}
                                            onChange={(value) => handleChange('national_intern', value)}
                                            name='national_intern'
                                            options={nationalityList?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.nationality_name
                                                }
                                            })}
                                            placeholder="Select national"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        />
                                    </Form.Item>
                                </Col> */}
                                <Col sm={6}>
                                    {/* <Form.Item label='Client' name='client_id' rules={[{ required: true, message: 'Please select client ' }]}> */}
                                    <Form.Item label='Client' name='client_id' rules={[{ required: true, message: 'Please select client ' }]}>

                                        <Select
                                            allowClear
                                            showSearch
                                            value={projectInfo?.basic_info?.tender_basic_details?.client_id}
                                            onChange={(value) => handleChange('client_id', value)}
                                            // name='client_id'
                                            options={BidClient?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.client_name
                                                }
                                            })}
                                            placeholder="Select Funding"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label='Funding Agency' >
                                        {/* <Select placeholder="Select Here" suffixIcon={<Down theme="outline" size="18" fill="#747474" />} /> */}
                                        <Select
                                            allowClear
                                            showSearch
                                            value={projectInfo?.basic_info?.tender_basic_details?.funding_id}
                                            onChange={(value) => handleChange('funding_id', value)}
                                            name='funding_id'
                                            options={BidFundingClientAgency?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.funding_org_name
                                                }
                                            })}
                                            placeholder="Select Funding"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label='Sector' name='sector_id' rules={[{ required: true, message: 'Please select client ' }]}>
                                        {/* <Select placeholder="Select Here" suffixIcon={<Down theme="outline" size="18" fill="#747474" />} /> */}
                                        <Select
                                            allowClear
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder='Enter Here'
                                            options={BidSector?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.sector_name
                                                }
                                            })}
                                            name='sector_id'
                                            onChange={(value) => handleChange('sector_id', value)}

                                            value={projectInfo?.basic_info?.tender_basic_details?.sector_id}
                                            // onChange={(value) => handleSelectChange('sector_id', value)}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label='Country' name='country_id' rules={[{ required: true, message: 'Please select country ' }]}>
                                        {/* <Select placeholder="Select Here" suffixIcon={<Down theme="outline" size="18" fill="#747474" />} /> */}
                                        <Select
                                            allowClear
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder='Select Country'
                                            options={BidCountry?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.country_name
                                                }
                                            })}
                                            // name='country_id'
                                            onChange={(value) => handleChange('country_id', value)}

                                            value={projectInfo?.basic_info?.tender_basic_details?.country_id}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label='State' name='state_id' rules={[{ required: true, message: 'Please select state ' }]}>
                                        {/* <Select placeholder="Select Here" suffixIcon={<Down theme="outline" size="18" fill="#747474" />} /> */}
                                        <Select
                                            allowClear
                                            placeholder='Select State'
                                            showSearch
                                            // optionFilterProp="children"
                                            name='state_id'
                                            options={statelist?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.state_name
                                                }
                                            })}
                                            onChange={(value) => handleChange('state_id', value)}
                                            value={projectInfo?.basic_info?.tender_basic_details?.state_id}
                                            // onChange={(value) => handleSelectChange('state_id', value)}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label='City' >
                                        {/* <Select placeholder="Select Here" suffixIcon={<Down theme="outline" size="18" fill="#747474" />} /> */}
                                        <Select
                                            allowClear
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder='Select city'
                                            name='city_id'
                                            options={cityList?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.city_name
                                                }
                                            })}
                                            onChange={(value) => handleChange('city_id', value)}
                                            value={projectInfo?.basic_info?.tender_basic_details?.city_id}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label='Tender Estimated Cost' name='tender_cost' rules={[{ required: true, message: 'Please type Tender Estimated Cost ' }]} onKeyPress={handleKeyContainOnlyNumbers}>
                                        <Input
                                            type='number' placeholder='Enter Here'
                                            value={projectInfo?.basic_info?.tender_basic_details?.tender_cost}
                                            name='tender_cost'
                                            onChange={(e) => handleChange('tender_cost', e?.target?.value.replace(/[^0-9.]/g, ''))}
                                        />
                                    </Form.Item>
                                </Col>
                                {/* <Col sm={6}>
                                    <Form.Item label='Earnest Money Deposite' >
                                        <Input type='text' value={resetBasicDetail?.money_deposite} defaultValue={500000} placeholder='Enter here...' onChange={(e) => handleBasicDetail(e, 'money_deposite')} />
                                    </Form.Item>
                                </Col> */}
                            </Row>
                            <div className='bd_model_button info_btn'>
                                <Button key="back" className='BG_ghostButton' onClick={handleResetBasicDetail}>
                                    Reset
                                </Button>
                                <Button key="submit" className='BG_mainButton' type="primary" htmlType="submit" loading={loadings?.loadingBasic} disabled={loadings?.loadingBasic} onClick={basicDetaildate}>
                                    Save & Update
                                </Button>
                            </div>
                        </Form>
                    </div>
                </Panel>
            </Collapse>

            <Collapse onChange={() => togglePanel('projectEmdDetail')} defaultActiveKey={1}>
                <Panel
                    key="1"
                    header={
                        <div className='collapse_flex'>
                            <div className="d-flex">
                                <div className="iconBox">
                                    <FileExcel theme="outline" size="22" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                </div>
                                EMD Details
                            </div>
                            {panelStates?.projectEmdDetail ?
                                <Down theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                :
                                <Right theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                            }
                        </div>
                    }
                >
                    <div className="project_info_form">
                        <div className="tender_profile_fields">
                            <div className="profile_fields_name">
                                <span>EMD Amount :</span>
                                <p>₹5,000</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Currency :</span>
                                <p>Rupee</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>EMD Fee Type :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>EMD Payable To :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>EMD Payable At :</span>
                                <p>Chhattisgarh Police Housing Corporation Ltd (CGPHC)</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>EMD Percentage :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>EMD Exemption :</span>
                                <p>yes</p>
                            </div>
                        </div>
                        <div className='bd_model_button info_btn'>
                            <Button className='BG_mainButton' type="primary">
                                Edit
                            </Button>
                        </div>
                        <Form
                            style={{ display: "none" }}
                            form={formemd}
                            layout="vertical"
                            onFinish={handleProjectEmd}
                            autoComplete='off'
                            name="control-hooks"
                        >
                            <Row gutter={20}>
                                <Col sm={6}>
                                    <Form.Item label="EMD Amount"
                                        name="emd_amount"
                                        rules={[{ required: true, message: 'Please enter a Emd amount!' }]}
                                        onKeyPress={handleKeyContainOnlyNumbers}
                                    >
                                        <Input type='text' placeholder='Enter Here' />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label="Currency"
                                        // name="currency"
                                        rules={[{ required: true, message: 'Please enter a Currency' }]}
                                        onKeyPress={handleKeyPress}
                                    >
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder='Select Here'
                                            options={BidCurrency?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.name
                                                }
                                            })}
                                            name='currency'
                                            onChange={(value) => handleChange('currency', value)}
                                            value={projectInfo?.tender_emd?.currency}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label='EMD Fee Type'
                                        // name="emd_fee_type"
                                        rules={[{ required: true, message: 'Please enter a Emd Fee Type' }]}
                                    // onKeyPress={handleKeyContainOnlyNumbers}
                                    >
                                        <Input type='text' placeholder='Enter Here'
                                            value={projectInfo?.tender_emd?.emd_fee_type !== null ? projectInfo?.tender_emd?.emd_fee_type : ''}
                                            name='emd_fee_type'
                                            onChange={(e) => handleChange('emd_fee_type', e?.target?.value)} />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label='EMD Payable To'
                                        // name="emd_payable_to"
                                        rules={[{ required: true, message: 'Please enter a Emd Payable To' }]}
                                    // onKeyPress={handleKeyContainOnlyNumbers}
                                    >
                                        <Input type='text' placeholder='Enter Here'
                                            value={projectInfo?.tender_emd?.emd_payable_to}
                                            name='emd_payable_to'
                                            onChange={(e) => handleChange('emd_payable_to', e?.target?.value.replace(/[^A-Z A-z0-9.]/g, ''))} />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label='EMD Payable At'
                                        // name="emd_payable_at"
                                        rules={[{ required: true, message: 'Please enter a Emd Payable At' }]}
                                    // onKeyPress={handleKeyContainOnlyNumbers}
                                    >
                                        <Input type='text' placeholder='Enter Here'
                                            value={projectInfo?.tender_emd?.emd_payable_at}
                                            name='emd_payable_at'
                                            onChange={(e) => handleChange('emd_payable_at', e?.target?.value.replace(/[^A-Z A-z0-9.]/g, ''))} />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label='EMD Percentage'
                                        // name="emd_percentage"
                                        rules={[{ required: true, message: 'Please enter a Emd Percentage' }]}
                                    // onKeyPress={handleKeyContainOnlyNumbers}
                                    // onKeyPress={(e) => {
                                    //     const allowedChars = /[0-9.%]/;
                                    //     if (!allowedChars.test(e.key)) {
                                    //         e.preventDefault();
                                    //     }
                                    //     else if (e.key === 'Enter') {
                                    //         e.preventDefault();
                                    //     } else if (e.key === ' ' && e.target.selectionStart === 0) {
                                    //         e.preventDefault();
                                    //     }
                                    // }}
                                    >
                                        <Input type='text' placeholder='Enter Here'
                                            value={projectInfo?.tender_emd?.emd_percentage}
                                            name='emd_percentage'
                                            onChange={(e) => handleChange('emd_percentage', e?.target?.value.replace(/[^0-9.]/g, ''))}
                                        />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label='EMD Exemption'
                                    // name="emd_through_BG_ST_orEMD_exemption_allowed"
                                    // rules={[{ required: true, message: 'Please enter a Emd Exemption' }]}
                                    // onKeyPress={handleKeyPress}
                                    >
                                        {/* <Input type='text' placeholder='Enter Here'
                                            value={projectInfo?.tender_emd?.emd_through_BG_ST_orEMD_exemption_allowed}
                                            name='emd_through_BG_ST_orEMD_exemption_allowed'
                                            onChange={(e) => handleChange('emd_through_BG_ST_orEMD_exemption_allowed', e?.target?.value.replace(/[^A-Za-z .]/g, ''))} /> */}
                                        <Select
                                            placeholder="Select here"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            showSearch
                                            optionFilterProp="label"
                                            options={[{ value: 'yes', label: 'Yes' }, { value: 'no', label: 'No' }]}
                                            onChange={(e) => handleChange('emd_through_BG_ST_orEMD_exemption_allowed', e)}
                                            name='emd_through_BG_ST_orEMD_exemption_allowed'
                                            value={projectInfo?.tender_emd?.emd_through_BG_ST_orEMD_exemption_allowed}
                                        />
                                    </Form.Item>
                                </Col>




                            </Row>
                            <div className='bd_model_button info_btn'>
                                <Button key="back" className='BG_ghostButton' onClick={resetEmdInfo}>
                                    Reset
                                </Button>
                                <Button key="submit" className='BG_mainButton' type="primary" htmlType="submit" loading={loadings?.loadingEmd} disabled={loadings?.loadingEmd}
                                // onClick={handleProjectEmd}
                                >
                                    Save & Update
                                </Button>
                            </div>
                        </Form>
                    </div>
                </Panel>
            </Collapse>

            <Collapse onChange={() => togglePanel('projectInfoData')} defaultActiveKey={1} >
                <Panel
                    key="1"
                    header={
                        <div className='collapse_flex'>
                            <div className="d-flex">
                                <div className="iconBox">
                                    <Info theme="outline" size="22" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                </div>
                                {/* Additional Information */}
                                Critical Dates
                            </div>
                            {panelStates?.projectInfoData ?
                                <Down theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                :
                                <Right theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                            }
                        </div>
                    }
                >
                    <div className="project_info_form">
                        <div className="tender_profile_fields">
                            <div className="profile_fields_name">
                                <span>Tender Published Date :</span>
                                <p>₹5,000</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Tender Published Time :</span>
                                <p>Rupee</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Bid Opening Date :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Bid Opening Time :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Doc Download Start Date :</span>
                                <p>Chhattisgarh Police Housing Corporation Ltd (CGPHC)</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Doc Download Start Time :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Doc Download End Date :</span>
                                <p>yes</p>
                            </div>

                            <div className="profile_fields_name">
                                <span>Doc Download End Time :</span>
                                <p>yes</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Clarification Start Date :</span>
                                <p>yes</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Clarification Start Time :</span>
                                <p>yes</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Clarification End Date :</span>
                                <p>yes</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Clarification End Time :</span>
                                <p>yes</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Bid Submission Start Date :</span>
                                <p>yes</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Bid Submission Start Time :</span>
                                <p>yes</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Bid Submission End Date :</span>
                                <p>yes</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Bid Submission End Time :</span>
                                <p>yes</p>
                            </div>
                        </div>
                        <div className='bd_model_button info_btn'>
                            <Button className='BG_mainButton' type="primary">
                                Edit
                            </Button>
                        </div>
                        <Form
                            style={{ display: "none" }}
                            form={formInfo}
                            layout="vertical"
                            // onFinish={handleProjectInfo}
                            autoComplete='off'
                            name="control-hooks"
                        >
                            <Row gutter={20}>

                                <Col sm={6}>
                                    <Form.Item
                                        // label="Tender Published Date"
                                        label={
                                            <span>
                                                <span style={{ color: '#ff4d4f' }}>*</span>
                                                Tender Published Date
                                            </span>
                                        }
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <DatePicker placeholder='dd/mm/yyyy'
                                            name='tnd_published_date'
                                            type="date"
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.tnd_published_date !== null ? dayjs(projectInfo?.tender_date?.tnd_published_date) : null}
                                            onChange={(e) => handleChange('tnd_published_date', e)}
                                            name="tnd_published_date"

                                        />
                                        {
                                            errorsMsg?.tnd_published_date &&
                                            <div className="col-md-12" style={{ color: 'red' }}>Please Select a Published Date</div>
                                        }
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item
                                        label="Tender Published Time"
                                        label={
                                            <span>
                                                <span style={{ color: '#ff4d4f' }}>*</span>
                                                Tender Published Time
                                            </span>
                                        }
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <TimePicker
                                            placeholder='Select Time'
                                            name='tnd_published_time'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null &&
                                                projectInfo?.tender_date?.tnd_published_time !== null
                                                ? dayjs(projectInfo?.tender_date?.tnd_published_time, 'HH:mm:ss')
                                                : null
                                            }
                                            onChange={(e) => handleChange('tnd_published_time', e)}
                                            name="tnd_published_time"

                                        />
                                        {errorsMsg?.tnd_published_time && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Published Time</div>}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Bid Opening Date"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <DatePicker placeholder='dd/mm/yyyy'
                                            name='bid_opening_date'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.bid_opening_date !== null ? dayjs(projectInfo?.tender_date?.bid_opening_date) : ''}
                                            onChange={(e) => handleChange('bid_opening_date', e)}
                                            name="bid_opening_date"
                                            format={"YYYY-MM-DD"}
                                        />
                                        {/* {errorsMsg?.bid_opening_date && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Opening Date</div>} */}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Bid Opening Time"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <TimePicker
                                            placeholder='Select Time'
                                            name='bid_opening_time'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.bid_opening_time !== null ? dayjs(projectInfo?.tender_date?.bid_opening_time, 'HH:mm:ss') : null}
                                            onChange={(e) => handleChange('bid_opening_time', e)}
                                            name="bid_opening_time"
                                        />
                                        {/* {errorsMsg?.bid_opening_time && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Opening Time</div>} */}
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label="Doc Download Start Date"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <DatePicker placeholder='dd/mm/yyyy'
                                            name='doc_download_start_date'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.doc_download_start_date !== null ? dayjs(projectInfo?.tender_date?.doc_download_start_date) : null}
                                            onChange={(e) => handleChange('doc_download_start_date', e)}
                                            name="doc_download_start_date"
                                            format={"YYYY-MM-DD"}
                                        />
                                        {/* {errorsMsg?.doc_download_start_date && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Download Start Date</div>} */}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Doc Download Start Time"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <TimePicker
                                            placeholder='Select Time'
                                            name='doc_download_start_time'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.doc_download_start_time !== null ? dayjs(projectInfo?.tender_date?.doc_download_start_time, 'HH:mm:ss') : null}
                                            onChange={(e) => handleChange('doc_download_start_time', e)}
                                            name="doc_download_start_time"
                                        />
                                        {/* {errorsMsg?.doc_download_start_time && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Doc Download Start Time</div>} */}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Doc Download End Date"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <DatePicker placeholder='dd/mm/yyyy'
                                            name='doc_download_end_date'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.doc_download_end_date !== null ? dayjs(projectInfo?.tender_date?.doc_download_end_date) : null}
                                            onChange={(e) => handleChange('doc_download_end_date', e)}
                                            name="doc_download_end_date"
                                            format={"YYYY-MM-DD"}
                                        />
                                        {/* {errorsMsg?.doc_download_end_date && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Doc Download End Date</div>} */}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Doc Download End Time"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <TimePicker
                                            placeholder='Select Time'
                                            name='doc_download_end_time'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.doc_download_end_time !== null ? dayjs(projectInfo?.tender_date?.doc_download_end_time, 'HH:mm:ss') : null}
                                            onChange={(e) => handleChange('doc_download_end_time', e)}
                                            name="doc_download_end_time"
                                        />
                                        {/* {errorsMsg?.doc_download_end_time && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Doc Download End Time</div>} */}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Clarification Start Date"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <DatePicker placeholder='dd/mm/yyyy'
                                            name='clarification_start_date'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.clarification_start_date !== null ? dayjs(projectInfo?.tender_date?.clarification_start_date) : null}
                                            onChange={(e) => handleChange('clarification_start_date', e)}
                                            name="clarification_start_date"
                                            format={"YYYY-MM-DD"}
                                        />
                                        {/* {errorsMsg?.clarification_start_date && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Clarification Start Date</div>} */}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Clarification Start Time"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <TimePicker
                                            placeholder='Select Time'
                                            name='clarification_start_time'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.clarification_start_time !== null ? dayjs(projectInfo?.tender_date?.clarification_start_time, 'HH:mm:ss') : null}
                                            onChange={(e) => handleChange('clarification_start_time', e)}
                                            name="clarification_start_time"
                                        />
                                        {/* {errorsMsg?.clarification_start_time && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Clarification Start Time</div>} */}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Clarification End Date"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <DatePicker placeholder='dd/mm/yyyy'
                                            name='clarification_end_date'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.clarification_end_date !== null ? dayjs(projectInfo?.tender_date?.clarification_end_date) : null}
                                            onChange={(e) => handleChange('clarification_end_date', e)}
                                            name="clarification_end_date"
                                            format={"YYYY-MM-DD"}
                                        />
                                        {/* {errorsMsg?.clarification_end_date && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Clarification End Date</div>} */}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Clarification End Time"
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <TimePicker
                                            placeholder='Select Time'
                                            name='clarification_end_time'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.clarification_end_time !== null ? dayjs(projectInfo?.tender_date?.clarification_end_time, 'HH:mm:ss') : null}
                                            onChange={(e) => handleChange('clarification_end_time', e)}
                                            name="clarification_end_time"
                                        />
                                        {/* {errorsMsg?.clarification_end_time && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Clarification End Time</div>} */}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item
                                        //  label="Bid Submission Start Date"
                                        label={
                                            <span>
                                                <span style={{ color: '#ff4d4f' }}>*</span>
                                                Bid Submission Start Date
                                            </span>
                                        }
                                        onKeyPress={handleKeyPressSelectedItem}

                                    >
                                        <DatePicker placeholder='dd/mm/yyyy'
                                            name='bid_submission_start_date'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.bid_submission_start_date !== null ? dayjs(projectInfo?.tender_date?.bid_submission_start_date) : null}
                                            onChange={(e) => handleChange('bid_submission_start_date', e)}
                                        />
                                        {errorsMsg?.bid_submission_start_date && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Bid Submission Start Date</div>}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item
                                        // label="Bid Submission Start Time"
                                        label={
                                            <span>
                                                <span style={{ color: '#ff4d4f' }}>*</span>
                                                Bid Submission Start Time
                                            </span>
                                        }
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <TimePicker
                                            placeholder='Select Time'
                                            name='bid_submission_start_time'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.bid_submission_start_time !== null ? dayjs(projectInfo?.tender_date?.bid_submission_start_time, 'HH:mm:ss') : null}
                                            onChange={(e) => handleChange('bid_submission_start_time', e)}
                                        />
                                        {errorsMsg?.bid_submission_start_time && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Bid Submission Start Time</div>}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item
                                        //  label="Bid Submission End Date"
                                        label={
                                            <span>
                                                <span style={{ color: '#ff4d4f' }}>*</span>
                                                Bid Submission End Date
                                            </span>
                                        }
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <DatePicker placeholder='dd/mm/yyyy'
                                            name='bid_submission_end_date'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.bid_submission_end_date !== null ? dayjs(projectInfo?.tender_date?.bid_submission_end_date) : null}
                                            onChange={(e) => handleChange('bid_submission_end_date', e)}
                                            name="bid_submission_end_date"
                                            format={"YYYY-MM-DD"}
                                        />
                                        {errorsMsg?.bid_submission_end_date && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Bid Submission End Date</div>}
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item
                                        label="Bid Submission End Time"
                                        label={
                                            <span>
                                                <span style={{ color: '#ff4d4f' }}>*</span>
                                                Bid Submission End Time
                                            </span>
                                        }
                                        onKeyPress={handleKeyPressSelectedItem}
                                    >
                                        <TimePicker
                                            placeholder='Select Time'
                                            name='bid_submission_end_time'
                                            onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                            value={projectInfo?.tender_date !== null && projectInfo?.tender_date?.bid_submission_end_time !== null ? dayjs(projectInfo?.tender_date?.bid_submission_end_time, 'HH:mm:ss') : null}
                                            onChange={(e) => handleChange('bid_submission_end_time', e)}
                                            name="bid_submission_end_time"
                                        />
                                        {errorsMsg?.bid_submission_end_time && <div className="col-md-12" style={{ color: 'red' }}>Please Select a Bid Submission End Time</div>}
                                    </Form.Item>
                                </Col>
                            </Row>

                            <div className='bd_model_button info_btn'>
                                <Button key="back" className='BG_ghostButton' onClick={resetProjectInfo}>
                                    Reset
                                </Button>
                                <Button key="submit" className='BG_mainButton'
                                    type="primary" htmlType="submit" loading={loadings?.loadingDate} disabled={loadings?.loadingDate}
                                    onClick={handleProjectInfo}
                                >
                                    Save & Update
                                </Button>
                            </div>
                        </Form>

                    </div>
                </Panel>
            </Collapse>

            <Collapse onChange={() => togglePanel('projectFeeInfo')} defaultActiveKey={1}>
                <Panel
                    key="1"
                    header={
                        <div className='collapse_flex'>
                            <div className="d-flex">
                                <div className="iconBox">
                                    <WalletThree theme="outline" size="22" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                </div>
                                Project Financials
                            </div>
                            {panelStates?.projectFeeInfo ?
                                <Down theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                :
                                <Right theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                            }
                        </div>
                    }
                >
                    <div className="project_info_form">
                        <div className="tender_profile_fields">
                            <div className="profile_fields_name">
                                <span>Tender Fee :</span>
                                <p>₹5,000</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Currency :</span>
                                <p>Rupee</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Processing Fee :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Fee Payable To :</span>
                                <p>24 Aug 2024</p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Fee Payable At :</span>
                                <p></p>
                            </div>
                            <div className="profile_fields_name">
                                <span>Tender Fee Exemption :</span>
                                <p>24 Aug 2024</p>
                            </div>
                        </div>
                        <div className='bd_model_button info_btn'>
                            <Button className='BG_mainButton' type="primary">
                                Edit
                            </Button>
                        </div>
                        <Form layout="vertical"
                            style={{ display: "none" }}
                            form={formfee}
                            layout="vertical"
                            // onFinish={handleProjectFeeInfo}
                            autoComplete='off'
                            name="control-hooks"
                        >
                            <Row gutter={20}>
                                <Col sm={6}>
                                    <Form.Item label="Tender Fee" rules={[{ required: true, message: "please enter a Tender Fee" }]}>
                                        <Input type='text'
                                            value={projectInfo?.tender_feeinfo?.tnd_fee}
                                            name='tnd_fee'
                                            onChange={(e) => handleChange('tnd_fee', e?.target?.value.replace(/[^0-9.]/g, ''))} />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label="Currency" rules={[{ required: true, message: "please Enter a currency" }]}>
                                        <Select
                                            showSearch
                                            optionFilterProp="children"
                                            placeholder='Enter Here'
                                            options={BidCurrency?.map((item, index) => {
                                                return {
                                                    value: item?.id,
                                                    label: item?.name
                                                }
                                            })}
                                            name='currency'
                                            onChange={(value) => handleChange('currency', value)}
                                            value={projectInfo?.tender_feeinfo?.currency}
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            filterOption={(input, option) =>
                                                option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                            }
                                        />
                                    </Form.Item>
                                </Col>
                                <Col sm={6}>
                                    <Form.Item label="Processing Fee" rules={[{ required: true, message: "please enter a Processing Fees" }]} >
                                        <Input type='text'
                                            value={projectInfo?.tender_feeinfo?.processing_fee} name="processing_fee" onChange={(e) => handleChange('processing_fee', e?.target?.value.replace(/[^0-9.]/g, ''))} />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Fee Payable To" rules={[{ required: true, message: "please enter a Fees Payable To" }]} >
                                        <Input type='text'
                                            value={projectInfo?.tender_feeinfo?.fee_payable_to} name="fee_payable_to" onChange={(e) => handleChange('fee_payable_to', e?.target?.value.replace(/[^A-Z A-z0-9.]/g, ''))} />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label="Fee Payable At" rules={[{ required: true, message: "please enter a Fees Payable At" }]}>
                                        <Input type='text'
                                            value={projectInfo?.tender_feeinfo?.fee_payable_at !== 'null' ? projectInfo?.tender_feeinfo?.fee_payable_at : ''} name="fee_payable_at" onChange={(e) => handleChange('fee_payable_at', e?.target?.value.replace(/[^A-Z A-z0-9.]/g, ''))}
                                        />
                                    </Form.Item>
                                </Col>

                                <Col sm={6}>
                                    <Form.Item label='Tender Fee Exemption' rules={[{ required: true, message: "please enter a Tender Fee Exemption" }]}>
                                        {/* <Input type='text' value={projectInfo?.tender_feeinfo?.tnd_fee_exemption_allowed !== 'null' ? projectInfo?.tender_feeinfo?.tnd_fee_exemption_allowed : ''} name="tnd_fee_exemption_allowed"
                                            onChange={(e) => handleChange('tnd_fee_exemption_allowed', e?.target?.value.replace(/[^A-Za-z .]/g, ''))}
                                        /> */}

                                        <Select
                                            placeholder="Select here"
                                            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                            showSearch
                                            optionFilterProp="label"
                                            options={[{ value: 'yes', label: 'Yes' }, { value: 'no', label: 'No' }]}
                                            onChange={(e) => handleChange('tnd_fee_exemption_allowed', e)}
                                            name='tnd_fee_exemption_allowed'
                                            value={projectInfo?.tender_feeinfo?.tnd_fee_exemption_allowed !== 'null' ? projectInfo?.tender_feeinfo?.tnd_fee_exemption_allowed : ''}
                                        />
                                    </Form.Item>
                                </Col>

                            </Row>
                            <div className='bd_model_button info_btn'>
                                <Button key="back" className='BG_ghostButton' onClick={resetFeeInfo}>
                                    Reset
                                </Button>
                                <Button key="submit" className='BG_mainButton'
                                    onClick={handleProjectFeeInfo}
                                    type="primary" htmlType="submit" loading={loadings.loadingFee} disabled={loadings.loadingFee}>
                                    Save & Update
                                </Button>
                            </div>
                        </Form>

                    </div>
                </Panel>
            </Collapse>

            <Collapse onChange={() => togglePanel('projectCoverInfo')} defaultActiveKey={1}>
                <Panel
                    key="1"
                    header={
                        <div className='collapse_flex'>
                            <div className="d-flex">
                                <div className="iconBox">
                                    <Bookshelf theme="outline" size="22" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                </div>
                                Cover Information

                            </div>
                            {panelStates?.projectCoverInfo ?
                                <Down theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                :
                                <Right theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                            }
                        </div>
                    }
                >
                    <div className='bd_tender_profile_documents'>
                        <div className='bd_profile_doucments_header'>
                            <Button className='BG_mainButton' onClick={handleModalAdd}>Add Project Cover</Button>
                        </div>
                        <DataTable
                            title=" Project Cover Info"
                            // handleUpdate={handleUpdate}
                            handleDelete={handleDelete}
                            columnLabels={columnLabels}
                            dataSource={coverInfoTableData}
                            getPropDataVal={getPropDataVal}
                            showActions={showActions}
                        />
                    </div>
                </Panel>
            </Collapse>


            <Modal title={projectCoverInfo?.bg_tender_id ? 'Edit Project Cover' : "Add Project Cover"} className='bd_model_main'
                open={addOpenModal}
                onOk={() => setAddOpenModal(false)}
                onCancel={() => {
                    // setProjectCoverInfo({
                    //     cover_type: '',
                    //     description: '',
                    //     doc_type: '',
                    // });
                    setAddOpenModal(false);
                    // setErrorMessage('');
                    form1.resetFields()
                }}
                footer={false}
            >
                <Form form={form1} name="control-hooks" layout="vertical" autoComplete="off" onFinish={handleProjectCoverInfo}>
                    <Form.Item label="Cover Type" name='cover_type' rules={[{ required: true, message: 'Cover Type is required' }]}>
                        <Input placeholder="Enter Here" type='text'
                            onChange={(e) => handleEmployeeChange('cover_type', e)}
                        //  value={projectCoverInfo?.cover_type} 
                        //  onChange={(e) => handleCoverChange('cover_type', e?.target?.value?.trimStart())}
                        />
                    </Form.Item>

                    <Form.Item label="Description" name='description' rules={[{ required: true, message: 'Description is required' }]}>
                        <Input placeholder="Enter Here"
                            onChange={(e) => handleEmployeeChange('description', e)}
                        // type='text' value={projectCoverInfo?.description}
                        //  onChange={(e) => handleCoverChange('description', e?.target?.value?.trimStart())} 
                        />
                    </Form.Item>

                    <Form.Item label="Doc Type" name='doc_type'
                        //  rules={[{ required: true, message: 'Doc Type is required' }]}
                        rules={[
                            {
                                required: true,
                                message: 'Doc Type is required'
                            },
                            {
                                validator: validateDocType,
                            },
                        ]}
                    >
                        <Input placeholder="Enter Here"
                            onChange={(e) => handleEmployeeChange('doc_type', e)}
                        // value={projectCoverInfo?.doc_type} 
                        // Change={(e) => handleCoverChange('doc_type', e?.target?.value)}
                        />
                        {/* <div className="col-md-12" style={{ color: `${!showError ? "green" : 'red'}` }}> {errorMessage} </div> */}
                    </Form.Item>
                    <Flex justify='flex-end' align='center'>
                        <Button key="back" className='BG_ghostButton' onClick={() => { form1.resetFields() }}>
                            Reset
                        </Button>
                        <Button key="submit" className='BG_mainButton' style={{ marginLeft: '20px' }} type="primary" htmlType="submit" loading={loadings?.loadingCover} disabled={loadings?.loadingCover}>
                            {projectCoverInfo?.bg_tender_id ? 'Edit Cover' : "Add Cover"}
                        </Button>
                    </Flex>
                </Form>

            </Modal>

        </div>
    )
}
ProjectInfo.whyDidYouRender = true

export default ProjectInfo

