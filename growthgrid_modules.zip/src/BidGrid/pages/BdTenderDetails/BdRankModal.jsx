import React from 'react'
import { Form,  Input,  Modal, Select, } from 'antd';

const BdRankModal = ({genRankModal, setGenRankModal}) => {
const handleSubmitRank= ()=>{
    setGenRankModal(false)
}
  return (
    <Modal title="Generate Rank" className='bd_model_main'

            open={genRankModal}
            onOk={() => setGenRankModal(false)}
            onCancel={() => setGenRankModal(false)}
            footer={[
                <button key="back" className='BG_ghostButton' >
                    Reset
                </button>,
                <button key="submit" onClick={handleSubmitRank} className='BG_mainButton' >
                    Submit
                </button>
            ]}
        >
            <Form name="validateOnly" layout="vertical" autoComplete="off"
            // onKeyDown={handleKeyPress}
            >
                <Form.Item label="FinanCial Weightage">
                    <Input placeholder='Select Value' disabled={true} />
                </Form.Item>
                <Form.Item label="Financial">
                    <Input placeholder='Select Value' />
                </Form.Item>
            </Form>
        </Modal>
  )
}

export default BdRankModal