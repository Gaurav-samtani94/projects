import React, { useCallback, useRef, useState } from 'react';
import { Drawer, Avatar, Mentions } from 'antd';
import debounce from 'lodash/debounce';
import skipBack from "../../assets/images/skip-back.png";
import commentprofile from '../../assets/images/profile2.jpg';
import { SendOutlined } from '@ant-design/icons';
import { Write, } from '@icon-park/react';

function BdAddComment({ showCommnetDrawer, tagsopen, commentSetOpen, comment, setComment, oncommentClose }) {
    console.log(oncommentClose, "oncommentClose")

    const [loading, setLoading] = useState(false);
    const [reply, setReply] = useState(false);
    const [users, setUsers] = useState([]);
    const [inputValue, setInputValue] = useState('');
    const ref = useRef();
    const replyfocus = useRef(null);

    const loadUsers = (key) => {
        if (!key) {
            setUsers([]);
            return;
        }
        fetch(`https://api.github.com/search/users?q=${key}`)
            .then((res) => res.json())
            .then(({ items = [] }) => {
                if (ref.current !== key) return;
                setLoading(false);
                setUsers(items.slice(0, 10));
            });
    };
    const debounceLoad = useCallback(debounce(loadUsers, 800), []);

    const onSearch = (search) => {
        console.log('Search:', search);
        ref.current = search;
        setLoading(!!search);
        setUsers([]);
        debounceLoad(search);
    };
    const handleReply = () => {
        replyfocus.current.focus()
    }


    return (
        <Drawer className='bs_todo_drawer_comment' closeIcon={<img src={skipBack} alt='' />} title="Comments" placement="right" onClose={() => setComment(false)}
            open={comment} width={600}
            footer={[
                <>
                    <div className='input_comment'>
                        <Mentions
                            // className={reply ? ' active' :''}
                            ref={replyfocus}
                            // style={{ width: '90 %' }}
                            loading={loading}
                            onSearch={onSearch}
                            placeholder='Add Comment'
                            value={inputValue}
                            // style={{ color: inputValue.startsWith('@') ? 'blue' : 'black' }}
                            onChange={(value) => setInputValue(value)}
                            options={users.map(({ login, avatar_url: avatar }) => ({
                                key: login,
                                value: login,
                                className: 'antd-demo-dynamic-option',
                                label: (
                                    <>
                                        <img src={avatar} alt={login} />
                                        <span style={{ color: login.startsWith('@') ? 'blue' : 'black' }}>{login}</span>
                                    </>
                                ),
                            }))}
                        />
                        <SendOutlined />
                    </div>
                </>
            ]}
        >
            <div className='todo_comments_cont'>
                <div className='todo_comments'>
                    <div className='todo_comment_img'>
                        <img src={commentprofile} alt="comment img" />
                    </div>
                    <div className='todo_comment_main_cont'>
                        <div className='todo_comment_name'>
                            <span>Vijay Kumar Jangid</span>
                            <p>10/10/2023</p>
                        </div>
                        <div className='todo_comment_para'>
                            <p><span>@Hitesh Patel</span> please send email to RINA <span>@Hitesh Patel</span> <span>@Hitesh Patel</span> <span>@Hitesh Patel</span></p>
                        </div>
                        <button className="editComment" onClick={handleReply}>
                            <Write theme="outline" size="24" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" />
                        </button>

                        <div className='todo_comments_reply'>
                            <div className='todo_reply_img'>
                                <img src={commentprofile} alt="comment img" />
                            </div>
                            <div className='todo_reply_main_cont'>
                                <div className='todo_reply_name'>
                                    <span>Vijay Kumar Jangid</span>
                                    <p>10/10/2023</p>
                                </div>
                                <div className='todo_reply_para'>
                                    <p><span>@Hitesh Patel</span> please send email to RINA <span>@Hitesh Patel</span> <span>@Hitesh Patel</span> <span>@Hitesh Patel</span></p>
                                </div>
                            </div>
                        </div>
                        <div className='todo_comments_reply'>
                            <div className='todo_reply_img'>
                                <img src={commentprofile} alt="comment img" />
                            </div>
                            <div className='todo_reply_main_cont'>
                                <div className='todo_reply_name'>
                                    <span>Vijay Kumar Jangid</span>
                                    <p>10/10/2023</p>
                                </div>
                                <div className='todo_reply_para'>
                                    <p><span>@Hitesh Patel</span> please send email to RINA <span>@Hitesh Patel</span> <span>@Hitesh Patel</span> <span>@Hitesh Patel</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='todo_comments'>
                    <div className='todo_comment_img'>
                        <img src={commentprofile} alt="comment img" />
                    </div>
                    <div className='todo_comment_main_cont'>
                        <div className='todo_comment_name'>
                            <span>Vijay Kumar Jangid</span>
                            <p>10/10/2023</p>
                        </div>
                        <div className='todo_comment_para'>
                            <p><span>@Hitesh Patel</span> please send email to RINA <span>@Hitesh Patel</span> <span>@Hitesh Patel</span> <span>@Hitesh Patel</span></p>
                        </div>
                        <button onClick={handleReply}>Reply</button>

                        <div className='todo_comments_reply'>
                            <div className='todo_reply_img'>
                                <img src={commentprofile} alt="comment img" />
                            </div>
                            <div className='todo_reply_main_cont'>
                                <div className='todo_reply_name'>
                                    <span>Vijay Kumar Jangid</span>
                                    <p>10/10/2023</p>
                                </div>
                                <div className='todo_reply_para'>
                                    <p><span>@Hitesh Patel</span> please send email to RINA <span>@Hitesh Patel</span> <span>@Hitesh Patel</span> <span>@Hitesh Patel</span></p>
                                </div>
                            </div>
                        </div>
                        <div className='todo_comments_reply'>
                            <div className='todo_reply_img'>
                                <img src={commentprofile} alt="comment img" />
                            </div>
                            <div className='todo_reply_main_cont'>
                                <div className='todo_reply_name'>
                                    <span>Vijay Kumar Jangid</span>
                                    <p>10/10/2023</p>
                                </div>
                                <div className='todo_reply_para'>
                                    <p><span>@Hitesh Patel</span> please send email to RINA <span>@Hitesh Patel</span> <span>@Hitesh Patel</span> <span>@Hitesh Patel</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Drawer>
    )
}

export default BdAddComment
