// @ts-nocheck

import React, { useState, useEffect, useMemo } from 'react'
import { useParams } from 'react-router-dom/dist';
import DataTable from 'BidGrid/components/dataTable/DataTable';
import { Button, Form, Select, Modal, Flex, Table } from 'antd';
import { toast } from 'react-toastify';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import dayjs from 'dayjs';
import { BankApi } from 'Services/bidgrid/master/bank/BidBank';
import { bgdetail } from 'Services/bidgrid/add/BG detail/BgdetailApi';
import { Down } from '@icon-park/react';

const bgColumnLabels = {
    bank_name: { name: 'Bank Name', required: true },
    bg_amount: { name: 'Amount', required: true },
    bg_validity: { name: 'validity', required: true },
};

const columns = [
    {
        title: 'Sr. No',
        dataIndex: 'no',
        key: 'no',
    },
    {
        title: 'Bank Name',
        dataIndex: 'age',
        key: 'age',
    },
    {
        title: 'Amount Allowed',
        dataIndex: 'address',
        key: 'address',
    },
];
const data = [
    {
        key: '1',
        no: '1',
        age: "SBI",
        address: '1923,2456,053',
    },
    {
        key: '2',
        no: '2',
        age: 42,
        address: 'London No. 1 Lake Park',
    },
    {
        key: '3',
        no: '3',
        age: 32,
        address: 'Sydney No. 1 Lake Park',
    },
];

const BdTenderBank = () => {
    const [bankName, setBankName] = useState([])
    const [pbgModal, setPbgModal] = useState(false)
    const [addPbgState, setAddPbgState] = useState(null)
    const [bankDetailList, setBankDetailList] = useState([])
    const [flatBankDetail, setFlatBankDetail] = useState([])
    const [disableBtn, setDisableBtn] = useState(false)
    const [loadingBG, setLoadingBG] = useState(false)
    const showActions = true;
    const [form2] = Form.useForm();
    const { id } = useParams()
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const handlePbgModal = () => {
        setPbgModal(true)
    }

    // list Bg Details
    const fetchBankDetail = async () => {
        const formData = new URLSearchParams();
        formData.append('tender_id', id);
        try {
            const response = await TenderApi.bgBankList(formData);
            if (response?.data?.status == 1) {
                setBankDetailList(response?.data?.data)
            }
            else {
                setBankDetailList([])
            }

        } catch (error) {
            console.log(error, "Api");
        }


    }


    // delete bg details
    const handleBgDelete = async (val) => {
        const formData = new URLSearchParams();
        formData.append('project_id', id);
        formData.append('assign_bg_id', val);

        try {
            const response = await TenderApi.deleteBgBank(formData);
            if (response?.data?.status == 1) {
                notifySuccess('Bank Detail Deleted Successfully');
                await fetchBankDetail()
            } else {
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            console.log(error, "Api");
        }
    };


    // bank list 

    const BankList = async () => {
        try {
            const responseBank = await BankApi.getBank()
            const response = await bgdetail.Bglist()
            if (response?.data?.status == 1 && responseBank?.data?.status == 1) {
                const masterDrpValue = response?.data?.data.map((element) => {
                    const bankObj = responseBank?.data?.data?.find((val) => val.id === element.bg_bank)
                    element['bankObj'] = bankObj
                    return element
                });
                setBankName(masterDrpValue)
                // console.log("masterDrpValue", masterDrpValue)
            }
            else {
                setBankName([])
            }
        } catch (error) {
            console.log(error)
        }
    };

    // add bg Details
    const addBank = async () => {
        setLoadingBG(true)

        const formData = new URLSearchParams();
        formData.append('tender_id', id);
        formData.append('bg_id', addPbgState);
        try {
            const response = await TenderApi.addBgBank(formData);
            if (response?.data?.status == 1) {
                notifySuccess('Bank Detail Added Successfully');
                setPbgModal(false)
                setAddPbgState(null)
                setLoadingBG(false)
                form2.resetFields()
                await fetchBankDetail()
            } else {
                setAddPbgState(null)
                setPbgModal(true)
                setLoadingBG(false)
                notify(response?.response?.data?.message);
            }
        } catch (error) {
            setLoadingBG(false)
            console.log(error, "Api");
        }

        // setTimeout(() => {
        //     setDisableBtn(false)
        // }, 2000);
    }

    const handlePbgChange = (e) => {
        setAddPbgState(e)
    }

    useEffect(() => {
        const flattenedData = bankDetailList?.map(project => ({
            id: project?.id,
            bank_name: project?.bg_performance_detail?.bg_performance_mstr_bank?.bank_name,
            bg_amount: project?.bg_performance_detail?.bg_amount,
            bg_validity: dayjs(project?.bg_performance_detail?.bg_validity).format('YYYY-MM-DD'),
        }));
        setFlatBankDetail(flattenedData);
    }, [bankDetailList]);

    const resetBank = () => {
        setAddPbgState(null)
        form2.resetFields()
    }
    const bgDetailsData = useMemo(() => {
        return flatBankDetail;
    }, [flatBankDetail]);

    useEffect(() => {
        BankList()
        fetchBankDetail()
    }, [])

    return (

        <>
            <div className="meetingSchedule_wraper">

                <div className="bd_emplist_main mb-4">
                    <div className='bd_empHeader'>
                        <div className="bd_emplist_main_header" style={{ fontSize: 20 }}>Bank Guarantee amonut alloted to banks</div>
                    </div>
                </div>

                <Table className="mb-5" columns={columns} dataSource={data} pagination={false} />

                <div className="bd_emplist_main">
                    <div className='bd_empHeader'>
                        <div className="bd_emplist_main_header">Bank Guarantee List</div>
                        <Button className='BG_mainButton' onClick={handlePbgModal} style={{ display: 'flex', justifyContent: 'end' }}>Add Bank</Button>
                    </div>
                </div>


                <DataTable
                    title=" Bank Detail"
                    // handleUpdate={handleUpdate}
                    handleDelete={handleBgDelete}
                    columnLabels={bgColumnLabels}
                    dataSource={bgDetailsData}
                    infoId={id}
                    // getPropDataVal={getPropDataVal}
                    showActions={showActions}
                />

                {/* bg bank */}

                <Modal title='New Bank Guarantee' className='bd_model_main'
                    open={pbgModal}
                    onOk={() => setPbgModal(false)}
                    onCancel={() => { setPbgModal(false); form2.resetFields() }}
                    footer={false}
                >
                    <Form form={form2} name="control-hooks" layout="vertical" autoComplete="off" onFinish={addBank}>
                        <Form.Item label="Assign Bank" name='Assign' rules={[{ required: true, message: 'Assign BG is required' }]}>
                            <Select
                                allowClear
                                showSearch
                                optionFilterProp="children"
                                placeholder='Enter Here'
                                options={bankName?.map((item, index) => {
                                    return {
                                        value: item?.id,
                                        label: `${item?.bg_title} , (${item?.bankObj?.bank_name}) - ${item?.bg_amount}`
                                    }
                                })}
                                onChange={handlePbgChange}
                                value={addPbgState}
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                filterOption={(input, option) =>
                                    option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }

                            />
                        </Form.Item>
                        <Flex justify='flex-end' align='center'>
                            <Button key="back" className='BG_ghostButton' onClick={resetBank}>
                                Reset
                            </Button>
                            <Button key="submit" disabled={disableBtn} className='BG_mainButton' style={{ marginLeft: '20px' }} type="primary" htmlType="submit" loading={loadingBG}>
                                Add Bank
                            </Button>
                        </Flex>
                    </Form>

                </Modal>

            </div>
        </>

    )
}

export default BdTenderBank;