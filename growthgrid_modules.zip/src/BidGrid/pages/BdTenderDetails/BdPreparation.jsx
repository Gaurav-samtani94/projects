// @ts-nocheck
import React, { useEffect, useState } from 'react';
import ReactQuill from 'react-quill';
import 'quill/dist/quill.snow.css'
import { Form, Select, Row, Col, Input, DatePicker, Tabs, Collapse } from 'antd';
import { factSheet } from 'Services/bidgrid/factSheet/factSheet';
import { toast } from 'react-toastify';
import { Down, Download } from '@icon-park/react';
import TextArea from 'antd/es/input/TextArea';
import { useParams } from 'react-router-dom';
import dayjs from 'dayjs';
import spinGif from '../../assets/images/spin.gif';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import FactSheetEmailModal from 'BidGrid/components/TenderCycleActionModal/FactSheetEmailModal';


const { Panel } = Collapse;
const notify = (error) => toast.error(error);
const notifySuccess = (msg, id) => toast.success(msg, { toastId: id });

var modules = {
    toolbar: [
        [{ size: ["small", false, "large", "huge"] }],
        ["bold", "italic", "underline", "strike", "blockquote"],
        [{ list: "ordered" }, { list: "bullet" }],
        ["link", "image"],
        [
            { list: "ordered" },
            { list: "bullet" },
            { indent: "-1" },
            { indent: "+1" },
            { align: [] }
        ],
        [{ "color": ["#000000", "#e60000", "#ff9900", "#ffff00", "#008a00", "#0066cc", "#9933ff", "#ffffff", "#facccc", "#ffebcc", "#ffffcc", "#cce8cc", "#cce0f5", "#ebd6ff", "#bbbbbb", "#f06666", "#ffc266", "#ffff66", "#66b966", "#66a3e0", "#c285ff", "#888888", "#a10000", "#b26b00", "#b2b200", "#006100", "#0047b2", "#6b24b2", "#444444", "#5c0000", "#663d00", "#666600", "#003700", "#002966", "#3d1466", 'custom-color'] }],
    ]
};

var formats = [
    "header", "height", "bold", "italic",
    "underline", "strike", "blockquote",
    "list", "color", "bullet", "indent",
    "link", "image", "align", "size",
];

const BdBIdPrepration = (props) => {
    const { userListData } = props;
    const { id } = useParams()

    const [factListData, setFactListData] = useState([]);
    const [assignListFieldsData, setAssignListFieldsData] = useState([]);
    const [activeTab, setActiveTab] = useState();
    const [fieldValues, setFieldValues] = useState({});
    const [countryId, setCountryId] = useState('');
    const [stateId, setStateId] = useState('');
    const [loading, setLoading] = useState(false);
    const [skeleton, setSkeleton] = useState(false);
    const [factsheetEmailModalOpen, setFactsheetEmailModalOpen] = useState(false);
    const [inputReactQuillShow, setInputReactQuillShow] = useState(null);


    const handleTabChange = (key) => {
        setActiveTab(key);
        assignFields(key);
        setInputReactQuillShow(null)
    };

    const handleFieldChange = async (value, field) => {       
        if(field?.fs_input_type?.fs_input_type === "Editor") { // In case of editor.
            handleSubmitForm(value, field?.id);
        }
        else {
            if (field?.desc_name_id == 4) {       // In case of country dropdown
                setCountryId(value);

            }
            if (field?.desc_name_id == 7) {       // In case of State dropdown
                setStateId(value);
            }
            setFieldValues(prevState => ({
                ...prevState,
                [field?.id]: value
            }));
            handleSubmitForm(value, field?.id);
        }

    };

    const handleSubmitForm = async (val, remark_id) => {
        try {
            const formData = new URLSearchParams();
            formData.append('project_id', id);
            formData.append('desc_remark_id', remark_id);
            formData.append('desc_remark_data', val);
            const response = await factSheet?.submitFormData(formData)
            if (response?.data?.status == 1) {
                notifySuccess(response?.data?.message, id);
            }
        } catch (error) {
            console.log(error)
        }
    }

    const convertHtmlTagIntoString = (str) => {
        const htmlTagPattern = /<[^>]*>/g;
        const htmlTags = str?.match(htmlTagPattern);
        if (htmlTags) {
            const stringWithoutHtmlTags = str.replace(htmlTagPattern, '');
            return stringWithoutHtmlTags
        } else {
            return str;
        }
    }
    

    const convertBufferToString = (data) => {
        const bufferData = data?.data;
        const uint8Array = new Uint8Array(bufferData);
        const textDecoder = new TextDecoder('utf-8');
        const decodedStr = textDecoder.decode(uint8Array);
        return decodedStr;
    }

    const showFieldsData = (field) => {
        let fieldValue = fieldValues[field.id] || '';

        switch (field?.fs_input_type?.fs_input_type) {
            case "number":
                return (
                    <Input type='number' placeholder='Enter Here' value={fieldValue} onChange={(e) => handleFieldChange(e?.target?.value, field)} />
                );
            case "select":

                let selectOptions = field?.select_box_data;
                if (field?.desc_name === 'State' && countryId) {
                    const statesArray = field?.select_box_data.filter(item => item?.select_id == countryId);
                    selectOptions = statesArray;
                }

                if (field?.desc_name === 'City' && stateId) {
                    const citiesArray = field?.select_box_data.filter(item => item?.select_id == stateId);
                    selectOptions = citiesArray;
                }

                return (
                    <Select
                        showSearch
                        optionFilterProp="children"
                        placeholder="Select"
                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                        options={selectOptions?.map((item, index) => {
                            return {
                                value: item?.id,
                                label: item?.select_name
                            }
                        })}
                        value={fieldValue}
                        filterOption={(input, option) =>
                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }
                        onChange={(e) => handleFieldChange(e, field)}
                    >
                    </Select>

                );
            case "date":
                const dateValue = fieldValue ? dayjs(fieldValue) : null;
                return (
                    <DatePicker placeholder='YYYY/MM/DD' value={dateValue} onChange={(e) => handleFieldChange(e, field)} disabledDate={(current) => current && current < dayjs().startOf('day')} />
                );
            case "textarea":
                return (
                    <TextArea placeholder='Enter Here' value={convertHtmlTagIntoString(fieldValue)} onChange={(e) => handleFieldChange(e?.target?.value, field)} />
                );
            case "text":
                return (
                    <Input placeholder='Enter Here' value={fieldValue} onChange={(e) => handleFieldChange(e?.target?.value, field)} />
                );

            case 'Editor':               
                return (
                    inputReactQuillShow != field?.id ?
                        <Input placeholder='Enter Here' onClick={() => setInputReactQuillShow(field?.id)} />
                        : inputReactQuillShow[field?.id] ? '' : <ReactQuill theme="snow" modules={modules} formats={formats} value={convertBufferToString(fieldValue)} onChange={(e) => handleFieldChange(e, field)} />
                )

            default:
                return null;
        }
    };


    const getFactList = async () => {
        setSkeleton(true);
        try {
            const response = await factSheet?.getFactList()
            if (response?.data?.status == 1) {
                setSkeleton(false);
                setFactListData(response?.data?.data)
                setActiveTab(response?.data?.data[0]?.id)
                assignFields(response?.data?.data[0]?.id)
            }
        } catch (error) {
            console.log(error)
        }
    }

    const assignFields = async (typeId) => {
        setLoading(true);
        try {
            const formData = new URLSearchParams();
            formData.append('type_id', typeId);
            formData.append('project_id', id);
            const response = await factSheet?.assignDescCompanyList(formData)
            if (response?.data?.status == 1) {
                setLoading(false);
                setAssignListFieldsData(response?.data?.data)
            }
        } catch (error) {
            setLoading(false);
            console.log(error)
        }
    }

    useEffect(() => {
        getFactList()
    }, [])

    useEffect(() => {
        const initialValues = {};
        assignListFieldsData[0]?.fs_desc_assign_comps?.forEach(field => {
            initialValues[field.id] = typeof (field?.fs_desc_remark) === 'object' ? field.fs_desc_remark?.desc_remark_data : field.fs_desc_remark;
        });
        setFieldValues(initialValues);
    }, [assignListFieldsData]);



    const items = factListData?.map((item, index) => {
        return {
            key: item?.id,
            label: item?.type_name,
            children: (
                <div className="project_info_form" key={index}>
                    {
                        !loading ?
                            <Form layout="vertical">

                                <Row gutter={20}>
                                    {assignListFieldsData[0]?.fs_desc_assign_comps?.sort((a, b) => a.sr_no - b.sr_no).map((field, idx) => (
                                        <Col sm={field?.fs_input_type?.fs_input_type === 'textarea' ? 24 : field?.fs_input_type?.fs_input_type === 'Editor' ? 12 : 8}>
                                            <Form.Item label={field?.desc_name}>
                                                <React.Fragment key={idx}>
                                                    {showFieldsData(field)}
                                                </React.Fragment>

                                            </Form.Item>
                                        </Col>

                                    ))}
                                </Row>

                            </Form>
                            : <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20%' }}>
                                <img src={spinGif} width={30} />
                            </div>
                    }

                    {/* <div className="button_flex">
                        <button className="BG_ghostButton">Reset</button>
                        <button className="BG_mainButton">Save & Update</button>
                    </div> */}
                </div>
            ),
        };
    });



    return (
        <div className="bid_prepration">

            <div className="head_flex">
                <h2>Bid Preparation</h2>
                <button className='factSheet_btn' onClick={() => setFactsheetEmailModalOpen(true)} >
                    <Download theme="outline" size="18" fill="#fff" strokeWidth={3} strokeLinecap="butt" /> Prepare FactSheet
                </button>
            </div>
            {
                !skeleton ?
                    <Tabs className="custom-tabs-container" tabPosition='left' defaultActiveKey={activeTab} onChange={(key) => handleTabChange(key)} items={items} />
                    :
                    <Collapse>
                        <Panel
                            key="1"
                            header={
                                <div className='collapse_flex'>
                                    <Skeleton width={300} height={60} />
                                    <Skeleton width={300} height={60} />
                                    <Skeleton width={300} height={60} />
                                    <Skeleton width={300} height={60} />
                                    <Skeleton width={300} height={60} />
                                    <Skeleton width={300} height={60} />
                                </div>
                            }
                        >
                        </Panel>
                    </Collapse>
            }



            <FactSheetEmailModal
                isModalOpen={factsheetEmailModalOpen}
                setFactsheetEmailModalOpen={setFactsheetEmailModalOpen}
                projectId={id}
                userListData={userListData}
            />

        </div>
    )
}

export default BdBIdPrepration;