import React from 'react'
import { Form,  Modal, Select, } from 'antd'
const BdConsortiumModal = ({ consortiumModal, setConsortiumModal }) => {
    const handleSubmitConsortium = () => {
        setConsortiumModal(false)
    }
    return (
        <Modal title="Consortium" className='bd_model_main'

            open={consortiumModal}
            onOk={() => setConsortiumModal(false)}
            onCancel={() => setConsortiumModal(false)}
            footer={[
                <button key="back" className='BG_ghostButton' >
                    Reset
                </button>,
                <button key="submit" onClick={handleSubmitConsortium} className='BG_mainButton' >
                    Submit
                </button>
            ]}
        >
            <Form name="validateOnly" layout="vertical" autoComplete="off"
            // onKeyDown={handleKeyPress}
            >
                <Form.Item label="Lead Companhy">
                    <Select placeholder='Select Value' />
                </Form.Item>
                <Form.Item label="JV(Joint Venture)">
                    <Select placeholder='Select Value' />
                </Form.Item>
            </Form>
        </Modal>
    )
}

export default BdConsortiumModal