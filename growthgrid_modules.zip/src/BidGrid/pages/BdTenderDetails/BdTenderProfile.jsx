// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Button, Table, Checkbox, Form, Select, Row, Col, Drawer, Input, Mentions, Modal, Upload, Avatar, Dropdown, Flex, Menu, Spin, DatePicker } from 'antd';
import editBtn from '../../assets/images/icons/editbtn.png';
import commentBtn from '../../assets/images/icons/comments.png';

import docIcon from "../../assets/images/icons/file_present.png";
import emptyCommentImg from "../../assets/images/chat.png"

import skipBack from '../../assets/images/skip-back.png'
import TodoComments from 'BidGrid/components/Drawer/TodoComment';
import { bidProspective } from 'Services/bidgrid/prospective/bidProspective';
import { bidRegion } from 'Services/bidgrid/master/region/region';
import { AddTenderList } from 'Services/bidgrid/add/AddTender';
import { useSelector } from 'react-redux';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import dayjs from 'dayjs';
import { useLocation, useParams } from 'react-router-dom';
import { PlusCircleOutlined } from '@ant-design/icons';
import { toast } from 'react-toastify';
import { DocumentApi } from 'Services/bidgrid/tenderList/DocumentApi';
import { Down, More, Plus, Write, Close, Textarea } from '@icon-park/react';
import Delete from 'BidGrid/components/modalDelete/Delete';
import { EXTENSIONS } from 'Constants/Extension';
import xlsImg from '../../../assests/img/xls.png'
import coregImg from "../../../assests/img/pdf.png"
import fileImg from '../../../assests/img/file.png';
import { useRef } from 'react';
import { useCallback } from 'react';
import { debounce } from 'lodash';
import { SendOutlined, UploadOutlined } from '@ant-design/icons';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import { navigationData } from 'Redux/actions/bidgrid/navigationData';
import { useDispatch } from 'react-redux';
import { docAuth, docurlchat } from 'utils/configurable';
import downloadFileIcon from "../../assets/images/download.png";
import { TimeConverter } from 'BidGrid/components/TimeConverter/TimeConverter';
import { bidCompany } from 'Services/bidgrid/master/company/bidCompany';
const { TextArea } = Input;

const { Option } = Select;

const getBase64 = (file) =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
    });

const initialState = {
    tender_id: null,
    tender_name: '',
    tender_cost: '',
    tender_emd_amnt_val: '',
    client_cont_person: '',
    client_cont_address: '',
    bid_validity_date: null,
    publication_date: null,
    client_id: null,
    currency_id: null,
    region_id: null,
    country_id: null,
    state_id: null,
    city_id: null,
    sector_id: null,
    funding_id: null,
    cycle_id: null,
    national_intern: null,
    client_manager: null,
    bid_manager: null,
    submission_end_date: null,
    submission_start_date: null,
    pre_bid_meeting_date: null,
    publication_date: null
}

const intidata = {
    lead_comp_id: null,
    associats_id: [],
    jvs_company: []
}

const initCompanyArr = {
    lead_comp_id: [],
    associats_id: [],
    jvs_company: []
}

const initialDoc = {
    tender_doc: [],
    file_doc_description: ''
}

const BdTenderProfile = ({ detailsData, trackHistory, getTenderBdDetails, scopeStatus, activeTabKey, consortiumStatus }) => {
    const { BidClient, BidFundingClientAgency, BidCurrency, BidCountry, BidSector } = useSelector((state) => state.bidDropdownCalVal)
    const { socket, isConnected } = useSelector((state) => state.socket);
    const location = useLocation()
    const dispatch = useDispatch()
    const { id } = useParams()

    const { navigateData } = useSelector((state) => state.navigationData)

    // form conatiner
    const [formFieldsValues, setFormFiledsValues] = useState(initialState)

    // form validations
    const [form] = Form.useForm()
    const [formCompany] = Form.useForm()
    const [form1] = Form.useForm()
    const [form2] = Form.useForm()

    // refrence of mentions input
    const replyfocus = useRef(null);

    // modal / drawer states
    const [addDocModalOpen, setAddDocModalOpen] = useState(false)
    const [detailsDrawerOpen, setDetailsDrawerOpen] = useState(false)
    const [commentDrawerOpen, setCommentDrawerOpen] = useState(false)
    const [companyAdd, setCompanyAdd] = useState(false)

    // data conatiners
    const [userList, setUserList] = useState([]);
    const [rearrangedUserList, setRearrangedUserList] = useState();
    const [tenderComments, setTenderComments] = useState([])
    const [statelist, setStateList] = useState([])
    const [cityList, setCityList] = useState([])
    const [regionList, setRegionList] = useState([])

    //handle change states
    const [inputValue, setInputValue] = useState('');
    const [addConsortiumCompany, setAddConsortiumCompany] = useState({
        company_name: '',
        company_details: ''
    })

    // comment states
    const [parentId, setParentId] = useState(0)
    const [editId, setEditId] = useState(null)
    const [replyUser, setReplyUser] = useState({})
    const [replyStatus, setReplyStatus] = useState(false);

    //consortium states
    const [consortiumInitial, setConsortiumInitial] = useState(intidata)
    const [disabledOption, setDisabledOption] = useState({
        disableLead: [],
        disableJvs: [],
        disableAssociative: []
    })
    const [disabledOptionComp, setDisabledOptionComp] = useState({
        disableLead: [],
        disableJvs: [],
        disableAssociative: []
    })
    const [companyComp, setCompanyComp] = useState({
        comptitor_data: [],
        consortium_data: []
    })
    const [isRefreshed, setIsRefreshed] = useState(false)
    const [apiConsortiumData, setApiConsortiumData] = useState({})
    const [companyOptions, setCompanyOptions] = useState(initCompanyArr)
    const [soloStatus, setSoloStatus] = useState(false)
    const [checksoloStatus, setCheckSoloStatus] = useState(false)
    const [companyVal, setCompanyVal] = useState([])

    // document 
    const [DocumentList, setDocumentList] = useState([])
    const [addDocument, setAddDocument] = useState(initialDoc)
    const [orderDirection, setOrderDirection] = useState();
    const [pageSize, setPageSize] = useState(5)
    const [modalData, setModalData] = useState({});
    const [deleteModal, setDeleteModal] = useState(false)
    const [errorsCompanyMsg, setErrorsCompanyMsg] = useState(false)
    const [spinner, setSpinner] = useState(false)
    const { userBidInfo } = useSelector((state) => state?.userDetails)
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);


    // Upload
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
    const [fileList, setFileList] = useState([]);
    const [binaryData, setBinaryData] = React.useState(null);

    const [loadings, setLoadings] = useState({
        loadingCon: false,
        loadingEdit: false,
        loadingDoc: false
    });
    const [errorMsgDate, setErrorMsgDate] = useState(false)


    const handleCancel = () => setPreviewOpen(false);

    const options = [];
    for (let i = 10; i < 36; i++) {
        options.push({
            value: i.toString(36) + i,
            label: i.toString(36) + i,
        });
    }


    const exceptSymbol = ['e', 'E', '+', '-', '.'];



    const columns = [
        {
            title: (
                <div>
                    S. No.
                </div>
            ),
            dataIndex: 'srNo',
            sorter: (a, b) => a.srNo - b.srNo,
            width: 50,
            render: (text, record, index) => index + 1, // Render the index (plus 1) as Sr No
        },

        {
            title: (
                <div>
                    Document

                </div>
            ),
            dataIndex: 'file_name',
            sorter: (a, b) => a.file_name - b.file_name,
            // width: 300,
            render: ((record, item) => {
                let fileExtension = record.slice(-3)
                let imgUrl
                switch (fileExtension) {
                    case EXTENSIONS.XLS:
                        imgUrl = xlsImg
                        break;
                    case EXTENSIONS.PDF:
                        imgUrl = coregImg
                        break;
                    default:
                        imgUrl = fileImg
                        break;
                }
                return (
                    <>
                        <a href={`${item?.tender_category === 3 ? docAuth : docurlchat}${item?.doc_path}/${item?.file_name}`} target="_blank">
                            <img src={imgUrl} width={30} /> {item?.file_name}
                        </a>
                        {/* <a href={`https://api.growthgrids.com/bd_growthgrids/doc_file/${item?.doc_path}/${item?.file_name}`} download={`https://api.growthgrids.com/bd_growthgrids/doc_file/${item?.doc_path}/${item?.file_name}`} target="_blank">
                            <img src={imgUrl} width={30} /> {item?.file_name}
                        </a> */}

                    </>
                )
            })


        },

        {
            title: (
                <div>
                    Created On
                </div>
            ),
            dataIndex: 'created_at',
            sorter: (a, b) => a.created_at - b.created_at,
            // width: 50,
            render: ((item) => {
                return (
                    <>

                        {item != null ? `${dayjs(item).format('DD-MM-YYYY')} ${TimeConverter(item)}` : '-'}

                    </>
                )
            })

        },

        {
            title: (
                <div>
                    created by
                </div>
            ),
            dataIndex: 'created_by',
            sorter: (a, b) => a.created_by - b.created_by,
            // width: 50,
            render: ((item) => {
                return (
                    <>
                        {
                            item !== null ? userList?.filter(items => items?.id === item)?.map(val => val?.userfullname) : "Tender Grid"
                        }
                    </>
                )
            })

        },
        {
            title: "Action",
            dataIndex: '',
            width: 70,
            render: ((item) => {
                return (
                    <>
                        <Dropdown
                            // menu={{ items: getItems(item) }}
                            placement="bottomRight"
                            overlay={
                                <Menu className="bd_tableAction">
                                    <Menu.Item key="edit" className='bd_view_btn' onClick={() => documentFileDownload(item)}>
                                        {/* <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip0_221_1663)">
                                                <path d="M8.25 3H3C2.60218 3 2.22064 3.15804 1.93934 3.43934C1.65804 3.72064 1.5 4.10218 1.5 4.5V15C1.5 15.3978 1.65804 15.7794 1.93934 16.0607C2.22064 16.342 2.60218 16.5 3 16.5H13.5C13.8978 16.5 14.2794 16.342 14.5607 16.0607C14.842 15.7794 15 15.3978 15 15V9.75" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M13.875 1.87505C14.1734 1.57668 14.578 1.40906 15 1.40906C15.422 1.40906 15.8266 1.57668 16.125 1.87505C16.4234 2.17342 16.591 2.57809 16.591 3.00005C16.591 3.422 16.4234 3.82668 16.125 4.12505L9 11.25L6 12L6.75 9.00005L13.875 1.87505Z" stroke="#636363" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            </g>
                                            <defs>
                                                <clipPath id="clip0_221_1663">
                                                    <rect width="18" height="18" fill="white" />
                                                </clipPath>
                                            </defs>
                                        </svg> */}
                                        <span><img src={downloadFileIcon} width={20} /></span>
                                        Download
                                    </Menu.Item>

                                    {
                                        item.created_by !== null ?
                                            <Menu.Item key="delete" onClick={() => deleteDocument(item)} className='bd_delete_btn'>
                                                <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M2.25 4.5H3.75H15.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72064 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M7.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M10.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                                Delete
                                            </Menu.Item>
                                            : ""
                                    }
                                </Menu>

                            }
                        >
                            <a onClick={(e) => e.preventDefault()}
                            >
                                <More theme="outline" size="25" fill="#95a6b6" strokeWidth={3} />
                            </a>
                        </Dropdown>
                    </>
                )
            }


            ),
        }


    ];

    // document functions
    const deleteDocument = (items) => {
        setModalData(items)
        setDeleteModal(true)
    }


    const documentBlobReq = async (doc_name, apiUrl) => {
        const fullUrl = window.location.href;
        const urlObject = new URL(fullUrl);
        const protocol = urlObject.protocol;
        const hostname = urlObject.host;
        const domain = `${protocol}//${hostname}`;
        const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
        const response = await fetch(proxyUrl)
        const blobData = await response?.blob()
        const fileURL = window.URL.createObjectURL(blobData);
        let alink = document.createElement("a");
        alink.href = fileURL;
        alink.download = doc_name;
        alink.click();
    }
    const documentFileDownload = (item) => {
        const apiUrl = `${docurlchat}${item?.doc_path}/${item?.file_name}`;
        documentBlobReq(item?.file_name, apiUrl)
    }
    const documentDownload = (item) => {
        const apiUrl = `${docurlchat}${item?.file_path}/${item?.file_name}`;
        documentBlobReq(item?.file_name, apiUrl)
    }
    const showModalCompany = () => {
        setCompanyAdd(true)

    }

    const handleDocChange = (name, value) => {
        setAddDocument({ ...addDocument, [name]: value })
    }

    const fetchDocument = async (initial) => {
        if (initial) {
            setSpinner(true)
        }
        const formData = new URLSearchParams()
        formData.append('tender_id', id)
        try {
            const res = await DocumentApi.DocumentList(formData)
            if (res?.data?.status === '1') {
                setDocumentList(res?.data?.data)
                setSpinner(false)
            } else {
                setDocumentList([])
                setSpinner(false)
            }
        } catch (error) {
            console.log(error, 'api erorr')
            setSpinner(false)
        }
    }

    const handleLoading = (key, value) => {

        setLoadings(prevLoadings => ({
            ...prevLoadings,
            [key]: value
        }));
    };

    const AddDocument = async (values) => {
        handleLoading('loadingDoc', true);
        const formData = new FormData();
        formData.append('tender_id', id);
        formData.append('file_doc_description', values?.file_doc_description);
        addDocument?.tender_doc?.forEach((file, index) => {
            formData.append('tender_doc', file.originFileObj);
        });
        try {
            const response = await DocumentApi?.addDocument(formData);
            if (response?.data?.status == 1) {
                setSpinner(true)
                notifySuccess("Document added");
                await fetchDocument(false);
                handleReset();
                setAddDocModalOpen(false);
                handleLoading('loadingDoc', false);
            } else {
                notify(response?.response?.data?.message);
                handleLoading('loadingDoc', false);
                setSpinner(false)
            }
        } catch (error) {
            console.log(error, 'Api Error');
            handleLoading('loadingDoc', false);
            setSpinner(false)
        }
    }

    const handleReset = () => {
        form.resetFields()
        setAddDocument(initialDoc)
    }

    useEffect(() => {
        if (userList?.length > 0) {
            fetchDocument(true)
        }
    }, [userList])

    const handleDelete = async (docId) => {
        const formData = new URLSearchParams();
        formData.append('tender_doc_id', docId);
        try {
            const response = await DocumentApi.deleteDocument(formData);
            if (response?.data?.status == 1) {
                setSpinner(true)
                notifySuccess("Document delete successfully");
                await fetchDocument(false)
            } else {
                notify(response?.response?.data?.message);
                setSpinner(false)
            }
        } catch (error) {
            console.log(error, "Api");
            setSpinner(false)
        }
    }

    const handleModalAdd = () => {
        setAddDocModalOpen(true)
    }
    // edit profile functions 
    const getState = async () => {

        const formData = new URLSearchParams()
        formData.append('country_id', detailsData?.edittender?.country_id)
        try {
            const res = await bidProspective.getStateList(formData)
            if (res?.data?.status === '1') {
                setStateList(res?.data?.data)
            } else {
                setStateList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const getStateDrawer = async () => {
        const formData = new URLSearchParams()
        formData.append('country_id', formFieldsValues?.country_id)
        try {
            const res = await bidProspective.getStateList(formData)
            if (res?.data?.status === '1') {
                setStateList(res?.data?.data)
            } else {
                setStateList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const getCity = async (stateId) => {
        const formData = new URLSearchParams()
        formData.append('state_id', formFieldsValues?.state_id ? formFieldsValues?.state_id : stateId)
        try {
            const res = await AddTenderList.getTenderCityList(formData)
            if (res?.data?.status === '1') {
                setCityList(res?.data?.data)
            } else {
                setCityList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const handleRegionList = async () => {
        const formData = new URLSearchParams();
        formData.append('country_id', formFieldsValues?.country_id);
        try {
            const response = await bidRegion.getRegionList(formData)
            if (response?.data?.status === '1') {
                setRegionList(response?.data?.data)
            } else {
                setRegionList([])
                // notify(response?.response?.data?.message)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    useEffect(() => {
        if (detailsData?.edittender?.country_id) {
            getState()
            handleRegionList()
        }
    }, [detailsData])


    useEffect(() => {
        if (formFieldsValues?.country_id) {
            getStateDrawer()
            handleRegionList()
        }
    }, [formFieldsValues?.country_id])


    useEffect(() => {
        if (formFieldsValues?.state_id) {
            getCity()
        }
    }, [formFieldsValues?.state_id,])

    useEffect(() => {
        if (detailsData?.edittender?.state_id) {
            getCity(detailsData?.edittender?.state_id)
        }
    }, [detailsData?.edittender?.state_id])

    const handleSubmitDrawer = async (value) => {

        if (formFieldsValues?.submission_end_date !== null) {
            handleLoading('loadingEdit', true);
            const formData = new URLSearchParams();
            formData.append('tender_id', id);
            formData.append('tender_name', value?.tender_name);
            formData.append('tender_cost', value?.tender_cost);
            formData.append('tender_emd_amnt_val', value?.tender_emd_amnt_val);
            formData.append('client_cont_person', value?.client_cont_person);
            formData.append('client_cont_address', value?.client_cont_address);
            formData.append('client_id', value?.client_id);
            formData.append('currency_id', value?.currency_id);
            formData.append('region_id', formFieldsValues?.region_id !== null ? formFieldsValues?.region_id : '');
            formData.append('country_id', value?.country_id);
            formData.append('state_id', value?.state_id);
            formData.append('city_id', formFieldsValues?.city_id ? formFieldsValues?.city_id : '');
            formData.append('sector_id', value?.sector_id);
            formData.append('funding_id', value?.funding_id ? value?.funding_id : '');
            // formData.append('cycle_id', value?.cycle_id);
            // formData.append('national_intern', value?.national_intern);
            formData.append('submission_end_date', formFieldsValues?.submission_end_dat !== null ? dayjs(formFieldsValues?.submission_end_date).format('YYYY-MM-DD') : '');
            formData.append('pre_bid_meeting_date', formFieldsValues?.pre_bid_meeting_date !== null ? dayjs(formFieldsValues?.pre_bid_meeting_date).format('YYYY-MM-DD') : '');
            formData.append('bid_validity_date', formFieldsValues?.bid_validity_date !== null ? dayjs(formFieldsValues?.bid_validity_date).format('YYYY-MM-DD') : '');
            formData.append('publication_date', formFieldsValues?.publication_date !== null ? dayjs(formFieldsValues?.publication_date).format('YYYY-MM-DD') : '');
            formData.append('submission_start_date', formFieldsValues?.submission_start_date !== null ? dayjs(formFieldsValues?.submission_start_date).format('YYYY-MM-DD') : '');
            formData.append('key_client_manager', formFieldsValues?.client_manager !== null ? formFieldsValues?.client_manager : '');
            formData.append('bid_manager', formFieldsValues?.bid_manager !== null ? formFieldsValues?.bid_manager : '');
            try {
                const response = await TenderApi.updateTenderdesc(formData)
                if (response?.data?.status === '1') {
                    await getTenderBdDetails()
                    setDetailsDrawerOpen(false)
                    handleLoading('loadingEdit', false);
                    notifySuccess("Profile update successfully")
                    setDetailsDrawerOpen(false)

                } else {
                    setDetailsDrawerOpen(false)
                    notify(response?.response?.data?.message)
                    handleLoading('loadingEdit', false);
                }
            } catch (error) {
                notify(error)
                setDetailsDrawerOpen(false)
                handleLoading('loadingEdit', false);
                console.log(error, "else")
            }
        }

    }

    const handleSelectChange = (name, value) => {
        if (name === 'country_id') {
            form2.setFieldsValue({
                state_id: '',
                city_id: '',
                region_id: ''
            });
            setStateList([])
            setCityList([])
        }
        if (name === 'state_id') {
            form2.setFieldsValue({
                city_id: '',
            });
            setCityList([])
        }
        if (name === 'submission_end_date') {
            setErrorMsgDate(false)
        }
        setFormFiledsValues({ ...formFieldsValues, [name]: value })
    }

    const handlePredefined = () => {

        const newObj = {
            tender_id: id ? id : null,
            tender_name: detailsData?.edittender?.tender_name ? detailsData?.edittender?.tender_name.replace(/<[^>]*>/g, '') : '',
            tender_cost: detailsData?.edittender?.tender_cost ? detailsData?.edittender?.tender_cost : '',
            tender_emd_amnt_val: detailsData?.edittender?.tender_emd_amnt_val ? detailsData?.edittender?.tender_emd_amnt_val : '',
            client_cont_person: detailsData?.edittender?.client_cont_person ? detailsData?.edittender?.client_cont_person : '',
            client_cont_address: detailsData?.edittender?.client_cont_address ? detailsData?.edittender?.client_cont_address : '',
            client_id: BidClient?.find(val => val.id === detailsData?.edittender?.client_id)?.hasOwnProperty('id') ? detailsData?.edittender?.client_id : null,
            currency_id: BidCurrency?.find(val => val.id === detailsData?.edittender?.currency_id)?.hasOwnProperty('id') ? detailsData?.edittender?.currency_id : null,
            region_id: regionList?.find(val => val.id === detailsData?.edittender?.region_id)?.hasOwnProperty('id') ? detailsData?.edittender?.region_id : null,
            country_id: detailsData?.edittender?.country_id ? detailsData?.edittender?.country_id : null,
            state_id: statelist?.find(val => val.id === detailsData?.edittender?.state_id)?.hasOwnProperty('id') ? detailsData?.edittender?.state_id : null,
            city_id: cityList?.find(val => val?.id === detailsData?.edittender?.city_id)?.hasOwnProperty('id') ? detailsData?.edittender?.city_id : null,
            sector_id: BidSector?.find(val => val.id === detailsData?.edittender?.sector_id)?.hasOwnProperty('id') ? detailsData?.edittender?.sector_id : null,
            funding_id: detailsData?.edittender?.funding_id ? detailsData?.edittender?.funding_id : null,
            cycle_id: detailsData?.edittender?.cycle_id ? detailsData?.edittender?.cycle_id : null,
            national_intern: detailsData?.edittender?.national_intern ? detailsData?.edittender?.national_intern : null,
            submission_start_date: detailsData?.edittender?.submission_start_date ? detailsData?.edittender?.submission_start_date : null,
            publication_date: detailsData?.edittender?.publication_date ? detailsData?.edittender?.publication_date : null,
            pre_bid_meeting_date: detailsData?.edittender?.pre_bid_meeting_date ? detailsData?.edittender?.pre_bid_meeting_date?.split("T")[0] : null,
            bid_validity_date: detailsData?.edittender?.bid_validity_date ? detailsData?.edittender?.bid_validity_date?.split("T")[0] : null,
            publication_date: detailsData?.edittender?.publication_date ? detailsData?.edittender?.publication_date?.split("T")[0] : null,
            submission_end_date: detailsData?.edittender?.submission_end_date ? detailsData?.edittender?.submission_end_date?.split("T")[0] : null,
            bid_manager: detailsData?.Bid_Manager ? detailsData?.Bid_Manager?.assign_to : null,
            client_manager: detailsData?.key_client_manger ? detailsData?.key_client_manger?.assign_to : null,
        }

        setFormFiledsValues((prevState) => {
            return {
                ...prevState,
                ...newObj,
            };
        });
        form2.setFieldsValue(newObj)

    }

    useEffect(() => {
        if (detailsDrawerOpen) {
            handlePredefined()
        }
    }, [detailsDrawerOpen])


    // consortium functions list



    // for calling solo company list 
    // const getCompany = async () => {

    //     try {
    //         const response = await bidCompany.getCompanyList();
    //         if (response?.data?.status === '1') {
    //             setCompanyVal(response?.data?.data)
    //         } else {
    //             setCompanyVal([])
    //         }
    //     } catch (error) {
    //         console.log(error)
    //     }
    // };

    // const handleInputChange = (e) => {
    //     setAddConsortiumCompany({ ...addConsortiumCompany, [e.target.name]: e?.target?.value });
    // };


    const fetchConsortiumStatus = async () => {

        const formData = new URLSearchParams();
        formData.append('project_id', id);
        try {
            const response = await TenderApi.updateConsortiumStatus(formData)

            if (response?.data?.status === '1') {
                if (response?.data?.is_solo === '1') {
                    getCompetitorList(true)
                    setSoloStatus(true)
                } else {
                    getCompetitorList(false)
                    setSoloStatus(false)
                }
            } else {
                getCompetitorList(false)
            }
        } catch (error) {
            console.log(error, 'api erorr')
            getCompetitorList(false)
        }
    }



    const getCompetitorList = async (isSolo) => {

        const formData = new URLSearchParams();
        formData.append('project_id', id);
        try {
            const response = await TenderApi.competitorCompany(formData)
            if (response?.data?.status === '1') {

                let consortiumData = [];
                let comptitorData = [];

                response?.data?.data?.forEach(item => {
                    const leadCompanines = item.comptitor_assign_company_list.Lead_company;

                    leadCompanines?.forEach(val => {
                        if (val?.type_data === '1') {
                            consortiumData?.push(item)
                        } else if (val?.type_data === '2') {
                            comptitorData.push(item)
                        } else {
                            return
                        }
                    })
                })
                disableCompetitorCompanies(comptitorData)

                if (consortiumData?.length > 0 && !isSolo) {
                    let leadData
                    let associativeData
                    let jvsData
                    consortiumData?.map(item => {
                        leadData = Number(item?.comptitor_assign_company_list?.Lead_company[0]?.company_id)
                        associativeData = item?.comptitor_assign_company_list?.associative_company?.map(item => Number(item?.company_id)) || [];
                        jvsData = item?.comptitor_assign_company_list?.jvs_company?.map(item => Number(item?.company_id)) || []
                    })
                    const newObj = {
                        lead_comp_id: leadData,
                        associats_id: associativeData,
                        jvs_company: jvsData
                    }

                    setConsortiumInitial((prevState) => {
                        return {
                            ...prevState,
                            ...newObj,
                        };
                    });
                    setIsRefreshed(true)
                } else {
                    setConsortiumInitial((prevState) => {
                        return {
                            ...prevState,
                            lead_comp_id: [],
                            associats_id: [],
                            jvs_company: []
                        };
                    });
                }
            }
            else {
                setCompanyComp([])
            }

        } catch (error) {
            console.log(error, "else")

        }
    }

    const disableCompetitorCompanies = (comptitor_data) => {
        let disableCompetitorIds = [];
        if (comptitor_data?.length > 0) {
            comptitor_data?.map(item => {
                disableCompetitorIds.push(Number(item?.comptitor_assign_company_list?.Lead_company[0]?.company_id))
                const associativeCompanyIds = item?.comptitor_assign_company_list?.associative_company?.map(item => Number(item?.company_id));

                if (associativeCompanyIds) {
                    disableCompetitorIds.push(...associativeCompanyIds);
                }
                const jvsCompanyIds = item?.comptitor_assign_company_list?.jvs_company?.map(item => Number(item?.company_id))

                if (jvsCompanyIds) {
                    disableCompetitorIds.push(...jvsCompanyIds);
                }
            })
        }
        const { disableLead, disableJvs, disableAssociative } = disabledOptionComp;

        let disableLead_new = [...disableLead, ...disableCompetitorIds];
        let disableJvs_new = [...disableJvs, ...disableCompetitorIds];
        let disableAssociative_new = [...disableAssociative, ...disableCompetitorIds];

        setDisabledOptionComp({
            disableLead: disableLead_new,
            disableJvs: disableJvs_new,
            disableAssociative: disableAssociative_new
        });
    }


    const predefinedVal = () => {
        const { disableLead, disableJvs, disableAssociative } = disabledOptionComp
        const existsAss = consortiumInitial?.associats_id || [];
        const existsJvs = consortiumInitial?.jvs_company || [];
        const existsLeadComp = consortiumInitial?.lead_comp_id !== null ? consortiumInitial?.lead_comp_id : [];

        let disableLead_new = [...existsAss, ...existsJvs, ...disableLead];
        let disableJvs_new = [existsLeadComp, ...existsAss, ...disableJvs];
        let disableAssociative_new = [existsLeadComp, ...existsJvs, ...disableAssociative];

        disableJvs_new?.filter(item => {
            if (item?.length === 0) {
                disableJvs_new.splice(0, 1)
            } else {
                return disableJvs_new
            }
        })

        disableAssociative_new?.filter(item => {
            if (item?.length === 0) {
                disableAssociative_new.splice(0, 1)
            } else {
                return disableAssociative_new
            }
        })

        setDisabledOption({
            disableLead: disableLead_new,
            disableJvs: disableJvs_new,
            disableAssociative: disableAssociative_new
        });

    }

    useEffect(() => {
        predefinedVal()
    }, [consortiumInitial?.lead_comp_id, consortiumInitial?.associats_id, consortiumInitial?.jvs_company]);

    const getconsortiumCompanyList = async () => {
        const formData = new URLSearchParams();
        formData.append('project_id', id)
        try {
            const response = await TenderApi?.CompetitorList(formData)
            if (response?.data?.status == 1) {

                setCompanyOptions((prevState) => ({
                    ...prevState,
                    lead_comp_id: response?.data?.data,
                    associats_id: response?.data?.data,
                    jvs_company: response?.data?.data
                }))

            }

        } catch (error) {
            console.log(error)
        }
    };

    const handleConsortiumSubmit = async () => {

        if (!soloStatus && consortiumInitial?.lead_comp_id === null) {
            setErrorsCompanyMsg(true)
            return
        } else {
            handleLoading('loadingCon', true);

            try {
                const formData = new URLSearchParams();
                formData.append('project_id', id)
                if (soloStatus) {
                    formData.append('solo', soloStatus)
                } else {
                    formData.append('lead_comp_id', consortiumInitial?.lead_comp_id)
                    { consortiumInitial?.jvs_company?.length > 0 && formData.append('jvs_company', consortiumInitial?.jvs_company) }
                    { consortiumInitial?.associats_id?.length > 0 && formData.append('associats_id', consortiumInitial?.associats_id) }
                }
                const response = await TenderApi.updateConsortium(formData)
                if (response?.data?.status == 1) {

                    form1.resetFields()
                    setConsortiumInitial(intidata)
                    handleLoading('loadingCon', false);
                    notifySuccess("Company updated")
                    await fetchConsortiumStatus()
                }
                else {
                    handleLoading('loadingCon', false);
                }

            } catch (error) {
                console.log('Api Error', error);
                handleLoading('loadingCon', false);
            }
        }

    }

    const handleCompanyAdd = async (value) => {
        const formData = new URLSearchParams();
        formData.append("company_name", value?.company_name);
        formData.append("company_details", value?.company_details);
        try {
            const response = await TenderApi?.centerlizeCompany(formData);
            if (response?.data?.status == 1) {
                await getconsortiumCompanyList()
                setAddConsortiumCompany({
                    company_name: '',
                    company_details: ''
                })
                notifySuccess("Company Added Successfully")
                setCompanyAdd(false)
                formCompany.resetFields()
            }
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    }


    const handleSoloChange = (e) => {
        if (!checksoloStatus) {
            setSoloStatus(e?.target?.checked)
        }

    }

    const handleConsortiumChange = (name, value) => {
        if (name === "lead_comp_id") {
            setErrorsCompanyMsg(false)
        }
        setConsortiumInitial((prevDataOption) => ({
            ...prevDataOption,
            [name]: value === undefined ? null : value
        }));
    };
    // comment tender functions
    const assignUserList = async () => {
        try {
            const res = await bidEmployeeList.getUserList()
            if (res?.data?.status == '1') {
                setUserList(res?.data?.data)
            } else {
                setUserList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const handleComment = () => {
        setCommentDrawerOpen(true)
    }

    const userGetCommentList = async (setGetUserCommentData) => {

        const formData = new URLSearchParams();
        formData.append('tender_id', id)
        try {
            const response = await TenderApi.tenderCommentList(formData)
            if (response?.data?.status === '1') {
                setTenderComments(response?.data?.data)
                setGetUserCommentData(response?.data?.data)
            } else {
                setGetUserCommentData([])
                setTenderComments([])
            }
        } catch (error) {
            console.log('no comments yet')
        }
    }


    const commentSection = (inputValue) => {
        let inputArr = inputValue?.split(' ')
        return (
            <>
                {
                    inputArr?.map((item) => {
                        return (
                            <span className={item.includes('@') ? "userTag" : ""}>{item} &nbsp;</span>
                        )
                    })
                }
            </>
        )
    }

    function formatDateUtcWithMonthName(dateString) {
        if (dateString) {
            const monthNames = [
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'Sept', 'Oct', 'Nov', 'Dec'
            ];

            const date = new Date(dateString);
            const day = date.getUTCDate().toString().padStart(2, '0');
            const month = monthNames[date.getUTCMonth()];
            const year = date.getUTCFullYear();
            return `${day} ${month} ${year}`;
        } else {
            return '';
        }
    }






    // fetch consortium data




    // competitor Assign list


    // const getconsortiumCompanyListAll = async () => {
    //     try {
    //         const response = await TenderApi?.getAllCompanyList()
    //         if (response?.data?.status == 1) {
    //             setCompanyOptions((prevState) => ({
    //                 ...prevState,
    //                 lead_comp_id: response?.data?.data,
    //                 associats_id: response?.data?.data,
    //                 jvs_company: response?.data?.data
    //             }))

    //             setConsortiumCompanies(response?.data?.data)
    //         }
    //         else {
    //             setConsortiumCompanies([])
    //         }
    //     } catch (error) {
    //         console.log(error)
    //     }
    // };

    // update consortium 






    useEffect(() => {
        userGetCommentList()
    }, [id])

    useEffect(() => {

        assignUserList()
        getconsortiumCompanyList()
        // getCompany()
    }, [])



    useEffect(() => {

        if (activeTabKey === '1') {
            fetchConsortiumStatus()
        }

    }, [activeTabKey])




    //comment section statements


    const onSearch = useCallback(
        debounce(async (search) => {
            const filteredUsers = rearrangedUserList?.map((item) => {
                let userfullnameInp = item?.userfullname
                if (userfullnameInp?.includes(search?.toLowerCase())) {
                    return item
                }
            })
        }, 300),
        []
    );


    const handleChangeComment = (value) => {
        if (value.startsWith(' ')) {
            setInputValue(value.trimStart());
        } else {
            setInputValue(value);
        }
    };

    useEffect(() => {
        let usersMapped = userList?.filter(item => item.isactive === 1)?.map((val) => {
            const inputString = val.userfullname
            const words = inputString?.toLowerCase()?.split(' ');
            const result = words?.map((word, index) => (index === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)))?.join('');
            return { id: val.id, userfullname: result, profileimg: val.profileimg, profileimg_path: val?.profileimg_path }
        })
        setRearrangedUserList(usersMapped)
    }, [userList])


    useEffect(() => {
        if (isConnected && window.location.pathname.includes('bdtenderdetails')) {
            if (!commentDrawerOpen) {
                const socketListener = (data) => {
                    setTenderComments(prevComments => {
                        const existingIndex = prevComments.findIndex(comment => comment.id === data.id);
                        if (existingIndex !== -1) {
                            return prevComments.map((comment, index) =>
                                index === existingIndex ? data : comment
                            );
                        } else {
                            return [...prevComments, data];
                        }
                    });
                };

                socket.on(detailsData?.edittender?.id, socketListener);
                return () => {
                    socket.off(detailsData?.edittender?.id, socketListener);
                };
            }
        }
    }, [isConnected, detailsData, commentDrawerOpen]);


    const AddComment = async () => {

        if (inputValue !== '') {
            let userVar = []
            inputValue?.split(' ')?.filter((val) => val?.includes('@'))
                ?.map((item) => {
                    return rearrangedUserList?.filter((elem) => '@' + elem.userfullname === item)?.forEach((value) => {
                        userVar.push(value.id)
                    });
                });

            const uniqueArray = [...new Set(userVar)];
            let socketDetailShare = { comment_id: editId, file: fileList, tender_id: id, parent_id: parentId, comment_txt: inputValue, ping_users_info: uniqueArray?.join(',') }
            if (isConnected) {
                socket.emit('tender_comment', socketDetailShare);
            }
            // await userGetCommentList()
            handleCancelReply()
        }

    }

    useEffect(() => {
        const element = document.querySelector('.commentsDetails_forms');
        element.scrollTop = element.scrollHeight;
    }, [tenderComments])



    const handlePreview = async (file) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj);
        }
        setPreviewImage(file.url || file.preview);
        setPreviewOpen(true);
        setPreviewTitle(
            file.name || file.url.substring(file.url.lastIndexOf('/') + 1)
        );
    };
    const handleChange = ({ fileList: newFileList }) => {
        setFileList(newFileList)
        if (fileList.length === 1) {
            const file = fileList[0];
            const reader = new FileReader();
            reader.onload = () => {
                setBinaryData(reader.result); // Store the binary data in state
            };
            reader.readAsArrayBuffer(file.originFileObj); // Read file as ArrayBuffer
        }
    };


    const uploadButton = (
        <button
            style={{
                border: 0,
                background: 'none',
            }}
            type="button"
        >
            <UploadOutlined />
        </button>
    );

    const handleRemove = (item) => {
        const newFileList = addDocument?.tender_doc?.filter((f) => f?.uid !== item?.uid);
        setAddDocument(prev => ({
            ...prev,
            tender_doc: newFileList
        }));
    };

    const beforeUpload = (file) => {
        const allowedExtensions = [
            '.pdf',
            '.doc',
            '.docx',
            '.xls',
            '.xlsx',
            '.txt',
            '.html',
            '.htm',
            '.json',
            '.odt',
            '.ods',
            '.ppt',
            '.pptx'
        ];

        const fileExtension = file?.name?.slice(file?.name?.lastIndexOf('.'))?.toLowerCase();
        if (!allowedExtensions?.includes(fileExtension)) {
            notify('You can only upload document files');
            return Upload.LIST_IGNORE; // This will ignore the file upload
        }
        return true;
    };
    const handleDoc = (info) => {
        if (info?.file?.status === 'done' || info?.file?.status === 'uploading') {
            Promise.all(info?.fileList?.map(file => new Promise((resolve, reject) => {
                getBase64(file.originFileObj)
                    .then(url => {
                        resolve({
                            uid: file?.uid,
                            name: file?.name,
                            status: 'done',
                            originFileObj: file?.originFileObj,
                            url: url
                        });
                    })
                    .catch(error => reject(error));
            })))
                .then(fileList => {
                    handleDocChange('tender_doc', fileList);
                })
                .catch(error => {
                    console.error('Error processing files:', error);
                    // Handle the error, notify the user, etc.
                });
        }
    };



    useEffect(() => {
        if (navigateData?.type === 'tender_comments' && navigateData?.hasOwnProperty('item')) {
            setCommentDrawerOpen(true)
            dispatch(navigationData.setNavigationDataAction({}))
        }
    }, [navigateData])

    const Updatedate = () => {
        if (formFieldsValues?.submission_end_date === null) {
            setErrorMsgDate(true)
        }
        else {
            setErrorMsgDate(false)
        }
    }

    const handleSpaceChange = (name, e) => {
        const trimmedValue = e.target.value.trimStart();
        form.setFieldsValue({ [name]: trimmedValue });
        formCompany.setFieldsValue({ [name]: trimmedValue });

    };

    const handleReply = (item) => {
        setEditId(null);
        setInputValue('')
        setParentId(item?.id);
        setReplyUser(item)
        replyfocus.current.focus()
        setReplyStatus(true)
    }

    const handleEditParent = (item) => {
        setEditId(item?.id);
        setParentId(0);
        setInputValue(item?.comment_txt)
        setReplyUser(item)
        setReplyStatus(true)
        replyfocus.current.focus()
    }
    const handleEditChild = (item) => {
        setEditId(item?.id);
        setParentId(item?.parent_id);
        setInputValue(item?.comment_txt)
        setReplyUser(item)
        setReplyStatus(true)
        replyfocus.current.focus()
    }
    const handleCancelReply = () => {
        setReplyUser({})
        setReplyStatus(false)
        setEditId(null);
        setInputValue('')
        setParentId(0)
        setFileList([])
    }
    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };
    const handleContainOnlyText = (e) => {
        // const alphabeticChars = /[a-zA-Z]/;
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            //  handleProjectInfo()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };
    const handleKeyPressSelectedItem = (e) => {
        const allowedChars = /[0-9.]/;
        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter' || (e.key === ' ' && e.target.selectionStart === 0)) {
            e.preventDefault();
        }
    };
    const showStatusColor = (scopeOrderSerial) => {
        switch (scopeOrderSerial) {
            case 1:
                return "one"

            case 2:
                return "two"

            case 3:
                return "three"

            case 4:
                return "four"

            case 5:
                return "five"

            case 6:
                return "six"

            case 7:
                return "seven"

            case 8:
                return "eight"

            default:
                break;
        }
    }

    useEffect(() => {
        if (!consortiumStatus) {
            fetchConsortiumStatus()
        }
    }, [consortiumStatus])


    return (
        <div className='profile_detail_info_box'>
            <div className='info_box_left'>
                <div className='tenderDetails_deatils'>
                    <div className='bd_tender_profile_headings'>
                        <h2>Details</h2>
                        <button className='edit_btn' onClick={(e) => setDetailsDrawerOpen(true)}>
                            <Write theme="outline" size="14" fill="#fff" strokeWidth={3} strokeLinecap="butt" /> Edit
                        </button>
                    </div>
                    <div className='tender_profile_fields'>
                        <div className='profile_fields_name'><span>GG Tender Id</span>:<p>{detailsData?.edittender?.tg_tender_id}</p></div>
                        <div className='profile_fields_name'><span>Generated Tender Id</span>:<p>{detailsData?.edittender?.bg_assign_tndr_generated_id?.generated_tender_id || 'Not Specified'}</p></div>

                        <div className='profile_fields_name'><span>Key Client Manager</span>:<p>{detailsData?.key_client_manger?.user?.userfullname || 'Not Specified'}</p></div>
                        <div className='profile_fields_name'><span>Bid Manager </span>:<p>{detailsData?.Bid_Manager?.user?.userfullname || 'Not Specified'}</p></div>
                        {/* <div className='profile_fields_name'><span>Bid Executive :</span><p></p></div>
                        <div className='profile_fields_name'><span>RFP Reviewer :</span><p></p></div> */}
                        <div className='profile_fields_name'><span>Pre-Bid Meeting Date</span>:<p>{detailsData?.edittender?.pre_bid_meeting_date}</p></div>
                        <div className='profile_fields_name'><span>Bid Submission Start Date</span>:<p>{detailsData?.edittender?.submission_start_date !== null ? `${formatDateUtcWithMonthName(detailsData?.edittender?.submission_start_date)} ${TimeConverter(detailsData?.edittender?.submission_start_date)}` : '-'}</p></div>
                        <div className='profile_fields_name'><span>Bid Submission End Date</span>:<p>{detailsData?.edittender?.submission_end_date !== null ? `${formatDateUtcWithMonthName(detailsData?.edittender?.submission_end_date)} ${TimeConverter(detailsData?.edittender?.submission_end_date)}` : '-'}</p></div>
                        <div className='profile_fields_name'><span>Sector </span>:<p>{BidSector?.filter(item => item?.id === detailsData?.edittender?.sector_id)?.map(item => item?.sector_name)}</p></div>
                        {/* <div className='profile_fields_name'><span>Country/State :</span>{<p>{`${BidCountry?.filter(item => item?.id === detailsData?.edittender?.country_id)?.map(item => item?.country_name)} / ${detailsData?.edittender?.state_id !== null ? statelist?.filter(item => item?.id === detailsData?.edittender?.state_id)?.map(item => item?.state_name) : ''}`}</p >}</div> */}
                        {/* <div className='profile_fields_name'><span>Country/State </span>:
                            <p>{`${BidCountry?.filter(item => item?.id === detailsData?.edittender?.country_id)?.map(item => item?.country_name)}`}
                                {detailsData?.edittender?.state_id &&
                                    ` / ${statelist?.filter(item => item?.id === detailsData?.edittender?.state_id)?.map(item => item?.state_name)}`
                                }
                                {detailsData?.edittender?.city_id &&
                                    ` / ${cityList?.filter(item => item?.id === detailsData?.edittender?.city_id)?.map(item => item?.city_name)}`
                                }
                            </p>
                        </div> */}
                        <div className='profile_fields_name'><span>Country/State </span>:
                            {/* <p>{detailsData?.edittender?.bg_mstr_country?.country_name ? detailsData?.edittender?.bg_mstr_country?.country_name : detailsData?.edittender?.bg_mstr_state != null ? `/${detailsData?.edittender?.bg_mstr_state?.state_name}` : detailsData?.edittender?.bg_mstr_city != null ? `/${detailsData?.edittender?.bg_mstr_city?.city_name}` : ""}</p> */}
                            <p>{detailsData?.edittender?.bg_mstr_country != null ? detailsData?.edittender?.bg_mstr_country?.country_name : ''}
                                {detailsData?.edittender?.bg_mstr_state != null ? `/${detailsData?.edittender?.bg_mstr_state?.state_name}` : ''}
                                {detailsData?.edittender?.bg_mstr_city != null ? `/${detailsData?.edittender?.bg_mstr_city?.city_name}` : ''}</p>
                        </div>
                        <div className='profile_fields_name'><span>Bid Validity Date </span>:<p>{detailsData?.edittender?.bid_validity_date}</p></div>
                        <div className='profile_fields_name'><span>Client </span>:<p>{BidClient?.filter(item => item?.id === detailsData?.edittender?.client_id)?.map(item => item?.client_name)}</p></div>
                        <div className='profile_fields_name'><span>Contact Person at Client </span>:<p>{detailsData?.edittender?.client_cont_person}</p></div>
                        <div className='profile_fields_name'><span>Client Address </span>:<p>{detailsData?.edittender?.client_cont_address}</p></div>
                        <div className='profile_fields_name'><span>Funding Agency </span>:<p>{BidFundingClientAgency?.filter(item => item?.id === detailsData?.edittender?.funding_id)?.map(item => item?.funding_org_name)}</p></div>
                        <div className='profile_fields_name'><span>Tender Estimated Value </span>:<p>{detailsData?.edittender?.tender_cost !== 0 ? detailsData?.edittender?.tender_cost : 'Not Specified'}</p></div>
                        <div className='profile_fields_name'><span>Publication Date </span>:<p>{detailsData?.edittender?.publication_date !== null ? `${formatDateUtcWithMonthName(detailsData?.edittender?.publication_date)}` : '-'}</p></div>
                        {/* <div className='profile_fields_name'><span>Pre Bid Attended By :</span><p></p></div> */}
                    </div>
                </div>

                <Row gutter={30}>
                    <Col span={17}>
                        <div className='bd_tender_profile_documents'>
                            <div className='bd_profile_doucments_header'>
                                <h2>Documents</h2>
                                <Button className='documents_add_btn' onClick={handleModalAdd}>
                                    <Plus theme="outline" size="20" fill="#fff" strokeWidth={3} strokeLinecap="butt" /> Add Document
                                </Button>
                            </div>

                            {
                                spinner ?
                                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '40vh' }}>
                                        <Spin size="small" />
                                    </div> : <Table
                                        // bordered
                                        columns={columns}
                                        dataSource={DocumentList}
                                        pagination={{
                                            pageSize: pageSize,
                                        }}

                                    />
                            }
                        </div>
                    </Col>
                    <Col span={7}>
                        <div className='info_life_color' style={{ marginTop: 50 }}>
                            <div className='info_box_headings'>
                                <h2>Life Cycle</h2>
                            </div>
                            <div className='info_box_pera'>
                                {/* <div className='info_box_dots'>
                                    <div className='details_points_second'>
                                        <span><hr /></span>
                                    </div>

                                    <p>{`Tender uploaded on ${dayjs(trackHistory?.[0]?.TenderDetails?.created_at).format('DD MMMM YYYY')} Through ${trackHistory?.[0]?.TenderDetails?.source_id}`}</p>
                                </div > */}
                                {
                                    trackHistory !== null &&
                                    trackHistory?.map((item, index) => {
                                        return (
                                            index == 0 ?
                                                <div className='info_box_dots'>
                                                    <div className={trackHistory?.length == 1 ? 'details_points_third' : 'details_points_color_upload'}>
                                                        <span><hr /></span>
                                                    </div>

                                                    <p>{`Tender uploaded on ${dayjs(item?.created_at).format('DD MMMM YYYY')} by ${item?.source_id}`}</p>
                                                </div >
                                                :
                                                <>
                                                    <div className='info_box_dots' key={index}>
                                                        {/* <div className={trackHistory?.length === 1 && index != trackHistory?.length - 1 ? 'details_points_third' : index === 1 && index != trackHistory?.length - 1 ? 'details_points_color' : index == trackHistory?.length - 1 ? 'details_points_third' : 'details_points_second'}>
                                                            <span><hr /></span>
                                                        </div> */}
                                                        {/* <div className={`details_points_color_common ${showStatusColor(item?.to_cycle?.order_sr)}`}>
                                                            <span><hr /></span>
                                                        </div> */}
                                                        <div className={index != trackHistory?.length - 1 ? `details_points_color_common ${showStatusColor(item?.to_cycle?.order_sr)}` : `details_points_color_common_without_arrow ${showStatusColor(item?.to_cycle?.order_sr)}`}>
                                                            <span><hr /></span>
                                                        </div>

                                                        <p>{`Moved To ${item?.to_cycle?.cycle_name} on ${dayjs(item?.created_at).format('DD MMMM YYYY')} ${dayjs(item?.created_at).format('h:mm A')} From ${item?.from_cycle?.cycle_name} By ${item?.created_by_user?.userfullname}`}</p>
                                                    </div >
                                                </>
                                        )
                                    })
                                }

                            </div>
                        </div>
                    </Col>
                </Row>

            </div>

            <div className='info_box_right' style={{ marginTop: 50 }}>

                <Row gutter={30}>
                    <Col span={12}>
                        <div className='tenderdetails_comment'>
                            <div className='commentsDetail_heading'>
                                <h2>Comments</h2>
                                <button className='documents_add_btn' onClick={handleComment}> <img src={commentBtn} width={16} alt='edit Btn' />View all</button>
                            </div>
                            <div className='commentsDetails_forms todo_comments_cont'>
                                {
                                    tenderComments?.length > 0 ?
                                        <>
                                            {
                                                tenderComments?.filter((val) => val.parent_id == 0)?.map((item, index) => {
                                                    const createdBy = userList?.find(val => val?.id === parseInt(item?.created_by))

                                                    return (
                                                        <>
                                                            <div className='todo_comments'>
                                                                <div className='todo_comment_img'>
                                                                    <Avatar
                                                                        style={{ backgroundColor: !createdBy?.profileimg && '#f56a00' }}
                                                                        size="large"
                                                                        src={docurlchat + createdBy?.profileimg_path + "/" + createdBy?.profileimg}
                                                                    >
                                                                        {createdBy?.userfullname?.charAt(0)}
                                                                    </Avatar>
                                                                </div>
                                                                <div className='todo_comment_main_cont'>
                                                                    <div className='todo_comment_name'>
                                                                        <span>{userList?.filter(val => val?.id == item?.created_by)?.map(currentElem => currentElem?.userfullname)}</span>

                                                                        <div className="d-flex" style={{ gap: 15 }}>
                                                                            <p>{item?.created_at !== null ? `${dayjs(item?.created_at).format('MMMM DD, YYYY')} ${TimeConverter(item?.created_at)}` : '-'}</p>
                                                                            <button className="editComment" onClick={() => handleEditParent(item)}>
                                                                                <Write theme="outline" size="16" fill="#9b9b9b" strokeWidth={4} strokeLinecap="butt" />
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                    <div className='todo_comment_para'>
                                                                        <div>
                                                                            {commentSection(item?.comment_txt)}
                                                                        </div>
                                                                        {item?.file_name &&
                                                                            <div onClick={() => documentDownload(item)}>
                                                                                <img src={docIcon} alt="" />
                                                                            </div>
                                                                        }
                                                                    </div>

                                                                    <div className="btn_flex">
                                                                        <button onClick={() => handleReply(item)}>Reply</button>
                                                                    </div>

                                                                    {tenderComments?.filter((val) => val?.parent_id == item?.id)?.map((elem, index) => {
                                                                        const createdBy = userList?.find(val => val?.id === parseInt(elem?.created_by))

                                                                        return (
                                                                            <div className='todo_comments_reply' key={index}>
                                                                                <div className='todo_reply_img'>
                                                                                    <Avatar
                                                                                        style={{ backgroundColor: !createdBy?.profileimg && '#f56a00' }}
                                                                                        size="large"
                                                                                        src={docurlchat + createdBy?.profileimg_path + "/" + createdBy?.profileimg}

                                                                                    >
                                                                                        {createdBy?.userfullname?.charAt(0)}
                                                                                    </Avatar>
                                                                                </div>
                                                                                <div className='todo_reply_main_cont'>
                                                                                    <div className='todo_reply_name'>
                                                                                        <span>{userList?.filter(val => val?.id === parseInt(elem?.created_by))?.map(currentElem => currentElem?.userfullname)}</span>

                                                                                        <div className="d-flex" style={{ gap: 15 }}>
                                                                                            <p>{dayjs(elem?.created_at).format('MMMM DD, YYYY h:mm A')}</p>
                                                                                            {item?.created_by === userBidInfo?.id && <button className="editComment" onClick={() => handleEditChild(elem)}>
                                                                                                <Write theme="outline" size="16" fill="#9b9b9b" strokeWidth={4} strokeLinecap="butt" />
                                                                                            </button>}
                                                                                        </div>
                                                                                    </div>
                                                                                    <div className='todo_reply_para'>
                                                                                        <p>{commentSection(elem?.comment_txt)}</p>
                                                                                        {elem?.file_name !== null &&
                                                                                            <div onClick={() => documentDownload(item)}>
                                                                                                <img src={docIcon} alt="" />
                                                                                            </div>
                                                                                        }
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        )
                                                                    })}
                                                                </div>
                                                            </div>
                                                        </>
                                                    )
                                                })
                                            }
                                        </>
                                        :
                                        <div className="noComment_wrap">
                                            <img src={emptyCommentImg} alt="" />
                                            <p>No Comments Yet...</p>
                                        </div>
                                }
                            </div>
                            <hr />
                            {replyStatus &&
                                <div className="reply_wrap" style={{ paddingLeft: 15 }}>
                                    {editId ? 'Edit comment' :
                                        <span> Reply to : {userList?.filter(val => val?.id === parseInt(replyUser?.created_by))?.map(currentElem => currentElem?.userfullname)}</span>}
                                </div>
                            }
                            <div className="comment_wrapper">
                                <Upload
                                    action="https://run.mocky.io/v3/435e224c-44fb-4773-9faf-380c5e6a2188"
                                    listType="picture-card"
                                    fileList={fileList}
                                    onPreview={handlePreview}
                                    onChange={handleChange}
                                >
                                    {fileList.length >= 1 ? null : uploadButton}
                                </Upload>
                                <Modal
                                    open={previewOpen}
                                    title={previewTitle}
                                    footer={null}
                                    onCancel={handleCancel}
                                >
                                    <img
                                        alt="example"
                                        style={{
                                            width: '100%',
                                        }}
                                        src={previewImage}
                                    />
                                </Modal>
                                <div className='comment_box'>
                                    <Mentions
                                        ref={replyfocus}
                                        onSearch={onSearch}
                                        value={inputValue}
                                        onChange={(value) => handleChangeComment(value)}
                                        options={rearrangedUserList?.filter(item => item?.id !== userBidInfo?.id)?.map(({ userfullname, profileimg, profileimg_path }) => ({
                                            key: userfullname,
                                            value: userfullname,
                                            className: 'antd-demo-dynamic-option',
                                            label: (
                                                <>
                                                    {
                                                        profileimg !== null ?
                                                            <img src={`${docurlchat}${profileimg_path}/${profileimg}`} alt='' />
                                                            :
                                                            <Avatar

                                                                style={{ backgroundColor: '#f56a00' }}
                                                                size="large"
                                                            >
                                                                {userfullname?.charAt(0)}
                                                            </Avatar>
                                                    }
                                                    <span>{userfullname}</span>
                                                </>
                                            ),
                                        }))}
                                        placeholder={replyStatus ? editId ? 'Edit Comment..' : 'Reply Comment..' : 'Type Comment..'}
                                    >
                                    </Mentions>
                                    {replyStatus &&
                                        <button className="close_text" onClick={handleCancelReply}>
                                            <Close theme="outline" size="16" fill="#000" strokeWidth={3} strokeLinecap="butt" />
                                        </button>}
                                    <div className='reply_icons'>
                                        <div onClick={AddComment} style={{ lineHeight: "100%" }}> <SendOutlined /></div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </Col>
                    <Col span={12}>
                        {

                            scopeStatus?.order_sr >= 6 &&

                            <div className='tender_consotrium'>
                                <div className='consotrium_heading'>
                                    <h2>Consortium</h2>
                                    <div className='heading_checkbox'>
                                        <div className='checkbox_heading'>

                                            <div className="d-flex" style={{ gap: 15 }}>

                                                <button className='documents_add_btn' onClick={showModalCompany}  >  <PlusCircleOutlined /> Add</button>

                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div className='consotrium_forms'>
                                    <Form
                                        form={form1}
                                        layout="vertical"
                                        // onFinish={ConsortiumUpdate}
                                        autoComplete='off'
                                        name="control-hooks"
                                    >
                                        < div className='checkbox_heading'>
                                            <Checkbox onChange={handleSoloChange} checked={soloStatus}>Sole Proprietor </Checkbox>
                                            {soloStatus ? companyOptions?.lead_comp_id?.filter(item => item?.link_comp_id == userBidInfo?.comp_id)?.map(val => `(${val?.company_name})`) : ''}
                                        </div>
                                        {
                                            soloStatus ?
                                                <></>
                                                :
                                                <Row gutter={20}>
                                                    <Col sm={24}>

                                                        <Form.Item label="Lead Company" name="lead_comp_ids" rules={[{ required: true, message: "please enter a Lead Company" }]}>

                                                            <Select
                                                                allowClear
                                                                // disabled={apiConsortiumData?.is_solo === '0'}
                                                                placeholder='Enter here...'
                                                                // mode='multiple'
                                                                value={consortiumInitial?.lead_comp_id}
                                                                name='lead_comp_id'
                                                                onChange={(value) => handleConsortiumChange('lead_comp_id', value)}
                                                            // disabled={soloStatus}
                                                            >
                                                                {companyOptions?.lead_comp_id?.map((item) => {
                                                                    return (
                                                                        <Option key={item?.id} value={item?.id} disabled={disabledOption?.disableLead?.includes(item?.id)}>
                                                                            {item?.company_name}
                                                                        </Option>
                                                                    )
                                                                }
                                                                )}
                                                            </Select>
                                                            {errorsCompanyMsg ? <div className="col-md-12" style={{ color: '#ff4d4f' }}>please enter a Lead Company</div> : ''}
                                                        </Form.Item>

                                                    </Col>
                                                    <Col sm={12}>
                                                        <Form.Item label="JV(Joint Venture)"
                                                        >
                                                            <Select
                                                                allowClear
                                                                // disabled={apiConsortiumData?.is_solo === '0'}
                                                                placeholder='Enter here...'
                                                                mode='multiple'
                                                                value={consortiumInitial?.jvs_company?.map((id) =>
                                                                    companyOptions?.jvs_company?.find((company) => company.id === Number(id))?.company_name
                                                                )}
                                                                name='jvs_company'
                                                                onChange={(value) => {
                                                                    const selectedIds = value.map((name) =>
                                                                        companyOptions?.jvs_company?.find((company) => company.company_name === name)?.id
                                                                    );
                                                                    handleConsortiumChange('jvs_company', selectedIds);
                                                                }}
                                                            // disabled={soloStatus}
                                                            >
                                                                {companyOptions?.jvs_company?.map((item) => (
                                                                    <Option key={item?.id} value={item?.company_name} disabled={disabledOption?.disableJvs?.includes(item?.id)}>
                                                                        {item?.company_name}
                                                                    </Option>
                                                                ))}
                                                            </Select>

                                                        </Form.Item>
                                                    </Col>

                                                    <Col sm={12}>
                                                        <Form.Item label="Associate Company Id"
                                                        >
                                                            <Select
                                                                allowClear
                                                                // disabled={apiConsortiumData?.is_solo === '0'}
                                                                placeholder='Enter here...'
                                                                mode='multiple'
                                                                value={consortiumInitial?.associats_id?.map((id) =>
                                                                    companyOptions?.associats_id.find((company) => company.id === Number(id))?.company_name
                                                                )}
                                                                name='associats_id'
                                                                onChange={(value) => {
                                                                    const selectedIds = value.map((name) =>
                                                                        companyOptions?.associats_id.find((company) => company.company_name === name)?.id
                                                                    );
                                                                    handleConsortiumChange('associats_id', selectedIds);
                                                                }}
                                                            // disabled={soloStatus}
                                                            >
                                                                {companyOptions?.associats_id?.map((item) => (
                                                                    <Option key={item?.id} value={item?.company_name} disabled={disabledOption?.disableAssociative?.includes(item?.id)}>
                                                                        {item?.company_name}
                                                                    </Option>
                                                                ))}
                                                            </Select>


                                                        </Form.Item>
                                                    </Col>
                                                </Row>
                                        }

                                        <div>

                                            <div className='save_update_btn'>
                                                <Button className='BG_mainButton' type="primary" htmlType="submit" loading={loadings?.loadingCon} disabled={loadings?.loadingCon} onClick={handleConsortiumSubmit}>Submit</Button>
                                            </div>
                                        </div>


                                    </Form>
                                </div>




                            </div>
                        }

                    </Col>
                </Row>




            </div>

            {/* edit button drawer */}
            < Drawer className='bd_drawer_main'
                closeIcon={< img src={skipBack} alt='' />}
                title="Edit Profile Details"
                placement="right"
                onClose={() => { setDetailsDrawerOpen(false); setErrorMsgDate(false) }}
                open={detailsDrawerOpen} width={1000} >
                <div className='bd_prospective_drawer'>
                    <Form form={form2} name="validateOnly" layout="vertical" autoComplete="off" onFinish={handleSubmitDrawer}
                    >
                        <Row gutter={20}>
                            <Col sm={12}>
                                <Form.Item label="Tender Name" name="tender_name" rules={[{ required: true, message: "Please enter a Tender Name" }]} onKeyPress={handleKeyPress} >
                                    <TextArea
                                        placeholder='Enter here'
                                        name='tender_name'
                                        value={formFieldsValues?.tender_name}
                                        // {htmlToPlainText(detailsData?.edittender?.tender_name)}
                                        onChange={(e) => handleSelectChange('tender_name', e?.target?.value?.trim())}
                                    />
                                    {/* <p className='star'>{selectedOption?.tender_name !== '' ? '' : 'Tender name is required'}</p> */}
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Tender Value" name="tender_cost" rules={[{ required: true, message: "Please enter a Tender Value" }]} onKeyPress={handleKeyPressSelectedItem}>
                                    <Input
                                        placeholder='Enter here'
                                        name='tender_cost'
                                        value={formFieldsValues?.tender_cost}
                                        onChange={(e) => handleSelectChange('tender_cost', e?.target?.value)}

                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Tender Emd Amount Value" name="tender_emd_amnt_val" onKeyPress={handleKeyPressSelectedItem}>
                                    <Input
                                        placeholder='Enter Here'
                                    // name='tender_emd_amnt_val'
                                    // value={formFieldsValues?.tender_emd_amnt_val}
                                    // onChange={(e) => handleSelectChange('tender_emd_amnt_val', e?.target?.value)}

                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Client Address" name="client_cont_address" onKeyPress={handleKeyPress}>
                                    <Input
                                        placeholder='Enter Here'
                                        name='client_cont_address'
                                        value={formFieldsValues?.client_cont_address}
                                        onChange={(e) => handleSelectChange('client_cont_address', e?.target?.value.trim())}

                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Contact Person At Client" name="client_cont_person" onKeyPress={handleKeyPress}>
                                    <Input
                                        placeholder='Enter Here'
                                        name='client_cont_person'
                                        value={formFieldsValues?.client_cont_person}
                                        onChange={(e) => handleSelectChange('client_cont_person', e?.target?.value.trim())}

                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Bid Validity Date" >
                                    <DatePicker
                                        placeholder='dd/mm/yyyy'
                                        name='bid_validity_date'
                                        type="date"
                                        onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                        value={formFieldsValues?.bid_validity_date !== null ? dayjs(formFieldsValues?.bid_validity_date) : null}
                                        onChange={(e) => handleSelectChange('bid_validity_date', e)}
                                    // disabledDate={(current) => current && current < dayjs().startOf('day')}

                                    // name="submission_start_date"
                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Publication Date" >
                                    <DatePicker
                                        placeholder='dd/mm/yyyy'
                                        name='publication_date'
                                        type="date"
                                        onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                        value={formFieldsValues?.publication_date !== null ? dayjs(formFieldsValues?.publication_date) : null}
                                        onChange={(e) => handleSelectChange('publication_date', e)}
                                    // disabledDate={(current) => current && current < dayjs().startOf('day')}

                                    // name="submission_start_date"
                                    />
                                </Form.Item>
                            </Col>

                            <Col sm={12}>
                                <Form.Item label="Key Client Manager "
                                // name="client_manager" rules={[{ required: true, message: "Please enter a Key Client Manager" }]}
                                >
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        options={userList?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.userfullname
                                            }
                                        })}
                                        name='client_manager'
                                        onChange={(value) => handleSelectChange('client_manager', value)}

                                        value={formFieldsValues?.client_manager}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }

                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Bid Manager"
                                // name="bid_manager" rules={[{ required: true, message: "Please enter a Bid Manager" }]}
                                >
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        options={userList?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.userfullname
                                            }
                                        })}
                                        name='bid_manager'
                                        onChange={(value) => handleSelectChange('bid_manager', value)}

                                        value={formFieldsValues?.bid_manager}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }

                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Bid Submission Start Date" >
                                    <DatePicker
                                        placeholder='dd/mm/yyyy'
                                        name='submission_start_date'
                                        type="date"
                                        onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                        value={formFieldsValues?.submission_start_date !== null ? dayjs(formFieldsValues?.submission_start_date) : null}
                                        onChange={(e) => handleSelectChange('submission_start_date', e)}
                                        // disabledDate={(current) => current && current < dayjs().startOf('day')}
                                        disabledDate={(current) =>
                                            formFieldsValues?.submission_end_date &&
                                            current &&
                                            current.isAfter(dayjs(formFieldsValues?.submission_end_date).startOf('day'))
                                        }

                                    // name="submission_start_date"
                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label={<span><span style={{ color: '#ff4d4f' }}>*</span>Bid Submission End Date</span>}>
                                    <DatePicker
                                        placeholder='dd/mm/yyyy'
                                        name='submission_end_date'
                                        type="date"
                                        onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                        value={formFieldsValues?.submission_end_date !== null ? dayjs(formFieldsValues?.submission_end_date) : null}
                                        onChange={(e) => handleSelectChange('submission_end_date', e)}
                                        disabledDate={(current) =>
                                            formFieldsValues?.submission_start_date &&
                                            current &&
                                            current.isBefore(dayjs(formFieldsValues?.submission_start_date).startOf('day'))
                                        }
                                    // name="submission_end_date"
                                    />
                                    {errorMsgDate ? <div className="col-md-12" style={{ color: '#ff4d4f' }}>Please select a End Date</div> : ''}
                                </Form.Item>
                            </Col>

                            <Col sm={12}>
                                <Form.Item label="Pre Bid Meeting Date">
                                    <DatePicker
                                        placeholder='dd/mm/yyyy'
                                        name='pre_bid_meeting_date'
                                        type="date"
                                        onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                        value={formFieldsValues?.pre_bid_meeting_date !== null ? dayjs(formFieldsValues?.pre_bid_meeting_date) : null}
                                        onChange={(e) => handleSelectChange('pre_bid_meeting_date', e)}
                                    // name="submission_end_date"
                                    />
                                    {/* {errorMsgDate ? <div className="col-md-12" style={{ color: '#ff4d4f' }}>Please select a Pre bid Date</div> : ''} */}
                                </Form.Item>
                            </Col>

                            <Col sm={12}>
                                <Form.Item label="Publication Date">
                                    <DatePicker
                                        placeholder='dd/mm/yyyy'
                                        name='publication_date'
                                        type="date"
                                        onKeyDown={(e) => { exceptSymbol?.includes(e?.key) && e.preventDefault() }}
                                        value={formFieldsValues?.publication_date !== null ? dayjs(formFieldsValues?.publication_date) : null}
                                        onChange={(e) => handleSelectChange('publication_date', e)}
                                    // name="submission_end_date"
                                    />
                                    {/* {errorMsgDate ? <div className="col-md-12" style={{ color: '#ff4d4f' }}>Please select a Pre bid Date</div> : ''} */}
                                </Form.Item>
                            </Col>

                            <Col sm={12}>
                                <Form.Item label="Client" name="client_id" rules={[{ required: true, message: "Please enter a Client" }]}>
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        options={BidClient?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.client_name
                                            }
                                        })}
                                        name='client_id'
                                        onChange={(value) => handleSelectChange('client_id', value)}

                                        value={formFieldsValues?.client_id}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }

                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Currency" name="currency_id" rules={[{ required: true, message: "Please enter a Currency" }]}>
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        options={BidCurrency?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.name
                                            }
                                        })}
                                        // name='currency_id'
                                        onChange={(value) => handleSelectChange('currency_id', value)}

                                        value={formFieldsValues?.currency_id}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Region" rules={[{ required: true, message: "Please enter a Region" }]} onKeyPress={handleContainOnlyText} >
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        options={regionList?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.region_name
                                            }
                                        })}
                                        // name='region_id'
                                        onChange={(value) => handleSelectChange('region_id', value)}

                                        value={formFieldsValues?.region_id}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Country" name="country_id" rules={[{ required: true, message: "Please enter a Country" }]} onKeyPress={handleContainOnlyText} >
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        options={BidCountry?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.country_name
                                            }
                                        })}
                                        // name='country_id'
                                        onChange={(value) => handleSelectChange('country_id', value)}

                                        value={formFieldsValues?.country_id}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="State" name="state_id" onKeyPress={handleContainOnlyText} >
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        // name='state_id'
                                        options={statelist?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.state_name
                                            }
                                        })}
                                        onChange={(value) => handleSelectChange('state_id', value)}
                                        value={formFieldsValues?.state_id}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="City" name="city_id" onKeyPress={handleContainOnlyText} >
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        // name='city_id'
                                        options={cityList?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.city_name
                                            }
                                        })}
                                        onChange={(value) => handleSelectChange('city_id', value)}
                                        value={formFieldsValues?.city_id}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Sector" name="sector_id" rules={[{ required: true, message: "Please enter a Sector" }]} onKeyPress={handleContainOnlyText} >
                                    <Select
                                        allowClear
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        options={BidSector?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.sector_name
                                            }
                                        })}
                                        name='sector_id'
                                        onChange={(value) => handleSelectChange('sector_id', value)}

                                        value={formFieldsValues?.sector_id}
                                        // onChange={(value) => handleSelectChange('sector_id', value)}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="Funding Agency" name='funding_id'
                                    //  rules={[{ required: true, message: "Please enter a Funding Agency" }]} 
                                    onKeyPress={handleContainOnlyText} >
                                    <Select
                                        allowClear
                                        showSearch
                                        value={formFieldsValues?.funding_id}
                                        onChange={(value) => handleSelectChange('funding_id', value)}
                                        name='funding_id'
                                        options={BidFundingClientAgency?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.funding_org_name
                                            }
                                        })}
                                        placeholder="Select Funding"
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    />
                                </Form.Item>
                            </Col>
                            {/* <Col sm={12}>
                                <Form.Item label="Tender Cycle" name="cycle_id" rules={[{ required: true, message: "Please enter a Tender Cycle" }]} onKeyPress={handleContainOnlyText} >
                                    <Select
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        options={cycleList?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.scope_name
                                            }
                                        })}
                                        name='cycle_id'
                                        onChange={(value) => handleSelectChange('cycle_id', value)}

                                        value={selectedOption?.cycle_id}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    />
                                </Form.Item>
                            </Col>
                            <Col sm={12}>
                                <Form.Item label="National/International" name="national_intern" rules={[{ required: true, message: "Please enter a National/International" }]} onKeyPress={handleContainOnlyText} >
                                    <Select
                                        showSearch
                                        optionFilterProp="children"
                                        placeholder='Enter Here'
                                        options={nationality?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.nationality_name
                                            }
                                        })}
                                        name='national_intern'
                                        onChange={(value) => handleSelectChange('national_intern', value)}

                                        value={selectedOption?.national_intern}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    />
                                </Form.Item>
                            </Col> */}

                        </Row>
                        <div className="bd_drawerFoot">
                            <Button className='BG_ghostButton'
                                onClick={() => setDetailsDrawerOpen(false)}
                            >
                                Cancel
                            </Button>
                            <Button className='BG_mainButton ' type="primary" htmlType="submit" loading={loadings?.loadingEdit} disabled={loadings?.loadingEdit} onClick={Updatedate}
                            >Submit</Button>
                        </div>
                    </Form>
                </div>
            </Drawer >

            <Modal title="Add Documents" className='bd_model_main'
                open={addDocModalOpen}
                onOk={() => setAddDocModalOpen(false)}
                onCancel={() => { setAddDocModalOpen(false); form.resetFields(); setAddDocument(initialDoc) }}
                footer={false}
            >
                <Form form={form} name="control-hooks" layout="vertical" autoComplete="off" onFinish={AddDocument} >
                    <Form.Item label="Attach file  (Max Size is 20 MB)" name='tender_doc' rules={[{ required: true, message: 'Tender doc is required' }]}>
                        <div className='todo_model_upload'>
                            <Upload
                                listType="picture"
                                maxCount={1}
                                fileList={addDocument?.tender_doc}
                                onChange={handleDoc}
                                beforeUpload={beforeUpload}
                                onRemove={handleRemove}
                            // customRequest={({ file, onSuccess }) => {
                            //     setTimeout(() => {
                            //         onSuccess("ok");
                            //     }, 0);
                            // }}
                            >
                                <Button className='todo_choosen_btn'>Choose file</Button>
                                <span className='file_choosen'>No file chosen</span>
                            </Upload>
                        </div>
                    </ Form.Item>

                    <Form.Item label="Description" name='file_doc_description'>
                        <Input placeholder='Enter Here ....'
                            onChange={(e) => handleSpaceChange('file_doc_description', e)}
                        />
                    </Form.Item>
                    <Flex justify='flex-end' align='center'>
                        <Button key="back" className='BG_ghostButton' onClick={handleReset}>
                            Reset
                        </Button>
                        <Button key="submit" className='BG_mainButton' style={{ marginLeft: '20px' }} type="primary" htmlType="submit" loading={loadings?.loadingDoc} disabled={loadings?.loadingDoc}>
                            Submit
                        </Button>
                    </Flex>
                </Form>
            </Modal>

            <Modal title="Company name" open={companyAdd} onCancel={() => { setCompanyAdd(false); formCompany.resetFields() }} footer={false}>
                <Form form={formCompany}
                    layout="vertical"
                    onFinish={handleCompanyAdd}
                    autoComplete='off'
                    name="control-hooks" className='bd_model_form' >
                    <Row gutter={20}>
                        <Col sm={24}>
                            <Form.Item label='Company Name'
                                name="company_name"
                                // onKeyPress={handleKeyPress}
                                rules={[{ required: true, message: "Please enter a company name" }]}
                            >
                                <Input
                                    placeholder='Enter here...'
                                    onChange={(e) => handleSpaceChange('company_name', e)}
                                // name='company_name'
                                // value={centerlizeCompany?.company_name}
                                // onChange={handleInputChange}
                                />

                            </Form.Item>
                        </Col>
                        <Col sm={24}>
                            <Form.Item label='Company Details' name='company_details' rules={[{ required: true, message: "Please enter a Company details" }]}>
                                <Input
                                    placeholder={`Enter here...`}
                                    onChange={(e) => handleSpaceChange('company_details', e)}
                                // value={centerlizeCompany?.company_details}
                                // onChange={handleInputChange}
                                />

                            </Form.Item>
                        </Col>
                    </Row>
                    <div style={{ display: "flex", alignItems: "end", gap: "10px", justifyContent: "end" }}>
                        <Button key="cancel" className="BG_ghostButton" onClick={() => formCompany.resetFields()}>
                            Reset
                        </Button>
                        <Button className="BG_mainButton" htmlType="submit"
                        //  type="primary" htmlType="submit" loading={loadings} disabled={loadings}
                        > Submit
                        </Button>
                    </div>
                </Form>
            </Modal>

            {
                commentDrawerOpen ? <TodoComments projectId={null} comment={commentDrawerOpen} isTodo={false} setComment={setCommentDrawerOpen} dropdownValState={userList} item={detailsData?.edittender} detailPage={true} userGetCommentLists={userGetCommentList} setTenderCommentData={setTenderComments} onCloseOfComment={() => { }} /> : ""
            }
            <Delete title={'Document'} open={deleteModal} handleDelete={handleDelete} onClose={() => setDeleteModal(false)} modalData={modalData} />

        </div >

    )
}
// BdTenderProfile.whyDidYouRender = true

export default BdTenderProfile;
