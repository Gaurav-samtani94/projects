// @ts-nocheck
import { PlusCircleOutlined } from '@ant-design/icons'
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { Button, Col, Form, Input, Modal, Row, Select, } from 'antd'
import React, { useEffect, useState } from 'react'
import { toast } from 'react-toastify';
import { CompetitorApi } from 'Services/bidgrid/tenderList/CompetitorApi';
const { Option } = Select;

// const initCompanyArr = {
//     technical_weightage: null,
//     financial_weightage: null,
//     weightage_method: null
// }


const BdWeightageModel = ({ setShowWeightageModal, showWeightageModal, id, WeightageAddedData }) => {
    const [dataOption, setDataOption] = useState(null)
    const [technical_weightage, setTechnical_weightage] = useState(null)
    const [financial_weightage, setFinancial_weightage] = useState(null)
    const [compAllList, setCompAllList] = useState([]);

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [form] = Form.useForm();

    // const handleChange = (name, value) => {
    //     setDataOption((prevDataOption) => ({
    //         ...prevDataOption,
    //         [name]: value
    //     }));
    // };

    const compList = async () => {
        // console.log('in compList==>>');
        const formData = new URLSearchParams();
        formData?.append('project_id', id);
        let result = await CompetitorApi.getCompList(formData);
        setCompAllList(result?.data?.data);
    }

    const handleSubmit = async () => {
        const formData = new URLSearchParams()
        formData?.append('project_id', id)
        formData?.append('technical_weightage', dataOption == 1 ? '0' : technical_weightage)
        formData?.append('financial_weightage', dataOption == 1 ? '100' : financial_weightage)
        formData?.append('weightage_method', dataOption)
        try {
            const response = await CompetitorApi.addWeightageToProject(formData)
            if (response?.data?.status === '1') {
                setShowWeightageModal(false)
                notifySuccess('Weightage Added To Project Successfully.')
                setTechnical_weightage(null)
                setFinancial_weightage(null)
                compList();
            }
        } catch (error) {
            setShowWeightageModal(false)
            notify('Try Later')
        }
    }
    const handleReset = () => {
        setDataOption(prevState => ({
            ...prevState,
            technical_weightage: [],
            financial_weightage: [],
            weightage_method: []
        }))
        form.resetFields();
    }




    const handleKeyPress = (e) => {
        const alphabeticChars = /[a-zA-Z]/;
        const forbiddenChars = /[{}.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key) && alphabeticChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            //  handleProjectInfo()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const handleContainOnlyNumbers = (e) => {
        const allowedChars = /[0-9]/;
        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            // handleProjectInfo()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    // console.log(dataOption, 'data')

    // useEffect(() => {
    //     form.setFieldsValue({
    //         technical_weightage: WeightageAddedData?.technical_weightage,
    //         financial_weightage: WeightageAddedData?.financial_weightage,
    //         weightage_method: WeightageAddedData?.method_type
    //     })
    //     setDataOption(WeightageAddedData?.method_type);
    //     setTechnical_weightage(WeightageAddedData?.technical_weightage);
    //     setFinancial_weightage(WeightageAddedData?.financial_weightage);
    // }, [])

    const handleTechnicalWeightageChange = (e) => {
        const value = e.target.value;
        setTechnical_weightage(value);
        setFinancial_weightage(100 - value);
        form.setFieldsValue({ financial_weightage: 100 - value });
    };

    const handleFinancialWeightageChange = (e) => {
        const value = e.target.value;
        setFinancial_weightage(value);
        setTechnical_weightage(100 - value);
        form.setFieldsValue({ technical_weightage: 100 - value });
    };

    useEffect(() => {
        form.setFieldsValue({
            technical_weightage: WeightageAddedData?.technical_weightage,
            financial_weightage: WeightageAddedData?.financial_weightage,
            weightage_method: WeightageAddedData?.method_type,
        });
        setDataOption(WeightageAddedData?.method_type);
        setTechnical_weightage(WeightageAddedData?.technical_weightage);
        setFinancial_weightage(WeightageAddedData?.financial_weightage);
    }, [WeightageAddedData, form]);

    return (
        <>
            <Modal title="Add/Edit Weightage" className='bd_model_main'

                open={showWeightageModal}
                onOk={() => setShowWeightageModal(false)}
                onCancel={() => { setShowWeightageModal(false); }}
                footer={null}
            >
                <Form
                    form={form}
                    layout="vertical"
                    name="control-hooks"
                    onFinish={handleSubmit}
                >
                    <Row gutter={20}>
                        <Col sm={24}>
                            <Form.Item label="Weightage Method:"
                                name='weightage_method'
                                rules={[{ required: true, message: "please select a weightage method" }]}

                            >
                                <Select
                                    allowClear
                                    name='weightage_method'
                                    placeholder='search weightage method'
                                    mode='single'
                                    value={dataOption?.weightage_method}
                                    onChange={(e) => setDataOption(e)}
                                >
                                    <Option value={1}> LCS</Option>
                                    <Option value={2}> QCBS</Option>

                                </Select>


                            </Form.Item>
                        </Col>

                        {
                            dataOption === 2 ?  // QCBS
                                <>
                                    <Col sm={24}>
                                        <Form.Item label="Technical Weightage:" name="technical_weightage" rules={[{ required: true, message: "Please enter technical weightage" }]} onKeyPress={handleContainOnlyNumbers}>
                                            <Input
                                                name='technical_weightage'
                                                // value={dataOption?.technical_weightage} 
                                                placeholder="Enter technical weightage"
                                                // onChange={(e) => handleChange('technical_weightage', e.target.value?.trimStart())}
                                                // onChange={(e) => setTechnical_weightage(e.target.value?.trimStart())}
                                                onChange={handleTechnicalWeightageChange}
                                            />

                                        </Form.Item>
                                    </Col>
                                    <Col sm={24}>
                                        <Form.Item label="Financial Weightage:" name="financial_weightage" rules={[{ required: true, message: "please enter  financial weightage" }]} onKeyPress={handleContainOnlyNumbers}>
                                            <Input
                                                name='financial_weightage'
                                                // value={dataOption?.financial_weightage}
                                                placeholder="Enter financial weightage"
                                                // onChange={(e) => handleChange('financial_weightage', e.target.value?.trimStart())}
                                                // onChange={(e) => setFinancial_weightage(e.target.value?.trimStart())}
                                                onChange={handleFinancialWeightageChange}
                                            />

                                        </Form.Item>
                                    </Col>

                                </>

                                :
                                <></>
                        }

                        {
                            dataOption === 1 ?  //LCS

                                <Col sm={24}>
                                    <Form.Item label="Financial Weightage:" rules={[{ required: true, message: "Please enter technical weightage" }]} onKeyPress={handleContainOnlyNumbers}>
                                        <Input
                                            // name='technical_weightageLCS'
                                            // value={dataOption?.technical_weightage}
                                            placeholder="Enter technical weightage"
                                            // onChange={(e) => handleChange('technical_weightage', e.target.value?.trimStart())}

                                            defaultValue={'100'}
                                            // onChange={(e) => setTechnical_weightage(e.target.value?.trimStart())}
                                            readOnly
                                        />

                                    </Form.Item>
                                </Col>

                                :
                                <></>
                        }




                    </Row>
                    <div style={{ display: "flex", justifyContent: "end", gap: "10px" }}>
                        <Button key="back" className='BG_ghostButton' onClick={handleReset}
                        > Reset
                        </Button>
                        <button key="submit"
                            className='BG_mainButton' >
                            Submit
                        </button>
                    </div>
                </Form>
            </Modal>

        </>

    )
}

export default BdWeightageModel