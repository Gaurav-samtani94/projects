// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Tabs, Select, Tooltip, Steps } from 'antd';
import { Down, SaveOne, Add } from '@icon-park/react';
// import { Form, Select, Input, Checkbox, Tooltip } from 'antd';
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { useLocation, useParams, useNavigate } from 'react-router-dom/dist';
import Link from '@mui/material/Link';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import BookmarkAddIcon from '@mui/icons-material/BookmarkAdd';
import AppRegistrationIcon from '@mui/icons-material/AppRegistration';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';

import { UnorderedListOutlined } from '@ant-design/icons';
import { Dropdown, Space } from 'antd';
// import { DownOutlined, SmileOutlined } from '@ant-design/icons';
import { ListView, Prescription, FileTips, FolderClose, Exchange, Table, OnlineMeeting, UserToUserTransmission, EveryUser, Bank, Download } from '@icon-park/react';
import BdTenderProfile from '../BdTenderDetails/BdTenderProfile';
import BdBidPreparation from './BdPreparation';
import BdProjectInfo from './BdProjectInfo';
import BdCompetitor from './BdCompetitor';
import BdDoctroll from './BdDoctroll';
import Todo from '../Todo/Todo';
import { tenderCycle } from 'Services/bidgrid/tenderCycle/tenderCycle';
import { toast } from 'react-toastify';
import TenderRemainderModal from 'BidGrid/components/TenderCycleActionModal/TenderRemainderModal';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import TenderDeleteModal from 'BidGrid/components/TenderCycleActionModal/TenderDeleteModal';
import TenderWishListModal from 'BidGrid/components/TenderCycleActionModal/TenderWishListModal';
import MeetingSchedules from '../MeetingSchedules';
import BdRequest from './BdRequest';
import { AddTenderList } from 'Services/bidgrid/add/AddTender';
import Skeleton from 'react-loading-skeleton';
import 'react-loading-skeleton/dist/skeleton.css'
import BdTeamRequisition from './BdTeamRequisition';
import BdTenderBank from './BdTenderBank';
import { useSelector } from 'react-redux';
import { navigationData } from 'Redux/actions/bidgrid/navigationData';
import { useDispatch } from 'react-redux';
import html2pdf from 'html2pdf.js';
import ReactDOMServer from 'react-dom/server';
import CheckList from './CheckList';
import TenderDetailAction from 'BidGrid/components/TendercardComponents/TenderDetailAction';
import GernerateNumber from 'BidGrid/components/InAction/GernerateNumber';
import GernerateRole from 'BidGrid/components/InAction/GernerateRole';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import GernerateRole2 from 'BidGrid/components/InAction/GernerateRole2';
import ConsortiumModel from 'BidGrid/components/InAction/ConsortiumModel';
import BdCorrigendumUpdate from './BdCorrigendumUpdate';
import { MisApi } from 'Services/bidgrid/tenderList/MIsApi';

let status = {
  current: {},
  previous: [],
  next: []
}


const initialModalState = {
  createTemplate: { visible: false, data: null },
  generateNum: { visible: false, data: null },
  keyClientAssign: { visible: false, data: null },
  consortiumCompAssign: { visible: false, data: null },
  bidManager: { visible: false, data: null }
}

const BdTenderDetails = ({ itemId }) => {
  const [loading, setLoading] = useState(true);

  const { id } = useParams()
  const defaultValues = 'Select'
  const [detailsData, setDetailsData] = useState([])
  const [trackHistory, setTrackHistory] = useState(null)
  const [remind, setReminOpen] = useState(false);
  const [deleteOpen, setdeleteOpen] = useState(false);
  const [cycleId, setCycleId] = useState({})
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeTabKey, setActiveTabKey] = useState('1');
  const [scopeStatus, setScopeStatus] = useState(status)

  const { navigateData } = useSelector((state) => state.navigationData)
  const [getActionsList, setActionsList] = useState([]);
  const [actionData, setActionData] = useState(null);
  const [modals, setModals] = useState(initialModalState);
  const [getGenTenderId, setGenTenderId] = useState()
  const [conSubmitName, setConSubmitName] = useState("")
  const [inActionPopup, setInActionPopup] = useState(false)
  const [loadingModalBtn, setLoadingModalBtn] = useState(false);
  const [userListData, setUserListData] = useState([])
  const [generateData, setGenerateData] = useState([])
  const [singleDropDownList, setSingleDropDownList] = useState([]);
  const [statusChange, setStatusChange] = useState(defaultValues);
  const [getBdClientManagerData, setBdClientManagerData] = useState([])
  const [misSingleDropDownList, setMisSingleDropDownList] = useState([])





  const dispatch = useDispatch();
  const navigate = useNavigate();
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);

  const location = useLocation();
  const val = location?.pathname;
  const str = val.replace('/', '')

  const getActionsBtnLIst = async () => {
    const formData = new URLSearchParams();
    formData.append('scope_id', detailsData?.edittender?.bg_tenders_status_manage == null ? Number(detailsData?.edittender?.cycle_id) : Number(detailsData?.edittender?.bg_tenders_status_manage?.tender_status));
    let result = detailsData?.edittender?.bg_tenders_status_manage == null ? await TenderApi.getTenderCycleInactionBtnList(formData) : await MisApi?.getMisInActionBtnList(formData);
    setActionsList(result?.data?.data)
  }

  const getGenerateList = async () => {
    try {
      const response = await tenderCycle.bdGenerateNum()
      if (response?.data?.status === '1') {
        setGenerateData(response?.data?.data)
      }
    } catch (error) {
      console.log(error)
    }
  }

  const getUserListData = async () => {
    try {
      const response = await bidEmployeeList?.getUserList()
      if (response?.data?.status) {
        setUserListData(response?.data?.data)
      }
    } catch (error) {
      console.log(error)
    }
  }
  const getSingleDropDownValues = async (value) => {
    const formData = new URLSearchParams();
    formData.append('cycle_id', value);
    let result = await TenderApi.getDropDownValuesSingle(formData);
    if (result?.data?.status == '1') {
      setSingleDropDownList(result?.data?.data);
    }
  }

  const getMisSingleDropDownValues = async (value) => {
    const formData = new URLSearchParams();
    formData.append('cycle_id', value);
    let result = await MisApi.getTenderCycleNextList(formData);
    if (result?.data?.status == '1') {
      console.log(result?.data?.data, "result")
      setMisSingleDropDownList(result?.data?.data);
    }
  }

  const handleMoveTenderToAnotherScope = async (itemID, name) => {
    setGenTenderId(itemID)
    setConSubmitName(name)
    const formData = new URLSearchParams();
    formData.append('tender_id', id);
    try {
      const response = detailsData?.edittender?.bg_tenders_status_manage == null ? await tenderCycle.getBdMoveTender(formData) : await tenderCycle.getBdMoveTender(formData)
      if (response?.data?.status === "1") {
        getTenderBdDetails()
        getBdTenderHistory()
        notifySuccess(response?.data?.message)
      } else if (response?.response?.data?.stage == 5) {
        setModals(prevModals => ({
          ...prevModals,
          generateNum: { visible: true, data: null },
        }));
      } else if (response?.response?.data?.stage == 6) {
        setModals(prevModals => ({
          ...prevModals,
          keyClientAssign: { visible: true, data: null },
        }));

      }
      else if (response?.response?.data?.stage == 7) {
        setModals(prevModals => ({
          ...prevModals,
          bidManager: { visible: true, data: null },
        }));
      }
      else if (response?.response?.data?.stage == 11) {
        setModals(prevModals => ({
          ...prevModals,
          consortiumCompAssign: { visible: true, data: null },
        }));
      }
      else {
        notify("Error");
      }
    } catch (error) {
      console.log(error)
    }

  }

  const handleSubmitTender = async (val, itemID, setStatusChange, item) => {
    setInActionPopup(false)
    let scopeName;
    scopeName = detailsData?.edittender?.bg_tenders_status_manage == null ? singleDropDownList?.find(item => item.id == val)?.cycle_name : misSingleDropDownList?.find(item => item.id == val)?.cycle_nam;

    setCycleId(val)
    setConSubmitName("")
    const formData = new URLSearchParams();
    formData.append("tender_id", itemID);
    formData.append("cycle_id", Number(val));
    try {
      const response = detailsData?.edittender?.bg_tenders_status_manage == null ? await TenderApi.getTransferTender(formData) : await MisApi?.moveTenderToNextScope(formData)
      if (response?.data?.status === '1') {
        getTenderBdDetails()
        getBdTenderHistory()
        notifySuccess(`Tender moved into ${scopeName ? scopeName : 'next'} stage`)
      }
      else if (response?.response?.data?.stage == 5) {

        setModals(prevModals => ({
          ...prevModals,
          generateNum: { visible: true, data: null },
        }));
        setStatusChange(defaultValues)
      } else if (response?.response?.data?.stage == 6) {
        setModals(prevModals => ({
          ...prevModals,
          keyClientAssign: { visible: true, data: null },
        }));
        setStatusChange(defaultValues)
      }
      else if (response?.response?.data?.stage == 7) {
        setModals(prevModals => ({
          ...prevModals,
          bidManager: { visible: true, data: null },
        }));
        setStatusChange(defaultValues)
      }
      else if (response?.response?.data?.stage == 11) {
        setModals(prevModals => ({
          ...prevModals,
          consortiumCompAssign: { visible: true, data: null },
        }));
        setStatusChange(defaultValues)
      }
      else {
        notify("Error");
      }
    } catch (error) {
      console.log(error)
    }
  }

  const getActionListApi = async () => {
    try {
      const response = await tenderCycle.bdActionListTender()
      if (response?.data?.status === '1') {
        // if (!actionData) {
        setActionData(response?.data?.data)
        // }
      }
    } catch (error) {
      console.log(error)
    }
  }

  const getRoleList = async () => {
    try {
      const response = await tenderCycle.getBdRoleList()
      if (response?.data?.status === '1') {
        console.log()
      }
    } catch (error) {
      console.log(error)
    }
  }

  const onChangeStatus = async (e) => {
    setCycleId(e)
    setGenTenderId(id)
    setStatusChange(e);
    handleSubmitTender(e, id, setStatusChange, detailsData?.edittender)
  };

  useEffect(() => {
    modals?.generateNum?.visible && getGenerateList()
    modals?.keyClientAssign?.visible && getRoleList()
  }, [modals?.generateNum?.visible, modals?.keyClientAssign?.visible])


  const getTenderBdDetails = async () => {
    const formData = new URLSearchParams();
    formData.append('tender_id', id)
    try {
      const response = await tenderCycle.bdtenderdetails(formData)
      if (response?.data?.status === '1') {
        setDetailsData(response?.data?.data)
        response?.data?.data?.edittender?.bg_tenders_status_manage == null ? getSingleDropDownValues(response?.data?.data?.edittender?.cycle_id) : getMisSingleDropDownValues(response?.data?.data?.edittender?.bg_tenders_status_manage?.tender_status)
      } else {
        setDetailsData([])
      }
    } catch (error) {
      notify("Api Erorr!!");
      console.log(error, 'api erorr')
    }
  }

  const handleTabChange = (key) => {
    setActiveTabKey(key);
  };

  const fetchActiveStatus = async () => {
    let scopes = []
    try {
      const formData = new URLSearchParams();
      formData.append('tender_id', id);
      const res = await AddTenderList.getTenderdetailsScopeList(formData)
      if (res?.data?.status == 1) {
        scopes = res?.data?.data
      }
    } catch (error) {
      console.log(error, 'api erorr')
    }
    const index = scopes.findIndex(item => item.id === detailsData?.edittender?.cycle_id);
    if (index !== -1) {
      const previousObjects = scopes.slice(0, index);
      const currentObject = scopes[index];
      const nextObjects = scopes.slice(index + 1);
      setScopeStatus((prevState) => ({
        ...prevState,
        current: currentObject,
        previous: previousObjects,
        next: nextObjects
      }))
      setLoading(false)
    } else {
      console.log('Object with ID', detailsData?.edittender?.cycle_id, 'not found.');
      setLoading(true)
    }
  }
  useEffect(() => {
    if (detailsData?.edittender?.cycle_id) {
      fetchActiveStatus()
      getActionsBtnLIst()
    }
    getActionListApi()
  }, [detailsData])


  const tabItems = [
    {
      key: '1',
      label: 'Profile',
      children: <BdTenderProfile detailsData={detailsData} trackHistory={trackHistory} getTenderBdDetails={getTenderBdDetails} scopeStatus={scopeStatus['current']} activeTabKey={activeTabKey} consortiumStatus={modals?.consortiumCompAssign?.visible} />,
      icon: <ListView theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
      key: '2',
      label: 'Bid Preparation',
      children: <BdBidPreparation userListData={userListData}
      />,
      icon: <Prescription theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
      key: '3',
      label: 'Project Details',
      children: <BdProjectInfo id={id} activeTabKey={activeTabKey} />,
      icon: <FileTips theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
      key: '4',
      label: 'Files',
      children: <BdDoctroll TenderDetailid={id} activeTabKey={activeTabKey} />,
      icon: <FolderClose theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },

    (
      scopeStatus['current']?.order_sr >= 6 &&
      {
        key: '5',
        label: 'Competitor',
        children: <BdCompetitor id={id} tab={activeTabKey} consortiumStatus={modals?.consortiumCompAssign?.visible} />,
        icon: <Exchange theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
      }

    ),


    {
      key: '6',
      label: 'Task',
      children: <Todo id={id} />,
      icon: <Table theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
      key: '7',
      label: 'Meetings',
      children: <div className="meetingSchedule_wraper"><MeetingSchedules id={id} /></div>,
      icon: <OnlineMeeting theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
      key: '8',
      label: "Requests",
      children: <BdRequest activeTabKey={activeTabKey} />,
      icon: <UserToUserTransmission theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
      key: '9',
      label: "Team Requisition",
      children: <BdTeamRequisition id={id} activeTabKey={activeTabKey} />,
      icon: <EveryUser theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
      key: '10',
      label: "Bank Guarantee",
      children: <BdTenderBank id={id} />,
      icon: <Bank theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },
    {
      key: '11',
      label: "Corrigendum Update",
      children: <BdCorrigendumUpdate />,
      icon: <Bank theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />,
    },
    // {
    //   key: '11',
    //   label: "CheckList",
    //   children: <CheckList id={id} />,
    //   icon: <UnorderedListOutlined theme="outline" size="20" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
    // }
    // {
    //   key: '11',
    //   label: "Financial Detail",
    //   children: <BdFinancialDetail id={id} />,
    // }
  ];
  const getBdTenderHistory = async () => {

    const formData = new URLSearchParams();
    formData.append('tender_id', id)
    try {
      const response = await TenderApi.tenderTrackHistory(formData)
      if (response?.data?.status == 1) {
        // console.log('response?.data?.data====',response?.data?.data);
        setTrackHistory(response?.data?.data)
      } else {
        setTrackHistory([])
      }
    } catch (error) {
      notify("Api Erorr!!");
      console.log(error, 'api erorr')
    }
  }

  useEffect(() => {
    getTenderBdDetails()
    getBdTenderHistory()

  }, [id])

  const handleRemindCancel = () => {
    setReminOpen(false);
  };


  const handleDelete = () => {
    setdeleteOpen(false);
  };

  function htmlToPlainText(html) {
    var temporaryElement = document.createElement("div");
    temporaryElement.innerHTML = html;
    return temporaryElement.textContent || temporaryElement?.innerText || "";
  }

  const date = new Date();
  let day = date.getDate();
  let month = date.getMonth() + 1;
  if (month < 10) {
    month = '0' + month
  }
  let year = date.getFullYear();

  let currentDate = `${year}/${month}/${day}`;
  const submissionEndDate = new Date(detailsData?.edittender?.submission_end_date);
  const formattedDate = `${submissionEndDate.getUTCFullYear()}/${(submissionEndDate.getUTCMonth() + 1).toString().padStart(2, '0')}/${submissionEndDate.getUTCDate().toString().padStart(2, '0')}`;
  let daysLeft = datediff(parseDate(formattedDate), parseDate(currentDate));

  function datediff(first, second) {
    return Math.round((first - second) / (1000 * 60 * 60 * 24));
  }

  function parseDate(str) {
    var mdy = str?.split('/');
    return new Date(mdy[0], mdy[1] - 1, mdy[2]); // Adjust the order of parameters
  }

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {

    let timeoutId;
    if (navigateData?.hasOwnProperty('item')) {
      if (navigateData?.type === 'tender_comments') {
        setActiveTabKey('1')
      } else if (navigateData?.type === 'tender_todo_comments') {
        timeoutId = setTimeout(() => {
          setActiveTabKey('6')
        }, 500);
      } else if (navigateData?.type === 'tender_request') {
        timeoutId = setTimeout(() => {
          setActiveTabKey('8')
          dispatch(navigationData.setNavigationDataAction({}))
        }, 500);
      } else if (navigateData?.type === 'meeting_schedule') {
        timeoutId = setTimeout(() => {
          setActiveTabKey('7')
          dispatch(navigationData.setNavigationDataAction({}))
        }, 500);
      } else {
        return
      }
    }
    return () => {
      clearTimeout(timeoutId);
    };
  }, [navigateData])

  useEffect(() => {
    getUserListData()

  }, [])
  return (
    <>
      {/* <Breadcrumb data={str} /> */}
      <div className="bd_tender-details">
        <div className='bd_tenderDetailsAction'>

          {/* <Dropdown
            menu={{
              items,
            }}
          >
            <a onClick={(e) => e.preventDefault()}>
              <Download theme="outline" size="18" fill="#fff" strokeWidth={3} strokeLinecap="butt" onClick={downloadPrepare} /> <span onClick={()=>setFactsheetEmailModalOpen(true)}>Prepare FactSheet</span> 
            </a>
          </Dropdown> */}

          {/* <button className="factSheet_btn" onClick={()=>setFactsheetEmailModalOpen(true)} >
            <Download theme="outline" size="18" fill="#fff" strokeWidth={3} strokeLinecap="butt" /> Prepare FactSheet
          </button> */}

          <div className="bd_active_btn_sec" >
            <div className={`status_select ${statusChange}`}>
              <Select
                defaultValue={defaultValues}
                value={detailsData?.edittender?.bg_tenders_status_manage == null ? scopeStatus?.current?.cycle_name : detailsData?.edittender?.bg_tenders_status_manage?.bg_mstr_tndr_status?.status_name}
                disabled={detailsData?.edittender?.bg_tenders_status_manage != null ? detailsData?.edittender?.bg_tenders_status_manage?.bg_mstr_tndr_status?.status_name == "Awaiting" ? false : true : false}
                onChange={onChangeStatus}
                suffixIcon={<Down theme="outline" size="18" fill="#78889b" />}
                options={detailsData?.edittender?.bg_tenders_status_manage == null ? singleDropDownList?.map((item) => ({
                  value: item.id,
                  label: item.cycle_name
                }))
                  :
                  misSingleDropDownList?.map((item) => ({
                    value: item.id,
                    label: item.cycle_name
                  }))
                }
              />
            </div>
          </div>

          <div className="d-flex">
            <TenderDetailAction
              item={detailsData?.edittender}
              getActionsList={getActionsList}
              setGenerateNumOpen={() => setModals(prevModals => ({
                ...prevModals,
                generateNum: { visible: true, data: null },
              }))}
              setGenTenderId={setGenTenderId}
              handleMoveTenderToAnotherScope={handleMoveTenderToAnotherScope}
              actionData={actionData}
              setRoleOpen={() => setModals(prevModals => ({
                ...prevModals,
                bidManager: { visible: true, data: null },
              }))}
              setBidRoleOpen={() => setModals(prevModals => ({
                ...prevModals,
                keyClientAssign: { visible: true, data: null },
              }))}
              getAllTenders={getTenderBdDetails}
              getActionListApi={getActionListApi}
              setInActionPopup={setInActionPopup}
              commonFilter={'DETAIL'}
            />
          </div>

        </div>
        <div className="bt_inner_wrapper">

          <div className='bd_tender_pera_main'>
            <div className='bd_tender_sub_first'>
              {detailsData?.edittender?.tender_name !== '' && detailsData?.edittender?.tender_name !== undefined ? htmlToPlainText(detailsData?.edittender?.tender_name) : ''}
            </div>
            <div className='bd_tender_sub_sec'>
              <span>Bid Submission end</span>
              <span className='bd_tender_end_date'>
                {
                  daysLeft < 0 ?
                    <span style={{ color: 'red' }}>Expired</span>

                    :
                    daysLeft > 0 ?
                      <span>{`${daysLeft} Days Left`}</span>
                      :
                      daysLeft === 0 ?
                        <span style={{ color: 'blue' }}>Today</span>
                        :
                        <></>
                }
                <div className="blinkText">{detailsData?.edittender?.is_corri_update > 0 ? "New Update" : ""}</div>
              </span>

            </div>
          </div>

          <div className='bd_tender_btns_icons'>
            <div className='bd_tender_btns'>
              <div className="pipline_steps">

                {
                  loading ?
                    <Skeleton variant="rectangular" width={1400} height={50} />
                    :
                    <>
                      {/* {console.log("steps array", [...scopeStatus?.previous, scopeStatus?.current, ...scopeStatus?.next])} */}

                      {scopeStatus?.previous?.map((val, index) => {
                        return (
                          <div className={index === 0 ? 'ps_item past' : 'ps_itemeded past'}>{val?.cycle_name}</div>
                        )
                      })}

                      <div className={scopeStatus?.current?.cycle_name === 'Submitted' ? 'ps_item_last future ps_itemeded present' : scopeStatus?.current?.cycle_name === "Fresh/live" ? 'ps_item current' : 'ps_itemeded present'}> {scopeStatus?.current?.cycle_name}</div>

                      {scopeStatus?.next?.map((val, index) => {

                        return (
                          <div className={index === scopeStatus?.next?.length - 1 ? 'ps_item_last future' : 'ps_itemeded future'}>{val?.cycle_name}</div>
                        )
                      })}
                    </>
                }


                {/* <div className="ps_item past">New Tender</div>
                <div className="ps_itemeded past">Important Tender</div>
                <div className="ps_itemeded present">In Review</div>
                <div className="ps_itemeded future">To Be Submitted</div>
                <div className="ps_item_last future">Submitted Tender</div> */}
              </div>
              <Steps
                current={scopeStatus?.previous.length}
                // progressDot
                // items={[
                //   {
                //     title: 'Finished',
                //   },
                //   {
                //     title: 'In Progress',
                //   },
                //   {
                //     title: 'Waiting',
                //   },
                //   {
                //     title: 'Waiting',
                //   },
                // ]}
                items={[...scopeStatus?.previous, scopeStatus?.current, ...scopeStatus?.next].map((item) => {
                  return {
                    title: item?.cycle_name
                  }
                })}
              />
            </div>
          </div>
        </div>
        {/* ./bt_inner_wrapper */}

        <div className='bd_tender_tabs_main'>
          <Tabs
            defaultActiveKey="1"
            items={tabItems}
            // defaultActiveKey="1"
            // items={items}
            activeKey={activeTabKey}
            onChange={handleTabChange}
            indicator={{ size: (origin) => origin - 16 }}

          />
        </div>
      </div>

      <TenderRemainderModal
        remind={remind}
        itemId={id}
        handleRemindCancel={handleRemindCancel}
      />


      <TenderDeleteModal
        deleteOpen={deleteOpen}
        handleDelete={handleDelete}
        setdeleteOpen={setdeleteOpen}
        itemId={id}
        cycleId={cycleId}
      />

      <TenderWishListModal
        isModalOpen={isModalOpen}
        itemId={id}
        setIsModalOpen={setIsModalOpen}
      />

      <GernerateNumber
        open={modals?.generateNum?.visible}
        close={() => setModals(prevModals => ({
          ...prevModals,
          generateNum: { visible: false, data: null },
        }))}
        generateData={generateData}
        getGenTenderId={getGenTenderId}
        tenderCycle={tenderCycle}
        setModals={setModals}
        inActionPopup={inActionPopup}
        getAllTenders={getTenderBdDetails}
        setInActionPopup={setInActionPopup}
        loadingModalBtn={loadingModalBtn}
        setLoadingModalBtn={setLoadingModalBtn}
      />
      <GernerateRole  // BID MANAGER
        open={modals?.bidManager?.visible}
        close={() => setModals(prevModals => ({
          ...prevModals,
          bidManager: { visible: false, data: null },
        }))}
        getGenTenderId={getGenTenderId}
        userListData={userListData}
        tenderCycle={tenderCycle}
        setBdClientManagerData={setBdClientManagerData}
        setModals={setModals}
        inActionPopup={inActionPopup}
        setInActionPopup={setInActionPopup}
        getAllTenders={getTenderBdDetails}
        loadingModalBtn={loadingModalBtn}
        setLoadingModalBtn={setLoadingModalBtn}

      />
      <GernerateRole2 // KEY CLIENT MANAGER
        open={modals?.keyClientAssign?.visible}
        close={() => setModals(prevModals => ({
          ...prevModals,
          keyClientAssign: { visible: false, data: null },
        }))}
        getGenTenderId={getGenTenderId}
        userListData={userListData}

        tenderCycle={tenderCycle}
        setModals={setModals}
        inActionPopup={inActionPopup}
        setInActionPopup={setInActionPopup}
        getAllTenders={getTenderBdDetails}
        loadingModalBtn={loadingModalBtn}
        setLoadingModalBtn={setLoadingModalBtn}
      />
      {/* lead company modal */}
      <ConsortiumModel
        // open={modals?.consortiumCompAssign?.visible}
        open={modals?.consortiumCompAssign?.visible}

        close={() => setModals(prevModals => ({
          ...prevModals,
          consortiumCompAssign: { visible: false, data: null },
        }))}
        getGenTenderId={getGenTenderId}
        getAllTenders={getTenderBdDetails}
        consortiumModelOpen={modals?.consortiumCompAssign?.visible}
        handleMoveTenderToAnotherScope={handleMoveTenderToAnotherScope}
        setModals={setModals}
        loadingModalBtn={loadingModalBtn}
        setLoadingModalBtn={setLoadingModalBtn}
        conSubmitName={conSubmitName}
        handleSubmitTender={handleSubmitTender}
        cycleId={cycleId}
        id={id}
      />
    </>
  )
}
BdTenderDetails.whyDidYouRender = true

export default BdTenderDetails;