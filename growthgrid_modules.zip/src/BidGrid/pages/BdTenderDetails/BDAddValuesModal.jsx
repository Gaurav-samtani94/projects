// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Table, Input, Select, Dropdown, Spin, Modal, Row, Col, Form, Button } from 'antd';
import { CompetitorApi } from 'Services/bidgrid/tenderList/CompetitorApi';
import { toast } from 'react-toastify';

const BDAddValuesModal = (props) => {

    const { handleOk, handleCancel, setIsModalOpen, isModalOpen, projectId, leadCompId, compScoreId, valuesData, } = props;

    const [techinicalValue, setTechnicalValue] = useState(null);
    const [financialValue, setFinancialValue] = useState(null);
    const [techinicalValueForCheckAddOrEdit, setTechnicalValueForCheckAddOrEdit] = useState();
    const [checkMethodType, setCheckMethodType] = useState(null);

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [form] = Form.useForm();
    const [editData, setEditData] = useState({
        financial_score: '',
        technical_score: '',
    })
    // console.log(editData, "editData")

    // console.log('valuesData=16=>>',valuesData?.comptitor_assign_company_list.comp_list_data[0]?.technical_score);
    // console.log('valuesData==17', valuesData)
    // form.setFieldValue(valuesData);

    const fetchEditDetails = async () => {
        let formData = new URLSearchParams();
        formData.append('comp_score_id', compScoreId);
        let result = await CompetitorApi.compScoreEdit(formData);
        if (result?.data?.status === '1') {
            // setEditData(result?.data?.data)
            // console.log(result?.data?.data?.financial_score,"result?.data?.data");

            setTechnicalValueForCheckAddOrEdit(result?.data?.data?.technical_score)
            form.setFieldsValue({
                technical_score: result?.data?.data?.technical_score,
                financial_score: result?.data?.data?.financial_score,
            })
            setCheckMethodType(result?.data?.data?.method_type);

        }
        else {
            console.log("error")
        }

    }

    const handleSubmit = async (value) => {
        console.log(value)
        let formData = new URLSearchParams();
        formData.append('comp_score_id', compScoreId);
        formData.append('lead_comp_id', leadCompId);
        formData.append('project_id', projectId);
        formData.append('technical_score', checkMethodType==1 ? 0 : value?.technical_score);
        formData.append('financial_score', value?.financial_score);
        let result = await CompetitorApi.compScoreUpdate(formData);
        if (result?.data?.status === '1') {
            handleCancel();
            notifySuccess('Values added successfully');
            setTechnicalValue(null)
            setFinancialValue(null)
        }
        else {
            handleCancel();
            notifySuccess('Something went wrong, Please try again');
        }
    }

    // const fetchData=()=>{
    //     console.log('valuesData====39',valuesData?.comptitor_assign_company_list.comp_list_data[0]?.financial_score);
    //     setFinancialValue(valuesData?.comptitor_assign_company_list.comp_list_data[0]?.financial_score)
    //     setTechnicalValue(valuesData?.comptitor_assign_company_list.comp_list_data[0]?.technical_score)
    // }

    useEffect(() => {
        if (isModalOpen) {
            fetchEditDetails()
        }
    }, [isModalOpen])

    const handleContainOnlyNumbers = (e) => {
        const allowedChars = /[0-9]/;
        if (
            !allowedChars.test(e.key) &&
            e.key !== 'Backspace' && // Check for backspace key
            e.key !== 'Enter' &&
            !(e.key === ' ' && e.target.selectionStart === 0)
        ) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            // handleProjectInfo()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    return (
        <>
            <Modal title={(techinicalValueForCheckAddOrEdit) ? "Edit Values" : "Add Values"} open={isModalOpen} onOk={handleOk} onCancel={() => { handleCancel(); form.resetFields() }} footer={null}>
                <Form
                    form={form}
                    name="control-hooks" layout="vertical" autoComplete="off"
                    // initialValues={editData}
                    onFinish={handleSubmit}

                // form={form}
                // name="control-hooks"
                // layout="vertical"
                // autoComplete="off"
                // onFinish={handleSubmit}
                >
                    <Row gutter={20}>
                        {
                            checkMethodType == 1 ? <Col sm={24}>
                                <Form.Item label="Financial :"
                                    name='financial_score'
                                    rules={[{ required: true, message: "Please enter financial value" }]}
                                    onKeyPress={handleContainOnlyNumbers}
                                >
                                    <Input
                                        // type='text'
                                        placeholder='Enter here'
                                    // onChange={(e) => setFinancialValue(e?.target?.value?.trimStart())}
                                    />
                                </Form.Item>
                            </Col> :
                                <>
                                    <Col sm={24}>
                                        <Form.Item
                                            label="Technical:"
                                            name='technical_score'
                                            rules={[{ required: true, message: "Please enter technical value" }]}
                                            onKeyPress={handleContainOnlyNumbers}
                                        >
                                            <Input
                                                placeholder="Enter here"
                                            // onChange={(e) => setTechnicalValue(e?.target?.value?.trimStart())}
                                            />
                                        </Form.Item>
                                    </Col>


                                    <Col sm={24}>
                                        <Form.Item label="Financial :"
                                            name='financial_score'
                                            rules={[{ required: true, message: "Please enter financial value" }]}
                                            onKeyPress={handleContainOnlyNumbers}
                                        >
                                            <Input
                                                // type='text'
                                                placeholder='Enter here'
                                            // onChange={(e) => setFinancialValue(e?.target?.value?.trimStart())}
                                            />
                                        </Form.Item>
                                    </Col>
                                </>
                        }


                    </Row>
                    <div style={{ display: "flex", justifyContent: "end", gap: "10px" }}>
                        <Button key="back" className='BG_ghostButton' onClick={() => form.resetFields()}
                        > Reset
                        </Button>
                        <button key="submit" className='BG_mainButton'>
                            Submit
                        </button>
                    </div>
                </Form>
            </Modal>
        </>
    )
}



export default BDAddValuesModal;