// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { Table, Input, Select, Dropdown, Spin } from 'antd';
import { Down, More, Up } from '@icon-park/react';
import { PlusOutlined } from '@ant-design/icons';
import BdVentureModal from './BdVentureModal';
import BdConsortiumModal from './BdConsortiumModal';
import BdRankModal from './BdRankModal';
import Delete from 'BidGrid/components/modalDelete/Delete';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { toast } from 'react-toastify';
import BdWeightageModel from './BdWeightageModel';
import { CompetitorApi } from 'Services/bidgrid/tenderList/CompetitorApi';
import BDAddValuesModal from './BDAddValuesModal';

const { Search } = Input;
const { Option } = Select;



const BdCompetitor = ({ id, tab, consortiumStatus }) => {
    const [pageSize, setPageSize] = useState(5)
    const [searchText, setSearchText] = useState('');

    const [showVentureModal, setShowVentureModal] = useState(false)
    const [showWeightageModal, setShowWeightageModal] = useState(false)
    const [consortiumModal, setConsortiumModal] = useState(false)
    const [genRankModal, setGenRankModal] = useState(false)
    const [deleteModal, setDeleteModal] = useState(false)
    const [dataSource, setDataSource] = useState([])
    const [orderDirection, setOrderDirection] = useState();
    const [modalData, setModalData] = useState({});
    const [spinner, setSpinner] = useState(false)
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [isActive, setIsActive] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [leadId, setLeadId] = useState()
    const [scoreId, setScoreId] = useState()
    const [refresh, setRefresh] = useState(false);
    const [valuesData, setValuesData] = useState();
    const [flattenedProjects, setFlattenedProjects] = useState([]);
    const [isWeightageAdded, setIsWeightageAdded] = useState(false);
    const [WeightageAddedData, setWeightageAddedData] = useState({});
    const [updateForWeightage, setUpdateForWeightage] = useState(false);

    const totalResults = 90
    const changeOrder = (direction) => () => {
        setOrderDirection(direction);
    };
    const handlePageSizeChange = (value) => {
        setPageSize(value);
    }


    const deleteCompetitor = (items) => {
        // const group_id = Number(items?.comptitor_assign_company_list?.Lead_company?.map(item => item?.group_no).join(''))
        setModalData({ ...modalData, id: items?.comptitor_assign_company_list?.Lead_company[0]?.group_no })
        setDeleteModal(true)


    }

    const editCompetitor = (val) => {
        setModalData(val)
        setShowVentureModal(true)
    }
    const getItems = (reference) => {
        return [
            {
                key: '1',
                label: (<div onClick={() => { editCompetitor(reference) }}>Edit</div>),
            },
            {
                key: '2',
                label: (<div onClick={() => showModal(reference)}>Add Values</div>),
            },
            {
                key: '3',
                label: (<div onClick={() => { deleteCompetitor(reference) }}>Delete</div>),
            },
        ];
    }



    // const getDropdownItems = (reference) => {
    //     return [
    //         {
    //             key: '1',
    //             label: (<div className='add_joint_ven' onClick={() => setConsortiumModal(true)}><PlusOutlined /> Add Join Joint Venture</div>),
    //         },
    //         {
    //             key: '2',
    //             label: (<div className='add_joint_ven' onClick={() => setGenRankModal(true)}><FormOutlined />Generate Rank</div>),
    //         },
    //         {
    //             key: '3',
    //             label: (<div className='del_ven_competitor' onClick={() => setDeleteModal(true)}><DeleteFilled />Delete</div>),
    //         },
    //     ];
    // }


    const showEditDrawer = (items) => {
        console.log(items, "items")
    };

    const getCompanyCompetitor = async (initial) => {
        if (initial) {
            setSpinner(true)
        }
        const formData = new URLSearchParams();
        formData.append('project_id', id);

        try {
            const response = await TenderApi.competitorCompany(formData)
            if (response?.data?.status === '1') {

                let compListResponse = await CompetitorApi.getCompList(formData);

                const updatedDataSource = response?.data?.data?.map(item => {
                    const filteredTableData = compListResponse?.data?.data?.filter(compItem =>
                        item?.comptitor_assign_company_list?.Lead_company?.some(leadItem => leadItem?.lead_id === compItem?.id)
                    );

                    return {
                        ...item,
                        comptitor_assign_company_list: {
                            ...item.comptitor_assign_company_list,
                            ['comp_list_data']: filteredTableData
                        }
                    };
                });

                setDataSource(updatedDataSource)
                setSpinner(false)
            } else {
                setDataSource([])
                setSpinner(false)
            }

        } catch (error) {
            setSpinner(false)
            console.log(error, "else")

        }
    }

    // delete competitor 
    const handleDelete = async (groupid) => {
        const formData = new URLSearchParams();
        formData.append('project_id', id);
        formData.append('group_no', groupid);
        try {
            const response = await TenderApi.deleteCompetitorCompany(formData);
            if (response?.data?.status == 1) {
                notifySuccess('Competitor delete successfully');
                setSpinner(true)
                await getCompanyCompetitor(false)
            } else {
                notify(response?.response?.data?.message);
                setSpinner(true)
            }
        } catch (error) {
            console.log(error, "Api");
            setSpinner(false)
        }
    }
    // useEffect(()=>{
    //     handleClickRefresh()
    // },[showVentureModal==false])

    const handleClickRefresh = async () => {
        setIsActive(true); // Toggle the isActive state

        const formData = new URLSearchParams();
        formData.append('project_id', id);
        let result = await CompetitorApi.compWeightageEdit(formData);
        if (result?.data?.status == 1) {
            console.log('result?.data?====177====???.', result?.data?.data);
            const formDataForWeightageAdd = new URLSearchParams();
            formDataForWeightageAdd?.append('project_id', id)
            formDataForWeightageAdd?.append('technical_weightage', result?.data?.data?.technical_weightage)
            formDataForWeightageAdd?.append('financial_weightage', result?.data?.data?.financial_weightage)
            formDataForWeightageAdd?.append('weightage_method', result?.data?.data?.method_type)

            const response = await CompetitorApi.addWeightageToProject(formDataForWeightageAdd)
            if (response?.data?.status == 1) {
                let formDataForAll = new URLSearchParams();
                formDataForAll.append('project_id', id);
                await CompetitorApi.compFinMarksUpdate(formDataForAll);
                await CompetitorApi.compTechMarksUpdate(formDataForAll);
                await CompetitorApi.compTotalMarksUpdate(formDataForAll);
                await CompetitorApi.compRankUpdate(formDataForAll);
                await CompetitorApi.compTotalMarksUpdate(formDataForAll);
                // weightageEdit();
                setRefresh(!refresh)
                // setIsActive(!isActive);
                setTimeout(() => {
                    setIsActive(false);
                }, 500);
            }
        }
        else {
            let formDataForAll = new URLSearchParams();
            formDataForAll.append('project_id', id);
            await CompetitorApi.compFinMarksUpdate(formDataForAll);
            await CompetitorApi.compTechMarksUpdate(formDataForAll);
            await CompetitorApi.compTotalMarksUpdate(formDataForAll);
            await CompetitorApi.compRankUpdate(formDataForAll);
            await CompetitorApi.compTotalMarksUpdate(formDataForAll);
            // weightageEdit();
            setRefresh(!refresh)
            // setIsActive(!isActive);
            setTimeout(() => {
                setIsActive(false);
            }, 500);
        }

    };


    const showModal = (reference) => {

        setLeadId(reference?.comptitor_assign_company_list?.comp_list_data[0]?.lead_comp_ids)
        setScoreId(reference?.comptitor_assign_company_list?.comp_list_data[0]?.id)
        setValuesData(reference);
        // setTechnicalValue(reference?.comptitor_assign_company_list?.comp_list_data[0]?.technical_score);
        // setFinancialValue(reference?.comptitor_assign_company_list?.comp_list_data[0]?.financial_score);
        setIsModalOpen(true);

    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
    };

    const weightageEdit = async () => {
        const formData = new URLSearchParams();
        formData.append('project_id', id);
        try {
            let result = await CompetitorApi.compWeightageEdit(formData);
            if (result?.data?.status == 1) {
                setIsWeightageAdded(true);
                setWeightageAddedData(result?.data?.data)
            }

        } catch (error) {
            console.log('error===>', error)
        }
    }


    useEffect(() => {
        if (tab == 5 || !consortiumStatus) {
            getCompanyCompetitor(true);

        }
    }, [refresh, tab, consortiumStatus])


    useEffect(() => {
        weightageEdit();
    }, [])

    useEffect(() => {
        weightageEdit();
    }, [showWeightageModal])
    // console.log(dataSource,"datasource==366===>>")



    const columns = [
        {
            title: (
                <div>
                    S. No.
                </div>
            ),
            dataIndex: 'srNo',
            sorter: (a, b) => a.srNo - b.srNo,
            width: 100,
            render: (text, record, index) => index + 1, // Render the index (plus 1) as Sr No
        },

        {
            title: (
                <div>
                    Company Name
                </div>
            ),
            dataIndex: 'comptitor_assign_company_list',
            sorter: (a, b) => a.comptitor_assign_company_list - b.comptitor_assign_company_list,
            render: ((item) => {
                return (
                    <>

                        {
                            item?.Lead_company?.length > 0 &&
                            <>
                                {
                                    item?.Lead_company?.map(item => <p>{item?.companyName}</p>)

                                }
                            </>

                        }
                        <br />

                        {
                            item?.associative_company?.length > 0 &&
                            <>
                                {
                                    item?.associative_company?.map(item => <p>{item?.companyName}</p>)
                                }
                            </>

                        }
                        <br />
                        {
                            item?.jvs_company?.length > 0 &&
                            <>
                                {
                                    item?.jvs_company?.map(item => <p>{item?.companyName}</p>)
                                }
                            </>

                        }

                    </>
                )
            })
        },
        {
            title: (
                <div>
                    Type
                </div>
            ),
            dataIndex: 'comptitor_assign_company_list',
            render: ((item) => {
                console.log(item)
                return (<>
                    {item?.Lead_company[0]?.type_data === '2' ?
                        <span>Competitor</span>
                        :
                        <span>Consortium</span>

                    }
                </>)
            })
        },
        {
            title: (
                <div>
                    Technical Score
                </div>
            ),
            dataIndex: 'comptitor_assign_company_list',
            render: ((item) => {

                return (
                    <>

                        {
                            // console?.log(item,"ggggggggg")
                            item?.comp_list_data?.length > 0 &&
                            <>
                                {
                                    item?.comp_list_data?.map(item => item?.technical_marks ? item?.technical_marks : 0)

                                }
                            </>

                        }

                    </>
                )
            })
        },
        {
            title: (
                <div>
                    Financial Score
                </div>
            ),
            dataIndex: 'comptitor_assign_company_list',
            render: ((item) => {
                return (
                    <>

                        {
                            // console?.log(item,"ggggggggg")
                            item?.comp_list_data?.length > 0 &&
                            <>
                                {
                                    item?.comp_list_data?.map(item => item?.financial_marks ? item?.financial_marks : 0)

                                }
                            </>

                        }

                    </>
                )
            })
        },
        {
            title: (
                <div>
                    Total
                </div>
            ),
            dataIndex: 'comptitor_assign_company_list',
            render: ((item) => {
                return (
                    <>

                        {
                            item?.comp_list_data?.length > 0 &&
                            <>
                                {
                                    item?.comp_list_data?.map(item => item?.total ? item?.total : 0 + '.0')

                                }
                            </>

                        }

                    </>
                )
            })
        },
        {
            title: (
                <div>
                    Rank
                </div>
            ),
            dataIndex: 'comptitor_assign_company_list',
            render: ((item) => {
                return (
                    <>

                        {
                            item?.comp_list_data?.length > 0 &&
                            <>
                                {
                                    item?.comp_list_data?.map(item => item?.rank)

                                }
                            </>

                        }

                    </>
                )
            })
        },
        {
            srNo: 2,
            title: "Actions",
            dataIndex: '',
            width: 120,
            render: ((item) => {
                return (
                    <>
                        <Dropdown
                            menu={{ items: getItems(item) }}
                            placement="bottomRight"
                        >
                            <a onClick={(e) => e.preventDefault()}
                            >
                                <More theme="outline" size="25" fill="#95a6b6" strokeWidth={3} />
                            </a>
                        </Dropdown>
                    </>
                )
            }


            ),
        }
        // {
        //     title: 'Company',
        //     dataIndex: 'comptitor_assign_company_list',
        //     key: 'company',
        // },
        // {
        //     title: 'Financial Quote',
        //     dataIndex: 'financial_quote',
        //     key: 'financial_quote',
        // },
        // {
        //     title: 'Financial Marks',
        //     dataIndex: 'financial_marks',
        //     key: 'financial_marks',
        // },
        // {
        //     title: 'Total Marks',
        //     dataIndex: 'total_marks',
        //     key: 'total_marks',
        // },
        // {
        //     title: 'Rank',
        //     dataIndex: 'rank',
        //     key: 'rank',
        // },

    ];

    // const filteredData = props?.dataSource?.filter((item) => {

    //     return Object.values(item).some((value) =>

    //         String(value).toLowerCase().includes(searchText.toLowerCase())
    //     );
    // })
    //     ?.map((item, index) => ({
    //         ...item,
    //         srNo: <>{str === 'bidgrid/livetender' ? tenderPageSize * (currentPage - 1) + index + 1 : pageSize * (currentPage - 1) + index + 1}</>,
    //     }));


    const handleFilterChange = (e) => {
        setSearchText(e.target.value)
        // if (e.key === 'Enter') {
        //     e.preventDefault();
        //     // getAddtender(false)
        //     // handleSearchFun()
        // }
    }


    const handleWeightageModel = () => {
        setShowWeightageModal(true)
    }


    const filteredData = dataSource?.filter((item) => {

        return Object.values(item).some((value) =>

            String(value).toLowerCase().includes(searchText.toLowerCase())
        );
    })
        ?.map((item, index) => ({
            ...item,
        }));

    // useEffect(() => {

    //     if (activeTabKey === '1') {
    //         fetchConsortiumStatus()
    //     }

    // }, [activeTabKey])
    return (
        <div className="bd_competitor">
            <div className="table_wrap">
                <div className="tableHead_wrap">
                    <div className='competitor_serach_flex'>
                        <Search
                            placeholder="Search"
                            allowClear={false}
                            onChange={(e) => handleFilterChange(e)}
                            onKeyDown={(e) => handleFilterChange(e)}
                            style={{ width: 340 }}
                            value={searchText}
                        />
                        {/* <ExportDatatable
                            dataSource={dataSource}
                            columnLabels={columns}
                        /> */}
                    </div>
                    <div className='bd_model_button add_btns'>
                        <div className="showPrPage">
                            <span>Showing</span>
                            <Select
                                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                defaultValue={pageSize}
                                style={{ width: 70 }}
                                onChange={handlePageSizeChange}
                            >
                                <Option value={5}>5</Option>
                                <Option value={10}>10</Option>
                                <Option value={20}>20</Option>
                                <Option value={30}>30</Option>
                                <Option value={40}>40</Option>
                            </Select>
                        </div>
                        <button key="submit" className='BG_mainButton' onClick={() => { setShowVentureModal(true); setModalData({}) }}>
                            <PlusOutlined />  Add Competitor
                        </button>
                        <button key="submit" className='BG_mainButton' onClick={handleWeightageModel}>
                            <PlusOutlined />  {isWeightageAdded ? 'Edit Weightage' : 'Add Weightage'}
                        </button>
                       {dataSource?.length > 0 ?
                        <button key='submit' className={`reset_button ${isActive ? 'Refreshactive' : ''}`}
                            onClick={handleClickRefresh}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 24 24">
                                <path fill="currentColor" d="M20.5 5.835A10.485 10.485 0 0 0 12 1.5c-5.427 0-9.89 4.115-10.443 9.396l-.104.994l1.99.209l.103-.995A8.501 8.501 0 0 1 19.212 7.5H15.5v2h7v-7h-2v3.335Zm.057 6.066l-.104.995A8.501 8.501 0 0 1 4.787 16.5H8.5v-2h-7v7h2v-3.335A10.485 10.485 0 0 0 12 22.5c5.426 0 9.89-4.115 10.442-9.396l.104-.994l-1.989-.209Z" />
                            </svg>
                            Refresh
                        </button>
                        :''
                        }
                    </div>
                </div>
                {/* <DataTable /> */}
                <div className="tableBody_wrap">
                    {
                        spinner ?
                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '40vh' }}>
                                <Spin size="small" />
                            </div> :
                            <Table
                                // bordered
                                columns={columns}
                                dataSource={filteredData}
                                pagination={{
                                    pageSize: pageSize,
                                }}
                            />
                    }

                </div>



            </div>
            {
                showVentureModal == true ? <BdVentureModal dataSource={dataSource} showVentureModal={showVentureModal} setShowVentureModal={setShowVentureModal} id={id} handleComapny={getCompanyCompetitor} modalData={modalData} spinner={spinner} setSpinner={setSpinner} /> : ''
            }
            {
                showWeightageModal == true ? <BdWeightageModel showWeightageModal={showWeightageModal} setShowWeightageModal={setShowWeightageModal} id={id} WeightageAddedData={WeightageAddedData} /> : ''
            }
            {
                consortiumModal == true ? <BdConsortiumModal consortiumModal={consortiumModal} setConsortiumModal={setConsortiumModal} /> : ''
            }
            {
                genRankModal == true ? <BdRankModal genRankModal={genRankModal} setGenRankModal={setGenRankModal} /> : ''
            }

            <Delete title={'Competitor'} open={deleteModal} handleDelete={handleDelete} onClose={() => setDeleteModal(false)} modalData={modalData} />

            {/* <Modal title="Add Values" open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null}>
                <Form
                    layout="vertical"
                    name="control-hooks"
                >
                    <Row gutter={20}>
                        <Col sm={24}>
                            <Form.Item label="Technical:"
                                name='weightage_method'
                                rules={[{ required: true, message: "please enter technical value" }]}

                            >
                                            <Input
                                                name='technical_weightage'
                                                // value={dataOption?.technical_weightage} 
                                                placeholder="Enter here"
                                            // onChange={(e) => handleChange('technical_weightage', e.target.value?.trimStart())}
                                            // onChange={(e) => setTechnical_weightage(e.target.value?.trimStart())}
                                            />

                                        </Form.Item>

                        </Col>
                        <Col sm={24}>
                            <Form.Item label="Financial :"
                                name='name_items'
                                rules={[{ required: true, message: "please enter financial value" }]}>
                                <Input
                                    type='text'
                                    placeholder='Enter here'
                                />
                            </Form.Item>
                        </Col>
                    </Row>
                    <div style={{ display: "flex", justifyContent: "end", gap: "10px" }}>
                        <Button key="back" className='BG_ghostButton'
                        > Reset
                        </Button>
                        <button key="submit"
                            className='BG_mainButton' >
                            Submit
                        </button>
                    </div>
                </Form>
            </Modal> */}


            <BDAddValuesModal handleOk={handleOk} handleCancel={handleCancel} isModalOpen={isModalOpen} setIsModalOpen={setIsModalOpen} projectId={id} leadCompId={leadId} compScoreId={scoreId} valuesData={valuesData} />
        </div>
    )
}

export default BdCompetitor
