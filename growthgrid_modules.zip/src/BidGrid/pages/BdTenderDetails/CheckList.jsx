// @ts-nocheck
import React from 'react';
import { CloseOutlined, PlusOutlined, UploadOutlined } from '@ant-design/icons';
import { Button, Card, Form, Input, Progress, Typography, Upload } from 'antd';

const NestedItems = ({ fields, remove, path, add }) => (
    <>
        {fields.map((field, index) => (
            <Card
                size="small"
                title={`${path ? `${path}.` : ''}${index + 1}`}
                key={field.key}
                className="w-100 position-relative checklist-card"
                extra={<div className='d-flex gap-3'>
                    <Button className="addMenu-btn" type='primary' onClick={() => add()} >
                        + Add
                    </Button>
                    <CloseOutlined onClick={() => remove(field.name)} />
                    {/* <PlusOutlined onClick={() => add()} /> */}
                </div>}
            >
                <Form.Item
                    label="Title"
                    name={[field.name, 'title']}
                    rules={[{ required: true, message: 'Please input the title' }]}
                >
                    <Input />
                </Form.Item>
                <Form.Item label="Attachment" className='mb-3' name={[field.name, 'section']}>
                    <Upload>
                        <Button size="large" className='dashed-btn' icon={<UploadOutlined />}>
                            Click to Upload
                        </Button>
                    </Upload>
                </Form.Item>
                <Form.Item className='mb-0 submenu-h'>
                    <Form.List name={[field.name, 'subItems']}>
                        {(subFields, { add: addSub, remove: removeSubItem }) => (
                            <div className='d-flex gap-4 flex-column'>
                                <NestedItems fields={subFields} remove={removeSubItem} path={`${path ? `${path}.` : ''}${index + 1}`} add={addSub} />
                                <Button type="dashed" className="dashed-btn submenu-btn" onClick={() => addSub()} >
                                    + Add Sub Item
                                </Button>
                            </div>
                        )}
                    </Form.List>
                </Form.Item>
            </Card>
        ))}
    </>
);

const CheckList = ({ id }) => {
    const [form] = Form.useForm();

    return (
        <div className="profile_detail_info_box">
            <div className="info_box_left">
                <div>
                    <h5 className="mb-3">CheckList</h5>
                    <Progress percent={50} className='mb-3 checklist-progress' />
                    <Form
                        form={form}
                        name="dynamic_form_complex"
                        className="w-100"
                        autoComplete="off"
                        initialValues={{ items: [{}] }}
                    >
                        <Form.List name="items">
                            {(fields, { add, remove }) => (
                                <div className="d-flex flex-column gap-4">
                                    <NestedItems fields={fields} remove={remove} add={add} />
                                    {/* <Button type="dashed" className="dashed-btn" size="large" block onClick={() => add()}>
                                        + Add Item
                                    </Button> */}
                                </div>
                            )}
                        </Form.List>
                        <Form.Item noStyle shouldUpdate>
                            {() => (
                                <Typography>
                                    <pre>{JSON.stringify(form.getFieldsValue(), null, 2)}</pre>
                                </Typography>
                            )}
                        </Form.Item>
                    </Form>
                </div>
            </div>
        </div>
    );
};

export default CheckList;