
import React from 'react'
import { useParams } from 'react-router-dom/dist';
import { Form, Row, Col, Input, Button } from 'antd';

const BdFinancialDetail = () => {
    const { id } = useParams()

    return (

        <>
            <div className="project_info_form">
                <Form layout="vertical">
                    <Row gutter={20}>
                        <Col sm={6}>
                            <Form.Item label="Financial Proprosal" >
                                <Input placeholder='Enter here' defaultValue={'0.00'} />
                            </Form.Item>
                        </Col>
                        <Col sm={6}>
                            <Form.Item label="Value as per LOA" >
                                <Input placeholder='Enter here' />
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>
                <div className='bd_model_button info_btn'>
                    <Button key="back" className='BG_ghostButton'>
                        Reset
                    </Button>
                    <button key="submit" className='BG_mainButton' >
                        Save & Update
                    </button>
                </div>
            </div>
        </>

    )
}

export default BdFinancialDetail;