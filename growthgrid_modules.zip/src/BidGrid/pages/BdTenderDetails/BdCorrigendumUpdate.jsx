import React, { useState, useEffect } from 'react'

import { Write, Down, Right, Download } from '@icon-park/react';
import { Collapse, Drawer } from 'antd';

import skipBack from '../../assets/images/skip-back.png'
import { CorrigendumApi } from 'Services/bidgrid/tenderList/CorrigendumApi';
import { useParams } from 'react-router-dom';
import { docAuth, docurlchat } from 'utils/configurable';
import dayjs from 'dayjs';
import { TimeConverter } from 'BidGrid/components/TimeConverter/TimeConverter';

const { Panel } = Collapse;

function BdCorrigendumUpdate() {

    const [accordionActive, setAccordionActive] = useState(false);
    const [open, setOpen] = useState(false);

    const [corrDate, setCorrDate] = useState([]);
    const [corrFee, setCorrFee] = useState([]);
    const [corrExt, setCorrExt] = useState([]);
    const [corrOther, setcorrOther] = useState([]);

    const [dateChildData, setDateChildData] = useState(null);


    const { id } = useParams();

    // console.log('id--------',id);

    const showDrawer = (item) => {
        setOpen(true);
        setDateChildData(item);
    };

    const onClose = () => {
        setOpen(false);
    };

    const getTendersUpdates = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('tender_id', id);
            let result = await CorrigendumApi.getTenderUpdateRecord(formData);
            if (result?.data?.status == 1) {
                console.log('result?.data?.data?.corr_date', result?.data?.data?.corr_date);
                setCorrDate(result?.data?.data?.corr_date);
                setCorrFee(result?.data?.data?.corr_fee);
                setCorrExt(result?.data?.data?.corr_ext);
                setcorrOther(result?.data?.data?.corr_other);
            }
            else {
                setCorrDate([]);
                setCorrFee([]);
                setCorrExt([]);
                setcorrOther([]);
            }

        } catch (error) {
            console.log('error===', error);
        }

    }

    useEffect(() => {
        getTendersUpdates();
    }, [])

    const handleDownloadDoc = (item) => {
        console.log(item, "item");

        const apiUrl = `${item?.tender_category == 1 ? docurlchat : docAuth}${item?.doc_path}/${item?.document_name}`;

        // Open the file in a new tab
        const newTab = window.open(apiUrl, '_blank');
        if (newTab) {
            newTab.focus();
        } else {
            console.error("Failed to open new tab. Please check popup blocker settings.");
        }
    };

    const convertDateFormat=(date)=>{
        return date !== null ? `${dayjs(date).subtract(dayjs(date).utcOffset(), 'minute').format("DD MMM YYYY")}  ${TimeConverter(date)}` : '-'
    }

    return (
        <>
            <div className="tenderUpdate_wrapper">
                <div className='tu_head'>
                    <h2>Corrigendum Update</h2>
                </div>

                {corrDate?.length > 0 ? <div className='tu_card'>
                    <Collapse onChange={() => setAccordionActive(true)} defaultActiveKey={1} >
                        <Panel
                            key="1"
                            header={
                                <div className='bd_tender_profile_headings'>
                                    <h2>Critical Dates</h2>
                                    {accordionActive ?
                                        <Down theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                        :
                                        <Right theme="outline" size="28" fill="#b8b8b8" strokeWidth={3} strokeLinecap="butt" />
                                    }
                                </div>
                            }
                        >

                            {corrDate?.length > 0 && corrDate?.map(item => (
                                <div className="wrapper_box">
                                    <div className='heading__wrap'>
                                        <h2>{item?.bg_upd_corr_type_maste?.corrigendum_name}</h2>

                                       {item?.deteupdate !=null && <button className="update_btn BG_mainButton" onClick={()=>showDrawer(item?.deteupdate)}>
                                            Update history
                                        </button>}
                                    </div>
                                    <div className='tender_profile_fields'>
                                        <div className='profile_fields_name'><span>Publish date</span>:<p>{item?.published_date}</p></div>
                                        {/* <div className='profile_fields_name'><span>Bid opening date</span>:<p></p></div> */}
                                        <div className='profile_fields_name'><span>Title</span>:<p>{item?.corr_title}</p></div>
                                        {/* <div className='profile_fields_name'><span>Document download start date</span>:<p>03 Jan 2024</p></div> */}
                                        <div className='profile_fields_name'><span>Description</span>:<p>{item?.corr_desc}</p></div>
                                        <div className='profile_fields_name'><span>Document download</span>:<p>

                                            {
                                                item?.document_name !== null ?
                                                    <div className="doc__info_border_circle">
                                                        <p> Doc :</p><a onClick={() => handleDownloadDoc(item)} href={null} download={item?.document_name} target="_blank" > {item?.document_name}</a>
                                                        <Download theme="outline" size="18" fill="#684fd8" strokeWidth={3} strokeLinecap="butt" />

                                                    </div>
                                                    : ""
                                            }

                                        </p></div>
                                        {/*   <div className='profile_fields_name'><span>Clarification start date</span>:<p></p></div>
                                <div className='profile_fields_name'><span>Clarification end date</span>:<p></p></div>
                                <div className='profile_fields_name'><span>Bid submission start date</span>:<p></p></div>
                                <div className='profile_fields_name'><span>Bid submission start date</span>:<p>24 Aug 2024 12pm</p></div>
                                <div className='profile_fields_name'><span>Per-Bid meeting date</span>:<p>24 Aug 2024 12pm</p></div> */}
                                    </div>
                                </div>
                            ))
                            }
                            {/* <div className="wrapper_box">
                                <div className='heading__wrap'>
                                    <h2>24 May 2024 Update</h2>
                                    
                                    <button className="update_btn BG_mainButton" onClick={showDrawer}>
                                        Update history
                                    </button>
                                </div>
                                <div className='tender_profile_fields'>
                                    <div className='profile_fields_name'><span>Publish date</span>:<p>24 Aug 2024 12pm</p></div>
                                    <div className='profile_fields_name'><span>Bid opening date</span>:<p></p></div>
                                    <div className='profile_fields_name'><span>Document download start date</span>:<p>03 Jan 2024</p></div>
                                    <div className='profile_fields_name'><span>Document download end date</span>:<p>24 Aug 2024 12pm</p></div>
                                    <div className='profile_fields_name'><span>Clarification start date</span>:<p></p></div>
                                    <div className='profile_fields_name'><span>Clarification end date</span>:<p></p></div>
                                    <div className='profile_fields_name'><span>Bid submission start date</span>:<p></p></div>
                                    <div className='profile_fields_name'><span>Bid submission start date</span>:<p>24 Aug 2024 12pm</p></div>
                                    <div className='profile_fields_name'><span>Per-Bid meeting date</span>:<p>24 Aug 2024 12pm</p></div>
                                </div>
                            </div> */}

                        </Panel>
                    </Collapse>
                     
                    
                </div>
                : ''
            }
            </div>

            <Drawer
                className="update__drawer"
                title="Critical date updates"
                width={700}
                onClose={onClose}
                closeIcon={<img src={skipBack} alt='' />}
                open={open}>
                <div className="tenderUpdate_wrapper">
                    <div className='tu_card'>
                        <div className="tu_head">
                            <h2>Recent Update</h2>
                        </div>
                        <div className='tender_profile_fields'>
                            <div className='profile_fields_name'><span>Publish date :</span><p>{convertDateFormat(dateChildData?.publish_date)}</p></div>
                            <div className='profile_fields_name'><span>Bid opening date :</span><p>{convertDateFormat(dateChildData?.bid_opening_date)}</p></div>
                            <div className='profile_fields_name'><span>Document download start date :</span><p>{convertDateFormat(dateChildData?.document_download_start_date)}</p></div>
                            <div className='profile_fields_name'><span>Document download end date :</span><p>{convertDateFormat(dateChildData?.document_download_end_date)}</p></div>
                            <div className='profile_fields_name'><span>Clarification start date :</span><p>{convertDateFormat(dateChildData?.clarification_start_date)}</p></div>
                            <div className='profile_fields_name'><span>Clarification end date :</span><p>{convertDateFormat(dateChildData?.clarification_end_date)}</p></div>
                            <div className='profile_fields_name'><span>Bid submission start date :</span><p>{convertDateFormat(dateChildData?.bid_submission_start_date)}</p></div>
                            <div className='profile_fields_name'><span>Bid submission end date :</span><p>{convertDateFormat(dateChildData?.bid_submission_end_date)}</p></div>
                            <div className='profile_fields_name'><span>Per-Bid meeting date :</span><p>{convertDateFormat(dateChildData?.prebid_meeting_date)}</p></div>
                         </div>
                    </div>
                </div>
            </Drawer>
        </>
    )
}

export default BdCorrigendumUpdate
