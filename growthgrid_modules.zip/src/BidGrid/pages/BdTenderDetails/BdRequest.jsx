// @ts-nocheck
import { Button, DatePicker, Form, Input, Modal, Select, Table } from 'antd';
import React, { useEffect, useState } from 'react'
import { useLocation, useParams } from 'react-router-dom/dist';
import GenerateRequest from 'BidGrid/components/Drawer/GenerateRequest';
import { RequestApi } from 'Services/bidgrid/tenderList/RequestApi';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import { useMemo } from 'react';
import dayjs from 'dayjs';
import { toast } from 'react-toastify';
import xlsImg from '../../../assests/img/xls.png'
import coregImg from "../../../assests/img/pdf.png"
import fileImg from '../../../assests/img/file.png'
import RequestTable from 'BidGrid/components/dataTable/RequestTable';
import { Down } from '@icon-park/react';
import { useSelector } from 'react-redux';
import { docurlchat } from 'utils/configurable';
import { Avatar } from '@mui/material';
import { TimeConverter } from 'BidGrid/components/TimeConverter/TimeConverter';
const { Option } = Select;

const columnLabels = {

  subject: { name: "Subject", required: true, },
  desc_details: { name: "Description", required: true, },
  comment_txt: { name: "Comment", required: true, },
  req_from_userid: { name: "created by", required: true, },
  req_to_userid: { name: "Assigned To", required: true, },
  created_at: { name: "Created On  ", required: true, },
  file_name: { name: "File name", required: true, },
  curr_status: { name: "Status", required: true, },
};

const createdByOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }, { value: '3', label: 'Approved' }]
const assignedToOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }]

const BdRequest = ({ activeTabKey }) => {
  const [generateReqDrawer, setgenerateReqDrawer] = useState(false)
  const [showReminderModal, setShowReminderModal] = useState(false)

  // request
  const [requestList, setRequestList] = useState([])
  const [flattenedProjects, setFlattenedProjects] = useState([]);
  const [employeeListVal, setEmployeeListVal] = useState([])
  const [recordData, setRecordData] = useState({})
  const [dateVal, setDateVal] = useState(null)
  const [spinner, setSpinner] = useState(false)
  const { id } = useParams()
  const { userBidInfo } = useSelector((state) => state?.userDetails)

  const showActions = true;

  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);

  const location = useLocation();
  const val = location?.pathname;

  const handleReminderSubmit = () => {
    setShowReminderModal(false)
  }
  const handleReminderReset = () => {
    setShowReminderModal(false)
  }
  const generateRequesthandle = () => {
    setgenerateReqDrawer(true)
  }


  // user list

  const getUserList = async () => {
    try {
      const response = await bidEmployeeList.getUserList()
      if (response?.data?.status === "1") {
        setEmployeeListVal(response?.data?.data)
      }
    } catch (error) {

    }
  }

  // request list

  const fetchRequestList = async (initial) => {
    if (initial) {
      setSpinner(true)
    }
    const formData = new URLSearchParams();
    formData.append('tender_id', id)
    try {
      const response = await RequestApi.requestList(formData)
      if (response?.data?.status === "1") {

        const updatedArr = response?.data?.data?.map((item) => {
          let items = item


          if (items.curr_status === '1') {
            items['status'] = 'Pending'
          } else if (items.curr_status === '2') {
            items['status'] = 'Submitted'
          } else {
            items['status'] = 'Approved'
          }
          return items
        })

        setRequestList(updatedArr)
        setSpinner(false)
      } else {
        setRequestList([])
        setSpinner(false)
      }
    } catch (error) {
      setSpinner(false)
    }
  }

  const requestStatus = async (val, e) => {
    const formData = new FormData();
    formData.append('tender_id', val?.tender_id)
    formData.append('request_id', val?.id)
    formData.append('subject', val?.subject)
    formData.append('desc_details', val?.desc_details?.replace(/<[^>]*>/g, ''))
    formData.append('req_from_userid', val?.req_from_userid)
    formData.append('curr_status', Number(e))
    formData.append('comment_txt', val?.comment_txt)
    formData.append('req_to_userid', val?.req_to_userid)


    try {
      const response = await RequestApi.updateRequest(formData)
      if (response?.data?.status === "1") {
        await fetchRequestList()
        notifySuccess('Status update successfully')
      } else {
        notify(response?.response?.data?.message)
      }
    } catch (error) {
    }
  }


  // delete request 

  const handleDelete = async (val) => {
    console.log(val, 'val')
    const formData = new URLSearchParams();
    formData.append('request_id', val)
    try {
      const response = await RequestApi.deleteRequest(formData)
      if (response?.data?.status == 1) {
        notifySuccess(response?.data?.message)
        await fetchRequestList()
      }
      else {
        notify(response?.response?.data?.message)
      }
    } catch (error) {
      console.log(error, 'Api Error')
    }
  }



  const getPropDataVal = (record, status) => {
    setgenerateReqDrawer(status)
    if (status) {
      setRecordData(record)
    } else {
      setRecordData({})
    }
  }

  const getFileImage = (fileExtension) => {
    switch (fileExtension) {
      case 'xls':
        return xlsImg;
      case 'pdf':
        return coregImg;
      default:
        return fileImg;
    }
  };
  useEffect(() => {

    const flattenedData = requestList?.map(project => {
      const employee_from = employeeListVal?.find(item => item?.id === project?.req_from_userid)
      const employee_to = employeeListVal?.find(item => item?.id === project?.req_to_userid)
      const fileExtension = project?.file_name?.slice(-3); // Extract file extension
      const imgUrl = getFileImage(fileExtension);
      return {
        id: project?.id,
        subject: project?.subject,
        desc_details: project?.desc_details.replace(/<[^>]*>/g, ''),
        comment_txt: project?.comment_txt,
        req_from_userid: <div className="empFlex">
          <Avatar
            // sx={{ bgcolor: deepOrange[500] }}
            sizes=''
            sx={{ width: 32, height: 32 }}
            // alt="Remy Sharp"
            src={docurlchat + employee_from?.profileimg_path + '/' + employee_from?.profileimg}
          >
            {employee_from?.userfullname.slice(0, 1)}
          </Avatar>
          <span>{employee_from?.userfullname}</span>
        </div>,
        req_to_userid: <div className="empFlex">
          <Avatar
            // sx={{ bgcolor: deepOrange[500] }}
            sizes=''
            sx={{ width: 32, height: 32 }}
            // alt="Remy Sharp"
            src={docurlchat + employee_to?.profileimg_path + '/' + employee_to?.profileimg}
          >
            {employee_to?.userfullname.slice(0, 1)}
          </Avatar>
          <span>{employee_to?.userfullname}</span>
          {/* <Avatar
                        // sx={{ bgcolor: deepOrange[500] }}
                        sizes=''
                        sx={{ width: 32, height: 32 }}
                        // alt="Remy Sharp"
                        src={`${docurlchat}${project?.file_path}/${project?.file_name}`}
                    >
                        {employeeListVal?.filter(item => item?.id === project?.req_to_userid)?.map(items => items?.userfullname.slice(0, 1))}
                    </Avatar>
                    <span>{employeeListVal?.filter(item => item?.id === project?.req_to_userid)?.map(items => items?.userfullname)}</span> */}
        </div>,
        created_at: project?.created_at !== null ? `${dayjs(project?.created_at).format('YYYY-MM-DD')} ${TimeConverter(project?.created_at)}` : '',
        // curr_status: <><p className={project?.status === "Approval" ? 'approval' : project?.status === 'Pending' ? 'pending' : 'submitted'}>{project?.status}</p></>,
        file_name: <a href={`${docurlchat}${project?.file_path}/${project?.file_name}`} download={`${docurlchat}${project?.file_path}/${project?.file_name}`} target="_blank"><img src={imgUrl} alt="File Icon" width={30} /> {fileExtension}</a>,
        request_id: project?.req_to_userid,
        req_status: project?.curr_status,
        file_data: project?.file_name,
        file_path: project?.file_path,
        status: project?.status,
        created_by: project?.created_by,
        curr_status: <>
          <Select
            className={project?.status === "Approval" ? 'approved' : project?.status === 'Pending' ? 'pending' : 'submitted'}
            placeholder="Enter here"
            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
            optionFilterProp="label"
            // options={userBidInfo?.id === project?.created_by ? createdByOption : assignedToOption}
            options={userBidInfo?.id === project?.created_by ? createdByOption : (userBidInfo?.id === project?.req_to_userid && project?.curr_status !== '3') ? assignedToOption : createdByOption}
            onChange={(e) => requestStatus(project, e)}
            value={project?.status}
            // disabled={project?.status === 'Approval' ? true : false}
            disabled={(userBidInfo?.id !== project?.created_by && userBidInfo?.id !== project?.req_to_userid) || project?.curr_status === '3' ? true : false}

          />
        </>,

      }

    });

    setFlattenedProjects(flattenedData);
  }, [requestList]);

  const employeeTableData = useMemo(() => {
    return flattenedProjects;
  }, [flattenedProjects]);

  const documentBlobReq = async (doc_name, apiUrl) => {
    const fullUrl = window.location.href;
    const urlObject = new URL(fullUrl);
    const protocol = urlObject.protocol;
    const hostname = urlObject.host;
    const domain = `${protocol}//${hostname}`;
    const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
    const response = await fetch(proxyUrl)
    const blobData = await response?.blob()
    const fileURL = window.URL.createObjectURL(blobData);
    let alink = document.createElement("a");
    alink.href = fileURL;
    alink.download = doc_name;
    alink.click();
  }
  const documentFileDownload = (item) => {
    const apiUrl = `${docurlchat}${item?.doc_path}/${item?.file_name}`;
    documentBlobReq(item?.file_name, apiUrl)
  }
  const setTableData = (dateVal) => {
    setFlattenedProjects(dateVal?.map(project => ({
      id: project?.id,
      subject: project?.subject,
      desc_details: project?.desc_details.replace(/<[^>]*>/g, ''),
      comment_txt: project?.comment_txt,
      req_from_userid: <><span>{employeeListVal?.filter(item => item?.id === project?.req_from_userid)?.map(items => items?.userfullname)}</span></>,
      req_to_userid: <><img src={`${docurlchat}${project?.file_path}/${project?.file_name}`} width={50} /><span>{employeeListVal?.filter(item => item?.id === project?.req_to_userid)?.map(items => items?.userfullname)}</span></>,
      created_at: project?.created_at !== null ? `${dayjs(project?.created_at).format('YYYY-MM-DD')} ${TimeConverter(project?.created_at)}` : '',
      // curr_status: <><p className={project?.status === "Approval" ? 'approval' : project?.status === 'Pending' ? 'pending' : 'submitted'}>{project?.status}</p></>,
      file_name: <a href={`${docurlchat}${project?.file_path}/${project?.file_name}`} download={`${docurlchat}${project?.file_path}/${project?.file_name}`} target="_blank">{project?.file_name}</a>,
      request_id: project?.req_to_userid,
      req_status: project?.curr_status,
      created_by: project?.created_by,
      status: project?.status,

      curr_status:
        <>
          <Select
            className={project?.status === "Approval" ? 'approved' : project?.status === 'Pending' ? 'pending' : 'submitted'}
            placeholder="Enter here"
            suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
            optionFilterProp="label"
            // options={userBidInfo?.id === project?.created_by ? createdByOption : assignedToOption}
            options={userBidInfo?.id === project?.created_by ? createdByOption : (userBidInfo?.id === project?.req_to_userid && project?.curr_status !== '3') ? assignedToOption : createdByOption}

            onChange={(e) => requestStatus(project, e)}
            value={project?.status}
            // disabled={project?.status === 'Approval' ? true : false}
            disabled={(userBidInfo?.id !== project?.created_by && userBidInfo?.id !== project?.req_to_userid) || project?.curr_status === '3' ? true : false}

          />
        </>
      // file_name_val:project?.file_name,



    }))
    );
  }


  const handleDateChange = (e) => {
    if (e) {
      const formattedDate = dayjs(e).format('YYYY-MM-DD');
      setDateVal(e);
      // Filter the projects based on the selected date
      const filteredProjects = requestList?.filter(item => dayjs(item?.created_at).format('YYYY-MM-DD') === formattedDate);
      setTableData(filteredProjects)
    } else {
      // If no date is selected, show the whole data
      setDateVal(null);
      setTableData(requestList)
    }
  }

  useEffect(() => {
    getUserList()
  }, [])


  useEffect(() => {
    if (employeeListVal?.length > 0) {
      fetchRequestList()
    }
  }, [employeeListVal])

  useEffect(() => {

    if (activeTabKey === '8') {
      fetchRequestList()
    }

  }, [activeTabKey])

  const handleKeyPressSelectedItem = (e) => {
    // const alphabeticChars = /[a-zA-Z]/;
    const forbiddenChars = /[{ }.\[\]""''`~;:,0-9\-_@#$%^&*()<>?/|+=!\\]/;
    if (!forbiddenChars.test(e.key)) {
      e.preventDefault();
    }
    else if (e.key === 'Enter') {
      e.preventDefault();
      // handleProjectInfo()
    } else if (e.key === ' ' && e.target.selectionStart === 0) {
      e.preventDefault();
    }
  };


  return (
    <div className="meetingSchedule_wraper">
      <div className="bd_emplist_main">
        <div className="bd_empHeader">
          <div className="bd_emplist_main_header">Request List</div>
          <div className="buttonFlex">
            <Form.Item >
              <DatePicker placeholder='Filter by '
                onChange={handleDateChange}
                value={dateVal}
              />
            </Form.Item>
            <button className="BG_mainButton" onClick={generateRequesthandle} >
              Add Request
            </button>
          </div>
        </div>
      </div>

      <Modal
        visible={showReminderModal}
        title="Send Reminder"
        onCancel={() => setShowReminderModal(false)}
        footer={[
          <Button key="reset" className='BG_ghostButton' onClick={handleReminderReset}>
            Reset
          </Button>,
          <Button key="submit" type="primary" className='BG_mainButton' onClick={handleReminderSubmit}>
            Submit
          </Button>
        ]}
      >
        <Form layout="vertical">
          <Form.Item
            label="Remind before"
          // name="inputBox"
          // rules={[{ required: true, message: 'Please enter something!' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label="Remind before"
          // name="selectBox"
          // rules={[{ required: true, message: 'Please select something!' }]}
          >
            <Select>
              <Option value="option1">Option 1</Option>
              <Option value="option2">Option 2</Option>
              <Option value="option3">Option 3</Option>
            </Select>
          </Form.Item>
        </Form>
      </Modal>

      <GenerateRequest open={generateReqDrawer} onClose={() => setgenerateReqDrawer(false)} id={id} employeeListVal={employeeListVal} recordData={recordData} setRecordData={setRecordData} fetchRequestList={fetchRequestList} setSpinner={setSpinner} />

      {/* add request Dawer */}

      <RequestTable
        columnLabels={columnLabels}
        dataSource={employeeTableData}
        showActions={showActions}
        locationVal={val}
        TenderId={id}
        generateReqDrawer={generateReqDrawer}
        setgenerateReqDrawer={setgenerateReqDrawer}
        // showReminderModal={showReminderModal}
        setShowReminderModal={setShowReminderModal}
        handleDelete={handleDelete}
        title="Request"
        getPropDataVal={getPropDataVal}
        spinner={spinner}
        setSpinner={setSpinner}

      />


    </div>
  )
}

export default BdRequest;