// @ts-nocheck
import { PlusCircleOutlined } from '@ant-design/icons'
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { Button, Col, Form, Input, Modal, Row, Select, } from 'antd'
import { Down } from '@icon-park/react';
import React, { useEffect, useState } from 'react'
import { toast } from 'react-toastify';
const { Option } = Select;

const intidata = {
    lead_comp_id: null,
    associats_id: [],
    jvs_company: []
}

const initCompanyArr = {
    lead_comp_id: [],
    associats_id: [],
    jvs_company: []
}
const BdVentureModal = (props) => {
    const { dataSource, showVentureModal, setShowVentureModal, id, handleComapny, modalData, spinner, setSpinner } = props
    const [consortiumInitial, setConsortiumInitial] = useState(intidata)
    const [companyOptions, setCompanyOptions] = useState(initCompanyArr)
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [form] = Form.useForm();
    const [disabledOption, setDisabledOption] = useState({
        disableLead: [],
        disableJvs: [],
        disableAssociative: []
    })
    const [disabledOptionComp, setDisabledOptionComp] = useState({
        disableLead: [],
        disableJvs: [],
        disableAssociative: []
    })
    const [loadings, setLoadings] = useState(false);

    const handleChange = (name, value) => {
        setConsortiumInitial((prevDataOption) => ({
            ...prevDataOption,
            [name]: value
        }));
    };

    const disableListIds = () => {
        let disableCompetitorIds = [];
        let modalDataIds = []

        if (modalData?.hasOwnProperty('comptitor_assign_company_list')) {
            const leadCompanyIds = Number(modalData?.comptitor_assign_company_list.Lead_company.find(company => company.company_id)?.company_id);
            const jvCompanyIds = modalData?.comptitor_assign_company_list.jvs_company.map(company => company.company_id);
            const associativeCompanyIds = modalData?.comptitor_assign_company_list.associative_company.map(company => company.company_id);
            modalDataIds.push(leadCompanyIds, ...jvCompanyIds, ...associativeCompanyIds)
        }
        if (dataSource?.length > 0) {
            dataSource?.map(item => {
                disableCompetitorIds.push(Number(item?.comptitor_assign_company_list?.Lead_company[0]?.company_id))
                const associativeCompanyIds = item?.comptitor_assign_company_list?.associative_company?.map(item => Number(item?.company_id));
                if (associativeCompanyIds) {
                    disableCompetitorIds.push(...associativeCompanyIds);
                }
                const jvsCompanyIds = item?.comptitor_assign_company_list?.jvs_company?.map(item => Number(item?.company_id))
                if (jvsCompanyIds) {
                    disableCompetitorIds.push(...jvsCompanyIds);
                }
            })
        }
        const uniqueSetIds = disableCompetitorIds.filter(item => !modalDataIds.includes(item));

        const { disableLead, disableJvs, disableAssociative } = disabledOption;

        let disableLead_new = [...disableLead, ...uniqueSetIds];
        let disableJvs_new = [...disableJvs, ...uniqueSetIds];
        let disableAssociative_new = [...disableAssociative, ...uniqueSetIds];

        setDisabledOption({
            disableLead: disableLead_new,
            disableJvs: disableJvs_new,
            disableAssociative: disableAssociative_new
        });
    }

    const getCompetition = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('project_id', id)
            const response = await TenderApi?.CompetitorList(formData)
            if (response?.data?.status === '1') {
                setCompanyOptions((prevState) => ({
                    ...prevState,
                    lead_comp_id: response?.data?.data,
                    associats_id: response?.data?.data,
                    jvs_company: response?.data?.data
                }))
            }
        } catch (error) {
            console.log('Api Error', error);
        }
    }


    const predefinedVal = () => {
        const { disableLead, disableJvs, disableAssociative } = disabledOption

        const existsAss = consortiumInitial?.associats_id || [];
        const existsJvs = consortiumInitial?.jvs_company || [];
        const existsLeadComp = consortiumInitial?.lead_comp_id !== null ? consortiumInitial?.lead_comp_id : [];

        let disableLead_new = [...existsAss, ...existsJvs, ...disableLead];
        let disableJvs_new = [existsLeadComp, ...existsAss, ...disableJvs];
        let disableAssociative_new = [existsLeadComp, ...existsJvs, ...disableAssociative];

        disableJvs_new?.filter(item => {
            if (item?.length === 0) {
                disableJvs_new.splice(0, 1)
            } else {
                return disableJvs_new
            }
        })

        disableAssociative_new?.filter(item => {
            if (item?.length === 0) {
                disableAssociative_new.splice(0, 1)
            } else {
                return disableAssociative_new
            }
        })

        setDisabledOption({
            disableLead: disableLead_new,
            disableJvs: disableJvs_new,
            disableAssociative: disableAssociative_new
        });

    }

    useEffect(() => {
        predefinedVal()
    }, [consortiumInitial?.lead_comp_id, consortiumInitial?.associats_id, consortiumInitial?.jvs_company]);

    const handleSubmit = async () => {
        setLoadings(true)

        try {
            const formData = new URLSearchParams();
            formData.append('project_id', id)
            formData.append('lead_comp_ids', consortiumInitial?.lead_comp_id)
            { consortiumInitial?.jvs_company?.length > 0 && formData.append('jv_ids', consortiumInitial?.jvs_company) }
            { consortiumInitial?.associats_id?.length > 0 && formData.append('associative_ids', consortiumInitial?.associats_id) }
            const response = await TenderApi?.CompetitorAssign(formData)
            if (response?.data?.status === '1') {
                notifySuccess('Competitor add successfully')
                setShowVentureModal(false)
                setConsortiumInitial(intidata)
                setSpinner(true)
                setLoadings(false)
                await handleComapny(false)
            }
            else {
                notify(response?.data?.message, "error in a api")
                setSpinner(false)
                setLoadings(false)
            }

        } catch (error) {
            console.log('Api Error', error);
            setSpinner(false)
            setLoadings(false)
        }
    }

    const handleUpdate = async () => {
        setLoadings(true)
        if (modalData?.comptitor_assign_company_list?.Lead_company[0]?.type_data == '1') {
            try {
                const formData = new URLSearchParams();
                formData.append('project_id', id)
                formData.append('lead_comp_id', consortiumInitial?.lead_comp_id)
                { consortiumInitial?.jvs_company?.length > 0 && formData.append('jvs_company', consortiumInitial?.jvs_company) }
                { consortiumInitial?.associats_id?.length > 0 && formData.append('associats_id', consortiumInitial?.associats_id) }
                const response = await TenderApi.updateConsortium(formData)
                if (response?.data?.status === '1') {
                    notifySuccess("Competitor update successfully")
                    setShowVentureModal(false)
                    setConsortiumInitial(intidata)
                    setSpinner(true)
                    setLoadings(false)
                    await handleComapny(false)
                }
            } catch (error) {
                console.log('Api Error', error);
                setSpinner(false)
                setLoadings(false)
            }
        }
        else {
            const group_id = Number(modalData?.comptitor_assign_company_list?.Lead_company[0]?.group_no)
            try {
                const formData = new URLSearchParams();
                formData.append('project_id', id)
                formData.append('group_no', group_id)
                formData.append('lead_comp_ids', Number(consortiumInitial?.lead_comp_id))
                { consortiumInitial?.jvs_company?.length > 0 && formData.append('jv_ids', consortiumInitial?.jvs_company) }
                { consortiumInitial?.associats_id?.length > 0 && formData.append('associative_ids', consortiumInitial?.associats_id) }
                const response = await TenderApi?.editCompetitorCompany(formData)
                if (response?.data?.status === '1') {
                    notifySuccess("Competitor update successfully")
                    setShowVentureModal(false)
                    setConsortiumInitial(intidata)
                    setSpinner(true)
                    setLoadings(false)
                    await handleComapny(false)
                }
            } catch (error) {
                console.log('Api Error', error);
                setSpinner(false)
                setLoadings(false)
            }
        }


    }

    const handleReset = () => {
        setConsortiumInitial(prevState => ({
            ...prevState,
            lead_comp_id: [],
            associats_id: [],
            jvs_company: []
        }))
        form.resetFields();
    }


    useEffect(() => {
        if (modalData?.hasOwnProperty('comptitor_assign_company_list')) {
            prepopulateFormFields(modalData.comptitor_assign_company_list);
        }
    }, [modalData]);

    const prepopulateFormFields = (companyList) => {

        const leadCompanyIds = Number(companyList.Lead_company.find(company => company.company_id)?.company_id);
        const jvCompanyIds = companyList.jvs_company.map(company => company.company_id);
        const associativeCompanyIds = companyList.associative_company.map(company => company.company_id);
        setConsortiumInitial({
            lead_comp_id: leadCompanyIds,
            associats_id: associativeCompanyIds,
            jvs_company: jvCompanyIds
        });
        form.setFieldsValue({
            lead_comp_id: leadCompanyIds,
            jvs_company: jvCompanyIds,
            associats_id: associativeCompanyIds
        });
    };

    useEffect(() => {
        if (showVentureModal === true) {
            getCompetition()
        }
    }, [showVentureModal])

    useEffect(() => {
        disableListIds()
    }, [dataSource])

    return (
        <>
            <Modal title={modalData?.comptitor_assign_company_list ? "Edit Competitor" : "Add Competitor"} className='bd_model_main'

                open={showVentureModal}
                onOk={() => setShowVentureModal(false)}
                onCancel={() => { setShowVentureModal(false); setConsortiumInitial(intidata) }}
                footer={null}
            >
                <Form
                    form={form}
                    layout="vertical"
                    name="control-hooks"
                    onFinish={() => modalData?.hasOwnProperty('comptitor_assign_company_list') ? handleUpdate() : handleSubmit()}
                >
                    <Row gutter={20}>
                        <Col sm={24}>

                            {/* <Form.Item label="Lead Company" name="lead_comp_id" rules={[{ required: true, message: "please enter a Lead Company" }]}>
                                <Select
                                    showSearch
                                    optionFilterProp="children"
                                    allowClear
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    placeholder='Enter here...'

                                    // name='lead_comp_id'
                                    onChange={(value) => handleChange('lead_comp_id', value)}
                                    value={consortiumInitial?.lead_comp_id}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                >
                                    {companyOptions?.lead_comp_id?.map((item) => {
                                        return (
                                            <Option key={item?.id} value={item?.id} disabled={disabledOption?.disableLead?.includes(item?.id)}>
                                                {item?.company_name}
                                            </Option>
                                        )
                                    }
                                    )}
                                </Select>
                            </Form.Item> */}
                            <Form.Item label="Lead Company" name="lead_comp_id" rules={[{ required: true, message: "please enter a Lead Company" }]}>
                                <Select
                                    showSearch
                                    optionFilterProp="children"
                                    allowClear
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    placeholder="Enter here..."
                                    onChange={(value) => handleChange('lead_comp_id', value)}
                                    value={consortiumInitial?.lead_comp_id}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                    options={companyOptions?.lead_comp_id?.map((item) => ({
                                        value: item?.id,
                                        label: item?.company_name,
                                        disabled: disabledOption?.disableLead?.includes(item?.id)
                                    }))}
                                />
                            </Form.Item>

                        </Col>
                        <Col sm={24}>
                            <Form.Item label="JV(Joint Venture)"
                            >
                                <Select
                                    allowClear
                                    placeholder='Enter here...'
                                    mode='multiple'
                                    value={consortiumInitial?.jvs_company?.map((id) =>
                                        companyOptions?.jvs_company?.find((company) => company.id === Number(id))?.company_name
                                    )}
                                    name='jvs_company'
                                    onChange={(value) => {
                                        const selectedIds = value.map((name) =>
                                            companyOptions?.jvs_company?.find((company) => company.company_name === name)?.id
                                        );
                                        handleChange('jvs_company', selectedIds);
                                    }}
                                >
                                    {companyOptions?.jvs_company?.map((item) => (
                                        <Option key={item?.id} value={item?.company_name} disabled={disabledOption?.disableJvs?.includes(item?.id)}>
                                            {item?.company_name}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col>

                        <Col sm={24}>
                            <Form.Item label="Associate Company Id">
                                <Select
                                    allowClear
                                    placeholder='Enter here...'
                                    mode='multiple'
                                    value={consortiumInitial?.associats_id?.map((id) =>
                                        companyOptions?.associats_id.find((company) => company.id === Number(id))?.company_name
                                    )}
                                    name='associats_id'
                                    onChange={(value) => {
                                        const selectedIds = value.map((name) =>
                                            companyOptions?.associats_id.find((company) => company.company_name === name)?.id
                                        );
                                        handleChange('associats_id', selectedIds);
                                    }}
                                >
                                    {companyOptions?.associats_id?.map((item) => (
                                        <Option key={item?.id} value={item?.company_name} disabled={disabledOption?.disableAssociative?.includes(item?.id)}>
                                            {item?.company_name}
                                        </Option>
                                    ))}
                                </Select>
                            </Form.Item>
                        </Col>
                    </Row>
                    <div style={{ display: "flex", justifyContent: "end", gap: "10px" }}>
                        <Button key="back" className='BG_ghostButton' onClick={handleReset}
                        > Reset
                        </Button>
                        <Button key="submit"
                            className='BG_mainButton' type="primary" htmlType="submit" loading={loadings} disabled={loadings}>
                            {modalData?.hasOwnProperty('comptitor_assign_company_list') ? "Update" : "Submit"}
                        </Button>
                    </div>
                </Form>
            </Modal >

        </>

    )
}

export default BdVentureModal