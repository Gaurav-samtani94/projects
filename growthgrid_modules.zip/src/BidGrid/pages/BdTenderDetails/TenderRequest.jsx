// @ts-nocheck
import React, { useEffect, useState } from 'react'
import { DatePicker, Form, Select, Input, Button, Modal } from 'antd';
import { DashboardServiceApi } from 'Services/bidgrid/dashboard/DashboardAPi';
import dayjs from 'dayjs';
import { toast } from 'react-toastify';
import xlsImg from '../../../assests/img/xls.png'
import coregImg from "../../../assests/img/pdf.png"
import fileImg from '../../../assests/img/file.png'
import AddRequestDrawer from 'BidGrid/components/Drawer/AddRequestDrawer';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import { useLocation, useParams } from 'react-router-dom';
import RequestTable from 'BidGrid/components/dataTable/RequestTable';
import { Down } from '@icon-park/react';
import { useSelector } from 'react-redux';
import { RequestApi } from 'Services/bidgrid/tenderList/RequestApi';
import { docurlchat } from 'utils/configurable';
import { Avatar } from '@mui/material';
import { TimeConverter } from 'BidGrid/components/TimeConverter/TimeConverter';

const { Option } = Select;

const columnLabels = {
    // ID: { name: "ID", required: true, },
    tender_name: { name: 'Tender Name', required: true, width: 400 },
    subject: { name: "Subject", required: true, },
    desc_details: { name: "Description", required: true, },
    comment_txt: { name: "Remarks", required: true, },
    created_at: { name: "created on", required: true, },
    req_from_userid: { name: "created by", required: true, },
    req_to_userid: { name: "Assigned To", required: true, },
    file_name: { name: "File Name", required: true, },
    curr_status: { name: "status", required: true, },
};

const createdByOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }, { value: '3', label: 'Approved' }]
const assignedToOption = [{ value: '1', label: 'Pending' }, { value: '2', label: 'Submitted' }]

const TenderRequest = (props) => {
    const { employeeListVal } = props
    const [requestList, setRequestList] = useState([])
    const [flattenedProjects, setFlattenedProjects] = useState([]);
    const [dateVal, setDateVal] = useState(null)
    const [tenderRequestDetail, setTenderRequestDetail] = useState({})
    const [addRequestDrawer, setAddRequestDrawer] = useState(false)
    const [generateReqDrawer, setgenerateReqDrawer] = useState(false)
    const [recordData, setRecordData] = useState({})

    // remainder
    const [showReminderModal, setShowReminderModal] = useState(false)

    const { userBidInfo } = useSelector((state) => state?.userDetails)
    const showActions = true;
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    // remainder
    const handleReminderSubmit = () => {
        setShowReminderModal(false)
    }
    const handleReminderReset = () => {
        setShowReminderModal(false)
    }

    const listRequest = async () => {

        try {
            let response = await DashboardServiceApi.getRequestList();
            if (response?.data?.status === '1') {
                const updatedArr = response?.data?.data?.map((item) => {
                    let items = item
                    if (items.curr_status === '1') {
                        items['status'] = 'Pending'
                    } else if (items.curr_status === '2') {
                        items['status'] = 'Submitted'
                    } else {
                        items['status'] = 'Approved'
                    }
                    return items
                })
                setRequestList(updatedArr)
            } else {
                console.log(response?.data?.message)
            }
        } catch (error) {
            console.log('testError', error)
        }

    }


    const setTableData = (dateVal) => {



        setFlattenedProjects(dateVal?.map(project => {
            const employee_from = employeeListVal?.find(item => item?.id == project?.req_from_userid)
            const employee_to = employeeListVal?.find(item => item?.id == project?.req_to_userid)
            return {
                id: project?.id,
                subject: project?.subject,
                desc_details: project?.desc_details?.replace(/<[^>]*>/g, ''),
                comment_txt: project?.comment_txt,
                req_from_userid: <div className="empFlex">
                    <Avatar
                        // sx={{ bgcolor: deepOrange[500] }}
                        sizes=''
                        sx={{ width: 32, height: 32 }}
                        // alt="Remy Sharp"
                        src={docurlchat + employee_from?.profileimg_path + '/' + employee_from?.profileimg}
                    >
                        {employee_from?.userfullname.slice(0, 1)}
                    </Avatar>
                    <span>{employee_from?.userfullname}</span>
                </div>,
                req_to_userid: <div className="empFlex">
                    <Avatar
                        // sx={{ bgcolor: deepOrange[500] }}
                        sizes=''
                        sx={{ width: 32, height: 32 }}
                        // alt="Remy Sharp"
                        src={docurlchat + employee_to?.profileimg_path + '/' + employee_to?.profileimg}
                    >
                        {employee_to?.userfullname.slice(0, 1)}
                    </Avatar>
                    <span>{employee_to?.userfullname}</span>
                </div>,
                created_at: project?.created_at !== null ? `${dayjs(project?.created_at).format('YYYY-MM-DD')} ${TimeConverter(project?.created_at)}` : '',
                status: project?.status,
                file_name: project?.file_name,
                request_id: project?.req_to_userid,
                tender_name:
                    val === '/bidgrid/request' ? (
                        <p className="requestTenderName">
                            {capitalizeExceptPrepositionsAndLowerCase(project?.tender_Data?.tender_name?.replace(/<[^>]*>/g, ''))}
                        </p>
                    ) : (
                        <p className="requestTenderName" onClick={() => handleAddRequestDrawer(project?.id)}>
                            {capitalizeExceptPrepositionsAndLowerCase(project?.tender_Data?.tender_name?.replace(/<[^>]*>/g, ''))}
                        </p>
                    ),
                file_path: project?.file_path,
                file_data: project?.file_name,
                tender_id: project?.tender_id,
                created_by: project?.created_by,
                curr_status: <>
                    <Select
                        className={project?.status === "Approval" ? 'approved' : project?.status === 'Pending' ? 'pending' : 'submitted'}
                        placeholder="Enter here"
                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                        optionFilterProp="label"
                        // options={userBidInfo?.id === project?.created_by ? createdByOption : assignedToOption}
                        options={userBidInfo?.id === project?.created_by ? createdByOption : (userBidInfo?.id === project?.req_to_userid && project?.curr_status !== '3') ? assignedToOption : createdByOption}
                        onChange={(e) => requestStatus(project, e)}
                        value={project?.status}
                        // disabled={project?.status === 'Approval' ? true : false}
                        disabled={(userBidInfo?.id !== project?.created_by && userBidInfo?.id !== project?.req_to_userid) || project?.curr_status === '3' ? true : false}

                    />
                </>,
                req_status: project?.curr_status,

            }
        }));
    }

    const handleDateChange = (e) => {
        if (e) {
            const formattedDate = dayjs(e).format('YYYY-MM-DD');
            setDateVal(e);
            // Filter the projects based on the selected date
            const filteredProjects = requestList?.filter(item => dayjs(item?.created_at).format('YYYY-MM-DD') === formattedDate);
            setTableData(filteredProjects)

        } else {
            // If no date is selected, show the whole data
            setDateVal(null);
            setTableData(requestList)

        }
    }

    const requestStatus = async (val, e) => {
        const formData = new FormData();
        formData.append('tender_id', val?.tender_id)
        formData.append('request_id', val?.id)
        formData.append('subject', val?.subject)
        formData.append('desc_details', val?.desc_details?.replace(/<[^>]*>/g, ''))
        formData.append('req_from_userid', val?.req_from_userid)
        formData.append('curr_status', Number(e))
        formData.append('comment_txt', val?.comment_txt)
        formData.append('req_to_userid', val?.req_to_userid)


        try {
            const response = await RequestApi.updateRequest(formData)
            if (response?.data?.status === "1") {
                await listRequest()
                notifySuccess('Status update successfully')

            } else {
                notify(response?.response?.data?.message)
                // setSpinner(false)
            }
        } catch (error) {
            // setSpinner(false)
        }
    }

    const getFileImage = (fileExtension) => {
        switch (fileExtension) {
            case 'xls':
                return xlsImg;
            case 'pdf':
                return coregImg;
            default:
                return fileImg;
        }
    };
    const handleAddRequestDrawer = async (val) => {
        setAddRequestDrawer(true)
        const formData = new URLSearchParams();
        formData.append('request_id', val)
        try {
            const response = await DashboardServiceApi?.requestsDetail(formData)
            if (response?.data?.status == 1) {
                setTenderRequestDetail(response?.data?.data)
            }
            else {
                console.log(response?.response?.data?.message)
            }
        } catch (error) {
            console.log(error, 'Api Error')
        }

    }


    useEffect(() => {
        const flattenedData = requestList?.map(project => {
            const fileExtension = project?.file_name?.slice(-3); // Extract file extension
            const imgUrl = getFileImage(fileExtension);
            const employee_from = employeeListVal?.find(item => item?.id === project?.req_from_userid)
            const employee_to = employeeListVal?.find(item => item?.id === project?.req_to_userid)
            console.log("profile image", docurlchat + employee_from?.profileimg_path + '/' + employee_from?.profileimg, employee_from?.userfullname)

            return {
                id: project?.id,
                subject: project?.subject,
                desc_details: project?.desc_details.replace(/<[^>]*>/g, ''),
                comment_txt: project?.comment_txt,
                req_from_userid: <div className="empFlex">
                    <Avatar
                        // sx={{ bgcolor: deepOrange[500] }}
                        sizes=''
                        sx={{ width: 32, height: 32 }}
                        // alt="Remy Sharp"
                        src={docurlchat + employee_from?.profileimg_path + '/' + employee_from?.profileimg}
                    >
                        {employee_from?.userfullname.slice(0, 1)}
                    </Avatar>
                    <span>{employee_from?.userfullname}</span>
                </div>,
                req_to_userid: <div className="empFlex">
                    <Avatar
                        // sx={{ bgcolor: deepOrange[500] }}
                        sizes=''
                        sx={{ width: 32, height: 32 }}
                        // alt="Remy Sharp"
                        src={docurlchat + employee_to?.profileimg_path + '/' + employee_to?.profileimg}
                    >
                        {employee_to?.userfullname.slice(0, 1)}
                    </Avatar>
                    <span>{employee_to?.userfullname}</span>
                    {/* <Avatar
                        // sx={{ bgcolor: deepOrange[500] }}
                        sizes=''
                        sx={{ width: 32, height: 32 }}
                        // alt="Remy Sharp"
                        src={`${docurlchat}${project?.file_path}/${project?.file_name}`}
                    >
                        {employeeListVal?.filter(item => item?.id === project?.req_to_userid)?.map(items => items?.userfullname.slice(0, 1))}
                    </Avatar>
                    <span>{employeeListVal?.filter(item => item?.id === project?.req_to_userid)?.map(items => items?.userfullname)}</span> */}
                </div>,
                created_at: project?.created_at !== null ? `${dayjs(project?.created_at).format('YYYY-MM-DD')} ${TimeConverter(project?.created_at)}` : '',
                status: project?.status,
                file_name: <a href={`${docurlchat}${project?.file_path}/${project?.file_name}`} download={`${docurlchat}${project?.file_path}/${project?.file_name}`} target="_blank"> <img src={imgUrl} alt="File Icon" width={30} /> {fileExtension}</a>,
                request_id: project?.req_to_userid,
                tender_name:
                    val === '/bidgrid/request' ? (
                        <p className="requestTenderName">
                            {capitalizeExceptPrepositionsAndLowerCase(project?.tender_Data?.tender_name?.replace(/<[^>]*>/g, ''))}
                        </p>
                    ) : (
                        <p className="requestTenderName" onClick={() => handleAddRequestDrawer(project?.id)}>
                            {capitalizeExceptPrepositionsAndLowerCase(project?.tender_Data?.tender_name?.replace(/<[^>]*>/g, ''))}
                        </p>
                    ),
                file_path: project?.file_path,
                file_data: project?.file_name,
                tender_id: project?.tender_id,
                created_by: project?.created_by,
                curr_status: <>
                    <Select
                        className={project?.status === "Approval" ? 'approved' : project?.status === 'Pending' ? 'pending' : 'submitted'}
                        placeholder="Enter here"
                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                        optionFilterProp="label"
                        // options={userBidInfo?.id === project?.created_by ? createdByOption : assignedToOption}
                        options={userBidInfo?.id === project?.created_by ? createdByOption : (userBidInfo?.id === project?.req_to_userid && project?.curr_status !== '3') ? assignedToOption : createdByOption}

                        onChange={(e) => requestStatus(project, e)}
                        value={project?.status}
                        // disabled={project?.status === 'Approval' ? true : false}
                        disabled={(userBidInfo?.id !== project?.created_by && userBidInfo?.id !== project?.req_to_userid) || project?.curr_status === '3' ? true : false}

                    />
                </>,
                req_status: project?.curr_status

            };

        });
        if (flattenedData?.length > 0) {
            setFlattenedProjects(flattenedData);
        }
    }, [requestList]);


    useEffect(() => {
        if (employeeListVal?.length > 0) {
            listRequest()
        }
    }, [employeeListVal])

    const location = useLocation();
    let val = location?.pathname;



    const documentBlobReq = async (doc_name, apiUrl) => {
        const fullUrl = window.location.href;
        const urlObject = new URL(fullUrl);
        const protocol = urlObject.protocol;
        const hostname = urlObject.host;
        const domain = `${protocol}//${hostname}`;
        const proxyUrl = `${domain}/proxy?url=${encodeURIComponent(apiUrl)}`;
        const response = await fetch(proxyUrl)
        const blobData = await response?.blob()
        const fileURL = window.URL.createObjectURL(blobData);
        let alink = document.createElement("a");
        alink.href = fileURL;
        alink.download = doc_name;
        alink.click();
    }

    const getPropDataVal = (record, status) => {
        setgenerateReqDrawer(status)
        if (status) {
            setRecordData(record)
        } else {
            setRecordData({})
        }
    }

    return (
        <>
            <div className="bd_dashboard_request">
                <div className="bd_dashboard_title">
                    <h5>Tender Requests</h5>
                    <div className="buttonFlex">
                        <Form.Item style={{ width: 250 }} rules={[{ required: true, message: "Last Name is Required" }]}>
                            <DatePicker placeholder='Filter by '
                                onChange={handleDateChange}
                                value={dateVal}
                            />
                        </Form.Item>
                    </div>
                </div>
                {val === '/bidgrid/request' ? (
                    <RequestTable columnLabels={columnLabels} dataSource={flattenedProjects} showActions={showActions} setShowReminderModal={setShowReminderModal} generateReqDrawer={generateReqDrawer} setgenerateReqDrawer={setgenerateReqDrawer} listRequest={listRequest} recordData={recordData} setRecordData={setRecordData} getPropDataVal={getPropDataVal} employeeListVal={employeeListVal} />
                ) : (
                    <RequestTable columnLabels={columnLabels} dataSource={flattenedProjects} employeeListVal={employeeListVal} />
                )}

                <Modal
                    visible={showReminderModal}
                    title="Send Reminder"
                    onCancel={() => setShowReminderModal(false)}
                    footer={[
                        <Button key="reset" className='BG_ghostButton' onClick={handleReminderReset}>
                            Reset
                        </Button>,
                        <Button key="submit" type="primary" className='BG_mainButton' onClick={handleReminderSubmit}>
                            Submit
                        </Button>
                    ]}
                >
                    <Form layout="vertical">
                        <Form.Item
                            label="Remind before"
                        // name="inputBox"
                        // rules={[{ required: true, message: 'Please enter something!' }]}
                        >
                            <Input />
                        </Form.Item>
                        <Form.Item
                            label="Remind before"
                        // name="selectBox"
                        // rules={[{ required: true, message: 'Please select something!' }]}
                        >
                            <Select>
                                <Option value="option1">Option 1</Option>
                                <Option value="option2">Option 2</Option>
                                <Option value="option3">Option 3</Option>
                            </Select>
                        </Form.Item>
                    </Form>
                </Modal>
            </div>
            {/* add request Dawer */}

            <AddRequestDrawer documentBlobReq={documentBlobReq} onClose={() => setAddRequestDrawer(false)} setAddRequestDrawer={setAddRequestDrawer} addRequestDrawer={addRequestDrawer} tenderRequestDetail={tenderRequestDetail} employeeListVal={employeeListVal} />
        </>
    )
}


export default TenderRequest;