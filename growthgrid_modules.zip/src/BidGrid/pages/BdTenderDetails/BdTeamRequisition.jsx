// @ts-nocheck
import React, { useEffect, useState, useMemo } from 'react'
import { PlusOutlined, EditOutlined } from '@ant-design/icons';
import ExportDatatable from 'BidGrid/components/dataTable/ExportDatatable';
import { Menu, Select, Table, Input, Dropdown, Modal, Upload, Drawer, Form, Row, Col, Flex, Button, Card } from 'antd';
import { Down, More, Write, Download, Send } from '@icon-park/react';
import { toast } from 'react-toastify';
import skipBack from '../../assets/images/skip-back.png'
import { TeamReqApi } from 'Services/bidgrid/tenderList/TeamReqApi';
import { useNavigate, useParams } from 'react-router-dom';
import ROUTES from 'Constants/Routes';
import TeamRequisitionDrawer from 'BidGrid/components/Drawer/TeamRequisitionDrawer';
import TeamRequisitioModal from 'BidGrid/components/Models/TeamRequisitioModal';
import Delete from 'BidGrid/components/modalDelete/Delete';
import dayjs from 'dayjs';

const { Search } = Input;
const { Option } = Select;

const dataSource = [
  {
    key: '1',
    name: 'Mike',
    age: 32,
    address: '10 Downing Street',
  },
  {
    key: '2',
    name: 'John',
    age: 42,
    address: '10 Downing Street',
  },
];

const initialState = {
  category_id: null,
  designation_id: [],
  age_limit: null,
  man_months: null,
  construction_months: null,
  development_months: null,
  om_months: null,
}

const BdTeamRequisition = ({ activeTabKey }) => {
  const [teamRequisitionOpen, setTeamRequisitionOpen] = useState(false);
  const [openDrawer, setOpenDrawer] = useState(false);
  const [form] = Form.useForm();
  const [drawerData, setDrawerData] = useState(initialState)
  // add Category
  const [categories, setCategories] = useState([])
  // add designations
  const [reqDataList, setReqDataList] = useState([])
  const [flattenedProjects, setFlattenedProjects] = useState([]);
  const [record, setRecord] = useState({})
  const [modalData, setModalData] = useState({})

  const getAllKeys = (data) => {
    // console.log(data)

    if (data?.length > 0) {
      let keys = [];
      data.forEach((item) => {
        keys.push(item?.hasOwnProperty('key') ? item?.key : item.id);
        if (item.children && item.children.length > 0) {
          keys = keys.concat(getAllKeys(item.children));
        }
      });
      console.log(keys)
      return keys;
    } else {
      return
    }

  };

  const { id } = useParams()
  const notify = (error) => toast.error(error);
  const notifySuccess = (msg) => toast.success(msg);
  const [sortedInfo, setSortedInfo] = useState({});
  const [pageSize, setPageSize] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);
  const [deleteModal, setDeleteModal] = useState(false)


  // upload resume

  const [reqList, setReqList] = useState([])
  const [viewResume, setViewResume] = useState(false)
  const [resumeData, setResumeData] = useState({})
  const [resumeVal, setResumeVal] = useState([])

  const [filterResume, setFilterResume] = useState([])
  const deleteTeam = (items) => {
    setModalData(items)
    setRecord(items)
    setDeleteModal(true)
  }

  const columns = [
    {
      title: 'Sr. No',
      dataIndex: 'srNo',
      key: 'srNo',
      sorter: (a, b) => a.key - b.key,
      sortOrder: sortedInfo.columnKey === 'srNo' && sortedInfo.order,
      width: 120,
    },
    {
      title: 'Category',
      dataIndex: 'category_name',
      key: 'category_name',
    },
    {
      title: 'Designation',
      dataIndex: 'designation_name',
      key: 'designation_name',
    },
    {
      title: 'Age Limit',
      dataIndex: 'age_limit',
      key: 'age_limit',
    },
    {
      title: 'Man Months',
      dataIndex: 'man_months',
      key: 'man_months',
    },
    {
      title: 'Construction Months',
      dataIndex: 'construction_months',
      key: 'construction_months',
    },
    {
      title: 'Development Months',
      dataIndex: 'development_months',
      key: 'development_months',
    },
    {
      title: 'O&M Months',
      dataIndex: 'om_months',
      key: 'om_months',
    },
    {
      title: 'Weightage Marks',
      dataIndex: 'weightage_marks',
      key: 'weightage_marks',
    },
    {
      title: 'Remarks',
      dataIndex: 'remarks',
      key: 'remarks',
    },
    // {
    //   title: 'Total Resume',
    //   dataIndex: 'bg_tm_rq_negotiation_teams',
    //   key: 'bg_tm_rq_negotiation_teams',
    // },
    {
      title: 'View Team',
      key: 'view Team',
      render: (record) => {
        console.log(record)
        return (
          <>
            {
              !record?.hasOwnProperty('srNo') ?
                <a onClick={() => { setViewResume(true); setResumeData(record) }}>{record?.bg_tm_rq_negotiation_teams?.length > 0 && 'View Team (' + record?.bg_tm_rq_negotiation_teams?.length + ')'}</a>
                :
                <></>
            }
          </>
        )
      },
      width: 120
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (record) => {
        return (
          <>
            {
              !record?.hasOwnProperty('srNo') ?
                <Dropdown
                  placement='bottomRight'
                  overlay={
                    <Menu className="bd_tableAction">
                      <Menu.Item key="upload" className="bd_view_btn" onClick={() => { setTeamRequisitionOpen(true); setModalData(record) }}>
                        <svg width="18" height="18" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M24 43.9998H10C8.89543 43.9998 8 43.1043 8 41.9998V5.99976C8 4.89519 8.89543 3.99976 10 3.99976H38C39.1046 3.99976 40 4.89519 40 5.99976V23.9998" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" stroke-linejoin="round" /><path d="M35.5 43.9998V30.9998" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" stroke-linejoin="round" /><path d="M31 34.4998L32.5 32.9998L35.5 29.9998L38.5 32.9998L40 34.4998" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" stroke-linejoin="round" /><path d="M16 15.9998H32" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" /><path d="M16 23.9998H24" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" /></svg>
                        Upload Team
                      </Menu.Item>

                      <Menu.Item key="edit" className="bd_view_btn" onClick={() => { setRecord(record); setOpenDrawer(true) }}>
                        <svg width="18" height="18" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M24 43.9998H10C8.89543 43.9998 8 43.1043 8 41.9998V5.99976C8 4.89519 8.89543 3.99976 10 3.99976H38C39.1046 3.99976 40 4.89519 40 5.99976V23.9998" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" stroke-linejoin="round" /><path d="M35.5 43.9998V30.9998" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" stroke-linejoin="round" /><path d="M31 34.4998L32.5 32.9998L35.5 29.9998L38.5 32.9998L40 34.4998" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" stroke-linejoin="round" /><path d="M16 15.9998H32" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" /><path d="M16 23.9998H24" stroke="#4d4d4d" stroke-width="2" stroke-linecap="butt" /></svg>
                        Edit
                      </Menu.Item>
                      <Menu.Item key="delete" className='bd_delete_btn' onClick={() => deleteTeam(record)}>
                        <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M2.25 4.5H3.75H15.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                          <path d="M14.25 4.5V15C14.25 15.3978 14.092 15.7794 13.8107 16.0607C13.5294 16.342 13.1478 16.5 12.75 16.5H5.25C4.85218 16.5 4.47064 16.342 4.18934 16.0607C3.90804 15.7794 3.75 15.3978 3.75 15V4.5M6 4.5V3C6 2.60218 6.15804 2.22064 6.43934 1.93934C6.72064 1.65804 7.10218 1.5 7.5 1.5H10.5C10.8978 1.5 11.2794 1.65804 11.5607 1.93934C11.842 2.22064 12 2.60218 12 3V4.5" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                          <path d="M7.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                          <path d="M10.5 8.25V12.75" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                        Delete
                      </Menu.Item>

                    </Menu>

                  }
                >
                  <a onClick={(e) => e.preventDefault()}>
                    <More theme="outline" size="25" fill="#95a6b6" strokeWidth={3} />
                  </a>
                </Dropdown >

                :
                <></>
            }

          </>
        )
      },
      width: 120,
    },
  ];


  // Add drawer
  const showDrawer = () => {
    setOpenDrawer(true);
  };
  const onClose = () => {
    setOpenDrawer(false);
    form.resetFields()
    setDrawerData(initialState)
  };

  const sendEmail = async () => {
    const formData = new URLSearchParams()
    formData.append('project_id', id)
    try {
      const response = await TeamReqApi.sendEmail(formData)
      if (response?.data?.status == 1) {
        notifySuccess('Mail sent successfully')
      } else {
        notify('Try Later')
      }
    } catch (error) {
      notify(error)
    }
  }

  const fetchCategory = async () => {

    try {
      const response = await TeamReqApi.getDesignationCategoryList()
      if (response?.data?.status == '1') {
        setCategories(response?.data?.data)
      } else {
        setCategories([])
      }
    } catch (error) {
      console.log(error)
      setCategories([])
    }
  }

  const findCategoryName = (item) => {
    const resp = categories?.find((val) => val.id == item)
    return resp?.category_name
  }



  // team negotiation list
  const getTeamreqList = async () => {
    try {
      const formData = new URLSearchParams()
      formData.append('project_id', id)
      const response = await TeamReqApi.teamRqNegociationList(formData)
      if (response?.data?.status === '1') {

        const newDataVal = response?.data?.data;
        const groupedData = newDataVal?.reduce((acc, obj) => {
          const { category_id } = obj;
          if (!acc[category_id]) {
            acc[category_id] = [];
          }
          acc[category_id].push(obj);
          return acc;
        }, {});


        // generate id
        let uniqueIdCounter = 1;
        const generateUniqueId = () => uniqueIdCounter++;


        // Convert grouped data into array format
        const result = Object.entries(groupedData).map(([categoryId, children]) => ({
          key: generateUniqueId(),
          category_id: Number(categoryId),
          children,
        }));

        setReqDataList(result)
        // getReqList(response?.data?.data);
      } else {
        setReqDataList([])
        setFlattenedProjects([])
      }
    } catch (error) {
      setReqDataList([])
      setFlattenedProjects([])
      console.log(error)
    }
  }

  // team req list
  const getReqList = async (negoReqData) => {
    try {
      const response = await TeamReqApi.teamRqList()
      if (response?.data?.success === true) {
        setReqList(response?.data?.data)
        const dataVal = response?.data?.data

        const matchingReqData = [];
        let mergedReqData;
        negoReqData?.map(reqData => {
          const matchingReq = dataVal?.find(req => req?.tm_rq_members_id === reqData?.id);
          if (matchingReq) {
            mergedReqData = { ...reqData, ...matchingReq, team_id: matchingReq?.id, id: reqData?.id };
            matchingReqData.push(mergedReqData);
          } else {
            matchingReqData.push({ ...reqData, team_id: null, id: reqData?.id });
          }
        });
      }
      else {
        // setReqList([])
      }
    } catch (error) {
      setReqList([])
      // setFlattenedProjects([])
      console.log(error)
    }
  }

  // delete Team 
  const handleDelete = async (teamId) => {
    const formData = new URLSearchParams();
    formData.append('project_id', id);
    formData.append('tm_rq_negotiation_members_id', teamId);

    try {
      const response = await TeamReqApi.teamRqNegociationDelete(formData);
      if (response?.data?.status == 1) {
        // setSpinner(true)
        notifySuccess("Team Requisition Deleted Successfully");
        await getTeamreqList()
      } else {
        notify(response?.response?.data?.message);
        // setSpinner(false)
      }
    } catch (error) {
      console.log(error, "Api");
      // setSpinner(false)
    }
  }


  useEffect(() => {

    const flattenedData = reqDataList?.map((project, index) => ({
      ...project,
      srNo: pageSize * (currentPage - 1) + index + 1,
      key: pageSize * (currentPage - 1) + index + 1,
      id: project?.children?.map(item => item?.id)[0],
      // project_id: project?.project_id,
      category_id: project?.category_id,
      category_name: findCategoryName(project?.category_id),
      team_id: null,
      upload_designation_id: project?.children?.map(item => item?.designation_id)[0],
      upload_category_id: project?.category_id,
      children: project?.children?.map(item => ({ ...item, key: item.id, designation_name: item?.designation?.designation_name, team_id: null }))
    }));
    setFlattenedProjects(flattenedData);

  }, [categories, reqDataList]);

  console.log(flattenedProjects)

  const employeeTableData = useMemo(() => {
    return flattenedProjects;
  }, [flattenedProjects]);

  useEffect(() => {
    if (activeTabKey === '9') {
      fetchCategory()
      getTeamreqList()
      // getReqList()
    }

  }, [activeTabKey])


  // view resume
  const fetchRqListByDesg = async () => {
    try {
      const formData = new URLSearchParams()
      formData.append('project_id', id)
      formData.append('designation_id', resumeData?.designation_id)

      const response = await TeamReqApi.teamRqListByDes(formData)
      if (response?.data?.success === true) {
        setResumeVal(response?.data?.data)
      } else {
        setResumeVal([])

      }
    } catch (error) {
      setResumeVal([])
      console.log(error)
    }
  }


  useEffect(() => {
    const reqListData = resumeVal?.map((project, index) => ({
      srNo: pageSize * (currentPage - 1) + index + 1,
      team_id: project?.id,
      project_id: project?.project_id,
      category_id: project?.category_id,
      category_name: findCategoryName(project?.category_id),
      designation_name: project?.designation?.designation_name,
      designation_id: project?.designation_id,
      can_resume: project?.can_resume,
      file_path: project?.file_path,
      fullname: project?.fullname,
      remarks: project?.remarks,
      working_exp: project?.working_exp,
      tm_rq_members_id: project?.tm_rq_members_id,
      curr_status: project?.curr_status,
    }));


    setFilterResume(reqListData);
  }, [resumeVal]);

  useEffect(() => {
    if (viewResume) {
      fetchRqListByDesg()
    }
  }, [viewResume])

  const handlePageSizeChange = (value) => {
    setPageSize(value);
    setCurrentPage(1);
  };

  const defaultExpandedKeys = flattenedProjects.reduce((keys, item) => {
    keys.push(item.key); // Push parent key
    // Push children keys
    if (item.children && item.children.length > 0) {
      keys = keys.concat(item.children.map(child => child.key));
    }
    return keys;
  }, []);

  console.log("Default Expanded Keys:", defaultExpandedKeys);
  return (
    <>
      <div className="teamRequisition_wrapper">
        <div className="table_wrap">
          <div className="tableHead_wrap">
            <Search
              placeholder="Search"
              allowClear
              style={{ width: 340 }}
            />
            <div className="showPrPage">
              <ExportDatatable
                dataSource={dataSource}
              // columnLabels={columnLabels}
              />
              <span>Showing</span>
              <Select
                suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                defaultValue={pageSize}
                style={{ width: 70 }}
                onChange={handlePageSizeChange}
              >
                <Option value={10}>10</Option>
                <Option value={20}>20</Option>
                <Option value={30}>30</Option>
                <Option value={40}>40</Option>
              </Select>
              <span>of {employeeTableData?.length} results</span>
              <button className='BG_mainButton' onClick={showDrawer}><PlusOutlined style={{ color: "white" }} /> Add Team Requisition</button>
              {employeeTableData?.length > 0 && <button className='BG_ghostButton' onClick={sendEmail}><Send theme="outline" size="18" fill="#818181" />Send Email</button>}

            </div>
          </div>

          <div className="tableBody_wrap">
            <Table
              bordered
              columns={columns}
              dataSource={employeeTableData}
              className='no-grid-data'
              pagination={{
                pageSize: pageSize,
              }}
              scroll={{ x: 'max-content' }}
              // defaultExpandedRowKeys={flattenedProjects.map((item) => item.key)}
              expandable={{
                defaultExpandedRowKeys: defaultExpandedKeys
              }}
              onChange={(pagination, filters, sorter) => setSortedInfo(sorter)}
            />
          </div>
        </div>
      </div>

      <TeamRequisitioModal
        teamRequisitionOpen={teamRequisitionOpen}
        setTeamRequisitionOpen={setTeamRequisitionOpen}
        record={modalData}
        categories={categories}
        getTeamreqList={getTeamreqList}
        setRecord={setModalData}
        getReqList={getReqList}
        fetchRqListByDesg={fetchRqListByDesg}
        setViewResume={setViewResume}
      />

      {/* Add Drawer */}
      <TeamRequisitionDrawer
        onClose={onClose}
        getTeamreqList={getTeamreqList}
        openDrawer={openDrawer}
        categories={categories}
        record={record}
        setRecord={setRecord}
      />
      <Delete title={'Team requisition'} open={deleteModal} handleDelete={handleDelete} onClose={() => setDeleteModal(false)} modalData={record} />

      <Modal title="View Team" className="bd_model_main shareModal"
        open={viewResume}
        onCancel={() => { setViewResume(false) }}
        footer={null}
      >
        <div>

          {
            filterResume?.length > 0 ?

              filterResume?.map((item, index) => {
                return (
                  <>
                    <Card className="resume_wrap" style={{ marginBottom: '20px' }}>
                      <div className="resume_head">
                        {item?.curr_status === 1 ?
                          <div className="status_approved">Approved</div> :
                          <div className="status_pending">Pending</div>
                        }
                        <div className="edit_btn"><a onClick={() => { setTeamRequisitionOpen(true); setModalData(item); setViewResume(false) }}><Write theme="outline" size="18" fill="#9b9b9b" strokeWidth={3} strokeLinecap="butt" /></a></div>
                      </div>
                      <div className="name_text">{item?.fullname}</div>
                      <div className="d-flex">
                        <div className="rw_item">
                          <div className="label_text">Category:</div>
                          <span>{findCategoryName(item?.category_id)}</span>
                        </div>
                        <div className="rw_item">
                          <div className="label_text">Designation:</div>
                          <span>{item?.designation_name}</span>
                        </div>
                      </div>
                      <div className="rw_item">
                        <div className="label_text">Remarks:</div>
                        <span>{item?.remarks}</span>
                      </div>

                      {/* {item?.can_resume} */}
                      <div className="resumeDownload">
                        <a href="#">Download Resume
                          <div className="icon">
                            <Download theme="outline" size="16" fill="#c43d4b" strokeWidth={3} strokeLinecap="butt" />
                          </div>
                        </a>
                      </div>
                    </Card>
                  </>
                )
              })


              :
              <p>Data Not Found</p>
          }

        </div>

      </Modal >

    </>
  )
}

export default BdTeamRequisition