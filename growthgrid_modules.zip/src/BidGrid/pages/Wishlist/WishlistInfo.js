// @ts-nocheck
import ROUTES from 'Constants/Routes';
import { Checkbox, Select } from 'antd';
import { capitalizeExceptPrepositionsAndLowerCase } from 'common/components/CapitalLetter/CapitalLetterWithoutPrepositions';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import dayjs from "dayjs";
import EventBusyIcon from '@mui/icons-material/EventBusy';
import Loaction from '../../assets/images/icons/location.png';
import { TimeConverter } from 'BidGrid/components/TimeConverter/TimeConverter';


const WishlistInfo = (props) => {

    const { getListForWishlist, CollectionList, searchText } = props;

    const tenderNames = (str) => {
        const htmlTagPattern = /<[^>]*>/g;
        const htmlTags = str?.match(htmlTagPattern);

        if (htmlTags) {
            const stringWithoutHtmlTags = str.replace(htmlTagPattern, '');
            const capitalizedString = capitalizeExceptPrepositionsAndLowerCase(stringWithoutHtmlTags);
            return <span>{capitalizedString}</span>;
        } else {
            return <span>{capitalizeExceptPrepositionsAndLowerCase(str)}</span>;
        }
    }

    const showList = () => {
        return getListForWishlist?.filter(val =>
            val?.tender_details?.tender_name?.toLowerCase().includes(searchText?.toLowerCase())
        )?.map((item, index) => {
            return (
                <div className='bd_tenderCard card'>
                    <div className='bd_tenderCard_first'>
                        <div className="bd_cards_tender">
                            <div className='bd_cards_active'>
                                <h6> {item?.tender_details?.bg_mstr_client?.client_name}</h6>

                                {/* <div className='bd_active_btn_sec'>
                           
                        </div> */}
                            </div>
                            <div className='bd_tender_card_location'>
                                <img src={Loaction} width={13} alt='' />
                                <span>
                                    {capitalizeExceptPrepositionsAndLowerCase(item?.tender_details?.bg_mstr_city?.city_name)}
                                    {item?.tender_details?.bg_mstr_city !== null && ","}
                                    {capitalizeExceptPrepositionsAndLowerCase(item?.tender_details?.bg_mstr_state?.state_name)}
                                    {item?.tender_details?.bg_mstr_state !== null && ","}
                                    {capitalizeExceptPrepositionsAndLowerCase(item?.tender_details?.bg_mstr_country?.country_name)}
                                </span>
                            </div>
                        </div>
                        <div className='bd_tender_card_chips'>
                            <div className='bd_tender_chips'>
                                <span>
                                    {capitalizeExceptPrepositionsAndLowerCase(item?.tender_details?.bg_mstr_sector?.sector_name)}
                                </span>
                            </div>
                        </div>
                        <div className='bd_tender_card_detail'>
                            <Link className='tender_name' to={ROUTES.BD_TENDERDETAILS.replace(':id', item?.tender_details?.id)}>
                                {tenderNames(item?.tender_details?.tender_name)}
                            </Link>
                        </div>
                        <div className='bd_tender_card_expire'>
                            <EventBusyIcon />
                            <p>Expires on</p>
                            <span>
                                {
                                    item?.tender_details?.submission_end_date !== null ?
                                        `${dayjs(item?.tender_details?.submission_end_date).subtract(dayjs(item?.tender_details?.submission_end_date).utcOffset(), 'minute').format("DD MMM YYYY")} ${TimeConverter(item?.tender_details?.submission_end_date)}` : '-'
                                }
                            </span>
                        </div>


                    </div>
                </div>
            )
        })
    }

    return (
        <>
            {showList()}
        </>
    )
}


export default WishlistInfo;