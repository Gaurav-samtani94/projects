// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Col, Row, Select, Input, Form, Pagination } from 'antd';
import { Down, Label } from '@icon-park/react';
import WishlistInfo from './WishlistInfo';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import TenderInfo from 'BidGrid/components/TendercardComponents/TenderInfo';
import ExportDatatable from 'BidGrid/components/dataTable/ExportDatatable';
import EmptyBox from '../../../assests/img/empty-box.png';

const { Option } = Select;
const { Search } = Input;


const columnLabels = {
    // gg_tenderID: { name: 'GG Tender ID', required: true, width: 400 },
    tender_name: { name: 'Tender Name', required: true, width: 400 },
    tender_emd_amnt_val: { name: 'Tender amount value', required: true, width: 400 },
    submission_start_date: { name: 'Start Date', required: true, width: 400 },
    submission_end_date: { name: 'End Date', required: true, width: 400 },
}


// const initialState = {
//     collection_id: '',
//     status_id: ''
// }

const WishlistCard = (props) => {
    const { getListForWishlist, CollectionList, fetchWishList, activeKey, selectChange, setSelectChange, defaultVal } = props;
    const [current, setCurrent] = useState(1);
    const [limit, setLimit] = useState(5)
    const [searchText, setSearchText] = useState('');
    // const [selectChange, setSelectChange] = useState(initialState);
    // const defaultVal = "Select"

    const totalResults = 90

    // tender status
    const [scopeList, setScopeList] = useState([]);

    let wishListData = getListForWishlist?.filter((item) => item?.tender_details != null)?.map((itm) => itm?.tender_details);
    if (searchText?.length > 0) {
        wishListData = wishListData?.filter(val =>
            val?.tender_details?.tender_name?.toLowerCase().includes(searchText?.toLowerCase())
        ).map
    }

    const startIndex = (current - 1) * limit;
    const endIndex = startIndex + limit;
    const currentPageData = getListForWishlist?.slice(startIndex, endIndex);

    const handleChange = (name, value) => {
        setSelectChange((old) => ({
            ...old,
            [name]: value
        }))
        fetchWishList(activeKey, value, selectChange?.status_id)
    };

    const resetWishlist = () => {
        if (selectChange?.collection_id != "" || selectChange?.status_id != "") {
            fetchWishList()
            setSelectChange({
                collection_id: '',
                status_id: ''
            })
        }
    }

    const handleScopeChange = (name, value) => {
        setSelectChange((old) => ({
            ...old,
            [name]: value
        }))
        fetchWishList(activeKey, selectChange?.collection_id, value)
    }

    const handlePageChange = (value) => {
        setCurrent(value)
    }

    const handlePageSizeChange = (value) => {
        setLimit(value)
    }

    const selectOptions = {
        pdf: 'PDF',
        csv: 'CSV',
        print: 'Print',
    };

    // Tender Status

    const getAllScope = async () => {
        try {
            let result = await TenderApi.getScopList();
            if (result?.data?.status === '1') {
                setScopeList(result?.data?.data);
            }
            else {
                setScopeList([])
            }
        } catch (error) {

        }
    };



    useEffect(() => {
        getAllScope()
    }, [])

    return (
        <>
            <div className='bd_wishlist_top_card'>
                <div className='row'>
                    <div className='col-12'>
                        <div className="table_wrap">
                            <div className="tableHead_wrap">
                                <div className='bd_wishlist_search_dropdown'>
                                    <Search
                                        placeholder="Search"
                                        allowClear
                                        onChange={(e) => setSearchText(e?.target?.value)}
                                        style={{ width: 340 }}
                                        value={searchText}
                                    />

                                    <div className='bd_wishlist_collection'>
                                        <Row gutter={16}>
                                            <Col sm={12}>
                                                <Form.Item label="">
                                                    <Select
                                                        showSearch
                                                        optionFilterProp="children"
                                                        placeholder="Select Collection"
                                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                        options={CollectionList?.map((item) => {
                                                            return {
                                                                value: item?.id,
                                                                label: item?.collection_name
                                                            }
                                                        })}
                                                        filterOption={(input, option) =>
                                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                        }
                                                        // name='collection_id'
                                                        // defaultValue="My Collection"
                                                        // style={{
                                                        //     width: 155,
                                                        // }}8
                                                        value={parseInt(selectChange?.collection_id) || `${defaultVal} Collection`}
                                                        onChange={(value) => handleChange("collection_id", value)}
                                                        style={{ width: "180px" }}
                                                    />
                                                </Form.Item>
                                            </Col>
                                            <Col sm={12}>
                                                <Form.Item label="">
                                                    <Select
                                                        showSearch
                                                        optionFilterProp="children"
                                                        placeholder="Select Status"
                                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                                        options={scopeList?.filter((item) => item?.id !== 0)?.map((curElem) => {
                                                            return {
                                                                value: curElem?.id,
                                                                label: curElem?.scope_name
                                                            }
                                                        })
                                                        }
                                                        filterOption={(input, option) =>
                                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                                        }
                                                        // name='status_id'
                                                        // defaultValue="Tender Status"
                                                        // style={{
                                                        //     width: 165,
                                                        // }}
                                                        style={{ width: "180px" }}
                                                        value={(selectChange?.status_id) || `${defaultVal} Status`}
                                                        onChange={(value) => handleScopeChange("status_id", value)}

                                                    />
                                                </Form.Item>
                                            </Col>
                                        </Row>
                                    </div>
                                    <div className="bd_drawerFoot">
                                        <button className='BG_ghostButton' onClick={resetWishlist}>Reset</button>
                                    </div>
                                </div>

                                <div className="showPrPage">
                                    <Form.Item className="export">
                                        <ExportDatatable
                                            dataSource={wishListData}
                                            columnLabels={columnLabels}
                                        />
                                    </Form.Item>
                                    {/* <span>Showing</span>
                                    <Select
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        defaultValue={pageSize}
                                        style={{ width: 70 }}
                                        onChange={handlePageSizeChange}
                                    >
                                        <Option value={10}>10</Option>
                                        <Option value={20}>20</Option>
                                        <Option value={30}>30</Option>
                                        <Option value={40}>40</Option>
                                    </Select> */}





                                </div>
                            </div>
                            <h2>
                                <WishlistInfo getListForWishlist={currentPageData} CollectionList={CollectionList} searchText={searchText} />
                            </h2>
                            {wishListData?.length > 0 ? <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 20, marginInline: 30 }}>
                                <Pagination
                                    current={current}
                                    pageSize={limit}
                                    total={wishListData?.length}
                                    onChange={handlePageChange}
                                />
                                <div >
                                    <span>Showing</span>
                                    <Select
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        defaultValue={limit}
                                        style={{ width: 70 }}
                                        onChange={handlePageSizeChange}
                                    >
                                        <Option value={5}>5</Option>
                                        <Option value={10}>10</Option>
                                        <Option value={20}>20</Option>
                                        <Option value={30}>30</Option>
                                        <Option value={40}>40</Option>
                                    </Select>
                                </div>


                            </div>
                                :
                                <>
                                    <div className="spinerWrap">
                                        <div className="data_foundDiv">
                                            <img src={EmptyBox} width={100} />
                                            <div style={{ textAlign: "center", fontSize: 16 }}>No Record Found</div>
                                        </div>
                                    </div>
                                </>
                            }

                        </div>
                    </div>
                </div>
            </div >
        </>
    )
}

export default WishlistCard;


