// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Tabs, Switch } from 'antd';
import TabPane from 'antd/es/tabs/TabPane';
import { SettingOutlined } from '@ant-design/icons';
import SettingManageModel from 'BidGrid/components/Models/SettingManageModel';
import { settingApi } from 'Services/bidgrid/masterSetting/settingApi';
// const permissionsData = [
//     {
//         id: 1,
//         permission_name: 'Candidate',
//         add: 0,
//         edit: 1,
//         delete: 0,
//         view: 1
//     },
//     {

//         id: 2,
//         permission_name: 'Master',
//         category: [{
//             id: 1,
//             category_name: 'Role',
//             category_add: 0,
//             category_edit: 1,
//             category_delete: 0,
//             category_view: 2
//         }]
//     },
//     {
//         id: 3,
//         permission_name: 'Admin',
//         category: [{
//             id: 1,
//             category_name: 'Role1',
//             category_add: 0,
//             category_edit: 1,
//             category_delete: 0,
//             category_view: 1
//         },
//         {
//             id: 2,
//             category_name: 'Role2',
//             category_add: 0,
//             category_edit: 1,
//             category_delete: 0,
//             category_view: 1
//         }],


//     }
// ]

const RolesPermission = ({ roleList, getbidRoleTender, getFirstId }) => {
    const [AddManageSetting, setAddManageSetting] = useState(false);
    const [moduleListData, setModuleListData] = useState([])
    const [allModuleListData, setAllModuleListData] = useState([])
    const [getRoleId, setGetRoleId] = useState(getFirstId)

    const handleSettingManage = () => {
        setAddManageSetting(true);
    }

    const templateManageClose = () => {
        setAddManageSetting(false);
    };

    const handleChange = async (id, name, checked) => {
        // console.log(name, checked)
        const newValue = checked ? '1' : '2'
        await updateRoleData(id, name, newValue)
        setAllModuleListData((prevData) => {
            return prevData?.map((prevList) => {

                if (prevList.id === id) {
                    return {
                        ...prevList,
                        action_perm_role: {
                            ...prevList.action_perm_role,
                            [name]: newValue
                        },
                    };
                }
                return prevList;
            });
        });


    }

    const updateRoleData = async (id, name, newValue) => {
        const obj = allModuleListData?.find(item => item?.id === id)
        const formData = new URLSearchParams();
        formData.append('role_id', getRoleId)
        formData.append('view_perm', name === 'view_perm' ? newValue : obj?.action_perm_role.view_perm)
        formData.append('add_perm', name === 'add_perm' ? newValue : obj?.action_perm_role.add_perm)
        formData.append('edit_perm', name === 'edit_perm' ? newValue : obj?.action_perm_role.edit_perm)
        formData.append('delete_perm', name === 'delete_perm' ? newValue : obj?.action_perm_role.delete_perm)
        formData.append('module_id', id)

        try {
            const response = await settingApi.updateModuleList(formData)
            // if (response?.data?.status === '1') {
            //     console.log(response?.data?.data)
            // }
            // else {
            //     console.log(response?.response?.data?.data)
            // }
        } catch (error) {
            console.log(error)
        }
    }



    useEffect(() => {
        if (moduleListData?.length > 0) {

            setAllModuleListData((prevData) => {
                return prevData?.map((prevList) => {
                    // debugger;
                    let extractObj = moduleListData?.find((item) => item.id === prevList.id)
                    if (prevList.parent_id !== 0) {
                        return {
                            ...prevList,
                            action_perm_role: {
                                ...prevList.action_perm_role,
                                add_perm: extractObj?.action_perm_role?.add_perm ? extractObj?.action_perm_role?.add_perm : '2',
                                delete_perm: extractObj?.action_perm_role?.delete_perm ? extractObj?.action_perm_role?.delete_perm : '2',
                                edit_perm: extractObj?.action_perm_role?.edit_perm ? extractObj?.action_perm_role?.edit_perm : '2',
                                view_perm: extractObj?.action_perm_role?.view_perm ? extractObj?.action_perm_role?.view_perm : '2s'
                            },
                        };
                    } else if (extractObj.action_perm_role === null) {
                        return {
                            ...prevList,
                            action_perm_role: {
                                ...prevList.action_perm_role,
                                add_perm: '0',
                                delete_perm: '0',
                                edit_perm: '0',
                                view_perm: '0',
                            },
                        };
                    }
                    return prevList;
                });
            });
        }
    }, [moduleListData])

    const handleRoleTab = (id) => {
        setGetRoleId(id)
    }
    //all module list
    const getModuleList = async () => {
        try {
            const response = await settingApi.allModuleList()
            if (response?.data?.status === '1') {
                let allModulesList = response?.data?.data?.map((item) =>
                ({
                    id: item.id,
                    modules_name: item.modules_name,
                    parent_id: item.parent_id,
                    action_perm_role: {
                        add_perm: '2',
                        delete_perm: '2',
                        edit_perm: '2',
                        view_perm: '2'
                    }
                }))
                setAllModuleListData(allModulesList)
            }
            else {
                setAllModuleListData([])
            }
        } catch (error) {
            console.log(error)
        }
    };

    // module list
    const getAllModuleList = async () => {
        const formData = new URLSearchParams();
        formData.append('role_id', getRoleId)
        try {
            const response = await settingApi.moduleList(formData)
            if (response?.data?.status === '1') {
                setModuleListData(response?.data?.data)
            }
            else {
                setModuleListData([])
            }
        } catch (error) {
            console.log(error)
        }
    };

    useEffect(() => {

        getModuleList()
        getAllModuleList()
    }, [])

    useEffect(() => {
        getAllModuleList()
    }, [getRoleId])

    console.log(allModuleListData)

    return (
        <>
            <div className='manage_btn'>
                <button className='BG_mainButton' onClick={handleSettingManage} ><SettingOutlined />Manage Role</button>
            </div>
            <div className="tenderCycle_main">
                <Tabs
                    tabPosition="left"
                    className="custom-tabs-container"
                >
                    {
                        roleList?.map((item, index) => {
                            return (
                                <>
                                    <TabPane
                                        tab={
                                            <div className='tab-item' key={item?.id} defaultActiveKey="1" onClick={() => handleRoleTab(item?.id)}>
                                                <span>{item?.role_name}</span>
                                            </div>
                                        }
                                        key={index}>
                                        <div className="permissions_access_wrap">

                                            {
                                                allModuleListData.map((cur, index) => {
                                                    return (
                                                        <>

                                                            <div className="page_permission" key={index}>
                                                                <div className="title">{cur?.modules_name}</div>
                                                                <>
                                                                    <div className='switched_grp' key={index}>
                                                                        <div className='swtich'>
                                                                            <label>Add</label>
                                                                            <Switch name='add_perm' checked={cur?.action_perm_role?.add_perm === '1'} disabled={cur?.action_perm_role?.add_perm === '0'} onChange={(checked) => handleChange(cur?.id, "add_perm", checked)} />
                                                                        </div>
                                                                        <div className='swtich'>
                                                                            <label>View</label>
                                                                            <Switch name='view_perm' checked={cur?.action_perm_role?.view_perm === '1'} disabled={cur?.action_perm_role?.view_perm === '0'} onChange={(checked) => handleChange(cur?.id, "view_perm", checked)} />
                                                                        </div>
                                                                        <div className='swtich'>
                                                                            <label>Edit</label>
                                                                            <Switch name='edit_perm' checked={cur?.action_perm_role?.edit_perm === '1'} disabled={cur?.action_perm_role?.edit_perm === '0'} onChange={(checked) => handleChange(cur?.id, "edit_perm", checked)} />
                                                                        </div>

                                                                        <div className='swtich'>
                                                                            <label>Delete</label>
                                                                            <Switch name='delete_perm' checked={cur?.action_perm_role?.delete_perm === '1'} disabled={cur?.action_perm_role?.delete_perm === '0'} onChange={(checked) => handleChange(cur?.id, "delete_perm", checked)} />
                                                                        </div>
                                                                    </div>
                                                                </>
                                                            </div>
                                                        </>
                                                    )
                                                })
                                            }
                                            {/* <div className='switched_grp'>
                                                    <div className='swtich'>
                                                        <label>Add</label>
                                                        <Switch />
                                                       </div>
                                                       <div className='swtich'>
                                                        <label>View</label>
                                                        <Switch />
                                                       </div>
                                                       <div className='swtich'>
                                                           <label>Edit</label>
                                                        <Switch />
                                                    </div>

                                                       <div className='swtich'>
                                                           <label>Delete</label>
                                                        <Switch />
                                                    </div>
                                                </div> */}




                                        </div >
                                    </TabPane>
                                </>
                            )
                        })
                    }

                </Tabs>
            </div>

            <SettingManageModel templateManageClose={templateManageClose} AddManageSetting={AddManageSetting} roleList={roleList} getbidRoleTender={getbidRoleTender} />
        </>
    )

    function renderSwitch(label, value) {
        return value !== undefined && (
            <div className='swtich'>
                <label>{label}</label>
                <Switch checked={value === 1} onChange={(checked) => handleChange(label, checked)} />
            </div>
        );
    }
}

export default RolesPermission;


