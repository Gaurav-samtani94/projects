// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Tabs, Switch } from 'antd';
import TabPane from 'antd/es/tabs/TabPane';
import LableImg from '../../assets/images/icons/notification.png';
import { SettingOutlined } from '@ant-design/icons';
import SettingManageModel from 'BidGrid/components/Models/SettingManageModel';
// import { settingApi } from 'Services/bidgrid/masterSetting/settingApi';
import { TenderApi } from 'Services/bidgrid/tenderList/TenderApi';
import { useSelector } from 'react-redux';
import { filterCycleActions } from 'Redux/actions/bidgrid/cycleFilterAction';
import { useDispatch } from 'react-redux';


const TenderCycleAction = ({ roleList, getbidRoleTender, roleData, setRoleData }) => {
    const [AddManageSetting, setAddManageSetting] = useState(false);
    const [scopeList, setScopeList] = useState([]);
    const [inActionList, setInActionList] = useState([]);
    const { filterValues, isUpdate } = useSelector((state => state.cycleFilter));
    const [switched, setSwitched] = useState([]);

    const dispatch = useDispatch();

    const handleSettingManage = () => {
        setAddManageSetting(true);
    }

    const templateManageClose = () => {
        setAddManageSetting(false);
    };

   

    const handleChange = async (inActionId, index) => {
        const updatedInActionList = [...inActionList];
        updatedInActionList[index].inactionassignbtn = updatedInActionList[index].inactionassignbtn === "1" ? "0" : "1";
        setInActionList(updatedInActionList);
        const formData = new URLSearchParams();
        formData.append('inaction_id', inActionId);
        formData.append('cycle_id', filterValues.cycle_id);

        try {
            let result = await TenderApi.updateInActionButtons(formData);
        } catch (error) {
            console.log(error, 'Api Error');
        }
    }


    const filterInactionsByScopeId = async (id, index) => {
        const formData = new URLSearchParams();
        formData.append('cycle_id', id);
        try {
            const response = await TenderApi.getTenderCycleInactionList(formData);
            if (response?.data?.status == 1) {
                setInActionList(response?.data?.data)
                let body = { cycle_id: id }
                dispatch(filterCycleActions.filterUpdateIndividualKeys(body));
            }
            else {
                //   handleReset()
                //   notify(response?.response?.data?.message)
            }
        } catch (error) {
            console.log(error, 'Api Error')
        }
    }

    // Fetch the scope list
    const getAllScopes = async () => {
        try {
            let result = await TenderApi.getScopList();
            setScopeList(result?.data?.data)
            await filterInactionsByScopeId(result?.data?.data[0]?.id);

        } catch (error) {
            console.log('error in getAllScopes in NewTenderAssign sceen', error);
        }
    };

    // const showInActions = () => {
    //     return inActionList?.map((item,index) => {
    //         return <div className='swtich'>
    //             <div className='lable_switch'><img src={LableImg} width={15} /> <span>{item.inaction_name}</span></div>
    //             <Switch name="add" checked={switched[index] !== undefined ? switched[index] : (item.inactionassignbtn === '1')}
    //                 onChange={() => handleChange(item?.id,index)}
    //             />
    //         </div>
    //     })
    // }

    useEffect(() => {
        getAllScopes();
        // console.log(cycleId, "id")

    }, [])


    return (
        <>
            <div className="tenderCycle_main" style={{ paddingBottom: 70 }}>
                <div className="tenderCycle_left">
                    <Tabs
                        tabPosition="left"
                        className="custom-tabs-container"
                    >
                        {
                            scopeList?.map((item, index) => {
                                return (
                                    <TabPane
                                        tab={
                                            <div key={item?.id} onClick={() => filterInactionsByScopeId(item?.id, index)}>
                                                <span >{item?.scope_name}</span>
                                            </div>
                                        }
                                        key={index}
                                    >
                                        <div className="permissions_access_wrap">
                                            <div className="page_permission" style={{ marginTop: 15 }}>
                                                <div className='switched_grp_cycle'>
                                                    {inActionList?.map((item, index) => {
                                                        return (<div className='swtich'>
                                                            <div className='lable_switch'><img src={LableImg} width={15} /> <span>{item.inaction_name}</span></div>
                                                            <Switch name="add" checked={item?.inactionassignbtn === "1" ? true : false}
                                                                onChange={() => handleChange(item?.id, index)}
                                                            />
                                                        </div>)
                                                    })}
                                                </div>
                                            </div>

                                        </div>
                                    </TabPane>
                                )
                            })
                        }

                    </Tabs>
                </div>
            </div>
            <SettingManageModel templateManageClose={templateManageClose} AddManageSetting={AddManageSetting} roleList={roleList} getbidRoleTender={getbidRoleTender} />

        </>
    )
}


export default TenderCycleAction;


