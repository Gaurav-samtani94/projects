// @ts-nocheck
import React, { useEffect, useState } from 'react';
import { Space, Table, Tooltip } from 'antd';
import { CheckOutlined, CloseOutlined } from '@ant-design/icons';
import { settingApi } from 'Services/bidgrid/masterSetting/settingApi';

const ConfigurationLab = () => {
    const [configurList, setConfigurList] = useState([])
    const configurationList = async (id) => {
        try {
            const response = await settingApi?.getConfigurationList()
            if (response?.data?.status === '1') {
                setConfigurList(response?.data?.data)
            }
            else {
                // notify(response?.response?.data?.message)
            }
        } catch (error) {
            console.log(error)
        }
    };

    const columns = [
        {
            title: 'Roles And Permissions',
            dataIndex: 'rolesPermission',
            key: 'rolesPermission',
            render: (text) => <a>{text}</a>,
        },
        {
            title: 'Action',
            key: 'action',
            render: ((record) =>{
                return(
                    <>
                    <Space size="middle">
                    <Tooltip title="Checked Permission">
                        {
                            record.isDone === '1' ? <a style={{ color: 'green' }}><CheckOutlined /><span style={{ fontSize: '17px' }}>Done</span></a> : <a ><CheckOutlined /></a>
                        }
                    </Tooltip>
                    <Tooltip title="Delete Permission">
                        {
                            record.isDone == 0 ? <a style={{ color: 'red' }}><CloseOutlined /><span style={{fontSize:'17px'}}>inComplete</span></a> :<a><CloseOutlined /></a>
                        }
                    </Tooltip>
                </Space>
                    </>
                )
            })
                
            ,
        },
    ];

    const data = [
        ...configurList?.map((item,index) => {
            return (
                {
                    key: index,
                    rolesPermission: item?.configuration_master?.config_name,
                    isDone:item?.is_done

                }
            )
        })
    ];


    useEffect(() => {
        configurationList()
    }, []);

    return (
        <>
            <div className="tenderCycle_main" style={{ paddingBottom:70 }}>
                <div className="tenderCycle_left">
                    <Table columns={columns} dataSource={data} />
                </div>
            </div>

        </>
    )
}

export default ConfigurationLab;