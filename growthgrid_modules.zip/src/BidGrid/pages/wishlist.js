// @ts-nocheck

import React, { useEffect, useState } from "react";
import TenderDetailsCard from '../components/TendercardComponents/TenderDetailsCard';
import WishlistCard from "./Wishlist/WishlistTopCard";
import { Card, Input, Button, Tabs, Row, Col, Form } from "antd";
import Breadcrumb from "BidGrid/components/BidBreadCrumb/Breadcrumb";
import { useLocation } from 'react-router';
import { WishListApi } from "Services/bidgrid/wishlist/bidWishlist";
import { toast } from 'react-toastify';
import { tenderCycle } from "Services/bidgrid/tenderCycle/tenderCycle";
import TenderInfo from "BidGrid/components/TendercardComponents/TenderInfo";
import { Delete } from "@icon-park/react";
import DeleteModal from "../components/modalDelete/Delete"
// import TenderInfo from "BidGrid/components/TendercardComponents/TenderInfo";

const initialState = {
    collection_id: '',
    status_id: ''
}

const Wishlist = () => {
    const [form] = Form.useForm();
    const [paginatedDataList, setPaginatedDataList] = useState([])
    const [addCollection, setAddCollection] = useState('')
    const [collectionList, setCollectionList] = useState([])
    const [isBtnDisabled, setIsBtnDisabled] = useState(false);
    const [getListForWishlist, setListForWishlist] = useState([]);
    const [activeKey, setActiveKey] = useState([]);
    const [deleteModal, setDeleteModal] = useState(false)
    const [modalData, setModalData] = useState();
    const [selectChange, setSelectChange] = useState(initialState);
    const defaultVal = "Select"

    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);

    const handleTabChange = (e) => {
        setActiveKey(e - 1)
        fetchWishList(e - 1)
    }


    const fetchWishList = async (Id, val, scopeId) => {
        const formData = new URLSearchParams();
        try {
            { (Id != undefined && Id != 0) && formData.append('share_id', Id) }
            { (val != undefined) && formData.append('collection_id', val) }
            { (scopeId != undefined) && formData.append('tender_scope', scopeId) }
            let result = await tenderCycle.getWishList(formData);
            setListForWishlist(result?.data?.data);
        }
        catch (error) {
            console.log(error);
        }
    }

    const items = [
        {
            key: '1',
            label: 'All ( My + Shared )',
            children: (
                <div>
                    <WishlistCard getListForWishlist={getListForWishlist} CollectionList={collectionList} fetchWishList={fetchWishList} activeKey={activeKey} selectChange={selectChange} setSelectChange={setSelectChange} defaultVal={defaultVal} />
                    {/* <TenderDetailsCard setPaginatedDataList={setPaginatedDataList} /> */}
                </div>
            )
        },
        {
            key: '2',
            label: 'Public',
            children: (
                <div>
                    <WishlistCard getListForWishlist={getListForWishlist} CollectionList={collectionList} fetchWishList={fetchWishList} activeKey={activeKey} selectChange={selectChange} setSelectChange={setSelectChange} defaultVal={defaultVal} />
                </div>
            )
        },
        {
            key: '3',
            label: 'Private',
            children: (
                <div>
                    <WishlistCard getListForWishlist={getListForWishlist} CollectionList={collectionList} fetchWishList={fetchWishList} activeKey={activeKey} selectChange={selectChange} setSelectChange={setSelectChange} defaultVal={defaultVal} />
                </div>
            )
        },
        // {
        //     key: '4',
        //     label: 'Tender Grid',
        //     children: (
        //         <div>
        //             static data
        //         </div>
        //     )
        // },
    ];



    const handleInputChange = (e) => {
        setAddCollection(e?.target?.value)
    }

    const handleReset = () => {
        setAddCollection('')
        form.resetFields()
    }
    const showCollectionList = async () => {
        try {
            const response = await tenderCycle?.bdwishlistCollection()
            if (response?.data?.status == 1) {
                setCollectionList(response?.data?.data)
            } else {
                setCollectionList([])
            }
        } catch (error) {
            console.log('Api Error', error);
            notify('Error')
        }
    }

    useEffect(() => {
        showCollectionList();
        fetchWishList();
    }, [])


    const bdaddCollections = async () => {
        setIsBtnDisabled(true)
        if (addCollection) {
            try {
                const formdata = new URLSearchParams()
                formdata.append('collection_name', addCollection)
                const response = await tenderCycle?.bdwishlist(formdata)
                if (response?.data?.status == 1) {
                    handleReset()
                    notifySuccess(response?.data?.message)
                    showCollectionList()
                }
                else {
                    notify(response?.response?.data?.message)
                }
            } catch (error) {
                notify('Server Error')
            }
        }

        setTimeout(() => {
            setIsBtnDisabled(false)
        }, 2000);
    }

    const DeleteCollections = async (id) => {
        setIsBtnDisabled(true)
        try {
            const formdata = new URLSearchParams()
            formdata.append("collection_id", id);
            const response = await WishListApi?.DeleteCollection(formdata)
            if (response?.data?.status == 1) {
                notifySuccess(response?.data?.message)
                showCollectionList()
                setIsBtnDisabled(false)
                if (selectChange?.collection_id == id) {
                    console.log(selectChange?.collection_id == id, "selectChange?.collection_id == id")
                    setSelectChange((old) => ({
                        ...old,
                        collection_id: '',
                        status_id: ''
                    }))
                    fetchWishList(activeKey, '', '')
                } else {
                    fetchWishList(activeKey, selectChange?.collection_id, selectChange?.status_id)
                }

            }
        } catch (error) {
            notify('Error')
            console.log(error, 'Api Error')
        }
    }

    const handleDeletePopUp = (val) => {
        setDeleteModal(true)
        setModalData(val)
    }

    const handleKeyPress = (e) => {
        const forbiddenChars = /[{}.\[\]""''`~;:,\-_@#$%^&*()<>?/|+=!\\]/;
        if (forbiddenChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter') {
            e.preventDefault();
            bdaddCollections()
        } else if (e.key === ' ' && e.target.selectionStart === 0) {
            e.preventDefault();
        }
    };

    const onChange = () => { }
    const location = useLocation();
    const val = location?.pathname;
    const str = val.replace('/', '')

    // remove validation error click on outside form 
    useEffect(() => {
        const handleClickOutsideForm = (event) => {
            const collectionErrors = form.getFieldError('collection_name');

            if (collectionErrors.length > 0) {
                form.setFields([
                    {
                        name: 'collection_name',
                        errors: [],
                    },
                ]);
            }
        };

        document.addEventListener('click', handleClickOutsideForm);

        return () => {
            // Cleanup the event listener when the component unmounts
            document.removeEventListener('click', handleClickOutsideForm);
        };
    }, [form]);
    return (
        <>
            {/* <Breadcrumb data={str} /> */}
            <div className="wishlist-container">
                {/* <div className="headding-title">
                    <h2>Wishlist</h2>
                </div> */}
                <Row gutter={20}>
                    <Col span={6}>
                        <Form
                            form={form}
                            // name="validateOnly"
                            layout="vertical"
                            autoComplete="off"
                            onFinish={bdaddCollections}
                            onKeyDown={handleKeyPress}

                        >
                            <Form.Item label="Create a New Collection" name="collection_name" rules={[{ required: true, message: "Collection Name is required" }]}>
                                <Input
                                    placeholder="Enter here..."
                                    // name="collection_name"
                                    value={addCollection}
                                    onChange={(e) => handleInputChange(e)}

                                />
                            </Form.Item>

                            <button className="BG_mainButton" disabled={isBtnDisabled}>Create Collection</button>
                        </Form>
                        <div className="as">
                            <h5>Collections</h5>
                            <div className="list">
                                {collectionList?.map((item, index) => {
                                    return (
                                        <div className="sector">
                                            <span>{item?.collection_name}</span>
                                            <span style={{ cursor: 'pointer' }} onClick={() => handleDeletePopUp(item?.id)}>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                                    <path d="M10.5 3.5L3.5 10.5" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M3.5 3.5L10.5 10.5" stroke="#FF4343" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </span>
                                        </div>
                                    )
                                })
                                }

                            </div>
                        </div>
                    </Col>
                    <Col span={18}>
                        <div className="bd_main_profile_tabs" style={{ marginTop: 0 }}>
                            <div className="profile_tabs_heading">
                                <Tabs defaultActiveKey="1" items={items} onChange={(e) => handleTabChange(e)} className="tabs" />
                            </div>

                        </div>
                    </Col>
                </Row>

            </div>
            <DeleteModal title={"Wishlist Collection"} open={deleteModal} onClose={() => setDeleteModal(false)} handleDelete={DeleteCollections} modalData={modalData} />
        </>
    )
}
export default Wishlist;