import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import BIDGRIDROUTES from 'BidGrid/bidRoute/bidRoutes';


const Personal = () => {
    const [menuHide, setMenuHide] = useState(false)
    console.log(menuHide,"'hkhjkh");
    const showSubMenu = () => {
        setMenuHide(true)
        setTimeout(() => {
            setMenuHide(false);
        }, 1);
    }

    const design = (

        <>
            <div className='header_side_menu b'>
                <ul className="main-menu mainMenuNew">
                    <li className="nav-item ">
                        <span className="nav-link"><Link to={BIDGRIDROUTES?.DASHBOARD}>Dashboard</Link></span>
                    </li>
                    <li className="nav-item  dropdown">
                        <span className="nav-link dropdown-toggle">Personal</span>
                        <div className="dropdown-menu mega-menu visbleSubMenu" style={menuHide ? { display: "none" } : null}>
                            <div className="row">
                                <div className="col-sm-3">
                                    <span className="nav-link "><Link to={BIDGRIDROUTES?.Personal_reminder} onClick={() => showSubMenu()}>Reminder <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.Task_assigine} onClick={() => showSubMenu()}>TaskManage <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"><Link to={BIDGRIDROUTES?.Whislist} onClick={() => showSubMenu()}>Whishlist <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.PROFILE} onClick={() => showSubMenu()}>Profile <ArrowForwardIosIcon /></Link></span>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li className="nav-item ">
                        <span className="nav-link"> <Link to={BIDGRIDROUTES?.document_share}>Document Share</Link></span>
                    </li>
                    <li className="nav-item  dropdown">
                        <span className="nav-link dropdown-toggle ">Master</span>
                        <div className="dropdown-menu mega-menu visbleSubMenu" style={menuHide ? { display: "none" } : null}>
                            <div className="row" style={{ rowGap: 20 }}>
                                <div className="col-sm-3">
                                    <span className="nav-link "><Link to={BIDGRIDROUTES?.ADDUNIT} onClick={() => showSubMenu()}>Add Unit <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.JOBTITLE} onClick={() => showSubMenu()}>Job Title <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link "><Link to={BIDGRIDROUTES?.PREFIX} onClick={() => showSubMenu()}>Prefix <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.ROLE} onClick={() => showSubMenu()}>Role <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.DEPARTMENT_MANAGE} onClick={() => showSubMenu()}>Department <ArrowForwardIosIcon /></Link></span>
                                </div>

                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.DESIGNATION} onClick={() => showSubMenu()}> Designation<ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.CURRENCY} onClick={() => showSubMenu()}>Currency <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.LANGUAGE} onClick={() => showSubMenu()}>Language <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.TIMEZONE} onClick={() => showSubMenu()}>Timezone <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.ASSIGNSECTOR} onClick={() => showSubMenu()}>Assign Sector <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"><Link to={BIDGRIDROUTES?.KEYWORD} onClick={() => showSubMenu()}>Keyword <ArrowForwardIosIcon /></Link></span>
                                </div>
                                {/* <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.COMPANY} onClick={() => showSubMenu()}>Company <ArrowForwardIosIcon /></Link></span>
                                </div> */}
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.LOGO} onClick={() => showSubMenu()}>Logo <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.COUNTRYLIST} onClick={() => showSubMenu()}>Country  <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.SUBSECTOR} onClick={() => showSubMenu()}>Sub-Sector <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.TENDER_PHASE} onClick={() => showSubMenu()}>Phase <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.TENDER_SCOPE} onClick={() => showSubMenu()}>Tender Scope <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.FUNDING_AGENCY} onClick={() => showSubMenu()}>Funding Agency <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.STATELIST} onClick={() => showSubMenu()}>State <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.CITYLIST} onClick={() => showSubMenu()}>City <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.CONTINENTLIST} onClick={() => showSubMenu()}>Continent <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.REGIONLIST} onClick={() => showSubMenu()}> Region <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    {/* <span className="nav-link"> <Link to={BIDGRIDROUTES?.EMPLOYEE} onClick={() => showSubMenu()}> Employee <ArrowForwardIosIcon /></Link></span> */}
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.EMPLOYEE_STATUS} onClick={() => showSubMenu()}> Employee Status <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.BLOODGROUP}> Blood Group <ArrowForwardIosIcon /></Link></span>
                                </div>

                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.TENDER_SERVICES} onClick={() => showSubMenu()}> Tender Services <ArrowForwardIosIcon /></Link></span>
                                </div>

                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.NATIONALITY} onClick={() => showSubMenu()}>Nationality <ArrowForwardIosIcon /></Link></span>
                                </div>

                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.GENDER} onClick={() => showSubMenu()}>Gender <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.CLIENT} onClick={() => showSubMenu()}>Client <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.CONSORTIUM} onClick={() => showSubMenu()}>Consortium <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.TENDER_STATUS} onClick={() => showSubMenu()}>Tender Status <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-3">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.BD_TENDERDETAILS} onClick={() => showSubMenu()}>BdTenderDetails <ArrowForwardIosIcon /></Link></span>
                                </div>
                            </div>
                            {/* ./row */}
                        </div>


                    </li>
                    <li className="nav-item  dropdown">
                        <span className="nav-link dropdown-toggle ">Add</span>
                        <div className="dropdown-menu mega-menu visbleSubMenu" style={menuHide ? { display: "none" } : null}>
                            <div className="row">
                                <div className="col-sm-4">
                                    <span className="nav-link "><Link to={BIDGRIDROUTES?.LIVE_TENDERS} onClick={() => showSubMenu()}>Live Tender <ArrowForwardIosIcon /></Link></span>
                                </div>
                                <div className="col-sm-4">
                                    <span className="nav-link"><Link to={BIDGRIDROUTES?.PROSPECTIVE_TENDER} onClick={() => showSubMenu()}>Prospective Tender <ArrowForwardIosIcon /></Link></span>
                                </div>
                                {/* <div className="col-sm-4">
                                    <span className="nav-link"> <Link to={BIDGRIDROUTES?.COMPANY} onClick={() => showSubMenu()}>Company <ArrowForwardIosIcon /></Link></span>
                                </div> */}

                            </div>
                        </div>
                    </li>
                    <li className="nav-item ">
                        <span className="nav-link"> <Link to={BIDGRIDROUTES?.WORKLOAD_DISTRIBUTION}>Reports</Link></span>
                    </li>
                    <li className="nav-item ">
                        <span className="nav-link"><Link to={BIDGRIDROUTES?.New_assigne}>Tenders</Link></span>
                    </li>
                </ul>
            </div>
        </>
    )
    return design;
    // @ts-ignore
}
export default Personal;