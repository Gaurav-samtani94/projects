// @ts-nocheck
import React, { useEffect, useState, useMemo } from 'react';
import { Button, Input, Select, DatePicker, Drawer, Form, Row, Col, Modal, Flex, Avatar } from 'antd';
import { Down, AddUser } from '@icon-park/react';
import ExportDatatable from 'BidGrid/components/dataTable/ExportDatatable';
import DataTable from "BidGrid/components/dataTable/DataTable";
import SkipBack from '../../BidGrid/assets/images/skip-back.png'
import { RoleList } from 'Services/bidgrid/master/role/bidRole';
import { AddUnitApiList } from 'Services/bidgrid/master/addUnit/AddUnit';
import { biddepartment } from 'Services/bidgrid/master/department/biddepartment';
import { DesignationList } from 'Services/bidgrid/master/designation/bidDesignation';
import { bidCompany } from 'Services/bidgrid/master/company/bidCompany';
import { JobGrid } from 'Services/bidgrid/master/jobGrid/index';
import { TodoServices } from 'Services/bidgrid/todo/TodoServices';
import { bidEmployeeList } from 'Services/bidgrid/employeeList/bidEmployeeList';
import { toast } from 'react-toastify';
import user from '../../assests/img/user.png'
import { useSelector } from 'react-redux';
import { bidProspective } from 'Services/bidgrid/prospective/bidProspective';
import { AddTenderList } from 'Services/bidgrid/add/AddTender';
import dayjs from 'dayjs';
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb';
import { useLocation, useNavigate } from 'react-router-dom';
import { PlusCircleOutlined } from '@ant-design/icons';
import { bidtimezone } from 'Services/bidgrid/master/timeZone/bidtimezone';
import { COMMON_STRINGS } from 'Constants/Strings';
import ROUTES from 'Constants/Routes';
import { bidLeadCompanyAction } from 'Redux/actions/common/DropdownAction';
import { useDispatch } from 'react-redux';
import { docurlchat } from 'utils/configurable';

const { TextArea } = Input;
const { Option } = Select;
const showActions = true;

const optionVal = {
    role: [],
    unit: [],
    department: [],
    designation: [],
    company: [],
    jobgrid: [],
    reporting_manager: []

}
const initialstate = {
    firstname: '',
    lastname: '',
    role_id: null,
    company_id: null,
    department_id: null,
    designation_id: null,
    jobgrade_id: null,
    reporting_mngr_id: null,
    email: '',
    contactnumber: '',
    password: '',
    unit_id: null,
    country_id: null,
    state_id: null,
    city_id: null,
    date_of_birth: null,
    full_address_1: '',
    zip_code: '',
    profileimg: ''

}


const businessState = {
    country_id: null,
    state_id: null,
    city_id: null,
    timezone_name: null,
}

const EmployeeList = () => {
    const [openDrawer, setOpenDrawer] = useState(false)
    const [dropdownData, setDropdownData] = useState(optionVal)
    const [addEmployee, setAddEmployee] = useState(initialstate)
    const [employeeListVal, setEmployeeListVal] = useState([])
    const [flattenedProjects, setFlattenedProjects] = useState([]);
    const [propData, setPropData] = useState({})
    const [statelist, setStateList] = useState([])
    const [tenderCity, setTenderCity] = useState([])
    const [loadings, setLoadings] = useState(false)
    const [loadingsAdd, setLoadingsAdd] = useState(false)
    const { BidCountry } = useSelector((state) => state.bidDropdownCalVal)
    const { userBidInfo } = useSelector((state) => state?.userDetails)
    const dispatch = useDispatch()
    const notify = (error) => toast.error(error);
    const notifySuccess = (msg) => toast.success(msg);
    const [form] = Form.useForm();
    const [form2] = Form.useForm();
    const location = useLocation();
    const val = location?.pathname;
    const str = val.replace('/', '')
    const [isAddOpen, setAddOpen] = useState(false);
    const [modalLabel, setModalLabel] = useState("");
    const [modalFieldName, setModalFieldName] = useState("");
    const [formValues, setFormValues] = useState({});
    const [businessUnitState, setBusinessUnitState] = useState([])
    const [businessUnitCity, setBusinessUnitCity] = useState([])
    const [businessUnitTimezone, setBusinessUnitTimezone] = useState([])
    const [selectedOption, setSelectedOption] = useState(businessState);

    const dropdownRoleValues = dropdownData?.role;
    const dropdownBusinessUnitValues = dropdownData?.unit;
    const dropdownCompanyValues = dropdownData?.company;
    const dropdownDepartmentValues = dropdownData?.department;
    const dropdownDesignationValues = dropdownData?.designation;
    const dropdownJobgridValues = dropdownData?.jobgrid;
    const [errorMessage, setErrorMessage] = useState("");
    const [showError, setShowError] = useState(false)
    const [spinner, setSpinner] = useState(false)
    const navigate = useNavigate()


    const showModal = (fieldName, fieldLabel) => {

        setOpenDrawer(false)
        setAddOpen(true);
        setModalLabel(fieldLabel);
        setModalFieldName(fieldName);
    };
    const handleCancel = () => {
        setAddOpen(false);
        setOpenDrawer(true)
        form2.resetFields()
    };

    const empDropdownValues = async () => {

        // role list
        try {
            const response = await RoleList.getbidRole()
            if (response?.data?.status === '1') {
                setDropdownData(prev => ({ ...prev, role: response?.data?.data }))
            }
            else {
                setDropdownData(prev => ({ ...prev, role: [] }))
            }
        } catch (error) {
            console.log(error)
        }

        // Addunit
        try {
            const response = await AddUnitApiList.getUnitList()
            if (response?.data?.status === '1') {
                setDropdownData(prev => ({ ...prev, unit: response?.data?.data }))
            } else {
                setDropdownData(prev => ({ ...prev, unit: [] }))
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }

        // Department list
        try {
            const response = await biddepartment.getAllDepartmentList()
            if (response?.data?.status === '1') {
                setDropdownData(prev => ({ ...prev, department: response?.data?.data }))
            } else {
                setDropdownData(prev => ({ ...prev, department: [] }))
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }

        // designation list
        try {
            const response = await DesignationList.getDesignationList()
            if (response?.data?.status === '1') {
                console.log(response?.data?.data, "dfgdgfdg");
                setDropdownData(prev => ({ ...prev, designation: response?.data?.data }))
            } else {
                setDropdownData(prev => ({ ...prev, designation: [] }))
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }

        // company list
        try {
            const response = await bidCompany.getCompanyList();
            if (response?.data?.status === '1') {
                setDropdownData(prev => ({ ...prev, company: response?.data?.data }))
                dispatch(bidLeadCompanyAction(response?.data?.data?.sort((a, b) => a?.company_name?.localeCompare(b?.company_name))))

            }
            else {
                setDropdownData(prev => ({ ...prev, company: [] }))
            }
        } catch (error) {
            console.log(error, 'api error');
        }

        // job grade list
        try {
            const response = await JobGrid?.getJobGridList();
            if (response?.data?.status === '1') {
                setDropdownData(prev => ({ ...prev, jobgrid: response?.data?.data }))
            } else {
                setDropdownData(prev => ({ ...prev, jobgrid: [] }))
            }
        } catch (error) {
            console.error(error);
        }
    };


    const UserListShow = async (initial) => {
        if (initial) {
            setSpinner(true)
        }
        try {
            if (userBidInfo?.bg_mstr_role?.role_name !== 'System Admin') {
                const response = await bidEmployeeList.getUserListTeam()
                if (response?.data?.status === "1") {
                    setEmployeeListVal(response?.data?.data?.filter(item => item?.id !== userBidInfo?.id))
                    setDropdownData(prevState => ({ ...prevState, reporting_manager: response?.data?.data }))
                    setSpinner(false)
                }
                else {
                    setSpinner(false)
                }
            } else {
                const response = await bidEmployeeList.getUserList()
                if (response?.data?.status === "1") {
                    setEmployeeListVal(response?.data?.data?.filter(item => item?.id !== userBidInfo?.id))
                    setDropdownData(prevState => ({ ...prevState, reporting_manager: response?.data?.data }))
                    setSpinner(false)
                }
                else {
                    setSpinner(false)
                }
            }

        } catch (error) {
            setSpinner(false)
            console.log(error)
        }
    }

    const handleSelectChange = (name, value) => {
        if (name == "password") {
            const trimmedValue = value.trim();

            var lowerCase = /[a-z]/g;
            var upperCase = /[A-Z]/g;
            var numbers = /[0-9]/g;
            var charcter = /(?=.*[!@#$&*])/g;
            if (value?.length === 0) {
                setErrorMessage("");
                setShowError(true)
            }
            else if (!trimmedValue.match(lowerCase)) {
                setErrorMessage(COMMON_STRINGS.REQUIRED_LOWER_LETTER_PASSWORD);
                setShowError(true)
            }

            else if (!trimmedValue.match(upperCase)) {
                setErrorMessage(COMMON_STRINGS.REQUIRED_UPPER_LETTER_PASSWORD);
                setShowError(true)
            } else if (!trimmedValue.match(numbers)) {
                setErrorMessage(COMMON_STRINGS.REQUIRED_NUMBER_PASSWORD);
                setShowError(true)
            }
            else if (!trimmedValue.match(charcter)) {
                setErrorMessage(COMMON_STRINGS.REQUIRED_SPECIAL_PASSWORD);
                setShowError(true)
            }
            else if (trimmedValue.length < 8 || trimmedValue.length > 16) {
                setErrorMessage(COMMON_STRINGS.REQUIRED_LENGTH_PASSWORD);
                setShowError(true)
            }
            else {
                setShowError(false)
                setErrorMessage("");
            }
            setAddEmployee({ ...addEmployee, [name]: trimmedValue })
        }
        else {
            setAddEmployee({ ...addEmployee, [name]: value })
        }
    }


    const handleSubmit = async (value) => {
        setLoadingsAdd(true)

        const formData = new URLSearchParams();
        formData.append('firstname', value?.firstname);
        formData.append('lastname', value?.lastname);
        formData.append('role_id', value?.role_id);
        formData.append('email', value?.email);
        formData.append('contactnumber', value?.contactnumber);
        formData.append('password', value?.password);
        formData.append('company_id', value?.company_id);
        formData.append('department_id', value?.department_id);
        formData.append('designation_id', value?.designation_id);
        formData.append('jobgrade_id', value?.jobgrade_id);
        formData.append('reporting_mngr_id', value?.reporting_mngr_id);
        formData.append('unit_id', value?.unit_id);
        try {
            await form.validateFields();
            const response = await bidEmployeeList.addEmployee(formData)
            if (response?.data?.status === "1") {
                notifySuccess("Employee Add Successfully");
                form.resetFields()
                setAddEmployee(initialstate)
                setOpenDrawer(false)
                await UserListShow(false)
                setLoadingsAdd(false)
            } else {
                notify(response?.response?.data?.message);
                setLoadingsAdd(false)
            }

        } catch (error) {
            setLoadingsAdd(false)
            console.log(error, "api error")
        }

    }

    const employeeTableData = useMemo(() => {
        return flattenedProjects;
    }, [flattenedProjects]);

    const columnLabels = {
        full_name: { name: 'Full Name', required: true, width: 300 },
        isActive: { name: 'Employee Status', required: true, width: 300 },
        role: { name: 'Role', required: true, width: 200 },
        reporting_mngr: { name: 'Reporting Manager', required: true, width: 200 },
        designation: { name: 'Designation', required: true, width: 200 },
        department: { name: 'Department', required: true, width: 200 },
        job_grade: { name: 'Job Grade', required: true, width: 200 },
        created_by: { name: 'Created By', required: true, width: 200 },
        email: { name: 'Email', required: true, width: 300 },
        contact: { name: 'Contact Number', required: true, width: 200 },

    };


    useEffect(() => {
        const flattenedData = employeeListVal?.map(project => ({
            key: project.id,
            row_id: project?.id,
            full_name: <div>
                <Avatar
                    src={docurlchat + project?.profileimg_path + "/" + project?.profileimg}
                    style={{ backgroundColor: !project?.profileimg_path && '#f56a00' }}
                    size="medium"
                >
                    {project?.userfullname?.charAt(0)}
                </Avatar>
                {" "}
                {project?.userfullname}
            </div>,
            isActive: project?.isactive == 1 ? "Active" : "Inactive",
            role: project?.bg_mstr_role !== null ? project?.bg_mstr_role?.role_name : '-',
            reporting_mngr: project?.reporting_manager?.userfullname,
            designation: project?.bg_mstr_designation?.designation_name,
            department: project?.bg_mstr_department?.department_name,
            job_grade: project?.bg_mstr_jobgrade?.job_grade,
            created_by: project?.createdby_username?.userfullname,
            email: project?.email,
            contact: project?.contactnumber,
            ...project
        }));

        setFlattenedProjects(flattenedData);
    }, [employeeListVal]);


    const getPropData = (val) => {
        setPropData(val)
        navigate(ROUTES.BD_EMP_PROFILE.replace(':id', val?.id))

        // setOpenDrawer(true)
    }

    const getState = async () => {
        const formData = new URLSearchParams()
        formData.append('country_id', addEmployee?.country_id)
        try {
            const res = await bidProspective.getStateList(formData)
            if (res?.data?.status === '1') {
                setStateList(res?.data?.data)
            } else {
                setStateList([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }
    const getCity = async () => {
        const formData = new URLSearchParams();
        formData.append('state_id', addEmployee?.state_id);
        try {
            const res = await AddTenderList.getTenderCityList(formData)

            if (res?.data?.status === '1') {
                setTenderCity(res?.data?.data)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const predefinedValues = () => {
        let newObj = {
            firstname: propData?.firstname || '',
            lastname: propData?.lastname || '',
            role_id: propData?.emp_role_id || '',
            company_id: propData?.company_id || '',
            department_id: propData?.department_id || '',
            designation_id: propData?.designation_id || '',
            jobgrade_id: propData?.jobgrade_id || '',
            reporting_mngr_id: propData?.reporting_mngr_id || '',
            email: propData?.email || '',
            contactnumber: propData?.contactnumber || '',
            password: propData?.password || '',
            unit_id: propData?.unit_id || '',
            country_id: propData?.country_id || '',
            state_id: propData?.state_id || '',
            city_id: propData?.city_id || '',
            date_of_birth: propData?.date_of_birth !== null ? dayjs(propData?.date_of_birth) : null,
            full_address_1: propData?.full_address_1 || '',
            zip_code: propData?.zip_code || '',
            profileimg: propData?.profileimg || ''
        }
        setAddEmployee((prevState) => {
            return {
                ...prevState,
                ...newObj
            };
        });
        form.setFieldsValue(newObj);



    }

    const handleReset = () => {

        form.resetFields()
        setAddEmployee(initialstate)
        setErrorMessage("");

    }


    const handleAddApi = async (value, DataName) => {
        if (DataName === "role") {
            setLoadings(true)
            try {
                // await form.validateFields([modalFieldName]);
                const formData = new URLSearchParams();
                formData.append('role_name', value?.Role);
                const response = await RoleList?.postbidRole(formData)
                if (response?.data?.status == 1) {
                    setDropdownData(prev => ({ ...prev, role: response?.data?.data }))
                    setAddOpen(false);
                    setOpenDrawer(true)
                    form2.resetFields()
                    notifySuccess('Role added successfully')
                    setLoadings(false)
                }
                else {
                    // handleReset()
                    notify(response?.response?.data?.message)
                    setLoadings(false)
                }
            } catch (error) {
                console.log(error, 'Api Error')
                setLoadings(false)
            }
        }
        else if (DataName === "company") {
            setLoadings(true)
            const formData = new URLSearchParams();
            formData.append("company_name", value?.Company);
            try {
                const response = await bidCompany?.addCompanyList(formData);
                if (response?.data?.status == 1) {
                    setDropdownData(prev => ({ ...prev, company: response?.data?.data }))
                    setAddOpen(false);
                    setOpenDrawer(true)
                    form2.resetFields()
                    notifySuccess('company added successfully')
                    setLoadings(false)
                }
                else {
                    notify(response?.response?.data?.message)
                    setLoadings(false)
                }
            } catch (error) {
                console.error('Error fetching data:', error);
                setLoadings(false)
            }

        } else if (DataName === "designation") {
            setLoadings(true)
            const formData = new URLSearchParams();
            formData.append('designation_name', value?.Designation);
            try {
                const response = await DesignationList.addDesignationList(formData)
                if (response?.data?.status == 1) {
                    setDropdownData(prev => ({ ...prev, designation: response?.data?.data }))
                    setAddOpen(false);
                    setOpenDrawer(true)
                    notifySuccess('Designation added successfully')
                    form2.resetFields()
                    setLoadings(false)
                } else {
                    notify(response?.response?.data?.message);
                    setLoadings(false)
                }
            } catch (error) {
                console.log(error, "api error")
                setLoadings(false)
            }

        } else if (DataName === "department") {
            setLoadings(true)
            const formData = new URLSearchParams();
            formData.append('department_name', value?.Department);
            try {
                const response = await biddepartment.addDepartmentList(formData)
                if (response?.data?.status == 1) {
                    setDropdownData(prev => ({ ...prev, department: response?.data?.data }))
                    setAddOpen(false);
                    setOpenDrawer(true)
                    form2.resetFields()
                    notifySuccess('Department added successfully')
                    setLoadings(false)
                }
                else {
                    notify(response?.response?.data?.message);
                    setLoadings(false)
                }
            } catch (error) {
                setLoadings(false)
                notify("Server Error!!");
            }
        } else if (DataName === "jobgrade") {
            setLoadings(true)
            const formData = new URLSearchParams();
            formData.append('job_grade', value?.JobGrade);
            try {
                // await form.validateFields();
                const response = await JobGrid.createJobGrid(formData);
                if (response?.data?.status == 1) {
                    setDropdownData(prev => ({ ...prev, jobgrid: response?.data?.data }))
                    setAddOpen(false);
                    setOpenDrawer(true)
                    form2.resetFields()
                    notifySuccess('Job Grade added successfully')
                    setLoadings(false)
                } else {
                    notify(response?.response?.data?.message);
                    setLoadings(false)
                }
            } catch (error) {
                notify("Server Error!!");
                setLoadings(false)
            }
        } else if (DataName === "unit") {
            setLoadings(true)
            const formData = new URLSearchParams();
            formData.append('unit_name', value?.Business);
            formData.append('timezone_id', value?.timezone_name);
            formData.append('country_id', value?.country_id);
            formData.append('state_id', value?.state_id);
            formData.append('city_id', value?.city_id);
            try {
                const response = await AddUnitApiList.addUnitList(formData)
                if (response?.data?.status === '1') {
                    setDropdownData(prev => ({ ...prev, unit: response?.data?.data }))
                    setAddOpen(false);
                    setOpenDrawer(true)
                    form2.resetFields()
                    setSelectedOption(businessState)
                    setLoadings(false)
                    notifySuccess('Business unit added successfully')
                } else {
                    notify(response?.response?.data?.message)
                    setLoadings(false)
                }
            } catch (error) {
                console.log(error, "api error")
                setLoadings(false)
            }
        }

    }

    const handleSelectState = (name, value) => {
        setSelectedOption({ ...selectedOption, [name]: value });
    }

    const getBusinessUnitTimezone = async () => {
        try {
            const res = await bidtimezone.getTimezone()
            if (res?.data?.status === '1') {
                setBusinessUnitTimezone(res?.data?.data)
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }
    const getBusinessUnitState = async () => {
        const formData = new URLSearchParams();
        formData.append('country_id', selectedOption?.country_id);
        try {
            const res = await AddTenderList.getTenderStateList(formData)
            if (res?.data?.status === '1') {
                setBusinessUnitState(res?.data?.data)
            } else {
                setBusinessUnitState([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }

    const getBusinessUnitCity = async () => {
        const formData = new URLSearchParams();
        formData.append('state_id', selectedOption?.state_id);
        try {
            const res = await AddTenderList.getTenderCityList(formData)
            if (res?.data?.status === '1') {
                setBusinessUnitCity(res?.data?.data)
            } else {
                setBusinessUnitCity([])
            }
        } catch (error) {
            console.log(error, 'api erorr')
        }
    }
    useEffect(() => {
        if (selectedOption?.country_id !== null) {
            getBusinessUnitState()

        }
    }, [selectedOption?.country_id])

    useEffect(() => {
        if (selectedOption?.state_id !== null) {
            getBusinessUnitCity()
        }
    }, [selectedOption?.state_id])
    useEffect(() => {
        if (modalFieldName === 'unit')
            getBusinessUnitTimezone()
    }, [modalFieldName])

    useEffect(() => {
        if (addEmployee?.country_id !== '' && propData?.id) {
            getState()
        }
    }, [addEmployee?.country_id])

    useEffect(() => {
        if (addEmployee?.state_id !== '' && propData?.id) {
            getCity()
        }
    }, [addEmployee?.state_id])

    useEffect(() => {
        if (propData?.id) {
            predefinedValues()
        }
    }, [propData])

    useEffect(() => {
        UserListShow(true)
    }, [])

    useEffect(() => {
        if (openDrawer === true) {
            empDropdownValues()
        }
    }, [openDrawer])
    const handleResetModal = () => {
        form2.resetFields()
        setBusinessUnitCity([]);
        setBusinessUnitState([]);
        setSelectedOption(businessState)
    }


    const validateStrongPassword = (_, value) => {
        const lowercaseRegex = /[a-z]/;
        const uppercaseRegex = /[A-Z]/;
        const numericRegex = /[0-9]/;
        const specialCharacterRegex = /[@$!%*?#&]/;
        const minLength = 8;
        const maxLength = 16;

        if (!value) {
            return Promise.reject('');
        }

        if (value.length > maxLength) {
            return Promise.reject(`Password must not exceed ${maxLength} characters`);
        }

        if (!lowercaseRegex.test(value)) {
            return Promise.reject(COMMON_STRINGS.REQUIRED_LOWER_LETTER_PASSWORD);
        }

        if (!uppercaseRegex.test(value)) {
            return Promise.reject(COMMON_STRINGS.REQUIRED_UPPER_LETTER_PASSWORD);
        }

        if (!numericRegex.test(value)) {
            return Promise.reject(COMMON_STRINGS.REQUIRED_NUMBER_PASSWORD);
        }

        if (!specialCharacterRegex.test(value)) {
            return Promise.reject(COMMON_STRINGS.REQUIRED_SPECIAL_PASSWORD);
        }

        if (value.length < minLength) {
            return Promise.reject(COMMON_STRINGS.REQUIRED_LENGTH_PASSWORD);
        }

        return Promise.resolve();
    };



    const validateContactNumber = (_, value) => {
        // Regular expression to match exactly 10 digits
        const regex = /^[0-9]{10}$/;

        if (!value || regex.test(value)) {
            return Promise.resolve();
        }

        return Promise.reject('Contact number must be a 10-digit number');
    };
    const handleKeyPressSelectedItem = (e) => {
        const allowedChars = /[0-9.]/;

        if (!allowedChars.test(e.key)) {
            e.preventDefault();
        } else if (e.key === 'Enter' || (e.key === ' ' && e.target.selectionStart === 0)) {
            e.preventDefault();
        }
    };
    const handleEmployeeChange = (name, e) => {
        const trimmedValue = e.target.value.trimStart();
        form.setFieldsValue({ [name]: trimmedValue });
        form2.setFieldsValue({ [name]: trimmedValue });
    };
    return (
        <>
            {/* <Breadcrumb data={str} /> */}
            <div className="bd_emplist_main">

                <div className="bd_empHeader">
                    <div className="bd_emplist_main_header">Employee List</div>
                    <button className="BG_mainButton" onClick={() => { setOpenDrawer(true) }}>
                        <AddUser theme="outline" size="22" fill="#fff" strokeWidth={3} strokeLinecap="butt" /> Add Employee
                    </button>
                </div>

                <DataTable
                    columnLabels={columnLabels}
                    dataSource={employeeTableData}
                    showActions={showActions}
                    setOpen={setOpenDrawer}
                    getPropData={getPropData}
                    spinner={spinner}
                    setSpinner={setSpinner}
                />
            </div>

            <Drawer closeIcon={<img src={SkipBack} alt='' />} title='Add Employee' placement="right" onClose={() => { setOpenDrawer(false); handleReset(); }} open={openDrawer} width={800}>
                <Form
                    form={form}
                    name="control-hooks"
                    layout="vertical"
                    // onKeyDown={handleKeyPress}
                    onFinish={handleSubmit}
                >
                    <Row gutter={20}>
                        <Col sm={12} >
                            <Form.Item label="First Name" name='firstname' rules={[{ required: true, message: 'First name is required' }]} >
                                <Input placeholder="Enter Here" onChange={(e) => handleEmployeeChange('firstname', e)}
                                />
                            </Form.Item>
                        </Col>

                        <Col sm={12}>
                            <Form.Item label="Last Name" name='lastname' rules={[{ required: true, message: 'Last name is required' }]} >
                                <Input placeholder="Enter Here" onChange={(e) => handleEmployeeChange('lastname', e)}
                                />
                            </Form.Item>
                        </Col>


                        <Col sm={12} >
                            <Form.Item label={<span>Role <PlusCircleOutlined onClick={() => showModal('role', 'Role')} /></span>} name='role_id' rules={[{ required: true, message: 'Role is required' }]} >
                                <Select
                                    allowClear
                                    onChange={(e) => handleSelectChange('role_id', e)}
                                    value={addEmployee?.role_id}
                                    placeholder="Enter Here"
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    showSearch
                                    optionFilterProp="children"
                                    options={Object.values(dropdownRoleValues)?.map((item, index) => {
                                        return {
                                            value: item?.id,
                                            label: item?.role_name
                                        };
                                    })}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                />
                            </Form.Item>

                        </Col>
                        <Col sm={12} >
                            <Form.Item label={<span>Business Unit <PlusCircleOutlined onClick={() => showModal('unit', 'Business')} /></span>} name='unit_id' rules={[{ required: true, message: 'Business Unit is required' }]}>
                                <Select
                                    allowClear
                                    placeholder="Enter Here"
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    showSearch
                                    optionFilterProp="children"
                                    options={Object.values(dropdownBusinessUnitValues).map((item, index) => {
                                        return {
                                            value: item?.id,
                                            label: item?.unit_name
                                        }
                                    })}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                    onChange={(e) => handleSelectChange('unit_id', e)}
                                    value={addEmployee?.unit_id}
                                />
                            </Form.Item>
                        </Col>
                        <Col sm={12} >
                            <Form.Item label={<span>Company  <PlusCircleOutlined onClick={() => showModal('company', 'Company')} /></span>} name='company_id' rules={[{ required: true, message: 'Company is required' }]}>

                                <Select
                                    allowClear
                                    placeholder="Enter Here"
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    showSearch
                                    optionFilterProp="children"
                                    options={Object.values(dropdownCompanyValues)?.map((item, index) => {
                                        return {
                                            value: item?.id,
                                            label: item?.company_name
                                        }
                                    })}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }

                                    onChange={(e) => handleSelectChange('company_id', e)}
                                    value={addEmployee?.company_id}
                                />
                            </Form.Item>
                        </Col>

                        <Col sm={12} >
                            <Form.Item label={<span>Designation  <PlusCircleOutlined onClick={() => showModal('designation', 'Designation')} /></span>} name='designation_id' rules={[{ required: true, message: 'Designation is required' }]}>
                                <Select
                                    allowClear
                                    placeholder="Enter Here"
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    showSearch
                                    optionFilterProp="children"
                                    options={Object.values(dropdownDesignationValues)?.map((item, index) => {
                                        return {
                                            value: item?.id,
                                            label: item?.designation_name
                                        }
                                    })}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                    onChange={(e) => handleSelectChange('designation_id', e)}
                                    value={addEmployee?.designation_id}
                                />
                            </Form.Item>
                        </Col>

                        <Col sm={12} >
                            <Form.Item label={<span>Department  <PlusCircleOutlined onClick={() => showModal('department', 'Department')} /></span>} name='department_id' rules={[{ required: true, message: 'Department is required' }]}>
                                <Select
                                    allowClear
                                    placeholder="Enter Here"
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    showSearch
                                    optionFilterProp="children"
                                    options={Object.values(dropdownDepartmentValues)?.map((item, index) => {
                                        return {
                                            value: item?.id,
                                            label: item?.department_name
                                        }
                                    })}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                    onChange={(e) => handleSelectChange('department_id', e)}
                                    value={addEmployee?.department_id}
                                />
                            </Form.Item>
                        </Col>

                        <Col sm={12} >
                            <Form.Item label={<span>Job Grade  <PlusCircleOutlined onClick={() => showModal('jobgrade', 'JobGrade')} /></span>} name='jobgrade_id' rules={[{ required: true, message: 'Job Grade is required' }]}>
                                <Select
                                    allowClear
                                    placeholder="Enter Here"
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    showSearch
                                    optionFilterProp="children"
                                    options={Object.values(dropdownJobgridValues)?.map((item, index) => {
                                        return {
                                            value: item?.id,
                                            label: item?.job_grade
                                        }
                                    })}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                    // name='jobgrade_id'
                                    onChange={(e) => handleSelectChange('jobgrade_id', e)}
                                    value={addEmployee?.jobgrade_id}
                                />
                            </Form.Item>
                        </Col>

                        <Col sm={12} >
                            <Form.Item label="Reporting Manager" name='reporting_mngr_id' rules={[{ required: true, message: 'Reporting manager is required' }]}>
                                <Select
                                    allowClear
                                    placeholder="Enter Here"
                                    suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                    showSearch
                                    optionFilterProp="children"
                                    options={dropdownData?.reporting_manager?.filter(val => val.isactive == 1)?.map((item, index) => ({
                                        value: item?.id,
                                        label: item?.userfullname
                                    }))}
                                    filterOption={(input, option) =>
                                        option.label.toLowerCase().trim().indexOf(input.toLowerCase().trim()) >= 0
                                    }
                                    onChange={(e) => handleSelectChange('reporting_mngr_id', e)}
                                    value={addEmployee?.reporting_mngr_id}
                                />

                            </Form.Item>
                        </Col>
                        <Col sm={12} >
                            <Form.Item label="Email" name='email' rules={[{ required: true, message: 'Email is required' }, {
                                type: 'email',
                                message: 'Please enter a valid email address',
                            },]}>
                                <Input
                                    onChange={(e) => handleEmployeeChange('email', e)}
                                    placeholder="Enter Here"

                                />
                            </Form.Item>
                        </Col>
                        <Col sm={12} >
                            <Form.Item label="Contact Number" name='contactnumber' rules={[{ required: true, message: 'Contact Number is required' }, {
                                validator: validateContactNumber,
                            },]} onKeyPress={handleKeyPressSelectedItem}>
                                <Input
                                    placeholder="Enter Here"
                                    type='text'
                                    maxLength={10}
                                />
                            </Form.Item>
                        </Col>
                        <Col sm={12} >
                            <Form.Item label="Password" name='password' rules={[{ required: true, message: 'Password is required' }, {
                                validator: validateStrongPassword,
                            },]}>
                                <Input
                                    placeholder="Enter Here"
                                    onChange={(e) => handleEmployeeChange('password', e)}

                                />
                            </Form.Item>
                        </Col>

                    </Row>

                    <div className="bd_drawerFoot">
                        <Button className='BG_ghostButton' onClick={handleReset}>Reset</Button>
                        <Button key="submit" className='BG_mainButton' type="primary" htmlType="submit" loading={loadingsAdd} disabled={loadingsAdd}>Add</Button>
                    </div>
                </Form>

            </Drawer>

            <Modal title={`Add ${modalLabel}`} open={isAddOpen} onCancel={handleCancel}
                footer={false}>
                <Form form={form2} name="control-hooks" layout="vertical" autoComplete="off" className='bd_model_form' onFinish={(val) => handleAddApi(val, modalFieldName)}>
                    <Form.Item label={`${modalLabel} Name :`} name={modalLabel} rules={[{ required: true, message: `${modalLabel} is Required` }]}>
                        <Input
                            placeholder={`Enter ${modalLabel} here...`}
                            onChange={(e) => handleEmployeeChange(modalLabel, e)}
                        />

                    </Form.Item>
                    {
                        modalFieldName === "unit" ?
                            <>
                                <Form.Item label="TimeZone:" name='timezone_name' rules={[{ required: true, message: 'Timezone is required' }]}>
                                    <Select
                                        allowClear
                                        showSearch
                                        value={selectedOption?.timezone_name}
                                        onChange={(value) => handleSelectState('timezone_name', value)}
                                        options={businessUnitTimezone?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.timezone_name
                                            }
                                        })}
                                        placeholder="Select TimeZone"
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    >
                                    </Select>
                                </Form.Item>
                                <Form.Item label="Country:" name='country_id' rules={[{ required: true, message: 'Country is required' }]}>
                                    <Select
                                        allowClear
                                        placeholder="Select Country"
                                        showSearch
                                        value={selectedOption?.country_id}
                                        onChange={(value) => handleSelectState('country_id', value)}
                                        options={BidCountry?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.country_name
                                            }
                                        })}
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    >

                                    </Select>
                                </Form.Item>
                                <Form.Item label="State:" name='state_id' rules={[{ required: true, message: 'State is required' }]}>
                                    <Select
                                        allowClear
                                        showSearch
                                        value={selectedOption?.state_id}
                                        onChange={(value) => handleSelectState('state_id', value)}
                                        options={businessUnitState?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.state_name
                                            }
                                        })}
                                        placeholder="Select State"
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    >

                                    </Select>
                                </Form.Item>
                                <Form.Item label="City:" name='city_id' rules={[{ required: true, message: 'City is required' }]}>
                                    <Select
                                        allowClear
                                        showSearch
                                        value={selectedOption?.city_id}
                                        onChange={(value) => handleSelectState('city_id', value)}
                                        options={businessUnitCity?.map((item, index) => {
                                            return {
                                                value: item?.id,
                                                label: item?.city_name
                                            }
                                        })}
                                        placeholder="Select City"
                                        suffixIcon={<Down theme="outline" size="18" fill="#747474" />}
                                        filterOption={(input, option) =>
                                            option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                        }
                                    >

                                    </Select>
                                </Form.Item>
                            </> : ""
                    }

                    <Flex justify='flex-end' align='center'>
                        <Button key="cancel" onClick={handleResetModal} className="BG_ghostButton">
                            Reset
                        </Button>
                        <Button key="submit" className='BG_mainButton' style={{ marginLeft: '20px' }} type="primary" htmlType="submit" loading={loadings} disabled={loadings}>
                            Submit
                        </Button>
                    </Flex>
                </Form>
            </Modal>


        </>
    )
}

export default EmployeeList
