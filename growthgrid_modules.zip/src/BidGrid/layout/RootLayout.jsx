import { useLocation } from "react-router-dom";
// import "../assets/statgridapp.scss"
import React, { Suspense, lazy, useState } from 'react'
import ROUTES from "Constants/Routes";
const Header = lazy(() => import('BidGrid/layout/sharedLayout/Header'));
const Sidebar = lazy(() => import('BidGrid/layout/sharedLayout/Sidebar'));

const RootLayout = ({ children }) => {
    const [collapsed, setCollapsed] = useState(true)
    const location = useLocation()
    const changeCollapsed = () => {
        setCollapsed(!collapsed)
    }
    return (
        <>

            <div className='d-flex gap-0 align-items-start'>
                <Suspense fallback={<div></div>}>
                    {(location.pathname !== ROUTES.BD_LOGIN && location.pathname !== ROUTES.BD_CONFIG) &&
                        <Sidebar collapsed={collapsed} />
                    }

                    <div className='w-50 flex-grow-1 '>
                        {(location.pathname !== ROUTES.BD_LOGIN && location.pathname !== ROUTES.BD_CONFIG) &&
                            <Header changeCollapsed={changeCollapsed} collapsed={collapsed} />
                        }
                        {children}
                    </div>
                </Suspense>
            </div>
        </>
    )
}

export default RootLayout