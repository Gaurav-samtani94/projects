// @ts-nocheck
import React, { useEffect, useState } from 'react'
import '../../assets/css/new/header.scss'
import { useSelector } from 'react-redux'
import { DashboardServiceApi } from 'Services/bidgrid/dashboard/DashboardAPi'
import { Dropdown, Menu } from 'antd'
import { DownOutlined, LogoutOutlined, UserOutlined } from '@ant-design/icons'
import { Avatar } from '@mui/material'
import { useLocation, useNavigate, Link } from 'react-router-dom'
import BIDGRIDROUTES from 'BidGrid/bidRoute/bidRoutes'
import { userBidLogoutAction } from 'Redux/actions/common/authAction'
import { useDispatch } from 'react-redux'
import dayjs from 'dayjs'
import ROUTES from "Constants/Routes";
import Breadcrumb from 'BidGrid/components/BidBreadCrumb/Breadcrumb'
import { navigationData } from 'Redux/actions/bidgrid/navigationData'
import { docurlchat } from 'utils/configurable';
import { RoleList } from 'Services/bidgrid/master/role/bidRole'

const Header = ({ changeCollapsed, collapsed }) => {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const location = useLocation()
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const { userBidInfo } = useSelector((state) => state.userDetails)
  const { socket, isConnected } = useSelector((state) => state.socket);
  const [designation, setDesignation] = useState('')
  const [notification, setNotification] = useState([])
  const { bidMenu } = useSelector((state) => state.bidMenuVal)

  const fetchDesignation = async () => {
    try {
      const formData = new URLSearchParams();
      formData.append('designation_id', userBidInfo?.designation_id)
      const response = await DashboardServiceApi.getDeisgnationOfUser(formData)
      if (response?.data?.status === '1') {
        setDesignation(response?.data?.data?.designation_name)
      } else {
        setDesignation('')
      }
    } catch (error) {
      console.log(error)
    }
  }

  // menu list
  const fetchMenuList = async () => {
    const formData = new URLSearchParams();
    formData.append('role_id', userBidInfo?.bg_mstr_role?.id)
    // formData.append('role_id', 1)


    try {
      const response = await RoleList.menuList(formData)
      if (response?.data?.status == 1) {

        let dataVal = response?.data?.data;

        const newData = dataVal?.filter(val => val?.parent_menu_id === 0)?.map(item => {

          const children = dataVal?.filter(child => child?.parent_menu_id === item?.id);
          return {
            ...item,
            children: children?.length > 0 ? children : []
          };
        });

        dispatch(navigationData.BidMenuData(newData))
        // setMenuData(newData);
      }
      else {
        // setMenuData([])
      }
    } catch (error) {
      console.log(error)
    }

  }

  useEffect(() => {
    fetchMenuList()
  }, [])

  useEffect(() => {
    if (isConnected) {
      const socketListener = (data) => {
        setNotification(prevComments => [data, ...prevComments.slice(0)]);
      }
      socket.on(userBidInfo?.id, socketListener);
      return () => {
        socket.off(userBidInfo?.id, socketListener);
      };

    }
  }, [isConnected])

  const getUserHistoryApi = async (shouldOpen) => {
    try {
      const response = await DashboardServiceApi.fetchNotifications()
      if (response?.data?.status === '1') {
        setNotification(response?.data?.data)
        shouldOpen && setIsDropdownOpen(true)
      } else {
        setNotification([])
      }
    } catch (error) {
      setNotification([])
    }
  }

  useEffect(() => {
    if (localStorage.getItem('bidToken')) {
      fetchDesignation()
      getUserHistoryApi(false)
    }

  }, [])



  const handleNavigate = async (item) => {
    const obj = {
      item: item,
      type: item.category_types,
      key: item?.category_id
    }
    dispatch(navigationData.setNavigationDataAction(obj))
    if (item.category_types === 'tender_todo_comments' || item.category_types === 'tender_comments' || item.category_types === 'meeting_schedule' || item.category_types === 'tender_request') {
      navigate(ROUTES.BD_TENDERDETAILS.replace(':id', item?.tender_id));
    } else if (item.category_types === 'to_do_comments') {
      navigate('/bidgrid/todo');
    }
    try {
      const formData = new URLSearchParams()
      formData.append('notification_id', item?.id)
      const response = await DashboardServiceApi.notificationClicked(formData)

      if (response?.data?.status === '1') {
        getUserHistoryApi(false)
      }
    } catch (error) {

    }

  }

  function convertHtmlToText(item) {
    return item?.replace(/<[^>]*>/g, '')
  }


  const items = notification.map((item, index) => ({
    label: <div className={`notiItem ${item.is_clicked !== '1' ? "view_is" : ''}`} key={index} onClick={() => handleNavigate(item)}>
      <span>{item?.mentioned_by}</span>{convertHtmlToText(item?.category_details)}
      <div className="date">{dayjs(item?.created_at).format('YYYY-MM-DD')}</div>
    </div>,
    key: index.toString(), // Use a unique key for each menu item
  }));

  // console.log(window.location.pathname)
  const handleLogout = () => {
    localStorage.setItem('lastVisited', window.location.pathname)
    dispatch(userBidLogoutAction());

  };

  const handleClick = async () => {
    if (isDropdownOpen) {
      return
    }
    try {
      const response = await DashboardServiceApi.seenNotification()

      if (response?.data?.status === '1') {
        // getUserHistoryApi(true)
        const updatedData = notification.map((item) => {
          return { ...item, ['is_viewed']: '1' };
        });
        setNotification(updatedData)
        setIsDropdownOpen(true)
      }
    } catch (error) {
      console.log(error)
    }
  }


  const menu = (
    <Menu className='px-2'>
      {/* <Menu.Item className='my-2 py-2 px-3 rounded-4' key="1" icon={
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 48 48">
          <g fill="currentColor" fill-rule="evenodd" clip-rule="evenodd">
            <path d="M24 27a8 8 0 1 0 0-16a8 8 0 0 0 0 16Zm0-2a6 6 0 1 0 0-12a6 6 0 0 0 0 12Z" />
            <path d="M44 24c0 11.046-8.954 20-20 20S4 35.046 4 24S12.954 4 24 4s20 8.954 20 20ZM33.63 39.21A17.915 17.915 0 0 1 24 42a17.916 17.916 0 0 1-9.832-2.92c-.24-.3-.483-.61-.73-.93A2.144 2.144 0 0 1 13 36.845c0-1.077.774-1.98 1.809-2.131c6.845-1 11.558-.914 18.412.035A2.077 2.077 0 0 1 35 36.818c0 .48-.165.946-.463 1.31c-.307.374-.61.735-.907 1.082Zm3.355-2.744c-.16-1.872-1.581-3.434-3.49-3.698c-7.016-.971-11.92-1.064-18.975-.033c-1.92.28-3.335 1.856-3.503 3.733A17.94 17.94 0 0 1 6 24c0-9.941 8.059-18 18-18s18 8.059 18 18a17.94 17.94 0 0 1-5.015 12.466Z" />
          </g>
        </svg>
      } onClick={() => navigate(BIDGRIDROUTES?.PROFILE)}>Profile</Menu.Item> */}
      {userBidInfo?.bg_mstr_role?.role_name === 'System Admin' &&

        <>
          {
            bidMenu?.filter(item => item?.menu_name === 'Setting' || item?.menu_name === 'Profile')?.map((val, index) => {
              return (
                <>
                  <Menu.Item className='my-2 py-2 px-3 rounded-4' key={index}

                    icon={<img src={docurlchat + val?.icon_path} width={20} height={20} />}
                    onClick={() => navigate(val?.action_url)}>
                    {val?.menu_name}
                  </Menu.Item>
                </>
              )
            })

          }
        </>


      }

      <Menu.Item className='my-2 py-2 px-3 rounded-4' key="6" danger icon={
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
          <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13.496 21H6.5c-1.105 0-2-1.151-2-2.571V5.57c0-1.419.895-2.57 2-2.57h7M16 15.5l3.5-3.5L16 8.5m-6.5 3.496h10" />
        </svg>
      } onClick={handleLogout}>
        LogOut
      </Menu.Item>
    </Menu>
  );
  const val = location?.pathname;
  const str = val.replace('/', '')
  return (
    <>
      <header className='header'>
        <div onClick={changeCollapsed} className='collapsedBtn' style={{ transform: `rotateY(${collapsed ? "180deg" : "0deg"})` }}>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
            <path fill="none" stroke="#747474" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12H3m4-4l-4 4l4 4m5 5a9 9 0 0 0 0-18" />
          </svg>
        </div>
        <div className='d-flex justify-content-between align-items-center w-100'>
          <div className="headerDeyt">
            {/* <small>Welcome</small> */}
            <h4>{userBidInfo?.userfullname} <span>{designation !== '' ? `(${designation})` : ''}</span>
            </h4>
            <Breadcrumb data={str} />
          </div>
          <div className='d-flex gap-3'>
            <div className="notification_wrap">
              <Dropdown
                menu={{
                  items,
                }}
                open={isDropdownOpen} // Pass the visibility state as a prop
                onOpenChange={setIsDropdownOpen}
                dropdownRender={(menu) => (
                  <div className="notification_Dropdown">
                    <div className="noti_header">Notification</div>
                    {React.cloneElement(menu, {
                      // style: menuStyle,
                    })}
                    <div className="noti_footer"><Link to={BIDGRIDROUTES?.NOTIFICATION}>View all</Link ></div>
                  </div>
                )}
                trigger={['click']}
                placement="bottomRight"
              // arrow
              >
                <div onClick={() => handleClick()} className='ot-btn'>
                  <span className="countNum">{notification?.filter(val => val.is_viewed === '0')?.length}</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 16 16">
                    <path fill="currentColor" fill-rule="evenodd" d="M2.316 12h10.368c-.188-.704-.28-1.691-.348-3.037c-.07-1.382-.103-1.888-.19-2.612c-.028-.236-.06-.462-.096-.68c-.31-1.892-1.506-2.923-3.708-3.131a1 1 0 1 0-1.684 0c-2.202.208-3.397 1.24-3.708 3.13a16.01 16.01 0 0 0-.096.68c-.087.725-.12 1.23-.19 2.613c-.068 1.346-.16 2.333-.348 3.037m10.843 1H1.84c-.308.353-.737.5-1.341.5a.5.5 0 1 1 0-1c.786 0 1.024-.783 1.166-3.587c.07-1.407.105-1.926.196-2.681c.03-.25.063-.49.102-.724c.334-2.041 1.546-3.313 3.556-3.792a2 2 0 0 1 3.96 0c2.01.479 3.222 1.75 3.557 3.792a17 17 0 0 1 .102.724c.09.755.125 1.274.196 2.681c.14 2.804.379 3.587 1.165 3.587a.5.5 0 1 1 0 1c-.604 0-1.033-.147-1.341-.5M5.5 14h4a2 2 0 1 1-4 0" />
                  </svg>
                </div>
              </Dropdown>
            </div>
            <Dropdown overlay={menu} trigger={['click']}>
              <span style={{ cursor: 'pointer', display: 'flex', alignItems: 'center' }}>


                <Avatar
                  alt={userBidInfo?.userfullname}
                  className='bid-avatar'
                  src={docurlchat + userBidInfo.profileimg_path + "/" + userBidInfo.profileimg}
                >
                  {userBidInfo?.userfullname?.charAt(0)}
                </Avatar>

                <DownOutlined style={{ marginLeft: '8px' }} />
              </span>
            </Dropdown>
          </div>
        </div>
      </header>
      <div className="new-breadcrumb">

      </div>
    </>
  )
}

export default Header