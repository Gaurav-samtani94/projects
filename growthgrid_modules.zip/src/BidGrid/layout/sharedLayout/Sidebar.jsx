// @ts-nocheck
import React, { useCallback, useEffect, useState } from 'react'
import { DashboardOne, SettingTwo, DocumentFolder, AddOne, ViewList, ShareOne, UserBusiness, FolderClose, OnlineMeeting, PullRequests } from '@icon-park/react';
import { Button, Menu } from 'antd';
import '../../assets/css/new/aside.scss'
import { useSelector } from 'react-redux';
import { Link, useLocation, useNavigate } from 'react-router-dom';
// import ROUTES from 'BidGrid/bidRoute/bidRoutes';
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import ROUTES from 'Constants/Routes';
import { docurlchat } from 'utils/configurable';

function getItem(label, key, icon, children, type) {
  return {
    key,
    icon,
    children,
    label,
    type,
  };
}


function useScrollDirection() {
  const [scrollDirection, setScrollDirection] = useState(null);

  useEffect(() => {
    let lastScrollY = window.pageYOffset;

    const updateScrollDirection = () => {
      const scrollY = window.pageYOffset;
      const direction = scrollY > lastScrollY ? "down" : "up";
      if (
        direction !== scrollDirection &&
        (scrollY - lastScrollY > 10 || scrollY - lastScrollY < -10)
      ) {
        setScrollDirection(direction);
      }
      lastScrollY = scrollY > 0 ? scrollY : 0;
    };
    window.addEventListener("scroll", updateScrollDirection); // add event listener
    return () => {
      window.removeEventListener("scroll", updateScrollDirection); // clean up
    };
  }, [scrollDirection]);

  return scrollDirection;
}




const navMenus = [
  {
    key: ROUTES?.DASHBOARD,
    label: "Dashboard",
    icon: <DashboardOne theme="outline" size="24" fill="#313131" strokeWidth={3} strokeLinecap="butt" />
  },
  {
    key: "Add",
    label: "Add",
    icon: <AddOne theme="outline" size="22" fill="#313131" strokeWidth={3} strokeLinecap="butt" />,
    children: [
      {
        key: ROUTES.LIVE_TENDERS,
        label: "Live Tender"
      },

      {
        key: ROUTES.PROSPECTIVE_TENDER,
        label: "Prospective Tender"
      },

      {
        key: ROUTES.BANKGUARANTEE,
        label: "Bank Guarantee"
      },
      { label: 'Team Requisitions', key: ROUTES?.TeamRequisitionDesignation },
      { label: 'Requisition Category', key: ROUTES?.TeamRequisitionDesignationCategory },

    ]
  },
  {
    key: "Tenders",
    label: "Tenders",
    icon: <DocumentFolder theme="outline" size="22" fill="#313131" strokeWidth={3} strokeLinecap="butt" />,
    children: [
      {
        key: ROUTES.New_assigne,
        label: "All Tender"
      },
      {
        key: ROUTES.MIS,
        label: "MIS"
      },
      {
        key: ROUTES.Trash,
        label: "Trash"
      }
    ]
  },
  {
    key: "Personal",
    label: "Personal",
    icon: <ViewList theme="outline" size="22" fill="#313131" strokeWidth={3} strokeLinecap="butt" />,
    children: [
      {
        key: ROUTES.ToDo,
        label: "Todo"
      },
      {
        key: ROUTES.WISHLIST,
        label: "Wishlist"
      },
      {
        key: ROUTES.Personal_reminder,
        label: "Reminder"
      },
    ]
  },
  {
    key: ROUTES?.BRIEFCASE,
    label: "Briefcase",
    icon: <FolderClose theme="outline" size="22" fill="#313131" strokeWidth={3} />
  },

  {
    key: ROUTES?.REQUEST,
    label: "Request",
    icon: <PullRequests theme="outline" size="22" fill="#313131" strokeWidth={3} strokeLinecap="butt" />
  },
  {
    key: ROUTES?.document_share,
    label: "Document Share",
    icon: <ShareOne theme="outline" size="22" fill="#313131" strokeWidth={3} strokeLinecap="butt" />
  },
]
const masterMenuItem = navMenus.find(item => item.key === "master");

if (masterMenuItem) {

  masterMenuItem.children.sort((a, b) => a.label.localeCompare(b.label));
}



const Sidebar = ({ collapsed }) => {

  const scrollDirection = useScrollDirection();

  const navigate = useNavigate()
  const location = useLocation()
  // console.log("loc", location.pathname)
  const { userBidInfo } = useSelector((state) => state.userDetails)
  const { bidMenu } = useSelector((state) => state.bidMenuVal)
  const [menuBar, setMenuBar] = useState([])
  const [active, setActive] = useState('')
  useEffect(() => {
    const filterMenu = bidMenu?.filter(item => item?.menu_name !== 'Setting' && item?.menu_name !== 'Profile' && item?.is_view !== '2')
    let menuData = filterMenu?.map(item => {
      const filteredItems = item?.childUrls?.filter(item => window?.location?.pathname?.includes(item));
      console.log(filteredItems)
      if (item?.children?.length > 0) {
        return {
          key: item?.action_url,
          label: item?.menu_name,
          icon: filteredItems?.length > 0 ? <img src={`${docurlchat}${item?.active_icon}`} alt="" width={24} height={24} /> : <img src={`${docurlchat}${item?.icon_path}`} alt="" width={24} height={24} />,
          children: item?.children?.map(val => {
            return {
              key: val?.action_url,
              label: val?.menu_name,
            }
          })
        }
      } else {
        return {
          key: item?.action_url,
          label: item?.menu_name,
          icon: window?.location?.pathname?.includes(item.action_url) ? <img src={`${docurlchat}${item?.active_icon}`} alt="" width={24} height={24} /> : <img src={`${docurlchat}${item?.icon_path}`} alt="" width={24} height={24} />,
        }
      }
    })
    console.log(menuData)

    const findActive = menuData?.find(val => window?.location?.pathname?.includes(val.key))
    setActive(findActive?.key)
    setMenuBar(menuData)
  }, [bidMenu, window.location.pathname])



  const handleNavigate = (d) => {
    setActive(d.key)
    navigate(d.key)
  }



  // useEffect(() => {
  //   if (userBidInfo?.bg_mstr_role?.role_name === 'System Admin') {

  //     setMenuBar([
  //       ...menuBar,
  //       {
  //         key: ROUTES?.EMPLOYEELIST,
  //         label: "Employee List",
  //         icon: <UserBusiness theme="outline" size="22" fill="#313131" strokeWidth={3} strokeLinecap="butt" />
  //       }
  //     ]);
  //     // Add the "Employee List" menu item
  //   } else {
  //     setMenuBar()
  //   }
  // }, [userBidInfo?.bg_mstr_role?.role_name]);



  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
    });
  };
  const scrollToBottom = () => {
    const targetPosition = Math.max(
      0,
      document.documentElement.scrollHeight - window.innerHeight - 0
    );

    window.scroll({
      top: targetPosition,
      behavior: "smooth",
    });
  };


  return (
    <>
      <aside className='aside' style={{ width: collapsed ? '100px' : '300px' }}>

        <div className="brandLogo_wrap">
          {collapsed
            ? <Link to={ROUTES?.DASHBOARD} >
              <img
                className="bd_main_sub_s_img"
                src={`${docurlchat}${userBidInfo.thumbnailPath}/${userBidInfo.thumbnailName}`}
                alt="brand  logo small"
                width="45px"
                className="mx-auto d-block mb-3"
              />
            </Link>
            : <Link to={ROUTES?.DASHBOARD}>
              <img
                className="ms-3"
                src={`${docurlchat}${userBidInfo.docpath}/${userBidInfo.docname}`}
                alt={userBidInfo.docname}
                // width={180}
                height={45}
              />
            </Link>
          }
        </div>

        <Menu
          // defaultOpenKeys={window.location.pathname}
          selectedKeys={active}
          mode="inline"
          theme="light"
          inlineCollapsed={collapsed}
          items={menuBar}
          className='sidebar'
          onSelect={handleNavigate}
        />
      </aside>
      <div
        className="bd_topScoll"
        onClick={scrollToTop}
        style={{ display: scrollDirection === "down" ? "flex" : "none" }}
      >
        <ArrowUpwardIcon />
      </div>
      <div
        className="bd_downScoll"
        onClick={scrollToBottom}
        style={{ display: scrollDirection === "up" ? "flex" : "none" }}
      >
        <ArrowDownwardIcon />
      </div>
    </>
  )
}

export default Sidebar