// @ts-nocheck
import React, { lazy, Suspense, useState, useEffect } from 'react';
import io from 'socket.io-client';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import SendIcon from '@mui/icons-material'
import './assets/css/app.scss';
import Dashboard from "./pages/BDDashboard/Dashboard";
import TaskManager from "./pages/TaskManager";
import TaskAssigine from "./pages/TaskAssigine";
import AddUnit from "./pages/master/addUnit/AddUnit";
import WorkDistribution from './pages/WorkDistribution/WorkDistribution';
import Calendar from "./pages/Calendar/Calendar";
import NewAssigne from "./pages/NewTenderAssign";
import Briefcase from "./pages/Briefcase";
import ProspectiveTender from "./pages/AddTenders/ProspectiveTenders/ProspectiveTender";
import LiveTenders from "./pages/AddTenders/LiveTenders/LiveTenders";
import Jobtitle from "./pages/master/AddJobtitle/Jobtitle";
import Prefix from "./pages/master/AddPrefix/Prefix";
import Role from "./pages/master/AddRole/Role";
import Designation from "./pages/master/AddDesignation/Designation";
import TeamRequisitionDesignation from "./pages/master/TeamRequisitionDesignation/TeamRequisitionDesignation"
import Currency from "./pages/master/AddCurrency/Currency"
import Language from "./pages/master/AddLanguage/Language"
import Timezone from "./pages/master/AddTimezone/Timezone";
import { useNavigate } from 'react-router-dom';
import AssignSector from "./pages/master/AssignSector/AssignSector";
import Keyword from "./pages/master/Addkeyword/Keyword";
import TenderScope from './pages/master/tenderscope/tenderscope';
import FundingAgency from './pages/master/FundingAgency/FundingAgency';
import Company from "./pages/AddTenders/AddCompany/Company";
import Error404 from 'common/pages/Error404/Error404';
import Logo from "./pages/master/AddLogo/Logo";
import Reminder from "./pages/Reminder";
import Wishlist from "./pages/wishlist";
import Profile from "./pages/Profile/Profile";
import UpdateProfile from './pages/EmployeeProfile/UpdateProfile';
import Department from './pages/master/Department/Department';
import Phase from "./pages/master/Phase/Phase"
import CountryList from "./pages/master/CountryList/CountryList"
import StateList from './pages/master/StateList/StateList';
import CityList from './pages/master/CityList/CityList';
import ContinentList from './pages/master/ContinentList/ContinentList';
import RegionList from "./pages/master/RegionList/RegionList"
import Employee from './pages/master/Employee/Employee';
import Tender_service from "./pages/master/Tender_service/Tender_service"
import EmployeeStatus from './pages/master/EmployeeStatus/EmployeeStatus';
import Blood_Group from './pages/BloodGroup/BloodGroup';
import Fileshare from './pages/Fileshare';
import AddTenderStatus from './pages/master/AddStatus/AddTenderStatus';
import Footerchat from './pages/chat/chat';
import Client from './pages/master/Client/Client'
import Consortium from './pages/master/Consortium/Consortium'
// import { ClientList } from 'Services/bidgrid/master/client/Client';
import Nationality from "./pages/master/Nationality/Nationality"
import Gender from './pages/master/Gender/Gender';
import SubSector from './pages/master/subSector/SubSector';
import BidGridMaster from 'Includes/BidGridMaster';
import BdLogin from './pages/login/Login';
import '../assests/style.css';
import '../assests/styleResponsive.css';
import ChatboatIcon from './components/Chatboaticon/ChatboatIcon';
import BloodGroup from './pages/BloodGroup/BloodGroup';
import { ProtectedRoutesBid } from 'utils/ProtectedRoutesBid';
import TenderServices from './pages/master/Tender_service/Tender_service';
import ChatBoat from './ChatGrid/App'
import BIDGRIDROUTES from './bidRoute/bidRoutes';
import BdTenderDetails from './pages/BdTenderDetails/BdTenderDetails';
import ToDo from './pages/Todo/Todo';
import ConFiguration from './pages/Configuration/configuration';
import EmployeeList from './pages/EmployeeList';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import RolePermissions from './pages/master/RolePermissions';
import SettingsLayout from './pages/setting/SettingsLayout';
import MeetingSchedules from 'BidGrid/pages/MeetingSchedules';
import PrepareFactSheet from './pages/PrepareFactSheet';
import Doctrol from './pages/master/Doctrol/Doctrol';
import ROUTES from 'Constants/Routes';
import BdMeetingSchedule from './pages/BdTenderDetails/BdRequest';
import BdRequest from './pages/BdTenderDetails/BdRequest';
import { bidBaseUrl, socketBaseUrl } from 'utils/configurable';
import BankGuarantee from './pages/AddTenders/BankGuarantee/BankGuarantee';
import Bank from './pages/master/Bank/Bank';
import BdHeader from '../BidGrid/components/Includes/BdHeader'
import TeamRequisitionDesignationCategory from './pages/master/TeamRequisitionDesignationCategory/TeamRequisitionDesignationCategory';
import Mis from './pages/Mis/Mis';
import RootLayout from './layout/RootLayout';
// import PdfUpload from './pages/Pdf/PdfUpload';
import Request from './pages/Request';
import TrashFile from './pages/trash/TrashFile';
import WidgetTab from './pages/master/WidgetTab';
import TenderCycleAction from './pages/master/TenderCycleAction';
import ConfigurationLab from './pages/master/ConfigurationLab';
import PrefixGenerated from './pages/master/AddPrefix/PrefixGenerated';
import TenderCompany from './pages/AddTenders/TenderCompany/TenderCompany';
import { docurlchat } from 'utils/configurable';
import BidNotification from './pages/BidNotification';
import { store } from '../Redux/store'
// import { NotifivcatioPush } from '../firebase'
const BdFooter = lazy(() => import('../BidGrid/components/Includes/BdFooter'));

const BidGridApp = () => {

    const dispatch = useDispatch()
    const { bidgridData } = useSelector((state) => state.loginData)
    const { userBidInfo } = useSelector((state) => state?.userDetails)

    const navigate = useNavigate()

    const handleBeforeUnload = () => {
        const state = store.getState();
        console.log(state)
        const socketInstance = state.socket.socket;

        if (socketInstance && socketInstance.connected) {
            socketInstance.disconnect();
        }
    };

    useEffect(() => {
        if (bidgridData?.data?.id) {
            const socketInstance = io(socketBaseUrl, {
                transports: ['websocket'],
                query: {
                    user_id: bidgridData?.data?.id
                }
            });
            socketInstance.on("connect", () => {
                console.log("connected");
                dispatch({
                    type: 'SET_SOCKET',
                    payload: { socket: socketInstance, isConnected: socketInstance?.connected },
                });
            });
            window.addEventListener('beforeunload', handleBeforeUnload);
            socketInstance.on('disconnect', () => {
                console.log('Disconnected from server!');
                dispatch({
                    type: 'SET_SOCKET',
                    payload: { socket: null, isConnected: false },
                });
            });
            return () => {
                if (socketInstance.connected) {
                    socketInstance.disconnect();
                }
                window.removeEventListener('beforeunload', handleBeforeUnload);
            };
        }
    }, [bidgridData]);


    const checkAuth = () => {
        let authForLogin = localStorage.getItem('bidToken');
        const currentPath = window.location.pathname;
        if (currentPath === '/bidgrid') {
            navigate(ROUTES?.BD_LOGIN, { replace: true })
        }
        if (authForLogin) {


            if (currentPath === ROUTES?.BD_LOGIN) {
                navigate(ROUTES?.DASHBOARD, { replace: true })
                window.open(ROUTES?.DASHBOARD, "_blank")
            }

        }
    };

    useEffect(() => {
        checkAuth()
    }, [])

    useEffect(() => {
        document.title = 'Bid Grid'
    }, []);

    useEffect(() => {

        const favicon = document.querySelector('link[rel="icon"]')
        if (favicon) {
            favicon.href = `${docurlchat}${userBidInfo.thumbnailPath}/${userBidInfo.thumbnailName}`

        }
    }, [userBidInfo])

    return (
        <>
            <BidGridMaster />
            {/* <Suspense fallback={<div></div>}> */}
            {/* <NotifivcatioPush.OnMessageListener /> */}
            {/* {sessionStorage.getItem("headerHide") ==='true' ? <></> : <BdHeader />
            } */}
            {/* <BdHeader /> */}
            {/* </Suspense> */}
            <RootLayout>
                <Routes>
                    <Route path='*' element={<Error404 />} />
                    <Route path='/error' element={<Error404 />} />
                    <Route path='/' element={<BdLogin />} />
                    <Route path={BIDGRIDROUTES?.BD_LOGIN} element={<BdLogin />} />
                    <Route path={BIDGRIDROUTES?.DASHBOARD} element={<ProtectedRoutesBid><Dashboard /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.TASK_MANAGER} element={<ProtectedRoutesBid><TaskManager /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.Task_assigine} element={<ProtectedRoutesBid><TaskAssigine /></ProtectedRoutesBid>} />

                    <Route path={BIDGRIDROUTES?.WORKLOAD_DISTRIBUTION} element={<ProtectedRoutesBid><WorkDistribution /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.CALENDAR} element={<ProtectedRoutesBid><Calendar /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.LIVE_TENDERS} element={<ProtectedRoutesBid><LiveTenders /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.PROFILE} element={<ProtectedRoutesBid><Profile /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.EMP_PROFILE} element={<ProtectedRoutesBid><UpdateProfile /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.New_assigne} element={<ProtectedRoutesBid><NewAssigne /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.document_share} element={<ProtectedRoutesBid><Fileshare /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.PROSPECTIVE_TENDER} element={<ProtectedRoutesBid><ProspectiveTender /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.Personal_reminder} element={<ProtectedRoutesBid><Reminder /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.WISHLIST} element={<ProtectedRoutesBid><Wishlist /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.CHATBOAT} element={<ProtectedRoutesBid><ChatBoat /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.BD_TENDERDETAILS} element={<ProtectedRoutesBid><BdTenderDetails /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.ToDo} element={<ProtectedRoutesBid><ToDo /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.EMPLOYEELIST} element={<ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><EmployeeList /></ProtectedRoutesBid>} />


                    <Route path={BIDGRIDROUTES?.MEETING} element={<ProtectedRoutesBid><MeetingSchedules /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.PREPAREFACTSHEET} element={<ProtectedRoutesBid><PrepareFactSheet /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.BDREQUEST} element={<ProtectedRoutesBid><BdRequest /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.BANKGUARANTEE} element={<ProtectedRoutesBid><BankGuarantee /></ProtectedRoutesBid>} />

                    <Route path={BIDGRIDROUTES?.briefcase} element={<ProtectedRoutesBid><Briefcase /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.MIS} element={<ProtectedRoutesBid><Mis /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.Trash} element={<ProtectedRoutesBid><TrashFile /></ProtectedRoutesBid>} />
                    {/* <Route path={BIDGRIDROUTES?.PDF} element={<ProtectedRoutesBid><PdfUpload /></ProtectedRoutesBid>} /> */}
                    <Route path={BIDGRIDROUTES?.REQUEST} element={<ProtectedRoutesBid><Request /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.NOTIFICATION} element={<ProtectedRoutesBid><BidNotification /></ProtectedRoutesBid>} />


                    {/* masters routes */}

                    <Route path={BIDGRIDROUTES?.ROLEPERMISSIONS}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><RolePermissions /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.WIDGETSACTION}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><WidgetTab /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.TENDERCYCLEACTION}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><TenderCycleAction /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.CONFIGURATIONLEVEL}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><ConfigurationLab /></ProtectedRoutesBid></SettingsLayout>} />


                    <Route path={BIDGRIDROUTES?.ADDUNIT}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><AddUnit /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.BANK}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}> <Bank /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.JOBTITLE}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Jobtitle /></ProtectedRoutesBid></SettingsLayout>} />
                    {/* <Route path={BIDGRIDROUTES?.PREFIX}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Prefix /></ProtectedRoutesBid></SettingsLayout>} /> */}
                    <Route path={BIDGRIDROUTES?.PREFIXNO}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><PrefixGenerated /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.ROLE}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Role /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.DESIGNATION}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Designation /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.TeamRequisitionDesignation}
                        element={<ProtectedRoutesBid ><TeamRequisitionDesignation /></ProtectedRoutesBid>} />
                    <Route path={BIDGRIDROUTES?.TeamRequisitionDesignationCategory}
                        element={<ProtectedRoutesBid ><TeamRequisitionDesignationCategory /></ProtectedRoutesBid>} />

                    <Route path={BIDGRIDROUTES?.CURRENCY}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Currency /></ProtectedRoutesBid></SettingsLayout>} />
                    {/* <Route path={BIDGRIDROUTES?.LANGUAGE}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Language /></ProtectedRoutesBid></SettingsLayout>} /> */}
                    {/* <Route path={BIDGRIDROUTES?.TIMEZONE}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}> <Timezone /></ProtectedRoutesBid></SettingsLayout>} /> */}
                    <Route path={BIDGRIDROUTES?.ASSIGNSECTOR}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><AssignSector /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.KEYWORD}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Keyword /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.COMPANY}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Company /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.TENDER_COMPANY}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><TenderCompany /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.LOGO}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Logo /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.DEPARTMENT_MANAGE}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Department /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.PHASE}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Phase /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.TENDER_STATUS}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><AddTenderStatus /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.BD_CLIENT}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Client /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.CONSORTIUM}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Consortium /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.NATIONALITY}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Nationality /></ProtectedRoutesBid></SettingsLayout>} />
                    {/* <Route path={BIDGRIDROUTES?.GENDER}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Gender /></ProtectedRoutesBid></SettingsLayout>} /> */}
                    <Route path={BIDGRIDROUTES?.SUBSECTOR}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><SubSector /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.COUNTRYLIST}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><CountryList /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.STATELIST}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><StateList /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.CITYLIST}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><CityList /></ProtectedRoutesBid></SettingsLayout>} />
                    {/* <Route path={BIDGRIDROUTES?.CONTINENTLIST}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><ContinentList /></ProtectedRoutesBid></SettingsLayout>} /> */}
                    <Route path={BIDGRIDROUTES?.REGIONLIST}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><RegionList /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.DOCTROL}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><Doctrol /></ProtectedRoutesBid></SettingsLayout>} />
                    {/* <Route path={BIDGRIDROUTES?.EMPLOYEE} 
                    element={<SettingsLayout><ProtectedRoutesBid><Employee /></ProtectedRoutesBid></SettingsLayout>} /> */}
                    {/* <Route path={BIDGRIDROUTES?.EMPLOYEE_STATUS}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><EmployeeStatus /></ProtectedRoutesBid></SettingsLayout>} /> */}
                    {/* <Route path={BIDGRIDROUTES?.BLOODGROUP}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><BloodGroup /></ProtectedRoutesBid></SettingsLayout>} /> */}
                    <Route path={BIDGRIDROUTES?.TENDER_SERVICES}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><TenderServices /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.TENDER_SCOPE}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><TenderScope /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.FUNDING_AGENCY}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}>< FundingAgency /></ProtectedRoutesBid></SettingsLayout>} />
                    <Route path={BIDGRIDROUTES?.ConFiguration}
                        element={<SettingsLayout><ProtectedRoutesBid isSystemAdmin={userBidInfo?.bg_mstr_role?.role_name}><ConFiguration /></ProtectedRoutesBid></SettingsLayout>} />

                </Routes>
            </RootLayout>
            <Suspense fallback={<div></div>}>

                {/* {sessionStorage.getItem("headerHide") ==='true' ? <></> : <BdFooter />
            } */}
                {/* <BdFooter /> */}
            </Suspense>
            <ChatboatIcon />
        </>



    )
}
export default BidGridApp;


