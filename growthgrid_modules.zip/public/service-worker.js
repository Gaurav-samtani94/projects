// @ts-nocheck
self.addEventListener('push', function (event) {
    const payload = event.data.json();
    const title = payload.notification.title;
    const options = {
        body: payload.notification.body,
    };
    event.waitUntil(self.registration.showNotification(title, options));
});
