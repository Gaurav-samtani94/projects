importScripts('https://www.gstatic.com/firebasejs/8.2.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.2.0/firebase-messaging.js');

// Initialize the Firebase app in the service worker by passing the generated config
const firebaseConfig = {
    apiKey: "AIzaSyAdl8ONQCwHeUCh-oDI0h6Utf_c5AtUHP8",
    authDomain: "chatweb-14c48.firebaseapp.com",
    projectId: "chatweb-14c48",
    storageBucket: "chatweb-14c48.appspot.com",
    messagingSenderId: "116363121663",
    appId: "1:116363121663:web:4a2a499f36124de8b38dca",
    measurementId: "G-JW1NMVD0RC"
};

firebase.initializeApp(firebaseConfig);

// Retrieve firebase messaging
const messaging = firebase.messaging();
