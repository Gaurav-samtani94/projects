const jwt = require('jsonwebtoken');

const authorization = async (request, reply) => {
  try {
    const token = request.headers.authorization;

    if (!token) {
      return reply.code(401).send({ message: 'Not Authorized or No Token Provided' });
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // Attach user info to request
    request.user = decoded;
  } catch (error) {
    return reply.code(401).send({ message: 'Not authorized, token failed' });
  }
};

module.exports = { authorization };
