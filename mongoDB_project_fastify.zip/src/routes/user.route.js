const userController = require('../controllers/user.controller');
const {authorization} = require('../middleware/authMiddleware');

async function userRoutes(fastify, options) {

  fastify.register(async function (protectedRoutes) {
    protectedRoutes.addHook('preHandler', authorization);

    protectedRoutes.post('/users', userController.createUser);
    protectedRoutes.get('/users', userController.getUsers);
    protectedRoutes.get('/users/:id', userController.getUserById);
    protectedRoutes.put('/users/:id', userController.updateUser);
    protectedRoutes.delete('/users/:id', userController.deleteUser);
  });
  
  fastify.post('/login',userController.loginUser);
}

module.exports = userRoutes;
