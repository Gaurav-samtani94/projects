const User = require('../models/user.model');
const Joi = require('joi');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.loginUser = async (req, res) => {
    const Schema = Joi.object({
      email: Joi.string().email().required(),
      password: Joi.string().required()
    });
  
    const DataToValidate = {
      email: req.body.email,
      password: req.body.password
    };
  
    const result = Schema.validate(DataToValidate);
    if (result.error) {
      return res.status(400).send({
        message: result.error.details[0].message,
        status: "0",
        success: false,
        error: true
      });
    }
  
    try {
      const user = await User.findOne({
        email: req.body.email,
        isActive: true // Assuming MongoDB field is isActive: Boolean
      });
  
      if (!user) {
        return res.status(401).send({
          message: 'Invalid email or password 999',
          success: false,
          status: '0',
          error: true
        });
      }
  
      const isMatch = await bcrypt.compare(req.body.password, user.password);
      if (!isMatch) {
        return res.status(401).send({
          message: 'Invalid email or password',
          success: false,
          status: '0',
          error: true
        });
      }
  
      // const token = jwt.sign(
      //   { userId: user._id },
      //   JWT_SECRET,
      //   { expiresIn: '30d' }
      // );
      const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '30d' });

  
      return res.status(200).send({
        message: 'Login successful',
        success: true,
        status: '1',
        user: user,
        token: token
      });
  
    } catch (error) {
      return res.status(500).send({
        message: 'Something went wrong',
        success: false,
        status: '0',
        error: error.message
      });
    }
  };

exports.createUser = async (req, reply) => {
  try {
    console.log("sssssssssssss");
    const user = new User(req.body);
    const result = await user.save();
    reply.code(201).send(result);
  } catch (err) {
    // console.log(err.errorResponse.errInfo,"=================");
    if (err.name === 'ValidationError') {
    // Extract field-level error messages
    const errors = Object.values(err.errors).map(e => e.message);
    reply.code(400).send({ error: errors });
    } else {
    reply.code(500).send({ error: err.message });
    }
    reply.code(500).send({ error: err.message });
  }
};

exports.getUsers = async (req, reply) => {
  try {
    const users = await User.find();
    reply.send(users);
  } catch (err) {
    reply.code(500).send({ error: err.message });
  }
};

exports.getUserById = async (req, reply) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return reply.code(404).send({ error: 'User not found' });
    reply.send(user);
  } catch (err) {
    reply.code(500).send({ error: err.message });
  }
};

exports.updateUser = async (req, reply) => {
  try {
    const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!user) return reply.code(404).send({ error: 'User not found' });
    reply.send(user);
  } catch (err) {
    reply.code(500).send({ error: err.message });
  }
};

exports.deleteUser = async (req, reply) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return reply.code(404).send({ error: 'User not found' });
    reply.send({ message: 'User deleted successfully' });
  } catch (err) {
    reply.code(500).send({ error: err.message });
  }
};
