const fastify = require('fastify')({ logger: true });
const cors = require('@fastify/cors');
const connectDB = require('./src/config/db');
const userRoutes = require('./src/routes/user.route');
require('dotenv').config();

const startServer = async () => {
  try {
    await connectDB();
    await fastify.register(cors, { origin: '*' });
    await fastify.register(userRoutes);
    // await fastify.register(userRoutes, { prefix: '/api/user' });

    await fastify.listen({ port: 3000 });
    console.log('Server running at http://localhost:3000');
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

startServer();
