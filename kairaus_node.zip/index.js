require('./apps/models/master/associations'); // Import associations
const express = require('express');
const session = require('express-session')
const crypto = require('crypto')
const path = require('path');
require('dotenv').config();
var multer = require('multer');
const UserRoutes = require('./apps/config/routes')
const paymentRoutes = require('./apps/config/ccavenueRoutes')
const InventoryRoutes = require('./apps/config/inventoryRoute')
const fileUpload = require('express-fileupload');
const app = express();
app.use(fileUpload());
var upload = multer();
const port = process.env.PORT || 3011;
app.use(express.json());

const secret = crypto.randomBytes(32).toString('hex');
app.use('/uploads', express.static('./uploads'));
app.use(session({
    secret: secret,
    resave: false,
    saveUninitialized: false,
}));

const cors = require('cors');
app.use(cors(

));
// const allowedOrigins = ['https://files.growthgrids.com'];

// app.use(cors({
//     origin: function (origin, callback) {
//         // Allow requests with no origin (like mobile apps or curl requests)
//         if (!origin) return callback(null, true);
//         if (allowedOrigins.indexOf(origin) === -1) {
//             const msg = 'The CORS policy for this site does not allow access from the specified origin.';
//             return callback(new Error(msg), false);
//         }
//         return callback(null, true);
//     }
// }));
// const allowedOrigins = ['https://files.growthgrids.com'];

// app.use(cors({
//     origin: function (origin, callback) {
//         // Block requests with no origin (like mobile apps or Postman requests)
//         if (!origin) {
//             const msg = 'Requests without an origin are not allowed.';
//             return callback(new Error(msg), false);
//         }
//         if (allowedOrigins.indexOf(origin) === -1) {
//             const msg = 'The CORS policy for this site does not allow access from the specified origin.';
//             return callback(new Error(msg), false);
//         }

//         return callback(null, true);
//     }
// }));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));



app.get('/', (req, res) => {
    // res.send("Hello World");
    // res.redirect('https://kairaus.com');
});
app.use('/api/inventory', InventoryRoutes);
app.use('/api/user/', UserRoutes);
app.use('/payment/', paymentRoutes);
app.use((req, res) => {
    // res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).json({
    //     message: 'Not Found',
    //     error: true,
    //     success: false,
    //     status: '0',
    // });
    res.redirect('https://kairaus.com');

});
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});
