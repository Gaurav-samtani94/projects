// utils/ccavenueUtils.js
const crypto = require('crypto');
require('dotenv').config();
const config = require('../config/config')
let initOptions = {
  MERCHANT_ID: config.ccavenue.merchantId,
  ACCESS_CODE: config.ccavenue.accessCode,
  WORKING_KEY: config.ccavenue.workingKey,
  REDIRECT_URL: config.ccavenue.redirectUrl || process.env.URL,
};

function configure(options) {
  initOptions = { ...initOptions, ...options };
}

function validate(key) {
  return Boolean(initOptions[key]);
}

function throwError(requirement) {
  throw new Error(`${requirement} is required to perform this action`);
}

function encrypt(plainText) {
  if (!validate('WORKING_KEY')) {
    throwError('Working Key');
  }
  if (!plainText) {
    throwError('Plain text');
  }

  const m = crypto.createHash('md5');
  m.update(initOptions.WORKING_KEY);
  const key = m.digest();
  const iv = Buffer.from('\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f');
  const cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
  let encoded = cipher.update(plainText, 'utf8', 'hex');
  encoded += cipher.final('hex');
  return encoded;
}

function decrypt(encText) {
  if (!validate('WORKING_KEY')) {
    throwError('Working Key');
  }
  if (!encText) {
    throwError('Encrypted text');
  }

  const m = crypto.createHash('md5');
  m.update(initOptions.WORKING_KEY);
  const key = m.digest();
  const iv = Buffer.from('\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f');
  const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
  let decoded = decipher.update(encText, 'hex', 'utf8');
  decoded += decipher.final('utf8');
  return decoded;
}

function redirectResponseToJson(response) {
  if (!response) {
    throwError('CCAvenue encrypted response');
  }

  const ccavResponse = decrypt(response);
  return ccavResponse.split('&').reduce((acc, pair) => {
    const [key, value] = pair.split('=');
    acc[key] = value;
    return acc;
  }, {});
}

function getEncryptedOrder(orderParams) {
  if (!validate('MERCHANT_ID')) {
    throwError('Merchant ID');
  }
  if (!orderParams) {
    throwError('Order Params');
  }

  const data = `merchant_id=${initOptions.MERCHANT_ID}&` +
    Object.entries(orderParams)
      .map(([key, value]) => `${key}=${value}`)
      .join('&');
  return encrypt(data);
}

module.exports = {
  configure,
  encrypt,
  decrypt,
  redirectResponseToJson,
  getEncryptedOrder
};