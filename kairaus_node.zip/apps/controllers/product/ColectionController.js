const Product = require("../../models/master/Product");
const ProductMedia = require("../../models/master/ProductMedia");
const Wishlist = require("../../models/master/Wishlist");
const AssignPageSlider = require('../../models/master/AssignPageSlider');
const PageSlider = require('../../models/master/PageSlider');
const PageSliderImages = require('../../models/master/PageSliderImages');
const ProductNotifyModel = require("../../models/master/ProductNotifyModel");
const SiteSellerProducts = require("../../models/master/SiteSellerProducts");
const ProductAttributes = require("../../models/master/ProductAttributes");
const Category = require("../../models/master/Category");
require('dotenv').config();
const getCurrentDateTime = () => new Date();
const NavigationMenu = require("../../models/master/NavigationMenu");
const Op = require('sequelize').Op;
const sequelize = require('sequelize');
const Joi = require("joi");
const ProductAttributeValue = require("../../models/master/ProductAttributeValue");
const SearchKeywordTemplate = require("../../models/master/SearchKeywordTemplate");
const Cart = require("../../models/master/Cart");
const OrderDiscountCoupon = require("../../models/master/OrderDiscountCoupon");
const Coupon = require("../../models/master/Coupon");
const Order = require("../../models/master/Order");
const { group } = require("console");
const BuyNow = require("../../models/master/BuyNow");
const HomeCollectionModel = require('../../models/master/HomeCollectionMaster')
const CollectionAssignProductsModel = require('../../models/master/CollectionAssignProductsModel')

// HomeCollectionMasterModel

//get category detail
const GetCategoryDetail = async (req, res) => {

    const slug = req.params.slug;
    const user_id = req.body.user_id || 0;
    try {
        const page_number = req.body.page_number || 1;
        const limit = req.body.limit || 100;
        const offset = (page_number - 1) * limit;

        const color_id = req.body.color_id;
        const min_price = req.body.min_price;
        const max_price = req.body.max_price;
        const sorting = req.body.sorting;
        const remove_stock = req.body.remove_stock;
        const material_id = req.body.material_id || 0;
        const discount = req.body.discount;
        const type_ids = req.body.type_ids || 0;
        var stockQuantity = (remove_stock == 1) ? { stock_quantity: { [sequelize.Op.gt]: 0 } } : '';


        let sortBy = [['stock_quantity', 'DESC'], [sequelize.literal('TRIM(product_name)'), 'ASC']];
        if (sorting == 'a-z') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'ASC']];
        } else if (sorting == 'z-a') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'DESC']];
        } else if (sorting == 'new_arrival') {
            sortBy = [['is_home_new_arrival', 'DESC']];
        } else if (sorting == 'low_to_high') {
            sortBy = [['price', 'ASC']];
        } else if (sorting == 'high_to_low') {
            sortBy = [['price', 'DESC']];
        }
        var dynamicFilters = [];



        let slugIdInMasterCollection = await HomeCollectionModel.findOne({
            where: { slug: slug, status: '1' },
            // attributes: ['id', ['collection_name', 'name'], ['collection_image', 'image'], 'slug','banner_image']
            attributes: ['id', ['collection_name', 'name'], ['banner_image', 'image'], 'slug',['collection_image', 'small_image']]

        })

        slugIdInMasterCollection = slugIdInMasterCollection.toJSON();
        slugIdInMasterCollection.assign_slider = null

        if (max_price != 'ALL') {
            if (min_price || max_price) {
                dynamicFilters.push({
                    price: {
                        [Op.gte]: min_price,
                        [Op.lte]: max_price,
                    },
                });
            }
        }


        if (discount) {
            dynamicFilters.push({
                discount: {
                    [Op.gte]: discount,
                },
            });
        }


        if (material_id) {
            var materialid = material_id.split(",");
            dynamicFilters.push({
                material_id: {
                    [Op.in]: materialid,
                },
            });
        }

        if (type_ids) {
            var typeId = type_ids.split(',');
            dynamicFilters.push({
                type_id: {
                    [Op.in]: typeId,
                },
            });
        }
        let productIdArray = [];
        if (color_id) {
            const colorIds = color_id.split(',');
            const productAttributes = await ProductAttributes.findAll({
                where: {
                    attr_val_id: { [Op.in]: colorIds },
                    attr_type_id: 2
                },
                attributes: ['product_id'],
            });
            productIdArray = productAttributes.map(attribute => attribute.product_id);
            if (productIdArray.length > 0) {
                dynamicFilters.push({
                    id: {
                        [Op.in]: productIdArray,
                    },
                });
            }
        }

        let CollectionMasterArray = [];
        if (slugIdInMasterCollection) {
            const result = await CollectionAssignProductsModel.findAll({
                where: {
                    collection_id: slugIdInMasterCollection.id,
                    status: '1'
                },
                attributes: ['product_id'],
            });
            CollectionMasterArray = result.map(data => data.product_id);
        }

        if (CollectionMasterArray.length > 0) {
            dynamicFilters.push({
                id: {
                    [Op.in]: CollectionMasterArray.length > 0
                        ? CollectionMasterArray
                        : [0],
                },
            });
        }

        var categories = await NavigationMenu.findOne({
            where: {
                slug: slug,
                type: 3
            },
            attributes: ['id', 'menu_id'],
            include: [
                {
                    model: Category,
                    as: 'categories',
                    attributes: ['id', 'slug', 'name', 'description', 'image'],
                    required: false,
                    include: [
                        {
                            model: AssignPageSlider,
                            as: 'assign_slider',
                            attributes: ['page_slider_id'],
                            required: false,
                            where: { type: '2' },
                            include: [
                                {
                                    model: PageSlider,
                                    as: 'page_slider',
                                    attributes: ['id', 'title'],
                                    required: false,
                                    include: [
                                        {
                                            model: PageSliderImages,
                                            as: 'page_slider_images',
                                            attributes: ['id', 'image_title', 'button_link', 'description', 'inner_description', 'image'],
                                            required: false,
                                        },
                                    ],
                                },
                            ],
                        }
                    ],
                }
            ],
        });
        // if (categories) {
        //     const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
        //     var catIds = [categories['menu_id']].concat(subcategoryIds);
        //     // var catIds = [categories['menu_id']];

        // } else {
        //     var catIds = [];
        // }

        // var pcondi = {
        //     //category_id: { [Op.in]: catIds },
        //     //[Op.or]: catIds.map(catId => ({ category_id: { [Op.like]: `${catId}` } })),
        //     [Op.or]: catIds.map(catId => ({
        //         [Op.or]: [
        //             { category_id: catId.toString() }, // Check for the exact value
        //             //{ category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
        //             { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
        //             { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
        //         ]
        //     })),

        //     status: '1',
        //     is_deleted: '0',
        // };

        // if (slug == 'offers') {
        //     dynamicFilters.push({
        //         discount: {
        //             [Op.gt]: 0,
        //         },
        //     });

        // } else {
        //     dynamicFilters.push({

        //         [Op.or]: catIds.map(catId => ({
        //             [Op.or]: [
        //                 { category_id: catId.toString() }, // Exact match
        //                 sequelize.literal(`FIND_IN_SET(${catId}, category_id) > 0`) // Match catId in a comma-separated list
        //             ]
        //         })),
        //         // stock_quantity: {
        //         //     [Op.gt]: 0,
        //         // }


        //     });
        // }



        const products = await Product.findAll({
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
                status: '1',
                is_deleted: '0',
                id: {
                    [Op.in]: CollectionMasterArray.length > 0
                        ? CollectionMasterArray
                        : [0],
                },
            },
            limit: parseInt(limit),
            offset: parseInt(offset),
            order: [['stock_quantity', 'DESC']],
            // where: pcondi,
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['is_default', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    //where: { is_default: '1' },
                    limit: 2,
                    required: false,
                    order: [['is_default', 'DESC']]
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: sortBy,
            group: ['id'],

        });

        // const maxpriceproducts = await Product.findOne({
        //     where: {
        //         ...stockQuantity,
        //         [Op.and]: [
        //             ...dynamicFilters,
        //         ],
        //     },
        //     attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        //     order: [
        //         ['price', 'DESC'],
        //     ]

        // });

        const maxpriceproducts = await Product.findOne({
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
                status: '1',
                is_deleted: '0',
            },
            order: [
                ['price', 'DESC'],
            ],
            group: ['id'],
        });
        const count = await Product.findAll({
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
                status: '1',
                is_deleted: '0',
            },
            group: ['id'],
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }

        const categoriesss = {
            categories: slugIdInMasterCollection,


        }
        // const assign_slider = null;
        // categoriesss?.categories

        if (!products[0]) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '1'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                category_path: process.env.SITE_URL + 'uploads/collection/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                product_path: process.env.SITE_URL + 'uploads/products/',
                max_price: maxpriceVal,
                path: process.env.SITE_URL + 'uploads/products/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                slug: slug,
                totalItems: count.length,
                dataoncurrentPage: products.length,
                totalPages: Math.ceil(count.length / limit),
                currentPage: page_number,
                category: categoriesss,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}

const HomeCollectionMasterList = async (req, res) => {
    try {

        const result = await HomeCollectionModel.findAll({
            where: {
                status: '1'
            },
            attributes: ['id', 'collection_name', 'slug', 'collection_image','banner_image'],
        })
        if (result.length > 0) {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                status: '1',
                is_collection: '1',
                error: false,
                success: true,
                collection: process.env.SITE_URL + 'uploads/collection/',
                data: result
            })
        } else {
            return res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                status: '0',
                error: true,
                success: false,

            })
        }
    } catch (error) {
        return res.status(500).send({
            message: process.env.ERROR_MSG,
            status: '0',
            error: true,
            success: false,
            me: error.message
        })
    }
}

module.exports = {
    GetCategoryDetail, HomeCollectionMasterList

};
