const Product = require("../../models/master/Product");
const ProductMedia = require("../../models/master/ProductMedia");
const Wishlist = require("../../models/master/Wishlist");
const AssignPageSlider = require('../../models/master/AssignPageSlider');
const PageSlider = require('../../models/master/PageSlider');
const PageSliderImages = require('../../models/master/PageSliderImages');
const ProductNotifyModel = require("../../models/master/ProductNotifyModel");
const SiteSellerProducts = require("../../models/master/SiteSellerProducts");
const ProductAttributes = require("../../models/master/ProductAttributes");
const Category = require("../../models/master/Category");
require('dotenv').config();
const getCurrentDateTime = () => new Date();
const NavigationMenu = require("../../models/master/NavigationMenu");
const Op = require('sequelize').Op;
const sequelize = require('sequelize');
const Joi = require("joi");
const ProductAttributeValue = require("../../models/master/ProductAttributeValue");
const SearchKeywordTemplate = require("../../models/master/SearchKeywordTemplate");
const Cart = require("../../models/master/Cart");
const OrderDiscountCoupon = require("../../models/master/OrderDiscountCoupon");
const Coupon = require("../../models/master/Coupon");
const Order = require("../../models/master/Order");
const { group } = require("console");
const BuyNow = require("../../models/master/BuyNow");
const HomeCollectionModel = require('../../models/master/HomeCollectionMaster')

const getCurrentDate = () => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`; // Format as YYYY-MM-DD
};
const GethHomePRoduct = async (req, res) => {
    const user_id = req.body.user_id || 0;
    try {
        const finestProduct = await Product.findAll({
            limit: 10,
            order: [
                // ['stock_quantity','DESC']
                // ['updated_at', 'DESC'],
                ['created_at', 'DESC']
            ],
            //order: [['stock_quantity','DESC']],
            //  order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const bestSellProduct = await Product.findAll({
            limit: 10,
            order: [
                // ['stock_quantity','DESC']
                // ['updated_at', 'DESC'],
                ['created_at', 'DESC']
            ],
            // order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
            //order: [['stock_quantity','DESC']],
            attributes: ['id', 'sold_out_count', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const arrivalsProduct = await Product.findAll({
            limit: 10,
            order: [
                // ['stock_quantity','DESC']
                // ['updated_at', 'DESC'],
                ['created_at', 'DESC']
            ],
            order: [
                // ['stock_quantity','DESC']
                // ['updated_at', 'DESC'],
                ['created_at', 'DESC']
            ],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    //where: { is_default: '1'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const discountedProduct = await Product.findAll({
            limit: 10,
            order: [
                // ['stock_quantity','DESC']
                // ['updated_at', 'DESC'],
                ['discount', 'DESC']
            ],
            // order: [['discount','DESC']],
            //order: [['stock_quantity', 'DESC'],['discount', 'DESC']],
            // order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'discount', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ]],
            // where: {
            //     status: 1,

            // },
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    //where: { is_default: '1'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                //is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                },
                discount: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const response = {
            arrivalsProduct: arrivalsProduct,
            bestSellProduct: bestSellProduct,
            finestProduct: finestProduct,
            discountedProduct: discountedProduct,
        }
        if (!response) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: response
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// const Getmoreproduct = async (req, res) => {
//     const user_id = req.body.user_id || 0;

//     const schema = Joi.object().keys({
//         type_id: Joi.number().integer().required()
//     });
//     const dataToValidate = {
//         type_id: req.body.type_id
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(403).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         const type_id = req.body.type_id;

//         const page_number = req.body.page_number || 1;
//         const limit = req.body.limit || 100;
//         const offset = (page_number - 1) * limit;


//         if (type_id == '1') {
//             const slug = req.body.slug || 'newarrival';
//             const response = await get_arrivalsProduct(limit, offset, user_id);
//             if (!response?.arrivalsProduct[0]) {
//                 res.status(404).send({
//                     message: process.env.RECORD_NOT_FOUND,
//                     error: true,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else {
//                 res.status(200).send({
//                     message: process.env.SUCCESS_MSG,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     path: process.env.SITE_URL + 'uploads/products/',
//                     page_slider: process.env.SITE_URL + 'uploads/page_slider/',
//                     slug: slug,
//                     max_price: response?.maxpriceVal,
//                     totalItems: response?.count,
//                     dataoncurrentPage: response?.arrivalsProduct.length,
//                     totalPages: Math.ceil(response?.count / limit),
//                     currentPage: page_number,
//                     slider_details: response?.slider_details,
//                     data: response?.arrivalsProduct
//                 });
//             }
//         } else if (type_id == '2') {
//             const slug = req.body.slug || 'bestseller';
//             const response = await get_bestSellProduct(limit, offset, user_id);
//             if (!response?.bestSellProduct[0]) {
//                 res.status(404).send({
//                     message: process.env.RECORD_NOT_FOUND,
//                     error: true,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else {
//                 res.status(200).send({
//                     message: process.env.SUCCESS_MSG,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     path: process.env.SITE_URL + 'uploads/products/',
//                     page_slider: process.env.SITE_URL + 'uploads/page_slider/',
//                     slug: slug,
//                     max_price: response?.maxpriceVal,
//                     totalItems: response?.count,
//                     dataoncurrentPage: response?.bestSellProduct.length,
//                     totalPages: Math.ceil(response?.count / limit),
//                     currentPage: page_number,
//                     slider_details: response?.slider_details,
//                     data: response?.bestSellProduct
//                 });
//             }
//         } else if (type_id == '3') {
//             const slug = req.body.slug || 'finestProduct';
//             const response = await get_finestProduct(limit, offset, user_id);
//             if (!response?.finestProduct[0]) {
//                 res.status(404).send({
//                     message: process.env.RECORD_NOT_FOUND,
//                     error: true,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else {
//                 res.status(200).send({
//                     message: process.env.SUCCESS_MSG,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     path: process.env.SITE_URL + 'uploads/products/',
//                     page_slider: process.env.SITE_URL + 'uploads/page_slider/',
//                     slug: slug,
//                     max_price: response?.maxpriceVal,
//                     totalItems: response?.count,
//                     dataoncurrentPage: response?.finestProduct.length,
//                     totalPages: Math.ceil(response?.count / limit),
//                     currentPage: page_number,
//                     slider_details: response?.slider_details,
//                     data: response?.finestProduct
//                 });
//             }
//         } else if (type_id == '4') {
//             const slug = req.body.slug || 'bigsavings';
//             const response = await get_discountedProduct(limit, offset, user_id);
//             if (!response?.discountedProduct[0]) {
//                 res.status(404).send({
//                     message: process.env.RECORD_NOT_FOUND,
//                     error: true,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else {
//                 res.status(200).send({
//                     message: process.env.SUCCESS_MSG,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     path: process.env.SITE_URL + 'uploads/products/',
//                     page_slider: process.env.SITE_URL + 'uploads/page_slider/',
//                     slug: slug,
//                     max_price: response?.maxpriceVal,
//                     totalItems: response?.count,
//                     dataoncurrentPage: response?.discountedProduct.length,
//                     totalPages: Math.ceil(response?.count / limit),
//                     currentPage: page_number,
//                     slider_details: response?.slider_details,
//                     data: response?.discountedProduct
//                 });
//             }
//         } else {
//             return res.status(404).send({
//                 message: process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         }

//     }
// }

// async function get_discountedProduct(limit, offset, user_id) {
//     var slider_details = await AssignPageSlider.findOne({
//         attributes: ['page_slider_id'],
//         required: false,
//         where: { type: '3', category_menu_id: 2 },
//         include: [
//             {
//                 model: PageSlider,
//                 as: 'page_slider',
//                 attributes: ['id', 'title'],
//                 required: false,
//                 include: [
//                     {
//                         model: PageSliderImages,
//                         as: 'page_slider_images',
//                         attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
//                         required: false,
//                     },
//                 ],
//             },
//         ],

//     });
//     const discountedProduct = await Product.findAll({
//         // order: [['discount','DESC']],
//         //order: [['stock_quantity', 'DESC'],['discount', 'DESC']],
//         limit: parseInt(limit),
//         offset: parseInt(offset),
//         order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
//         attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'discount', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
//             // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
//             sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
//             'is_wishlist'
//         ]],
//         include: [
//             {
//                 model: ProductMedia,
//                 as: 'productimages',
//                 attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
//                 //where: { is_default: '1'},
//                 limit: 2,
//                 required: false,
//             },
//             {
//                 model: Wishlist,
//                 as: 'wishlist',
//                 attributes: ['id'],
//                 where: { user_id: user_id },
//                 required: false,
//             },
//             {
//                 model: SiteSellerProducts,
//                 as: 'seller_product',
//                 attributes: ['seller_id'],
//                 where: { seller_id: 3 },
//                 required: true,
//             }
//         ],
//         where: {
//             is_home_new_arrival: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//     });
//     const maxpriceproducts = await Product.findOne({
//         where: {
//             is_home_new_arrival: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },

//         attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
//         order: [
//             ['price', 'DESC'],
//         ],

//     });
//     var maxpriceVal = 0;
//     if (maxpriceproducts) {
//         var maxpriceVal = maxpriceproducts['price'];
//     }


//     const count = await Product.count({
//         where: {
//             is_home_new_arrival: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//         include: [
//             {
//                 model: SiteSellerProducts,
//                 as: 'seller_product',
//                 attributes: ['seller_id'],
//                 where: { seller_id: 3 },
//                 required: true,
//             }
//         ],
//     });

//     const response = {
//         maxpriceVal: maxpriceVal,
//         slider_details: slider_details,
//         discountedProduct: discountedProduct,
//         count: count,
//     }
//     return response;

// }
// async function get_finestProduct(limit, offset, user_id) {

//     var slider_details = await AssignPageSlider.findOne({
//         attributes: ['page_slider_id'],
//         required: false,
//         where: { type: '3', category_menu_id: 3 },
//         include: [
//             {
//                 model: PageSlider,
//                 as: 'page_slider',
//                 attributes: ['id', 'title'],
//                 required: false,
//                 include: [
//                     {
//                         model: PageSliderImages,
//                         as: 'page_slider_images',
//                         attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
//                         required: false,
//                     },
//                 ],
//             },
//         ],

//     });
//     const finestProduct = await Product.findAll({
//         limit: parseInt(limit),
//         offset: parseInt(offset),
//         order: [['stock_quantity', 'DESC']],
//         attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
//             // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
//             sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
//             'is_wishlist'
//         ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
//         include: [
//             {
//                 model: ProductMedia,
//                 as: 'productimages',
//                 attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
//                 //where: { is_default: '1'},
//                 limit: 2,
//                 required: false,
//             },
//             {
//                 model: Wishlist,
//                 as: 'wishlist',
//                 attributes: ['id'],
//                 where: { user_id: user_id },
//                 required: false,
//             },
//             {
//                 model: ProductNotifyModel,
//                 as: 'product_notify',
//                 attributes: ['id'],
//                 where: { user_id: user_id },
//                 required: false,
//             },
//             {
//                 model: SiteSellerProducts,
//                 as: 'seller_product',
//                 attributes: ['seller_id'],
//                 where: { seller_id: 3 },
//                 required: true,
//             }
//         ],
//         where: {
//             is_finest: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//     });
//     const maxpriceproducts = await Product.findOne({
//         where: {
//             is_finest: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//         attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
//         order: [
//             ['price', 'DESC'],
//         ]
//     });
//     var maxpriceVal = 0;
//     if (maxpriceproducts) {
//         var maxpriceVal = maxpriceproducts['price'];
//     }
//     const count = await Product.count({
//         where: {
//             is_finest: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//         include: [
//             {
//                 model: SiteSellerProducts,
//                 as: 'seller_product',
//                 attributes: ['seller_id'],
//                 where: { seller_id: 3 },
//                 required: true,
//             },
//         ],
//     });
//     const response = {
//         maxpriceVal: maxpriceVal,
//         slider_details: slider_details,
//         finestProduct: finestProduct,
//         count: count,
//     }
//     return response;
// }
// async function get_bestSellProduct(limit, offset, user_id) {

//     var slider_details = await AssignPageSlider.findOne({
//         attributes: ['page_slider_id'],
//         required: false,
//         where: { type: '3', category_menu_id: 4 },
//         include: [
//             {
//                 model: PageSlider,
//                 as: 'page_slider',
//                 attributes: ['id', 'title'],
//                 required: false,
//                 include: [
//                     {
//                         model: PageSliderImages,
//                         as: 'page_slider_images',
//                         attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
//                         required: false,
//                     },
//                 ],
//             },
//         ],

//     });
//     const bestSellProduct = await Product.findAll({
//         limit: parseInt(limit),
//         offset: parseInt(offset),
//         order: [['stock_quantity', 'DESC']],
//         attributes: ['id', 'sold_out_count', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
//             sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
//             'is_wishlist'
//         ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
//         include: [
//             {
//                 model: ProductMedia,
//                 as: 'productimages',
//                 attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
//                 limit: 2,
//                 required: false,
//             },
//             {
//                 model: Wishlist,
//                 as: 'wishlist',
//                 attributes: ['id'],
//                 where: { user_id: user_id },
//                 required: false,
//             },
//             {
//                 model: ProductNotifyModel,
//                 as: 'product_notify',
//                 attributes: ['id'],
//                 where: { user_id: user_id },
//                 required: false,
//             },
//             {
//                 model: SiteSellerProducts,
//                 as: 'seller_product',
//                 attributes: ['seller_id'],
//                 where: { seller_id: 3 },
//                 required: true,
//             }
//         ],
//         where: {
//             is_best_seller: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//     });
//     const maxpriceproducts = await Product.findOne({
//         where: {
//             is_best_seller: '1',
//             status: '1',
//             is_deleted: '0'
//         },
//         attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
//         order: [
//             ['price', 'DESC'],
//         ]
//     });
//     var maxpriceVal = 0;
//     if (maxpriceproducts) {
//         var maxpriceVal = maxpriceproducts['price'];
//     }


//     const count = await Product.count({
//         where: {
//             is_best_seller: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//         include: [
//             {
//                 model: SiteSellerProducts,
//                 as: 'seller_product',
//                 attributes: ['seller_id'],
//                 where: { seller_id: 3 },
//                 required: true,
//             },
//         ],
//     });
//     const response = {
//         maxpriceVal: maxpriceVal,
//         slider_details: slider_details,
//         bestSellProduct: bestSellProduct,
//         count: count,
//     }
//     return response;
// }
// async function get_arrivalsProduct(limit, offset, user_id) {

//     var slider_details = await AssignPageSlider.findOne({
//         attributes: ['page_slider_id'],
//         required: false,
//         where: { type: '3', category_menu_id: 1 },
//         include: [
//             {
//                 model: PageSlider,
//                 as: 'page_slider',
//                 attributes: ['id', 'title'],
//                 required: false,
//                 include: [
//                     {
//                         model: PageSliderImages,
//                         as: 'page_slider_images',
//                         attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
//                         required: false,
//                     },
//                 ],
//             },
//         ],

//     });
//     const arrivalsProduct = await Product.findAll({
//         limit: parseInt(limit), // Apply limit for pagination
//         offset: parseInt(offset),
//         order: [['stock_quantity', 'DESC']],
//         attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
//             // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
//             sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
//             'is_wishlist'],
//             [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']
//         ],
//         include: [
//             {
//                 model: ProductMedia,
//                 as: 'productimages',
//                 attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
//                 //where: { is_default: '1'},
//                 limit: 2,
//                 required: false,
//             },
//             {
//                 model: Wishlist,
//                 as: 'wishlist',
//                 attributes: ['id'],
//                 where: { user_id: user_id },
//                 required: false,
//             },
//             {
//                 model: ProductNotifyModel,
//                 as: 'product_notify',
//                 attributes: ['id'],
//                 where: { user_id: user_id },
//                 required: false,
//             },
//             {
//                 model: SiteSellerProducts,
//                 as: 'seller_product',
//                 attributes: ['seller_id'],
//                 where: { seller_id: 3 },
//                 required: true,
//             }
//         ],
//         where: {
//             is_home_new_arrival: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//     });
//     const maxpriceproducts = await Product.findOne({
//         where: {
//             is_home_new_arrival: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//         attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
//         order: [
//             ['price', 'DESC'],
//         ]
//     });
//     var maxpriceVal = 0;
//     if (maxpriceproducts) {
//         var maxpriceVal = maxpriceproducts['price'];
//     }


//     const count = await Product.count({
//         where: {
//             is_home_new_arrival: '1',
//             status: '1',
//             is_deleted: '0',
//             stock_quantity: {
//                 [sequelize.Op.gt]: 0
//             }
//         },
//         include: [
//             {
//                 model: SiteSellerProducts,
//                 as: 'seller_product',
//                 attributes: ['seller_id'],
//                 where: { seller_id: 3 },
//                 required: true,
//             },
//         ],
//     });
//     const response = {
//         maxpriceVal: maxpriceVal,
//         slider_details: slider_details,
//         arrivalsProduct: arrivalsProduct,
//         count: count,
//     }
//     return response;


// }

const Getmoreproduct = async (req, res) => {
    const user_id = req.body.user_id || 0;

    const schema = Joi.object().keys({
        type_id: Joi.number().integer().required()
    });
    const dataToValidate = {
        type_id: req.body.type_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const type_id = req.body.type_id;
        const page_number = req.body.page_number || 1;
        const limit = req.body.limit || 100;
        const offset = (page_number - 1) * limit;
        //filter
        const slug = req.body.slug;
        const category_id = req.body.category_id;
        const keyword = req.body.keyword || 0;
        const menu_product = req.body.menu_product || 0;
        const color_id = req.body.color_id;
        const min_price = req.body.min_price;
        const max_price = req.body.max_price;
        const sorting = req.body.sorting;
        const remove_stock = req.body.remove_stock;
        const material_id = req.body.material_id || 0;
        const discount = req.body.discount;
        const type_ids = req.body.type_ids || 0;
        var stockQuantity = (remove_stock == 1) ? { stock_quantity: { [sequelize.Op.gt]: 0 } } : '';

        // var cateid = JSON.parse(category_id);
        // var clrid = JSON.parse(color_id);
        // var materialid = JSON.parse(material_id);
        // var typeId = JSON.parse(type_id);
        // const colorData = await ProductAttributeValue.findOne({
        //     where: { slug: slug, prod_attr_type_id: 2 },
        //     attributes: ['id'],
        //     required: false,
        // });



        let sortBy = [['stock_quantity', 'DESC'], [sequelize.literal('TRIM(product_name)'), 'ASC']];
        if (sorting == 'a-z') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'ASC']];
        } else if (sorting == 'z-a') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'DESC']];
        } else if (sorting == 'new_arrival') {
            sortBy = [['is_home_new_arrival', 'DESC']];
        } else if (sorting == 'low_to_high') {
            sortBy = [['price', 'ASC']];
        } else if (sorting == 'high_to_low') {
            sortBy = [['price', 'DESC']];
        }
        else if (sorting == 'recommendation') {
            sortBy = [['recommended_product', 'DESC'],['stock_quantity', 'DESC'], [sequelize.literal('TRIM(product_name)'), 'ASC']];
        }
        const dynamicFilters = [];
        if (max_price != 'ALL') {
            if (min_price || max_price) {
                dynamicFilters.push({
                    price: {
                        [Op.gte]: min_price,
                        [Op.lte]: max_price,
                    },
                });
            }
        }

        if (discount) {
            dynamicFilters.push({
                discount: {
                    [Op.gte]: discount,
                },
            });
        }

        if (material_id) {
            var materialid = material_id.split(",");
            dynamicFilters.push({
                material_id: {
                    [Op.in]: materialid,
                },
            });
        }

        if (type_ids) {
            var typeId = type_ids.split(',');
            dynamicFilters.push({
                type_id: {
                    [Op.in]: typeId,
                },
            });
        }
        let productIdArray = [];
        if (color_id) {
            const colorIds = color_id.split(',');
            const productAttributes = await ProductAttributes.findAll({
                where: {
                    attr_val_id: { [Op.in]: colorIds },
                    attr_type_id: 2
                },
                attributes: ['product_id'],
            });
            productIdArray = productAttributes.map(attribute => attribute.product_id);
            if (productIdArray.length > 0) {
                dynamicFilters.push({
                    id: {
                        [Op.in]: productIdArray,
                    },
                });
            } else {
                dynamicFilters.push({
                    id: {
                        [Op.in]: [0],
                    },
                });
            }
        }


        if (type_id == '1') {
            const slug = req.body.slug || 'newarrival';
            const response = await get_arrivalsProduct(limit, offset, user_id, sortBy, stockQuantity, dynamicFilters);
            if (!response?.arrivalsProduct[0]) {
                res.status(404).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                    slug: slug,
                    max_price: response?.maxpriceVal,
                    totalItems: response?.count,
                    dataoncurrentPage: response?.arrivalsProduct.length,
                    totalPages: Math.ceil(response?.count / limit),
                    currentPage: page_number,
                    slider_details: response?.slider_details,
                    data: response?.arrivalsProduct
                });
            }
        } else if (type_id == '2') {
            const slug = req.body.slug || 'bestseller';
            const response = await get_bestSellProduct(limit, offset, user_id, sortBy, stockQuantity, dynamicFilters);
            if (!response?.bestSellProduct[0]) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                    slug: slug,
                    max_price: response?.maxpriceVal,
                    totalItems: response?.count,
                    dataoncurrentPage: response?.bestSellProduct.length,
                    totalPages: Math.ceil(response?.count / limit),
                    currentPage: page_number,
                    slider_details: response?.slider_details,
                    data: response?.bestSellProduct
                });
            }
        } else if (type_id == '3') {
            const slug = req.body.slug || 'finestProduct';
            const response = await get_finestProduct(limit, offset, user_id, sortBy, stockQuantity, dynamicFilters);
            if (!response?.finestProduct[0]) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                    slug: slug,
                    max_price: response?.maxpriceVal,
                    totalItems: response?.count,
                    dataoncurrentPage: response?.finestProduct.length,
                    totalPages: Math.ceil(response?.count / limit),
                    currentPage: page_number,
                    slider_details: response?.slider_details,
                    data: response?.finestProduct
                });
            }
        } else if (type_id == '4') {
            const slug = req.body.slug || 'bigsavings';
            const response = await get_discountedProduct(limit, offset, user_id, sortBy, stockQuantity, dynamicFilters);
            if (!response?.discountedProduct[0]) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                    slug: slug,
                    max_price: response?.maxpriceVal,
                    totalItems: response?.count,
                    dataoncurrentPage: response?.discountedProduct.length,
                    totalPages: Math.ceil(response?.count / limit),
                    currentPage: page_number,
                    slider_details: response?.slider_details,
                    data: response?.discountedProduct
                });
            }
        } else {
            return res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        }

    }
}
async function get_discountedProduct(limit, offset, user_id, sortBy, stockQuantity, dynamicFilters) {
    var slider_details = await AssignPageSlider.findOne({
        attributes: ['page_slider_id'],
        required: false,
        where: { type: '3', category_menu_id: 2 },
        include: [
            {
                model: PageSlider,
                as: 'page_slider',
                attributes: ['id', 'title'],
                required: false,
                include: [
                    {
                        model: PageSliderImages,
                        as: 'page_slider_images',
                        attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                        required: false,
                    },
                ],
            },
        ],

    });
    const discountedProduct = await Product.findAll({
        // order: [['discount','DESC']],
        //order: [['stock_quantity', 'DESC'],['discount', 'DESC']],
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
        attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'discount', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
            // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
            sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
            'is_wishlist'
        ]],

        include: [
            {
                model: ProductMedia,
                as: 'productimages',
                attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                //where: { is_default: '1'},
                limit: 2,
                required: false,
            },
            {
                model: Wishlist,
                as: 'wishlist',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
        order: sortBy,
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            sold_out_count: {
                [sequelize.Op.gt]: 0
            },
            stock_quantity: {
                [Op.gt]: 0
            },
            //...stockQuantity,
            [Op.and]: [
                ...dynamicFilters,
            ],
        },
    });
    const maxpriceproducts = await Product.findOne({
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity
        },
        attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        order: [
            ['price', 'DESC'],
        ]
    });
    var maxpriceVal = 0;
    if (maxpriceproducts) {
        var maxpriceVal = maxpriceproducts['price'];
    }


    const count = await Product.count({
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity,
            [Op.and]: [
                ...dynamicFilters,
            ],
            sold_out_count: {
                [sequelize.Op.gt]: 0
            },
            stock_quantity: {
                [Op.gt]: 0
            },
        },
        include: [
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
    });

    const response = {
        maxpriceVal: maxpriceVal,
        slider_details: slider_details,
        discountedProduct: discountedProduct,
        count: count,
    }
    return response;

}
async function get_finestProduct(limit, offset, user_id, sortBy, stockQuantity, dynamicFilters) {

    var slider_details = await AssignPageSlider.findOne({
        attributes: ['page_slider_id'],
        required: false,
        where: { type: '3', category_menu_id: 3 },
        include: [
            {
                model: PageSlider,
                as: 'page_slider',
                attributes: ['id', 'title'],
                required: false,
                include: [
                    {
                        model: PageSliderImages,
                        as: 'page_slider_images',
                        attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                        required: false,
                    },
                ],
            },
        ],

    });
    const finestProduct = await Product.findAll({
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [['stock_quantity', 'DESC']],
        attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
            // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
            sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
            'is_wishlist'
        ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
        include: [
            {
                model: ProductMedia,
                as: 'productimages',
                attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                //where: { is_default: '1'},
                limit: 2,
                required: false,
            },
            {
                model: Wishlist,
                as: 'wishlist',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: ProductNotifyModel,
                as: 'product_notify',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
        order: sortBy,
        where: {
            is_finest: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity,
            [Op.and]: [
                ...dynamicFilters,
            ],


        },
    });
    const maxpriceproducts = await Product.findOne({
        where: {
            is_finest: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity
        },
        attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        order: [
            ['price', 'DESC'],
        ]
    });
    var maxpriceVal = 0;
    if (maxpriceproducts) {
        var maxpriceVal = maxpriceproducts['price'];
    }
    const count = await Product.count({
        where: {
            is_finest: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity,
            [Op.and]: [
                ...dynamicFilters,
            ],
        },
        include: [
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
    });
    const response = {
        maxpriceVal: maxpriceVal,
        slider_details: slider_details,
        finestProduct: finestProduct,
        count: count,
    }
    return response;
}
async function get_bestSellProduct(limit, offset, user_id, sortBy, stockQuantity, dynamicFilters) {

    var slider_details = await AssignPageSlider.findOne({
        attributes: ['page_slider_id'],
        required: false,
        where: { type: '3', category_menu_id: 4 },
        include: [
            {
                model: PageSlider,
                as: 'page_slider',
                attributes: ['id', 'title'],
                required: false,
                include: [
                    {
                        model: PageSliderImages,
                        as: 'page_slider_images',
                        attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                        required: false,
                    },
                ],
            },
        ],

    });
    const bestSellProduct = await Product.findAll({
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [['stock_quantity', 'DESC']],
        attributes: ['id', 'sold_out_count', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
            sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
            'is_wishlist'
        ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
        include: [
            {
                model: ProductMedia,
                as: 'productimages',
                attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                limit: 2,
                required: false,
            },
            {
                model: Wishlist,
                as: 'wishlist',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: ProductNotifyModel,
                as: 'product_notify',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
        order: sortBy,
        where: {
            is_best_seller: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity,
            [Op.and]: [
                ...dynamicFilters,
            ],
        },
    });
    const maxpriceproducts = await Product.findOne({
        where: {
            is_best_seller: '1',
            status: '1',
            is_deleted: '0'
        },
        attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        order: [
            ['price', 'DESC'],
        ]
    });
    var maxpriceVal = 0;
    if (maxpriceproducts) {
        var maxpriceVal = maxpriceproducts['price'];
    }


    const count = await Product.count({
        where: {
            is_best_seller: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity,
            [Op.and]: [
                ...dynamicFilters,
            ],

        },
        include: [
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
    });
    const response = {
        maxpriceVal: maxpriceVal,
        slider_details: slider_details,
        bestSellProduct: bestSellProduct,
        count: count,
    }
    return response;
}
async function get_arrivalsProduct(limit, offset, user_id, sortBy, stockQuantity, dynamicFilters) {

    var slider_details = await AssignPageSlider.findOne({
        attributes: ['page_slider_id'],
        required: false,
        where: { type: '3', category_menu_id: 1 },
        include: [
            {
                model: PageSlider,
                as: 'page_slider',
                attributes: ['id', 'title'],
                required: false,
                include: [
                    {
                        model: PageSliderImages,
                        as: 'page_slider_images',
                        attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                        required: false,
                    },
                ],
            },
        ],

    });
    const arrivalsProduct = await Product.findAll({
        limit: parseInt(limit), // Apply limit for pagination
        offset: parseInt(offset),
        order: [['stock_quantity', 'DESC']],
        attributes: ['id','product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
            // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
            sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
            'is_wishlist'],
            [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']
        ],
        include: [
            {
                model: ProductMedia,
                as: 'productimages',
                attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                //where: { is_default: '1'},
                limit: 2,
                required: false,
            },
            {
                model: Wishlist,
                as: 'wishlist',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: ProductNotifyModel,
                as: 'product_notify',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
        order: sortBy,
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity,
            [Op.and]: [
                ...dynamicFilters,
            ],
        },
    });
    const maxpriceproducts = await Product.findOne({
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity
        },
        attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        order: [
            ['price', 'DESC'],
        ]
    });
    var maxpriceVal = 0;
    if (maxpriceproducts) {
        var maxpriceVal = maxpriceproducts['price'];
    }


    const count = await Product.findAll({
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            ...stockQuantity,
            [Op.and]: [
                ...dynamicFilters,
            ],
        },
        include: [
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
        group: ['id'],
    });

    const response = {
        maxpriceVal: maxpriceVal,
        slider_details: slider_details,
        arrivalsProduct: arrivalsProduct,
        count: count.length,
    }
    return response;


}




async function getSubcategoriesRecursive(parentId) {
    const subcategories = await NavigationMenu.findAll({
        where: {
            type: 3,
            parent_id: parentId
        },
        attributes: ['id', 'menu_id']
    });

    let subcategoryIds = [];
    for (let subcategory of subcategories) {
        subcategoryIds.push(subcategory.menu_id);
        // Recursively find subcategories of the current subcategory
        const childIds = await getSubcategoriesRecursive(subcategory.id);
        subcategoryIds = subcategoryIds.concat(childIds);
    }
    return subcategoryIds;
}



//get category detail
const GetCategoryDetail = async (req, res) => {

    const slug = req.params.slug;
    const user_id = req.body.user_id || 0;
    try {
        const page_number = req.body.page_number || 1;
        const limit = req.body.limit || 100;
        const offset = (page_number - 1) * limit;

        const color_id = req.body.color_id;
        const min_price = req.body.min_price;
        const max_price = req.body.max_price;
        const sorting = req.body.sorting;
        const remove_stock = req.body.remove_stock;
        const material_id = req.body.material_id || 0;
        const discount = req.body.discount;
        const type_ids = req.body.type_ids || 0;
        var stockQuantity = (remove_stock == 1) ? { stock_quantity: { [sequelize.Op.gt]: 0 } } : '';


        let sortBy = [['stock_quantity', 'DESC'], [sequelize.literal('TRIM(product_name)'), 'ASC']];
        if (sorting == 'a-z') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'ASC']];
        } else if (sorting == 'z-a') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'DESC']];
        } else if (sorting == 'new_arrival') {
            sortBy = [['is_home_new_arrival', 'DESC']];
        } else if (sorting == 'low_to_high') {
            sortBy = [['price', 'ASC']];
        } else if (sorting == 'high_to_low') {
            sortBy = [['price', 'DESC']];
        } else if (sorting == 'recommendation') {
            sortBy = [['recommended_product', 'DESC'],['stock_quantity', 'DESC'], [sequelize.literal('TRIM(product_name)'), 'ASC']];
        }
        var dynamicFilters = [];

        // let CollectionMasterArray = [];

        // let slugIdInMasterCollection = await HomeCollectionMasterModel.findOne({
        //     where: {slug: slug, status: '1'},
        //     attributes: ['id']
        // })

        // if(slugIdInMasterCollection){
        //     const result = await CollectionAssignProductsModel.findAll({
        //         where: {
        //            collection_id: slugIdInMasterCollection.id,
        //            status: '1'
        //         },
        //         attributes: ['product_id'],
        //     });

        //     CollectionMasterArray = result.map(data => data.product_id);

        //     if (CollectionMasterArray.length > 0) {
        //         dynamicFilters.push({
        //             id: {
        //                 [Op.in]: CollectionMasterArray,
        //             },
        //         });
        //     }  else {
        //         dynamicFilters.push({
        //             id: {
        //                 [Op.in]: [0],
        //             },
        //         });
        //     }

        // }


        if (max_price != 'ALL') {
            if (min_price || max_price) {
                dynamicFilters.push({
                    price: {
                        [Op.gte]: min_price,
                        [Op.lte]: max_price,
                    },
                });
            }
        }


        if (discount) {
            dynamicFilters.push({
                discount: {
                    [Op.gte]: discount,
                },
            });
        }


        if (material_id) {
            var materialid = material_id.split(",");
            dynamicFilters.push({
                material_id: {
                    [Op.in]: materialid,
                },
            });
        }

        if (type_ids) {
            var typeId = type_ids.split(',');
            dynamicFilters.push({
                type_id: {
                    [Op.in]: typeId,
                },
            });
        }
        let productIdArray = [];
        if (color_id) {
            const colorIds = color_id.split(',');
            const productAttributes = await ProductAttributes.findAll({
                where: {
                    attr_val_id: { [Op.in]: colorIds },
                    attr_type_id: 2
                },
                attributes: ['product_id'],
            });
            productIdArray = productAttributes.map(attribute => attribute.product_id);
            if (productIdArray.length > 0) {
                dynamicFilters.push({
                    id: {
                        [Op.in]: productIdArray,
                    },
                });
            } else {
                dynamicFilters.push({
                    id: {
                        [Op.in]: [0],
                    },
                });
            }
        }

        var categories = await NavigationMenu.findOne({
            where: {
                slug: slug,
                type: 3
            },
            attributes: ['id', 'menu_id'],
            include: [
                {
                    model: Category,
                    as: 'categories',
                    attributes: ['id', 'slug', 'name', 'description', 'image'],
                    required: false,
                    include: [
                        {
                            model: AssignPageSlider,
                            as: 'assign_slider',
                            attributes: ['page_slider_id'],
                            required: false,
                            where: { type: '2' },
                            include: [
                                {
                                    model: PageSlider,
                                    as: 'page_slider',
                                    attributes: ['id', 'title'],
                                    required: false,
                                    include: [
                                        {
                                            model: PageSliderImages,
                                            as: 'page_slider_images',
                                            attributes: ['id', 'image_title', 'button_link', 'description', 'inner_description', 'image'],
                                            required: false,
                                        },
                                    ],
                                },
                            ],
                        }
                    ],
                }
            ],
        });
        if (categories) {
            const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
            var catIds = [categories['menu_id']].concat(subcategoryIds);
            // var catIds = [categories['menu_id']];

        } else {
            var catIds = [];
        }

        // var pcondi = {
        //     //category_id: { [Op.in]: catIds },
        //     //[Op.or]: catIds.map(catId => ({ category_id: { [Op.like]: `${catId}` } })),
        //     [Op.or]: catIds.map(catId => ({
        //         [Op.or]: [
        //             { category_id: catId.toString() }, // Check for the exact value
        //             //{ category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
        //             { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
        //             { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
        //         ]
        //     })),

        //     status: '1',
        //     is_deleted: '0',
        // };

        if (slug == 'offers') {
            dynamicFilters.push({
                discount: {
                    [Op.gt]: 0,
                },
            });

        } else {
            dynamicFilters.push({

                [Op.or]: catIds.map(catId => ({
                    [Op.or]: [
                        { category_id: catId.toString() }, // Exact match
                        sequelize.literal(`FIND_IN_SET(${catId}, category_id) > 0`) // Match catId in a comma-separated list
                    ]
                })),
                // stock_quantity: {
                //     [Op.gt]: 0,
                // }


            });
        }



        const products = await Product.findAll({
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
                status: '1',
                is_deleted: '0',
            },
            limit: parseInt(limit),
            offset: parseInt(offset),
            order: [['stock_quantity', 'DESC']],
            // where: pcondi,
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['is_default', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    //where: { is_default: '1' },
                    limit: 2,
                    required: false,
                    order: [['is_default', 'DESC']]
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: sortBy,
            group: ['id'],

        });

        // const maxpriceproducts = await Product.findOne({
        //     where: {
        //         ...stockQuantity,
        //         [Op.and]: [
        //             ...dynamicFilters,
        //         ],
        //     },
        //     attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        //     order: [
        //         ['price', 'DESC'],
        //     ]

        // });

        const maxpriceproducts = await Product.findOne({
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
                status: '1',
                is_deleted: '0',
            },
            order: [
                ['price', 'DESC'],
            ],
            group: ['id'],
        });
        const count = await Product.findAll({
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
                status: '1',
                is_deleted: '0',
            },
            group: ['id'],
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }

        if (!categories) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '1'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                category_path: process.env.SITE_URL + 'uploads/category/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                product_path: process.env.SITE_URL + 'uploads/products/',
                max_price: maxpriceVal,
                path: process.env.SITE_URL + 'uploads/products/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                slug: slug,
                totalItems: count.length,
                dataoncurrentPage: products.length,
                totalPages: Math.ceil(count.length / limit),
                currentPage: page_number,
                category: categories,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}

//get color wise product start
const GetColorWiseProduct = async (req, res) => {
    const slug = req.params.slug;
    const user_id = req.body.user_id || 0;
    try {

        const page_number = req.body.page_number || 1;
        const limit = req.body.limit || 100;
        const offset = (page_number - 1) * limit;

        const min_price = req.body.min_price;
        const max_price = req.body.max_price;
        const sorting = req.body.sorting;
        const remove_stock = req.body.remove_stock;
        const material_id = req.body.material_id || 0;
        const discount = req.body.discount;
        const type_ids = req.body.type_ids || 0;
        var stockQuantity = (remove_stock == 1) ? { stock_quantity: { [sequelize.Op.gt]: 0 } } : '';
        let sortBy = [['stock_quantity', 'DESC'], [sequelize.literal('TRIM(product_name)'), 'ASC']];
        if (sorting == 'a-z') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'ASC']];
        } else if (sorting == 'z-a') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'DESC']];
        } else if (sorting == 'new_arrival') {
            sortBy = [['is_home_new_arrival', 'DESC']];
        } else if (sorting == 'low_to_high') {
            sortBy = [['price', 'ASC']];
        } else if (sorting == 'high_to_low') {
            sortBy = [['price', 'DESC']];
        }
        const dynamicFilters = [];
        if (max_price != 'ALL') {
            if (min_price || max_price) {
                dynamicFilters.push({
                    price: {
                        [Op.gte]: min_price,
                        [Op.lte]: max_price,
                    },
                });
            }
        }

        if (discount) {
            dynamicFilters.push({
                discount: {
                    [Op.gte]: discount,
                },
            });
        }

        if (material_id) {
            var materialid = material_id.split(",");
            dynamicFilters.push({
                material_id: {
                    [Op.in]: materialid,
                },
            });
        }

        if (type_ids) {
            var typeId = type_ids.split(',');
            dynamicFilters.push({
                type_id: {
                    [Op.in]: typeId,
                },
            });
        }

        var slider_details = await AssignPageSlider.findOne({
            attributes: ['page_slider_id'],
            required: false,
            where: { type: '3', category_menu_id: 5 },
            include: [
                {
                    model: PageSlider,
                    as: 'page_slider',
                    attributes: ['id', 'title'],
                    required: false,
                    include: [
                        {
                            model: PageSliderImages,
                            as: 'page_slider_images',
                            attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                            required: false,
                        },
                    ],
                },
            ],

        });
        const colorData = await ProductAttributeValue.findOne({
            where: { slug: slug, prod_attr_type_id: 2 },
            attributes: ['id'],
            required: false,
        });

        const color_id = colorData ? colorData['id'] : 0;

        const productAttribute = await ProductAttributes.findAll({
            where: { attr_val_id: color_id, attr_type_id: 2 },
            attributes: ['product_id'],
            required: false,
        });

        var prIdArr = productAttribute.map(variant => variant.product_id);
        if (prIdArr.length > 0) {
            dynamicFilters.push({
                id: {
                    [Op.in]: prIdArr,
                },
            });
        } else {
            dynamicFilters.push({
                id: {
                    [Op.in]: [0],
                },
            });
        }


        const products = await Product.findAll({
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
                //added by suresh 05-11-2024 show deleted product 
                status: '1',
                is_deleted: '0',
                // end
            },
            limit: parseInt(limit),
            offset: parseInt(offset),
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            //added by suresh 05-11-2024 show same product in multiple time in query
            group: ['id'],
            //end
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    //where: { is_default: '1' },
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: sortBy,
        });

        const maxpriceproducts = await Product.findOne({
            attributes: ['id', 'product_slug', 'price', 'usd_price', 'usd_compare_price', 'status', 'is_deleted'],
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                ...stockQuantity,
                id: {
                    [Op.in]: prIdArr,
                },
                status: '1',
                is_deleted: '0',
            },
            order: [
                ['price', 'DESC'],
            ],
            group: ['id'],
        });
        const count = await Product.findAll({
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
                //added by suresh 05-11-2024 show deleted product 
                status: '1',
                is_deleted: '0',
                // end
            },
            group: ['id'],
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }
        if (!products[0]) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                path: process.env.SITE_URL + 'uploads/products/',
                slug: slug,
                max_price: maxpriceVal,
                totalItems: count.length,
                dataoncurrentPage: products.length,
                totalPages: Math.ceil(count.length / limit),
                currentPage: page_number,
                slider_details: slider_details,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get color wise product end
const GetSearchKeywordProduct = async (req, res) => {
    const keyword = req.body?.keyword?.trim();
    const user_id = req.body.user_id || 0;
    try {

        const page_number = req.body.page_number || 1;
        const limit = req.body.limit || 100;
        const offset = (page_number - 1) * limit;
        const min_price = req.body.min_price;
        const max_price = req.body.max_price;
        const sorting = req.body.sorting;
        const remove_stock = req.body.remove_stock;
        const material_id = req.body.material_id || 0;
        const color_id = req.body.color_id || 0;
        const discount = req.body.discount;
        const type_ids = req.body.type_ids || 0;
        var stockQuantity = (remove_stock == 1) ? { stock_quantity: { [sequelize.Op.gt]: 0 } } : '';
        let sortBy = [['stock_quantity', 'DESC'], [sequelize.literal('TRIM(product_name)'), 'ASC']];
        if (sorting == 'a-z') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'ASC']];
        } else if (sorting == 'z-a') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'DESC']];
        } else if (sorting == 'new_arrival') {
            sortBy = [['is_home_new_arrival', 'DESC']];
        } else if (sorting == 'low_to_high') {
            sortBy = [['price', 'ASC']];
        } else if (sorting == 'high_to_low') {
            sortBy = [['price', 'DESC']];
        }
        const dynamicFilters = [];

        if (keyword) {
            dynamicFilters.push({
                product_name: {
                    [Op.like]: `%${keyword}%`
                },
                status: '1',
                is_deleted: '0'
            });
        } else {
            dynamicFilters.push({
                status: '1',
                is_deleted: '0'
            });
        }

        if (max_price != 'ALL') {
            if (min_price || max_price) {
                dynamicFilters.push({
                    price: {
                        [Op.gte]: min_price,
                        [Op.lte]: max_price,
                    },
                });
            }
        }

        if (discount) {
            dynamicFilters.push({
                discount: {
                    [Op.gte]: discount,
                },
            });
        }

        if (material_id) {
            var materialid = material_id.split(",");
            dynamicFilters.push({
                material_id: {
                    [Op.in]: materialid,
                },
            });
        }

        if (type_ids) {
            var typeId = type_ids.split(',');
            dynamicFilters.push({
                type_id: {
                    [Op.in]: typeId,
                },
            });
        }


        let productIdArray = [];
        if (color_id) {
            const colorIds = color_id.split(',');
            const productAttributes = await ProductAttributes.findAll({
                where: {
                    attr_val_id: { [Op.in]: colorIds },
                    attr_type_id: 2
                },
                attributes: ['product_id'],
            });
            productIdArray = productAttributes.map(attribute => attribute.product_id);
            if (productIdArray.length > 0) {
                dynamicFilters.push({
                    id: {
                        [Op.in]: productIdArray,
                    },
                });
            } else {
                dynamicFilters.push({
                    id: {
                        [Op.in]: [0],
                    },
                });
            }
        }

        const products = await Product.findAll({
            limit: parseInt(limit),
            offset: parseInt(offset),
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    //where: { is_default: '1' },
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: sortBy,
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
            },
        });

        if (keyword && user_id > 0) {
            const searchKeyword = await SearchKeywordTemplate.findOne({
                where: {
                    user_id: user_id,
                    product_title: keyword,
                    status: '1',
                },
                attributes: ['id', 'product_title'],
            });
            if (!searchKeyword) {
                await SearchKeywordTemplate.create({
                    user_id: user_id,
                    product_title: keyword
                });
            }
        }
        const count = await Product.count({
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                ...stockQuantity,
                [Op.and]: [
                    ...dynamicFilters,
                ],
            },
        });
        const maxpriceproducts = await Product.findOne({
            // where: pcondi,
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ],
            where: {
                ...stockQuantity,

            },
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }
        if (!products) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                product_path: process.env.SITE_URL + 'uploads/products/',
                max_price: maxpriceVal,
                totalItems: count,
                dataoncurrentPage: products.length,
                totalPages: Math.ceil(count / limit),
                currentPage: page_number,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}

// const ApplyCoupon = async (req, res) => {
//     const user_id = req.userId;
//     const coupon_code = req.body.coupon_code;
//     const apply_type = req.body.apply_type;

//     const schema = Joi.object().keys({
//         coupon_code: Joi.string().required().label("Coupon"),
//         apply_type: Joi.string().required().label("Apply Type"),
//     });
//     const dataToValidate = {
//         coupon_code: coupon_code,
//         apply_type: apply_type
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(403).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {
//             const coupon_Arr = coupon_code.split(',');
//             if (coupon_Arr.length > 2) {
//                 return res.status(409).send({
//                     message: 'You can apply maximum two Coupon',
//                     error: true,
//                     success: false,
//                     status: '0',
//                     coupon_code: coupon_Arr,
//                 });
//             }

//             const check_coupon_apply = await OrderDiscountCoupon.findAll({
//                 where: {
//                     user_id: user_id,
//                 }
//             });
//             // if (check_coupon_apply.length >= 2) {
//             //     return res.status(409).send({
//             //         message: 'You can apply maximum two Coupon',
//             //         error: true,
//             //         success: false,
//             //         status: '0',
//             //         data: check_coupon_apply,
//             //     });
//             // }
//             await OrderDiscountCoupon.destroy({
//                 where: {
//                     user_id: user_id,
//                     // discount_mode: apply_type,
//                 }
//             });
//             let result = null;
//             // if (apply_type == 'cart') {

//             //     result = await Cart.findOne({
//             //         where: {
//             //             user_id: user_id
//             //         },
//             //         attributes: [[sequelize.fn('SUM', sequelize.col('subtotal_amount')), 'total_subtotal_amount']],
//             //         raw: true
//             //     });
//             // } else if (apply_type == 'buy_now') {
//             result = await BuyNow.findOne({
//                 where: {
//                     user_id: user_id
//                 },
//                 attributes: [[sequelize.fn('SUM', sequelize.col('subtotal_amount')), 'total_subtotal_amount']],
//                 raw: true
//             });
//             // } else {
//             //     return res.status(409).send({
//             //         message: 'Something Went Wrong',
//             //         error: true,
//             //         success: false,
//             //         status: '0',
//             //     });

//             // }

//             let subtotal_amount = result.total_subtotal_amount ? parseFloat(result.total_subtotal_amount) : 0;
//             const uniqueCoupons = [...new Set(coupon_Arr)];

//             // Group by unique coupons
//             const groupedCoupons = uniqueCoupons.reduce((group, coupon) => {
//                 if (!group[coupon]) {
//                     group[coupon] = [];
//                 }
//                 group[coupon].push(coupon);
//                 return group;
//             }, {});
//             for (const coupon_code_sngle of uniqueCoupons) {
//                 const couponDetails = await Coupon.findOne(
//                     {
//                         where: {
//                             coupon_code: coupon_code_sngle,
//                             // status: '1',
//                             status: {
//                                 [Op.in]: ['1', '2'],
//                             },
//                             is_deleted: 0,
//                             number_of_uses: {
//                                 [Op.gt]: 0,
//                             },
//                             from_date: {
//                                 [Op.lte]: getCurrentDate()
//                             },
//                             to_date: {
//                                 [Op.gte]: getCurrentDate()
//                             }
//                         },
//                         attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt']
//                     });
//                 // add by suresh 15-11-2024 user can use multiple time and single time one coupon
//                 const appliedCoupons = await Order.findAll({
//                     where: {
//                         user_id,
//                         [Op.or]: [
//                             { discount_id: couponDetails.id.toString() },
//                             sequelize.literal(`FIND_IN_SET(${couponDetails.id}, discount_id) > 0`)
//                         ]
//                     },
//                 });
//                 var is_applied = appliedCoupons.length > 0 ? 1 : 0;
//                 // end
//                 if (!couponDetails) {
//                     return res.status(409).send({
//                         message: 'Coupon not valid',
//                         error: true,
//                         success: false,
//                         status: '0',
//                         coupon_code: coupon_code_sngle,
//                     });
//                 } else if (is_applied && couponDetails.multiple_use != '0') {
//                     return res.status(409).send({
//                         message: 'Coupon Already Redeemed',
//                         error: true,
//                         success: false,
//                         status: '0'
//                     });
//                 } else {
//                     const check_order_exist = await Order.count({
//                         where: {
//                             user_id: user_id,
//                         },
//                         // attributes: ['id']
//                     });


//                     var min_amount = couponDetails ? couponDetails.min_amount : 0;
//                     var upto_amount = couponDetails ? couponDetails.upto_amount : 0;

//                     if ((min_amount >= 0 && min_amount > subtotal_amount) || (upto_amount > 0 && upto_amount < subtotal_amount)) {
//                         return res.status(202).send({
//                             message: `Order amount less then ${min_amount} and amount greater then ${upto_amount}`,
//                             error: true,
//                             success: false,
//                             status: '0'
//                         });
//                     }


//                     const couponAddDisount = await OrderDiscountCoupon.findOne({
//                         where: {
//                             user_id: user_id,
//                             applied_status: 1,
//                             discount_type: {
//                                 [Op.in]: ['first_order', 'order']
//                             }
//                         },
//                         attributes: [
//                             [sequelize.fn('SUM', sequelize.col('discount_amt')), 'totalDiscountAmt']
//                         ]
//                     });
//                     const totalDiscountAmt = couponAddDisount ? couponAddDisount.get('totalDiscountAmt') : 0;
//                     //end add Suresh 17-oct-2024
//                     var dis_amt = subtotal_amount - totalDiscountAmt;
//                     if (couponDetails.coupon_type === 'percent') {
//                         var discount_amount = (Math.round(dis_amt) * couponDetails.type_val) / 100;
//                     }

//                     // else if (couponDetails.coupon_type === 'normal') {
//                     //     var discount_amount = couponDetails.type_val;
//                     // }
//                     const discount = await OrderDiscountCoupon.findOne({
//                         where: {
//                             user_id: user_id,
//                             discount_type: couponDetails?.apply_to.toLowerCase(),
//                             discount_id: couponDetails?.id
//                         },
//                         attributes: ['id', 'discount_type', 'discount_id'],
//                     });
//                     var dataCoupon = '';
//                     if ((couponDetails?.apply_to == 'FIRST_ORDER') && (check_order_exist < 1)) {
//                         if (discount) {
//                             const discountCoupon = discount.get({ plain: true });
//                             await OrderDiscountCoupon.update({
//                                 user_id: user_id,
//                                 discount_id: couponDetails.id,
//                                 discount_amt: discount_amount,
//                                 discount_mode: apply_type,
//                                 discount_type: couponDetails.apply_to.toLowerCase(),
//                                 updated_at: getCurrentDateTime(),
//                             }, {
//                                 where: {
//                                     id: discountCoupon?.id
//                                 }
//                             });
//                         } else {
//                             dataCoupon = await OrderDiscountCoupon.create({
//                                 user_id: user_id,
//                                 discount_id: couponDetails.id,
//                                 discount_amt: discount_amount,
//                                 discount_mode: apply_type,
//                                 discount_type: couponDetails.apply_to.toLowerCase(),
//                                 created_at: getCurrentDateTime(),
//                             });
//                         }
//                         // return res.status(200).send({
//                         //     message: process.env.SUCCESS_MSG,
//                         //     error: false,
//                         //     success: true,
//                         //     status: '1',
//                         //     user_id: user_id,
//                         //     data: discount_amount
//                         // });
//                     } else {
//                         if ((couponDetails?.apply_to != 'FIRST_ORDER')) {
//                             if (discount) {
//                                 const discountCoupon = discount.get({ plain: true });
//                                 await OrderDiscountCoupon.update({
//                                     discount_amt: discount_amount,
//                                     discount_mode: apply_type,
//                                     discount_type: couponDetails.apply_to.toLowerCase(),
//                                     updated_at: getCurrentDateTime(),
//                                 }, {
//                                     where: {
//                                         id: discountCoupon.id,
//                                         user_id: user_id,
//                                     }
//                                 });

//                             } else {
//                                 dataCoupon = await OrderDiscountCoupon.create({
//                                     user_id: user_id,
//                                     discount_id: couponDetails.id,
//                                     discount_amt: discount_amount,
//                                     discount_mode: apply_type,
//                                     discount_type: couponDetails.apply_to.toLowerCase(),
//                                     created_at: getCurrentDateTime(),
//                                 });
//                             }
//                         }
//                     }
//                 }
//             }
//             const apply_coupon_list = await OrderDiscountCoupon.findAll({
//                 where: {
//                     user_id: user_id,
//                 },
//                 attributes: ['discount_id']
//             });
//             const discountIdArray = apply_coupon_list.map(item => item?.discount_id);



//             const coupon_details_s = await Coupon.findAll({
//                 where: {
//                     id: {
//                         [Op.in]: discountIdArray,
//                     },
//                     // status: '1',
//                     status: {
//                         [Op.in]: ['1', '2'],
//                     },
//                     is_deleted: 0
//                 },
//             })

//             res.status(200).send({
//                 message: process.env.SUCCESS_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 user_id: user_id,
//                 data: coupon_details_s
//             });
//         } catch (error) {
//             res.status(500).send({
//                 message: process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }

const ApplyCoupon = async (req, res) => {
    const user_id = req.userId;
    const coupon_code = req.body.coupon_code;
    const apply_type = req.body.apply_type;
    const schema = Joi.object().keys({
        coupon_code: Joi.string().required().label("Coupon"),
        apply_type: Joi.string().required().label("Apply Type"),
    });
    const dataToValidate = {
        coupon_code: coupon_code,
        apply_type: apply_type
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const coupon_Arr = coupon_code.split(',');
            if (coupon_Arr.length > 2) {
                return res.status(409).send({
                    message: 'You can apply maximum two Coupon',
                    error: true,
                    success: false,
                    status: '0',
                    coupon_code: coupon_Arr,
                });
            }

            const check_coupon_apply = await OrderDiscountCoupon.findAll({
                where: {
                    user_id: user_id,
                    discount_mode: apply_type,
                }
            });
            // if (check_coupon_apply.length >= 2) {
            //     return res.status(409).send({
            //         message: 'You can apply maximum two Coupon',
            //         error: true,
            //         success: false,
            //         status: '0',
            //         data: check_coupon_apply,
            //     });
            // }
            await OrderDiscountCoupon.destroy({
                where: {
                    user_id: user_id,
                    discount_mode: apply_type,
                }
            });
            let result = null;
            if (apply_type == 'cart') {

                result = await Cart.findOne({
                    where: {
                        user_id: user_id
                    },
                    attributes: [[sequelize.fn('SUM', sequelize.col('subtotal_amount')), 'total_subtotal_amount']],
                    raw: true
                });
            } else if (apply_type == 'buy_now') {
                result = await BuyNow.findOne({
                    where: {
                        user_id: user_id
                    },
                    attributes: [[sequelize.fn('SUM', sequelize.col('subtotal_amount')), 'total_subtotal_amount']],
                    raw: true
                });
            } else {
                return res.status(409).send({
                    message: 'Something Went Wrong',
                    error: true,
                    success: false,
                    status: '0',
                });

            }
            let subtotal_amount = result.total_subtotal_amount ? parseFloat(result.total_subtotal_amount) : 0;
            const uniqueCoupons = [...new Set(coupon_Arr)];

            // Group by unique coupons
            const groupedCoupons = uniqueCoupons.reduce((group, coupon) => {
                if (!group[coupon]) {
                    group[coupon] = [];
                }
                group[coupon].push(coupon);
                return group;
            }, {});

            for (const coupon_code_sngle of uniqueCoupons) {
                const couponDetails = await Coupon.findOne(
                    {
                        where: {
                            coupon_code: coupon_code_sngle,
                            // status: '1',
                            status: {
                                [Op.in]: ['1', '2'],
                            },
                            is_deleted: 0,
                            number_of_uses: {
                                [Op.gt]: 0,
                            },
                            from_date: {
                                [Op.lte]: getCurrentDate()
                            },
                            to_date: {
                                [Op.gte]: getCurrentDate()
                            }
                        }
                        , attributes: ['id', 'multiple_use', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt']
                    });
                // add by suresh 15-11-2024 user can use multiple time and single time one coupon
                const appliedCoupons = await Order.findAll({
                    where: {
                        user_id,
                        [Op.or]: [
                            { discount_id: couponDetails.id.toString() },
                            sequelize.literal(`FIND_IN_SET(${couponDetails.id}, discount_id) > 0`)
                        ]
                    },
                });
                var is_applied = appliedCoupons.length > 0 ? 1 : 0;
                // end
                if (!couponDetails) {
                    return res.status(409).send({
                        message: 'Coupon not valid',
                        error: true,
                        success: false,
                        status: '010',
                        coupon_code: coupon_code_sngle,
                    });
                }
                else if (is_applied && couponDetails.multiple_use == "1") {
                    return res.status(409).send({
                        message: 'Coupon Already Redeemed',
                        error: true,
                        success: false,
                        status: '0'
                    });

                }
                else {
                    const check_order_exist = await Order.count({
                        where: {
                            user_id: user_id,
                        },
                        // attributes: ['id']
                    });


                    var min_amount = couponDetails ? couponDetails.min_amount : 0;
                    var upto_amount = couponDetails ? couponDetails.upto_amount : 0;

                    if ((min_amount >= 0 && min_amount > subtotal_amount) || (upto_amount > 0 && upto_amount < subtotal_amount)) {
                        return res.status(202).send({
                            message: `Order amount less then ${min_amount} and amount greater then ${upto_amount}`,
                            error: true,
                            success: false,
                            status: '0'
                        });
                    }
                    const couponAddDisount = await OrderDiscountCoupon.findOne({
                        where: {
                            user_id: user_id,
                            applied_status: 1,
                            discount_mode: apply_type,
                            discount_type: {
                                [Op.in]: ['first_order', 'order']
                            }
                        },
                        attributes: [
                            [sequelize.fn('SUM', sequelize.col('discount_amt')), 'totalDiscountAmt']
                        ]
                    });
                    const totalDiscountAmt = couponAddDisount ? couponAddDisount.get('totalDiscountAmt') : 0;
                    //end add Suresh 17-oct-2024
                    var dis_amt = subtotal_amount - totalDiscountAmt;
                    if (couponDetails.coupon_type === 'percent') {
                        var discount_amount = (Math.round(dis_amt) * couponDetails.type_val) / 100;
                    }

                    // else if (couponDetails.coupon_type === 'normal') {
                    //     var discount_amount = couponDetails.type_val;
                    // }
                    const discount = await OrderDiscountCoupon.findOne({
                        where: {
                            user_id: user_id,
                            discount_mode: apply_type,
                            discount_type: couponDetails?.apply_to.toLowerCase(),
                            discount_id: couponDetails?.id
                        },
                        attributes: ['id', 'discount_type', 'discount_id'],
                    });
                    var dataCoupon = '';
                    if ((couponDetails?.apply_to == 'FIRST_ORDER') && (check_order_exist < 1)) {
                        if (discount) {
                            const discountCoupon = discount.get({ plain: true });
                            await OrderDiscountCoupon.update({
                                user_id: user_id,
                                discount_mode: apply_type,
                                discount_id: couponDetails.id,
                                discount_amt: discount_amount,
                                discount_type: couponDetails.apply_to.toLowerCase(),
                                updated_at: getCurrentDateTime(),
                            }, {
                                where: {
                                    id: discountCoupon?.id
                                }
                            });
                        } else {
                            dataCoupon = await OrderDiscountCoupon.create({
                                user_id: user_id,
                                discount_id: couponDetails.id,
                                discount_mode: apply_type,
                                discount_amt: discount_amount,
                                discount_type: couponDetails.apply_to.toLowerCase(),
                                created_at: getCurrentDateTime(),
                            });
                        }
                        // return res.status(200).send({
                        //     message: process.env.SUCCESS_MSG,
                        //     error: false,
                        //     success: true,
                        //     status: '1',
                        //     user_id: user_id,
                        //     data: discount_amount
                        // });
                    } else {
                        if ((couponDetails?.apply_to != 'FIRST_ORDER')) {
                            if (discount) {
                                const discountCoupon = discount.get({ plain: true });
                                await OrderDiscountCoupon.update({
                                    discount_amt: discount_amount,
                                    discount_mode: apply_type,
                                    discount_type: couponDetails.apply_to.toLowerCase(),
                                    updated_at: getCurrentDateTime(),
                                }, {
                                    where: {
                                        id: discountCoupon.id,
                                        user_id: user_id,
                                    }
                                });

                            } else {
                                dataCoupon = await OrderDiscountCoupon.create({
                                    user_id: user_id,
                                    discount_id: couponDetails.id,
                                    discount_mode: apply_type,
                                    discount_amt: discount_amount,
                                    discount_type: couponDetails.apply_to.toLowerCase(),
                                    created_at: getCurrentDateTime(),
                                });
                            }
                        }
                    }
                }
            }

            const apply_coupon_list = await OrderDiscountCoupon.findAll({
                where: {
                    user_id: user_id,
                },
                attributes: ['discount_id']
            });
            const discountIdArray = apply_coupon_list.map(item => item?.discount_id);



            const coupon_details_s = await Coupon.findAll({
                where: {
                    id: {
                        [Op.in]: discountIdArray,
                    },
                    // status: '1',
                    status: {
                        [Op.in]: ['1', '2'],
                    },
                    is_deleted: 0
                },
            })
            if (coupon_details_s[0]) {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    user_id: user_id,
                    data: coupon_details_s,
                });
            } else {
                res.status(200).send({
                    message: 'Records Not found',
                    error: true,
                    success: false,
                    status: '0',
                    user_id: user_id,
                    // data: coupon_details_s,
                });
            }

        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}



module.exports = {
    GethHomePRoduct, Getmoreproduct, GetCategoryDetail, GetColorWiseProduct, GetSearchKeywordProduct, ApplyCoupon

};
