const bodyParser = require('body-parser');
const express = require('express')
const jwt = require('jsonwebtoken');
const Joi = require('joi');
const User = require('../../apps/models/User');
const Collections = require('../../apps/models/ProductCollections');
const Product = require('../../apps/models/master/Product');
const ProductType = require('../../apps/models/master/ProductType');
const Category = require('../../apps/models/master/Category');
const ProductMedia = require("../../apps/models/master/ProductMedia");
const Wishlist = require("../../apps/models/master/Wishlist");
const ProductNotifyModel = require("../../apps/models/master/ProductNotifyModel");
const SiteSellerProducts = require("../../apps/models/master/SiteSellerProducts");
const ProductVariant = require("../../apps/models/master/ProductVariant");
const Color = require("../../apps/models/master/Color");
const Size = require("../../apps/models/master/Size");
const Country = require('../../apps/models/master/Country');
const State = require('../../apps/models/master/State');
const City = require('../../apps/models/master/City');
const UserWallet = require("../models/master/UserWallet");
const UserAddress = require("../../apps/models/master/UserAddress");
const EmailTemplate = require("../../apps/models/master/EmailTemplate");
const md5 = require('md5');
const multer = require('multer');
const secretKey = 'storepedia277833';
const currentDate = new Date();
const current_date = Date.now();
const fs = require('fs');
const path = require('path');
const moment = require('moment');
//const Op = require('sequelize').Op;
const { Op } = require('sequelize');
const sequelize = require('sequelize');
const { sendDynamicEmail, sendEmailWith_temp } = require('../config/mail');

//Product collection record
const ProductCollections = async (req, res) => {
    var categoryId = req.body.category_id;
    var typeId = req.body.type_id;
    var productId = req.body.product_id;
    /*
    let recordCategory = await Category.findAll({ order: [['id', 'DESC']],where:{status:'1',parent_id:0}, attributes: ['id', 'slug', 'name', 'description', 'image'], include: [{
        model: Category,
        as: "child_items",
        attributes: ['id', 'slug', ['name', 'child_name'], 'description', 'image'],
        where: { status: '1' },
        required: false,
        include:
        {
            model: Category,
            as: "child_items",
            attributes: ['id', 'slug', ['name', 'child_name'], 'description', 'image'],
            where: { status: '1' },
            required: false
        }
    }] }); */
    //let recordType = await ProductType.findAll({where: {status: '1'},attributes: ['id', 'type_name']});
    var where_con = '';
    let includes_rel = [{model: Product,as:'product',attributes: ['product_name','product_slug'],required: false},{model: Category,as: 'category',attributes: ['name','slug'],required: false}];
    if(!empty(productId)){
        where_con = {product_id:productId};
    } else if(!empty(categoryId)){
        where_con = {category_id:categoryId};
    } 
    let recordCollections;
    
    try {
        if(!empty(where_con)){
            recordCollections = await Collections.findAll({ order: [['id', 'DESC']],where:where_con, attributes: ['id', 'product_id', 'category_id', 'name','slug', 'collection_type', 'min_collection_value', 'max_collection_value', 'collection_image', 'status'],virtuals: ['product_url'], include: includes_rel }); 
           
        } else {

            recordCollections = await Collections.findAll({order: [['id', 'DESC']], attributes: [
                'id',
                'product_id',
                'category_id',
                'redirect_on',
                'name',
                'slug',
                'collection_type',
                'min_collection_value',
                'max_collection_value',
                'collection_image',
                'status'
            ],virtuals: ['product_url'], include: includes_rel
            }); 

           
        }
        

        // Assuming this is inside an async function
        for (const products of recordCollections) {
            var redirect_ons = (!empty(products.redirect_on) ? products.redirect_on : 0);
            var category_ids = (!empty(products.category_id) ? products.category_id : 0);
            var product_ids = (!empty(products.product_id) ? products.product_id : 0);
            var slugs = products?.dataValues?.slug;
            
            // Use await here
            const productUrl = await urlRecords(redirect_ons, category_ids, product_ids,slugs);
            
            products.dataValues.productUrl = productUrl;
        }
        
    } catch (err) {
        console.error("Error fetching collections:", err);
        res.status(500).send("Internal Server Error");
    }
    
    res.status(200).send({
        message: 'Product Collection successful',
        error: false,
        success: true,
        status: '1',
        //categoryAll: recordCategory,
        //typeAll: recordType,
        path:process.env.SITE_URL+'uploads/collection/',
        data: recordCollections
    }); 
};

const CollectionsProductList = async (req, res) => {
    const collectionId = parseInt(req.params.id.replace(':', ''), 10);
    const user_id = req.body.user_id || 0;
    let recordProducts;
    let recordCollections;
    let where_con;
    try {
        // Fetch collection details
        recordCollections = await Collections.findOne({
            where: { id: collectionId },
            attributes: [
                'id', 'product_id', 'category_id', 'type_id', 'name', 
                'collection_type', 'min_collection_value', 'max_collection_value', 
                'collection_image', 'created_by', 'status', 'created_at', 
                'modefied_by', 'modefied_at'
            ]
        });

        if (!recordCollections) {
            return res.status(404).send({ message: 'Collection not found', error: true });
        }

        let discount_min, discount_max, pieces_min, pieces_max;
        const { collection_type, min_collection_value, max_collection_value, category_id, type_id, product_id } = recordCollections;
        
        // Set discount or pieces range based on collection type
        if (collection_type === 1) {
            discount_min = min_collection_value;
            discount_max = max_collection_value;
        } else {
            pieces_min = min_collection_value;
            pieces_max = max_collection_value;
        }
        
        if(!empty(category_id) && !empty(product_id)){
            
            if(!empty(discount_min) && !empty(discount_max)){
                where_con = {status: '1',is_deleted: 0,category_id: {[Op.like]: `%${category_id}%`},id:product_id,discount: {[Op.between]: [discount_min, discount_max]}};
            } else if(!empty(pieces_min) && !empty(pieces_max)){
                where_con = {status: '1',is_deleted: 0,category_id: {[Op.like]: `%${category_id}%`},id:product_id,stock_quantity: {[Op.between]: [pieces_min, pieces_min]}};
            }
            
        } else if(!empty(category_id) && !empty(type_id)){
            
            if(!empty(discount_min) && !empty(discount_max)){
                where_con = {status: '1',is_deleted: 0,category_id: {[Op.like]: `%${category_id}%`},discount: {[Op.between]: [discount_min, discount_max]}};
            } else if(!empty(pieces_min) && !empty(pieces_max)){
                where_con = {status: '1',is_deleted: 0,category_id: {[Op.like]: `%${category_id}%`},stock_quantity: {[Op.between]: [pieces_min, pieces_min]}};
            }
        } else if(!empty(category_id) && !empty(product_id)){
            
            if(!empty(discount_min) && !empty(discount_max)){
                where_con = {status: '1',is_deleted: 0,category_id: {[Op.like]: `%${category_id}%`},id:product_id,discount: {[Op.between]: [discount_min, discount_max]}};
            } else if(!empty(pieces_min) && !empty(pieces_max)){
                where_con = {status: '1',is_deleted: 0,category_id: {[Op.like]: `%${category_id}%`},id:product_id,stock_quantity: {[Op.between]: [pieces_min, pieces_min]}};
            }
        } else if(!empty(type_id) && !empty(product_id)){
            
            if(!empty(discount_min) && !empty(discount_max)){
                where_con = {status: '1',is_deleted: 0,id:product_id,discount: {[Op.between]: [discount_min, discount_max]}};
            } else if(!empty(pieces_min) && !empty(pieces_max)){
                where_con = {status: '1',is_deleted: 0,id:product_id,stock_quantity: {[Op.between]: [pieces_min, pieces_min]}};
            }
        } else if(!empty(product_id)){
            
            if(!empty(discount_min) && !empty(discount_max)){
                where_con = {status: '1',is_deleted: 0,id:product_id,discount: {[Op.between]: [discount_min, discount_max]}};
            } else if(!empty(pieces_min) && !empty(pieces_max)){
                where_con = {status: '1',is_deleted: 0,id:product_id,stock_quantity: {[Op.between]: [pieces_min, pieces_min]}};
            }
        } else if(!empty(category_id)){
            
            if(!empty(discount_min) && !empty(discount_max)){
                where_con = {status: '1',is_deleted: 0,category_id: {[Op.like]: `%${category_id}%`},discount: {[Op.between]: [discount_min, discount_max]}};
            } else if(!empty(pieces_min) && !empty(pieces_max)){
                where_con = {status: '1',is_deleted: 0,category_id: {[Op.like]: `%${category_id}%`},stock_quantity: {[Op.between]: [pieces_min, pieces_min]}};
            }
        } else if(!empty(type_id)){
            
            if(!empty(discount_min) && !empty(discount_max)){
                where_con = {status: '1',is_deleted: 0,type_id:type_id,discount: {[Op.between]: [discount_min, discount_max]}};
            } else if(!empty(pieces_min) && !empty(pieces_max)){
                where_con = {status: '1',is_deleted: 0,type_id:type_id,stock_quantity: {[Op.between]: [pieces_min, pieces_min]}};
            }
        }
        console.log(where_con);
        
        let where_user = '';
        if(!empty(user_id)){
            where_user = { user_id: user_id };
        } 
            
        // Fetch product records
        recordProducts = await Product.findAll({
            order: [['id', 'DESC']],
            where: where_con,
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price',[
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),'is_wishlist'
            ],[sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['is_default', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    //where: { is_default: '1' },
                    limit: 2,
                    required: false,
                    order: [['is_default', 'DESC']]
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: where_user,
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: where_user,
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
        });

        

    } catch (err) {
        console.error("Error fetching collections:", err);
        return res.status(500).send({ message: "Internal Server Error", error: true });
    }
    /*
    if (!recordProducts || recordProducts.length === 0) {
        return res.status(404).send({ message: 'No products found for this collection', error: true });
    } */

    res.status(200).send({
        message: 'Product Collection fetched successfully',
        error: false,
        success: true,
        status: '1',
        where_con: where_con,
        data: recordProducts
    });
};

// Helper function to check for emptiness
function empty(value) {
    if (value === undefined || value === null) return true;
    if (typeof value === 'string' || typeof value === 'boolean') return value === '' || value === '0' || value === false;
    if (typeof value === 'number') return value === 0;
    if (Array.isArray(value)) return value.length === 0;
    if (typeof value === 'object') return Object.keys(value).length === 0;
    return false;
}


async function urlRecords(redirect_on, category_id, product_id,collection_slug) {
    const urls = `${process.env.SITE_URL}api/user`;
    let product_url = '';
    console.log(collection_slug);
    try {
        if(!empty(redirect_on == 2)){
            if (!empty(category_id)) {
                const recordCategory = await Category.findOne({
                    order: [['id', 'DESC']],
                    where: { status: '1', id: category_id },
                    attributes: ['slug']
                });
                if (recordCategory && recordCategory.slug) {
                    //product_url = `${urls}/get-category-detail/${recordCategory.slug}`;
                    product_url = recordCategory.slug+'?collections='+collection_slug;
                }
            }
        } else {
            const recordProducts = await Product.findOne({
                where: { status: '1', is_deleted: 0, id: product_id },
                attributes: ['product_slug']
            });
            if (recordProducts && recordProducts.product_slug) {
               // product_url = `${urls}/get-product-detail/${recordProducts.product_slug}`;
                product_url = recordProducts.product_slug+'?collections='+collection_slug;
            }
        }
        
    } catch (error) {
        console.error("Error fetching records:", error);
    }
    return product_url;
}

module.exports = {ProductCollections,CollectionsProductList};
