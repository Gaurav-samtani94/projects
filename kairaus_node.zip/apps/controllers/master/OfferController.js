const Offers = require('../../models/master/Offers')
const OrderDiscountCoupon = require("../../models/master/OrderDiscountCoupon");
const Coupon = require("../../models/master/Coupon");
const moment = require('moment')
const getCurrentDateTime = () => new Date();
const Op = require('sequelize').Op;
const sequelize = require('sequelize');
const UserCoupon = require("../../models/master/UserCoupon");
const Order = require("../../models/master/Order");







const listOffers = async (req, res) => {
    try {


        const offers = await Offers.findAll({
            where: {status: '1'},
            order: [['order_id', 'ASC']]
        })


        const user_id = req.body.user_id || 0;

        const usercoupons = await UserCoupon.findAll({
            where: {
                user_id: user_id,
            },
            attributes: ['coupon_id'],

        });

       
        const couponIds = usercoupons.map(coupon => coupon.coupon_id);
        var current_datee = moment(getCurrentDateTime()).format("YYYY-MM-DD");
        const coupon = await Coupon.findAll({
            where: {
                apply_to: 'ORDER',
                // apply_to:{ [Op.ne]: "FIRST_ORDER" },
                to_date: { [Op.gte]: current_datee },
                from_date: { [Op.lte]: current_datee },
                status: '1',
                is_deleted: 0,
                [Op.or]: [
                    { coupon_allow: '1' },
                    { id: { [Op.in]: couponIds } },
                ],
            },
            attributes: ['id', 'coupon_code','sticker', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN applied_coupon.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_coupon'
            ]],
            include: [
                {
                    model: OrderDiscountCoupon,
                    as: 'applied_coupon',
                    attributes: ['id'],
                    where: { user_id: user_id, discount_type: 'order' },
                    required: false,
                }
            ],
        });
        const firstOrder = await Coupon.findOne({
            where: {
                apply_to: 'FIRST_ORDER',
                status: '1',
                is_deleted: 0,
            },
            attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'
                , [
                    sequelize.literal(`CASE WHEN applied_coupon.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                    'is_applied'
                ]
            ],
            include: [
                {
                    model: OrderDiscountCoupon,
                    as: 'applied_coupon',
                    attributes: ['id'],
                    where: { user_id: user_id, discount_type: 'order' },
                    required: false,
                }
            ],
        });

        const orderCount = await Order.count({
            where: {
                user_id: user_id,
                payment_status: { [Op.in]: [0, 1] }
            }
        });
        const coupon_item={
            coupon_msg:process.env.COUPONMESSAGE,
            coupon_img:process.env.COUPONIMG,
        };

        if (!offers[0]) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                baseURL: 'https://api.growthgrids.com/storepedia/uploads/stickers/',
                order_count: orderCount,
                coupon_item: coupon_item,
                firstOrder: firstOrder,
                coupon: coupon,
                offers: offers
            });
        }

      
        
    } catch (error) {
        return res.status(500).send({
            message: 'Internal Server Error',
            status: '0', 
            error: true,
            success: false,
            msg: error.message
        })

    }
}


module.exports = {
    listOffers
}