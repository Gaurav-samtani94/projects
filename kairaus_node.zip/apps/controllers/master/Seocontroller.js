
const Country = require("../../models/master/Country");
const Blog = require("../../models/master/Blog");
const Blog_faq = require("../../models/master/BlogFaq");
require('dotenv').config();
const currentDate = new Date();
const Joi = require('joi');
const getblogfaq = async (req, res) => {
    const schema = Joi.object().keys({
        blog_title: Joi.string().required(),
    });
    const dataToValidate = {
        blog_title: req.body.blog_title,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(404).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        //var bodyTitles= req.body.blog_title;
        const response = await Blog.findOne({
            // order: [['country_name', 'ASC']],
            where: { status: '1', slug: req.body.blog_title },
            attributes: ['id'],
        });
        try {
            
            if (!response) {
                return res.status(404).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const response_2 = await Blog_faq.findAll({
                    // order: [['country_name', 'ASC']],
                    where: { status: '1', blog_id: response?.id },
                    // attributes: ['id', 'country_name'],
                });
                if (!response_2[0]) {
                    return res.status(404).send({
                        message: 'Recorde Not Founds',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    return res.status(200).send({
                        message: 'Recorde Not Founds',
                        error: false,
                        success: true,
                        status: '1',
                        data: response_2,

                    });
                }


            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: error.message
            });

        }
    }
}


module.exports = {
    getblogfaq
};    