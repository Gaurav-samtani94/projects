const jwt = require('jsonwebtoken');
const FaqCategory =  require("../../models/master/FaqCategory");
const Faq =  require("../../models/master/Faq");
const { sendDynamicEmail, sendEmailWith_temp } = require('../../config/mail');

const multer = require('multer');
const fs = require('fs');
const moment = require('moment')
const slugify = require('slugify')
require('dotenv').config();
// const currentDate = new Date();
const current_date = new Date();
const Joi = require('joi');
const path = require('path');
const Op = require('sequelize').Op;


//get faq category
const GetFaqCategory = async (req, res) => {
    const type = req.body.type;

    const schema = Joi.object().keys({
        type: Joi.number().required().label("type"),
    });
    const dataToValidate = {
        type: type,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
        error: true,
        success: false,
        status: "0",
        message: result.error.details[0].message,
        });
    } else {
        try {
            const faqCategory = await FaqCategory.findAll({
                limit: 10,
                order: [["id", "ASC"]],
                where: {
                status: "1",
                product_display: "0",
                type: type,
                },
                attributes: ["id", "name"],
            });
            if (faqCategory == 0) {
                res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: "0",
                });
            } else {
                res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                data: faqCategory,
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: "0",
            });
        }
    }
};
//get faq category

//get faq list
const GetFaqList = async (req, res) => {
    const type = req.body.type;

    const schema = Joi.object().keys({
        type: Joi.number().required().label("type"),
    });
    const dataToValidate = {
        type: type,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
        error: true,
        success: false,
        status: "0",
        message: result.error.details[0].message,
        });
    } else {
        try {
            const faq = await FaqCategory.findAll({
                limit: 10,
                order: [["id", "ASC"]],
                attributes: ["id", "name"],
                where: {
                status: "1",
                product_display: "0",
                type: type,
                },
                include: [
                {
                    model: Faq,
                    as: "faq",
                    attributes: ["id", "question", "answer"],
                    limit: 10,
                    order: [["id", "DESC"]],
                    where: { status: "1", type: "1" },
                    required: false,
                },
                ],
            });
            if (faq == 0) {
                res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: "0",
                });
            } else {
                res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                data: faq,
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: "0",
            });
        }
    }
};
//get faq list

module.exports = {
    GetFaqCategory, GetFaqList
};
   

