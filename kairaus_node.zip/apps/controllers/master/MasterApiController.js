const jwt = require('jsonwebtoken');
const City = require("../../models/master/City");
const Country = require("../../models/master/Country");
const Currency = require("../../models/master/Currency");
const Gender = require("../../models/master/Gender");
const Prefix = require("../../models/master/Prefix");
const State = require("../../models/master/State");
const Timezones = require("../../models/master/Timezones");
const Color = require("../../models/master/Color");
const Size = require("../../models/master/Size");
const Menu = require("../../models/master/Menu");
const PageMstr = require("../../models/master/PageMstr");
const Role = require("../../models/master/Role");
const StaticPage = require("../../models/master/StaticPage");
const Category = require("../../models/master/Category");
const SubCategory = require("../../models/master/SubCategory");
const Wishlist = require("../../models/master/Wishlist");
const Cart = require("../../models/master/Cart");
const UserAddress = require("../../models/master/UserAddress");
const WishlistCategory = require("../../models/master/WishlistCategory");
const UserWallet = require("../../models/master/UserWallet");
const Product = require("../../models/master/Product");
const User = require("../../models/User");
const Query = require("../../models/master/Query");
const Coupon = require("../../models/master/Coupon");
const UserCoupon = require("../../models/master/UserCoupon");
const WalletMain = require("../../models/master/WalletMain");
const Seo = require("../../models/master/Seo");
const ProductVariant = require("../../models/master/ProductVariant");
const ProductMedia = require("../../models/master/ProductMedia");
const HomeSlider = require("../../models/master/HomeSlider");
const Tag = require("../../models/master/Tag");
const NewsLetter = require("../../models/master/NewsLetter");
const HomeSection = require("../../models/master/HomeSection");
const ProductType = require("../../models/master/ProductType");
const ProductMaterial = require("../../models/master/ProductMaterial");
const MenuCategory = require("../../models/master/MenuCategory");
const Blog = require("../../models/master/Blog");
const Review = require("../../models/master/Review");
const Order = require("../../models/master/Order");
const OrderItem = require("../../models/master/OrderItem");
const ProductVariantGroup = require("../../models/master/ProductVariantGroup");
const Variant = require("../../models/master/Variant");
const HomeGiftVisits = require("../../models/master/HomeGiftVisits");
const HomeGridVisits = require("../../models/master/HomeGridVisits");
const Feedback = require('../../models/master/Feedback');
const ShipPincode = require('../../models/master/ShipPincode');
const ProductReviewLike = require("../../models/master/ProductReviewLike");
const HomeGiftGridLayout = require('../../models/master/HomeGiftGridLayout');
const RelatedProduct = require('../../models/master/RelatedProduct');
const MenuImages = require("../../models/master/MenuImages");
const CategoryImages = require("../../models/master/CategoryImages");
const RewardPointWallet = require('../../models/master/RewardPointWallet');
const EarnRewardPoint = require('../../models/master/EarnRewardPoint');
const NavigationMenu = require('../../models/master/NavigationMenu');
const AssignPageSlider = require('../../models/master/AssignPageSlider');
const PageSlider = require('../../models/master/PageSlider');
const PageSliderImages = require('../../models/master/PageSliderImages');
const ShopCategoryPosition = require('../../models/master/ShopCategoryPosition');
const BulkOrderInformation = require('../../models/master/BulkOrderInformation');
const Setting = require('../../models/master/Setting');
const FaqCategory = require("../../models/master/FaqCategory");
const Faq = require("../../models/master/Faq");
const SearchKeywordTemplate = require("../../models/master/SearchKeywordTemplate");
const UserProductView = require("../../models/master/UserProductView");
const TrendingKeyword = require("../../models/master/TrendingKeyword");
const ContactUsQuery = require("../../models/master/ContactUsQueryModel");
const ContactUsModel = require("../../models/master/ContactUsModel");
const ProductAttributeType = require("../../models/master/ProductAttributeType");
const ProductAttributeValue = require("../../models/master/ProductAttributeValue");
const ProductAttributes = require("../../models/master/ProductAttributes");
const ProductDiscountRange = require("../../models/master/ProductDiscountRange");
const ProductNotifyModel = require("../../models/master/ProductNotifyModel");
const ReviewImages = require("../../models/master/ReviewImages");
const EmailTemplate = require("../../models/master/EmailTemplate");
const SiteSellerProducts = require("../../models/master/SiteSellerProducts");
const GroupComboProducts = require("../../models/master/GroupComboProducts");
const GroupComboProductsQty = require("../../models/master/GroupComboProductsQty");
const InvtProduct = require("../../models/master/InvtProduct");
const RelInvtStrpdProduct = require("../../models/master/RelInvtStrpdProduct");
const InvtQty = require("../../models/master/InvtQty");
const FileModel = require("../../models/master/FileModel");
const OrderDiscountCoupon = require("../../models/master/OrderDiscountCoupon");
const BuyNow = require("../../models/master/BuyNow");
const OrderHistoryModel = require('../../models/master/OrderHistory');
const QueryList = require('../../models/master/QueryList')
const HomePageSectionModel = require('../../models/master/HomepageSection')
const ThemeSettingModel = require('../../models/master/ThemeModel')
const AppBannerModel = require('../../models/master/AppBannerModel')
const Header_contentDiscountModel = require('../../models/master/Header_contentDiscountModel')
const TrackOrder = require('../../models/master/TrackOrder')
const OrderReturn = require('../../models/master/OrderReturn')
const HomeCollectionModel = require('../../models/master/HomeCollectionMaster')
const OrderReturnReasons = require('../../models/master/OrderReturnReasons')
const CustomerStorie = require('../../models/master/CustomerStorie')
const CollectionAssignProductsModel = require('../../models/master/CollectionAssignProductsModel')
const { sendDynamicEmail, sendEmailWith_temp, generatePDFAndSendEmail } = require('../../config/mail');
const { sendEmail } = require("../../emailtemplates/SendMail");
const multer = require('multer');
const fs = require('fs');
const moment = require('moment')
const slugify = require('slugify')
require('dotenv').config();
// const currentDate = new Date();
const current_date = new Date();
const getCurrentDateTime = () => new Date();
const Joi = require('joi');
const path = require('path');
const Op = require('sequelize').Op;
const sequelize = require('sequelize');
const secretKey = 'storepedia277833';
const md5 = require('md5');
const axios = require('axios');
const qs = require('qs');

//get gender list start
const GetGenderList = async (req, res) => {
    try {
        const genders = await Gender.findAll({
            where: {
                status: '1'
            },
            attributes: ['id', 'name']
        });
        if (genders == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: genders
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get gender list end

//get color list start

const OldGetColorList = async (req, res) => {
    const slug = req.body.slug;
    try {
        var categories = await NavigationMenu.findOne({
            where: {
                slug: slug,
                type: 3
            },
            attributes: ['id', 'menu_id']
        });
        if (categories) {
            const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
            var catIds = [categories['menu_id']].concat(subcategoryIds);
        } else {
            var catIds = [];
        }

        var pcondi = {
            [Op.or]: catIds.map(catId => ({
                [Op.or]: [
                    { category_id: catId.toString() },
                    { category_id: { [Op.like]: `%,${catId}` } },
                    { category_id: { [Op.like]: `${catId},%` } }
                ]
            })),
            status: '1',
            is_deleted: '0'
        };

        const products = await Product.findAll({
            where: pcondi,
            attributes: ['id']
        });
        const pIdArr = products.map(product => product ? product.id : null);
        const productAttribute = await ProductAttributes.findAll({
            where: { product_id: { [Op.in]: pIdArr }, attr_type_id: 2 },
            attributes: ['attr_val_id'],
            required: false,
        });

        const colorIdArr = productAttribute.map(productattr => productattr ? productattr.attr_val_id : null);
        const color = await ProductAttributeValue.findAll({
            where: { id: { [Op.in]: colorIdArr }, prod_attr_type_id: 2 },
            attributes: ['id', ['attr_val_name', 'color'], 'image'],
            required: false,
        });

        if (color == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                // message: 'suresh',
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/color_image/',
                data: color
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const GetColorList = async (req, res) => {
    const slug = req.body.slug;
    const keyword = req.body.keyword || 0;
    const menu_product = req.body.menu_product || 0;

    let CollectionMasterArray = [];
    let slugIdInMasterCollection = await HomeCollectionModel.findOne({
        where: { slug: slug, status: '1' },
        attributes: ['id', ['collection_name', 'name'], ['collection_image', 'image'], 'slug']
    })

    try {
        if (slug == 'newarrival') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            };

        } else if (slug == 'bestseller') {
            var pcondi = {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0'
            };
        } else if (slug == 'finestProduct') {
            var pcondi = {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
            };
        } else if (slug == 'bigsavings') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
            };

        } else if (slug == 'allProduct') {
            var pcondi = {
                product_name: { [Op.like]: `%${keyword}%` },
                status: '1',
                is_deleted: '0'
            };
        } else if (slugIdInMasterCollection) {
            slugIdInMasterCollection = slugIdInMasterCollection.toJSON();
            slugIdInMasterCollection.assign_slider = null
            const result = await CollectionAssignProductsModel.findAll({
                where: {
                    collection_id: slugIdInMasterCollection.id,
                    status: '1'
                },
                attributes: ['product_id'],
            });
            CollectionMasterArray = result.map(data => data.product_id);

            var pcondi = {
                id: {
                    [Op.in]: CollectionMasterArray.length > 0
                        ? CollectionMasterArray
                        : [0],
                },
                status: '1',
                is_deleted: '0'
            };
        } else {
            if (menu_product == 'menu_product') {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 1
                    },
                    attributes: ['id', 'menu_id']
                });
            } else {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 3
                    },
                    attributes: ['id', 'menu_id']
                });
            }
            if (categories) {
                const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
                var catIds = [categories['menu_id']].concat(subcategoryIds);
            } else {
                var catIds = [];
            }
            if (slug === 'offers') {
                var pcondi = {
                    status: '1',
                    is_deleted: '0',
                    discount: { [Op.gt]: 0 }
                };
            } else {
                var pcondi = {
                    [Op.or]: catIds.map(catId => ({
                        [Op.or]: [
                            { category_id: catId.toString() }, // Exact match
                            sequelize.literal(`FIND_IN_SET(${catId}, category_id) > 0`) // Match catId in a comma-separated list
                        ]
                    })),
                    status: '1',
                    is_deleted: '0'
                };
            }
        }
        const products = await Product.findAll({
            where: pcondi,
            attributes: ['id'],
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
        });
        const pIdArr = products.map(product => product ? product.id : null);
        const productAttribute = await ProductAttributes.findAll({
            where: { product_id: { [Op.in]: pIdArr }, attr_type_id: 2 },
            attributes: ['attr_val_id'],
            required: false,
        });

        const colorIdArr = productAttribute.map(productattr => productattr ? productattr.attr_val_id : null);
        const color = await ProductAttributeValue.findAll({
            where: { id: { [Op.in]: colorIdArr }, prod_attr_type_id: 2 },
            attributes: ['id', ['attr_val_name', 'color'], 'image'],
            required: false,
        });

        if (color == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                // message: 'suresh',
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/color_image/',
                data: color
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get color list end

//get currency list start
const GetCurrencyList = async (req, res) => {
    try {
        const currencies = await Currency.findAll({
            where: {
                status: '1'
            },
            attributes: ['id', 'name', 'code']
        });
        if (currencies == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: currencies
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get currency list end

//get size list start
const GetSizeList = async (req, res) => {
    try {
        const sizes = await Size.findAll({
            where: { status: '1' },
            attributes: ['id', 'size']
        });
        if (sizes == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: sizes
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get size list end

//get menu list start
// const GetMenuList = async (req, res) => {
//     var category_id = req.body.category_id;
//     try {
//         const categories = await getParentMenuCategoriesWithSubcategories(category_id);
//         const datastore = [];
//         if (category_id) {

//             const response_3 = await Product.findAll({
//                 where: {
//                     status: '1',
//                     [Op.and]: sequelize.literal(`FIND_IN_SET('${category_id}', category_id)`)
//                 },
//                 attributes: ['id']
//             })
//             if (response_3.length > 0) {
//                 datastore.push(categories);
//             }
//         }
//         if (datastore < 1) {
//             res.status(202).send({
//                 message: process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         } else {
//             res.status(200).send({
//                 message: process.env.SUCCESS_MSG,
//                 category_path: process.env.SITE_URL + 'uploads/category/',
//                 error: false,
//                 success: true,
//                 status: '1',
//                 data: categories
//             });
//         }
//     } catch (error) {
//         res.status(500).send({
//             message: error,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }


const GetMenuList = async (req, res) => {
    try {
        const categories_1 = await getParentMenuCategoriesWithSubcategories(1);
        const categories_2 = await getParentMenuCategoriesWithSubcategories(2);
        const categories_3 = await getParentMenuCategoriesWithSubcategories(3);
        const categories_4 = await getParentMenuCategoriesWithSubcategories(4);
        const response = {
            categories_1: categories_1,
            categories_2: categories_2,
            categories_3: categories_3,
            categories_4: categories_4,
        }
        if (!response) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: 0
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                category_path: process.env.SITE_URL + 'uploads/category/',
                error: false,
                success: true,
                status: '1',
                data: response
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// Function to fetch parent categories with their subcategories
async function getParentMenuCategoriesWithSubcategories(categoryId) {
    const categories = await NavigationMenu.findAll({
        attributes: ['id', 'menu_id', 'slug', 'name'],
        where: {
            category: categoryId,
            parent_id: '0'
        },
        include: [{
            model: Menu,
            as: 'menus',
            attributes: ['header_image', 'menu_type', 'show_type', 'icon_image'],
            required: false
        }]
    });

    if (!categories || categories.length === 0) {
        return [];
    }

    const result = await Promise.all(categories.map(async category => {
        const subcategories = await getSubcategories(category.id);
        return {
            id: category.id,
            slug: category.slug,
            name: category.name,
            menus: category.menus,
            child_items: subcategories
        };
    }));

    return result;
}

// Recursive function to fetch subcategories
async function getSubcategories(parentCategoryId) {
    const categories = await NavigationMenu.findAll({
        attributes: ['id', 'menu_id', 'slug', 'name'],
        where: { parent_id: parentCategoryId }
    });

    if (!categories || categories.length === 0) {
        return [];
    }

    const result = await Promise.all(categories.map(async category => {
        const subcategories = await getSubcategories(category.id);
        return {
            id: category.id,
            slug: category.slug,
            name: category.name,
            child_items: subcategories
        };
    }));

    return result;
}

const GetSubMenuList = async (req, res) => {
    const menu_id = req.body.menu_id;
    try {
        const menus = await MenuCategory.findAll({
            attributes: ['category_id'],
            where: {
                menu_id: menu_id,
            }
        });
        const catIds = menus.map(menu => menu.category_id);
        const categories = await Category.findAll({
            attributes: ['id', 'slug', 'name', 'image'],
            where: {
                status: '1',
                id: { [Op.in]: catIds }
            },
            include: [{
                model: Category,
                as: "child_items",
                attributes: ['id', 'slug', ['name', 'child_name'], 'description', 'image'],
                where: { status: '1' },
                required: false,
                include:
                {
                    model: Category,
                    as: "child_items",
                    attributes: ['id', 'slug', ['name', 'child_name'], 'description', 'image'],
                    where: { status: '1' },
                    required: false
                }
            }]
        });
        if (categories == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: categories
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get menu list end

//get page list start
const GetPageList = async (req, res) => {
    try {
        const pages = await PageMstr.findAll(
            {
                where: { status: '1' },
                attributes: ['id', 'page_name']
            }
        );
        if (pages == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: pages
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get page list end

//get prefix list start
const GetPrefixList = async (req, res) => {
    try {
        const prefixes = await Prefix.findAll({
            where: { status: '1' },
            attributes: ['id', 'prefix']
        });
        if (prefixes == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: prefixes
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

//get prefix list end

//get timezone list start
const GetTimezoneList = async (req, res) => {
    try {
        const timezones = await Timezones.findAll({
            where: { status: '1' },
            attributes: ['id', 'timezone', 'timezone_abbr', 'offset_value']
        });
        if (timezones == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: timezones
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get timezone list end

//get role list start
const GetRoleList = async (req, res) => {
    try {
        const roles = await Role.findAll({
            where: { status: '1' },
            attributes: ['id', 'role_name']
        });
        if (roles == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: roles
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get role list end

//get state list by country start
const GetStateListByCountry = async (req, res) => {
    const country_id = req.body.country_id;
    const schema = Joi.object().keys({
        country_id: Joi.string().required().label("Country")
    });
    const dataToValidate = {
        country_id: country_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const states = await State.findAll({
                where: {
                    country_id: country_id,
                    status: '1'
                },
                attributes: ['id', 'state_name', 'country_id'],
                include: [{
                    model: Country,
                    attributes: ['id', 'country_name'],
                    where: { status: '1' },
                    required: false
                }]
            });
            if (states == 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: states
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//get state list by country end

//get city list by state start
const GetCityListByState = async (req, res) => {
    const state_id = req.body.state_id;
    const schema = Joi.object().keys({
        state_id: Joi.string().required().label("State")
    });
    const dataToValidate = {
        state_id: state_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const cities = await City.findAll({
                where: {
                    state_id: state_id,
                    status: '1'
                },
                attributes: ['id', 'city_name', 'state_id'],
                include: {
                    model: State,
                    attributes: ['id', 'state_name', 'image_name', 'country_id'],
                    required: false
                }
            });
            if (cities == 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: cities
                });
            }
        } catch (error) {
            res.status(500).send({
                message: error,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//get city list by state end

//get country list start
const GetCountryList = async (req, res) => {
    try {
        const countries = await Country.findAll({
            where: { status: '1' },
            attributes: ['id', 'country_name']
        });
        if (countries == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: countries
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get country list end

//get category list start
async function getCategoryWithSubcategories(condition) {
    const categories = await NavigationMenu.findAll({
        where: condition,
        attributes: ['id', 'slug', 'name'],
        include: [
            {
                model: Category,
                as: 'categories',
                attributes: ['id', 'image'],
                required: false,
            }
        ],
    });

    if (!categories || categories.length === 0) {
        return [];
    }

    const result = await Promise.all(categories.map(async category => {
        const subcategories = await getCategoryWithSubcategories({ parent_id: category.id, type: 3 });
        return {
            id: category.id,
            slug: category.slug,
            name: category.name,
            image: category.categories.image,
            child_items: subcategories
        };
    }));

    return result;
}

async function getParentCategoriesWithSubcategories(slug) {
    const menu = await NavigationMenu.findOne({
        attributes: ['id'],
        where: { slug: slug, type: 1 },
    });

    let condition;
    if (menu) {
        condition = {
            parent_id: menu.id,
            type: 3
        };
    } else {
        condition = {
            slug: slug,
            type: 3
        };
    }

    const categories = await getCategoryWithSubcategories(condition);
    return categories;
}

const GetCategoryList = async (req, res) => {
    const slug = req.body.slug;
    try {
        const categories = await getParentCategoriesWithSubcategories(slug);
        if (categories == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/category/',
                data: categories
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}

async function getSearchCategoriesWithSubcategories() {

    const menus = await NavigationMenu.findAll({
        attributes: ['id'],
        where: { parent_id: 0, type: 1 },
    });
    const menuIds = menus.map(menu => menu.id);

    condition = {
        parent_id: { [Op.in]: menuIds },
        type: 3
    };

    const categories = await getCategoryWithSubcategories(condition);
    return categories;
}

const GetSearchCategoryList = async (req, res) => {
    try {
        const categories = await getSearchCategoriesWithSubcategories();
        if (categories == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/category/',
                data: categories
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}

const GetCategoryParentList = async (req, res) => {
    const slug = req.body.slug;
    try {
        var catIds = [];
        var category = await Category.findOne({
            where: {
                status: '1',
                slug: slug
            },
            attributes: ['parent_id']
        });

        if (category) {
            var pcategory = await Category.findOne({
                where: {
                    status: '1',
                    id: category['parent_id']
                },
                attributes: ['parent_id']
            });
            if (pcategory) {
                var pCatId = pcategory['parent_id'] || category['parent_id'];
            }

            const parentcat = await MenuCategory.findOne({
                attributes: ['menu_id'],
                where: {
                    category_id: pCatId,
                }
            });
            if (parentcat) {
                const menus = await Menu.findOne({
                    attributes: ['id'],
                    where: {
                        id: parentcat['menu_id'],
                        parent: 0
                    }
                });
                if (menus) {
                    const menuscat = await MenuCategory.findAll({
                        attributes: ['category_id'],
                        where: {
                            menu_id: menus['id'],
                        }
                    });
                    var catIds = menuscat.map(menuscate => menuscate.category_id);
                }
            }
        }

        const categories = await Category.findAll({
            where: {
                id: { [Op.in]: catIds },
                status: '1'
            },
            attributes: ['id', 'parent_id', 'name', 'slug', 'description', 'image'],
            include: [{
                model: Category,
                as: "child_items",
                attributes: ['id', 'slug', ['name', 'child_name'], 'description', 'image'],
                where: { status: '1' },
                required: false,
                include:
                {
                    model: Category,
                    as: "child_items",
                    attributes: ['id', 'slug', ['name', 'child_name'], 'description', 'image'],
                    where: { status: '1' },
                    required: false
                }
            }]
        });
        if (categories == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/category/',
                data: categories
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get category list end

//get subcategory list start
const GetSubCategoryList = async (req, res) => {
    try {
        const subcategories = await Category.findAll({
            where:
            {
                status: '1',
                parent_id: {
                    [Op.ne]: '0'
                }
            },
            attributes: ['id', 'name', 'description', 'image']
        });
        if (subcategories == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: subcategories
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get subcategory list end

//wishlist starts
//get wishlist start
const GetWishlist = async (req, res) => {
    const user_id = req.userId;
    try {
        const wishlists = await Wishlist.findAll({
            where: {
                user_id: user_id,
                status: '1'
            },
            attributes: ['id', 'user_id', 'product_id'],
            order: [
                ['id', 'DESC']
            ],
            include: [
                // {
                //     model: Product,
                //     as:'product',
                //     attributes: ['id','product_name'],
                //     where: {status:'1'},
                //     required: false,
                //     include:[
                //         {
                //             model:ProductMedia,
                //             as:'productimages',
                //             attributes: ['file_name','file_name_200_x_200','file_name_180_x_180','file_name_150_x_150','file_name_120_x_120'],
                //             where: {is_default: '1'},
                //             required: false,
                //         }
                //     ]
                // },
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'firstname'],
                    required: false
                }
            ]
        });
        var wishlistData = [];
        for (const wishlist of wishlists) {
            const products = await Product.findOne({
                where: {
                    id: wishlist.product_id
                },
                attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                    sequelize.fn('AVG', sequelize.col('reviews.rating')), // Calculate average rating
                    'average_rating'
                ], [
                        // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                        sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                        'is_wishlist'
                    ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
                include: [
                    {
                        model: ProductMedia,
                        as: 'productimages',
                        attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                        where: { is_default: '1',file_type:'image' },
                        required: false,
                    },
                    {
                        model: Wishlist,
                        as: 'wishlist',
                        attributes: ['id'],
                        where: { user_id: user_id },
                        required: false,
                    },
                    {
                        model: Review, // Assuming you have a model for product ratings
                        as: 'reviews',
                        attributes: [],
                        required: false,
                    },
                    {
                        model: ProductNotifyModel,
                        as: 'product_notify',
                        attributes: ['id'],
                        where: { user_id: user_id },
                        required: false,
                    }
                ]
            });

            wishlistData.push({
                id: wishlist.id,
                user_id: wishlist.user_id,
                product_id: wishlist.product_id,
                product: products,
                user: wishlist.user
            });
        }

        if (wishlists == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                product_path: process.env.SITE_URL + "uploads/products/",
                data: wishlistData
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get wishlist end

//add wishlist start
const AddWishlist = async (req, res) => {
    const user_id = req.userId;
    const product_id = req.body.product_id;
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product")
    });
    const dataToValidate = {
        product_id: product_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const checkProductExists = await Wishlist.findOne({
                where: { product_id: product_id, user_id: user_id },
                attributes: ['id']
            });

            if (checkProductExists) {
                const planWishlists = checkProductExists.get({ plain: true });
                Wishlist.destroy({
                    where: {
                        id: planWishlists['id'],
                    },
                });
                var is_wishlist = 0;
                var wishlists = [];
                var msg = 'Removed from favourite';
            } else {
                wishlists = await Wishlist.create({
                    user_id: user_id,
                    product_id: product_id,
                    wishlist_cate_id: 0,
                    created_at: current_date,
                    created_by: user_id
                });
                var is_wishlist = 1;
                var msg = 'Added to favourite';
            }
            if (!wishlists) {
                res.status(202).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: msg,
                    error: false,
                    success: true,
                    status: '1',
                    is_wishlist: is_wishlist,
                    data: wishlists
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//add wishlist end

//wishlist ends 

//cart starts
//get cart start
const GetCart = async (req, res) => {
    try {
        const user_id = req.userId;
        const carts = await Cart.findAll({
            where: {
                user_id: user_id,
            },
            attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount', 'currency_rate', 'usd_amount', 'currency_symbol', 'currency_code', 'status'],
            include: [
                {
                    model: Product,
                    as: 'product',
                    attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'usd_price', 'usd_compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge'],
                    required: false,
                    include: [
                        {
                            model: ProductMedia,
                            as: 'productimages',
                            attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                            where: { is_default: '1',file_type:'image' },
                            required: false,
                        },
                        // Subquery to check if the product is in the user's wishlist
                        {
                            model: Wishlist,
                            as: 'wishlist',
                            attributes: ['id'],
                            where: { user_id: user_id, product_id: sequelize.col('product.id') }, // Using subquery
                            required: false,
                        }
                    ],
                    // Map the result of the subquery to a virtual attribute 'is_wishlist'
                    // 'is_wishlist' will be true if there's a matching record in the wishlist, otherwise false
                    mapToModel: true,
                    virtuals: ['is_wishlist']
                },
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'firstname']
                },
            ]
        });

        // Transform the result to add 'is_wishlist' attribute to each product
        carts.forEach(cart => {
            if (cart.product) {
                cart.product.dataValues.is_wishlist = cart.product.wishlist ? 1 : 0;
            }
        });
        if (carts == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: carts
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get cart end

//add cart start
// const addToCart = async (req, res) => {
//     const user_id =  req.userId;
//     const products = req.body;
//     try {
//         var stock_quantity_availability = [];
//         for (const product of products) {

//             const checkCartExists = await Cart.findOne({
//                 where: {
//                     product_id: product.product_id,
//                     product_variant_id: product.product_variant_id,
//                     user_id: user_id,
//                     status:1
//                 }
//             });

//             var cartqty = checkCartExists ? checkCartExists.quantity + product.quantity : 0;
//             //check avlaiable qty
//             const productDetail = await Product.findOne({
//                 attributes: ['price','stock_quantity','product_name','usd_price','usd_compare_price'],
//                 where: {
//                     id: product.product_id
//                 }
//             });
//             const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;

//             if(prqty >= product.quantity && prqty >= cartqty){
//                 var coupon_code = product.coupon_code ? product.coupon_code : '0'
//                 const couponDetails = await Coupon.findOne({where:{coupon_code:coupon_code,status:'1',is_deleted: 0},
//                 attributes:['id','coupon_code','from_date','to_date','coupon_type','type_val','min_amount','upto_amount','coupon_desc','coupon_allow','apply_to','apply_value','max_discount_allow','max_discount_amt']}
//                 );
//                 var cart_qty = checkCartExists ? checkCartExists.quantity + product.quantity : product.quantity;
//                 let discountAmount = 0;
//                 const subtotal = product.quantity * parseFloat(productDetail.price);
//                 let finalAmount = subtotal;
//                 if (couponDetails) {
//                     const { coupon_type, type_val, max_discount_allow, max_discount_amt, to_date, min_amount, upto_amount } = couponDetails;
//                     const couponExpiry = moment(`${to_date} 23:59:59`, "YYYY-MM-DD HH:mm:ss");
//                     const currentDate = moment(getCurrentDateTime());
//                     if (couponExpiry >= currentDate && (min_amount <= subtotal && upto_amount >= subtotal)) {
//                         if (coupon_type === 'normal') {
//                             discountAmount = Math.min(parseFloat(type_val), max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
//                         } else if (coupon_type === 'percent') {
//                             const percentDiscount = (subtotal * parseFloat(type_val)) / 100;
//                             discountAmount = Math.min(percentDiscount, max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
//                         }
//                         finalAmount = subtotal - discountAmount;
//                     }
//                 }
//                 if (checkCartExists) {
//                     const planProductCarts = checkCartExists.get({ plain: true });
//                     await Cart.update({
//                         user_id: user_id,
//                         quantity: cart_qty,
//                         amount: productDetail.price,
//                         discount_amt:discountAmount,
//                         discount_id:discountAmount > 0 ? couponDetails?.id || 0 :0,
//                         subtotal_amount:finalAmount,
//                         updated_at: current_date,
//                         updated_by: user_id,
//                     }, {
//                         where: {
//                             id: planProductCarts.id
//                         }
//                     });
//                 } else{
//                     Cart.create({
//                         user_id: user_id,
//                         product_id: product.product_id,
//                         product_variant_id: product.product_variant_id,
//                         quantity: product.quantity,
//                         amount:productDetail.price,
//                         subtotal_amount:finalAmount,
//                         discount_amt:discountAmount,
//                         discount_id:discountAmount > 0 ? couponDetails?.id || 0 :0,
//                         created_at:current_date,
//                         status:1,
//                         created_by:user_id
//                     });
//                 }
//             }else{
//                 stock_quantity_availability.push(`${productDetail.product_name}`);
//             }
//         }
//         var stock_quantity_msg = '';
//         var is_out_of_stock = 1;
//         if(stock_quantity_availability.length>0){
//             var stock_quantity_msg = stock_quantity_availability.join(', ')  + ' Out of stock';
//             var is_out_of_stock = 0;
//         }

//         if (!products){
//             res.status(202).send({
//                 message: process.env.NOT_INSERTED_MSG,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         }else{
//             res.status(200).send({
//                 message: process.env.INSERTED_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 out_of_stock_msg: stock_quantity_msg,
//                 is_out_of_stock: is_out_of_stock,
//                 data: products
//             });
//         }
//     } catch(error) {
//         res.status(500).send({
//             message:process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }

// const addToCart = async (req, res) => {
//     const user_id = req.userId;
//     const products = req.body;
//     try {
//         var stock_quantity_availability = [];
//         for (const product of products) {

//             const checkCartExists = await Cart.findOne({
//                 where: {
//                     product_id: product.product_id,
//                     product_variant_id: product.product_variant_id,
//                     user_id: user_id,
//                 }
//             });

//             var cartqty = checkCartExists ? checkCartExists.quantity + product.quantity : 0;
//             //check avlaiable qty
//             const productDetail = await Product.findOne({
//                 attributes: ['price', 'stock_quantity', 'product_name', 'usd_price', 'usd_compare_price'],
//                 where: {
//                     id: product.product_id
//                 }
//             });
//             const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;

//             if (prqty >= product.quantity && prqty >= cartqty) {
//                 var coupon_code = product.coupon_code ? product.coupon_code : '0'
//                 const couponDetails = await Coupon.findOne({
//                     where: { coupon_code: coupon_code, status: '1', is_deleted: 0 },
//                     attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt']
//                 }
//                 );
//                 var cart_qty = checkCartExists ? checkCartExists.quantity + product.quantity : product.quantity;
//                 let discountAmount = 0;
//                 if (product.currency_code == 'INR') {
//                     var subtotal = cart_qty * parseFloat(productDetail.price);
//                 } else {
//                     var subtotal = cart_qty * parseFloat(product.usd_amount * product.currency_rate);
//                 }
//                 let finalAmount = subtotal;
//                 if (couponDetails) {
//                     const { coupon_type, type_val, max_discount_allow, max_discount_amt, to_date, min_amount, upto_amount } = couponDetails;
//                     const couponExpiry = moment(`${to_date} 23:59:59`, "YYYY-MM-DD HH:mm:ss");
//                     const currentDate = moment(getCurrentDateTime());
//                     if (couponExpiry >= currentDate && (min_amount <= subtotal && upto_amount >= subtotal)) {
//                         if (coupon_type === 'normal') {
//                             discountAmount = Math.min(parseFloat(type_val), max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
//                         } else if (coupon_type === 'percent') {
//                             const percentDiscount = (subtotal * parseFloat(type_val)) / 100;
//                             discountAmount = Math.min(percentDiscount, max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
//                         }
//                         finalAmount = subtotal - discountAmount;
//                     }
//                 }
//                 if (checkCartExists) {
//                     const planProductCarts = checkCartExists.get({ plain: true });
//                     await Cart.update({
//                         user_id: user_id,
//                         quantity: cart_qty,
//                         amount: productDetail.price,
//                         usd_amount: product.usd_amount,
//                         currency_code: product.currency_code,
//                         currency_symbol: product.currency_symbol,
//                         currency_rate: product.currency_rate,
//                         discount_amt: discountAmount,
//                         discount_id: discountAmount > 0 ? couponDetails?.id || 0 : 0,
//                         subtotal_amount: finalAmount,
//                         updated_at: current_date,
//                         updated_by: user_id,
//                     }, {
//                         where: {
//                             id: planProductCarts.id
//                         }
//                     });
//                 } else {
//                     Cart.create({
//                         user_id: user_id,
//                         product_id: product.product_id,
//                         product_variant_id: product.product_variant_id,
//                         quantity: product.quantity,
//                         amount: productDetail.price,
//                         usd_amount: product.usd_amount,
//                         currency_code: product.currency_code,
//                         currency_symbol: product.currency_symbol,
//                         currency_rate: product.currency_rate,
//                         currency_symbol: product.currency_symbol,
//                         currency_rate: product.currency_rate,
//                         subtotal_amount: finalAmount,
//                         discount_amt: discountAmount,
//                         discount_id: discountAmount > 0 ? couponDetails?.id || 0 : 0,
//                         created_at: current_date,
//                         status: 1,
//                         created_by: user_id
//                     });
//                 }
//             } else {
//                 stock_quantity_availability.push(`${productDetail.product_name}`);
//             }
//         }
//         var stock_quantity_msg = '';
//         var is_out_of_stock = 1;
//         if (stock_quantity_availability.length > 0) {
//             var stock_quantity_msg = stock_quantity_availability.join(', ') + ' Out of stock';
//             var is_out_of_stock = 0;
//         }

//         if (!products) {
//             res.status(202).send({
//                 message: process.env.NOT_INSERTED_MSG,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         } else {
//             res.status(200).send({
//                 message: process.env.INSERTED_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 out_of_stock_msg: stock_quantity_msg,
//                 is_out_of_stock: is_out_of_stock,
//                 data: products
//             });
//         }
//     } catch (error) {
//         res.status(500).send({
//             message: process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }

const addToCart = async (req, res) => {
    const user_id = req.userId;
    const products = req.body;
    try {
        var stock_quantity_availability = [];
        for (const product of products) {

            const checkCartExists = await Cart.findOne({
                where: {
                    product_id: product.product_id,
                    product_variant_id: product.product_variant_id,
                    user_id: user_id,
                }
            });

            var cartqty = checkCartExists ? checkCartExists.quantity + product.quantity : 0;
            //check avlaiable qty
            const productDetail = await Product.findOne({
                attributes: ['price', 'stock_quantity', 'product_name', 'usd_price', 'usd_compare_price'],
                where: {
                    id: product.product_id
                }
            });
            const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;

            if (prqty >= product.quantity && prqty >= cartqty) {
                var coupon_code = product.coupon_code ? product.coupon_code : '0'
                const couponDetails = await Coupon.findOne({
                    where: { coupon_code: coupon_code, status: '1', is_deleted: 0 },
                    attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt']
                }
                );
                var cart_qty = checkCartExists ? checkCartExists.quantity + product.quantity : product.quantity;
                let discountAmount = 0;
                if (product.currency_code == 'INR') {
                    var subtotal = cart_qty * parseFloat(productDetail.price);
                } else {
                    var subtotal = cart_qty * parseFloat(product.usd_amount * product.currency_rate);
                }
                let finalAmount = subtotal;
                if (couponDetails) {
                    const { coupon_type, type_val, max_discount_allow, max_discount_amt, to_date, min_amount, upto_amount } = couponDetails;
                    const couponExpiry = moment(`${to_date} 23:59:59`, "YYYY-MM-DD HH:mm:ss");
                    const currentDate = moment(getCurrentDateTime());
                    if (couponExpiry >= currentDate && (min_amount <= subtotal && upto_amount >= subtotal)) {
                        if (coupon_type === 'normal') {
                            discountAmount = Math.min(parseFloat(type_val), max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                        } else if (coupon_type === 'percent') {
                            const percentDiscount = (subtotal * parseFloat(type_val)) / 100;
                            discountAmount = Math.min(percentDiscount, max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                        }
                        finalAmount = subtotal - discountAmount;
                    }
                }
                if (checkCartExists) {
                    const planProductCarts = checkCartExists.get({ plain: true });
                    await Cart.update({
                        user_id: user_id,
                        quantity: cart_qty,
                        amount: productDetail.price,
                        usd_amount: product.usd_amount,
                        currency_code: product.currency_code,
                        currency_symbol: product.currency_symbol,
                        currency_rate: product.currency_rate,
                        discount_amt: discountAmount,
                        discount_id: discountAmount > 0 ? couponDetails?.id || 0 : 0,
                        subtotal_amount: finalAmount,
                        updated_at: current_date,
                        updated_by: user_id,
                    }, {
                        where: {
                            id: planProductCarts.id
                        }
                    });
                } else {
                    Cart.create({
                        user_id: user_id,
                        product_id: product.product_id,
                        product_variant_id: product.product_variant_id,
                        quantity: product.quantity,
                        amount: productDetail.price,
                        usd_amount: product.usd_amount,
                        currency_code: product.currency_code,
                        currency_symbol: product.currency_symbol,
                        currency_rate: product.currency_rate,
                        currency_symbol: product.currency_symbol,
                        currency_rate: product.currency_rate,
                        subtotal_amount: finalAmount,
                        discount_amt: discountAmount,
                        discount_id: discountAmount > 0 ? couponDetails?.id || 0 : 0,
                        created_at: current_date,
                        status: 1,
                        created_by: user_id
                    });
                }
            } else {
                stock_quantity_availability.push(`${productDetail.product_name}`);
            }
        }
        var stock_quantity_msg = '';
        var is_out_of_stock = 1;
        if (stock_quantity_availability.length > 0) {
            var stock_quantity_msg = stock_quantity_availability.join(', ') + ' Out of stock';
            var is_out_of_stock = 0;
        }

        if (!products) {
            res.status(202).send({
                message: process.env.NOT_INSERTED_MSG,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.INSERTED_MSG,
                error: false,
                success: true,
                status: '1',
                out_of_stock_msg: stock_quantity_msg,
                is_out_of_stock: is_out_of_stock,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const updateCart_old = async (req, res) => {
    const user_id = req.userId;
    const product_id = req.body.product_id;
    const quantity = req.body.quantity;
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product"),
        quantity: Joi.number().integer().required().label("quantity")
    });
    const dataToValidate = {
        product_id: product_id,
        quantity: quantity
    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const checkCartExists = await Cart.findOne({
                where: {
                    product_id: product_id,
                    user_id: user_id,
                    status: 1
                }
            });
            //check avlaiable qty
            const productDetail = await Product.findOne({
                attributes: ['stock_quantity', 'product_name', 'usd_price', 'usd_compare_price'],
                where: {
                    id: product_id
                }
            });
            const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;
            if (prqty >= quantity) {

                if (checkCartExists) {
                    const planProductCarts = checkCartExists.get({ plain: true });

                    const couponDetails = await Coupon.findOne({ where: { id: checkCartExists.discount_id, status: '1', is_deleted: 0 }, attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'] });

                    let discountAmount = 0;
                    const subtotal = quantity * parseFloat(planProductCarts.amount);
                    let finalAmount = subtotal;
                    if (couponDetails) {
                        const { coupon_type, type_val, max_discount_allow, max_discount_amt, to_date, min_amount, upto_amount } = couponDetails;
                        const couponExpiry = moment(`${to_date} 23:59:59`, "YYYY-MM-DD HH:mm:ss");
                        const currentDate = moment(getCurrentDateTime());
                        if (couponExpiry >= currentDate && (min_amount <= subtotal && upto_amount >= subtotal)) {
                            if (coupon_type === 'normal') {
                                discountAmount = Math.min(parseFloat(type_val), max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                            } else if (coupon_type === 'percent') {
                                const percentDiscount = (subtotal * parseFloat(type_val)) / 100;
                                discountAmount = Math.min(percentDiscount, max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                            }
                            finalAmount = subtotal - discountAmount;
                        }
                    }
                    await Cart.update({
                        user_id: user_id,
                        quantity: quantity,
                        discount_amt: discountAmount,
                        subtotal_amount: finalAmount,
                        updated_at: current_date,
                        updated_by: user_id,
                    }, {
                        where: {
                            id: planProductCarts.id,
                        }
                    });
                }
                if (!checkCartExists) {
                    res.status(202).send({
                        message: process.env.NOT_INSERTED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    res.status(200).send({
                        message: 'Quantity update successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } else {
                res.status(202).send({
                    message: productDetail.product_name + ' Out of stock',
                    error: true,
                    success: false,
                    status: '0'
                });

            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const updateCart = async (req, res) => {
    const user_id = req.userId;
    const product_id = req.body.product_id;
    const quantity = req.body.quantity;
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product"),
        quantity: Joi.number().integer().required().label("quantity")
    });
    const dataToValidate = {
        product_id: product_id,
        quantity: quantity
    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const checkCartExists = await Cart.findOne({
                where: {
                    product_id: product_id,
                    user_id: user_id,
                    status: 1
                }
            });
            //check avlaiable qty
            const productDetail = await Product.findOne({
                attributes: ['stock_quantity', 'product_name', 'usd_price', 'usd_compare_price'],
                where: {
                    id: product_id
                }
            });
            const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;
            if (prqty >= quantity) {

                if (checkCartExists) {
                    const planProductCarts = checkCartExists.get({ plain: true });

                    const couponDetails = await Coupon.findOne({ where: { id: checkCartExists.discount_id, status: '1', is_deleted: 0 }, attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'] });

                    let discountAmount = 0;

                    if (planProductCarts.currency_code == "INR") {
                        subtotal = quantity * parseFloat(planProductCarts.amount);
                    } else {
                        subtotal = quantity * parseFloat(planProductCarts.usd_amount) * planProductCarts.currency_rate;
                    }
                    let finalAmount = subtotal;
                    if (couponDetails) {
                        const { coupon_type, type_val, max_discount_allow, max_discount_amt, to_date, min_amount, upto_amount } = couponDetails;
                        const couponExpiry = moment(`${to_date} 23:59:59`, "YYYY-MM-DD HH:mm:ss");
                        const currentDate = moment(getCurrentDateTime());
                        if (couponExpiry >= currentDate && (min_amount <= subtotal && upto_amount >= subtotal)) {
                            if (coupon_type === 'normal') {
                                discountAmount = Math.min(parseFloat(type_val), max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                            } else if (coupon_type === 'percent') {
                                const percentDiscount = (subtotal * parseFloat(type_val)) / 100;
                                discountAmount = Math.min(percentDiscount, max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                            }
                            finalAmount = subtotal - discountAmount;
                        }
                    }
                    await Cart.update({
                        user_id: user_id,
                        quantity: quantity,
                        discount_amt: discountAmount,
                        subtotal_amount: finalAmount,
                        updated_at: current_date,
                        updated_by: user_id,
                    }, {
                        where: {
                            id: planProductCarts.id,
                        }
                    });
                }
                // update discount
                const carts = await Cart.findAll({
                    where: {
                        user_id: user_id
                    },
                    attributes: ['subtotal_amount'],
                });
                let subtotal_amount = 0;
                if (carts) {
                    for (const cart of carts) {
                        if (cart) {
                            subtotal_amount += parseFloat(cart.subtotal_amount);
                        }
                    }
                }
                await updateDiscount(user_id, subtotal_amount);
                // end 

                if (!checkCartExists) {
                    res.status(202).send({
                        message: process.env.NOT_INSERTED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    res.status(200).send({
                        message: 'Quantity update successfully',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
            } else {
                res.status(202).send({
                    message: productDetail.product_name + ' Out of stock',
                    error: true,
                    success: false,
                    status: '0'
                });

            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const updateDiscount = async (user_id, subtotal_amount) => {
    try {

        const discount_ids = await OrderDiscountCoupon.findAll({
            where: {
                user_id: user_id,
                discount_mode: 'cart',
            },
            attributes: ['discount_id'],
        });
        await OrderDiscountCoupon.update({
            discount_amt: 0,
        }, {
            where: {
                user_id: user_id,
                discount_mode: 'cart',
            }
        });
        const check_order_exist = await Order.count({
            where: {
                user_id: user_id,
                // add by suresh check cod and online payment
                payment_status: {
                    [Op.in]: ['0', '1'],
                },
                //end
            },
            // attributes: ['id']
        });

        if (discount_ids[0]) {
            const discountIdArray = discount_ids.map(item => item.discount_id);
            const coupon_details = await Coupon.findAll({
                where: {
                    id: {
                        [Op.in]: discountIdArray, // WHERE IN clause
                    },
                    status: {
                        [Op.in]: ['1', '2'],
                    },
                    is_deleted: 0
                },
                order: [['type_val', 'ASC']],
                attributes: [
                    'id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount',
                    'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'
                ]
            });
            for (coupon_details_sngle of coupon_details) {
                var min_amount = coupon_details_sngle ? coupon_details_sngle.min_amount : 0;
                var upto_amount = coupon_details_sngle ? coupon_details_sngle.upto_amount : 0;
                // if ((min_amount >= 0 && min_amount > subtotal_amount) || (upto_amount > 0 && upto_amount < subtotal_amount)) {
                //     return res.status(202).send({
                //         message: `Order amount less then ${min_amount} and amount greater then ${upto_amount}`,
                //         error: true,
                //         success: false,
                //         status: '0'
                //     });
                // }
                const discount = await OrderDiscountCoupon.findOne({
                    where: {
                        user_id: user_id,
                        discount_mode: 'cart',
                        discount_type: coupon_details_sngle?.apply_to.toLowerCase(),
                        discount_id: coupon_details_sngle?.id
                    },
                    attributes: ['id', 'discount_type', 'discount_id'],
                });

                const couponAddDisount = await OrderDiscountCoupon.findOne({
                    where: {
                        user_id: user_id,
                        discount_mode: 'cart',
                        applied_status: 1,
                        discount_type: {
                            [Op.in]: ['first_order', 'order']
                        }
                    },
                    attributes: [
                        [sequelize.fn('SUM', sequelize.col('discount_amt')), 'totalDiscountAmt']
                    ]
                });
                const totalDiscountAmt = couponAddDisount ? couponAddDisount.get('totalDiscountAmt') : 0;
                var dis_amt = subtotal_amount - totalDiscountAmt;
                if (coupon_details_sngle.coupon_type === 'percent') {
                    var discount_amount = (Math.round(dis_amt) * coupon_details_sngle.type_val) / 100;
                }
                var dataCoupon = '';
                if ((coupon_details_sngle?.apply_to == 'FIRST_ORDER') && (check_order_exist < 1)) {
                    if (discount) {
                        const discountCoupon = discount.get({ plain: true });
                        await OrderDiscountCoupon.update({
                            user_id: user_id,
                            discount_id: coupon_details_sngle.id,
                            discount_amt: discount_amount,
                            discount_type: coupon_details_sngle.apply_to.toLowerCase(),
                            updated_at: getCurrentDateTime(),
                        }, {
                            where: {
                                id: discountCoupon?.id
                            }
                        });
                    } else {
                        dataCoupon = await OrderDiscountCoupon.create({
                            user_id: user_id,
                            discount_id: coupon_details_sngle.id,
                            discount_amt: discount_amount,
                            discount_type: coupon_details_sngle.apply_to.toLowerCase(),
                            created_at: getCurrentDateTime(),
                        });
                    }
                    // return res.status(200).send({
                    //     message: process.env.SUCCESS_MSG,
                    //     error: false,
                    //     success: true,
                    //     status: '1',
                    //     user_id: user_id,
                    //     data: discount_amount
                    // });
                } else {
                    if ((coupon_details_sngle?.apply_to != 'FIRST_ORDER')) {
                        if (discount) {
                            const discountCoupon = discount.get({ plain: true });
                            await OrderDiscountCoupon.update({
                                discount_amt: discount_amount,
                                discount_type: coupon_details_sngle.apply_to.toLowerCase(),
                                updated_at: getCurrentDateTime(),
                            }, {
                                where: {
                                    id: discountCoupon.id,
                                    user_id: user_id,
                                }
                            });

                        } else {
                            dataCoupon = await OrderDiscountCoupon.create({
                                user_id: user_id,
                                discount_id: coupon_details_sngle.id,
                                discount_amt: discount_amount,
                                discount_type: coupon_details_sngle.apply_to.toLowerCase(),
                                created_at: getCurrentDateTime(),
                            });
                        }
                    }
                }
            }

        }



    } catch (error) {
        console.error('Error fetching data:', error);
        throw new Error('Failed to receive data');
    }
}
const updateCartStatus = async (req, res) => {
    const user_id = req.userId;
    const products = req.body;

    try {
        for (const product of products) {
            const checkCartExists = await Cart.findOne({
                where: {
                    product_id: product.product_id,
                    user_id: user_id
                }
            });

            if (!checkCartExists) {
                return res.status(404).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

            const productDetail = await Product.findOne({
                attributes: ['stock_quantity', 'product_name', 'usd_price', 'usd_compare_price'],
                where: {
                    id: product.product_id
                }
            });

            const prqty = productDetail.stock_quantity || 0;
            const planProductCarts = checkCartExists.get({ plain: true });
            const couponDetails = await Coupon.findOne({
                where: {
                    id: checkCartExists.discount_id,
                    status: '1',
                    is_deleted: 0
                },
                attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt']
            });

            let discountAmount = 0;
            const subtotal = checkCartExists.quantity * parseFloat(planProductCarts.amount);
            let finalAmount = subtotal;

            if (couponDetails) {
                const { coupon_type, type_val, max_discount_allow, max_discount_amt, to_date, min_amount, upto_amount } = couponDetails;
                const couponExpiry = moment(`${to_date} 23:59:59`, "YYYY-MM-DD HH:mm:ss");
                const currentDate = moment(getCurrentDateTime());
                if (couponExpiry >= currentDate && (min_amount <= subtotal && upto_amount >= subtotal)) {
                    if (coupon_type === 'normal') {
                        discountAmount = Math.min(parseFloat(type_val), max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                    } else if (coupon_type === 'percent') {
                        const percentDiscount = (subtotal * parseFloat(type_val)) / 100;
                        discountAmount = Math.min(percentDiscount, max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                    }
                    finalAmount = subtotal - discountAmount;
                }
            }

            await Cart.update({
                user_id: user_id,
                discount_amt: discountAmount,
                subtotal_amount: finalAmount,
                updated_at: current_date,
                updated_by: user_id,
                status: product.status,
            }, {
                where: {
                    id: checkCartExists.id,
                }
            });
        }

        const carts = await Cart.findAll({
            where: {
                user_id: user_id,
                status: 1
            },
            attributes: ['subtotal_amount'],
        });

        let subtotal_amount = 0;
        for (const cart of carts) {
            if (cart) {
                subtotal_amount += parseFloat(cart.subtotal_amount);
            }
        }

        const couponDiscount = await OrderDiscountCoupon.findAll({
            where: {
                user_id: user_id,
                discount_type: {
                    [Op.in]: ['first_order', 'order']
                }
            },
        });

        if (couponDiscount) {
            for (const discount_coupon of couponDiscount) {
                const couponDetails = await Coupon.findOne({
                    where: {
                        id: discount_coupon.discount_id,
                        status: '1',
                        is_deleted: 0
                    },
                    attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt']
                });

                if (couponDetails) {
                    let discount_amount = 0;
                    if (couponDetails.coupon_type === 'percent') {
                        discount_amount = (subtotal_amount * couponDetails.type_val) / 100;
                    } else if (couponDetails.coupon_type === 'normal') {
                        discount_amount = couponDetails.type_val;
                    }

                    await OrderDiscountCoupon.update({
                        user_id: user_id,
                        discount_id: couponDetails.id,
                        discount_amt: discount_amount,
                        discount_type: couponDetails.apply_to.toLowerCase(),
                        updated_at: current_date,
                    }, {
                        where: {
                            id: discount_coupon.id
                        }
                    });
                }
            }
        }

        return res.status(200).send({
            message: 'Update successfully',
            error: false,
            success: true,
            status: '1',
        });

    } catch (error) {
        return res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
};
//add cart end

//delete cart start
// const DeleteCart = async (req, res) => {
//     const user_id = req.userId;
//     const id = req.body.id;
//     const schema = Joi.object().keys({
//         id:  Joi.number().integer().required()
//     });
//     const dataToValidate = {
//         id:id
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(403).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//             try {
//                 const carts = Cart.destroy({
//                     where: {
//                         user_id: user_id,
//                         product_id: id
//                     },
//                     });
//                 if (!carts){
//                     res.status(202).send({
//                         message: process.env.NOT_DELETED_MSG,
//                         error: true,
//                         success: false,
//                         status: '0'
//                     });
//                 }else{
//                     res.status(200).send({
//                         message: process.env.DELETED_MSG,
//                         error: false,
//                         success: true,
//                         status: '1'
//                     });
//                 }
//             } catch(error) {
//                 res.status(500).send({
//                     message:process.env.ERROR_MSG,
//                     error: true,
//                     success: false,
//                     status: '0',
//                 });
//             }
//     }
// }
const DeleteCart = async (req, res) => {
    const { userId: user_id } = req;
    const { id } = req.body;

    const schema = Joi.object({
        id: Joi.number().integer().required(),
    });

    const { error } = schema.validate({ id });
    if (error) {
        return res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: error.details[0].message,
        });
    }

    try {
        const carts = await Cart.destroy({
            where: {
                user_id,
                product_id: id,
            },
        });

        if (!carts) {
            return res.status(202).send({
                message: process.env.NOT_DELETED_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }

        const cartDetails = await Cart.count({ where: { user_id } });
        if (cartDetails === 0) {
            await OrderDiscountCoupon.destroy({ where: { user_id } });
        }

        res.status(200).send({
            message: process.env.DELETED_MSG,
            error: false,
            success: true,
            status: '1',
        });
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
};

//delete cart end
//cart ends

//user address starts
//get user address start
const GetUserAddress = async (req, res) => {
    try {
        const user_id = req.userId;
        const userAddresses = await UserAddress.findAll({
            where: {
                user_id: user_id,
                status: '1'
            },
            attributes: ['id', 'user_id', 'name', 'title', 'apartment', 'land_mark', 'address', 'mobile_number', 'zip_code', 'is_default', 'is_gst', 'gst_number', 'company_name', 'company_address', 'is_shipping_address', 'is_billing_address', 'billing_name', 'billing_country_id', 'billing_state_id', 'billing_city_id', 'billing_address', 'billing_pincode', 'billing_phone'],
            order: [['is_default', 'DESC']],
            include: [
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'firstname'],
                    required: false
                },
                {
                    model: Country,
                    as: 'country',
                    attributes: ['id', 'country_name'],
                    required: false
                },
                {
                    model: State,
                    as: 'state',
                    attributes: ['id', 'state_name'],
                    required: false
                },
                {
                    model: City,
                    as: 'city',
                    attributes: ['id', 'city_name'],
                    required: false
                },
                {
                    model: Country,
                    as: 'billing_country',
                    attributes: ['id', 'country_name'],
                    required: false
                },
                {
                    model: State,
                    as: 'billing_state',
                    attributes: ['id', 'state_name'],
                    required: false
                },
                {
                    model: City,
                    as: 'billing_city',
                    attributes: ['id', 'city_name'],
                    required: false
                }
            ]
        });
        if (userAddresses == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: userAddresses
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get user address end

//add user address start
const AddUserAddress = async (req, res) => {
    const user_id = req.userId;
    const title = req.body.title;
    const name = req.body.name;
    const pincode = req.body.pincode;
    const country_id = req.body.country_id;
    const state_id = req.body.state_id;
    const city_id = req.body.city_id;
    const mobile_number = req.body.mobile_number;
    const apartment = req.body.apartment;
    const land_mark = req.body.land_mark;
    const address = req.body.address;
    const is_default = req.body.is_default ? req.body.is_default : 0;
    //add new fild
    const is_gst = req.body.is_gst;
    const gst_number = req.body.gst_number;
    const company_name = req.body.company_name;
    const company_address = req.body.company_address;
    const is_shipping_address = req.body.is_shipping_address ? req.body.is_shipping_address : 0;
    const is_billing_address = req.body.is_billing_address;
    const billing_name = req.body.billing_name;
    const billing_phone = req.body.billing_phone;
    const billing_pincode = req.body.billing_pincode;
    const billing_country_id = req.body.billing_country_id;
    const billing_state_id = req.body.billing_state_id;
    const billing_city_id = req.body.billing_city_id;
    const billing_address = req.body.billing_address;
    const schema = Joi.object().keys({
        title: Joi.string().required().label("Title"),
        name: Joi.string().required().label("Name"),
        pincode: Joi.number().integer().required().label("Pincode"),
        country_id: Joi.number().integer().required().label("Country"),
        state_id: Joi.number().integer().required().label("State"),
        city_id: Joi.number().integer().required().label("City"),
        mobile_number: Joi.number().integer().required().label("Mobile Number"),
        address: Joi.string().required().label("Address"),
        is_billing_address: Joi.number().valid(0, 1).required().label("Is Billing Address"),
        billing_name: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.string().required().label("Billing Name")
        }),
        billing_phone: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.number().integer().required().label("Billing Phone")
        }),
        billing_pincode: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.number().integer().required().label("Billing Pincode")
        }),
        billing_country_id: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.number().integer().required().label("Billing Country")
        }),
        billing_state_id: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.number().integer().required().label("Billing State")
        }),
        billing_city_id: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.number().integer().required().label("Billing City")
        }),
        billing_address: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.string().required().label("Billing Address")
        })
    });
    const dataToValidate = {
        title: title,
        name: name,
        pincode: pincode,
        country_id: country_id,
        state_id: state_id,
        city_id: city_id,
        mobile_number: mobile_number,
        address: address,
        is_billing_address: is_billing_address,
        billing_name: billing_name,
        billing_phone: billing_phone,
        billing_pincode: billing_pincode,
        billing_country_id: billing_country_id,
        billing_state_id: billing_state_id,
        billing_city_id: billing_city_id,
        billing_address: billing_address,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const ValidGSt = await verifyGST(gst_number);
            if (is_gst == 1 && !ValidGSt) {
                return res.status(403).send({
                    message: "Invalid GST Number",
                    error: true,
                    success: false,
                    status: "0",
                });
            }

            if (is_shipping_address == 1) {
                var bill_name = name;
                var bill_phone = mobile_number;
                var bill_pincode = pincode;
                var bill_country_id = country_id;
                var bill_state_id = state_id;
                var bill_city_id = city_id;
                var bill_address = address;
            } else if (is_billing_address == 1) {
                var bill_name = billing_name;
                var bill_phone = billing_phone;
                var bill_pincode = billing_pincode;
                var bill_country_id = billing_country_id;
                var bill_state_id = billing_state_id;
                var bill_city_id = billing_city_id;
                var bill_address = billing_address;
            }
            // let userAddressData = {
            //     user_id: user_id,
            //     title: title,
            //     name: name,
            //     zip_code: pincode,
            //     country_id: country_id,
            //     state_id: state_id,
            //     city_id: city_id,
            //     mobile_number: mobile_number,
            //     apartment: apartment ? apartment : '',
            //     land_mark: land_mark ? land_mark : '',
            //     address: address,
            //     is_default: is_default,
            //     is_gst: is_gst ? is_gst : 0,
            //     gst_number: gst_number,
            //     company_name: company_name,
            //     company_address: company_address,
            //     is_shipping_address: is_shipping_address,
            //     is_billing_address: is_billing_address,
            //     billing_name: bill_name,
            //     billing_phone: bill_phone,
            //     billing_pincode: bill_pincode,
            //     billing_country_id: bill_country_id,
            //     billing_state_id: bill_state_id,
            //     billing_city_id: bill_city_id,
            //     billing_address: bill_address,
            //     created_at: current_date,
            //     created_by: user_id
            // };
            // const userAddress = await UserAddress.create(userAddressData);

            let userAddressData = {
                user_id: user_id,
                title: title,
                name: name,
                zip_code: pincode,
                country_id: country_id,
                state_id: state_id,
                city_id: city_id,
                mobile_number: mobile_number,
                apartment: apartment || '',
                land_mark: land_mark ? land_mark : '' || '',
                address: address,
                is_default: is_default,
                is_gst: is_gst || 0,
                gst_number: gst_number,
                company_name: company_name,
                company_address: company_address,
                is_shipping_address: is_shipping_address,
                is_billing_address: is_billing_address,
                billing_name: bill_name,
                billing_phone: bill_phone,
                billing_pincode: bill_pincode,
                billing_country_id: bill_country_id,
                billing_state_id: bill_state_id,
                billing_city_id: bill_city_id,
                billing_address: bill_address,
                created_at: current_date,
                created_by: user_id
            };

            // Define the fields to check for duplicates
            const fieldsToCheck = {
                user_id,
                title,
                name,
                zip_code: pincode,
                country_id,
                state_id,
                city_id,
                mobile_number,
                apartment: apartment || '',
                land_mark: land_mark || '',
                address,
                is_shipping_address,
                is_billing_address,
                billing_name: bill_name,
                billing_phone: bill_phone,
                billing_pincode: bill_pincode,
                billing_country_id: bill_country_id,
                billing_state_id: bill_state_id,
                billing_city_id: bill_city_id,
                billing_address: bill_address
            };

            const existingAddress = await UserAddress.findOne({ where: fieldsToCheck });

            if (!existingAddress) {

                var userAddress = await UserAddress.create(userAddressData);
            } else {
                var userAddress = await UserAddress.findOne({
                    where: {
                        user_id: user_id,
                        is_default: 1
                    },
                    attributes: ['id', 'user_id', 'name', 'title', 'apartment', 'billing_phone', 'land_mark', 'address', 'mobile_number', 'zip_code', 'is_default', 'is_gst', 'gst_number', 'company_name', 'company_address', 'is_shipping_address', 'is_billing_address', 'billing_name', 'billing_country_id', 'billing_state_id', 'billing_city_id', 'billing_address', 'billing_pincode', 'billing_phone'],
                });

            }

            if (!userAddress) {
                res.status(202).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                if (is_default == 1) {
                    const address = await UserAddress.update({
                        is_default: 0,
                    }, {
                        where: {
                            user_id: user_id,
                            id: {
                                [Op.ne]: userAddress['id'],
                            }
                        }
                    });
                }
                res.status(200).send({
                    message: process.env.INSERTED_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: userAddress
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//add user address end 

//get user address detail
const GetUserAddressDetail = async (req, res) => {
    const id = req.body.id;
    const schema = Joi.object().keys({
        id: Joi.string().required()
    });
    const dataToValidate = {
        id: id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const userAddress = await UserAddress.findOne({
                where: {
                    id: id,
                    status: '1'
                },
                attributes: ['id', 'user_id', 'name', 'title', 'apartment', 'billing_phone', 'land_mark', 'address', 'mobile_number', 'zip_code', 'is_default', 'is_gst', 'gst_number', 'company_name', 'company_address', 'is_shipping_address', 'is_billing_address', 'billing_name', 'billing_country_id', 'billing_state_id', 'billing_city_id', 'billing_address', 'billing_pincode', 'billing_phone'],
                include: [
                    {
                        model: User,
                        as: 'user',
                        attributes: ['firstname'],
                        required: false
                    },
                    {
                        model: Country,
                        as: 'country',
                        attributes: ['id', 'country_name'],
                        required: false
                    },
                    {
                        model: State,
                        as: 'state',
                        attributes: ['id', 'state_name'],
                        required: false
                    },
                    {
                        model: City,
                        as: 'city',
                        attributes: ['id', 'city_name'],
                        required: false
                    },
                    {
                        model: Country,
                        as: 'billing_country',
                        attributes: ['country_name'],
                        required: false
                    },
                    {
                        model: State,
                        as: 'billing_state',
                        attributes: ['state_name'],
                        required: false
                    },
                    {
                        model: City,
                        as: 'billing_city',
                        attributes: ['city_name'],
                        required: false
                    }
                ]
            });

            if (!userAddress) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: userAddress
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//get user address detail

//edit user address start
const EditUserAddress = async (req, res) => {
    const id = req.body.id;
    const user_id = req.userId;
    const title = req.body.title;
    const name = req.body.name;
    const pincode = req.body.pincode;
    const country_id = req.body.country_id;
    const state_id = req.body.state_id;
    const city_id = req.body.city_id;
    const mobile_number = req.body.mobile_number;
    const apartment = req.body.apartment;
    const land_mark = req.body.land_mark;
    const address = req.body.address;
    const is_default = req.body.is_default;

    const is_gst = req.body.is_gst;
    const gst_number = req.body.gst_number;
    const company_name = req.body.company_name;
    const company_address = req.body.company_address;
    const is_shipping_address = req.body.is_shipping_address;
    const is_billing_address = req.body.is_billing_address;
    const billing_name = req.body.billing_name;
    const billing_phone = req.body.billing_phone;
    const billing_pincode = req.body.billing_pincode;
    const billing_country_id = req.body.billing_country_id;
    const billing_state_id = req.body.billing_state_id;
    const billing_city_id = req.body.billing_city_id;
    const billing_address = req.body.billing_address;

    const schema = Joi.object().keys({
        title: Joi.string().required().label("Title"),
        name: Joi.string().required().label("Name"),
        pincode: Joi.number().integer().required().label("Pincode"),
        country_id: Joi.number().integer().required().label("Country"),
        state_id: Joi.number().integer().required().label("State"),
        city_id: Joi.number().integer().required().label("City"),
        mobile_number: Joi.number().integer().required().label("Mobile Number"),
        address: Joi.string().required().label("Address"),
        is_billing_address: Joi.number().valid(0, 1).required().label("Is Billing Address"),
        billing_name: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.string().required().label("Billing Name")
        }),
        billing_phone: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.number().integer().required().label("Billing Phone")
        }),
        billing_country_id: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.number().integer().required().label("Billing Country")
        }),
        billing_state_id: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.number().integer().required().label("Billing State")
        }),
        billing_city_id: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.number().integer().required().label("Billing City")
        }),
        billing_address: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.string().required().label("Billing Address")
        }),
        billing_pincode: Joi.when('is_billing_address', {
            is: 1,
            then: Joi.string().required().label("Billing Pincode")
        })
    });
    const dataToValidate = {
        title: title,
        name: name,
        pincode: pincode,
        country_id: country_id,
        state_id: state_id,
        city_id: city_id,
        mobile_number: mobile_number,
        address: address,
        is_billing_address: is_billing_address,
        billing_name: billing_name,
        billing_phone: billing_phone,
        billing_pincode: billing_pincode,
        billing_country_id: billing_country_id,
        billing_state_id: billing_state_id,
        billing_city_id: billing_city_id,
        billing_address: billing_address,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const ValidGSt = await verifyGST(gst_number);
            if (is_gst == 1 && !ValidGSt) {
                return res.status(403).send({
                    message: "Invalid GST Number",
                    error: true,
                    success: false,
                    status: "0",
                });
            }
            if (is_shipping_address == 1) {
                var bill_name = name;
                var bill_phone = mobile_number;
                var bill_pincode = pincode;
                var bill_country_id = country_id;
                var bill_state_id = state_id;
                var bill_city_id = city_id;
                var bill_address = address;
            } else if (is_billing_address == 1) {
                var bill_name = billing_name;
                var bill_phone = billing_phone;
                var bill_pincode = billing_pincode;
                var bill_country_id = billing_country_id;
                var bill_state_id = billing_state_id;
                var bill_city_id = billing_city_id;
                var bill_address = billing_address;
            }

            const checkDefault = await UserAddress.findOne({
                where: { id: id },
                attributes: ['id', 'is_default']
            });
            if (checkDefault) {
                const plainCheckDefault = checkDefault.get({ plain: true });
                if (plainCheckDefault['is_default'] == 1 && is_default == 1) {
                    var isDefault = 1;
                } else if (plainCheckDefault['is_default'] == 1 && is_default == 0) {
                    var isDefault = 1;
                } else if (plainCheckDefault['is_default'] == 0 && is_default == 1) {
                    var isDefault = 1;
                } else {
                    var isDefault = 0;
                }
            }
            const userAddressData = {
                user_id: user_id,
                title: title,
                name: name,
                zip_code: pincode,
                country_id: country_id,
                state_id: state_id,
                city_id: city_id,
                mobile_number: mobile_number,
                apartment: apartment ? apartment : "",
                land_mark: land_mark ? land_mark : "",
                address: address,
                is_default: isDefault,
                is_gst: is_gst ? is_gst : 0,
                gst_number: gst_number,
                company_name: company_name,
                company_address: company_address,
                is_shipping_address: is_shipping_address ? is_shipping_address : 0,
                is_billing_address: is_billing_address,
                billing_name: bill_name,
                billing_phone: bill_phone,
                billing_pincode: bill_pincode,
                billing_country_id: bill_country_id,
                billing_state_id: bill_state_id,
                billing_city_id: bill_city_id,
                billing_address: bill_address,
                updated_at: current_date,
                updated_by: user_id
            };
            const userAddress = await UserAddress.update(userAddressData, {
                where: {
                    id: id
                }
            });
            if (!userAddress) {
                res.status(202).send({
                    message: process.env.NOT_UPDATED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                if (is_default == 1) {
                    const address = await UserAddress.update({
                        is_default: 0,
                    }, {
                        where: {
                            user_id: user_id,
                            id: {
                                [Op.ne]: id,
                            }
                        }
                    });
                }
                res.status(200).send({
                    message: process.env.UPDATED_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: userAddressData
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//edit user address end

//delete user address start
const DeleteUserAddress = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id: Joi.string().required()
    });
    const dataToValidate = {
        id: id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const carts = await UserAddress.update({
                status: '0',
                updated_at: current_date,
                updated_by: user_id
            }, {
                where: {
                    id: id
                }
            });
            if (!carts) {
                res.status(202).send({
                    message: process.env.NOT_DELETED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.DELETED_MSG,
                    error: false,
                    success: true,
                    status: '1'
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//delete user address end
//user address ends

//wishlist category starts
//get wishlist category start
const GetWishlistCategory = async (req, res) => {
    try {
        const user_id = req.userId;
        const wishlistCategories = await WishlistCategory.findAll({
            where: {
                user_id: user_id,
                status: '1'
            },
            attributes: ['id', 'category_name'],
            include: {
                model: User,
                attributes: ['id', 'firstname'],
                required: false
            }
        });
        if (wishlistCategories == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: wishlistCategories
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get wishlist category end

//add wishlist category start
const AddWishlistCategory = async (req, res) => {
    const user_id = req.userId;
    const category_name = req.body.category_name;
    const schema = Joi.object().keys({
        category_name: Joi.string().required().label("Category name")
    });
    const dataToValidate = {
        category_name: category_name
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const checkCategoryExists = await WishlistCategory.findAll({ where: { user_id: user_id, status: '1' } });
            if (checkCategoryExists != 0) {
                res.status(409).send({
                    message: process.env.ALREADY_EXIST_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const category = await WishlistCategory.create({
                    user_id: user_id,
                    category_name: category_name,
                    created_at: current_date,
                    created_by: user_id
                });
                if (!category) {
                    res.status(202).send({
                        message: process.env.NOT_INSERTED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    res.status(200).send({
                        message: process.env.INSERTED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: category
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//add wishlist category end

//edit wishlist category start
const EditWishlistCategory = async (req, res) => {
    const id = req.body.id;
    const user_id = req.userId;
    const category_name = req.body.category_name;
    const schema = Joi.object().keys({
        id: Joi.string().required(),
        category_name: Joi.string().required().label("Category name")
    });
    const dataToValidate = {
        id: id,
        category_name: category_name
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const category = await WishlistCategory.update({
                user_id: user_id,
                category_name: category_name,
                updated_at: current_date,
                updated_by: user_id
            }, {
                where: {
                    id: id
                }
            });
            if (!category) {
                res.status(202).send({
                    message: process.env.NOT_UPDATED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.UPDATED_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: req.body
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//edit wishlist category end

//delete wishlist category start
const DeleteWishlistCategory = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id: Joi.number().integer().required()
    });
    const dataToValidate = {
        id: id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const category = await WishlistCategory.update({
                status: '0',
                updated_at: current_date,
                updated_by: user_id
            }, {
                where: {
                    id: id
                }
            });
            if (!category) {
                res.status(202).send({
                    message: process.env.NOT_DELETED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.DELETED_MSG,
                    error: false,
                    success: true,
                    status: '1'
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//delete wishlist category end
//wishlist category ends

//user wallet starts
//get user wallet start
const GetUserWallet = async (req, res) => {
    try {
        const user_id = req.userId;
        const wallet = await UserWallet.findOne({
            where: {
                user_id: user_id,
                status: '1'
            },
            include: {
                model: User,
                attributes: ['id', 'firstname'],
                required: false
            },
            attributes: ['id', 'amount_balance', 'last_update', 'wallet_amnt_exp_lastdate'],
        });
        if (!wallet) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: wallet
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get user wallet end

//add user wallet start
const AddUserWallet = async (req, res) => {
    const user_id = req.userId;
    const amount_balance = req.body.amount_balance;
    const wallet_amnt_exp_lastdate = req.body.wallet_amnt_exp_lastdate;
    const schema = Joi.object().keys({
        amount_balance: Joi.number().required().label("Amount balance"),
        wallet_amnt_exp_lastdate: Joi.date().required().greater('now').iso().label("Wallet amount expiration last date")
    });
    const dataToValidate = {
        amount_balance: amount_balance,
        wallet_amnt_exp_lastdate: wallet_amnt_exp_lastdate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const checkWalletExists = await UserWallet.findOne({ where: { user_id: user_id, status: '1' } });
            if (checkWalletExists) {
                res.status(409).send({
                    message: process.env.ALREADY_EXIST_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const wallet = await UserWallet.create({
                    user_id: user_id,
                    amount_balance: amount_balance,
                    wallet_amnt_exp_lastdate: wallet_amnt_exp_lastdate,
                    last_update: current_date,
                    created_by: user_id
                });
                if (!wallet) {
                    res.status(202).send({
                        message: process.env.NOT_INSERTED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    res.status(200).send({
                        message: process.env.INSERTED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: wallet
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//add user wallet end

//edit user wallet start
const EditUserWallet = async (req, res) => {
    const user_id = req.userId;
    const amount_balance = req.body.amount_balance;
    const wallet_amnt_exp_lastdate = req.body.wallet_amnt_exp_lastdate;
    const schema = Joi.object().keys({
        amount_balance: Joi.number().required().label("Amount balance"),
        wallet_amnt_exp_lastdate: Joi.date().required().greater('now').iso().label("Wallet amount expiration last date")
    });
    const dataToValidate = {
        amount_balance: amount_balance,
        wallet_amnt_exp_lastdate: wallet_amnt_exp_lastdate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const wallet = await UserWallet.update({
                amount_balance: amount_balance,
                wallet_amnt_exp_lastdate: wallet_amnt_exp_lastdate,
                last_update: current_date,
                updated_by: user_id
            }, {
                where: {
                    user_id: user_id,
                    status: '1'
                }
            });
            if (!wallet) {
                res.status(202).send({
                    message: process.env.NOT_UPDATED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.UPDATED_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: req.body
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//edit user wallet end

//delete user wallet start
const DeleteUserWallet = async (req, res) => {
    const user_id = req.userId;
    try {
        const wallet = await UserWallet.update({
            status: '0'
        }, {
            where: {
                user_id: user_id
            }
        });
        if (!wallet) {
            res.status(202).send({
                message: process.env.NOT_DELETED_MSG,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.DELETED_MSG,
                error: false,
                success: true,
                status: '1'
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//delete user wallet end
//user wallet ends

//static page starts
//get static page list start
const GetStaticPage = async (req, res) => {
    const slug = req.params.slug;
    try {
        const pmstr = await PageMstr.findOne({
            where: {
                page_slug: slug,
                status: '1'
            },
            attributes: ['id']
        });
        const page_id = pmstr ? pmstr['id'] : 0;
        const staticPages = await StaticPage.findOne({
            where: {
                page_id: page_id,
                status: '1'
            },
            attributes: ['id', 'title', 'description']
        });
        if (staticPages == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: staticPages
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get static page list end

//static page starts

//product starts
//get product start
const GetProduct = async (req, res) => {
    try {
        const product = await Product.findAll({
            where: {
                status: '1',
                is_deleted: '0'
            },
            attributes: ['id', 'product_name', 'product_slug', 'title', 'description', 'price', 'stock_quantity', 'weight', 'category_id', 'has_variant', 'product_tags', 'usd_price', 'usd_compare_price'],
            include: [
                {
                    model: Category,
                    attributes: ['id', 'name'],
                    where: { status: '1' },
                    required: false
                },
                {
                    model: ProductVariant,
                    attributes: ['size_id', 'color_id'],
                    required: false,
                    include: [
                        {
                            model: Size,
                            attributes: ['size'],
                            where: { status: '1' },
                            required: false
                        },
                        {
                            model: Color,
                            attributes: ['color'],
                            where: { status: '1' },
                            required: false
                        }
                    ],
                }
            ]
        });
        if (product == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: product
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get product end

//storage start
const product_file_storage = multer.diskStorage({
    destination: async (req, file, cb) => {
        const uploadPath = process.env.PRODUCT_IMAGE;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + extension);
    },
});
//storage end

//add product start
const upload = multer({ storage: product_file_storage });
const AddProduct = async (req, res) => {
    upload.single('file')(req, res, async function (error) {
        const user_id = req.userId;
        const product_name = req.body.product_name;
        const title = req.body.title;
        const description = req.body.description;
        const product_slug = slugify(title, '-');
        const price = req.body.price;
        const stock_quantity = req.body.stock_quantity;
        const category_id = req.body.category_id;
        const has_variant = req.body.has_variant;
        const weight = req.body.weight;
        const product_tags = req.body.product_tags;
        const size_id = req.body.size_id;
        const color_id = req.body.color_id;
        const file_type = req.body.file_type;
        const schema = Joi.object().keys({
            product_name: Joi.string().required().label("Product name"),
            title: Joi.string().required().label("Title"),
            description: Joi.string().required().label("Description"),
            price: Joi.string().required().label("Price"),
            stock_quantity: Joi.string().required().label("Stock quantity"),
            category_id: Joi.number().integer().required().label("Category"),
            has_variant: Joi.number().integer().required().label("Variant"),
            weight: Joi.number().required().label("Weight"),
            product_tags: Joi.array().items(Joi.number().integer()).label("Product Tags"),
            size_id: Joi.number().integer().required().label("Size"),
            color_id: Joi.number().integer().required().label("Color")
        });
        const dataToValidate = {
            product_name: product_name,
            title: title,
            description: description,
            price: price,
            stock_quantity: stock_quantity,
            category_id: category_id,
            has_variant: has_variant,
            weight: weight,
            product_tags: product_tags,
            size_id: size_id,
            color_id: color_id
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(403).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        } else {
            try {
                const checkProductExists = await Product.findOne({ where: { product_name: product_name, status: '1' } });
                if (checkProductExists) {
                    res.status(409).send({
                        message: 'Product already exists',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    const product = await Product.create({
                        product_name: product_name,
                        product_slug: product_slug,
                        title: title,
                        description: description,
                        price: price,
                        stock_quantity: stock_quantity,
                        weight: weight,
                        product_tags: product_tags,
                        category_id: category_id,
                        created_at: current_date,
                        created_by: user_id
                    });
                    const productVariant = await ProductVariant.create({
                        product_id: product['id'],
                        size_id: size_id,
                        color_id: color_id
                    });
                    const hasVariantUpd = await Product.update({
                        has_variant: productVariant['id']
                    }, {
                        where: {
                            id: product['id']
                        }
                    });
                    if (req.file) {
                        var image = req.file.filename;
                    } else {
                        var image = null;
                    }
                    const productMedia = await ProductMedia.create({
                        product_id: product['id'],
                        file_name: image,
                        file_type: file_type
                    });
                    if (!product) {
                        res.status(202).send({
                            message: process.env.NOT_INSERTED_MSG,
                            error: true,
                            success: false,
                            status: '0'
                        });
                    } else {
                        res.status(200).send({
                            message: process.env.INSERTED_MSG,
                            error: false,
                            success: true,
                            status: '1',
                            data: product
                        });
                    }
                }
            } catch (error) {
                res.status(500).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
}
//add product end

//edit product start
const EditProduct = async (req, res) => {
    upload.single('file')(req, res, async function (error) {
        const id = req.body.id;
        const user_id = req.userId;
        const product_name = req.body.product_name;
        const title = req.body.title;
        const description = req.body.description;
        const product_slug = slugify(title, '-');
        const price = req.body.price;
        const stock_quantity = req.body.stock_quantity;
        const category_id = req.body.category_id;
        const has_variant = req.body.has_variant;
        const weight = req.body.weight;
        const product_tags = req.body.product_tags;
        const size_id = req.body.size_id;
        const color_id = req.body.color_id;
        const file_type = req.body.file_type;
        const schema = Joi.object().keys({
            id: Joi.required(),
            product_name: Joi.required().label("Product name"),
            title: Joi.string().required().label("Title"),
            description: Joi.string().required().label("Description"),
            price: Joi.string().required().label("Price"),
            stock_quantity: Joi.string().required().label("Stock quantity"),
            category_id: Joi.number().integer().required().label("Category"),
            has_variant: Joi.number().integer().required().label("Variant"),
            weight: Joi.number().label("Weight"),
            product_tags: Joi.array().items(Joi.number().integer()).label("Product Tags"),
            size_id: Joi.number().integer().label("Size"),
            color_id: Joi.number().integer().label("Color")
        });
        const dataToValidate = {
            id: id,
            product_name: product_name,
            title: title,
            description: description,
            price: price,
            stock_quantity: stock_quantity,
            category_id: category_id,
            has_variant: has_variant,
            weight: weight,
            product_tags: product_tags,
            size_id: size_id,
            color_id: color_id
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(403).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        } else {
            try {
                if (size_id && color_id) {
                    const productVariant = await ProductVariant.update({
                        product_id: id,
                        size_id: size_id,
                        color_id: color_id
                    }, {
                        where: {
                            id: id
                        }
                    });
                }
                const product = await Product.update({
                    product_name: product_name,
                    product_slug: product_slug,
                    title: title,
                    description: description,
                    price: price,
                    stock_quantity: stock_quantity,
                    category_id: category_id,
                    has_variant: '1',
                    weight: weight,
                    product_tags: product_tags,
                    updated_at: current_date,
                    updated_by: user_id
                }, {
                    where: {
                        id: id,
                        status: '1'
                    }
                });
                if (req.file) {
                    const userData = await ProductMedia.findOne({
                        where: {
                            id: id
                        }
                    });
                    if (userData['file_name'] !== null && userData['file_name'] !== '') {
                        fs.unlink(process.env.PRODUCT_IMAGE + userData['file_name'], (error) => {
                        });
                    }
                    var image = req.file.filename;
                } else {
                    var image = null;
                }
                const productMedia = await ProductMedia.create({
                    product_id: product['id'],
                    file_name: image,
                    file_type: file_type
                });
                if (!product) {
                    res.status(202).send({
                        message: process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    res.status(200).send({
                        message: process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch (error) {
                res.status(500).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
}
//edit product end

//delete product start
const DeleteProduct = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id: Joi.number().integer().required()
    });
    const dataToValidate = {
        id: id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const page = await Product.update({
                status: '0',
                is_deleted: '1',
                updated_at: current_date,
                updated_by: user_id
            }, {
                where: { id: id }
            });
            if (!page) {
                res.status(202).send({
                    message: process.env.NOT_DELETED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.DELETED_MSG,
                    error: false,
                    success: true,
                    status: '1'
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//delete product ends
//product ends

//add query start
const AddQuery = async (req, res) => {
    const name = req.body.name;
    const email = req.body.email;
    const contact_number = req.body.contact_number;
    const message = req.body.message;
    const schema = Joi.object().keys({
        name: Joi.string().required().label("Name"),
        email: Joi.string().required().email().label("Email"),
        contact_number: Joi.number().min(12).required().label("Contact number"),
        message: Joi.string().required().label("Message"),
    });
    const dataToValidate = {
        name: name,
        email: email,
        contact_number: contact_number,
        message: message
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const query = await Query.create({
                name: name,
                email: email,
                contact_number: contact_number,
                message: message,
                created_at: current_date
            });
            const axios = require('axios');
            const qs = require('qs');
            let data = qs.stringify({
                'to': email,
                'subject': 'Contact Us',
                'msg_detail': email + ' have contacted you for inquiry.',
            });

            const config = {
                method: 'post',
                url: process.env.SITE_URL + 'send_mail_node_api',
                data: data
            };

            const response = await axios(config);
            if (!query) {
                res.status(202).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.INSERTED_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: query
                });
            }

        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//add query end

//Coupon starts
//get coupon start
// const GetCoupon = async (req, res) => {
//     const user_id = req.userId;
//     // try {

//     const usercoupons = await UserCoupon.findAll({
//         where: {
//             user_id: user_id,
//         },
//         attributes: ['coupon_id'],

//     });
//     const couponIds = usercoupons.map(coupon => coupon.coupon_id);
//     var current_datee = moment(getCurrentDateTime()).format("YYYY-MM-DD");
//     const coupon = await Coupon.findAll({
//         where: {
//             apply_to: 'ORDER',
//             // apply_to:{ [Op.ne]: "FIRST_ORDER" },
//             to_date: { [Op.gte]: current_datee },
//             status: '1',
//             is_deleted: 0,
//             [Op.or]: [
//                 { coupon_allow: '1' },
//                 { id: { [Op.in]: couponIds } },
//             ],
//         },
//         attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt', [
//             // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
//             sequelize.literal(`CASE WHEN applied_coupon.id IS NOT NULL THEN TRUE ELSE FALSE END`),
//             'is_coupon'
//         ]],
//         include: [
//             {
//                 model: OrderDiscountCoupon,
//                 as: 'applied_coupon',
//                 attributes: ['id'],
//                 where: { user_id: user_id, discount_type: 'order' },
//                 required: false,
//             }
//         ],
//     });
//     if (!coupon) {
//         res.status(202).send({
//             message: process.env.RECORD_NOT_FOUND,
//             error: true,
//             success: false,
//             status: '0'
//         });
//     } else {
//         res.status(200).send({
//             message: process.env.SUCCESS_MSG,
//             error: false,
//             success: true,
//             status: '1',
//             data: coupon,
//         });
//     }
//     // } catch(error) {
//     //     res.status(500).send({
//     //         message:process.env.ERROR_MSG,
//     //         error: true,
//     //         success: false,
//     //         status: '0',
//     //     });
//     // }
// }

const GetCoupon = async (req, res) => {
    const user_id = req.body.user_id || 0;
    try {

        const usercoupons = await UserCoupon.findAll({
            where: {
                user_id: user_id,
            },
            attributes: ['coupon_id'],

        });
        const couponIds = usercoupons.map(coupon => coupon.coupon_id);
        var current_datee = moment(getCurrentDateTime()).format("YYYY-MM-DD");
        const coupon = await Coupon.findAll({
            where: {
                apply_to: 'ORDER',
                // apply_to:{ [Op.ne]: "FIRST_ORDER" },
                to_date: { [Op.gte]: current_datee },
                status: {
                    [Op.in]: ['1', '2']
                },
                is_deleted: 0,
                [Op.or]: [
                    { coupon_allow: '1' },
                    { id: { [Op.in]: couponIds } },
                ],
            },
            attributes: ['id', 'multiple_use', 'status', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt',
                [sequelize.literal(`CASE WHEN applied_coupon.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                    'is_applied']
            ],
            include: [
                {
                    model: OrderDiscountCoupon,
                    as: 'applied_coupon',
                    attributes: ['id'],
                    where: { user_id: user_id, discount_type: 'order' },
                    required: false,
                }
            ],
        });
        var firstOrder = await Coupon.findOne({
            where: {
                apply_to: 'FIRST_ORDER',
                status: '1',
                is_deleted: 0,
            },
            attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'
                , [
                    sequelize.literal(`CASE WHEN applied_coupon.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                    'is_applied'
                ]
            ],
            include: [
                {
                    model: OrderDiscountCoupon,
                    as: 'applied_coupon',
                    attributes: ['id'],
                    where: { user_id: user_id, discount_type: 'first_order' },
                    required: false,
                }
            ],
        });

        await Promise.all(
            coupon.map(async (coupons) => {
                const appliedCoupon = await Order.findOne({
                    where: {
                        user_id,
                        [Op.or]: [
                            { discount_id: coupons.id.toString() },
                            sequelize.literal(`FIND_IN_SET(${coupons.id}, discount_id) > 0`)
                        ]
                    },
                });
                coupons.dataValues.is_redeemed = appliedCoupon ? 1 : 0;
            })
        );

        const orderCount = await Order.count({
            where: {
                user_id: user_id,
                payment_status: { [Op.in]: [0, 1] }
            }
        });
        if (!coupon[0]) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                order_count: orderCount,
                firstOrder: '',
                data: coupon,
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}


const GetProductCoupon = async (req, res) => {
    const product_id = req.body.product_id;
    const user_id = req.body.user_id || 0;
    try {
        var current_datee = moment(getCurrentDateTime()).format("YYYY-MM-DD");
        const coupon = await Coupon.findAll({
            where: {
                apply_to: 'PRODUCTS',
                to_date: { [Op.gte]: current_datee },
                status: '1',
                is_deleted: 0,
                [Op.or]: [
                    // Check if product_id is in the comma-separated list of apply_value
                    sequelize.literal(`FIND_IN_SET(${product_id}, apply_value)`),
                    // Add other conditions if needed
                ]
            },
            attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'
                , [
                    sequelize.literal(`CASE WHEN product_coupon_applied.discount_id IS NOT NULL THEN TRUE ELSE FALSE END`),
                    'applied_product_coupon'
                ]
            ],
            include: [
                {
                    model: Cart,
                    as: 'product_coupon_applied',
                    attributes: ['id'],
                    where: { user_id: user_id, product_id: product_id },
                    required: false,
                }
            ],
        });

        const cartCouponCount = await Cart.count({
            where: {
                user_id: user_id,
                product_id: product_id,
                discount_id: {
                    [sequelize.Op.ne]: 0
                }
            },
            distinct: true,
            col: 'discount_id'
        });
        var couponDetails = '0';
        if (cartCouponCount) {
            var cartCouponDetails = await Cart.findOne({
                where: {
                    user_id: user_id,
                    product_id: product_id,
                    discount_id: {
                        [sequelize.Op.ne]: 0
                    }
                },
                include: [
                    {
                        model: Coupon,
                        as: 'product_coupon',
                        attributes: ['id', 'coupon_code'],
                    }
                ],
                attributes: ['id', 'subtotal_amount', 'discount_id', 'product_id'],
            });
        }
        console.log(user_id)

        if (cartCouponDetails) {
            couponDetails = {
                id: cartCouponDetails.id,
                subtotal_amount: cartCouponDetails.subtotal_amount,
                discount_id: cartCouponDetails.discount_id,
                product_id: cartCouponDetails.product_id,
                coupon_code: cartCouponDetails.product_coupon.coupon_code // Assign coupon_code directly
            };
        }


        if (!coupon) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: coupon,
                couponDetails: couponDetails,
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            msg: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}


const ApplyCoupon = async (req, res) => {
    const user_id = req.userId;
    const coupon_code = req.body.coupon_code;
    const schema = Joi.object().keys({
        coupon_code: Joi.string().required().label("Coupon"),
    });
    const dataToValidate = {
        coupon_code: coupon_code
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const couponDetails = await Coupon.findOne({ where: { coupon_code: coupon_code, status: '1', is_deleted: 0 }, attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'] });
            if (!couponDetails) {
                res.status(409).send({
                    message: 'Coupon not valid',
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const carts = await Cart.findAll({
                    where: {
                        user_id: user_id
                    },
                    attributes: ['subtotal_amount'],
                });
                let subtotal_amount = 0;
                if (carts) {
                    for (const cart of carts) {
                        if (cart) {
                            subtotal_amount += parseFloat(cart.subtotal_amount);
                        }
                    }
                }
                const orderCount = await Order.count({
                    where: {
                        discount_id: couponDetails['id'],
                    }
                });
                const cartCouponCount = await Cart.count({
                    where: {
                        user_id: user_id,
                        discount_id: {
                            [sequelize.Op.ne]: 0
                        }
                    },
                    distinct: true,
                    col: 'discount_id'
                });
                if (cartCouponCount) {
                    var total_cart_coupon_apply = 1;
                }
                const couponDiscount = await OrderDiscountCoupon.count({
                    where: {
                        user_id: user_id,
                        applied_status: 1,
                        discount_id: {
                            [sequelize.Op.ne]: 0
                        }
                    },
                    distinct: true,
                    col: 'discount_id'
                });
                if (couponDiscount) {
                    var total_discount_coupon_apply = 1;
                }
                var total_coupon = total_cart_coupon_apply + total_discount_coupon_apply;
                var to_date = moment(couponDetails['to_date'] + ' 23:59:59', "YYYY-MM-DD HH:mm:ss");
                var current_datee = moment(getCurrentDateTime());

                var min_amount = couponDetails ? couponDetails.min_amount : 0;
                var upto_amount = couponDetails ? couponDetails.upto_amount : 0;
                if (to_date < current_datee) {
                    res.status(202).send({
                        message: 'Coupon expired',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else if (total_coupon == 2) {
                    res.status(202).send({
                        message: 'You can only apply up to two coupons. Oops! It looks like you’ve already applied two.',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else if (couponDetails['number_of_uses'] < orderCount) {
                    res.status(202).send({
                        message: 'Coupon not axious',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else if ((min_amount >= 0 && min_amount > subtotal_amount) || (upto_amount > 0 && upto_amount < subtotal_amount)) {
                    res.status(202).send({
                        message: `Order amount less then ${min_amount} and amount greater then ${upto_amount}`,
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    if (couponDetails) {
                        // add Suresh 17-oct-2024 add discount  total amount
                        const couponAddDisount = await OrderDiscountCoupon.findOne({
                            where: {
                                user_id: user_id,
                                applied_status: 1,
                                discount_type: {
                                    [Op.in]: ['first_order', 'order']
                                }
                            },
                            attributes: [
                                [sequelize.fn('SUM', sequelize.col('discount_amt')), 'totalDiscountAmt']
                            ]
                        });
                        const totalDiscountAmt = couponAddDisount ? couponAddDisount.get('totalDiscountAmt') : 0;
                        //end add Suresh 17-oct-2024
                        var dis_amt = subtotal_amount - totalDiscountAmt;
                        if (couponDetails.coupon_type === 'percent') {
                            var discount_amount = (Math.round(dis_amt) * couponDetails.type_val) / 100;
                        } else if (couponDetails.coupon_type === 'normal') {
                            var discount_amount = couponDetails.type_val;
                        }
                        const discount = await OrderDiscountCoupon.findOne({
                            where: {
                                user_id: user_id,
                                discount_type: couponDetails.apply_to.toLowerCase()
                            },
                            attributes: ['id', 'discount_type', 'discount_id'],
                        });
                        var dataCoupon = '';
                        if (discount) {
                            const discountCoupon = discount.get({ plain: true });
                            await OrderDiscountCoupon.update({
                                user_id: user_id,
                                discount_id: couponDetails.id,
                                discount_amt: discount_amount,
                                discount_type: couponDetails.apply_to.toLowerCase(),
                                updated_at: current_date,
                            }, {
                                where: {
                                    id: discountCoupon.id
                                }
                            });
                        } else {
                            dataCoupon = await OrderDiscountCoupon.create({
                                user_id: user_id,
                                discount_id: couponDetails.id,
                                discount_amt: discount_amount,
                                discount_type: couponDetails.apply_to.toLowerCase(),
                                created_at: current_date,
                            });
                        }
                    }
                    res.status(200).send({
                        message: process.env.SUCCESS_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        user_id: user_id,
                        data: discount_amount
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const ApplyCoupon_olddd = async (req, res) => {
    const user_id = req.userId;
    const coupon_code = req.body.coupon_code;
    const schema = Joi.object().keys({
        coupon_code: Joi.string().required().label("Coupon"),
    });
    const dataToValidate = {
        coupon_code: coupon_code
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const couponDetails = await Coupon.findOne({ where: { coupon_code: coupon_code, status: '1', is_deleted: 0 }, attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'] });
            if (!couponDetails) {
                res.status(409).send({
                    message: 'Coupon not valid',
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const carts = await Cart.findAll({
                    where: {
                        user_id: user_id
                    },
                    attributes: ['subtotal_amount'],
                });
                let subtotal_amount = 0;
                if (carts) {
                    for (const cart of carts) {
                        if (cart) {
                            subtotal_amount += parseFloat(cart.subtotal_amount);
                        }
                    }
                }
                const orderCount = await Order.count({
                    where: {
                        discount_id: couponDetails['id'],
                    }
                });
                const cartCouponCount = await Cart.count({
                    where: {
                        user_id: user_id,
                        discount_id: {
                            [sequelize.Op.ne]: 0
                        }
                    },
                    distinct: true,
                    col: 'discount_id'
                });
                if (cartCouponCount) {
                    var total_cart_coupon_apply = 1;
                }
                const couponDiscount = await OrderDiscountCoupon.count({
                    where: {
                        user_id: user_id,
                        applied_status: 1,
                        discount_id: {
                            [sequelize.Op.ne]: 0
                        }
                    },
                    distinct: true,
                    col: 'discount_id'
                });
                if (couponDiscount) {
                    var total_discount_coupon_apply = 1;
                }
                var total_coupon = total_cart_coupon_apply + total_discount_coupon_apply;
                var to_date = moment(couponDetails['to_date'] + ' 23:59:59', "YYYY-MM-DD HH:mm:ss");
                var current_datee = moment(getCurrentDateTime());

                var min_amount = couponDetails ? couponDetails.min_amount : 0;
                var upto_amount = couponDetails ? couponDetails.upto_amount : 0;
                if (to_date < current_datee) {
                    res.status(202).send({
                        message: 'Coupon expired',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else if (total_coupon == 2) {
                    res.status(202).send({
                        message: 'You can only apply up to two coupons. Oops! It looks like you’ve already applied two.',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else if (couponDetails['number_of_uses'] < orderCount) {
                    res.status(202).send({
                        message: 'Coupon not axious',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else if ((min_amount >= 0 && min_amount > subtotal_amount) || (upto_amount > 0 && upto_amount < subtotal_amount)) {
                    res.status(202).send({
                        message: `Order amount less then ${min_amount} and amount greater then ${upto_amount}`,
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    if (couponDetails) {
                        if (couponDetails.coupon_type === 'percent') {
                            var discount_amount = (subtotal_amount * couponDetails.type_val) / 100;
                        } else if (couponDetails.coupon_type === 'normal') {
                            var discount_amount = couponDetails.type_val;
                        }
                        const discount = await OrderDiscountCoupon.findOne({
                            where: {
                                user_id: user_id,
                                discount_type: couponDetails.apply_to.toLowerCase()
                            },
                            attributes: ['id', 'discount_type', 'discount_id'],
                        });
                        if (discount) {
                            const discountCoupon = discount.get({ plain: true });
                            await OrderDiscountCoupon.update({
                                user_id: user_id,
                                discount_id: couponDetails.id,
                                discount_amt: discount_amount,
                                discount_type: couponDetails.apply_to.toLowerCase(),
                                updated_at: current_date,
                            }, {
                                where: {
                                    id: discountCoupon.id
                                }
                            });
                        } else {
                            const dataCoupon = await OrderDiscountCoupon.create({
                                user_id: user_id,
                                discount_id: couponDetails.id,
                                discount_amt: discount_amount,
                                discount_type: couponDetails.apply_to.toLowerCase(),
                                created_at: current_date,
                            });
                        }
                    }
                    res.status(200).send({
                        message: process.env.SUCCESS_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        user_id: user_id,
                        data: couponDetails
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

const ApplyCoupon_old = async (req, res) => {
    const user_id = req.userId;
    const coupon_code = req.body.coupon_code;
    const schema = Joi.object().keys({
        coupon_code: Joi.string().required().label("Coupon"),
    });
    const dataToValidate = {
        coupon_code: coupon_code
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const couponDetails = await Coupon.findOne({ where: { coupon_code: coupon_code, status: '1', is_deleted: 0 }, attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'] });

            if (!couponDetails) {
                res.status(409).send({
                    message: 'Coupon not valid',
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const orderCount = await Order.count({
                    where: {
                        discount_id: couponDetails['id'],
                    }
                });

                var to_date = moment(couponDetails['to_date'] + ' 23:59:59', "YYYY-MM-DD HH:mm:ss");
                var current_datee = moment(getCurrentDateTime());

                if (to_date < current_datee) {
                    res.status(202).send({
                        message: 'Coupon expired',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else if (couponDetails['number_of_uses'] < orderCount) {
                    res.status(202).send({
                        message: 'Coupon not axious',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    res.status(200).send({
                        message: process.env.SUCCESS_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: couponDetails
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//get coupon end
//Coupon ends

//Wallet main start
const AddWalletMain = async (req, res) => {
    const user_id = req.userId;
    const amount = req.body.amount;
    const details = req.body.details;
    const if_apply_coupon = req.body.if_apply_coupon;
    const coupon_id = req.body.coupon_id;
    if (if_apply_coupon == '1') {
        var coupon_id_valid = Joi.number().integer().required().label("Coupon");
    } else {
        var coupon_id_valid = Joi.number().integer().label("Coupon");
    }
    const schema = Joi.object().keys({
        if_apply_coupon: Joi.string().required().label("If apply coupon"),
        amount: Joi.string().required().label("Amount"),
        details: Joi.string().required().label("Details"),
        coupon_id: coupon_id_valid
    });
    const dataToValidate = {
        if_apply_coupon: if_apply_coupon,
        amount: amount,
        details: details,
        coupon_id: coupon_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            function randomString(len) {
                var p = "0123456789";
                return [...Array(len)].reduce(a => a + p[~~(Math.random() * p.length)], '');
            }
            if (amount < 0) {
                var transaction_id = "strpd" + randomString(6);
                var debit_credit_status = 2;
            } else {
                var transaction_id = "strpd" + randomString(6);
                var debit_credit_status = 1;
            }
            const WalletData = await WalletMain.create({
                user_id: user_id,
                transaction_id: transaction_id,
                debit_credit: debit_credit_status,
                invoice_no: '12345',
                invoice_type: '1',
                amount: amount,
                order_status: '1',
                details: details,
                if_apply_coupon: if_apply_coupon,
                created_at: current_date,
                created_by: user_id
            });
            if (!WalletData) {
                res.status(202).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.INSERTED_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: WalletData
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//Wallet main end

//seo start
//get seo start
const GetSeo = async (req, res) => {
    const page_type = req.body.page_type;
    const slug = req.body.slug;
    try {
        const seo = await Seo.findOne({
            where: {
                page_type: page_type,
                page_slug: slug,
                status: '1'
            },
            attributes: ['id', 'page_type', 'page_slug', 'page_id', 'title', 'meta_description', 'meta_keyword', 'footer_content']
        });
        if (!seo) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: seo
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get seo end

//get home slider start
const GetHomeSliderList = async (req, res) => {
    try {

        const slider = await HomeSlider.findAll({
            where: {
                status: '1'
            },
            attributes: ['id', 'title', 'sub_title', 'image', 'button_link'],
            order: [
                ['order_sr_no', 'ASC']
            ],
        });


        // const slider = await HomeSlider.findAll({
        //     order: [
        //         ['order_sr_no', 'ASC']
        //     ],
        //     attributes: ['id', 'title', 'sub_title', 'image', 'button_link','status']
        // }, {
        //     where: {
        //         status:"1"
        //     }
        // });
        if (slider == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/slider/',
                data: slider
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get home slider end

//get tag start
const GetTagList = async (req, res) => {
    try {
        const slider = await Tag.findAll({
            where: {
                status: '1'
            },
            attributes: ['id', 'tag_name']
        });
        if (slider == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: slider
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get tag start

//get new arrivals 
const GetNewArrivals = async (req, res) => {
    const user_id = req.body.user_id || 0;
    try {
        const arrivalsProduct = await Product.findAll({
            limit: 10,
            // order: [
            //     // ['stock_quantity','DESC']
            //     ['updated_at', 'DESC'],
            //     ['created_at', 'DESC']
            // ],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: { file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        if (arrivalsProduct == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: arrivalsProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
function convertToSlug(text) {
    return text
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '')
        .replace(/^-+|-+$/g, '');
}
const GetAllNewArrivals = async (req, res) => {
    const user_id = req.body.user_id || 0;
    const slug = req.body.slug || 'newarrival';
    try {
        var slider_details = await AssignPageSlider.findOne({
            attributes: ['page_slider_id'],
            required: false,
            where: { type: '3', category_menu_id: 1 },
            include: [
                {
                    model: PageSlider,
                    as: 'page_slider',
                    attributes: ['id', 'title'],
                    required: false,
                    include: [
                        {
                            model: PageSliderImages,
                            as: 'page_slider_images',
                            attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                            required: false,
                        },
                    ],
                },
            ],

        });
        const arrivalsProduct = await Product.findAll({
            order: [['stock_quantity', 'DESC']],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'],
                [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']
            ],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const maxpriceproducts = await Product.findOne({
            where: {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ]
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }
        if (arrivalsProduct == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                slug: slug,
                slider_details: slider_details,
                max_price: maxpriceVal,
                data: arrivalsProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get new arrivals

//about us
const AboutUs = async (req, res) => {
    try {
        const page = await PageMstr.findOne({
            attributes: ['page_slug']
        }, {
            where: {
                status: '1',
                page_slug: 'about-us'
            },
        });
        const aboutUs = await StaticPage.findOne({
            attributes: ['title', 'home_image', 'home_description']
        }, {
            where: {
                status: '1',
                page_id: page['id']
            },
        });
        if (aboutUs == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/about_us/',
                data: aboutUs
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//about us

//contact us
const AddContactUs = async (req, res) => {
    const email = req.body.email;
    const schema = Joi.object().keys({
        email: Joi.string().required().email().label("Email")
    });
    const dataToValidate = {
        email: email
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const newsletter = await NewsLetter.create({
                email: email,
                created_at: current_date
            }
            );
            sendEmail(newsletter, 'Subscribe');
            if (!newsletter) {
                res.status(202).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.INSERTED_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: req.body
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//contact us

//shop by category
const ShopByCategory = async (req, res) => {
    try {
        // const category = await ShopCategoryPosition.findAll({
        //     attributes: ['id'],
        //     include: [
        //         {
        //             model: Menu,
        //             as: 'menus',
        //             attributes: ['id', 'slug', ['menu_name', 'name'], 'image'],
        //             where: {
        //                 status: '1',
        //                 parent: '0',
        //             },
        //             required: false,
        //         }
        //     ],
        //     order: [['position', 'ASC']],
        // });
        const category = await Category.findAll({
            attributes: ['id', 'name','slug', 'image_icon'],
            where: {
                status: '1',
                parent_id: {
                [sequelize.Op.ne]: '0',
                },
            },
        });
        if (category == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/category/',
                data: category
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//shop by category

//get home section start
// const GetHomeSectionList = async (req, res) => {
//     var section_type = req.body.section_type;
//     try {
//         const section = await HomeSection.findAll({
//             where: {
//                 section_type:section_type,
//                 status:'1'
//             },
//             attributes:['id','title','sub_title','image','button_link','section_type']
//         });

//         if (section == 0){
//             res.status(202).send({
//                 message: process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         }else{
//             res.status(200).send({
//                 message: process.env.SUCCESS_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 path:process.env.SITE_URL+'uploads/sections/',
//                 data: section
//             });
//         }
//     }catch(error) {
//         res.status(500).send({
//             message:process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }

//abhimanyu
const GetHomeSectionList = async (req, res) => {
    // var section_type = req.body.section_type;
    try {
        const section_top = await HomeSection.findAll({
            where: {
                // section_type: section_type,
                status: '1',
                section_type: 'top'
            },
            attributes: ['id', 'title', 'sub_title', 'image', 'button_link', 'section_type']
        });

        const section_middle = await HomeSection.findAll({
            where: {
                // section_type: section_type,
                status: '1',
                section_type: 'middle'
            },
            attributes: ['id', 'title', 'sub_title', 'image', 'button_link', 'section_type']
        });

        const section_offer = await HomeSection.findAll({
            where: {
                //  section_type: section_type,
                status: '1',
                section_type: 'offer'
            },
            attributes: ['id', 'title', 'sub_title', 'image', 'button_link', 'section_type']
        });

        const section_down = await HomeSection.findAll({
            where: {
                //  section_type: section_type,
                status: '1',
                section_type: 'down'
            },
            attributes: ['id', 'title', 'sub_title', 'image', 'button_link', 'section_type']
        });

        const response = {
            section_top: section_top,
            section_middle: section_middle,
            section_offer: section_offer,
            section_down: section_down,

        }
        if (response == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/sections/',
                data: response
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}



// const GetProductDetail = async (req, res) => {
//     const user_id = req.body.user_id || 0;
//     const slug = req.params.slug || 0;
//     const attr_type_id = req.body.attr_type_id || 0;
//     const attr_val_id = req.body.attr_val_id || 0;
//     const attr_second_type_id = req.body.attr_second_type_id || 0;
//     const attr_second_val_id = req.body.attr_second_val_id || 0;

//     try {
//         const products = await Product.findOne({
//             where: {
//                 product_slug:slug,
//                 status: '1',
//                 is_deleted: '0'
//             },
//             attributes:['id','sku','product_name','product_slug','price','compare_price','category_id','stock_quantity','usd_price','usd_compare_price',['product_tags','Feature'],'pack_contain','description','additional_description',['why_we_it','why_we_love_it'],'shipping_return','dimension'
//             ,'is_gift_option','gift_price','is_allow_cod','return_days_limit','image_alt','weight','unit','is_shipping','shipping_amount_type','shipping_charge'
//             ,'product_buffer_days','description_class','additional_description_class','why_we_love_it_class','shipping_return_class','dimension_class','product_overview','product_overview_class','why_we_it_class','discount'
//             ],
//             include:[
//             {
//                 model:ProductType,
//                 as:'producttypes',
//                 attributes: ['type_name'],
//                 where: { status: '1'},
//                 required: false
//             },
//             {
//                 model:ProductMaterial,
//                 as:'productmaterials',
//                 attributes: ['material_name'],
//                 where: { status: '1'},
//                 required: false
//             },
//             {
//                 model:ProductMedia,
//                 as:'productimages',
//                 attributes: ['file_name','file_name_200_x_200','file_name_180_x_180','file_name_150_x_150','file_name_120_x_120'],
//                 required: false,
//                 // order: [['is_default', 'DESC']]
//             },
//             {
//                 model: ProductNotifyModel,
//                 as: 'product_notify',
//                 attributes: ['id'],
//                 where: { user_id: user_id },
//                 required: false,
//             },
//             {
//                 model: SiteSellerProducts,
//                 as: 'seller_product',
//                 attributes: ['seller_id'],
//                 where: { seller_id: 3 },
//                 required: true,
//             }
//         ],
//         order: [[{ model: ProductMedia, as: 'productimages' }, 'is_default', 'DESC']],
//         });
//         const product_id = products ? products['id'] : 0;

//         const variantDetail = await ProductVariantGroup.findOne({
//             where:{product_id:product_id},
//             attributes: ['product_id','variant_id'],
//             required: false,
//             include: [
//                 {
//                     model: Variant,
//                     as:'variants',
//                     attributes: ['variant_title','attr_type_id'],
//                     where: { status: '1'},
//                     required: false,
//                     include: [
//                         {
//                             model: ProductAttributeType,
//                             as:'variant_attr_type',
//                             attributes: ['attr_type_name'],
//                             where: { status: '1'},
//                             required: false,
//                         }
//                     ]
//                 }
//             ]
//         });

//         //product variant group
//         const get_product_attr = await ProductAttributes.findAll({
//             where: { product_id: product_id },
//             attributes: ['id', 'attr_type_id', 'attr_val_id'],
//         });

//         const get_product_variant = await ProductVariantGroup.findOne({
//             where: { product_id: product_id },
//             attributes: ['id', 'variant_id'],
//         });

//         async function processAttribute(attr) {
//             if((attr.attr_second_val_id)) {

//                 // const prodByColor = await ProductAttributes.findAll({
//                 //     attributes:['product_id'],
//                 //     where:{
//                 //         attr_type_id:attr.attr_type_id,
//                 //         attr_val_id:attr.attr_val_id,
//                 //     }
//                 // });
//                 // const prIdArr = prodByColor.map(product => product ? product.product_id : null);

//                 const prodByColor1 = await ProductAttributes.findAll({
//                     attributes:['product_id'],
//                     where:{
//                         attr_type_id:attr_second_type_id,
//                         attr_val_id:attr_second_val_id,
//                     }
//                 });
//                 const prIdArr1 = prodByColor1.map(product => product ? product.product_id : null);
//                 var prIdd = prIdArr1;
//                 // var prIdd = prIdArr.filter(value => prIdArr1.includes(value));

//             } else {
//                 const prodByColor = await ProductAttributes.findAll({
//                     attributes:['product_id'],
//                     where:{
//                         attr_type_id:attr.attr_type_id,
//                         attr_val_id:attr.attr_val_id,
//                     }
//                 });
//                 const prIdArr = prodByColor.map(product => product ? product.product_id : null);
//                 var prIdd = prIdArr;
//             }

//             const checkVeriant = await ProductVariantGroup.findAll({ 
//                 attributes:['product_id'],
//                 where:{
//                     variant_id:get_product_variant ? get_product_variant.variant_id : null,
//                     product_id: { [Op.in]: prIdd }
//                 },
//             });
//             const checkprIdArr = checkVeriant.map(product => product ? product.product_id : null);

//             const productColor = await ProductAttributes.findAll({
//                 where:{product_id: { [Op.in]: checkprIdArr },attr_type_id: attr.attr_type_id, attr_val_id:attr.attr_val_id},
//                 attributes: ['attr_type_id','attr_val_id'],
//                 group:['attr_val_id'],
//                 required: false,
//                 include: [
//                     {
//                         model:Product,
//                         as:"products",
//                         attributes:['product_slug','sku'],
//                         where: {
//                             status:'1'},
//                     },
//                     {
//                         model: ProductAttributeValue,
//                         as:'product_attr_value',
//                         attributes: ['attr_val_name','image'],
//                         where: { status: '1'},
//                         required: false,
//                     }
//                 ]
//             });


//             const checkVeriant1 = await ProductVariantGroup.findAll({ 
//                 attributes:['product_id'],
//                 where:{
//                     variant_id:get_product_variant ? get_product_variant.variant_id : null,
//                     product_id: { [Op.in]: prIdd }
//                 },
//             });

//             const checkprIdArr1 = checkVeriant1.map(product => product ? product.product_id : null);

//             const productAllVariant = await ProductAttributes.findAll({
//                 where:{product_id: { [Op.in]: checkprIdArr1 },attr_type_id: attr.attr_type_id},
//                 attributes: ['attr_type_id','attr_val_id'],
//                 group:['attr_val_id'],
//                 required: false,
//                 include: [
//                     {
//                         model:Product,
//                         as:"products",
//                         attributes:['product_slug','sku'],
//                         where: {
//                             status:'1'},
//                     },
//                     {
//                         model: ProductAttributeValue,
//                         as:'product_attr_value',
//                         attributes: ['attr_val_name','image'],
//                         where: { status: '1'},
//                         required: false,
//                     }
//                 ]
//             });


//             return {
//                 id: attr.id,
//                 attr_type_id: attr.attr_type_id,
//                 attr_val_id: attr.attr_val_id,
//                 variant_id: get_product_variant ? get_product_variant.variant_id : null,
//                 products_by_attr: {data:productColor, alldata:productAllVariant},
//             };
//         }

//         const product_variant_groups = await Promise.all(get_product_attr.map(processAttribute))

//         //primary variant group
//         async function primaryprocessAttribute(attr) {
//             const primaryvariantGroup = await ProductVariantGroup.findOne({
//                 where:{product_id:product_id},
//                 attributes: ['product_id','variant_id'],
//                 required: false,
//                 include: [
//                     {
//                         model: Variant,
//                         as:'variants',
//                         attributes: ['variant_title','attr_type_id'],
//                         where: { status: '1'},
//                         required: false,
//                         include: [
//                             {
//                                 model: ProductAttributeType,
//                                 as:'variant_attr_type',
//                                 attributes: ['attr_type_name'],
//                                 where: { status: '1'},
//                                 required: false,
//                             }
//                         ]
//                     }
//                 ]
//             });
//             const primaryvariantId = primaryvariantGroup ? primaryvariantGroup['variant_id'] : 0;

//             const primarygroupAll = await ProductVariantGroup.findAll({
//                 where: {
//                     variant_id: primaryvariantId,
//                 },
//                 attributes: ['product_id']
//             });
//             const primaryprIdArr = primarygroupAll.map(product => product ? product.product_id : null);


//             const primaryproductColor = await ProductAttributes.findAll({
//                 where:{product_id: { [Op.in]: primaryprIdArr },attr_type_id: attr.attr_type_id},
//                 attributes: ['attr_type_id','attr_val_id'],
//                 group:['attr_val_id'],
//                 required: false,
//                 include: [
//                     {
//                         model:Product,
//                         as:"products",
//                         attributes:['product_slug'],
//                         where: {
//                             status:'1'},
//                     },
//                     {
//                         model: ProductAttributeValue,
//                         as:'product_attr_value',
//                         attributes: ['attr_val_name','image'],
//                         where: { status: '1'},
//                         required: false,
//                     }
//                 ]
//             });
//             return {primary_variant_detail:primaryvariantGroup,primary_data:primaryproductColor}
//         }


//         const product_primary_variant = await Promise.all(get_product_attr.map(primaryprocessAttribute))



//         const productAttribute = await ProductAttributes.findAll({
//             where:{product_id: product_id},
//             attributes: ['id','product_id','attr_type_id','attr_val_id'],
//             required: false,
//             include: [
//                 {
//                     model: ProductAttributeType,
//                     as:'product_attr_type',
//                     attributes: ['id','attr_type_name'],
//                     where: { status: '1'},
//                     required: false,
//                 },
//                 {
//                     model: ProductAttributeValue,
//                     as:'product_attr_value',
//                     attributes: ['id','attr_val_name','slug','image'],
//                     where: { status: '1'},
//                     required: false,
//                 }
//             ]
//         });




//         var variantGroup = await ProductVariantGroup.findOne({where:{product_id:product_id},attributes: ['id']});
//         if (variantGroup) {
//             var is_variant = 1;
//         } else {
//             var is_variant = 0;
//         }

//         const ratings = await Review.findOne({
//             order:[['user_id','DESC']],
//             where:{
//                 status:'1',
//                 product_id:product_id
//             },
//             attributes:[[sequelize.fn('AVG', sequelize.col('rating')), 'StarRating'],[sequelize.fn('COUNT', sequelize.col('user_id')), 'Rating']]
//         });

//         var uId = user_id || 0;
//         var isWishlists = await Wishlist.findOne({where:{product_id:product_id,user_id:uId},attributes: ['id']});
//         if (isWishlists) {
//             var is_wishlist = 1;
//         } else {
//             var is_wishlist = 0;
//         }

//         var review = await Review.findOne({where:{product_id:product_id,user_id:uId},attributes: ['id']});
//         if (review) {
//             var is_review_count = 1;
//         } else {
//             var is_review_count = 0;
//         }

//         const catIdArr = products ? products['category_id'].split(',').map(Number):[];

//         var category = await Category.findAll({
//             where: {
//                 id: { [Op.in]: catIdArr },
//                 status: '1'
//             },
//             attributes:['id','slug','name']
//         });

//         if(user_id){
//             const userProductView = await UserProductView.findOne({
//                 where: {
//                     user_id: user_id,
//                     product_id:product_id,
//                 },
//                 attributes: ['id'],
//             });
//                 if(userProductView){
//                 await UserProductView.update({
//                         created_at: getCurrentDateTime(),
//                     }, {
//                     where: {
//                         user_id: user_id,
//                         product_id: product_id,
//                     }
//                 });
//             }else{
//                 await UserProductView.create({
//                     user_id: user_id,
//                     product_id: product_id,
//                 });
//             }
//         }

//                 if (products) {
//                     var isNotify = await ProductNotifyModel.findOne({where:{product_id:product_id,user_id:uId},attributes: ['id']});
//                     products.dataValues.is_notify = isNotify ? 1 : 0;
//                 }
//                 // inventory product start
//                 var product_sku =  products ? products.sku : '';
//                 const cQuantity = await SiteSellerProducts.findOne({
//                     attributes: [
//                         'quantity',
//                         [sequelize.col('migcp.invt_group_combo_product_id'), 'invt_group_combo_product_id'],
//                         [sequelize.col('migcp.strpd_product_id'), 'group_strpd_id']
//                     ],
//                     include: [
//                         {
//                             model: RelInvtStrpdProduct,
//                             as: 'irsp',
//                             required: false,
//                             include: [
//                                 {
//                                     model: InvtQty,
//                                     as: 'miq',
//                                     required: false,
//                                     attributes: [['qty', 'total_quantity']]
//                                 }
//                             ]
//                         },
//                         {
//                             model: GroupComboProducts,
//                             as: 'migcp',
//                             required: false,
//                             attributes: []
//                         }
//                     ],
//                     where: {
//                         sku: product_sku,
//                         product_id: product_id
//                     }
//                 });

//                 const current_quantity = cQuantity ? cQuantity.quantity : 0;
//                 const total_quantity = cQuantity && cQuantity.irsp && cQuantity.irsp.miq ? cQuantity.irsp.miq.dataValues.total_quantity : 0;
//                 const invt_group_combo_product_id = cQuantity ? cQuantity.dataValues.invt_group_combo_product_id : 0;
//                 const group_strpd_id = cQuantity ? cQuantity.dataValues.group_strpd_id : 0;

//                 let invt_type;
//                 if (group_strpd_id) {
//                     invt_type = 'invt_group_product';
//                 } else {
//                     invt_type = 'invt_product';
//                 }

//                 let is_invt_avl = 0;
//                 if (invt_type === 'invt_product') {
//                     is_invt_avl = (total_quantity !== 0 && total_quantity >= current_quantity) ? 1 : 0;
//                 } else {
//                     const recArr1 = await GroupComboProductsQty.findAll({
//                         attributes: [
//                             [sequelize.col('ip.product_name'), 'product_name'],
//                             [sequelize.fn('SUM', sequelize.col('main_invt_group_combo_product_qtys.qty')), 'qty'],
//                             [sequelize.col('miq.qty'), 'total_qty']
//                         ],
//                         include: [
//                             {
//                                 model: InvtProduct,
//                                 as: 'ip',
//                                 required: false,
//                                 attributes: []
//                             },
//                             {
//                                 model: InvtQty,
//                                 as: 'miq',
//                                 required: false,
//                                 attributes: []
//                             }
//                         ],
//                         where: {
//                             invt_group_combo_product_id: invt_group_combo_product_id
//                         },
//                         group: ['main_invt_group_combo_product_qtys.invt_product_id']
//                     });
//                     if (recArr1) {
//                         for (const vall of recArr1) {
//                             if (vall.dataValues.total_qty !== 0 && vall.dataValues.total_qty >= vall.dataValues.qty) {
//                                 is_invt_avl = 1;
//                             } else {
//                                 is_invt_avl = 0;
//                                 break;
//                             }
//                         }
//                     }
//                 }
//             // end inventory product
//         if (!products){
//             res.status(202).send({
//                 message:process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         }else{
//             res.status(200).send({
//                 message:process.env.SUCCESS_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 color_img_path:process.env.SITE_URL+'uploads/color_image/',
//                 path:process.env.SITE_URL+'uploads/products/',
//                 rating:ratings,
//                 is_wishlist:is_wishlist,
//                 is_review_count:is_review_count,
//                 data:products,
//                 primary_variant_detail:variantDetail,
//                 product_attribute:productAttribute,
//                 is_variant:is_variant,
//                 category:category,
//                 is_invt_avl:is_invt_avl,
//                 product_variant_group:product_variant_groups,
//                 product_primary_variant:product_primary_variant
//             });
//         }
//     } catch(error) {
//         res.status(500).send({
//             message:process.env.ERROR_MSG,
//             error: error.message,
//             success: false,
//             status: '0',
//         });
//     }
// }
//get products detail

const GetProductDetail = async (req, res) => {
    const user_id = req.body.user_id || 0;
    const slug = req.params.slug || 0;
    const attr_type_id = req.body.attr_type_id || 0;
    const attr_val_id = req.body.attr_val_id || 0;
    const attr_second_type_id = req.body.attr_second_type_id || 0;
    const attr_second_val_id = req.body.attr_second_val_id || 0;

    try {
        const products = await Product.findOne({
            where: {
                product_slug: slug,
                status: '1',
                is_deleted: '0'
            },
            attributes: ['id', 'sku', 'product_name', 'product_slug', 'price', 'compare_price', 'category_id', 'stock_quantity', 'usd_price', 'usd_compare_price', ['product_tags', 'Feature'], 'pack_contain', 'description', 'additional_description', ['why_we_it', 'why_we_love_it'], 'shipping_return', 'dimension'
                , 'is_gift_option', 'gift_price', 'is_allow_cod', 'return_days_limit', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge'
                , 'product_buffer_days', 'description_class', 'additional_description_class', 'why_we_love_it_class', 'shipping_return_class', 'dimension_class', 'product_overview', 'product_overview_class', 'why_we_it_class', 'discount'
            ],
            include: [
                {
                    model: ProductType,
                    as: 'producttypes',
                    attributes: ['type_name'],
                    where: { status: '1' },
                    required: false
                },
                {
                    model: ProductMaterial,
                    as: 'productmaterials',
                    attributes: ['material_name'],
                    where: { status: '1' },
                    required: false
                },
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_type','file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    required: false,
                    // order: [['file_type', 'DESC']]
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: [[{ model: ProductMedia, as: 'productimages' }, 'sr_order', 'ASC']],
        });
        const product_id = products ? products['id'] : 0;

        const variantDetail = await ProductVariantGroup.findOne({
            where: { product_id: product_id },
            attributes: ['product_id', 'variant_id'],
            required: false,
            include: [
                {
                    model: Variant,
                    as: 'variants',
                    attributes: ['variant_title', 'attr_type_id'],
                    where: { status: '1' },
                    required: false,
                    include: [
                        {
                            model: ProductAttributeType,
                            as: 'variant_attr_type',
                            attributes: ['attr_type_name'],
                            where: { status: '1' },
                            required: false,
                        }
                    ]
                }
            ]
        });

        //product variant group
        const get_product_attr = await ProductAttributes.findAll({
            where: { product_id: product_id },
            attributes: ['id', 'attr_type_id', 'attr_val_id'],
        });

        const get_product_variant = await ProductVariantGroup.findOne({
            where: { product_id: product_id },
            attributes: ['id', 'variant_id'],
        });

        async function processAttribute(attr) {
            if ((attr.attr_second_val_id)) {

                // const prodByColor = await ProductAttributes.findAll({
                //     attributes:['product_id'],
                //     where:{
                //         attr_type_id:attr.attr_type_id,
                //         attr_val_id:attr.attr_val_id,
                //     }
                // });
                // const prIdArr = prodByColor.map(product => product ? product.product_id : null);

                const prodByColor1 = await ProductAttributes.findAll({
                    attributes: ['product_id'],
                    where: {
                        attr_type_id: attr_second_type_id,
                        attr_val_id: attr_second_val_id,
                    }
                });
                const prIdArr1 = prodByColor1.map(product => product ? product.product_id : null);
                var prIdd = prIdArr1;
                // var prIdd = prIdArr.filter(value => prIdArr1.includes(value));

            } else {
                const prodByColor = await ProductAttributes.findAll({
                    attributes: ['product_id'],
                    where: {
                        attr_type_id: attr.attr_type_id,
                        attr_val_id: attr.attr_val_id,
                    }
                });
                const prIdArr = prodByColor.map(product => product ? product.product_id : null);
                var prIdd = prIdArr;
            }

            const checkVeriant = await ProductVariantGroup.findAll({
                attributes: ['product_id'],
                where: {
                    variant_id: get_product_variant ? get_product_variant.variant_id : null,
                    product_id: { [Op.in]: prIdd }
                },
            });
            const checkprIdArr = checkVeriant.map(product => product ? product.product_id : null);

            const productColor = await ProductAttributes.findAll({
                where: { product_id: { [Op.in]: checkprIdArr }, attr_type_id: attr.attr_type_id, attr_val_id: attr.attr_val_id },
                attributes: ['attr_type_id', 'attr_val_id'],
                group: ['attr_val_id'],
                required: false,
                include: [
                    {
                        model: Product,
                        as: "products",
                        attributes: ['product_slug', 'sku'],
                        where: {
                            status: '1'
                        },
                    },
                    {
                        model: ProductAttributeValue,
                        as: 'product_attr_value',
                        attributes: ['attr_val_name', 'image'],
                        where: { status: '1' },
                        required: false,
                    }
                ]
            });


            const checkVeriant1 = await ProductVariantGroup.findAll({
                attributes: ['product_id'],
                where: {
                    variant_id: get_product_variant ? get_product_variant.variant_id : null,
                    product_id: { [Op.in]: prIdd }
                },
            });

            const checkprIdArr1 = checkVeriant1.map(product => product ? product.product_id : null);

            const productAllVariant = await ProductAttributes.findAll({
                where: { product_id: { [Op.in]: checkprIdArr1 }, attr_type_id: attr.attr_type_id },
                attributes: ['attr_type_id', 'attr_val_id'],
                group: ['attr_val_id'],
                required: false,
                include: [
                    {
                        model: Product,
                        as: "products",
                        attributes: ['product_slug', 'sku'],
                        where: {
                            status: '1'
                        },
                    },
                    {
                        model: ProductAttributeValue,
                        as: 'product_attr_value',
                        attributes: ['attr_val_name', 'image'],
                        where: { status: '1' },
                        required: false,
                    }
                ]
            });


            return {
                id: attr.id,
                attr_type_id: attr.attr_type_id,
                attr_val_id: attr.attr_val_id,
                variant_id: get_product_variant ? get_product_variant.variant_id : null,
                products_by_attr: { data: productColor, alldata: productAllVariant },
            };
        }

        const product_variant_groups = await Promise.all(get_product_attr.map(processAttribute))

        //primary variant group
        async function primaryprocessAttribute(attr) {
            const primaryvariantGroup = await ProductVariantGroup.findOne({
                where: { product_id: product_id },
                attributes: ['product_id', 'variant_id'],
                required: false,
                include: [
                    {
                        model: Variant,
                        as: 'variants',
                        attributes: ['variant_title', 'attr_type_id'],
                        where: { status: '1' },
                        required: false,
                        include: [
                            {
                                model: ProductAttributeType,
                                as: 'variant_attr_type',
                                attributes: ['attr_type_name'],
                                where: { status: '1' },
                                required: false,
                            }
                        ]
                    }
                ]
            });
            const primaryvariantId = primaryvariantGroup ? primaryvariantGroup['variant_id'] : 0;

            const primarygroupAll = await ProductVariantGroup.findAll({
                where: {
                    variant_id: primaryvariantId,
                },
                attributes: ['product_id']
            });
            const primaryprIdArr = primarygroupAll.map(product => product ? product.product_id : null);


            const primaryproductColor = await ProductAttributes.findAll({
                where: { product_id: { [Op.in]: primaryprIdArr }, attr_type_id: attr.attr_type_id },
                attributes: ['attr_type_id', 'attr_val_id'],
                group: ['attr_val_id'],
                required: false,
                include: [
                    {
                        model: Product,
                        as: "products",
                        attributes: ['product_slug'],
                        where: {
                            status: '1'
                        },
                    },
                    {
                        model: ProductAttributeValue,
                        as: 'product_attr_value',
                        attributes: ['attr_val_name', 'image'],
                        where: { status: '1' },
                        required: false,
                    }
                ]
            });
            return { primary_variant_detail: primaryvariantGroup, primary_data: primaryproductColor }
        }


        const product_primary_variant = await Promise.all(get_product_attr.map(primaryprocessAttribute))



        const productAttribute = await ProductAttributes.findAll({
            where: { product_id: product_id },
            attributes: ['id', 'product_id', 'attr_type_id', 'attr_val_id'],
            required: false,
            include: [
                {
                    model: ProductAttributeType,
                    as: 'product_attr_type',
                    attributes: ['id', 'attr_type_name'],
                    where: { status: '1' },
                    required: false,
                },
                {
                    model: ProductAttributeValue,
                    as: 'product_attr_value',
                    attributes: ['id', 'attr_val_name', 'slug', 'image'],
                    where: { status: '1' },
                    required: false,
                }
            ]
        });




        var variantGroup = await ProductVariantGroup.findOne({ where: { product_id: product_id }, attributes: ['id'] });
        if (variantGroup) {
            var is_variant = 1;
        } else {
            var is_variant = 0;
        }

        const ratings = await Review.findOne({
            order: [['user_id', 'DESC']],
            where: {
                status: '1',
                product_id: product_id
            },
            attributes: [[sequelize.fn('AVG', sequelize.col('rating')), 'StarRating'], [sequelize.fn('COUNT', sequelize.col('user_id')), 'Rating']]
        });

        var uId = user_id || 0;
        var isWishlists = await Wishlist.findOne({ where: { product_id: product_id, user_id: uId }, attributes: ['id'] });
        if (isWishlists) {
            var is_wishlist = 1;
        } else {
            var is_wishlist = 0;
        }

        var review = await Review.findOne({ where: { product_id: product_id, user_id: uId }, attributes: ['id'] });
        if (review) {
            var is_review_count = 1;
        } else {
            var is_review_count = 0;
        }

        const catIdArr = products ? products['category_id'].split(',').map(Number) : [];

        var category = await Category.findAll({
            where: {
                id: { [Op.in]: catIdArr },
                status: '1'
            },
            attributes: ['id', 'slug', 'name']
        });

        if (user_id) {
            const userProductView = await UserProductView.findOne({
                where: {
                    user_id: user_id,
                    product_id: product_id,
                },
                attributes: ['id'],
            });
            if (userProductView) {
                await UserProductView.update({
                    created_at: getCurrentDateTime(),
                }, {
                    where: {
                        user_id: user_id,
                        product_id: product_id,
                    }
                });
            } else {
                await UserProductView.create({
                    user_id: user_id,
                    product_id: product_id,
                });
            }
        }

        if (products) {
            var isNotify = await ProductNotifyModel.findOne({ where: { product_id: product_id, user_id: uId }, attributes: ['id'] });
            products.dataValues.is_notify = isNotify ? 1 : 0;
        }
        // inventory product start
        var product_sku = products ? products.sku : '';
        const cQuantity = await SiteSellerProducts.findOne({
            attributes: [
                'quantity',
                [sequelize.col('migcp.invt_group_combo_product_id'), 'invt_group_combo_product_id'],
                [sequelize.col('migcp.strpd_product_id'), 'group_strpd_id']
            ],
            include: [
                {
                    model: RelInvtStrpdProduct,
                    as: 'irsp',
                    required: false,
                    include: [
                        {
                            model: InvtQty,
                            as: 'miq',
                            required: false,
                            attributes: [['qty', 'total_quantity']]
                        }
                    ]
                },
                {
                    model: GroupComboProducts,
                    as: 'migcp',
                    required: false,
                    attributes: []
                }
            ],
            where: {
                sku: product_sku,
                product_id: product_id
            }
        });

        const current_quantity = cQuantity ? cQuantity.quantity : 0;
        const total_quantity = cQuantity && cQuantity.irsp && cQuantity.irsp.miq ? cQuantity.irsp.miq.dataValues.total_quantity : 0;
        const invt_group_combo_product_id = cQuantity ? cQuantity.dataValues.invt_group_combo_product_id : 0;
        const group_strpd_id = cQuantity ? cQuantity.dataValues.group_strpd_id : 0;

        let invt_type;
        if (group_strpd_id) {
            invt_type = 'invt_group_product';
        } else {
            invt_type = 'invt_product';
        }

        let is_invt_avl = 0;
        if (invt_type === 'invt_product') {
            is_invt_avl = (total_quantity !== 0 && total_quantity >= current_quantity) ? 1 : 0;
        } else {
            const recArr1 = await GroupComboProductsQty.findAll({
                attributes: [
                    [sequelize.col('ip.product_name'), 'product_name'],
                    [sequelize.fn('SUM', sequelize.col('main_invt_group_combo_product_qtys.qty')), 'qty'],
                    [sequelize.col('miq.qty'), 'total_qty']
                ],
                include: [
                    {
                        model: InvtProduct,
                        as: 'ip',
                        required: false,
                        attributes: []
                    },
                    {
                        model: InvtQty,
                        as: 'miq',
                        required: false,
                        attributes: []
                    }
                ],
                where: {
                    invt_group_combo_product_id: invt_group_combo_product_id
                },
                group: ['main_invt_group_combo_product_qtys.invt_product_id']
            });
            if (recArr1) {
                for (const vall of recArr1) {
                    if (vall.dataValues.total_qty !== 0 && vall.dataValues.total_qty >= vall.dataValues.qty) {
                        is_invt_avl = 1;
                    } else {
                        is_invt_avl = 0;
                        break;
                    }
                }
            }
        }
        // end inventory product
        if (!products) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                color_img_path: process.env.SITE_URL + 'uploads/color_image/',
                path: process.env.SITE_URL + 'uploads/products/',
                path_thumbnails_video: process.env.SITE_URL + 'uploads/products_video/thumbnails/',
                path_video: process.env.SITE_URL + 'uploads/products_video/',
                rating: ratings,
                is_wishlist: is_wishlist,
                is_review_count: is_review_count,
                data: products,
                primary_variant_detail: variantDetail,
                product_attribute: productAttribute,
                is_variant: is_variant,
                category: category,
                is_invt_avl: is_invt_avl,
                product_variant_group: product_variant_groups,
                product_primary_variant: product_primary_variant,

            });

        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}

async function getSubcategoriesRecursive(parentId) {
    const subcategories = await NavigationMenu.findAll({
        where: {
            type: 3,
            parent_id: parentId
        },
        attributes: ['id', 'menu_id']
    });

    let subcategoryIds = [];
    for (let subcategory of subcategories) {
        subcategoryIds.push(subcategory.menu_id);
        // Recursively find subcategories of the current subcategory
        const childIds = await getSubcategoriesRecursive(subcategory.id);
        subcategoryIds = subcategoryIds.concat(childIds);
    }
    return subcategoryIds;
}

async function findAllParentAndChildCategoryIds(parentCategoryIds) {
    let allCategoryIds = [];

    async function findChildAndSubChildIds(parentIds) {
        // Find direct child categories
        const childCategories = await NavigationMenu.findAll({
            where: {
                parent_id: { [Op.in]: parentIds },
                type: 3
            },
            attributes: ['id', 'menu_id']
        });

        if (childCategories.length === 0) {
            return [];
        }

        let categoryIds = [];
        for (let category of childCategories) {
            categoryIds.push(category.menu_id);
            // Recursively find sub-child categories
            const subChildIds = await findChildAndSubChildIds([category.id]);
            categoryIds = categoryIds.concat(subChildIds);
        }
        return categoryIds;
    }

    // Find child and sub-child categories for each parent category
    for (let parentId of parentCategoryIds) {
        // Find the menu_id corresponding to the parentId
        const parentCategory = await NavigationMenu.findOne({
            where: {
                id: parentId
            },
            attributes: ['menu_id']
        });
        if (parentCategory) {
            // Include menu_id in the result
            allCategoryIds.push(parentCategory.menu_id);
            const parentCategoryIds = await findChildAndSubChildIds([parentId]);
            allCategoryIds = allCategoryIds.concat(parentCategoryIds);
        }
    }

    return allCategoryIds;
}

//get category detail
const GetCategoryDetail = async (req, res) => {
    const slug = req.params.slug;
    const user_id = req.body.user_id || 0;
    try {
        var categories = await NavigationMenu.findOne({
            where: {
                slug: slug,
                type: 3
            },
            attributes: ['id', 'menu_id'],
            include: [
                {
                    model: Category,
                    as: 'categories',
                    attributes: ['id', 'slug', 'name', 'description', 'image'],
                    required: false,
                    include: [
                        {
                            model: AssignPageSlider,
                            as: 'assign_slider',
                            attributes: ['page_slider_id'],
                            required: false,
                            where: { type: '2' },
                            include: [
                                {
                                    model: PageSlider,
                                    as: 'page_slider',
                                    attributes: ['id', 'title'],
                                    required: false,
                                    include: [
                                        {
                                            model: PageSliderImages,
                                            as: 'page_slider_images',
                                            attributes: ['id', 'image_title', 'button_link', 'description', 'inner_description', 'image'],
                                            required: false,
                                        },
                                    ],
                                },
                            ],
                        }
                    ],
                }
            ],
        });
        if (categories) {
            const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
            var catIds = [categories['menu_id']].concat(subcategoryIds);
        } else {
            var catIds = [];
        }
        var pcondi = {
            //category_id: { [Op.in]: catIds },
            //[Op.or]: catIds.map(catId => ({ category_id: { [Op.like]: `${catId}` } })),
            [Op.or]: catIds.map(catId => ({
                [Op.or]: [
                    { category_id: catId.toString() }, // Check for the exact value
                    //{ category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
                    { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
                    { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
                ]
            })),
            status: '1',
            is_deleted: '0',
        };
        const products = await Product.findAll({
            order: [['stock_quantity', 'DESC']],
            where: pcondi,
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['is_default', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                    order: [['is_default', 'DESC']]
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
        });

        const maxpriceproducts = await Product.findOne({
            where: pcondi,
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ]
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }

        if (!categories) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                category_path: process.env.SITE_URL + 'uploads/category/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                product_path: process.env.SITE_URL + 'uploads/products/',
                max_price: maxpriceVal,
                category: categories,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

// const oldGetFilterProduct = async (req, res) => {
//     const slug = req.body.slug;
//     const category_id = req.body.category_id;
//     //const keyword = req.body.keyword;
//     const color_id = req.body.color_id;
//     const min_price = req.body.min_price;
//     const max_price = req.body.max_price;
//     const sorting = req.body.sorting;
//     const remove_stock = req.body.remove_stock;
//     const material_id = req.body.material_id;
//     const min_discount = req.body.min_discount;
//     const max_discount = req.body.max_discount;
//     const user_id = req.body.user_id || 0;
//     try {
//         var cateid = JSON.parse(category_id);
//         var clrid = JSON.parse(color_id);
//         var materialid = JSON.parse(material_id);
//         // var categories = await NavigationMenu.findOne({
//         //     where: {
//         //         slug:slug,
//         //         type:3
//         //     },
//         //     attributes:['id','menu_id'],
//         // });
//         // if(categories) {
//         //     const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
//         //     var catIds = [categories['menu_id']].concat(subcategoryIds);
//         // } else {
//         //     var catIds = [];
//         // }

//         var categories = await NavigationMenu.findOne({
//             where: {
//                 slug:slug,
//                 type:3
//             },
//             attributes:['id','menu_id'],
//             include: [
//                 {
//                     model: Category,
//                     as: 'categories',
//                     attributes:['id','slug','name','description','image'],
//                     required: false,
//                     include: [
//                         {
//                             model: AssignPageSlider,
//                             as: 'assign_slider',
//                             attributes: ['page_slider_id'],
//                             required: false,
//                             where: { type: '2' },
//                             include: [
//                                 {
//                                     model: PageSlider,
//                                     as: 'page_slider',
//                                     attributes: ['id','title'],
//                                     required: false,
//                                     include: [
//                                         {
//                                             model: PageSliderImages,
//                                             as: 'page_slider_images',
//                                             attributes: ['id','image_title','button_link','description','image'],
//                                             required: false,
//                                         },
//                                     ],
//                                 },
//                             ],
//                         }
//                     ],
//                 }
//             ],
//         });
//         if(categories) {
//             const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
//             var catIds = [categories['menu_id']].concat(subcategoryIds);
//         } else {
//             var catIds = [];
//         }

//         // const pvariant = await ProductVariant.findAll({
//         //     attributes:['product_id'],
//         //     where:{
//         //         color_id: { [Op.in]: clrid }
//         //     }
//         // });
//         const productAttribute = await ProductAttributes.findAll({
//             where:{attr_val_id: { [Op.in]: clrid },attr_type_id:2},
//             attributes: ['product_id'],
//             required: false,
//         });
//         var prIdArr = productAttribute.map(variant => variant.product_id);
//         var stockQuantity = (remove_stock == 1) ? {stock_quantity: {[sequelize.Op.gt]: 0}}: '';
//         //if (keyword == 0) {
//             if(cateid.length !== 0) {
//                 var catIdss = await findAllParentAndChildCategoryIds(cateid);
//                 if(prIdArr && prIdArr.length > 0) {
//                     var pcondi = {
//                         id: { [Op.in]: prIdArr },
//                         //category_id: { [Op.in]: cateid },
//                         [Op.or]: catIdss.map(catId => ({ [Op.or]: [
//                             { category_id: catId.toString() }, // Check for the exact value
//                             //{ category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
//                             { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
//                             { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
//                           ] })),
//                         status: '1',
//                         is_deleted: '0',
//                         ...stockQuantity
//                     };
//                 } else {
//                     var pcondi = {
//                         //category_id: { [Op.in]: cateid },
//                         [Op.or]: catIdss.map(catId => ({ [Op.or]: [
//                             { category_id: catId.toString() }, // Check for the exact value
//                             //{ category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
//                             { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
//                             { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
//                           ] })),
//                         status: '1',
//                         is_deleted: '0',
//                         ...stockQuantity
//                     };
//                 }
//             } else {
//                 if(prIdArr && prIdArr.length > 0) {
//                     var pcondi = {
//                         id: { [Op.in]: prIdArr },
//                         //category_id: { [Op.in]: catIds },
//                         [Op.or]: catIds.map(catId => ({ [Op.or]: [
//                             { category_id: catId.toString() }, // Check for the exact value
//                             //{ category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
//                             { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
//                             { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
//                           ]  })),
//                         status: '1',
//                         is_deleted: '0',
//                         ...stockQuantity
//                     };
//                 } else {
//                     var pcondi = {
//                         //category_id: { [Op.in]: catIds },
//                         [Op.or]: catIds.map(catId => ({ [Op.or]: [
//                             { category_id: catId.toString() }, // Check for the exact value
//                            // { category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
//                             { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
//                             { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
//                           ]  })),
//                         status: '1',
//                         is_deleted: '0',
//                         ...stockQuantity
//                     };
//                 }
//             }
//         // } else {
//         //     var pcondi = {
//         //         [Op.or]: [
//         //             { category_id: { [Op.in]: catIds } },
//         //             { product_name: { [Op.like]: `%${keyWords}%` } },
//         //             ],
//         //         status: '1',
//         //         is_deleted: '0'
//         //     };
//         // }

//         // Filter by price range
//         if (min_price || max_price) {
//             pcondi.price = {};
//             if (min_price) {
//                 pcondi.price[Op.gte] = min_price;
//             }
//             if (max_price) {
//                 pcondi.price[Op.lte] = max_price;
//             }
//         }

//         // Filter by discount if provided
//         if (min_discount || max_discount) {
//             pcondi.discount = {};
//             if (min_price) {
//                 pcondi.discount[Op.gte] = min_discount;
//             }
//             if (max_discount) {
//                 pcondi.discount[Op.lte] = max_discount;
//             }
//         }

//         // Filter by material ID if provided
//         if (materialid && materialid.length > 0) {
//             pcondi.material_id = { [Op.in]: materialid };
//         }

//         let sortBy = [['product_name', 'ASC']];
//         if (sorting == 'a-z') {
//             sortBy = [['product_name', 'ASC']];
//         } else if (sorting == 'z-a') {
//             sortBy = [['product_name', 'DESC']];
//         } else if (sorting == 'new_arrival') {
//             sortBy = [['is_home_new_arrival', 'DESC']];
//         } else if (sorting == 'low_to_high') {
//             sortBy = [['price', 'ASC']];
//         } else if (sorting == 'high_to_low') {
//             sortBy = [['price', 'DESC']];
//         }

//         const products = await Product.findAll({
//             where: pcondi,
//             attributes: [
//                 'id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge','discount','product_buffer_days',
//                 [sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_wishlist'],
//                 [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`),'is_notify']
//             ],
//             include: [
//                 {
//                     model: ProductMedia,
//                     as: 'productimages',
//                     attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
//                     limit: 2,
//                     required: false,
//                 },
//                 {
//                     model: Wishlist,
//                     as: 'wishlist',
//                     attributes: ['id'],
//                     where: { user_id: user_id },
//                     required: false,
//                 },
//                 {
//                     model: ProductNotifyModel,
//                     as: 'product_notify',
//                     attributes: ['id'],
//                     where: { user_id: user_id },
//                     required: false,
//                 }
//             ],
//             order: sortBy
//         });

//         if (!products){
//             res.status(202).send({
//                 message:process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         }else{
//             res.status(200).send({
//                 message:process.env.SUCCESS_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 category_path:process.env.SITE_URL+'uploads/category/',
//                 page_slider:process.env.SITE_URL+'uploads/page_slider/',
//                 product_path: process.env.SITE_URL+'uploads/products/',
//                 category:categories,
//                 data:products
//             });
//         }
//     } catch(error) {
//         res.status(500).send({
//             message:process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }
const GetFilterProduct = async (req, res) => {
    const slug = req.body.slug;
    const category_id = req.body.category_id;
    const keyword = req.body.keyword || 0;
    const menu_product = req.body.menu_product || 0;
    const color_id = req.body.color_id;
    const min_price = req.body.min_price;
    const max_price = req.body.max_price;
    const sorting = req.body.sorting;
    const remove_stock = req.body.remove_stock;
    const material_id = req.body.material_id;
    const min_discount = req.body.min_discount;
    const max_discount = req.body.max_discount;
    const user_id = req.body.user_id || 0;
    const type_id = req.body.type_id || 0;
    var stockQuantity = (remove_stock == 1) ? { stock_quantity: { [sequelize.Op.gt]: 0 } } : '';
    try {
        var cateid = JSON.parse(category_id);
        var clrid = JSON.parse(color_id);
        var materialid = JSON.parse(material_id);
        var typeId = JSON.parse(type_id);
        const colorData = await ProductAttributeValue.findOne({
            where: { slug: slug, prod_attr_type_id: 2 },
            attributes: ['id'],
            required: false,
        });
        const productAttribute = await ProductAttributes.findAll({
            where: { attr_val_id: { [Op.in]: clrid }, attr_type_id: 2 },
            attributes: ['product_id'],
            required: false,
        });
        var prIdArr = productAttribute.map(variant => variant.product_id);
        if (slug == 'newarrival') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                ...stockQuantity
                // stock_quantity: {
                //     [sequelize.Op.gt]: 0
                // }
            };
            var category_menu_id = 1;
        } else if (slug == 'bestseller') {
            var pcondi = {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0',
                ...stockQuantity
            };
            var category_menu_id = 4;
        } else if (slug == 'finestProduct') {
            var pcondi = {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
                ...stockQuantity
            };
            var category_menu_id = 3;
        } else if (slug == 'bigsavings') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                ...stockQuantity
            };
            var category_menu_id = 2;
        } else if (colorData) {
            const product_color_id = colorData ? colorData['id'] : 0;
            const attribute = await ProductAttributes.findAll({
                where: { attr_val_id: product_color_id, attr_type_id: 2 },
                attributes: ['product_id'],
                required: false,
            });
            var productAtt = attribute.map(variant => variant.product_id);

            var pcondi = {
                id: { [Op.in]: productAtt },
                status: '1',
                is_deleted: '0',
                ...stockQuantity
            };
            var category_menu_id = 5;
        } else if (slug == 'allProduct') {
            var pcondi = {
                product_name: { [Op.like]: `%${keyword}%` },
                status: '1',
                is_deleted: '0',
                ...stockQuantity
            };
            var category_menu_id = 5;
        } else {
            var category_menu_id = '';
            if (menu_product == 'menu_product') {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 1
                    },
                    attributes: ['id', 'menu_id'],
                    include: [
                        {
                            model: Category,
                            as: 'categories',
                            attributes: ['id', 'slug', 'name', 'description', 'image'],
                            required: false,
                            include: [
                                {
                                    model: AssignPageSlider,
                                    as: 'assign_slider',
                                    attributes: ['page_slider_id'],
                                    required: false,
                                    where: { type: '1' },
                                    include: [
                                        {
                                            model: PageSlider,
                                            as: 'page_slider',
                                            attributes: ['id', 'title'],
                                            required: false,
                                            include: [
                                                {
                                                    model: PageSliderImages,
                                                    as: 'page_slider_images',
                                                    attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                                                    required: false,
                                                },
                                            ],
                                        },
                                    ],
                                }
                            ],
                        }
                    ],
                });
            } else {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 3
                    },
                    attributes: ['id', 'menu_id'],
                    include: [
                        {
                            model: Category,
                            as: 'categories',
                            attributes: ['id', 'slug', 'name', 'description', 'image'],
                            required: false,
                            include: [
                                {
                                    model: AssignPageSlider,
                                    as: 'assign_slider',
                                    attributes: ['page_slider_id'],
                                    required: false,
                                    where: { type: '2' },
                                    include: [
                                        {
                                            model: PageSlider,
                                            as: 'page_slider',
                                            attributes: ['id', 'title'],
                                            required: false,
                                            include: [
                                                {
                                                    model: PageSliderImages,
                                                    as: 'page_slider_images',
                                                    attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                                                    required: false,
                                                },
                                            ],
                                        },
                                    ],
                                }
                            ],
                        }
                    ],
                });

            }
            if (categories) {
                const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
                var catIds = [categories['menu_id']].concat(subcategoryIds);
            } else {
                var catIds = [];
            }
            // const productAttribute = await ProductAttributes.findAll({
            //     where:{attr_val_id: { [Op.in]: clrid },attr_type_id:2},
            //     attributes: ['product_id'],
            //     required: false,
            // });
            // var prIdArr = productAttribute.map(variant => variant.product_id);
            // var stockQuantity = (remove_stock == 1) ? {stock_quantity: {[sequelize.Op.gt]: 0}}: '';
            //if (keyword == 0) {
            if (cateid.length !== 0) {
                var catIdss = await findAllParentAndChildCategoryIds(cateid);
                if (prIdArr && prIdArr.length > 0) {
                    var pcondi = {
                        id: { [Op.in]: prIdArr },
                        //category_id: { [Op.in]: cateid },
                        [Op.or]: catIdss.map(catId => ({
                            [Op.or]: [
                                { category_id: catId.toString() }, // Check for the exact value
                                //{ category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
                                { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
                                { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
                            ]
                        })),
                        status: '1',
                        is_deleted: '0',
                        ...stockQuantity
                    };
                } else {
                    var pcondi = {
                        //category_id: { [Op.in]: cateid },
                        [Op.or]: catIdss.map(catId => ({
                            [Op.or]: [
                                { category_id: catId.toString() }, // Check for the exact value
                                //{ category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
                                { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
                                { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
                            ]
                        })),
                        status: '1',
                        is_deleted: '0',
                        ...stockQuantity
                    };
                }
            } else {
                if (prIdArr && prIdArr.length > 0) {
                    var pcondi = {
                        id: { [Op.in]: prIdArr },
                        //category_id: { [Op.in]: catIds },
                        [Op.or]: catIds.map(catId => ({
                            [Op.or]: [
                                { category_id: catId.toString() }, // Check for the exact value
                                //{ category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
                                { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
                                { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
                            ]
                        })),
                        status: '1',
                        is_deleted: '0',
                        ...stockQuantity
                    };
                } else {
                    var pcondi = {
                        //category_id: { [Op.in]: catIds },
                        [Op.or]: catIds.map(catId => ({
                            [Op.or]: [
                                { category_id: catId.toString() }, // Check for the exact value
                                // { category_id: { [Op.like]: `%${catId},%` } }, // Check if the value is in a comma-separated list
                                { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
                                { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
                            ]
                        })),
                        status: '1',
                        is_deleted: '0',
                        ...stockQuantity
                    };
                }
            }
        }
        if ((prIdArr && prIdArr.length > 0) && (slug == 'newarrival' || slug == 'bestseller' || slug == 'finestProduct' || slug == 'bigsavings' || slug == 'allProduct')) {
            pcondi.id = { [Op.in]: prIdArr };
        }
        if ((category_menu_id != '') && (colorData != null || slug == 'newarrival' || slug == 'bestseller' || slug == 'finestProduct' || slug == 'bigsavings' || slug == 'allProduct')) {
            var categories = await AssignPageSlider.findOne({
                attributes: ['page_slider_id'],
                required: false,
                where: { type: '3', category_menu_id: category_menu_id },
                include: [
                    {
                        model: PageSlider,
                        as: 'page_slider',
                        attributes: ['id', 'title'],
                        required: false,
                        include: [
                            {
                                model: PageSliderImages,
                                as: 'page_slider_images',
                                attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                                required: false,
                            },
                        ],
                    },
                ],
            });
        }
        // Filter by price range
        if (min_price || max_price) {
            pcondi.price = {};
            if (min_price) {
                pcondi.price[Op.gte] = min_price;
            }
            if (max_price) {
                pcondi.price[Op.lte] = max_price;
            }
        }

        // Filter by discount if provided
        if (min_discount || max_discount) {
            pcondi.discount = {};
            if (min_price) {
                pcondi.discount[Op.gte] = min_discount;
            }
            // if (max_discount) {
            //     pcondi.discount[Op.lte] = max_discount;
            // }
        }

        // Filter by material ID if provided
        if (materialid && materialid.length > 0) {
            pcondi.material_id = { [Op.in]: materialid };
        }
        if (typeId && typeId.length > 0) {
            pcondi.type_id = { [Op.in]: typeId };
        }

        let sortBy = [['stock_quantity', 'DESC'], [sequelize.literal('TRIM(product_name)'), 'ASC']];
        if (sorting == 'a-z') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'ASC']];
        } else if (sorting == 'z-a') {
            sortBy = [[sequelize.literal('TRIM(product_name)'), 'DESC']];
        } else if (sorting == 'new_arrival') {
            sortBy = [['is_home_new_arrival', 'DESC']];
        } else if (sorting == 'low_to_high') {
            sortBy = [['price', 'ASC']];
        } else if (sorting == 'high_to_low') {
            sortBy = [['price', 'DESC']];
        }

        const products = await Product.findAll({
            where: pcondi,
            attributes: [
                'id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price',
                [sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_wishlist'],
                [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']
            ],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: sortBy
        });
        const maxpriceproducts = await Product.findOne({
            where: pcondi,
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ]
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }
        if (!products) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                category_path: process.env.SITE_URL + 'uploads/category/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                product_path: process.env.SITE_URL + 'uploads/products/',
                max_price: maxpriceVal,
                category: categories,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const GetSearchKeywordProduct = async (req, res) => {
    const keyword = req.body.keyword;
    const user_id = req.body.user_id || 0;
    try {

        var pcondi = {
            product_name: { [Op.like]: `%${keyword}` },
            status: '1',
            is_deleted: '0'
        };
        const products = await Product.findAll({
            where: pcondi,
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: [
                ['stock_quantity', 'DESC'],
            ]
        });

        if (user_id > 0) {
            const searchKeyword = await SearchKeywordTemplate.findAll({
                where: {
                    user_id: user_id,
                    product_title: keyword,
                    status: '1',
                },
                attributes: ['id', 'product_title'],
            });
            // if (searchKeyword.length < 1) {
            //     await SearchKeywordTemplate.create({
            //         user_id: user_id,
            //         product_title: keyword
            //     });
            // }
        }
        const maxpriceproducts = await Product.findOne({
            where: pcondi,
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ]
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }
        if (!products) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                product_path: process.env.SITE_URL + 'uploads/products/',
                max_price: maxpriceVal,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get category detail

//get product material
const OldGetMaterialList = async (req, res) => {
    const slug = req.body.slug;
    try {
        var categories = await NavigationMenu.findOne({
            where: {
                slug: slug,
                type: 3
            },
            attributes: ['id', 'menu_id']
        });
        if (categories) {
            const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
            var catIds = [categories['menu_id']].concat(subcategoryIds);
        } else {
            var catIds = [];
        }

        var pcondi = {
            [Op.or]: catIds.map(catId => ({
                [Op.or]: [
                    { category_id: catId.toString() },
                    { category_id: { [Op.like]: `%,${catId}` } },
                    { category_id: { [Op.like]: `${catId},%` } }
                ]
            })),
            status: '1',
            is_deleted: '0'
        };

        const products = await Product.findAll({
            where: pcondi,
            attributes: ['material_id']
        });
        const materialIdArr = products.map(product => product ? product.material_id : null);

        const materials = await ProductMaterial.findAll({
            where: {
                id: { [Op.in]: materialIdArr },
                status: '1'
            },
            attributes: ['id', 'material_name']
        });
        if (materials == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: materials
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const GetMaterialList = async (req, res) => {
    const slug = req.body.slug;
    const keyword = req.body.keyword || 0;
    const menu_product = req.body.menu_product || 0;
    try {
        const colorData = await ProductAttributeValue.findOne({
            where: { slug: slug, prod_attr_type_id: 2 },
            attributes: ['id'],
            required: false,
        });

        let CollectionMasterArray = [];
        let slugIdInMasterCollection = await HomeCollectionModel.findOne({
            where: { slug: slug, status: '1' },
            attributes: ['id', ['collection_name', 'name'], ['collection_image', 'image'], 'slug']
        })

        if (slug == 'newarrival') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                // stock_quantity: {
                //     [sequelize.Op.gt]: 0
                // }
            };

        } else if (slug == 'bestseller') {
            var pcondi = {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0'
            };
        } else if (slug == 'finestProduct') {
            var pcondi = {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
            };
        } else if (slug == 'bigsavings') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
            };

        } else if (slug == 'allProduct') {
            var pcondi = {
                product_name: { [Op.like]: `%${keyword}%` },
                status: '1',
                is_deleted: '0'
            };
        } else if (colorData) {

            const color_id = colorData ? colorData['id'] : 0;
            const productAttribute = await ProductAttributes.findAll({
                where: { attr_val_id: color_id, attr_type_id: 2 },
                attributes: ['product_id'],
                required: false,
            });

            var prIdArr = productAttribute.map(variant => variant.product_id);

            var pcondi = {
                id: { [Op.in]: prIdArr },
                status: '1',
                is_deleted: '0'
            };

        }else if (slugIdInMasterCollection) {
            slugIdInMasterCollection = slugIdInMasterCollection.toJSON();
            slugIdInMasterCollection.assign_slider = null
            const result = await CollectionAssignProductsModel.findAll({
                where: {
                    collection_id: slugIdInMasterCollection.id,
                    status: '1'
                },
                attributes: ['product_id'],
            });
            CollectionMasterArray = result.map(data => data.product_id);
    
            var pcondi = {
                id: {
                    [Op.in]: CollectionMasterArray.length > 0
                        ? CollectionMasterArray
                        : [0],
                },
                status: '1',
                is_deleted: '0'
            };
        } else {
            if (menu_product == 'menu_product') {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 1
                    },
                    attributes: ['id', 'menu_id']
                });
            } else {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 3
                    },
                    attributes: ['id', 'menu_id']
                });
            }
            if (categories) {
                const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
                var catIds = [categories['menu_id']].concat(subcategoryIds);
            } else {
                var catIds = [];
            }
            if (slug === 'offers') {
                var pcondi = {
                    status: '1',
                    is_deleted: '0',
                    discount: { [Op.gt]: 0 }
                };
            } else {
                var pcondi = {
                    [Op.or]: catIds.map(catId => ({
                        [Op.or]: [
                            { category_id: catId.toString() }, // Exact match
                            sequelize.literal(`FIND_IN_SET(${catId}, category_id) > 0`) // Match catId in a comma-separated list
                        ]
                    })),
                    status: '1',
                    is_deleted: '0'
                };
            }
        }

        var products = await Product.findAll({
            where: pcondi,
            attributes: ['material_id'],
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
        });
        const materialIdArr = products.map(product => product ? product.material_id : null);
        const materials = await ProductMaterial.findAll({
            where: {
                id: { [Op.in]: materialIdArr },
                status: '1'
            },
            attributes: ['id', 'material_name']
        });
        if (materials == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: materials
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get product material

//get product type
const GetTypeList = async (req, res) => {
    try {
        const types = await ProductType.findAll({
            where: {
                status: '1'
            },
            attributes: ['id', 'type_name']
        });
        if (types == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: types
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get product type

//get menu data
const GetMenuData = async (req, res) => {
    const menu_id = req.body.menu_id;
    const schema = Joi.object().keys({
        menu_id: Joi.number().integer().required().label("Menu")
    });
    const dataToValidate = {
        menu_id: menu_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const menus = await MenuCategory.findAll({
                attributes: ['category_id'],
                where: {
                    menu_id: menu_id
                }
            });
            if (menus == 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                    data: false
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: menus
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//get menu data

//get product you may like
const GetProductYouMayLike = async (req, res) => {
    const category_id = req.body.category_id;
    const user_id = req.body.user_id || 0;
    const schema = Joi.object().keys({
        category_id: Joi.number().integer().required().label("Category")
    });
    const dataToValidate = {
        category_id: category_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const likeableproducts = await Product.findAll({
                limit: 5,
                order: [['id', 'DESC']],
                where: {
                    category_id: category_id,
                    status: '1',
                    is_deleted: '0'
                },
                attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'image_alt', 'usd_price', 'usd_compare_price', [
                    // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                    sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                    'is_wishlist'
                ]],
                include: [
                    {
                        model: ProductMedia,
                        as: 'productimages',
                        attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                        where: {file_type:'image'},
                        limit: 2,
                        required: false,
                    },
                    {
                        model: Wishlist,
                        as: 'wishlist',
                        attributes: ['id'],
                        where: { user_id: user_id },
                        required: false,
                    },
                    {
                        model: SiteSellerProducts,
                        as: 'seller_product',
                        attributes: ['seller_id'],
                        where: { seller_id: 3 },
                        required: true,
                    }
                ],
            });
            if (likeableproducts == 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                    data: false
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    data: likeableproducts
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//get product you may like

//get blog
const GetBlog = async (req, res) => {
    try {
        const blogs = await Blog.findAll({
            limit: 3,
            order: [['id', 'DESC']],
            where: {
                status: '1'
            },
            attributes: ['id', 'slug', 'title', 'image', 'description'],
            include: [
                {
                    model: Category,
                    as: 'categories',
                    attributes: ['id', 'name', 'slug'],
                    required: false,
                    through: {
                        attributes: []
                    }
                },
            ],
        });
        if (blogs == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/blogs/',
                data: blogs
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get blog 

//get All blog
const GetAllBlog = async (req, res) => {
    try {
        const blogs = await Blog.findAll({
            order: [['id', 'DESC']],
            where: {
                status: '1',
            },
            attributes: ['id', 'slug', 'title', 'image', 'description', 'status'],
            include: [
                {
                    model: Category,
                    as: 'categories',
                    attributes: ['id', 'name', 'slug'],
                    required: false,
                    through: {
                        attributes: []
                    }
                },
            ],
        });

        if (blogs == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/blogs/',
                data: blogs
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            message_error: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get All blog 

//get blog detail
const GetBlogDetail = async (req, res) => {
    const slug = req.params.slug;
    try {
        const blogDetail = await Blog.findOne({
            where: {
                slug: slug,
                status: '1'
            },
            attributes: ['id', 'slug', 'title', 'image', 'description', 'created_at'],
            include: [
                {
                    model: Category,
                    as: 'categories',
                    attributes: ['id', 'name', 'slug'],
                    required: false,
                    through: {
                        attributes: []
                    }
                },
            ],
        });
        const plainBlogDetail = blogDetail.get({ plain: true });
        plainBlogDetail['created_at'] = moment(plainBlogDetail['created_at']).format("Do MMMM, YYYY");

        const latestBlogs = await Blog.findAll({
            order: [['id', 'DESC']],
            where: {
                status: '1',
            },
            attributes: ['id', 'slug', 'title', 'image', 'description', 'status'],
        });

        if (!plainBlogDetail) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/blogs/',
                data: plainBlogDetail,
                latestBlogs: latestBlogs
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get blog detail

//get trending products by category
const GetTrendingProductsByCategoryId = async (req, res) => {
    const category_id = req.body.category_id;
    const user_id = req.body.user_id || 0;
    const schema = Joi.object().keys({
        category_id: Joi.number().integer().required().label("Category")
    });
    const dataToValidate = {
        category_id: category_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const products = await Product.findAll({
                limit: 5,
                order: [['sold_out_count', 'DESC']],
                where: {
                    category_id: category_id,
                    status: '1',
                    is_deleted: '0'
                },
                attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'image_alt', 'usd_price', 'usd_compare_price', [
                    // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                    sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                    'is_wishlist'
                ]],
                include: [
                    {
                        model: ProductMedia,
                        as: 'productimages',
                        attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                        where: {file_type:'image'},
                        limit: 2,
                        required: false,
                    },
                    {
                        model: Wishlist,
                        as: 'wishlist',
                        attributes: ['id'],
                        where: { user_id: user_id },
                        required: false,
                    },
                    {
                        model: SiteSellerProducts,
                        as: 'seller_product',
                        attributes: ['seller_id'],
                        where: { seller_id: 3 },
                        required: true,
                    }
                ],
            });
            if (!products) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    data: products
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//get trending products by category

// get search auto product list start
const getSearchAutoProduct = async (req, res) => {
    const keyword = req.body.keyword;
    const user_id = req.body.user_id || 0;
    try {
        const products = await Product.findAll({
            where: {
                product_name: {
                    [Op.like]: `%${keyword}%`
                },
                status: '1',
                is_deleted: '0'
            },
            attributes: ['id', 'product_name', 'product_slug', 'stock_quantity', 'price', 'compare_price', 'stock_quantity', 'usd_price', 'usd_compare_price', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimage',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: { is_default: '1',file_type:'image'},
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: [
                ['stock_quantity', 'DESC'],
            ],
            group: ['id']
        });

        if (products == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get search auto product list end

//get user review rating start
const GetUserRaviewRating = async (req, res) => {
    try {
        const product_id = req.body.product_id;
        const user_id = req.body.user_id || 0;
        const reviewedByUser = await Review.findOne({
            where: {
                user_id: user_id,
                product_id: product_id
            }
        })
        const reviewRating = await Review.findAll({
            where: {
                product_id: product_id,
                status: "1",
            },
            attributes: ["id", "user_id", "product_id", "rating", "review", "image", "status", "created_at", "updated_at",
                [sequelize.literal("(SELECT COUNT(*) FROM strpd_product_review_likes AS review_like WHERE strpd_product_reviews.id = review_like.product_review_id)"), "review_like_count"],
                [sequelize.literal(`CASE WHEN product_review.id IS NOT NULL THEN TRUE ELSE FALSE END`), "is_review_like"],
            ],
            include: [
                {
                    model: User,
                    as: "user",
                    attributes: ["userfullname"],
                    required: false,
                },
                {
                    model: ProductReviewLike,
                    as: "product_review",
                    attributes: ["id"],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ReviewImages,
                    as: "review_images",
                    attributes: ["id", "image"],
                    required: false,
                },
            ],
            order: [
                ['id', 'DESC'],
            ]
        });

        if (reviewRating == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: "0",
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                path: process.env.DISPLAY_REVIEW_IMAGE,
                data: reviewRating,
                is_review: ((reviewedByUser ? '1' : '0'))
            });
        }
    } catch (error) {
        console.error('Error fetching user review:', error);
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: "0",
        });
    }
}
//get review rating end

//add review rating start
const product_review_file_storage = multer.diskStorage({
    destination: async (req, file, cb) => {
        const uploadPath = process.env.PRODUCT_REVIEW_IMAGE;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + extension);
    },
});
//storage end

//add product start
const upload_review = multer({ storage: product_review_file_storage });


const AddReviewRating = async (req, res) => {
    const user_id = req.userId;
    const product_id = req.body.product_id;
    const rating = req.body.rating;
    const review = req.body.review;
    const current_date = new Date();

    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product"),
        rating: Joi.number().precision(1).required().label("Rating"),
    });
    const dataToValidate = {
        product_id: product_id,
        rating: rating,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(403).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    }

    try {
        const reviewExists = await Review.findOne({
            where: {
                user_id: req.userId,
                product_id: req.body.product_id
            }
        });

        if (reviewExists) {
            return res.status(400).send({
                message: "Review Already Exists",
                status: '0',
                success: false,
                error: true,
            });
        }

        const files = req.files && req.files.file
            ? Array.isArray(req.files.file)
                ? req.files.file
                : [req.files.file]
            : [];
        if (files.length > 5) {
            return res.status(403).send({
                message: "You can only upload a maximum of 5 images.",
                status: '0',
                success: false,
                error: true,
            });
        }
        const allowedExtensions = ['jpg', 'jpeg', 'png'];
        for (const file of files) {
            const fileExtension = file.name.split('.').pop().toLowerCase();
            if (!allowedExtensions.includes(fileExtension)) {
                return res.status(400).send({
                    message: `Only ${allowedExtensions.join(", ")} formats are allowed.`,
                    status: '0',
                    success: false,
                    error: true,
                });
            }
        }

        const batchSize = 20;
        let insertObj = {
            user_id: user_id,
            product_id: product_id,
            rating: rating,
            review: review,
            created_at: getCurrentDateTime(),
            created_by: user_id,
        };
        var reviewRating = await Review.create(insertObj);

        if (files.length > 0) {
            for (let i = 0; i < files.length; i += batchSize) {
                const batch = files.slice(i, i + batchSize);
                const batchData = [];

                for (const file of batch) {
                    const directoryPath = process.env.PRODUCT_REVIEW_IMAGE || './uploads/reviews';
                    if (!fs.existsSync(directoryPath)) {
                        fs.mkdirSync(directoryPath, { recursive: true });
                    }

                    const filePath = path.join(directoryPath, file.name);

                    try {
                        await file.mv(filePath);
                    } catch (err) {
                        console.error("File save error:", err.message);
                        return res.status(500).send({
                            message: "Failed to save file.",
                            error: true,
                            success: false,
                            status: '0',
                            details: err.message
                        });
                    }

                    batchData.push({
                        product_review_id: reviewRating.id,
                        image: file.name,
                        created_at: current_date,
                        created_by: req.userId,
                    });
                }

                await ReviewImages.bulkCreate(batchData);
            }
        }

        const userReview = await Review.findOne({
            where: {
                id: reviewRating.id,
                user_id: user_id,
                status: "1",
            },
            attributes: ["id", "user_id", "product_id", "rating", "review", "image"],
            include: [
                {
                    model: User,
                    as: "user",
                    attributes: ["firstname"],
                    required: false,
                },
                {
                    model: ReviewImages,
                    as: "review_images",
                    attributes: ["id", "image"],
                    required: false,
                },
            ],
        });

        if (userReview) {
            res.status(200).send({
                message: "Review saved successfully.",
                userReview: userReview,
                error: false,
                success: true,
                status: '1'
            });
        }

    } catch (error) {

        res.status(500).send({
            message: process.env.ERROR_MSG,
            msg: error.message,
            error: true,
            success: false,
            status: "0",
        });
    }
};


//add review rating end

//get user review rating detail
const GetUserReviewRatingDetail = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    try {
        const userReview = await Review.findOne({
            where: {
                id: id,
                user_id: user_id,
                status: "1",
            },
            attributes: ["id", "user_id", "product_id", "rating", "review", "image"],
            include: [
                {
                    model: User,
                    as: "user",
                    attributes: ["firstname"],
                    required: false,
                },
                {
                    model: ReviewImages,
                    as: "review_images",
                    attributes: ["id", "image"],
                    required: false,
                },
            ],
        });

        if (!userReview) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: "0",
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                path: process.env.DISPLAY_REVIEW_IMAGE,
                data: userReview,
            });
        }
    } catch (error) {
        console.error('Error fetching user review:', error);
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: "0",
        });
    }
}
//get user review rating detail

const EditReviewRating = async (req, res) => {
    const id = req.body.id;
    const user_id = req.userId;
    const rating = req.body.rating;
    const review = req.body.review;
    const old_image_id = req.body.old_image_id;

    const schema = Joi.object().keys({
        id: Joi.number().integer().required().label("Review Id"),
        rating: Joi.number().precision(1).required().label("Rating"),
    });
    const dataToValidate = {
        id: id,
        rating: rating,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(403).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    }

    try {
        const oldImageId = JSON.parse(old_image_id);
        const existingReview = await Review.findOne({
            where: { id: id },
        });

        let reviewRating;
        if (existingReview) {
            const existingReviewDelete = await ReviewImages.findAll({
                where: {
                    id: { [Op.in]: oldImageId },
                    product_review_id: id,
                }
            });
            if (existingReviewDelete.review_images && existingReviewDelete.review_images.length > 0) {
                for (const oldImage of existingReviewDelete.review_images) {
                    const oldImagePath = path.join(process.env.PRODUCT_REVIEW_IMAGE || './uploads/reviews', oldImage.image);
                    if (fs.existsSync(oldImagePath)) {
                        fs.unlinkSync(oldImagePath); // Delete the file
                    }
                }
            }
            if (oldImageId.length > 0) {
                await ReviewImages.destroy({
                    where: {
                        id: { [Op.in]: oldImageId },
                        product_review_id: id,
                    }
                });
            }
            // Update the existing review
            await existingReview.update({
                rating: rating,
                review: review,
                updated_at: current_date,
                updated_by: user_id,
            });
            reviewRating = existingReview;
        }


        const files = req.files && req.files.file ? (Array.isArray(req.files.file) ? req.files.file : [req.files.file]) : [];

        const existingReviewImage = await ReviewImages.count({
            where: {
                product_review_id: id,
            }
        });
        var totalImage = existingReviewImage + files.length;
        if (totalImage > 5) {
            return res.status(403).send({
                message: "You can only upload a maximum of 5 images.",
                status: '0',
                success: false,
                error: true,
            });
        }
        const allowedExtensions = ['jpg', 'jpeg', 'png'];
        for (const file of files) {
            const fileExtension = file.name.split('.').pop().toLowerCase();
            if (!allowedExtensions.includes(fileExtension)) {
                return res.status(400).send({
                    message: `Only ${allowedExtensions.join(", ")} formats are allowed.`,
                    status: '0',
                    success: false,
                    error: true,
                });
            }
        }
        const batchSize = 20;
        if (files.length > 0) {
            for (let i = 0; i < files.length; i += batchSize) {
                const batch = files.slice(i, i + batchSize);
                const batchData = [];

                for (const file of batch) {
                    const directoryPath = process.env.PRODUCT_REVIEW_IMAGE || './uploads/reviews';
                    if (!fs.existsSync(directoryPath)) {
                        fs.mkdirSync(directoryPath, { recursive: true });
                    }

                    const filePath = path.join(directoryPath, file.name);

                    // Save the file with the full path
                    try {
                        await file.mv(filePath);
                    } catch (err) {
                        console.error("File save error:", err.message);
                        return res.status(500).send({
                            message: "Failed to save file.",
                            error: true,
                            success: false,
                            status: '0',
                            details: err.message,
                        });
                    }

                    batchData.push({
                        product_review_id: id,
                        image: file.name,
                        created_at: current_date,
                        created_by: user_id,
                    });
                }

                // Insert batch data into the database
                await ReviewImages.bulkCreate(batchData);
            }
        }

        const userReview = await Review.findOne({
            where: {
                id: id,
                user_id: user_id,
                status: "1",
            },
            attributes: ["id", "user_id", "product_id", "rating", "review", "image"],
            include: [
                {
                    model: User,
                    as: "user",
                    attributes: ["firstname"],
                    required: false,
                },
                {
                    model: ReviewImages,
                    as: "review_images",
                    attributes: ["id", "image"],
                    required: false,
                },
            ],
        });
        if (userReview) {
            res.status(200).send({
                message: "Review update successfully.",
                userReview: userReview,
                error: false,
                success: true,
                status: '1',
            });
        }

    } catch (error) {
        console.error("Error:", error.message);
        res.status(500).send({
            message: process.env.ERROR_MSG || "Internal server error",
            msg: error.message,
            error: true,
            success: false,
            status: "0",
        });
    }
};
//edit user rating end


const PayPayment = async (req, res) => {

    const user_id = req.userId;
    const transaction_id = req.body.transaction_id;
    // const payment_type = req.body.payment_type;
    // const currency = req.body.currency;
    const address_id = req.body.address_id;
    const buy_now_product = req.body.buy_now || 'cart';
    const schema = Joi.object().keys({
        // payment_type:  Joi.number().integer().required().label("Type"),
        // currency:Joi.string().required().label("Currency"),
        address_id: Joi.number().integer().required().label("Address Id"),
    });
    const dataToValidate = {
        // payment_type:payment_type,
        // currency:currency,
        address_id: address_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const buy_now = await BuyNow.findAll({
                where: {
                    user_id: user_id,
                    status: 1
                },
                attributes: ['id', 'user_id', 'product_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount'],
                include: [
                    {
                        model: Product,
                        as: 'product',
                        attributes: ['id', 'product_name', 'stock_quantity', 'is_shipping', 'shipping_amount_type', 'shipping_charge'],
                        required: false,
                    }
                ]
            });
            if (buy_now.length > 0 && buy_now_product == 'buy_now') {
                var carts = buy_now;
            } else {
                var carts = await Cart.findAll({
                    where: {
                        user_id: user_id,
                        status: 1
                    },
                    attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount'],
                    include: [
                        {
                            model: Product,
                            as: 'product',
                            attributes: ['id', 'product_name', 'stock_quantity', 'is_shipping', 'shipping_amount_type', 'shipping_charge'],
                            required: false,
                        }
                    ]
                });
            }
            if(carts.length == 0){
                return res.status(404).json({
                    message: 'Record not found',
                    error: true,
                    success: false,
                    status: '0',
                  });
            }
            var stock_quantity_availability = [];

            let subtotal_amount = 0;
            let shipping_amt = 0;
            let product_discount = 0;
            if (carts) {
                for (const cart of carts) {
                    if (cart.product) {
                        var currency = cart.currency_code
                        subtotal_amount += parseFloat(cart.subtotal_amount);
                        product_discount += parseFloat(cart.discount_amt);
                        var shipping_amount_type = cart.product.shipping_amount_type;
                        if (shipping_amount_type == 1) {
                            shipping_amt += parseFloat(cart.product.shipping_charge);
                        } else if (shipping_amount_type == 2) {
                            shipping_amt += parseFloat(cart.subtotal_amount) * parseFloat(cart.product.shipping_charge) / 100;
                        }

                        var cartqty = cart.quantity;
                        const prqty = cart.product.stock_quantity ? cart.product.stock_quantity : 0;
                        if (prqty < cartqty) {
                            stock_quantity_availability.push(cart.product.product_name);
                        }
                    }
                }
            }

            if (buy_now.length > 0 && buy_now_product == 'buy_now') {
                var order_discount = 0;
                var order_discount_id = 0;
            } else {
                const orderdiscount = await OrderDiscountCoupon.findOne({
                    where: {
                        user_id: user_id,
                        applied_status: 1,
                        discount_type: 'order',
                        discount_mode: buy_now_product
                    },
                    attributes: ['discount_id', 'discount_amt']
                });
                var order_discount = orderdiscount ? parseFloat(orderdiscount.discount_amt) : 0;
                var order_discount_id = orderdiscount ? orderdiscount.discount_id : 0;
            }

            const forderdiscount = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: user_id,
                    applied_status: 1,
                    discount_type: 'first_order',
                    discount_mode: buy_now_product
                },
                attributes: ['discount_id', 'discount_amt']
            });
            var first_order_discount = forderdiscount ? parseFloat(forderdiscount.discount_amt) : 0;
            var first_order_discount_id = forderdiscount ? forderdiscount.discount_id : 0;

            const rewarddiscount = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: user_id,
                    applied_status: 1,
                    discount_type: 'reward',
                    discount_mode: buy_now_product
                },
                attributes: ['discount_amt']
            });
            var reward_discount = rewarddiscount ? parseFloat(rewarddiscount.discount_amt) : 0;

            var reward_point = 0;
            if (reward_discount > 0) {
                const checkRewardPoint = await RewardPointWallet.findOne({
                    attributes: ['id', 'total_points'],
                    where: {
                        user_id: user_id
                    }
                });
                var reward_point = checkRewardPoint ? checkRewardPoint.total_points : 0;
            }

            // add multiple order discount
            const result = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: user_id,
                    discount_type: 'order',
                    discount_mode: buy_now_product
                },
                attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
                raw: true // Ensures you get a plain object rather than an instance of the model
            });

            let ord_discount = result.total_subtotal_amount ? parseFloat(result.total_subtotal_amount) : 0;

            //end
            var total_discountt = ord_discount + first_order_discount + reward_discount + product_discount;

            var total_amtt = subtotal_amount - total_discountt;

            const setting = await Setting.findOne({
                attributes: ['max_shipping_amount','shipping_amount']
              });
            var max_shipping_amount = setting ? parseFloat(setting.max_shipping_amount) : 0;
            if (max_shipping_amount > total_amtt) {
                var shipping_charge = setting.shipping_amount;
                // var shipping_charge = parseFloat(shipping_amt);
            } else {
                var shipping_charge = 0;
            }
            var total_amt = total_amtt + shipping_charge;

            var stock_quantity_msg = '';
            if (stock_quantity_availability.length > 0) {
                var stock_quantity_msg = stock_quantity_availability.join(', ') + ' Out of stock';
                return res.status(202).send({
                    message: stock_quantity_msg,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                // get user address
                const userAddress = await UserAddress.findOne({
                    where: {
                        id: address_id,
                        status: '1'
                    },
                    attributes: ['id', 'user_id', 'name', 'title', 'apartment', 'land_mark', 'address', 'mobile_number', 'zip_code', 'country_id', 'state_id', 'city_id', 'is_default', 'gst_number', 'billing_name', 'billing_phone', 'billing_address', 'billing_pincode', 'company_name', 'company_address'],
                    include: [
                        {
                            model: User,
                            as: 'user',
                            attributes: ['firstname', 'lastname', 'userfullname', 'email'],
                            required: false
                        },
                        {
                            model: Country,
                            as: 'country',
                            attributes: ['country_name'],
                            required: false
                        },
                        {
                            model: State,
                            as: 'state',
                            attributes: ['state_name'],
                            required: false
                        },
                        {
                            model: City,
                            as: 'city',
                            attributes: ['city_name'],
                            required: false
                        },
                        {
                            model: Country,
                            as: 'billing_country',
                            attributes: ['country_name'],
                            required: false
                        },
                        {
                            model: State,
                            as: 'billing_state',
                            attributes: ['state_name'],
                            required: false
                        },
                        {
                            model: City,
                            as: 'billing_city',
                            attributes: ['city_name'],
                            required: false
                        }
                    ]
                });
                const discount = ord_discount;
                const f_order_discount = first_order_discount;
                const subTotal = subtotal_amount;

                const orderdiscount = await OrderDiscountCoupon.findAll({
                    where: {
                        user_id: user_id,
                        discount_type: 'order'
                    },
                    attributes: ['discount_amt', 'discount_id'],
                    // update by suresh multiple discount id  date 23-oct-2024
                    include: [
                        {
                            model: Coupon,
                            as: 'applied_coupon_code',
                            attributes: ['id', 'coupon_code'],
                            required: false,
                        }
                    ],

                });
                const discountIdString = orderdiscount.map(item => item?.applied_coupon_code?.id);
                const discountIdArray = discountIdString.join(',');
                //end
                const orders = await Order.create({
                    address_id: address_id,
                    user_id: user_id,
                    transaction_id: transaction_id,
                    total_amount: subTotal,
                    discount_amt: discount,
                    first_order_discount_amt: f_order_discount,
                    reward_amt: reward_discount,
                    shipping_amt: shipping_charge,
                    tax_amt: 0,
                    paid_amount: total_amt,
                    payment_type: 2,
                    currency: currency,
                    discount_id: discountIdArray ? discountIdArray : null,
                    first_order_discount_id: first_order_discount_id ? first_order_discount_id : null,
                    first_name: userAddress.user ? userAddress.user.firstname : null,
                    last_name: userAddress.user ? userAddress.user.lastname : null,
                    name: userAddress.name ? userAddress.name : null,
                    title: userAddress.title ? userAddress.title : null,
                    apartment: userAddress.apartment ? userAddress.apartment : null,
                    land_mark: userAddress.land_mark ? userAddress.land_mark : null,
                    address: userAddress.address ? userAddress.address : null,
                    mobile_number: userAddress.mobile_number ? userAddress.mobile_number : null,
                    country: userAddress.country ? userAddress.country.country_name : null,
                    state: userAddress.state ? userAddress.state.state_name : 0,
                    city: userAddress.city ? userAddress.city.city_name : 0,
                    zip_code: userAddress.zip_code ? userAddress.zip_code : null,
                    gst_number: userAddress.gst_number ? userAddress.gst_number : null,
                    company_name: userAddress ? userAddress.company_name : "",
                    company_address: userAddress ? userAddress.company_address : "",
                    billing_name: userAddress ? userAddress.billing_name : "",
                    billing_phone: userAddress ? userAddress.billing_phone : "",
                    billing_country: userAddress.billing_country?.country_name || "",
                    billing_state: userAddress.billing_state?.state_name || "",
                    billing_city: userAddress.billing_city?.city_name || "",
                    billing_address: userAddress ? userAddress.billing_address : "",
                    billing_pincode: userAddress ? userAddress.billing_pincode : "",
                    created_at: getCurrentDateTime(),
                    created_by: user_id
                });

                if (!orders) {
                    res.status(202).send({
                        message: process.env.NOT_INSERTED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    const orderId = orders.id;
                    var total_disocunt = parseFloat(discount) + parseFloat(f_order_discount);
                    // get cart data
                    const cartArray = carts;
                    for (const cart of cartArray) {
                        const productId = cart.product_id;
                        const quantity = cart.quantity;
                        const amount = cart.amount;
                        const prd_discount_amt = cart.discount_amt;
                        const samount = cart.subtotal_amount;
                        const pDiscounts = (total_disocunt > 0) ? (total_disocunt * samount) / subTotal : 0;
                        const pDiscountAmts = samount - pDiscounts;

                        await OrderItem.create({
                            order_id: orderId,
                            product_id: productId,
                            quantity: quantity,
                            price: amount,
                            prd_discount_amt: prd_discount_amt,
                            subtotal_amt: samount,
                            discount_amt: pDiscounts,
                            total_amt: pDiscountAmts,
                            created_at: getCurrentDateTime()
                        });

                        const productDetail = await Product.findOne({
                            attributes: ['stock_quantity'],
                            where: {
                                id: productId
                            }
                        });
                        const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;
                        const totalQty = prqty - quantity;

                        const sumResult = await OrderItem.findOne({
                            attributes: [
                                [sequelize.fn('SUM', sequelize.col('quantity')), 'totalQuantity']
                            ],
                            where: {
                                product_id: productId
                            }
                        });
                        const totalQuantity = sumResult.getDataValue('totalQuantity');

                        if (totalQty >= 0) {
                            await Product.update({
                                stock_quantity: totalQty,
                                sold_out_count: totalQuantity
                            }, {
                                where: {
                                    id: productId
                                }
                            });
                        }
                    }
                    // update uses of coupon 23-oct-2024
                    if (forderdiscount) {
                        const f_couponDetail = await Coupon.findOne({
                            attributes: ['number_of_uses'],
                            where: {
                                id: forderdiscount.discount_id
                            }
                        });
                        const uses = f_couponDetail.number_of_uses ? f_couponDetail.number_of_uses : 0;
                        const f_totalUses = uses - 1;
                        await Coupon.update({
                            number_of_uses: f_totalUses,
                        }, {
                            where: {
                                id: forderdiscount.discount_id
                            }
                        });
                    }
                    if (orderdiscount.length > 0) {
                        for (const orderDiscount of orderdiscount) {
                            const couponDetail = await Coupon.findOne({
                                attributes: ['number_of_uses'],
                                where: {
                                    id: orderDiscount.discount_id
                                }
                            });
                            const uses = couponDetail.number_of_uses ? couponDetail.number_of_uses : 0;
                            const totalUses = uses - 1;
                            await Coupon.update({
                                number_of_uses: totalUses,
                            }, {
                                where: {
                                    id: orderDiscount.discount_id
                                }
                            });
                        }
                    }
                    // end
                    if (buy_now.length > 0 && buy_now_product == 'buy_now') {
                        await BuyNow.destroy({
                            where: {
                                user_id: user_id,
                                status: 1,
                            },
                        });
                    } else {
                        await Cart.destroy({
                            where: {
                                user_id: user_id,
                                status: 1,
                            },
                        });
                    }

                    await OrderDiscountCoupon.destroy({
                        where: {
                            user_id: user_id,
                            discount_mode: buy_now_product,
                            discount_type: 'order'
                        },
                    });
                    await OrderDiscountCoupon.destroy({
                        where: {
                            user_id: user_id,
                            discount_type: 'first_order',
                        },
                    });



                    //if(reward_point>=process.env.MIN_REWARD_POINT){
                    if (reward_point > 0) {
                        await EarnRewardPoint.create({
                            user_id: user_id,
                            order_id: orderId,
                            reward_point: -reward_point,
                            type: 1,
                            debit_credit: 2,
                            reward_cmnt: 'use',
                            created_at: getCurrentDateTime()
                        });
                    }

                    // const axios = require('axios');
                    // const qs = require('qs');
                    // let data = qs.stringify({
                    //     'id': orderId,
                    //     'user_id': user_id 
                    //     });

                    // const config = {
                    //     method: 'post',
                    //     url: process.env.SITE_URL+'download_pdf',
                    //     data: data
                    // };

                    // const response = await axios(config);
                    // const invoiceUrl = process.env.SITE_URL+'uploads/order_invoice/'+response.data

                    // /******* Send invoice pdf mail start*/
                    // let dataa = qs.stringify({
                    //     'to': userAddress.user ? userAddress.user.email : null,
                    //     'subject': 'Order Invoice',
                    //     'msg_detail':'Please find attached the PDF.',
                    //     'attach': invoiceUrl,
                    //     });

                    // const configg = {
                    //     method: 'post',
                    //     url: process.env.SITE_URL+'send_mail_node_api',
                    //     data: dataa
                    // };

                    // const responsee = await axios(configg);

                    //SEND MAIL
                    // const orderDetail = await Order.findOne({
                    //     where: { id: orderId },
                    //     attributes: ['id', 'transaction_id', 'bank_ref_no', 'total_amount', 'discount_amt', 'reward_amt', 'shipping_amt', 'tax_amt', 'paid_amount', 'payment_type',
                    //         'payment_status', 'currency', 'discount_id', 'first_name', 'last_name', 'name', 'title', 'apartment', 'land_mark', 'address', 'mobile_number', 'country', 'state', 'city', 'zip_code', 'order_id', 'shipment_id', 'gst_number'],
                    //     include: [
                    //         {
                    //             model: OrderItem,
                    //             as: 'order_item',
                    //             attributes: ['id', 'order_id', 'product_id', 'quantity', 'price', 'shipping_type', 'shipping_id', 'shipping_min_price', 'status', 'total_amt'],
                    //             required: false,
                    //             include:
                    //             {
                    //                 model: Product,
                    //                 as: "products",
                    //                 attributes: ['id', 'product_name'],
                    //                 required: false,
                    //                 include: [{
                    //                     model: ProductMedia,
                    //                     as: 'productimage',
                    //                     attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    //                     where: { is_default: '1' },
                    //                     required: false,
                    //                 }],

                    //             },
                    //         },

                    //     ],
                    // });
                    // sendEmail(userAddress.user, 'OrderConfirmation', orderDetail);

                    // let dataa = qs.stringify({
                    //     'to': userAddress.user ? userAddress.user.email : null,
                    //     'user_id': userAddress.user_id,
                    //     'order_id': orderId,
                    // });

                    // const configg = {
                    //     method: 'post',
                    //     url: process.env.SITE_URL + 'order_confirmation',
                    //     data: dataa
                    // };
                    // const responsee = await axios(configg);

                    //END

                    /******* Send invoice pdf mail end*/
                    res.status(200).send({
                        message: process.env.INSERTED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        // data: orders
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                message_error: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const PayPayment_old = async (req, res) => {
    const user_id = req.userId;
    const transaction_id = req.body.transaction_id;
    const total_amount = req.body.total_amount;
    const discount_amt = req.body.discount_amt;
    const first_order_discount_amt = req.body.first_order_discount_amt;
    const first_order_discount_id = req.body.first_order_discount_id;
    const shipping_amt = req.body.shipping_amt;
    const tax_amt = req.body.tax_amt;
    const paid_amount = req.body.paid_amount;
    const payment_type = req.body.payment_type;
    const currency = req.body.currency;
    const coupon_id = req.body.coupon_id;
    const address_id = req.body.address_id;
    const reward_point = req.body.reward_point || 0;
    const reward_amt = req.body.reward_amt;
    var buy_now = req.body.buy_now;
    const schema = Joi.object().keys({
        total_amount: Joi.number().precision(1).required().label("Total Amount"),
        paid_amount: Joi.number().precision(1).required().label("Paid Amount"),
        payment_type: Joi.number().integer().required().label("Type"),
        currency: Joi.string().required().label("Currency"),
        address_id: Joi.number().integer().required().label("Address Id"),
    });
    const dataToValidate = {
        total_amount: total_amount,
        paid_amount: paid_amount,
        payment_type: payment_type,
        currency: currency,
        address_id: address_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const buyNowArray = buy_now ? JSON.parse(buy_now) : [];
            if (buyNowArray.length > 0) {
                var carts = buyNowArray;
            } else {
                var carts = await Cart.findAll({
                    where: {
                        user_id: user_id,
                        status: 1,
                    },
                    attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'subtotal_amount'],
                });
            }

            var stock_quantity_availability = [];
            if (carts) {
                const cartArray = carts;
                for (const cart of cartArray) {
                    var cartqty = cart.quantity;
                    const productDetail = await Product.findOne({
                        attributes: ['stock_quantity', 'product_name'],
                        where: {
                            id: cart.product_id
                        }
                    });
                    const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;
                    if (prqty < cartqty) {
                        stock_quantity_availability.push(productDetail.product_name);
                    }
                }
            }

            var stock_quantity_msg = '';
            if (stock_quantity_availability.length > 0) {
                var stock_quantity_msg = stock_quantity_availability.join(', ') + ' Out of stock';
                res.status(202).send({
                    message: stock_quantity_msg,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                // get user address
                const userAddress = await UserAddress.findOne({
                    where: {
                        id: address_id,
                        status: '1'
                    },
                    attributes: ['id', 'user_id', 'name', 'title', 'apartment', 'land_mark', 'address', 'mobile_number', 'zip_code', 'country_id', 'state_id', 'city_id', 'is_default', 'gst_number', 'billing_name', 'billing_phone', 'billing_address', 'billing_pincode', 'company_name', 'company_address'],
                    include: [
                        {
                            model: User,
                            as: 'user',
                            attributes: ['firstname', 'lastname', 'userfullname', 'email'],
                            required: false
                        },
                        {
                            model: Country,
                            as: 'country',
                            attributes: ['country_name'],
                            required: false
                        },
                        {
                            model: State,
                            as: 'state',
                            attributes: ['state_name'],
                            required: false
                        },
                        {
                            model: City,
                            as: 'city',
                            attributes: ['city_name'],
                            required: false
                        },
                        {
                            model: Country,
                            as: 'billing_country',
                            attributes: ['country_name'],
                            required: false
                        },
                        {
                            model: State,
                            as: 'billing_state',
                            attributes: ['state_name'],
                            required: false
                        },
                        {
                            model: City,
                            as: 'billing_city',
                            attributes: ['city_name'],
                            required: false
                        }
                    ]
                });

                const discount = discount_amt ? discount_amt : 0;
                const f_order_discount = first_order_discount_amt ? first_order_discount_amt : 0;
                const subTotal = total_amount;

                const orders = await Order.create({
                    user_id: user_id,
                    transaction_id: transaction_id,
                    total_amount: subTotal,
                    discount_amt: discount,
                    first_order_discount_amt: f_order_discount,
                    reward_amt: reward_amt ? reward_amt : 0,
                    shipping_amt: shipping_amt ? shipping_amt : 0,
                    tax_amt: tax_amt ? tax_amt : 0,
                    paid_amount: paid_amount,
                    payment_type: payment_type,
                    currency: currency,
                    discount_id: coupon_id ? coupon_id : null,
                    first_order_discount_id: first_order_discount_id ? first_order_discount_id : null,
                    first_name: userAddress.user ? userAddress.user.firstname : null,
                    last_name: userAddress.user ? userAddress.user.lastname : null,
                    name: userAddress.name ? userAddress.name : null,
                    title: userAddress.title ? userAddress.title : null,
                    apartment: userAddress.apartment ? userAddress.apartment : null,
                    land_mark: userAddress.land_mark ? userAddress.land_mark : null,
                    address: userAddress.address ? userAddress.address : null,
                    mobile_number: userAddress.mobile_number ? userAddress.mobile_number : null,
                    country: userAddress.country ? userAddress.country.country_name : null,
                    state: userAddress.state ? userAddress.state.state_name : 0,
                    city: userAddress.city ? userAddress.city.city_name : 0,
                    zip_code: userAddress.zip_code ? userAddress.zip_code : null,
                    gst_number: userAddress.gst_number ? userAddress.gst_number : null,
                    company_name: userAddress ? userAddress.company_name : "",
                    company_address: userAddress ? userAddress.company_address : "",
                    billing_name: userAddress ? userAddress.billing_name : "",
                    billing_phone: userAddress ? userAddress.billing_phone : "",
                    billing_country: userAddress.billing_country?.country_name || "",
                    billing_state: userAddress.billing_state?.state_name || "",
                    billing_city: userAddress.billing_city?.city_name || "",
                    billing_address: userAddress ? userAddress.billing_address : "",
                    billing_pincode: userAddress ? userAddress.billing_pincode : "",
                    created_at: getCurrentDateTime(),
                    created_by: user_id
                });

                if (!orders) {
                    res.status(202).send({
                        message: process.env.NOT_INSERTED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    const orderId = orders.id;
                    var total_disocunt = parseFloat(discount) + parseFloat(f_order_discount);
                    // get cart data
                    const cartArray = carts;
                    for (const cart of cartArray) {
                        const productId = cart.product_id;
                        const quantity = cart.quantity;
                        const amount = cart.amount;
                        const samount = quantity * amount;
                        const pDiscounts = (total_disocunt > 0) ? (total_disocunt * samount) / subTotal : 0;
                        const pDiscountAmts = samount - pDiscounts;

                        await OrderItem.create({
                            order_id: orderId,
                            product_id: productId,
                            quantity: quantity,
                            price: amount,
                            discount_amt: pDiscounts,
                            total_amt: pDiscountAmts,
                            created_at: getCurrentDateTime()
                        });

                        const productDetail = await Product.findOne({
                            attributes: ['stock_quantity'],
                            where: {
                                id: productId
                            }
                        });
                        const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;
                        const totalQty = prqty - quantity;

                        const sumResult = await OrderItem.findOne({
                            attributes: [
                                [sequelize.fn('SUM', sequelize.col('quantity')), 'totalQuantity']
                            ],
                            where: {
                                product_id: productId
                            }
                        });
                        const totalQuantity = sumResult.getDataValue('totalQuantity');

                        if (totalQty >= 0) {
                            await Product.update({
                                stock_quantity: totalQty,
                                sold_out_count: totalQuantity
                            }, {
                                where: {
                                    id: productId
                                }
                            });
                        }
                    }

                    if (buyNowArray.length == 0) {
                        await Cart.destroy({
                            where: {
                                user_id: user_id,
                                status: 1,
                            },
                        });
                    }

                    //if(reward_point>=process.env.MIN_REWARD_POINT){
                    if (reward_point > 0) {
                        await EarnRewardPoint.create({
                            user_id: user_id,
                            order_id: orderId,
                            reward_point: -reward_point,
                            type: 1,
                            debit_credit: 2,
                            reward_cmnt: 'use',
                            created_at: getCurrentDateTime()
                        });
                    }

                    const axios = require('axios');
                    const qs = require('qs');
                    let data = qs.stringify({
                        'id': orderId,
                        'user_id': user_id
                    });

                    const config = {
                        method: 'post',
                        url: process.env.SITE_URL + 'download_pdf',
                        data: data
                    };

                    const response = await axios(config);
                    const invoiceUrl = process.env.SITE_URL + 'uploads/order_invoice/' + response.data

                    /******* Send invoice pdf mail start*/
                    let dataa = qs.stringify({
                        'to': userAddress.user ? userAddress.user.email : null,
                        'subject': 'Order Invoice',
                        'msg_detail': 'Please find attached the PDF.',
                        'attach': invoiceUrl,
                    });

                    const configg = {
                        method: 'post',
                        url: process.env.SITE_URL + 'send_mail_node_api',
                        data: dataa
                    };

                    const responsee = await axios(configg);
                    /******* Send invoice pdf mail end*/
                    res.status(200).send({
                        message: process.env.INSERTED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: orders
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//pay payment end

// order shipment update start
const OrderShipmentUpdate = async (req, res) => {
    const id = req.body.id;
    const shipment_id = req.body.shipment_id;
    const order_id = req.body.order_id;
    const schema = Joi.object().keys({
        id: Joi.number().integer().required().label("Id"),
        shipment_id: Joi.string().required().label("Shipment Id"),
        order_id: Joi.string().required().label("Order Id"),

    });
    const dataToValidate = {
        id: id,
        shipment_id: shipment_id,
        order_id: order_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const order = await Order.update({
                shipment_id: shipment_id,
                order_id: order_id,
            }, {
                where: {
                    id: id
                }
            });
            if (!order) {
                res.status(202).send({
                    message: process.env.NOT_UPDATED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.UPDATED_MSG,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
// order shipment update end

//Get order list start
// const GetOrderList = async (req, res) => {
//     const user_id =  req.userId;
//         try {
//             const orderDetail = await Order.findAll({
//                 where: {
//                     user_id:user_id,
//                 },
//                 attributes:['id','transaction_id','total_amount','discount_amt','reward_amt','shipping_amt','tax_amt','paid_amount','payment_type',
//                 'payment_status','currency','discount_id','first_name','last_name','name','title','apartment','land_mark','address','mobile_number','country','state','city','zip_code','order_id','shipment_id','gst_number',
//                 [sequelize.literal('DATE_FORMAT(strpd_orders.created_at, "%Y-%m-%d")'), 'created_at'],
//                 [sequelize.literal('CASE WHEN payment_type = 1 THEN "online" WHEN payment_type = 2 THEN "cod" ELSE "" END'),'payment_type'],
//                 [sequelize.literal('(SELECT IF(COUNT(*) = 1, 1, 0) FROM strpd_orders AS o WHERE o.user_id = strpd_orders.user_id AND o.id <= strpd_orders.id)'), 'is_first_order']],
//                 include:[
//                     {
//                         model:OrderItem,
//                         as:'order_item',
//                         attributes:['id','order_id','product_id','quantity','price',['awb_code','tracking_id'],'status'],
//                         required: false,
//                         include:
//                         {
//                             model:Product,
//                             as:"products",
//                             attributes:['id','product_name','product_slug','image_alt','compare_price'],
//                             required: false,
//                             include: [{
//                                 model: ProductMedia,
//                                 as: 'productimage',
//                                 attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
//                                 required: false,
//                             }]

//                         }
//                     }

//                 ],
//                 order: [
//                     ['id', 'DESC'],
//                 ]
//             });

//         if (!orderDetail){
//             res.status(202).send({
//                 message:process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         }else{
//             res.status(200).send({
//                 message:process.env.SUCCESS_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 ORDERID: process.env.ORDERID,
//                 path: process.env.SITE_URL+'uploads/products/',
//                 data:orderDetail
//             });
//         }
//     } catch(error) {
//         res.status(500).send({
//             message:process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }

const GetOrderList = async (req, res) => {
    const user_id = req.userId;
    try {

        const page_number = parseInt(req.body.page_number) || 1;
        const limit = parseInt(req.body.limit) || 20;
        const offset = (parseInt(page_number) - 1) * parseInt(limit);

        const getAWB = await Order.findAll({
            where: {
                user_id: user_id,
            },
            attributes: ['id'],
            include: [
                {
                    model: OrderItem,
                    as: "order_item",
                    attributes: [
                        "id",
                        "order_id",
                        "product_id",
                        "quantity",
                        "price",
                        "awb_code",
                        "status",
                    ],
                    required: false,
                },
            ],
            order: [["id", "DESC"]],
        });

        const result = getAWB;

        if (result) {
            const promises = [];
            for (const data of result) {
                // Ensure order_item exists and is an array
                if (data.order_item && Array.isArray(data.order_item)) {
                    if (data.order_item.length > 0) {
                        for (const item of data.order_item) {
                            if (item.awb_code) {
                                promises.push(updateStatus(item));
                            }
                        }
                    }
                }
            }

            // Await all the promises to resolve
            await Promise.all(promises);
        }
        const orderDetail = await Order.findAll({
            where: {
                user_id: user_id,
            },
            attributes: [
                "id",
                "transaction_id",
                "total_amount",
                "discount_amt",
                "reward_amt",
                "shipping_amt",
                "tax_amt",
                "paid_amount",
                // "payment_type",
                "payment_status",
                "currency",
                "discount_id",
                "first_name",
                "last_name",
                "name",
                "title",
                "apartment",
                "land_mark",
                "address",
                "mobile_number",
                "country",
                "state",
                "city",
                "zip_code",
                "order_id",
                "shipment_id",
                "gst_number",
                [
                    sequelize.literal('DATE_FORMAT(strpd_orders.created_at, "%Y-%m-%d")'),
                    "created_at",
                ],
                [
                    sequelize.literal(
                        'CASE WHEN payment_type = 1 THEN "online" WHEN payment_type = 2 THEN "cod" ELSE "" END'
                    ),
                    "payment_type",
                ],
                [
                    sequelize.literal(
                        "(SELECT IF(COUNT(*) = 1, 1, 0) FROM strpd_orders AS o WHERE o.user_id = strpd_orders.user_id AND o.id <= strpd_orders.id)"
                    ),
                    "is_first_order",
                ],
                [
                    sequelize.literal(`
                        (SELECT 
                            CASE
                                WHEN COUNT(DISTINCT status) = 1 THEN MAX(status)
                                ELSE 'Mixed'
                            END
                        FROM strpd_order_items 
                        WHERE strpd_order_items.order_id = strpd_orders.id
                        )
                    `),
                    "order_status",
                ],
            ],
            offset,
            limit,
            include: [
                {
                    model: OrderItem,
                    as: "order_item",
                    attributes: [
                        "id",
                        "order_id",
                        "product_id",
                        "quantity",
                        "price",
                        ["awb_code", "tracking_id"],
                        "status",
                    ],
                    required: false,
                    include: [
                        {
                            model: TrackOrder,
                            as: "track_order",
                            attributes: [
                                "id",
                                "date",
                            ],
                            where: {
                                    delivery_status: { [Op.in]: ['DLVD', 'SHIPMENT DELIVERED'] },
                            },
                            required: false,
                        },
                    {
                        model: Product,
                        as: "products",
                        attributes: [
                            "id",
                            "product_name",
                            "product_slug",
                            "image_alt",
                            "compare_price",
                        ],
                        required: false,
                        include: [
                            {
                                model: ProductMedia,
                                as: "productimage",
                                attributes: [
                                    "file_name",
                                    "file_name_200_x_200",
                                    "file_name_180_x_180",
                                    "file_name_150_x_150",
                                    "file_name_120_x_120",
                                ],
                                where: {file_type:'image'},
                                required: false,
                            },
                        ],
                    },
                ],
                },
            ],
            order: [["id", "DESC"]],
        });



        const totalData = await Order.count({
            where: {
                user_id: user_id,
            },
            attributes: ['id'],

        });

        const totalItems = totalData;
        const totalPages = Math.ceil(totalItems / limit);
        const currentPage = page_number;
        const dataoncurrentPage = orderDetail.length;


        if (!orderDetail) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: "0",
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                ORDERID: process.env.ORDERID,
                path: process.env.SITE_URL + "uploads/products/",
                totalItems,
                totalPages,
                currentPage,
                dataoncurrentPage,
                data: orderDetail,
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: "0",
            msg: error.message
        });
    }
};

//Get order list end

//Get order detail start
const GetOrderDetails = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    try {
        const orderDetail = await Order.findOne({
            where: {
                user_id: user_id,
                id: id,
            },
            attributes: ['id', 'transaction_id', 'bank_ref_no', 'total_amount', 'discount_amt', 'reward_amt', 'shipping_amt', 'tax_amt', 'paid_amount', 'payment_type',
                'payment_status', 'currency', 'discount_id', 'first_name', 'last_name', 'name', 'title', 'apartment', 'land_mark', 'address', 'mobile_number', 'country', 'state', 'city', 'zip_code', 'order_id', 'shipment_id', 'gst_number',
                [sequelize.literal('DATE_FORMAT(strpd_orders.created_at, "%Y-%m-%d")'), 'created_at']],
            include: [
                {
                    model: OrderItem,
                    as: 'order_item',
                    attributes: ['id', 'order_id', 'product_id', 'quantity', 'price', 'shipping_type', 'shipping_id', 'shipping_min_price', 'status'],
                    required: false,
                    include:
                    {
                        model: Product,
                        as: "products",
                        attributes: ['id', 'product_name', 'product_slug', 'image_alt'],
                        required: false,
                        include: [{
                            model: ProductMedia,
                            as: 'productimages',
                            attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                            where: { is_default: '1',file_type:'image' },
                            required: false,
                        }],

                    },
                },

            ],
        });

        if (!orderDetail) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: orderDetail
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//Get order detail end

// order item cancel start
const OrderItemCancel = async (req, res) => {
    const order_id = req.body.id;
    const status = req.body.status;
    const cancel_reason = req.body.cancel_reason;
    const schema = Joi.object().keys({
        order_id: Joi.number().integer().required().label('Order Id'),
        status: Joi.number().integer().required().label('Cancel Status'),
        cancel_reason: Joi.string().required().label('Cancel Reason'),
    });
    const dataToValidate = {
        order_id: order_id,
        status: status,
        cancel_reason: cancel_reason,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const orderCancel = await OrderItem.update({
                status: status,
                cancel_reason: cancel_reason,
            }, {
                where: {
                    id: order_id,
                },
            });
            const user_id = req.userId;
            const items = await OrderItem.findOne({
                where: { id: order_id },
                attributes: ['id', 'product_id', 'quantity', 'shiprocket_order_id', 'total_amt'],
                include: [
                    {
                        model: Product,
                        as: "products",
                        attributes: ['id', 'product_name'],
                        required: false,
                        include: [{
                            model: ProductMedia,
                            as: 'productimage',
                            attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                            where: { is_default: '1',file_type:'image' },
                            required: false,
                        }],

                    },
                ],
            });

            const productId = items.product_id ? items.product_id : 0;
            const quantity = items.quantity ? items.quantity : 0;
            const total_amount = items.total_amt ? items.total_amt : 0;
            const productDetail = await Product.findOne({
                attributes: ['stock_quantity'],
                where: {
                    id: productId
                }
            });
            const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;
            const totalQty = prqty + quantity;

            if (totalQty >= 0) {
                await Product.update({
                    stock_quantity: totalQty
                }, {
                    where: {
                        id: productId
                    }
                });
            }

            // cancel order on shiprocket
            const shipOrderId = items ? items.shiprocket_order_id : '';
            if (shipOrderId) {
                const token = await shiprocketLogin();
                const axios = require('axios');
                let dataa = JSON.stringify({
                    "ids": [
                        shipOrderId
                    ]
                });

                let configg = {
                    method: 'post',
                    maxBodyLength: Infinity,
                    url: 'https://apiv2.shiprocket.in/v1/external/orders/cancel',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    data: dataa
                };

                const responsee = await axios(configg);
            }

            // const adminDetail = await User.findOne({
            //     attributes: ['email'],
            //     where: {
            //         role_id: 1
            //     }
            // });
            // const response = sendDynamicEmail(
            //     user.email,
            //     'OrderItem Cancel Mail',
            //     'OrderItem Cancel Mail',
            //     '<p>'+ 'OrderItem Cancel Mail :' + items.products.product_name +'</p>'
            //     );

            const product_name = items ? items.products.product_name : '';
            // order itme cancle mail
            const user = await User.findOne({
                attributes: ['id', 'email', 'userfullname'],
                where: {
                    id: user_id
                }
            });


            let data_email = qs.stringify({
                'to': user.email,
                'user_id': user.id,
                'order_id': items.id,
            });

            const config = {
                method: 'post',
                url: process.env.SITE_URL + 'order_cancel',
                data: data_email
            };
            const response = await axios(config);

            // sendEmail(user, 'CancelOrderItemEmail', items);
            if (!orderCancel) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: "Order Item has been cancel successfully",
                    error: false,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                message_error: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
// order item cancel end

// order cancel start
const OrderCancel = async (req, res) => {
    const order_id = req.body.order_id;
    const cancel_status = req.body.cancel_status;
    const cancel_reason = req.body.cancel_reason;
    const schema = Joi.object().keys({
        order_id: Joi.number().integer().required().label('Order Id'),
        cancel_status: Joi.number().integer().required().label('Cancel Status'),
        cancel_reason: Joi.string().required().label('Cancel Reason'),
    });
    const dataToValidate = {
        order_id: order_id,
        cancel_status: cancel_status,
        cancel_reason: cancel_reason,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    }
    else {
        try {
            const orderCancel = await Order.update({
                cancel_status: cancel_status,
                cancel_reason: cancel_reason,
            }, {
                where: {
                    id: order_id,
                }
            });

            const user_id = req.userId;
            const orderDetail = await Order.findOne({
                where: {
                    user_id: user_id,
                    id: order_id,
                },
                attributes: ['id'],
                include: [
                    {
                        model: User,
                        as: 'user',
                        attributes: ['id', 'email'],
                        required: false,
                    },
                    {
                        model: OrderItem,
                        as: 'order_item',
                        attributes: ['id'],
                        required: false,
                        include:
                        {
                            model: Product,
                            as: "products",
                            attributes: ['product_name'],
                            required: false,
                            include: [
                                {
                                    model: ProductMedia,
                                    as: 'productimages',
                                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                                    where: { is_default: '1',file_type:'image' },
                                    required: false,
                                }
                            ]
                        },
                    },

                ],
            });

            await OrderItem.update({
                cancel_status: 4,
                cancel_reason: cancel_reason,
            }, {
                where: {
                    order_id: order_id,
                }
            });

            const products = orderDetail.order_item.map(orderItems => orderItems.products.product_name);
            // const response = sendDynamicEmail(
            //         orderDetail.user.email,
            //         'Order Cancel Mail',
            //         'Order Cancel Mail',
            //         products.join(',')
            //     );

            // const adminDetail = await User.findOne({
            //     attributes: ['email'],
            //     where: {
            //         role_id: 1
            //     }
            // });

            // const axios = require('axios');
            // const qs = require('qs');
            // let data = qs.stringify({
            //     'to': adminDetail['email'],
            //     'subject': 'Order Cancel Mail',
            //     'msg_detail': products.join(',') + 'items is cancelled. Reason: ' + cancel_reason,
            //     });

            // const config = {
            //     method: 'post',
            //     url: process.env.SITE_URL+'send_mail_node_api',
            //     data: data
            // };

            // const response = await axios(config);
            const user = await User.findOne({
                attributes: ['email', 'userfullname'],
                where: {
                    id: user_id
                }
            });
            const template_email = await EmailTemplate.findOne({
                where: {
                    mail_type: 'CancelOrderEmail'
                }
            });
            var contact_mail = template_email.message.replace('[NAME]', user.userfullname);
            let data = qs.stringify({
                'to': user.email,
                'subject': template_email.subject,
                'msg_detail': contact_mail,
            });
            const config = {
                method: 'post',
                url: process.env.SITE_URL + 'send_mail_node_api',
                data: data
            };
            const response = await axios(config);
            if (!orderCancel) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: "Order has been cancel successfully",
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
// order cancel end

// get home gift list start
const GetHomeGiftVisits = async (req, res) => {
    try {

        const homeGift = await HomeGiftGridLayout.findAll({
            attributes: ['column_val', 'home_gift_grid_id', 'layout_type'],
            include: [
                {
                    model: HomeGiftVisits,
                    as: 'home_gift_data',
                    attributes: ['id', 'title', 'sub_title', 'image', 'button_link'],
                    required: false,
                },
            ],
        });

        if (!homeGift) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/home_gift/',
                data: homeGift
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get home gift list end

// get home grid list start
const GetHomeGridVisits = async (req, res) => {
    try {
        const homeGift = await HomeGridVisits.findAll({
            where: {
                status: 1,
            },
            attributes: ['id', 'title', 'sub_title', 'image', 'button_link',
                [sequelize.literal('DATE_FORMAT(created_at, "%d-%m-%Y")'), 'created_at']]
        });

        if (!homeGift) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/home_grid/',
                data: homeGift
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get home grid list end

// get all product list start
const GetAllProduct = async (req, res) => {
    const user_id = req.body.user_id || 0;
    try {
        const allProduct = await Product.findAll({
            order: [['id', 'DESC']],
            limit: 50,
            where: {
                status: '1',
                is_deleted: '0',
            },
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                sequelize.literal('CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END'),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
        });
        if (allProduct == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0',
                data: false
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: allProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get all product list end

//get all category list start
const GetAllCategoryList = async (req, res) => {
    try {
        const categories = await Category.findAll({
            where: {
                status: '1'
            },
            attributes: ['id', 'name', 'slug'],
        });
        const datastore = [];
        const catebycount = await Promise.all(categories.map(async (cate_data) => {
            const response_3 = await Product.findAll({
                where: {
                    status: '1',
                    [Op.and]: sequelize.literal(`FIND_IN_SET('${cate_data.id}', category_id)`)
                },
                //where: {status: '1', category_id: cate_data.id },
                attributes: ['id']
            })
            if (response_3.length > 0) {
                datastore.push({ 'id': cate_data.id, 'name': cate_data.name, 'slug': cate_data.slug, 'cate_count': response_3.length })
            }

        }));
        if (datastore < 1) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/category/',
                data: categories
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get all category list end

// add feedback start
const AddFeedback = async (req, res) => {
    const name = req.body.name;
    const email = req.body.email;
    const feedback = req.body.feedback;
    const schema = Joi.object().keys({
        name: Joi.string().required().label("Name"),
        email: Joi.string().email().required().label("Email"),
        feedback: Joi.string().required().label("feedback"),
    });
    const dataToValidate = {
        name: name,
        email: email,
        feedback: feedback,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const feedbackData = await Feedback.create(
                {
                    name: name,
                    email: email,
                    feedback: feedback,
                    created_at: current_date,
                }
            );
            if (!feedbackData) {
                res.status(202).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.INSERTED_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: feedbackData
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
// add feedback end

// get feedback start
const GetFeedback = async (req, res) => {
    try {
        const feedback = await Feedback.findAll({
            where: {
                status: '1'
            },
            attributes: ['id', 'name', 'email', 'feedback', [sequelize.literal('DATE_FORMAT(created_at, "%d-%m-%Y")'), 'created_at']]
        });
        if (feedback == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: feedback
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get feedback end

// download invoice start
const DownloadInvoice_old = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;

    const schema = Joi.object().keys({
        id: Joi.number().integer().required().label("Order Id"),
    });
    const dataToValidate = {
        id: id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const orderDetail = await Order.findOne({
                where: {
                    user_id: user_id,
                    id: id,
                },
                attributes: ['id', 'transaction_id', 'bank_ref_no', 'total_amount', 'discount_amt', 'shipping_amt', 'tax_amt', 'paid_amount', 'payment_type',
                    'payment_status', 'currency', 'discount_id', 'first_name', 'last_name', 'title', 'apartment', 'land_mark', 'address', 'mobile_number', 'country', 'state', 'city', 'zip_code', 'order_id', 'shipment_id',
                    [sequelize.literal('DATE_FORMAT(strpd_orders.created_at, "%Y-%m-%d")'), 'created_at']],
                include: [
                    {
                        model: User,
                        as: 'user',
                        attributes: ['firstname', 'lastname', 'userfullname', 'email'],
                        required: false
                    },
                    {
                        model: OrderItem,
                        as: 'order_item',
                        attributes: ['id', 'order_id', 'product_id', 'quantity', 'price', 'status'],
                        required: false,
                        include:
                        {
                            model: Product,
                            as: "products",
                            attributes: ['id', 'product_name', 'product_slug'],
                            required: false,
                            include: [{
                                model: ProductMedia,
                                as: 'productimages',
                                attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                                where: { is_default: '1',file_type:'image'},
                                required: false,
                            }],

                        },
                    },

                ],
            });

            if (!orderDetail) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                    data: false
                });
            } else {

                var country = orderDetail.country ? orderDetail.country + ',' : null;
                var state = orderDetail.state ? orderDetail.state + ',' : null;
                var city = orderDetail.city ? orderDetail.city + ',' : null;
                var zipcode = orderDetail.zip_code ? orderDetail.zip_code : null;
                var apartment = orderDetail.apartment ? orderDetail.apartment : null;
                var land_mark = orderDetail.land_mark ? orderDetail.land_mark : null;
                var address = orderDetail.address ? orderDetail.address : null;
                const customerAdrs = city + state + country + zipcode;

                const items = [];
                var i = 1;
                orderDetail.order_item.forEach(item => {
                    const product = item.products;
                    items.push({
                        srno: i++,
                        product_name: product.product_name,
                        quantity: item.quantity,
                        price: item.price,
                        total: item.quantity * item.price
                    });
                });

                const path = require('path');
                const templatePath = path.resolve(__dirname, "../../views/invoice_template.html"); // Resolve the absolute path to the template
                const invoiceData = {
                    customerName: orderDetail.user ? orderDetail.user.userfullname : null,
                    customerAddress: customerAdrs,
                    ordereId: orderDetail.order_id ? orderDetail.order_id : null,
                    txnId: orderDetail.transaction_id ? orderDetail.transaction_id : null,
                    bankRefNo: orderDetail.bank_ref_no ? orderDetail.bank_ref_no : null,
                    totalAmt: orderDetail.total_amount ? orderDetail.total_amount : null,
                    discountAmt: orderDetail.discount_amt ? orderDetail.discount_amt : 0,
                    shippingAmt: orderDetail.shipping_amt ? orderDetail.shipping_amt : 0,
                    taxAmt: orderDetail.tax_amt ? orderDetail.tax_amt : 0,
                    paidAmount: orderDetail.paid_amount ? orderDetail.paid_amount : null,
                    paymentType: (orderDetail.payment_type === 1) ? 'Online' : 'Offline',
                    paymentStatus: (orderDetail.payment_status === 1) ? 'Success' : 'Pending',
                    currency: orderDetail.currency ? orderDetail.currency : null,
                    items: items,
                    totalAmount: orderDetail.paid_amount ? orderDetail.paid_amount : null,
                };
                const currentTime = new Date().toISOString().replace(/[-:]/g, '').replace('T', '_').replace(/\..+/, '');
                const outputPath = path.resolve(__dirname, `../../../uploads/order_invoice/order_invoice_${currentTime}.pdf`);

                generatePDF(templatePath, invoiceData, outputPath);
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: outputPath
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const DownloadInvoice = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.order_id;

    const axios = require('axios');

    // Assuming you need to send additional data in the request body
    const qs = require('qs');
    let data = qs.stringify({
        'id': id,
        'user_id': user_id
    });

    const config = {
        method: 'post',
        url: process.env.SITE_URL + 'download_pdf',
        data: data
    };

    try {
        const response = await axios(config);

        res.status(200).send({
            message: process.env.SUCCESS_MSG,
            error: false,
            success: true,
            status: '1',
            data: process.env.SITE_URL + 'uploads/order_invoice/' + response.data
        });
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            message_error: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }

}
// dowmload invoice end

async function generatePDF(templatePath, data, outputPath) {
    try {
        const puppeteer = require('puppeteer');
        const fs = require('fs');
        const handlebars = require('handlebars');

        // Read HTML template file
        const htmlTemplate = fs.readFileSync(templatePath, 'utf8');

        // Compile template with data
        const compiledTemplate = handlebars.compile(htmlTemplate);
        const renderedHtml = compiledTemplate(data);

        // Launch Puppeteer
        const browser = await puppeteer.launch({ headless: "new", executablePath: '/usr/bin/google-chrome' });
        const page = await browser.newPage();

        // Set content of the page to the rendered HTML
        await page.setContent(renderedHtml);

        // Generate PDF
        await page.pdf({ path: outputPath, format: 'A4' });

        // Close Puppeteer
        await browser.close();

        console.log(`PDF saved to ${outputPath}`);
    } catch (error) {
        console.error('Error occurred:', error);
    }
}

// get category wise product list start
const GetCategoryProduct = async (req, res) => {
    const slugs = req.params.slug;
    const user_id = req.body.user_id || 0;
    try {
        var menus = await NavigationMenu.findOne({
            where: {
                slug: slugs,
                type: 1
            },
            attributes: ['id', 'menu_id'],
            include: [
                {
                    model: Menu,
                    as: 'menus',
                    attributes: ['id', 'slug', ['menu_name', 'name'], 'title', 'description', 'image'],
                    required: false,
                    include: [
                        {
                            model: AssignPageSlider,
                            as: 'assign_slider',
                            attributes: ['page_slider_id'],
                            required: false,
                            where: { type: '1' },
                            include: [
                                {
                                    model: PageSlider,
                                    as: 'page_slider',
                                    attributes: ['id', 'title'],
                                    required: false,
                                    include: [
                                        {
                                            model: PageSliderImages,
                                            as: 'page_slider_images',
                                            attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                                            required: false,
                                        },
                                    ],
                                },
                            ],
                        }
                    ],
                }
            ],
        });
        var categoriess = [];
        if (menus) {
            var categoriess = await NavigationMenu.findAll({
                where: {
                    parent_id: menus['id'],
                    type: 3
                },
                attributes: ['id', 'menu_id'],
                include: [
                    {
                        model: Category,
                        as: 'categories',
                        attributes: ['id', 'slug', 'name', 'description', 'image'],
                        required: false,
                        include: [
                            {
                                model: CategoryImages,
                                as: 'images',
                                attributes: ['image'],
                                required: false,
                            }
                        ],
                    }
                ],
                order: [
                    ['id', 'ASC'],
                ]
            });
        }

        cateProductArray = [];
        var offer = {};
        if (categoriess) {
            const categoriesArray = categoriess;
            for (const categorys of categoriesArray) {
                const categoryId = categorys.menu_id;
                const cate_slug = categorys.categories.slug;
                const name = categorys.categories.name;
                const description = categorys.categories.description;
                const images = categorys.categories.images;

                const subcategoryIds = await getSubcategoriesRecursive(categorys.id);
                var catIds = [categorys.menu_id].concat(subcategoryIds);
                if (slugs === 'offers') {
                    var pcondi = {
                        status: '1',
                        is_deleted: '0',
                        discount: { [Op.gt]: 0 }
                    };
                } else {
                    var pcondi = {
                        [Op.or]: catIds.map(catId => ({
                            [Op.or]: [
                                { category_id: catId.toString() }, // Exact match
                                sequelize.literal(`FIND_IN_SET(${catId}, category_id) > 0`) // Match catId in a comma-separated list
                            ]
                        })),
                        status: '1',
                        is_deleted: '0',
                        // [Op.or]: catIds.map(catId => ({
                        //     [Op.or]: [
                        //         { category_id: catId.toString() },
                        //         { category_id: { [Op.like]: `%,${catId}` } },
                        //         { category_id: { [Op.like]: `${catId},%` } }
                        //     ]
                        // })),
                        // status: '1',
                        // is_deleted: '0',
                    };



                }

                
                const products = await Product.findAll({
                    where: pcondi,
                    limit: 10,
                    attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                        // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                        sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                        'is_wishlist'
                    ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
                    include: [
                        {
                            model: ProductMedia,
                            as: 'productimages',
                            attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                            where: {file_type:'image'},
                            limit: 2,
                            required: false,
                        },
                        {
                            model: Wishlist,
                            as: 'wishlist',
                            attributes: ['id'],
                            where: { user_id: user_id },
                            required: false,
                        },
                        {
                            model: ProductNotifyModel,
                            as: 'product_notify',
                            attributes: ['id'],
                            where: { user_id: user_id },
                            required: false,
                        },
                        {
                            model: SiteSellerProducts,
                            as: 'seller_product',
                            attributes: ['seller_id'],
                            where: { seller_id: 3 },
                            required: true,
                        }
                    ],
                    order: [
                        ['stock_quantity', 'DESC'],
                    ]
                });

                cateProductArray.push({
                    id: categoryId,
                    slug: cate_slug,
                    name: name,
                    images: images,
                    description: description,
                    product_datas: products,
                });
            }
        }

        if (!menus) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                category_path: process.env.SITE_URL + 'uploads/category/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                product_path: process.env.SITE_URL + 'uploads/products/',
                menus_detail: menus,
                category: categoriess,
                data: cateProductArray
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get category wise product list end

// check pincode start
const checkPincode = async (req, res) => {
    const pincode = req.body.pincode;
    const schema = Joi.object().keys({
        pincode: Joi.number().integer().required(),
    });
    const dataToValidate = {
        pincode: pincode,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const pincodes = await ShipPincode.findOne({
                where: {
                    pincode: pincode,
                    delivery_status: 1
                }
            });
            if (pincodes) {
                res.status(200).send({
                    message: 'COD is not available for this pincode.',
                    error: false,
                    success: true,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: 'COD is available for this pincode.',
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
// check pincode end

// add review like unlike start
const AddProductReviewLike = async (req, res) => {
    const user_id = req.userId;
    const product_review_id = req.body.product_review_id;
    const schema = Joi.object().keys({
        product_review_id: Joi.number().integer().required().label("Product review id")
    });
    const dataToValidate = {
        product_review_id: product_review_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const checkProductExists = await ProductReviewLike.findOne({
                where: { product_review_id: product_review_id, user_id: user_id },
                attributes: ['id']
            });

            if (checkProductExists) {
                const planWishlists = checkProductExists.get({ plain: true });
                ProductReviewLike.destroy({
                    where: {
                        id: planWishlists['id'],
                    },
                });
                var is_like = 0;
                var likes = [];
                var msg = 'Remove review like';
            } else {
                var likes = await ProductReviewLike.create({
                    user_id: user_id,
                    product_review_id: product_review_id,
                    created_at: current_date,
                    created_by: user_id
                });
                var is_like = 1;
                var msg = 'Added review Like';
            }
            if (!likes) {
                res.status(202).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: msg,
                    error: false,
                    success: true,
                    status: '1',
                    is_like: is_like,
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
// add review like unlike start

// get related product start
const GetRelatedProduct = async (req, res) => {
    const product_id = req.body.product_id;
    const related_type = req.body.related_type;
    const user_id = req.body.user_id || 0;
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product")
    });
    const dataToValidate = {
        product_id: product_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const products = await RelatedProduct.findAll({
                limit: 5,
                order: [['id', 'DESC']],
                where: {
                    related_product_id: {
                        [Op.ne]: product_id,
                    },

                    product_id: product_id,
                    related_type: related_type,
                },
                attributes: ['id', 'product_id', 'related_product_id', 'related_type'],
                include: [
                    {
                        model: Product,
                        as: 'relatedproduct',
                        attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price'],
                        required: true,
                        where: {
                            is_deleted: '0',
                            status: '1'
                        },
                        include: [
                            {
                                model: ProductMedia,
                                as: 'productimages',
                                attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                                where: { is_default: '1',file_type:'image'},
                                required: false,
                            },
                            // Subquery to check if the product is in the user's wishlist
                            {
                                model: Wishlist,
                                as: 'wishlist',
                                attributes: ['id'],
                                where: { user_id: user_id }, // Using subquery
                                required: false,
                            },
                            {
                                model: ProductNotifyModel,
                                as: 'product_notify',
                                attributes: ['id'],
                                where: { user_id: user_id },
                                required: false,
                            },
                            {
                                model: SiteSellerProducts,
                                as: 'seller_product_rel',
                                attributes: ['seller_id'],
                                where: { seller_id: 3 },
                                required: true,
                            }
                        ]
                    },
                ],
            });
            products.forEach(prod => {
                if (prod.relatedproduct) {
                    prod.relatedproduct.dataValues.is_wishlist = prod.relatedproduct.wishlist ? 1 : 0;
                    prod.relatedproduct.dataValues.is_notify = prod.relatedproduct.product_notify ? 1 : 0;
                }
            });
            if (products == 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                    data: false
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    data: products
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
// get related product end

// get price wise gift product start
const GetGiftProduct = async (req, res) => {
    const slug = req.params.slug;
    const price = req.body.price;
    const user_id = req.body.user_id || 0;
    try {

        var categories = await NavigationMenu.findOne({
            where: {
                slug: slug,
                type: 3
            },
            attributes: ['id', 'menu_id'],
            include: [
                {
                    model: Category,
                    as: 'categories',
                    attributes: ['id', 'slug', 'name', 'description', 'image'],
                    required: false,
                    include: [
                        {
                            model: AssignPageSlider,
                            as: 'assign_slider',
                            attributes: ['page_slider_id'],
                            required: false,
                            where: { type: '2' },
                            include: [
                                {
                                    model: PageSlider,
                                    as: 'page_slider',
                                    attributes: ['id', 'title'],
                                    required: false,
                                    include: [
                                        {
                                            model: PageSliderImages,
                                            as: 'page_slider_images',
                                            attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                                            required: false,
                                        },
                                    ],
                                },
                            ],
                        }
                    ],
                }
            ],
        });
        if (categories) {
            const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
            var catIds = [categories['menu_id']].concat(subcategoryIds);
        } else {
            var catIds = [];
        }
        var pcondi = {
            [Op.or]: catIds.map(catId => ({
                [Op.or]: [
                    { category_id: catId.toString() }, // Exact match
                    sequelize.literal(`FIND_IN_SET(${catId}, category_id) > 0`) // Match catId in a comma-separated list
                ]
            })),
            price: { [Op.lte]: price }, // Price less than or equal to 1000
            status: '1',
            is_deleted: '0'
        };


        const products = await Product.findAll({
            where: pcondi,
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: [
                ['stock_quantity', 'DESC'],
            ]
        });

        const maxpriceproducts = await Product.findOne({
            where: pcondi,
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['id', 'DESC'],
            ]
        });

        if (!categories) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                category_path: process.env.SITE_URL + 'uploads/category/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                product_path: process.env.SITE_URL + 'uploads/products/',
                max_price: maxpriceproducts['price'] || 0,
                category: categories,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get price wise gift product end

const paymentForm = async (req, res) => {
    fs.readFile(path.join(__dirname, '../../views/form.html'), (err, data) => {
        if (err) {
            res.writeHead(500, { 'Content-Type': 'text/plain' });
            res.end('Error loading HTML file');
        } else {
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(data);
        }
    });
}

// add review like dislike start
const AddProductReviewDisLike = async (req, res) => {
    const user_id = req.userId;
    const product_review_id = req.body.product_review_id;
    const schema = Joi.object().keys({
        product_review_id: Joi.number().integer().required().label("Product review id")
    });
    const dataToValidate = {
        product_review_id: product_review_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const checkProductExists = await ProductReviewLike.findOne({
                where: { product_review_id: product_review_id, user_id: user_id },
                attributes: ['id']
            });

            if (checkProductExists) {
                const planWishlists = checkProductExists.get({ plain: true });
                ProductReviewLike.destroy({
                    where: {
                        id: planWishlists['id'],
                    },
                });
                var is_dislike = 0;
                var likes = [];
                var msg = 'Remove review like';
            } else {
                var likes = await ProductReviewLike.create({
                    user_id: user_id,
                    product_review_id: product_review_id,
                    created_at: current_date,
                    created_by: user_id,
                    status: '0'
                });
                var is_dislike = 1;
                var msg = 'Added review Like';
            }
            if (!likes) {
                res.status(202).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: msg,
                    error: false,
                    success: true,
                    status: '1',
                    is_dislike: is_dislike,
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

let authToken = null;
const shiprocketLogin = async () => {
    if (authToken) {
        return authToken; // Return the stored token if it exists
    }

    try {
        let data = JSON.stringify({
            "email": "abhiesharma93@gmail.com",
            "password": "Shanu@11"
        });

        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: 'https://apiv2.shiprocket.in/v1/external/auth/login',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: data
        };

        const response = await axios.request(config);
        authToken = response.data.token;
        return authToken;
    } catch (error) {
        console.error('Error logging in:', error.response.data);
        throw error;
    }
};

const shiprocketPincodeVerify = async (req, res) => {

    const token = await shiprocketLogin();
    const pickup_postcode = req.body.pickup_postcode;
    const delivery_postcode = req.body.delivery_postcode;
    const weight = req.body.weight;
    const cod = req.body.cod;
    const schema = Joi.object().keys({
        delivery_postcode: Joi.required().label("delivery_postcode")
    });
    const dataToValidate = {
        delivery_postcode: delivery_postcode,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        let config = {
            method: 'get',
            maxBodyLength: Infinity,
            url: `https://apiv2.shiprocket.in/v1/external/courier/serviceability/?pickup_postcode=${pickup_postcode}&delivery_postcode=${delivery_postcode}&weight=${weight}&cod=${cod}`,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        };

        axios.request(config)
            .then((response) => {
                res.status(200).send(JSON.stringify(response.data));
            })
            .catch((error) => {
                // Log the error for debugging purposes
                console.error('Error occurred:', error);

                // Check if the error is an axios error with a response
                if (error.response) {
                    // If the server responded with a status other than 200
                    // send the status code and error response back to the client
                    res.status(error.response.status).send(error.response.data);
                } else if (error.request) {
                    // If the request was made but no response was received
                    // (e.g., network error), send an appropriate status code
                    res.status(500).send('Server Error');
                } else {
                    // If there was an error setting up the request
                    res.status(500).send('Request Error');
                }
            });
    }
}

// get user reward point start
const getRewardPointWallet = async (req, res) => {
    const user_id = req.userId;
    try {
        const checkRewardPoint = await RewardPointWallet.findOne({
            attributes: ['id', 'total_points'],
            where: {
                user_id: user_id
            }
        });
        if (!checkRewardPoint) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: checkRewardPoint
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get user reward point end

// get user reward point history start
const getRewardPointHistory = async (req, res) => {
    const user_id = req.userId;
    try {
        const checkRewardPoint = await EarnRewardPoint.findAll({
            attributes: ['id', 'user_id', 'reward_point', 'status',
                [
                    sequelize.literal(`CASE
                WHEN debit_credit = 2 THEN 'Debit'
                WHEN debit_credit = 1 THEN 'Credit'
                ELSE NULL
            END`), 'debit_credit'
                ],
                [
                    sequelize.literal(`CASE
                WHEN type = 1 THEN 'Byorder'
                WHEN type = 2 THEN 'Byadmin'
                WHEN type = 3 THEN 'Bynewjoin'
                WHEN type = 4 THEN 'Coupon'
                WHEN type = 5 THEN 'Byrefralcode'
                WHEN type = 6 THEN 'Deduct'
                ELSE NULL
            END`), 'type'
                ]
            ],
            where: {
                user_id: user_id
            }
        });
        if (!checkRewardPoint) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: checkRewardPoint
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get user reward point history end

// payment cancel url start
const cancelPayment = async (req, res) => {
    const user_id = req.userId;
    try {

        console.log(req.body);
        //     res.redirect(req.body);
        res.redirect(process.env.FRONT_SITE_URL + 'payment');
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// payment cancel url end

//verify GST Number
async function verifyGST(gstNumber) {
    try {
        const response = await axios.get(`https://cleartax.in/gst-number-search/${gstNumber}`);
        if (response.status == 200) {
            // const $ = cheerio.load(response.data);
            // const tagData = $('title').text();
            return true
        }
        return false
    } catch (error) {
        console.error('Error verifying GST Number:', error.message);
    }
}


// bulk order information start
const AddBulkOrderInformation = async (req, res) => {
    const product_id = req.body.product_id || 0;
    const name = req.body.name;
    const email = req.body.email;
    const mobile_number = req.body.mobile_number;
    const country_id = req.body.country_id;
    const pincode = req.body.pincode;
    const type = req.body.type;
    const gst_no = req.body.gst_no;
    const gst_comp_name = req.body.gst_comp_name;
    const gst_address = req.body.gst_address;
    const address = req.body.address;
    const query = req.body.query;
    const schema = Joi.object().keys({
        name: Joi.string().required().label("Name"),
        email: Joi.string().required().email().label("Email"),
        mobile_number: Joi.string()
            .pattern(/^[0-9]{10,12}$/)
            .required()
            .label("Contact number"),
        country_id: Joi.number().integer().required().label("Country"),
    });
    const dataToValidate = {
        name: name,
        email: email,
        mobile_number: mobile_number,
        country_id: country_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {
        try {
            if (gst_no) {
                if (gst_no.length < 15) {
                    return res.status(202).send({
                        message: process.env.RECORD_NOT_FOUND,
                        error: true,
                        success: false,
                        status: "0",
                        reason: "GST Number cannot be less than 15 characters",
                    });
                } else {
                    const gstNumber = await verifyGST(gst_no);
                    if (!gstNumber) {
                        return res.status(202).send({
                            message: process.env.RECORD_NOT_FOUND,
                            error: true,
                            success: false,
                            status: "0",
                            reason: "GST Number is invalid",
                        });
                    }
                }
            }
            const bulkOrder = await BulkOrderInformation.create({
                product_id: product_id,
                name: name,
                email: email,
                mobile_number: mobile_number,
                country_id: country_id,
                gst_no: gst_no,
                gst_comp_name: gst_comp_name,
                gst_address: gst_address,
                pincode: pincode,
                address: address,
                query: query,
                type: type,
            });
            // const product = await Product.findOne({
            //     where: {
            //         id: product_id,
            //     },
            //     attributes: ['id', 'product_name'],
            // });

            const subjectMap = {
                'BulkOrder': 'Automatic Reply: Bulk Order',
                'Questions': 'Automatic Reply: Have Questions',
                'BusinessCollaborations': 'Automatic Reply: Business Collaborations'
            };

            if (subjectMap[type]) {
                const subject = subjectMap[type];
                var data_email = qs.stringify({
                    'to': email,
                    'username': name,
                    'subject': subject,
                });
            }

            const config = {
                method: 'post',
                url: process.env.SITE_URL + 'query_mail',
                data: data_email
            };
            const response = await axios(config);

            if (!bulkOrder) {
                res.status(202).send({
                    message: process.env.NOT_INSERTED_MSG,
                    error: true,
                    success: false,
                    status: "0",
                });
            } else {
                res.status(200).send({
                    message: process.env.INSERTED_MSG,
                    error: false,
                    success: true,
                    status: "1",
                    data: bulkOrder,
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                message_error: error.message,
                error: true,
                success: false,
                status: "0",
            });
        }
    }
};
// bulk order information end

//get favourite color 
const GetFavouriteColor = async (req, res) => {
    try {
        // const favouriteColor = await Product.findAll({
        //     limit: 5,
        //     order: [['sold_out_count','DESC']],
        //     attributes: ['id'],
        //     where:{
        //         status:'1',
        //         is_deleted: '0'
        //     },
        // });

        // const pIdArr = favouriteColor.map(product => product ? product.id : null);
        // const productAttribute = await ProductAttributes.findAll({
        //     where:{product_id: { [Op.in]: pIdArr },attr_type_id:2},
        //     attributes: ['attr_val_id'],
        //     required: false,
        // });

        // const colorIdArr = productAttribute.map(productattr => productattr ? productattr.attr_val_id : null);
        const favouriteColorArray = await ProductAttributeValue.findAll({
            //where:{id: { [Op.in]: colorIdArr },prod_attr_type_id:2},
            limit: 5,
            where: { prod_attr_type_id: 2, is_favourite: 1 },
            attributes: ['id', ['attr_val_name', 'color'], 'slug', 'image'],
            required: false,
        });

        if (favouriteColorArray == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/color_image/',
                data: favouriteColorArray
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get favourite color

// get best seller product start
const GetBestSellProduct = async (req, res) => {
    const user_id = req.body.user_id || 0;
    try {
        const bestSellProduct = await Product.findAll({
            limit: 10,
            // order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
            //order: [['stock_quantity','DESC']],
            attributes: ['id', 'sold_out_count', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        if (bestSellProduct.length == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: bestSellProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const GetAllBestSellProduct = async (req, res) => {
    const user_id = req.body.user_id || 0;
    const slug = req.body.slug || 'bestseller';
    try {
        var slider_details = await AssignPageSlider.findOne({
            attributes: ['page_slider_id'],
            required: false,
            where: { type: '3', category_menu_id: 4 },
            include: [
                {
                    model: PageSlider,
                    as: 'page_slider',
                    attributes: ['id', 'title'],
                    required: false,
                    include: [
                        {
                            model: PageSliderImages,
                            as: 'page_slider_images',
                            attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                            required: false,
                        },
                    ],
                },
            ],

        });
        const bestSellProduct = await Product.findAll({
            order: [['stock_quantity', 'DESC']],
            attributes: ['id', 'sold_out_count', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0'
            },
        });
        const maxpriceproducts = await Product.findOne({
            where: {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0'
            },
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ]
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }
        if (bestSellProduct.length == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                path: process.env.SITE_URL + 'uploads/products/',
                slug: slug,
                slider_details: slider_details,
                max_price: maxpriceVal,
                data: bestSellProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get best seller product end

//get color wise product start
const GetColorWiseProduct = async (req, res) => {
    const slug = req.params.slug;
    const user_id = req.body.user_id || 0;
    try {
        var slider_details = await AssignPageSlider.findOne({
            attributes: ['page_slider_id'],
            required: false,
            where: { type: '3', category_menu_id: 5 },
            include: [
                {
                    model: PageSlider,
                    as: 'page_slider',
                    attributes: ['id', 'title'],
                    required: false,
                    include: [
                        {
                            model: PageSliderImages,
                            as: 'page_slider_images',
                            attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                            required: false,
                        },
                    ],
                },
            ],

        });
        const colorData = await ProductAttributeValue.findOne({
            where: { slug: slug, prod_attr_type_id: 2 },
            attributes: ['id'],
            required: false,
        });

        const color_id = colorData ? colorData['id'] : 0;
        const productAttribute = await ProductAttributes.findAll({
            where: { attr_val_id: color_id, attr_type_id: 2 },
            attributes: ['product_id'],
            required: false,
        });

        var prIdArr = productAttribute.map(variant => variant.product_id);

        var pcondi = {
            id: { [Op.in]: prIdArr },
            status: '1',
            is_deleted: '0'
        };

        const products = await Product.findAll({
            where: pcondi,
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: [
                ['stock_quantity', 'DESC'],
            ]
        });
        const maxpriceproducts = await Product.findOne({
            where: pcondi,
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ]
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }
        if (!products) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                product_path: process.env.SITE_URL + 'uploads/products/',
                slug: slug,
                max_price: maxpriceVal,
                slider_details: slider_details,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get color wise product end

// get gift category list start
const GetGiftCategory = async (req, res) => {
    try {
        var menus = await NavigationMenu.findOne({
            where: {
                slug: 'gifts',
                type: 1
            },
            attributes: ['id', 'menu_id']
        });
        var categoriess = [];
        if (menus) {
            var categoriess = await NavigationMenu.findAll({
                where: {
                    parent_id: menus['id'],
                    type: 3
                },
                attributes: ['id', 'menu_id'],
                include: [
                    {
                        model: Category,
                        as: 'categories',
                        attributes: ['id', 'slug', 'name', 'description', 'image'],
                        required: false
                    }
                ],
            });
        }

        if (!categoriess) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                category_path: process.env.SITE_URL + 'uploads/category/',
                data: categoriess
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get gift category list end

//setting

const GetSettingList = async (req, res) => {
    try {
        const setting = await Setting.findOne({
            attributes: ['id',['discount', 'onlineDiscount'],'support_person', 'support_email', 'support_phone', 'manufacturing_warranty', 'product_buffer_days', 'max_product_quantity', 'max_shipping_amount', 'shipping_amount', 'support_hour', 'corporate_address', 'footer_heading', 'footer_description', 'bulk_description', 'footer_link_content']
        });
        if (setting == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: setting
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//end setting


// get related product start
const GetComboProduct = async (req, res) => {
    const product_id = req.body.product_id;

    const related_type = 'combo_product';
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product"),
    });
    const dataToValidate = {
        product_id: product_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const products = await RelatedProduct.findAll({
                where: {
                    product_id: product_id,
                    related_type: related_type,
                },
                attributes: ['related_product_id'],
            });
            var related = products.map(product => product.related_product_id);

            const originalProductData = await Product.findOne({
                where: {
                    id: Number(product_id),
                    stock_quantity: {
                        [Op.gt]: 0
                    },
                    status: '1',
                    is_deleted: '0',
                },
                attributes: ['id', 'product_name', 'product_slug', 'title', 'description', 'price', 'compare_price', 'stock_quantity', 'weight', 'category_id', 'has_variant', 'product_tags', 'usd_price', 'usd_compare_price'],
                include: [{
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }]
            });

            const relatedProductData = await Product.findAll({
                where: {
                    id: { [Op.in]: related },
                    stock_quantity: {
                        [Op.gt]: 0
                    },
                    status: '1',
                    is_deleted: '0',
                },
                attributes: ['id', 'product_name', 'product_slug', 'title', 'description', 'price', 'compare_price', 'stock_quantity', 'weight', 'category_id', 'has_variant', 'product_tags', 'usd_price', 'usd_compare_price'],
                include: [{
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }]
            });

            // Combine original product data with related product data
            const comboData = [originalProductData, ...relatedProductData];
            if (comboData.length === 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                    data: false
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    data: comboData,
                });
            }
        } catch (error) {
            console.error(error);
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
// get combo product end

// get compare product start
const GetCompareProduct = async (req, res) => {
    // const product_id = req.body.product_id;
    const user_id = req.body.user_id || 0;
    try {
        var product_ids = JSON.parse(req.body.product_id);

        const products = await Product.findAll({
            where: {
                id: { [Op.in]: product_ids },
                status: '1',
                is_deleted: '0'
            },
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'category_id', 'stock_quantity', ['product_tags', 'Feature'], 'pack_contain', 'description', 'additional_description', ['why_we_it', 'why_we_love_it'], 'shipping_return', 'dimension'
                , 'is_gift_option', 'gift_price', 'is_allow_cod', 'return_days_limit', 'image_alt', 'weight', 'unit', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price',
                [sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_wishlist'],
                [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify'],
                [sequelize.literal('(SELECT CASE WHEN AVG(rating) IS NULL THEN 0 ELSE AVG(rating) END FROM strpd_product_reviews WHERE strpd_product_reviews.product_id = strpd_main_products.id)'), 'average_rating']],
            include: [
                {
                    model: ProductVariant,
                    as: 'pr_variant',
                    attributes: ['id', 'product_id', 'size_id', 'color_id'],
                    required: false,
                    include: [
                        {
                            model: Size,
                            as: 'product_size',
                            attributes: ['id', 'size'],
                            where: { status: '1' },
                            required: false,
                        },
                        {
                            model: Color,
                            as: 'product_color',
                            attributes: ['id', 'color', 'image'],
                            where: { status: '1' },
                            required: false,
                        },
                    ]
                },
                {
                    model: ProductType,
                    as: 'producttypes',
                    attributes: ['type_name'],
                    where: { status: '1' },
                    required: false
                },
                {
                    model: ProductMaterial,
                    as: 'productmaterials',
                    attributes: ['material_name'],
                    where: { status: '1' },
                    required: false
                },
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ]
        });


        if (!products) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                color_img_path: process.env.SITE_URL + 'uploads/color_image/',
                path: process.env.SITE_URL + 'uploads/products/',
                data: products,

            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}


//product faq list start

const GetProductFaqList = async (req, res) => {
    const product_id = req.body.product_id;

    const schema = Joi.object().keys({
        product_id: Joi.number().required().label("product_id"),
    });
    const dataToValidate = {
        product_id: product_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {

        try {
            const faq = await Faq.findAll({
                limit: 10,
                order: [['id', 'ASC']],
                attributes: ['id', 'product_id', 'question', 'answer'],
                where: {
                    product_id: product_id,
                    status: '1',
                    type: '2'

                },
                // include:[{
                //     model:Faq,
                //     as:"faq",
                //     attributes:['id','question','answer'],
                //     limit: 10,
                //     order: [['id','DESC']],
                //     where: {status:'1'},
                //     required: false
                // }]
            });
            if (faq == 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: faq
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//==========================

// get search keyword history start
const GetSearchKeywordTemplate = async (req, res) => {
    const user_id = req.userId;
    try {
        const searchKeyword = await SearchKeywordTemplate.findAll({
            where: {
                user_id: user_id,
                status: '1',
            },
            attributes: ['id', 'product_title'],
        });
        if (!searchKeyword) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: searchKeyword
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get search keyword history end

// get user view product list start
const GetUserProductView = async (req, res) => {
    const user_id = req.userId;
    try {
        const userProductViews = await UserProductView.findAll({
            order: [['created_at', 'DESC']],
            where: {
                user_id: user_id,
            },
            attributes: ['id', 'product_id'],
            include: [
                {
                    model: Product,
                    as: 'products',
                    attributes: ['id', 'sold_out_count', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days',
                        [sequelize.literal('(SELECT COUNT(*) FROM strpd_product_reviews WHERE strpd_product_reviews.product_id = products.id)'), 'review_count'],
                        [sequelize.literal('(SELECT CASE WHEN AVG(rating) IS NULL THEN 0 ELSE AVG(rating) END FROM strpd_product_reviews WHERE strpd_product_reviews.product_id = products.id)'), 'average_rating']
                    ],
                    where: { status: '1', is_deleted: '0' },
                    required: false,
                    include: [
                        {
                            model: ProductMedia,
                            as: 'productimages',
                            attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                            where: {file_type:'image'},
                            limit: 2,
                            required: false,
                        },
                        {
                            model: Wishlist,
                            as: 'wishlist',
                            attributes: ['id'],
                            where: { user_id: user_id },
                            required: false,
                        },
                        {
                            model: ProductNotifyModel,
                            as: 'product_notify',
                            attributes: ['id'],
                            where: { user_id: user_id },
                            required: false,
                        },
                        {
                            model: SiteSellerProducts,
                            as: 'seller_product',
                            attributes: ['seller_id'],
                            where: { seller_id: 3 },
                            required: true,
                        }
                    ],
                }
            ]
        });
        userProductViews.forEach(prod => {
            if (prod.products) {
                prod.products.dataValues.is_wishlist = prod.products.wishlist ? 1 : 0;
                prod.products.dataValues.is_notify = prod.products.product_notify ? 1 : 0;
            }
        });
        //console.log(userProductViews.length);
        if (userProductViews.length == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                product_path: process.env.SITE_URL + "uploads/products/",
                data: userProductViews,
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get user view product list end

// get first order coupon start
const GetFirstOrderCoupon = async (req, res) => {
    const user_id = req.body.user_id || 0;
    try {

        const firstOrder = await Coupon.findOne({
            where: {
                apply_to: 'FIRST_ORDER',
                status: '1',
                is_deleted: 0,
            },
            attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'
                , [
                    sequelize.literal(`CASE WHEN applied_coupon.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                    'is_applied'
                ]
            ],
            include: [
                {
                    model: OrderDiscountCoupon,
                    as: 'applied_coupon',
                    attributes: ['id'],
                    where: { user_id: user_id, discount_type: 'order' },
                    required: false,
                }
            ],
        });

        const orderCount = await Order.count({
            where: {
                user_id: user_id,
                payment_status: { [Op.in]: [0, 1] }
            }
        });
        const header_discount = await Header_contentDiscountModel.findAll({
            where: {
                status: '1',
            },
            attributes: ['id', 'content', 'action_url']


        });


        if (!firstOrder) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                header_discount: header_discount,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                header_discount: header_discount,
                order_count: orderCount,
                data: firstOrder
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get first order coupon end

// get tender keyword start
const GetTrendingKeywordList = async (req, res) => {
    try {
        const trendingKeyword = await TrendingKeyword.findAll({
            where: {
                status: '1',
            },
            include: {
                model: Category,
                attributes: ['id', 'slug'],
                where: { status: '1' },
                required: true
            },
            attributes: ['id', 'title', 'slug', 'status']
        });
        if (trendingKeyword == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: trendingKeyword
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get tender keyword end

// check product stock start
const checkProductStock = async (req, res) => {
    const user_id = req.userId;
    const buy_now = req.body.buy_now || 'cart';
    try {
        var buy = await BuyNow.findAll({
            where: {
                user_id: user_id,
                status: 1,
            },
        });
        if (buy_now == 'buy_now' && buy_now.length > 0) {
            var carts = buy;
        } else {
            var carts = await Cart.findAll({
                where: {
                    user_id: user_id,
                    status: 1,
                },
                attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'subtotal_amount'],
            });
        }
        var stock_quantity_availability = [];
        var out_of_stock = [];
        if (carts) {
            const cartArray = carts;
            for (const cart of cartArray) {
                var cartqty = cart.quantity;
                const productDetail = await Product.findOne({
                    attributes: ['stock_quantity', 'product_name','id'],
                    where: {
                        id: cart.product_id
                    }
                });
                const prqty = productDetail ? productDetail.stock_quantity : 0;
                const product_name = productDetail ? productDetail.product_name + ' Out of stock' : '';
                const product_id = productDetail ? productDetail.id : '';
                if (prqty < cartqty) {
                    stock_quantity_availability.push(product_name);
                    out_of_stock.push({ product_name, product_id });

                }
            }
        }

        var stock_quantity_msg = '';
        if (carts.length == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else if (stock_quantity_availability.length > 0) {
            var stock_quantity_msg = stock_quantity_availability.join(', ') + ' Out of stock';
            res.status(200).send({
                out_of_stock:out_of_stock,
                message: stock_quantity_msg,
                error: true,
                success: false,
                status: '2'
            });
        } else {
            res.status(200).send({
                message: 'Stock Avalaible',
                error: false,
                success: true,
                status: '1',
                data: carts
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            message_error:error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// check product stock end

//get finest product start
const GetFienstProduct = async (req, res) => {
    const user_id = req.body.user_id || 0;
    const slug = req.body.slug || 'finestProduct';
    try {
        var slider_details = await AssignPageSlider.findOne({
            attributes: ['page_slider_id'],
            required: false,
            where: { type: '3', category_menu_id: 3 },
            include: [
                {
                    model: PageSlider,
                    as: 'page_slider',
                    attributes: ['id', 'title'],
                    required: false,
                    include: [
                        {
                            model: PageSliderImages,
                            as: 'page_slider_images',
                            attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                            required: false,
                        },
                    ],
                },
            ],

        });
        const finestProduct = await Product.findAll({
            order: [['stock_quantity', 'DESC']],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
                // stock_quantity: {
                //     [sequelize.Op.gt]: 0
                // }
            },
        });
        const maxpriceproducts = await Product.findOne({
            where: {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ]
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }
        if (finestProduct == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                path: process.env.SITE_URL + 'uploads/products/',
                slug: slug,
                max_price: maxpriceVal,
                slider_details: slider_details,
                data: finestProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get finest product end
//get finest product start 10 record stock_quantity > 0
const GetFienstProducts = async (req, res) => {
    const user_id = req.body.user_id || 0;
    try {

        const finestProduct = await Product.findAll({
            limit: 10,
            //order: [['stock_quantity','DESC']],
            //order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        if (finestProduct == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: finestProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get finest product end

//==========================
const GetContactUsQueryList = async (req, res) => {
    try {

        const response = await ContactUsQuery.findAll({
            where: { status: "1" },
            attributes: ["id", "name", "created_by", "created_at"],
        });

        if (!response[0]) {
            return res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: "0",
            });
        } else {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                data: response,
            });
        }

    } catch (error) {
        res.status(process.env.INTERNAL_SERVER_STATUS).send({
            // message: process.env.ERROR_MSG,
            message: error.message,
            error: true,
            success: false,
            status: "0",
        });
    }
};

const contactUsAdd = async (req, res) => {
    const user_id = req.userId;
    const query = req.body.query_id;
    const message = req.body.query;
    const order_number = req.body.order_number;
    const email_id = req.body.email_id;
    const schema = Joi.object().keys({
        query: Joi.string().required().label("query"),
        email_id: Joi.string().required().email().label("Email_id"),
        order_number: Joi.string().required().label("Order number"),
    });
    const dataToValidate = {
        query: query,
        order_number: order_number,
        email_id: email_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {
        try {
            const order_id = order_number.split('-');
            const checkOrderExists = await OrderItem.findOne({ where: { id: order_id[0], order_id: order_id[2] } });
            if (checkOrderExists == null || process.env.ORDERID != order_id[1]) {
                res.status(409).send({
                    message: 'Please Enter Valid Order Number',
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const contactUs = await ContactUsModel.create({
                    query_id: query,
                    order_number: order_id[0],
                    email_id: email_id,
                    query: message,
                    created_by: user_id,
                    created_at: getCurrentDateTime(),
                });
                // let data = qs.stringify({
                // to: email_id,
                // subject: "Contact Us",
                // msg_detail: email_id + " have contacted you for inquiry.",
                // });

                // const config = {
                // method: "post",
                // url: process.env.SITE_URL + "send_mail_node_api",
                // data: data,
                // };
                const user = await User.findOne({
                    attributes: ['email', 'userfullname'],
                    where: {
                        id: user_id
                    }
                });
                const query_user = await QueryList.findOne({
                    attributes: ['query'],
                    where: {
                        id: query,
                    }
                });

                let data_email = qs.stringify({
                    'to': user.email,
                    'subject': `Automatic Reply: ${query_user.query}`,

                });

                const config = {
                    method: 'post',
                    url: process.env.SITE_URL + 'query_mail',
                    data: data_email
                };
                const response = await axios(config);


                // const template_email = await EmailTemplate.findOne({where:{
                //     mail_type:'ContactUsEmail'
                // }});
                // var contact_mail = template_email.message.replace('[NAME]', user.userfullname);
                // let data = qs.stringify({
                //     'to': email_id,
                //     'subject': template_email.subject.replace('[Query]', 'Contact Us'),
                //     'msg_detail': contact_mail,
                //     });
                // const config = {
                //     method: 'post',
                //     url: process.env.SITE_URL+'send_mail_node_api',
                //     data: data
                // };
                // const response = await axios(config);

                // sendEmail(user, 'ContactUsEmail', query_user);

                if (!contactUs) {
                    res.status(202).send({
                        message: process.env.NOT_INSERTED_MSG,
                        error: true,
                        success: false,
                        status: "0",
                    });
                } else {
                    res.status(200).send({
                        message: process.env.INSERTED_MSG,
                        error: false,
                        success: true,
                        status: "1",
                        data: contactUs,
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                message_err: error.message,
                error: true,
                success: false,
                status: "0",
            });
        }
    }
};

//get product detail color wise product list start
const GetProductColorWiseProduct = async (req, res) => {
    const color_id = req.body.color_id;
    const user_id = req.body.user_id || 0;
    try {

        const productAttribute = await ProductAttributes.findAll({
            where: { attr_val_id: color_id, attr_type_id: 2 },
            attributes: ['product_id'],
            required: false,
        });
        var prIdArr = productAttribute.map(variant => variant.product_id);

        var pcondi = {
            id: { [Op.in]: prIdArr },
            status: '1',
            is_deleted: '0'
        };
        const products = await Product.findAll({
            limit: 10,
            where: pcondi,
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            order: [
                ['stock_quantity', 'DESC'],
            ]
        });

        if (!products) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                product_path: process.env.SITE_URL + 'uploads/products/',
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get product detail color wise product list end

// cart gst info start
const cartGSTaddUpdate = async (req, res) => {
    const user_id = req.userId;
    const gst_number = req.body.gst_number;
    const company_name = req.body.company_name;
    const company_address = req.body.company_address;

    const schema = Joi.object().keys({
        gst_number: Joi.string().required().label("gst_number"),
        company_name: Joi.string().required().label("company_name"),
        company_address: Joi.string().required().label("company_address"),
    });
    const dataToValidate = {
        gst_number: gst_number,
        company_name: company_name,
        company_address: company_address,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {

        const ValidGSt = await verifyGST(gst_number);

        if (!ValidGSt) {
            return res.status(403).send({
                message: "Invalid GST Number",
                error: true,
                success: false,
                status: "0",
            });
        }
        try {
            const existingDetails = await UserAddress.findOne({
                where: {
                    user_id: user_id,
                    is_default: "1",
                },
            });

            if (existingDetails) {
                const updateDetails = await UserAddress.update(
                    {
                        gst_number: gst_number,
                        company_name: company_name,
                        company_address: company_address,
                    },
                    {
                        where: {
                            user_id: user_id,
                            is_default: "1",
                        },
                    }
                );

                if (updateDetails) {
                    res.status(200).send({
                        message: process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: "1",
                        data: updateDetails,
                    });
                }
            } else {
                const addDetails = await UserAddress.create({
                    user_id: user_id,
                    gst_number: gst_number,
                    company_name: company_name,
                    company_address: company_address,
                    is_default: "1",
                });

                if (addDetails) {
                    res.status(200).send({
                        message: process.env.INSERTED_MSG,
                        error: false,
                        success: true,
                        status: "1",
                        data: addDetails,
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: "0",
            });
        }
    }
};

const cartGSTDetail = async (req, res) => {
    const user_id = req.userId;
    try {
        const GSTDetail = await UserAddress.findOne({
            where: {
                user_id: user_id,
                is_default: "1",
            },
            attributes: ['id', 'gst_number', 'company_name', 'company_address']
        });

        if (GSTDetail) {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                data: GSTDetail,
            });
        } else {
            return res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: "0",
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: "0",
        });
    }
}
// cart gst info end


// Product list by discount
// const GetProductsByDiscount = async (req, res) => {
//     const user_id = req.body.user_id || 0;
//     const slug = req.body.slug || 'bigsavings';
//     try {
//         var slider_details = await AssignPageSlider.findOne({
//             attributes: ['page_slider_id'],
//             required: false,
//             where: { type: '3', category_menu_id: 2 },
//             include: [
//                 {
//                     model: PageSlider,
//                     as: 'page_slider',
//                     attributes: ['id', 'title'],
//                     required: false,
//                     include: [
//                         {
//                             model: PageSliderImages,
//                             as: 'page_slider_images',
//                             attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
//                             required: false,
//                         },
//                     ],
//                 },
//             ],

//         });
//         const discountedProduct = await Product.findAll({
//             // order: [['discount','DESC']],
//             //order: [['stock_quantity', 'DESC'],['discount', 'DESC']],
//             order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
//             attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'discount', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
//                 // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
//                 sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
//                 'is_wishlist'
//             ]],
//             include: [
//                 {
//                     model: ProductMedia,
//                     as: 'productimages',
//                     attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
//                     //where: { is_default: '1'},
//                     limit: 2,
//                     required: false,
//                 },
//                 {
//                     model: Wishlist,
//                     as: 'wishlist',
//                     attributes: ['id'],
//                     where: { user_id: user_id },
//                     required: false,
//                 },
//                 {
//                     model: SiteSellerProducts,
//                     as: 'seller_product',
//                     attributes: ['seller_id'],
//                     where: { seller_id: 3 },
//                     required: true,
//                 }
//             ],
//             where: {
//                 is_home_new_arrival: '1',
//                 status: '1',
//                 is_deleted: '0',
//                 // stock_quantity: {
//                 //     [sequelize.Op.gt]: 0
//                 // }
//             },
//         });
//         const maxpriceproducts = await Product.findOne({
//             where: {
//                 is_home_new_arrival: '1',
//                 status: '1',
//                 is_deleted: '0',
//                 stock_quantity: {
//                     [sequelize.Op.gt]: 0
//                 }
//             },
//             attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
//             order: [
//                 ['price', 'DESC'],
//             ]
//         });
//         var maxpriceVal = 0;
//         if (maxpriceproducts) {
//             var maxpriceVal = maxpriceproducts['price'];
//         }
//         if (discountedProduct == 0) {
//             res.status(202).send({
//                 message: process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         } else {
//             res.status(200).send({
//                 message: process.env.SUCCESS_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 page_slider: process.env.SITE_URL + 'uploads/page_slider/',
//                 path: process.env.SITE_URL + 'uploads/products/',
//                 slug: slug,
//                 max_price: maxpriceVal,
//                 slider_details: slider_details,
//                 data: discountedProduct
//             });
//         }
//     } catch (error) {
//         res.status(500).send({
//             message: error,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }

const GetProductsByDiscount = async (req, res) => {
    const user_id = req.body.user_id || 0;
    const slug = req.body.slug || 'bigsavings';
    try {
        var slider_details = await AssignPageSlider.findOne({
            attributes: ['page_slider_id'],
            required: false,
            where: { type: '3', category_menu_id: 2 },
            include: [
                {
                    model: PageSlider,
                    as: 'page_slider',
                    attributes: ['id', 'title'],
                    required: false,
                    include: [
                        {
                            model: PageSliderImages,
                            as: 'page_slider_images',
                            attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                            required: false,
                        },
                    ],
                },
            ],

        });
        const discountedProduct = await Product.findAll({
            // order: [['discount','DESC']],
            //order: [['stock_quantity', 'DESC'],['discount', 'DESC']],
            // order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'discount', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ]],

            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const maxpriceproducts = await Product.findOne({
            where: {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ]
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }
        if (discountedProduct == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                path: process.env.SITE_URL + 'uploads/products/',
                slug: slug,
                max_price: maxpriceVal,
                slider_details: slider_details,
                data: discountedProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const GetProductsBigSaving = async (req, res) => {
    const user_id = req.body.user_id || 0;
    const slug = req.body.slug || 'bigsavings';
    try {
        const discountedProduct = await Product.findAll({
            limit: 10,
            order: [['discount', 'DESC']],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'discount', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ]],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });

        if (discountedProduct == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: discountedProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}


//get faq list by search
const getSearchData = async (req, res) => {
    const search_for = req.body.search_for;
    const search_data = req.body.search_data;
    const schema = Joi.object().keys({
        search_for: Joi.number().required().label("Search For"),
        search_data: Joi.string().required().label("Search Keyword"),
    });
    const dataToValidate = {
        search_for: search_for,
        search_data: search_data,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const faq = await FaqCategory.findAll({
                limit: 10,
                order: [['id', 'ASC']],
                attributes: ['id', 'name'],
                where: {
                    // name: { [Op.like]: `%${req.body.search_data}%` },
                    status: '1',
                    product_display: '0',
                    type: search_for
                },
                include: [{
                    model: Faq,
                    as: "faq",
                    attributes: ['id', 'question', 'answer'],
                    limit: 10,
                    order: [['id', 'DESC']],
                    where: {
                        [Op.or]: [
                            { question: { [Op.like]: `%${search_data}%` } },
                            { answer: { [Op.like]: `%${search_data}%` } },
                        ],
                        // question: { [Op.like]: `%${req.body.search_data}%` },
                        // answer: { [Op.like]: `%${req.body.search_data}%` },
                        status: '1'
                    },
                    // required: false
                }]
            });
            if (faq == 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: faq
                });
            }
        } catch (error) {
            res.status(500).send({
                message: error.message,
                message1: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }

    }
}
//get faq search

//get product discount
// const GetProductsDiscountList = async (req, res) => {
//     const slug = req.body.slug;
//     try {
//         var categories = await NavigationMenu.findOne({
//             where: {
//                 slug:slug,
//                 type:3
//             },
//             attributes:['id','menu_id']
//         });
//         if(categories) {
//             const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
//             var catIds = [categories['menu_id']].concat(subcategoryIds);
//         } else {
//             var catIds = [];
//         }

//         var pcondi = {
//             [Op.or]: catIds.map(catId => ({ [Op.or]: [
//                 { category_id: catId.toString() },
//                 { category_id: { [Op.like]: `%,${catId}` } },
//                 { category_id: { [Op.like]: `${catId},%` } }
//               ]  })),
//             status: '1',
//             is_deleted: '0'
//         };

//         const products = await Product.findAll({
//             where: pcondi,
//             attributes:['discount'],
//             group:['discount']
//         });
//         const discountArr = products.map(product => product.discount);

//         const discountRange = await ProductDiscountRange.findAll({
//             where: {
//                 [Op.or]: discountArr.map(discount => ({
//                     [Op.and]: [
//                         { from_discount_val: { [Op.lt]: discount } }, 
//                         { to_discount_val: { [Op.gte]: discount } } 
//                     ]
//                 }))
//             },
//             attributes:['from_discount_val','to_discount_val']
//         });
//         if (discountRange == 0) {
//             res.status(202).send({
//                 message: process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         }else{
//             res.status(200).send({
//                 message: process.env.SUCCESS_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 data: discountRange
//             });
//         }
//     } catch(error) {
//         res.status(500).send({
//             message: process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }
const GetProductsDiscountList = async (req, res) => {
    const slug = req.body.slug;
    const keyword = req.body.keyword || 0;
    const menu_product = req.body.menu_product || 0;
    try {
        const colorData = await ProductAttributeValue.findOne({
            where: { slug: slug, prod_attr_type_id: 2 },
            attributes: ['id'],
            required: false,
        });

        let CollectionMasterArray = [];
        let slugIdInMasterCollection = await HomeCollectionModel.findOne({
            where: { slug: slug, status: '1' },
            attributes: ['id', ['collection_name', 'name'], ['collection_image', 'image'], 'slug']
        })
    

        if (slug == 'newarrival') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            };

        } else if (slug == 'bestseller') {
            var pcondi = {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0'
            };
        } else if (slug == 'finestProduct') {
            var pcondi = {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
            };
        } else if (slug == 'bigsavings') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
            };
        } else if (colorData) {
            const color_id = colorData ? colorData['id'] : 0;
            const productAttribute = await ProductAttributes.findAll({
                where: { attr_val_id: color_id, attr_type_id: 2 },
                attributes: ['product_id'],
                required: false,
            });
            var prIdArr = productAttribute.map(variant => variant.product_id);
            var pcondi = {
                id: { [Op.in]: prIdArr },
                status: '1',
                is_deleted: '0'
            };
        } else if (slug == 'allProduct') {
            var pcondi = {
                product_name: { [Op.like]: `%${keyword}%` },
                status: '1',
                is_deleted: '0'
            };
        }    else if (slugIdInMasterCollection) {
            slugIdInMasterCollection = slugIdInMasterCollection.toJSON();
            slugIdInMasterCollection.assign_slider = null
            const result = await CollectionAssignProductsModel.findAll({
                where: {
                    collection_id: slugIdInMasterCollection.id,
                    status: '1'
                },
                attributes: ['product_id'],
            });
            CollectionMasterArray = result.map(data => data.product_id);
            var pcondi = {
                id: {
                    [Op.in]: CollectionMasterArray.length > 0
                        ? CollectionMasterArray
                        : [0],
                },
                status: '1',
                is_deleted: '0'
            };
        } else {
            if (menu_product == 'menu_product') {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 1
                    },
                    attributes: ['id', 'menu_id']
                });
            } else {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 3
                    },
                    attributes: ['id', 'menu_id']
                });
            }
            if (categories) {
                const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
                var catIds = [categories['menu_id']].concat(subcategoryIds);
            } else {
                var catIds = [];
            }
            if (slug === 'offers') {
                var pcondi = {
                    status: '1',
                    is_deleted: '0',
                    discount: { [Op.gt]: 0 }
                };
            } else {
                var pcondi = {
                    [Op.or]: catIds.map(catId => ({
                        [Op.or]: [
                            { category_id: catId.toString() }, // Exact match
                            sequelize.literal(`FIND_IN_SET(${catId}, category_id) > 0`) // Match catId in a comma-separated list
                        ]
                    })),
                    status: '1',
                    is_deleted: '0'
                };
            }
        }
        const products = await Product.findAll({
            where: pcondi,
            attributes: ['discount'],
            group: ['discount']
        });
        const discountArr = products.map(product => product.discount);
        const discountRange = await ProductDiscountRange.findAll({
            where: {
                [Op.or]: discountArr.map(discount => ({
                    [Op.and]: [
                        { from_discount_val: { [Op.lt]: discount } },
                        { to_discount_val: { [Op.gte]: discount } }
                    ]
                }))
            },
            attributes: ['from_discount_val', 'to_discount_val']
        });
        if (discountRange == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: discountRange
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get product discount

//get attributes type list start
const GetAttributeTypeList = async (req, res) => {
    try {
        const attributeType = await ProductAttributeType.findAll({
            where: {
                status: '1'
            },
            attributes: ['id', 'attr_type_name']
        });
        if (attributeType == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: attributeType
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get attributes type list end

// get product variant start
const GetPrimaryVariantAttribute = async (req, res) => {
    const product_id = req.body.product_id;
    const attr_type_id = req.body.attr_type_id;
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product")
    });
    const dataToValidate = {
        product_id: product_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const variantGroup = await ProductVariantGroup.findOne({
                where: { product_id: product_id },
                attributes: ['product_id', 'variant_id'],
                required: false,
                include: [
                    {
                        model: Variant,
                        as: 'variants',
                        attributes: ['variant_title', 'attr_type_id'],
                        where: { status: '1' },
                        required: false,
                        include: [
                            {
                                model: ProductAttributeType,
                                as: 'variant_attr_type',
                                attributes: ['attr_type_name'],
                                where: { status: '1' },
                                required: false,
                            }
                        ]
                    }
                ]
            });
            const variantId = variantGroup ? variantGroup['variant_id'] : 0;

            const groupAll = await ProductVariantGroup.findAll({
                where: {
                    variant_id: variantId,
                },
                attributes: ['product_id']
            });
            const prIdArr = groupAll.map(product => product ? product.product_id : null);
            const productColor = await ProductAttributes.findAll({
                where: { product_id: { [Op.in]: prIdArr }, attr_type_id: attr_type_id },
                attributes: ['attr_type_id', 'attr_val_id'],
                group: ['attr_val_id'],
                required: false,
                include: [
                    {
                        model: Product,
                        as: "products",
                        attributes: ['product_slug'],
                        where: {
                            status: '1'
                        },
                    },
                    {
                        model: ProductAttributeValue,
                        as: 'product_attr_value',
                        attributes: ['attr_val_name', 'image'],
                        where: { status: '1' },
                        required: false,
                    }
                ]
            });
            if (productColor == 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0',
                    data: false
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/color_image/',
                    variant_detail: variantGroup,
                    data: productColor
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

// const getVariantWiseAttribute = async(req, res) => {
//     const attr_val_id = req.body.attr_val_id;
//     const attr_second_val_id = req.body.attr_second_val_id;
//     const attr_type_id = req.body.attr_type_id;
//     const variant_id = req.body.variant_id;
//     const schema = Joi.object().keys({
//         attr_val_id: Joi.number().required().label("Color Id"),
//         attr_type_id: Joi.number().required().label("Attribute Type"),
//         variant_id: Joi.number().required().label("Variant Id"),
//     });
//     const dataToValidate = {
//         attr_val_id: attr_val_id,
//         attr_type_id: attr_type_id,
//         variant_id: variant_id,
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(403).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {
//             if(attr_second_val_id) {

//                 const prodByColor = await ProductAttributes.findAll({
//                     attributes:['product_id'],
//                     where:{
//                         attr_val_id:attr_val_id,
//                     }
//                 });
//                 const prIdArr = prodByColor.map(product => product ? product.product_id : null);

//                 const prodByColor1 = await ProductAttributes.findAll({
//                     attributes:['product_id'],
//                     where:{
//                         attr_val_id:attr_second_val_id,
//                     }
//                 });
//                 const prIdArr1 = prodByColor1.map(product => product ? product.product_id : null);

//                 var prIdd = prIdArr.filter(value => prIdArr1.includes(value));

//             } else {
//                 const prodByColor = await ProductAttributes.findAll({
//                     attributes:['product_id'],
//                     where:{
//                         attr_val_id:attr_val_id,
//                     }
//                 });
//                 const prIdArr = prodByColor.map(product => product ? product.product_id : null);
//                 var prIdd = prIdArr;
//             }

//             const checkVeriant = await ProductVariantGroup.findAll({ 
//                 attributes:['product_id'],
//                 where:{
//                     variant_id:variant_id,
//                     product_id: { [Op.in]: prIdd }
//                 },
//             });

//             const checkprIdArr = checkVeriant.map(product => product ? product.product_id : null);
//             const productColor = await ProductAttributes.findAll({
//                 where:{product_id: { [Op.in]: checkprIdArr },attr_type_id: attr_type_id},
//                 attributes: ['attr_type_id','attr_val_id'],
//                 group:['attr_val_id'],
//                 required: false,
//                 include: [
//                     {
//                         model:Product,
//                         as:"products",
//                         attributes:['product_slug','sku'],
//                         where: {
//                             status:'1'},
//                     },
//                     {
//                         model: ProductAttributeValue,
//                         as:'product_attr_value',
//                         attributes: ['attr_val_name','image'],
//                         where: { status: '1'},
//                         required: false,
//                     }
//                 ]
//             });

//             const checkVeriant1 = await ProductVariantGroup.findAll({ 
//                 attributes:['product_id'],
//                 where:{
//                     variant_id:variant_id
//                 },
//             });

//             const checkprIdArr1 = checkVeriant1.map(product => product ? product.product_id : null);
//             const productAllVariant = await ProductAttributes.findAll({
//                 where:{product_id: { [Op.in]: checkprIdArr1 },attr_type_id: attr_type_id},
//                 attributes: ['attr_type_id','attr_val_id'],
//                 group:['attr_val_id'],
//                 required: false,
//                 include: [
//                     {
//                         model:Product,
//                         as:"products",
//                         attributes:['product_slug','sku'],
//                         where: {
//                             status:'1'},
//                     },
//                     {
//                         model: ProductAttributeValue,
//                         as:'product_attr_value',
//                         attributes: ['attr_val_name','image'],
//                         where: { status: '1'},
//                         required: false,
//                     }
//                 ]
//             });

//             if (productColor == 0) {
//                 res.status(202).send({
//                     message: process.env.RECORD_NOT_FOUND,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             }else{
//                 res.status(200).send({
//                     message: process.env.SUCCESS_MSG,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     path: process.env.SITE_URL+'uploads/color_image/',
//                     data: productColor,
//                     all_data:productAllVariant
//                 });
//             }
//         } catch(error) {
//             res.status(500).send({
//                 message:error.message,
//                 message1:process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         } 

// }
// }
// get product variant end

//add Product Notify start

const getVariantWiseAttribute = async (req, res) => {
    const attr_val_id = req.body.attr_val_id;
    //const attr_second_type_id = req.body.attr_second_type_id;
    const attr_second_val_id = req.body.attr_second_val_id;
    const attr_type_id = req.body.attr_type_id;
    const variant_id = req.body.variant_id;
    const schema = Joi.object().keys({
        attr_val_id: Joi.number().required().label("Color Id"),
        attr_type_id: Joi.number().required().label("Attribute Type"),
        variant_id: Joi.number().required().label("Variant Id"),
    });
    const dataToValidate = {
        attr_val_id: attr_val_id,
        attr_type_id: attr_type_id,
        variant_id: variant_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            if (attr_second_val_id) {

                const prodByColor = await ProductAttributes.findAll({
                    attributes: ['product_id'],
                    where: {
                        attr_type_id: attr_type_id,
                    }
                });
                const prIdArr = prodByColor.map(product => product ? product.product_id : null);

                const prodByColor1 = await ProductAttributes.findAll({
                    attributes: ['product_id'],
                    where: {
                        // attr_type_id:attr_second_type_id,
                        attr_val_id: attr_second_val_id,
                    }
                });
                const prIdArr1 = prodByColor1.map(product => product ? product.product_id : null);

                var prIdd = prIdArr.filter(value => prIdArr1.includes(value));

            } else {
                const prodByColor = await ProductAttributes.findAll({
                    attributes: ['product_id'],
                    where: {
                        attr_type_id: attr_type_id,
                    }
                });
                const prIdArr = prodByColor.map(product => product ? product.product_id : null);
                var prIdd = prIdArr;
            }

            const checkVeriant = await ProductVariantGroup.findAll({
                attributes: ['product_id'],
                where: {
                    variant_id: variant_id,
                    product_id: { [Op.in]: prIdd }
                },
            });

            const checkprIdArr = checkVeriant.map(product => product ? product.product_id : null);
            const productColor = await ProductAttributes.findAll({
                where: { product_id: { [Op.in]: checkprIdArr }, attr_type_id: attr_type_id },
                attributes: ['attr_type_id', 'attr_val_id'],
                group: ['attr_val_id'],
                required: false,
                include: [
                    {
                        model: Product,
                        as: "products",
                        attributes: ['product_slug', 'sku'],
                        where: {
                            status: '1'
                        },
                    },
                    {
                        model: ProductAttributeValue,
                        as: 'product_attr_value',
                        attributes: ['attr_val_name', 'image'],
                        where: { status: '1' },
                        required: false,
                    }
                ]
            });

            const checkVeriant1 = await ProductVariantGroup.findAll({
                attributes: ['product_id'],
                where: {
                    variant_id: variant_id,
                    product_id: { [Op.in]: prIdd }
                },
            });

            const checkprIdArr1 = checkVeriant1.map(product => product ? product.product_id : null);
            const productAllVariant = await ProductAttributes.findAll({
                where: { product_id: { [Op.in]: checkprIdArr1 }, attr_type_id: attr_type_id },
                attributes: ['attr_type_id', 'attr_val_id'],
                group: ['attr_val_id'],
                required: false,
                include: [
                    {
                        model: Product,
                        as: "products",
                        attributes: ['product_slug', 'sku'],
                        where: {
                            status: '1'
                        },
                    },
                    {
                        model: ProductAttributeValue,
                        as: 'product_attr_value',
                        attributes: ['attr_val_name', 'image'],
                        where: { status: '1' },
                        required: false,
                    }
                ]
            });

            if (productColor == 0) {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/color_image/',
                    data: productColor,
                    all_data: productAllVariant
                });
            }
        } catch (error) {
            res.status(500).send({
                message: error.message,
                message1: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }

    }
}

const AddProductNotify = async (req, res) => {
    const user_id = req.userId;
    const product_id = req.body.product_id;
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("product_id"),
    });
    const dataToValidate = {
        product_id: product_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {
        try {
            const checkProductNotifyExists = await ProductNotifyModel.findOne({
                where: { product_id: product_id, user_id: user_id },
                attributes: ["id"],
            });

            if (checkProductNotifyExists) {
                return res.status(200).send({
                    message: "Already Notified",
                    error: true,
                    success: false,
                    status: "0",
                    is_notify: '0'
                });

            } else {
                const notify = await ProductNotifyModel.create({
                    user_id: user_id,
                    product_id: product_id,
                    created_at: getCurrentDateTime(),
                    created_by: user_id,
                });

                if (notify) {
                    return res.status(200).send({
                        message: process.env.INSERTED_MSG,
                        error: false,
                        success: true,
                        status: "1",
                        is_notify: '1'
                    });
                }

            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: "0",
            });
        }
    }
}
//add Product Notify End

// get gst information start
const GetGstInformation = async (req, res) => {
    try {
        const user_id = req.userId;
        const userAddresses = await UserAddress.findAll({
            where: {
                user_id: user_id,
                status: '1',
                [sequelize.Op.and]: [
                    { company_name: { [sequelize.Op.not]: '' } },
                    { company_address: { [sequelize.Op.not]: '' } },
                    { gst_number: { [sequelize.Op.not]: '' } }
                ]
            },
            attributes: ['id', 'company_name', 'company_address', 'gst_number'],
        });
        if (userAddresses == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: userAddresses
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get gst information end

// get product detail wise best seller start
const GetBestSellProductWise = async (req, res) => {
    const user_id = req.body.user_id || 0;
    var catIds = JSON.parse(req.body.category_id);
    try {
        var pcondi = {
            [Op.or]: catIds.map(catId => ({
                [Op.or]: [
                    { category_id: catId.toString() },
                    { category_id: { [Op.like]: `%,${catId}` } },
                    { category_id: { [Op.like]: `${catId},%` } }
                ]
            })),
            is_best_seller: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        };
        const bestSellProduct = await Product.findAll({
            limit: 10,
            order: [['stock_quantity', 'DESC']],
            attributes: ['id', 'sold_out_count', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: pcondi,
        });

        if (bestSellProduct.length == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: bestSellProduct
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
// get product detail wise best seller end

const GetMenuAllCategoryProduct = async (req, res) => {
    const slug = req.params.slug;
    const user_id = req.body.user_id || 0;
    try {
        var categories = await NavigationMenu.findOne({
            where: {
                slug: slug,
                type: 1
            },
            attributes: ['id', 'menu_id'],
            include: [
                {
                    model: Menu,
                    as: 'menus',
                    attributes: ['id', 'slug', ['menu_name', 'name'], 'title', 'description', 'image'],
                    required: false,
                    include: [
                        {
                            model: AssignPageSlider,
                            as: 'assign_slider',
                            attributes: ['page_slider_id'],
                            required: false,
                            where: { type: '1' },
                            include: [
                                {
                                    model: PageSlider,
                                    as: 'page_slider',
                                    attributes: ['id', 'title'],
                                    required: false,
                                    include: [
                                        {
                                            model: PageSliderImages,
                                            as: 'page_slider_images',
                                            attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                                            required: false,
                                        },
                                    ],
                                },
                            ],
                        }
                    ],
                }
            ],
        });
        if (categories) {
            const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
            var catIds = subcategoryIds;
        } else {
            var catIds = [];
        }

        var pcondi = {
            [Op.or]: catIds.map(catId => ({
                [Op.or]: [
                    { category_id: catId.toString() }, // Check for the exact value
                    { category_id: { [Op.like]: `%,${catId}` } }, // Check if the value is at the end of a comma-separated list
                    { category_id: { [Op.like]: `${catId},%` } } // Check if the value is at the start of a comma-separated list
                ]
            })),
            status: '1',
            is_deleted: '0',
        };
        const products = await Product.findAll({
            order: [['stock_quantity', 'DESC']],
            where: pcondi,
            attributes: ['id', 'category_id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
        });

        const maxpriceproducts = await Product.findOne({
            where: pcondi,
            attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
            order: [
                ['price', 'DESC'],
            ]
        });
        var maxpriceVal = 0;
        if (maxpriceproducts) {
            var maxpriceVal = maxpriceproducts['price'];
        }

        if (!categories) {
            res.status(204).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                category_path: process.env.SITE_URL + 'uploads/category/',
                page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                product_path: process.env.SITE_URL + 'uploads/products/',
                max_price: maxpriceVal,
                categories: categories,
                data: products,
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const GetCountryByIP = async (req, res) => {
    const ip = req.body.ip || 0;
    var countryCode = req.body.countryCode || 0;
    try {
        if (ip) {
            const ipInfoConfig = {
                method: 'get',
                url: `https://ipinfo.io/${ip}/json`,
            };
            const response = await axios.request(ipInfoConfig);
            var countryCode = response.data.country;
        }
        const countryDetailsConfig = {
            method: 'get',
            url: `https://restcountries.com/v3.1/alpha/${countryCode}`,
        };
        const countryResponse = await axios.request(countryDetailsConfig);
        const countryInfo = countryResponse.data[0];
        const fullName = countryInfo.name.common;
        const flagUrl = countryInfo.flags.svg;
        const currencyCode = Object.keys(countryInfo.currencies)[0];
        const currencySymbol = countryInfo.currencies[currencyCode]?.symbol;
        const exchangeRateResponse = await axios.get(`https://api.exchangerate-api.com/v4/latest/USD`);
        const exchangeRates = exchangeRateResponse.data.rates;
        const exchangeRate = exchangeRates[currencyCode];
        res.status(200).send({
            fullName,
            flagUrl,
            countryCode,
            currencyCode,
            currencySymbol,
            exchangeRate,
        });

    } catch (error) {
        console.log(error);
        res.status(500).send({ error: 'An error occurred' });
    }
};

const GetProductTypeList = async (req, res) => {
    const slug = req.body.slug;
    const keyword = req.body.keyword || 0;
    const menu_product = req.body.menu_product || 0;
    try {
        const colorData = await ProductAttributeValue.findOne({
            where: { slug: slug, prod_attr_type_id: 2 },
            attributes: ['id'],
            required: false,
        });
        
        let CollectionMasterArray = [];
        let slugIdInMasterCollection = await HomeCollectionModel.findOne({
            where: { slug: slug, status: '1' },
            attributes: ['id', ['collection_name', 'name'], ['collection_image', 'image'], 'slug']
        })

        if (slug == 'newarrival') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
            };

        } else if (slug == 'bestseller') {
            var pcondi = {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0'
            };
        } else if (slug == 'finestProduct') {
            var pcondi = {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
            };
        } else if (slug == 'bigsavings') {
            var pcondi = {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
            };

        } else if (slug == 'allProduct') {
            var pcondi = {
                product_name: { [Op.like]: `%${keyword}%` },
                status: '1',
                is_deleted: '0'
            };
        } else if (colorData) {

            const color_id = colorData ? colorData['id'] : 0;
            const productAttribute = await ProductAttributes.findAll({
                where: { attr_val_id: color_id, attr_type_id: 2 },
                attributes: ['product_id'],
                required: false,
            });

            var prIdArr = productAttribute.map(variant => variant.product_id);

            var pcondi = {
                id: { [Op.in]: prIdArr },
                status: '1',
                is_deleted: '0'
            };

        } else if (slugIdInMasterCollection) {
            slugIdInMasterCollection = slugIdInMasterCollection.toJSON();
            slugIdInMasterCollection.assign_slider = null
            const result = await CollectionAssignProductsModel.findAll({
                where: {
                    collection_id: slugIdInMasterCollection.id,
                    status: '1'
                },
                attributes: ['product_id'],
            });
            CollectionMasterArray = result.map(data => data.product_id);
    
            var pcondi = {
                id: {
                    [Op.in]: CollectionMasterArray.length > 0
                        ? CollectionMasterArray
                        : [0],
                },
                status: '1',
                is_deleted: '0'
            };
        }else {
            if (menu_product == 'menu_product') {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 1
                    },
                    attributes: ['id', 'menu_id']
                });
            } else {
                var categories = await NavigationMenu.findOne({
                    where: {
                        slug: slug,
                        type: 3
                    },
                    attributes: ['id', 'menu_id']
                });
            }
            if (categories) {
                const subcategoryIds = await getSubcategoriesRecursive(categories['id']);
                var catIds = [categories['menu_id']].concat(subcategoryIds);
            } else {
                var catIds = [];
            }
            if (slug === 'offers') {
                var pcondi = {
                    status: '1',
                    is_deleted: '0',
                    discount: { [Op.gt]: 0 }
                };
            } else {
                var pcondi = {
                    [Op.or]: catIds.map(catId => ({
                        [Op.or]: [
                            { category_id: catId.toString() }, // Exact match
                            sequelize.literal(`FIND_IN_SET(${catId}, category_id) > 0`) // Match catId in a comma-separated list
                        ]
                    })),
                    status: '1',
                    is_deleted: '0'
                };
            }
        }

        var products = await Product.findAll({
            where: pcondi,
            attributes: ['type_id'],
            include: [
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
        });
        const product_type = products.map(product => product ? product.type_id : null);
        const type = await ProductType.findAll({
            where: {
                id: { [Op.in]: product_type },
                status: '1'
            },
            attributes: ['id', 'type_name']
        });
        if (type == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: type
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const GetSitemap = async (req, res) => {
    try {
        const files = await FileModel.findAll({
            attributes: ["file_name"]
        });

        const fileNames = files.map(file => file.file_name);

        const staticFiles = [
            'sitemap.xml',
            'sitemap_pages.xml',
            'sitemap_category.xml',
            'sitemap_blogs.xml',
            'sitemap_images.xml'
        ]


        const allFiles = [...fileNames, ...staticFiles].map(fileName => ({
            fileName: fileName
        }));

        res.status(200).send({
            message: process.env.SUCCESS_MSG,
            error: false,
            success: true,
            status: '1',
            baseUrl: process.env.SITE_URL + "uploads/sitemap/",
            fileNames: allFiles
        });

    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
};

//get cart amount detail start
// const GetCartAmountDetail = async (req, res) => {
//     try {
//         const user_id = req.userId;
//         const buy_now_data = req.body.buy_now || '';
//         const buy_now = await BuyNow.findAll({
//             where: {
//                 user_id: user_id,
//                 status:1
//             },
//             // attributes: ['id'],
//             attributes: ['id', 'user_id', 'product_id','quantity', 'amount', 'discount_amt', 'subtotal_amount'],
//             include: [
//                 {
//                     model: Product,
//                     as: 'product',
//                     attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price','stock_quantity','image_alt','weight','unit','is_shipping','shipping_amount_type','shipping_charge'],
//                     required: false,
//                     include:[
//                         {
//                             model:ProductMedia,
//                             as:'productimage',
//                             attributes: ['file_name_120_x_120'],
//                             where: {is_default: '1'},
//                             required: false,
//                         }
//                     ]
//                 }
//             ]
//         });
//         if(buy_now.length > 0 && buy_now_data == 'buy_now') {
//             var carts = buy_now;
//         } else {
//             var carts = await Cart.findAll({
//                 where: {
//                     user_id: user_id,
//                     status:1
//                 },
//                 attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount'],
//                 include: [
//                     {
//                         model: Product,
//                         as: 'product',
//                         attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price','stock_quantity','image_alt','weight','unit','is_shipping','shipping_amount_type','shipping_charge'],
//                         required: false,
//                         include:[
//                             {
//                                 model:ProductMedia,
//                                 as:'productimage',
//                                 attributes: ['file_name_120_x_120'],
//                                 where: {is_default: '1'},
//                                 required: false,
//                             }
//                         ]

//                     }
//                 ]
//             });
//         }

//         if (carts == 0) {
//             res.status(202).send({
//                 message: process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         }else{
//             const setting = await Setting.findOne({
//                 attributes:['max_shipping_amount']
//             });
//             let bag_mrp = 0;
//             let subtotal_amount = 0;
//             let shipping_amt = 0;
//             if (carts) {
//                 for (const cart of carts) {
//                     if (cart.product) {
//                         bag_mrp += parseFloat(cart.product.compare_price) * cart.quantity;
//                         subtotal_amount += parseFloat(cart.subtotal_amount);
//                         var shipping_amount_type = cart.product.shipping_amount_type;
//                         if(shipping_amount_type == 1) {
//                             shipping_amt += parseFloat(cart.product.shipping_charge);
//                         } else if(shipping_amount_type == 2){
//                             shipping_amt += parseFloat(cart.subtotal_amount) * parseFloat(cart.product.shipping_charge) / 100;
//                         }
//                     }
//                 }
//             }

//             let kairaus_saving = bag_mrp - subtotal_amount;

//             if(buy_now.length > 0) {
//                 var order_discount = 0;
//             } else {
//                 const orderdiscount = await OrderDiscountCoupon.findOne({
//                     where: {
//                         user_id: user_id,
//                         discount_type:'order'
//                     },
//                     attributes: ['discount_amt']
//                 });
//                 var order_discount = orderdiscount ? parseFloat(orderdiscount.discount_amt) : 0;
//             }

//             const forderdiscount = await OrderDiscountCoupon.findOne({
//                 where: {
//                     user_id: user_id,
//                     discount_type:'first_order'
//                 },
//                 attributes: ['discount_amt']
//             });
//             var first_order_discount = forderdiscount ? parseFloat(forderdiscount.discount_amt) : 0;

//             const rewarddiscount = await OrderDiscountCoupon.findOne({
//                 where: {
//                     user_id: user_id,
//                     discount_type:'reward'
//                 },
//                 attributes: ['discount_amt']
//             });
//             var reward_discount = rewarddiscount ? parseFloat(rewarddiscount.discount_amt) : 0;

//             var total_discount = order_discount + first_order_discount;
//             var total_amtt = subtotal_amount - total_discount;

//             if (rewarddiscount && reward_discount > total_amtt && buy_now_data != 'buy_now') {
//                 var total = reward_discount - total_amtt;
//                 var all_amt = reward_discount - total;
//                 reward_discount = all_amt;
//                 var total_amt = total_amtt - reward_discount;
//             } else {
//                 total_amtt = total_amtt - reward_discount;
//                 var total_amt = total_amtt;
//             }


//             var max_shipping_amount = setting ? parseFloat(setting.max_shipping_amount) : 0;
//             if(max_shipping_amount > total_amtt) {
//                 var shipping_charge = parseFloat(shipping_amt);
//             } else {
//                 var shipping_charge = 0;
//             }
//             var total_amt = total_amtt + shipping_charge;
//             const price_data = {
//                 bag_mrp: bag_mrp,
//                 kairaus_saving:kairaus_saving,
//                 order_discount:order_discount,
//                 first_order_discount:first_order_discount,
//                 reward_discount:reward_discount,
//                 shipping_amt:shipping_charge,
//                 total_amt:total_amt,
//                 total_items: carts.length,
//             }

//             res.status(200).send({
//                 message: process.env.SUCCESS_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 path:process.env.SITE_URL+'uploads/products/',
//                 cart_list:carts,
//                 price_data:price_data,
//             });
//         }
//     } catch(error) {
//         res.status(500).send({
//             message:process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }


// update product wise coupon end
const GetCartAmountList = async (req, res) => {
    try {
        const user_id = req.userId;
        var carts = await Cart.findAll({
            where: {
                user_id: user_id,
                status: 1
            },
            attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'currency_symbol', 'currency_rate', 'quantity', 'amount', 'discount_amt', 'subtotal_amount', 'currency_code', 'currency_symbol'],
            include: [
                {
                    model: Product,
                    as: 'product',
                    attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'usd_price', 'usd_compare_price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge'],
                    required: false,
                }
            ]
        });

        if (carts.length === 0) {
            var carts_data = await Cart.findAll({
                where: {
                    user_id: user_id,
                },
                attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount'],
            });
            if (carts_data.length > 0) {
                return res.status(202).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    bag_mrp: 0,
                    kairaus_saving: 0,
                    order_discount: 0,
                    orderdiscount_coupon_code: 0,
                    first_order_discount: 0,
                    first_order_discount_coude: 0,
                    reward_discount: 0,
                    total_amt: 0,
                });
            } else {
                return res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }

        } else {
            let bag_mrp = 0;
            let subtotal_amount = 0;
            let shipping_amt = 0;
            let currency_symbol = '';
            for (const cart of carts) {
                if (cart.product) {
                    // bag_mrp += parseFloat(cart.product.compare_price) * cart.quantity;
                    currency_symbol = cart.currency_symbol
                    if (cart.currency_code == "INR") {
                        code_c = cart.currency_code;
                        bag_mrp += parseFloat(cart.product.compare_price) * cart.quantity;
                        subtotal_amount += parseFloat(cart.subtotal_amount);
                    } else {
                        bag_mrp += parseFloat(cart.product.usd_compare_price * cart.currency_rate) * cart.quantity;
                        subtotal_amount += parseFloat(cart.subtotal_amount * cart.currency_rate);
                    }

                    var shipping_amount_type = cart.product.shipping_amount_type;
                    if (shipping_amount_type == 1) {
                        shipping_amt += parseFloat(cart.product.shipping_charge);
                    } else if (shipping_amount_type == 2) {
                        shipping_amt += parseFloat(cart.subtotal_amount) * parseFloat(cart.product.shipping_charge) / 100;
                    }
                }
            }
            //update discount
            await updateDiscount(user_id, subtotal_amount);
            //end
            let kairaus_saving = bag_mrp - subtotal_amount;

            const orderdiscount = await OrderDiscountCoupon.findAll({
                where: {
                    user_id: user_id,
                    discount_mode: 'cart',
                    discount_type: 'order'
                },
                attributes: ['discount_amt'],
                include: [
                    {
                        model: Coupon,
                        as: 'applied_coupon_code',
                        attributes: ['id', 'coupon_code'],
                        where: {
                            status: {
                                [Op.in]: ['1', '2'],
                            },
                            is_deleted: 0,
                            number_of_uses: {
                                [Op.gt]: 0,
                            },
                            from_date: {
                                [Op.lte]: getCurrentDateTime()
                            },
                            to_date: {
                                [Op.gte]: getCurrentDateTime()
                            }
                        },
                        required: false,
                    }
                ],

            });
            const discountIdString = orderdiscount.map(item => item?.applied_coupon_code?.coupon_code);
            const discountIdArray = discountIdString.join(',');

            // var order_discount = orderdiscount ? parseFloat(orderdiscount.discount_amt) : 0;
            // const result = await OrderDiscountCoupon.findOne({
            //     where: {
            //         user_id: user_id,
            //         discount_type: 'order'
            //     },
            //     attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
            //     include: [
            //         {
            //             model: Coupon,
            //             as: 'applied_coupon_code',
            //             attributes: ['id', 'coupon_code'],
            //             where: {
            //                 status: {
            //                     [Op.in]: ['1', '2'],
            //                 },
            //                 is_deleted: 0,
            //                 number_of_uses: {
            //                     [Op.gt]: 0,
            //                 },
            //                 from_date: {
            //                     [Op.lte]: getCurrentDateTime()
            //                 },
            //                 to_date: {
            //                     [Op.gte]: getCurrentDateTime()
            //                 }
            //             },
            //             required: false,
            //         }
            //     ],
            // });
            // var order_discount = result?.applied_coupon_code ? parseFloat(result.total_subtotal_amount) : 0;

            const result = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: user_id,
                    discount_mode: 'cart',
                    discount_type: 'order'
                },
                attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
                include: [
                    {
                        model: Coupon,
                        as: 'applied_coupon_code',
                        attributes: ['id', 'coupon_code'],
                        where: {
                            status: {
                                [Op.in]: ['1', '2'],
                            },
                            is_deleted: 0,
                            number_of_uses: {
                                [Op.gt]: 0,
                            },
                            from_date: {
                                [Op.lte]: getCurrentDateTime()
                            },
                            to_date: {
                                [Op.gte]: getCurrentDateTime()
                            }
                        },
                        required: false,
                    }
                ],
            });

            const order_discount = result && result.applied_coupon_code ? parseFloat(result.get('total_subtotal_amount')) : 0;

            const forderdiscount = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: user_id,
                    applied_status: 1,
                    discount_mode: 'cart',
                    discount_type: 'first_order'
                },
                attributes: ['discount_amt'],
                include: [
                    {
                        model: Coupon,
                        as: 'applied_coupon_code',
                        attributes: ['id', 'coupon_code'],
                        where: {
                            status: {
                                [Op.in]: ['1', '2'],
                            },
                            is_deleted: 0,
                            number_of_uses: {
                                [Op.gt]: 0,
                            },
                            from_date: {
                                [Op.lte]: getCurrentDateTime()
                            },
                            to_date: {
                                [Op.gte]: getCurrentDateTime()
                            }
                        },
                        required: false,
                    }
                ],
            });
            var first_order_discount = forderdiscount?.applied_coupon_code ? parseFloat(forderdiscount.discount_amt) : 0;

            const rewarddiscount = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: user_id,
                    discount_mode: 'cart',
                    discount_type: 'reward'
                },
                attributes: ['discount_amt'],
                include: [
                    {
                        model: Coupon,
                        as: 'applied_coupon_code',
                        attributes: ['id', 'coupon_code'],
                        required: false,
                    }
                ],
            });

            var reward_discount = rewarddiscount ? parseFloat(rewarddiscount.discount_amt) : 0;

            // var total_discount = order_discount + first_order_discount;
            var total_discount = order_discount + first_order_discount;

            var total_amtt = subtotal_amount - total_discount;

            if (rewarddiscount && reward_discount > total_amtt) {
                var total = reward_discount - total_amtt;
                var all_amt = reward_discount - total;
                reward_discount = all_amt;
                var total_amt = total_amtt - reward_discount;
            } else {
                total_amtt = total_amtt - reward_discount;
                var total_amt = total_amtt;
            }

            const totalQuantity = carts.reduce((sum, cart) => {
                return sum + cart.quantity;
            }, 0);
            const setting = await Setting.findOne({
                attributes: ['max_shipping_amount']
            });
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                addMore_Price: total_amt > setting.max_shipping_amount ? 0 : Math.round(setting.max_shipping_amount - total_amt),
                total_item: totalQuantity || 0,
                bag_mrp: Math.round(bag_mrp) || 0,
                kairaus_saving: Math.round(kairaus_saving) || 0,
                order_discount: Math.round(order_discount) || 0,
                orderdiscount_coupon_code: discountIdArray,
                first_order_discount: Math.round(first_order_discount) || 0,
                first_order_discount_coude: forderdiscount ? forderdiscount.applied_coupon_code.coupon_code : '',
                reward_discount: reward_discount || 0,
                total_amt: Math.round(total_amt) || 0,
                // carts:carts,
                currency_symbol: currency_symbol || '',
                user_id: user_id
            });
            // var minus_10_per = 0;
            // var disco = 0;
            // if (total_amt) {
            //     // var amount_dis = (total_amt - first_order_discount);
            //     disco = (total_amt * 10 / 100);
            //     minus_10_per = (total_amt - disco);

            // }

            // return res.status(200).send({
            //     message: process.env.SUCCESS_MSG,
            //     error: false,
            //     success: true,
            //     status: '1',
            //     total_item: totalQuantity || 0,
            //     bag_mrp: bag_mrp || 0,
            //     kairaus_saving: kairaus_saving || 0,
            //     order_discount: Math.round(disco) || 0,
            //     orderdiscount_coupon_code: orderdiscount?.applied_coupon_code ? orderdiscount.applied_coupon_code.coupon_code : '',
            //     first_order_discount: first_order_discount || 0,
            //     first_order_discount_coude: forderdiscount ? forderdiscount.applied_coupon_code.coupon_code : '',
            //     reward_discount: reward_discount || 0,
            //     total_amt: Math.round(minus_10_per) || 0,
            //     // carts:carts,
            //     currency_symbol: currency_symbol || '',
            //     user_id: user_id
            // });
        }
    } catch (error) {
        return res.status(500).send({
            message: process.env.ERROR_MSG,
            error1: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
};
const GetCartAmountDetail = async (req, res) => {
    try {
        const user_id = req.userId;
        const buy_now_data = req.body.buy_now || '';
        var carts = 0;
        if (buy_now_data == 'buy_now') {
            var carts = await BuyNow.findAll({
                where: {
                    user_id: user_id,
                    status: 1
                },
                attributes: ['id', 'user_id', 'product_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount', 'currency_rate', 'usd_amount', 'currency_symbol', 'currency_code'],
                include: [
                    {
                        model: Product,
                        as: 'product',
                        attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'usd_price', 'usd_compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge'],
                        required: false,
                        include: [
                            {
                                model: ProductMedia,
                                as: 'productimage',
                                attributes: ['file_name_120_x_120'],
                                where: { is_default: '1',file_type:'image' },
                                required: false,
                            }
                        ]
                    }
                ]
            });
        } else if (buy_now_data == 'cart') {
            var carts = await Cart.findAll({
                where: {
                    user_id: user_id,
                    status: 1
                },
                attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount', 'currency_rate', 'usd_amount', 'currency_symbol', 'currency_code'],
                include: [
                    {
                        model: Product,
                        as: 'product',
                        attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'usd_price', 'usd_compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'product_buffer_days'],
                        required: false,
                        include: [
                            {
                                model: ProductMedia,
                                as: 'productimage',
                                attributes: ['file_name_120_x_120'],
                                where: { is_default: '1',file_type:'image' },
                                required: false,
                            }
                        ]

                    }
                ]
            });
        }

        if (carts == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            const setting = await Setting.findOne({
                attributes: ['max_shipping_amount', 'shipping_amount','discount']
            });
            let bag_mrp = 0;
            let subtotal_amount = 0;
            let shipping_amt = 0;
            let currency_symbol = '';
            let code_c = '';
            if (carts) {
                for (const cart of carts) {
                    if (cart.product) {
                        // bag_mrp += parseFloat(cart.product.compare_price) * cart.quantity;
                        currency_symbol = cart.currency_symbol
                        code_c = cart.currency_code;
                        if (cart.currency_code == "INR") {
                            bag_mrp += parseFloat(cart.product.compare_price) * cart.quantity;
                            subtotal_amount += parseFloat(cart.subtotal_amount);
                        } else {
                            bag_mrp += parseFloat(cart.product.usd_compare_price * cart.currency_rate) * cart.quantity;
                            subtotal_amount += parseFloat(cart.subtotal_amount * cart.currency_rate);
                        }

                        var shipping_amount_type = cart.product.shipping_amount_type;
                        if (shipping_amount_type == 1 && cart.currency_code == "INR") {
                            shipping_amt += parseFloat(cart.product.shipping_charge);
                        } else if (shipping_amount_type == 2 && cart.currency_code == "INR") {
                            shipping_amt += parseFloat(cart.subtotal_amount) * parseFloat(cart.product.shipping_charge) / 100;
                        }
                    }
                }
            }

            let kairaus_saving = bag_mrp - subtotal_amount;
            var order_discount = 0;
            // if (buy_now_data == 'buy_now') {
            //     order_discount = 0;
            // } else {
            // const orderdiscount = await OrderDiscountCoupon.findOne({
            //     where: {
            //         user_id: user_id,
            //         discount_type: 'order',
            //         applied_status: 1,
            //     },
            //     attributes: ['discount_amt']
            // });
            // var order_discount = orderdiscount ? parseFloat(orderdiscount.discount_amt) : 0;
            // const result = await OrderDiscountCoupon.findOne({
            //     where: {
            //         user_id: user_id,
            //         discount_type: 'order'
            //     },
            //     attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
            //     raw: true,
            //     include: [
            //         {
            //             model: Coupon,
            //             as: 'applied_coupon_code',
            //             attributes: ['id', 'coupon_code'],
            //             where: {
            //                 status: {
            //                     [Op.in]: ['1', '2'],
            //                 },
            //                 is_deleted: 0,
            //                 number_of_uses: {
            //                     [Op.gt]: 0,
            //                 },
            //                 from_date: {
            //                     [Op.lte]: getCurrentDateTime()
            //                 },
            //                 to_date: {
            //                     [Op.gte]: getCurrentDateTime()
            //                 }
            //             },
            //             required: false,
            //         }
            //     ],
            // });

            // order_discount = result?.applied_coupon_code ? parseFloat(result.total_subtotal_amount) : 0;
            const result = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: user_id,
                    discount_mode: buy_now_data,
                    discount_type: 'order'
                },
                attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
                include: [
                    {
                        model: Coupon,
                        as: 'applied_coupon_code',
                        attributes: ['id', 'coupon_code'],
                        where: {
                            status: {
                                [Op.in]: ['1', '2'],
                            },
                            is_deleted: 0,
                            number_of_uses: {
                                [Op.gt]: 0,
                            },
                            from_date: {
                                [Op.lte]: getCurrentDateTime()
                            },
                            to_date: {
                                [Op.gte]: getCurrentDateTime()
                            }
                        },
                        required: false,
                    }
                ],
            });

            order_discount = result && result.applied_coupon_code ? parseFloat(result.get('total_subtotal_amount')) : 0;


            // }

            const forderdiscount = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: user_id,
                    applied_status: 1,
                    discount_type: 'first_order',
                    discount_mode: buy_now_data,
                },
                attributes: ['discount_amt'],
                include: [
                    {
                        model: Coupon,
                        as: 'applied_coupon_code',
                        attributes: ['id', 'coupon_code'],
                        where: {
                            status: {
                                [Op.in]: ['1', '2'],
                            },
                            is_deleted: 0,
                            number_of_uses: {
                                [Op.gt]: 0,
                            },
                            from_date: {
                                [Op.lte]: getCurrentDateTime()
                            },
                            to_date: {
                                [Op.gte]: getCurrentDateTime()
                            }
                        },
                        required: false,
                    }
                ],
            });
            var first_order_discount = forderdiscount?.applied_coupon_code ? parseFloat(forderdiscount.discount_amt) : 0;

            const rewarddiscount = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: user_id,
                    discount_mode: buy_now_data,
                    discount_type: 'reward'
                },
                attributes: ['discount_amt']
            });
            var reward_discount = rewarddiscount ? parseFloat(rewarddiscount.discount_amt) : 0;

            var total_discount = order_discount + first_order_discount;
            var total_amtt = subtotal_amount - total_discount;

            if (rewarddiscount && reward_discount > total_amtt && buy_now_data != 'buy_now') {
                var total = reward_discount - total_amtt;
                var all_amt = reward_discount - total;
                reward_discount = all_amt;
                var total_amt = total_amtt - reward_discount;
            } else {
                total_amtt = total_amtt - reward_discount;
                var total_amt = total_amtt;
            }


            var max_shipping_amount = setting ? parseFloat(setting.max_shipping_amount) : 0;
            if (max_shipping_amount > total_amtt) {
                var shipping_charge = setting.shipping_amount;
                // var shipping_charge = parseFloat(shipping_amt);
            } else {
                var shipping_charge = 0;
            }

            // add discount
            var extraDisount = (Math.round(total_amtt) * setting.discount) / 100;
            var afterdiscount_amount = total_amtt - Math.round(extraDisount);
            var  after_discount_amount = afterdiscount_amount + shipping_charge;
            //end

            var total_amt = total_amtt + shipping_charge;

            const totalQuantity = carts.reduce((sum, cart) => {
                return sum + cart.quantity;
            }, 0);
            const orderdiscount = await OrderDiscountCoupon.findAll({
                where: {
                    user_id: user_id,
                    discount_mode: buy_now_data,
                    discount_type: 'order'
                },
                attributes: ['discount_amt'],
                include: [
                    {
                        model: Coupon,
                        as: 'applied_coupon_code',
                        attributes: ['id', 'coupon_code'],
                        required: false,
                    }
                ],

            });
            const discountIdString = orderdiscount.map(item => item?.applied_coupon_code?.coupon_code);
            const discountIdArray = discountIdString.join(',');

            const price_data = {
                after_discount : Math.round(extraDisount),
                after_discount_amount : Math.round(after_discount_amount),
                after_discount_percent : setting.discount,
                addMore_Price: total_amtt > setting.max_shipping_amount ? 0 : Math.round(setting.max_shipping_amount - total_amtt),
                bag_mrp: Math.round(bag_mrp),
                kairaus_saving: Math.round(kairaus_saving),
                order_discount: Math.round(order_discount),
                orderdiscount_coupon_code: discountIdArray,
                first_order_discount: Math.round(first_order_discount),
                first_order_discount_coude: forderdiscount ? forderdiscount.applied_coupon_code.coupon_code : '',
                reward_discount: Math.round(reward_discount),
                shipping_amt: shipping_charge,
                total_amt: Math.round(total_amt),
                total_items: Math.round(totalQuantity),
                currency_symbol: currency_symbol || '',
                code_c: code_c || '',
                saving: Math.round(kairaus_saving + order_discount + first_order_discount),
            }

            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                cart_list: carts,
                price_data: price_data,
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error_message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get cart amount detail end

//buy now start
const buyNow = async (req, res) => {
    const user_id = req.userId;
    const products = req.body;
    try {
        const stockQuantityAvailability = [];
        const existingBuyNowRecord = await BuyNow.findOne({ where: { user_id: user_id } });
        if (existingBuyNowRecord) {
            await BuyNow.destroy({
                where: { user_id: user_id },
            });
        }
        for (const product of products) {
            // Fetch product coupon details
            const productCoupons = await Coupon.findOne({
                where: {
                    coupon_code: product.coupon_code,
                    [Op.or]: [
                        sequelize.literal(`FIND_IN_SET(${product.product_id}, apply_value)`),
                    ],
                },
            });

            // Check if BuyNow record exists for the user


            // Fetch product details
            const productDetail = await Product.findOne({
                attributes: ['stock_quantity', 'product_name', 'price'],
                where: { id: product.product_id },
            });
            const availableStock = productDetail.stock_quantity || 0;

            // Check if the product can be purchased
            if (product.quantity > 0 && availableStock >= product.quantity) {
                // Remove existing BuyNow record if it exists

                // Calculate discount and subtotal
                let discountAmount = 0;
                // add by suresh currency convet 02-08-2024
                if (product.currency_code == 'INR') {
                    var subtotal = product.quantity * parseFloat(productDetail.price);
                } else {
                    var subtotal = product.quantity * parseFloat(product.usd_amount * product.currency_rate);
                }
                //end
                let finalAmount = subtotal;

                if (productCoupons) {
                    const { coupon_type, type_val, max_discount_allow, max_discount_amt, to_date, min_amount, upto_amount } = productCoupons;
                    const couponExpiry = moment(`${to_date} 23:59:59`, "YYYY-MM-DD HH:mm:ss");
                    const currentDate = moment(getCurrentDateTime());

                    if (couponExpiry >= currentDate && (min_amount <= subtotal && upto_amount >= subtotal)) {
                        if (coupon_type === 'normal') {
                            discountAmount = Math.min(parseFloat(type_val), max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                        } else if (coupon_type === 'percent') {
                            const percentDiscount = (subtotal * parseFloat(type_val)) / 100;
                            discountAmount = Math.min(percentDiscount, max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                        }
                        finalAmount = subtotal - discountAmount;
                    }
                }

                var discount_id = 0;
                if (discountAmount > 0) {
                    var discount_id = productCoupons?.id || 0;
                }

                // Create new BuyNow record
                await BuyNow.create({
                    user_id: user_id,
                    product_id: product.product_id,
                    quantity: product.quantity,
                    amount: productDetail.price,
                    usd_amount: product.usd_amount,
                    currency_code: product.currency_code,
                    currency_symbol: product.currency_symbol,
                    currency_rate: product.currency_rate,
                    discount_amt: discountAmount,
                    subtotal_amount: finalAmount,
                    discount_id: discount_id,
                    created_by: user_id,
                });
            } else {
                stockQuantityAvailability.push(productDetail.product_name);
            }
        }

        // Generate out-of-stock message
        const stockQuantityMessage = stockQuantityAvailability.length > 0 ? `${stockQuantityAvailability.join(', ')} Out of stock` : '';


        if (!products) {
            res.status(202).send({
                message: process.env.NOT_INSERTED_MSG,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.INSERTED_MSG,
                error: false,
                success: true,
                status: '1',
                out_of_stock_msg: stockQuantityMessage,
                data: products
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const removeBuyNow = async (req, res) => {
    const user_id = req.userId;
    try {
        const existingBuyNowRecord = await BuyNow.findOne({ where: { user_id } });

        if (!existingBuyNowRecord) {
            res.status(202).send({
                message: process.env.NOT_DELETED_MSG,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            await BuyNow.destroy({
                where: {
                    user_id: user_id
                    // id: existingBuyNowRecord.id
                },
            });
            res.status(200).send({
                message: process.env.DELETED_MSG,
                error: false,
                success: true,
                status: '1',
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//buy now end

//reward point apply start
// const applyRewardPoint = async (req, res) => {
//     try {
//         const checkRewardPoint = await RewardPointWallet.findOne({
//             attributes: ["id", "total_points"],
//             where: {
//             user_id: req.userId,
//             },
//         });
//         if (!checkRewardPoint) {
//             res.status(202).send({
//             message: process.env.RECORD_NOT_FOUND,
//             error: true,
//             success: false,
//             status: "0",
//             });
//         } else {
//             const discountAmout = checkRewardPoint.total_points / 100;

//             const RewardDetails = {
//             user_id: req.userId,
//             discount_id: 0,
//             discount_type: 'reward',
//             discount_amt: parseFloat(discountAmout),
//             };

//             const existingRecord = await OrderDiscountCoupon.findOne({
//             where: {
//                 user_id: req.userId,
//                 discount_type: "reward",
//             },
//             });

//             if (existingRecord) {
//             RewardDetails.updated_at = getCurrentDateTime();

//             const update_reward_discount = await OrderDiscountCoupon.update(
//                 RewardDetails,
//                 {
//                 where: {
//                     id: existingRecord.id,
//                 },
//                 }
//             );
//             } else {
//             RewardDetails.created_at = getCurrentDateTime();
//             const add_apply_reward_discount = await OrderDiscountCoupon.create(
//                 RewardDetails
//             );
//             }

//             res.status(200).send({
//             message: "Reward Applied",
//             error: false,
//             success: true,
//             status: "1",
//             discount: discountAmout,
//             });
//         }
//     } catch (error) {
//       res.status(500).send({
//         message: process.env.ERROR_MSG,
//         msg: error.message,
//         error: true,
//         success: false,
//         status: "0",
//       });
//     }
//   };

const applyRewardPoint = async (req, res) => {
    try {
        const checkRewardPoint = await RewardPointWallet.findOne({
            attributes: ["id", "total_points"],
            where: {
                user_id: req.userId,
            },
        });
        if (!checkRewardPoint) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: "0",
            });
        } else {
            const discountAmout = checkRewardPoint.total_points / 100;

            const RewardDetails = {
                user_id: req.userId,
                discount_id: 0,
                discount_type: 'reward',
                discount_amt: parseFloat(discountAmout),
            };
            const existingRecord = await OrderDiscountCoupon.findOne({
                where: {
                    user_id: req.userId,
                    discount_type: "reward",
                },
            });

            if (existingRecord) {
                const update_reward_discount = await OrderDiscountCoupon.destroy({
                    where: {
                        id: existingRecord.id,
                    },
                });

                res.status(200).send({
                    message: "Reward Point Remove",
                    error: false,
                    success: true,
                    status: "0",
                    discount: '0',
                });

            } else {
                RewardDetails.created_at = getCurrentDateTime();
                const add_apply_reward_discount = await OrderDiscountCoupon.create(
                    RewardDetails
                );
                res.status(200).send({
                    message: "Reward Applied",
                    error: false,
                    success: true,
                    status: "1",
                    discount: discountAmout,
                });
            }
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            msg: error.message,
            error: true,
            success: false,
            status: "0",
        });
    }
};
const removeRewardPoint = async (req, res) => {
    try {
        const record = await OrderDiscountCoupon.findOne({
            where: {
                user_id: req.userId,
                discount_type: "reward",

            },
        });

        if (record) {
            const update_reward_discount = await OrderDiscountCoupon.destroy({
                where: {
                    id: record.id,
                },
            });
            if (update_reward_discount) {
                return res.status(200).send({
                    message: "Record Remvoed",
                    error: false,
                    success: true,
                    status: 1,
                });
            }
        } else {
            res.status(404).send({
                message: "Record not exists",
                error: true,
                success: false,
                status: "0",
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            msg: error.message,
            error: true,
            success: false,
            status: "0",
        });
    }
};
//reward point apply end

// update product wise coupon start
const updateProductWiseDiscount = async (req, res) => {
    const user_id = req.userId;
    const product_id = req.body.product_id;
    const coupon_code = req.body.coupon_code;
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product"),
        coupon_code: Joi.string().optional().allow("").label("Coupon Code"), // Optional coupon code
    });
    const dataToValidate = {
        product_id: product_id,
        coupon_code: coupon_code
    };
    const result = schema.validate(dataToValidate);

    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const checkCartExists = await Cart.findOne({
                where: {
                    product_id: product_id,
                    user_id: user_id
                }
            });
            if (checkCartExists) {
                const planProductCarts = checkCartExists.get({ plain: true });
                const couponDetails = await Coupon.findOne({ where: { coupon_code: coupon_code, status: '1', is_deleted: 0 }, attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'] });
                let discountAmount = 0;
                // const subtotal = planProductCarts.amount * parseFloat(planProductCarts.quantity);
                if (planProductCarts.currency_code == 'INR') {
                    var subtotal = planProductCarts.amount * parseFloat(planProductCarts.quantity);
                } else {
                    var subtotal = planProductCarts.quantity * parseFloat(planProductCarts.usd_amount * planProductCarts.currency_rate);
                }
                let finalAmount = subtotal;
                if (couponDetails) {
                    const { coupon_type, type_val, max_discount_allow, max_discount_amt, to_date, min_amount, upto_amount } = couponDetails;
                    const couponExpiry = moment(`${to_date} 23:59:59`, "YYYY-MM-DD HH:mm:ss");
                    const currentDate = moment(getCurrentDateTime());
                    if (couponExpiry >= currentDate && (min_amount <= subtotal && upto_amount >= subtotal)) {
                        if (coupon_type === 'normal') {
                            discountAmount = Math.min(parseFloat(type_val), max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                        } else if (coupon_type === 'percent') {
                            const percentDiscount = (subtotal * parseFloat(type_val)) / 100;
                            discountAmount = Math.min(percentDiscount, max_discount_allow ? parseFloat(max_discount_amt) : Infinity);
                        }
                        finalAmount = subtotal - discountAmount;
                    } else {
                        return res.status(202).send({
                            message: 'Coupon not applyed',
                            error: true,
                            success: false,
                            status: '0'
                        });
                    }
                    const couponCounts = await OrderDiscountCoupon.findAll({
                        where: {
                            user_id: user_id,
                            applied_status: 1,
                            discount_type: {
                                [Op.in]: ['first_order', 'order']
                            }
                        },
                        attributes: ['discount_type', [sequelize.fn('COUNT', 'discount_type'), 'count']],
                        group: ['discount_type']
                    });
                    const appliedCoupons = couponCounts.map(coupon => coupon.get('discount_type'));
                    if (appliedCoupons.includes('first_order') && appliedCoupons.includes('order')) {
                        res.status(202).send({
                            message: 'You can only apply up to two coupons. Oops! It looks like you’ve already applied two.',
                            error: true,
                            success: false,
                            status: '2'
                        });
                    } else {
                        await Cart.update({
                            user_id: user_id,
                            quantity: planProductCarts.quantity,
                            discount_id: discountAmount > 0 ? couponDetails.id : 0,
                            discount_amt: discountAmount,
                            subtotal_amount: finalAmount,
                            updated_at: current_date,
                            updated_by: user_id,
                        }, {
                            where: {
                                id: planProductCarts.id,
                            }
                        });
                        res.status(200).send({
                            message: process.env.INSERTED_MSG,
                            error: false,
                            success: true,
                            currency_symbol: planProductCarts.currency_symbol,
                            finalAmount: finalAmount,
                            status: '1',
                        });
                    }
                } else {
                    if (planProductCarts && coupon_code == "") {
                        await Cart.update({
                            user_id: user_id,
                            quantity: planProductCarts.quantity,
                            discount_id: 0,
                            discount_amt: 0,
                            subtotal_amount: finalAmount,
                            updated_at: current_date,
                            updated_by: user_id,
                        }, {
                            where: {
                                id: planProductCarts.id,
                            }
                        });
                        res.status(202).send({
                            message: 'Product Discount Remove',
                            error: true,
                            success: false,
                            status: '0'
                        });
                    } else {
                        res.status(202).send({
                            message: process.env.RECORD_NOT_FOUND,
                            error: true,
                            success: false,
                            status: '0'
                        });
                    }
                }
            } else {
                res.status(202).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const RemoveCoupon = async (req, res) => {
    try {
        const record = await OrderDiscountCoupon.findOne({
            where: {
                user_id: req.userId,
                discount_id: req.body.coupon_id,
                // discount_mode: 'cart',
                // discount_type: "order",

            },
        });
        if (record) {
            const update_reward_discount = await OrderDiscountCoupon.destroy({
                where: {
                    id: record.id,
                },
            });
            if (update_reward_discount) {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } else {
            res.status(404).send({
                message: "Record not exists",
                userr_id:req.userId,
                error: true,
                success: false,
                status: "0",
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            msg: error.message,
            error: true,
            success: false,
            status: "0",
        });
    }
};
//create by tc 28-aug-2024
const removeFirstOrderCoupon = async (req, res) => {
    try {
        var user_id = req.userId;

        const cartCouponCount = await Cart.count({
            where: {
                user_id: user_id,
                discount_id: {
                    [sequelize.Op.ne]: 0
                }
            },
            distinct: true,
            col: 'discount_id'
        });
        if (cartCouponCount) {
            var total_cart_coupon_apply = 1;
        }
        const couponDiscount = await OrderDiscountCoupon.count({
            where: {
                user_id: user_id,
                applied_status: 1,
                discount_id: {
                    [sequelize.Op.ne]: 0
                }
            },
            distinct: true,
            col: 'discount_id'
        });
        if (couponDiscount) {
            var total_discount_coupon_apply = 1;
        }
        var total_coupon = total_cart_coupon_apply + total_discount_coupon_apply;

        var discount_id = req.body.coupon_id
        const firstCouponapply = await OrderDiscountCoupon.findOne({
            attributes: ['id', 'user_id', 'discount_id', 'applied_status'],
            where: { user_id: user_id, discount_id: discount_id }
        });


        if (total_coupon == 2 && firstCouponapply.applied_status == 0) {
            res.status(202).send({
                message: 'You can only apply up to two coupons. Oops! It looks like you’ve already applied two.',
                error: true,
                success: false,
                status: '0'
            });
        } else {
            if (firstCouponapply) {
                firstCouponapply.applied_status = firstCouponapply.applied_status === 1 ? 0 : 1;
                const data = await firstCouponapply.save();

                res.status(200).send({
                    message: `coupon ${data.applied_status == 1 ? 'applied' : 'removed'}`,
                    error: false,
                    success: true,
                    status: '1',
                    data: firstCouponapply,
                });
            } else {
                res.status(404).send({
                    message: "Coupon not found",
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }

    } catch (error) {
        // Handle any errors that occur
        res.status(500).send({
            message: process.env.ERROR_MSG || "An error occurred",
            error: true,
            success: false,
            status: '0',
        });
    }
};
//end


const CcavenuePayment = async (req, res) => {
    const user_id = req.userId;
    const address_id = req.address_id || 0;

    const schema = Joi.object().keys({
        address_id: Joi.required().label("address_id")
    });
    const dataToValidate = {
        address_id: address_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {

        let data = qs.stringify({
            'merchant_id': '2168434',
            'order_id': '12123',
            'currency': 'INR',
            'amount': '1.00',
            'redirect_url': 'localhost:3011/api/user/ccavenue-callback',
            'redirect_url': `https://demo3.mystorepedia.com/ccavenue-callback?gst_number=0&reward_point=0&reward_amt=0&address_name=ss&buy_now=&address_id=${address_id}&first_order_discount_id=0&first_order_discount_amt=0`,
            'cancel_url': 'http://127.0.0.1:3011/ccavenue-callback',
            'language': 'EN',
            'billing_name': 'Peter',
            'billing_address': 'Santacruz',
            'billing_city': 'Mumbai',
            'billing_state': 'MH',
            'billing_zip': '400054',
            'billing_country': 'India',
            'billing_tel': '9876543210',
            'billing_email': 'testing@domain.com',
            'delivery_name': 'Sam',
            'delivery_address': 'Vile Parle',
            'delivery_city': 'Mumbai',
            'delivery_state': 'Maharashtra',
            'delivery_zip': user_id,
            'delivery_country': 'India',
            'delivery_tel': '0123456789',
            'merchant_param1': '123',
            'merchant_param2': '123',
            'merchant_param3': '123',
            'merchant_param4': '123',
            'merchant_param5': '123',
            'integration_type': 'iframe_normal',
            'promo_code': '',
            'customer_identifier': ''
        });

        let config = {
            method: 'post',
            maxBodyLength: Infinity,
            url: 'https://demo3.mystorepedia.com/initiate-payment',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            data: data
        };
        axios.request(config)
            .then((response) => {
                // Assuming the response data is an HTML string
                var htmlResponse = response.data;
                console.log("Received HTML response:", htmlResponse);

                // Regex to find the iframe src URL
                const iframeSrcMatch = htmlResponse.match(/<iframe[^>]+src="([^"]+)"/);

                if (iframeSrcMatch && iframeSrcMatch[1]) {
                    const extractedUrl = iframeSrcMatch[1];
                    console.log("Extracted URL:", extractedUrl);
                    res.status(200).send(JSON.stringify(extractedUrl));
                } else {
                    console.error('URL not found in the HTML response');
                    res.status(500).send('URL not found in the HTML response');
                }
            })
            .catch((error) => {
                // Log the error for debugging purposes
                console.error('Error occurred:', error);

                if (error.response) {
                    res.status(error.response.status).send(error.response.data);
                } else if (error.request) {
                    res.status(500).send('Server Error');
                } else {
                    res.status(500).send('Request Error');
                }
            });

    }

}

const addOrderHistory = async (req, res) => {
    try {
        const schema = Joi.object({
            items: Joi.string().required(),
        })

        const dataToValidate = {
            items: req.body.items
        }

        const result = schema.validate(dataToValidate)

        if (result.error) {
            return res.status(400).send({
                message: result.error.message,
                error: true,
                success: false,
                status: 0
            })
        }

        const insertObj = {
            items: req.body.items,
            user_id: req.userId,
            status: '1',
            created_at: getCurrentDateTime(),
            created_by: req.userId
        }

        const insert = await OrderHistoryModel.create(insertObj)

        if (insert) {
            return res.status(200).send({
                message: process.env.INSERTED_MSG,
                success: true,
                error: false,
                status: '1'
            })
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            status: 0,
            error: true,
            success: false
        })

    }

}


const GetQueryList = async (req, res) => {
    try {
        const query = await QueryList.findAll({
            where: { status: '1' },
            attributes: ['id', 'query']
        });
        if (query == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: query
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const updateStatus = async (item) => {
    try {
        const token = await shiprocketLogin()
        const response = await axios.get(
            `https://apiv2.shiprocket.in/v1/external/courier/track/awb/${item.awb_code}`,
            {
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                }
            }
        );
        let curr_status = response.data.tracking_data.shipment_track[0].current_status

        const update = await OrderItem.update({
            order_status: curr_status
        }, {
            where: {
                id: item.id,
                order_id: item.order_id,
            }
        })

        return update ? true : false

    } catch (error) {
        console.log('Error Fetching token', error)
        throw new Error('Failed to receive token')

    }

}


const getHomepageSections = async (req, res) => {
    try {
        const data = await HomePageSectionModel.findAll({
            where: {
                status: '1'
            }
        })
        if (data.length > 0) {
            return res.status(200).send({
                message: "Records found",
                status: 1,
                error: false,
                success: true,
                file_path: 'https://img.kairaus.com/uploads/home_section/',
                data: data
            })

        } else {

            return res.status(404).send({
                message: "Records not found",
                status: 0,
                error: true,
                success: false,
            })
        }

    } catch (error) {
        return res.status(500).send({
            message: process.env.ERROR_MSG,
            status: 0,
            success: false,
            error: true,
        })

    }
}
const InsertDummyUser = async (req, res) => {
    const userData = [
        { "firstname": "Aarav", "lastname": "Patel", "userfullname": "Aarav Patel", "email": "aarav.patel@gmail.com", "password": "password123", "role_id": "2" },
        { "firstname": "Vivaan", "lastname": "Sharma", "userfullname": "Vivaan Sharma", "email": "vivaan.sharma@yahoo.com", "password": "password123", "role_id": "2" },
        { "firstname": "Aditya", "lastname": "Singh", "userfullname": "Aditya Singh", "email": "aditya.singh@outlook.com", "password": "password123", "role_id": "2" },
        { "firstname": "Vihaan", "lastname": "Gupta", "userfullname": "Vihaan Gupta", "email": "vihaan.gupta@gmail.com", "password": "password123", "role_id": "2" },
        { "firstname": "Arjun", "lastname": "Reddy", "userfullname": "Arjun Reddy", "email": "arjun.reddy@yahoo.com", "password": "password123", "role_id": "2" },
        { "firstname": "Sai", "lastname": "Kumar", "userfullname": "Sai Kumar", "email": "sai.kumar@outlook.com", "password": "password123", "role_id": "2" },
        { "firstname": "Reyansh", "lastname": "Sharma", "userfullname": "Reyansh Sharma", "email": "reyansh.sharma@gmail.com", "password": "password123", "role_id": "2" },
        { "firstname": "Aanya", "lastname": "Mehta", "userfullname": "Aanya Mehta", "email": "aanya.mehta@yahoo.com", "password": "password123", "role_id": "2" },
        { "firstname": "Ishaan", "lastname": "Joshi", "userfullname": "Ishaan Joshi", "email": "ishaan.joshi@outlook.com", "password": "password123", "role_id": "2" },
        { "firstname": "Saanvi", "lastname": "Gupta", "userfullname": "Saanvi Gupta", "email": "saanvi.gupta@gmail.com", "password": "password123", "role_id": "2" },
        { "firstname": "Ahmed", "lastname": "Khan", "userfullname": "Ahmed Khan", "email": "ahmed.khan@gmail.com", "password": "password456", "role_id": "2" },
        { "firstname": "Ali", "lastname": "Shah", "userfullname": "Ali Shah", "email": "ali.shah@yahoo.com", "password": "password456", "role_id": "2" },
        { "firstname": "Hassan", "lastname": "Malik", "userfullname": "Hassan Malik", "email": "hassan.malik@outlook.com", "password": "password456", "role_id": "2" },
        { "firstname": "Mohammad", "lastname": "Khan", "userfullname": "Mohammad Khan", "email": "mohammad.khan@gmail.com", "password": "password456", "role_id": "2" },
        { "firstname": "Sarah", "lastname": "Ahmed", "userfullname": "Sarah Ahmed", "email": "sarah.ahmed@yahoo.com", "password": "password456", "role_id": "2" },
        { "firstname": "Ayesha", "lastname": "Khan", "userfullname": "Ayesha Khan", "email": "ayesha.khan@outlook.com", "password": "password456", "role_id": "2" },
        { "firstname": "Omer", "lastname": "Farooq", "userfullname": "Omer Farooq", "email": "omer.farooq@gmail.com", "password": "password456", "role_id": "2" },
        { "firstname": "Fatima", "lastname": "Ali", "userfullname": "Fatima Ali", "email": "fatima.ali@yahoo.com", "password": "password456", "role_id": "2" },
        { "firstname": "Bilal", "lastname": "Ahmad", "userfullname": "Bilal Ahmad", "email": "bilal.ahmad@outlook.com", "password": "password456", "role_id": "2" },
        { "firstname": "Noor", "lastname": "Bibi", "userfullname": "Noor Bibi", "email": "noor.bibi@gmail.com", "password": "password456", "role_id": "2" },
        { "firstname": "Omar", "lastname": "Al-Farsi", "userfullname": "Omar Al-Farsi", "email": "omar.alfarsi@gmail.com", "password": "password789", "role_id": "2" },
        { "firstname": "Fatima", "lastname": "Al-Mansoori", "userfullname": "Fatima Al-Mansoori", "email": "fatima.almansoori@yahoo.com", "password": "password789", "role_id": "2" },
        { "firstname": "Hassan", "lastname": "Al-Mutairi", "userfullname": "Hassan Al-Mutairi", "email": "hassan.almutairi@outlook.com", "password": "password789", "role_id": "2" },
        { "firstname": "Aisha", "lastname": "Al-Suwaidi", "userfullname": "Aisha Al-Suwaidi", "email": "aisha.alsuwaidi@gmail.com", "password": "password789", "role_id": "2" },
        { "firstname": "Ahmed", "lastname": "Al-Sheikh", "userfullname": "Ahmed Al-Sheikh", "email": "ahmed.alsheikh@yahoo.com", "password": "password789", "role_id": "2" },
        { "firstname": "Sara", "lastname": "Al-Qassimi", "userfullname": "Sara Al-Qassimi", "email": "sara.alqassimi@outlook.com", "password": "password789", "role_id": "2" },
        { "firstname": "Khalid", "lastname": "Al-Jabri", "userfullname": "Khalid Al-Jabri", "email": "khalid.aljabri@gmail.com", "password": "password789", "role_id": "2" },
        { "firstname": "Hana", "lastname": "Al-Nasr", "userfullname": "Hana Al-Nasr", "email": "hana.alnasr@yahoo.com", "password": "password789", "role_id": "2" },
        { "firstname": "Mohammed", "lastname": "Al-Hamadi", "userfullname": "Mohammed Al-Hamadi", "email": "mohammed.alhamadi@outlook.com", "password": "password789", "role_id": "2" },
        { "firstname": "Mariam", "lastname": "Al-Basti", "userfullname": "Mariam Al-Basti", "email": "mariam.albasti@gmail.com", "password": "password789", "role_id": "2" },
        { "firstname": "Ravi", "lastname": "Sharma", "userfullname": "Ravi Sharma", "email": "ravi.sharma@gmail.com", "password": "password101", "role_id": "2" },
        { "firstname": "Pooja", "lastname": "Thapa", "userfullname": "Pooja Thapa", "email": "pooja.thapa@yahoo.com", "password": "password101", "role_id": "2" },
        { "firstname": "Rajesh", "lastname": "Kumar", "userfullname": "Rajesh Kumar", "email": "rajesh.kumar@outlook.com", "password": "password101", "role_id": "2" },
        { "firstname": "Anita", "lastname": "Sharma", "userfullname": "Anita Sharma", "email": "anita.sharma@gmail.com", "password": "password101", "role_id": "2" },
        { "firstname": "Deepak", "lastname": "Adhikari", "userfullname": "Deepak Adhikari", "email": "deepak.adhikari@yahoo.com", "password": "password101", "role_id": "2" },
        { "firstname": "Sita", "lastname": "Rai", "userfullname": "Sita Rai", "email": "sita.rai@outlook.com", "password": "password101", "role_id": "2" },
        { "firstname": "Ramesh", "lastname": "Gurung", "userfullname": "Ramesh Gurung", "email": "ramesh.gurung@gmail.com", "password": "password101", "role_id": "2" },
        { "firstname": "Nisha", "lastname": "Bhandari", "userfullname": "Nisha Bhandari", "email": "nisha.bhandari@yahoo.com", "password": "password101", "role_id": "2" },
        { "firstname": "Sanjay", "lastname": "Nepal", "userfullname": "Sanjay Nepal", "email": "sanjay.nepal@outlook.com", "password": "password101", "role_id": "2" },
        { "firstname": "Kriti", "lastname": "Shah", "userfullname": "Kriti Shah", "email": "kriti.shah@gmail.com", "password": "password101", "role_id": "2" },
        { "firstname": "Ravi", "lastname": "Sharma", "userfullname": "Ravi Sharma", "email": "ravi.sharma2@gmail.com", "password": "password102", "role_id": "2" },
        { "firstname": "Pooja", "lastname": "Thapa", "userfullname": "Pooja Thapa", "email": "pooja.thapa2@yahoo.com", "password": "password102", "role_id": "2" }
    ];
    try {
        // Hash passwords before inserting users
        const hashedUsersData = userData.map(user => ({
            ...user,
            password: md5(user.password) // Hashing passwords with MD5
        }));

        // Insert dummy users
        const insertedUsers = await User.bulkCreate(hashedUsersData);

        // Generate tokens for the inserted users
        const userTokenMap = {};
        for (const user of insertedUsers) {
            const token = jwt.sign({ id: user.id, userfullname: user.userfullname }, secretKey, { expiresIn: '30d' });
            userTokenMap[user.id] = token;
        }

        // Add tokens to the user objects
        const usersWithTokens = insertedUsers.map(user => ({
            ...user.toJSON(), // Convert sequelize instance to plain object
            token: userTokenMap[user.id]
        }));

        // Send a success response with user data and tokens
        res.status(200).send({
            error: false,
            success: true,
            status: '1',
            message: 'Users inserted successfully',
            users: usersWithTokens
        });
    } catch (error) {
        console.error('Unable to connect to the database or insert data:', error);
        // Send an error response
        res.status(500).send({
            error: true,
            success: false,
            status: '0',
            message: 'Failed to insert users',
            details: error.message
        });
    }
};


const updateDiscount_suresh = async (user_id, subtotal_amount) => {
    try {

        const first = await OrderDiscountCoupon.findOne({
            where: {
                user_id: user_id,
                discount_type: 'first_order'
            },
        });
        const order = await OrderDiscountCoupon.findOne({
            where: {
                user_id: user_id,
                discount_type: 'order'
            },
        });

        let firstDiscountAmt = 0;

        // Apply the first order discount
        if (first) {
            const firstCouponDetails = await Coupon.findOne({
                where: {
                    id: first.discount_id,
                    status: '1',
                    is_deleted: 0
                },
                attributes: [
                    'id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount',
                    'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'
                ]
            });

            if (firstCouponDetails) {
                // Calculate the discount for the first order
                if (firstCouponDetails.coupon_type === 'percent') {
                    firstDiscountAmt = (subtotal_amount * firstCouponDetails.type_val) / 100;
                } else if (firstCouponDetails.coupon_type === 'normal') {
                    firstDiscountAmt = firstCouponDetails.type_val;
                }

                // Update first order discount details
                await OrderDiscountCoupon.update({
                    user_id: user_id,
                    discount_id: firstCouponDetails.id,
                    discount_amt: firstDiscountAmt,
                    discount_type: firstCouponDetails.apply_to.toLowerCase(),
                    updated_at: current_date,
                }, {
                    where: { id: first.id }
                });
            }
        }

        let totalDiscount = subtotal_amount - firstDiscountAmt; // Subtract first discount from subtotal

        // Apply the order discount
        if (order) {
            const orderCouponDetails = await Coupon.findOne({
                where: {
                    id: order.discount_id,
                    status: '1',
                    is_deleted: 0
                },
                attributes: [
                    'id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount',
                    'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'
                ]
            });

            if (orderCouponDetails) {
                let orderDiscountAmt = 0;

                // Calculate the discount for the order
                if (orderCouponDetails.coupon_type === 'percent') {
                    orderDiscountAmt = (totalDiscount * orderCouponDetails.type_val) / 100;
                } else if (orderCouponDetails.coupon_type === 'normal') {
                    orderDiscountAmt = orderCouponDetails.type_val;
                }

                // Update order discount details
                await OrderDiscountCoupon.update({
                    user_id: user_id,
                    discount_id: orderCouponDetails.id,
                    discount_amt: orderDiscountAmt,
                    discount_type: orderCouponDetails.apply_to.toLowerCase(),
                    updated_at: current_date,
                }, {
                    where: { id: order.id }
                });
            }
        }

    } catch (error) {
        console.error('Error fetching data:', error);
        throw new Error('Failed to receive data');
    }
}

const updateDiscount_old = async (user_id, subtotal_amount) => {
    try {

        const couponDiscount = await OrderDiscountCoupon.findAll({
            where: {
                user_id: user_id,
                discount_type: {
                    [Op.in]: ['first_order', 'order']
                }
            },
        });
        if (couponDiscount) {
            for (const discount_coupon of couponDiscount) {
                const couponDetails = await Coupon.findOne({ where: { id: discount_coupon.discount_id, status: '1', is_deleted: 0 }, attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt'] });
                if (couponDetails) {
                    if (couponDetails.coupon_type === 'percent') {
                        var discount_amount = (subtotal_amount * couponDetails.type_val) / 100;
                    } else if (couponDetails.coupon_type === 'normal') {
                        var discount_amount = couponDetails.type_val;
                    }
                    if (couponDetails) {
                        await OrderDiscountCoupon.update({
                            user_id: user_id,
                            discount_id: couponDetails.id,
                            discount_amt: discount_amount,
                            discount_type: couponDetails.apply_to.toLowerCase(),
                            updated_at: current_date,
                        }, {
                            where: {
                                id: discount_coupon.id
                            }
                        });
                    }
                }
            }
        }

    } catch (error) {
        console.log('Error Fetching data', error)
        throw new Error('Failed to receive data')

    }

}

const GetOrderCoupon = async (req, res) => {
    try {
        var current_datee = moment(getCurrentDateTime()).format("YYYY-MM-DD");
        const coupon = await Coupon.findAll({
            where: {
                apply_to: 'ORDER',
                to_date: { [Op.gte]: current_datee },
                status: '1',
                is_deleted: 0,
                [Op.or]: [
                    { coupon_allow: '1' },
                ],
            },
            attributes: ['id', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val', 'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to', 'apply_value', 'max_discount_allow', 'max_discount_amt']
        });
        if (!coupon) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: coupon,
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

// get all coupon used and avaliable coupon and expired coupon

const GetAllCoupon = async (req, res) => {
    const user_id = req.userId || 0;
    try {
        const usercoupons = await UserCoupon.findAll({
            where: { user_id },
            attributes: ['coupon_id'],
        });
        const couponIds = usercoupons.map(coupon => coupon.coupon_id);
        const coupons = await Coupon.findAll({
            where: {
                status: '1',
                is_deleted: 0,
                [Op.or]: [
                    { coupon_allow: '1' },
                    { id: { [Op.in]: couponIds } },
                ],
                status: { [Op.in]: ['1', '2'] },
            },
            attributes: [
                'id', 'multiple_use', 'coupon_code', 'from_date', 'to_date', 'coupon_type', 'type_val',
                'min_amount', 'upto_amount', 'coupon_desc', 'coupon_allow', 'apply_to',
                'apply_value', 'max_discount_allow', 'max_discount_amt',
                [
                    sequelize.literal(`CASE WHEN applied_coupon_user_first_order.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                    'first_order'
                ],
                [
                    sequelize.literal(`CASE WHEN NOW() > to_date THEN TRUE ELSE FALSE END`),
                    'is_expired'
                ],
            ],
            group: ['id'],
            include: [
                {
                    model: Order,
                    as: 'applied_coupon_user_first_order',
                    attributes: ['id'],
                    required: false,
                    where: { user_id },
                }
            ],
            order: [['id', 'DESC']],
        });

        await Promise.all(
            coupons.map(async (coupon) => {
                const appliedCoupons = await Order.findAll({
                    where: {
                        user_id,
                        [Op.or]: [
                            { discount_id: coupon.id.toString() },
                            sequelize.literal(`FIND_IN_SET(${coupon.id}, discount_id) > 0`)
                        ]
                    },
                });
                // Set is_applied to 1 if any order matches, otherwise 0
                coupon.dataValues.is_applied = appliedCoupons.length > 0 && coupon.multiple_use > 0 ? 1 : 0;
            })
        );

        if (!coupons.length) {
            return res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }

        res.status(200).send({
            message: process.env.SUCCESS_MSG,
            error: false,
            success: true,
            status: '1',
            data: coupons,
        });

    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            message_message: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
};
//end

// instagram api

const GetInstagramMedia = async (req, res) => {
    try {
        const setting = await Setting.findOne({
            attributes: ['instagram_token']
        });
        let config = {
            method: 'get',
            maxBodyLength: Infinity,
            url: `https://graph.instagram.com/me/media?fields=id,caption,media_type,media_url,permalink,thumbnail_url,timestamp,username,comments_count,like_count&access_token=${setting.instagram_token}`,
            headers: {}
        };

        axios.request(config)
            .then((response) => {

                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data: response.data.data.length > 0 ? response.data.data : [],
                });
            })
            .catch((error) => {
                console.log(error);
            });
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

//end

const AppBanner =async (req,res) => {
    try {
        // Find if the user's theme already exists
        const items = await AppBannerModel.findAll();
        if (items) {
            return res.status(200).json({
                message: 'record found',
                success: true,
                error: false,
                status: '1',
                path: process.env.SITE_URL + 'uploads/app_banner/',
                data: items
            })
        } else {
            return res.status(400).json({
                message: 'record  not found',
                success: false,
                error: true,
                status: '0',
            })
        }
    } catch (error) {
        return res.status(500).json({
            error: true,
            success: false,
            status: '0',
            message: error.message
        });
    }
};

const ThemeSettingActive = async (req, res) => {
    try {
        // Find if the user's theme already exists
        const existingTheme = await ThemeSettingModel.findOne({
            where: { status: 1 },
        });
        if (existingTheme) {
            return res.status(200).json({
                message: 'record found',
                success: true,
                error: false,
                status: '1',
                data: existingTheme
            })
        } else {
            return res.status(400).json({
                message: 'record  not found',
                success: false,
                error: true,
                status: '0',
                // data: existingTheme
            })
        }
    } catch (error) {
        return res.status(500).json({
            error: true,
            success: false,
            status: '0',
            message: error.message
        });
    }
};

const GetTrackOrder = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    try {
        const orderItem = await OrderItem.findOne({
            where: { id: id },
            attributes: ['shipping_type','status'],
        });
        if(orderItem){
            const blueDart = sequelize.literal(`
                CASE
                    WHEN delivery_status = 'Online shipment booked' THEN '${process.env.ORDER_CONFIRM}'
                    WHEN delivery_status = 'SHIPMENT PICKED UP' THEN '${process.env.ORDER_CONFIRM1}'
                    WHEN delivery_status = 'SHIPMENT ARRIVED' THEN '${process.env.in_transit}'
                    WHEN delivery_status = 'SHIPMENT OUT FOR DELIVERY' THEN '${process.env.out_of_delivery}'
                    WHEN delivery_status = 'SHIPMENT DELIVERED' THEN '${process.env.delivery}'
                    ELSE NULL
                END
            `);
            const shipRocket = sequelize.literal(`
                CASE
                    WHEN delivery_status = 'IT' THEN '${process.env.ORDER_CONFIRM}'
                    WHEN delivery_status = 'PUD' THEN '${process.env.ORDER_CONFIRM1}'
                    WHEN delivery_status = 'OFP' THEN '${process.env.in_transit}'
                    WHEN delivery_status = 'OFD' THEN '${process.env.out_of_delivery}'
                    WHEN delivery_status = 'DLVD' THEN '${process.env.delivery}'
                    ELSE NULL
                END
            `);
        if(orderItem.shipping_type != 'ship_rocket'){
            var orderDetail = await TrackOrder.findAll({
                where: {
                    order_item_id: id,
                    status:'1',
                    delivery_status: {
                        [sequelize.Op.in]: ['SHIPMENT PICKED UP', 'SHIPMENT ARRIVED', 'SHIPMENT DELIVERED','Online shipment booked','SHIPMENT OUT FOR DELIVERY']
                    },
                },
                attributes: [
                    'order_id',
                    'time',
                    'date',
                    [blueDart, 'track_order_status'],
                    [sequelize.literal(`
                        CASE
                            WHEN delivery_status = 'Online shipment booked' THEN '1'
                            WHEN delivery_status = 'SHIPMENT PICKED UP' THEN '1'
                            WHEN delivery_status = 'SHIPMENT ARRIVED' THEN '2'
                            WHEN delivery_status = 'SHIPMENT OUT FOR DELIVERY' THEN '3'
                            WHEN delivery_status = 'SHIPMENT DELIVERED' THEN '4'
                            WHEN track_type = '2' THEN '5'
                            ELSE NULL
                        END
                    `), 'status'],
                    [sequelize.literal(`
                        CASE
                            WHEN delivery_status = 'Online shipment booked' THEN '1'
                            WHEN delivery_status = 'SHIPMENT PICKED UP' THEN '2'
                            WHEN delivery_status = 'SHIPMENT ARRIVED' THEN '3'
                            WHEN delivery_status = 'SHIPMENT OUT FOR DELIVERY' THEN '4'
                            WHEN delivery_status = 'SHIPMENT DELIVERED' THEN '5'
                             WHEN track_type = '2' THEN '6'
                            ELSE NULL
                        END
                    `), 'order_status']
                ],
                order: [
                    ['order_status', 'ASC'],
                ],
                group:['delivery_status'],
            });
        }else{
            var orderDetail = await TrackOrder.findAll({
                where: {
                    order_item_id: id,
                    delivery_status: {
                        [sequelize.Op.in]: ['IT', 'PUD', 'OFP','DLVD','OFD']
                    },
                },
                attributes: [
                    'order_id',
                    'time',
                    'date',
                    [shipRocket, 'track_order_status'],
                    [sequelize.literal(`
                        CASE
                            WHEN delivery_status = 'IT' THEN '1'
                            WHEN delivery_status = 'PUD' THEN '1'
                            WHEN delivery_status = 'OFP' THEN '2'
                            WHEN delivery_status = 'OFD' THEN '3'
                            WHEN delivery_status = 'DLVD' THEN '4'
                            ELSE NULL
                        END
                    `), 'status'],
                    [sequelize.literal(`
                       CASE
                            WHEN delivery_status = 'IT' THEN '1'
                            WHEN delivery_status = 'PUD' THEN '2'
                            WHEN delivery_status = 'OFP' THEN '3'
                            WHEN delivery_status = 'OFD' THEN '4'
                            WHEN delivery_status = 'DLVD' THEN '5'
                            ELSE NULL
                        END
                    `), 'order_status']
                ],
                order: [
                    ['order_status', 'ASC'], // Sort by status first
                ],
                group:['delivery_status'],
            });
        }
    }
    const result = await groupByTitle(orderDetail,id);
    if (!result[0]) {
        res.status(202).send({
            message: process.env.RECORD_NOT_FOUND,
            error: true,
            success: false,
            status: '0'
        });
    } else {
        res.status(200).send({
            message: process.env.SUCCESS_MSG,
            error: false,
            success: true,
            status: '1',
            delivery_status:orderItem.status ? orderItem.status : 1,
            data: result
        });
    }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            message_e: error.message,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const groupByTitle = async (data,id) => {
    const grouped = {
        order_confirm: { title: 'Order Confirmed', date: '', status: [] },
        in_transit: { title: 'In Transit', date: '', status: [] },
        out_of_delivery: { title: 'Out for Delivery', date: null, status: [] },
        delivery: { title: 'Delivered', date: '', status: [] },
    };

    var orderReturn = await OrderReturn.findOne({
        where: {
            order_item_id: id
        },
        include: [
            {
                model: OrderReturnReasons,
                as: 'order_return_reason',
                required: true,
            }
        ],
    });
    if (orderReturn) {
        grouped.return = { title: 'Return Request', date: moment(orderReturn.created_at).format('YYYY-MM-DD'), status: [
            {
                "order_id": orderReturn.order_id,
                "time": moment(orderReturn.created_at).format("HH:mm:ss"),
                "date": moment(orderReturn.created_at).format('YYYY-MM-DD'),
                "track_order_status": orderReturn.order_return_reason.reason,
                "status": "5",
                "order_status": "6"
            }
        ] };
    }

    data.forEach((item) => {
        let key;
        let date;
        switch (item.status) {
            case '1':
                key = 'order_confirm';
                date = item.date;
                break;
            case '2':
                key = 'in_transit';
                date = item.date;
                break;
            case '3':
                key = 'out_of_delivery';
                date = item.date;
                break;
            case '4':
                key = 'delivery';
                date = item.date;
                break;
            case '5':
                key = 'return';
                date = item.date;
                break;
            default:
                key = 'unknown';
        }

        if (grouped[key]) {
            grouped[key].date = grouped[key].date || date;
            grouped[key].status.push(item);
        }
    });

    return Object.values(grouped);
};


const return_order_storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const uploadPath = 'uploads/public' + '/' + 'returnOrder' + '/' + year + '/' + month + '/' + day + '/' + req.userId; 
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        // cb(null, Date.now() + 'returnOrder' + Math.random() + extension); // Rename file with a timestamp
        cb(null, file.originalname + extension); // Rename file with a timestamp
    }
});


const retrun_order_upload = multer({
    storage: return_order_storage,
});

const OrderReturnRequest = (req, res) => {
    retrun_order_upload.array('files')(req, res, async function (err) {
        if (err) {
            return res.status(400).send({
                message: process.env.ERROR_MSG,
                error: err.message,
                success: false,
            })
        }
        const schema = Joi.object().keys({
            reason_id: Joi.string().required(),
            reason_description: Joi.string().required(),
            address_id: Joi.number().required(),
            account_holder: Joi.string().required(),
            account_number: Joi.string().required(),
            cnf_account_number: Joi.string().required(),
            ifsc_code: Joi.string().required(),
            user_id: Joi.number().required(),
            created_by: Joi.number().integer().required(),
            created_at: Joi.date().iso().required(),
        });

        const dataToValidate = {
            reason_id: req.body.reason_id,
            reason_description: req.body.reason_description,
            address_id: req.body.address_id,
            account_holder: req.body.account_holder,
            account_number: req.body.account_number,
            cnf_account_number: req.body.cnf_account_number,
            ifsc_code: req.body.ifsc_code,
            user_id: req.userId,
            created_by: req.userId,
            created_at: getCurrentDateTime(),
        };

        const result = schema.validate(dataToValidate);
        if (result.error) {
            return res.status(400).send({
                error: true,
                success: false,
                status: '0',
                message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
            });
        } else {
            try {
                const files = req.files;
                if (!Array.isArray(files) || files.length > 4) {
                    return res.status(400).json({ error: 'Invalid input data.' });
                }

                const imageColumns = ['product_image_1', 'product_image_2', 'product_image_3', 'product_image_4'];
                const videoColumn = 'product_video';
                const imageData = {};
                let videoData = null;
                files.forEach((file, idx) => {
                    const mimeType = file.mimetype;
                    
                    if (mimeType.startsWith('image/') && idx < imageColumns.length) {
                        imageData[imageColumns[idx]] = file.originalname;
                    } else if (mimeType.startsWith('video/')) {
                        if (!videoData) {
                            videoData = file.originalname;
                        }
                    }
                });
                
                const orderReturnData = {
                    address_id:req.body.address_id,
                    account_holder:req.body.account_holder,
                    account_number:req.body.account_number,
                    cnf_account_number:req.body.cnf_account_number,
                    ifsc_code:req.body.ifsc_code,
                    branch_name:(req.body.branch_name) ? "" : "",
                    reason_id:req.body.reason_id,
                    reason_description:req.body.reason_description,
                    ...imageData,
                    ...(videoData ? { [videoColumn]: videoData } : {})
                };
                
                const returnOrderdata = await OrderReturn.create(orderReturnData);
                if(returnOrderdata){
                    return res.status(200).send({
                        message: 'Data Updated Successfully.',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
                else {
                    return res.status(400).send({
                        message: 'Error.',
                        error: true,
                        success: false,
                        status: '0',
                    });
                }

            } catch (error) {
                return res.status(400).send({
                    message: process.env.ERROR_MSG,
                    error: error.message,
                    success: false,
                    status: '0',
                })
            }
        }
    });
}



const GetCustomerStories = async (req, res) => {
    try {
        const customerStories = await CustomerStorie.findAll({
            where: {
                status: '1'
            },

            attributes: ['id', 'name','title','rating','description','image',[sequelize.literal("DATE_FORMAT(created_at, '%M %d, %Y')"), 'formatted_created_at']],
        })
        if (customerStories == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: "0",
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                path: process.env.DISPLAY_REVIEW_IMAGE,
                data: customerStories,
            });
        }
    } catch (error) {
        console.error('Error fetching user review:', error);
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: "0",
        });
    }
}

module.exports = {
    GetGenderList, GetColorList, GetCurrencyList, GetSizeList, GetMenuList, GetSubMenuList, GetPageList, GetPrefixList, GetOrderCoupon,
    GetTimezoneList, GetRoleList, GetStateListByCountry, GetCityListByState, GetCountryList, GetCategoryList, GetWishlist,
    AddWishlist, GetCart, addToCart, DeleteCart, GetUserAddress, AddUserAddress, GetUserAddressDetail, EditUserAddress,
    DeleteUserAddress, GetWishlistCategory, AddWishlistCategory, EditWishlistCategory, DeleteWishlistCategory, GetUserWallet,
    AddUserWallet, EditUserWallet, DeleteUserWallet, GetStaticPage, GetProduct, AddProduct, EditProduct, DeleteProduct, AddQuery,
    GetCoupon, ApplyCoupon, AddWalletMain, GetSeo, GetHomeSliderList, GetTagList, GetNewArrivals, GetAllNewArrivals, AboutUs, AddContactUs, ShopByCategory,
    GetHomeSectionList, GetTrendingProductsByCategoryId, GetProductDetail, GetCategoryDetail, GetMaterialList, GetTypeList,
    GetSubCategoryList, GetMenuData, GetProductYouMayLike, GetBlog, GetAllBlog, GetBlogDetail, getSearchAutoProduct,
    GetUserRaviewRating, AddReviewRating, GetUserReviewRatingDetail, EditReviewRating, GetFilterProduct, PayPayment,
    OrderShipmentUpdate, GetOrderList, GetOrderDetails, OrderItemCancel, OrderCancel, GetHomeGiftVisits, GetHomeGridVisits,
    GetAllProduct, GetAllCategoryList, AddFeedback, GetFeedback, DownloadInvoice, GetCategoryProduct, GetCategoryParentList,
    checkPincode, AddProductReviewLike, GetSearchKeywordProduct, GetRelatedProduct, paymentForm, GetGiftProduct, shiprocketLogin,
    AddProductReviewDisLike, shiprocketPincodeVerify, DownloadInvoice_old, updateCart, updateCartStatus, getRewardPointWallet,
    getRewardPointHistory, cancelPayment, AddBulkOrderInformation, GetSearchCategoryList, GetFavouriteColor,
    GetBestSellProduct, GetColorWiseProduct, GetAllBestSellProduct, GetProductCoupon, GetGiftCategory, GetSettingList,
    GetComboProduct, GetCompareProduct, GetProductFaqList, GetSearchKeywordTemplate, GetUserProductView, GetFirstOrderCoupon,
    GetTrendingKeywordList, checkProductStock, GetFienstProduct, GetContactUsQueryList, contactUsAdd, GetProductColorWiseProduct,
    cartGSTaddUpdate, cartGSTDetail, GetProductsByDiscount, getSearchData, GetProductsDiscountList, GetAttributeTypeList,
    GetPrimaryVariantAttribute, getVariantWiseAttribute, AddProductNotify, GetGstInformation, GetBestSellProductWise, 
    GetProductsBigSaving, GetFienstProducts, GetMenuAllCategoryProduct, GetCountryByIP, GetProductTypeList, GetSitemap, 
    GetCartAmountDetail, buyNow, removeBuyNow, applyRewardPoint, removeRewardPoint, updateProductWiseDiscount, 
    GetCartAmountList, RemoveCoupon, removeFirstOrderCoupon, CcavenuePayment, addOrderHistory, AppBanner, GetQueryList, 
    getHomepageSections, InsertDummyUser, GetAllCoupon, GetInstagramMedia, ThemeSettingActive, GetTrackOrder, OrderReturnRequest,GetCustomerStories
};