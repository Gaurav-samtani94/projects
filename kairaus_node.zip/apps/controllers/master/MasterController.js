
const City = require("../../models/master/City");
const Country = require("../../models/master/Country");
const Currency = require("../../models/master/Currency");
const Gender = require("../../models/master/Gender");
const Prefix = require("../../models/master/Prefix");
const State = require("../../models/master/State");
const Timezones = require("../../models/master/Timezones");
require('dotenv').config();
const currentDate = new Date();
const Joi = require('joi');
const GetcountryList = async (req, res) => {
    try {
        const response = await Country.findAll({
            order: [['country_name', 'ASC']],
            where: { status: '1', is_varified: '1' },
            attributes: ['id', 'country_name'],
        });
        const resp_private = await Country.findAll({
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'country_name'],
        });
        const mergedResponse = [...response, ...resp_private];
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const GetstateList = async (req, res) => {
    const country_id = req.body.country_id;
    const schema = Joi.object().keys({
        country_id: Joi.string().required(),
    });
    const dataToValidate = {
        country_id: country_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await State.findAll({
                order: [['state_name', 'ASC']],
                where: { status: '1', country_id: country_id, is_varified: '1', },
                attributes: ['id', 'state_name'],
            });
            const response_private = await State.findAll({
                // order: [['state_name', 'ASC']],
                where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
                attributes: ['id', 'state_name'],
            });
            const mergedResponse = [...response, ...response_private];
            if (!mergedResponse[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: mergedResponse,

            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


const GetcityList = async (req, res) => {
    const state_id = req.body.state_id;
    const schema = Joi.object().keys({
        state_id: Joi.string().required(),
    });
    const dataToValidate = {
        state_id: state_id,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const response = await City.findAll({
                order: [['city_name', 'ASC']],
                where: { status: '1', state_id: state_id, is_varified: '1', },
                attributes: ['id', 'city_name'],
            });
            const response_private = await City.findAll({
                order: [['city_name', 'ASC']],
                where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
                attributes: ['id', 'city_name'],
            });
            const mergedResponse = [...response, ...response_private];
            if (!mergedResponse[0]) {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }
            res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                message: process.env.APIRESPMSG_RECFOUND,
                error: false,
                success: true,
                status: '1',
                data: mergedResponse,

            });
        } catch (error) {
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const GetcurrencyList = async (req, res) => {
    try {
        const response = await Currency.findAll({
            order: [['name', 'ASC']],
            where: { status: '1', is_varified: '1', },
            attributes: ['id', 'name', 'code'],
        });
        const response_private = await Currency.findAll({
            order: [['name', 'ASC']],
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'name', 'code'],
        });
        const mergedResponse = [...response, ...response_private];
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}

const GetprefixList = async (req, res) => {
    try {
        const response = await Prefix.findAll({
            order: [['prefix', 'ASC']],
            where: { status: '1', is_varified: '1', },
            attributes: ['id', 'prefix'],
        });
        const response_private = await Prefix.findAll({
            order: [['prefix', 'ASC']],
            where: { status: '1', is_varified: '2', created_by: req.userId, user_comp_id: req.comp_id },
            attributes: ['id', 'prefix'],
        });
        const mergedResponse = [...response, ...response_private];
        if (!mergedResponse[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: mergedResponse,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const GettimezonesList = async (req, res) => {
    try {
        const response = await Timezones.findAll({
            order: [['timezone', 'ASC']],
            where: { status: '1', },
            attributes: ['id', 'timezone'],
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                message: process.env.APIRESPMSG_RECNOTFOUND,
                error: true,
                success: false,
                status: '0'
            });
        }
        res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });
    } catch (error) {
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}

module.exports = {
    GetcountryList, GetstateList, GetcityList,
    GetcurrencyList, GetprefixList,
    GettimezonesList
};    
