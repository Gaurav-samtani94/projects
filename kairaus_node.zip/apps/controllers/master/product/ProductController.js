const Product = require("../../models/master/Product");
const ProductMedia = require("../../models/master/ProductMedia");
const Wishlist = require("../../models/master/Wishlist");
const AssignPageSlider = require('../../models/master/AssignPageSlider');
const PageSlider = require('../../models/master/PageSlider');
const PageSliderImages = require('../../models/master/PageSliderImages');
const ProductNotifyModel = require("../../models/master/ProductNotifyModel");
const SiteSellerProducts = require("../../models/master/SiteSellerProducts");
require('dotenv').config();
const getCurrentDateTime = () => new Date();

const Op = require('sequelize').Op;
const sequelize = require('sequelize');
const Joi = require("joi");

const GethHomePRoduct = async (req, res) => {
    const user_id = req.body.user_id || 0;
    try {
        const finestProduct = await Product.findAll({
            limit: 10,
            //order: [['stock_quantity','DESC']],
            //order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_finest: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const bestSellProduct = await Product.findAll({
            limit: 10,
            //order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
            //order: [['stock_quantity','DESC']],
            attributes: ['id', 'sold_out_count', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_best_seller: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const arrivalsProduct = await Product.findAll({
            limit: 10,
            // order: [
            //     // ['stock_quantity','DESC']
            //     ['updated_at', 'DESC'],
            //     ['created_at', 'DESC']
            // ],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: ProductNotifyModel,
                    as: 'product_notify',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const discountedProduct = await Product.findAll({
            limit: 10,
            // order: [['discount','DESC']],
            //order: [['stock_quantity', 'DESC'],['discount', 'DESC']],
           // order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'discount', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
                // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
                sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
                'is_wishlist'
            ]],
            // where: {
            //     status: 1,
            //     sold_out_count: {
            //         [Op.gt]: 0
            //     }
            // },
            include: [
                {
                    model: ProductMedia,
                    as: 'productimages',
                    attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                    where: {file_type:'image'},
                    limit: 2,
                    required: false,
                },
                {
                    model: Wishlist,
                    as: 'wishlist',
                    attributes: ['id'],
                    where: { user_id: user_id },
                    required: false,
                },
                {
                    model: SiteSellerProducts,
                    as: 'seller_product',
                    attributes: ['seller_id'],
                    where: { seller_id: 3 },
                    required: true,
                }
            ],
            where: {
                is_home_new_arrival: '1',
                status: '1',
                is_deleted: '0',
                stock_quantity: {
                    [sequelize.Op.gt]: 0
                },
                //status: 1,
                sold_out_count: {
                    [sequelize.Op.gt]: 0
                }
            },
        });
        const response = {
            arrivalsProduct: arrivalsProduct,
            bestSellProduct: bestSellProduct,
            finestProduct: finestProduct,
            discountedProduct: discountedProduct,
        }
        if (!response) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL + 'uploads/products/',
                data: response
            });
        }
    } catch (error) {
        res.status(500).send({
            message: error,
            error: true,
            success: false,
            status: '0',
        });
    }
}
const Getmoreproduct = async (req, res) => {
    const user_id = req.body.user_id || 0;

    const schema = Joi.object().keys({
        type_id: Joi.number().integer().required()
    });
    const dataToValidate = {
        type_id: req.body.type_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        const type_id = req.body.type_id;

        const page_number = req.body.page_number || 1;
        const limit = req.body.limit || 100;
        const offset = (page_number - 1) * limit;


        if (type_id == '1') {
            const slug = req.body.slug || 'newarrival';
            const response = await get_arrivalsProduct(limit, offset, user_id);
            if (!response?.arrivalsProduct[0]) {
                res.status(404).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                    slug: slug,
                    max_price: response?.maxpriceVal,
                    totalItems: response?.count,
                    dataoncurrentPage: response?.arrivalsProduct.length,
                    totalPages: Math.ceil(response?.count / limit),
                    currentPage: page_number,
                    slider_details: response?.slider_details,
                    data: response?.arrivalsProduct
                });
            }
        } else if (type_id == '2') {
            const slug = req.body.slug || 'bestseller';
            const response = await get_bestSellProduct(limit, offset, user_id);
            if (!response?.bestSellProduct[0]) {
                res.status(404).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                    slug: slug,
                    max_price: response?.maxpriceVal,
                    totalItems: response?.count,
                    dataoncurrentPage: response?.bestSellProduct.length,
                    totalPages: Math.ceil(response?.count / limit),
                    currentPage: page_number,
                    slider_details: response?.slider_details,
                    data: response?.bestSellProduct
                });
            }
        } else if (type_id == '3') {
            const slug = req.body.slug || 'finestProduct';
            const response = await get_finestProduct(limit, offset, user_id);
            if (!response?.finestProduct[0]) {
                res.status(404).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                    slug: slug,
                    max_price: response?.maxpriceVal,
                    totalItems: response?.count,
                    dataoncurrentPage: response?.finestProduct.length,
                    totalPages: Math.ceil(response?.count / limit),
                    currentPage: page_number,
                    slider_details: response?.slider_details,
                    data: response?.finestProduct
                });
            }
        } else if (type_id == '4') {
            const slug = req.body.slug || 'bigsavings';
            const response = await get_discountedProduct(limit, offset, user_id);
            if (!response?.discountedProduct[0]) {
                res.status(404).send({
                    message: process.env.RECORD_NOT_FOUND,
                    error: true,
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    path: process.env.SITE_URL + 'uploads/products/',
                    page_slider: process.env.SITE_URL + 'uploads/page_slider/',
                    slug: slug,
                    max_price: response?.maxpriceVal,
                    totalItems: response?.count,
                    dataoncurrentPage: response?.discountedProduct.length,
                    totalPages: Math.ceil(response?.count / limit),
                    currentPage: page_number,
                    slider_details: response?.slider_details,
                    data: response?.discountedProduct
                });
            }
        } else {
            return res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        }

    }
}

async function get_discountedProduct(limit, offset, user_id) {
    var slider_details = await AssignPageSlider.findOne({
        attributes: ['page_slider_id'],
        required: false,
        where: { type: '3', category_menu_id: 2 },
        include: [
            {
                model: PageSlider,
                as: 'page_slider',
                attributes: ['id', 'title'],
                required: false,
                include: [
                    {
                        model: PageSliderImages,
                        as: 'page_slider_images',
                        attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                        required: false,
                    },
                ],
            },
        ],

    });
    const discountedProduct = await Product.findAll({
        // order: [['discount','DESC']],
        //order: [['stock_quantity', 'DESC'],['discount', 'DESC']],
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [['updated_at', 'DESC'], ['created_at', 'DESC']],
        attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'discount', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
            // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
            sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
            'is_wishlist'
        ]],

        include: [
            {
                model: ProductMedia,
                as: 'productimages',
                attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                where: {file_type:'image'},
                limit: 2,
                required: false,
            },
            {
                model: Wishlist,
                as: 'wishlist',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
    });
    const maxpriceproducts = await Product.findOne({
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
        attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        order: [
            ['price', 'DESC'],
        ]
    });
    var maxpriceVal = 0;
    if (maxpriceproducts) {
        var maxpriceVal = maxpriceproducts['price'];
    }


    const count = await Product.count({
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
    });

    const response = {
        maxpriceVal: maxpriceVal,
        slider_details: slider_details,
        discountedProduct: discountedProduct,
        count: count,
    }
    return response;

}
async function get_finestProduct(limit, offset, user_id) {

    var slider_details = await AssignPageSlider.findOne({
        attributes: ['page_slider_id'],
        required: false,
        where: { type: '3', category_menu_id: 3 },
        include: [
            {
                model: PageSlider,
                as: 'page_slider',
                attributes: ['id', 'title'],
                required: false,
                include: [
                    {
                        model: PageSliderImages,
                        as: 'page_slider_images',
                        attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                        required: false,
                    },
                ],
            },
        ],

    });
    const finestProduct = await Product.findAll({
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [['stock_quantity', 'DESC']],
        attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
            // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
            sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
            'is_wishlist'
        ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
        include: [
            {
                model: ProductMedia,
                as: 'productimages',
                attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                where: {file_type:'image'},
                limit: 2,
                required: false,
            },
            {
                model: Wishlist,
                as: 'wishlist',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: ProductNotifyModel,
                as: 'product_notify',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
        where: {
            is_finest: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
    });
    const maxpriceproducts = await Product.findOne({
        where: {
            is_finest: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
        attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        order: [
            ['price', 'DESC'],
        ]
    });
    var maxpriceVal = 0;
    if (maxpriceproducts) {
        var maxpriceVal = maxpriceproducts['price'];
    }
    const count = await Product.count({
        where: {
            is_finest: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
    });
    const response = {
        maxpriceVal: maxpriceVal,
        slider_details: slider_details,
        finestProduct: finestProduct,
        count: count,
    }
    return response;
}
async function get_bestSellProduct(limit, offset, user_id) {

    var slider_details = await AssignPageSlider.findOne({
        attributes: ['page_slider_id'],
        required: false,
        where: { type: '3', category_menu_id: 4 },
        include: [
            {
                model: PageSlider,
                as: 'page_slider',
                attributes: ['id', 'title'],
                required: false,
                include: [
                    {
                        model: PageSliderImages,
                        as: 'page_slider_images',
                        attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                        required: false,
                    },
                ],
            },
        ],

    });
    const bestSellProduct = await Product.findAll({
        limit: parseInt(limit),
        offset: parseInt(offset),
        order: [['stock_quantity', 'DESC']],
        attributes: ['id', 'sold_out_count', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
            sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
            'is_wishlist'
        ], [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']],
        include: [
            {
                model: ProductMedia,
                as: 'productimages',
                attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                where: {file_type:'image'},
                limit: 2,
                required: false,
            },
            {
                model: Wishlist,
                as: 'wishlist',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: ProductNotifyModel,
                as: 'product_notify',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
        where: {
            is_best_seller: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
    });
    const maxpriceproducts = await Product.findOne({
        where: {
            is_best_seller: '1',
            status: '1',
            is_deleted: '0'
        },
        attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        order: [
            ['price', 'DESC'],
        ]
    });
    var maxpriceVal = 0;
    if (maxpriceproducts) {
        var maxpriceVal = maxpriceproducts['price'];
    }


    const count = await Product.count({
        where: {
            is_best_seller: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
    });
    const response = {
        maxpriceVal: maxpriceVal,
        slider_details: slider_details,
        bestSellProduct: bestSellProduct,
        count: count,
    }
    return response;
}
async function get_arrivalsProduct(limit, offset, user_id) {

    var slider_details = await AssignPageSlider.findOne({
        attributes: ['page_slider_id'],
        required: false,
        where: { type: '3', category_menu_id: 1 },
        include: [
            {
                model: PageSlider,
                as: 'page_slider',
                attributes: ['id', 'title'],
                required: false,
                include: [
                    {
                        model: PageSliderImages,
                        as: 'page_slider_images',
                        attributes: ['id', 'image_title', 'button_link', 'description', 'image'],
                        required: false,
                    },
                ],
            },
        ],

    });
    const arrivalsProduct = await Product.findAll({
        limit: parseInt(limit), // Apply limit for pagination
        offset: parseInt(offset),
        order: [['stock_quantity', 'DESC']],
        attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge', 'discount', 'product_buffer_days', 'discount', 'product_buffer_days', 'usd_price', 'usd_compare_price', [
            // Set `is_wishlist` attribute to true if the product is in the user's wishlist, otherwise false
            sequelize.literal(`CASE WHEN wishlist.id IS NOT NULL THEN TRUE ELSE FALSE END`),
            'is_wishlist'],
            [sequelize.literal(`CASE WHEN product_notify.id IS NOT NULL THEN TRUE ELSE FALSE END`), 'is_notify']
        ],
        include: [
            {
                model: ProductMedia,
                as: 'productimages',
                attributes: ['id', 'product_id', 'file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                where: {file_type:'image'},
                limit: 2,
                required: false,
            },
            {
                model: Wishlist,
                as: 'wishlist',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: ProductNotifyModel,
                as: 'product_notify',
                attributes: ['id'],
                where: { user_id: user_id },
                required: false,
            },
            {
                model: SiteSellerProducts,
                as: 'seller_product',
                attributes: ['seller_id'],
                where: { seller_id: 3 },
                required: true,
            }
        ],
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
    });
    const maxpriceproducts = await Product.findOne({
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
        attributes: ['id', 'price', 'usd_price', 'usd_compare_price'],
        order: [
            ['price', 'DESC'],
        ]
    });
    var maxpriceVal = 0;
    if (maxpriceproducts) {
        var maxpriceVal = maxpriceproducts['price'];
    }


    const count = await Product.count({
        where: {
            is_home_new_arrival: '1',
            status: '1',
            is_deleted: '0',
            stock_quantity: {
                [sequelize.Op.gt]: 0
            }
        },
    });
    const response = {
        maxpriceVal: maxpriceVal,
        slider_details: slider_details,
        arrivalsProduct: arrivalsProduct,
        count: count,
    }
    return response;


}
module.exports = {
    GethHomePRoduct, Getmoreproduct

};
