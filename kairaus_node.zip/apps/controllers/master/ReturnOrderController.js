
const OrderReturn = require('../../models/master/OrderReturn')
const OrderReturnReasons = require('../../models/master/OrderReturnReasons')
const Order = require("../../models/master/Order");
const OrderItem = require("../../models/master/OrderItem");
const Product = require("../../models/master/Product");
const ProductMedia = require("../../models/master/ProductMedia");
const ProductAttributes = require("../../models/master/ProductAttributes");
const ProductAttributeType = require("../../models/master/ProductAttributeType");
const ProductAttributeValue = require("../../models/master/ProductAttributeValue");
const UserAddress = require("../../models/master/UserAddress");
const BankDetail = require("../../models/master/BankDetail");
const multer = require('multer');
const fs = require('fs');
require('dotenv').config();
const Op = require('sequelize').Op;
const getCurrentDateTime = () => new Date();
const Joi = require('joi');
const path = require('path');


// const return_order_storage = multer.diskStorage({
//     destination: (req, file, cb) => {
//         const year = getCurrentDateTime().getFullYear();
//         const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
//         const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
//         const uploadPath = 'uploads/public' + '/' + 'returnOrder' + '/' + year + '/' + month + '/' + day + '/' + req.userId; 
//         if (!fs.existsSync(uploadPath)) {
//             fs.mkdirSync(uploadPath, { recursive: true });
//         }
//         cb(null, uploadPath);
//     },
//     filename: (req, file, cb) => {
//         const extension = path.extname(file.originalname);
//         // cb(null, Date.now() + 'returnOrder' + Math.random() + extension); // Rename file with a timestamp
//         cb(null, file.originalname + extension); // Rename file with a timestamp
//     }
// });


// const retrun_order_upload = multer({ 
//     storage: return_order_storage,
// });
const live_tender_doc_storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const year = getCurrentDateTime().getFullYear();
        const month = String(getCurrentDateTime().getMonth() + 1).padStart(2, '0');
        const day = String(getCurrentDateTime().getDate()).padStart(2, '0');
        const uploadPath = 'uploads/public' + '_' + '4'+ '/';
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        //console.log("Ash :- "+extension);
        cb(null, Date.now() + 'tenderdoc_' + Math.random() + extension); // Rename file with a timestamp
    },
});


const tender_doc_upload = multer({ storage: live_tender_doc_storage, limits: { fileSize: 10 * 1024 * 1024 } });



// const OrderReturnRequest = async (req, res) => {
//     const schema = Joi.object().keys({
//         reason_id: Joi.string().required(),
//         reason_description: Joi.string().required(),
//         address_id: Joi.number().required(),
//         account_holder: Joi.string().required(),
//         account_number: Joi.string().required(),
//         cnf_account_number: Joi.string().required(),
//         ifsc_code: Joi.string().required(),
//         user_id: Joi.number().required(),
//         created_by: Joi.number().integer().required(),
//         created_at: Joi.date().iso().required(),
//     });

//     const dataToValidate = {
//         reason_id: req.body.reason_id,
//         reason_description: req.body.reason_description,
//         address_id: req.body.address_id,
//         account_holder: req.body.account_holder,
//         account_number: req.body.account_number,
//         cnf_account_number: req.body.cnf_account_number,
//         ifsc_code: req.body.ifsc_code,
//         user_id: req.userId,
//         created_by: req.userId,
//         created_at: getCurrentDateTime(),
//     };

//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         return res.status(400).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
//         });
//     } 
//     if (result.error) {
//         return res.status(400).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
//         });
//     } else {
//         try {



         
//         var files = req.files && req.files.files
//         ? Array.isArray(req.files.files)
//             ? req.files.files
//             : [req.files.files]
//         : [];

//         const allowedImageTypes = ['image/jpeg', 'image/png', 'image/gif'];
//         const allowedVideoTypes = ['video/mp4', 'video/mkv', 'video/avi'];
        
//         if (files.length > 5) {
//             return res.status(403).send({
//                 message: "You can only upload a maximum of 4 images and 1 video.",
//                 status: '0',
//                 success: false,
//                 error: true,
//             });
//         }

//         let imageCount = 0;
//         let videoCount = 0;

//         files.forEach(file => {
//             if (allowedImageTypes.includes(file.mimetype)) {
//                 imageCount++;
//             } else if (allowedVideoTypes.includes(file.mimetype)) {
//                 videoCount++;
//             }
//         });

//         if (imageCount > 4 || videoCount > 1) {
//             return res.status(403).send({
//                 message: `You can only upload a maximum of 4 images and 1 video. Current: ${imageCount} images, ${videoCount} videos.`,
//                 status: '0',
//                 success: false,
//                 error: true,
//             });
//         }
//         const imageColumns = ['product_image_1', 'product_image_2', 'product_image_3', 'product_image_4'];
//         const videoColumn = 'product_video';
//         const imageData = {};
//         let videoData = null;
//         // Counter for sequential image assignment
//         let imageCounter = 0;

//         files.forEach((file) => {
//             const mimeType = file.mimetype;
//             if (mimeType.startsWith('image/') && imageCounter < imageColumns.length) {
//                 // Assign the image to the next available column
//                 imageData[imageColumns[imageCounter]] = file.name;
//                 imageCounter++; // Increment the counter
//             } else if (mimeType.startsWith('video/') && !videoData) {
//                 // Save the first video
//                 videoData = file.name;
//             }
//         });

//         // Create the order return data
//         const orderReturnData = {
//             address_id: req.body.address_id,
//             account_holder: req.body.account_holder,
//             account_number: req.body.account_number,
//             cnf_account_number: req.body.cnf_account_number,
//             ifsc_code: req.body.ifsc_code,
//             reason_id: req.body.reason_id,
//             reason_description: req.body.reason_description,
//             ...imageData,
//             ...(videoData ? { [videoColumn]: videoData } : {})
//         };

//             // Example output for debugging
//             const returnOrderdata = await OrderReturn.create(orderReturnData);
//             if(returnOrderdata){
//                 return res.status(200).send({
//                     message: 'Request has been sent successfully',
//                     error: false,
//                     success: true,
//                     status: '1',
//                 });
//             }
//             else {
//                 return res.status(400).send({
//                     message: 'Error.',
//                     error: true,
//                     success: false,
//                     status: '0',
//                 });
//             }

//         } catch (error) {
//             return res.status(400).send({
//                 message: process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             })
//         }
//     }
// };

const OrderReturnRequest = async (req, res) => {
   
    const schema = Joi.object({
        reason_id: Joi.string().required().label("Reason"),
        address_id: Joi.string().required().label("Address"),
        payment_type: Joi.string().required().label("Payment Type"),
        bank_id: Joi.number().optional(), // bank_id is optional
        account_holder: Joi.when('bank_id', {
            is: 0,
            then: Joi.string().required().label("Account Holder")
                .messages({
                    "any.required": "Account holder is required when Bank ID is 0"
                }),
            otherwise: Joi.string()
                .optional()
                .empty("")
                .messages({
                    "string.empty": "Account holder is not allowed to be empty"
                })
        }),
        account_number: Joi.when('bank_id', {
            is: 0,
            then: Joi.string().required().label("Account Number")
                .messages({
                    "any.required": "Account number is required when Bank ID is 0"
                }),
            otherwise: Joi.string()
                .optional()
                .empty("")
                .messages({
                    "string.empty": "Account number is not allowed to be empty"
                })
        }),
        cnf_account_number: Joi.when('bank_id', {
            is: 0,
            then: Joi.string().required().label("Account cnf")
                .messages({
                    "any.required": "Account cnf is required when Bank ID is 0"
                }),
            otherwise: Joi.string()
                .optional()
                .empty("")
                .messages({
                    "string.empty": "Account cnf is not allowed to be empty"
                })
        }),
        ifsc_code: Joi.when('bank_id', {
            is: 0,
            then: Joi.string().required().label("IFSC")
                .messages({
                    "any.required": "IFSC is required when Bank ID is 0"
                }),
            otherwise: Joi.string()
                .optional()
                .empty("")
                .messages({
                    "string.empty": "IFSC is not allowed to be empty"
                })
        })
    });

    const dataToValidate = {
        reason_id: req.body.reason_id,
        address_id: req.body.address_id,
        bank_id: req.body.bank_id,
        account_holder: req.body.account_holder,
        account_number: req.body.account_number,
        cnf_account_number: req.body.cnf_account_number,
        ifsc_code: req.body.ifsc_code,
        payment_type: req.body.payment_type,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
        });
    } 
    if (result.error) {
        return res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
        });
    } else {
        try {
        var bank_id = req.body.bank_id || 0;
        var files = req.files && req.files.files
        ? Array.isArray(req.files.files)
            ? req.files.files
            : [req.files.files]
        : [];

        const allowedImageTypes = ['image/jpeg', 'image/png', 'image/gif'];
        const allowedVideoTypes = ['video/mp4', 'video/mkv', 'video/avi'];
        if (files.length > 5) {
            return res.status(403).send({
                message: "You can only upload a maximum of 4 images and 1 video.",
                status: '0',
                success: false,
                error: true,
            });
        }

        let imageCount = 0;
        let videoCount = 0;

        files.forEach(file => {
            if (allowedImageTypes.includes(file.mimetype)) {
                imageCount++;
            } else if (allowedVideoTypes.includes(file.mimetype)) {
                videoCount++;
            }
        });

        if (imageCount > 4 || videoCount > 1) {
            return res.status(403).send({
                message: `You can only upload a maximum of 4 images and 1 video. Current: ${imageCount} images, ${videoCount} videos.`,
                status: '0',
                success: false,
                error: true,
            });
        }
        const imageColumns = ['product_image_1', 'product_image_2', 'product_image_3', 'product_image_4'];
        const videoColumn = 'product_video';
        const imageData = {};
        let videoData = null;
        // Counter for sequential image assignment
        let imageCounter = 0;

        files.forEach((file) => {
            const mimeType = file.mimetype;
            if (mimeType.startsWith('image/') && imageCounter < imageColumns.length) {
                imageData[imageColumns[imageCounter]] = file.name;
                imageCounter++;
            } else if (mimeType.startsWith('video/') && !videoData) {
                videoData = file.name;
            }
        });

        const orderReturnData = {
            order_id: req.body.order_id,
            order_item_id: req.body.order_item_id,
            address_id: req.body.address_id,
            reason_id: req.body.reason_id,
            reason_description: req.body.reason_description,
            created_at: getCurrentDateTime(),
            ...imageData,
            ...(videoData ? { [videoColumn]: videoData } : {})
        };
        var returnOrderdata = await OrderReturn.create(orderReturnData);
        //end

        if(bank_id == 0 && req.body.payment_type == 'cod'){
            const bankData = {
                user_id: req.userId,
                order_return_id:returnOrderdata.id,
                address_id: req.body.address_id,
                account_holder: req.body.account_holder,
                account_number: req.body.account_number,
                cnf_account_number: req.body.cnf_account_number,
                ifsc_code: req.body.ifsc_code,
                branch_name: req.body.branch_name || '',
            };
            await BankDetail.create(bankData);
        }
        await OrderItem.update(
            {
                status: 5,
            },
            {
                where: {
                    order_id: req.body.order_id,
                    id: req.body.order_item_id,
                },
            });

        //end

        if(returnOrderdata){
                return res.status(200).send({
                    message: 'Request has been sent successfully',
                    error: false,
                    success: true,
                    status: '1',
                });

            }else {
                return res.status(400).send({
                    message: 'Error.',
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            return res.status(400).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            })
        }
    }
};


// const GetOrderListByOrderId = async (req, res) => {
//     const schema = Joi.object().keys({
//         order_id: Joi.number().required(),
//         order_item_id: Joi.string().required(),
//     });

//     const dataToValidate = {
//         order_id: req.body.order_id,
//         order_item_id: req.body.order_item_id,
//     };

//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(400).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
//         });
//     } else {

//         const user_id =  req.userId;
//             try {
//                 const orderDetail = await Order.findAll({
//                     where: {
//                         // user_id:req.user_id,
//                         id:req.body.order_id
//                     },
//                     // attributes:['id','transaction_id','total_amount','discount_amt','reward_amt','shipping_amt','tax_amt','paid_amount','payment_type','created_at'],
//                     include:[
//                         {
//                             model:OrderItem,
//                             where: {
//                                 id: {
//                                     [Op.in]: req.body.order_item_id.split(',') // Split comma-separated IDs into an array
//                                 }
//                             },
//                             as:'order_item',
//                             attributes:['id','order_id','product_id','quantity','price',['awb_code','tracking_id'],'status'],
//                             required: false,
//                             include:[
//                                 {
//                                     model:Product,
//                                     as:"products",
//                                     attributes:['id','product_name','product_slug','image_alt','compare_price'],
//                                     required: false,
//                                     include: [{
//                                         model: ProductMedia,
//                                         as: 'productimage',
//                                         attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
//                                         required: false,
//                                 },
//                                 {
//                                     model: ProductAttributes,
//                                     as: 'product_attribute',
//                                     attributes: ['id'],
//                                     required: false,
//                                     include:[
//                                         {
//                                             model: ProductAttributeType,
//                                             as: 'product_attr_type',
//                                             attributes: ['id', 'attr_type_name'],
//                                             required: false,
//                                         },
//                                         {
//                                             model: ProductAttributeValue,
//                                             as: 'product_attr_value',
//                                             attributes: ['id', 'attr_val_name'],
//                                             required: false,
//                                         }
//                                     ],
//                                 },
//                                 ]

//                             },
//                             {
//                                 model:OrderReturn,
//                                 as:"order_return",
//                                 attributes:['account_holder','account_number','cnf_account_number','ifsc_code','branch_name'],
//                                 required: false,
//                             },]
//                         },
//                         {
//                             model:UserAddress,
//                             as:'user_address',
//                             required: false,
//                         }

//                     ],
//                 });
                
//             if (!orderDetail){
//                 res.status(202).send({
//                     message:process.env.RECORD_NOT_FOUND,
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             }else{
//                 res.status(200).send({
//                     message:process.env.SUCCESS_MSG,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     data:orderDetail,
//                     ORDERID: process.env.ORDERID,
//                     path: process.env.SITE_URL + 'uploads/products/',
//                 });
//             }
//         } catch(error) {
//             res.status(500).send({
//                 message:process.env.ERROR_MSG,
//                 error: error.message,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }

const GetOrderListByOrderId = async (req, res) => {
    const schema = Joi.object().keys({
        order_id: Joi.number().required(),
        order_item_id: Joi.string().required(),
    });

    const dataToValidate = {
        order_id: req.body.order_id,
        order_item_id: req.body.order_item_id,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: (result.error) ? result.error.details[0].message : result_partner.error.details[0].message
        });
    } else {

        const user_id =  req.userId;
            try {
                const orderDetail = await Order.findAll({
                    where: {
                        id:req.body.order_id
                    },
                    include:[
                        {
                            model: OrderReturn,
                            as: 'order_return',
                            where: {
                                order_id:req.body.order_id
                            },
                            attributes:['id','order_id','order_item_id'],
                            required: false,
                            include:[
                                {
                                    model: BankDetail,
                                    as: 'bank_details',
                                    attributes:[['id','bank_id'],'account_holder','account_number','cnf_account_number','ifsc_code','branch_name'],
                                    required: false,
                                },
                            ],
                        },
                        {
                            model:OrderItem,
                            where: {
                                id: {
                                    [Op.in]: req.body.order_item_id.split(',') // Split comma-separated IDs into an array
                                }
                            },
                            as:'order_item_return',
                            attributes:['id','order_id','product_id','quantity','price',['total_amt','return_amount'],['awb_code','tracking_id'],'status'],
                            required: false,
                            include:[
                                {
                                    model:Product,
                                    as:"products",
                                    attributes:['id','product_name','product_slug','image_alt','compare_price'],
                                    required: false,
                                    include: [{
                                        model: ProductMedia,
                                        as: 'productimage',
                                        attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                                        required: false,
                                },
                                {
                                    model: ProductAttributes,
                                    as: 'product_attribute',
                                    attributes: ['id'],
                                    required: false,
                                    include:[
                                        {
                                            model: ProductAttributeType,
                                            as: 'product_attr_type',
                                            attributes: ['id', 'attr_type_name'],
                                            required: false,
                                        },
                                        {
                                            model: ProductAttributeValue,
                                            as: 'product_attr_value',
                                            attributes: ['id', 'attr_val_name'],
                                            required: false,
                                        }
                                    ],
                                },
                                ]

                            },
                           
                        ]
                        },
                        {
                            model:UserAddress,
                            as:'user_address',
                            required: false,
                        }

                    ],
                });
                // var return_order = await OrderReturn.findAll({
                //     where: {
                //         order_item_id: {
                //             [Op.in]: req.body.order_item_id.split(',')
                //         },
                //     },
                //     attributes:['id','order_id','order_item_id'],
                //     required: false,
                //     include:[
                //         {
                //             model: BankDetail,
                //             as: 'bank_details',
                //             attributes:[['id','bank_id'],'account_holder','account_number','cnf_account_number','ifsc_code','branch_name'],
                //             required: false,
                //         },
                //     ],
                // });

                const return_order = await BankDetail.findAll({
                    where: {
                        user_id: user_id,
                    },
                    attributes:[['id','bank_id'],'account_holder','account_number','cnf_account_number','ifsc_code','branch_name'],
                    order: [["id", "DESC"]],
                });
            if (!orderDetail){
                res.status(202).send({
                    message:process.env.RECORD_NOT_FOUND,
                    error: true,
                    success: false,
                    status: '0'
                });
            }else{
                res.status(200).send({
                    message:process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: '1',
                    data:orderDetail,
                    return_order:return_order,
                    ORDERID: process.env.ORDERID,
                    path: process.env.SITE_URL + 'uploads/products/',
                });
            }
        } catch(error) {
            res.status(500).send({
                message:process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
}

const GetReturnResonsList = async (req, res) => {
    try {
        const returnReason = await OrderReturnReasons.findAll({
            where: {
                status: '1'
            },
        });
        if (returnReason == 0) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: returnReason
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}


// BankDetail

const GetBankDetailList = async (req, res) => {
    const user_id = req.userId;
    try {

        const bankDetail = await BankDetail.findAll({
            where: {
                user_id: user_id,
            },
            attributes:[['id','bank_id'],'account_holder','account_number','cnf_account_number','ifsc_code','branch_name'],
            order: [["id", "DESC"]],
        });
        if (!bankDetail) {
            res.status(202).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: "0",
            });
        } else {
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                bankDetail,
            });
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: "0",
            msg: error.message
        });
    }
};

module.exports = {
    OrderReturnRequest, GetOrderListByOrderId, GetReturnResonsList,GetBankDetailList
};