const Role = require("../../models/master/Role");
const Joi = require('joi');
require('dotenv').config();
const currentDate = new Date();

const InsertUserRole = async (req, res) => {

    const dataToValidate = {
        user_comp_id: req.comp_id,
        role_name: req.body.role_name,
        created_by: req.userId,
        created_at: currentDate,
    };

    const schema = Joi.object().keys({
        role_name: Joi.string().required(),
        user_comp_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {

            const existData = await Role.findOne({ where: { user_comp_id: req.comp_id, role_name: req.body.role_name }, attributes: ['id'] });
            // console.log(existCompany.dataValues.id);
            if (existData) {
                return res.status(process.env.APIRESPCODE_ALREADY_EXIST).send({
                    message: process.env.APIRESPMSG_RECALREADYEXISTS,
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const user = await Role.create(dataToValidate)
                res.send({
                    message: process.env.APIRESPMSG_RECINSERTED,
                    error: false,
                    success: true,
                    status: '1',
                    data: user,
                });
            }

        } catch (error) {
            // res.status(process.env.).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}







//Lising of Role..
const ListUserRole = async (req, res) => {
    try {
        const response = await Role.findAll({
            order: [['role_name', 'ASC']],
            where: { status: '1', user_comp_id: req.comp_id },
            attributes: ['id', 'role_name', 'deletable'],
        });
        if (!response[0]) {
            return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                error: true,
                success: false,
                status: '0',
                message: process.env.APIRESPMSG_RECNOTFOUND,
            });
        }
        res.send({
            message: process.env.APIRESPMSG_RECFOUND,
            error: false,
            success: true,
            status: '1',
            data: response,

        });
    } catch (error) {
        // res.status(400).send({ error: error.message });
        res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}






//Lising of Role..
const DeleteUserRole = async (req, res) => {
    const dataToValidate = {
        role_id: req.body.role_id,
        modified_by: req.userId,
        updated_at: currentDate,
    };

    const schema = Joi.object().keys({
        role_id: Joi.number().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Role.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.role_id }, attributes: ['id'] });
            // console.log(existData.dataValues.id);
            if (existData) {
                const UpdateDataArr = {
                    status: "0",
                    modified_by: req.userId
                }
                const update = await Role.update(UpdateDataArr, {
                    where: { user_comp_id: req.comp_id, id: req.body.role_id, deletable: '1' }
                });

                res.send({
                    message: process.env.APIRESPMSG_RECDELETED,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });

            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//Single Data Get of Role..
const GetByIDUserRole = async (req, res) => {
    const schema = Joi.object().keys({
        role_id: Joi.number().required(),
    });
    const dataToValidate = {
        role_id: req.body.role_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Role.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.role_id } });
            if (existData) {
                res.send({
                    message: process.env.APIRESPMSG_RECFOUND,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

//Update By Id Role..
const UpdateByIDUserRole = async (req, res) => {
    const dataToValidate = {
        update_role_id: req.body.update_role_id,
        role_name: req.body.role_name,
        modified_by: req.userId,
        updated_at: currentDate,
    };

    const schema = Joi.object().keys({
        update_role_id: Joi.number().required(),
        role_name: Joi.string().required(),
        modified_by: Joi.number().required(),
        updated_at: Joi.date().iso().required(),
    });

    //console.log(dataToValidate);
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(process.env.APIRESPCODE_VALIDATION).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await Role.findOne({ where: { status: "1", user_comp_id: req.comp_id, id: req.body.update_role_id }, attributes: ['id'] });
            if (existData) {
                const existData_upd = await Role.findOne({ where: { status: "1", user_comp_id: req.comp_id, role_name: req.body.role_name }, attributes: ['id'] });
                if (existData_upd) {
                    return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                        message: process.env.APIRESPMSG_RECALREADYEXISTS,
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
                const update = await Role.update(dataToValidate, {
                    where: { status: "1", user_comp_id: req.comp_id, id: req.body.update_role_id, deletable: '1' }
                });

                res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
                    message: process.env.APIRESPMSG_RECUPDATED,
                    error: false,
                    success: true,
                    status: '1',
                    data: existData,
                });
            } else {
                return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
                    message: process.env.APIRESPMSG_RECNOTFOUND,
                    error: true,
                    success: false,
                    status: '0',
                });
            }

        } catch (error) {
            // res.status(400).send({ error: error.message });
            res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}


module.exports = {
    InsertUserRole, ListUserRole, DeleteUserRole, GetByIDUserRole, UpdateByIDUserRole
};    
