// const { Sequelize, DataTypes, Op } = require('sequelize');
// const jwt = require('jsonwebtoken');
// const Joi = require('joi');
// require('dotenv').config();


// const max = 10;
// const min = 1;
// const moment = require('moment-timezone');
// const path = require('path');
// const fs = require('fs');
// const { sendDynamicEmail, sendEmailWith_temp } = require('../config/mail');
// const sendMail = async (req, res) => {
//     try {
//         // const dynamicData = {
//         //     subject: 'Dynamic Subject',
//         //     body: 'Dynamic Body of the Email',
//         // };
//         const response = sendDynamicEmail(
//             'sabhimanyu336@gmail.com',
//             'Dynamic Subject',
//             'Dynamic Body of the Email',
//             '<p>Dynamic HTML body of the email</p>',
//         );
//         res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//             message: process.env.APIRESPMSG_RECDELETED,
//             error: false,
//             success: true,
//             status: '1',
//             data: response
//         });
//     } catch (error) {
//         res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//             message: process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });

//     }

// }
// const sendMail_temp = async (req, res) => {
//     try {
//         const dynamicData = {
//             subject: 'Dyssssssssnamic Subject',
//             body: 'Dynasssssmic Body of the Email',
//         };
//         const templatePath = path.join(__dirname, '../emailtemplates/emailTemplate.hbs');
//         const response = sendEmailWith_temp(
//             'sabhimanyu336@gmail.com',
//             null,
//             // 'Dynamic Body of the Email',
//             null,
//             templatePath,
//             dynamicData
//         );
//         res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//             message: process.env.APIRESPMSG_RECDELETED,
//             error: false,
//             success: true,
//             status: '1',
//             data: response
//         });
//     } catch (error) {
//         res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//             message: process.env.ERROR_MSG,
//             error: error.message,
//             success: false,
//             status: '0',
//         });

//     }

// }
// // const tenderlist = async (req, res) => {
// //     const schema = Joi.object().keys({
// //         limit: Joi.string().required(),
// //         page_number: Joi.string().required(),

// //     });
// //     const dataToValidate = {
// //         limit: req.body.limit,
// //         page_number: (req.body.page_number == 0) ? '1' : req.body.page_number,
// //     }
// //     const result = schema.validate(dataToValidate);
// //     if (result.error) {
// //         res.status(process.env.APIRESPCODE_VALIDATION).send({
// //             message: result.error.details[0].message,
// //             error: true,
// //             success: false,
// //             status: '0'
// //         });
// //     } else {
// //         try {

// //             const page_number = parseInt(dataToValidate.page_number) || 1;
// //             const limit = parseInt(dataToValidate.limit) || 10;
// //             const offset = (parseInt(page_number) - 1) * parseInt(limit);

// //             //filter record 
// //             const filterConditions = {};
// //             if (req.body.country_id) {
// //                 filterConditions.country_id = req.body.country_id;
// //             }

// //             if (req.body.state_id) {
// //                 filterConditions.state_id = req.body.state_id;
// //             }

// //             if (req.body.sector_id) {
// //                 filterConditions.sector_id = req.body.sector_id;
// //             }

// //             if (req.body.sector_id) {
// //                 filterConditions.sector_id = req.body.sector_id;
// //             }
// //             if (req.body.tender_keyword) {
// //                 filterConditions.tender_name = {
// //                     [Op.like]: `%${req.body.tender_keyword}%`,
// //                 };
// //             }

// //             if ((req.body.from_date) && (req.body.to_date)) {
// //                 // const fromDate = moment.tz(req.body.from_date, 'YYYY-MM-DD', 'Asia/Kolkata').toDate();
// //                 // const toDate = moment.tz(req.body.to_date, 'YYYY-MM-DD', 'Asia/Kolkata').toDate();
// //                 const startDate = new Date(req.body.from_date);
// //                 const endDate = new Date(req.body.to_date);
// //                 console.log(startDate, 'startDatestartDatestartDatestartDatestartDate')
// //                 console.log(endDate, 'endDateendDateendDateendDateendDateendDateendDate')
// //                 filterConditions.created_at = {
// //                     [Op.between]: [startDate.toISOString(), endDate.toISOString()],
// //                 };
// //                 // console.log(req.body.from_date, 'req.body.from_datereq.body.from_date')

// //                 // const fromDate = moment(req.body.from_date, 'YYYY-MM-DD').toDate();
// //                 // console.log(fromDate, 'fromDatefromDatefromDatefromDatefromDate')
// //                 // const toDate = moment(req.body.to_date, 'YYYY-MM-DD').toDate();
// //                 // filterConditions.created_at = {
// //                 //     [Sequelize.Op.between]: [fromDate, toDate],
// //                 // };
// //             }
// //             const { count, rows } = await TenderModel.findAndCountAll({
// //                 order: [['id', 'DESC']],
// //                 where: { status: '1' },
// //                 where: filterConditions,
// //                 logging: console.log,
// //                 offset,
// //                 limit,
// //                 include: [{
// //                     model: Country,
// //                     attributes: ['country_name'],
// //                     where: { status: '1' },
// //                     required: false,
// //                 },
// //                 {
// //                     model: State,
// //                     attributes: ['state_name'],
// //                     where: { status: '1' },
// //                     required: false,
// //                 },
// //                 ]
// //             })
// //             if (!rows[0]) {
// //                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
// //                     message: process.env.APIRESPMSG_RECNOTFOUND,
// //                     error: true,
// //                     success: false,
// //                     status: '0'
// //                 });
// //             }
// //             else {
// //                 // const count_data = await TenderModel.count();
// //                 res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
// //                     message: process.env.APIRESPMSG_RECFOUND,
// //                     error: false,
// //                     success: true,
// //                     status: '1',
// //                     totalItems: count,
// //                     totalPages: Math.ceil(count / limit),
// //                     currentPage: page_number,
// //                     dataoncurrentPage: rows.length,
// //                     data: rows,
// //                 });
// //             }
// //         } catch (error) {
// //             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
// //                 message: process.env.ERROR_MSG,
// //                 error: true,
// //                 success: false,
// //                 status: '0',
// //             });
// //         }
// //     }
// // }

// const curl = async (req, res) => {
//     const axios = require('axios');
//     const FormData = require('form-data');
//     let data = new FormData();
//     data.append('financial_year', '2023-2024');
//     data.append('tender_date', '2023-10-31');

//     let config = {
//         method: 'post',
//         maxBodyLength: Infinity,
//         url: 'https://api.growthgrids.com/bd_growthgrids/index.php/gg_alltenderlist',
//         headers: {
//             'Token': 'nrWY4SPrEZ2?Z14mYDwWNj5M7GcUrra77EWt8?vC2w4YXGwsU#mJyFQTcwX@',
//             'Cookie': 'PHPSESSID=udoh75us0mcv924cn9uitjlhfd',
//             ...data.getHeaders()
//         },
//         data: data
//     };
//     const response = await axios.request(config)
//     // const response_data = response;

//     const response_data = Object.values(response.data);

//     // const response_data = JSON.parse(response);
//     try {
//         if (response_data) {
//             // console.log(response_data[3], 'dddd')
//             const fileRecords = await TenderModel.bulkCreate(response_data[3].map((data) => ({

//                 user_comp_id: req.comp_id,
//                 gg_tenderID: data.gg_tenderID,
//                 tender_name: data.tender_details,
//                 tnd_ref_id: data.tnd_ref_id,
//                 tender_gov_id: data.tender_gov_id,
//                 tender_cost: data.tender_amnt_val,
//                 tender_emd_amnt_val: data.tender_emd_amnt_val,
//                 cycle_id: 1,
//                 source_id: '1',
//                 national_intern: '1',
//                 currency_id: '1',
//                 country_id: 1,
//                 funding_id: 1,
//                 region_id: 1,
//                 state_id: 1,
//                 city_id: 1,
//                 client_id: 1,
//                 sector_id: 1,
//                 // Math.random() * (max - min) + min
//                 client_cont_person: data.client_cont_person,
//                 client_cont_address: data.client_cont_address,
//                 bid_opening_place: data.bid_opening_place,
//                 submission_start_date: data.submission_start_date,
//                 submission_end_date: data.submission_end_date,

//                 pre_bid_meeting_place: data.pre_bid_meeting_place,
//                 pre_bid_meeting_address: data.pre_bid_meeting_address,
//                 pre_bid_meeting_date: data.pre_bid_meeting_date,
//                 pre_bid_meeting_time: data.pre_bid_meeting_time,

//                 tnd_url: data.tnd_url,
//                 created_at: data.entry_date,
//                 created_by: req.userId,
//             })));
//             res.status(200).send({
//                 message: `${fileRecords.length} records inserted successfully`,
//                 error: false,
//                 success: true,
//                 status: '1',
//             });
//         }
//     } catch (error) {
//         res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//             message: process.env.ERROR_MSG,
//             error: error.message,
//             success: false,
//             status: '0',
//         });
//         // Handle the error appropriately
//     }
//     // if (Array.isArray(response_data)) {

//     //     const fileRecords = await TenderModel.bulkCreate(response_data.map((data) => ({
//     //         user_comp_id: req.comp_id,
//     //         gg_tenderID: data.gg_tenderID,
//     //         tender_name: data.tender_details,
//     //         tnd_ref_id: data.tnd_ref_id,
//     //         tender_gov_id: data.tender_gov_id,
//     //         tender_cost: data.tender_amnt_val,
//     //         tender_emd_amnt_val: data.tender_emd_amnt_val,
//     //         cycle_id: 1,
//     //         source_id: '3',
//     //         national_intern: '1',

//     //         country_id: 1,

//     //         state_id: Math.random() * (max - min) + min,
//     //         city_id: Math.random() * (max - min) + min,
//     //         client_id: Math.random() * (max - min) + min,
//     //         sector_id: Math.random() * (max - min) + min,

//     //         client_cont_person: data.client_cont_person,
//     //         client_cont_address: data.client_cont_address,
//     //         bid_opening_place: data.bid_opening_place,
//     //         submission_start_date: data.submission_start_date,
//     //         submission_end_date: data.submission_end_date,

//     //         pre_bid_meeting_place: data.pre_bid_meeting_place,
//     //         pre_bid_meeting_address: data.pre_bid_meeting_address,
//     //         pre_bid_meeting_date: data.pre_bid_meeting_date,
//     //         pre_bid_meeting_time: data.pre_bid_meeting_time,

//     //         tnd_url: data.tnd_url,
//     //         created_at: data.entry_date,
//     //         created_by: req.userId,
//     //     })));
//     // } else {
//     //     console.error("response_data is not an array.");
//     //     // Handle the data structure issue accordingly
//     // }

//     // .then(async (response) => {
//     //     const responseData = response.data;
//     //     // Insert the data into the MySQL table
//     //     responseData.forEach((data) => {
//     //         // Transform and validate data if needed
//     //         const transformedItem = {
//     //             // Map the properties as needed based on your model structure
//     //             user_comp_id: req.comp_id,
//     //             gg_tenderID: data.gg_tenderID,
//     //             tender_name: data.tender_details,
//     //             tnd_ref_id: data.tnd_ref_id,
//     //             tender_gov_id: data.tender_gov_id,
//     //             tender_cost: data.tender_amnt_val,
//     //             tender_emd_amnt_val: data.tender_emd_amnt_val,
//     //             cycle_id: 1,
//     //             source_id: '3',
//     //             national_intern: '1',

//     //             country_id: 1,

//     //             state_id: Math.random() * (max - min) + min,
//     //             city_id: Math.random() * (max - min) + min,
//     //             client_id: Math.random() * (max - min) + min,
//     //             sector_id: Math.random() * (max - min) + min,

//     //             client_cont_person: data.client_cont_person,
//     //             client_cont_address: data.client_cont_address,
//     //             bid_opening_place: data.bid_opening_place,
//     //             submission_start_date: data.submission_start_date,
//     //             submission_end_date: data.submission_end_date,

//     //             pre_bid_meeting_place: data.pre_bid_meeting_place,
//     //             pre_bid_meeting_address: data.pre_bid_meeting_address,
//     //             pre_bid_meeting_date: data.pre_bid_meeting_date,
//     //             pre_bid_meeting_time: data.pre_bid_meeting_time,

//     //             tnd_url: data.tnd_url,
//     //             created_at: data.entry_date,
//     //             created_by: req.userId,
//     //         };
//     //         recordsToInsert.push(transformedItem);
//     //     });

//     //     await TenderModel.bulkCreate(recordsToInsert);
//     // })

//     // .catch((error) => {
//     //     res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//     //         message: process.env.ERROR_MSG,
//     //         error: error.message,
//     //         success: false,
//     //         status: '0',
//     //     });
//     // });

// }

// const download_file = async (req, res) => {
//     const path = require('path');

//     const file_data = await ProspectiveDocs.findOne({ where: { id: '264' } })

//     // Construct the full path to the file
//     // const filePath = path.join('/opt/lampp/htdocs/bidrid/', file_data.doc_path + '/' + file_data.doc_name);
//     const filePath = 'uploads/public_4/prospective/2023/10/23/376/1698040086715-gg_client_master_subdiv.xlsx';
//     if (fs.existsSync(filePath)) {
//         console.log('File exists:', filePath);
//     } else {
//         console.error('File does not exist:', filePath);
//     }
//     // console.log(filePath, 'filePathfilePath');
//     // // Set appropriate headers for the response
//     res.setHeader('Content-disposition', 'attachment; filename=' + path.basename(filePath));
//     res.setHeader('Content-type', 'application/octet-stream');

//     const fileStream = fs.createReadStream(filePath);  // Use the corrected file path
//     fileStream.pipe(res);

//     // res.setHeader('Content-Disposition', `attachment; filename=${file_data.doc_name}`);
//     // res.setHeader('Content-Type', 'application/octet-stream');

//     // // Send the file content as the response
//     // res.send(file_data.doc_name);

// }
// module.exports = {
//     curl, sendMail, sendMail_temp, download_file
// };  