const bodyParser = require('body-parser');
const express = require('express')
const jwt = require('jsonwebtoken');
const Joi = require('joi');
const MembershipMaster = require('../models/master/MembershipMaster');
const MembershipFeatures = require('../models/master/MembershipFeatures');
const RewardEvents = require('../models/master/RewardEvents');


const getMembershipDetails = async (req, res) => {
   
        try {
            
            const membershipData = await MembershipMaster.findAll({
                where: {
                    status: '1',
                },
                attributes: ['id', 'membership_name'],
                
                include: [
                    {
                        model: MembershipFeatures,
                        as: 'membership_features',
                        attributes: ['id', 'title', 'description'],
                        required: false
                    }
                ]
            });

            const rewardEvents = await RewardEvents.findAll({
                where:{
                    status:'1'
                },
                attributes:['id','event_name','points','description']
            });

            res.send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: membershipData,
                reward_events:rewardEvents
            });
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
module.exports = {
    getMembershipDetails
};