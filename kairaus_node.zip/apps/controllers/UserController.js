const bodyParser = require('body-parser');
const express = require('express')
const jwt = require('jsonwebtoken');
const Joi = require('joi');
const User = require('../../apps/models/User');
const Country = require('../../apps/models/master/Country');
const State = require('../../apps/models/master/State');
const City = require('../../apps/models/master/City');
const UserWallet = require("../models/master/UserWallet");
const UserAddress = require("../../apps/models/master/UserAddress");
const { sendEmail } = require("../../apps/emailtemplates/SendMail");
const EmailTemplate = require("../../apps/models/master/EmailTemplate");
const md5 = require('md5');
const multer = require('multer');
const secretKey = 'storepedia277833';
const currentDate = new Date();
const current_date = Date.now();
const getCurrentDateTime = () => new Date();
const fs = require('fs');
const qs = require('qs');
const axios = require('axios');
const path = require('path');
const moment = require('moment');
const Op = require('sequelize').Op;
const { sendDynamicEmail, sendEmailWith_temp } = require('../config/mail');
const OrderDiscountCoupon = require("../../apps/models/master/OrderDiscountCoupon");

//login
const userlogin = async (req, res) => {
    // if (req.body.user) {
    var username = req.body?.username?.trim();
    // }
    const password = req.body.password
    const schema = Joi.object().keys({
        username: Joi.string().required().email().label("Email"),
        password: Joi.string().required().label("Password"),
    });
    const dataToValidate = {
        username: username,
        password: password,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const user = await User.findOne({ where: { email: req.body.username, password: md5(req.body.password), role_id: 2, isactive: '1' }, attributes: ['id', 'role_id', 'email', 'contactnumber', 'userfullname', 'firstname', 'lastname', 'date_of_birth', 'profileimg', 'country_id', 'state_id', 'city_id', 'zip_code', 'password'] });

            //const userpass = await User.findOne({ where: { password: md5(req.body.password) }, attributes: ['id', 'role_id', 'email', 'contactnumber', 'userfullname','password'] })

            if ((!user)) {

                res.status(404).send({
                    message: "Invalid email address or password",
                    error: true,
                    success: false,
                    status: '0',
                });
                // }else if(!user){
                //     res.status(401).send({
                //         message:"Email not found",
                //         error: true,
                //         success: false,
                //         status: '0',
                //     });
                // }else if(md5(req.body.password) != user.dataValues.password){
                //     res.status(401).send({
                //         message:"Incorrect password",
                //         error: true,
                //         success: false,
                //         status: '0',
                //     });
            } else {
                const OrderDiscountCoupon1 = await OrderDiscountCoupon.findOne({ where: { discount_type: 'first_order', applied_status: 1, user_id: user.id } });
                var coupon_existence1 = 0;
                if (OrderDiscountCoupon1) {
                    coupon_existence1 = 1;
                }
                delete user.dataValues.password;

                const token = jwt.sign({ id: user.id, role_id: user.role_id }, secretKey, {
                    expiresIn: '30d',
                });
                const udate_info = {
                    last_login: getCurrentDateTime(),
                    auth_token: token,
                }
                await User.update(udate_info, { where: { id: user.id, isactive: '1' } })
                // req.session.user = {
                //     username: req.body.username,
                //     // Any other user data you may want to store
                //   };
                // if (req.session && req.session.user) {
                //     // Set or update last activity time to the current timestamp
                //     req.session.lastActivity = Date.now();
                // }

                res.send({
                    message: 'Login successful',
                    msg: req.session.user,
                    msg1: req.session.lastActivity,
                    error: false,
                    success: true,
                    status: '1',
                    data: user,
                    coupon_existence: coupon_existence1,
                    token: token
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0',
            });
        }
    }
};
//login

//user login app
const userloginApp = async (req, res) => {
    const mobile_number = req.body.mobile_number;
    const schema = Joi.object().keys({
        mobile_number: Joi.string().regex(/^[0-9]{10}$/).required().label("Mobile Number"),
    });
    const dataToValidate = {
        mobile_number: mobile_number
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const user = await User.findOne({ where: { contactnumber: mobile_number }, attributes: ['id', 'role_id', 'contactnumber'] });

            if ((!user)) {
                const otp = Math.floor(1000 + Math.random() * 9000);
                const users = await User.create({
                    role_id: 2,
                    contactnumber: mobile_number,
                    last_login_otp: otp,
                    created_at: current_date
                });
                res.send({
                    message: 'Signup otp send successful',
                    error: false,
                    success: true,
                    status: '1',
                    otp: otp,
                    data: users
                });
            } else {
                const otp = Math.floor(1000 + Math.random() * 9000);

                var users = await User.update({
                    last_login_otp: otp,
                }, {
                    where: {
                        id: user.id
                    }
                });

                res.send({
                    message: 'Login otp send successful',
                    error: false,
                    success: true,
                    status: '1',
                    otp: otp,
                    data: user
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
};
//user login app

//verify login otp start
const verifyLoginOtp = async (req, res) => {
    const id = req.body.id;
    const otp = req.body.otp;
    const schema = Joi.object().keys({
        id: Joi.number().integer().required(),
        otp: Joi.number().integer().required(),
    });
    const dataToValidate = {
        id: id,
        otp: otp
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const updateUser = await User.findOne({
                where: {
                    id: id,
                    last_login_otp: otp
                },
                attributes: ['id', 'role_id', 'email', 'contactnumber', 'userfullname', 'firstname', 'lastname', 'date_of_birth', 'profileimg', 'country_id', 'state_id', 'city_id', 'zip_code', 'password']
            });
            if (!updateUser) {
                res.status(202).send({
                    message: 'Otp not exists',
                    error: false,
                    success: true,
                    status: '0'
                });
            } else {
                var user = await User.update({
                    login_attempt: '1',
                    last_login: currentDate
                }, {
                    where: {
                        id: updateUser['id']
                    }
                });

                const token = jwt.sign({ id: updateUser['id'], role_id: updateUser['role_id'] }, secretKey, {
                    expiresIn: '30d', // Token expires in 1 hour
                });
                res.status(200).send({
                    message: 'Login successfully',
                    error: false,
                    success: true,
                    status: '1',
                    data: updateUser,
                    token
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//verify login otp end

//user resend otp app
const resendOtp = async (req, res) => {
    const mobile_number = req.body.mobile_number;
    const schema = Joi.object().keys({
        mobile_number: Joi.string().regex(/^[0-9]{10}$/).required().label("Mobile Number"),
    });
    const dataToValidate = {
        mobile_number: mobile_number
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const users = await User.findOne({ where: { contactnumber: mobile_number }, attributes: ['id', 'role_id', 'contactnumber', 'email', 'userfullname'] });

            if ((!users)) {
                res.status(202).send({
                    message: "Invalid mobile number",
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                // const otp = Math.floor(1000 + Math.random() * 9000);

                // var users = await User.update({
                //     last_login_otp: otp,
                // }, {
                //     where: {
                //         id: user.id
                //     }
                // });
                var otp = null;
                if (process.env.COUPONCODESTATIC == 'TRUE') {
                    otp = '1234';
                } else if (process.env.COUPONCODESTATIC == 'FALSE') {
                    otp = Math.floor(1000 + Math.random() * 9000);

                    let data = qs.stringify({
                        'to': users?.email,
                        'username': users?.userfullname,
                        'otp': otp,

                    });
                    const config = {
                        method: 'post',
                        url: process.env.SITE_URL + 'account_verification',
                        data: data
                    };
                    const response = await axios(config);
                }

                var user = await User.update({
                    mobile_verify_otp: otp
                }, {
                    where: {
                        id: users?.id
                    }
                });

                res.send({
                    message: 'Otp Resend successful',
                    error: false,
                    success: true,
                    status: '1',
                    otp: otp,
                    data: user
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
};
//user resend otp app

//user expire otp app
const expireOtp = async (req, res) => {
    const user_id = req.body.user_id;
    const schema = Joi.object().keys({
        user_id: Joi.number().integer().required(),
    });
    const dataToValidate = {
        user_id: user_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const user = await User.findOne({ where: { id: user_id }, attributes: ['id'] });

            if ((!user)) {
                res.status(202).send({
                    message: "Invalid user",
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {

                var users = await User.update({
                    last_login_otp: '',
                }, {
                    where: {
                        id: user.id
                    }
                });

                res.send({
                    message: 'Otp Expire successful',
                    error: false,
                    success: true,
                    status: '1',
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
};
//user expire otp app

//register
// const userRegister = async (req, res) => {
//     const firstname = req.body.firstname.trim();
//     const lastname = req.body.lastname.trim();
//     //const country_id = req.body.country_id;
//     // const state_id = req.body.state_id;
//     // const city_id = req.body.city_id;
//     // const pincode = req.body.pincode;
//     const email = req.body.email.trim();
//     const mobile_number = req.body.mobile_number;
//     //const birthday = req.body.birthday;
//     const password = md5(req.body.password.trim());
//     const referrer = req.body.referrer;
//     const userfullname = firstname + " " + lastname;
//     const schema = Joi.object().keys({
//         firstname: Joi.string().required().label("First Name"),
//         lastname: Joi.string().required().label("Last Name"),
//         // country_id:  Joi.number().integer().required().label("Country"),
//         // state_id:  Joi.number().integer().required().label("State"),
//         // city_id:  Joi.number().integer().required().label("City"),
//         // pincode:  Joi.number().integer().required().label("Pincode"),
//         email: Joi.string().required().email().label("Email"),
//         mobile_number: Joi.string().regex(/^[0-9]{10}$/).required().label("Mobile Number"),
//         password: Joi.string().required().label("Password"),
//     });
//     const dataToValidate = {
//         firstname: firstname,
//         lastname: lastname,
//         // country_id:country_id,
//         // state_id:state_id,
//         // city_id:city_id,
//         // pincode:pincode,
//         email: email,
//         mobile_number: mobile_number,
//         password: password,
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(403).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {
//             const checkEmailExists = await User.findAll({ where: { email: email } });
//             const checkMobileExists = await User.findAll({ where: { contactnumber: mobile_number } });
//             if (checkEmailExists != 0) {
//                 res.status(404).send({
//                     message: 'Email Id Already Exists',
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else if (checkMobileExists != 0) {
//                 res.status(404).send({
//                     message: 'Mobile Number Already Exists',
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else {
//                 function randomString(len) {
//                     var p = "0123456789";
//                     return [...Array(len)].reduce(a => a + p[~~(Math.random() * p.length)], '');
//                 }
//                 var code = firstname.substring(0, 4).toUpperCase();
//                 var refCode = code + randomString(6);

//                 if (referrer !== 'undefined' && referrer !== '') {
//                     const referrerDetails = await User.findOne({
//                         where: {
//                             ref_code: referrer
//                         }
//                     });
//                     if (referrerDetails) {
//                         var ref_id = referrerDetails['id'];
//                         const wallet = await UserWallet.increment(
//                             {
//                                 amount_balance: +10
//                             }, {
//                             where: {
//                                 user_id: ref_id
//                             }
//                         });
//                     } else {
//                         res.status(404).send({
//                             message: 'Invalid referrer code',
//                             error: false,
//                             success: true,
//                             status: '1'
//                         });
//                     }
//                 } else {
//                     var ref_id = null;
//                 }
//                 const user = await User.create({
//                     role_id: 2,
//                     firstname: firstname,
//                     lastname: lastname,
//                     userfullname: userfullname,
//                     email: email,
//                     contactnumber: mobile_number,
//                     // country_id: country_id,
//                     // state_id: state_id,
//                     // city_id: city_id,
//                     // zip_code: pincode,
//                     // date_of_birth:moment(birthday).format("YYYY-MM-DD"),
//                     password: password,
//                     ref_code: refCode,
//                     parent_ref_id: ref_id,
//                     created_at: current_date
//                 });
//                 if (user) {
//                     // await UserAddress.create({
//                     //     user_id: user.id,
//                     //     name:firstname,
//                     //     country_id: country_id,
//                     //     state_id: state_id,
//                     //     city_id: city_id,
//                     //     zip_code: pincode,
//                     //     is_default:1,
//                     //     created_at:currentDate,
//                     //     created_by:user.id
//                     // });
//                     const token = jwt.sign({ id: user.id, role_id: user.role_id }, secretKey, {
//                         expiresIn: '30d', // Token expires in 1 hour
//                     });
//                     const adminDetail = await User.findOne({
//                         attributes: ['email'],
//                         where: {
//                             role_id: 1
//                         }
//                     });
//                     const axios = require('axios');
//                     const qs = require('qs');
//                     if (adminDetail) {
//                         // const response = sendDynamicEmail(
//                         //     adminDetail['email'],
//                         //     'Customer Register',
//                         //     'Customer Register',
//                         //     '<p>' + userfullname + 'is registered on Storepedia' + '</p>',
//                         // );

//                         let data = qs.stringify({
//                             'to': adminDetail['email'],
//                             'subject': 'Customer Register',
//                             'msg_detail': userfullname + 'is registered on Storepedia',
//                             });

//                         const config = {
//                             method: 'post',
//                             url: process.env.SITE_URL+'send_mail_node_api',
//                             data: data
//                         };

//                         const response = await axios(config);
//                     }
//                     const template_email = await EmailTemplate.findOne({where:{
//                         mail_type:'WelcomeEmail'
//                      }});
//                     var welcom_mail_user = template_email.message.replace('[NAME]', userfullname);
//                     let dataa = qs.stringify({
//                         'to': email,
//                         'subject': template_email.subject,
//                         'msg_detail': welcom_mail_user,
//                         });
//                     const configg = {
//                         method: 'post',
//                         url: process.env.SITE_URL+'send_mail_node_api',
//                         data: dataa
//                     };

//                     const responsee = await axios(configg);

//                     res.status(200).send({
//                         message: 'Registered Successfully',
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: { id: user.id, userfullname: user.firstname, email: user.email },
//                         token: token
//                     });
//                 }
//             }
//         } catch (error) {
//             res.status(500).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
// }
// const userRegister = async (req, res) => {
//     if(req.body.is_social_login==2){
//     const firstname = req.body.firstname ? req.body.firstname.trim() : undefined;
//     const lastname = req.body.lastname ? req.body.lastname.trim() : undefined;
//     const email = req.body.email ? req.body.email.trim() : undefined;
//     const mobile_number = req.body.mobile_number;
//     const password = req.body.password ? md5(req.body.password.trim()) : undefined;

//     const referrer = req.body.referrer;
//     const userfullname = firstname + " " + lastname;
//     const schema = Joi.object().keys({
//         firstname: Joi.string().required().label("First Name"),
//         lastname: Joi.string().required().label("Last Name"),
//         email: Joi.string().required().email().label("Email"),
//         mobile_number: Joi.string().regex(/^[0-9]{10}$/).required().label("Mobile Number"),
//         password: Joi.string().required().label("Password"),
//     });
//     const dataToValidate = {
//         firstname: firstname,
//         lastname: lastname,
//         email: email,
//         mobile_number: mobile_number,
//         password: password,
//     };
//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(403).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {
//             const checkEmailExists = await User.findAll({ where: { email: email } });
//             const checkMobileExists = await User.findAll({ where: { contactnumber: mobile_number } });
//             if (checkEmailExists != 0) {
//                 res.status(404).send({
//                     message: 'Email Id Already Exists',
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else if (checkMobileExists != 0) {
//                 res.status(404).send({
//                     message: 'Mobile Number Already Exists',
//                     error: true,
//                     success: false,
//                     status: '0'
//                 });
//             } else {
//                 function randomString(len) {
//                     var p = "0123456789";
//                     return [...Array(len)].reduce(a => a + p[~~(Math.random() * p.length)], '');
//                 }
//                 var code = firstname.substring(0, 4).toUpperCase();
//                 var refCode = code + randomString(6);

//                 if (referrer !== 'undefined' && referrer !== '') {
//                     const referrerDetails = await User.findOne({
//                         where: {
//                             ref_code: referrer
//                         }
//                     });
//                     if (referrerDetails) {
//                         var ref_id = referrerDetails['id'];
//                         const wallet = await UserWallet.increment(
//                             {
//                                 amount_balance: +10
//                             }, {
//                             where: {
//                                 user_id: ref_id
//                             }
//                         });
//                     } else {
//                         res.status(404).send({
//                             message: 'Invalid referrer code',
//                             error: false,
//                             success: true,
//                             status: '1'
//                         });
//                     }
//                 } else {
//                     var ref_id = null;
//                 }
//                 const user = await User.create({
//                     role_id: 2,
//                     firstname: firstname,
//                     lastname: lastname,
//                     userfullname: userfullname,
//                     email: email,
//                     contactnumber: mobile_number,
//                     password: password,
//                     ref_code: refCode,
//                     parent_ref_id: ref_id,
//                     created_at: current_date
//                 });
//                 if (user) {
//                     const token = jwt.sign({ id: user.id, role_id: user.role_id }, secretKey, {
//                         expiresIn: '30d', // Token expires in 1 hour
//                     });

//                     let dataa = qs.stringify({
//                         'to': user.email,
//                         'username': user.userfullname,

//                     });
//                     const configg = {
//                         method: 'post',
//                         url: process.env.SITE_URL + 'welcome_mail',
//                         data: dataa
//                     };

//                     const responsee = await axios(configg);

//                     // sendEmail(user,'WelcomeEmail');
//                     res.status(200).send({
//                         message: 'Registered Successfully',
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: { id: user.id, userfullname: user.firstname, email: user.email },
//                         token: token
//                     });
//                 }
//             }
//         } catch (error) {
//             res.status(500).send({
//                 message: process.env.ERROR_MSG,
//                 message_error: error.message,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }
//     }else if(req.body.is_social_login == 1){

//         try {
//             if(!req.body.social_token){
//                 return res.status(400).send({
//                     message: 'social_token is required',
//                     status: '0',
//                     error: true,
//                     success: false
//                 })

//             }

//         const decodedString = Buffer.from(req.body.social_token, 'base64').toString('utf-8');

//         const DecodedData = JSON.parse(decodedString);

//         const firstname = DecodedData?.given_name
//         const lastname= DecodedData?.family_name
//         const userfullname = DecodedData?.name
//         const email = DecodedData?.email

//         const referrer = req.body.referrer

//             const checkEmailExists = await User.findOne({ where: { email: email, isactive: '1' } });
//             if (checkEmailExists) {

//                 const token = jwt.sign({ id: checkEmailExists.id, role_id: checkEmailExists.role_id }, secretKey, {
//                     expiresIn: '30d', // Token expires in 1 hour
//                 });
//                   // sendEmail(user,'WelcomeEmail');
//                    return res.status(200).send({
//                         message: 'Login Successful',
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: { id: checkEmailExists.id, userfullname: checkEmailExists.name, email: checkEmailExists.email },
//                         token: token
//                     });

//             } else {

//                 const user = await User.create({
//                     role_id: 2,
//                     firstname: firstname,
//                     lastname: lastname,
//                     userfullname: userfullname,
//                     email: email,
//                     ref_code: null,
//                     is_social_login: '1',
//                     created_at: current_date
//                 });
//                 if (user) {
//                     const token = jwt.sign({ id: user.id, role_id: user.role_id }, secretKey, {
//                         expiresIn: '30d', // Token expires in 1 hour
//                     });

//                     let dataa = qs.stringify({
//                         'to': user.email,
//                         'username': user.userfullname,

//                         });
//                     const configg = {
//                         method: 'post',
//                         url: process.env.SITE_URL+'welcome_mail',
//                         data: dataa
//                     };

//                     const responsee = await axios(configg);

//                     // sendEmail(user,'WelcomeEmail');
//                     res.status(200).send({
//                         message: 'Registered Successfully',
//                         error: false,
//                         success: true,
//                         status: '1',
//                         data: { id: user.id, userfullname: user.firstname, email: user.email },
//                         token: token
//                     });
//                 }
//             }
//         } catch (error) {
//            return res.status(500).send({
//                 message: process.env.ERROR_MSG,
//                 message_error: error.message,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }


//     }else{   
//        return res.status(500).send({
//             message: process.env.ERROR_MSG,
//             error: true,
//             success: false,
//             status: '0',
//         });



//     }

// }


const userRegister = async (req, res) => {
    try {
        if (req.body.is_social_login == 2) {
            const firstname = req.body.firstname
                ? req.body.firstname.trim()
                : '';
            const lastname = req.body.lastname ? req.body?.lastname.trim() : '';
            const email = req.body.email ? req.body.email.trim() : '';
            const mobile_number = req.body.mobile_number;
            const password = req.body.password
                ? md5(req.body.password.trim())
                : '';
            const referrer = req.body.referrer;
            const userfullname = firstname + " " + lastname;
            const schema = Joi.object().keys({
                firstname: Joi.string().required().label("First Name"),
                // lastname: Joi.string().label("Last Name"),
                email: Joi.string().required().email().label("Email"),
                mobile_number: Joi.string()
                    .regex(/^[0-9]{10}$/)
                    .required()
                    .label("Mobile Number"),
                password: Joi.string().required().label("Password"),
            });
            const dataToValidate = {
                firstname: firstname,
                // lastname: lastname,
                email: email,
                mobile_number: mobile_number,
                password: password,
            };
            const result = schema.validate(dataToValidate);
            if (result.error) {
                res.status(403).send({
                    error: true,
                    success: false,
                    status: "0",
                    message: result.error.details[0].message,
                });
            } else {
                try {
                    const checkEmailExists = await User.findAll({
                        where: { email: email },
                    });
                    const checkMobileExists = await User.findAll({
                        where: { contactnumber: mobile_number },
                    });
                    if (checkEmailExists != 0) {
                        res.status(404).send({
                            message: "Email Id Already Exists",
                            error: true,
                            success: false,
                            status: "0",
                        });
                    } else if (checkMobileExists != 0) {
                        res.status(404).send({
                            message: "Mobile Number Already Exists",
                            error: true,
                            success: false,
                            status: "0",
                        });
                    } else {
                        function randomString(len) {
                            var p = "0123456789";
                            return [...Array(len)].reduce(
                                (a) => a + p[~~(Math.random() * p.length)],
                                ""
                            );
                        }
                        var code = firstname.substring(0, 4).toUpperCase();
                        var refCode = code + randomString(6);

                        if (referrer !== "undefined" && referrer !== "") {
                            const referrerDetails = await User.findOne({
                                where: {
                                    ref_code: referrer,
                                },
                            });
                            if (referrerDetails) {
                                var ref_id = referrerDetails["id"];
                                const wallet = await UserWallet.increment(
                                    {
                                        amount_balance: +10,
                                    },
                                    {
                                        where: {
                                            user_id: ref_id,
                                        },
                                    }
                                );
                            } else {
                                res.status(404).send({
                                    message: "Invalid referrer code",
                                    error: false,
                                    success: true,
                                    status: "1",
                                });
                            }
                        } else {
                            var ref_id = null;
                        }
                        const user = await User.create({
                            role_id: 2,
                            firstname: firstname,
                            lastname: lastname,
                            userfullname: userfullname,
                            email: email,
                            contactnumber: mobile_number,
                            password: password,
                            ref_code: refCode,
                            parent_ref_id: ref_id,
                            created_at: current_date,
                        });
                        if (user) {
                            const token = jwt.sign(
                                { id: user.id, role_id: user.role_id },
                                secretKey,
                                {
                                    expiresIn: "30d", // Token expires in 1 hour
                                }
                            );
                            const udate_info = {
                                auth_token: token,
                            }
                            await User.update(udate_info, { where: { id: user.id, isactive: '1' } })
                            let dataa = qs.stringify({
                                to: user.email,
                                username: user.userfullname,
                                password: req.body.password,
                            });
                            const configg = {
                                method: "post",
                                url: process.env.SITE_URL + "welcome_mail",
                                data: dataa,
                            };

                            const responsee = await axios(configg);

                            // sendEmail(user,'WelcomeEmail');
                            res.status(200).send({
                                message: "Registered Successfully",
                                error: false,
                                success: true,
                                status: "1",
                                data: {
                                    id: user.id,
                                    userfullname: user.userfullname,
                                    email: user.email,
                                },
                                token: token,
                            });
                        }
                    }
                } catch (error) {
                    res.status(500).send({
                        message: process.env.ERROR_MSG,
                        message_error: error.message,
                        error: true,
                        success: false,
                        status: "0",
                    });
                }
            }
        } else if (req.body.is_social_login == 1) {
            if (!req.body.social_token || !req.body.social_login_type) {
                return res.status(400).send({
                    message: !req.body.social_token ? "social_token is required" : "social_login_type is required",
                    status: "0",
                    error: true,
                    success: false,
                });
            }

            const decodedString = Buffer.from(
                req.body.social_token,
                "base64"
            ).toString("utf-8");

            const DecodedData = JSON.parse(decodedString);
            const social_login_type = req.body.social_login_type;
            let firstname, lastname, userfullname, email;


            if (social_login_type == 2) {
                let nameParts = DecodedData.name.split(' ')
                firstname = nameParts[0];
                lastname = nameParts[nameParts.length - 1];
                userfullname = DecodedData?.name;
                email = DecodedData?.email;
            } else if (req.body.social_login_type == 1) {
                firstname = DecodedData?.given_name;
                lastname = DecodedData?.family_name;
                userfullname = DecodedData?.name;
                email = DecodedData?.email;
            }



            const checkEmailExists = await User.findOne({
                where: { email: email, isactive: "1" },
            });
            if (checkEmailExists) {
                const token = jwt.sign(
                    { id: checkEmailExists.id, role_id: checkEmailExists.role_id },
                    secretKey,
                    {
                        expiresIn: "30d", // Token expires in 1 hour
                    }
                );
                await User.update({
                    firstname: firstname,
                    lastname: lastname,
                    userfullname: userfullname,
                    social_login_type: social_login_type,
                    auth_token: token,

                }, {
                    where: {
                        id: checkEmailExists.id
                    }
                })
                // sendEmail(user,'WelcomeEmail');
                return res.status(200).send({
                    message: "Login Successful",
                    error: false,
                    success: true,
                    status: "1",
                    data: {
                        id: checkEmailExists.id,
                        userfullname: checkEmailExists.userfullname,
                        email: checkEmailExists.email,
                    },
                    token: token,
                });
            } else {
                const user = await User.create({
                    role_id: 2,
                    firstname: firstname,
                    lastname: lastname,
                    userfullname: userfullname,
                    email: email,
                    ref_code: null,
                    is_social_login: "1",
                    social_login_type: social_login_type,
                    created_at: current_date,
                });
                if (user) {
                    const token = jwt.sign(
                        { id: user.id, role_id: user.role_id },
                        secretKey,
                        {
                            expiresIn: "30d", // Token expires in 1 hour
                        }
                    );

                    let dataa = qs.stringify({
                        to: user.email,
                        username: user.userfullname,
                    });
                    const configg = {
                        method: "post",
                        url: process.env.SITE_URL + "welcome_mail",
                        data: dataa,
                    };

                    const responsee = await axios(configg);

                    // sendEmail(user,'WelcomeEmail');
                    res.status(200).send({
                        message: "Registered Successfully",
                        error: false,
                        success: true,
                        status: "1",
                        data: {
                            id: user.id,
                            userfullname: user.userfullname,
                            email: user.email,
                        },
                        token: token,
                    });
                }
            }
        } else {
            return res.status(404).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: "0",
            });
        }
    } catch (error) {
        return res.status(500).send({
            message: process.env.ERROR_MSG,
            message_error: error.message,
            error: true,
            success: false,
            status: "0",
        });
    }
};
//register

//storage
const storage = multer.diskStorage({
    destination: async (req, file, cb) => {
        const userData = await User.findOne({
            where: {
                id: req.userId
            }
        });
        if (userData['profileimg'] !== null && userData['profileimg'] !== '') {
            fs.unlink(process.env.USER_IMAGE + userData['profileimg'], (error) => {
            });
        }
        const uploadPath = process.env.USER_IMAGE;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + extension);
    },
});
//storage

//edit profile
const upload = multer({ storage: storage });
const EditUserProfile_old = async (req, res) => {
    upload.single('file')(req, res, async function (error) {
        const user_id = req.userId;
        const firstname = req.body.firstname;
        const lastname = req.body.lastname;
        const contactnumber = req.body.contactnumber;
        // const date_of_birth = req.body.date_of_birth;
        // const country_id = req.body.country_id;
        // const state_id = req.body.state_id;
        // const city_id = req.body.city_id;
        // const zip_code = req.body.zip_code;
        const userfullname = firstname + " " + lastname;
        const schema = Joi.object().keys({
            firstname: Joi.required(),
            contactnumber: Joi.string().regex(/^[0-9]{10}$/).required().label("Mobile Number"),
            // country_id:Joi.string().required(),
            // state_id:Joi.string().required(),
            // city_id:Joi.string().required(),

        });
        const dataToValidate = {
            firstname: firstname,
            contactnumber: contactnumber,
            // country_id:country_id,
            // state_id:state_id,
            // city_id:city_id,
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(403).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        } else {
            try {
                if (req.file) {
                    var image = req.file.filename;
                } else {
                    var image = null;
                }
                const updateUser = await User.update({
                    firstname: firstname,
                    lastname: lastname,
                    userfullname: userfullname,
                    contactnumber: contactnumber,
                    // date_of_birth:date_of_birth,
                    // profileimg:image,
                    // country_id:country_id,
                    // state_id:state_id,
                    // city_id:city_id,
                    // zip_code:zip_code,
                    updated_at: current_date,
                    updated_by: user_id
                }, {
                    where: {
                        id: user_id
                    }
                });
                if (!updateUser) {
                    res.status(204).send({
                        message: 'User profile not updated',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else {
                    res.status(200).send({
                        message: 'User profile updated successfully',
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch (error) {
                res.status(500).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
}

const EditUserProfile = async (req, res) => {
    upload.single('file')(req, res, async function (error) {
        const user_id = req.userId;
        const firstname = req.body.firstname.trim();
        const lastname = req.body.lastname.trim();
        const email = req.body.email.trim();
        const contactnumber = req.body.contactnumber.trim();
        const date_of_birth = req.body.date_of_birth;
        const gender = req.body.gender;
        const father_name = req.body.father_name;
        const mother_name = req.body.mother_name;
        const marital_status = req.body.marital_status;
        const anniversary_date = req.body.anniversary_date;
        const schema = Joi.object().keys({
            firstname: Joi.string().required().label('First Name'),
            lastname: Joi.string().required().label('Last Name'),
            email: Joi.string().required().email().label("Email"),
            contactnumber: Joi.string().regex(/^[0-9]{10}$/).required().label("Mobile Number"),

        });
        const dataToValidate = {
            firstname: firstname,
            lastname: lastname,
            email: email,
            contactnumber: contactnumber,
        };
        const result = schema.validate(dataToValidate);
        if (result.error) {
            res.status(403).send({
                error: true,
                success: false,
                status: '0',
                message: result.error.details[0].message
            });
        } else {
            try {
                const checkUserEmail = await User.findOne({
                    where: {
                        email: email,
                        id: { [Op.ne]: user_id }
                    }
                });
                const checkUserMobile = await User.findOne({
                    where: {
                        contactnumber: contactnumber,
                        id: { [Op.ne]: user_id }
                    }
                });
                const checkEmail = await User.findOne({ where: { email: email } });
                const checkMobile = await User.findOne({ where: { contactnumber: contactnumber } });
                if ((!checkEmail) && (!checkMobile)) {
                    res.status(403).send({
                        message: 'Please update one of your mobile number and email.',
                        error: true,
                        success: false,
                        status: '0'
                    });
                } else
                    if ((checkUserEmail)) {
                        res.status(403).send({
                            message: 'Email already exists for another user.',
                            error: true,
                            success: false,
                            status: '0'
                        });
                    } else if (checkUserMobile) {
                        res.status(403).send({
                            message: 'Contact Number already exists for another user.',
                            error: true,
                            success: false,
                            status: '0'
                        });

                    }
                    else {
                        var otp = null;
                        if (process.env.COUPONCODESTATIC == 'TRUE') {
                            otp = '1234';
                        } else if (process.env.COUPONCODESTATIC == 'FALSE') {
                            otp = Math.floor(1000 + Math.random() * 9000);
                            //const otp = 1234;
                            const checkEmail = await User.findOne({
                                where: {
                                    email: email,
                                }
                            });


                            let data = qs.stringify({
                                'to': checkEmail.email,
                                'username': checkEmail.userfullname,
                                'otp': otp,

                            });
                            const config = {
                                method: 'post',
                                url: process.env.SITE_URL + 'account_verification',
                                data: data
                            };

                            const response = await axios(config);

                        }

                        var user = await User.update({
                            mobile_verify_otp: otp,
                            updated_at: getCurrentDateTime()
                        }, {
                            where: {
                                id: user_id
                            }
                        });
                        //    await sendEmail(checkEmail,'UpdateProfileEmail',otp);
                        res.status(200).send({
                            message: 'Profile verify Otp sent on mail',
                            error: false,
                            success: true,
                            status: '1',
                            data: req.body
                        });
                    }
            } catch (error) {
                res.status(500).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
        }
    });
}
//edit profile

// user profile start
const UserProfile = async (req, res) => {
    const user_id = req.userId;
    const existData = await User.findOne({
        where: {
            isactive: '1',
            id: user_id
        },
        attributes: ['id', 'firstname', 'lastname', 'userfullname', 'contactnumber', 'email', 'profileimg', 'date_of_birth', 'gender', 'father_name', 'mother_name', 'marital_status', 'anniversary_date', 'country_id', 'state_id', 'city_id', 'zip_code', 'is_verified_mobile'],
        include: [
            {
                model: Country,
                as: 'country',
                attributes: ['country_name'],
                required: false
            },
            {
                model: State,
                as: 'state',
                attributes: ['state_name'],
                required: false
            },
            {
                model: City,
                as: 'city',
                attributes: ['city_name'],
                required: false
            }
        ]

    });
    if (existData) {
        res.send({
            message: 'User profile details',
            error: false,
            success: true,
            status: '1',
            path: process.env.USER_IMAGE,
            data: existData
        });
    } else {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }

}
// user profile end


//change password start
const changePassword = async (req, res) => {
    const user_id = req.userId;
    const old_password = req.body.old_password;
    const new_password = req.body.new_password;
    const confirm_password = req.body.confirm_password;
    const schema = Joi.object().keys({
        old_password: Joi.string().trim().required().min(1),
        new_password: Joi.string().trim().required().min(1)
            .when('old_password', {
                is: Joi.exist(), // Validate only if old_password exists
                then: Joi.not(Joi.ref('old_password')).required().label("new password is not equal to old password"), // Ensure new_password is not equal to old_password
                otherwise: Joi.optional() // Otherwise, new_password is optional
            }),
        confirm_password: Joi.string().trim().required().valid(Joi.ref('new_password')),
    });

    const dataToValidate = {
        old_password: old_password,
        new_password: new_password,
        confirm_password: confirm_password
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const existData = await User.findOne({
                where: { id: user_id, password: md5(old_password) }
            });
            if (!existData) {
                res.status(500).send({
                    message: 'Old password not match',
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                const updateUser = await User.update({
                    password: md5(req.body.new_password)
                }, {
                    where: {
                        id: user_id
                    }
                });
                sendEmail(existData, 'ChangePasswordEmail', req.body.new_password);
                // const template_email = await EmailTemplate.findOne({where:{
                //     mail_type:'ChangePasswordEmail'
                // }});

                // var reset_mail = template_email.message.replace('[NAME]', updateUser.userfullname).replace('[Password]', `${req.body.new_password}`);
                // let data = qs.stringify({
                //     'to': email,
                //     'subject': template_email.subject,
                //     'msg_detail': reset_mail,
                //     });
                // const config = {
                //     method: 'post',
                //     url: process.env.SITE_URL+'send_mail_node_api',
                //     data: data
                // };

                // const response = await axios(config);
                if (updateUser) {
                    res.status(200).send({
                        message: 'Password updated successfully',
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//change password end

//forgot password start
const forgotPassword = async (req, res) => {
    const email = req.body.email;
    const schema = Joi.object().keys({
        email: Joi.string().required().email().label("Email")
    });
    const dataToValidate = {
        email: email
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const updateUser = await User.findOne({
                where: {
                    email: email
                }
            });
            if (!updateUser) {
                res.status(404).send({
                    message: 'Email does not exists',
                    error: true,
                    success: false,
                    status: '0',
                    data: req.body
                });
            } else {

                const stringPart = Math.random().toString(36).substr(2, 4).toUpperCase();
                const digitPart = Math.floor(1000 + Math.random() * 9000);
                const resetPassword = stringPart + digitPart.toString();
                const password = md5(resetPassword);
                await User.update({
                    password: password,
                }, {
                    where: {
                        email: email
                    }
                });

                let data = qs.stringify({
                    'to': updateUser.email,
                    'username': updateUser.userfullname,
                    'password': resetPassword,

                });
                const config = {
                    method: 'post',
                    url: process.env.SITE_URL + 'reset_password',
                    data: data
                };

                const response = await axios(config);


                // const resetToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
                // const resetToken = Math.random().toString(36).substring(2, 15);
                // const resetPasswordLink = process.env.FRONT_SITE_URL+`reset-password?token=${resetToken}`;
                // const expirationTime = getCurrentDateTime();
                // expirationTime.setMinutes(expirationTime.getMinutes() + 15); // Token expires in 15 minutes
                // expirationTime.setHours(expirationTime.getHours() + 1);
                // await User.update({
                //     reset_pass_token: resetToken,
                //     reset_pass_token_expiry: expirationTime

                // }, {
                //     where: {
                //         email: email
                //     }
                // });

                // let dataa = qs.stringify({
                //     'to': updateUser.email,
                //     'username': updateUser.userfullname,

                //     });
                // const configg = {
                //     method: 'post',
                //     url: process.env.SITE_URL+'welcome_mail',
                //     data: dataa
                // };

                // const responsee = await axios(configg);



                // const response = sendDynamicEmail(
                //     email,
                //     'Reset Your Password',
                //     'Click this link to reset your password'
                // );
                // const response = '';
                // const nodemailer = require('nodemailer');

                // const transporter = nodemailer.createTransport({
                //     host: 'mail.growthgrids.com',
                //     port: 587,
                //     secure: false,
                //     auth: {
                //         user: 'business@growthgrids.com',
                //         pass: 'Growth@2023Busi'
                //     }
                // });

                // const mailOptions = {
                //     from: 'business@growthgrids.com',
                //     to: 'demouser@mailinator.com',
                //     subject: 'Test Email 23',
                //     text: 'This is a test email sent from Node.js using SMTP.13',
                //     html:'<h1>hello</h1>',
                //     newline: 'crlf',
                //     charset: 'UTF-8',
                //     mailtype: 'html',
                //     wordwrap: true
                // };
                // await transporter.sendMail(mailOptions, (error, info) => {
                //     if (error) {
                //         console.error('Error sending email:', error);
                //     } else {
                //         console.log('Email sent:Xyz d1', info.response+' ==>'+info.messageId);
                //     }
                // });

                // const axios = require('axios');
                // const qs = require('qs');
                // let data = qs.stringify({
                //     'to': email,
                //     'subject': 'Reset Your Password',
                //     'msg_detail': `Click this link to reset your password: ${resetPasswordLink}`,
                //     });
                // const config = {
                //     method: 'post',
                //     url: process.env.SITE_URL+'send_mail_node_api',
                //     data: data
                // };
                // const template_email = await EmailTemplate.findOne({where:{
                //     mail_type:'ResetPasswordEmail'
                // }});

                // var reset_mail = template_email.message.replace('[NAME]', updateUser.userfullname).replace('[LINK]', `${resetPasswordLink}`);
                // let data = qs.stringify({
                //     'to': email,
                //     'subject': template_email.subject,
                //     'msg_detail': reset_mail,
                //     });
                // const config = {
                //     method: 'post',
                //     url: process.env.SITE_URL+'send_mail_node_api',
                //     data: data
                // };

                // const response = await axios(config);
                //   data = sendEmail(updateUser,'ResetPasswordEmail',resetPasswordLink);
                res.status(200).send({
                    message: 'Reset password link sent to your email.',
                    error: false,
                    success: true,
                    status: '1',
                    // data: data.data
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                message_error: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//forgot password end

//resset password start
const resetPassword = async (req, res) => {
    const token = req.body.token;
    const new_password = req.body.new_password;
    const confirm_password = req.body.confirm_password;
    const schema = Joi.object().keys({
        token: Joi.string().trim().required(),
        new_password: Joi.string().trim().required().min(1),
        confirm_password: Joi.string().trim().required().valid(Joi.ref('new_password'))
    });
    const dataToValidate = {
        token: token,
        new_password: new_password,
        confirm_password: confirm_password
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const checkUser = await User.findOne({
                where: {
                    reset_pass_token: token
                }
            });
            if (!checkUser) {
                return res.status(404).send({
                    message: 'The Link is expired.',
                    error: true,
                    success: false,
                    status: '0',
                });
            } else if (getCurrentDateTime() > checkUser.reset_pass_token_expiry) {
                return res.status(404).send({
                    message: 'The token has expired.',
                    error: true,
                    success: false,
                    status: '0'
                });
            } else {
                const checkValidation = await User.findOne({
                    where: {
                        password: md5(req.body.new_password),
                        id: checkUser['id']
                    }
                });
                if (checkValidation) {
                    res.status(404).send({
                        message: 'New password and old password should not be same',
                        error: true,
                        success: false,
                        status: '0',
                    });

                } else {
                    const updateUser = await User.update({
                        password: md5(req.body.new_password),
                        reset_pass_token: ""
                    }, {
                        where: {
                            id: checkUser['id']
                        }
                    });
                    if (updateUser) {
                        res.status(200).send({
                            message: 'Password reset successful',
                            error: false,
                            success: true,
                            status: '1'
                        });
                    }
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//reset password end

//send mobile number verify otp start
const sendMobileNumberVerifyOtp = async (req, res) => {
    const user_id = req.userId;
    const mobile_number = req.body.mobile_number;
    const schema = Joi.object().keys({
        mobile_number: Joi.string().regex(/^[0-9]{10}$/).required().label("Mobile Number"),
    });
    const dataToValidate = {
        mobile_number: mobile_number
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const updateUser = await User.findOne({
                where: {
                    id: user_id,
                    contactnumber: mobile_number,
                    isactive: '1'
                },
                attributes: ['id', 'email']
            });
            if (!updateUser) {
                res.status(404).send({
                    message: 'Mobile number not exists',
                    error: false,
                    success: true,
                    status: '1',
                    data: req.body
                });
            } else {

                //const otp = Math.floor(1000 + Math.random() * 9000);
                const otp = 1234;
                var user = await User.update({
                    mobile_verify_otp: otp
                }, {
                    where: {
                        id: updateUser['id']
                    }
                });
                // const response = sendDynamicEmail(
                //     updateUser['email'],
                //     'Mobile Verify OTP',
                //     'Mobile Verify OTP',
                //     '<p>' + 'Mobile Verify OTP is:' + otp + '</p>'
                // );

                const axios = require('axios');
                const qs = require('qs');
                let data = qs.stringify({
                    'to': updateUser['email'],
                    'subject': 'Mobile Verify OTP',
                    'msg_detail': 'Mobile Verify OTP is:' + otp,
                });

                const config = {
                    method: 'post',
                    url: process.env.SITE_URL + 'send_mail_node_api',
                    data: data
                };

                const response = await axios(config);

                res.status(200).send({
                    message: 'Mobile verify Otp sent on mail',
                    error: false,
                    success: true,
                    status: '1',
                    data: otp
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//send mobile number otp end

//verify mobile number otp start
const verifyMobileNumberOtp = async (req, res) => {
    const user_id = req.userId;
    const otp = req.body.otp;
    const firstname = req.body.firstname.trim();
    const lastname = req.body.lastname.trim();
    const email = req.body.email.trim();
    const contactnumber = req.body.contactnumber.trim();
    const date_of_birth = req.body.date_of_birth;
    const gender = req.body.gender;
    const father_name = req.body.father_name;
    const mother_name = req.body.mother_name;
    const marital_status = req.body.marital_status;
    const anniversary_date = req.body.anniversary_date;
    const userfullname = firstname + " " + lastname;
    const schema = Joi.object().keys({
        otp: Joi.number().integer().required(),
        firstname: Joi.string().required().label('First Name'),
        lastname: Joi.string().required().label('Last Name'),
        email: Joi.string().required().email().label("Email"),
        contactnumber: Joi.string().regex(/^[0-9]{10}$/).required().label("Mobile Number"),
    });
    const dataToValidate = {
        otp: otp,
        firstname: firstname,
        lastname: lastname,
        email: email,
        contactnumber: contactnumber,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            // const updateUser = await User.findOne({
            //     where: {
            //         id: user_id,
            //         mobile_verify_otp: otp
            //     }
            // });
            // if (!updateUser) {
            //     res.status(202).send({
            //         message: 'Otp not exists',
            //         error: false,
            //         success: true,
            //         status: '0'
            //     });
            // }
            const updateUser = await User.findOne({
                where: {
                    id: user_id,
                    mobile_verify_otp: otp,
                    updated_at: {
                        [Op.gte]: new Date(Date.now() - 2 * 60 * 1000) // Two minutes ago
                    }
                }
            });

            if (!updateUser) {
                res.status(202).send({
                    message: 'Otp not exists or has expired',
                    error: false,
                    success: true,
                    status: '0'
                });
            } else {
                var user = await User.update({
                    firstname: firstname,
                    lastname: lastname,
                    userfullname: userfullname,
                    email: email,
                    contactnumber: contactnumber,
                    date_of_birth: date_of_birth ? date_of_birth : null,
                    gender: (gender == 'null') ? null : gender,
                    father_name: father_name ? father_name : null,
                    mother_name: mother_name ? mother_name : null,
                    marital_status: (marital_status == 'null') ? null : marital_status,
                    anniversary_date: anniversary_date ? anniversary_date : null,
                    is_verified_mobile: '1'
                }, {
                    where: {
                        id: updateUser['id']
                    }
                });
                res.status(200).send({
                    message: 'Otp verified successfully',
                    error: false,
                    success: true,
                    status: '1'
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//verify mobile number otp end

//send login otp start
const sendLoginOtp = async (req, res) => {
    const email = req.body.email;
    const schema = Joi.object().keys({
        email: Joi.string().required().email().label("Email")
    });
    const dataToValidate = {
        email: email
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const updateUser = await User.findOne({
                where: {
                    email: email
                }
            });
            if (!updateUser) {
                res.status(404).send({
                    message: 'Email not exists',
                    error: false,
                    success: true,
                    status: '1',
                    data: req.body
                });
            } else {
                const row = await User.findOne({
                    where: {
                        email: email,
                        isactive: '1'
                    }
                });
                if (row) {
                    if (row['resent_otp_attemp'] < 4) {
                        const otp = Math.floor(1000 + Math.random() * 9000);
                        var i = 1;
                        var user = await User.update({
                            last_login_otp: otp,
                            resent_otp_attemp: row['resent_otp_attemp'] + i
                        }, {
                            where: {
                                id: row['id']
                            }
                        });
                        const response = sendDynamicEmail(
                            email,
                            'Login OTP',
                            'Login OTP',
                            '<p>' + 'Login OTP is:' + otp + '</p>'
                        );
                        res.status(200).send({
                            message: 'Login Otp sent on mail',
                            error: false,
                            success: true,
                            status: '1',
                            data: response
                        });
                    }
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//send login otp end

//verify otp start
const verifyLoginOtp_old = async (req, res) => {
    const email = req.body.email;
    const otp = req.body.otp;
    const schema = Joi.object().keys({
        email: Joi.string().required().email().label("Email"),
        otp: Joi.required()
    });
    const dataToValidate = {
        email: email,
        otp: otp
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const updateUser = await User.findOne({
                where: {
                    email: email
                }
            });
            if (!updateUser) {
                res.status(204).send({
                    message: 'Email not exists',
                    error: false,
                    success: true,
                    status: '1',
                    data: req.body
                });
            } else {
                const row = await User.findOne({
                    where: {
                        email: email,
                        isactive: '1'
                    }
                });
                if (row) {
                    if (row['last_login_otp'] == otp) {
                        var user = await User.update({
                            resent_otp_attemp: '0'
                        }, {
                            where: {
                                isactive: '1',
                                email: email
                            }
                        });
                        res.status(200).send({
                            message: 'Otp verified successfully',
                            error: false,
                            success: true,
                            status: '1'
                        });
                    } else {
                        res.status(204).send({
                            message: 'Wrong OTP.Please enter again.',
                            error: false,
                            success: true,
                            status: '1'
                        });
                    }
                }
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}
//verify otp end

// const userlogout = async (req, res) => {
//     const schema = Joi.object().keys({
//         tender_id: Joi.number().required(),
//         lead_id: Joi.string().custom(customValidator).required(),
//         // user_comp_id: Joi.number().required(),
//         // created_by: Joi.number().required(),
//         // created_at: Joi.date().iso().required()
//     });

//     const dataToValidate = {
//         tender_id: req.body.tender_id,
//         // user_comp_id: req.comp_id,
//         lead_id: '2',
//         // created_by: req.userId,
//         // created_at: currentDate,
//     };
//     const result = schema.validate(dataToValidate);
//     console.log(result, 'aa')
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: result.error.details[0].message,
//             error: true,
//             success: false,
//             status: '0',
//         });

//     } else {

//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             message: 's',
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }

//Change Password..
// const changepassword = async (req, res) => {
//     const schema = Joi.object().keys({
//         password: Joi.string().required(),
//     });

//     const dataToValidate = {
//         password: req.body.password,
//     };

//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(400).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {
//             console.log(dataToValidate, 'dataToValidatedataToValidate', req.userId);
//             const user = await Users.update({ password: md5(req.body.password) }, { where: { id: req.userId } });
//             if (!user[0]) {
//                 return res.status(400).send({
//                     message: 'something went wrong',
//                     error: true,
//                     success: false,
//                     status: '0',
//                 });
//             }
//             res.send({
//                 message: 'Password change successfully done.',
//                 error: false,
//                 success: true,
//                 status: '1',
//                 data: user,
//             });
//         } catch (error) {
//             res.status(400).send({ error: error.message });
//         }
//     }
// };



//User Add ...




// const storage = multer.diskStorage({
//     destination: (req, file, cb) => {
//         const uploadPath = 'uploads/public' + '_' + req.comp_id + '/' + 'profile';
//         if (!fs.existsSync(uploadPath)) {
//             fs.mkdirSync(uploadPath, { recursive: true });
//         }
//         cb(null, uploadPath);
//     },
//     filename: (req, file, cb) => {
//         const extension = path.extname(file.originalname);
//         //console.log("Ash :- "+extension);
//         cb(null, Date.now() + 'Profile_' + Math.random() + extension); // Rename file with a timestamp
//     },
// });



//Update By Id Role..
// const upload = multer({ storage: storage }); // Initialize Multer
// const userdetails_update = async (req, res) => {
//     upload.single('profileimg')(req, res, async function (err) {
//         if (err) {
//             return res.status(400).send({ error: err.message });
//         }

//         const dataToValidate = {
//             comp_id: req.comp_id,
//             firstname: req.body.firstname,
//             lastname: req.body.lastname,
//             userfullname: req.body.firstname + " " + req.body.lastname,
//             contactnumber: req.body.contactnumber,

//             company_id: req.body.company_id,
//             department_id: req.body.department_id,
//             designation_id: req.body.designation_id,
//             jobgrade_id: req.body.jobgrade_id,
//             reporting_mngr_id: req.body.reporting_mngr_id,

//             date_of_birth: req.body.date_of_birth,
//             country_id: req.body.country_id,
//             state_id: req.body.state_id,
//             city_id: req.body.city_id,
//             zip_code: req.body.zip_code,
//             full_address_1: req.body.full_address_1,

//             modified_by: req.userId,
//             updated_at: currentDate,
//         };


//         const schema = Joi.object().keys({
//             comp_id: Joi.number().required(),
//             firstname: Joi.string().required(),
//             lastname: Joi.string().required(),
//             userfullname: Joi.string().required(),
//             contactnumber: Joi.string().pattern(/^[0-9]{10}$/).required(),

//             company_id: Joi.number().required(),
//             department_id: Joi.number().required(),
//             designation_id: Joi.number().required(),
//             jobgrade_id: Joi.number().required(),
//             reporting_mngr_id: Joi.number().required(),

//             date_of_birth: Joi.date().iso(),
//             country_id: Joi.number(),
//             state_id: Joi.number(),
//             city_id: Joi.number(),
//             zip_code: Joi.string().pattern(/^[0-9]{6}$/),
//             full_address_1: Joi.string(),

//             modified_by: Joi.number().required(),
//             updated_at: Joi.date().iso().required(),
//         });

//         const result = schema.validate(dataToValidate);
//         if (result.error) {
//             res.status(process.env.APIRESPCODE_VALIDATION).send({
//                 error: true,
//                 success: false,
//                 status: '0',
//                 message: result.error.details[0].message
//             });
//         } else {
//             const files = req.file;
//             try {
//                 if (files) {
//                     var upd_user_details = {
//                         profileimg: req.file.filename,
//                         firstname: req.body.firstname,
//                         lastname: req.body.lastname,
//                         userfullname: req.body.firstname + " " + req.body.lastname,
//                         contactnumber: req.body.contactnumber,

//                         company_id: req.body.company_id,
//                         department_id: req.body.department_id,
//                         designation_id: req.body.designation_id,
//                         jobgrade_id: req.body.jobgrade_id,
//                         reporting_mngr_id: req.body.reporting_mngr_id,

//                         date_of_birth: req.body.date_of_birth,
//                         country_id: req.body.country_id,
//                         state_id: req.body.state_id,
//                         city_id: req.body.city_id,
//                         zip_code: req.body.zip_code,
//                         full_address_1: req.body.full_address_1,

//                         modified_by: req.userId,
//                         updated_at: currentDate,
//                     }
//                 } else {
//                     var upd_user_details = {
//                         firstname: req.body.firstname,
//                         lastname: req.body.lastname,
//                         userfullname: req.body.firstname + " " + req.body.lastname,
//                         contactnumber: req.body.contactnumber,

//                         company_id: req.body.company_id,
//                         department_id: req.body.department_id,
//                         designation_id: req.body.designation_id,
//                         jobgrade_id: req.body.jobgrade_id,
//                         reporting_mngr_id: req.body.reporting_mngr_id,

//                         date_of_birth: req.body.date_of_birth,
//                         country_id: req.body.country_id,
//                         state_id: req.body.state_id,
//                         city_id: req.body.city_id,
//                         zip_code: req.body.zip_code,
//                         full_address_1: req.body.full_address_1,

//                         modified_by: req.userId,
//                         updated_at: currentDate,
//                     }
//                 }
//                 const update = await Users.update(upd_user_details, {
//                     where: { isactive: "1", comp_id: req.comp_id, id: req.body.update_user_id }
//                 });

//                 res.status(process.env.APIRESPCODE_SUCCESS_MSG).send({
//                     message: process.env.APIRESPMSG_RECUPDATED,
//                     error: false,
//                     success: true,
//                     status: '1',
//                 });

//             } catch (error) {
//                 res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                     message: process.env.ERROR_MSG,
//                     error: true,
//                     success: false,
//                     status: '0',
//                 });
//             }
//         }
//     });
// }

//Single Data Get..
// const userdetails = async (req, res) => {
//     const schema = Joi.object().keys({
//         user_id: Joi.number().required(),
//     });

//     const dataToValidate = {
//         user_id: req.body.user_id
//     };

//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {
//             const existData = await Users.findOne({ where: { isactive: "1", comp_id: req.comp_id, id: req.body.user_id } });
//             if (existData) {
//                 res.send({
//                     message: process.env.APIRESPMSG_RECFOUND,
//                     error: false,
//                     success: true,
//                     status: '1',
//                     data: existData,
//                 });
//             } else {
//                 return res.status(process.env.APIRESPCODE_RECORD_NOT_FOUND).send({
//                     message: process.env.APIRESPMSG_RECNOTFOUND,
//                     error: true,
//                     success: false,
//                     status: '0',
//                 });
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             })
//             // res.status(400).send({ error: error.message });
//         }
//     }
// }
// const userlogout = async (req, res) => {
//     const schema = Joi.object().keys({
//         user_id: Joi.number().required(),
//         user_comp_id: Joi.number().required(),
//     });

//     const dataToValidate = {
//         user_id: req.userId,
//         user_comp_id: req.comp_id
//     };

//     const result = schema.validate(dataToValidate);
//     if (result.error) {
//         res.status(process.env.APIRESPCODE_VALIDATION).send({
//             error: true,
//             success: false,
//             status: '0',
//             message: result.error.details[0].message
//         });
//     } else {
//         try {
//             const add_activity = {
//                 created_by: req.userId,
//                 user_comp_id: req.comp_id,
//                 activity: 'log_out',
//                 ip_address: req.body.ip_address,
//                 created_at: currentDate
//             };
//             const insert = await Useractivehistory.create(add_activity);
//             if (insert) {
//                 res.send({
//                     message: 'Logout successful',
//                     error: false,
//                     success: true,
//                     status: '1',

//                 });
//             }
//         } catch (error) {
//             res.status(process.env.APIRESPCODE_INTERNAL_SERVER).send({
//                 message: process.env.ERROR_MSG,
//                 error: true,
//                 success: false,
//                 status: '0',
//             });
//         }
//     }

// }
// async function sendEmail(user, mailType, emailData='') {
//     const filePath = path.join(__dirname, '../emailtemplates/index.html');

//     fs.readFile(filePath, 'utf8', async (err, htmlContent) => {
//         if (err) {
//             console.error('Error reading file:', err);
//             return;
//         }

//         try {
//             const template_email = await EmailTemplate.findOne({ where: { mail_type: mailType } });
//             if (!template_email) {
//                 throw new Error('Email template not found');
//             }
//             if(mailType == "WelcomeEmail"){
//             var mail_user = template_email.message.replace('[NAME]', user.userfullname);
//             var emailContent = htmlContent.replace('<p class="email_data"></p>', `${mail_user}`);
//             }else if(mailType == "ResetPasswordEmail"){
//                 mail_user = template_email.message.replace('[NAME]', user.userfullname)
//                 .replace('[LINK]', emailData);
//             var emailContent = htmlContent.replace('<p class="email_data"></p>', `${mail_user}`);
//             }else if(mailType == "ChangePasswordEmail"){
//                 mail_user = template_email.message.replace('[NAME]', user.userfullname)
//                 .replace('[PASSWORD]', emailData);
//             var emailContent = htmlContent.replace('<p class="email_data"></p>', `${mail_user}`);
//             }
//             // Prepare the email data
//             const data = qs.stringify({
//                 'to': user.email,
//                 'subject': template_email.subject,
//                 'msg_detail': emailContent,
//             });

//             // Configure and send the email
//             const config = {
//                 method: 'post',
//                 url: `${process.env.SITE_URL}send_mail_node_api`,
//                 data: data
//             };

//             const response = await axios(config);
//             console.log('Email sent:', response.data);
//             return response;
//         } catch (error) {
//             console.error('Error sending email:', error);
//         }
//     });
// }



//send email otp  start
const sendEmailVerifyOtp = async (req, res) => {
    const email = req.body.email;
    const schema = Joi.object().keys({
        email: Joi.string().required().email().label("Email")
    });
    const dataToValidate = {
        email: email
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const userExists = await User.findOne({
                where: {
                    email: email
                }
            });
            if (!userExists) {
                res.status(404).send({
                    message: 'Email does not exists',
                    error: true,
                    success: false,
                    status: '0',
                    data: req.body
                });
            } else {

                var otp = null;
                if (process.env.COUPONCODESTATIC == 'TRUE') {
                    otp = '1234';
                } else if (process.env.COUPONCODESTATIC == 'FALSE') {
                    otp = Math.floor(1000 + Math.random() * 9000);

                    let data = qs.stringify({
                        'to': userExists.email,
                        'username': userExists.userfullname,
                        'otp': otp,
                    });
                    const config = {
                        method: 'post',
                        url: process.env.SITE_URL + 'account_verification',
                        data: data
                    };
                    const response = await axios(config);
                }

                await User.update({ email_verify_otp: otp, updated_at: getCurrentDateTime() }, {
                    where: {
                        email: req.body.email
                    }
                })

                // await sendEmail(checkEmail,'UpdateProfileEmail',otp);
                return res.status(200).send({
                    message: 'OTP sent on email',
                    error: false,
                    success: true,
                    status: '1',
                    data: req.body,
                    otp: otp
                });

            }

        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                message_error: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

const verifyEmail = async (req, res) => {
    const email = req.body.email;
    const otp = req.body.otp

    console.log(email, otp)

    const schema = Joi.object().keys({
        email: Joi.string().required().email().label("Email"),
        otp: Joi.number().required().label("Password"),
    });
    const dataToValidate = {
        email: email,
        otp: otp,
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const user = await User.findOne({
                where: {
                    email: req.body.email, email_verify_otp: otp,
                    updated_at: {
                        [Op.gte]: new Date(Date.now() - 2 * 60 * 1000) // Two minutes ago
                    },
                    role_id: 2
                }, attributes: ['id', 'role_id', 'email', 'contactnumber', 'userfullname', 'firstname', 'lastname', 'date_of_birth', 'profileimg', 'country_id', 'state_id', 'city_id', 'zip_code', 'password']
            });


            if ((!user)) {
                res.status(404).send({
                    message: "Invalid OTP",
                    error: true,
                    success: false,
                    status: '0',
                });
            } else {
                delete user.dataValues.password;

                const token = jwt.sign({ id: user.id, role_id: user.role_id }, secretKey, {
                    expiresIn: '30d', // Token expires in 1 hour
                });
                const udate_info = {
                    email_verify_otp: null,
                    is_verified_email: '1',
                    auth_token: token,
                }
                await User.update(udate_info, { where: { id: user.id, isactive: '1' } })
                const userAddresses = await UserAddress.findOne({
                    where: {
                        user_id: user.id,
                        status: '1',
                        is_default: '1'
                    },
                    attributes: ['id', 'user_id', 'name', 'title', 'apartment', 'land_mark', 'address', 'mobile_number', 'zip_code', 'is_default', 'is_gst', 'gst_number', 'company_name', 'company_address', 'is_shipping_address', 'is_billing_address', 'billing_name', 'billing_country_id', 'billing_state_id', 'billing_city_id', 'billing_address', 'billing_pincode', 'billing_phone'],
                    order: [['is_default', 'DESC']],
                    include: [
                        {
                            model: User,
                            as: 'user',
                            attributes: ['id', 'firstname'],
                            required: false
                        },
                        {
                            model: Country,
                            as: 'country',
                            attributes: ['id', 'country_name'],
                            required: false
                        },
                        {
                            model: State,
                            as: 'state',
                            attributes: ['id', 'state_name'],
                            required: false
                        },
                        {
                            model: City,
                            as: 'city',
                            attributes: ['id', 'city_name'],
                            required: false
                        },
                        {
                            model: Country,
                            as: 'billing_country',
                            attributes: ['id', 'country_name'],
                            required: false
                        },
                        {
                            model: State,
                            as: 'billing_state',
                            attributes: ['id', 'state_name'],
                            required: false
                        },
                        {
                            model: City,
                            as: 'billing_city',
                            attributes: ['id', 'city_name'],
                            required: false
                        }
                    ]
                });
                res.send({
                    message: 'Login successful',
                    msg: req.session.user,
                    msg1: req.session.lastActivity,
                    error: false,
                    success: true,
                    status: '1',
                    data: user,
                    token,
                    address: userAddresses
                });
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
                msg: error.message
            });
        }
    }
};



// user inactive

const UserInactive = async (req, res) => {
    // const user_id = req.userId;
    const mobile_number = req.body.mobile_number;
    const schema = Joi.object().keys({
        mobile_number: Joi.string()
        .regex(/^[0-9]{10}$/)
        .required()
        .label("Mobile Number"),
    });
    const dataToValidate = {
        mobile_number: mobile_number
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
            const userExists = await User.findOne({
                where: {
                    // id:user_id,
                    contactnumber: mobile_number
                }
            });
            if (!userExists) {
                res.status(404).send({
                    message: 'Mobile number does not exists',
                    error: true,
                    success: false,
                    status: '0',
                    data: req.body
                });
            } else {

                await User.update({ isactive:0}, {
                    where: {
                        // id: user_id,
                        contactnumber: mobile_number
                    }
                })
                return res.status(200).send({
                    message: 'User deactived',
                    error: false,
                    success: true,
                    status: '1',
                });

            }

        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                message_error: error.message,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
}

module.exports = {
    userlogin, userRegister, EditUserProfile, UserProfile, changePassword, forgotPassword, resetPassword, sendLoginOtp, userloginApp, verifyLoginOtp, resendOtp, expireOtp, sendMobileNumberVerifyOtp, verifyMobileNumberOtp
    , sendEmailVerifyOtp, verifyEmail,UserInactive
};
