
const config = require('../config/config');

const CCAvenue = require('../utils/ccavenueUtils'); // Adjust the path as n
const Order = require("../models/master/Order");
const OrderItem = require("../models/master/OrderItem");
const Cart = require("../models/master/Cart");
const User = require("../models/User");
const Product = require("../models/master/Product");
const EarnRewardPoint = require('../models/master/EarnRewardPoint');
const UserAddress = require('../models/master/UserAddress');
const Country = require('../models/master/Country');
const State = require('../models/master/State');
const City = require('../models/master/City');
const OrderDiscountCoupon = require("../models/master/OrderDiscountCoupon");
const Coupon = require("../models/master/Coupon");
const Setting = require('../models/master/Setting');
const BuyNow = require("../models/master/BuyNow");
const ProductMedia = require("../models/master/ProductMedia");
const OrderHistoryModel = require('../models/master/OrderHistory')
const getCurrentDateTime = () => new Date();
const Op = require('sequelize').Op;
const sequelize = require('sequelize');
const { sendEmail } = require("./../emailtemplates/SendMail");
const { json } = require('stream/consumers');
const axios = require('axios');
var http = require('http'),
  fs = require('fs'),
  ccav = require('../utils/ccavutil'),
  qs = require('querystring');
  const Razorpay = require('razorpay');
  const crypto = require('crypto');

  const razorpayInstance =  new Razorpay({
    key_id: process.env.Razorpay_key, // Replace with your Razorpay Key ID
    key_secret: process.env.Razorpay_Secret, // Replace with your Razorpay Secret Key
  });


const initiatePayment = async (req, res) => {
  const addressId = req.body.address_id;
  if (!addressId) {
    return res.send({
      success: false,
      message: 'Address id is required.',
      status: 0,
    })
  }
  try {
    const user_id = req.userId;
    const buy_now_data = req.body.buy_now ? req.body.buy_now : 'cart';
    const buy_now = await BuyNow.findAll({
      where: {
        user_id: user_id,
        status: 1
      },
      // attributes: ['id'],
      attributes: ['id', 'user_id', 'product_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount', 'currency_rate', 'usd_amount', 'currency_symbol', 'currency_code'],
      include: [
        {
          model: Product,
          as: 'product',
          attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge'],
          required: false,
          include: [
            {
              model: ProductMedia,
              as: 'productimage',
              attributes: ['file_name_120_x_120'],
              where: { is_default: '1' },
              required: false,
            }
          ]
        }
      ]
    });
    if (buy_now.length > 0 && buy_now_data == 'buy_now') {
      var carts = buy_now;
    } else {
      var carts = await Cart.findAll({
        where: {
          user_id: user_id,
          status: 1
        },
        attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount', 'currency_rate', 'usd_amount', 'currency_symbol', 'currency_code'],
        include: [
          {
            model: Product,
            as: 'product',
            attributes: ['id', 'product_name', 'product_slug', 'price', 'compare_price', 'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping', 'shipping_amount_type', 'shipping_charge'],
            required: false,
            include: [
              {
                model: ProductMedia,
                as: 'productimage',
                attributes: ['file_name_120_x_120'],
                where: { is_default: '1' },
                required: false,
              }
            ]
          }
        ]
      });
    }

    if (carts == 0) {
      res.status(202).send({
        message: process.env.RECORD_NOT_FOUND,
        error: true,
        success: false,
        status: '0'
      });

    }else {
      const setting = await Setting.findOne({
        attributes: ['max_shipping_amount']
      });

      let subtotal_amount = 0;
      let shipping_amt = 0;
      var stock_quantity_availability = [];
      if (carts) {
        for (const cart of carts) {
          if (cart.product) {
            subtotal_amount += parseFloat(cart.subtotal_amount);
            var shipping_amount_type = cart.product.shipping_amount_type;
            if (shipping_amount_type == 1 && cart.currency_code == "INR") {
              shipping_amt += parseFloat(cart.product.shipping_charge);
            } else if (shipping_amount_type == 2 && cart.currency_code == "INR") {
              shipping_amt += parseFloat(cart.subtotal_amount) * parseFloat(cart.product.shipping_charge) / 100;
            }

            var cartqty = cart.quantity;
            const prqty = cart.product.stock_quantity ? cart.product.stock_quantity : 0;
            if (prqty < cartqty) {
              stock_quantity_availability.push(cart.product.product_name);
            }

          }
        }
      }

      var stock_quantity_msg = '';
      if (stock_quantity_availability.length > 0) {
        var stock_quantity_msg = stock_quantity_availability.join(', ') + ' Out of stock';
        return res.status(202).send({
          message: stock_quantity_msg,
          error: true,
          success: false,
          status: '0'
        });
      }

      if (buy_now.length > 0 && buy_now_data == 'buy_now') {
        var order_discount = 0;
      } else {
        // const orderdiscount = await OrderDiscountCoupon.findOne({
        //   where: {
        //     user_id: user_id,
        //     applied_status: 1,
        //     discount_type: 'order'
        //   },
        //   attributes: ['discount_amt']
        // });
        // var order_discount = orderdiscount ? parseFloat(orderdiscount.discount_amt) : 0;

        // add multiple order discount 
          //   const result = await OrderDiscountCoupon.findOne({
          //     where: {
          //         user_id: user_id,
          //         discount_type: 'order'
          //     },
          //     attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
          //     raw: true,
          //     include: [
          //       {
          //           model: Coupon,
          //           as: 'applied_coupon_code',
          //           attributes: ['id', 'coupon_code'],
          //           where: {
          //               status: {
          //                   [Op.in]: ['1', '2'],
          //               },
          //               is_deleted: 0,
          //               number_of_uses: {
          //                   [Op.gt]: 0,
          //               },
          //               from_date: {
          //                   [Op.lte]: getCurrentDateTime()
          //               },
          //               to_date: {
          //                   [Op.gte]: getCurrentDateTime()
          //               }
          //           },
          //           required: false,
          //       }
          //   ],
          // });

          // var ord_discount = result ? parseFloat(result.total_subtotal_amount) : 0;


          const result = await OrderDiscountCoupon.findOne({
            where: {
                user_id: user_id,
                discount_type: 'order'
            },
            attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
            include: [
                {
                    model: Coupon,
                    as: 'applied_coupon_code',
                    attributes: ['id', 'coupon_code'],
                    where: {
                        status: {
                            [Op.in]: ['1', '2'],
                        },
                        is_deleted: 0,
                        number_of_uses: {
                            [Op.gt]: 0,
                        },
                        from_date: {
                            [Op.lte]: getCurrentDateTime()
                        },
                        to_date: {
                            [Op.gte]: getCurrentDateTime()
                        }
                    },
                    required: false,
                }
            ],
        });
        
        var ord_discount = result && result.applied_coupon_code ? parseFloat(result.get('total_subtotal_amount')) : 0;
        

            //end
      }

      const forderdiscount = await OrderDiscountCoupon.findOne({
        where: {
          user_id: user_id,
          applied_status: 1,
          discount_type: 'first_order',
          discount_mode: buy_now_data
        },
        attributes: ['discount_amt'],
        include: [
          {
              model: Coupon,
              as: 'applied_coupon_code',
              attributes: ['id', 'coupon_code'],
              where: {
                  status: {
                      [Op.in]: ['1', '2'],
                  },
                  is_deleted: 0,
                  number_of_uses: {
                      [Op.gt]: 0,
                  },
                  from_date: {
                      [Op.lte]: getCurrentDateTime()
                  },
                  to_date: {
                      [Op.gte]: getCurrentDateTime()
                  }
              },
              required: false,
          }
      ],
      });
      var first_order_discount = forderdiscount?.applied_coupon_code ? parseFloat(forderdiscount.discount_amt) : 0;

      const rewarddiscount = await OrderDiscountCoupon.findOne({
        where: {
          user_id: user_id,
          applied_status: 1,
          discount_type: 'reward'
        },
        attributes: ['discount_amt']
      });
      var reward_discount = rewarddiscount ? parseFloat(rewarddiscount.discount_amt) : 0;

      var total_discount = ord_discount + first_order_discount;
      var total_amtt = subtotal_amount - total_discount;

      if (rewarddiscount && reward_discount > total_amtt && buy_now_data != 'buy_now') {
        var total = reward_discount - total_amtt;
        var all_amt = reward_discount - total;
        reward_discount = all_amt;
        var total_amt = total_amtt - reward_discount;
      } else {
        var total_amtt = total_amtt - reward_discount;
      }

      

      var max_shipping_amount = setting ? parseFloat(setting.max_shipping_amount) : 0;
      if (max_shipping_amount > total_amtt) {
        // var shipping_charge = parseFloat(shipping_amt);
        var shipping_charge = 70;
      } else {
        var shipping_charge = 0;
      }
      var total_amt = total_amtt + shipping_charge;
      const chckExist_billingAdddress = await UserAddress.findOne({
        where: {
          id: addressId,
          user_id: req.userId,
          billing_country_id: { [sequelize.Op.ne]: null },  // billing_country_id is not 
          billing_state_id: { [sequelize.Op.ne]: null },
          billing_city_id: { [sequelize.Op.ne]: null },
        },
        attributes: ['id'],

      })
      let alias_country = '';
      let alias_state = '';
      let alias_city = '';
      if (chckExist_billingAdddress?.id) {
        alias_country = 'billing_country';
        alias_state = 'billing_state';
        alias_city = 'billing_city';
      } else {
        alias_country = 'country';
        alias_state = 'state';
        alias_city = 'city';
      }

      const uAddress = await UserAddress.findOne({
        where: {
          id: addressId,
          user_id: req.userId
        },
        include: [
          {
            model: User,
            as: 'user',
            attributes: ['id', 'firstname', 'email'],
            required: false
          },
          {
            model: Country,
            as: alias_country,
            attributes: ['country_name'],
            required: false
          },
          {
            model: State,
            as: alias_state,
            attributes: ['state_name'],
            required: false
          },
          {
            model: City,
            as: alias_city,
            attributes: ['city_name'],
            required: false
          }
        ]
      });

      const paymentData = {
        merchant_id: config.ccavenue.merchantId,
        order_id: `ORD${Date.now()}`,
        amount: Math.round(total_amt),
        currency: "INR",
        redirect_url: process.env.URL,
        cancel_url: config.ccavenue.cancelUrl,
        billing_name: uAddress.billing_name || uAddress.name,
        billing_email: uAddress.user ? uAddress.user.email : "",
        billing_tel: uAddress.billing_phone || uAddress.mobile_number,
        billing_address: `${uAddress.billing_address}`,
        billing_city: uAddress.billing_city ? uAddress.billing_city.city_name : uAddress.city.city_name,
        billing_state: uAddress.billing_state ? uAddress.billing_state.state_name : uAddress.state.state_name,
        billing_country: uAddress.billing_country ? uAddress.billing_country.country_name : uAddress.country.country_name,
        billing_zip: uAddress.billing_pincode || uAddress.zip_code,
        merchant_param5: addressId,
        merchant_param4: total_amt,
        merchant_param3: buy_now_data,
        merchant_param2: user_id,
        language: 'EN'
      };
      const encRequest = CCAvenue.getEncryptedOrder(paymentData);
      const accessCode = config.ccavenue.accessCode;
      const paymentUrl = `https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction&merchant_id=${paymentData.merchant_id}&encRequest=${encRequest}&access_code=${accessCode}`;
      res.status(200).json({ paymentUrl });
    }
  } catch (error) {
    res.status(500).send({
      error: error.message,
      status: 0,
      success: false
    });
  }
};

const handleResponse = async (req, res) => {

  const { encResp } = req.body;

  if (!encResp) {
    return res.status(400).json({ error: 'No encrypted response received' });
  }
  const decryptedResponse = CCAvenue.redirectResponseToJson(encResp);
  const payment_status = decryptedResponse.order_status === "Success" ? 1 : 2;

  const address_id = decryptedResponse.merchant_param5 || 1;
  const user_id = decryptedResponse.merchant_param2 || 0;

  const transaction_id = decryptedResponse.tracking_id;

  var buy_now_product = decryptedResponse.merchant_param3.buy_now;
  try {
    const buy_now = await BuyNow.findAll({
      where: {
        user_id: user_id,
        status: 1
      },
      attributes: ['id', 'user_id', 'product_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount'],
      include: [
        {
          model: Product,
          as: 'product',
          attributes: ['id', 'product_name', 'stock_quantity', 'is_shipping', 'shipping_amount_type', 'shipping_charge'],
          required: false,
        }
      ]
    });
    if (buy_now.length > 0 && buy_now_product == 'buy_now') {
      var carts = buy_now;
    } else {
      buy_now_product = 'cart'
      var carts = await Cart.findAll({
        where: {
          user_id: user_id,
          status: 1
        },
        attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount'],
        include: [
          {
            model: Product,
            as: 'product',
            attributes: ['id', 'product_name', 'stock_quantity', 'is_shipping', 'shipping_amount_type', 'shipping_charge'],
            required: false,
          }
        ]
      });
    }

    var stock_quantity_availability = [];

    let subtotal_amount = 0;
    let shipping_amt = 0;
    let product_discount = 0;
    if (carts) {
      for (const cart of carts) {
        if (cart.product) {
          var currency = cart.currency_code
          subtotal_amount += parseFloat(cart.subtotal_amount);
          product_discount += parseFloat(cart.discount_amt);
          var shipping_amount_type = cart.product.shipping_amount_type;
          // if (shipping_amount_type == 1) {
          //   shipping_amt += parseFloat(cart.product.shipping_charge);
          // } else if (shipping_amount_type == 2) {
          //   shipping_amt += parseFloat(cart.subtotal_amount) * parseFloat(cart.product.shipping_charge) / 100;
          // }

          var cartqty = cart.quantity;
          const prqty = cart.product.stock_quantity ? cart.product.stock_quantity : 0;
          if (prqty < cartqty) {
            stock_quantity_availability.push(cart.product.product_name);
          }
        }
      }
    }

    if (buy_now.length > 0 && buy_now_product == 'buy_now') {
      var order_discount = 0;
      var order_discount_id = 0;
    } else {
      // const orderdiscount = await OrderDiscountCoupon.findOne({
      //   where: {
      //     user_id: user_id,
      //     applied_status: 1,
      //     discount_type: 'order'
      //   },
      //   attributes: ['discount_id', 'discount_amt']
      // });
      // var order_discount = orderdiscount ? parseFloat(orderdiscount.discount_amt) : 0;
      // var order_discount_id = orderdiscount ? orderdiscount.discount_id : 0;

    // add multiple order discount
  //   const result = await OrderDiscountCoupon.findOne({
  //     where: {
  //         user_id: user_id,
  //         discount_type: 'order'
  //     },
  //     attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
  //     raw: true // Ensures you get a plain object rather than an instance of the model
  // });

  // var ord_discount = result.total_subtotal_amount ? parseFloat(result.total_subtotal_amount) : 0;

  const result = await OrderDiscountCoupon.findOne({
    where: {
        user_id: user_id,
        discount_type: 'order'
    },
    attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
    include: [
        {
            model: Coupon,
            as: 'applied_coupon_code',
            attributes: ['id', 'coupon_code'],
            where: {
                status: {
                    [Op.in]: ['1', '2'],
                },
                is_deleted: 0,
                number_of_uses: {
                    [Op.gt]: 0,
                },
                from_date: {
                    [Op.lte]: getCurrentDateTime()
                },
                to_date: {
                    [Op.gte]: getCurrentDateTime()
                }
            },
            required: false,
        }
    ],
});

var ord_discount = result && result.applied_coupon_code ? parseFloat(result.get('total_subtotal_amount')) : 0;

var orderdiscount = await OrderDiscountCoupon.findAll({
    where: {
        user_id: user_id,
        discount_type: 'order'
    },
    attributes: ['discount_amt','discount_id'],
    include: [
        {
            model: Coupon,
            as: 'applied_coupon_code',
            attributes: ['id', 'coupon_code'],
            required: false,
        }
    ],

  });
  const discountIdString = orderdiscount.map(item => item?.applied_coupon_code?.id);
  var discountIdArray = discountIdString.join(',');
  // end

  }

    const forderdiscount = await OrderDiscountCoupon.findOne({
      where: {
        user_id: user_id,
        applied_status: 1,
        discount_type: 'first_order',
        discount_mode: buy_now_product
      },
      attributes: ['discount_id', 'discount_amt']
    });
    var first_order_discount = forderdiscount ? parseFloat(forderdiscount.discount_amt) : 0;
    var first_order_discount_id = forderdiscount ? forderdiscount.discount_id : 0;

    const rewarddiscount = await OrderDiscountCoupon.findOne({
      where: {
        user_id: user_id,
        applied_status: 1,
        discount_type: 'reward'
      },
      attributes: ['discount_amt']
    });
    var reward_discount = rewarddiscount ? parseFloat(rewarddiscount.discount_amt) : 0;

    var reward_point = 0;
    if (reward_discount > 0) {
      const checkRewardPoint = await RewardPointWallet.findOne({
        attributes: ['id', 'total_points'],
        where: {
          user_id: user_id
        }
      });
      var reward_point = checkRewardPoint ? checkRewardPoint.total_points : 0;
    }
    // add order multiple order discount
    var reward_discount = rewarddiscount ? parseFloat(rewarddiscount.discount_amt) : 0;

    var total_discountt = ord_discount + first_order_discount + reward_discount + product_discount;

    var total_amtt = subtotal_amount - total_discountt;

    const setting = await Setting.findOne({
        attributes:['max_shipping_amount']
    });
    var max_shipping_amount = setting ? parseFloat(setting.max_shipping_amount) : 0;
    if(max_shipping_amount > total_amtt) {
        // var shipping_charge = parseFloat(shipping_amt);
        var shipping_charge = 70;
    } else {
        var shipping_charge = 0;
    }
    var total_amt = total_amtt + shipping_charge;

    // update by abhi
    // var minus_10_per = 0;
    // var disco = 0;
    // var total_amt = 0;
    // var shipping = 0;
    // if (total_amtt) {
    //   // var amount_dis = (total_amt - first_order_discount);
    //   disco = (total_amtt * 10 / 100);
    //   minus_10_per = (total_amtt - disco);
    //   if (minus_10_per >= 1000) {
    //     total_amt = minus_10_per
    //     shipping = 0;

    //   } else {
    //     total_amt = minus_10_per + 70;
    //     shipping = 70

    //   }

    // }


    var stock_quantity_msg = '';
    if (stock_quantity_availability.length > 0) {
      var stock_quantity_msg = stock_quantity_availability.join(', ') + ' Out of stock';
      return res.status(202).send({
        message: stock_quantity_msg,
        error: true,
        success: false,
        status: '0'
      });
    } else {
      // get user address
      const userAddress = await UserAddress.findOne({
        where: {
          id: address_id,
          status: '1'
        },
        attributes: ['id', 'user_id', 'name', 'title', 'apartment', 'land_mark', 'address', 'mobile_number', 'zip_code', 'country_id', 'state_id', 'city_id', 'is_default', 'gst_number', 'billing_name', 'billing_phone', 'billing_address', 'billing_pincode', 'company_name', 'company_address'],
        include: [
          {
            model: User,
            as: 'user',
            attributes: ['firstname', 'lastname', 'userfullname', 'email'],
            required: false
          },
          {
            model: Country,
            as: 'country',
            attributes: ['country_name'],
            required: false
          },
          {
            model: State,
            as: 'state',
            attributes: ['state_name'],
            required: false
          },
          {
            model: City,
            as: 'city',
            attributes: ['city_name'],
            required: false
          },
          {
            model: Country,
            as: 'billing_country',
            attributes: ['country_name'],
            required: false
          },
          {
            model: State,
            as: 'billing_state',
            attributes: ['state_name'],
            required: false
          },
          {
            model: City,
            as: 'billing_city',
            attributes: ['city_name'],
            required: false
          }
        ]
      });

      const discount = ord_discount;
      const f_order_discount = first_order_discount;
      const subTotal = subtotal_amount;

      const orders = await Order.create({
        user_id: user_id,
        transaction_id: transaction_id,
        total_amount: subTotal,
        discount_amt: discount,
        first_order_discount_amt: f_order_discount,
        reward_amt: reward_discount,
        shipping_amt: shipping_charge,
        tax_amt: 0,
        paid_amount: total_amt,
        payment_status: payment_status,
        payment_type: 1,
        currency: currency,
        discount_id: discountIdArray ? discountIdArray : null,
        first_order_discount_id: first_order_discount_id ? first_order_discount_id : null,
        first_name: userAddress.user ? userAddress.user.firstname : null,
        last_name: userAddress.user ? userAddress.user.lastname : null,
        name: userAddress.name ? userAddress.name : null,
        title: userAddress.title ? userAddress.title : null,
        apartment: userAddress.apartment ? userAddress.apartment : null,
        land_mark: userAddress.land_mark ? userAddress.land_mark : null,
        address: userAddress.address ? userAddress.address : null,
        mobile_number: userAddress.mobile_number ? userAddress.mobile_number : null,
        country: userAddress.country ? userAddress.country.country_name : null,
        state: userAddress.state ? userAddress.state.state_name : 0,
        city: userAddress.city ? userAddress.city.city_name : 0,
        zip_code: userAddress.zip_code ? userAddress.zip_code : null,
        gst_number: userAddress.gst_number ? userAddress.gst_number : null,
        company_name: userAddress ? userAddress.company_name : "",
        company_address: userAddress ? userAddress.company_address : "",
        billing_name: userAddress ? userAddress.billing_name : "",
        billing_phone: userAddress ? userAddress.billing_phone : "",
        billing_country: userAddress.billing_country?.country_name || "",
        billing_state: userAddress.billing_state?.state_name || "",
        billing_city: userAddress.billing_city?.city_name || "",
        billing_address: userAddress ? userAddress.billing_address : "",
        billing_pincode: userAddress ? userAddress.billing_pincode : "",
        created_at: getCurrentDateTime(),
        created_by: user_id
      });

      if (!orders) {
        res.status(202).send({
          message: process.env.NOT_INSERTED_MSG,
          error: true,
          success: false,
          status: '0'
        });
      } else {
        const orderId = orders.id;
        var total_disocunt = parseFloat(discount) + parseFloat(f_order_discount);
        // get cart data
        const cartArray = carts;
        for (const cart of cartArray) {
          const productId = cart.product_id;
          const quantity = cart.quantity;
          const amount = cart.amount;
          const prd_discount_amt = cart.discount_amt;
          const samount = cart.subtotal_amount;
          const pDiscounts = (total_disocunt > 0) ? (total_disocunt * samount) / subTotal : 0;
          const pDiscountAmts = samount - pDiscounts;

          await OrderItem.create({
            order_id: orderId,
            product_id: productId,
            quantity: quantity,
            price: amount,
            prd_discount_amt: prd_discount_amt,
            subtotal_amt: samount,
            discount_amt: pDiscounts,
            total_amt: pDiscountAmts,
            created_at: getCurrentDateTime()
          });

          const productDetail = await Product.findOne({
            attributes: ['stock_quantity'],
            where: {
              id: productId
            }
          });
          const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;
          const totalQty = prqty - quantity;

          const sumResult = await OrderItem.findOne({
            attributes: [
              [sequelize.fn('SUM', sequelize.col('quantity')), 'totalQuantity']
            ],
            where: {
              product_id: productId
            }
          });
          const totalQuantity = sumResult.getDataValue('totalQuantity');

          if (totalQty >= 0 && payment_status === 1) {
            await Product.update({
              stock_quantity: totalQty,
              sold_out_count: totalQuantity
            }, {
              where: {
                id: productId
              }
            });
          }
        }
        // update uses of coupon 23-oct-2024
            if(forderdiscount){
              const f_couponDetail = await Coupon.findOne({
              attributes: ['number_of_uses'],
              where: {
              id: forderdiscount.discount_id
              }
              });
              const uses = f_couponDetail.number_of_uses ? f_couponDetail.number_of_uses : 0;
              const f_totalUses = uses - 1;
              await Coupon.update({
              number_of_uses: f_totalUses,
              }, {
              where: {
              id: forderdiscount.discount_id
              }
              });
              }
              if(orderdiscount.length > 0){
                for (const orderDiscount of orderdiscount) {
                const couponDetail = await Coupon.findOne({
                attributes: ['number_of_uses'],
                where: {
                id: orderDiscount.discount_id
                }
                });
                const uses = couponDetail.number_of_uses ? couponDetail.number_of_uses : 0;
                const totalUses = uses - 1;
                await Coupon.update({
                number_of_uses: totalUses,
                }, {
                where: {
                id: orderDiscount.discount_id
                }
                });
                }
              }
          // end
        if (payment_status === 1) {
          if (buy_now.length > 0 && buy_now_product == 'buy_now') {
            await BuyNow.destroy({
              where: {
                user_id: user_id,
                status: 1,
              },
            });
            await OrderDiscountCoupon.destroy({
              where: {
                user_id: user_id,
              },
            });
          } else {
            await Cart.destroy({
              where: {
                user_id: user_id,
                status: 1,
              },
            });
            await OrderDiscountCoupon.destroy({
              where: {
                user_id: user_id,
              },
            });
          }

          if (reward_point > 0) {
            await EarnRewardPoint.create({
              user_id: user_id,
              order_id: orderId,
              reward_point: -reward_point,
              type: 1,
              debit_credit: 2,
              reward_cmnt: 'use',
              created_at: getCurrentDateTime()
            });
          }

          //SEND MAIL
          //   const orderDetail = await Order.findOne({
          //     where: {id:orderId},
          //     attributes:['id','transaction_id','bank_ref_no','total_amount','discount_amt','reward_amt','shipping_amt','tax_amt','paid_amount','payment_type','first_order_discount_amt',
          //     'payment_status','currency','discount_id','first_name','last_name','name','title','apartment','land_mark','address','mobile_number','country','state','city','zip_code','order_id','shipment_id','gst_number'],
          //     include:[
          //         {
          //             model:OrderItem,
          //             as:'order_item',
          //             attributes:['id','order_id','product_id','quantity','price','shipping_type','shipping_id','shipping_min_price','status','total_amt'],
          //             required: false,
          //             include:
          //             {
          //                 model:Product,
          //                 as:"products",
          //                 attributes:['id','product_name'],
          //                 required: false,
          //                 include: [{
          //                     model: ProductMedia,
          //                     as: 'productimage',
          //                     attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
          //                     where: { is_default: '1' },
          //                     required: false,
          //                 }],

          //             },
          //         },

          //   ],
          // });
          // sendEmail(userAddress.user,'OrderConfirmation',orderDetail);
          // let data = qs.stringify({
          // 'to': userAddress.user ? userAddress.user.email : null,
          // 'user_id': userAddress.user_id,
          // 'order_id': orderId,
          // });

          // const config = {
          // method: 'post',
          // url: process.env.SITE_URL + 'order_confirmation',
          // data: data
          // };
          // const responsee = await axios(config);
          //END
          // Redirect to success page

          return res.redirect(`${process.env.FRONT_SITE_URL}thanku-check?order_id=${orderId}`);
        } else {

          // let data = qs.stringify({
          //   'to': userAddress.user ? userAddress.user.email : null,
          //   'user_id': userAddress.user_id,
          //   'order_id': orderId,
          //   });

          //   const config = {
          //   method: 'post',
          //   url: process.env.SITE_URL + 'order_failed',
          //   data: data
          //   };
          //   const responsee = await axios(config);
          //END

          return res.redirect(`${process.env.FRONT_SITE_URL}payment-failed`);
          // return res.redirect(`${process.env.FRONT_SITE_URL_PAYMENT}`);
        }
      }
    }
  } catch (error) {
    res.status(500).send({
      message: process.env.ERROR_MSG,
      message_message: error.message,
      error: true,
      success: false,
      status: '0',
    });
  }

}

const cancelPayment = async (req, res) => {
  try {
    const { encResp } = req.body;
    const decryptedResponse = CCAvenue.redirectResponseToJson(encResp);

    const insertObj = {
      items: JSON.stringify(decryptedResponse),
      reason: decryptedResponse.status_message,
      user_id: decryptedResponse.merchant_param2,
      status: '1',
      created_at: getCurrentDateTime(),
      created_by: decryptedResponse.merchant_param2
    }
    const insert = await OrderHistoryModel.create(insertObj)
    if (insert.length == 0) {
      return res.status(404).send({
        message: process.env.NOT_INSERTED_MSG,
        success: false,
        error: true,
        status: '0'
      })
    } else {
      return res.redirect(`${process.env.FRONT_SITE_URL_PAYMENT}`);
    }
  } catch (error) {
    res.status(500).send({
      message: process.env.ERROR_MSG,
      error: error.message,
      success: false,
      status: '0',
    });
  }
}


// testing payment gateway

const initiatePayment2 = function (request, response) {
  console.log("testing");
  var body = request.body,
    // workingKey = '541B8138FA326D97596E57B1FE356B4A',		//Put in the 32-Bit key shared by CCAvenues.
    workingKey = '2FD1F43BD6E5EC396352A5B4EC702C79',		//Put in the 32-Bit key shared by CCAvenues.
    accessCode = 'AVVG86LE27BB88GVBB';		//Put in the access code shared by CCAvenues.
  // accessCode = 'AVCM79LD90BL68MCLB';		//Put in the access code shared by CCAvenues.
  // encRequest = '',
  // formbody = '';
  // merchant_id = 2168434;
  // const body = req.body;
  console.log(body, 'Received body ================');

  // Proceed with encryption and form construction here
  // const encRequest = ccav.encrypt(body, workingKey); 
  const bodyString = typeof body === 'object' ? JSON.stringify(body) : body;

  encRequest = ccav.encrypt(bodyString, workingKey);
  const merchant_id = 2168434;

  const formbody = `<html><head><title>Sub-merchant checkout page</title>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script></head>
    <body><center><iframe width="482" height="500" scrolling="No" frameborder="0" 
    id="paymentFrame" src="https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction&merchant_id=${merchant_id}&encRequest=${encRequest}&access_code=${accessCode}"></iframe></center>
    <script type="text/javascript">$(document).ready(function() {
        $("iframe#paymentFrame").load(function() {
            window.addEventListener("message", function(e) {
                $("#paymentFrame").css("height", e.data["newHeight"] + "px");
            }, false);
        });
    });</script></body></html>`;

  response.writeHead(200, { 'Content-Type': 'text/html' });
  response.end(formbody);

};

const InsertOrder = async (req, res) => {
  //get address for find user address
  const addressId = req.body.address_id;
  const orderId = req.body.order_id;
  // if user not sent address is into frontend then show error
  if (!addressId) {
    return res.send({
      success: false,
      message: 'Address id is required.',
      status: 0,
    })
  }
  try {
    //get user id from token
    // console.log(req.userId,"==============");
    // const user_id = req.userId;
    const user_id = req.userId;
    //get buy now data from frontend for manage cart data
    const buy_now_data = req.body.buy_now || '';
    // user selected product store in cart i nn both buy now and cart cash
    const carts = buy_now_data === 'buy_now' ? await BuyNow.findAll({
      where: { user_id, status: 1 },
      attributes: ['id', 'user_id', 'product_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount'],
      include: [
        {
          model: Product,
          as: 'product',
          attributes: [
            'id', 'product_name', 'product_slug', 'price', 'compare_price',
            'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping',
            'shipping_amount_type', 'shipping_charge'
          ],
          required: false,
          include: [
            {
              model: ProductMedia,
              as: 'productimage',
              attributes: ['file_name_120_x_120'],
              where: { is_default: '1' },
              required: false,
            }
          ]
        }
      ]
    }) : await Cart.findAll({
      where: { user_id, status: 1 },
      attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'discount_amt', 'subtotal_amount'],
      include: [
        {
          model: Product,
          as: 'product',
          attributes: [
            'id', 'product_name', 'product_slug', 'price', 'compare_price',
            'stock_quantity', 'image_alt', 'weight', 'unit', 'is_shipping',
            'shipping_amount_type', 'shipping_charge'
          ],
          required: false,
          include: [
            {
              model: ProductMedia,
              as: 'productimage',
              attributes: ['file_name_120_x_120'],
              where: { is_default: '1' },
              required: false,
            }
          ]
        }
      ]
    });

    // if cart in empty  then send error message
    if (carts.length == 0) {
      res.status(202).send({
        message: process.env.RECORD_NOT_FOUND,
        error: true,
        success: false,
        status: '0'
      });
    }
    else {
      //get max shipping amount from setting
      const setting = await Setting.findOne({
        attributes: ['max_shipping_amount','shipping_amount','discount']
      });
      // define variable for subtotal amount and shipping amount
      let subtotal_amount = 0;
      let shipping_amt = 0;
      // check if cart exist then check carts is an array or not
      if (carts && Array.isArray(carts)) {
        // apply loop for every carts and destructure product and subtotal_amount from carts
        carts.forEach(({ product, subtotal_amount: itemSubtotalAmount }) => {
          // if product is null then instaint return 
          if (!product) return;
          // add subtotal_amount in subtotal_amount
          itemSubtotalAmount = parseFloat(itemSubtotalAmount);
          // destructure shipping_amount_type and shipping_charge from product
          const { shipping_amount_type, shipping_charge } = product;
          // console.log(shipping_amount_type,shipping_charge,'shipping_charge')
          subtotal_amount += itemSubtotalAmount;
          // Calculate shipping charge based on type
          const shippingCharge = parseFloat(shipping_charge);
          // console.log(shippingCharge,'shippingCharge')
          // if shipping_amount_type is 1 then use max shipping amount in shiping charge else use shipping charge based on percentage
          if (shipping_amount_type === 1) {
            shipping_amt += shippingCharge; // Fixed shipping charge
          } else if (shipping_amount_type === 2) {
            shipping_amt += (subtotal_amount * shippingCharge) / 100; // Percentage-based shipping
          }
        })
      };

      //create a variable for store discount value and initialize with 0
      var order_discount = 0;
      var discountIdArray = 0;
      //if buy_now_data is not buy_now then run this
      if (buy_now_data !== 'buy_now') {
        // const orderdiscount = await OrderDiscountCoupon.findOne({
        //   where: {
        //     user_id: user_id,
        //     discount_mode: buy_now_data,
        //     discount_type: 'order'
        //   },
        //   attributes: ['id','discount_amt']
        // });
        
        // discount_id = orderdiscount ? orderdiscount.id : 0;
        // order_discount = orderdiscount?.discount_amt ? parseFloat(orderdiscount.discount_amt) : 0;

        const result = await OrderDiscountCoupon.findOne({
          where: {
            user_id: user_id,
            discount_mode: buy_now_data,
            discount_type: 'order'
          },
          attributes: [[sequelize.fn('SUM', sequelize.col('discount_amt')), 'total_subtotal_amount']],
          include: [
            {
              model: Coupon,
              as: 'applied_coupon_code',
              attributes: ['id', 'coupon_code'],
              where: {
                status: {
                  [Op.in]: ['1', '2'],
                },
                is_deleted: 0,
                number_of_uses: {
                  [Op.gt]: 0,
                },
                from_date: {
                  [Op.lte]: getCurrentDateTime()
                },
                to_date: {
                  [Op.gte]: getCurrentDateTime()
                }
              },
              required: false,
            }
          ],
        });

        var order_discount = result && result.applied_coupon_code ? parseFloat(result.get('total_subtotal_amount')) : 0;

        var orderdiscount = await OrderDiscountCoupon.findAll({
          where: {
            user_id: user_id,
            discount_type: 'order'
          },
          attributes: ['discount_amt','discount_id'],
          include: [
            {
              model: Coupon,
              as: 'applied_coupon_code',
              attributes: ['id', 'coupon_code'],
              required: false,
            }
          ],

        });
        const discountIdString = orderdiscount.map(item => item?.applied_coupon_code?.id);
        var discountIdArray = discountIdString.join(',');

      }

      //get first order discount based on userid
      const forderdiscount = await OrderDiscountCoupon.findOne({
        where: {
          user_id: user_id,
          discount_mode: buy_now_data,
          discount_type: 'first_order'
        },
        attributes: ['discount_amt']
      });
      // if forderdiscount is true then get discount amount and store in variable otherwise  0
      const first_order_discount = forderdiscount ? parseFloat(forderdiscount.discount_amt) : 0;

      //get reward discount based on userid
      const rewarddiscount = await OrderDiscountCoupon.findOne({
        where: {
          user_id: user_id,
          discount_mode: buy_now_data,
          discount_type: 'reward'
        },
        attributes: ['discount_amt']
      });
      // if rewarddiscount is true then get discount amount and store in variable otherwise  0
      let reward_discount = rewarddiscount ? parseFloat(rewarddiscount.discount_amt) : 0;
      // combine the all type of discount
      const total_discount = order_discount + first_order_discount;
      // calculate total amount after discount
      let total_amount = subtotal_amount - total_discount;

      let total_price = total_amount; // Initialize total_price with a valid value (e.g., total_amount)

      // if rewarddiscount and reward_discount is greater than total_price and buy_now_data is not buy_now then subtract reward_discount from total_price
      if (rewarddiscount && reward_discount > total_price && buy_now_data !== 'buy_now') {
        // Calculate the difference between reward_discount and total_price
        const total = reward_discount - total_price;
        // Subtract the difference from total_price and update reward_discount
        reward_discount -= total; // Directly update reward_discount
        // Update total_price with the remaining difference
        total_price = total_price - reward_discount; // Calculate final total_amt
      } else {
        // Update total_price with the remaining reward_discount in buy_now case
        total_price = total_price - reward_discount; // Direct calculation when condition is false
      }


      // get max shipping amount from setting
      const max_shipping_amount = parseFloat(setting?.max_shipping_amount || 0);

      // calculate shipping charges based on max shipping amount
      const shipping_charge = max_shipping_amount > total_price
        ? parseFloat(setting.shipping_amount)
        : 0;
      // add shiping charges in total price

        // add discount
        var extraDisount = 0;
        if(setting.discount > 0){
         extraDisount = (Math.round(total_price) * setting.discount) / 100;
         total_price =total_price - Math.round(extraDisount);
        }
        //end

      const total_amt = total_price + shipping_charge;


      const chckExist_billingAdddress = await UserAddress.findOne({
        where: {
          id: addressId,
          user_id: req.userId,
          billing_country_id: { [sequelize.Op.ne]: null },  // billing_country_id is not 
          billing_state_id: { [sequelize.Op.ne]: null },
          billing_city_id: { [sequelize.Op.ne]: null },
        },
        attributes: ['id'],

      })

      // Destructure or assign aliases based on whether billing address exists
      const alias_country = chckExist_billingAdddress ? 'billing_country' : 'country';
      const alias_state = chckExist_billingAdddress ? 'billing_state' : 'state';
      const alias_city = chckExist_billingAdddress ? 'billing_city' : 'city';

      // find user address by id
      const uAddress = await UserAddress.findOne({
        where: {
          id: addressId,
          user_id: req.userId
        },
        raw: true,
        include: [
          {
            model: Country,
            as: alias_country,
            attributes: ['country_name'],
            required: false
          },
          {
            model: State,
            as: alias_state,
            attributes: ['state_name'],
            required: false
          },
          {
            model: City,
            as: alias_city,
            attributes: ['city_name'],
            required: false
          }
        ]
      });

      // if user address not found then return error
      if (!uAddress) {
        return res.status(404).json({ error: 'User address not found' });
      }

      const options = {
        amount: Math.round(total_amt) * 100, // Convert to paise
        currency: 'INR',
        receipt: `receipt_${Math.random()}`,
        // prefill: {
        // //   // "name": "User Name", // Replace with the actual user name
        // //   // "email": "user@example.com", // Replace with the actual user email
        //    contact: "9314959433" // Replace with the actual user's mobile number
        // }, // Generate a random receipt ID
      };

      // Create order with Razorpay
      const orders = await razorpayInstance.orders.create(options);

      if (orders.status !== 'created') {
        return res.status(400).json({ message: 'Order not created' });
      }
      // Create order
      var all_discount = Math.round(total_discount + extraDisount);
      const order = await Order.create({
        user_id,
        order_id: orders.id,
        address_id: addressId,
        total_amount: Math.round(subtotal_amount),
        discount_amt: all_discount,
        first_order_discount_amt: Math.round(first_order_discount),
        reward_amt: reward_discount,
        shipping_amt: shipping_charge,
        paid_amount: Math.round(total_amt),
        payment_type: 1,
        currency: 'INR',
        discount_id: discountIdArray ? discountIdArray : null,
        first_order_discount_id: forderdiscount ? forderdiscount.id :0 ,
        first_name: uAddress?.name || "",
        last_name: uAddress?.name || "",
        address: uAddress?.address || "",
        name: uAddress?.name || "",
        title: uAddress?.title || "",
        apartment: uAddress?.apartment || "",
        land_mark: uAddress?.land_mark || "",
        mobile_number: uAddress?.mobile_number || "",
        country: uAddress.billing_country || uAddress['billing_country.country_name'],
        state: uAddress.billing_state || uAddress['billing_state.state_name'],
        city: uAddress.billing_city || uAddress['billing_city.city_name'],
        zip_code: uAddress?.zip_code || "",
        gst_number: uAddress.gst_number || "",
        company_name: uAddress.company_name || "",
        company_address: uAddress.company_address || "",
        billing_name: uAddress.billing_name || "",
        billing_phone: uAddress.billing_phone || "",
        billing_country: uAddress['billing_country.country_name'],
        billing_state: uAddress['billing_state.state_name'],
        billing_city: uAddress['billing_city.city_name'],
        billing_address: uAddress.billing_address || "",
        billing_pincode: uAddress.billing_pincode || "",
        payment_status: "2",
        created_at: getCurrentDateTime(),
        created_by: user_id,
      });
      if (!order) {
        return res.status(500).json({
          message: 'Order not inserted',
          error: true,
          success: false,
          status: '0',
        });
      }

      // const cartData = buy_now_data ? buy_now_data : [];

      // const Carts = cartData.length > 0
      //   ? await BuyNow.findAll({ where: { user_id, status: 1 }, attributes: ['id', 'user_id', 'product_id', 'quantity', 'amount', 'subtotal_amount'] })
      //   : await Cart.findAll({ where: { user_id, status: 1 }, attributes: ['id', 'user_id', 'product_id', 'product_variant_id', 'quantity', 'amount', 'subtotal_amount'] });

      if (carts.length > 0) {
        for (const cart of carts) {
          const { product_id, quantity, amount } = cart;

          const samount = quantity * amount;
          const pDiscounts = all_discount > 0 ? (all_discount * samount) / (subtotal_amount || 1) : 0;
          const pDiscountAmts = samount - pDiscounts

          await OrderItem.create({
            order_id: order.id,
            product_id,
            quantity,
            price: amount,
            discount_amt: pDiscounts,
            total_amt: pDiscountAmts,
            created_at: getCurrentDateTime(),
          });

        }
        const cartCondition = buy_now_data.length === 0 ? Cart : BuyNow;
        // await cartCondition.destroy({ where: { user_id, status: 1 } });
      }
      return res.status(200).json({
        status: 'success',
        message: 'order created successfully',
        Razorpay: orders,
        data: order,
        status: '1'
      });
    }
  }
  catch (error) {
    return res.status(500).send({
      success: false,
      message: process.env.ERROR_MSG,
      message_error: error.message,
      error: error.message,
      status: "00"
    })
  }
}


const VerifyPayment = async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature,buy_now } = req.body;

    // 1. Create a body string for signature verification
    const body = `${razorpay_order_id}|${razorpay_payment_id}`;

    // 2. Generate expected signature with HMAC SHA256
    const expected_signature = crypto
      .createHmac('sha256', process.env.Razorpay_Secret)
      .update(body.toString())
      .digest('hex');

    // 3. Check if the signature matches
    if (expected_signature !== razorpay_signature) {
      // Payment verification failed, no update to payment_status
      return res.status(400).json({
        status: "failure",
        message: "Payment verification failed"
      });
    }

    // 4. Fetch payment details from Razorpay to verify the actual payment status
    const razorpayPaymentDetails = await axios.get(`https://api.razorpay.com/v1/payments/${razorpay_payment_id}`, {
      auth: {
        username: process.env.Razorpay_key,  // Your Razorpay Key ID
        password: process.env.Razorpay_Secret   // Your Razorpay Secret
      }
    });

    const paymentData = razorpayPaymentDetails.data;
    const paymentStatus = paymentData.status; // Captured, Failed, etc.
    const transaction_id = paymentData.id; // Razorpay Transaction ID
    const bank_reference = paymentData.acquirer_data?.bank_transaction_id; // Bank reference ID

    // 5. Check if payment was successfully captured
    if (paymentStatus !== "captured") {
      // Payment is either failed or pending, so no status update
      return res.status(400).json({
        status: "failure",
        message: `Payment is not successful. Current status: ${paymentStatus}`
      });
    }

    // 6. Payment is successful, now find the order and update payment_status
    const order = await Order.findOne({ where: { order_id: razorpay_order_id } });
    if (!order) {
      return res.status(404).json({ status: "failure", message: "Order not found" });
    }
    // await Cart.destroy({ where: { user_id:req.body.user_id, status: 1 } });
    // await OrderDiscountCoupon.destroy({
    //   where: {
    //     user_id: req.body.user_id,
    //   },
    // });

    if (buy_now === 'buy_now') {
      await BuyNow.destroy({
        where: {
          user_id: req.body.user_id,
          status: 1,
        },
      });
    } else {
      await Cart.destroy({
        where: {
          user_id: req.body.user_id,
          status: 1,
        },
      });
    }

    await OrderDiscountCoupon.destroy({
      where: {
        user_id: req.body.user_id,
        discount_mode: buy_now,
        discount_type: 'order'
      },
    });
    await OrderDiscountCoupon.destroy({
      where: {
        user_id: req.body.user_id,
        discount_type: 'first_order',
      },
    });


    // 7. Update payment_status, transaction_id, and bank_reference in one query
    await Order.update(
      {
        payment_status: "1",  // Assuming '1' means paid
        transaction_id: transaction_id,
        bank_ref_no: bank_reference || "N/A"
      },
      { where: { order_id: razorpay_order_id } } // Use transaction here
    );

    // 8. Update stock quantity for the products in the order
    const orderItems = await OrderItem.findAll({ where: { order_id: order.id } });

    for (const item of orderItems) {
      const product = await Product.findOne({ where: { id: item.product_id } });
      if (product) {
        product.stock_quantity -= item.quantity;
        if (product.stock_quantity < 0) product.stock_quantity = 0; // Prevent negative stock
        await product.save();
      }
    }

    if (order?.reward_amt > 0) {
      await EarnRewardPoint.create({
        user_id,
        order_id: order.id,
        reward_point: order.reward_amt,
        type: 1,
        debit_credit: 2,
        reward_cmnt: 'use',
        created_at: getCurrentDateTime(),
      });
    }

    // 9. Respond with success
    return res.json({
      status: "success",
      message: "Payment verified and stock updated successfully",
      order_id: order.id
    });

  } catch (error) {
    return res.status(500).json({
      status: "0",
      message: "Internal server error",
      error:error.message,
    });
  }
};

module.exports = { handleResponse, initiatePayment, cancelPayment, initiatePayment2, InsertOrder, VerifyPayment };

