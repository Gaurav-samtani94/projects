const bodyParser = require('body-parser');
const express = require('express')
const jwt = require('jsonwebtoken');
const Joi = require('joi');
const md5 = require('md5');
const multer = require('multer');
const secretKey = 'storepedia277833';
const currentDate = new Date();
const current_date = Date.now();
const fs = require('fs');
const path = require('path');
const moment = require('moment');
const Op = require('sequelize').Op;
const { error } = require('console');
const User = require('../../models/User');

//user login app
const userloginApp = async (req, res) => {
    const mobile_number = req.body.mobile_number;
    const schema = Joi.object().keys({
        mobile_number:  Joi.string().regex(/^[0-9]{10}$/).required().label("Mobile Number"),
    });
    const dataToValidate = {
        mobile_number: mobile_number
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
                const user = await User.findOne({ where: { contactnumber: mobile_number,}, attributes: ['id', 'role_id', 'contactnumber'] });
                if((!user)){
                    const otp = Math.floor(1000 + Math.random() * 9000);
                    const users = await User.create({ 
                        role_id:4,
                        contactnumber:mobile_number,
                        last_login_otp: otp,
                        created_at:current_date
                    });
                    res.send({
                        message: 'Signup otp send successful',
                        error: false,
                        success: true,
                        status: '1',
                        otp: otp,
                        data:users
                    });
                }else{
                    const otp = Math.floor(1000 + Math.random() * 9000);
                    
                    var users = await User.update({
                        last_login_otp: otp,
                    },{
                        where: {
                        id:user.id
                        }
                    });
                
                    res.send({
                        message: 'Login otp send successful',
                        error: false,
                        success: true,
                        status: '1',
                        otp: otp,
                        data:user
                    });
                }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
};




//verify login otp start
const verifyLoginOtp = async (req, res) => {
    const id = req.body.id;
    const otp = req.body.otp;
    const schema = Joi.object().keys({
        id:Joi.number().integer().required(),
        otp:Joi.number().integer().required(),
    });
    const dataToValidate = {
        id:id,
        otp:otp
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const updateUser = await User.findOne({
                    where: {
                        id:id,
                        last_login_otp:otp
                    },
                    attributes: ['id', 'role_id', 'email', 'contactnumber', 'userfullname','firstname','lastname','date_of_birth','profileimg','country_id','state_id','city_id','zip_code','password']
                });
                if (!updateUser){
                    res.status(404).send({
                        message:'Otp not exists',
                        error: false,
                        success: true,
                        status: '0'
                    });
                }else{
                    var user = await User.update({
                        login_attempt:'1',
                        last_login: currentDate
                    },{
                        where: {
                            id:updateUser['id']
                        }
                    });
                   
                    const token = jwt.sign({ id: updateUser['id'], role_id: updateUser['role_id'] }, secretKey, {
                        expiresIn: '30d', // Token expires in 1 hour
                    });
                    res.status(200).send({
                        message:'Login successfully',
                        error: false,
                        success: true,
                        status: '1',
                        data: updateUser,
                        token
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}

//user expire otp app
const expireOtp = async (req, res) => {
    const user_id = req.body.user_id;
    const schema = Joi.object().keys({
        user_id:Joi.number().integer().required(),
    });
    const dataToValidate = {
        user_id: user_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
        try {
                const user = await User.findOne({ where: { id: user_id}, attributes: ['id'] });

                if((!user)){
                    res.status(202).send({
                        message:"Invalid user",
                        error: true,
                        success: false,
                        status: '0',
                    });
                }else{
                   
                    var users = await User.update({
                        last_login_otp: '',
                    },{
                        where: {
                        id:user.id
                        }
                    });
                
                    res.send({
                        message: 'Otp Expire successful',
                        error: false,
                        success: true,
                        status: '1',
                    });
                }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: '0',
            });
        }
    }
};
//user expire otp app

module.exports = {
    userloginApp,verifyLoginOtp,expireOtp
};