const Joi = require('joi');
require('dotenv').config();
const getCurrentDateTime = () => new Date()
const moment = require('moment')
const { Op } = require('sequelize');
const sequelize = require('sequelize');
const BarcodeModel = require('../../models/inventory/BarcodeModel')
const ProductModel = require('../../models/inventory/ProductInvtModel.js')
const RoleModel = require('../../models/master/Role')
const ProductINVTModel = require('../../models/inventory/ProductInvtModel.js')
const ProductPurchaseModel = require('../../models/inventory/PurchasePrdctModel.js')
const SellerPlatformModel = require('../../models/inventory/SellerplatformModel.js')
const ProductQuatintieModel = require('../../models/inventory/ProductQuatintieModel.js')
const VendorModel = require('../../models/inventory/Vendors.js')
const StoreLocationModel = require('../../models/inventory/Storelocation.js')
const SizeModel = require('../../models/master/Size.js')
const ColorModel = require('../../models/master/Color')

const Product = require('../../models/master/Product')
const ProductMedia = require('../../models/master/ProductMedia')
const RelInvtStrpdProduct = require('../../models/inventory/RelInvtStrpdProduct')
const SiteSellerProducts = require('../../models/inventory/SiteSellerProducts')

const Order =  require("../../models/master/Order");
const OrderItem =  require("../../models/master/OrderItem");

const InvtProducts = require("../../models/master/InvtProduct");
const LawQtyNotificationReport = require("../../models/inventory/LawQtyNotificationReport");

const { SiteSellerProduct, InvtProduct, MainInvtRelInvtStrpdProduct, ProductAttrValue, Category, ProductAttrType, MainInvtQty, MainProductAttribute, MainProduct, ProductType, ProductMaterial, SiteSellerPlatform,PurchasePrdctModel} = require('../../models/inventory/indexModel.js');
const OrderModel = require('../../models/inventory/orderModel.js');

const BarCodeCheck = async (req, res) => {
    // console.log(req.roleId,'role_id');
    const schema = Joi.object().keys({
        bar_code_number: Joi.string().required(),
        id: Joi.number().required()
    });
    const dataToValidate = {
        bar_code_number: req.body.bar_code_number,
        id: req.roleId
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.send({
            message: result.error.details[0].message,
            error: true,
            success: false,
            status: '0',
        });
    } else {
        try {
            const checkPermission = await RoleModel.findOne({ where: { id: 4 } });
            if (!checkPermission || checkPermission.id !== 4) {
                return res.send({
                    message: "Role and permission not allowed.",
                    error: true,
                    success: false,
                    status: "0",
                });
            } else {
                const barcodeCheck = await BarcodeModel.findAll({
                    where: { bar_code_number: req.body.bar_code_number, status: '1' },
                    attributes: { exclude: ['created_at', 'updated_at'] },
                    include: [
                        {
                        model: ProductModel,
                        as:'invt_product_model',
                        attributes: { exclude: ['created_at', 'updated_at', 'created_by', 'updated_by', 'status'] },
                        include: [
                            {
                                model: RelInvtStrpdProduct,
                                as: 'rel_product',
                                attributes: ['strpd_prod_id'],
                                include: [
                                    {
                                        model: Product,
                                        as: 'strpd_product',
                                        attributes: ['id','product_name'],
                                        include: [
                                            {
                                                model:ProductMedia,
                                                as:'productimages',
                                                attributes: ['id','file_name','file_name_200_x_200','file_name_180_x_180','file_name_150_x_150','file_name_120_x_120'],
                                                required: false,
                                                where: { is_default: '1' },
                                            },
                                            {
                                                model: SiteSellerProducts,
                                                as: 'site_seller_product',
                                                attributes: ['id','sku','seller_id'],
                                                include: [
                                                    {
                                                        model: SellerPlatformModel,
                                                        as: 'site_seller',
                                                        attributes: ['id','seller_platform_name'],
                                                    }
                                                ],
                                            }
                                        ],
                                    }
                                ],
                            }
                        ],
                    },

                        ]
                });
                if (barcodeCheck.length > 0) {
                    const size_id = barcodeCheck[0]?.main_invt_product?.size_id;
                    const color_id = barcodeCheck[0]?.main_invt_product?.color_id;
                    const sizeData = size_id ? await SizeModel.findOne({
                        where: { id: size_id, status: '1' },
                        attributes: { exclude: ['created_at', 'created_by', 'updated_at', 'updated_by', 'status'] }
                    }) : null;
                    const colorData = color_id ? await ColorModel.findOne({
                        where: { id: color_id, status: '1' },
                        attributes: { exclude: ['created_at', 'created_by', 'updated_at', 'updated_by', 'status'] }
                    }) : null;
                    // Merge the data into one object
                    const responseData = {
                        ...barcodeCheck[0].toJSON(),
                        colorData,
                        sizeData
                    };
                    return res.send({
                        message: process.env.SUCCESS_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: responseData
                    });
                } else {
                    return res.send({
                        message: 'Barcode is invalid',
                        error: true,
                        success: false,
                        status: '0',
                    });
                }
            }
        } catch (error) {
            res.send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: '0'
            });
        }
    }
};

const ProdectListWithRelation = async (req, res) => {
    try {
        const list = await ProductINVTModel.findAll({ where: { status: '1' }, include: { model: ProductPurchaseModel, required: true } })
        if(list.length > 0) {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: list
            })
        } else {
            return res.status(204).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0',
            })
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0'
        })
    }
}

const SellerPlatformList = async (req, res) => {
    try {
        const list = await SellerPlatformModel.findAll({ where: { status: '1' } })
        if (list.length > 0) {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: list
            })
        } else {
            return res.status(204).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0',
            })
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0'
        })
    }
}

const ProductQuatintieList = async (req, res) => {
    try {
        const list = await ProductQuatintieModel.findAll({ where: { status: '1' } })
        if (list.length > 0) {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: list
            })
        } else {
            return res.status(204).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0',
            })
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0'
        })
    }
}

const GetVendorList = async (req, res) => {
    try {
        const list = await VendorModel.findAll({ where: { status: '1' }, attributes: ['id', 'name', 'status'] });
        if (list.length > 0) {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: list
            })
        } else {
            return res.status(204).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0',
            })
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0'
        })
    }
}

const GetStoreLocationList = async (req, res) => {
    try {
        const list = await StoreLocationModel.findAll({ where: { status: '1' }, attributes: ['id', 'location', 'status'] });
        if (list.length > 0) {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: list
            })
        } else {
            return res.status(204).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            })
        }
    } catch (error) {
        return res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0'
        })
    }
}

const addProductPurchase = async (req, res) => {
    const schema = Joi.object().keys({
        invt_product_id: Joi.number().required(),
        vendor_id: Joi.string().required(),
        prod_quantity: Joi.number().required(),
        rate_per_qty: Joi.number().required(),
        total_amount: Joi.number().required(),
        purchase_date: Joi.date().required(),
        invoice_no: Joi.string().required(),
        invoice_attachment: Joi.string().required(),
        store_location_id: Joi.number().required(),
        created_by: Joi.number().required(),
        created_at: Joi.date().iso().required(),
    });
    const dataToValidate = {
        invt_product_id: req.body.invt_product_id,
        vendor_id: req.body.vendor_id,
        prod_quantity: req.body.prod_quantity,
        rate_per_qty: req.body.rate_per_qty,
        total_amount: req.body.total_amount,
        purchase_date: req.body.purchase_date,
        invoice_no: req.body.invoice_no,
        invoice_attachment: req.body.invoice_attachment,
        store_location_id: req.body.store_location_id,
        created_by: req.userId,
        created_at: getCurrentDateTime(),
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {
        try {
            const insert = await ProductPurchaseModel.create(dataToValidate);
            if (insert) {
                return res.status(200).send({
                    message: process.env.SUCCESS_MSG,
                    error: false,
                    success: true,
                    status: "1",
                    data: insert,
                });
            }else{
                return res.status(404).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: "0",
                });  
            }
        } catch (error) {
            res.status(500).send({
                message: process.env.ERROR_MSG,
                error: error.message,
                success: false,
                status: "0",
            });
        }
    }
};

const GetproductQuantyList = async (req, res) => {
    const schema = Joi.object().keys({
        product_id: Joi.number().required(),
    })
    const dataToValidate = {
        product_id: req.body.product_id
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    }
    try {
        const list = await ProductQuatintieModel.findAll({
            where: { status: '1', product_id: req.body.product_id },
            attributes: { exclude: ['entry_by', 'entry_date'] },
            include: {
                model: ProductModel,
                required: true,
                attributes: { exclude: ['updated_by', 'updated_at', 'created_by', 'created_at'] }
            }
        })
        if (list.length > 0) {
            return res.send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: "1",
                data: list,
            })
        } else {
            return res.send({
                message: process.env.ERROR_MSG,
                error: true,
                success: false,
                status: "0",
            })
        }
    } catch (error) {
        return res.send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0'
        })
    }
}


const InventroyOrderdetails = async (req, res) => {
    const schema = Joi.object().keys({
        sku: Joi.string().required(),
    })
    const dataToValidate = {
        sku: req.body.sku
    }
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(400).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {
        try {
            const productDetail = await SiteSellerProduct.findOne({
                where: { sku: req.body.sku },
                include: [
                    {
                        model: MainInvtRelInvtStrpdProduct,
                        include: [
                            {
                                model: InvtProduct,
                                include: [
                                    { model: ProductAttrValue, as: 'size' },
                                    { model: ProductAttrValue, as: 'color' },
                                    { model: Category },
                                    { model: MainInvtQty }
                                ]
                            }
                        ]
                    },
                    {
                        model: MainProduct,
                        include: [
                            { model: ProductType,},
                            { model: ProductMaterial },
                            {model:PurchasePrdctModel},

                            {
                                model:MainProductAttribute,
                                include: [
                                        {model: ProductAttrType},
                                        { model: ProductAttrValue }
                                ]
                            }
                        ],
                    },
                    {
                        model: SiteSellerPlatform,
                        
                    }
                ]
            });
            if (productDetail) {
                return res.status(200).json({
                    message: "Record Found",
                    error: false,
                    success: true,
                    status: '1',
                    data: productDetail,
                });
            } else {
                return res.status(204).json({
                    message: "Record Not Found",
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            return res.status(500).json({
                message: "Internal Server Error",
                error: error.message,
                success: false,
                status: '0'
            });
        }
    }
}




const GetorderList = async (req, res) => {
    try {
        const list = await OrderModel.findAll({ where: { status: '1' }, });
        if (list.length > 0) {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: list
            })
        } else {
            return res.status(204).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0',
            })
        }
    } catch (error) {
        return res.status(500).json({
            message: "Internal Server Error",
            error: error.message,
            success: false,
            status: '0'
        });
    }
}




const InventroyOrder = async (req, res) => {
    const schema = Joi.object().keys({
        sku: Joi.string().required(),
        qty: Joi.number().integer().positive().required(),
        price: Joi.number().positive().required(),
        order_id: Joi.string().optional(),
    });

    const dataToValidate = {
        sku: req.body.sku,
        qty: req.body.qty,
        price: req.body.price,
    };

    const result = schema.validate(dataToValidate);
    if (result.error) {
        return res.status(400).send({
            error: true,
            success: false,
            status: "0",
            message: result.error.details[0].message,
        });
    } else {
        try {
            const productDetail = await SiteSellerProduct.findOne({
                where: { sku: req.body.sku },
                include: [
                    {
                        model: MainInvtRelInvtStrpdProduct,
                        include: [
                            {
                                model: InvtProduct,
                                include: [
                                    { model: ProductAttrValue, as: 'size' },
                                    { model: ProductAttrValue, as: 'color' },
                                    { model: Category },
                                    { model: MainInvtQty }
                                ]
                            }
                        ]
                    },
                    {
                        model: MainProduct,
                        include: [
                            { model: ProductType },
                            { model: ProductMaterial }
                        ]
                    },
                    {
                        model: SiteSellerPlatform
                    }
                ]
            });
            if (productDetail) {
                const productId = productDetail?.dataValues?.product_id;
                const  MainInvtRelInvtStrpdProductavailableStock = await SiteSellerProduct.findOne({ where: { product_id: productId } });
                const  MainProductavailableStock = await MainProduct.findOne({
                    where:{id: productId}
                })

                // console.log(MainInvtRelInvtStrpdProductavailableStock?.quantity,'one')
                // console.log(MainProductavailableStock?.stock_quantity,'two')
                if ((req.body.qty > MainInvtRelInvtStrpdProductavailableStock?.quantity) || req.body.qty > MainProductavailableStock?.stock_quantity) {
                    return res.status(400).json({
                        message: "Requested quantity exceeds available stock",
                        error: true,
                        success: false,
                        status: '0'
                    });
                }
                const invtProductId = productDetail.MainInvtRelInvtStrpdProduct?.InvtProduct?.id || null;
                const strpdProductId = productDetail.product_id;
                const totalPrice = req.body.qty * req.body.price;

                const newOrder = await OrderModel.create({
                    invt_product_id: invtProductId,
                    strpd_product_id: strpdProductId,
                    order_id: `ORD-${Date.now()}`, // Generate a unique order ID
                    qty: req.body.qty,
                    price: req.body.price,
                    total_price: totalPrice,
                    order_date: new Date(),
                    status: 1,
                    created_at: new Date(),
                });

                // Update the quantities
                await SiteSellerProduct.update(
                    { quantity: productDetail?.quantity - req.body.qty },
                    { where: { product_id: productDetail?.product_id } }
                );
                await MainProduct.update(
                    { stock_quantity: MainProductavailableStock?.stock_quantity - req.body.qty },
                    { where: { id: productId } }
                );

                return res.status(200).json({
                    message: "Order Created Successfully",
                    error: false,
                    success: true,
                    status: '1',
                    data: newOrder
                });
            } else {
                return res.status(204).json({
                    message: "Product Not Found",
                    error: true,
                    success: false,
                    status: '0'
                });
            }
        } catch (error) {
            return res.status(500).json({
                message: "Internal Server Error",
                error: error.message,
                success: false,
                status: '0'
            });
        }
    }
};

const GetOrderReport = async (req, res) => {
    const user_id =  req.userId;
        try {
            const to_date = req.body.to_date || 0;
            const from_date = req.body.from_date || 0;
            if (from_date && to_date) {
                var condi = {
                    created_at: {
                        [Op.gte]: to_date,
                        [Op.lte]: from_date
                    }
                };
            }else{
            const startOfMonth = getCurrentDateTime();
            const endOfMonth = moment(startOfMonth).subtract(30, 'days');
            var condi = {
                created_at: {
                    [Op.gte]: endOfMonth,
                    [Op.lte]: startOfMonth
                }
            };
            }
            const orderDetail = await Order.findAll({
                where:condi,
                attributes:['id','transaction_id','total_amount','discount_amt','reward_amt','shipping_amt','tax_amt','paid_amount','payment_type',
                'payment_status','currency','discount_id','first_name','last_name','name','title','apartment','land_mark','address','mobile_number','country','state','city','zip_code','order_id','shipment_id','gst_number',
                [sequelize.literal('DATE_FORMAT(strpd_orders.created_at, "%Y-%m-%d")'), 'created_at'],
                [sequelize.literal('CASE WHEN payment_type = 1 THEN "online" WHEN payment_type = 2 THEN "cod" ELSE "" END'),'payment_type'],
                [sequelize.literal('(SELECT IF(COUNT(*) = 1, 1, 0) FROM strpd_orders AS o WHERE o.user_id = strpd_orders.user_id AND o.id <= strpd_orders.id)'), 'is_first_order']
            ],
                include:[
                    {
                        model:OrderItem,
                        as:'order_item',
                        attributes:['id','order_id','product_id','quantity','price',['awb_code','tracking_id'],'status'],
                        required: false,
                        include:
                        {
                            model:Product,
                            as:"products",
                            attributes:['id','product_name','product_slug','image_alt','compare_price'],
                            required: false,
                            include: [{
                                model: ProductMedia,
                                as: 'productimage',
                                attributes: ['file_name', 'file_name_200_x_200', 'file_name_180_x_180', 'file_name_150_x_150', 'file_name_120_x_120'],
                                required: false,
                            }]

                        }
                    }

                ],
                order: [
                    ['id', 'DESC'],
                ]
            });

        if (!orderDetail){
            res.status(202).send({
                message:process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message:process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                ORDERID: process.env.ORDERID,
                path: process.env.SITE_URL+'uploads/products/',
                data:orderDetail
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0',
        });
    }
}

const GetInvtLawQuantityReport = async (req, res) => {
    try {
        const list = await LawQtyNotificationReport.findAll({
            attributes:['id','invt_product_id','invt_total_qty',[sequelize.literal('DATE_FORMAT(strpd_notifications.created_at, "%Y-%m-%d")'), 'created_at'],],
             include: { 
                model: InvtProducts, 
                as:'invt_product',
                attributes:['product_name','product_image'],
                required: true 
            } 
        });
        if(list.length > 0) {
            return res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path: process.env.SITE_URL+'uploads/inventory_product/',
                data: list
            })
        } else {
            return res.status(204).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0',
            })
        }
    } catch (error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: error.message,
            success: false,
            status: '0'
        })
    }
}

module.exports = {
    BarCodeCheck,
    GetVendorList,
    GetStoreLocationList,
    ProdectListWithRelation,
    SellerPlatformList,
    ProductQuatintieList,
    addProductPurchase,
    GetproductQuantyList,
    InventroyOrder,
    InventroyOrderdetails,
    GetorderList,
    GetOrderReport,
    GetInvtLawQuantityReport
}