const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
const Product = require('../models/master/Product');
const ProductType = require('../models/master/ProductType');
const Category = require('../models/master/Category');

const ProductCollections = sequelize.define('product_collections', {
    id: {
        type: DataTypes.DOUBLE.UNSIGNED,  // Defines a DOUBLE UNSIGNED datatype
        autoIncrement: true,              // Enables auto-increment for the column
        primaryKey: true,
    },
    product_id: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    category_id: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    redirect_on: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: 1,
        comment: "1-single product,2 category product "
    },
    collection_type: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 1,
        comment: "1-discount_value, 2-pieces"
    },
    min_collection_value: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    max_collection_value: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    collection_image: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: 1,
        comment: "1-Active, 0-Inactive"
    },
    created_at: {
        type: DataTypes.DATE,  // Corrected to DataTypes.DATE
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    modified_at: {  // Corrected spelling (was "modefied_at")
        type: DataTypes.DATE,  // Corrected to DataTypes.DATE
        allowNull: true,
    },
    modified_by: {  // Corrected spelling (was "modefied_by")
        type: DataTypes.INTEGER,
        allowNull: true,
    } 
}, {
    timestamps: false,  // Disable Sequelize's automatic timestamps
    createdAt: 'created_at',  // Custom field for creation date
    updatedAt: 'modified_at',  // Custom field for modification date
});

// Define relationships
ProductCollections.belongsTo(Product, {
    foreignKey: 'product_id',
    as: 'product'
});

ProductCollections.belongsTo(Category, {
    foreignKey: 'category_id',
    as: 'category'  // Alias for the relationship
});

module.exports = ProductCollections;