const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const ProductModel = require('../../models/inventory/ProductInvtModel')
const BarcodeModel = sequelize.define('strpd_product_bar_codes', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      product_id: {
        type: Sequelize.INTEGER,
        allowNull: true,
      },
      bar_image: {
        type: Sequelize.STRING(255),
        allowNull: true,
      },
      bar_code_number: {
        type: Sequelize.STRING(255),
        allowNull: false,
      },
      status: {
        type: Sequelize.ENUM('0', '1'),
        defaultValue: '1',
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false,
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: true,
      },
});

BarcodeModel.belongsTo(ProductModel,
  {
    foreignKey:'product_id',
    targetKey:'id',
     as :'invt_product_model'
  });


module.exports = BarcodeModel;
