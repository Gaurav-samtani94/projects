const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your DataTypes instance
const PurchasePrdctModel = require('./PurchasePrdctModel')
const RelInvtStrpdProduct = require('./RelInvtStrpdProduct')
const ProductINVTModel = sequelize.define('main_invt_products', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true
      },
      product_name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      product_uniq_code: {
        type: Sequelize.STRING(255),
        allowNull: false,
        unique: true
      },
      product_description: {
        type: Sequelize.STRING,
        allowNull: false
      },
      product_image: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      size_id: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      color_id: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      brand_comp_name: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      product_categ_id: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      status: {
        type: Sequelize.SMALLINT,
        defaultValue: 1
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updated_by: {
        type: Sequelize.INTEGER,
        allowNull: false
      }
});

ProductINVTModel.hasMany(PurchasePrdctModel, {
  foreignKey: 'invt_product_id',
  sourceKey: 'id'
});

ProductINVTModel.hasMany(RelInvtStrpdProduct, {
  foreignKey: 'invt_product_id',
  sourceKey: 'id',
  as:'rel_product'
});
module.exports = ProductINVTModel;