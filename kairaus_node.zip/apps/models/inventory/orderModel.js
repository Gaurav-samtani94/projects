const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your DataTypes instance
const OrderModel = sequelize.define('main_invt_orders', {
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      invt_product_id: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      strpd_product_id: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      order_id: {
        type: Sequelize.STRING(255),
        allowNull: true,
        collate: 'latin1_swedish_ci'
      },
      qty: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      price: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0.00
      },
      total_price: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0.00
      },
      order_date: {
        type: Sequelize.DATE,
        allowNull: true
      },
      status: {
        type: Sequelize.TINYINT(3),
        allowNull: false,
        defaultValue: 1
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: true
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: true
      },
      updated_by: {
        type: Sequelize.INTEGER,
        allowNull: true
      }
});


module.exports = OrderModel;