const {  Sequelize } = require('sequelize');
const sequelize = require('../../config/database'); // Import your DataTypes instance
const PurchasePrdctModel = sequelize.define('main_invt_purchase_product', {
    id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      invt_product_id: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'invt_products',
          key: 'id'
        }
      },
      vendor_id: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      prod_quantity: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      rate_per_qty: {
        type: Sequelize.DOUBLE,
        allowNull: false
      },
      total_amount: {
        type: Sequelize.DOUBLE,
        allowNull: false
      },
      purchase_date: {
        type: Sequelize.DATE,
        allowNull: false
      },
      invoice_no: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      invoice_attachment: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      store_location_id: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      status: {
        type: Sequelize.SMALLINT,
        defaultValue: 1
      },
      created_at: {
        type: Sequelize.DATE,
        allowNull: false
      },
      created_by: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      updated_at: {
        type: Sequelize.DATE,
        allowNull: true
      },
      updated_by: {
        type: Sequelize.INTEGER,
        allowNull: true
      }
});

module.exports = PurchasePrdctModel;