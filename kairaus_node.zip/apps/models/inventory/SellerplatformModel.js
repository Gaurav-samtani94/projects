const {  DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your DataTypes instance
const SellerPlatformModel = sequelize.define('mstr_invt_site_seller_platforms', {
    id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER
      },
      seller_platform_name: {
        type: DataTypes.STRING(255),
        allowNull: true
      },
      status: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
      },
      created_at: {
        allowNull: true,
        type: DataTypes.DATE
      },
      created_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      },
      updated_at: {
        allowNull: true,
        type: DataTypes.DATE
      },
      updated_by: {
        allowNull: true,
        type: DataTypes.INTEGER
      }
});

module.exports = SellerPlatformModel;