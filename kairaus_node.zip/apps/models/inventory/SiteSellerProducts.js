const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance

// const GroupComboProducts = require("../../models/master/GroupComboProducts");
// const RelInvtStrpdProduct = require("../../models/master/RelInvtStrpdProduct");
const SellerPlatformModel = require("../../models/inventory/SellerplatformModel");
const SiteSellerProducts = sequelize.define('mstr_invt_site_seller_products', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    seller_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        defaultValue: '0'
    },
    sku: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    quantity: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    price: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

});


// SiteSellerProducts.hasOne(RelInvtStrpdProduct, { 
//     foreignKey: 'strpd_prod_id', 
//     sourceKey: 'product_id',
//     as: 'irsp' 
// });

SiteSellerProducts.belongsTo(SellerPlatformModel, {
    foreignKey: 'seller_id',
    as :'site_seller'
});

module.exports = SiteSellerProducts;