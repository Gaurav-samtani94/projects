const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance


const SiteSellerProduct = sequelize.define('SiteSellerProduct', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    sku: DataTypes.STRING,
    product_id: DataTypes.INTEGER,
    seller_id: DataTypes.INTEGER,
    quantity:DataTypes.INTEGER,
    // seller_platform_name: DataTypes.STRING
}, {
    tableName: 'mstr_invt_site_seller_products',
    timestamps: false
});


const PurchasePrdctModel = sequelize.define('purchaseProduct',{
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      invt_product_id: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      vendor_id: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      prod_quantity: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      rate_per_qty: {
        type: Sequelize.DOUBLE,
        allowNull: false
      },
      total_amount: {
        type: Sequelize.DOUBLE,
        allowNull: false
      },
      purchase_date: {
        type: Sequelize.DATE,
        allowNull: false
      },
      invoice_no: {
        type: Sequelize.STRING(255),
        allowNull: true,
        collate: 'latin1_swedish_ci'
      },
      invoice_attachment: {
        type: Sequelize.STRING(255),
        allowNull: true,
        collate: 'latin1_swedish_ci'
      },
      store_location_id: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
},
{
        tableName: 'main_invt_purchase_products',
        timestamps: false
}
)

const InvtProduct = sequelize.define('InvtProduct', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    product_name: DataTypes.STRING,
    product_uniq_code: DataTypes.STRING,
    brand_comp_name: DataTypes.STRING,
    size_id: DataTypes.INTEGER,
    color_id: DataTypes.INTEGER,
    product_categ_id: DataTypes.INTEGER,
    product_image:DataTypes.STRING,
}, {
    tableName: 'main_invt_products',
    timestamps: false
});

// Define other models similarly...

const MainInvtRelInvtStrpdProduct = sequelize.define('MainInvtRelInvtStrpdProduct', {
    strpd_prod_id: DataTypes.INTEGER,
    invt_product_id: DataTypes.INTEGER
}, {
    tableName: 'main_invt_rel_invt_strpd_products',
    timestamps: false
});

const ProductAttrValue = sequelize.define('ProductAttrValue', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    attr_val_name: DataTypes.STRING
}, {
    tableName: 'strpd_mstr_product_attr_values',
    timestamps: false
});

const Category = sequelize.define('Category', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    name: DataTypes.STRING
}, {
    tableName: 'strpd_mstr_categories',
    timestamps: false
});

const MainInvtQty = sequelize.define('MainInvtQty', {
    product_id: DataTypes.INTEGER,
    qty: DataTypes.INTEGER
}, {
    tableName: 'main_invt_qtys',
    timestamps: false
});

const MainProduct = sequelize.define('MainProduct', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    product_name: DataTypes.STRING,
    stock_quantity: DataTypes.INTEGER,
    type_id: DataTypes.INTEGER,
    material_id: DataTypes.INTEGER,
    product_id:DataTypes.TEXT,
}, {
    tableName: 'strpd_main_products',
    timestamps: false
});

const ProductType = sequelize.define('ProductType', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    type_name: DataTypes.STRING
}, {
    tableName: 'strpd_mstr_product_types',
    timestamps: false
});

const ProductMaterial = sequelize.define('ProductMaterial', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    material_name: DataTypes.STRING
}, {
    tableName: 'strpd_mstr_product_materials',
    timestamps: false
});

const SiteSellerPlatform = sequelize.define('SiteSellerPlatform', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    seller_platform_name: DataTypes.STRING
}, {
    tableName: 'mstr_invt_site_seller_platforms',
    timestamps: false
});





const MainProductAttribute = sequelize.define('MainProductAttribute', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    product_id: DataTypes.INTEGER,
    attr_type_id: DataTypes.INTEGER,
    attr_val_id: DataTypes.INTEGER,
    // Other fields...
}, {
    tableName: 'strpd_main_product_attributes',
    timestamps: false
});

const ProductAttrType = sequelize.define('ProductAttrType', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    attr_type_name: DataTypes.STRING
}, {
    tableName: 'strpd_mstr_product_attr_types',
    timestamps: false
});



// Define associations
SiteSellerProduct.belongsTo(MainInvtRelInvtStrpdProduct, { foreignKey: 'product_id', targetKey: 'strpd_prod_id' });
MainInvtRelInvtStrpdProduct.belongsTo(InvtProduct, { foreignKey: 'invt_product_id' });
InvtProduct.belongsTo(ProductAttrValue, { as: 'size', foreignKey: 'size_id' });
InvtProduct.belongsTo(ProductAttrValue, { as: 'color', foreignKey: 'color_id' });

InvtProduct.belongsTo(Category, { foreignKey: 'product_categ_id' });
InvtProduct.hasOne(MainInvtQty, { foreignKey: 'product_id' });
SiteSellerProduct.belongsTo(MainProduct, { foreignKey: 'product_id' });
MainProduct.belongsTo(ProductType, { foreignKey: 'type_id' });
MainProduct.belongsTo(ProductMaterial, { foreignKey: 'material_id' });
MainProduct.belongsTo(PurchasePrdctModel,{
    foreignKey:'id',
    targetKey:'invt_product_id'
})
SiteSellerProduct.belongsTo(SiteSellerPlatform, { foreignKey: 'seller_id' });


MainProduct.hasMany(MainProductAttribute,{foreignKey:'product_id'})
MainProductAttribute.belongsTo(ProductAttrType, { foreignKey: 'attr_type_id' });
MainProductAttribute.belongsTo(ProductAttrValue, { foreignKey: 'attr_val_id' });



module.exports = {
    SiteSellerProduct,
    InvtProduct,
    MainInvtRelInvtStrpdProduct,
    ProductAttrValue,
    Category,
    MainInvtQty,
    MainProduct,
    ProductType,
    ProductMaterial,
    SiteSellerPlatform,
    MainProductAttribute,
    ProductAttrType,
    PurchasePrdctModel
};
