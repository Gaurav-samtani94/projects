const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your DataTypes instance
const ProductModel = require('../../models/inventory/ProductInvtModel.js')

const ProductQuatintieModel = sequelize.define('main_invt_qtys', {
  id: {
    type: Sequelize.INTEGER,
    primaryKey: true,
    allowNull: false,
    autoIncrement: true
  },
  product_id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    references: {
      model: 'products',
      key: 'id'
    }
  },
  qty: {
    type: Sequelize.DOUBLE,
    allowNull: false
  },
  status: {
    type: Sequelize.SMALLINT,
    defaultValue: 1
  },
  entry_date: {
    type: Sequelize.DATE,
    allowNull: false
  },
  entry_by: {
    type: Sequelize.INTEGER,
    allowNull: true
  },
  debit_credit: {
    type: Sequelize.SMALLINT,
    allowNull: false
  }
});

ProductQuatintieModel.belongsTo(ProductModel, { foreignKey: 'product_id' });
module.exports = ProductQuatintieModel;