const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance

const InvtProduct = require("../../models/master/InvtProduct");
const LawQtyNotificationReport = sequelize.define('strpd_notifications', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    invt_product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    message: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    invt_total_qty: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    is_read: {
        type: DataTypes.TINYINT,
        defaultValue: 0
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
});

LawQtyNotificationReport.belongsTo(InvtProduct, {
    foreignKey: 'invt_product_id',
    as:'invt_product'
});

module.exports = LawQtyNotificationReport;