const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const OrderDiscountCoupon = require("../../models/master/OrderDiscountCoupon");
const Coupon = sequelize.define('strpd_main_coupons', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    coupon_code: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    sticker: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    from_date: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    to_date: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    number_of_uses: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    coupon_use: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    coupon_type: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    type_val: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    min_amount: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    upto_amount: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    coupon_desc: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    coupon_allow: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'
        ],
        defaultValue: '1'
    },
    multiple_use: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '0'
    },
    user_ids: {
        type: DataTypes.ARRAY(DataTypes.STRING),
        allowNull: false,
    },
    apply_to: {
        type: DataTypes.ENUM,
        values: [
            'ORDER', 'PRODUCTS', 'FIRST_ORDER'
        ],
        defaultValue: 'ORDER'
    },
    apply_value: {
        type: DataTypes.ARRAY(DataTypes.STRING),
        allowNull: false,
    },
    max_discount_allow: {
        type: DataTypes.TINYINT,
        defaultValue: '0'
    },
    max_discount_amt: {
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1', '2'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    is_deleted: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: '0'
    }
});


module.exports = Coupon;