const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Product = require("../../models/master/Product");
const UserProductView = sequelize.define('strpd_user_product_views', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type:DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    product_id: {
        type:DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

UserProductView.belongsTo(Product, {
    foreignKey: 'product_id',
    as :'products'
});

module.exports = UserProductView;
