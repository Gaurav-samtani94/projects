const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Product = require('../../models/master/Product');
const ProductAttributeType = require('../../models/master/ProductAttributeType');
const ProductAttributeValue = require('../../models/master/ProductAttributeValue');
const ProductAttributes = sequelize.define('strpd_main_product_attributes', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    product_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    attr_type_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    attr_val_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

ProductAttributes.belongsTo(ProductAttributeType, {
    foreignKey: 'attr_type_id',
    as:'product_attr_type'
});
ProductAttributes.belongsTo(ProductAttributeValue, {
    foreignKey: 'attr_val_id',
    as:'product_attr_value'
});

// ProductAttributes.belongsTo(Product, {
//     foreignKey: 'product_id',
//     as:'products'
// });
module.exports = ProductAttributes;