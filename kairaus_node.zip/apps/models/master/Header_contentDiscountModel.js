const { DataTypes, STRING } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const User = require("../User");
//const Product = require("../../models/master/Product");
const Header_contentDiscountModel = sequelize.define('strpd_header_discount_contents', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    content: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    action_url: {
        type: DataTypes.STRING(255),
        allowNull: true,
    },

    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
});


module.exports = Header_contentDiscountModel;



