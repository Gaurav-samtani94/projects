const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Category = require("./Category");
const TrendingKeyword = sequelize.define('strpd_trending_keywords', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    status: {
        type: DataTypes.INTEGER,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
  
});

TrendingKeyword.belongsTo(Category, {
    foreignKey: 'slug',
    targetKey: 'slug'
})

module.exports = TrendingKeyword;
