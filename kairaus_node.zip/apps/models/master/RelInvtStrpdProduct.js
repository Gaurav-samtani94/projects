const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const InvtQty = require("../../models/master/InvtQty");

const RelInvtStrpdProduct = sequelize.define('main_invt_rel_invt_strpd_products', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    invt_product_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    strpd_prod_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

});

RelInvtStrpdProduct.hasOne(InvtQty, { 
    foreignKey: 'product_id', 
    sourceKey: 'invt_product_id', 
    as: 'miq' 
});

module.exports = RelInvtStrpdProduct;