const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const User = require("../User");
const Product = require("../../models/master/Product");
const ProductVariant = require("../../models/master/ProductVariant");
const Cart = sequelize.define('strpd_product_carts', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    product_variant_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        defaultValue: '0'
    },
    quantity: {
        type: DataTypes.STRING,
        defaultValue: '1'
    },
    amount: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    discount_amt: {
        type: DataTypes.FLOAT,
        defaultValue: '0.00'
    },
    subtotal_amount: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    discount_id: {
        type: DataTypes.INTEGER,
        defaultValue: '0'
    },
    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    currency_symbol: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    currency_code: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    usd_amount: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    currency_rate: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
});


Cart.belongsTo(User, {
    foreignKey: 'user_id',
    as:'user'
});

Cart.belongsTo(Product, {
    foreignKey: 'product_id',
    as:'product'
});
Cart.belongsTo(ProductVariant, {
    foreignKey: 'product_variant_id',
    as:'product_variant'
});





module.exports = Cart;