const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const BankDetail = require('../../models/master/BankDetail');
const OrderReturnReasons = require('../../models/master/OrderReturnReasons');
const OrderReturn = sequelize.define('order_return_details', {
    id: {
        type: DataTypes.INTEGER(11),
        autoIncrement: true,
        primaryKey: true,
    },
    reason_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    order_item_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    order_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    reason_description: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    address_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    product_image_1: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    product_image_2: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    product_image_3: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    product_image_4: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    product_video: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: ['0', '1'],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

OrderReturn.hasMany(BankDetail, {
    foreignKey: 'order_return_id',
    as :'bank_details'
});

OrderReturn.belongsTo(OrderReturnReasons, {
    foreignKey: 'reason_id',
    as :'order_return_reason'
});
module.exports = OrderReturn;