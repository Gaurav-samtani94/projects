const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const CategoryImages = require("../../models/master/CategoryImages");
const AssignPageSlider = require("../../models/master/AssignPageSlider");
const Category = sequelize.define('strpd_mstr_categories', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    parent_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    slug: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    image: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

// Category.belongsTo(Category, {
//     foreignKey: 'parent_id',
// });


Category.hasMany(Category, {
    foreignKey:'parent_id',
    as:'child_items'
});

Category.belongsTo(Category, {
    foreignKey:'id',
    as:'parent_items'
});

Category.hasMany(CategoryImages, {
    foreignKey:'category_id',
    as:'images'
});

Category.hasOne(AssignPageSlider, {
    foreignKey:'category_menu_id',
    as:'assign_slider'
});

module.exports = Category;