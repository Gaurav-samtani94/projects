const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Product = require('../../models/master/Product');
const Size = require('../../models/master/Size');
const Color = require('../../models/master/Color');
const ProductVariant = sequelize.define('strpd_main_product_variants', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    product_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    size_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    color_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
});

ProductVariant.belongsTo(Size, {
    foreignKey: 'size_id',
    as:'product_size'
});
ProductVariant.belongsTo(Color, {
    foreignKey: 'color_id',
    as:'product_color'
});
module.exports = ProductVariant;