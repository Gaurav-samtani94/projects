const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const User = require("../User");
const Country = require('../../models/master/Country');
const State = require('../../models/master/State');
const City = require('../../models/master/City');
const UserAddress = sequelize.define('strpd_user_addresses', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    title: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    mobile_number: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    country_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    state_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    city_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    zip_code: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    billing_pincode: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    apartment: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    land_mark: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    address: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    is_default: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: '0'
    },
    is_gst: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: '0'
    },
    gst_number: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    company_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    company_address: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    is_shipping_address: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: '0'
    },
    is_billing_address: {
        type: DataTypes.TINYINT,
        allowNull: true,
        defaultValue: '0'
    },
    billing_name: {
        type: DataTypes.STRING,
        allowNull: true,    
    },
    billing_phone: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    billing_country_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    billing_state_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    billing_city_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    billing_address: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

UserAddress.belongsTo(User, {
    foreignKey: 'user_id',
    as:'user'
});

UserAddress.belongsTo(Country, {
    foreignKey: 'country_id',
    as :'country'
});

UserAddress.belongsTo(State, {
    foreignKey: 'state_id',
    as :'state'
});

UserAddress.belongsTo(City, {
    foreignKey: 'city_id',
    as :'city'
});

UserAddress.belongsTo(Country, {
    foreignKey: 'billing_country_id',
    as :'billing_country'
});

UserAddress.belongsTo(State, {
    foreignKey: 'billing_state_id',
    as :'billing_state'
});

UserAddress.belongsTo(City, {
    foreignKey: 'billing_city_id',
    as :'billing_city'
});

module.exports = UserAddress;