const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const HomepageSection = sequelize.define('homepage_sections', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    heading: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    sub_heading: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    icon: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    url_slug: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    section_type: {
        type: DataTypes.ENUM,
        values: [
            '1', '2',
        ]    
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '1', '0',
        ]   
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
});

module.exports = HomepageSection;