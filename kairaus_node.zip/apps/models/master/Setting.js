
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Setting = sequelize.define('strpd_settings', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    support_person: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    support_email: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    instagram_token: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    support_phone: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    manufacturing_warrently: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    product_buffer_days: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    max_shipping_amount: {
        type: DataTypes.DOUBLE,
        allowNull: false,
    },
    discount: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    shipping_amount: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    max_product_quantity: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});
module.exports = Setting;