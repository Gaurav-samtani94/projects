const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const User = require("../User");
const ProductReviewLike = require("../master/ProductReviewLike");
const ReviewImages = require("../master/ReviewImages");
const Review = sequelize.define('strpd_product_reviews', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    product_id:{
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    rating: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    review: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    image: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

Review.belongsTo(User, {
    foreignKey: 'user_id',
    as:'user'
});

Review.hasOne(ProductReviewLike, {
    foreignKey: 'product_review_id',
    as:'product_review'
});

Review.hasMany(ReviewImages, {
    foreignKey: 'product_review_id',
    as :'review_images'
});

module.exports = Review;