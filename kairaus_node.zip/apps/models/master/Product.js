const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Category = require('../../models/master/Category');
const ProductVariant = require('../../models/master/ProductVariant');
const ProductMedia = require('../../models/master/ProductMedia');
const ProductType = require('../../models/master/ProductType');
const ProductMaterial = require('../../models/master/ProductMaterial');
const Tag = require('../../models/master/Tag');
const Wishlist = require("../../models/master/Wishlist");
const Review = require("../../models/master/Review");
const ProductNotifyModel = require("../../models/master/ProductNotifyModel");
const SiteSellerProducts = require("../../models/master/SiteSellerProducts");
const Product = sequelize.define('strpd_main_products', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    product_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    product_slug: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    sku: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    title: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    additional_description: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    price: {
        type: DataTypes.DOUBLE,
        allowNull: false,
    },
    compare_price: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    usd_price: {
        type: DataTypes.DECIMAL,
        allowNull: false,
    },
    usd_compare_price: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    discount: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    stock_quantity: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    weight:{
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    category_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    has_variant:{
        type: DataTypes.TEXT('tiny'),
        allowNull: true,
    },
    product_tags:{
        type: DataTypes.ARRAY(DataTypes.STRING),
        allowNull: false,
    },
    type_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    material_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    pack_contain:{
        type: DataTypes.STRING,
        allowNull: true,
    },
    why_we_it:{
        type: DataTypes.TEXT,
        allowNull: true,
    },
    shipping_return:{
        type: DataTypes.TEXT,
        allowNull: true,
    },
    dimension:{
        type: DataTypes.TEXT,
        allowNull: true,
    },
    is_shipping:{
        type: DataTypes.TINYINT,
        allowNull: true,
    },
    shipping_amount_type:{
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    shipping_charge:{
        type: DataTypes.FLOAT,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    sold_out_count:{
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    product_buffer_days: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    description_class: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    additional_description_class: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    why_we_love_it_class: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    shipping_return_class: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    dimension_class: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    product_overview: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    product_overview_class: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    why_we_it_class: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    is_deleted:{
        type: DataTypes.TEXT('tiny'),
        defaultValue: '0'
    }
});
Product.belongsTo(Category, {
    foreignKey: 'category_id'
});
Product.hasMany(ProductVariant, {
    foreignKey: 'product_id',
    as:'product_variant'
});

Product.hasMany(ProductMedia, {
    foreignKey: 'product_id',
    as :'productimages'
});

ProductMedia.belongsTo(Product, {
    foreignKey: 'product_id',
    as :'productmedias'
});

Product.belongsTo(ProductType, {
    foreignKey: 'type_id',
    as :'producttypes'
});

Product.belongsTo(ProductMaterial, {
    foreignKey: 'material_id',
    as :'productmaterials'
});
Product.hasOne(ProductMedia, {
    foreignKey: 'product_id',
    as :'productimage',
    scope:{is_default:'1'}
});

Product.hasOne(ProductVariant, {
    foreignKey: 'product_id',
    as:'pr_variant'
});

Product.hasOne(Wishlist, {
    foreignKey: 'product_id',
    as:'wishlist'
});
Product.hasMany(Review, {
    foreignKey: 'product_id',
    as:'reviews'
});

Product.hasOne(ProductNotifyModel, {
    foreignKey: 'product_id',
    as:'product_notify'
});

Product.hasMany(SiteSellerProducts, {
    foreignKey: 'product_id',
    as:'site_seller_product'
});

Product.hasOne(SiteSellerProducts, {
    foreignKey: 'product_id',
    as:'seller_product'
});

Product.hasMany(SiteSellerProducts, {
    foreignKey: 'product_id',
    as:'seller_product_rel'
});


module.exports = Product;
