const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const User = require("../User");
//const Product = require("../../models/master/Product");
const Wishlist = sequelize.define('strpd_product_wishlists', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    wishlist_cate_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
});

Wishlist.belongsTo(User, {
    foreignKey: 'user_id',
    as:'user'
});

// Wishlist.belongsTo(Product, {
//     foreignKey: 'product_id',
//     as:'product'
// });

module.exports = Wishlist;



