const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Product = require('../../models/master/Product');
const Variant = require('../../models/master/Variant');

const ProductVariantGroup = sequelize.define('strpd_product_variant_groups', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    product_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    variant_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
});

ProductVariantGroup.belongsTo(Product, {
  foreignKey: 'product_id',
  as: 'product_data',
});

  ProductVariantGroup.belongsTo(Variant, {
    foreignKey: 'variant_id',
    as: 'variants',
  });



module.exports = ProductVariantGroup;