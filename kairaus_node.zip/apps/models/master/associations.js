const OrderDiscountCoupon = require('./OrderDiscountCoupon');
const Coupon = require('./Coupon');
const Cart = require("../../models/master/Cart");
const Order = require("../../models/master/Order");
const ProductAttributes = require("../../models/master/ProductAttributes");
const Product = require('../../models/master/Product');
const Blog = require('../../models/master/Blog');
const Category = require('../../models/master/Category');
// Define associations
Coupon.hasOne(OrderDiscountCoupon, {
    foreignKey: 'discount_id',
    as:'applied_coupon'
});


OrderDiscountCoupon.belongsTo(Coupon, {
     foreignKey: 'discount_id',
    as:'applied_coupon_code'
});


Coupon.hasOne(Cart, {
    foreignKey: 'discount_id',
    as:'product_coupon_applied'
});

Cart.belongsTo(Coupon, {
    foreignKey: 'discount_id',
    as:'product_coupon'
});

Coupon.hasOne(Order, {
    foreignKey: 'discount_id',
    as:'applied_coupon_user'
});
Coupon.hasOne(Order, {
    foreignKey: 'first_order_discount_id',
    as:'applied_coupon_user_first_order'
});

ProductAttributes.belongsTo(Product, {
    foreignKey: 'product_id',
    as:'products'
});

Product.hasMany(ProductAttributes, {
    foreignKey: 'product_id',
    as:'product_attribute'
});

Blog.belongsToMany(Category, {
    through: 'strpd_blogs_categories',
    as: 'categories',
    foreignKey: 'blog_id',
    otherKey: 'category_id',
});

Category.belongsToMany(Blog, {
    through: 'strpd_blogs_categories',
    as: 'Blogs',
    foreignKey: 'category_id',
    otherKey: 'blog_id',
});
