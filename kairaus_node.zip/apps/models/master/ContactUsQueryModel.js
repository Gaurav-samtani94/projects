const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance

const ContactUsQuery = sequelize.define('strpd_contact_us_queries', {
    id: {
        type: DataTypes.BIGINT(20),
        primaryKey: true,
        autoIncrement: true,
    },
    name: {
        type: DataTypes.STRING(255),
        allowNull: false,
        collate: 'latin1_swedish_ci',
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: false,
        defaultValue: '1',
        collate: 'latin1_swedish_ci',
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    created_by: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
    },
    modified_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
        defaultValue: 0,
    },
}, {
    tableName: 'strpd_contact_us_queries',
    timestamps: false, // Set to true if you want Sequelize to manage createdAt and updatedAt columns
});

module.exports = ContactUsQuery;
