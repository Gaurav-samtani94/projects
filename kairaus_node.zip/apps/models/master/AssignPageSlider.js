const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const PageSlider = require("../../models/master/PageSlider");
const AssignPageSlider = sequelize.define('strpd_assign_page_sliders', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    category_menu_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    page_slider_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    type: {
        type: DataTypes.INTEGER,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

AssignPageSlider.belongsTo(PageSlider, {
    foreignKey:'page_slider_id',
    as:'page_slider'
});

module.exports = AssignPageSlider;