const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const User = require("../User");
// const Product = require("../../models/master/Product");

const GroupComboProducts = sequelize.define('main_invt_group_combo_rel_strpd_products', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    strpd_product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    invt_group_combo_product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        defaultValue: '0'
    },
    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

});


module.exports = GroupComboProducts;