const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const HomeGiftVisits = require("../../models/master/HomeGiftVisits");
const HomeGiftGridLayout = sequelize.define('strpd_home_gift_grid_layouts',{
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    column_val: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    home_gift_grid_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    layout_type: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

HomeGiftGridLayout.belongsTo(HomeGiftVisits, {
    foreignKey: 'home_gift_grid_id',
    as:'home_gift_data'
});


module.exports = HomeGiftGridLayout;
