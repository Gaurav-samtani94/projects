const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const MembershipFeatures = require('./MembershipFeatures');
const MembershipMaster = sequelize.define('mstr_membership_rewards', {
    id: {
        type: DataTypes.INTEGER(11),
        autoIncrement: true,
        primaryKey: true,
    },
    membership_name: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: ['0', '1'],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

MembershipMaster.hasMany(MembershipFeatures, {
    foreignKey: 'id',
    // targetKey:'order_item_id',
    as :'membership_features'
});


module.exports = MembershipMaster;