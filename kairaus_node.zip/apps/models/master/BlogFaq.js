const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Blog_faq = sequelize.define('strpd_blog_faqs', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    blog_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    question: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    answer: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

module.exports = Blog_faq;