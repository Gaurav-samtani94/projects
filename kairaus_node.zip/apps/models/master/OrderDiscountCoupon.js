const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const OrderDiscountCoupon = sequelize.define('strpd_user_order_discounts', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    discount_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    discount_amt: {
        type: DataTypes.DECIMAL,
        allowNull: false,
    },

    applied_status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    discount_type: {
        type: DataTypes.ENUM,
        values: [
            'order', 'first_order', 'reward'
        ],
        defaultValue: 'order'
    },
    discount_mode: {
        type: DataTypes.ENUM,
        values: [
            'cart', 'buy_now'
        ],
        defaultValue: 'cart'
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

});

module.exports = OrderDiscountCoupon;