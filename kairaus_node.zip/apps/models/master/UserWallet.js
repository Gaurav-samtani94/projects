const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const User = require("../User");
const UserWallet = sequelize.define('strpd_user_wallets', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    amount_balance: {
        type: DataTypes.DOUBLE,
        allowNull: false,
    },
    last_update: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    wallet_amnt_exp_lastdate: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    }
});

UserWallet.belongsTo(User, {
    foreignKey: 'user_id',
});

module.exports = UserWallet;