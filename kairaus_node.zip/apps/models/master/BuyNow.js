const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const User = require("../User");
const Product = require("../../models/master/Product");

const BuyNow = sequelize.define('strpd_buy_now_products', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    quantity: {
        type: DataTypes.STRING,
        defaultValue: '1'
    },
    amount: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    discount_amt: {
        type: DataTypes.FLOAT,
        defaultValue: '0.00'
    },
    subtotal_amount: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    discount_id: {
        type: DataTypes.INTEGER,
        defaultValue: '0'
    },
    status: {
        type: DataTypes.TINYINT,
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    currency_symbol: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    currency_code: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    usd_amount: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    currency_rate: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
});


BuyNow.belongsTo(User, {
    foreignKey: 'user_id',
    as:'user'
});

BuyNow.belongsTo(Product, {
    foreignKey: 'product_id',
    as:'product'
});

module.exports = BuyNow;