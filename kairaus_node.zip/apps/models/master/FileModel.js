const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize 
const File = sequelize.define('strpd_sitemap_file_saves', {
    fld_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    file_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    type: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    
   
});



module.exports = File;
