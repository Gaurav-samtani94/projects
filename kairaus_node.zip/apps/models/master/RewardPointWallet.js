const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const User = require("../User");
const RewardPointWallet = sequelize.define('reward_point_wallets', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    total_points: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
     status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    modified_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

module.exports = RewardPointWallet;



