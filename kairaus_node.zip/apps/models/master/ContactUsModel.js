const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance

const RelationView = sequelize.define('strpd_contact_us', {
    id: {
        type: DataTypes.BIGINT(20),
        primaryKey: true,
        autoIncrement: true,
    },
    query_id: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
        collate: 'latin1_swedish_ci',
    },
    order_number: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
    },
    email_id: {
        type: DataTypes.STRING(255),
        allowNull: false,
        collate: 'latin1_swedish_ci',
    },
    query: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM('0', '1'),
        allowNull: true,
        defaultValue: '1',
        collate: 'latin1_swedish_ci',
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
    },
    created_by: {
        type: DataTypes.INTEGER(11),
        allowNull: false,
    },
    modified_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modified_by: {
        type: DataTypes.INTEGER(11),
        allowNull: true,
    },
}, {
    tableName: 'strpd_contact_us',
    timestamps: false, // Set to true if you want Sequelize to manage createdAt and updatedAt columns
});

module.exports = RelationView;
