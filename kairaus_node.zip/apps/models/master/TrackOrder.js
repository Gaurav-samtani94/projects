const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance

const TrackOrder = sequelize.define('courier_pkg_delivery_status', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    order_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    order_item_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    awb_number: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    location: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    time: {
        type: DataTypes.TIME,
        allowNull: true,
    },
    delivery_status: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    status: {
        type: DataTypes.INTEGER,
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.STRING,
        allowNull: true,
    },
}
, {
    tableName: 'courier_pkg_delivery_status', // Explicitly set the table name
    timestamps: false, // Optional: if your table does not have `createdAt` and `updatedAt`
});

// TrackOrder.belongsTo(Product, {
//     foreignKey: 'product_id',
//     as :'products'
// });

module.exports = TrackOrder;