const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const ProductAttributeType = require('../../models/master/ProductAttributeType');
const Variant = sequelize.define('strpd_variants', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    variant_title: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    no_of_product: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    attr_type_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

});

Variant.belongsTo(ProductAttributeType, {
    foreignKey: 'attr_type_id',
    as:'variant_attr_type'
});

module.exports = Variant;