const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Product = require('../../models/master/Product');
const ProductMedia = sequelize.define('strpd_main_product_medias', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    product_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    file_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_name_200_x_200: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_name_180_x_180: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_name_150_x_150: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_name_120_x_120: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_type: {
        type: DataTypes.ENUM,
        values: [
            'image', 'video'
        ],
        defaultValue: 'image'
    },
    is_default:{
        type: DataTypes.TINYINT(3),
        allowNull: true,
    }
});


 
    


module.exports = ProductMedia;