const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database');
const Product = require("../../models/master/Product");
const RelatedProduct = sequelize.define('strpd_related_products', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    related_product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    related_type: {
        type: DataTypes.ENUM,
        values: [
            'related', 'up_sell','cross_sell'
        ],
        defaultValue: 'related'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
});

RelatedProduct.belongsTo(Product, {
    foreignKey: 'related_product_id',
    as :'relatedproduct'
});



module.exports = RelatedProduct;
