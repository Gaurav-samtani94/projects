const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Country = require('../../models/master/Country');
const State = require('../../models/master/State');
const City = require('../../models/master/City');
const OrderItem = require('../../models/master/OrderItem');
const UserAddress = require('../../models/master/UserAddress');
const OrderReturn = require('../../models/master/OrderReturn');
const User = require("../User");
const Order = sequelize.define('strpd_orders', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    transaction_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    bank_ref_no: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    total_amount: {
        type: DataTypes.DOUBLE,
        allowNull: false,
    },
    discount_amt: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    first_order_discount_amt: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    reward_amt: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    shipping_amt: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    tax_amt: {
        type: DataTypes.DECIMAL,
        allowNull: true,
    },
    paid_amount: {
        type: DataTypes.DECIMAL,
        allowNull: false,
    },
    payment_type: {
        type: DataTypes.TINYINT,
        defaultValue: '1'
    },
    payment_status: {
        type: DataTypes.TINYINT,
        defaultValue: '0'
    },
    currency: {
        type: DataTypes.STRING,
        defaultValue: 'INR'
    },
    discount_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    first_order_discount_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    first_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    last_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    title: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    apartment: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    land_mark: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    address: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    mobile_number: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    country: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    state: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    city: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    zip_code: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    gst_number: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    address_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    company_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    company_address: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    billing_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    billing_phone: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    billing_country: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    billing_state: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    billing_city: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    billing_address: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    billing_pincode: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    cancel_status: {
        type: DataTypes.TINYINT,
        defaultValue: '0'
    },
    cancel_reason: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    order_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    shipment_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
 
});

Order.belongsTo(UserAddress, {
    foreignKey: 'address_id',
    as:'user_address'
});

Order.belongsTo(User, {
    foreignKey: 'user_id',
    as:'user'
});

Order.hasMany(OrderItem, {
    foreignKey: 'order_id',
    as :'order_item'
});

Order.hasOne(OrderItem, {
    foreignKey: 'order_id',
    as :'order_item_return'
});


Order.hasOne(OrderReturn, {
    foreignKey: 'order_id',
    as :'order_return'
});

module.exports = Order;