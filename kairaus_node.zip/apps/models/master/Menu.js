
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const MenuCategory = require("../../models/master/MenuCategory");
const MenuImages = require("../../models/master/MenuImages");
const AssignPageSlider = require("../../models/master/AssignPageSlider");
const Menu = sequelize.define('strpd_mstr_menus', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },  
    menu_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    image: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    header_image: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    icon_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    parent: {
        type: DataTypes.TINYINT,
        allowNull: false,
    },
    menu_order: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    menu_type: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'
        ],
        defaultValue: '1'
    },
    action_url: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    is_in_childmenu: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    menu_category: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

// Menu.hasMany(Menu, {
//     foreignKey:'parent',
//     as:'child_items'
// });

// Menu.belongsTo(Menu, {
//     foreignKey:'id',
//     as:'parent_items'
// });

Menu.hasMany(MenuCategory, {
    foreignKey:'menu_id',
    as:'child_items'
});

Menu.hasMany(MenuImages, {
    foreignKey:'menu_id',
    as:'images'
});

Menu.hasOne(AssignPageSlider, {
    foreignKey:'category_menu_id',
    as:'assign_slider'
});

// Menu.belongsTo(Menu, {
//     foreignKey:'parent',
//     as:'parent_info'
// });

module.exports = Menu;