const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const HomeCollectionMaster = sequelize.define('mstr_home_collections',{
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    collection_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    slug: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    collection_image: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    banner_image: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    modefied_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    modefied_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});



module.exports = HomeCollectionMaster;
