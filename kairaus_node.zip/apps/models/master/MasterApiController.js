const jwt = require('jsonwebtoken');
const City = require("../../models/master/City");
const Country = require("../../models/master/Country");
const Currency = require("../../models/master/Currency");
const Gender = require("../../models/master/Gender");
const Prefix = require("../../models/master/Prefix");
const State = require("../../models/master/State");
const Timezones = require("../../models/master/Timezones");
const Color = require("../../models/master/Color");
const Size = require("../../models/master/Size");
const Menu = require("../../models/master/Menu");
const PageMstr = require("../../models/master/PageMstr");
const Role = require("../../models/master/Role");
const StaticPage = require("../../models/master/StaticPage");
const Category = require("../../models/master/Category");
const SubCategory = require("../../models/master/SubCategory");
const Wishlist = require("../../models/master/Wishlist");
const Cart = require("../../models/master/Cart");
const UserAddress = require("../../models/master/UserAddress");
const WishlistCategory = require("../../models/master/WishlistCategory");
const UserWallet = require("../../models/master/UserWallet");
const Product = require("../../models/master/Product");
const User = require("../../models/User");
const Query =  require("../../models/master/Query");
const Coupon = require("../../models/master/Coupon");
const UserCoupon = require("../../models/master/UserCoupon");
const WalletMain = require("../../models/master/WalletMain");
const Seo = require("../../models/master/Seo");
const ProductVariant = require("../../models/master/ProductVariant");
const ProductMedia = require("../../models/master/ProductMedia");
const HomeSlider = require("../../models/master/HomeSlider");
const Tag = require("../../models/master/Tag");
const NewsLetter =  require("../../models/master/NewsLetter");
const { sendDynamicEmail, sendEmailWith_temp } = require('../../config/mail');

const multer = require('multer');
const fs = require('fs');
const moment = require('moment')
const slugify = require('slugify')
require('dotenv').config();
// const currentDate = new Date();
const current_date = Date.now();
const Joi = require('joi');
const path = require('path');

//get gender list start
const GetGenderList = async (req, res) => {
    try {
        const genders = await Gender.findAll({where:{status:'1'}});
        if (genders == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: genders
            });
        }
    }catch(error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get gender list end

//get color list start
const GetColorList = async (req, res) => {
            try {
                const colors = await Color.findAll({where:{status:'1'}});
                if (colors == 0) {
                    res.status(404).send({
                        message: process.env.RECORD_NOT_FOUND,
                        error: true,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.SUCCESS_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: colors
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
}
//get color list end

//get currency list start
const GetCurrencyList = async (req, res) => {
            try {
                const currencies = await Currency.findAll({where:{status:'1'}});
                if (currencies == 0) {
                    res.status(404).send({
                        message: process.env.RECORD_NOT_FOUND,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.SUCCESS_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: currencies
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
}
//get currency list end

//get size list start
const GetSizeList = async (req, res) => {
    try {
        const sizes = await Size.findAll({where:{status:'1'}});
        if (sizes == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: sizes
            });
        }
    } catch(error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get size list end

//get menu list start
const GetMenuList = async (req, res) => {
    try {
        const menus = await Menu.findAll({
            where:{
                status:'1',
                parent:'0'
            },
            include:[{
                model:Menu,
                as:"child_items",
                attributes:['id',['menu_name', 'child_name'],['parent','parent_id']],
                where: {status:'1'},
                required: false,
                include:
                    {
                        model:Menu,
                        as:"child_items",
                        attributes:['id',['menu_name', 'child_name'],['parent','parent_id']],
                        where: {status:'1'},
                        required: false
                    }
            }]
        });
        if (menus == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: menus
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get menu list end

//get page list start
const GetPageList = async (req, res) => {
    try {
        const pages = await PageMstr.findAll({where:{status:'1'}});
        if (pages == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: pages
            });
        }
    } catch(error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get page list end

//get prefix list start
const GetPrefixList = async (req, res) => {
    try {
        const prefixes = await Prefix.findAll({where:{status:'1'}});
        if (prefixes == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: prefixes
            });
        }
    } catch(error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

//get prefix list end

//get timezone list start
const GetTimezoneList = async (req, res) => {
    try {
        const timezones = await Timezones.findAll({where:{status:'1'}});
        if (timezones == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: timezones
            });
        }
    } catch(error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get timezone list end

//get role list start
const GetRoleList = async (req, res) => {
    try {
        const roles = await Role.findAll({where:{status:'1'}});
        if (roles == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: roles
            });
        }
    } catch(error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get role list end

//get state list by country start
const GetStateListByCountry = async (req, res) => {
    const country_id = req.body.country_id;
    const schema = Joi.object().keys({
        country_id: Joi.string().required().label("Country")
    });
    const dataToValidate = {
        country_id: country_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const states = await State.findAll({
                    where: {
                        country_id: country_id,
                        status: '1'
                    },
                    include: [{
                        model: Country,
                        attributes: ['id','country_name'],
                        where: {status:'1'},
                        required: false
                    }]
                });
                if (states == 0) {
                    res.status(404).send({
                        message: process.env.RECORD_NOT_FOUND,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.SUCCESS_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: states
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message: process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//get state list by country end

//get city list by state start
const GetCityListByState = async (req, res) => {
    const state_id = req.body.state_id;
    const schema = Joi.object().keys({
        state_id: Joi.string().required().label("State")
    });
    const dataToValidate = {
        state_id: state_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const cities = await City.findAll({
                    where: {
                        state_id: state_id,
                        status: '1'
                    }
                });
                if (cities == 0) {
                    res.status(404).send({
                        message: process.env.RECORD_NOT_FOUND,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.SUCCESS_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: cities
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//get city list by state end

//get country list start
const GetCountryList = async (req, res) => {
    try {
        const countries = await Country.findAll({where:{status:'1'}});
        if (countries == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: countries
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get country list end

//get category list start
const GetCategoryList = async (req, res) => {
    try {
        const categories = await Category.findAll({
            where:{
                status:'1'
            },
            include:{
                model:Category,
                attributes:['id','name'],
                where: {status:'1'},
                required: false
            }
        });
        if (categories == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: categories
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get category list end

//get subcategory list start
// const GetSubCategoryList = async (req, res) => {
//     try {
//         const subcategories = await SubCategory.findAll({
//             where:
//             {
//                 status:'1'
//             },
//             include:{
//                 'model' : Category,
//                 attributes:['id','name','description']
//             }
//         });
//         if (subcategories == 0) {
//             res.status(404).send({
//                 message: process.env.RECORD_NOT_FOUND,
//                 error: true,
//                 success: false,
//                 status: '0'
//             });
//         }else{
//             res.status(200).send({
//                 message: process.env.SUCCESS_MSG,
//                 error: false,
//                 success: true,
//                 status: '1',
//                 data: subcategories
//             });
//         }
//     } catch(error) {
//         res.status(500).send({
//             message: error,
//             error: true,
//             success: false,
//             status: '0',
//         });
//     }
// }
//get subcategory list end

//wishlist starts
//get wishlist start
const GetWishlist = async (req, res) => {
    try {
        const wishlists = await Wishlist.findAll({
            where: {
              user_id: req.userId, 
              status:'1'
            },
            include: [
                {
                    model: Product,
                    attributes: ['id','product_name'],
                    where: {status:'1'},
                    required: false
                },
                {
                    model: User,
                    attributes: ['id','firstname'],
                    required: false
                },
                {
                    model: WishlistCategory,
                    attributes: ['id','category_name'],
                    where: {status:'1'},
                    required: false
                }
            ]
        });
        if (wishlists == 0){
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: wishlists
            });
        }
    }catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get wishlist end

//add wishlist start
const AddWishlist = async (req, res) => {
    const user_id =  req.userId;
    const product_id = req.body.product_id;
    const wishlist_cate_id = req.body.wishlist_cate_id;
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product"),
        wishlist_cate_id: Joi.number().integer().required().label("Wishlist category")
    });
    const dataToValidate = {
        product_id:product_id,
        wishlist_cate_id:wishlist_cate_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const checkProductExists = await Wishlist.findOne({where:{product_id:product_id,user_id:user_id,status:'1'}});
                if (checkProductExists) {
                    res.status(409).send({
                        message: process.env.ALREADY_EXIST_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    const wishlists = await Wishlist.create({ 
                        user_id: user_id,
                        product_id: product_id,
                        wishlist_cate_id: wishlist_cate_id,
                        created_at:current_date,
                        created_by:user_id
                    });
                    if (!wishlists){
                        res.status(404).send({
                            message: process.env.NOT_INSERTED_MSG,
                            error: true,
                            success: false,
                            status: '0'
                        });
                    }else{
                        res.status(200).send({
                            message: process.env.INSERTED_MSG,
                            error: false,
                            success: true,
                            status: '1',
                            data: wishlists
                        });
                    }
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//add wishlist end

//edit wishlist start
const EditWishlist = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const product_id = req.body.product_id;
    const wishlist_cate_id = req.body.wishlist_cate_id;
    const schema = Joi.object().keys({
        id: Joi.string().required(),
        product_id: Joi.number().integer().required().label("Product"),
        wishlist_cate_id: Joi.number().integer().required().label("Wishlist category")
    });
    const dataToValidate = {
        id:id,
        product_id:product_id,
        wishlist_cate_id:wishlist_cate_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    }else{
            try {
                const wishlists = await Wishlist.update({
                        user_id: user_id,
                        product_id: product_id,
                        wishlist_cate_id: wishlist_cate_id,
                        updated_at:current_date,
                        updated_by:user_id
                    }, {
                    where: {
                      id:id
                    }
                });
                if (!wishlists){
                    res.status(404).send({
                        message: process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//edit wishlist end

//delete wishlist start
  const DeleteWishlist = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id:  Joi.number().integer().required(),
    });
    const dataToValidate = {
        id:id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const wishlists = await Wishlist.update({
                    status: '0',
                    updated_at:current_date,
                    updated_by:user_id
                }, {
                where: {
                  id:id
                }
                });
                if (!wishlists){
                    res.status(404).send({
                        message: process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//delete wishlist end
//wishlist ends 

//cart starts
//get cart start
const GetCart = async (req, res) => {
    try {
        const user_id = req.userId;
        const carts = await Cart.findAll({
            where: {
              user_id: user_id,
              status:'1'
            },
            include: [
                {
                    model: Product,
                    attributes: ['id','product_name'],
                    where: {status:'1'},
                    required: false
                },
                {
                    model: User,
                    attributes: ['id','firstname']
                },
            
            ]
        });
        if (carts == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: carts
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get cart end

//add cart start
const AddCart = async (req, res) => {
    const user_id =  req.userId;
    const product_id = req.body.product_id;
    const quantity = req.body.quantity;
    const schema = Joi.object().keys({
        product_id: Joi.number().integer().required().label("Product"),
        quantity: Joi.number().integer().required().label("Quantity")
    });
    const dataToValidate = {
        product_id:product_id,
        quantity:quantity
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                const checkProductExists = await Cart.findOne({where:{product_id:product_id,user_id:user_id,status:'1'}});
                if (checkProductExists) {
                    res.status(409).send({
                        message: process.env.ALREADY_EXIST_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                        const carts =  await Cart.create({ 
                            user_id: user_id,
                            product_id: product_id,
                            quantity: quantity,
                            created_at:current_date,
                            created_by:user_id
                        });
                        if (!carts){
                            res.status(404).send({
                                message: process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message: process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: carts
                            });
                        }
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//add cart end

//edit cart start
const EditCart = async (req, res) => {
    const id = req.body.id;
    const user_id =  req.userId;
    const product_id = req.body.product_id;
    const quantity = req.body.quantity;
    const schema = Joi.object().keys({
        id: Joi.string().required(),
        product_id:  Joi.number().integer().required().label("Product"),
        quantity:  Joi.number().integer().required().label("Quantity"),
    });
    const dataToValidate = {
        id:id,
        product_id:product_id,
        quantity:quantity
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const carts = await Cart.update({
                        user_id: user_id,
                        product_id: product_id,
                        quantity: quantity,
                        updated_at:current_date,
                        updated_by:user_id
                    }, {
                    where: {
                      id:id
                    }
                });
                if (!carts){
                    res.status(404).send({
                        message: process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//edit cart end

//delete cart start
const DeleteCart = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id:  Joi.number().integer().required()
    });
    const dataToValidate = {
        id:id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const carts = await Cart.update({
                    status: '0',
                    updated_at:user_id,
                    updated_by:current_date
                }, {
                where: {
                  id:id
                }
                });
                if (!carts){
                    res.status(404).send({
                        message: process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//delete cart end
//cart ends

//user address starts
//get user address start
const GetUserAddress = async (req, res) => {
    try {
        const user_id = req.userId;
        const userAddresses = await UserAddress.findAll({
            where: {
              user_id: user_id,
              status:'1'
            },
            include:{
                model:User,
                attributes:['id','firstname']
            }
        });
        if (userAddresses == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: userAddresses
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get user address end

//add user address start
const AddUserAddress = async (req, res) => {
    const user_id =  req.userId;
    const address = req.body.address;
    const schema = Joi.object().keys({
        address: Joi.string().required().label("Address")
    });
    const dataToValidate = {
        address:address
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                const checkAddressExists = await UserAddress.findOne({where:{user_id:user_id,status:'1'}});
                if (checkAddressExists) {
                    res.status(409).send({
                        message: process.env.ALREADY_EXIST_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                        const carts =  await UserAddress.create({ 
                            user_id: user_id,
                            address: address,
                            created_at:current_date,
                            created_by:user_id
                        });
                        if (!carts){
                            res.status(404).send({
                                message: process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message:  process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: carts
                            });
                        }
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//add user address end

//edit user address start
const EditUserAddress = async (req, res) => {
    const id = req.body.id;
    const user_id =  req.userId;
    const address = req.body.address;
    const schema = Joi.object().keys({
        id: Joi.string().required(),
        address: Joi.string().required().label("Address")
    });
    const dataToValidate = {
        id:id,
        address:address
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const carts = await UserAddress.update({
                        user_id: user_id,
                        address: address,
                        updated_at:current_date,
                        updated_by:user_id
                    }, {
                    where: {
                      id:id
                    }
                });
                if (!carts){
                    res.status(404).send({
                        message: process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//edit user address end

//delete user address start
const DeleteUserAddress = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id: Joi.string().required()
    });
    const dataToValidate = {
        id:id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const carts = await UserAddress.update({
                    status: '0',
                    updated_at:current_date,
                    updated_by:user_id
                }, {
                where: {
                  id:id
                }
                });
                if (!carts){
                    res.status(404).send({
                        message: process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//delete user address end
//user address ends

//wishlist category starts
//get wishlist category start
const GetWishlistCategory = async (req, res) => {
    try {
        const user_id = req.userId;
        const wishlistCategories = await WishlistCategory.findAll({
            where: {
              user_id:user_id,
              status:'1'
            },
            include:{
                model: User,
                attributes:['id','firstname']
            }
        });
        if (wishlistCategories == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: wishlistCategories
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get wishlist category end

//add wishlist category start
const AddWishlistCategory = async (req, res) => {
    const user_id = req.userId;
    const category_name = req.body.category_name;
    const schema = Joi.object().keys({
        category_name: Joi.string().required().label("Category name")
    });
    const dataToValidate = {
        category_name:category_name
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                const checkCategoryExists = await WishlistCategory.findAll({where:{user_id:user_id,status:'1'}});
                if (checkCategoryExists != 0) {
                    res.status(409).send({
                        message:process.env.ALREADY_EXIST_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                        const category =  await WishlistCategory.create({ 
                            user_id: user_id,
                            category_name: category_name,
                            created_at:current_date,
                            created_by:user_id
                        });
                        if (!category){
                            res.status(404).send({
                                message: process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message: process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: category
                            });
                        }
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//add wishlist category end

//edit wishlist category start
const EditWishlistCategory = async (req, res) => {
    const id = req.body.id;
    const user_id = req.userId;
    const category_name = req.body.category_name;
    const schema = Joi.object().keys({
        id: Joi.string().required(),
        category_name: Joi.string().required().label("Category name")
    });
    const dataToValidate = {
        id:id,
        category_name:category_name
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const category = await WishlistCategory.update({
                        user_id: user_id,
                        category_name: category_name,
                        updated_at:current_date,
                        updated_by:user_id
                    }, {
                    where: {
                      id:id
                    }
                });
                if (!category){
                    res.status(404).send({
                        message: process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:  process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//edit wishlist category end

//delete wishlist category start
const DeleteWishlistCategory = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id:Joi.number().integer().required()
    });
    const dataToValidate = {
        id:id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const category = await WishlistCategory.update({
                    status: '0',
                    updated_at:current_date,
                    updated_by:user_id
                }, {
                where: {
                  id:id
                }
                });
                if (!category){
                    res.status(404).send({
                        message:process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message: process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//delete wishlist category end
//wishlist category ends

//user wallet starts
//get user wallet start
const GetUserWallet = async (req, res) => {
    try {
        const user_id = req.userId;
        const wallet = await UserWallet.findOne({
            where: {
              user_id: user_id,
              status: '1'
            },
            include:{
                model: User,
                attributes:['id','firstname']
            }
        });
        if (!wallet) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: wallet
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get user wallet end

//add user wallet start
const AddUserWallet = async (req, res) => {
    const user_id = req.userId;
    const amount_balance = req.body.amount_balance;
    const wallet_amnt_exp_lastdate = req.body.wallet_amnt_exp_lastdate;
    const schema = Joi.object().keys({
        amount_balance: Joi.number().required().label("Amount balance"),
        wallet_amnt_exp_lastdate: Joi.date().required().greater('now').iso().label("Wallet amount expiration last date")
    });
    const dataToValidate = {
        amount_balance:amount_balance,
        wallet_amnt_exp_lastdate: wallet_amnt_exp_lastdate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                const checkWalletExists = await UserWallet.findOne({where:{user_id:user_id,status:'1'}});
                if (checkWalletExists) {
                    res.status(409).send({
                        message:process.env.ALREADY_EXIST_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                        const wallet = await UserWallet.create({ 
                            user_id: user_id,
                            amount_balance: amount_balance,
                            wallet_amnt_exp_lastdate:wallet_amnt_exp_lastdate,
                            last_update:current_date,
                            created_by: user_id
                        });
                        if (!wallet){
                            res.status(404).send({
                                message:process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message:process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: wallet
                            });
                        }  
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//add user wallet end

//edit user wallet start
const EditUserWallet = async (req, res) => {
    const user_id = req.userId;
    const amount_balance = req.body.amount_balance;
    const wallet_amnt_exp_lastdate = req.body.wallet_amnt_exp_lastdate;
    const schema = Joi.object().keys({
        amount_balance:Joi.number().required().label("Amount balance"),
        wallet_amnt_exp_lastdate: Joi.date().required().greater('now').iso().label("Wallet amount expiration last date")
    });
    const dataToValidate = {
        amount_balance:amount_balance,
        wallet_amnt_exp_lastdate:wallet_amnt_exp_lastdate
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const wallet = await UserWallet.update({
                        amount_balance: amount_balance,
                        wallet_amnt_exp_lastdate:wallet_amnt_exp_lastdate,
                        last_update:current_date,
                        updated_by:user_id
                    }, {
                    where: {
                      user_id:user_id,
                      status: '1'
                    }
                });
                if (!wallet){
                    res.status(404).send({
                        message:process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//edit user wallet end

//delete user wallet start
const DeleteUserWallet = async (req, res) => {
    const user_id = req.userId;
            try {
                const wallet = await UserWallet.update({
                    status: '0'
                }, {
                where: {
                  user_id:user_id
                }
                });
                if (!wallet){
                    res.status(404).send({
                        message:process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
}
//delete user wallet end
//user wallet ends

//static page starts
//get static page list start
const GetStaticPage = async (req, res) => {
    try {
        const staticPages = await StaticPage.findAll({
            where:{
                status:'1'
            },
            include:{
                model:PageMstr,
                attributes:['id','page_name'],
                where: {status:'1'},
                required: false
            }
        });
        if (staticPages == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: staticPages
            });
        }
    } catch(error) {
        res.status(500).send({
            message: process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get static page list end

//add static page start
const AddStaticPage = async (req, res) => {
    const token = req.header('authorization');
    jwt.verify(token,'storepedia277833',(err, decoded) => {
        req.userId = decoded.id;
    });
    const user_id = req.userId;
    const page_id = req.userId;
    const title = req.body.title;
    const heading = req.body.heading;
    const description = req.body.description;
    const schema = Joi.object().keys({
        page_id: Joi.number().integer().required().label("Page"),
        title: Joi.string().required().label("Title"),
        heading:Joi.string().required().label("Heading"),
        description:Joi.string().required().label("Description")
    });
    const dataToValidate = {
        page_id:page_id,
        title: title,
        heading:heading,
        description:description
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                const checkPageExists = await StaticPage.findOne({where:{page_id:page_id,title:title,status:'1'}});
                if (checkPageExists) {
                    res.status(409).send({
                        message: 'Page already exists',
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                        const page = await StaticPage.create({ 
                            page_id: page_id,
                            title: title,
                            heading:heading,
                            description:description,
                            created_at:current_date,
                            created_by: user_id
                        });
                        if (!page){
                            res.status(404).send({
                                message:process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message:process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: page
                            });
                        }  
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//add static page end

//edit static page start
const EditStaticPage = async (req, res) => {
    const token = req.header('authorization');
    jwt.verify(token,'storepedia277833',(err, decoded) => {
        req.userId = decoded.id;
    });
    const id = req.body.id;
    const user_id = req.userId;
    const page_id = req.body.page_id;
    const title = req.body.title;
    const heading = req.body.heading;
    const description = req.body.description;
    const schema = Joi.object().keys({
        id:Joi.required(),
        page_id: Joi.number().integer().required().label("Page"),
        title: Joi.string().required().label("Title"),
        heading: Joi.string().required().label("Heading"),
        description: Joi.string().required().label("Description")
    });
    const dataToValidate = {
        id:id,
        page_id:page_id,
        title:title,
        heading: heading,
        description: description
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const page = await StaticPage.update({
                        page_id: page_id,
                        title:title,
                        heading:heading,
                        description:description,
                        updated_at:current_date,
                        updated_by:user_id
                    },{
                    where: {
                      id:id,
                      status: '1'
                    }
                });
                if (!page){
                    res.status(404).send({
                        message:process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//edit static page end

//delete static page start
const DeleteStaticPage = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id:Joi.number().integer().required(),
    });
    const dataToValidate = {
        id:id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const page = await StaticPage.update({
                    status: '0',
                    updated_at:current_date,
                    updated_by:user_id
                }, {
                where: {
                  id:id
                }
                });
                if (!page){
                    res.status(404).send({
                        message:process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//delete static page ends
//static page starts

//product starts
//get product start
const GetProduct = async (req, res) => {
    try {
        const product = await Product.findAll({
            where:{
                status:'1'
            },
            include:[
                {
                    model:Category,
                    attributes:['id','name'],
                    where: {status:'1'},
                    required: false
                },
                {
                    model:ProductVariant,
                    attributes:['size_id','color_id'],
                    required: false,
                    include:[
                        {
                            model:Size,   
                            attributes: ['size'],
                            where: { status: '1'},
                            required: false
                        },
                        {
                            model:Color,   
                            attributes: ['color'],
                            where: { status: '1'},
                            required: false
                        }
                    ],
                }
        ]
        });
        if (product == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: product
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get product end

//storage start
const product_file_storage = multer.diskStorage({
    destination: async (req, file, cb) => {
        const uploadPath = process.env.PRODUCT_IMAGE;
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const extension = path.extname(file.originalname);
        cb(null, Date.now() + extension);
    },
});
//storage end

//add product start
const upload = multer({ storage: product_file_storage });
const AddProduct = async (req, res) => {
    upload.single('file')(req, res, async function (error) {
    const user_id = req.userId;
    const product_name = req.body.product_name;
    const title = req.body.title;
    const description = req.body.description;
    const product_slug =  slugify(title,'-');
    const price = req.body.price;
    const stock_quantity = req.body.stock_quantity;
    const category_id = req.body.category_id;
    const has_variant = req.body.has_variant;
    const weight = req.body.weight;
    const product_tags = req.body.product_tags;
    const size_id = req.body.size_id;
    const color_id = req.body.color_id;
    const file_type = req.body.file_type;
    const schema = Joi.object().keys({
        product_name: Joi.string().required().label("Product name"),
        title: Joi.string().required().label("Title"),
        description:Joi.string().required().label("Description"),
        price:Joi.string().required().label("Price"),
        stock_quantity:Joi.string().required().label("Stock quantity"),
        category_id:Joi.number().integer().required().label("Category"),
        has_variant:Joi.number().integer().required().label("Variant"),
        weight: Joi.number().required().label("Weight"),
        product_tags:Joi.array().items(Joi.number().integer()).label("Product Tags"),
        size_id:Joi.number().integer().required().label("Size"),
        color_id:Joi.number().integer().required().label("Color")
    });
    const dataToValidate = {
        product_name: product_name,
        title: title,
        description:description,
        price:price,
        stock_quantity:stock_quantity,
        category_id:category_id,
        has_variant:has_variant,
        weight:weight,
        product_tags:product_tags,
        size_id:size_id,
        color_id:color_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                const checkProductExists = await Product.findOne({where:{product_name:product_name,status:'1'}});
                if (checkProductExists) {
                    res.status(409).send({
                        message:'Product already exists',
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                        const product = await Product.create({ 
                            product_name: product_name,
                            product_slug:product_slug,
                            title: title,
                            description:description,
                            price:price,
                            stock_quantity:stock_quantity,
                            weight:weight,
                            product_tags:product_tags,
                            category_id:category_id,
                            created_at:current_date,
                            created_by: user_id
                        });
                        const productVariant = await ProductVariant.create({
                            product_id:product['id'],
                            size_id:size_id,
                            color_id:color_id
                        });
                        const hasVariantUpd = await Product.update({
                            has_variant:productVariant['id']
                        },{
                            where: {
                                id:product['id']
                            }
                        });
                        if(req.file){
                              var image = req.file.filename;
                        }else{
                              var image = null;
                        }
                        const productMedia = await ProductMedia.create({
                            product_id:product['id'],
                            file_name:image,
                            file_type:file_type
                        });
                        if (!product){
                            res.status(404).send({
                                message:process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message:process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: product
                            });
                        }  
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
});
}
//add product end

//edit product start
const EditProduct = async (req, res) => {
    upload.single('file')(req, res, async function (error) {
    const id = req.body.id;
    const user_id = req.userId;
    const product_name = req.body.product_name;
    const title = req.body.title;
    const description = req.body.description;
    const product_slug = slugify(title,'-');
    const price = req.body.price;
    const stock_quantity = req.body.stock_quantity;
    const category_id = req.body.category_id;
    const has_variant = req.body.has_variant;
    const weight = req.body.weight;
    const product_tags = req.body.product_tags;
    const size_id = req.body.size_id;
    const color_id = req.body.color_id;
    const file_type = req.body.file_type;
    const schema = Joi.object().keys({
        id:Joi.required(),
        product_name: Joi.required().label("Product name"),
        title: Joi.string().required().label("Title"),
        description:Joi.string().required().label("Description"),
        price:Joi.string().required().label("Price"),
        stock_quantity:Joi.string().required().label("Stock quantity"),
        category_id: Joi.number().integer().required().label("Category"),
        has_variant: Joi.number().integer().required().label("Variant"),
        weight: Joi.number().label("Weight"),
        product_tags:Joi.array().items(Joi.number().integer()).label("Product Tags"),
        size_id:Joi.number().integer().label("Size"),
        color_id:Joi.number().integer().label("Color")
    });
    const dataToValidate = {
        id:id,
        product_name: product_name,
        title: title,
        description:description,
        price:price,
        stock_quantity:stock_quantity,
        category_id:category_id,
        has_variant:has_variant,
        weight:weight,
        product_tags:product_tags,
        size_id:size_id,
        color_id:color_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    }else{
            try {
                if(size_id && color_id){
                    const productVariant = await ProductVariant.update({
                        product_id:id,
                        size_id:size_id,
                        color_id:color_id
                    },{
                        where: {
                            id:id
                        }
                    });
                }
                const product = await Product.update({
                        product_name: product_name,
                        product_slug:product_slug,
                        title: title,
                        description:description,
                        price:price,
                        stock_quantity:stock_quantity,
                        category_id:category_id,
                        has_variant:'1',
                        weight:weight,
                        product_tags:product_tags,
                        updated_at:current_date,
                        updated_by:user_id
                    }, {
                    where: {
                        id:id,
                        status: '1'
                    }
                });
                if(req.file){
                    const userData = await ProductMedia.findOne({where:{
                       id:id
                    }});
                    if(userData['file_name'] !== null && userData['file_name'] !== ''){
                        fs.unlink(process.env.PRODUCT_IMAGE+userData['file_name'], (error) => {
                        });
                    }   
                    var image = req.file.filename;
                }else{
                    var image = null;
                }
                const productMedia = await ProductMedia.create({
                    product_id:product['id'],
                    file_name:image,
                    file_type:file_type
                });
                if (!product){
                    res.status(404).send({
                        message:process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
});
}
//edit product end

//delete product start
const DeleteProduct = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id:  Joi.number().integer().required()
    });
    const dataToValidate = {
        id:id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const page = await Product.update({
                    status: '0',
                    is_deleted:'1',
                    updated_at:current_date,
                    updated_by:user_id
                }, {
                    where: {id:id}
                });
                if (!page){
                    res.status(404).send({
                        message:process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//delete product ends
//product ends

//Queries start
//get query start
const GetQuery = async (req, res) => {
    try {
        const token = req.header('authorization');
        jwt.verify(token,'storepedia277833',(err, decoded) => {
            req.userId = decoded.id;
        });
        const query = await Query.findAll({
            where: {
              user_id: req.userId,
              status: '1'
            },
            include:{
                model: User,
                attributes:['id','firstname']
            }
        });
        if (query == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: query
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get query end

//add query start
const AddQuery = async (req, res) => {
    const user_id = req.userId;
    const email = req.body.email;
    const contact_number = req.body.contact_number;
    const subject = req.body.subject;
    const description = req.body.description;
    const schema = Joi.object().keys({
        email: Joi.string().required().email().label("Email"),
        contact_number: Joi.number().min(10).required().label("Contact number"),
        subject: Joi.string().required().label("Subject"),
        description: Joi.string().required().label("Description"),
    });
    const dataToValidate = {
        email: email,
        contact_number: contact_number,
        subject: subject,
        description: description
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                        const query = await Query.create({ 
                            user_id: user_id,
                            email: email,
                            contact_number:contact_number,
                            subject: subject,
                            description:description,
                            created_at:current_date,
                            created_by:user_id
                        });
                        if (!query){
                            res.status(404).send({
                                message:process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message:process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: query
                            });
                        }  
                
            }catch(error){
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//add query end

//edit query start
const EditQuery = async (req, res) => {
    const id = req.body.id;
    const user_id = req.userId;
    const email = req.body.email;
    const contact_number = req.body.contact_number;
    const subject = req.body.subject;
    const description = req.body.description;
    const schema = Joi.object().keys({
        id: Joi.number().integer().required(),
        email: Joi.string().required().email().label("Email"),
        contact_number: Joi.number().min(10).required().label("Contact number"),
        subject: Joi.string().required().label("Subject"),
        description: Joi.string().required().label("Description")
    });
    const dataToValidate = {
        id:id,
        email:email,
        contact_number:contact_number,
        subject:subject,
        description:description
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const query = await Query.update({
                        email:email,
                        contact_number:contact_number,
                        subject:subject,
                        description:description,
                        updated_at:current_date,
                        updated_by:user_id
                    }, {
                    where: {
                      id:id,
                      user_id:user_id,
                      status: '1'
                    }
                });
                if (!query){
                    res.status(404).send({
                        message:process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//edit query end

//delete query start
const DeleteQuery = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id: Joi.number().integer().required()
    });
    const dataToValidate = {
        id:id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const query = await Query.update({
                    status: '0',
                    updated_at:current_date,
                    updated_by:user_id
                },{
                where: {
                  id:id
                }
                });
                if (!query){
                    res.status(404).send({
                        message:process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//delete query end
//Queries end

//Coupon starts
//get coupon start
const GetCoupon = async (req, res) => {
    try {
        const coupon = await Coupon.findAll({
                where: {
                  status: '1'
                }
        });
        if (coupon == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: coupon
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const GetActiveCoupon = async (req, res) => {
    try {
        const activecoupon = await Coupon.findAll({
            where: {
              status: '1'
            }
        });
        if (activecoupon == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: activecoupon
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}

const AddCoupon = async (req, res) => {
    upload.single('file')(req, res, async function (error) {
    const user_id = req.userId;
    const from_date = req.body.from_date;
    const to_date = req.body.to_date;
    const number_of_uses = req.body.number_of_uses;
    const coupon_use = req.body.coupon_use;
    const coupon_type = req.body.coupon_type;
    const coupon_desc = req.body.coupon_desc;
    const coupon_allow = req.body.coupon_allow;
    const type_val = req.body.type_val;
    const user_ids = req.body.user_ids;
    const schema = Joi.object().keys({
        from_date: Joi.date().required().greater('now').iso().label("From date"),
        to_date: Joi.date().required().greater(Joi.ref('from_date')).iso().label("To date"),
        number_of_uses: Joi.number().integer().required().label("Number of uses"),
        coupon_use: Joi.number().integer().required().label("Coupon use"),
        coupon_type: Joi.string().required().label("Coupon type"),
        coupon_desc: Joi.string().required().label("Coupon description"),
        coupon_allow: Joi.number().integer().required().label("Coupon allow"),
        type_val: Joi.number().integer().required().label("Type val"),
        user_ids:Joi.array().items(Joi.number().integer()).label("User Id"),
    });
    const dataToValidate = {
        from_date: from_date,
        to_date: to_date,
        number_of_uses: number_of_uses,
        coupon_use: coupon_use,
        coupon_type: coupon_type,
        coupon_desc: coupon_desc,
        coupon_allow: coupon_allow,
        type_val:type_val,
        user_ids:user_ids
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                        function randomString(len){
                            var p = "0123456789ABCDEFGHJKLMNOPQRSTUVWXYZ";
                            return [...Array(len)].reduce(a=>a+p[~~(Math.random()*p.length)],'');
                        }
                        const addCoupon = await Coupon.create({ 
                            coupon_code: randomString(16),
                            from_date: from_date,
                            to_date: to_date,
                            number_of_uses: number_of_uses,
                            coupon_use: coupon_use,
                            coupon_type: coupon_type,
                            coupon_desc: coupon_desc,
                            coupon_allow: coupon_allow,
                            type_val:type_val,
                            user_ids:user_ids,
                            created_at:current_date,
                            created_by: user_id
                        });
                        if (!addCoupon){
                            res.status(404).send({
                                message:process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message: process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: addCoupon
                            });
                        }  
                
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
});
}

const CouponCheck = async (req, res) => {
    const coupon_code = req.body.coupon_code;
    const schema = Joi.object().keys({
        coupon_code: Joi.number().integer().required().label("Coupon")
    });
    const dataToValidate = {
        coupon_code: coupon_code
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                const couponDetails = await Coupon.findOne({where:{coupon_code:coupon_code,status:'1'}});
                if (couponDetails == 0){
                    res.status(409).send({
                        message: 'Coupon not valid',
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                        var to_date = moment(couponDetails['to_date']).format("DD-MM-YYYY"); 
                        var current_date = moment(currentDate).format("DD-MM-YYYY"); 
                        if(to_date < current_date){
                            res.status(404).send({
                                message: 'Coupon expired',
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            if(couponDetails['number_of_uses'] < 1){
                                res.status(404).send({
                                    message: 'Coupon not axious',
                                    error: true,
                                    success: false,
                                    status: '0'
                                });
                            }else{
                                res.status(200).send({
                                    message: process.env.SUCCESS_MSG,
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: couponDetails
                                });
                            }  
                        }
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}

const ApplyCoupon = async (req, res) => {
    const user_id = req.userId;
    const coupon_code = req.body.coupon_code;
    const schema = Joi.object().keys({
        coupon_code: Joi.number().integer().required().label("Coupon")
    });
    const dataToValidate = {
        coupon_code: coupon_code
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                    const couponAppliedExists = await UserCoupon.findOne({
                        where:{
                            user_id:user_id,
                            coupon_code:coupon_code,
                            status:'1'
                        }
                    });
                    if(couponAppliedExists){
                            res.status(409).send({
                                message: 'Coupon already applied',
                                error: true,
                                success: false,
                                status: '0'
                            });
                    }else{
                        const couponDetail = await Coupon.findOne({
                            where:{
                                id:coupon_code,
                                status:'1'
                            }
                        });
                        if(couponDetail['number_of_uses'] > couponDetail['coupon_use']){
                            const appliedCouponData = await UserCoupon.create({ 
                                user_id: user_id,
                                coupon_code: coupon_code,
                                created_at:current_date,
                                created_by: user_id
                            });
                            const coupon = await Coupon.update({
                                coupon_use: couponDetail['coupon_use']+1
                            },{
                                where: {
                                id:coupon_code
                                }
                            });
                            if (!appliedCouponData){
                                res.status(404).send({
                                    message: 'Coupon not applied',
                                    error: true,
                                    success: false,
                                    status: '0'
                                });
                            }else{
                                res.status(200).send({
                                    message: 'Coupon applied',
                                    error: false,
                                    success: true,
                                    status: '1',
                                    data: appliedCouponData
                                });
                            }  
                        }else{
                            res.status(404).send({
                                message: 'Coupon use limit exceeded',
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }
                    }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//get coupon end

//delete coupon
const DeleteCoupon = async (req, res) => {
    const user_id = req.userId;
    const id = req.body.id;
    const schema = Joi.object().keys({
        id: Joi.number().integer().required()
    });
    const dataToValidate = {
        id:id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const coupon = await Coupon.update({
                    status: '0',
                    is_deleted:'1',
                    updated_at:current_date,
                    updated_by:user_id
                }, {
                where: {
                  id:id
                }
                });
                if (!coupon){
                    res.status(404).send({
                        message:process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//delete coupon
//Coupon ends

//Wallet main start
const AddWalletMain = async(req,res) => {
    const user_id = req.userId;
    const amount = req.body.amount;
    const details = req.body.details;
    const if_apply_coupon = req.body.if_apply_coupon;
    const coupon_id = req.body.coupon_id;
    if(if_apply_coupon == '1'){
       var coupon_id_valid = Joi.number().integer().required().label("Coupon");
    }else{
       var coupon_id_valid = Joi.number().integer().label("Coupon");
    }
    const schema = Joi.object().keys({
        if_apply_coupon: Joi.string().required().label("If apply coupon"),
        amount: Joi.string().required().label("Amount"),
        details: Joi.string().required().label("Details"),
        coupon_id:coupon_id_valid
    });
    const dataToValidate = {
        if_apply_coupon:if_apply_coupon,
        amount: amount,
        details: details,
        coupon_id:coupon_id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                        function randomString(len) {
                            var p = "0123456789";
                            return [...Array(len)].reduce(a=>a+p[~~(Math.random()*p.length)],'');
                        }
                        if(amount < 0){
                            var transaction_id = "strpd"+ randomString(6); 
                            var debit_credit_status = 2;
                        }else{
                            var transaction_id = "strpd"+ randomString(6); 
                            var debit_credit_status = 1; 
                        }
                        const WalletData = await WalletMain.create({ 
                            user_id:user_id,
                            transaction_id:transaction_id,
                            debit_credit:debit_credit_status,
                            invoice_no:'12345',
                            invoice_type:'1',
                            amount: amount,
                            order_status:'1',
                            details: details,
                            if_apply_coupon:if_apply_coupon,
                            created_at:current_date,
                            created_by: user_id
                        });
                        if (!WalletData){
                            res.status(404).send({
                                message: process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message: process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: WalletData
                            });
                        }  
            }catch(error){
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//Wallet main end

//seo start
//get seo start
const GetSeo = async (req, res) => {
    try {
        const seo = await Seo.findAll({
            where: {
              status: '1'
            },
            include:{
                model:PageMstr,
                attributes:['id','page_name'],
                where: {status:'1'},
                required: false
            }
        });
        if (seo == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: seo
            });
        }
    } catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get seo end

//add seo start
const AddSeo = async (req, res) => {
    const page_id = req.body.page_id;
    const title = req.body.title;
    const meta_description = req.body.meta_description;
    const meta_keyword = req.body.meta_keyword;
    const schema = Joi.object().keys({
        page_id: Joi.number().integer().label("Page"),
        title: Joi.string().required().label("Title"),
        meta_description: Joi.string().required().label("Meta description"),
        meta_keyword: Joi.string().required().label("Meta keyword"),
    });
    const dataToValidate = {
        page_id: page_id,
        title: title,
        meta_description: meta_description,
        meta_keyword: meta_keyword
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {        
            try {
                        const seo = await Seo.create({ 
                            page_id: page_id,
                            title:title,
                            meta_description: meta_description,
                            meta_keyword:meta_keyword,
                            created_at:current_date
                        });
                        if (!seo){
                            res.status(404).send({
                                message:process.env.NOT_INSERTED_MSG,
                                error: true,
                                success: false,
                                status: '0'
                            });
                        }else{
                            res.status(200).send({
                                message:process.env.INSERTED_MSG,
                                error: false,
                                success: true,
                                status: '1',
                                data: seo
                            });
                        }  
                
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//add seo end

//edit seo start
const EditSeo = async (req, res) => {
    const id = req.body.id;
    const page_id = req.body.page_id;
    const title = req.body.title;
    const meta_description = req.body.meta_description;
    const meta_keyword = req.body.meta_keyword;
    const schema = Joi.object().keys({
        id: Joi.number().integer().required(),
        page_id: Joi.number().integer().label("Page"),
        title: Joi.string().required().label("Title"),
        meta_description: Joi.string().required().label("Meta description"),
        meta_keyword: Joi.string().required().label("Meta keyword"),
    });
    const dataToValidate = {
        id:id,
        page_id: page_id,
        title: title,
        meta_description: meta_description,
        meta_keyword: meta_keyword
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const seo = await Seo.update({
                        page_id:page_id,
                        title:title,
                        meta_description:meta_description,
                        meta_keyword:meta_keyword,
                        created_at:current_date
                    }, {
                    where: {
                      id:id,
                      status: '1'
                    }
                });
                if (!seo){
                    res.status(404).send({
                        message:process.env.NOT_UPDATED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.UPDATED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//edit seo end

//delete seo start
const DeleteSeo = async (req, res) => {
    const id = req.body.id;
    const schema = Joi.object().keys({
        id: Joi.number().integer().required()
    });
    const dataToValidate = {
        id:id
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const seo = await Seo.update({
                    status: '0'
                }, {
                where: {
                  id:id
                }
                });
                if (!seo){
                    res.status(404).send({
                        message:process.env.NOT_DELETED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.DELETED_MSG,
                        error: false,
                        success: true,
                        status: '1'
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
    }
}
//delete seo end
//seo end

//get home slider start
const GetHomeSliderList = async (req, res) => {
    try {
        const slider = await HomeSlider.findAll({
            attributes:['id','title','sub_title','image','button_link']
        },{
            where:{
                status:'1'
            }
        });
        if (slider == 0){
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path:'https://api.growthgrids.com/storepedia/uploads/slider/',
                data: slider
            });
        }
    }catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get home slider start

//get tag start
const GetTagList = async (req, res) => {
    try {
        const slider = await Tag.findAll({
            where:{
                status:'1'
            }
        });
        if (slider == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: slider
            });
        }
    }catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get tag start

//about us
const AboutUs = async (req, res) => {
    try {
        const aboutUs = await StaticPage.findOne({
            attributes: ['title','heading','description','image']
        },{
            where:{
                page_id:1,
                status:'1'
            },
        });
        if (aboutUs == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                data: aboutUs
            });
        }
    }catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//about us

//contact us
const AddContactUs = async (req, res) => {
    const email = req.body.email;
    const schema = Joi.object().keys({
        email: Joi.required()
    });
    const dataToValidate = {
        email:email
    };
    const result = schema.validate(dataToValidate);
    if (result.error) {
        res.status(403).send({
            error: true,
            success: false,
            status: '0',
            message: result.error.details[0].message
        });
    } else {
            try {
                const newsletter = await NewsLetter.create({
                        email:email,
                        created_at:current_date
                    }
                );
                const response = sendDynamicEmail(
                    email,
                    'Contact Us',
                    'Contact Us',
                    '<p>'+ email +' have contacted you for inquiry.</p>'
                );
                if (!newsletter){
                    res.status(404).send({
                        message:process.env.NOT_INSERTED_MSG,
                        error: true,
                        success: false,
                        status: '0'
                    });
                }else{
                    res.status(200).send({
                        message:process.env.INSERTED_MSG,
                        error: false,
                        success: true,
                        status: '1',
                        data: req.body
                    });
                }
            } catch(error) {
                res.status(500).send({
                    message:process.env.ERROR_MSG,
                    error: true,
                    success: false,
                    status: '0',
                });
            }
  }
}
//contact us

//shop by category
const ShopByCategory = async (req, res) => {
    try {
        const category = await Category.findAll({
            attributes: ['id','name','image'],
            limit: 5,
            order: [['id','DESC']],
        },{
            where:{
                status:'1'
            },
        });
        if (category == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path:'https://api.growthgrids.com/storepedia/uploads/category/',
                data: category
            });
        }
    }catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//shop by category

//get new arrivals 
const GetNewArrivals = async (req, res) => {
    try {
        const arrivalsProduct = await Product.findAll({
            limit: 10,
            order: [['id','DESC']],
            attributes: ['id','product_name','price'],
            include:[{
                model:ProductMedia,
                as:'products',
                attributes: ['id','product_id','file_name','file_name_200_x_200','file_name_180_x_180','file_name_150_x_150','file_name_120_x_120'],
            }],
        },{
            where:{
                status:'1'
            },
        }
      );

        if (arrivalsProduct == 0) {
            res.status(404).send({
                message: process.env.RECORD_NOT_FOUND,
                error: true,
                error: true,
                success: false,
                status: '0'
            });
        }else{
            res.status(200).send({
                message: process.env.SUCCESS_MSG,
                error: false,
                success: true,
                status: '1',
                path:'https://api.growthgrids.com/storepedia/uploads/products/',
                data: arrivalsProduct
            });
        }
    }catch(error) {
        res.status(500).send({
            message:process.env.ERROR_MSG,
            error: true,
            success: false,
            status: '0',
        });
    }
}
//get new arrivals



module.exports = {
    GetGenderList,GetColorList,GetCurrencyList,GetSizeList,GetMenuList,GetPageList,GetPrefixList,GetTimezoneList,GetRoleList,GetStateListByCountry,GetCityListByState,GetCountryList,GetCategoryList,GetWishlist,AddWishlist,EditWishlist,DeleteWishlist,GetCart,AddCart,EditCart,DeleteCart,GetUserAddress,AddUserAddress,EditUserAddress,DeleteUserAddress,GetWishlistCategory,AddWishlistCategory,EditWishlistCategory,DeleteWishlistCategory,GetUserWallet,AddUserWallet,EditUserWallet,DeleteUserWallet,GetStaticPage,AddStaticPage,EditStaticPage,DeleteStaticPage,GetProduct,AddProduct,EditProduct,DeleteProduct,GetQuery,AddQuery,EditQuery,DeleteQuery,GetCoupon,GetActiveCoupon,CouponCheck,ApplyCoupon,DeleteCoupon,AddWalletMain,AddCoupon,GetSeo,AddSeo,EditSeo,DeleteSeo,GetHomeSliderList,GetTagList,AboutUs,AddContactUs,GetNewArrivals,ShopByCategory
};
   


