const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance

const InvtQty = sequelize.define('main_invt_qtys', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    qty: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    status: {
        type: DataTypes.TINYINT(3).UNSIGNED,
        defaultValue: '1'
    },
    debit_credit: {
        type: DataTypes.TINYINT(3).UNSIGNED,
        defaultValue: '1'
    },
    entry_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    entry_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});


module.exports = InvtQty;