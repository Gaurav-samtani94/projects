const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Product = require('../../models/master/Product');
const TrackOrder = require('../../models/master/TrackOrder');
const OrderItem = sequelize.define('strpd_order_items', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    order_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    product_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    quantity: {
        type: DataTypes.INTEGER,
        defaultValue: '0'
    },
    price: {
        type: DataTypes.DECIMAL,
        defaultValue: '0.00'
    },
    discount_amt: {
        type: DataTypes.DECIMAL,
        defaultValue: '0.00'
    },
    total_amt: {
        type: DataTypes.DECIMAL,
        defaultValue: '0.00'
    },
    prd_discount_amt: {
        type: DataTypes.DECIMAL,
        defaultValue: '0.00'
    },
    discount_id: {
        type: DataTypes.INTEGER,
        defaultValue: '0'
    },
    shipping_type: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    shipping_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    shipping_min_price: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },
    shiprocket_order_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    shiprocket_shipping_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    shiprocket_status: {
        type: DataTypes.TINYINT,
        defaultValue: '0'
    },
    awb_code: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.INTEGER,
        defaultValue: '0'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

OrderItem.belongsTo(Product, {
    foreignKey: 'product_id',
    as :'products'
});




OrderItem.hasOne(TrackOrder, {
    foreignKey: 'order_item_id',
    as :'track_order'
});

module.exports = OrderItem;