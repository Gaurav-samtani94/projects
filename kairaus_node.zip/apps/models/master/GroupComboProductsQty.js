const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const InvtProduct = require("../../models/master/InvtProduct");
const InvtQty = require("../../models/master/InvtQty");

const GroupComboProductsQty = sequelize.define('main_invt_group_combo_product_qtys', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    invt_product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    invt_group_combo_product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        defaultValue: '0'
    },
    status: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

GroupComboProductsQty.belongsTo(InvtProduct, {
    foreignKey: 'invt_product_id',
    as:'ip'
});
GroupComboProductsQty.belongsTo(InvtQty, {
    foreignKey: 'invt_product_id',
    as:'miq'
});

module.exports = GroupComboProductsQty;