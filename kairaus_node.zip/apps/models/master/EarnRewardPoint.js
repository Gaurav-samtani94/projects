const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const EarnRewardPoint = sequelize.define('history_earn_rewards', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    order_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    reward_point: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    reward_cmnt: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    type: {
        type: DataTypes.TINYINT(3).UNSIGNED,
        defaultValue: '1'
    },
    debit_credit: {
        type: DataTypes.TINYINT(3).UNSIGNED,
        defaultValue: '1'
    },
    status: {
        type: DataTypes.TINYINT(3).UNSIGNED,
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
});

module.exports = EarnRewardPoint;



