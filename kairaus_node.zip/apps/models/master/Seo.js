const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const PageMstr = require("../../models/master/PageMstr");
const Seo = sequelize.define('strpd_seo_metas', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    page_type: {
        type: DataTypes.ENUM,
        values: [
            'menu', 'category', 'aboutus', 'product'
        ],
        allowNull: true,
    },
    page_slug: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    page_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    title: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    meta_description: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    footer_content: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    footer_link_content: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    meta_keyword: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});

module.exports = Seo;