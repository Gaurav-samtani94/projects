
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Category = require("../../models/master/Category");
const MenuCategory  = sequelize.define('strpd_menu_categories', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },  
    menu_id: {
        type:DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    category_id: {
        type:DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
});

MenuCategory.belongsTo(Category, {
    foreignKey:'category_id',
    as:'child_items'
});

module.exports = MenuCategory;