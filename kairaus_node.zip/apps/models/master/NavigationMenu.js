
const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const Category = require("../../models/master/Category");
const Menu = require("../../models/master/Menu");
const NavigationMenu = sequelize.define('strpd_navigation_menus', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    }, 
    menu_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    parent_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }, 
    name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    slug: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    type: {
        type: DataTypes.ENUM,
        values: [
            '1', '2','3'
        ]
    },
    category: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'
        ]
    },
});

NavigationMenu.belongsTo(NavigationMenu, {
    foreignKey:'menu_id',
    as:'parent_items'
});
NavigationMenu.hasMany(NavigationMenu, {
    foreignKey:'parent_id',
    as:'child_items'
});

NavigationMenu.belongsTo(Category, {
    foreignKey:'menu_id',
    as:'categories'
});

NavigationMenu.belongsTo(Menu, {
    foreignKey:'menu_id',
    as:'menus'
});

module.exports = NavigationMenu;