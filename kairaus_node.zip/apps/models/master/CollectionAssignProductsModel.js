const { DataTypes } = require('sequelize');
const sequelize = require('../../config/database'); // Import your Sequelize instance
const CollectionAssignProductsModel = sequelize.define('stprd_collection_assign_products',{
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    collection_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },
    product_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
 
    status: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'
        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
});



module.exports = CollectionAssignProductsModel;
