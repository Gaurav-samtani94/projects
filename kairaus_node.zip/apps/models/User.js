const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
const Role = require("./master/Role");
const Country = require('./master/Country');
const State = require('./master/State');
const City = require('./master/City');
const User = sequelize.define('strpd_main_users', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    role_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
    },
    firstname: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    middle_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    lastname: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    userfullname: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    email: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    contactnumber: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    password: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    isactive: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: '1',
        comment: "0-InActive,1-Active,2-resigned,3-left,4-suspended,5-deleted"
    },
    date_of_birth: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    profileimg: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    country_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    state_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    city_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    zip_code: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    full_address_1: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    ref_code: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    parent_ref_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    last_login: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    reset_pass_token_expiry: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    last_login_otp: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    login_attempt: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    user_login_block_datetime: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    login_otp_wrong_attempt: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    user_login_block_datetime_wrong_otp: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    resent_otp_attemp: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    is_verified_mobile: {
        type: DataTypes.ENUM,
        values: ['1', '2'],
        defaultValue: '2',
        comment: "1-yes,2-no"
    },
    mobile_verify_otp: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    is_verified_email: {
        type: DataTypes.ENUM,
        values: ['0', '1'],
        defaultValue: '0',
        comment: "1-yes,0-no"
    },
    email_verify_otp: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    auth_token: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    is_social_login: {
        type: DataTypes.ENUM,
        values: ['1', '2'],
        defaultValue: '2',
        comment: "1-yes,2-other"
    },
    social_login_type: {
        type: DataTypes.ENUM,
        values: ['1', '2'],
        defaultValue: null,
        comment: "1-Gmail,2-Facebook"
    },
    reset_pass_token: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    gender: {
        type: DataTypes.ENUM,
        values: ['male', 'female', 'other'],
        allowNull: true,
    },
    father_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    mother_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    marital_status: {
        type: DataTypes.ENUM,
        values: ['single', 'married', 'other'],
        allowNull: true,
    },
    anniversary_date: {
        type: DataTypes.STRING,
        allowNull: true,
    },
});

User.belongsTo(Role, {
    foreignKey: 'role_id',
});

User.belongsTo(Country, {
    foreignKey: 'country_id',
    as: 'country'
});

User.belongsTo(State, {
    foreignKey: 'state_id',
    as: 'state'
});

User.belongsTo(City, {
    foreignKey: 'city_id',
    as: 'city'
});

module.exports = User;
