const sessionTrack = (req, res, next) => {
    console.log(req.session.lastActivity,"==========QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ=========")
    console.log(req.session.user,"===================")

    if (req.session && req.session.user) {
        console.log(req.session.lastActivity,"===================")
        const customExpirationTime = req.session.customExpirationTime || (.25 * 60 * 1000); // Default: 30 minutes
    
        if (req.session.lastActivity && (Date.now() - req.session.lastActivity > customExpirationTime)) {
            console.log(customExpirationTime,"===================")
            req.session.destroy(err => {
                if (err) {
                    return res.status(process.env.APIRESPCODE_SESSION_MSG).send({
                        message: 'Error in destroying session',
                        session_message: err,
                        error: true,
                        success: false,
                        status: '0',
    
                    });
                }
    
                //res.redirect("https://files.growthgrids.com/signin")
                return res.status(process.env.APIRESPCODE_SESSION_MSG).send({
                    message: process.env.APIRESPMSG_SESSION_EXPIRED,
                    error: true,
                    success: false,
                    status: '0',
                });
    
            });
            
        } else {
            // Update last activity time
            req.session.lastActivity = Date.now();
            next();
        }
    } else {
        next();
    }
    };
    
    module.exports = sessionTrack;