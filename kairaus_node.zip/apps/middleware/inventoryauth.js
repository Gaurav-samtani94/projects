const jwt = require('jsonwebtoken');
const secretKey = 'storepedia277833';


const inventoryverifyToken = (req, res, next) => {
    const token = req.header('authorization');
    if (!token) {
        return res.status(401).json({ message: 'No token provided' });
    }
    jwt.verify(token, secretKey, (err, decoded) => {
        // console.log(decoded,'decode');
        if (err) {
            return res.status(401).json({ message: 'Invalid token' });
        }
        req.userId = decoded.id;
        req.comp_id = decoded.comp_id;
        req.roleId= decoded.role_id;
        // console.log(decoded.role_id,'abhi')
        if (decoded.role_id !== 4) {
            return res.status(403).json({ message: 'You do not have permission' });
          }
        next();
    });

};


module.exports = inventoryverifyToken