const jwt = require('jsonwebtoken');
const secretKey = 'storepedia277833';
const users = require('../models/User')
const verifyToken = async (req, res, next) => {
    const token = req.header('authorization');
    if (!token) {
        return res.status(401).json({ message: 'No token provided' });
    }
    jwt.verify(token, secretKey, async (err, decoded) => {
        if (err) {
            return res.status(401).json({ message: 'Invalid token' });
        }
        // const user = await users.findOne({
        //     where: {
        //         id: decoded.id
        //     }
        // })
        // if (user.auth_token !== token) {
        //     return res.status(401).json({ message: 'You have logged into another device', status: '0' });
        // }
        req.userId = decoded.id;
        req.comp_id = decoded.comp_id;
        next();
    });

};
module.exports = verifyToken;