const jwt = require('jsonwebtoken');
const secretKey = 'bidgrid277833';

const sessionTrackActivity = (req, res, next) => {
    console.log(req,"--------------");
    req.session.user = {
        username: req.body.username,
        // Any other user data you may want to store
      };
    // Check if the user is logged in and if a session is available
    console.log(req.session.user,'======');
    if (req.session && req.session.user) {
        console.log(req.session.user,'gggggggggggggggggggggggg');
        // Set or update last activity time to the current timestamp
        req.session.lastActivity = Date.now();
    }
    // console.log(req.session.lastActivity,"==============ttttttttttttttt==================")
    next(); // Call next middleware in the chain
};

module.exports = { sessionTrackActivity };