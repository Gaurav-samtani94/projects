var http = require('http'),
fs = require('fs'),
ccav = require('./ccavutil.js'),
crypto = require('crypto'),
qs = require('querystring');
const sequelize = require('sequelize');
const current_date =  new Date();
const getCurrentDateTime = () => new Date();
const url = require('url');
const Order = require("../models/master/Order");
const OrderItem =  require("../models/master/OrderItem");
const Cart = require("../models/master/Cart");
const User = require("../models/User");
const Product = require("../models/master/Product");
const EarnRewardPoint = require('../models/master/EarnRewardPoint');

// exports.postRes = function(request,response,callback){
//     var ccavEncResponse='',
// 	ccavResponse='',	
// 	workingKey = '0D66B2843A02FB40C35007C28F8A9E29',	//Put in the 32-Bit key provided by CCAvenues.
// 	ccavPOST = '';

//     //Generate Md5 hash for the key and then convert in base64 string
//     var md5 = crypto.createHash('md5').update(workingKey).digest();
//     var keyBase64 = Buffer.from(md5).toString('base64');

//     //Initializing Vector and then convert in base64 string
//     var ivBase64 = Buffer.from([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d,0x0e, 0x0f]).toString('base64');

//         request.on('data', function (data) {
// 	    ccavEncResponse += data;
// 	    ccavPOST =  qs.parse(ccavEncResponse);
// 	    var encryption = ccavPOST.encResp;
// 	    ccavResponse = ccav.decrypt(encryption, keyBase64, ivBase64);
//         });

// 	request.on('end', function () {
// 		var ccavResponseObj = qs.parse(ccavResponse);
// 		callback(ccavResponseObj);
//         // console.log(ccavResponseObj.order_id);
		

// 	    // var pData = '';
// 	    // pData = '<table border=1 cellspacing=2 cellpadding=2><tr><td>'	
// 	    // pData = pData + ccavResponse.replace(/=/gi,'</td><td>')
// 	    // pData = pData.replace(/&/gi,'</td></tr><tr><td>')
// 	    // pData = pData + '</td></tr></table>'
//         //     htmlcode = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>Response Handler</title></head><body><center><font size="4" color="blue"><b>Response Page</b></font><br>'+ pData +'</center><br></body></html>';
//         //     response.writeHeader(200, {"Content-Type": "text/html"});
// 	    // response.write(htmlcode);
// 	    // response.end();
// 	}); 	
// };

const postRes = async (request, response) => { 
	const parsedUrl = url.parse(request.url, true);
    const queryStringParams = parsedUrl.query;
	
    var ccavEncResponse = '';
    var ccavResponse = '';	
    var workingKey = '0D66B2843A02FB40C35007C28F8A9E29';	// Put in the 32-Bit key provided by CCAvenues.
    var ccavPOST = '';

    // Generate Md5 hash for the key and then convert in base64 string
    var md5 = crypto.createHash('md5').update(workingKey).digest();
    var keyBase64 = Buffer.from(md5).toString('base64');

    // Initializing Vector and then convert in base64 string
    var ivBase64 = Buffer.from([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d,0x0e, 0x0f]).toString('base64');

    request.on('data', function (data) {
        ccavEncResponse += data;
        ccavPOST =  qs.parse(ccavEncResponse);
        var encryption = ccavPOST.encResp;
        ccavResponse = ccav.decrypt(encryption, keyBase64, ivBase64);
    });

    request.on('end', async function () {
        var ccavResponseObj = qs.parse(ccavResponse);
        try {
			if(ccavResponseObj.order_status == 'Success') {
				var payment_status = 1;
			} else {
				var payment_status = 2;
			}
			var user_id = ccavResponseObj.delivery_zip ? ccavResponseObj.delivery_zip : 0;
            const orders = await Order.create({ 
                user_id: user_id,
				order_id: ccavResponseObj.order_id,
				transaction_id: ccavResponseObj.tracking_id,
				bank_ref_no: ccavResponseObj.bank_ref_no,
				total_amount: ccavResponseObj.billing_notes ? ccavResponseObj.billing_notes : 0,
				discount_amt: ccavResponseObj.merchant_param2 ? ccavResponseObj.merchant_param2 : 0,
				reward_amt: queryStringParams.reward_amt ? queryStringParams.reward_amt : 0,
				shipping_amt: ccavResponseObj.merchant_param3 ? ccavResponseObj.merchant_param3 : 0,
				tax_amt: ccavResponseObj.merchant_param4 ? ccavResponseObj.merchant_param4 : 0,
				paid_amount: ccavResponseObj.amount,
				payment_type: 1,
				currency: ccavResponseObj.currency,
				discount_id: ccavResponseObj.merchant_param5 ? ccavResponseObj.merchant_param5 : 0,
				first_name: ccavResponseObj.billing_name ? ccavResponseObj.billing_name : null,
				last_name: ccavResponseObj.delivery_name ? ccavResponseObj.delivery_name : null,
				address: ccavResponseObj.billing_address ? ccavResponseObj.billing_address : null,
				name:queryStringParams.address_name ? queryStringParams.address_name : null,
				title: ccavResponseObj.delivery_address ? ccavResponseObj.delivery_address : null,
				apartment: ccavResponseObj.delivery_state ? ccavResponseObj.delivery_state : null,
				land_mark: ccavResponseObj.delivery_city ? ccavResponseObj.delivery_city : null,
				mobile_number: ccavResponseObj.billing_tel ? ccavResponseObj.billing_tel : null,
				country: ccavResponseObj.billing_country ? ccavResponseObj.billing_country : null,
				state: ccavResponseObj.billing_state ? ccavResponseObj.billing_state : null,
				city: ccavResponseObj.billing_city ? ccavResponseObj.billing_city : null,
				zip_code: ccavResponseObj.billing_zip ? ccavResponseObj.billing_zip : null,
				gst_number:queryStringParams.gst_number ? queryStringParams.gst_number : null,
				payment_status: payment_status,
				created_at:getCurrentDateTime(),
				created_by:user_id
            });
            if (!orders){
				response.status(404).send({
					message: 'Order not inserted',
					error: true,
					success: false,
					status: '0'
				});
			}else{
				const orderId = orders.id;

				const orderDetail = await Order.findOne({
					where: {
						user_id:user_id,
						id:orderId,
					},
					attributes:['id'],
					include:[
						{
							model:User,
							as:'user',
							attributes:['email'],
							required: false
						}
					],
				});
				const user_email = orderDetail.user ? orderDetail.user.email : null;

				// get cart data
				const carts = await Cart.findAll({
					where: {
						user_id: user_id,
						status: 1
					},
					attributes:['id','user_id','product_id','product_variant_id','quantity','amount','subtotal_amount'],
				});
				if(carts) {
					const cartArray = carts;
					for (const cart of cartArray) {
						const productId = cart.product_id;
						const quantity = cart.quantity;
						const amount = cart.amount;
						await OrderItem.create({ 
							order_id: orderId,
							product_id: productId,
							quantity: quantity,
							price: amount,
							created_at:getCurrentDateTime()
						});

						const productDetail = await Product.findOne({
							attributes: ['stock_quantity'],
							where: {
								id: productId
							}
						});
						const prqty = productDetail.stock_quantity ? productDetail.stock_quantity : 0;
						const totalQty = prqty-quantity;

						const sumResult = await OrderItem.findOne({
							attributes: [
								[sequelize.fn('SUM', sequelize.col('quantity')), 'totalQuantity']
							],
							where: {
								product_id: productId
							}
						});
						const totalQuantity = sumResult.getDataValue('totalQuantity');

						if(totalQty >= 0) {
							await Product.update({
								stock_quantity: totalQty,
								sold_out_count:totalQuantity
							},{
								where: {
								id:productId
								}
							});
						}
					}
					await Cart.destroy({
						where: {
							user_id: user_id,
							status: 1
						},
						});
				}

				//if(queryStringParams.reward_point>=process.env.MIN_REWARD_POINT){
				if(queryStringParams.reward_point > 0){
					await EarnRewardPoint.create({
						user_id: user_id,
						order_id: orderId,
						reward_point: -queryStringParams.reward_point,
						type: 1,
						debit_credit: 2,
						reward_cmnt: 'use',
						created_at:getCurrentDateTime()
					});
				}

				const axios = require('axios');
				const qs = require('qs');
				let data = qs.stringify({
					'id': orderId,
					'user_id': user_id 
					});

				const config = {
					method: 'post',
					url: process.env.SITE_URL+'download_pdf',
					data: data
				};

				const respons = await axios(config);
				const invoiceUrl = process.env.SITE_URL+'uploads/order_invoice/'+respons.data
				
				/******* Send invoice pdf mail start*/
				let dataa = qs.stringify({
					'to': user_email,
					'subject': 'Order Invoice',
					'msg_detail':'Please find attached the PDF.',
					'attach': invoiceUrl,
					});
			
				const configg = {
					method: 'post',
					url: process.env.SITE_URL+'send_mail_node_api',
					data: dataa
				};

				const responsee = await axios(configg);
				/******* Send invoice pdf mail end*/

				// response.status(200).send({
				// 	message: 'Order inserted successfully',
				// 	error: false,
				// 	success: true,
				// 	status: '1',
				// 	data: orders
				// });
				console.log(process.env.FRONT_SITE_URL+'thanku-check================================')
				response.redirect(process.env.FRONT_SITE_URL+'thanku-check?order_id='+orderId);
			}
        } catch (error) {
            console.error(error);
            response.status(500).send({
                message: 'Error inserting order',
                error: true,
                success: false,
                status: '0'
            });
        }
    }); 
}

module.exports = {postRes}