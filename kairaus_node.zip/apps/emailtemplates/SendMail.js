const axios = require('axios');
const qs = require('qs');
const path = require('path');
const fs = require('fs');
require('dotenv').config();
const EmailTemplate = require("../../apps/models/master/EmailTemplate");
async function sendEmail(user, mailType, emailData='') {
    const image_path = process.env.SITE_URL+'uploads/products/';
    try {
        const template_email = await EmailTemplate.findOne({ where: { mail_type: mailType } });
        if (!template_email) {
            throw new Error('Email template not found');
        }
        var template_subject =  template_email.subject
        if(mailType == "WelcomeEmail"){

            var emailContent = template_email.message.replace('[NAME]', user.userfullname);
        }else if(mailType == "ResetPasswordEmail"){
            var emailContent = template_email.message.replace('[NAME]', user.userfullname)
            .replace('[LINK]', emailData);
        }else if(mailType == "ChangePasswordEmail"){
            var emailContent = template_email.message.replace('[NAME]', user.userfullname)
            .replace('[PASSWORD]', emailData);
        }else if(mailType == "UpdateProfileEmail"){
            var emailContent = template_email.message.replace('[NAME]', user.userfullname).replace('[OTP]', emailData);
        }else if(mailType == "Subscribe"){

            var emailContent = template_email.message.replace('[CompanyName]', 'Kairaus');

        }else if(mailType == "BulkOrderEnquiry"){
            var emailContent = template_email.message.replace('[NAME]', user.name)
            .replace('[PRODUCTNAME]', emailData?emailData.product_name:'')
            .replace('[ADDRESS]', user.address);

        }else if(mailType == "ContactUsEmail"){
            var emailContent = template_email.message.replace('[NAME]', user.userfullname)
            .replace('[QUERY]', emailData.query).replace('[QUERY]', emailData.query);

            var template_subject =  template_email.subject.replace('[QUERY]', emailData.query);

        }else if(mailType == "CancelOrderItemEmail"){
            var itemsList = '';
            itemsList += `
            <div style="display: flex; align-items: center; padding: 10px 0; border-bottom: 1px solid #eaeaea;">
            <img src="${image_path}${emailData.products.productimage.file_name_200_x_200}"
                alt="${emailData.products.product_name}" style="max-width: 80px; margin-right: 20px;">
            <div>
                <h3 style="font-size: 16px; margin: 0;">${emailData.products.product_name}</h3>
            </div>
            <div style="margin-left: auto; font-size: 14px;">${emailData.quantity}</div>
            <div style="margin-left: auto; font-size: 14px;">${emailData.total_amt}</div>
        </div>`;

        var emailContent = template_email.message.replace('[NAME]', user.userfullname).replace('[ORDERITEM]',`${itemsList}`)
        .replace('[ITEMS]', emailData.products.product_name);
        }else if(mailType == "OrderConfirmation"){
            let itemsList = '';
            emailData.order_item.forEach(item => {
                itemsList += `
                    <div style="display: flex; align-items: center; padding: 10px 0; border-bottom: 1px solid #eaeaea;">
                    <img src="${image_path}${item.products.productimage.file_name_200_x_200}"
                        alt="${item.products.product_name}" style="max-width: 80px; margin-right: 20px;">
                    <div>
                        <h3 style="font-size: 16px; margin: 0;">${item.products.product_name}</h3>
                    </div>
                    <div style="margin-left: auto; font-size: 14px;">${item.quantity}</div>
                    <div style="margin-left: auto; font-size: 14px;">${item.total_amt}</div>
                </div>
                `;
            });
            var discount =  parseFloat(emailData.discount_amt || 0) + parseFloat(emailData.reward_amt || 0) + parseFloat(emailData.first_order_discount_amt || 0);
            var emailContent = template_email.message.replace('[NAME]', user.userfullname).replace('[ORDERSUMMERY]',`${itemsList}`)
            .replace('[EMAIL]',user.email)
            .replace('[SUBTOTAL]',emailData.total_amount)
            .replace('[DISCOUNT]',discount.toFixed(2))
            .replace('[PAIDAMOUNT]',emailData.paid_amount)
            .replace('[SHIPPINGAMOUNT]',emailData.shipping_amt)
            .replace('[USER]',emailData.first_name).replace('[APARTMENT]',emailData.apartment ? emailData.apartment :'')
            .replace('[ADDRESS]',emailData.address).replace('[ZIPCODE]',emailData.zip_code)
            .replace('[COUNTRY]',emailData.country)

            .replace('[BILLINGUSER]',emailData.billing_name ?emailData.billing_name :emailData.first_name)
            .replace('[BILLINGAPARTMENT]',emailData.apartment ? emailData.apartment :emailData.apartment ? emailData.apartment :'')
            .replace('[BILLINGADDRESS]',emailData.billing_address ? emailData.billing_address : emailData.address)
            .replace('[PINCODE]',emailData.billing_pincode ? emailData.billing_pincode : emailData.zip_code)
            .replace('[BILLINGCOUNTRY]',emailData.billing_country ? emailData.billing_country : emailData.country);
        }
        // Prepare the email data
        const data = qs.stringify({
            'to': user.email,
            'subject': template_subject,
            'msg_detail': emailContent,
        });

        // Configure and send the email
        const config = {
            method: 'post',
            url: `${process.env.SITE_URL}send_mail_node_api`,
            data: data
        };

        const response = await axios(config);
        console.log('Email sent:', response.data);
        return response;
    } catch (error) {
        console.error('Error sending email:', error);
    }
}

module.exports = {
    sendEmail
};