
// ccavenueRoutes.js
const express = require('express');
const router = express.Router();
const ccavenueController = require('../controllers/paymentController');
const authMiddleware = require('../../apps/middleware/auth.js');


router.post('/initiate-payment',authMiddleware,ccavenueController.initiatePayment );
router.post('/payment-response',ccavenueController.handleResponse);
router.post('/cancel-payment',ccavenueController.cancelPayment);

//testing only
router.post('/initiate-payment-testing',ccavenueController.initiatePayment2 );

//tc
router.post('/insert-order',authMiddleware,ccavenueController.InsertOrder);
router.post('/verify-payment', ccavenueController.VerifyPayment);


module.exports = router;