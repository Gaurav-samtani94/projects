const express = require('express');
const authMiddleware = require('../../apps/middleware/auth.js');
const Router = express.Router();
const userController = require('../../apps/controllers/UserController');
// const CronJobController = require('../../apps/controllers/CronJobController');
const authMiddlewareadmin = require('../middleware/adminauth');
const MasterController = require("../controllers/master/MasterController");
const SeoController = require("../controllers/master/Seocontroller");
const MasterApiController = require("../controllers/master/MasterApiController");
const ReturnOrderController = require("../controllers/master/ReturnOrderController");
const BackendApiController = require("../controllers/master/BackendApiController");
const ProductController = require("../controllers/product/ProductController");
const ccavReqHandler = require('../ccavenue/ccavRequestHandler.js');
const ccavResHandler = require('../ccavenue/ccavResponseHandler.js');
const ProductCollectionController = require("../controllers/ProductCollectionController");
const sessionTrack = require('../../apps/middleware/sessionAuth.js');
const OfferController = require('../controllers/master/OfferController.js')
const urlencodedParser = express.urlencoded({ extended: false });

const ColectionController = require('../controllers/product/ColectionController.js')
const MembershipController = require('../../apps/controllers/MembershipController');
// Create a new user 
Router.post('/user-login', urlencodedParser, userController.userlogin); // Use userController.createUser

// Router.post('/user-details-edit', authMiddleware, userController.userdetails);
// Router.put('/user-details-update', authMiddleware, userController.userdetails_update);
// Router.post('/change-password', authMiddleware, userController.changepassword);
// Router.post('/user-logout', authMiddleware, userController.userlogout);

// Router.post('/send-mail', CronJobController.sendMail);
// Router.post('/send-mail-temp', CronJobController.sendMail_temp);
// Router.get('/download-file', CronJobController.download_file);

//ceterlize master routes by abhimanyu start
// Router.get('/country-list', authMiddleware, MasterController.GetcountryList);
// Router.post('/state-list', authMiddleware, MasterController.GetstateList);
// Router.post('/city-list', authMiddleware, MasterController.GetcityList);
// Router.get('/currency-list', authMiddleware, MasterController.GetcurrencyList);
// Router.get('/prefix-list', authMiddleware, MasterController.GetprefixList);
// Router.get('/timezones-list', authMiddleware, MasterController.GettimezonesList);

////////////////////////////////////////  Pooja Code Start  ////////////////////////////////////////

Router.post('/user-register', urlencodedParser, userController.userRegister);
Router.post('/edit-user-profile', urlencodedParser, authMiddleware, userController.EditUserProfile);
Router.get('/user-profile', urlencodedParser, authMiddleware, userController.UserProfile);
Router.post('/change-password', urlencodedParser, authMiddleware, userController.changePassword);
Router.post('/forgot-password', urlencodedParser, userController.forgotPassword);
Router.post('/reset-password', urlencodedParser, userController.resetPassword);
Router.post('/user-login-app', urlencodedParser, userController.userloginApp);
Router.post('/verify-login-otp', urlencodedParser, userController.verifyLoginOtp);
Router.post('/resend-otp', urlencodedParser, userController.resendOtp);
Router.post('/expire-otp', urlencodedParser, userController.expireOtp);
Router.post('/send-mobile-verify-otp', urlencodedParser, authMiddleware, userController.sendMobileNumberVerifyOtp);
Router.post('/verify-mobile-otp', urlencodedParser, authMiddleware, userController.verifyMobileNumberOtp);

Router.post('/user-inactive', urlencodedParser, userController.UserInactive);


Router.get('/gender-list', urlencodedParser, MasterApiController.GetGenderList);
Router.post('/color-list', urlencodedParser, MasterApiController.GetColorList);
Router.get('/currency-list', urlencodedParser, MasterApiController.GetCurrencyList);
Router.get('/size-list', urlencodedParser, MasterApiController.GetSizeList);
Router.post('/menu-list', urlencodedParser, MasterApiController.GetMenuList);
Router.post('/sub-menu-list', urlencodedParser, MasterApiController.GetSubMenuList);
Router.get('/page-list', urlencodedParser, MasterApiController.GetPageList);
Router.get('/prefix-list', urlencodedParser, MasterApiController.GetPrefixList);
Router.get('/timezone-list', urlencodedParser, MasterApiController.GetTimezoneList);
Router.get('/role-list', urlencodedParser, MasterApiController.GetRoleList);
Router.post('/state-list-by-country', urlencodedParser, MasterApiController.GetStateListByCountry);
Router.post('/city-list-by-state', urlencodedParser, MasterApiController.GetCityListByState);
Router.get('/country-list', urlencodedParser, MasterApiController.GetCountryList);
Router.post('/category-list', urlencodedParser, MasterApiController.GetCategoryList);
Router.post('/category-with-parent-list', urlencodedParser, MasterApiController.GetCategoryParentList);
Router.get('/all-category-list', urlencodedParser, MasterApiController.GetAllCategoryList);
Router.get('/tag-list', urlencodedParser, MasterApiController.GetTagList);
Router.get('/sub-category-list', urlencodedParser, MasterApiController.GetSubCategoryList);
Router.get('/search-category-list', urlencodedParser, MasterApiController.GetSearchCategoryList);


//wishlist starts
Router.get('/wishlist', urlencodedParser, authMiddleware, MasterApiController.GetWishlist);
Router.post('/add-wishlist', urlencodedParser, authMiddleware, MasterApiController.AddWishlist);
//wishlist ends

//cart starts
Router.get('/cart', urlencodedParser, authMiddleware, MasterApiController.GetCart);
Router.post('/add-cart', urlencodedParser, authMiddleware, MasterApiController.addToCart);
Router.post('/update-cart', urlencodedParser, authMiddleware, MasterApiController.updateCart);
Router.post('/update-cart-status', urlencodedParser, authMiddleware, MasterApiController.updateCartStatus);
Router.delete('/delete-cart', urlencodedParser, authMiddleware, MasterApiController.DeleteCart);
//cart ends

//user address starts
Router.get('/user-address', urlencodedParser, authMiddleware, MasterApiController.GetUserAddress);
Router.post('/add-user-address', urlencodedParser, authMiddleware, MasterApiController.AddUserAddress);
Router.put('/edit-user-address', urlencodedParser, authMiddleware, MasterApiController.EditUserAddress);
Router.post('/user-address-detail', urlencodedParser, authMiddleware, MasterApiController.GetUserAddressDetail);
Router.delete('/delete-user-address', urlencodedParser, authMiddleware, MasterApiController.DeleteUserAddress);
//user address ends

//wishlist categories starts
Router.get('/wishlist-categories', urlencodedParser, authMiddleware, MasterApiController.GetWishlistCategory);
Router.post('/add-wishlist-category', urlencodedParser, authMiddleware, MasterApiController.AddWishlistCategory);
Router.put('/edit-wishlist-category', urlencodedParser, authMiddleware, MasterApiController.EditWishlistCategory);
Router.delete('/delete-wishlist-category', urlencodedParser, authMiddleware, MasterApiController.DeleteWishlistCategory);
//wishlist categories ends

//user wallet starts
Router.get('/user-wallet', urlencodedParser, authMiddleware, MasterApiController.GetUserWallet);
Router.post('/add-user-wallet', urlencodedParser, authMiddleware, MasterApiController.AddUserWallet);
Router.put('/edit-user-wallet', urlencodedParser, authMiddleware, MasterApiController.EditUserWallet);
Router.delete('/delete-user-wallet', urlencodedParser, authMiddleware, MasterApiController.DeleteUserWallet);
//user wallet ends

//static page starts
Router.get('/static-page/:slug', urlencodedParser, MasterApiController.GetStaticPage);
//static page ends

//product starts
Router.get('/product', urlencodedParser, MasterApiController.GetProduct);
Router.post('/add-product', urlencodedParser, authMiddleware, MasterApiController.AddProduct);
Router.put('/edit-product', urlencodedParser, authMiddleware, MasterApiController.EditProduct);
Router.delete('/delete-product', urlencodedParser, authMiddleware, MasterApiController.DeleteProduct);
//product ends

//query starts
Router.post('/add-query', urlencodedParser, MasterApiController.AddQuery);
//query ends

//coupon starts
Router.post('/get-coupon', urlencodedParser, MasterApiController.GetCoupon);
Router.post('/get-product-coupon', urlencodedParser, MasterApiController.GetProductCoupon);
Router.post('/apply-coupon', urlencodedParser, authMiddleware, MasterApiController.ApplyCoupon);
Router.post('/remove-coupon', urlencodedParser, authMiddleware, MasterApiController.RemoveCoupon);

Router.get('/get-all-coupon', urlencodedParser, authMiddleware, MasterApiController.GetAllCoupon);
//coupon ends

//wallet main starts
Router.post('/add-wallet-main', urlencodedParser, authMiddleware, MasterApiController.AddWalletMain);
//wallet main ends

//seo starts
Router.post('/get-seo-meta', urlencodedParser, MasterApiController.GetSeo);
//seo ends

Router.post('/new-arrivals', urlencodedParser, MasterApiController.GetNewArrivals);
Router.post('/all-new-arrivals', urlencodedParser, MasterApiController.GetAllNewArrivals);
Router.get('/about-us', urlencodedParser, MasterApiController.AboutUs);
Router.get('/home-slider-list', urlencodedParser, MasterApiController.GetHomeSliderList);
Router.get('/home-section-list', urlencodedParser, MasterApiController.GetHomeSectionList);
Router.get('/get-home-gift-visits', urlencodedParser, MasterApiController.GetHomeGiftVisits);
Router.get('/get-home-grid-visits', urlencodedParser, MasterApiController.GetHomeGridVisits);
Router.post('/contact-us', urlencodedParser, MasterApiController.AddContactUs);
Router.get('/shop-by-category', urlencodedParser, MasterApiController.ShopByCategory);
Router.post('/get-trending-products-by-category', urlencodedParser, MasterApiController.GetTrendingProductsByCategoryId);
Router.post('/get-product-detail/:slug', urlencodedParser, MasterApiController.GetProductDetail);
Router.post('/get-category-detail/:slug', urlencodedParser, MasterApiController.GetCategoryDetail);
Router.post('/get-gift-product/:slug', urlencodedParser, MasterApiController.GetGiftProduct);
Router.post('/get-all-product', urlencodedParser, MasterApiController.GetAllProduct);
Router.post('/get-filter-product-list', urlencodedParser, MasterApiController.GetFilterProduct);
Router.post('/get-category-product/:slug', urlencodedParser, MasterApiController.GetCategoryProduct);
Router.post('/check-pincode', urlencodedParser, MasterApiController.checkPincode);

Router.post('/material-list', urlencodedParser, MasterApiController.GetMaterialList);
Router.get('/type-list', urlencodedParser, MasterApiController.GetTypeList);

Router.post('/get-menu-data', urlencodedParser, MasterApiController.GetMenuData);

Router.post('/product-you-may-like', urlencodedParser, MasterApiController.GetProductYouMayLike);
Router.get('/get-blog', urlencodedParser, MasterApiController.GetBlog);
Router.get('/get-all-blog', urlencodedParser, MasterApiController.GetAllBlog);
Router.post('/get-blog-detail/:slug', urlencodedParser, MasterApiController.GetBlogDetail);
Router.post('/get-auto-search-product', urlencodedParser, MasterApiController.getSearchAutoProduct);
Router.post('/get-search-keyword-product', urlencodedParser, MasterApiController.GetSearchKeywordProduct);
Router.post('/get-related-product', urlencodedParser, MasterApiController.GetRelatedProduct);

////////////////////////////////////////  Pooja Code End  ///////////////////////////////////////////

/////////////////////////////////////// Madan Code Start //////////////////////////////////////////
// Faq start
Router.post('/get-faq-category', urlencodedParser, BackendApiController.GetFaqCategory);
Router.post('/get-faq-list', urlencodedParser, BackendApiController.GetFaqList);
Router.post('/get-blog-faq', urlencodedParser, SeoController.getblogfaq);
//Faq end

// Get review rating list start
Router.post('/get-user-review-rating', urlencodedParser, MasterApiController.GetUserRaviewRating);
Router.post('/add-review-rating', urlencodedParser, authMiddleware, MasterApiController.AddReviewRating);
Router.post('/user-review-rating-detail', urlencodedParser, authMiddleware, MasterApiController.GetUserReviewRatingDetail);
Router.put('/edit-review-rating', urlencodedParser, authMiddleware, MasterApiController.EditReviewRating);
Router.post('/add-review-like', urlencodedParser, authMiddleware, MasterApiController.AddProductReviewLike);
Router.post('/add-review-dislike', urlencodedParser, authMiddleware, MasterApiController.AddProductReviewDisLike);
// Get review rating list end

// user pay payment start
Router.post('/pay-payment', urlencodedParser, authMiddleware, MasterApiController.PayPayment);
Router.post('/order-shipment-update', urlencodedParser, authMiddleware, MasterApiController.OrderShipmentUpdate);
// user pay payment end

// Get order list start
Router.post('/get-order-list', urlencodedParser, authMiddleware, MasterApiController.GetOrderList);
Router.post('/get-order-details', urlencodedParser, authMiddleware, MasterApiController.GetOrderDetails);
Router.post('/cancel-order', urlencodedParser, authMiddleware, MasterApiController.OrderCancel);
Router.post('/cancel-order-item', urlencodedParser, authMiddleware, MasterApiController.OrderItemCancel);
Router.post('/download-invoice', urlencodedParser, authMiddleware, MasterApiController.DownloadInvoice);
// Get order list end

// get feedback start
Router.get('/get-feedback', urlencodedParser, MasterApiController.GetFeedback);
Router.post('/add-feedback', urlencodedParser, MasterApiController.AddFeedback);
// get feedback end

// Router.post('/initiate-payment', ccavReqHandler.postReq);
// Router.post('/ccavenue-callback', ccavResHandler.postRes);
Router.get('/payment', urlencodedParser, MasterApiController.paymentForm);
Router.post('/cancel-payment', MasterApiController.cancelPayment);
/////////////////////////////////////// Madan Code End /////////////////////////////////////////
Router.post('/shiprocket-login', urlencodedParser, MasterApiController.shiprocketLogin);
Router.post('/shiprocket-pincode-verift', urlencodedParser, MasterApiController.shiprocketPincodeVerify);

Router.get('/get-reward-point', urlencodedParser, authMiddleware, MasterApiController.getRewardPointWallet);
Router.get('/get-reward-history', urlencodedParser, authMiddleware, MasterApiController.getRewardPointHistory);

Router.post('/bulk-order', urlencodedParser, MasterApiController.AddBulkOrderInformation);

Router.get('/get-fourite-color', urlencodedParser, MasterApiController.GetFavouriteColor);
Router.post('/get-best-sell-product', urlencodedParser, MasterApiController.GetBestSellProduct);
Router.post('/get-all-best-sell-product', urlencodedParser, MasterApiController.GetAllBestSellProduct);
Router.post('/get-color-wise-product/:slug', urlencodedParser, MasterApiController.GetColorWiseProduct);

Router.get('/get-gift-category', urlencodedParser, MasterApiController.GetGiftCategory);

Router.get('/customer-support', urlencodedParser, MasterApiController.GetSettingList);

Router.post('/get-combo-product', urlencodedParser, MasterApiController.GetComboProduct);

Router.post('/get-compare-product', urlencodedParser, MasterApiController.GetCompareProduct);

Router.post('/get-product-faq-list', urlencodedParser, MasterApiController.GetProductFaqList);

Router.get('/get-search-keyword-history', urlencodedParser, authMiddleware, MasterApiController.GetSearchKeywordTemplate);
Router.get('/get-user-product-view', urlencodedParser, authMiddleware, MasterApiController.GetUserProductView);
Router.post('/get-first-order-coupon', urlencodedParser, MasterApiController.GetFirstOrderCoupon);
Router.get('/get-trending-keyword', urlencodedParser, MasterApiController.GetTrendingKeywordList);
Router.post('/check-product-stock', urlencodedParser, authMiddleware, MasterApiController.checkProductStock);
Router.post('/get-finest-product', urlencodedParser, MasterApiController.GetFienstProduct);
//get only 10 record
Router.post('/finest-product', urlencodedParser, MasterApiController.GetFienstProducts);

//contact us routes
Router.get('/get-contact-us-query', urlencodedParser, authMiddleware, MasterApiController.GetContactUsQueryList);
Router.post('/add-contact-us', urlencodedParser, authMiddleware, MasterApiController.contactUsAdd);
Router.post('/get-product-color-wise-product', urlencodedParser, MasterApiController.GetProductColorWiseProduct);

Router.post('/cart-gst-update', urlencodedParser, authMiddleware, MasterApiController.cartGSTaddUpdate)
Router.get('/cart-gst-detail', urlencodedParser, authMiddleware, MasterApiController.cartGSTDetail)

//product list sort by discount in descending order
Router.post('/get-discounted-products', urlencodedParser, MasterApiController.GetProductsByDiscount);
Router.post('/get-big-saving', urlencodedParser, MasterApiController.GetProductsBigSaving);

// get searchable data
Router.post('/get-search-data', urlencodedParser, authMiddleware, MasterApiController.getSearchData);

Router.post('/product-discount-list', urlencodedParser, MasterApiController.GetProductsDiscountList);

Router.get('/get-attribute-type-list', urlencodedParser, MasterApiController.GetAttributeTypeList);
Router.post('/get-primary-variant-attribute', urlencodedParser, MasterApiController.GetPrimaryVariantAttribute);
Router.post('/get-variant-wise-attribute', urlencodedParser, MasterApiController.getVariantWiseAttribute);

Router.post('/add-product-notify', urlencodedParser, authMiddleware, MasterApiController.AddProductNotify);
Router.get('/get-gst-information', urlencodedParser, authMiddleware, MasterApiController.GetGstInformation);

Router.post('/get-best-sell-product-wise', urlencodedParser, MasterApiController.GetBestSellProductWise);

Router.post('/get-menu-all-category-product/:slug', urlencodedParser, MasterApiController.GetMenuAllCategoryProduct);

Router.post('/get-country-by-ip', urlencodedParser, MasterApiController.GetCountryByIP);

Router.post('/product-type-list', urlencodedParser, MasterApiController.GetProductTypeList);

Router.get('/get-sitemap', urlencodedParser, MasterApiController.GetSitemap);

Router.post('/get-cart-amount-detail', urlencodedParser, authMiddleware, MasterApiController.GetCartAmountDetail);
Router.post('/buy-now', urlencodedParser, authMiddleware, MasterApiController.buyNow);
Router.post('/remove-buy-now', urlencodedParser, authMiddleware, MasterApiController.removeBuyNow);
Router.post('/apply-reward-point', urlencodedParser, authMiddleware, MasterApiController.applyRewardPoint);
Router.post('/remove-reward-point', urlencodedParser, authMiddleware, MasterApiController.removeRewardPoint);
Router.post('/update-product-discount', urlencodedParser, authMiddleware, MasterApiController.updateProductWiseDiscount);
Router.get('/get-cart-amount-list', urlencodedParser, authMiddleware, MasterApiController.GetCartAmountList);

Router.post('/remove-apply-first-order-coupon', urlencodedParser, authMiddleware, MasterApiController.removeFirstOrderCoupon)
Router.post('/add-order-history', urlencodedParser, authMiddleware, MasterApiController.addOrderHistory)


Router.post('/ccavenue-payment', urlencodedParser, authMiddleware, MasterApiController.CcavenuePayment)

Router.get('/query-list', urlencodedParser, MasterApiController.GetQueryList);

Router.get('/homepage-sections', MasterApiController.getHomepageSections)


Router.get('/dummy-user-insert', urlencodedParser, MasterApiController.InsertDummyUser);

Router.get('/get-order-coupon', urlencodedParser, MasterApiController.GetOrderCoupon);

//abhimanyu start
Router.post('/get-home-product', urlencodedParser, ProductController.GethHomePRoduct);
Router.post('/get-more-product', urlencodedParser, ProductController.Getmoreproduct);
Router.post('/get-category-products/:slug', urlencodedParser, ProductController.GetCategoryDetail);
Router.post('/get-color-wise-products/:slug', urlencodedParser, ProductController.GetColorWiseProduct);
Router.post('/get-search-keyword-products', urlencodedParser, ProductController.GetSearchKeywordProduct);
Router.post('/applies-coupon', urlencodedParser, authMiddleware, ProductController.ApplyCoupon);
//abhimanyu end
Router.post('/product-collection', urlencodedParser, ProductCollectionController.ProductCollections);
Router.post('/collection-product:id', urlencodedParser, ProductCollectionController.CollectionsProductList);


//cody by Himanshu Sharan
Router.post('/send-email-otp', urlencodedParser, userController.sendEmailVerifyOtp);
Router.post('/verify-email-otp', urlencodedParser, userController.verifyEmail);


Router.post('/offers', urlencodedParser, OfferController.listOffers)

Router.get('/get-instagram-media', urlencodedParser, MasterApiController.GetInstagramMedia)

// code by tc
Router.get('/theme-setting-active', MasterApiController.ThemeSettingActive);

Router.get('/home-collection-master-list', urlencodedParser, ColectionController.HomeCollectionMasterList)
Router.post('/collection-product-list/:slug', urlencodedParser, ColectionController.GetCategoryDetail)

Router.post('/get-track-order', urlencodedParser,authMiddleware, MasterApiController.GetTrackOrder)
Router.post('/order-return-request', urlencodedParser,authMiddleware, ReturnOrderController.OrderReturnRequest)
Router.post('/order-return-summery', urlencodedParser,authMiddleware, ReturnOrderController.GetOrderListByOrderId)
Router.get('/order-return-reason', urlencodedParser,authMiddleware, ReturnOrderController.GetReturnResonsList)
// Router.get('/bank-detail', urlencodedParser,authMiddleware, ReturnOrderController.GetBankDetailList)


Router.get('/get-membership-details', urlencodedParser, MembershipController.getMembershipDetails);

//ishpreet
Router.post('/app-banner', urlencodedParser, MasterApiController.AppBanner);


Router.get('/customer-stories', urlencodedParser, MasterApiController.GetCustomerStories);

module.exports = Router;





