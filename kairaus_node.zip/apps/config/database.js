const { Sequelize } = require('sequelize');
const sequelize = new Sequelize({
    dialect: 'mysql', // Change this to your database dialect
	// host: '202.131.122.249',
    // username: 'storepedia_test',
    // password: 'A1t2g1425!@$',
    // database: 'storepedia',

    host: 'localhost',
    username: 'root',
    password: '',
    database: 'kairaus',
    
    timezone: '+05:30',
    define: {
        timestamps: false, // Sequelize will enable timestamps by default
    },
});

module.exports = sequelize;
