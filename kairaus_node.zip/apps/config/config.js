require('dotenv').config();

module.exports = {
  ccavenue: {
    merchantId: process.env.MERCHANT_ID,
    accessCode: process.env.ACCESS_CODE,
    workingKey: process.env.WORKING_KEY,
    redirectUrl: process.env.REDIRECT_URL,
    cancelUrl: process.env.CANCEL_URL
  }
};
