const express = require('express');
const invertoryAuth = require('../../apps/middleware/inventoryauth');

const InventoryRouter = express.Router();
const InventoryController = require('../controllers/inventory/InventoryController.js')
const InventoryUserController = require('../controllers/inventory/inventoryUserController.js')
const urlencodedParser = express.urlencoded({ extended: false });



//login route by tc
InventoryRouter.post('/login-app', urlencodedParser, InventoryUserController.userloginApp);
InventoryRouter.post('/login-verify-otp', urlencodedParser, InventoryUserController.verifyLoginOtp);
InventoryRouter.post('/expire-otp', urlencodedParser,InventoryUserController.expireOtp);
// barcode route
InventoryRouter.post("/barcode-check", invertoryAuth,urlencodedParser, InventoryController.BarCodeCheck)

InventoryRouter.get('/vendor-list',invertoryAuth,InventoryController.GetVendorList);
InventoryRouter.get('/store-location-list',invertoryAuth,InventoryController.GetStoreLocationList);
InventoryRouter.post('/product-list',invertoryAuth,InventoryController.ProdectListWithRelation)
InventoryRouter.get('/seller-platform',invertoryAuth,InventoryController.SellerPlatformList)
// InventoryRouter.get('/product-qnty',invertoryAuth,InventoryController.ProductQuatintieList)
InventoryRouter.post('/add-product-purchase',urlencodedParser,invertoryAuth,InventoryController.addProductPurchase)
InventoryRouter.post('/product-qnt-list',urlencodedParser,invertoryAuth,InventoryController.GetproductQuantyList)

InventoryRouter.post('/inventory-order-details',urlencodedParser,invertoryAuth,InventoryController.InventroyOrderdetails)

InventoryRouter.post('/inventory-order',urlencodedParser,invertoryAuth,InventoryController.InventroyOrder)
InventoryRouter.get('/order-list',urlencodedParser,invertoryAuth,InventoryController.GetorderList)
InventoryRouter.post('/get-order-report', urlencodedParser,invertoryAuth, InventoryController.GetOrderReport);
InventoryRouter.get('/get-law-qty-report', urlencodedParser,invertoryAuth, InventoryController.GetInvtLawQuantityReport);
module.exports = InventoryRouter