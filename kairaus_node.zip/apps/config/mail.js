const nodemailer = require('nodemailer');
require('dotenv').config();
const handlebars = require('handlebars');
const puppeteer = require('puppeteer');
const fs = require('fs');

const transporter = nodemailer.createTransport({
    host: process.env.MAIL_HOST,
    port: process.env.MAIL_PORT,
    secure: false, // true for 465, false for other ports// Use your email service provider
    auth: {
        user: process.env.MAIL_USER,
        pass: process.env.MAIL_PASS,
    }
});

function mailOptions(to, subject, text, html) {
    return {
        from: process.env.MAIL_FROM,
        to: to,
        subject: subject,
        text: text,
        html: html,
        mailtype: 'html',
        newline: 'crlf',
        wordwrap: true, // Set line separator to CRLF
        charset: 'UTF-8'
    };
}
function sendDynamicEmail(to, subject, text, html) {
    const mailOption = mailOptions(to, subject, text, html);
    transporter.sendMail(mailOption, (error, info) => {
        if (error) {
            console.error('Email sent: ', error);
            // reject(error);
        } else {
            console.log('Email sent Ash: ' + info.response);
            // resolve(info.response);
        }
    });
}
// function sendDynamicEmail(to = null, subject = null, text = null, html = null) {
//     const mailOptions = {
//         from: 'Business@growthgrids.com', // Or you can use a hardcoded email address here
//         to: 'sabhimanyu336@gmail.com',
//         subject: subject,
//         // text: text,
//         // html: html
//     };
//     console.log('Attempting to send email:', mailOptions);

//     return new Promise((resolve, reject) => {
//         transporter.sendMail(mailOptions, (error, info) => {
//             if (error) {
//                 console.error('Error sending email:', error);
//                 reject(error);
//             } else {
//                 console.log('Email sent successfully:', info.response);
//                 resolve(info.response);
//             }
//         });
//     });
// }


function loadTemplate(templatePath, replacements) {
    const template = fs.readFileSync(templatePath, 'utf8');
    const compiledTemplate = handlebars.compile(template);
    return compiledTemplate(replacements);
}

function sendEmailWith_temp(to, subject = null, body = null, templatePath, dynamicData) {
    const mailOptions = {
        from: process.env.MAIL_FROM,
        to,
        subject,
        html: loadTemplate(templatePath, dynamicData),
    };
    return new Promise((resolve, reject) => {
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error('Email not sent: ', error);
                reject(error);
            } else {
                console.log('Email sent: ' + info.response);
                resolve(info.response);
            }
        });
    });
}

async function generatePDFAndSendEmail(recipient, subject, body, templatePath, invoiceData) {
    try {
        // Launch Puppeteer
        const browser = await puppeteer.launch({ headless: "new", executablePath: '/usr/bin/google-chrome' });
        const page = await browser.newPage();

        // Set content of the page to the HTML template
        const htmlContent = loadTemplate(templatePath, invoiceData);
        await page.setContent(htmlContent);

        // Generate PDF
        const pdfBuffer = await page.pdf();

        // Close Puppeteer
        await browser.close();

        // Send email with PDF attachment
        sendEmailWithAttachment(recipient, subject, body, pdfBuffer);
    } catch (error) {
        console.error('Error occurred:', error);
    }
}

function sendEmailWithAttachment(recipient, subject, body, attachment) {
    // Email options
    const mailOptions = {
        from: process.env.MAIL_FROM,
        to: recipient,
        subject: subject,
        html: body,
        attachments: [{ filename: 'invoice.pdf', content: attachment }],
        mailtype: 'html',
        // Configure word wrap
        wordwrap: true,
    };

    // Send email
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error occurred:', error);
        } else {
            console.log('Email sent:', info.response);
        }
    });
}

module.exports = { sendDynamicEmail, sendEmailWith_temp, generatePDFAndSendEmail };