import React, { useState, useRef } from "react";

const FileUpload = () => {
  const [progress, setProgress] = useState(0); // To track the upload progress
  const [uploadStatus, setUploadStatus] = useState(""); // To display success or error message
  const fileInputRef = useRef(null); // Reference for file input

  const uploadFile = () => {
    const file = fileInputRef.current.files[0]; // Get the selected file
    if (!file) return; // Return if no file is selected

    const formData = new FormData();
    formData.append("file", file);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "localhost:3010/api/user/upload"); // Your backend endpoint for file upload

    // Track upload progress
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        const percentComplete = (event.loaded / event.total) * 100;
        setProgress(percentComplete); // Update the progress state
      }
    };

    // Handle successful upload
    xhr.onload = function () {
      if (xhr.status === 200) {
        setUploadStatus("File uploaded successfully!");
      } else {
        setUploadStatus("File upload failed.");
      }
    };

    // Handle errors
    xhr.onerror = function () {
      setUploadStatus("An error occurred during the file upload.");
    };

    // Send the file
    xhr.send(formData);
  };

  return (
    <div>
      <form id="uploadForm" encType="multipart/form-data">
        <input type="file" ref={fileInputRef} />
        <button type="button" onClick={uploadFile}>
          Upload
        </button>
        <progress id="progressBar" value={progress} max="100"></progress>
        <span>{progress.toFixed(2)}% uploaded</span>
        {uploadStatus && <div>{uploadStatus}</div>}
      </form>
    </div>
  );
};

export default FileUpload;
