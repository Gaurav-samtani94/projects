import React from "react";
import axios from "axios";

const Checkout = () => {
  // Load Razorpay script dynamically
  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  // Trigger Razorpay checkout
  const displayRazorpay = async () => {
    const scriptLoaded = await loadRazorpayScript();
    if (!scriptLoaded) {
      alert("Razorpay SDK failed to load. Are you online?");
      return;
    }
  
    // Fetch order data from backend
    const response = await axios.post(
      "https://demo1.growthgrids.com/payment/insert-order",
      new URLSearchParams({
        address_id: '256', // Replace with dynamic address
        // buy_now: 'buy_now' // Replace with actual value
      }), {
        headers: {
          'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NDg1LCJyb2xlX2lkIjoyLCJpYXQiOjE3MzAzNDkyNjIsImV4cCI6MTczMjk0MTI2Mn0.-1N9kjQuGmuaM5EwhsCt_Tnd4BgbAWrhvTS7INgqzTc', // Authorization header
          'Content-Type': 'application/x-www-form-urlencoded', // Content-Type header
        }
      }
    );
  
    const { Razorpay, data } = response.data;
  
    if (!Razorpay || !data) {
      alert("Failed to create order");
      return;
    }
  
    // Razorpay payment options
    const options = {
      key: "rzp_test_IvLwYTHVDXrpFz",
      amount: Razorpay.amount,
      currency: Razorpay.currency,
      name: "Kairaus",
      description: "Test Transaction",
      order_id: Razorpay.id,
      handler: function (paymentResponse) {
        console.log("Payment successful", paymentResponse);
        
        const paymentData = {
          razorpay_order_id: Razorpay.id,
          razorpay_payment_id: paymentResponse.razorpay_payment_id,
          razorpay_signature: paymentResponse.razorpay_signature,
        };
  
        // Verify the payment on the backend
        axios
          .post("https://demo1.growthgrids.com/payment/verify-payment", paymentData)
          .then((res) => {
            if (res.data.status === "success") {
              // Redirect to success page
              window.location.href = "/success";
            } else {
              // Redirect to failure page if payment verification failed
              window.location.href = "/failed";
            }
          })
          .catch((err) => {
            console.error("Payment verification failed", err);
            // Redirect to failure page if an error occurs
            window.location.href = "/failed";
          });
      },
      theme: {
        color: "#d63384",
      },
    };
  
    const paymentObject = new window.Razorpay(options);
    paymentObject.open();
  };
  
  return <button onClick={displayRazorpay}> NPayow</button>;
};

export default Checkout;