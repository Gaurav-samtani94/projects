const express = require('express');
const app = express();
const path = require('path');
const PORT = 3012;
const fs = require('fs').promises;
const axios = require('axios');

// Optional: Retry axios requests to handle transient errors
// const axiosRetry = require('axios-retry');
// axiosRetry(axios, { retries: 3 });

async function fetchSitemap() {
  try {
    console.log('Fetching sitemap...');
    const response = await axios.get('https://api.kairaus.com/api/user/get-sitemap', {
      timeout: 10000 // Increase timeout
    });
    console.log('Response received:', response.data);

    if (response.status === 200 && response.data.status === '1') {
      const { baseUrl, fileNames } = response.data;
      const buildDir = path.join(__dirname, 'build');

      // Ensure the build directory exists
      await fs.mkdir(buildDir, { recursive: true });

      // Use Promise.all to handle multiple file downloads concurrently
      const filePromises = fileNames.map(async (val) => {
        try {
          const filePath = path.join(buildDir, val.fileName);
          const fileUrl = baseUrl + val.fileName;
          const fileResponse = await axios.get(fileUrl, { responseType: 'arraybuffer', timeout: 10000 });
          await fs.writeFile(filePath, fileResponse.data);
        } catch (err) {
          console.error(`Failed to download or save file: ${val.fileName}`, err.message);
        }
      });

      await Promise.all(filePromises); // Wait for all files to be written
      console.log('Sitemap files updated successfully');
    } else {
      console.error('Failed to fetch sitemap data: Invalid status in response');
    }
  } catch (error) {
    console.error('Error updating sitemap files:', error);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
      console.error('Response headers:', error.response.headers);
    } else if (error.request) {
      console.error('Request made but no response received:', error.request);
    } else {
      console.error('Error setting up request:', error.message);
    }
  }
}

// Serve static files from the React build directory
app.use(express.static(path.join(__dirname, 'build'), { maxAge: '300d' }));

app.get('/api/sitemap', async (req, res) => {
  try {
    await fetchSitemap();
    res.status(200).send('Sitemap updated successfully');
  } catch (error) {
    res.status(500).send(`Error updating sitemap: ${error.message}`);
  }
});

app.get('/proxy', async (req, res) => {
  const apiUrl = req.query.url;

  try {
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

    if (response.status !== 200) {
      console.error(`Error: ${response.status} - ${response.statusText}`);
      res.status(response.status).send('Internal Server Error');
      return;
    }

    const contentType = response.headers['content-type'];
    const fileName = path.basename(apiUrl); // Extract file name from URL

    // Set the appropriate response headers
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename=${encodeURIComponent(fileName)}`);

    // Send the binary data
    res.send(response.data);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Internal Server Error');
  }
});

const indexPath = path.resolve(__dirname, 'build', 'index.html');

app.get('*', async (req, res) => {
  // Serve XML files if the request is for an XML file
  if (req.url.includes('.xml')) {
    const parts = req.url.split('/');
    console.log('URL parts:', parts);  // Log the parts array
    if (parts.length === 2) {
      const filePath = path.join(__dirname, 'build', parts[1]);
      console.log('Serving XML file from path:', filePath);
      res.set('Content-Type', 'application/xml');
      res.sendFile(filePath, (err) => {
        if (err) {
          console.error('Error sending file:', err.message);
          res.status(500).send('Error serving XML file');
        }
      });
    } else {
      console.error('Invalid URL structure:', req.url);
      res.status(400).send('Invalid URL structure');
    }
    return; // Exit the handler after serving the XML file or handling the error
  }

  // Serve index.html for all other routes
  try {
    const htmlData = await fs.readFile(indexPath, 'utf8');
    res.send(htmlData);
  } catch (error) {
    console.error('Error reading index.html:', error.message);
    res.status(500).send('Error serving HTML file');
  }
});

app.listen(PORT, (error) => {
  if (error) {
    return console.log('Error during app startup', error);
  }
  console.log(`Listening on ${PORT}...`);
});