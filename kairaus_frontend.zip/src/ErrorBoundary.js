import React, { Component } from 'react';

class ErrorBoundary extends Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError(error) {
        // Update state to trigger componentDidUpdate
        return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
        // Log the error if needed
        console.error('Error caught:', error, errorInfo);
    }

    componentDidUpdate(prevProps, prevState) {
        // When an error occurs, reload the page
        if (this.state.hasError && !prevState.hasError) {
            window.location.reload();
        }
    }

    render() {
        // Just render children normally
        return this.props.children;
    }
}

export default ErrorBoundary;