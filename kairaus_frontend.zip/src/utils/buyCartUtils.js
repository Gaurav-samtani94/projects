// src/utils/cartUtils.js
import { useSelector } from "react-redux";

const CalculateTotalsBuy = () => {
  const buy = useSelector((state) => state.buy);
  console.log()
  const {coupon_type,type_val,coupon_code} = useSelector((state) => state.coupon);
  const rewardSlice = useSelector((state) => state.reward);
  const {currencySymbol,currencyCode} = useSelector(state => state.excrate);
  const filteredCartData = buy.filter((product) =>product.isChecked);

  const buyLength = filteredCartData?.length;  // console.log('filteredCartData',filteredCartData);

  let firstOrderCouponDetail = localStorage.getItem('FirstOrderCouponDetails');
  firstOrderCouponDetail = JSON.parse(firstOrderCouponDetail);

  const total = filteredCartData.reduce(
    (accumulator, { compare_price = 0,usd_price=0,usd_compare_price=0, price = 0, count = 0, newPrice=0 }) => {
      const effectivePrice = newPrice || price;
      accumulator.totalComparePrice += currencyCode === "INR" ?(compare_price > 0 ? compare_price : effectivePrice) * count:(usd_compare_price > 0 ? usd_compare_price : usd_price) * count;
      accumulator.totalPrice += currencyCode === "INR" ?effectivePrice * count:usd_price * count;
      accumulator.totalCount += count;

  return accumulator;
},
{ totalPrice: 0, totalComparePrice: 0, totalCount: 0 }
  );

  const bagDiscount = total.totalComparePrice - total.totalPrice;

  let totalPrice = 0;
  let firstOrderCouponDiscount=0;
  let isCouponTypePercent=firstOrderCouponDetail?.data?.coupon_type === "percent";
  let firstOrderCouponValue=firstOrderCouponDetail?.data?.type_val;
  

if (firstOrderCouponDetail?.order_count === 0 && isCouponTypePercent) { // Case of first order
     firstOrderCouponDiscount = total.totalPrice * (firstOrderCouponValue / 100);
    totalPrice = total.totalPrice - firstOrderCouponDiscount;
} else {
    totalPrice = total.totalPrice;
}

  let disAmount = 0;
  if (coupon_type) {
    if (coupon_type === 'percent') {
      const amountOfPercent = type_val / 100;
      disAmount = totalPrice * amountOfPercent;
    } else if (coupon_type === 'normal') {
      disAmount = type_val;
    }
  }
  const rewardAmnt = total.totalPrice > 0 ? rewardSlice || 0 : null;
  let grandTotal = totalPrice - disAmount - (rewardAmnt > 0 ? rewardAmnt : 0);
  grandTotal = grandTotal > 1000 ? grandTotal : grandTotal+70
  let savingAmnt = bagDiscount + disAmount + (rewardAmnt > 0 ? rewardAmnt : 0)
  savingAmnt += firstOrderCouponDiscount > 0 ? firstOrderCouponDiscount : 0;

  return {
    total,
    disAmount,
    grandTotal,
    cartLength: buyLength,
    filteredCartData,
    bagDiscount,
    rewardAmnt,
    savingAmnt,
    firstOrderCouponDiscount,
    isCouponTypePercent,
    firstOrderCouponValue,
    currencySymbol,
    coupon_code
  };
};

export default CalculateTotalsBuy;