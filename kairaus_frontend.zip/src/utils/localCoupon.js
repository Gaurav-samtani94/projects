// src/utils/cartUtils.js
import { useSelector } from "react-redux";

const CouponDiscount = () => {
  const cart = useSelector((state) => state.cart);
  const {coupon_type,type_val,coupon_code} = useSelector((state) => state.localCoupon);

  const filteredCartData = cart.filter((product) =>product.isChecked);
  let firstOrderCouponDetail = localStorage.getItem('FirstOrderCouponDetails');
  firstOrderCouponDetail = JSON.parse(firstOrderCouponDetail);

  const total = filteredCartData.reduce(
    (accumulator, { compare_price = 0, price = 0, count = 0, newPrice=0 }) => {
      const effectivePrice = newPrice || price;
      accumulator.totalComparePrice += (compare_price > 0 ? compare_price : effectivePrice) * count;
      accumulator.totalPrice += effectivePrice * count;
      accumulator.totalCount += count;

  return accumulator;
},
{ totalPrice: 0, totalComparePrice: 0, totalCount: 0 }
  );

  let totalPrice = 0;
  let firstOrderCouponDiscount=0;
  let isCouponTypePercent=firstOrderCouponDetail?.data?.coupon_type === "percent";
  let firstOrderCouponValue=firstOrderCouponDetail?.data?.type_val;
  

if (firstOrderCouponDetail?.order_count === 0 && isCouponTypePercent) { // Case of first order
     firstOrderCouponDiscount = total.totalPrice * (firstOrderCouponValue / 100);
    totalPrice = total.totalPrice - firstOrderCouponDiscount;
} else {
    totalPrice = total.totalPrice;
}

  let disAmount = 0;
  if (coupon_type) {
    if (coupon_type === 'percent') {
      const amountOfPercent = type_val / 100;
      disAmount = totalPrice * amountOfPercent;
    } else if (coupon_type === 'normal') {
      disAmount = type_val;
    }
  }
  let couponDiscount = disAmount


  return {
    couponDiscount,
  };
};

export default CouponDiscount;