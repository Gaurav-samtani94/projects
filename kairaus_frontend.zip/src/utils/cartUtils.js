// src/utils/cartUtils.js
import { useSelector } from "react-redux";

const CalculateTotals = () => {
  const cart = useSelector((state) => state.cart);
  const buy = useSelector((state) => state.buy);

  const localDataManage = buy?.length>0 ? buy : cart
  const rewardSlice = useSelector((state) => state.reward);
  const { currencySymbol, currencyCode } = useSelector(state => state.excrate);
  const filteredCartData = localDataManage.filter((product) => product.isChecked);

  const cartLength = filteredCartData.length;  // console.log('filteredCartData',filteredCartData);

  let firstOrderCouponDetail = JSON.parse(localStorage.getItem('appliedCoupons'));

  const total = filteredCartData.reduce(
    (accumulator, { compare_price = 0, usd_price = 0, usd_compare_price = 0, price = 0, count = 0, newPrice = 0 }) => {
      const effectivePrice = newPrice || price;
      accumulator.totalComparePrice += currencyCode === "INR" ? (compare_price > 0 ? compare_price : effectivePrice) * count : (usd_compare_price > 0 ? usd_compare_price : usd_price) * count;
      accumulator.totalPrice += currencyCode === "INR" ? effectivePrice * count : usd_price * count;
      accumulator.totalCount += count;

      return accumulator;
    },
    { totalPrice: 0, totalComparePrice: 0, totalCount: 0 }
  );

  const bagDiscount = total.totalComparePrice - total.totalPrice;

  let totalPrice = 0;
  let firstOrderCouponDiscount = 0;
  let isCouponTypePercent = firstOrderCouponDetail?.coupon_type === "percent";
  let firstOrderCouponValue = firstOrderCouponDetail?.type_val;
  


  if (firstOrderCouponDetail?.isApplied && isCouponTypePercent) { // Case of first order
    firstOrderCouponDiscount = total.totalPrice * (firstOrderCouponValue / 100);
    totalPrice = total.totalPrice
  } else {
    totalPrice = total.totalPrice;
  }

  let totalPriceAdjusted = totalPrice; // Keep the original totalPrice intact
  const localCoupons = useSelector((state) => state.localCoupon);
  // const coupon_code = localCoupons.map(coupon => coupon.coupon_code);
  const couponDiscount = localCoupons?.reduce((acc, coupon) => {
    const { coupon_type, type_val } = coupon; // Extract relevant fields from each coupon

    if (coupon_type === 'percent') {
      const amountOfPercent = type_val / 100;
      const discount = totalPriceAdjusted * amountOfPercent; // Calculate discount based on total price
      totalPriceAdjusted -= discount; // Adjust totalPrice for the next iteration
      return acc + discount; // Accumulate the discount
    }
    // Uncomment if normal discount logic is needed
    // else if (coupon_type === 'normal') {
    //   const discount = Math.min(type_val, totalPriceAdjusted); // Avoid exceeding the total price
    //   totalPriceAdjusted -= discount; // Adjust totalPrice for the next iteration
    //   return acc + discount; // Accumulate the discount
    // }

    return acc; // Return accumulated discount if no valid type
  }, 0); // Initial accumulator value is 0
  const rewardAmnt = total.totalPrice > 0 ? rewardSlice || 0 : null;

  let grandTotal = Math.round(totalPrice) - Math.round(couponDiscount) - (rewardAmnt > 0 ? rewardAmnt : 0);
  
  grandTotal = grandTotal > 1499 ? grandTotal : grandTotal + (cartLength !=0 ? 99 : 0 );
  let savingAmnt = Math.round(bagDiscount) + Math.round(couponDiscount) + (rewardAmnt > 0 ? rewardAmnt : 0)
  // savingAmnt += firstOrderCouponDiscount > 0 ? firstOrderCouponDiscount : 0;
  // const localCouponCoupon_code = JSON.parse(localStorage.getItem('appliedCoupons'));
  // const firstOrderCouponCode=localCouponCoupon_code.coupon_code;
  // let coupon_code = localCoupons.map(coupon => coupon.coupon_code);
  // coupon_code = coupon_code.filter(code => code !== firstOrderCouponCode);

  // const firstOrderCouponCode = JSON.parse(localStorage.getItem('appliedCoupons')).coupon_code||[];
  const appliedCoupons = JSON.parse(localStorage.getItem('appliedCoupons'));
const coupon_code = localCoupons?.map(coupon => coupon.coupon_code).filter(code => code !== appliedCoupons?.coupon_code)||'';

  // console.log('grandTotal====52',grandTotal);


  return {
    total,
    couponDiscount,
    grandTotal,
    cartLength,
    filteredCartData,
    bagDiscount,
    rewardAmnt,
    savingAmnt,
    firstOrderCouponDiscount,
    isCouponTypePercent,
    firstOrderCouponValue,
    currencySymbol,
    coupon_code
  };
};

export default CalculateTotals;