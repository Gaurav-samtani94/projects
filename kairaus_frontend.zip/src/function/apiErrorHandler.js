import Routes from "../Routes/Routes";

export const handleApiError = (error) => {

  let errorMessage = 'An error occurred. Please try again later.';

  if (error.response && error.response.data && error.response.data.message) {
    errorMessage = error.response.data.message;
  }

  throw new Error(errorMessage);
};