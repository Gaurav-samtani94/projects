// import { useDispatch } from 'react-redux';
// import { applyCoupon } from "../reducers/couponSlice";
// import { clearCart } from "../reducers/cartSlice";
// import { useNavigate } from 'react-router-dom';
// import { applyShipping } from "../reducers/shippingSlice";
// import { addToChip } from "../reducers/filterSlice";
// import { addToUser, clearUser } from "../reducers/userSlice";


// export const logoutUser = () => {
//     console.log('==================logoutUser===================')
//     const dispatch = useDispatch();
//     const navigate = useNavigate();

//     const couponnull = {};
//     const logoutEventTimestamp = Date.now().toString();

//     // Clear local storage
//     localStorage.removeItem("user");
//     localStorage.removeItem("cart");
//     localStorage.removeItem("shippingFees");
//     localStorage.removeItem("FirstOrderCouponDetails");
//     localStorage.removeItem("chips");
//     localStorage.removeItem('maxPrice');
//     localStorage.removeItem('coupon');

//     // Dispatch Redux actions to clear the store
//     dispatch(applyCoupon(couponnull));
//     dispatch(clearUser());
//     dispatch(clearCart());

//     // Custom actions
//     dispatch(applyShipping(null));
//     dispatch(addToChip([]));

//     dispatch(addToUser({ lastLogoutTime: logoutEventTimestamp }));

//     // Update local storage
//     localStorage.setItem("logoutEvent", logoutEventTimestamp);

//     // Redirect to login page
//     navigate('/login');  // Assuming '/login' is your sign-in route
// };



