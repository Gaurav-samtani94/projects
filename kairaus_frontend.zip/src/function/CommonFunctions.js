export const genrateRandomPassword=()=>{

        const upperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const lowerCase = "abcdefghijklmnopqrstuvwxyz";
        const numbers = "0123456789";
        const specialChars = "!@#$%^&*";
        
        const allChars = upperCase + lowerCase + numbers + specialChars;
        
        let password = "";
        
        // Ensure at least one of each required character type is included
        password += upperCase[Math.floor(Math.random() * upperCase.length)];
        password += lowerCase[Math.floor(Math.random() * lowerCase.length)];
        password += numbers[Math.floor(Math.random() * numbers.length)];
        password += specialChars[Math.floor(Math.random() * specialChars.length)];
        
        // Fill the rest of the password up to the minimum length (8)
        for (let i = password.length; i < 8; i++) {
          password += allChars[Math.floor(Math.random() * allChars.length)];
        }
        
        // Shuffle the password to avoid a predictable pattern
        password = password.split('').sort(() => 0.5 - Math.random()).join('');
        
        return password;      
      
}

export const handleKeyPressForMobile = (e) => {
  const key = e.key;
  const value = e.target.value;
  const cursorPosition = e.target.selectionStart;

  // Allow arrow keys, backspace, and tab
  if (key === 'ArrowLeft' || key === 'ArrowRight' || key === 'Backspace' || key === 'Tab') {
    return; // Allow these keys without restriction
  }

  // Prevent the number from starting with zero, even after deleting characters
  if (cursorPosition === 0 && key === '0') {
    e.preventDefault();
    return;
  }

  // Allow only numeric keys (0-9)
  if (!(key >= '0' && key <= '9')) {
    e.preventDefault();
    return;
  }

  // Check if the next value will start with zero
  const nextValue = value.slice(0, cursorPosition) + key + value.slice(cursorPosition);
  if (nextValue.startsWith('0')) {
    e.preventDefault();
  }
};