import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { clearUser } from './reducers/userSlice.js';
import Routes from './Routes/Routes';

const SessionTimeout = () => {
  const sessionTimeout = 30 * 60 * 1000; // 30 minutes in milliseconds
  const warningTime = 2 * 60 * 1000; // 2 minutes in milliseconds
  const [timer, setTimer] = useState(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useEffect(() => {
    const logout = () => {
      // Perform logout actions here, like clearing local storage or sending a logout request to the server
      // Redirect the user to the login page if needed
      localStorage.removeItem('user');
      dispatch(clearUser());
      navigate(Routes.SignIn);
    };

    const resetTimer = () => {
      clearTimeout(timer); // Clear the previous timer
      setTimer(setTimeout(logout, sessionTimeout - warningTime));
    };

    const handleActivity = () => {
      resetTimer();
    };
    const alertWarning = () => {
        alert(`Your session will expire in ${warningTime / 1000} seconds.`);
      };

    const addActivityListeners = () => {
      document.addEventListener('mousemove', handleActivity);
      document.addEventListener('keydown', handleActivity);
      // Add other event listeners as needed
    };

    const removeActivityListeners = () => {
      document.removeEventListener('mousemove', handleActivity);
      document.removeEventListener('keydown', handleActivity);
    };

    addActivityListeners();
    resetTimer();

    return () => {
      removeActivityListeners();
      clearTimeout(timer); // Clear the timer when unmounting
    };

  }, []); // Empty dependency array

  // Remember to return some JSX here if needed
  return null;
}

export default SessionTimeout;
