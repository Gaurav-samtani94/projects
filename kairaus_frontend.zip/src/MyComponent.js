import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation } from 'react-router-dom';
import { getSeoMeta } from './services/seo/seo';
import SchemaMarkup from './components/SchemaMarkup';
import { getAllCategory } from './services/category/categoryApi';
import { useDispatch } from 'react-redux';
import { addToSeo } from './reducers/seoSlice';
import { addToCategory } from './reducers/categorySlice';
import { getProductDetails } from './services/home';

const getBaseUrl = () => {
  const { protocol, hostname, port } = window.location;
  return `${protocol}//${hostname}${port ? `:${port}` : ''}`;
};

const MyComponent = () => {
  const BASE_URL = getBaseUrl();
  const location = useLocation();
  const canonicalUrl = `${BASE_URL}${location.pathname}`;
  const pathParts = useMemo(() => {
    return location.pathname.split('/').filter(Boolean);
  }, [location.pathname]);
  // const pathParts = location.pathname.split('/').filter(Boolean); // Removes any empty strings
  const [headerId, setHeaderId] = useState(null);
  const [imageName, setImageName] = useState(null); 
  // Split the pathname into parts
  useEffect(() => {
    const fetchData = async () => {

      const formData = new URLSearchParams();
      formData.append("user_id", 0);

      try {
        const response = await getProductDetails(pathParts[1], formData);
        // console.log('response',response);
        
        const headerData = response?.data;
        const imagePath = `${response?.path}/${response?.data?.productimages[0].file_name}`;
        setImageName(imagePath); // Set the image path
        setHeaderId(headerData); // Set the headerId in state
      } catch (error) {
        console.error("Error fetching product details:", error);
      }
    }

    if (pathParts.length === 2 && pathParts[0] === 'product') {
      fetchData();
    };
  }, [pathParts]); // Trigger effect when pathname changes

  const [seoData, setSeoData] = useState({
    title: 'Kairaus',
    description: '',
  });
  const dispatch = useDispatch();

  // const handleSeoUpdate = () => {
  //   dispatch(addToSeo({ description: seoData.footer_content }));
  // };
  const slug = window.location.href.split('/');
  const lastSegment = slug[slug.length - 1] || 'home';
  const productType = slug[slug.length - 2];

  useEffect(() => {
    const fetchData = async () => {
      const res_category = await getAllCategory();
      if (res_category.status === "1") {
        dispatch(addToCategory(res_category?.data));
      }
      const slugData = res_category?.data?.map(item => item.slug).filter(Boolean); // Extracting slugs
      const validSegments = new Set(slugData);
      const pageType = validSegments.has(lastSegment) ? 'category' : lastSegment === 'home' ? 'home' : productType === 'product' ? 'product' : productType === 'blog' ? 'blog' : 'menu';
      try {
        const formData = new URLSearchParams();
        formData.append('page_type', pageType);
        formData.append('slug', lastSegment);
        const response = await getSeoMeta(formData);
        if (response.status === '0') {
          dispatch(addToSeo(""));
        }
        if (response.status === '1') {
          setSeoData({
            title: response.data?.title,
            description: response.data?.meta_description,
          });
          dispatch(addToSeo(response.data?.footer_content));

        }
        // Do something with the response, if needed
      } catch (error) {
        console.error('Error fetching seo data:', error);
      }
    };

    fetchData();
  }, [lastSegment]); // Dependency array is empty, meaning this effect runs only once on mount

  function formatCurrency(number, currency = 'USD', locale = 'en-US') {
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(number);
  }

  return (
    <>
      <Helmet>
        {/* //facebook */}
        <meta property="og:type" content="product" />
      {/* //facebook */}
        <meta name="twitter:title" content={seoData.title} />
        <meta name="twitter:description" content={seoData.description} />
        <meta property="og:title" content={seoData.title} />
        <meta property="og:description" content={seoData.description} />
        <title>{seoData.title}</title>
        <meta name="description" content={seoData.description} />
        <link rel="canonical" href={canonicalUrl} />
        {/* // */}
        <meta property="og:price:amount" content={String(headerId?.price)}/>
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:image:secure_url" content={imageName}/>
        <meta property="og:image:width" content="2310" />
        <meta property="og:image:height" content="2735" />
        <meta property="og:price:currency" content="INR" />
        <meta name="twitter:card" content="summary_large_image" />
        {/* <meta name="google-site-verification" content="i25gAO7ldjcQ7U_selC7AyR81SpT818EIghF0H3ult0"/> */}

        <script async src="https://www.googletagmanager.com/gtag/js?id=G-HPKYDJRGM2"></script>
        <script>{`
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-HPKYDJRGM2');
        `}
        </script>
        {/* first script forfacebook connect 1 */}
        {headerId && 
        <>
           <meta property="og:title" content={headerId.product_name} />
           <meta property="og:description" content={headerId?.description?.replace(/<\/?[^>]+(>|$)/g, "")} />
           <meta property="og:image" content={imageName} />
        <script type={`application/ld+json`}>
          {JSON.stringify({
            "@context": "http://schema.org",
            "@type": "Product",
            "id": headerId?.id,
            "name": headerId.product_name, // Added product name for better schema
            "price": headerId?.price,
            "sku": headerId?.sku,
            "image": imageName,
            "description":headerId?.description?.replace(/<\/?[^>]+(>|$)/g, ""),
            "offers": [{
              "@type": "Offer",
              "price": headerId?.price,
              "priceCurrency": "INR",
              "availability": "http://schema.org/InStock",
              "url": canonicalUrl,
            }]
          })}
        </script>
        </>
}

<script type="application/ld+json">
{JSON.stringify({
          "@context": "https://schema.org/", 
          "@type": "Product", 
          "name": "Golden Peaks Ceramic Quarter Plate Set of 2 (7 Inch)",
          "image": "https://img.kairaus.com/uploads/products/product_172042335552718.jpg",
          "description": "Uplift your dining experience with this Small Golden Peaks Ceramic Plate Set. The picturesque angular design of these plates resembles mountain peaks bathed in sunlight. Painted in a subtle yellow colour, they will surely add a fresh and joyful touch to any table setting. Plus, the yellow rims on the plates make them stand out even more. You can use them on a vibrant outdoor brunch party or every day at home. These quarter plates will make your every meal look more appealing and irresistible.",
          "brand": {
            "@type": "Brand",
            "name": "Kairaus"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.5",
            "bestRating": "5",
            "worstRating": "1",
            "ratingCount": "25"
          }
        })}
        </script>
      </Helmet>
      {/* // */}


      {/* Integrate SchemaMarkup component */}
      <SchemaMarkup
        type="ItemList"
        data={{
          itemListElement: [
            { '@type': 'ListItem', position: 1, name: 'Dining', url: 'https://kairaus.com/dining' },
            { '@type': 'ListItem', position: 2, name: 'Home Decor', url: 'https://kairaus.com/home-decor' },
            { '@type': 'ListItem', position: 3, name: 'Home Furnishing', url: 'https://kairaus.com/everyday-essentials' },
            { '@type': 'ListItem', position: 4, name: 'Lifestyle', url: 'https://kairaus.com/gifts' },
            { '@type': 'ListItem', position: 6, name: 'About Us', url: 'https://kairaus.com/about-us' },
            // Add other items here
          ],
        }}
      />
      <SchemaMarkup
        type="Organization"
        data={{
          name: 'Kairaus',
          url: 'https://kairaus.com/',
          logo: 'https://kairaus.com/static/media/KAIRAUS_logo_383x60.03f3be966f2cf9babab5c236103d2672.svg',
          sameAs: [
            "https://www.facebook.com/people/KairausOfficial/61565182179977/",
            "https://x.com/Kairausofficial",
            "https://www.instagram.com/kairaus_official/?hl=en",
            "https://www.youtube.com/@Officialkairaus",
            "https://www.linkedin.com/in/kairausofficial/",
            "https://in.pinterest.com/kairaus_official/"
          ],
        }}
      />
      <SchemaMarkup
        type="WebSite"
        data={{
          name: 'Kairaus',
          url: 'https://kairaus.com/',
          potentialAction: {
            '@type': 'SearchAction',
            target: 'https://kairaus.com/{search_term_string}',
            'query-input': 'required name=search_term_string',
          },
        }}
      />
     
    </>
  );
};

export default MyComponent;
