import React, { useEffect, useState } from 'react';
import { Tabs } from 'antd';
import ProfilePage from '../accountDetails/ProfilePage';
import AddressPage from './AddressPage';
import GstInfo from './GstInfo';
import CouponsPage from '../accountDetails/CouponsPage';
import FavouritePage from './FavouritePage';
import ChangePassword from "./ChangePassword";
import { useLocation, useNavigate } from 'react-router-dom';
import OrderPage from './OrderPages';
import { useSelector } from 'react-redux';
import Routes from '../../Routes/Routes';

function AccountProfile() {
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState('Profile');
    const { userfullname, id } = useSelector((state) => state?.user);
    const location = useLocation();
    const [tabPosition, setTabPosition] = useState("left");

    // Detect screen width and update tab position
    useEffect(() => {
        const updateTabPosition = () => {
            if (window.innerWidth <= 768) {
                setTabPosition("top"); // For tablet and mobile screens
            } else {
                setTabPosition("left"); // For desktop screens
            }
        };

        // Call function on resize and on initial load
        updateTabPosition();
        window.addEventListener("resize", updateTabPosition);

        // Cleanup event listener on component unmount
        return () => window.removeEventListener("resize", updateTabPosition);
    }, []);

    useEffect(() => {
        if (!id) {
            navigate(Routes.SignIn);
        }
        if (location.state && location.state.from) {
            setActiveTab(location.state.from);
        }
        window.scrollTo(0, 0);
    }, [location.state, id, navigate]);

    const handleChange = (key) => {
        setActiveTab(key);
        navigate('', { state: { from: key } });
    };

    const items = [
        {
            key: 'Profile',
            label: <span>Profile</span>,
            children: <ProfilePage />,
        },
        {
            key: 'orders',
            label: <span>My Orders</span>,
            children: <OrderPage />,
        },
        {
            key: 'addresses',
            label: <span>Addresses</span>,
            children: <AddressPage />,
        },
        // {
        //     key: 'gstInfo',
        //     label: <span>GST Information</span>,
        //     children: <GstInfo />,
        // },
        {
            key: 'coupons',
            label: <span>Coupons</span>,
            children: <CouponsPage />,
        },
        {
            key: 'favourites',
            label: <span>Favourites</span>,
            children: <FavouritePage />,
        },
        {
            key: 'changePassword',
            label: <span>Change Password</span>,
            children: <ChangePassword />,
        }
    ];

    return (
        <div className='account_profile'>
            <div className='accounts_pageOrder'>
                <div>
                    <h1>Account</h1>
                    <p>{userfullname}</p>
                </div>
            </div>

            <div className='account_profile_tabs'>
                <div className='account_masterTabs'>
                    <Tabs
                        tabPosition={tabPosition}
                        activeKey={activeTab}
                        items={items}
                        onChange={handleChange}
                    />
                </div>
                <div className="acoountContent_wrapper">
                    {items.find(tab => tab.key === activeTab)?.children}
                </div>
            </div>
        </div>
    );
}

export default AccountProfile;
