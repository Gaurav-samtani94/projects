import React, { useEffect, useState } from 'react';
import { Collapse } from 'antd';
import { couponAllList, getCouponList } from '../../services/coupon/Coupon';
import { useSelector } from 'react-redux';
import dayjs from 'dayjs';
import NoDataimg from '../../assets/images/noData.png'


function CouponsPage() {
    const [couponList, setCouponList] = useState([]);
    const user = useSelector((state) => state.user);

    const fetchCouponsList = async () => {
        try {
            let result = await couponAllList(user.token);
            setCouponList(result?.data);   
        } catch (error) {
            console.log(error)  
        }
       
    }

    useEffect(() => {
        fetchCouponsList();
    }, [])

    const [copied, setCopied] = useState(false);

    const copyCode = (item) => {
        navigator.clipboard.writeText(item.coupon_code);
        setCopied(item);
        // setTimeout(() => {
        //     setCopied(false);
        // }, 3000);
    };



    const showCouponList = () => {

        return couponList?.length > 0 ?
            couponList?.map((item) => {

                return (

                    <div className='multiCoupons_crd' key={`coupons-${item?.id}`}>
                        <div className="coupon-card">
                            <h3>{item?.coupon_desc?.split(' upto ')[0]}
                                {/* <span> Rs{item?.coupon_desc.split(' upto ')[1]?.replace('rs', ' ')}</span> */}
                            </h3>
                            <div className="coupon-row">
                                <span id="cpnCode">{item.coupon_code}</span>
                                <span id="cpnBtn" onClick={() => item.is_expired !== 1 && item.first_order !== 1 && item.is_applied !== 1 && copyCode(item)}  style={{
                                    cursor: item.is_expired === 1 || item.is_applied === 1 || item?.first_order === 1 ? 'not-allowed' : 'pointer',
                                }}>{item.first_order == '1' || item?.is_applied == "1" ? 'OFFER REDEEMED': item.is_expired == '1'? 'EXPIRED': copied === item ? 'COPIED': 'COPY CODE'}</span>
                            </div>
                            <p>Valid Till: {dayjs(item?.to_date).format("DD MMM YYYY")}</p>
                            <div className="circle1"></div>
                            <div className="circle2"></div>
                        </div>
                    </div>
                )
            })
            :
            (
                <div className="noDataCont">
                    <img src={NoDataimg} alt="No Data" />
                    <h5>No Coupon Found</h5>
                </div>
            )
    }

    return (
        <>
            <div className='coupons_pages'>
                <h1>All Coupons</h1>
                <div className='coupons_cards'>
                    {showCouponList()}
                </div>
            </div>
        </>
    )
}

export default CouponsPage