import React, { useState } from 'react';
import { GoogleOAuthProvider, GoogleLogin, useGoogleLogin } from '@react-oauth/google';
import axios from 'axios';
import { addToUser } from '../reducers/userSlice';
import { useDispatch, useSelector } from 'react-redux';
import { signUpData } from '../services/auth/singUp';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import Routes from '../Routes/Routes';
import { addCart, addToBuyDB } from '../services/cart/addCart';
import { getApplyCouponData } from '../services/coupon/applyCoupon';

const GoogleLoginSocial = ({userLogin}) => {
  const navigate = useNavigate()
  const dispatch = useDispatch();
  const client_id_local = '767736904115-tdi0s8o2fmblbo8kj5gm1co28dnq9tmg.apps.googleusercontent.com'
  const client_id_prod = '767736904115-olo1tcrre51990jeo9bn8s0pvheo7p5v.apps.googleusercontent.com'
  const buy = useSelector((state) => state.buy);
  const cart = useSelector((state) => state.cart);
  const excRate = useSelector(state => state.excrate);
  const sCoupon = useSelector(state => state.productCoupon) || "";
  const localCoupons = useSelector((state) => state.localCoupon);
  const handleSuccess = (response) => {
    const token = response.credential;
  
    const base64Url = token.split('.')[1];
    // Decode the Base64URL payload
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  
    const decodedUser = JSON.parse(jsonPayload);  
    if(decodedUser){
      register(base64)
    }
  };



  const applyCouponData=async(userToken)=>{
    
    const coupon_code = localCoupons?.map(coupon => coupon.coupon_code).join(',')||[];
    try {
        const formData = new URLSearchParams();
        formData.append('coupon_code', coupon_code);
        const response=await getApplyCouponData(formData,userToken);
        // console.log("responseresponseresponseresponse",response);
        
      } catch (error) {
        // toast.error("Please try again later.");
          // console.error('Error applying coupon:', error.response);
      }	
}

  const register = async(social_token)=>{
    const formData = new URLSearchParams();
    formData?.append("social_token", social_token)
    formData.append('is_social_login', "1")
    formData.append('social_login_type', "1")
    const responseData = await signUpData(formData);
    const { id, email, userfullname, lastname } = responseData.data;
        const userInfo = { id, email, userfullname, lastname, token: responseData.token };
        localStorage.setItem('user', JSON.stringify(userInfo));
        dispatch(addToUser(userInfo));
        navigate(Routes.Home);
        if (cart.length > 0) {
          const products = cart.map((product) => ({
            product_id: product.id,
            product_variant_id: product.p_variant_id,
            quantity: product.count,
            coupon_code: sCoupon,
            usd_amount: product.usd_price,
            currency_code: excRate?.currencyCode,
            currency_rate: excRate?.rate,
            currency_symbol: excRate?.currencySymbol,
          }));
         let addCartResponse = await addCart(products, responseData.token);

          if(addCartResponse?.status==1){
            applyCouponData(responseData.token);
          }
        }

        if (buy?.length > 0) {
          const buy_now = buy?.map((buy_item) => ({
            product_id: buy_item?.id,
            quantity: buy_item?.count,
            product_coupon: buy_item?.productCoupon ? buy_item?.productCoupon : "",
            usd_amount: buy_item?.usd_price,
            currency_code: excRate?.currencyCode,
            currency_rate: excRate?.rate,
            currency_symbol: excRate?.currencySymbol
          }));
          await addToBuyDB(buy_now, responseData.token);
        }
        toast.success(responseData.message, { toastId: '' });

  }

  const handleFailure = (error) => {
    console.log('Login Failed: ', error);
  };

  return (
    <GoogleOAuthProvider clientId={client_id_prod}>
      <div className="App_logo">
          <GoogleLogin
            onSuccess={handleSuccess}
            onError={handleFailure}
            text={userLogin === "SignUp" ? "signup_with" : "signin_with"}
          />
      </div>
    </GoogleOAuthProvider>
  );
};

export default GoogleLoginSocial;
