import React from 'react'
import { Input, Form } from 'antd';

const { TextArea } = Input;
function Feedback() {
    return (
        <>
            <div className='BD_feedback_wrapper'>
                <div className='bd_model_left'>
                    <h1>Give us a Feedback!</h1>

                    <Form name="control-hooks" layout="vertical" autoComplete="off" >
                        <Form.Item name="Name" label="Name"
                            rules={[{ required: true }]}>
                            <Input className='input_signin' />
                        </Form.Item>

                        <Form.Item name="Email" label="Email"
                            rules={[{ required: true, }]}>
                            <Input className='input_signin' />
                        </Form.Item>

                        <Form.Item name="Feedback" label="Your Feedback*"
                            rules={[{ required: true, }]}>
                            <TextArea rows={5} className='textarea_signin' />
                        </Form.Item>

                        <div className='bd_model_button'>
                            <button key="submit" >
                                Submit
                            </button>
                        </div>
                    </Form>
                </div>
            </div>
        </>
    )
}

export default Feedback