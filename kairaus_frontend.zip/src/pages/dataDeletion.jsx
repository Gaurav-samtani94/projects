// src/DataDeletion.js
import React from 'react';

const DataDeletion = () => {
  return (
    <div style={styles.container}>
      <h1 style={styles.header}>Data Deletion Request</h1>
      <p style={styles.text}>
        If you would like to request deletion of your data associated with our app, please follow the steps below:
      </p>
      <ol style={styles.list}>
        <li>Send an email to <a href="mailto:customercare@kairaus.com">customercare@kairaus.com</a>.</li>
        <li>
          In the email, please include your Facebook User ID or the email address associated with your Facebook account.
        </li>
        <li>
          We will process your data deletion request within 48 hours and notify you once the deletion has been completed.
        </li>
      </ol>
      <p style={styles.text}>
        If you have any questions or concerns, feel free to contact our support team at the email address above.
      </p>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '800px',
    margin: '50px auto',
    padding: '20px',
    textAlign: 'center',
    border: '1px solid #ddd',
    borderRadius: '8px',
    backgroundColor: '#f9f9f9',
  },
  header: {
    fontSize: '2rem',
    color: '#333',
    marginBottom: '20px',
  },
  text: {
    fontSize: '1rem',
    color: '#555',
  },
  list: {
    textAlign: 'left',
    marginTop: '20px',
  },
};

export default DataDeletion;
