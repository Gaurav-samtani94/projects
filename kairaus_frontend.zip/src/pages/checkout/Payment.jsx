// checkout / Payment.js
import React, { useState } from 'react';
import { Popover, Steps, Row, Col, Collapse, Tabs } from 'antd';

import cashDeliver from '../../assets/images/cashdeliver.png';
import payPal from '../../assets/images/ccAvenue.png';
import UpiForm from '../PaymentTabs/UpiForm';
import CreditForm from '../PaymentTabs/CreditForm';
import NetBanking from '../PaymentTabs/NetBanking';
import CashDelivery from '../PaymentTabs/CashDelivery';
import PayPalForm from '../PaymentTabs/PayPalForm';
import PriceDetails from "../checkout/PriceDetails"
import { useDispatch, useSelector } from 'react-redux';

import { Link, useNavigate } from 'react-router-dom';
import Routes from '../../Routes/Routes';
import { createOrder } from '../../services/orders/order';
import { toast } from 'react-toastify';
import NoCartimg from '../../assets/images/nocart.png'
import { STRINGS } from '../../constants/Constant';
import { addToCart, clearCart } from '../../reducers/cartSlice';
import CheckoutCartProduct from '../../components/drawer/CheckoutCartProduct';
import CalculateTotals from "../../components/checkout/priceCalculateTotals";
import { applyCoupon } from '../../reducers/couponSlice';
import AmountDetails from './AmountDetails';
import logoName from "../../assets/images/KAIRAUS_logo_383x60.svg";
import { Tooltip } from 'antd';

const customDot = (dot, { status, index }) => (
    <Popover
        content={
            <span>
                step {index} status: {status}
            </span>
        }
    >
        {dot}
    </Popover>
);
//
const Payments = () => {
    const couponSlice = useSelector((state) => state.coupon);
    const couponId = couponSlice?.id || 0;
    // console.log('couponSlice',couponId);
    const user = useSelector((state) => state.user);
    const cart = useSelector((state) => state.cart);
    const buy = useSelector(state => state.buy);

    const buyNow = buy.length > 0 ? "buy_now" : "";
    const from = JSON.parse(sessionStorage.getItem('selectedAddress'));
    const dispatch = useDispatch();
    const navigate = useNavigate();
    // Cart details stored in session
    const [cartDetails, setCartDetails] = useState(() => ({
        cartList: null,
        imgPath: null,
        priceDetails: null
    }));
    const { cartList, imgPath, priceDetails } = cartDetails;
    // Destructuring with default values
    const { id = '', address = '', gst_number = '', land_mark = '', mobile_number = '', city = {}, zip_code = '', name = '', state = {}, country = {} } = from;

    // Using optional chaining to handle potential undefined values
    const city_name = city?.city_name || '';
    const state_name = state?.state_name || '';
    const country_name = country?.country_name || '';

    const textDeliver = (
        <div className='deliver_spn'>
            <h2>Shipping Address</h2>
            <span> {address}, {land_mark !== "undefined" && land_mark !== "" ? `${land_mark},` : ""} {city_name}, {state_name} {zip_code}</span>
            <p>{mobile_number}</p>
        </div>
    );
    const text_bag = (
        <div className='drawer_cupns_space'>
            {
                cartList?.length === 0 ? (
                    <div className='noDataCont'>
                        <img src={NoCartimg} alt='' />
                        <h5> No Product In cart.</h5>
                        <Link to={Routes.Home}>Continue Shopping</Link>
                    </div>
                ) : (
                    <CheckoutCartProduct cartDetailList={cartList} cartDetailImgPath={imgPath} />
                )}
        </div>
    );
    const handleCodData = async () => {
        try {

            // Product details
            // Create order in DB
            const orderFormData = new URLSearchParams();
            orderFormData.append('address_id', id);
            orderFormData.append('buy_now', buyNow);

            const dbResponse = await createOrder(orderFormData, user.token);

            if (dbResponse.status === "1") {
                const buyIds = buy?.map((item) => item.id);
                // console.log('buyIdsbuyIdsbuyIdsbuyIds',buyIds);
                if (buyIds.length > 0) {
                    // dispatch(clearBuy());
                    // localStorage.removeItem('buy');
                } else {

                    try {
                        // Collect product IDs to be deleted in parallel using Promise.all
                        const deletedProductIds = await Promise.all(cartList.map((product) => product?.product?.id));
                        // Filter the cart to remove the deleted products
                        const updatedCart = cart.filter((item) => !deletedProductIds.includes(item.id));

                        const updateCartState = (cartItems) => {
                            const couponnull = {};
                            localStorage.setItem('coupon', JSON.stringify(couponnull));
                            dispatch(applyCoupon(couponnull));

                            if (cartItems.length > 0) {
                                localStorage.setItem('cart', JSON.stringify(cartItems));
                                dispatch(addToCart(cartItems));
                            } else {
                                localStorage.removeItem("cart");
                                dispatch(clearCart());
                            }
                        };

                        // Update local storage and dispatch actions based on cart status
                        updateCartState(updatedCart);

                    } catch (error) {
                        console.error("Deleting Error:", error);
                    }


                }
                navigate(Routes.ThankuCheck);

            } else {
                toast.error(STRINGS.PLEASE_TRY_AGAIN_LATER);
            }
        } catch (error) {
            console.error('Error handling COD data:', error);
            toast.error(STRINGS.PLEASE_TRY_AGAIN_LATER);
        }
    };



    const [activeTab, setActiveTab] = useState('cashDelivery');
    const renderTabContent = () => {
        switch (activeTab) {
            case 'debitCrd':
                return <CreditForm />;
            case 'upiOnline':
                return <UpiForm />;
            case 'netBanking':
                return <NetBanking />;
            case 'cashDelivery':
                return <CashDelivery handleCodData={handleCodData} />;
            case 'payPal':
                return <PayPalForm from={from} CalculateTotals={CalculateTotals} couponId={couponId} />;
            default:
                return null;
        }
    };

    const onChange = (key) => {
        // console.log(key);
    };

    const genExtra = () => (
        <div className='extra_title'>
            {cartList?.length} Items
        </div>
    );
    const deliverExtra = () => (
        <div className='extra_title_sec'>
            {name}
        </div>
    );

    const items = [
        {
            key: '1',
            label: 'Bag',
            children: <div>{text_bag}</div>,
            extra: genExtra(),
        },
        {
            key: '2',
            label: 'Deliver to',
            children: <div>{textDeliver}</div>,
            extra: deliverExtra(),
        },
        {
            key: '3',
            label: 'Total Price',
            children: <div className='prize_detail'>{<PriceDetails cartDetailPrice={priceDetails} />}</div>,
        },
    ];

    const tabItems = [
        {
            key: "cashDelivery",
            label: (
                <div className='tab_flex_img'>
                    <img src={cashDeliver} alt="#" />
                    <div className='credit_debit_para'>
                        <span>Cash on Delivery</span>
                        <p>Pay at the time of delivery</p>
                    </div>
                </div>
            ),
            children: null,
        },
        {
            key: "payPal",
            label: (
                <div className='tab_flex_img'>
                    <img src={payPal} alt="#" width={25} />
                    <div className='credit_debit_para'>
                        <span>Pay CC Avenue</span>
                        <p>Pay through your CC Avenue Account</p>
                    </div>
                </div>
            ),
            children: null,
        },
    ];

    return (
        <>
            <AmountDetails setCartDetails={setCartDetails} />
            <Link to={Routes.Confirmation}>
                <Tooltip title="Back">
                    <button className='bacl_btn'>
                        <svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M5.79889 24H41.7989" stroke="#333" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                            <path d="M17.7988 36L5.79883 24L17.7988 12" stroke="#333" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                    </button>
                </Tooltip>
                <img src={logoName} alt="logo" className='logoName' />
            </Link>
            <div className='payment_main'>
                <div className='payment_steper'>
                    <Steps
                        current={1}
                        progressDot={customDot}
                        items={[
                            {
                                title: 'Shipping',
                            },
                            {
                                title: 'Payment',
                            },
                            {
                                title: 'Confirmation',
                            },
                        ]}
                    />
                </div>
                <div className='payment_heading'>
                </div>
                <div className='payment_card_itemInfo'>
                    <Row gutter={16}>
                        <Col xs={24} sm={24} md={24} lg={16}>
                            <div className='payment_mode_card'>
                                <div className='account_masterTabs'>
                                    <Tabs tabPosition="left" activeKey={activeTab} onChange={setActiveTab} items={tabItems}>
                                    </Tabs>
                                </div>
                                <div className="paymentContent_wrapper">{renderTabContent()}</div>
                            </div>
                        </Col>
                        <Col xs={24} sm={24} md={24} lg={8}>
                            <div className='payment_items_accordian'>
                                <Collapse
                                    onChange={onChange}
                                    items={items}
                                    defaultActiveKey={['1']}
                                />
                            </div>
                            <div className='paymnet_bag_info'>
                                {/* <span>You are saving ₹{savingAmnt.toFixed(2)}</span> */}
                            </div>
                        </Col>
                    </Row>
                </div>
            </div>
            <div className='payment_footer'>
                <Link to={Routes.Privacy}><span>Privacy policy </span></Link>
                <div className='profile_dashed'>|</div>
                <Link to={Routes.TermCondition}><span>Terms & Conditions</span></Link>
            </div>
        </>
    )
}

export default Payments