import React, { useEffect, useCallback, useState, useRef } from 'react';
import { Radio, Input, Row, Col, Select, Form, Collapse, Tabs, Button, Modal, Spin } from 'antd';
import { TruckOutlined } from '@ant-design/icons';
import { Link, useNavigate } from 'react-router-dom';
import { getCountryList } from '../../services/user/getCountryList';
import { getStateList } from '../../services/user/getStateList';
import { useDispatch, useSelector } from 'react-redux';
import { getCityList } from '../../services/user/getCitiyList';
import { addUserAddress } from '../../services/user/addUserAddress';
import { STRINGS } from '../../constants/Constant';
import { toast } from "react-toastify";
import { signUpData } from '../../services/auth/singUp';
import { addCart, addToBuyDB } from '../../services/cart/addCart';
import { checkPincodeForCOD, serviceability } from '../../services/ship/courierServiceability';
import DrawerLocalCartPriceList from '../../components/drawer/DrawerLocalCartPriceList';
import { ccavenueResponse, razorpayInserOrderResponse, razorpayVerifyPaymentResponse } from '../../services/ccavenue/ccavenueApi';
import { genrateRandomPassword, handleKeyPressForMobile } from '../../function/CommonFunctions';
import { authApi } from '../../services/auth/authApi';
import { addToUser, clearUser } from '../../reducers/userSlice';
import { getApplyCouponData, getCartAmountdetail } from '../../services/coupon/applyCoupon';
import PriceDetails from './PriceDetails';
import { getAddressData } from '../../services/user/getUserAddress';
import Routes from '../../Routes/Routes';
import { addToCart, clearCart } from '../../reducers/cartSlice';
import { createOrder } from '../../services/orders/order';
import { applyCoupon } from '../../reducers/couponSlice';
import upiImg from '../../assets/images/visa (2).png'
import visaImg from '../../assets/images/yes.png';
import rupayImg from '../../assets/images/rupay.png'
import phonepay from '../../assets/images/phonepay.png'
import masterImg from '../../assets/images/master.png'
import { storeLocalCoupon } from '../../reducers/localCouponSlice';

const { TextArea } = Input;

function MainCheckout() {
    const user = useSelector((state) => state.user);
    const { token } = user;
    const [form] = Form.useForm();
    const [states, setStates] = useState([]);
    const [cities, setCities] = useState([]);
    const [countries, setCountries] = useState(null);
    const [country_id, setCountryId] = useState(null);
    const [billingStates, setBillingStates] = useState([]);
    const [billingCities, setBillingCities] = useState([]);
    const [billingCounties, setBillingCounties] = useState([]);
    const [billingCountry_id, setBillingCountry_id] = useState(null);
    const [showBillingForm, setShowBillingForm] = useState(false);
    const [activeTab, setActiveTab] = useState('payPal');
    const [loading, setLoading] = useState(false);
    const [email, setEmail] = useState('');
    const [isEmailValid, setIsEmailValid] = useState(false);
    const cart = useSelector((state) => state.cart);
    const excRate = useSelector(state => state.excrate);
    const sCoupon = useSelector(state => state.productCoupon) || "";
    const [shipping, setShipping] = useState('');
    const [OtpModal, setOtpModal] = useState(false);
    const [mobileOtp, setMobileOtp] = useState([]);
    const [resendDisabled, setResendDisabled] = useState(false);
    const [timer, setTimer] = useState();
    const [cartDetails, setCartDetails] = useState(() => ({
        cartList: null,
        imgPath: null,
        priceDetails: null
    }));
    const [titleValue, setTitleValue] = useState('Home');
    const [deliveryError, setDeliveryError] = useState('');
    const [maskClosable, setMaskClosable] = useState(false);
    const [codAvailable, setCODAvailable] = useState(true);
    const [codAvailableMessage, setCODAvailableMessage] = useState('');

    const buy = useSelector(state => state.buy);
    const buyNow = buy.length > 0 ? "buy_now" : "cart";
    const buy_now_data = buy?.length>0 ? buy : cart;

    const otpInputs = useRef(Array.from({ length: 4 }, () => React.createRef()));
    const localCoupons = useSelector((state) => state.localCoupon);

    // Email validation regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let timerVal = 120;
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const paymentUrl = process.env.REACT_APP_API_PAYPAL_URL;

    // Focus on the first input when the modal opens
    useEffect(() => {
        if (OtpModal) {
            otpInputs.current[0].current.focus(); // Focus on the first OTP input
        }
    }, [OtpModal]); // Run this effect when the modal state (OtpModal) changes


    const tabItems = [
        {
            key: "payPal",
            label: (
                <div className='tab_flex_img'>
                    <div className='credit_debit_para'>
                        <span>Pay CC Avenue</span>
                        <p>Pay through your CC Avenue Account</p>
                    </div>
                    <div className='tabs_images'>
                        <img src={upiImg} alt="PayPal" width={25} />
                        <img src={masterImg} alt="PayPal" width={25} />
                        <img src={phonepay} alt="PayPal" width={25} />
                        <img src={visaImg} alt="PayPal" width={25} />
                        <img src={rupayImg} alt="PayPal" width={25} />
                    </div>
                </div>
            ),
            children: null,
        },
        codAvailable &&  {
            key: "cashDelivery",
            label: (
                <div className='tab_flex_img' onClick={() => setActiveTab('cashDelivery')}>
                    <div className='credit_debit_para'>
                        <span>Cash on Delivery</span>
                        <p>Pay at the time of delivery</p>
                    </div>
                </div>
            ),
            children: null,

        },
        {
            key: "razorpay",
            label: (
                <div className='tab_flex_img' onClick={() => setActiveTab('razorpay')}>
                    <div className='credit_debit_para'>
                        <span>Pay with Razorpay</span>
                        <p>Pay through your Razorpay Account</p>
                    </div>
                    <div className='tabs_images'>
                        <img src={upiImg} alt="PayPal" width={25} />
                        <img src={masterImg} alt="PayPal" width={25} />
                        <img src={phonepay} alt="PayPal" width={25} />
                        <img src={visaImg} alt="PayPal" width={25} />
                        <img src={rupayImg} alt="PayPal" width={25} />
                    </div>
                </div>
            ),
            children: null,
        },
    ];

    const pincodeCheckForCOD = async (userPincode) => {

        const formData = new URLSearchParams();
        formData.append('pincode', userPincode);

        try {
            let result = await checkPincodeForCOD(formData);
            if(result?.status == 1){
                setCODAvailable(true);
            }
            else{
                setCODAvailable(false);
                setCODAvailableMessage(result?.message);
                setActiveTab('payPal');
            }

        } catch (error) {
            console.log(error);
            
        }

    }

    const checkDelivery = async (val) => {
        if (val?.length == 0) {
            setShipping(null);
            setDeliveryError('Please enter the pincode');
            return
        }
        if (val?.length != 6) {
            setShipping(null);
            setDeliveryError('Please enter a valid 6-digit pincode');
            return
        }
        // const pickup_postcode = process.env.PICKUP_POSTCODE;
        pincodeCheckForCOD(val);
        const formData = new URLSearchParams();
        formData.append('delivery_postcode', val);
        formData.append('pickup_postcode', '302014');
        formData.append('weight', '1');
        formData.append('cod', '1');
        try {
            setDeliveryError('');
            // const response = await serviceability(orpickup_postcode, delivery_postcode, weight, cod);
            
            // const response = await serviceability(formData);
            // const availableCourierCompanies = response?.data?.available_courier_companies || [];
            // setShipping(availableCourierCompanies[0]?.etd || null)

            // if (!availableCourierCompanies?.length) {
            //     setDeliveryError('No delivery found with this pincode===========');
            // }
            // else {
            //     setDeliveryError(''); // Clear error if delivery is available
            // }
        } catch (error) {
            console.error('Error fetching data:', error);
            setDeliveryError('An error occurred while checking the pincode555555555555');

        }
    }

    const showCartProducts = () => {
        let productList = [];
        const customerServiceProductBufferdays = localStorage.getItem('customerServiceBufferdays');
        if (user?.id) {
            productList = cartDetails?.cartList?.map((item) => {
                let newItem = {
                    id: item?.product_id, product_name: item?.product?.product_name, product_slug: item?.product?.product_slug, is_wishlist: 0, price: item?.product?.price, usd_price: item?.product?.usd_price, image: `${cartDetails?.imgPath}${item?.product?.productimage?.file_name_120_x_120}`, shipping_amount_type: item?.product?.shipping_amount_type, shipping_charge: item?.product?.shipping_charge, count: item?.quantity, p_variant_id: item?.product_variant_id, compare_price: item?.product?.compare_price, usd_compare_price: item?.product?.usd_compare_price, weight: item?.product?.weight, unit: item?.product?.unit, stock_quantity: item?.product?.stock_quantity, isChecked: true, product_buffer_days: item?.product?.product_buffer_days
                };
                return newItem;
            });
        }
        else {
            productList = cart;
        }

        return productList?.filter(item => item?.isChecked == true)?.map((product, index) => (
            <div className='cart-products'>
                <div className='left_cart'>
                    <Link to="">
                        {product?.image && (
                            <img src={product?.image} alt={product?.product_name} />
                        )}
                    </Link>
                </div>
                <div className='right_cart'>
                    <div className='price_delete align-items-start'>
                        <Link to="">
                            <h2>{product?.product_name}</h2>
                        </Link>
                        <div className='cartProduct_price'>
                            <span>₹{product?.price}</span>
                            {parseInt(product?.compare_price) != product?.price &&
                                <p>₹{product?.compare_price}</p>}
                        </div>
                    </div>
                    <div className='quantity_span'>
                        <span>QTY : {product?.count}</span>
                        <h6>({product?.count} * {product?.price}) &nbsp; ₹ {product?.count * product?.price}</h6>
                    </div>
                    {shipping &&
                        <h5 className='pinCode_delivery'>
                            <TruckOutlined /> <p>Estimated delivery: {new Date(new Date(shipping).getTime() + parseInt(product?.product_buffer_days) * 24 * 60 * 60 * 1000 + parseInt(customerServiceProductBufferdays) * 24 * 60 * 60 * 1000).toLocaleDateString("en-US", { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                        </h5>}
                </div>
            </div>
        ))
    }

    const showBuyProducts = () => {
        return buy?.map((product, index) => (
            <div className='cart-products'>
                <div className='left_cart'>
                    <Link to="">
                        {/* <img src={chcekoutimg} /> */}
                        {product.image && (
                            <img src={product?.image} alt={product?.product_name} />
                        )}
                    </Link>
                </div>
                <div className='right_cart'>
                    <div className='price_delete align-items-start'>
                        <Link to="">
                            <h2>{product?.product_name}</h2>
                        </Link>
                        <div className='cartProduct_price'>
                            <span>₹{product?.price}</span>
                            {parseInt(product?.compare_price) != product?.price &&
                                <p>₹{product?.compare_price}</p>}
                        </div>
                    </div>
                    <div className='quantity_span'>
                        <span>QTY : {product?.count}</span>
                        <h6>({product?.count} * ₹{product?.price}) ₹ {product?.count * product?.price}</h6>
                    </div>
                    {shipping &&
                        <h5 className='pinCode_delivery'>
                            <TruckOutlined /> <p>Estimated delivery: {shipping}</p>
                        </h5>}
                </div>
            </div>
        ))
    }

    // for Mobile view
    const items = [
        {
            key: '1',
            label: 'Your Items',
            children: <div className='main_carts_phone'>
                <div className="checkout_bag">
                    {buy?.length > 0 ? showBuyProducts() : showCartProducts()}
                </div>
                {
                    user?.token ?
                        <PriceDetails cartDetailPrice={cartDetails?.priceDetails} />
                        :
                        <DrawerLocalCartPriceList from={'maincheckout'} />
                }
            </div>,
        },
    ];



    const fetchCountry = async () => {
        try {
            const response = await getCountryList();
            if (response?.status == '1') {
                setCountries(response?.data)
                setBillingCounties(response?.data);
            } else {
                setCountries([])
                setBillingCounties([]);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    const fetchStates = useCallback(async (country) => {
        const formData = new URLSearchParams();
        formData.append('country_id', country);
        try {
            const responseData = await getStateList(formData, token);

            if (responseData.status === '1') {
                const stateData = responseData.data;
                return stateData;
            }
        } catch (error) {
            console.error('API Request Error:', error);
            // message.error('Login failed. Please check your credentials and try again.');
        }
        return [];
    }, [token]);

    const fetchCities = useCallback(async (state) => {
        const formData = new URLSearchParams();
        formData.append('state_id', state);
        try {
            const responseData = await getCityList(formData, token);


            if (responseData.status === '1') {
                const cityData = responseData.data;
                return cityData;
            }
        } catch (error) {
            console.error('API Request Error:', error);
            // message.error('Login failed. Please check your credentials and try again.');
        }
        return [];
    }, [token]);

    useEffect(() => {
        const selectedCountry = form?.getFieldValue('country');
        const selectedState = form?.getFieldValue('state');

        if (selectedCountry) {
            fetchStates(selectedCountry)
                .then((states) => setStates(states))
                .catch((error) => console.error('Error fetching states:', error));
        }

        if (selectedState) {
            fetchCities(selectedState)
                .then((cities) => setCities(cities))
                .catch((error) => console.error('Error fetching cities:', error));
        } else {
            setCities([]);
        }
    }, [form, fetchStates, fetchCities]);


    //// billing countries code

    const fetchBillingStates = useCallback(async (country) => {
        const formData = new URLSearchParams();
        formData.append('country_id', country);
        try {
            const responseData = await getStateList(formData, token);

            if (responseData.status === '1') {
                const stateData = responseData.data;
                return stateData;
            }
        } catch (error) {
            console.error('API Request Error:', error);
            // message.error('Login failed. Please check your credentials and try again.');
        }
        return [];
    }, [token]);

    const fetchBillingCities = useCallback(async (state) => {
        const formData = new URLSearchParams();
        formData.append('state_id', state);
        try {
            const responseData = await getCityList(formData, token);


            if (responseData.status === '1') {
                const cityData = responseData.data;
                return cityData;
            }
        } catch (error) {
            console.error('API Request Error:', error);
            // message.error('Login failed. Please check your credentials and try again.');
        }
        return [];
    }, [token]);

    useEffect(() => {
        const selectedBCountry = form?.getFieldValue('billing_country_id');
        const selectedBState = form?.getFieldValue('billing_state_id');

        if (selectedBCountry) {
            fetchBillingStates(selectedBCountry)
                .then((states) => setBillingStates(states))
                .catch((error) => console.error('Error fetching states:', error));
        }

        if (selectedBState) {
            fetchBillingCities(selectedBState)
                .then((cities) => setBillingCities(cities))
                .catch((error) => console.error('Error fetching cities:', error));
        } else {
            setBillingCities([]);
        }
    }, [form, fetchBillingStates, fetchBillingCities]);

    const handleStateChange = (value) => {
        form?.setFieldsValue({ city: undefined });
        fetchCities(value)
            .then((cities) => setCities(cities))
            .catch((error) => console.error('Error fetching cities:', error));
    };

    const handleBillingStateChange = (value) => {
        form?.setFieldsValue({ billing_city_id: undefined });
        fetchBillingCities(value)
            .then((cities) => setBillingCities(cities))
            .catch((error) => console.error('Error fetching cities:', error));
    };

    const countryChange = async (value) => {
        setCountryId(value);
        form?.setFieldsValue({ state: undefined, city: undefined });
        const stateList = await fetchStates(value);
        setStates(stateList);
    }

    useEffect(() => {
        const filteredCartData = cart.filter((product) => product.isChecked);
        // if (filteredCartData?.length < 1 || buy?.length < 1) {
        //     navigate('/');
        // }

    }, [])

    useEffect(() => {
        fetchCountry();
    }, [])

    const billingCountryChange = async (value) => {
        setBillingCountry_id(value);
        form?.setFieldsValue({ billing_state_id: undefined, billing_city_id: undefined });
        const stateList = await fetchBillingStates(value);
        setBillingStates(stateList);
    }

    const handleRadioChange = e => {
        const value = e.target.value;
        form.setFieldsValue({
            is_shipping_address: value === 'same_ship_add',
            is_billing_address: value === 'differ_bill_add',
        });
        setShowBillingForm(value === 'differ_bill_add');
    };

    // // Function to handle the application of the first order coupon
    // const applyFirstOrderCoupon = async (couponCode, accessToken) => {
    //     // console.log("vivek see:", couponCode);
    //     try {
    //         const formData = new URLSearchParams();
    //         formData.append('coupon_code', couponCode);
    //         let response = await getApplyCouponData(formData, accessToken);
    //         if (response?.status == 1) {
    //             return true
    //         }
    //         else {
    //             return false
    //         }
    //     } catch (error) {
    //         console.error('Error applying first order coupon:', error);
    //         return false
    //     }
    // };

    const addressForm = async (values, accessToken, isAlreadyLoggedIn) => {

        const AddressFormData = new URLSearchParams();
        AddressFormData.append('title', titleValue);
        AddressFormData.append('name', values?.name);
        AddressFormData.append('country_id', values?.country);
        AddressFormData.append('state_id', values?.state);
        AddressFormData.append('city_id', values?.city);
        AddressFormData.append('pincode', values?.pincode);
        AddressFormData.append('address', values?.address);
        AddressFormData.append('land_mark', values?.land_mark !== undefined ? values?.land_mark : "");
        AddressFormData.append('mobile_number', values?.phone);
        AddressFormData.append('is_default', 1);
        AddressFormData.append('apartment', '');

        // Billing_Address
        AddressFormData.append('is_shipping_address', !showBillingForm ? '1' : '0');
        AddressFormData.append('is_billing_address', showBillingForm ? '1' : '0');
        // AddressFormData.append('is_shipping_address', values?.is_shipping_address ? '1' : values?.is_billing_address == false ? '1' : '0');
        // AddressFormData.append('is_billing_address', values?.is_billing_address ? '1' : '0');
        AddressFormData.append('billing_name', values?.billing_name ?? '');
        AddressFormData.append('billing_phone', values?.billing_phone ?? '');
        AddressFormData.append('billing_country_id', values?.billing_country_id ?? '');
        AddressFormData.append('billing_state_id', values?.billing_state_id ?? '');
        AddressFormData.append('billing_city_id', values?.billing_city_id ?? '');
        AddressFormData.append('billing_pincode', values?.billing_pincode ?? '');
        AddressFormData.append('billing_address', values?.billing_address ?? '');


        const addResponse = await addUserAddress(AddressFormData, accessToken);
        if (addResponse?.status === '1') {


            // toast.success(STRINGS.ADDRESS_ADDED_SUCCESSFULLY);
            // Add to cart
            let products;
            if (buy_now_data?.length > 0) {
                products = buy_now_data?.map((product) => ({
                    product_id: product.id,
                    product_variant_id: product.p_variant_id,
                    quantity: product.count,
                    coupon_code: sCoupon,
                    usd_amount: product.usd_price,
                    currency_code: excRate?.currencyCode,
                    currency_rate: excRate?.rate,
                    currency_symbol: excRate?.currencySymbol,
                }));

            }

            setFormData((prev) => ({
                ...prev,
                merchant_param2: addResponse?.data?.user_id,
                merchant_param5: addResponse?.data?.id
            }))

            if (isAlreadyLoggedIn) {
                console.log("yha aa gya")
                if (activeTab === 'cashDelivery') {   //COD
                    handleCodData(addResponse?.data?.id, accessToken)
                }
                else if (activeTab === 'payPal') {   // PAYMENT GATEWAY
                    console.log("yha kyu ni aaya")
                    
                    // paymentAdd(addResponse?.data?.id, accessToken);
                    setTimeout(() => {
                        placeOrderButtonRef?.current?.click();
                    }, 100);

                } else {
                    razorpayAdd(addResponse?.data?.id, accessToken)
                }
            }

            else {
                // New Register
                let addCartResponse = buy_now_data ? await addToBuyDB(products, accessToken) : await addCart(products, accessToken);
                if (addCartResponse?.status == 1) {

                    applyCouponData(accessToken)
                    setTimeout(() => {
                        if (activeTab === 'cashDelivery') {   //COD
                            handleCodData(addResponse?.data?.id, accessToken);
                        }
                        else if (activeTab === 'payPal') {   // PAYMENT GATEWAY
                            return;
                            // paymentAdd(addResponse?.data?.id, accessToken);
                            placeOrderButtonRef?.current?.click();

                        } else {
                            razorpayAdd(addResponse?.data?.id, accessToken)
                        }
                    }, 1500);

                }
            }

        }
        // Add-address else
        else {
            toast.error(STRINGS.FAILED_TO_ADD_ADDRESS);
        }
    }
    // COMMENT DELEBERATLY
    const paymentAdd = async (addressId, userToken) => {
        try {
            const formData = new URLSearchParams();
            formData.append('address_id', addressId);
            formData.append('buy_now', buyNow);

            const response = await ccavenueResponse(formData, userToken);

            if (response?.paymentUrl) {
                // window.location.href = response.paymentUrl;
                window.location.assign(response.paymentUrl);

            } else {
                console.error('Payment URL not found');
            }
        } catch (error) {
            console.error('Error during payment processing:', error);
        }

    }

    const razorpayAdd = async (addressId, userToken) => { 
        try {
            const formData = new URLSearchParams();
            formData.append('address_id', addressId);
            formData.append('buy_now', buyNow);
    
            const orderResponse = await razorpayInserOrderResponse(formData, userToken);
            console.log('orderResponse',orderResponse?.data);
            
            if (orderResponse?.status === "1") {
                const { data, Razorpay } = orderResponse;
                const options = {
                    key: "rzp_test_IvLwYTHVDXrpFz",
                    amount: data.paid_amount * 100,
                    currency: data?.currency,
                    name: "Kairaus",
                    description: "Test Transaction",
                    order_id: data.order_id, 
                    prefill: {
                        
                            contact: data?.mobile_number 
                        }, 
                    
                    handler: async function (paymentResponse) {
                        const paymentData = {
                            razorpay_order_id: paymentResponse.razorpay_order_id,
                            razorpay_payment_id: paymentResponse.razorpay_payment_id,
                            razorpay_signature: paymentResponse.razorpay_signature,
                            user_id:user?.id
                        };
    
                        try {
                            const verificationResponse = await razorpayVerifyPaymentResponse(paymentData, userToken);
                            console.log("Payment verification successful", verificationResponse);

                            if (verificationResponse.status === "success") {
                                navigate(Routes?.ThankuCheck, {state:{from:verificationResponse?.order_id}});
                            } else {
                                window.location.href = "/payment-failed";
                            }
                        } catch (error) {
                            console.error("Payment verification failed:", error);
                            // window.location.href = "/failed";
                        }
                    },
                    theme: {
                        color: "#d63384",
                    },
                };
    console.log(options,"ooooo");
                const paymentObject = new window.Razorpay(options);
                paymentObject.open();
            } else {
                console.error("Failed to create order:", orderResponse);
                alert("Failed to create order. Please try again.");
            }
        } catch (error) {
            console.error("Error during order creation or payment processing:", error);
            alert("Error during order creation or payment processing. Please try again.");
        }
    };

    useEffect(() => {
        if (loading) {
            setTimeout(() => {
                setLoading(false);
            }, 4000);
        }

    }, [loading])

    const handleKeyPressName = (e) => {
        const key = e.key;
        if ((key >= "0" && key <= "9") || !(key.match(/[a-zA-Z\s]/))) {
            e.preventDefault();
        }
    };

    const handleSubmit = async (values) => {
        setLoading(true);
        try {
            let generatedPassword = genrateRandomPassword();
            const nameParts = values?.name?.trim().split(' ');
            let firstName = '';
            let lastName = '';

            if (nameParts.length === 1) {
                firstName = nameParts[0]; // Assign the single name to firstName
            } else {
                lastName = nameParts?.pop(); // Pop the last part as lastName
                firstName = nameParts?.join(' '); // Join the remaining parts as firstName
            }

            // logged in case
            if (user?.token) {
                addressForm(values, user?.token, true);
            }
            // New user case
            else {
                const SignUpFormData = new URLSearchParams();
                SignUpFormData.append('firstname', firstName);
                SignUpFormData.append('lastname', lastName);
                SignUpFormData.append('email', email);
                SignUpFormData.append('mobile_number', values?.phone);
                SignUpFormData.append('password', generatedPassword);
                SignUpFormData.append('referrer', '');
                SignUpFormData.append('is_social_login', '2');

                // Sign up
                const responseData = await signUpData(SignUpFormData);
                if (responseData.status === '1') {
                    toast.success(responseData.message);
                    dispatch(clearUser());
                    const { id, email, userfullname, lastname } = responseData?.data;
                    const userInfo = { id, email, userfullname, lastname, token: responseData?.token };

                    localStorage.setItem('user', JSON.stringify(userInfo));
                    dispatch(addToUser(userInfo));
                    getCartAmountData(responseData?.token)

                    addressForm(values, responseData?.token, false);
                }

                // Sign up else
                else {
                    toast.error('Something went wrong to Sign UP');
                }
            }

        } catch (error) {
            console.error('AP', error);
            toast.error(error?.message);
        }
    };

    // 

    // Show modal when email is valid
    const handleEmailChange = (e) => {
        const value = e.target.value;
        setEmail(value);

        if (emailRegex.test(value)) {
            setIsEmailValid(true);
        } else {
            setIsEmailValid(false);
        }
    };

    const handleCancel = () => {
        setOtpModal(false);
        setMobileOtp([]);
    };

    const checkEmailForUser = async () => {
        setMaskClosable(false)
        try {
            const formData = new URLSearchParams();
            formData.append('email', email);
            let sendEmailOtpResponse = await authApi?.sendEmailOtp(formData);
            if (sendEmailOtpResponse?.status == 1) {
                // User already exist and OTP Sent.
                setOtpModal(true);
                toast.success('OTP has been sent on your Email')
                setTimer(timerVal);
            }
            else {
                setOtpModal(false);
            }
        } catch (error) {
            setOtpModal(false);
        }
    }

    const minutes = Math.floor(timer / 60);
    const seconds = timer % 60;

    const handleKeyDown = (e, index) => {
        if (e.key === 'Backspace') {
            const newOtp = [...mobileOtp];
            newOtp[index] = ''; // Clear the current input
            setMobileOtp(newOtp.join(''));

            // Move focus to the previous input if it exists
            if (index > 0 && !mobileOtp[index]) {
                otpInputs.current[index - 1].current.focus();
            }
        }
    };

    const renderStarInputs = () => {
        const starInputs = [];
        for (let i = 0; i < 4; i++) {
            starInputs.push(
                <input
                    key={i}
                    ref={otpInputs.current[i]}
                    maxLength={1}
                    value={mobileOtp[i] || ''}
                    onChange={(e) => handleInputChange(e, i)}
                    onKeyDown={(e) => handleKeyDown(e, i)}
                    style={{ width: '3rem', height: '3rem', margin: '0 0.5rem', fontSize: '2rem', borderRadius: '4px', border: '1px solid #ccc', textAlign: 'center' }}
                />
            );
        }
        return starInputs;
    };
    const handleInputChange = (e, index) => {
        const value = e.target.value;
        const newOtp = [...mobileOtp];
        newOtp[index] = value;

        // Concatenate the individual digits into a single string
        const otpValue = newOtp.join('');

        setMobileOtp(otpValue);

        if (value && index < otpInputs.current.length - 1 && otpInputs.current[index + 1]) {
            otpInputs.current[index + 1].current.focus();
        }
    };

    const applyCouponData = async (userToken) => {
        const coupon_code = localCoupons?.map(coupon => coupon.coupon_code).join(',') || [];

        try {
            // Prepare the form data
            const formData = new URLSearchParams();
            formData.append('coupon_code', coupon_code);

            // Fetch the coupon application result
            const response = await getApplyCouponData(formData, userToken);
            // console.log('response',response);
            if (response?.status === '1') {

                getCartAmountData(userToken);
                dispatch(storeLocalCoupon(response?.data));

            }
        } catch (error) {
            if (error?.response?.data?.status === '0') {
                toast.error("Please try again later.");
                console.error('Error applying coupon:', error.response);
            }
        }
    }

    const verifyOtp = async () => {

        const formData = new URLSearchParams();
        formData.append('email', email);
        formData.append('otp', mobileOtp);

        try {
            let verifyEmailOtpResponse = await authApi?.verifyEmailOtp(formData);
            if (verifyEmailOtpResponse?.status == 1) {
                toast.success('OTP has been verified');
                setOtpModal(false);
                setTimer(0);
                ///
                let products;
                if (buy_now_data?.length > 0) {
                    products = buy_now_data?.map((product) => ({
                        product_id: product.id,
                        product_variant_id: product.p_variant_id,
                        quantity: product.count,
                        coupon_code: sCoupon,
                        usd_amount: product.usd_price,
                        currency_code: excRate?.currencyCode,
                        currency_rate: excRate?.rate,
                        currency_symbol: excRate?.currencySymbol,
                    }));

                }
                let addCartResponse = buy_now_data ? await addToBuyDB(products, verifyEmailOtpResponse?.token) : await addCart(products, verifyEmailOtpResponse?.token);

                if (addCartResponse?.status == 1) {
                    applyCouponData(verifyEmailOtpResponse?.token);


                    // alert('470')
                    // const { data } = (JSON.parse(localStorage.getItem('FirstOrderCouponDetails'))) || {};

                    // First order condition
                    // if (verifyEmailOtpResponse?.order_count < 1) {   
                    //     // alert('474')
                    //     const formData = new URLSearchParams();
                    //     formData.append('coupon_code', data?.coupon_code);
                    //     let response = await getApplyCouponData(formData, verifyEmailOtpResponse?.token);
                    //     if (response?.status == 1) {

                    //         getCartAmountData(verifyEmailOtpResponse?.token);
                    //     }
                    // }



                }
                ////

                dispatch(clearUser());
                const { id, email, userfullname, lastname } = verifyEmailOtpResponse?.data;
                const userInfo = { id, email, userfullname, lastname, token: verifyEmailOtpResponse?.token };

                localStorage.setItem('user', JSON.stringify(userInfo));
                dispatch(addToUser(userInfo));

                if (verifyEmailOtpResponse?.address != null) {
                    fillAddressForm(verifyEmailOtpResponse?.address)
                }
            }
            else {
                // setOtpModal(false);
                toast.error(verifyEmailOtpResponse);
                setMobileOtp([]);

            }
        } catch (error) {
            setOtpModal(true);
            setMobileOtp([]);
            toast.error(error?.message);

        }
        // setMobileOtp([])
    }

    useEffect(() => {
        let interval;
        if (timer > 0) {
            interval = setInterval(() => {
                setTimer((prevTimer) => prevTimer - 1);
            }, 1000);
        }
        if (timer <= 0) {
            setTimer(0);
            setResendDisabled(false);
        } else {
            setResendDisabled(true);
        }

        return () => clearInterval(interval);
    }, [timer]);
    // 


    const fillAddressForm = (addressData) => {

        addressData?.is_billing_address == '1' ? setShowBillingForm(true) : setShowBillingForm(false);
        form?.setFieldsValue({
            name: addressData?.name,
            phone: addressData?.mobile_number,
            country: addressData?.country?.id,
            state: addressData?.state?.id,
            city: addressData?.city?.id,
            pincode: addressData?.zip_code,
            address: addressData?.address,
            land_mark: addressData?.land_mark,
            title: !addressData?.title ? titleValue : addressData?.title,
            is_default: addressData?.is_default,
            is_shipping_address: addressData?.is_shipping_address,
            is_billing_address: addressData?.is_billing_address,
            billing_name: addressData?.is_billing_address == "0" ? null : addressData?.billing_name,
            billing_country_id: addressData?.is_billing_address == '0' ? null : addressData?.billing_country_id,
            billing_state_id: addressData?.is_billing_address == '0' ? null : addressData?.billing_state_id,
            billing_city_id: addressData?.is_billing_address == '0' ? null : addressData?.billing_city_id,
            billing_address: addressData?.is_billing_address == "0" ? null : addressData?.billing_address,
            billing_pincode: addressData?.is_billing_address == "0" ? null : addressData?.billing_pincode,
            billing_phone: addressData?.is_billing_address == "0" ? null : addressData?.billing_phone,

        })
        setTitleValue(!addressData?.title ? titleValue : addressData?.title);
        checkDelivery(addressData?.zip_code);

        // Fetch states and set them in the form
        fetchStates(addressData?.country?.id)
            .then((states) => {
                setStates(states);

                // Fetch cities based on the selected state
                return fetchCities(addressData?.state.id);
            })
            .then((cities) => setCities(cities))
            .catch((error) => console.error('Error fetching states/cities:', error));

        fetchBillingStates(addressData?.billing_country_id)
            .then((states) => {
                setBillingStates(states);

                // Fetch cities based on the selected state
                return fetchBillingCities(addressData?.billing_state_id);
            })
            .then((cities) => setBillingCities(cities))
            .catch((error) => console.error('Error fetching states/cities:', error));

    }

    const getCartAmountData = async (userToken) => {
        try {
            const cartAmtDtlformData = new URLSearchParams();
            cartAmtDtlformData.append('buy_now', buyNow);

            const cartAmountDetailResponse = await getCartAmountdetail(cartAmtDtlformData, userToken);
            if (cartAmountDetailResponse?.status == 1) {
                setCartDetails({
                    cartList: cartAmountDetailResponse?.cart_list,
                    imgPath: cartAmountDetailResponse?.path,
                    priceDetails: cartAmountDetailResponse?.price_data,
                });
            } else {
                setCartDetails({ cartList: null, imgPath: null, priceDetails: null });
            }
        } catch (error) {
            console.error("Error fetching cart amount data:", error);
            // You may handle the error by setting an error state or providing feedback to the user
            setCartDetails({ cartList: null, imgPath: null, priceDetails: null });
        }
    };


    const fetchAddressList = async () => {
        try {
            let result = await getAddressData(token);
            let defaultAddress = result?.data?.find(item => item?.is_default == 1);
            fillAddressForm(defaultAddress);
            getCartAmountData(user?.token);

        }
        catch (e) {
            console.log('error', e);
        }
    }

    /// Cash on delivery
    const handleCodData = async (addressId, userToken) => {
        try {
            const orderFormData = new URLSearchParams();
            orderFormData.append('address_id', addressId);
            orderFormData.append('buy_now', buyNow);

            const dbResponse = await createOrder(orderFormData, userToken);

            if (dbResponse?.status === "1") {
                // const buyIds = buy?.map((item) => item.id);

                try {
                    // Collect product IDs to be deleted in parallel using Promise.all
                    const deletedProductIds = await Promise.all(cartDetails?.cartList?.map((product) => product?.product?.id));
                    // Filter the cart to remove the deleted products
                    const updatedCart = cart?.filter((item) => !deletedProductIds?.includes(item.id));

                    const updateCartState = (cartItems) => {
                        const couponnull = {};
                        localStorage.setItem('coupon', JSON.stringify(couponnull));
                        dispatch(applyCoupon(couponnull));

                        if (cartItems.length > 0) {
                            localStorage.setItem('cart', JSON.stringify(cartItems));
                            dispatch(addToCart(cartItems));
                        } else {
                            localStorage.removeItem("cart");
                            dispatch(clearCart());
                        }
                    };

                    // Update local storage and dispatch actions based on cart status
                    updateCartState(updatedCart);
                    toast.success('Your order has been placed successfully')

                } catch (error) {
                    console.error("Deleting Error:", error);
                }

                navigate(Routes?.ThankuCheck);

            } else {
                toast.error(STRINGS.PLEASE_TRY_AGAIN_LATER);
            }
        } catch (error) {
            console.error('Error handling COD data:', error);
            toast.error(STRINGS.PLEASE_TRY_AGAIN_LATER);
        }
    };
    ///

    useEffect(() => {
        if (user?.token) {
            const timeoutId = setTimeout(() => {
                getCartAmountData(user?.token);
            }, 1000); // 1 seconds delay

            // Clean up the timeout if the effect runs again or component unmounts
            return () => clearTimeout(timeoutId);
        }
    }, [user?.token, cart, localCoupons]);


    useEffect(() => {
        if (user?.token) {
            fetchAddressList();
            setEmail(user?.email);
        }
    }, [user?.token, window.location.href])

    const placeOrderButtonRef = useRef(null);

    const [formData, setFormData] = useState({
        merchant_param3: buyNow,
        merchant_param2: '', /// user_id ///
        merchant_param5: '' /// address_id ///
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };


    useEffect(() => {
        let timer;
        if (OtpModal && !maskClosable) {
            setMaskClosable(false);
            timer = setTimeout(() => {
                setMaskClosable(true);
            }, timerVal * 1000);
        }

        return () => {
            clearTimeout(timer);
        };
    }, [OtpModal, maskClosable]);


    return (
        <div className='main_checkout'>
            <div className='main_accordian'>
                <div className='checkout_items_accordian'>
                    <Collapse
                        items={items}
                    />
                </div>
            </div>
            <Row>
                <Col xs={24} sm={24} md={24} lg={12}>
                    <div className='main_allsteper'>
                        <Form autoComplete="off" initialValues={{ title: titleValue }} form={form} onFinish={handleSubmit}>

                            <div className='contact_login'>
                                <div className='contact_details'>
                                    <h3>Contact</h3>
                                    {/* <button>Login</button> */}
                                </div>
                                <div className='input_contct'>
                                    <Input
                                        placeholder='Enter Email'
                                        value={email}
                                        onChange={handleEmailChange} // To validate email in real-time
                                        onBlur={() => {
                                            if (isEmailValid) { // Only call checkEmailForUser if the email is valid
                                                checkEmailForUser();
                                            }
                                        }}
                                        disabled={user?.email ? true : false}
                                    />
                                    {!user?.email && !isEmailValid && email?.length > 0 && (
                                        <span style={{ color: 'red' }}>Invalid email address</span>
                                    )}
                                </div>

                            </div>
                            <div className='deliver_login'>
                                <h3>Delivery</h3>
                                <div className='model_form'>
                                    <Row gutter={18}>
                                        <Col span={24}>
                                            <Form.Item
                                                name="name"
                                                label={<>Name</>}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: 'Please enter your name',
                                                    },
                                                ]}
                                            >
                                                <Input placeholder="Enter Name" onKeyDown={handleKeyPressName} />
                                            </Form.Item>
                                        </Col>
                                        <Col span={24}>
                                            <Form.Item
                                                name="phone"
                                                label={<>Phone</>}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: 'Please enter your phone',
                                                    },
                                                    {
                                                        pattern: /^[0-9]{10}$/,
                                                        message: 'Please enter a valid 10-digit phone number',
                                                    },
                                                ]}
                                            >
                                                <Input placeholder="Enter Phone" onKeyDown={handleKeyPressForMobile} maxLength={10} type='text' />
                                            </Form.Item>
                                        </Col>
                                        <Col span={12}>
                                            <Form.Item
                                                name="country"
                                                label={<>Country</>}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: 'Please select your country',
                                                    },
                                                ]}
                                            >
                                                <Select
                                                    showSearch
                                                    // name="country_id"
                                                    placeholder="Select Country"
                                                    optionFilterProp="children"
                                                    onChange={(e) => {
                                                        countryChange(e);
                                                        // stateChange(null)

                                                    }}
                                                    filterOption={(input, option) =>
                                                        option.children
                                                            .toLowerCase()
                                                            .indexOf(input.toLowerCase()) >= 0
                                                    }
                                                    value={country_id || undefined}
                                                >
                                                    {countries &&
                                                        countries?.sort((a, b) => a.country_name.localeCompare(b.country_name))?.filter(item => item?.id == "1")?.map((country, index) => (
                                                            <Select.Option key={index} value={country.id}>
                                                                {country.country_name}
                                                            </Select.Option>
                                                        ))}
                                                </Select>
                                            </Form.Item>
                                        </Col>
                                        <Col span={12}>
                                            <Form.Item
                                                name="state"
                                                label={<>State</>}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: 'Please select your state',
                                                    },
                                                ]}
                                            >
                                                <Select placeholder="Select State"
                                                    showSearch
                                                    onChange={handleStateChange}
                                                    filterOption={(input, option) =>
                                                        option.children
                                                            .toLowerCase()
                                                            .indexOf(input.toLowerCase()) >= 0
                                                    }
                                                >
                                                    {states?.sort((a, b) => a.state_name.localeCompare(b.state_name))?.map((state) => (
                                                        <Select.Option key={state.id} value={state.id}>
                                                            {state.state_name}
                                                        </Select.Option>
                                                    ))}
                                                </Select>
                                            </Form.Item>
                                        </Col>
                                        <Col span={12}>
                                            <Form.Item
                                                name="city"
                                                label={<>City</>}
                                                className='counttyDropdown'
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: 'Please select your city',
                                                    },
                                                ]}
                                            >
                                                <Select placeholder="Select City" showSearch filterOption={(input, option) =>
                                                    option.children
                                                        .toLowerCase()
                                                        .indexOf(input.toLowerCase()) >= 0
                                                }>
                                                    {cities?.sort((a, b) => a.city_name.localeCompare(b.city_name))?.map((city) => (
                                                        <Select.Option key={city.id} value={city.id}>
                                                            {city.city_name}
                                                        </Select.Option>
                                                    ))}
                                                </Select>
                                            </Form.Item>
                                        </Col>
                                        <Col span={12}>
                                            <Form.Item
                                                name="pincode"
                                                label={<>Pincode</>}
                                                className='counttyDropdown'
                                                validateStatus={deliveryError ? 'error' : ''}
                                                help={deliveryError}
                                                onChange={(e) => checkDelivery(e?.target?.value)}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: 'Please enter your pincode',

                                                    },
                                                    {
                                                        pattern: /^[0-9]{6}$/,
                                                        message: 'Please enter a valid 6-digit pincode',
                                                    },
                                                    {
                                                        validator: (_, value) => {
                                                            // Skip custom delivery validation if the field is empty or doesn't match the pattern
                                                            if (!value || !/^[0-9]{6}$/.test(value)) {
                                                                return Promise.resolve();
                                                            }
                                                            return deliveryError
                                                                ? Promise.reject(new Error(deliveryError))
                                                                : Promise.resolve();
                                                        },
                                                    },

                                                ]}
                                            >
                                                <Input placeholder="Enter Pincode" maxLength={6} required
                                                //  onBlur={(e) => checkDelivery(e.target.value)}
                                                />
                                            </Form.Item>
                                        </Col>
                                    </Row>
                                    <Form.Item
                                        name="address"
                                        label={<>Address</>}
                                        rules={[
                                            {
                                                required: true,
                                                message: 'Please enter your full address',
                                            },
                                        ]}
                                    >
                                        <TextArea placeholder="Enter Road/Area/Colony" rows={6} />
                                    </Form.Item>
                                    <Form.Item
                                        name="land_mark"
                                        label={<>Landmark</>}

                                    >
                                        <Input placeholder="Landmark" />
                                    </Form.Item>
                                </div>
                                <div className='model_formSecAddress'>
                                    <Row>
                                        <Col span={24}>
                                            <Form.Item
                                                name="title"
                                                label={(
                                                    <>
                                                        <p>Type of Address</p> <span className='requires_star'>*</span>
                                                    </>
                                                )}
                                                rules={[
                                                    {
                                                        required: true,
                                                        message: 'Please select Type',
                                                    },
                                                ]}
                                            >
                                                <div className='radiobutton_type'>
                                                    <Radio.Group defaultValue={titleValue} value={titleValue} onChange={(e) => setTitleValue(e.target.value)}>
                                                        <Radio value='Home'>Home</Radio>
                                                        <Radio value='Office'>Office</Radio>
                                                        <Radio value='Other'>Other</Radio>
                                                    </Radio.Group>
                                                </div>
                                            </Form.Item>
                                        </Col>
                                        {/* <Col span={24}>
                                            <Form.Item
                                                name='is_default'
                                                valuePropName="checked"
                                            >
                                                <div className="checkbox_sigup">
                                                    <Checkbox checked={defaultValue}>
                                                        Save this information for next time
                                                    </Checkbox>
                                                </div>
                                            </Form.Item>
                                        </Col> */}
                                    </Row>
                                </div>

                                <div className='billing_addresses'>
                                    <h5>Billing address</h5>
                                    <div className='billing_mainCont'>
                                        <Radio.Group onChange={handleRadioChange} value={showBillingForm ? 'differ_bill_add' : 'same_ship_add'}  >
                                            <div className='shippingAddress'>
                                                <Form.Item name='is_shipping_address' valuePropName='checked'>
                                                    <Radio value='same_ship_add' >Same as shipping address</Radio>
                                                </Form.Item>
                                            </div>
                                            <div className='billingAddress'>
                                                <Form.Item name='is_billing_address' valuePropName="checked" >
                                                    <Radio value='differ_bill_add'>Use a different billing address</Radio>
                                                </Form.Item>
                                            </div>
                                        </Radio.Group>


                                        {showBillingForm && (
                                            <div className='gst_form'>
                                                {/* <Form> */}
                                                <Row gutter={18}>
                                                    <Col span={24}>
                                                        <Form.Item
                                                            name="billing_name"
                                                            label={<>Name</>}
                                                            rules={[
                                                                {
                                                                    required: true,
                                                                    message: 'Please enter your name',
                                                                },
                                                            ]}
                                                        >
                                                            <Input placeholder="Enter Name" />
                                                        </Form.Item>
                                                    </Col>
                                                    <Col span={24}>
                                                        <Form.Item
                                                            name="billing_phone"
                                                            label={<>Phone</>}
                                                            rules={[
                                                                {
                                                                    required: true,
                                                                    message: 'Please enter your phone',
                                                                },
                                                                {
                                                                    pattern: /^[0-9]{10}$/,
                                                                    message: 'Please enter a valid 10-digit phone number',
                                                                },
                                                            ]}
                                                        >
                                                            <Input placeholder="Enter Phone" maxLength={10} type='text' />
                                                        </Form.Item>
                                                    </Col>
                                                    <Col span={12}>
                                                        <Form.Item
                                                            name="billing_country_id"
                                                            label={<>Country</>}
                                                            rules={[
                                                                {
                                                                    required: true,
                                                                    message: 'Please select your country',
                                                                },
                                                            ]}
                                                        >
                                                            <Select
                                                                showSearch
                                                                name="billing_country_id"
                                                                placeholder="Select Country"
                                                                optionFilterProp="children"
                                                                onChange={(e) => {
                                                                    billingCountryChange(e);
                                                                    // stateChange(null)

                                                                }}
                                                                filterOption={(input, option) =>
                                                                    option.children
                                                                        .toLowerCase()
                                                                        .indexOf(input.toLowerCase()) >= 0
                                                                }
                                                                value={billingCountry_id || undefined}
                                                            >
                                                                {billingCounties &&
                                                                    billingCounties?.sort((a, b) => a.country_name.localeCompare(b.country_name))?.filter(item => item?.id == "1")?.map((country, index) => (
                                                                        <Select.Option key={index} value={country.id}>
                                                                            {country.country_name}
                                                                        </Select.Option>
                                                                    ))}
                                                            </Select>
                                                        </Form.Item>
                                                    </Col>
                                                    <Col span={12}>
                                                        <Form.Item
                                                            name="billing_state_id"
                                                            label={<>State</>}
                                                            rules={[
                                                                {
                                                                    required: true,
                                                                    message: 'Please select your state',
                                                                },
                                                            ]}
                                                        >
                                                            <Select placeholder="Select State"
                                                                showSearch
                                                                onChange={handleBillingStateChange}
                                                                filterOption={(input, option) =>
                                                                    option.children
                                                                        .toLowerCase()
                                                                        .indexOf(input.toLowerCase()) >= 0
                                                                }
                                                            >
                                                                {billingStates?.sort((a, b) => a.state_name.localeCompare(b.state_name))?.map((state) => (
                                                                    <Select.Option key={state.id} value={state.id}>
                                                                        {state.state_name}
                                                                    </Select.Option>
                                                                ))}
                                                            </Select>
                                                        </Form.Item>
                                                    </Col>
                                                    <Col span={12}>
                                                        <Form.Item
                                                            name="billing_city_id"
                                                            label={<>City</>}
                                                            className='counttyDropdown'
                                                            rules={[
                                                                {
                                                                    required: true,
                                                                    message: 'Please select your city',
                                                                },
                                                            ]}
                                                        >
                                                            <Select placeholder="Select City" showSearch filterOption={(input, option) =>
                                                                option.children
                                                                    .toLowerCase()
                                                                    .indexOf(input.toLowerCase()) >= 0
                                                            }>
                                                                {billingCities?.sort((a, b) => a.city_name.localeCompare(b.city_name))?.map((city) => (
                                                                    <Select.Option key={city.id} value={city.id}>
                                                                        {city.city_name}
                                                                    </Select.Option>
                                                                ))}
                                                            </Select>
                                                        </Form.Item>
                                                    </Col>
                                                    <Col span={12}>
                                                        <Form.Item
                                                            name="billing_pincode"
                                                            label={<>Pincode</>}
                                                            className='counttyDropdown'
                                                            rules={[
                                                                {
                                                                    required: true,
                                                                    message: 'Please enter your pincode',
                                                                },
                                                                {
                                                                    pattern: /^[0-9]{6}$/,
                                                                    message: 'Please enter a valid 6-digit pincode',
                                                                },
                                                            ]}
                                                        >
                                                            <Input placeholder="Enter Pincode" maxLength={6} />
                                                        </Form.Item>
                                                    </Col>
                                                    <Col span={24}>
                                                        <Form.Item
                                                            name="billing_address"
                                                            label="Address"
                                                            rules={[
                                                                {
                                                                    required: true,
                                                                    message: 'Please enter your address',
                                                                },

                                                            ]}
                                                        >
                                                            <Input placeholder="Enter Address" />
                                                        </Form.Item>
                                                    </Col>
                                                </Row>
                                                {/* </Form> */}
                                            </div>
                                        )}
                                    </div>
                                </div>

                            </div>
                            <div className="payment-form">
                                <h3>Payment</h3>
                                <span>All transactions are secure and encrypted.</span>

                                <div className='payment_mode_card'>
                                    <div className='account_masterTabs'>
                                        <Tabs activeKey={activeTab} tabPosition='left' onChange={setActiveTab} items={tabItems}>
                                        </Tabs>
                                    </div>
                                    {!codAvailable && <span style={{color:'red'}}>{codAvailableMessage}</span>}
                                    {(activeTab === 'payPal' || activeTab === 'razorpay') && <div className="paymentContent_wrapper">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="-252.3 356.1 163 80.9" class="zjrzY"><path fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="2" d="M-108.9 404.1v30c0 1.1-.9 2-2 2H-231c-1.1 0-2-.9-2-2v-75c0-1.1.9-2 2-2h120.1c1.1 0 2 .9 2 2v37m-124.1-29h124.1"></path><circle cx="-227.8" cy="361.9" r="1.8" fill="currentColor"></circle><circle cx="-222.2" cy="361.9" r="1.8" fill="currentColor"></circle><circle cx="-216.6" cy="361.9" r="1.8" fill="currentColor"></circle><path fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="2" d="M-128.7 400.1H-92m-3.6-4.1 4 4.1-4 4.1"></path></svg>
                                        <span>After clicking “Pay now”, you will be redirected to CC Avenue (UPI, Cards, Wallets, NetBanking) to complete your purchase securely.</span>
                                    </div>}
                                </div>

                            </div>
                            <button className='pay_btn' disabled={loading ? true : false}>{loading ? <Spin /> : activeTab === 'payPal' || activeTab === 'razorpay' ? 'Pay Now' : 'Place your order'}</button>
                        </Form>
                    </div>
                </Col>
                <Col xs={24} sm={24} md={24} lg={12}>
                    <div className='main_carts_section'>
                        <div className="checkout_bag">
                            {buy?.length > 0 ? showBuyProducts() : showCartProducts()}
                        </div>
                        {
                            user?.token ?
                                <PriceDetails cartDetailPrice={cartDetails?.priceDetails} />
                                :
                                <DrawerLocalCartPriceList from={'maincheckout'} />
                        }
                    </div>
                </Col>
            </Row>

            {/* Verify OTP MODAL */}
            <Modal
                open={OtpModal}
                maskClosable={maskClosable}
                // onOk={handleOk}
                onCancel={handleCancel}
                closeIcon={maskClosable}
                width={400}
                className='otpopUp_model'
                footer={
                    <div className='custom-modal-footer mt-4'>
                        <Button disabled={resendDisabled} className='cancel_Button' onClick={checkEmailForUser}>Resend OTP</Button>
                        <Button key="verify" className='deleteButton' onClick={verifyOtp}>
                            Verify
                        </Button>
                    </div>
                }
            >
                <div className="otpModel_heading">
                    <div className="otpSvg">
                        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24">
                            <path fill="currentColor" d="M12 20.962q-3.013-.895-5.007-3.651Q5 14.554 5 11.1V5.692l7-2.615l7 2.615V11.1q0 3.454-1.993 6.21q-1.994 2.757-5.007 3.652Zm0-1.062q2.425-.75 4.05-2.962T17.95 12H12V4.144L6 6.375v5.156q0 .194.05.469H12v7.9Z" />
                        </svg>
                    </div>
                    <span>Verify with OTP</span>
                    {/* <h6>OTP sent on +91 xxxxxx{modalValue?.contactnumber.slice(-4)}</h6> */}
                </div>
                <div className="otp_inputBox" >
                    {renderStarInputs()}
                </div>
                <div className="resend_tym">
                    {!(minutes == 0 && seconds == 0) && <span>Enable Resend OTP in {minutes}:{seconds < 10 ? `0${seconds}` : seconds}</span>}
                </div>
            </Modal>


            {/* for payment gateway */}
            <form name="customerData" method="POST" action={`${paymentUrl}/initiate-payment`}>
                <table width="40%" height="100" border='1' align="center" style={{ display: 'none' }}>
                    <tbody>
                        <tr>
                            <td>Parameter Name:</td>
                            <td>Parameter Value:</td>
                        </tr>
                        <tr>
                            <td colSpan="2">Compulsory information</td>
                        </tr>
                        {Object.keys(formData).map((key, index) => (
                            <tr key={index}>
                                <td>{key.replace(/_/g, ' ')}</td>
                                <td>
                                    <input
                                        type="text"
                                        name={key}
                                        value={formData[key]}
                                        onChange={handleChange}
                                    />
                                </td>
                            </tr>
                        ))}
                        <tr>
                            <td colSpan="2"></td>
                        </tr>
                    </tbody>
                    <button type='submit' value="Checkout" ref={placeOrderButtonRef}>Place Order </button>
                </table>
            </form>
        </div>
    )
}

export default MainCheckout