import React, { useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Routes from '../../Routes/Routes';
import { clearBuy } from '../../reducers/buySlice';
import { useDispatch } from 'react-redux';
import { addToCart } from '../../reducers/cartSlice';
import paymentFailed from '../../assets/images/Screenshot 2024-10-18 172332.png'

const PaymentFailed = () => {
  const navigate = useNavigate()
  const dispatch = useDispatch();

  useEffect(() => {
    const buy = JSON.parse(localStorage.getItem('buy')) || [];
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    buy.forEach(item => {
      const existingItemIndex = cart.findIndex(cartItem => cartItem.id === item.id);
      if (existingItemIndex !== -1) {
        cart[existingItemIndex].count += item.count;
      } else {
        cart.push(item);
      }
    });
    localStorage.setItem('cart', JSON.stringify(cart));
    dispatch(addToCart(cart));
    dispatch(clearBuy());
    localStorage.removeItem('buy');
  }, []);




  return (
    <>
      <div className='chcekout_thank_page'>
        <div className='checkout_failed'>
          <img src={paymentFailed} alt="" />
          <h3>Payment Failed</h3>
          <span>Your transaction has failed due to some techincal error. Please try again!</span>
        </div>
        <div className='trackOrder'>
          <button onClick={() => navigate("/")}>Continue Shopping</button>
        </div>
      </div>
      <div className='payment_footer'>
        <Link to={Routes.Terms} state={{ from: "#returnCancel" }}><span>Refund policy  </span></Link>
        <div className='profile_dashed'>|</div>
        <Link to={Routes.Terms} state={{ from: "#privacyPolicy" }}><span>Privacy policy </span></Link>
        <div className='profile_dashed'>|</div>
        <Link to={Routes.Terms} state={{ from: "#termsCond" }}><span>Terms & Conditions</span></Link>
      </div>
    </>
  )
}

export default PaymentFailed