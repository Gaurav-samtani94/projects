import React, { useEffect, useRef, useState } from 'react'
import { Link, useParams, useLocation, useNavigate } from 'react-router-dom';
import { getProductList } from '../../services/home';
import { Row, Col, Checkbox, Modal, Radio, Spin } from 'antd';
import { LiaGreaterThanSolid } from "react-icons/lia";
import Routes from '../../Routes/Routes';
import Wishlist from '../../function/Wishlist';
import dImg from '../../assets/images/d.png';
import { CategoryList, DiscountList, MaterialList } from '../../services/filter/categories';
import { getColor } from '../../services/filter/color';
import { useDispatch, useSelector } from 'react-redux';
import AddToCart from '../../function/AddToCart';
import { Carousel } from 'react-bootstrap';
import { addToChip } from '../../reducers/filterSlice';
import { addToCompare } from '../../reducers/compareSlice';
import { addToSlug } from '../../reducers/slugSlice';
import ProductPrice from '../../components/ProductPrice';
import ScrollComponent from '../../components/ScrollComponent';
import FilterDrawer from '../../components/MobileViewFilter';
import ProductImage from '../../components/ProductImage';
import grid2 from '../../assets/images/18.webp';
import grid3 from '../../assets/images/19.webp';
import grid4 from '../../assets/images/20.webp';
import CommFilter from '../../components/CommFilter';
import { addProductCount } from '../../reducers/productCountSlice';
const ProductCategory = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const [activeSpan, setActiveSpan] = useState(null);
    const [categoryList, setCategoryList] = useState();
    const [productList, setProductList] = useState([]);
    const [maxPrice, setMaxPrice] = useState();
    const [filterList, setFilterList] = useState([])
    const [priceRange, setPriceRange] = useState([0, maxPrice]);
    const [colorPath, setColorPath] = useState(null);
    const [categoryImgPath, setCategoryImgPath] = useState(null);
    const [sliderPath, setSliderPath] = useState(null);
    const [currentPage, setCurrentPage] = useState(0);
    const [pagination, setPagination] = useState({
        limit: 20,
        page_number: 1,
        totalItems: '',
        totalPages: '',
        perPagedata: ''
    })
    const [stockToggle, setStockToggle] = useState(0)
    const dispatch = useDispatch();
    const chips = useSelector(state => state.chips);
    const comp = useSelector(state => state.comp);
    const [materialList, setMaterialList] = useState([])
    const [discountList, setDiscountList] = useState([])
    const [selectedDiscount, setSelectedDiscount] = useState('')
    let from;
    let route;
    let categorySlug;
    let menuSlug;
    let compare;
    if (location.state) {
        from = location.state.from;
        menuSlug = location.state.menuSlug
        categorySlug = location.state.categorySlug;
        route = location.state.route;
        compare = location.state.compare
    }

    const urlName = location.pathname.split('/');
    const lastSegment = urlName[urlName.length - 1];
    const newChipsData = chips.filter(chipsItem => chipsItem?.pagneName === lastSegment);
    const { slug } = useParams();
    const [category, setCategory] = useState(null);
    const [imgPath, setimgPath] = useState(null);
    const [selectedSorting, setSelectedSorting] = useState(null);
    const [isFetching, setIsFetching] = useState(false)
    const stockToggleItem = newChipsData.find(item => item.type === 'stockToggle');
    const stockToggleValue = stockToggleItem ? stockToggleItem.value : stockToggle;
    const existingDiscountValue = newChipsData.find(item => item.discountID === 1)?.minDiscount ?? "";

    const price_range = newChipsData?.find(i => i?.priceRangeID === 1)?.priceRange ?? "";
    // featch data
    const fetchData = async () => {
        setIsFetching(true)
       
        const formData = new URLSearchParams();
        formData.append('slug', slug);
        formData.append('user_id', user?.id);
        formData.append('color_id', colorIds);
        formData.append('sorting', selectedSorting ?? '');
        formData.append('material_id', materialIds);
        formData.append('type_ids', typeIds);
        formData.append('min_price', price_range[0] ?? '');
        formData.append('max_price', price_range[1] ?? "ALL");
        formData.append('discount', existingDiscountValue)
        formData.append('remove_stock', stockToggleValue)
        formData?.append("limit", pagination.limit)
        formData?.append("page_number", pagination?.page_number)
        try {
            setIsProLoading(true)
            const response = await getProductList(slug, formData);
            // setCurrentPage(Number(response.currentPage));
            if (response.status === '1') {
                if (newChipsData?.length < 1) {
                    setMaxPrice(response?.max_price);
                }
                const obj = {
                    page_name: lastSegment,
                    max_price: response?.max_price,
                };

                let prevMaxPriceArray = JSON.parse(localStorage.getItem("newMaxprice")) || [];
                let exists = prevMaxPriceArray.some((item) => item.page_name === obj.page_name);

                if (!exists) {
                    prevMaxPriceArray.push(obj);
                    localStorage.setItem("newMaxprice", JSON.stringify(prevMaxPriceArray));
                }
                setPriceRange([0, response?.max_price])
                setCategory(response?.category?.categories);
                setCategoryImgPath(response.category_path);

                if (newChipsData?.length > 0 || selectedSorting) {
                    if (pagination?.page_number == "1") {
                        setFilterList(response);
                    } else {
                        setFilterList(prevProductList => {
                            const existingIds = new Set(prevProductList?.data?.map(item => item.product_name));
                            const uniqueNewData = response.data.filter(item => !existingIds.has(item.product_name));
                            return {
                                ...prevProductList,
                                data: [...(prevProductList?.data || []), ...uniqueNewData],
                            };
                        });
                    }
                } else {
                    setProductList(prevProductList => {
                        const existingIds = new Set(prevProductList?.data?.map(item => item.product_name));
                        const uniqueNewData = response.data.filter(item => !existingIds.has(item.product_name));
                        return {
                            ...prevProductList,
                            data: [...(prevProductList?.data || []), ...uniqueNewData],
                        };
                    });
                }

                setimgPath(response.product_path)
                setSliderPath(response.page_slider)
                setIsProLoading(false)
                setIsFetching(false)
                // Set and store the product count
                const productCount = response.data.length;
                sessionStorage.setItem('productCount', productCount);
                setPagination((prevPagination) => ({
                    ...prevPagination,
                    totalItems: response?.totalItems,
                    totalPages: response?.totalPages,
                    perPagedata: response?.dataoncurrentPage
                }));
            } else {
                // console.log('Response', 'Record Not Found!');
                setIsProLoading(false)
            }
            if(response?.data?.length < 1){
            dispatch(addProductCount(true))
            }
        } catch (error) {
            // console.error('Error fetching product list:', error);
            setIsProLoading(false)
            dispatch(addProductCount(true))
        }
        // }
    };


    const previousSearchValueRef = useRef(slug);

    const [shouldFetch, setShouldFetch] = useState(false);
    useEffect(() => {
        setProductList([]);
        // if(previousSearchValueRef.current !== slug) {
        // Reset productList and pagination when slug changes
        localStorage.removeItem("maxPrice");
            setPagination({
                limit: 20,
                page_number: 1,
                totalItems: '',
                totalPages: '',
                perPagedata: ''
            });
            // fetchData();
            setShouldFetch(true);
        // }
    }, [slug]); // Run whenever `slug` changes

    useEffect(() => {
        if (pagination?.page_number == 1 && shouldFetch) {
            fetchData();
            setShouldFetch(false);  // Reset shouldFetch after fetching
        }
    }, [pagination?.page_number, shouldFetch]);
    const [colorList, setColorList] = useState(null);

    const commonList = newChipsData?.length > 0 || selectedSorting ? filterList : productList;
    const fetchMaterialList = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('slug', slug);

            const response = await MaterialList(formData);
            if (response.status === '1') {
                setMaterialList(response.data)
            } else {
                // console.log('Response', 'Record Not Found !');
            }
        } catch (error) {
            console.error('Error fetching product list :', error);
        }
    }
    const fetchColorList = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('slug', slug);
            const response = await getColor(formData, user?.token);
            if (response.status === '1') {
                setColorList(response.data);
                setColorPath(response?.path)
            }
        } catch (error) {
            // console.log('Error fetching color List :', error);
        }
    }

    const fetchCategoryList = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('slug', slug);

            const response = await CategoryList(formData);
            // console.log('responseresponseresponseresponse vivek',response);
            if (response.status === '1') {
                setCategoryList(response.data)
            } else {
                // console.log('Response', 'Record Not Found !');
            }
        } catch (error) {
            console.error('Error fetching product list :', error);
        }
    }

    // const urlName = window?.location?.href.split('/');

    useEffect(() => {
        fetchCategoryList();
        fetchMaterialList();
        fetchDiscountList();
        fetchColorList();
        setCheckedColors(newChipsData.map(chip => chip.colorid));
        const stockToggleItem = newChipsData?.find(item => item.type === 'stockToggle');
        if (stockToggleItem) {
            setStockToggle(stockToggleItem.value);
        } else {
            setStockToggle(0)
        }
        const existingDiscount = newChipsData.find(item => item.discountID === 1);
        if (existingDiscount) {
            setSelectedDiscount(existingDiscount.discountRange);
        } else {
            setSelectedDiscount('')
        }
    }, [slug])


    const handleSpanClick = (index) => {
        setActiveSpan(index);
    };

    // console.log(stockToggle,"stockToggle")

    const removeOutOfStocks = () => {
        const newStockToggle = stockToggle === 0 ? 1 : 0;
        setStockToggle(newStockToggle);
        let updatedNames;
        if (newStockToggle === 0) {
            updatedNames = chips.filter(item => item.type !== 'stockToggle');
        } else {
            updatedNames = chips.map(item =>
                item.type === 'stockToggle'
                    ? { ...item, value: newStockToggle }
                    : item
            );

            // If the stockToggle item doesn't exist, add it
            if (!updatedNames.find(item => item.type === 'stockToggle')) {
                updatedNames.push({ type: 'stockToggle', value: newStockToggle, pagneName: lastSegment });
            }
        }

        localStorage.setItem('chips', JSON.stringify(updatedNames));
        dispatch(addToChip(updatedNames));
    };
    const onCheckbox = (id, childName) => {
        // Retrieve namesArray from localStorage or initialize it as an empty array
        const namesArray = JSON.parse(localStorage.getItem('chips')) || [];

        // Check if the id already exists in namesArray
        const existingIndex = namesArray.findIndex(item => item.id === id);

        // If the id exists, remove it; otherwise, add it
        if (existingIndex !== -1) {
            namesArray.splice(existingIndex, 1);
        } else {
            namesArray.push({ id, childName, pagneName: lastSegment });
        }

        // Update localStorage
        localStorage.setItem('chips', JSON.stringify(namesArray));

        // Dispatch an action or update state as needed
        dispatch(addToChip(namesArray));
    };

    const handleMaterialChange = (materialData) => {
        const { id, material_name } = materialData
        const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
        const existingIndex = namesArray.findIndex(item => item.materialId === id);
        if (existingIndex !== -1) {
            namesArray.splice(existingIndex, 1);
        } else {
            namesArray.push({ materialId: id, childName: material_name, pagneName: lastSegment });
        }
        localStorage.setItem('chips', JSON.stringify(namesArray));
        dispatch(addToChip(namesArray));
    }

    const handleDiscount = (value) => {
        setSelectedDiscount(value);
        // fetchTimeout.current = setTimeout(() => {
        const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
        const existingIndex = namesArray.findIndex(item => item.discountID === 1);

        const discountRange = value.split('-');
        const fromDiscount = discountRange[0];
        const toDiscount = discountRange[1];
        const discountFormat = (fromDiscount == '0' && toDiscount == '100') ? 'Discount: All' : `Discount: ${fromDiscount}% Above`;

        if (existingIndex !== -1) {
            namesArray[existingIndex] = { discountID: 1, discountRange: value, childName: discountFormat, minDiscount: fromDiscount, maxDiscount: toDiscount, pagneName: lastSegment };
        } else {
            namesArray.push({ discountID: 1, discountRange: value, childName: discountFormat, minDiscount: fromDiscount, maxDiscount: toDiscount, pagneName: lastSegment });
        }

        localStorage.setItem('chips', JSON.stringify(namesArray));
        dispatch(addToChip(namesArray));
        // }, 400);

    }

    const saveMaxPrice = JSON?.parse(localStorage.getItem("newMaxprice"));

    const updated_max_price = saveMaxPrice?.find(i => i?.page_name == lastSegment)?.max_price
    // console.log(updated_max_price,"updated_max_price")
    useEffect(() => {
        const max_Price = parseFloat(updated_max_price);
        if (max_Price > 0) {
            setMaxPrice(max_Price);
            // setPriceRange([0, saveMaxPrice])
        }
    }, [])

    const [checkedColors, setCheckedColors] = useState([]);


    const items = categoryList && categoryList.map((category, index) => ({
        key: `${index + 1}`,
        label: "Type",
        children: (
            <div className="SubCategory">
                {category.child_items && category.child_items.map((child, childIndex) => (
                    <span key={`child-${child.id}`} onClick={() => handleSpanClick(childIndex)} className={activeSpan === childIndex ? 'active' : ''}>
                        <Checkbox checked={newChipsData?.some(chip => chip.id === child.id)} onChange={() => onCheckbox(child.id, child.name)}>{child.name}</Checkbox>
                    </span>
                ))}
            </div>
        ),
    }));

    const itemsMaterial = (materialList) => [{
        key: 'materials-panel',
        label: "Material",
        children: (
            <div className="SubCategory">
                {materialList.map(material => (
                    <span key={`material-${material.id}`} className=''>
                        <Checkbox checked={newChipsData?.some(chip => chip.materialId === material.id)} onChange={() => handleMaterialChange(material)}>{material.material_name}</Checkbox>
                    </span>
                ))}
            </div>
        ),
    }];
    // used discount Chips
    const discountItem = (discountList) => [{
        key: "discounts-panel",
        label: "Discount",
        children: (
            <Radio.Group value={selectedDiscount} onChange={(e) => handleDiscount(e?.target?.value)} >
                <div className="SubCategory">
                    {discountList?.map((discountVal, discountIndex) => (
                        <span key={`discount-${discountIndex}`} className=''>
                            <Radio value={discountVal.from_discount_val + '-' + discountVal.to_discount_val}>
                                {discountVal.from_discount_val === 0 && discountVal.to_discount_val === 100 ? 'All' : `${discountVal.from_discount_val}% Above`}
                            </Radio>
                        </span>
                    ))}
                </div>
            </Radio.Group>
        ),
    }];
    const catDataArr = useSelector((state) => state.cat?.catData);
    useEffect(() => {
        if (Array.isArray(catDataArr)) {
            const slugData = catDataArr.map(item => item.slug).filter(Boolean); // Extracting slugs
            const validSegments = new Set(slugData);

            if (!validSegments.has(slug)) {
                const slugInfo = `collections/${slug}`;
                dispatch(addToSlug({ slug: slugInfo }));
                navigate(`/${slugInfo}`);
            }
        }
        setSelectedSorting(null);
    }, [slug, catDataArr, dispatch, navigate]); // Ensure all dependencies are included


    const user = useSelector((state) => state.user);


    const [isProLoading, setIsProLoading] = useState(false)

    const { materialIds, colorIds, typeIds } = chips.filter(chipsItem => chipsItem?.pagneName === lastSegment)
        .reduce((acc, chipsItem) => {
            if (chipsItem.materialId) acc.materialIds.push(chipsItem.materialId);
            if (chipsItem.colorid) acc.colorIds.push(chipsItem.colorid);
            if (chipsItem?.typeId) acc?.typeIds?.push(chipsItem?.typeId);
            return acc;
        }, { materialIds: [], colorIds: [], typeIds: [] });

    const fetchTimeout = useRef(null);

    const handlePriceChange = (value) => {
        const [min, max] = value;
        if (min > max) {
            setPriceRange([max, max]);
        } else {
            setPriceRange(value);
        }
        // Clear the previous timeout
        if (fetchTimeout.current) {
            clearTimeout(fetchTimeout.current);
        }

        // Set a new timeout
        fetchTimeout.current = setTimeout(() => {
            const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
            const existingIndex = namesArray.findIndex(item => item.priceRangeID === 1);

            if (existingIndex !== -1) {
                // Replace the existing item
                namesArray[existingIndex] = { priceRangeID: 1, priceRange: value, childName: `Price: ${min} - ${max}`, maxPrice: maxPrice, pagneName: lastSegment };
            } else {
                // Add a new item
                namesArray.push({ priceRangeID: 1, priceRange: value, childName: `Price: ${min} - ${max}`, maxPrice: maxPrice, pagneName: lastSegment });
            }

            localStorage.setItem('chips', JSON.stringify(namesArray));
            dispatch(addToChip(namesArray));
        }, 400);
    };

    useEffect(() => {
        const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
        const existingIndex = newChipsData.findIndex(item => item.priceRangeID === 1);
        const existingDiscount = newChipsData.find(item => item.discountID === 1);
        if (existingDiscount) {
            setSelectedDiscount(existingDiscount.discountRange);
        }

        if (existingIndex !== -1) {
            const [existingMinPrice, existingMaxPrice] = chips[existingIndex].priceRange;
            setPriceRange([existingMinPrice, existingMaxPrice]);
            setMaxPrice(namesArray[existingIndex]?.maxPrice);
        } else {
            setPriceRange([0, updated_max_price]);
        }
        if (chips.length <= 0) {
            // fetchData();
            // setFilterColor([]);
            setPriceRange([0, maxPrice]);
            setStockToggle(0);
        }
        setCheckedColors(newChipsData.map(chip => chip.colorid));

    }, []);


    //  featch data for filter used only

    // After used for discount 
    const fetchDiscountList = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('slug', slug);

            const response = await DiscountList(formData);
            if (response.status === '1') {
                setDiscountList(response.data)
            } else {
                // console.log('Response', 'Record Not Found !');
            }
        } catch (error) {
            // console.error('Error fetching product list :', error);
        }
    }

    const handleItem = (slug, from, route, dataSlug, menuSlug, catfirstegorySlug, ProductId) => {
        navigate(`${Routes.ProductDetail}/${slug}`, { state: { dataSlug, route, from, menuSlug, categorySlug, ProductId } });
    }
    const [isActiveIcon, setIsActiveIcon] = useState(false);
    const [isActiveSec, setIsActiveSec] = useState(false);

    const [index, setIndex] = useState(0);

    const handleSelect = (selectedIndex) => {
        setIndex(selectedIndex);
    };

    const [isDrawerVisible, setIsDrawerVisible] = useState(false);

    const toggleDrawerVisibility = () => {
        setIsDrawerVisible(!isDrawerVisible);
    };

    const closeDrawer = () => {
        setIsDrawerVisible(false);
    };

    const onChanged = (colorId) => {

        const { color, id, image } = colorId
        const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
        const existingIndex = namesArray.findIndex(item => item.colorid === id);
        if (existingIndex !== -1) {
            namesArray.splice(existingIndex, 1);
        } else {
            namesArray.push({ colorid: id, childName: color, image, pagneName: lastSegment });
        }
        localStorage.setItem('chips', JSON.stringify(namesArray));
        dispatch(addToChip(namesArray));
        setCheckedColors(namesArray.map(chip => chip.colorid));
    };
    const Breadcrumb = (from, menuSlug) => {
        navigate(`${Routes.ProductCategory}/${categorySlug}`, { state: { from, menuSlug } },)
    }
    const [marks, setMarks] = useState({});

    useEffect(() => {
        if (maxPrice > 1) {
            const updatedMarks = {
                0: '0',
                [maxPrice]: {
                    style: {
                        color: '#000',
                    },
                    label: <strong>{maxPrice}</strong>,
                },
            };
            setMarks(updatedMarks);

        }
        localStorage.removeItem('compareIDS');
    }, [maxPrice]);
    const [isCheckboxChecked, setIsCheckboxChecked] = useState(false);
    const compareData = JSON.parse(localStorage.getItem('compareData'));
    const onChangeCheck = (comData, e) => {

        const { product_name = '', price = 0, id } = comData;
        const comimage = `${productList.product_path}${comData.productimages[0]?.file_name_120_x_120}`;

        const dataToStore = {
            product_name,
            price,
            comimage,
            id,
            slug
            // Adding 'id' to 'dataToStore'
        };
        if (e && e.target) {
            const isChecked = e.target.checked;
            // console.log('isChecked',isChecked);
            setIsCheckboxChecked(isChecked);
            const singleCompareId = JSON.parse(localStorage.getItem('compareData')) || {};
            let compareIDs = JSON.parse(localStorage.getItem('comp')) || [];

            if (!Array.isArray(compareIDs)) {
                compareIDs = [];
            }
            if (singleCompareId.id !== comData.id) {
                if (isChecked) {
                    // Checking if the ID is already present in the compareIDs array
                    const alreadyExists = compareIDs.some(item => item.id === comData.id);
                    if (!alreadyExists) {
                        compareIDs.push(dataToStore);
                    }
                } else {
                    // Removing the item with matching ID
                    compareIDs = compareIDs.filter(compareID => compareID.id !== comData.id);
                }
                if (comp.length + 1 <= 4 || isChecked === false) {
                    // console.log('comp.length',comp.length);
                    dispatch(addToCompare(compareIDs));
                    localStorage.setItem('comp', JSON.stringify(compareIDs));
                }
            }
        }

    };
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = () => {

        navigate(`${Routes.Home}compareDetail`);
        // setIsModalOpen(true);
    };
    useEffect(() => {
        if (compare === true) {
            if (comp.length >= 4) {
                setIsModalOpen(true);
                setIsCheckboxChecked(true);
            } else if (comp.length >= 1) {
                setIsCheckboxChecked(true);
            }
        } else {
            setIsCheckboxChecked(false);
        }
    }, [comp, compare]); // Add comp and navigate to the dependency array
    const handleModalAction = () => {
        setIsModalOpen(false);
        let compareIDs = JSON.parse(localStorage.getItem('comp')) || [];
        compareIDs = compareIDs.filter(compareID => compareID.id !== compareIDs[3].id);
        dispatch(addToCompare(compareIDs));
        localStorage.setItem('comp', JSON.stringify(compareIDs));
    };

    const handleOk = () => {
        handleModalAction();
    };

    const handleCancel = () => {
        handleModalAction();
    };
    const [gridLayout, setGridLayout] = useState('md');


    const handleGridLayoutChange = (layout) => {
        setGridLayout(layout);
    };

    // useEffect(() => {
    //     handleGridLayoutChange('md');
    // }, []);

    const renderGridIcons = () => (
        <div className="grid-icons">
            <div className="grid-icon" onClick={() => handleGridLayoutChange('sm')}>
                <img src={grid2} width="24" height="24" alt='' />

            </div>
            <div className="grid-icon" onClick={() => handleGridLayoutChange('md')}>
                <img src={grid3} width="24" height="24" alt='' />
            </div>
            <div className="grid-icon" onClick={() => handleGridLayoutChange('lg')}>
                <img src={grid4} width="24" height="24" alt='' />
            </div>
        </div>
    );

    const getColSpan = () => {
        switch (gridLayout) {
            case 'sm':
                return { xs: 12, sm: 12 };
            case 'md':
                return { xs: 12, sm: 12, md: 8 };
            case 'lg':
                return { xs: 12, sm: 12, md: 8, lg: 6 };
            default:
                return { xs: 12, sm: 12, md: 8, lg: 6 };
        }
    };

    const productSectionRef = useRef(null); // Ref for the product listing section

    useEffect(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, [])

    return (
        <>
            <div className="drinkware_main">
                <div className="drinkware_top_img_sec">
                    <Carousel activeIndex={index} onSelect={handleSelect}>
                        {category?.assign_slider !== null ? (
                            category?.assign_slider?.page_slider?.page_slider_images.map((slider, index) => (
                                <Carousel.Item key={`slider-${slider?.id}`}>
                                    {/* <img src={`${sliderPath}${slider.image}`} alt={slider.image_title} /> */}
                                    <ProductImage imgPath={sliderPath} imgName={slider.image} alt={slider.image_title} />
                                    <Carousel.Caption>
                                        <div className='giftly_heading_para'>
                                            <h1>{slider.image_title}</h1>
                                            <p>{slider.inner_description}</p>
                                        </div>
                                    </Carousel.Caption>
                                </Carousel.Item>
                            ))
                        ) : (
                            <Carousel.Item>
                                <ProductImage imgPath={categoryImgPath} imgName={category.image} alt={category.name} />
                                <Carousel.Caption>
                                    <div className='giftly_heading_para'>
                                        <h1>{category && category?.name}</h1>
                                        <p>{category && category?.description}</p>
                                    </div>

                                </Carousel.Caption>
                            </Carousel.Item>
                        )}
                    </Carousel>
                </div>

                <div className='chips_grids'>
                    <div className="path_drinkware">
                        <Link to="/">Home</Link>
                        <LiaGreaterThanSolid />
                        {from && (
                            <>
                                {/* <LiaGreaterThanSolid /> */}
                                <span onClick={() => navigate(`/${menuSlug}`)}>{from}</span>
                                <LiaGreaterThanSolid />
                            </>
                        )}
                        {route && (
                            <>
                                {/* <LiaGreaterThanSolid /> */}
                                <span onClick={() => Breadcrumb(from, menuSlug)}>{route}</span>
                                <LiaGreaterThanSolid />
                            </>
                        )}
                        <p>{category && category.name}</p>
                    </div>
                    {renderGridIcons()}
                </div>
                <CommFilter isFetching={isFetching} slug={slug} setProductList={setProductList} setimgPath={setimgPath} fetchProducts={fetchData} setCategoryImgPath={setCategoryImgPath} setSliderPath={setSliderPath} setCategory={setCategory} maxPrice={maxPrice} pagination={pagination} setPagination={setPagination} productListRef={productSectionRef} setStockToggle={setStockToggle} stockToggle={stockToggle} setSelectedSorting={setSelectedSorting} selectedSorting={selectedSorting} currentPage={currentPage}/>
                {/* <>
                    <div className='price_heading_para'>
                        <div className='price_details'>
                            <div className='price_filterCont'>
                                <span>under</span>
                                <p>599</p>
                            </div>
                            <span>599 Store</span>
                        </div>
                        <div className='price_details'>
                            <div className='price_filterCont'>
                                <span>under</span>
                                <p>999</p>
                            </div>
                            <span>999 Store</span>
                        </div>
                        <div className='price_details'>
                            <div className='price_filterCont'>
                                <span>under</span>
                                <p>1599</p>
                            </div>
                            <span>1599 Store</span>
                        </div>
                        <div className='price_details'>
                            <div className='price_filterCont'>
                                <span>under</span>
                                <p>1999</p>
                            </div>
                            <span>1999 Store</span>
                        </div>
                        <div className='price_details'>
                            <div className='price_filterCont'>
                                <span>under</span>
                                <p>2599</p>
                            </div>
                            <span>2599 Store</span>
                        </div>
                        <div className='price_details'>
                            <div className='price_filterCont'>
                                <span>under</span>
                                <p>2999</p>
                            </div>
                            <span>2999 Store</span>
                        </div>
                        <div className='price_details'>
                            <div className='price_filterCont'>
                                <span>under</span>
                                <p>3599</p>
                            </div>
                            <span>3599 Store</span>
                        </div>
                    </div> */}


                <div className="drinkware_acc_carousel_section">
                    <div className="right_image_glry">
                        <div className="dinner_slider" ref={productSectionRef}>
                            <Row gutter={[32, 32]}>
                                {(isProLoading || (commonList && commonList?.data?.length > 0)) > 0 ? (
                                    commonList?.data?.map((product, index) => (
                                        <Col {...getColSpan()} key={`product-${product?.id}-${index}`}>
                                            <div className='dinner_sliderImg'>

                                                <div className='dinnerCategory_cont'>
                                                    <Link to={`${Routes.ProductDetail}/${product.product_slug}`} state={{ dataSlug: category?.name, route, from, menuSlug, categorySlug, ProductId: product?.id }}>
                                                        {product && product.productimages && product.productimages.length > 0 ? (
                                                            <div className='imageContainer ' onClick={() => handleItem(product.product_slug, from, route, category?.name, menuSlug, categorySlug, product?.id)}>

                                                                <ProductImage imgPath={imgPath} imgName={product.productimages[0].file_name} alt={product.product_name} placeholderImage={product.productimages[0].file_name_200_x_200} />
                                                                {product.productimages[1]?.file_name &&

                                                                    <div className={'hoverImage'}>
                                                                        <ProductImage imgPath={productList?.product_path} imgName={product?.productimages[1]?.file_name} alt={product?.product_name} placeholderImage={product.productimages[1].file_name_200_x_200} />
                                                                    </div>
                                                                }

                                                            </div>
                                                        ) : (
                                                            <img src={dImg} alt="Placeholder" />
                                                        )}
                                                    </Link>

                                                    {product?.stock_quantity <= 0 ?
                                                        <div className="sold_off_chips">
                                                            <p>Sold Out</p>
                                                        </div> :
                                                        product?.discount > 0 && product?.discount !== null &&
                                                        <div className="off_chips">
                                                            <p>{product?.discount}% off</p>
                                                        </div>}

                                                    {compare === true ? (compareData && compareData.id !== product.id &&
                                                        <div className='campare_checkbox'>
                                                            <Checkbox onChange={(e) => onChangeCheck(product, e)} checked={comp.some(item => item.id === product.id)}>Compare</Checkbox>
                                                        </div>
                                                    ) : (
                                                        <Wishlist is_wishlist={product?.is_wishlist} pId={product.id} path={`${Routes.ProductDetail}/${product.product_slug}`} mode='HeartOutlined' />
                                                    )}

                                                    <AddToCart productList={product} imgPath={imgPath} routeName={Routes?.ProductCategory} slug={slug} />
                                                </div>
                                                {/* </Link> */}
                                                <Link key={index} to={`${Routes.ProductDetail}/${product.product_slug}`} state={{ dataSlug: category?.name, route, from, menuSlug, categorySlug, ProductId: product?.id }}>
                                                    <div className='dinnerSlider_details'>
                                                        <p>{product.product_name}</p>
                                                        <div className='dinnerSliderSpan'>
                                                            <ProductPrice product={product} />
                                                        </div>
                                                    </div>

                                                </Link>
                                            </div>
                                        </Col>

                                    ))
                                ) : (
                                    <Col span={24}>
                                        <div className="comingSoonCont" style={{ marginTop: 60, textAlign: 'center' }}>
                                            <h2>{newChipsData?.length ? "Record Not Found" : "Coming Soon"}</h2>
                                        </div>
                                    </Col>

                                )

                                }
                                {isProLoading && (<div className='spin_csss'> <Spin /></div>)}
                            </Row>
                            {isCheckboxChecked && (
                                <div className='compare_button'>
                                    <button onClick={showModal}>Compare Product ({comp.length})</button>
                                </div>
                            )}
                        </div>
                    </div >
                </div >
                {commonList?.data?.length > 0 && <ScrollComponent totalProductCount={pagination?.totalItems} slug={category?.name} gridCount={gridLayout} productSectionRef={productSectionRef} setGridLayout={setGridLayout} />}
            </div >
            <FilterDrawer isDrawerVisible={isDrawerVisible} closeDrawer={closeDrawer} items={items} colorList={colorList} materialList={materialList} itemsMaterial={itemsMaterial} checkedColors={checkedColors} colorPath={colorPath} onChanged={onChanged} isActiveSec={isActiveSec} marks={marks} maxPrice={maxPrice} handlePriceChange={handlePriceChange} priceRange={priceRange} discountItem={discountItem} discountList={discountList} stockToggle={stockToggle} removeOutOfStocks={removeOutOfStocks} />

            <Modal open={isModalOpen} onOk={handleOk} onCancel={handleCancel} footer={null} className='comapreSlected'>
                <p>You've reached the limit! Only four items can be compared at once.</p>
                <div className='threeProd_okay'>
                    <button onClick={handleOk}>Okay, I understand</button>
                </div>
            </Modal>
        </>
    )
}

export default ProductCategory