import { Checkbox, Col, Row } from 'antd';
import React, { useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import Routes from '../../Routes/Routes';
import ProductImage from '../../components/ProductImage';
import Wishlist from '../../function/Wishlist';
import AddToCart from '../../function/AddToCart';
import ProductPrice from '../../components/ProductPrice';
import { useVirtualizer } from "@tanstack/react-virtual";

const ShowCategoryProducts = (props) => {
    const { productList, getColSpan, category, slugData, imgPath, hoverImage } = props

    const parentRef = useRef();

    const rowVirtualizer = useVirtualizer({
        count: Math.ceil(productList?.data?.length),
        getScrollElement: () => parentRef.current,
        estimateSize: () => 100,

    }

    );

    const containerStyles = {
        height: "100%", // Set to desired height for scrollable area
        overflow: 'auto',
        // paddingInline: "32px"
    };

    const memoizedCallback = useCallback(() => {

        const groupedData = [];
		for (let i = 0; i < productList?.data?.length; i += 4) {
		  groupedData.push(productList?.data.slice(i, i + 4));
		}
        // console.log(groupedData,"groupedData");
        

        return (
            <div ref={parentRef} style={containerStyles}>
                <div
                    style={{
                        height: `${rowVirtualizer.getTotalSize()}px`,
                        position: 'relative',
                    }}
                >
                    {rowVirtualizer.getVirtualItems().map((virtualRow) => {
                        const group = groupedData[virtualRow.index];
                        console.log('group',group.length);
                        
                        return (
                            <div style={{display:"flex"}} >

                                {
                                    group?.map((arrivalsitem) => (
                                        <Col {...getColSpan()} key={arrivalsitem?.id}>
                                            <div className='dinner_sliderImg'>
                                                <div className='dinnerCategory_cont'>
                                                    <Link to={`/product/${arrivalsitem?.product_slug}`} state={{ from: category?.page_slider?.title, menuSlug: slugData, ProductId: arrivalsitem?.id }} key={arrivalsitem?.id}>
                                                        <div className='imageContainer '>
                                                            <img src={`${imgPath}${arrivalsitem?.productimages[0]?.file_name}`} alt='' />
                                                            <img src={!arrivalsitem?.productimages[1] ? hoverImage : `${imgPath}${arrivalsitem?.productimages[1]?.file_name}`} className='hoverImage' alt='' />
                                                        </div>
                                                    </Link>
                                                    {arrivalsitem?.stock_quantity <= 0 ?
                                                        <div className="sold_off_chips">
                                                            <p>Sold Out</p>
                                                        </div> :
                                                        arrivalsitem?.discount !== 0 &&
                                                        <div className="off_chips">
                                                            <p>{arrivalsitem?.discount}% off</p>
                                                        </div>}
                                                    <Wishlist is_wishlist={arrivalsitem?.is_wishlist} pId={arrivalsitem?.id} path={`${Routes.Home}newarrival`} mode='HeartOutlined' />
                    
                                                    <AddToCart productList={arrivalsitem} p_id={arrivalsitem?.id} imgPath={imgPath} />
                                                </div>hoverImage
                                                <Link to={`/product/${arrivalsitem?.product_slug}`} state={{ from: "New Arrivals", ProductId: arrivalsitem?.id }} key={arrivalsitem?.id}>
                                                    <div className='dinnerSlider_details'>
                                                        <p>{arrivalsitem?.product_name} </p>
                                                        <div className='dinnerSliderSpan'>
                                                           
                                                            <ProductPrice product={arrivalsitem} />
                                                        </div>
                                                    </div>
                                                </Link>
                                            </div>
                                        </Col>
                                    ))
                                }
                            </div>
                            
                        );
                    })}
                </div>
            </div>
        );
    }, []);

    return (
        <>
            {memoizedCallback()}
        </>
    )
}

export default ShowCategoryProducts;