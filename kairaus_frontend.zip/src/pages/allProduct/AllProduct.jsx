import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';

import { Row, Col} from 'antd';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import '../../assets/css/style/product.scss'
import {useDispatch, useSelector } from 'react-redux';
import Wishlist from '../../function/Wishlist';
import Routes from '../../Routes/Routes';
import { LiaGreaterThanSolid } from "react-icons/lia";
import DinninhImg from '../../assets/images/soulsip.png';
import hoverImage from '../../assets/images/2nd.png';
import { Carousel } from 'react-bootstrap';
import { getAllProductSearch } from '../../services/cart/search/autoSearch';
import NoDataimg from '../../assets/images/noData.png'
import AddToCart from '../../function/AddToCart';
import CommFilter from '../../components/CommFilter';
import grid2 from '../../assets/images/18.webp';
import grid3 from '../../assets/images/19.webp';
import grid4 from '../../assets/images/20.webp';
import ScrollComponent from '../../components/ScrollComponent';
import { addProductCount } from '../../reducers/productCountSlice';

const AllProduct = () => {
    const location = useLocation()
    const {slug} = useParams()
    const [loading, setLoading] = useState(true);
    const [productList, setProductList] = useState(null);
    const [filterList, setFilterList] = useState([])
    const [imgPath, setimgPath] = useState(null);
    const user = useSelector((state) => state.user);
    const [stockToggle, setStockToggle] = useState(0)
    const [category, setCategory] = useState(null);
    const [categoryImgPath, setCategoryImgPath] = useState(null);
    const [sliderPath, setSliderPath] = useState(null);
    const [price, setPrice] = useState(null);
    const dispatch = useDispatch()
    const [selectedSorting, setSelectedSorting] = useState(null);
    const [isFetching, setIsFetching] = useState(false)
    const [maxPrice, setMaxPrice] = useState();
     const [pagination , setPagination] = useState({
        limit : 20,
        page_number : 1,
        totalItems:'',
        totalPages:'',
        perPagedata:''
       })
    const chips = useSelector(state => state.chips);
    const urlName = location.pathname.split('/');
    const lastSegment = urlName[urlName.length - 1];
    const newChipsData = chips.filter(chipsItem => chipsItem?.pagneName === lastSegment)

    const userId = user?.id ? user.id : 0;
    let searchValue;
    if (location.state) {
        searchValue = location.state.searchValue;
    }

    const { materialIds, colorIds, typeIds } = chips.filter(chipsItem => chipsItem?.pagneName === lastSegment)
    .reduce((acc, chipsItem) => {
        if (chipsItem.materialId) acc.materialIds.push(chipsItem.materialId);
        if (chipsItem.colorid) acc.colorIds.push(chipsItem.colorid);
        if (chipsItem?.typeId) acc?.typeIds?.push(chipsItem?.typeId);
        return acc;
    }, { materialIds: [], colorIds: [], typeIds: [] });

    const stockToggleItem = newChipsData.find(item => item.type === 'stockToggle');
    const stockToggleValue = stockToggleItem ? stockToggleItem.value : stockToggle;
    const existingDiscountValue = newChipsData.find(item => item.discountID === 1)?.minDiscount ?? "";
 
    const price_range = newChipsData?.find(i=> i?.priceRangeID === 1)?.priceRange ?? "";

    const fetchProducts = async () => {
        setIsFetching(true)
        try {
            const formData = new URLSearchParams();
            formData.append('keyword', searchValue);
            formData.append('slug', lastSegment);
            formData.append('user_id', userId);
            formData.append('color_id', colorIds);
            formData.append('sorting', selectedSorting ?? '');
            formData.append('material_id', materialIds);
            formData.append('type_ids', typeIds);
            formData.append('min_price', price_range[0] ?? '');
            formData.append('max_price', price_range[1]?? price ?? "ALL");
            formData.append('discount', existingDiscountValue)
            formData.append('remove_stock', stockToggleValue)
            formData?.append("limit" , pagination.limit)
            formData?.append("page_number" , pagination?.page_number) //maxPrice
            const response = await getAllProductSearch(formData);
            if (response.status === '1') {
                if (newChipsData?.length < 1) {
                    setMaxPrice(response?.max_price);
                }
                if(newChipsData?.length>0 || selectedSorting){
                    if(pagination?.page_number == "1"){
                        setFilterList(response);
                    }else{
                        setFilterList(prevProductList => {
                            const existingIds = new Set(prevProductList?.data?.map(item => item.id));
                            const uniqueNewData = response.data.filter(item => !existingIds.has(item.id));
                            return {
                                ...response,
                                data: [...(prevProductList?.data || []), ...uniqueNewData],
                            };
                        });
                    }
                }else{
                    setProductList(prevProductList => {
                        const existingIds = new Set(prevProductList?.data?.map(item => item.id));
                        const uniqueNewData = response.data.filter(item => !existingIds.has(item.id));
                        return {
                            ...response,
                            data: [...(prevProductList?.data || []), ...uniqueNewData],
                        };
                    });
                }
                // setProductList(response);
                setLoading(false);
                // console.log('response.product_path', response.path)
                setimgPath(response?.product_path);
                setPrice(response.max_price);
                localStorage.setItem("maxPrice", response?.max_price);
                setPagination((prevPagination) => ({
                    ...prevPagination,
                    totalItems : response?.totalItems,
                    totalPages : response?.totalPages,
                    perPagedata:response?.dataoncurrentPage
                }));
                setIsFetching(false)
            }
            else {
                setProductList([])
                setLoading(false);
            }
            if(response?.data?.length < 1){
                dispatch(addProductCount(true))
            }

        } catch (error) {
            console.error('Error fetching data:', error);
            setLoading(false);
            dispatch(addProductCount(true))
        }
    };

    const commonList = newChipsData?.length>0 || selectedSorting ? filterList : productList

    useEffect(() => {
        const removeFocus = () => {
            document.activeElement.blur();
        };
        removeFocus();

        return () => {
            removeFocus();
        };
    }, [searchValue]);
    const previousSearchValueRef = useRef(searchValue);
    useEffect(() => {
        // Check if searchValue has actually changed
        if (previousSearchValueRef.current !== searchValue) {
          // Update the previous value to the current one
          previousSearchValueRef.current = searchValue;
    
          // Reset product list and pagination when searchValue changes
          setProductList(null);
          setPagination(prev => ({
            ...prev,
            page_number: 1 // Reset to the first page when searching
          }));
    
          // Call fetchProducts only when searchValue changes
          fetchProducts();
        }
      }, [searchValue]);

    const [gridLayout, setGridLayout] = useState('md'); // Default layout is 'lg' (4 columns)

    const handleGridLayoutChange = (layout) => {
        setGridLayout(layout);
    };

    // useEffect(() => {
    //     handleGridLayoutChange('md');
    // }, []);

    const renderGridIcons = () => (
        <div className="grid-icons">
            <div className="grid-icon" onClick={() => handleGridLayoutChange('sm')}>
                <img src={grid2} alt="" />
            </div>
            <div className="grid-icon" onClick={() => handleGridLayoutChange('md')}>
                <img src={grid3} width="24" height="24" />
            </div>
            <div className="grid-icon" onClick={() => handleGridLayoutChange('lg')}>
                <img src={grid4} width="24" height="24" />
            </div>
        </div>
    );

    const getColSpan = () => {
        switch (gridLayout) {
            case 'sm':
                return { xs: 12, sm: 12 };
            case 'md':
                return { xs: 12, sm: 12, md: 8 };
            case 'lg':
                return { xs: 12, sm: 12, md: 8, lg: 6 };
            default:
                return { xs: 12, sm: 12, md: 8, lg: 6 };
        }
    };

    const productSectionRef = useRef(null);

    return (
        <>
            <div className='prodcut_arrivalNew'>
                <div className="drinkware_top_img_sec">
                    <Carousel>
                        <Carousel.Item>
                            <img src={DinninhImg} alt='' />
                            <Carousel.Caption>
                                <div className='giftly_heading_para'>
                                    <h2>All Products</h2>
                                    <p>Explore a Tapestry of Styles at Kairaus: Unveiling Collections that Define Your Space</p>
                                </div>
                            </Carousel.Caption>
                        </Carousel.Item>
                    </Carousel>
                </div>
                <div className='chips_grids'>
                    <div className='path_drinkware'>
                        Home <LiaGreaterThanSolid /> <p>{searchValue?.charAt(0).toUpperCase()+searchValue.slice(1)}</p>
                    </div>
                    {renderGridIcons()}
                </div>

                <CommFilter isFetching={isFetching} slug={slug} searchValue={searchValue} setProductList={setProductList} setimgPath={setimgPath} fetchProducts={fetchProducts} setCategoryImgPath={setCategoryImgPath} setSliderPath={setSliderPath} setCategory={setCategory} maxPrice={maxPrice} pagination={pagination} setPagination={setPagination} productListRef={productSectionRef} setStockToggle={setStockToggle} stockToggle={stockToggle} setSelectedSorting={setSelectedSorting} selectedSorting={selectedSorting} />

                {/* <CommFilter setProductList={setProductList} searchValue={searchValue} setimgPath={setimgPath} fetchProducts={fetchProducts} setCategoryImgPath={setCategoryImgPath} setSliderPath={setSliderPath} setCategory={setCategory} price={price} /> */}

                <div className='drinkware_acc_carousel_section'>
                    <div className='right-image-glry'>
                        <div className='dinner_slider' ref={productSectionRef}>
                            <Row gutter={[32, 32]}>
                                {
                                    commonList?.data?.length != 0 ?
                                    commonList?.data?.map(product => (
                                            <Col {...getColSpan()} key={product?.id}>
                                                <div className='dinner_sliderImg'>
                                                    <div className='dinnerCategory_cont'>
                                                        <Link to={`/product/${product?.product_slug}`} key={product?.id}>
                                                            <div className='imageContainer '>
                                                                <img src={`${imgPath}${product?.productimages[0]?.file_name}`} />
                                                                <img src={!product?.productimages[1] ? hoverImage : `${imgPath}${product?.productimages[0]?.file_name}`} className='hoverImage' />
                                                            </div>
                                                        </Link>
                                                        {product?.stock_quantity <= 0 ?
                                                            <div className="sold_off_chips">
                                                                <p>Sold Out</p>
                                                            </div>
                                                            :
                                                            product?.discount !== 0 &&
                                                            <div className="off_chips">
                                                                <p>{product?.discount}% off</p>
                                                            </div>}
                                                        <Wishlist is_wishlist={product?.is_wishlist} pId={product?.id} path={`${Routes.ProductDetail}/${product?.product_slug}`} mode='HeartOutlined' />
                                                        {/* <div className='addCart_Btn'>
                                                            <button onClick={() => handleAddToCart(id)}>Move to Cart</button>
                                                        </div> */}
                                                        <AddToCart productList={product} imgPath={imgPath} />
                                                    </div>
                                                    <Link to={`/product/${product?.product_slug}`} key={product?.id}>
                                                        <div className='dinnerSlider_details'>
                                                            <p>{product?.product_name} </p>
                                                            <div className='dinnerSliderSpan'>
                                                                <span>₹{product?.price}</span>
                                                                {product.price !== parseFloat(product.compare_price) && product.compare_price > 0 &&
                                                                    <p>₹{product.compare_price}</p>
                                                                }
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </div>
                                            </Col>
                                        ))
                                        : <div className='noDataCont'>
                                            <img src={NoDataimg} alt='' />
                                            <h5>Record Not Found</h5>
                                        </div>
                                }
                            </Row>

                            {/* </Slider> */}
                        </div>
                    </div>
                </div>
                {commonList?.data?.length > 0 && <ScrollComponent totalProductCount={pagination?.totalItems} slug={searchValue} gridCount={gridLayout} productSectionRef={productSectionRef} setGridLayout={setGridLayout} />}
            </div>
        </>
    );
};

export default AllProduct;