import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { getFinestProductList, getSavingProductList } from '../../services/home';
import { Row, Col, Collapse, Skeleton } from 'antd';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { PlusOutlined, MinusOutlined } from '@ant-design/icons';
import '../../assets/css/style/product.scss'
import { useDispatch, useSelector } from 'react-redux';
import Wishlist from '../../function/Wishlist';
import Routes from '../../Routes/Routes';
import { categoryApi } from '../../services/category/categoryApi';
import { LiaGreaterThanSolid } from "react-icons/lia";
import DinninhImg from '../../assets/images/product2.png';
import NoData from '../../assets/images/noData.png'
import hoverImage from '../../assets/images/2nd.png';
import { getFilterProductList } from '../../services/filter/categories';
import { Carousel } from 'react-bootstrap';
import AddToCart from '../../function/AddToCart';
import CommFilter from '../../components/CommFilter';
import ProductPrice from '../../components/ProductPrice';
import ProductImage from '../../components/ProductImage';
import LoaderSpinner from '../../components/LoaderSpinner';
import ScrollComponent from '../../components/ScrollComponent';
import grid2 from '../../assets/images/18.webp';
import grid3 from '../../assets/images/19.webp';
import grid4 from '../../assets/images/20.webp';

const FinestProduct = () => {
    const [loading, setLoading] = useState(true);
    const [productList, setProductList] = useState(null);
    const [category, setCategory] = useState(null);
    const [categoryImgPath, setCategoryImgPath] = useState(null);
    const [sliderPath, setSliderPath] = useState(null);
    const [imgPath, setimgPath] = useState(null);
    const [index, setIndex] = useState(0);
    const user = useSelector((state) => state.user);
    const [price, setPrice] = useState(null);
    const location = useLocation();
    const [slugData, setSlugData] = useState()
    const { pathname } = location;
    const productSectionRef = useRef();
    const staticSlug = pathname.split("/").join("")

    const fetchProducts = async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('type', '1');
            const response = await getFinestProductList(formData);
            if (response.status === '1') {
                setProductList(response);
                setCategory(response?.slider_details);
                setCategoryImgPath(response.category_path);
                setSliderPath(response.page_slider)
                setimgPath(response.path)
                setSlugData(response?.slug)
                setPrice(response.max_price)
            }
            else {
                setProductList([])
            }

        } catch (error) {
            console.error('Error fetching data:', error);
        } finally {
            setLoading(false)
        }
    };

    // useEffect(() => {
    //     fetchProducts();
    // }, []);

    const handleSelect = (selectedIndex) => {
        setIndex(selectedIndex);
    };

    const [gridLayout, setGridLayout] = useState('md');

    const handleGridLayoutChange = (layout) => {
        setGridLayout(layout);
    };
    useEffect(() => {
        handleGridLayoutChange('md');
    }, []);

    const renderGridIcons = () => (
        <div className="grid-icons">
            <div className="grid-icon" onClick={() => handleGridLayoutChange('sm')}>
                <img src={grid2} width="24" height="24" />

            </div>
            <div className="grid-icon" onClick={() => handleGridLayoutChange('md')}>
                <img src={grid3} width="24" height="24" />
            </div>
            <div className="grid-icon" onClick={() => handleGridLayoutChange('lg')}>
                <img src={grid4} width="24" height="24" />
            </div>
        </div>
    );

    const getColSpan = () => {
        switch (gridLayout) {
            case 'sm':
                return { xs: 12, sm: 12 };
            case 'md':
                return { xs: 12, sm: 12, md: 8 };
            case 'lg':
                return { xs: 12, sm: 12, md: 8, lg: 6 };
            default:
                return { xs: 12, sm: 12, md: 8, lg: 6 };
        }
    };

    return (
        <>
            <div className='prodcut_arrivalNew'>
                <div className="drinkware_top_img_sec">
                    <Carousel activeIndex={index} onSelect={handleSelect}>
                        {category?.page_slider?.page_slider_images.map((slider, index) => {
                            return (
                                <Carousel.Item key={index}>
                                    <img src={`${sliderPath}${slider.image}`} alt={slider.image_title} />
                                    {/* <Carousel.Caption>
                                        <div className='giftly_heading_para'>
                                            <h1>{slider.image_title}</h1>
                                            <p>{slider.description}</p>
                                        </div>
                                    </Carousel.Caption> */}
                                </Carousel.Item>
                            )
                        })}
                    </Carousel>
                </div>
                <div className='chips_grids'>
                    <div className='path_drinkware'>
                        Home <LiaGreaterThanSolid /> <p>{category?.page_slider?.title}</p>
                    </div>
                    {renderGridIcons()}
                </div>

                <CommFilter setProductList={setProductList} setimgPath={setimgPath} fetchProducts={fetchProducts} setCategoryImgPath={setCategoryImgPath} setSliderPath={setSliderPath} price={price} setCategory={setCategory} />

                <div className='drinkware_acc_carousel_section'>
                    <div className='right-image-glry'>
                        <div className='dinner_slider' ref={productSectionRef}>
                            <Row gutter={[32, 32]}>
                                {loading ?
                                    Array(8).fill(0).map((item, index) => {
                                        return (
                                            <Col key={`col-${index}`} xs={24} sm={12} md={8} lg={6}>
                                                <Skeleton.Image active={true} className='pro-sk-img' />
                                                <Skeleton paragraph={{
                                                    rows: 1,
                                                }} />
                                            </Col>
                                        )
                                    }) :
                                    productList?.data?.length > 0 ?
                                        productList?.data.map((arrivalsitem) => (
                                            <Col {...getColSpan()} key={arrivalsitem?.id}>
                                                <div className='dinner_sliderImg'>
                                                    <div className='dinnerCategory_cont'>
                                                        <Link to={`/product/${arrivalsitem?.product_slug}`} state={{ from: category?.page_slider?.title, menuSlug: slugData, ProductId: arrivalsitem?.id }} key={arrivalsitem?.id}>
                                                            <div className='imageContainer '>
                                                                <ProductImage imgPath={imgPath} imgName={arrivalsitem?.productimages[0]?.file_name} alt={""} />
                                                                {arrivalsitem?.productimages[1]?.file_name && <ProductImage imgPath={imgPath} imgName={arrivalsitem?.productimages[1]?.file_name} alt={""} className={"hoverImage"} />}

                                                            </div>
                                                        </Link>
                                                        {arrivalsitem?.stock_quantity <= 0 ?
                                                            <div className="sold_off_chips">
                                                                <p>Sold Out</p>
                                                            </div> :
                                                            arrivalsitem?.discount !== 0 &&
                                                            <div className="off_chips">
                                                                <p>{arrivalsitem?.discount}% off</p>
                                                            </div>}
                                                        <Wishlist is_wishlist={arrivalsitem?.is_wishlist} pId={arrivalsitem?.id} path={`${Routes.ProductDetail}/${arrivalsitem?.product_slug}`} mode='HeartOutlined' />
                                                        {/* <div className='addCart_Btn'>
                                                    <button onClick={() => handleAddToCart(id)}>Move to Cart</button>
                                                </div> */}
                                                        <AddToCart productList={arrivalsitem} p_id={arrivalsitem?.id} imgPath={imgPath} />
                                                    </div>
                                                    <Link to={`/product/${arrivalsitem?.product_slug}`} state={{ from: "Finest Product", ProductId: arrivalsitem?.id }} key={arrivalsitem?.id}>
                                                        <div className='dinnerSlider_details'>
                                                            <p>{arrivalsitem?.product_name} </p>
                                                            <div className='dinnerSliderSpan'>
                                                                {/* <span>₹{arrivalsitem?.price}</span>
                                                            {arrivalsitem.price !== parseFloat(arrivalsitem.compare_price) && arrivalsitem.compare_price > 0 &&
                                                                <p>₹{arrivalsitem.compare_price}</p>
                                                            } */}
                                                                <ProductPrice product={arrivalsitem} />
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </div>
                                            </Col>
                                        )) :
                                        <div className='noDataCont' style={{ marginTop: 60 }}>
                                            <img src={NoData} alt='' />
                                            <h5> Coming Soon</h5>
                                        </div>
                                }
                            </Row>
                        </div>
                    </div>
                </div>
                {/* {productList?.data?.length > 0 && <ScrollComponent totalProductCount={productList?.data?.length} slug={category?.page_slider?.title} gridCount={gridLayout} productSectionRef={productSectionRef} />} */}
            </div>
        </>
    );
};

export default FinestProduct;