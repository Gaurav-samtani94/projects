import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { Row, Col, Skeleton, } from 'antd';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import '../../assets/css/style/product.scss'
import { productApi } from '../../services/product/productApi';
import { useDispatch, useSelector } from 'react-redux';
import Wishlist from '../../function/Wishlist';
import Routes from '../../Routes/Routes';
import { LiaGreaterThanSolid } from "react-icons/lia";
import NoData from '../../assets/images/noData.png'
// import DinninhImg from '../../assets/images/soulsip.png';
import hoverImage from '../../assets/images/2nd.png';
import { Carousel } from 'react-bootstrap';
import AddToCart from '../../function/AddToCart';
import CommFilter from '../../components/CommFilter';

import ProductPrice from '../../components/ProductPrice';
import LoaderSpinner from '../../components/LoaderSpinner';
import ScrollComponent from '../../components/ScrollComponent';
import grid2 from '../../assets/images/18.webp';
import grid3 from '../../assets/images/19.webp';
import grid4 from '../../assets/images/20.webp';
import { getProductByColorList } from '../../services/home';
import { addProductCount } from '../../reducers/productCountSlice';


const NewArrivalProducts = () => {
    const [loading, setLoading] = useState(true);
    const location = useLocation()
    const [productList, setProductList] = useState(null);
    const [filterList, setFilterList] = useState([])
    const [category, setCategory] = useState(null);
    const [categoryImgPath, setCategoryImgPath] = useState(null);
    const [sliderPath, setSliderPath] = useState(null);
    const [index, setIndex] = useState(0);
    const [imgPath, setimgPath] = useState(null);
    const user = useSelector((state) => state.user);
    const userId = user?.id ? user.id : 0;
    const [maxPrice, setMaxPrice] = useState(null);
    const [isFetching, setIsFetching] = useState(false)
    const [slugData, setSlugData] = useState()
    const { pathname } = location;
    const productSectionRef = useRef(null);
    const staticSlug = pathname.split("/").join("");
    const urlName = window?.location?.href.split('/');
    const dispatch = useDispatch();
    const lastSegment = urlName[urlName.length - 1];
    const chips = useSelector(state => state.chips);
    const newChipsData = chips.filter(chipsItem => chipsItem?.pagneName === lastSegment);
    const [stockToggle, setStockToggle] = useState(0);
    const [selectedSorting, setSelectedSorting] = useState(null);
    const [pagination , setPagination] = useState({
    limit : 20,
    page_number : 1,
    totalItems:'',
    totalPages:'',
    perPagedata:''
   })

   const { slug } = useParams();
   const breadcrumb_title = slug?.charAt(0)?.toUpperCase() + slug?.slice(1)
   const { materialIds, typeIds, colorIds } = newChipsData.filter(chipsItem => chipsItem?.pagneName === lastSegment)
   .reduce((acc, chipsItem) => {
       if (chipsItem.materialId) acc.materialIds.push(chipsItem.materialId);
       if (chipsItem.typeId) acc.typeIds.push(chipsItem.typeId);
       if (chipsItem.colorid) acc.colorIds.push(chipsItem.colorid);
       return acc;
   }, { materialIds: [], colorIds: [], typeIds: [] });

   const stockToggleItem = newChipsData.find(item => item.type === 'stockToggle');
   const stockToggleValue = stockToggleItem ? stockToggleItem.value : stockToggle;
   const existingDiscountValue = newChipsData.find(item => item.discountID === 1)?.minDiscount ?? "";

   const price_range = newChipsData?.find(i=> i?.priceRangeID === 1)?.priceRange ?? "";

    const fetchProducts = async () => {
        setIsFetching(true)
        let type_id;
        if (staticSlug === "newarrival") {
            type_id = "1";  
        } else if (staticSlug === "bestseller") {
            type_id = "2";  
        } else if (staticSlug === "bigsavings") {
            type_id = "4";  
        } else if (staticSlug === "finest-product") {
            type_id = "3";  
        }

        const formData = new URLSearchParams();
        formData.append('user_id', userId);
        // formData?.append("type_id", type_id)
        // formData.append('color_id', colorIds);
        formData.append('sorting', selectedSorting ?? '');
        formData.append('material_id', materialIds);
        formData.append('type_ids', typeIds);
        formData.append('min_price', price_range[0] ?? '');
        formData.append('max_price', price_range[1]?? "ALL");
        formData.append('discount', existingDiscountValue)
        formData.append('remove_stock', stockToggleValue)
        formData?.append("limit" , pagination.limit)
        formData?.append("page_number" , pagination?.page_number)
        
        try {
            let response;
            if (type_id) {
                formData.append('slug', staticSlug);
                formData.append('type_id', type_id);
                formData.append('color_id', colorIds);
                response = await productApi.allmoreproduct(formData);
            } else {
                formData.append('slug', slug);
                response = await getProductByColorList(slug, formData);
            }
            if (response.status == '1') {

                if(newChipsData?.length>0 || selectedSorting || stockToggle){
                    if(pagination?.page_number == "1"){
                        setFilterList(response);
                    }else{
                        setFilterList(prevProductList => {
                            const existingIds = new Set(prevProductList?.data?.map(item => item.id));
                            const uniqueNewData = response.data.filter(item => !existingIds.has(item.id));
                            return {
                                ...prevProductList,
                                data: [...(prevProductList?.data || []), ...uniqueNewData],
                            };
                        });
                    }
                }else{
                    setProductList(prevProductList => {
                        const existingIds = new Set(prevProductList?.data?.map(item => item.id));
                        const uniqueNewData = response.data.filter(item => !existingIds.has(item.id));
                        return {
                            ...prevProductList,
                            data: [...(prevProductList?.data || []), ...uniqueNewData],
                        };
                    });
                }
                
                // setProductList(response)
                setCategory(response?.slider_details);
                setCategoryImgPath(response.category_path);
                setSliderPath(response.page_slider)
                setimgPath(response.path)
                setSlugData(response?.slug)
                setIsFetching(false)
                setMaxPrice(response.max_price)
                setPagination((prevPagination) => ({
                    ...prevPagination,
                    totalItems : response?.totalItems,
                    totalPages : response?.totalPages,
                    perPagedata:response?.dataoncurrentPage
                }));
            }
            else {
                setProductList([])
                setFilterList([])
            }

        } catch (error) {
            console.error('Error fetching data:', error);
            setFilterList([])
            dispatch(addProductCount(true))
        } finally {
            setLoading(false)
        }
    };
    const handleSelect = (selectedIndex) => {
        setIndex(selectedIndex);
    };

    const commonList = newChipsData?.length>0 || selectedSorting ? filterList : productList

    const [gridLayout, setGridLayout] = useState('md');

    const handleGridLayoutChange = (layout) => {
        setGridLayout(layout);
    };

    // useEffect(() => {
    //     handleGridLayoutChange('md');
    // }, []);

    const renderGridIcons = () => (
        <div className="grid-icons">
            <div className="grid-icon" onClick={() => handleGridLayoutChange('sm')}>
                <img src={grid2} width="24" height="24" alt=''/>

            </div>
            <div className="grid-icon" onClick={() => handleGridLayoutChange('md')}>
                <img src={grid3} width="24" height="24" alt=''/>
            </div>
            <div className="grid-icon" onClick={() => handleGridLayoutChange('lg')}>
                <img src={grid4} width="24" height="24" alt=''/>
            </div>
        </div>
    );

    const getColSpan = () => {
        switch (gridLayout) {
            case 'sm':
                return { xs: 12, sm: 12 };
            case 'md':
                return { xs: 12, sm: 12, md: 8 };
            default:
                return { xs: 12, sm: 12, md: 8, lg: 6 };
        }
    };

    return (
        <>
            <div className='prodcut_arrivalNew'>
                <div className="drinkware_top_img_sec">
                    <Carousel activeIndex={index} onSelect={handleSelect}>
                        {category?.page_slider?.page_slider_images.map((slider, index) => {
                            return (
                                <Carousel.Item key={index}>
                                    <img src={`${sliderPath}${slider.image}`} alt={slider.image_title} />
                                    {/* <Carousel.Caption>
                                        <div className='giftly_heading_para'>
                                            <h1>{slider.image_title}</h1>
                                            <p>{slider.description}</p>
                                        </div>
                                    </Carousel.Caption> */}
                                </Carousel.Item>
                            )
                        })}
                    </Carousel>
                </div>
                <div className='chips_grids'>
                    <div className='path_drinkware'>
                        Home <LiaGreaterThanSolid /> <p>{slug ? breadcrumb_title : category?.page_slider?.title}</p>
                    </div>
                    {renderGridIcons()}
                </div>
                <CommFilter isFetching={isFetching} setProductList={setProductList} setimgPath={setimgPath} fetchProducts={fetchProducts} setCategoryImgPath={setCategoryImgPath} setSliderPath={setSliderPath} setCategory={setCategory} maxPrice={maxPrice} pagination={pagination} setPagination={setPagination} productListRef={productSectionRef} setStockToggle={setStockToggle} stockToggle={stockToggle} setSelectedSorting={setSelectedSorting} selectedSorting={selectedSorting} breadcrumb_title={breadcrumb_title} />

                <div className='drinkware_acc_carousel_section'>
                    <div className='right-image-glry'>
                        <div className='dinner_slider' ref={productSectionRef}>
                            <Row gutter={[32, 32]}>
                                {loading ?
                                    Array(8).fill(0).map((item, index) => {
                                        return (
                                            <Col key={`col-${index}`} xs={24} sm={12} md={8} lg={6}>
                                                <Skeleton.Image active={true} className='pro-sk-img' />
                                                <Skeleton paragraph={{
                                                    rows: 1,
                                                }} />
                                            </Col>
                                        )
                                    })
                                    :
                                    commonList?.data?.length > 0 ?
                                    commonList?.data.map((arrivalsitem) => (
                                            <Col {...getColSpan()} key={`arrival-${arrivalsitem?.id}`}>
                                                <div className='dinner_sliderImg'>
                                                    <div className='dinnerCategory_cont'>
                                                        <Link to={`/product/${arrivalsitem?.product_slug}`} state={{ from: slug ? breadcrumb_title : category?.page_slider?.title, menuSlug: slugData, ProductId: arrivalsitem?.id }} key={arrivalsitem?.id}>
                                                            <div className='imageContainer '>
                                                                <img src={`${imgPath}${arrivalsitem?.productimages[0]?.file_name}`} alt='' />
                                                                <img src={!arrivalsitem?.productimages[1] ? hoverImage : `${imgPath}${arrivalsitem?.productimages[1]?.file_name}`} className='hoverImage' alt='' />
                                                            </div>
                                                        </Link>
                                                        {arrivalsitem?.stock_quantity <= 0 ?
                                                            <div className="sold_off_chips">
                                                                <p>Sold Out</p>
                                                            </div> :
                                                            arrivalsitem?.discount !== 0 &&
                                                            <div className="off_chips">
                                                                <p>{arrivalsitem?.discount}% off</p>
                                                            </div>}
                                                        <Wishlist is_wishlist={arrivalsitem?.is_wishlist} pId={arrivalsitem?.id} path={`${Routes.Home}newarrival`} mode='HeartOutlined' />

                                                        <AddToCart productList={arrivalsitem} p_id={arrivalsitem?.id} imgPath={imgPath} />
                                                    </div>
                                                    <Link to={`/product/${arrivalsitem?.product_slug}`} state={{ from: "New Arrivals", ProductId: arrivalsitem?.id }} key={arrivalsitem?.id}>
                                                        <div className='dinnerSlider_details'>
                                                            <p>{arrivalsitem?.product_name} </p>
                                                            <div className='dinnerSliderSpan'>
                                                                {/* <span>₹{arrivalsitem?.price}</span>
                                                            {arrivalsitem.price !== parseFloat(arrivalsitem.compare_price) && arrivalsitem.compare_price > 0 &&
                                                                <p>₹{arrivalsitem.compare_price}</p>
                                                            } */}
                                                                <ProductPrice product={arrivalsitem} />
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </div>
                                            </Col>
                                        )) :
                                        <div className='noDataCont' style={{ marginTop: 60 }}>
                                            <h2>{newChipsData?.length ? "Record Not Found" : "Coming Soon"}</h2>
                                        </div>
                                }
                            </Row >
                            {/* </Slider> */}
                        </div >
                    </div >
                </div >
                {commonList?.data?.length > 0 && <ScrollComponent totalProductCount={pagination?.totalItems} slug={slug ? breadcrumb_title : category?.page_slider?.title} gridCount={gridLayout} productSectionRef={productSectionRef} setGridLayout={setGridLayout} />}
            </div >
        </>
    );
};

export default NewArrivalProducts;
