import React, { useEffect, useState } from 'react';
import { Carousel } from 'react-bootstrap';
import DinninhImg from '../../assets/images/soulsip.png';
import { LiaGreaterThanSolid } from "react-icons/lia";
import { Pagination } from 'antd';
import collectImg from '../../assets/images/dining1.png';
import collectImg1 from '../../assets/images/dining3.png';
import collectImg2 from '../../assets/images/drinkwareBox.png';
import collectImg3 from '../../assets/images/basket.png';
import collectImg4 from '../../assets/images/2nd.png';
import collectImg5 from '../../assets/images/drinkwarebot.png'
import collectImg6 from '../../assets/images/drinkwarecup1.png';
import collectImg7 from '../../assets/images/gift1.png';
import { getCollectionList } from '../../services/collection';

const Collection = () => {

    const [collectionList, setCollectionList] = useState([]);
    const [collectionResponse, setCollectionResponse] = useState(null);

    const fetchCollections = async () => {
       try {
        const formData = new URLSearchParams();
        formData.append('limit', 10);
        let results = await getCollectionList(formData);

        if (results?.status == 1) {
            setCollectionResponse(results);
            setCollectionList(results?.data);
        }
        else {
            setCollectionList([]);
        }

       } 
       
       catch (error) {
        console.log(error)
        setCollectionList([]);
       }
    }

    const showCollections = () => {
        return (
            collectionList?.map((item, index) => (
                <div className='collection_mainDiv'>
                    <img src={collectionResponse?.path+item?.collection_image} />
                    <p>{item?.name}</p>
                </div>
            ))
        )
    }

    useEffect(() => {
        fetchCollections();
    }, [])

    return (
        <div className="collection_div">
            <div className="drinkware_top_img_sec">
                <Carousel>
                    <Carousel.Item>
                        <img src={DinninhImg} alt='' />
                        <Carousel.Caption>
                            <div className='giftly_heading_para'>
                                <h1>Collections</h1>
                                <p>Explore similar pieces you've been eyeing!</p>
                            </div>
                        </Carousel.Caption>
                    </Carousel.Item>
                </Carousel>
            </div>
            <div className='path_drinkware'>
                Home <LiaGreaterThanSolid /> <p>Our Collection</p>
            </div>
            <div className='collection_all'>
                <div className='collection_crds'>                   
                    {showCollections()}                    
                </div>
            </div>
            {/* <div className='collect_pagination'>
                <Pagination defaultCurrent={1} total={50} />
            </div> */}
        </div>
    )
}

export default Collection
