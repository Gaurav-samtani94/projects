import React, { useState, useRef, useEffect } from 'react'
import { LiaGreaterThanSolid } from "react-icons/lia";
import sliderImg from '../../assets/images/aboutus/who_ware_header.png';
import { getStaticPage } from '../../services/staticPage';
import delivery from '../../assets/images/track.png';
import crdOnline from '../../assets/images/card.png';
import shopWorld from '../../assets/images/worldwide.png';
import experienced from '../../assets/images/experience.png';
import aboutImg from '../../assets/images/dinnerItem.png'
import { Row, Col } from 'antd';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import aboutSliderImg from '../../assets/images/img2.png';
import slider1 from '../../assets/images/1st.png';
import slider2 from '../../assets/images/2nd.png';
import aboutSliderImg11 from '../../assets/images/homefernish.png';
import slider011 from '../../assets/images/img5.png';
import slider022 from '../../assets/images/img6.png';
import { Link } from 'react-router-dom';
import { FaFacebookF, FaInstagram, FaLinkedinIn, FaPinterestP, FaTwitter } from 'react-icons/fa';
import { CiYoutube } from 'react-icons/ci';

const Aboutus = () => {
  const [aboutUsData, setAboutUsData] = useState(null);
  const hasMounted = useRef(false);

  const fetchData = async () => {
    try {
      const aboutUsResponse = await getStaticPage('about-us');
      const aboutUsData = aboutUsResponse.data;
      if (aboutUsResponse.status === '1') {
        setAboutUsData(aboutUsData);
      }

      // setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      // setLoading(false);
    }
  };
  useEffect(() => {
    window.scrollTo(0, 0);
    if (hasMounted.current) return;
    fetchData();
    hasMounted.current = true;
  }, []);

  var settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 10000,
  };

  return (
    <>

      {/* <section className="section_one_whower">
        <img src={sliderImg} alt="#" />
        <div className="full_img_text">
          <h1>Who we are</h1>
        </div>
      </section> */}
      {/* <div className="path_about_drinkware">
        <p> Home <LiaGreaterThanSolid /><span> Who we are</span></p>
      </div> */}

      <section className='about_new'>
        <span>About Us</span>
        <h1> Welcome To Kairaus. <span>Welcome Home</span></h1>
      </section>

      <div className='new_designAbout'>
        <Row>
          <Col xs={24} sm={24} md={18}>
            <img src={aboutImg} alt="" />
          </Col>
          <div className='mission_card'>
            <h4> A Glimpse into the Future: The Kairotic Vision</h4>
            <p>“We envision a world where each moment holds the potential to rewrite luxury living” </p>
            <p>At Kairaus, we believe in the power of crafting moments now that align together to define a luxurious future. Rooted in the philosophy of living in the present, we provide opportune experiences today that bring to fruition your envisioned home and lifestyle of tomorrow.</p>
            {/* <button>Learn more  <svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19 11H37V29" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" /><path d="M11.5439 36.4559L36.9997 11" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" /></svg></button> */}
          </div>
        </Row>
      </div>

      <div dangerouslySetInnerHTML={{ __html: aboutUsData && aboutUsData.description }}></div>

      <div className='slider_about'>
        <Slider {...settings}>
          <div>
            <Row>
              <Col xs={24} sm={18} md={12} lg={12} xl={12}>
                <div className='aboutSlider_span'>
                  <span>The Kairaus Promise : Exceeding Expectations</span>
                  <p>Health First Collection </p>
                </div>
                <img src={aboutSliderImg} alt="" />
              </Col>
              <Col xs={24} sm={18} md={12} lg={12} xl={12}>
                <div className='main_aboutDeatil'>
                  <div className='flexImg'>
                    <img src={slider1} alt="" />
                    <img src={slider2} alt="" />
                  </div>
                  <p>Prioritising your well-being, most of our products are BPA, lead-free, and eco-friendly, ensuring a healthier lifestyle for you and the planet! </p>

                  {/* <button>Read more  <svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M41.9999 24H5.99994" stroke="#333" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /><path d="M30 12L42 24L30 36" stroke="#333" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></svg></button> */}
                </div>
              </Col>
            </Row>
          </div>
          <div>
            <Row>
              <Col xs={24} sm={18} md={12} lg={12} xl={12}>
                <div className='aboutSlider_span'>
                  <span>The Kairaus Promise : Exceeding Expectations</span>
                  <p>Diversity of Products</p>
                </div>
                <img src={aboutSliderImg11} alt="" />
              </Col>
              <Col xs={24} sm={18} md={12} lg={12} xl={12}>
                <div className='main_aboutDeatil'>
                  <div className='flexImg'>
                    <img src={slider011} alt="" />
                    <img src={slider022} alt="" />
                  </div>
                  <p>Explore Endless Options with our diverse range of imported and handcrafted products, crafted with love and care! </p>
                  {/* <button>Read more  <svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M41.9999 24H5.99994" stroke="#333" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /><path d="M30 12L42 24L30 36" stroke="#333" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></svg></button> */}
                </div>
              </Col>
            </Row>
          </div>
        </Slider>
      </div>

      <section className="qty_info_main">
        <h2>Our Brand Pillars</h2>
        <p>Discover our secret sauce: elegance, quality, and a dash of passion!</p>

        <div className='brand_pillar'>
          <div className="qty_info_sub">
            <img src={delivery} alt='' />
            <h6>Safe Home Delivery</h6>
            <span>Our delivery team treats your order like a VIP—Very Important Package—delivered right to your door!</span>
          </div>
          <div className="qty_info_sub">
            <img src={crdOnline} alt='' />
            <h6>Secure Online Payments</h6>
            <span>Pay with peace of mind; our security is rock-solid to keep your transactions safe and protected!</span>
          </div>
          <div className="qty_info_sub">
            <img src={shopWorld} alt='' />
            <h6>Shipping Worldwide</h6>
            <span>From our doorstep to yours, we’re like global delivery ninjas—swift and precise!</span>
          </div>
          <div className="qty_info_sub">
            <img src={experienced} alt='' />
            <h6>Quality Checked</h6>
            <span>We inspect each product like it’s a hidden gem—because, to us, it is!</span>
          </div>
        </div>
      </section>

      <div className="section_seven_whower">
        <div className="sec_seven_main">
          <h2>Join our Community</h2>

          <p>We invite you to join us on this journey of creating spaces that resonate with your lifestyle.</p>

          {/* <div className="sec_seven_icon"><a href="https://www.instagram.com/kairaus_official/?hl=en"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAZCAYAAAAv3j5gAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAG1SURBVHgBrVbhWcIwEH3y8d86gXEDRogTiBNQJrBOAE4gTgBMoE4ATiBM0G4AG2hi3plYaUIL7/veF7he7t1dr2mB/9CGM8PS8Ksld4avjBHFpEPwJs4Ns5SIrWiA9lCGOXw3VnWHPBDR6IYsSE4FYtPQaXXI2AJWYMcYBW0a/r5lkolU0xUz7i9JgRSge/DlfiSC5dxYMssVbcrwjT7293uwZ8t10EcaCm6CdM2uycrw3vAGrjubwGfPNeshjoyZawZ8ZMArw1vaFPx0bZoCpYQeGKhi4Bl/20zXFF0yoXksUEoo5zqmwCEUFNZMqrWQIiX7JtjrMkgaHYTk+KiQxj7lEBOquCqkcV3b00pIWmYrKyJ+Cr5lnaduydUeuIMGERntF0RamHpgF3DZjgw/+X/LgAPa5SGdxgIdczLkcL2fwI97CHv8jJEYiH7gcBnxm8JVM4RvYQV3D9eRfeL7o2FLlyM+w3kh7yQthgUNzzgfCvhXxy8UfFUTnI4R/Dsut4aL4KI1yMFYwY3rBsfDtl0Z3sG36gkN02gdSpz+BWS78+chv8BhDCna9kuoguvCArVx/wYnlKD8/LAQogAAAABJRU5ErkJggg==" /></a> <a href="https://www.facebook.com/profile.php?id=61563660128024"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAZCAYAAADuWXTMAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAD5SURBVHgB7VTREYIwDH14DIAblA0YoRvoBjKCTiBuwgaeE6Ab6ASwgTgBJlDOUFqU88Mf3927QpKXJrm2gB8RcU8siHdiI1gSk8AjVEbE64V4tvyc9ODRtpmZ2uPn3bPQ4UjNjjGxwgRc4g26Uith4/7XJukk2pIsW4nhwHiAiU+cin/lsLVY4HNUtoF75n62eA+ehRaJcv7ITFmVoBYiTn61/ByvQ5Ephhs1hsNR6Aao5vQ8wlfivmzuqxD2Hbo+exxNDMRa88458UYMDDXGPfLpWhr/g3jC+LK08B0SbQf+bmB/8UyEHvsKrycnwgzwMW0wfqeVHfgEMxA8OXqVmP8AAAAASUVORK5CYII=" /></a> <a href="https://www.youtube.com/@Officialkairaus"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAYCAYAAACfpi8JAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFnSURBVHgBxZaNUcMwDIVfewyQDWo2YAR3A0YIE8AGbSaADQgTABM0TABMQDYoG4BUy2c3l/bi+Kff3at99l2lSrIq4JiKtCHtSHvSXwZ9kmqSwgn44ieT8TGxrZtzTnQkjXxoUiu29hhE5lUuWpTjSWzu7IGCC1WFstgs6CV93MphR/pFWV5kPThio/CB6XAqufoV4uhlXS0xD44iVzyHdoMEKZ3riM8WrjdczJFr0jtMip5FCjOIdaSHSdOd7GuY6DwgkBSpYVrSGuYVcL08wusPJR2xrLz9NwK4QjwcgXuYomV6mFR1CCDWEY3jAm1gWndwY4x1xNYBN8MarkEFE1sj/Ms5DTrGCcaPSEh3bGSdlYZTjvSyV5jOFmnQsh5eGEdidEjJjIIbA5Q9tENKin/UKVRii23yq8NicKFgUtXI2iMtbEfD9B0l37/GwA5ftCg3PHfwor8Y8VrDzRs5+CK9YdB5/wEy+5X0ZR74BQAAAABJRU5ErkJggg==" /> </a> <a href="https://in.pinterest.com/kairaus_official/"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAZCAYAAADe1WXtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAFESURBVHgBtZXtbcIwEIZfRf3fjOANygb1CB3BI7BB0wmgE5ANkk5AOgEwAWKCsAHYwkaX444YER7ppNh3fv1xZwfQsd6W3jbeem+naKHdeHN4AOttT0Tu2T5H/FsYuPVWR2uVCRe5gmHrJfJ3cyNsWIBDHg0bZ6mzJY4Kt6uyimjYCU3imjrowVPWxLdShCu22jKtRBroWHCviH6xuFmBy3kmDiyYcoTMlrXLAjrvrN0pcYZ3FGymT/K9Y7H/kOFld9VLNdeTmR2EBAjUUBI9J4429i1JX6cIGgxLaqXNWMX2BuPlVGNYHUYKctFBazcNmJG44F+wmDlG4LVHbwx/CqVbKELPM2y9gf708XrGmyL6Qb7/cEmejQJh68fY1yETfp4GE2Ax/HU8TDHi/8VEWMjPYDbSStNr9IMJCYnq8AJKPMEZSKGdDvnLOTIAAAAASUVORK5CYII=" /></a></div> */}
          <div className="sec_seven_icon">
          <Link to="https://www.instagram.com/kairaus_official/?hl=en" target='_blank'>
                    <FaInstagram />
                  </Link>
                  <Link to="https://www.facebook.com/people/KairausOfficial/61565182179977/" target='_blank'>
                    <FaFacebookF />
                  </Link>
                  <Link to="https://www.youtube.com/@KairausOfficial" target='_blank'>
                    <CiYoutube />
                  </Link>
                  <Link to="https://in.pinterest.com/kairaus_official/" target='_blank'>
                    <FaPinterestP />
                  </Link>
                  <Link to="https://www.linkedin.com/in/kairausofficial/" target='_blank'>
                  <FaLinkedinIn />
                  </Link>
                  <Link to="https://x.com/Kairausofficial" target='_blank'>
                  <FaTwitter />
                  </Link>

          </div>
        </div>
      </div>
    </>

  )
}

export default Aboutus;