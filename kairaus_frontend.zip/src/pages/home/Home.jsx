import React, { useState, useEffect } from 'react'
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { getCategoriesList, getHomeSliderList, getHomeSectionList, getHaulisList, getHomeColorList, getGiftCategory, getHomeProductList } from '../../services/home';
import CarouselCom from '../../components/home/CarouselCom';
import { getAboutUs } from '../../services/aboutUs'
import { getBlog } from '../../services/blog'
import ContactUs from '../../components/contact/ContactUs'
import NewArrival from '../../components/home/NewArrival';
import Category from '../../components/home/Category'
import Routes from '../../Routes/Routes';
import { Carousel } from 'react-bootstrap';
import SubscribeImg from '../../assets/images/aboutus/subscribe_us.jpg';
import { Col, Row } from 'antd';
import BulkDrawer from '../../components/drawer/BulkDrawer';
import { useSelector } from 'react-redux';
import ProductImage from '../../components/ProductImage';
import WelcomePop from '../../components/modal/WelcomePop';
import { HeartOutlined } from '@ant-design/icons';
import image1 from '../../assets/images/dining.jpg';
import image2 from '../../assets/images/everyday essentials 1.jpg';
import image3 from '../../assets/images/everyday essentials 2.jpg';
import image4 from '../../assets/images/gifts.jpg';
import image5 from '../../assets/images/home decor 1.jpg';
import image6 from '../../assets/images/home decor 2.jpg';
import share from '../../assets/images/telegram.svg';
import Marquee from "react-fast-marquee";
import kairaus from '../../assets/images/KAIRAUS_logo.svg'

const Home = React.memo(({ listOne, brandPillerList, filePath }) => {
  const [sliderList, setSliderList] = useState(null);
  const [categoryList, setCategoryList] = useState([]);
  const [aboutUsData, setAboutUsData] = useState(null);
  const [blogs, setBlog] = useState(null);
  const [haulis, setHaulis] = useState([]);
  const [haulisImagePath, setHaulisImagePath] = useState('');
  const [giftCatPath, setGiftCatPath] = useState(null);
  const [giftCatData, setGiftCatData] = useState(null);
  const [colorList, setColorList] = useState([]);
  const [colorImage, setColorImage] = useState([]);
  const [open, setOpen] = useState(false);

  const [drawerHeading, setDrawerHeading] = useState('');
  const [topData, setTopData] = useState([]);
  const [middleData, setMiddleData] = useState([]);
  const [offerData, setOfferData] = useState([]);
  const [downData, setdownData] = useState([]);
  const [arival, setArival] = useState([])
  const [bestProduct, setBestProduct] = useState([])
  const [discountProduct, setDiscountProduct] = useState([])
  const [fitness, setFitness] = useState([])
  const [imagePath, setImagePath] = useState("")
  const [homeSectionImgPath, setHomeSectionImgPath] = useState('');
  const evetkey = useSelector(state => state.evetkey);
  const navigate = useNavigate();
  const user = useSelector((state) => state.user);
  const userId = user?.id ? user.id : 0;
  // const [showWelcome, setShowWelcome] = useState(false);

  // useEffect(() => {
  //   // Check if welcome pop has been shown before
  //   const hasShownWelcome = localStorage.getItem('hasShownWelcome');

  //   if (!hasShownWelcome) {
  //     // Show the welcome pop-up for the first time
  //     setShowWelcome(true);
  //     // Set a flag in localStorage to prevent showing it again
  //     localStorage.setItem('hasShownWelcome', 'true');
  //   }
  // }, []);

  const showDrawer = () => {
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
  };
  const fetchData = async () => {
    try {
      const [
        sliderResponse,
        categoriesResponse,
        aboutUsResponse,
        blogResponse,
        haulisResponse,
        homeColorResponse,
        homeSectionResponse,
        homeProductResponse,
        giftCategoryResponse
      ] = await Promise.all([
        getHomeSliderList(),        // Fetch home slider list
        getCategoriesList(),        // Fetch categories list
        getAboutUs(),               // Fetch about us data
        getBlog(),                  // Fetch blogs
        getHaulisList(),            // Fetch haulis list
        getHomeColorList(),         // Fetch home color list
        getHomeSectionList(),       // Fetch home section list
        getHomeProductList(new URLSearchParams({ 'user_id': userId })),  // Fetch home product list
        getGiftCategory()           // Fetch gift category list
      ]);
      // Handle slider response
      if (sliderResponse.status === '1') {
        setSliderList(sliderResponse);
      }

      // Handle categories response
      if (categoriesResponse.status === '1') {
        setCategoryList(categoriesResponse);
      }

      // Handle about us response
      if (aboutUsResponse.status === '1') {
        setAboutUsData(aboutUsResponse);
      }

      // Handle blog response
      if (blogResponse.status === '1') {
        setBlog(blogResponse);
      }

      // Handle haulis response
      if (haulisResponse.status === '1') {
        setHaulis(haulisResponse?.data);
        setHaulisImagePath(haulisResponse?.path);
      }

      // Handle home color response
      if (homeColorResponse.status === '1') {
        setColorList(homeColorResponse?.data);
        setColorImage(homeColorResponse?.path);
      }

      // Handle home section response
      if (homeSectionResponse?.status === '1') {
        setHomeSectionImgPath(homeSectionResponse?.path || '');

        const { section_top = [], section_middle = [], section_offer = [], section_down = [] } = homeSectionResponse?.data || {};
        setTopData(section_top);
        setMiddleData(section_middle);
        setOfferData(section_offer);
        setdownData(section_down);
      } else {
        console.error('Failed to fetch home section data: Invalid status');
      }

      // Handle home product response
      if (homeProductResponse?.status === '1') {
        setImagePath(homeProductResponse?.path);
        const { arrivalsProduct = [], bestSellProduct = [], discountedProduct = [], finestProduct = [] } = homeProductResponse?.data || {};
        setArival(arrivalsProduct);
        setBestProduct(bestSellProduct);
        setDiscountProduct(discountedProduct);
        setFitness(finestProduct);
      } else {
        console.error('Failed to fetch home product data: Invalid status');
      }

      // Handle gift category response
      if (giftCategoryResponse?.status === "1") {
        setGiftCatPath(giftCategoryResponse?.category_path);
        setGiftCatData(giftCategoryResponse?.data);
      } else {
        console.error('Failed to fetch gift category data: Invalid status');
      }

    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  useEffect(() => {
    if (evetkey.storageKey === 'home') {
      window.scrollTo(0, 0);
    }
  }, [evetkey]);
  useEffect(() => {
    fetchData()
  }, [])
  const handleListOne = (item) => {
    if (item?.url_slug === 'about-us') {
      navigate(item.url_slug);
    }
    else {
      setDrawerHeading(item?.heading);
      showDrawer();
    }
  }
  const ShowListOne = () => {
    return (
      <>
        {listOne?.map(item => (
          <div key={item.id} className="ask_query" onClick={() => handleListOne(item)}>
            <span>{item?.heading}</span>
            <img src={filePath + item?.icon} alt="asKSvg" style={{ height: '194px' }} loading="lazy" />
            <div className='ask_query_cont'>{item?.sub_heading}</div>
          </div>
        ))}
      </>
    );
  };

  const ShowBrandPillars = () => {
    return (
      <>
        {brandPillerList?.map(item => (
          <div key={item.id} className="qty_info_sub">
            {/* <img src={filePath + item?.icon} alt='icon' loading="lazy"/> */}
            <h6>{item?.heading}</h6>
            <span>{item?.sub_heading}</span>
          </div>
        ))}
      </>
    );
  };


  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchInstagramPosts = async () => {
      try {
        const response = await fetch('https://graph.instagram.com/me/media?fields=id,caption,media_type,media_url,permalink,thumbnail_url,timestamp,username,comments_count,like_count&access_token=IGQWRNSkNnWkdRcEFMeXZA4ejExT3puRlYwRHM3OGFhaUFEaV9rUVpfcUxDY2JWZAFJQNHAzRnpSajN4VHNfM0QwbGx5eWRndy1YU1ZAsNk9KbU5lcHNxVU5oZAlpwZAGQxTFRMbGJrZA2ZArZAGIyOXJYaU03bHA1aExydkUZD');
        const data = await response.json();
        setPosts(data.data || []);
      } catch (error) {
        console.error("Error fetching Instagram posts:", error);
      }
    };

    fetchInstagramPosts();
  }, []);

  return (
    <>
      <WelcomePop />
      <CarouselCom sliderList={sliderList} />
      <Category categoryList={categoryList.data} imagePath={categoryList.path} />
      {arival?.length > 0 && <NewArrival productData={arival} imagePath={imagePath} title="Kairaus's New Arrivals" discr="Discover the latest gems that just arrived to dazzle your dining experience!" type="newarrival" />}
      <section className="home_img_full_middle">
        <Carousel>
          {topData?.map((topItem, index) => (
            <Carousel.Item key={index}>
              <Link to="gifts">
                <img src={`${homeSectionImgPath}${topItem?.image}`} alt={topItem?.title} loading="lazy" /></Link>
            </Carousel.Item>
          ))}
        </Carousel>
      </section>

      <section className='four_cards_luxury'>
        <Row gutter={[24, 16]}>
          {giftCatData?.length > 0 && giftCatData.map((list, index) => (
            <Col key={index} xs={12} sm={12} md={6} lg={6} xl={6}>
              <Link to={`${Routes.ProductCategory}/${list?.categories?.slug}`}>
                <div className='luxury_crd'>
                  <img src={`${giftCatPath}/${list?.categories?.image}`} alt={list?.name} loading="lazy" />
                  <div className='luxury_cardHeading'>
                    <h4>{list?.categories?.name}</h4>
                  </div>
                </div>
              </Link>
            </Col>
          ))}
        </Row>
      </section>

      {bestProduct?.length > 0 && <NewArrival productData={bestProduct} imagePath={imagePath} title="Kairaus's Spotlight" discr="Shine bright with our curated picks that steal the show!" type="bestseller" />}

      <section className="home_img_full_last">
        <Carousel>
          {middleData?.map((item, index) => (
            <Carousel.Item key={index}>
              <Link key={index} to='collections/offers'>
                <ProductImage
                  imgPath={homeSectionImgPath}
                  imgName={item?.image}
                  alt={`Image for ${item?.image}`} loading="lazy" />
              </Link>
            </Carousel.Item>
          ))}
        </Carousel>
      </section>

      {/* <OfferItem /> */}
      {discountProduct?.length > 0 && <NewArrival productData={discountProduct} imagePath={imagePath} title="Kairaus’s Savings Bonanza" discr="Where luxury hugs your wallet—snag deals that sparkle!" type="offer" />}


      <section className='shop_Our_Look'>
        {offerData?.map((offerItem, index) => (
          <Link key={offerItem.id} to="/dining">
            <img
              src={`${homeSectionImgPath}${offerItem?.image}`}
              alt={`Banner ${index}`} loading="lazy" />
          </Link>
        ))}
      </section>
      {fitness?.length > 0 && <NewArrival productData={fitness} imagePath={imagePath} title="Kairaus's Handpicked Curation" discr="Beautiful pieces await—explore our handpicked masterpieces!" type="fitness" />}


      {/* <AboutUs aboutUsData={aboutUsData} /> */}

      <section className="all_categ">
        {haulis?.map((haulisItem, index) => (
          <div className="sub_categ" key={index}>
            <Link to={haulisItem?.button_link == 'collections' ? 'collections/offers' : haulisItem?.button_link}>
              <img src={`${haulisImagePath}${haulisItem?.image}`} alt="#" />
              <div className="sub_categ_text">
                <h3>{haulisItem?.title}</h3>
                <p>{haulisItem?.sub_title}</p>
                <button>Shop Now</button>
              </div>
            </Link>
          </div>
        ))}
      </section>

      {colorList?.length > 0 &&
        <section className='search_color'>
          <h3>Harmonious Hues</h3>
          <p>Transform your space with our stunning colour palettes!</p>
          <div className='color_container'>
            {colorList?.map((colorItem, index) => (
              <Link key={colorItem.id || index} to={`${Routes?.productByColor}/${colorItem?.slug}`}
                state={{ from: colorItem?.color, colorId: colorItem?.id }}>
                <div className='color_img_conat' key={index}>
                  <img src={`${colorImage}${colorItem?.image}`} alt='colorItem' loading="lazy" />
                  <span>{colorItem?.color}</span>
                </div>
              </Link>
            ))}
          </div>
        </section>}

      <section className='journal_wrapper'>
        <div className="container-fluid">
          <div className='row'>
            <h3 className='store_headings'>The Kairaus Journal</h3>
            <p>Stories of style and elegance for your everyday essentials!</p>
            {blogs && blogs.data.map((blog, index) => (
              <div className="col-md-4 col-sm-6 col-12 plan_categ" key={index}>
                <Link key={blog.image} to={`/blog/${blog.slug}`}>
                  {blog.image && <img src={`${blogs.path}/${blog.image}`} alt={blog.title} loading="lazy" />}
                  <div className="plan-texts">
                    <h4>{blog.title}</h4>
                  </div>
                </Link>
              </div>
            ))}
          </div>
          <div className='blog_viewmore'>
            <Link to={Routes?.BlogCategory}>View More</Link>
          </div>
        </div>
      </section>

      {/* <section className='loyality_Look'>
        <div className='shop_Our_Item'>

          {downData?.map((downItem, index) => (
            <Link key={downItem?.image} to={Routes?.Rewards}>
              <img
                src={`${downBannerImage}${downItem?.image}`}
                alt={`Loyalty banner ${index + 1}`} // More meaningful alt text
                loading="lazy" // Lazy load images for performance
              />
            </Link>
          ))}
          <img src={LoyalityImg} alt="#" />
          <div className='shop_Our_card'>
            <p>Never miss out the latest updates</p>
            <h3>Our Loyalty Program</h3>
            <Link to={Routes?.Rewards}>
              <button>Read More</button>
            </Link>
          </div>
        </div>
      </section> */}

      <section className='ask_conatiner_cards'>
        <div className='final_container'>
          {ShowListOne()}
        </div>
      </section>

      <section className='intragram_section'>
        <h2>Our Instagram Community!</h2>
        <p>Follow us on <Link>@kairaus</Link></p>
        <Marquee className='marquee' gradientColor='#fff' gradientWidth={100} gradient={true} pauseOnHover={true}>
          {posts.map((post, index) => (
            <div className="instragram_level" key={post.id || index}>
              <div className="instagram-post" key={post.id}>
                  <a href={post.permalink} target="_blank" rel="noopener noreferrer">
                <header className="post-head">
                  <div className="profile">

                    <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 256 256" className="profile-pic"><g fill="none"><rect width="256" height="256" fill="url(#skillIconsInstagram0)" rx="60" /><rect width="256" height="256" fill="url(#skillIconsInstagram1)" rx="60" /><path fill="#fff" d="M128.009 28c-27.158 0-30.567.119-41.233.604c-10.646.488-17.913 2.173-24.271 4.646c-6.578 2.554-12.157 5.971-17.715 11.531c-5.563 5.559-8.98 11.138-11.542 17.713c-2.48 6.36-4.167 13.63-4.646 24.271c-.477 10.667-.602 14.077-.602 41.236s.12 30.557.604 41.223c.49 10.646 2.175 17.913 4.646 24.271c2.556 6.578 5.973 12.157 11.533 17.715c5.557 5.563 11.136 8.988 17.709 11.542c6.363 2.473 13.631 4.158 24.275 4.646c10.667.485 14.073.604 41.23.604c27.161 0 30.559-.119 41.225-.604c10.646-.488 17.921-2.173 24.284-4.646c6.575-2.554 12.146-5.979 17.702-11.542c5.563-5.558 8.979-11.137 11.542-17.712c2.458-6.361 4.146-13.63 4.646-24.272c.479-10.666.604-14.066.604-41.225s-.125-30.567-.604-41.234c-.5-10.646-2.188-17.912-4.646-24.27c-2.563-6.578-5.979-12.157-11.542-17.716c-5.562-5.562-11.125-8.979-17.708-11.53c-6.375-2.474-13.646-4.16-24.292-4.647c-10.667-.485-14.063-.604-41.23-.604h.031Zm-8.971 18.021c2.663-.004 5.634 0 8.971 0c26.701 0 29.865.096 40.409.575c9.75.446 15.042 2.075 18.567 3.444c4.667 1.812 7.994 3.979 11.492 7.48c3.5 3.5 5.666 6.833 7.483 11.5c1.369 3.52 3 8.812 3.444 18.562c.479 10.542.583 13.708.583 40.396c0 26.688-.104 29.855-.583 40.396c-.446 9.75-2.075 15.042-3.444 18.563c-1.812 4.667-3.983 7.99-7.483 11.488c-3.5 3.5-6.823 5.666-11.492 7.479c-3.521 1.375-8.817 3-18.567 3.446c-10.542.479-13.708.583-40.409.583c-26.702 0-29.867-.104-40.408-.583c-9.75-.45-15.042-2.079-18.57-3.448c-4.666-1.813-8-3.979-11.5-7.479s-5.666-6.825-7.483-11.494c-1.369-3.521-3-8.813-3.444-18.563c-.479-10.542-.575-13.708-.575-40.413c0-26.704.096-29.854.575-40.396c.446-9.75 2.075-15.042 3.444-18.567c1.813-4.667 3.983-8 7.484-11.5c3.5-3.5 6.833-5.667 11.5-7.483c3.525-1.375 8.819-3 18.569-3.448c9.225-.417 12.8-.542 31.437-.563v.025Zm62.351 16.604c-6.625 0-12 5.37-12 11.996c0 6.625 5.375 12 12 12s12-5.375 12-12s-5.375-12-12-12v.004Zm-53.38 14.021c-28.36 0-51.354 22.994-51.354 51.355c0 28.361 22.994 51.344 51.354 51.344c28.361 0 51.347-22.983 51.347-51.344c0-28.36-22.988-51.355-51.349-51.355h.002Zm0 18.021c18.409 0 33.334 14.923 33.334 33.334c0 18.409-14.925 33.334-33.334 33.334c-18.41 0-33.333-14.925-33.333-33.334c0-18.411 14.923-33.334 33.333-33.334Z" /><defs><radialGradient id="skillIconsInstagram0" cx="0" cy="0" r="1" gradientTransform="matrix(0 -253.715 235.975 0 68 275.717)" gradientUnits="userSpaceOnUse"><stop stop-color="#FD5" /><stop offset=".1" stop-color="#FD5" /><stop offset=".5" stop-color="#FF543E" /><stop offset="1" stop-color="#C837AB" /></radialGradient><radialGradient id="skillIconsInstagram1" cx="0" cy="0" r="1" gradientTransform="matrix(22.25952 111.2061 -458.39518 91.75449 -42.881 18.441)" gradientUnits="userSpaceOnUse"><stop stop-color="#3771C8" /><stop offset=".128" stop-color="#3771C8" /><stop offset="1" stop-color="#60F" stop-opacity="0" /></radialGradient></defs></g></svg>
                    <span className="username">Kairaus</span>
                  </div>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="size-2">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 19.5l15-15m0 0H8.25m11.25 0v11.25" />
                    </svg>
                </header>
                </a>

                <div className="post-content">
                  <div className="grid">
                    {(post.media_type === 'IMAGE' || post.media_type === 'CAROUSEL_ALBUM') && <img src={post.media_url} alt="Instagram Post" />}
                    {post.media_type === 'VIDEO' && <video src={post.media_url} controls width="100%" poster={post.thumbnail_url} autoPlay muted loop playsInline />}
                  </div>
                </div>
                <footer className="post-footer">
                  <div className='icon_grid'>
                    <div className="icon"><HeartOutlined /> {post.like_count || 0}</div>
                    <div className="iocn_img">
                      <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 24 24">
                        <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 21a9 9 0 1 0-9-9c0 1.488.36 2.891 1 4.127L3 21l4.873-1c1.236.64 2.64 1 4.127 1Z" />
                      </svg> {post.comments_count || 0}
                    </div>
                  </div>
                  <p className="caption">{post.caption}</p>
                </footer>
              </div>
            </div>
          ))}
        </Marquee>
      </section>

      <section className="qty_info_main">
        <h2>Our Brand Pillars</h2>
        <p>Discover our secret sauce: elegance, quality, and a dash of passion!</p>
        <div className='brand_pillar'>
          {ShowBrandPillars()}
        </div>
      </section>

      {/* <section className='subcibe_Look'>
        <div className='shop_Our_Item'>
          <img src={SubscribeImg} alt="SubscribeImg" loading="lazy"/>
          <div className='shop_Our_card'>
            <p>Never miss out the latest updates</p>
            <h3>Subscribe Us</h3>
            <div className="contact_forms">
              <ContactUs />
            </div>
          </div>
        </div>
      </section> */}
      {open && <BulkDrawer onClose={onClose} openDrawer={open} productId={'0'} drawerHeading={drawerHeading} />}
    </>
  );
});

export default Home