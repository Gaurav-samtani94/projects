import React, { useMemo } from 'react';
import { Collapse } from 'antd';
import { useSelector } from 'react-redux';

const SeoContent = ({ isAOpen }) => {
    const seoDescription = useSelector((state) => state.seo.description); // Access the description from the Redux store
    const items = useMemo(() => [
        {
            key: '001',
            children: seoDescription
                ? <div dangerouslySetInnerHTML={{ __html: seoDescription }} className='seo_content' />
                : '', // Fallback message
        }
    ], [seoDescription]);

    return (
        <section className='seo_words'>
            <Collapse activeKey={[isAOpen ? "001" : ""]} ghost items={items} />
        </section>
    );
};

export default SeoContent;
