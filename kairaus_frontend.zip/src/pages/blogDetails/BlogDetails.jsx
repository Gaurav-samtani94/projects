import React, { useCallback, useEffect, useRef, useState } from 'react'
import Container from 'react-bootstrap/Container';
import { getBlogDetails } from '../../services/blog'
import { useNavigate, useParams } from 'react-router-dom';
import Accordion from 'react-bootstrap/Accordion';
import Routes from '../../Routes/Routes';
import { getBlogFag } from '../../services/faq';

const Blog = () => {

    const [blogDetail, setBlogDetail] = useState([]);
    const { slug } = useParams();
    // console.log('slug==>>>',slug);
    const navigate = useNavigate();

    const fetchBlogDetail = async () => {
        try {
            const blogResponse = await getBlogDetails(slug);
            if (blogResponse === 404) {
                navigate(Routes.Error);
            }
            if (blogResponse.status === '1') {
                setBlogDetail(blogResponse);
            }
        } catch (error) {
            console.error('Error fetching data:', error);
        }

    };
    const [blogFaq, setBlogFaq] = useState(null);

    const fetchData = useCallback(async () => {
        try {
            const formData = new URLSearchParams();
            formData.append('blog_title', slug);
            const response = await getBlogFag(formData);
            if (response.status === '1') {
                setBlogFaq(response.data);
            }

        } catch (error) {
            console.error('Error fetching FAQ data:', error);
        }
    }, []);

    useEffect(() => {
        fetchBlogDetail();
        fetchData();
    }, [slug]);


    return (
        <>
            <div className='spedia_blog_main'>
                <div className='blog_content_right'>
                    <h1>{blogDetail?.data?.title}</h1>
                    {/* <h4>How to Choose the Perfect Dinnerware Set</h4> */}
                    <p>{blogDetail?.data?.created_at}</p>
                </div>
                <div className='blog_content_left'>
                    <img src={blogDetail?.path + blogDetail?.data?.image} alt="not found" />
                </div>
            </div>
            <section className='blog_sec_two'>
                <Container>
                    <p className='blog_sec_two_main' dangerouslySetInnerHTML={{ __html: blogDetail?.data?.description }}></p>
                </Container>
                {blogFaq && <div className='faqs_productDetails'>
                    <section className='faqs_accor_main_sec1'>
                        <h4>Frequently Asked Questions</h4>
                        <Accordion defaultActiveKey="0">
                            {blogFaq?.map((qa, index) => (
                                <Accordion.Item eventKey={index.toString()} key={index}>
                                    <Accordion.Header>{qa.question}</Accordion.Header>
                                    <Accordion.Body>{qa.answer}</Accordion.Body>
                                </Accordion.Item>
                            ))}
                        </Accordion>
                    </section>
                </div>}

            </section>
        </>

    )
}

export default Blog