import { useEffect } from "react";
import { getAllBlog } from "../services/blog";

function SitemapBlogs() {
  const baseUrlSitemap = 'https://kairaus.com/blog';

  useEffect(() => {
    const fetchDataAndGenerateSitemap = async () => {
      const convertToStateEncoded = (name) =>
        name
          .toLowerCase()
          .replace(/\s+/g, '-')
          .replace(/&/g, 'and')
          .replace(/[()]/g, '');

      const escapeXml = (unsafe) =>
        typeof unsafe === "string"
          ? unsafe.replace(/[<>&'"]/g, (c) => {
              switch (c) {
                case "<": return "&lt;";
                case ">": return "&gt;";
                case "&": return "&amp;";
                case "'": return "&apos;";
                case '"': return "&quot;";
                default: return c;
              }
            })
          : "";

      const getCurrentDateTime = () => new Date().toISOString();

      const getRandomPriority = () => (Math.random() * 0.9 + 0.1).toFixed(1);

      try {
        const blogResponse = await getAllBlog();
        if (blogResponse?.status !== "1") {
          throw new Error("Failed to fetch blog data");
        }

        const blogsData = blogResponse.data;
        const blogUrls = blogsData.map((item) => {
          const stateName = escapeXml(convertToStateEncoded(item.slug));
          const lastmod = escapeXml(getCurrentDateTime());
          const priority = escapeXml(getRandomPriority());
          const loc = `${baseUrlSitemap}/${stateName}`;
          return `
            <url>
              <loc>${loc}</loc>
              <lastmod>${lastmod}</lastmod>
              <priority>${priority}</priority>
            </url>
          `;
        }).join("");

        const xmlContent = `<?xml version="1.0" encoding="UTF-8"?>
          <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
            ${blogUrls}
          </urlset>`;

        const blob = new Blob([xmlContent], { type: "application/xml" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "sitemap_blogs.xml";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } catch (error) {
        console.error("Error generating sitemap:", error);
      }
    };

    fetchDataAndGenerateSitemap();
  }, []);

  return null;
}

export default SitemapBlogs;
