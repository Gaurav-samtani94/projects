import axios from 'axios';
import React from 'react';
import FacebookLogin from 'react-facebook-login';
import { LoginSocialFacebook } from 'reactjs-social-login';
import { signUpData } from '../services/auth/singUp';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addToUser } from '../reducers/userSlice';
import Routes from '../Routes/Routes';


const FacebookSocialLogin = () => {
    const navigate = useNavigate()
    const dispatch = useDispatch();

    const toBase64 = (str) => {
        return btoa(unescape(encodeURIComponent(str)));
      };
    
  const responseFacebook = async(response) => {
    const base64Response = toBase64(JSON.stringify(response));
    console.log(response,"response")
    if(response?.error){
        return;
    }
    if (response?.accessToken) {
        const formData = new URLSearchParams();
        formData?.append("social_token", base64Response)
        formData.append('is_social_login', "1")
        formData.append('social_login_type', "2")

        const responseData = await signUpData(formData);
        const { id, email, userfullname, lastname } = responseData.data;
            const userInfo = { id, email, userfullname, lastname, token: responseData.token };
            localStorage.setItem('user', JSON.stringify(userInfo));
            dispatch(addToUser(userInfo));
            navigate(Routes.Home);
    } else {
      console.error("Facebook login failed");
    }
  };

  return (
    <div>
      <FacebookLogin
        appId="2273991179646547"
        autoLoad={false}
        fields="name,email,picture" // Get the necessary fields
        callback={responseFacebook} // Callback function when login is successful
        icon="fa-facebook" // Optional icon for the button
        textButton="Login with Facebook"
      />
    </div>
  );
};

export default FacebookSocialLogin;
