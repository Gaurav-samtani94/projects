import React, { useEffect } from 'react';
import { Input, Form, message } from 'antd';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { loginForm } from '../../services/auth/login';
import { useDispatch, useSelector } from 'react-redux';
import { addToUser } from '../../reducers/userSlice';
import { toast } from 'react-toastify';
import Routes from '../../Routes/Routes';
import { STRINGS } from '../../constants/Constant';

const SignIn = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { from } = location.state || { from: Routes.Home };;
  const user = useSelector((state) => state.user);
  // console.log('fromm', from);
  useEffect(() => {
    // Check if the user is already logged in
    if (user && user.id) {
      // User is already logged in, navigate to the home page
      if (from) {
        navigate(from);
      } else {
        navigate(Routes.Home);
      }

    }
  }, [user, navigate, from]);

  const emailRules = [
    {
      type: 'email',
      required: true,
      message: 'Please input your Email!',
    },
  ];

  const passwordRules = [
    {
      required: true,
      message: 'Please input your password!',
    },
  ];

  const handleSubmit = async (values) => {
    const { username, password } = values;
    // Check if both username and password are present
    if (!username || !password) {
      message.error('Please enter both username and password.');
      return;
    }

    try {
      const formData = new URLSearchParams();
      formData.append('username', username);
      formData.append('password', password);

      const responseData = await loginForm(formData);

      if (responseData.status === '1') {
        const { id, email, userfullname } = responseData.data;
        const userInfo = { id, email, userfullname, token: responseData.token };

        // console.log('API Response newItem:', userInfo);

        localStorage.setItem('user', JSON.stringify(userInfo));
        dispatch(addToUser(userInfo));
        navigate(from);
        toast.success(STRINGS.RECORD_UPDATED_SUCCESSFULLY);
      }
    } catch (error) {
      console.error('API Request Error:', error);
      message.error(STRINGS.LOGIN_FAILED_CHECK_CREDENTIALS);
      toast.error(STRINGS.LOGIN_FAILED_CHECK_CREDENTIALS);
    }
  };

  return (
    <div className='BD_master_wrapper'>
      <div className='bd_model_left'>
        <h1>Sign In!</h1>

        <Form name="control-hooks" layout="vertical" onFinish={handleSubmit} autoComplete="off">
          <Form.Item label={<>Email</>} name="username" rules={emailRules}>
            <Input />
          </Form.Item>
          <Form.Item label={<>Password</>} name="password" rules={passwordRules}>
            <Input.Password />
          </Form.Item>
          <div className='forget'>
            <span>Forgot password?</span>
          </div>
          <div className='bd_model_button'>
            <button key="submit" className='BG_mainButton' type="submit">
              Submit
            </button>
          </div>
          <div className='notice'>
            <p>By continuing, you agree to Kairaus's Conditions of Use and Privacy Notice.</p>
          </div>
          <div className='Storepedia'>
            <Link to={Routes?.SignUp}>
              New to Kairaus?
              {/* New to Kairaus.? */}
            </Link>
          </div>
          <button key="submit" className='BG_mainButton2'>
            Create an Account
          </button>
        </Form>
      </div>
    </div>
  );
};

export default SignIn;
