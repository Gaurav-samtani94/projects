// services/contactUs.js
import axios from "axios";

const apiConfig = {
  baseURL: process.env.REACT_APP_API_BASE_URL || 'https://demo1.growthgrids.com/api/user',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
};

const api = axios.create(apiConfig);

const handleApiError = (error) => {
  // console.error('API Error:', error);
  let errorMessage = 'An error occurred. Please try again later.';
  if (error.response && error.response.data && error.response.data.message) {
    errorMessage = error.response.data.message;
  }
  throw new Error(errorMessage);
};

export const getAllProducts = async (data) => {
  try {
    const response = await api.post('/get-all-product', data);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};


export const searchByKeywords = async (token) => {
  try {
    const response = await api.get('/get-search-keyword-history',{
    headers: {
      Authorization: token,
    },
  }
  );
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const getTrendingSearch = async (token) => {
  try {
    const response = await api.get('/get-trending-keyword',{
    headers: {
      Authorization: token,
    },
  }
  );
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const stockAvailabilityCheck = async (data,token) => {
  try {
    const response = await api.post('/check-product-stock',data,{
    headers: {
      Authorization: token,
      'Content-Type': 'application/json',
    },
  }
  );
    return response.data;
  } catch (error) {
    if(error.response?.status===404){
      return 404;
    }
    
    // return handleApiError(error);
  }
};
export const allNewArrivals = async (data) => {
  try {
    const response = await api.post('/all-new-arrivals', data);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const allmoreproduct = async (data) => {
  try {
    const response = await api.post('/get-more-product', data);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const productApi = {getAllProducts, searchByKeywords, getTrendingSearch, stockAvailabilityCheck,allNewArrivals, allmoreproduct}