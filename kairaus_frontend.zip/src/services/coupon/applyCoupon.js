// services/coupon/Coupon.js
import axios from "axios";

const apiConfig = {
  baseURL: process.env.REACT_APP_API_BASE_URL || 'https://demo1.growthgrids.com/api/user',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
};

const api = axios.create(apiConfig);

const handleApiError = (error) => {
  // console.error('API Error:', error);

  if (error.response && error.response.data && error.response.data.message) {
    throw new Error(error.response.data.message);
  } else {
    throw new Error('An error occurred. Please try again later.');
  }
};

export const getApplyCouponData = async (data, token) => {
  // console.log('coupon token :',token);
  // try {
  const response = await api.post('/applies-coupon', data, {
    headers: {
      Authorization: token,
    },
  });
  return response.data;
  // } catch (error) {
  //   handleApiError(error);
  // }
};
export const removeCoupon = async (data, token) => {
  try {
    const response = await api.post('/remove-coupon',data, {
      headers: {
        Authorization: token,
      },
    });
    return response.data;
  } catch (error) {
    handleApiError(error);
    throw error; // Re-throw the error if further handling is needed
  }
};
// /apply-reward-point
export const applyRewardPoint = async (token) => {
  // try {
  const response = await api.post('/apply-reward-point', {}, {
    headers: {
      Authorization: token,
    },
  });
  return response.data;
  // } catch (error) {
  //   handleApiError(error);
  // }
};
// /apply-reward-point
export const cartAmountList = async (token) => {
  // try {
  const response = await api.get('/get-cart-amount-list', {
    headers: {
      Authorization: token,
    },
  });
  return response.data;
  // } catch (error) {
  //   handleApiError(error);
  // }
};
export const getCartAmountdetail = async (data, token) => {
  try {
    const response = await api.post('/get-cart-amount-detail', data, {
      headers: {
        Authorization: token,
      },
    });
    return response.data;
  } catch (error) {
    handleApiError(error);
  }

};
export const toggleFirstCoupon = async (data,token) => {
  try {
    const response = await api.post('/remove-apply-first-order-coupon',data, {
      headers: {
        Authorization: token,
      },
    });
    return response.data;
  } catch (error) {
    handleApiError(error);
    throw error; // Re-throwing the error for further handling if needed
  }
};

