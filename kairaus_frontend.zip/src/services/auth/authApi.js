import axios from "axios";
import { handleApiError } from "../../function/apiErrorHandler";

const apiConfig = {
  baseURL: process.env.REACT_APP_API_BASE_URL || 'http://api.growthgrids.com:3011/api/user',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
};

const api = axios.create(apiConfig);

// const handleApiError = (error) => {
//   // console.error('API Error:', error);
//   let errorMessage = 'An error occurred. Please try again later.';
//   if (error.response && error.response.data && error.response.data.message) {
//     errorMessage = error.response.data.message;
//   }
//   return errorMessage;
// };

 const editUserProfile= async (data,token) => {
  try {
    const response = await api.post('/edit-user-profile', data, {
        headers: {
          Authorization: token,
        },
      });
      if (response.status === 200) {
        return response.data;
      } else {
        // throw new Error(`API Error: ${response.statusText}`);
        return response.statusText;
      }
  } catch (error) {
    return handleApiError(error);
    // return error;
  }
};

const getProfileDetail= async (token) => {
  try {
    const response = await api.get('/user-profile', {
        headers: {
          Authorization: token,
        },
      });
      if (response.status === 200) {
        return response.data;
      } else {
        throw new Error(response.statusText);
      }
  } catch (error) {
    return handleApiError(error);
  }
};

const changePassword= async (data,token) => {
  try {
    const response = await api.post('/change-password', data, {
        headers: {
          Authorization: token,
        },
      });
      if (response.status === 200) {
        return response.data;
      } else {
        throw new Error(response.statusText);
      }
  } catch (error) {
    // return handleApiError(error);
    return error;
  }
};

const forgotPassword = async (data) => {
  try {
    const response = await api.post('/forgot-password', data);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

const getOrderDetail= async (data,token) => {  
  try {
    const response = await api.post('/get-order-list', data, {
        headers: {
          Authorization: token,
        },
      });
      if (response.status === 200) {
        return response.data;
      } else {
        throw new Error(response.statusText);
      }
  } catch (error) {
    return handleApiError(error);
  }
};

const sendOtp= async (data,token) => {
  try {
    const response = await api.post('/send-mobile-verify-otp', data, {
        headers: {
          Authorization: token,
        },
      });
      if (response.status === 200) {
        return response.data;
      } else {
        throw new Error(response.statusText);
      }
  } catch (error) {
    return handleApiError(error);
  }
};

const verifyOtp= async (data,token) => {
  try {
    const response = await api.post('/verify-mobile-otp', data, {
        headers: {
          Authorization: token,
        },
      });
      if (response.status === 200) {
        return response.data;
      } else {
        throw new Error(response.statusText);
      }
  } catch (error) {
    return handleApiError(error);
  }
};

const downloadInvoice= async (data,token) => {
  try {
    const response = await api.post('/download-invoice', data, {
        headers: {
          Authorization: token,
        },
      });
      if (response.status === 200) {
        return response.data;
      } else {
        throw new Error(response.statusText);
      }
  } catch (error) {
    return handleApiError(error);
  }
};

const resetPassword = async (data) => {
  try {
    const response = await api.post('/reset-password', data);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

const sendEmailOtp= async (data) => {
  try {
    const response = await api.post('/send-email-otp', data);
      if (response.status === 200) {
        return response.data;
      } else {
        throw new Error(response.statusText);
      }
  } catch (error) {
    return handleApiError(error);
  }
};

const verifyEmailOtp= async (data,token) => {
  try {
    const response = await api.post('/verify-email-otp', data, {
        headers: {
          Authorization: token,
        },
      });
      if (response.status === 200) {
        return response.data;
      } else {
        throw new Error(response.statusText);
      }
  } catch (error) {
    return handleApiError(error);
  }
};



export const authApi = {editUserProfile,getProfileDetail, changePassword, forgotPassword, getOrderDetail, sendOtp, verifyOtp, downloadInvoice, resetPassword, sendEmailOtp, verifyEmailOtp}
