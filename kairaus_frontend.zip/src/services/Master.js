// services/Master.js
import axios from 'axios';

const apiConfig = {
  baseURL: process.env.REACT_APP_API_BASE_URL || 'https://demo1.growthgrids.com/api/user',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
};

const api = axios.create(apiConfig);



// const api = axios.create({
//   baseURL: process.env.REACT_APP_API_BASE_URL || 'hhttps://demo1.growthgrids.com/api/user',
// });

const Master = async (data) => {
  try {
    const response = await api.post('/menu-list',data);
    if (response.status === 200) {
      return response.data;
    } else {
      throw new Error(`API Error: ${response.statusText}`);
    }
  } catch (error) {
    // console.error('Error fetching menu data:', error);
    throw error; // Re-throw the error to allow the calling code to handle it
  }
};

export const SubMenu = async (data) => {
  try {
    const response = await api.post('/sub-menu-list',data);
    if (response.status === 200) {
      return response.data;
    } else {
      throw new Error(`API Error: ${response.statusText}`);
    }
  } catch (error) {
    // console.error('Error fetching menu data:', error);
    throw error; // Re-throw the error to allow the calling code to handle it
  }
};

export const HeaderApi = {Master}