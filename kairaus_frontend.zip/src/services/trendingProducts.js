import axios from 'axios';
const apiConfig = {
    baseURL: process.env.REACT_APP_API_BASE_URL || 'http://api.growthgrids.com:3011/api/user',
};  
const api = axios.create(apiConfig);

const handleApiError = (error) => {
    console.errror('API Error:', error);
    throw error;
}

export const trendingProducts = async (data) => {
  try {
    const response = await api.post('/get-trending-products-by-category', data);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};


// export const trendingProducts = async (category_id) => {
//     try {
//       const data = {
//         category_id: category_id,
//       };
//       const formData = qs.stringify(data);
//       // Make the POST request using Axios
//       const response = await api.post('/get-trending-products-by-category', formData, {
//         headers: {
//           'Content-Type': 'application/x-www-form-urlencoded',
//         },
//       });
  
//       if (response.status === 200) {
//         return response.data;
//       } else {
//         throw new Error(`API Error: ${response.statusText}`);
//       }
//     } catch (error) {
//       // Log the error or handle it appropriately
//       console.error('Error:', error);
//       return handleApiError(error);
//     }
//   };
  


