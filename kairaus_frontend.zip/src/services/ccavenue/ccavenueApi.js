// services/coupon/Coupon.js
import axios from "axios";
import { handleApiError } from "../../function/apiErrorHandler";
// const apiConfig = {
//   baseURL: process.env.NODE_ENV === 'production' 
//     ? 'hhttps://demo1.growthgrids.com' 
//     : 'https://demo1.growthgrids.com', // Replace with your local development URL
//   headers: {
//     'Content-Type': 'application/x-www-form-urlencoded',
//   },
// };
const apiConfig = {
  baseURL: process.env.REACT_APP_API_PAY_ENV,
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
  },
};


const api = axios.create(apiConfig);

// const handleApiError = (error) => {
//   // console.error('API Error:', error);

//   if (error.response && error.response.data && error.response.data.message) {
//     throw new Error(error.response.data.message);
//   } else {
//     throw new Error('An error occurred. Please try again later.');
//   }
// };

export const ccavenueResponse = async (data, token) => {

  try {
  const response = await api.post('/payment/initiate-payment', data, {
    headers: {
      Authorization: token,
    },
  });
  return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

export const razorpayInserOrderResponse = async (data, token) => {

  try {
  const response = await api.post('/payment/insert-order', data, {
    headers: {
      Authorization: token,
    },
  });
  return response.data;
  } catch (error) {
    handleApiError(error);
  }
};


export const razorpayVerifyPaymentResponse = async (data, token) => {

  try {
  const response = await api.post('/payment/verify-payment', data, {
    headers: {
      Authorization: token,
    },
  });
  return response.data;
  } catch (error) {
    handleApiError(error);
  }
};

