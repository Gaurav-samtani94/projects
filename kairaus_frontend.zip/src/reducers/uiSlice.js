// import { saveStateToLocalStorage } from "@/utils/localStorageUtills";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    screenSize: 0,
    brownLayerIsInView: false
}

// const saveAuthState = (state) => {
//     saveStateToLocalStorage('ui', {
//         ...state
//     })
// }

const uiSlice = createSlice({
    name: 'ui',
    initialState,
    reducers: {
        updateScreenSize: (state, action) => {
            state.screenSize = action.payload;
            // saveAuthState(state)
        },
        // updateBrownLayer: (state, action) => {
        //     state.brownLayerIsInView = action.payload;
        //     saveAuthState(state)
        // }
    }
})

export const { updateScreenSize, updateBrownLayer } = uiSlice.actions;
export default uiSlice.reducer; 