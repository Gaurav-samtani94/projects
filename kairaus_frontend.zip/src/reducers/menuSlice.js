
import { createSlice } from '@reduxjs/toolkit';

const menuSlice = createSlice({
  name: 'navigationMenu',
  initialState: {
    categories_1: [],
    categories_2: [],
    categories_3: [],
    categories_4: [],
  },  // Store categories as an object in initialState
  reducers: {
    setSliceMenuData: (state, action) => {
      // Store each category separately in the state
      state.menu_img_path = action.payload.menu_img_path;
      state.categories_1 = action.payload.categories_1 || [];
      state.categories_2 = action.payload.categories_2 || [];
      state.categories_3 = action.payload.categories_3 || [];
      state.categories_4 = action.payload.categories_4 || [];
    },
  },
});

export const { setSliceMenuData } = menuSlice.actions;

export default menuSlice.reducer;

