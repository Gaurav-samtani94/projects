// userSlice.js
import { createSlice } from '@reduxjs/toolkit';

const slugSlice = createSlice({
  name: 'slug',
  initialState: {},
  reducers: {
    addToSlug: (state, action) => {
      return { ...state, ...action.payload };
    },
  },
});

// Action creators are generated for each case reducer function
export const { addToSlug } = slugSlice.actions;
export default slugSlice.reducer;
