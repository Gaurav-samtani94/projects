import { createSlice } from '@reduxjs/toolkit';

// Retrieve stored data from localStorage
const storedData = typeof window !== 'undefined' ? localStorage.getItem('localCoupons') : null;
const getStoredCoupons = storedData ? JSON.parse(storedData) : [];

// Create the slice
const localCouponSlice = createSlice({
  name: 'localCoupon',
  initialState: getStoredCoupons,
  reducers: {
    storeLocalCoupon: (state, action) => {
      const newState = action.payload; // Get the new state from the payload
      // Update localStorage with the new state
      if (Array.isArray(newState)) {
        localStorage.setItem('localCoupons', JSON.stringify(newState)); // Store in localStorage
      }
      return newState; // Return the new state
    },
    clearLocalCoupons: () => {
      // Check if window is available before accessing localStorage
      if (typeof window !== 'undefined') {
        localStorage.removeItem('localCoupons'); // Clear from localStorage
      }
      return []; // Reset state
    },
  },
});

// Export the action and reducer
export const { storeLocalCoupon, clearLocalCoupons } = localCouponSlice.actions;
export default localCouponSlice.reducer;
