import { createSlice } from '@reduxjs/toolkit';

const proCount = false

const productCountSlice = createSlice({
    name: 'productCount',
    initialState: proCount,
    reducers: {
        addProductCount: (state, action) => {
            return action.payload; // This replaces the entire state with the new payload

    },
},
});

export const { addProductCount } = productCountSlice.actions;

export default productCountSlice.reducer;