// storeInstance.js
let storeInstance;

export const setStoreInstance = (store) => {
  storeInstance = store;
};

export const getStoreInstance = () => storeInstance;
