import Routes from "../../Routes/Routes";
import CalculateTotals from "../../utils/cartUtils";

const DrawerLocalCartPriceList = ({ handleCouponClick, from }) => {
  // Access the constants from the .env 
  const shippingAmount = process.env.REACT_APP_SHIPPING_AMOUNT;
  const applyMaxAmount = process.env.REACT_APP_APPLY_MAX_AMOUNT;
  // Safely destructure with default values
  const {
    total: { totalComparePrice = 0, totalCount = 0 } = {},
    grandTotal = 0,
    bagDiscount = 0,
    firstOrderCouponDiscount = 0,
    isCouponTypePercent,
    firstOrderCouponValue,
    currencySymbol,
    couponDiscount,
    coupon_code = '',
  } = CalculateTotals() || {};

  const slug = window.location.href;

  // Reusable function to render price details
  const renderPriceDetail = (label, amount, isNegative = true) => {
    if (amount <= 0) return null; // Skip rendering if the amount is 0 or less
    return (
      <div className="prize_dra">
        <p>{label}</p>
        {/* <p>{isNegative ? `- ${currencySymbol} ${amount.toFixed(0)}` : `${currencySymbol}${amount.toFixed(0)}`}</p> */}
        <p>{isNegative ? `- ${currencySymbol} ${Math.round(amount)}` : `${currencySymbol}${Math.round(amount)}`}</p>
      </div>
    );
  };

  const shippingCharges = from === 'maincheckout' && grandTotal < applyMaxAmount ? (
    <div className="prize_dra">
      <p>Shipping Charges</p>
      <p>+{shippingAmount}</p>
    </div>
  ) : null;

  // const couponDetails = !slug?.includes('/mainCheckout') && (
  //   <div className="prize_dra" onClick={handleCouponClick}>
  //     <div className="extra_coupons">
  //       <p>Coupon Discount {couponDiscount ? `(${coupon_code})` : null}</p>
  //     </div>
  //     {couponDiscount > firstOrderCouponDiscount ? (
  //       <span>-{currencySymbol} {couponDiscount-firstOrderCouponDiscount}</span>
  //     ) : (
  //       <span onClick={handleCouponClick}>Apply Coupon</span>
  //     )}
  //   </div>
  // );

  const couponDetails = () => {
    return (
      couponDiscount - firstOrderCouponDiscount > 0 ?
       <div className="prize_dra" onClick={handleCouponClick}>

        <div className="extra_coupons">
          <p>Coupon Discount {couponDiscount - firstOrderCouponDiscount > 0 ? `(${coupon_code})` : null}</p>
        </div>
        {couponDiscount > firstOrderCouponDiscount ? (
          <span>-{currencySymbol} {(couponDiscount - firstOrderCouponDiscount)?.toFixed(0)}</span>
        ) : (
          <span onClick={handleCouponClick}>Apply Coupon</span>
        )}
      </div>
      :
      !slug?.includes(Routes?.MainCheckout) &&  <div className="prize_dra" onClick={handleCouponClick}>

      <div className="extra_coupons">
        <p>Coupon Discount {couponDiscount - firstOrderCouponDiscount > 0 ? `(${coupon_code})` : null}</p>
      </div>
      {couponDiscount > firstOrderCouponDiscount ? (
        <span>-{currencySymbol} {(couponDiscount - firstOrderCouponDiscount)?.toFixed(0)}</span>
      ) : (
        <span onClick={handleCouponClick}>Apply Coupon</span>
      )}
    </div>
      
    )
  }


  const newGrandTotal = from === 'maincheckout' ? 0 : shippingAmount;

  return (
    <div className="prize_detail">
      <h4>Price Details</h4>

      {/* Bag MRP */}
      <div className="prize_dra">
        <p>Bag MRP ({totalCount} items)</p>
        <p>{currencySymbol} {totalComparePrice.toFixed(0)}</p>
      </div>

      {/* Conditional Price Details */}
      {renderPriceDetail("Kairaus Savings", bagDiscount)}
      {firstOrderCouponDiscount > 0 &&
        renderPriceDetail(`First Order Discount (${firstOrderCouponValue}${isCouponTypePercent ? "%" : ""})`, firstOrderCouponDiscount)
        }

      {couponDetails()}
      {shippingCharges}

      {/* Grand Total */}
      <div className="prize_dra">
        <p className="p_bold">Total</p>
        <p className="p_bold">{currencySymbol} {Math.round(grandTotal < 1499 ? grandTotal - newGrandTotal : grandTotal)}</p>
      </div>
    </div>
  );
};

export default DrawerLocalCartPriceList;
