import React from 'react';
import { useNavigate } from 'react-router-dom';
import Routes from '../../Routes/Routes';
import { useDispatch, useSelector } from 'react-redux';
import { clearBuy } from '../../reducers/buySlice';
import CalculateTotals from '../../utils/cartUtils';

const ProceedSection = ({ onClose, showGSTForm, isINR, currencySymbol,grandTotal }) => {
  const { id } = useSelector((state) => state.user);
  const cartIds = useSelector((state) => state.cartId);
  const cart = useSelector((state) => state.cart);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const {
    total: { totalComparePrice = 0, totalCount = 0 } = {},
    bagDiscount = 0,
    // grandTotal=0,
    firstOrderCouponDiscount = 0,
    isCouponTypePercent,
    firstOrderCouponValue,
  } = CalculateTotals() || {};
  
  const filteredCartData = cart.filter((product) => product.isChecked);
  // console.log("grandTotal===",grandTotal)

  const renderProceedButton = () => {
    if (grandTotal !== 0) {
      return (
        <button className='proceed_btn' onClick={handleProceedClick} style={{ cursor: 'pointer' }}>
          Proceed
          <i><svg width="23" height="23" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 12L24 24L12 36" stroke="#fff" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><path d="M24 12L36 24L24 36" stroke="#fff" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg>
          </i>
        </button>
      );
    } else {
      return (
        <button className='proceed_btn' disabled style={{ cursor: 'not-allowed' }}>
          Proceed
          <i>
            <svg width="23" height="23" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 12L24 24L12 36" stroke="#fff" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><path d="M24 12L36 24L24 36" stroke="#fff" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg>
          </i>
        </button>
      );
    }
  };
  const buy = useSelector((state) => state.buy) || [];


  // const handleProceedClick = () => {    // For existing functionality
  //   if (buy.length > 0) {
  //     dispatch(clearBuy());
  //     localStorage.removeItem('buy');
  //   }

  //   if (cartIds.length === cart.length) {
  //     localStorage.setItem('localCartIds', JSON.stringify([]));
  //   }
  //   if (id) {
  //     navigate(Routes?.Checkout);
  //   } else {
  //     navigate(Routes?.SignIn, { state: { from: Routes?.Checkout } });
  //   }
  //   onClose();
  // };

  // For new functionality
  const handleProceedClick = () => {
    navigate(Routes?.MainCheckout);
    onClose();
  };



  let newApplied_price;

  let l = totalComparePrice - bagDiscount
  let s = l - firstOrderCouponDiscount
  let appliedTenPerc = (s.toFixed(0)) * 10 / 100;


  newApplied_price = s.toFixed(0) - appliedTenPerc.toFixed(0)



  return (
    <div className='proceed_drawer'>
      {/* <div className='proceed_money'>
        <p className='bold_thousand'>{isINR ? "₹" : currencySymbol} {grandTotal.toFixed(2)}</p>
      <div className='proceed_money'>
        <p className='bold_thousand'>{isINR ?"₹":currencySymbol} {Math.round(grandTotal - 70)}</p>
        <p>Grand Total</p>
      </div>
      {renderProceedButton()} */}

      {/* {!id ?
        <div className='checkout-ii'>
          <button class="fill" onClick={handleProceedClick}>Checkout - ₹ {newApplied_price?.toFixed(2)}</button>
        </div>
       :
        <div className='checkout-ii'>
          <button class="fill" onClick={handleProceedClick} disabled={grandTotal !=0 ?false : true} >Checkout - ₹ {grandTotal?.toFixed(2)}</button>
        </div>
      }
       */}
       <div className='checkout-ii'>
          <button class="fill" onClick={handleProceedClick} disabled={filteredCartData?.length  !=0 ?false : true} >Checkout - ₹ { filteredCartData?.length !=0 ? Math?.round(grandTotal) : 0}</button>
        </div>
      {/* {renderProceedButton()} */}
    </div>
  );
};

export default ProceedSection;
