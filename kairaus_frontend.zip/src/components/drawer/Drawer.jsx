import React, { useEffect, useState } from 'react';
import { Drawer, Radio, Checkbox, Tooltip, Modal, Button } from 'antd';
import { Link, useNavigate } from 'react-router-dom';
import { FaGreaterThan } from 'react-icons/fa6';
import frame from '../../assets/images/Frame.png';
import DrawerCuppon from './DrawerCuppon';
import ProceedSection from './ProceedSection';
import DrawerCartProduct from './DrawerCartProduct';
import Routes from '../../Routes/Routes';
import { toast } from 'react-toastify';
import { useDispatch, useSelector } from 'react-redux';
import NoCartimg from '../../assets/images/nocart.png'
import { STRINGS } from '../../constants/Constant';
import CalculateTotals from '../../utils/cartUtils';
import DeleteImg from '../../assets/images/delete.webp'
import trashLottie from '../../assets/images/trash-lottie.json'
import Lottie from 'react-lottie'
import { addToCart, clearCart } from '../../reducers/cartSlice';
import { deleteCart, updateCartStatus } from '../../services/cart/addCart';
import { applyCoupon } from '../../reducers/couponSlice';
import { getRewardsPoints } from '../../services/rewardpoints/getRewards';
import { clearUser } from '../../reducers/userSlice';
import { applyRewardPoint, cartAmountList, getApplyCouponData, removeCoupon, toggleFirstCoupon } from '../../services/coupon/applyCoupon';
import { debounce } from 'lodash';
import couponsImg from '../../assets/images/couponsImg.webp';
import { setFirstOrderCoupon } from '../../reducers/firstOrderCouponSlice';
import DrawerCartPriceList from './DrawerCartPriceList';
import DrawerLocalCartPriceList from './DrawerLocalCartPriceList';
import { clearLocalCoupons, storeLocalCoupon } from '../../reducers/localCouponSlice';
import { CloseOutlined } from '@ant-design/icons';


const DrawerCart = ({ onClose, openDrawer }) => {
  // console.log('openDrawer',openDrawer);
  // const grandTotal=0
  const shippingAmount = process.env.REACT_APP_SHIPPING_AMOUNT;
  // console.log(shippingAmount,"shippingAmount")
  const { grandTotal = 0 } = CalculateTotals();
  // console.log(grandTotal,"grandTotal")
  // const newGrandTotal = grandTotal < 999 ? grandTotal : grandTotal - 70;
  // console.log(newGrandTotal,"newgrandTotal")
  // console.log("grandTotalgrandTotal",newGrandTotal);


  const [openCupponDrawer, setOpenCupponDrawer] = useState(false);
  const cart = useSelector((state) => state.cart);
  const couponDis = useSelector((state) => state.couponDis);
  const firstOrderCoupon = useSelector((state) => state.firstOrderCoupon);
  const totalProductCount = cart.reduce((total, item) => total + item.count, 0);
  const dispatch = useDispatch();
  const [rewardPointsChecked, setRewardPointsChecked] = useState(false);
  const [points, setPoints] = useState(0);
  const [rewardPoints, setRewardPoints] = useState(null)
  let firstOrderCouponDetail = localStorage.getItem('FirstOrderCouponDetails');
  const excRate = useSelector(state => state.excrate);
  const user = useSelector((state) => state.user);
  const { token } = user;
  const navigate = useNavigate();
  const [cartPriceList, setCartPriceList] = useState(null);
  const [isFirstOrderCouponApplied, setIsFirstOrderCouponApplied] = useState(!token);
  firstOrderCouponDetail = JSON.parse(firstOrderCouponDetail);
  const appliedCoupons = JSON.parse(localStorage.getItem('appliedCoupons')) || {};
  const localCoupons = useSelector((state) => state.localCoupon);
  useEffect(() => {
    // setCartOpen(true);
    const debouncedGetCartAmountList = debounce(async () => {
      try {
        const response = await cartAmountList(token);
        // console.log("amntListResponsetotal_amt:", response.total_amt);
        // if (response?.total_amt < 0) {
        //   // console.log("amntListResponsetotal_amt:", response.total_amt);
        //   // alert("Something went wrong");
        //   // window.location.reload();
        // }
        if (response.order_discount < 1) {
          dispatch(storeLocalCoupon());
        }

        localStorage?.setItem("couponApplied", response?.orderdiscount_coupon_code)
        setIsFirstOrderCouponApplied(response.status !== "1");
        if (response.status !== "1") return;

        const { first_order_discount, reward_discount } = response;
        setIsFirstOrderCouponApplied(first_order_discount > 0);
        setCartPriceList(response);
        let adjustedDiscount = reward_discount;
        setRewardPointsChecked(adjustedDiscount > 0);
        setPoints(adjustedDiscount);
      } catch (error) {
        // Handle error (optional: log or show error message)
      }
    }, 500); // Debounce with a delay of 500ms
    if (token && openDrawer) {
      debouncedGetCartAmountList();
    }

    return () => {
      debouncedGetCartAmountList.cancel(); // Clean up the debounced function
    };

  }, [token, cart, couponDis, openDrawer, firstOrderCoupon, localCoupons]); // Ensure dependencies are correct

  // Keep dependencies if necessary
  const handleRewardPointsChange = async () => {
    if (!cart.some(item => item.isChecked)) return;
    const response = await applyRewardPoint(token);
    if (response.status !== '1') {
      setRewardPointsChecked(false);
      setPoints(response.discount);
      // return;
    }
    const amntListResponse = await cartAmountList(token);

    if (amntListResponse.status !== '1') return;
    // console.log("amntListResponsetotal_amt:", amntListResponse.total_amt);
    setCartPriceList(amntListResponse);
    const { reward_discount } = amntListResponse;
    setRewardPointsChecked(reward_discount > 0);
    setPoints(reward_discount);
  };

  // Function to handle reward points fetching
  const fetchRewardPoints = async () => {
    try {
      const response = await getRewardsPoints(user.token);
      if (response?.status === '1') {
        setRewardPoints(response?.data);
      }
    } catch (error) {
      if (error.message === "Invalid token") {
        localStorage.removeItem('user'); // Remove only the 'user' key from local storage
        dispatch(clearUser());
        navigate(Routes.SignIn, { state: { from: Routes.Home } }); // Redirect to login page with state
      } else {
        console.error('Error fetching reward points:', error);
      }
    }
  };
  // Function to handle the application of the first order coupon
  const applyFirstOrderCoupon = async (couponCode) => {
    // console.log("vivek see:", couponCode);
    if (!user.token) {
      return;
    }
    try {
      const formData = new URLSearchParams();
      formData.append('coupon_code', couponCode);
      await getApplyCouponData(formData, user.token);
    } catch (error) {
      // console.error('Error applying first order coupon:', error);
    }
  };
  //========================================>
  // Fetch coupon for first order
  const applyCouponData = async (couponcode) => {

    const coupon_code = localCoupons?.map(coupon => coupon.coupon_code).join(',') || [];
    const newcode = coupon_code.length > 0 ? coupon_code : couponcode
    try {

      const formData = new URLSearchParams();
      formData.append('coupon_code', newcode);
      const response = await getApplyCouponData(formData, user?.token);

      dispatch(storeLocalCoupon(response?.data));
      // console.log("responseresponseresponseresponse",response);

    } catch (error) {
      // toast.error("Please try again later.");
      // console.error('Error applying coupon:', error.response);
    }
  }
  // .\++++++++++++++++++++++++++++++++./ 

  useEffect(() => {
    const debouncedEffect = debounce(() => {
      if (user.token && openDrawer) {
        // fetchRewardPoints();       //  Comment - F O R - N O W
      }
      const { data, order_count } = JSON.parse(localStorage.getItem('FirstOrderCouponDetails')) || {};
      const { id, coupon_code, type_val, apply_to, coupon_type } = data || {};
      const appliedFirstOrderCoupon = { id, coupon_code, type_val, apply_to, coupon_type, isApplied: true };
      const appliedCoupons = JSON.parse(localStorage.getItem('appliedCoupons'));
      if (!token) {
        setIsFirstOrderCouponApplied(appliedCoupons?.isApplied)
      }
      const isCouponExists = appliedCoupons && appliedCoupons.id === id;
      if (!isCouponExists) {
        if (localCoupons.length < 2) {
          if (!token) {
            const updateLocalCoupon = [...localCoupons, appliedFirstOrderCoupon];
            dispatch(storeLocalCoupon(updateLocalCoupon));
          }

          localStorage.setItem('appliedCoupons', JSON.stringify(appliedFirstOrderCoupon));

        }
      }
      if (user.token && openDrawer && cart.length > 0 && order_count === 0) {
        // console.log("vivek see");
        // applyFirstOrderCoupon(data?.coupon_code);
        const coupon_code = localCoupons?.map(coupon => coupon.coupon_code).join(',') || [];
        coupon_code.length < 1 && applyCouponData(data?.coupon_code)
      }
    }, 50);

    debouncedEffect();

    // Cleanup function to clear timeout if the component unmounts or dependencies change
    return () => {
      clearTimeout(debouncedEffect);
    };
  }, [openDrawer, localCoupons]);
  //
  const handleCouponClick = async () => {
    if (cart.length === 0) {
      onClose();
      navigate(Routes.Home);
      toast.error(STRINGS.NO_PRODUCT_IN_CART_CONTINUE_SHOPPING);
      return;
    }
    setOpenCupponDrawer(true);
    // if (user?.id) {
    //   setOpenCupponDrawer(true);
    // } else {
    //   onClose();
    //   navigate(Routes.SignIn, { state: { from: Routes.Checkout } });
    // }
  };
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    const hasCheckedItem = cart.some(cartItem => cartItem.isChecked);

    if (hasCheckedItem) {
      setIsModalOpen(true);
    } else {
      Modal.info({
        title: 'Kairaus says',
        content: 'No cart item checked. Please check the cart products you want to delete.',
      });
    }
  };


  const handleOk = async () => {
    const filteredCart = cart.filter(cartItem => cartItem.isChecked);
    if (!user.id) {
      const updatedCart = cart.filter((item) => !item.isChecked);
      localStorage.setItem('cart', JSON.stringify(updatedCart));
      dispatch(addToCart(updatedCart));
      toast.success(STRINGS.REMOVED_SUCCESSFULLY);
      if (updatedCart.length < 1) {
        const couponnull = {};
        localStorage.removeItem('appliedCoupons');
        localStorage.removeItem('localCoupons');
        dispatch(applyCoupon(couponnull));
      }
    }
    if (filteredCart.length > 0) {
      try {
        const deleteOperations = filteredCart.map(async (product) => {
          sessionStorage.removeItem(`coupon_${product.id}`);
          const formData = new URLSearchParams();
          formData.append('id', product.id);

          const responseDel = await deleteCart(formData);
          const deleteCartStatus = responseDel.data.status;
          if (deleteCartStatus === "1") {
            return product.id; // Return the ID of the successfully deleted product
          } else {
            return product.id;
          }
        });

        const deletedProductIds = await Promise.all(deleteOperations);

        // Update local storage and state after all delete operations are completed
        const updatedCart = cart.filter((item) => !deletedProductIds.includes(item.id));

        if (updatedCart.length > 0) {
          localStorage.setItem('cart', JSON.stringify(updatedCart));
          dispatch(addToCart(updatedCart));
        } else {
          const couponnull = {};
          dispatch(applyCoupon(couponnull));
          localStorage.setItem('coupon', JSON.stringify(couponnull));
          localStorage.removeItem("cart");
          localStorage.removeItem("shippingFees")
          localStorage.removeItem('appliedCoupons');
          localStorage.removeItem('localCoupons');
          dispatch(storeLocalCoupon([]));
          dispatch(applyCoupon(couponnull));
          dispatch(clearCart());
        }
        toast.success(STRINGS.REMOVED_SUCCESSFULLY);
      } catch (error) {
        console.error("Deleting Error:", error);
      }
    }
    setIsModalOpen(false);
  };
  const handleCancel = async () => {
    setIsModalOpen(false);
  };

  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: trashLottie,
    rendererSettings: {
      preserveAspectRatio: 'xMidYMid slice'
    }
  };
  const [selectAllChecked, setSelectAllChecked] = useState(cart?.some(item => item.isChecked));
  const [allProductIds, setAllProductIds] = useState([]);

  useEffect(() => {
    const productIds = cart?.map((product) => product.id);
    setAllProductIds(productIds);
  }, [cart]);
  //handle single id
  const handleUpdateCartStatus = async (pId, isChecked) => {
    try {
      const products = [{
        product_id: pId,
        status: isChecked ? "0" : "1",
      }];

      await updateCartStatus(products, user.token);
    } catch (error) {
      console.error('Failed to update cart status:', error);
    }
  };
  //handle multipal ids
  const handleSelectUpdateCartStatus = async (pIds, isChecked) => {
    try {
      const products = pIds.map(pId => ({
        product_id: pId,
        status: isChecked ? "0" : "1",
      }))
      await updateCartStatus(products, user.token);
    } catch (error) {
      console.error('Failed to update cart status:', error);
    }
  };
  const closeDrawerCart = (e) => {
    const className = e?.target?.className;
    setOpenCupponDrawer(false)
    if (className === undefined) {
      onClose();
    }
  };
  const isINR = excRate?.currencyCode === "INR";
  const currencySymbol = excRate?.currencySymbol || excRate?.currencyCode || '$';
  const { id } = JSON.parse(localStorage.getItem('FirstOrderCouponDetails'))?.data || {};
  const handleFirstOrderRemove = async () => {
    // Navigate if no token is available
    if (!token) {
      setIsFirstOrderCouponApplied(false);

      // Check if appliedCoupons exist in storage before proceeding
      if (appliedCoupons) {
        const appliedFirstOrderCoupon = {
          ...appliedCoupons, // Spread the existing coupon details
          isApplied: false // Update the isApplied field to false
        };

        // Update local storage with the modified coupon object
        localStorage.setItem('appliedCoupons', JSON.stringify(appliedFirstOrderCoupon));
        //
        if (localCoupons.length > 0) {
          const updatedCoupons = localCoupons.filter(coupon => coupon.id !== appliedCoupons.id);
          dispatch(storeLocalCoupon(updatedCoupons));
        }

        localStorage.setItem('appliedCoupons', JSON.stringify(appliedFirstOrderCoupon));


      }

      return;
    }


    !token && navigate(Routes.SignIn, { state: { from: Routes.Home } });
    const formData = new URLSearchParams({ coupon_id: id });


    // try {
    //   await removeCoupon(formData, user.token);
    //   const updatedCoupons = localCoupons.filter(coupon => coupon.id !== id );
    //       dispatch(storeLocalCoupon(updatedCoupons));
    //       const appliedFirstOrderCoupon = {
    //         ...appliedCoupons, // Spread the existing coupon details
    //         isApplied: false // Update the isApplied field to false
    //       };
    //       // Update local storage with the modified coupon object
    //     localStorage.setItem('appliedCoupons', JSON.stringify(appliedFirstOrderCoupon));
    //   // const { status, data } = await toggleFirstCoupon(formData, user.token);
    //   // if (status === "1") {
    //   //   dispatch(setFirstOrderCoupon(data.applied_status === 0));
    //   //   setIsFirstOrderCouponApplied(false)
    //   // }
    // } catch (error) {
    //   console.error('Error toggling first coupon:', error);
    // }
  };
  //

  const handleSelectAll = (flag) => {
    // Update the 'isCheck' field for all cart items based on the flag
    const updatedCart = cart.map(item => ({
      ...item,
      isChecked: !flag // Invert the flag to update 'isCheck'
    }));
    dispatch(addToCart(updatedCart));
    if (token) {
      // Update the cart status based on the flag
      handleSelectUpdateCartStatus(allProductIds, flag);
    }

    // Toggle the select all checked state
    setSelectAllChecked((prev) => !prev);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const handleCardClick = (p_id) => {
    let isChecked = false;

    // Toggle isChecked for the selected product and update the cart
    const updatedCart = cart.map(item => {
      if (item.id === p_id) {
        isChecked = !item.isChecked;  // Capture the toggled value
        return { ...item, isChecked };
      }
      return item;
    });
    if (token) {
      // Update cart status based on the toggled isChecked value
      handleUpdateCartStatus(p_id, !isChecked);
    }

    if (token) {
      // Update cart status based on the toggled isChecked value
      handleUpdateCartStatus(p_id, !isChecked);
    }

    // Update the select all checkbox
    setSelectAllChecked(updatedCart.some(item => item.isChecked));

    // Save the updated cart in localStorage and dispatch it to the Redux store
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    dispatch(addToCart(updatedCart));
  };

  // let newApplied_price;

  // let l = totalComparePrice - bagDiscount
  // let s = l - firstOrderCouponDiscount
  // let appliedTenPerc = (s.toFixed(0)) * 10 / 100;


  // newApplied_price = s.toFixed(0) - appliedTenPerc.toFixed(0)

  useEffect(() => {
    if (cart?.length < 1) {
      onClose();
    }
  }, [cart])

  // console.log('cartPriceList?.total_amt===>>',cartPriceList?.total_amt);
  // console.log('newGrandTotal===>>',newGrandTotal);
  const pageLocation = window.location.href;

  const screenSize = useSelector((state) => state.uiSlice.screenSize)

  // console.log("screenSize", screenSize)

  return (
    <>
      <Drawer
        title={`Your Cart (${totalProductCount})`}
        placement='right'
        onClose={onClose}
        open={!pageLocation?.includes('mainCheckout') && openDrawer}
        width={600}
        className="addToCart_drawer"
      >
        {cart?.length === 0 ? (
          <div className='noDataCont' onClick={onClose}>
            <img src={NoCartimg} alt='' />
            <h5> No Product In cart.</h5>
            <Link to={Routes.Home}>Continue Shopping</Link>
          </div>
        ) : (
          <div className='drawer_cupns_space'>
            <div className='drwawer_margins'>
              {user?.id &&
                rewardPoints?.total_points >= 100 && (
                  <div className='coupan_area'>
                    <div className='copan_left'>
                      <Radio checked={rewardPointsChecked} onClick={handleRewardPointsChange} />
                      <p>{rewardPoints?.total_points} Reward Points</p>
                    </div>
                    <div className='copan_right'>
                      <button onClick={handleRewardPointsChange}> {points > 0 ? 'Remove' : 'Apply'}</button>
                    </div>
                  </div>
                )
              }
              {isFirstOrderCouponApplied && (
                <div className='sticky_div'>
                  <div className='img_fixed'>
                    <img src={couponsImg} alt="couponsImg" className='couponsImg' />
                    <div className='coupon_number'>
                      {firstOrderCouponDetail?.data?.type_val}
                      {firstOrderCouponDetail?.data?.coupon_type === 'percent' ? '%' : firstOrderCouponDetail?.data?.coupon_type} <br />Off
                    </div>
                    <div className='coupons_details'>
                      <h4>FIRSTBUY</h4>
                      <span>Get a special discount with our First Buy Coupon! Shop now and save on your first purchase!</span>
                    </div>
                    {/* <Tooltip title="Delete Coupon" placement="bottom" onClick={handleFirstOrderRemove}>
                      <div className='close_iocn'>
                        <CloseOutlined />
                      </div>
                    </Tooltip> */}
                  </div>
                </div>
              )}
              <div className='select_allProduct'>
                <div className='selected_container'>
                  <Checkbox checked={selectAllChecked} onChange={() => handleSelectAll(selectAllChecked)} />
                  <span>{`${cart.filter(item => item.isChecked).length} / ${cart.length} Items Selected`}</span>
                </div>
                <div className='icons_selected'>
                  {/* <Tooltip title="Move To Favourite">
                    <HeartOutlined onClick={handleWishlist} />
                  </Tooltip> */}
                  <Tooltip title={screenSize < 400 ? "" : "Delete Item" }>
                    <img src={DeleteImg} onClick={showModal} alt='' />
                  </Tooltip>
                </div>
              </div>
              {cart?.map((product, index) => (
                <DrawerCartProduct
                  key={index}
                  product={product}
                  onClose={onClose}
                  handleCardClick={handleCardClick}
                  checked={selectAllChecked}
                  setSelectAllChecked={setSelectAllChecked}
                  onChange={handleSelectAll}
                />
              ))}
              <div className='coupan' onClick={handleCouponClick}>
                <div className='left_Coupon'>
                  <img src={frame} alt='img' />
                </div>
                <div className='right_Coupon'>
                  <p>Check Out More Vouchers</p>
                </div>

                <div className='icon_nex_cupn'>
                  <FaGreaterThan />
                </div>
              </div>

              {cartPriceList && <DrawerCartPriceList cartPriceList={cartPriceList} handleCouponClick={handleCouponClick} firstOrderCouponDetail={firstOrderCouponDetail} points={points} />}
              {!token && <DrawerLocalCartPriceList handleCouponClick={handleCouponClick} from={'drawer'} />}
              {/* <div className='reward_point_drawer'>
                <div className='reward_text_p'>
                  <p>Redeem points on your next order!</p>
                  <p className='bold_p_reward'>Earn {cartPriceList?.total_amt || Math.round(newGrandTotal)} Reward Points</p>
                </div>
              </div> */}
            </div>
            <ProceedSection grandTotal={cartPriceList?.total_amt || (grandTotal > 1499 ? grandTotal : grandTotal - 99)} onClose={onClose} isINR={isINR} currencySymbol={currencySymbol} />
          </div>
        )}
      </Drawer>
      {openCupponDrawer && <DrawerCuppon drawerClose={closeDrawerCart} openCupponDrawer={openCupponDrawer} grandTotal={cartPriceList?.total_amt || (grandTotal > 1499 ? grandTotal : grandTotal - 99)} disAmount={cartPriceList?.order_discount} first_order_discount={cartPriceList?.first_order_discount} handleFirstOrderRemove={handleFirstOrderRemove} />}
      <Modal
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
        className='deletePopUp_model'
        footer={
          <div className='custom-modal-footer'>
            <Button key="cancel" onClick={handleCancel} className='cancel_Button'>
              Cancel
            </Button>
            <Button key="delete" onClick={handleOk} className='deleteButton'>
              Delete
            </Button>
          </div>
        }
      >
        <div className='delete_popUpDesign'>
          <p>Are you sure want to delete the {cart?.length > 1 ? "products" : "product"}?</p>
          <Lottie options={defaultOptions}
            max-height={200}
            width={250}
          />
        </div>
      </Modal>
    </>
  );
};

export default React.memo(DrawerCart);
