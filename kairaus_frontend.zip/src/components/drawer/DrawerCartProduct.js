import React, { useEffect, useState } from 'react';
import { FaPlus, FaMinus } from 'react-icons/fa6';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../../reducers/cartSlice';
import "../../assets/css/style/checkout.scss"
import { useNavigate } from 'react-router-dom';
import Routes from '../../Routes/Routes';
import { Checkbox, Modal, Tooltip } from 'antd';
import { CloseOutlined } from '@ant-design/icons';
import { deleteCart, updateCartCount } from '../../services/cart/addCart';
import { toast } from 'react-toastify';
import { STRINGS } from '../../constants/Constant';
import { applyCoupon } from '../../reducers/couponSlice';
import { HeartOutlined } from '@ant-design/icons';
import { addWishlist } from '../../services/wishlist/addWishlist';
import { addToFavId } from '../../reducers/favIdSlice';
import ProductPrice from '../ProductPrice';
import { storeLocalCoupon } from '../../reducers/localCouponSlice';

const DrawerCartProduct = ({ product, onClose, handleCardClick, checked, onChange, setSelectAllChecked }) => {
  // console.log('productproductproductproduct', product);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  // Move the logic here
  const cart = useSelector((state) => state.cart);
  const user = useSelector((state) => state.user);
  const cartIds = useSelector((state) => state.cartId);
  const { token } = useSelector(state => state.user);
  const excRate = useSelector(state => state.excrate);
  // const [isChecked, setIsChecked] = useState(checked);
  const favId = useSelector((state) => state.favId) || [];
  const newUpdatedPrice = product?.newPrice ? product?.newPrice : excRate?.currencyCode === "INR" ? product?.price : product?.usd_price * excRate?.rate;


  const updateCart = (updatedCart) => {
    localStorage.setItem('cart', JSON.stringify(updatedCart));
    // Assuming you have a dispatch function available
    dispatch(addToCart(updatedCart));
    if (updatedCart.length === 0 && updatedCart[0]?.id === undefined) {
      // Assuming applyCoupon dispatches an action that sets the coupon state
      dispatch(applyCoupon({}));
      localStorage.setItem('coupon', JSON.stringify({}));
    }
  };

  const handleIncrement = async (id) => {
    if (!token) {
      // / Update the cart locally
      const updatedCart = cart.map(item =>
        item.id === id ? { ...item, count: item.count + 1 } : item
      );

      // Update state with the new cart
      updateCart(updatedCart);
      return
    }
    // Find the item to be incremented
    const itemToUpdate = cart.find(item => item.id === id);

    // Exit if item not found or not checked
    if (!itemToUpdate) return; // Exit if item not found
    if (!itemToUpdate.isChecked) {
      return Modal.info({
        title: 'Kairaus Say',
        content: (
          <div>
            <p>Please Select Product</p>
          </div>
        ),
      });
    }
    // Check stock availability
    if (itemToUpdate.stock_quantity <= itemToUpdate.count) {
      toast.error('Oops, the count has exceeded the available stock', { toastId: "1" });
      return; // Exit early if stock is exceeded
    }

    // Prepare form data for the API request
    const formData = new URLSearchParams();
    formData.append('product_id', id);
    formData.append('quantity', itemToUpdate.count + 1);

    try {
      // Update the cart count via API
      await updateCartCount(formData, token);

      // Update the cart locally
      const updatedCart = cart.map(item =>
        item.id === id ? { ...item, count: item.count + 1 } : item
      );

      // Update state with the new cart
      updateCart(updatedCart);
    } catch (error) {
      console.error("Cart Updating error :", error);
    }
  };


  const handleDecrement = async (id) => {
    // Find the item to be decremented
    const itemToUpdate = cart.find(item => item.id === id);
    if (itemToUpdate.count <= 1) return; // Prevent decrementing below 1
    if (!token) {
      // / Update the cart locally
      const updatedCart = cart.map(item =>
        item.id === id ? { ...item, count: item.count - 1 } : item
      );


      // Update state with the new cart
      updateCart(updatedCart);
      return
    }


    // Exit early if the item is not found, not checked, or if count is 1
    if (!itemToUpdate) return;
    if (!itemToUpdate.isChecked) {
      return Modal.info({
        title: 'Kairaus Say',
        content: (
          <div>
            <p>Please Select Product</p>
          </div>
        ),
      });
    }


    try {
      // Prepare form data for the API request
      const formData = new URLSearchParams();
      formData.append('product_id', id);
      formData.append('quantity', itemToUpdate.count - 1); // Decrease the quantity by 1

      // Update the cart count via API
      await updateCartCount(formData, token);

      // Update the cart locally
      const updatedCart = cart.map(item =>
        item.id === id ? { ...item, count: item.count - 1 } : item
      );

      // Update state with the new cart
      updateCart(updatedCart);
    } catch (error) {
      // console.error("Cart Updating error:", error);
      toast.error('Failed to update cart. Please try again.'); // User feedback for errors
    }
  };



  const handleWishlist = async (product_name, p_id) => {
    // console.log('click');
    if (!token) return navigate(Routes.SignIn);
    const existingItemIndex = favId.findIndex(item => item === p_id);
    // console.log(existingItemIndex);
    const updatedCart = cart.filter(item => item.product_name !== product_name);

    if (existingItemIndex !== -1) {
      // If pId exists in favId, remove it from cart and call deleteItemFromCart if token exists
      const confirmed = window.confirm("This item is already added to your favorites. Are you sure you want to remove it from the cart?");
      if (confirmed) {
        updateCart(updatedCart);
        if (token) {
          deleteItemFromCart(p_id);
        } else {
          toast.success("Already added in favourite");
        }
      }
    } else {
      // If pId doesn't exist in favId, add it to wishlist
      const formData = new URLSearchParams();
      formData.append('product_id', p_id);
      await addWishlist(formData, user?.token);

      const updatedFavId = [...favId, p_id]; // Add p_id to favId
      updateCart(updatedCart);

      if (token) {
        const formData = new URLSearchParams();
        formData.append('id', p_id)
        let deletedResult = await deleteCart(formData);

        if (deletedResult?.data?.status === '1') {
          toast.success('Added in favourite');
        }
      } else {
        toast.success("Already added in favourite");
      }

      dispatch(addToFavId(updatedFavId)); // Dispatch action to update favId state in Redux

      localStorage.setItem('favId', JSON.stringify(updatedFavId)); // Update local storage
    }
  };


  const handleRemove = (product_name, p_id) => {
    sessionStorage.removeItem(`coupon_${p_id}`);
    const updatedCart = cart?.filter((item) => item.product_name !== product_name);
    const productCouponId = JSON.parse(localStorage.getItem('productCoupon')) || [];
    const updatedProductCouponId = productCouponId?.filter((item) => item.productId !== p_id);
    localStorage.setItem('productCoupon', JSON.stringify(updatedProductCouponId));

    updateCart(updatedCart);
    if (token) {
      deleteItemFromCart(p_id);
    }
    else {
      toast.success(STRINGS.REMOVED_SUCCESSFULLY);
    }
    if (updatedCart < 1) {
      localStorage.removeItem('appliedCoupons');
      localStorage.removeItem('localCoupons');
      dispatch(storeLocalCoupon([]));
    }
  };

  // For deleting product from the cart & from DB.
  const deleteItemFromCart = async (productId) => {
    const formData = new URLSearchParams();
    formData.append('id', productId)
    let deletedResult = await deleteCart(formData);

    if (deletedResult?.data?.status === '1') {
      toast.success(STRINGS.REMOVED_SUCCESSFULLY);
    }
    else {
      toast.error(STRINGS.NOT_REMOVED_SUCCESSFULLY);
    }
  }

  const handleMoveToDetail = (ProductData) => {
    navigate(`${Routes?.ProductDetail}/${ProductData?.product_slug}`, { state: { ProductId: ProductData?.id } });
    onClose();
  }
  const [isChecked, setIsChecked] = useState(null);
  useEffect(() => {
    setIsChecked(checked)
  }, [checked])
  useEffect(() => {
    if (cartIds.length === cart.length) {
      setIsChecked(true);
    }
  }, [])
  const screenSize = useSelector((state) => state.uiSlice.screenSize)

  return (
    <div className={`checkout_bag ${product?.isChecked ? 'checked_card' : ''}`}>
      <div className='cart-products'>
        <Checkbox checked={product?.isChecked} onChange={(e) => setIsChecked(e.target.checked)} onClick={() => { handleCardClick(product.id) }} />
        <div className='left_cart' onClick={() => { handleMoveToDetail(product) }}>
          {product.image ? (
            <img src={product.image} alt={product.product_name} />
          ) : (
            'Image Not Found'
          )}
        </div>
        <div className='right_cart'>
          <div className='price_delete'>
            <h2 onClick={() => { handleMoveToDetail(product) }}>{product.product_name}</h2>
            <div className='crossed_heartIcon'>
              <Tooltip title="Move To Favourite" placement="top">
                <HeartOutlined onClick={(e) => { handleWishlist(product.product_name, product.id) }} />
              </Tooltip>
              <Tooltip title={screenSize < 400 ? "" : "Delete Item"} placement="bottom">
                <CloseOutlined onClick={(e) => { handleRemove(product.product_name, product.id) }} alt={product.product_name} />
              </Tooltip>
            </div>
          </div>
          {/* <span>Set of 1</span> */}
          <div className='add_product_price'>
            <div className="button-box">
              <button className='btn-incriment'>
                <span onClick={() => handleDecrement(product.id)}><FaMinus /></span>
                {product.count}
                <span onClick={() => handleIncrement(product.id)}><FaPlus /></span>
              </button>
            </div>


            <div className='cartProduct_price'>
              <h6>({`${product.count} * ${newUpdatedPrice}`})</h6>
              <ProductPrice product={product} />
            </div>
            {/* <img src={DeleteIcn} onClick={() => handleRemove(product.product_name)} alt={product.product_name} /> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DrawerCartProduct;
