import { Drawer, Tooltip } from 'antd';
import React, { useEffect, useState } from 'react';
import { IoCheckmarkCircle } from 'react-icons/io5';
import { useDispatch, useSelector } from 'react-redux';
import ProceedSection from './ProceedSection';
import { applyCoupon } from '../../reducers/couponSlice';
import { getApplyCouponData, removeCoupon, toggleFirstCoupon } from '../../services/coupon/applyCoupon';
import { toast } from 'react-toastify';
import { STRINGS } from '../../constants/Constant';
import { setFirstOrderCoupon } from '../../reducers/firstOrderCouponSlice';
import { getCouponList } from '../../services/coupon/Coupon';
import { clearUser } from '../../reducers/userSlice';
import { useNavigate } from 'react-router-dom';
import Routes from '../../Routes/Routes';
import couponsImg from '../../assets/images/couponsImg.webp';
import { Modal } from 'antd';
import { storeLocalCoupon } from '../../reducers/localCouponSlice';
import { CloseOutlined } from '@ant-design/icons';
const DrawerCuppon = (props) => {
  // console.log('props',props);
  const dispatch = useDispatch();
  const [coupons, setCoupons] = useState([]);
  const [couponCode, setCouponCode] = useState('');
  const [isProductCouponApplied, setIsProductCouponApplied] = useState(false);
  const { drawerClose, openCupponDrawer, grandTotal, disAmount, first_order_discount, handleFirstOrderRemove } = props;
  const cart = useSelector((state) => state.cart);
  const user = useSelector((state) => state.user);
  const [initialCoupons, setInitialCoupons] = useState(null);
  const navigate = useNavigate();
  const { token } = user;
  const [isFirstOrderCouponApplied, setIsFirstOrderCouponApplied] = useState(!token);
  const appliedCoupons = JSON.parse(localStorage.getItem('appliedCoupons'));
  const [isFirstCoupon, setIsFirstCoupon] = useState(first_order_discount > 0);
  const localCoupons = useSelector((state) => state.localCoupon);
  const cegCouponCode = 'CEG20';

  useEffect(() => {
    const fetchCoupons = async () => {
      const formData = new URLSearchParams();
      formData.append('user_id', user.id ? user.id : '0');
      // const userid = user?(user.id):0;
      try {
        const response = await getCouponList(formData);

        const responseData = response?.data || [];

        const transformedCoupons = responseData?.map(coupon => ({
          id: coupon.id,
          coupon_code: coupon.coupon_code,
          coupon_type: coupon.coupon_type,
          type_val: coupon.type_val,
          coupon_desc: coupon.coupon_desc,
          coupon_allow: coupon.coupon_allow,
          applied: coupon.is_applied === 1,  // simplified check
          removed: false,
          showRemoveConfirmation: false,
          from_date: coupon.from_date,
          to_date: coupon.to_date,
          min_amount: coupon.min_amount,
          upto_amount: coupon.upto_amount
        }));
        if (user.token) {
          setIsFirstOrderCouponApplied(response?.firstOrder?.is_applied == 1);

          const transformedLocalCoupons = responseData.filter(coupon => coupon.is_applied == 1);
         
            const ceg20=localCoupons?.some(item=>item?.coupon_code=='CEG20');

          // const firstcoupon={id: 9, coupon_code: "WELCOME5", type_val: 5, apply_to: "FIRST_ORDER", coupon_type: "percent"}
          let checkFirstCouponInRedux = localCoupons?.find(localItem => localItem?.id == 9);
          // console.log('====checkFirstCouponInRedux', checkFirstCouponInRedux)

          if (checkFirstCouponInRedux?.id) {
            transformedLocalCoupons?.push(checkFirstCouponInRedux);

            dispatch(storeLocalCoupon(transformedLocalCoupons));
          }
          else {

            dispatch(storeLocalCoupon(transformedLocalCoupons));
          }
          if(ceg20){
            const ceg201=transformedLocalCoupons?.some(item=>item?.coupon_code=='CEG20');
            if(!ceg201){
              const staticasdas={id: 15, coupon_code: "CEG20",type_val:20,coupon_type:"percent",from_date: "2024-10-25", to_date: "2025-11-25"}
              let cegCoupon = [...transformedLocalCoupons,staticasdas]
              dispatch(storeLocalCoupon(cegCoupon));
            }
          }
        }
        // console.log('transformedCoupons===',transformedCoupons)
        setInitialCoupons(transformedCoupons);

        // Store all coupon codes in session storage
        const couponCodes = responseData.map(coupon => coupon.coupon_code);
        sessionStorage.setItem('couponCodes', JSON.stringify(couponCodes));
      } catch (error) {
        if (error.message === "Invalid token") {
          // Handle invalid token scenario
          localStorage.removeItem('user'); // Remove only the 'user' key from local storage
          dispatch(clearUser());
          navigate(Routes.SignIn, { state: { from: Routes.Home } }); // Redirect to login page with state
        } else {
          console.error('Error adding to wishlist:', error);
          // Handle other errors gracefully
        }
      }
    };
    fetchCoupons();  // invoke the async function

  }, [user.token]);  // added dependency on user.token
  useEffect(() => {
    if (!token) {
      setIsFirstOrderCouponApplied(appliedCoupons?.isApplied)
      setIsFirstCoupon(appliedCoupons?.isApplied);
    }
  }, [appliedCoupons, token])

  const handleCouponCode = (c_code) => {
    setCouponCode(c_code)
  }
  const productCouponId = JSON.parse(localStorage.getItem('productCoupon')) || [];

  useEffect(() => {
    // Check if the coupon ID exists in the localCoupons array and update the coupons accordingly
    const updatedCoupons = initialCoupons?.map((coupon) => ({
      ...coupon,
      applied: Array.isArray(localCoupons) && localCoupons.some(localCoupon => localCoupon.id === coupon.id), // Check for matching IDs
      // applied: localCoupons?.some(localCoupon => localCoupon.id === coupon.id), // Check for matching IDs
    })) || []; // Default to an empty array if initialCoupons is undefined

    setCoupons(updatedCoupons);
    setIsProductCouponApplied(false); // Reset the applied state
  }, [initialCoupons, localCoupons]); // Include localCoupons as a dependency

  // useEffect(() => {
  //   setCoupons(initialCoupons?.map((coupon) =>
  //     productCouponId.some((productCoupon) => productCoupon.couponId === coupon.id)
  //       ? { ...coupon, applied: true }
  //       : coupon
  //   ));
  //   setIsProductCouponApplied(false)
  // }, [initialCoupons]);


  // setCoupons((prevCoupons) =>
  //   prevCoupons.map((prevCoupon) =>
  //     prevCoupon.id === coupon.id
  //       ? { ...prevCoupon, applied: true }
  //       : { ...prevCoupon, applied: false }
  //   )
  // );
  // Set the 'applied' status of all coupons to true

  const handleApplyCoupon = async (couponId, coupon) => {
    // Get the IDs from the localCoupon array
    const localCouponIds = localCoupons?.map((coupon) => coupon.id) || [];
    // localCouponIds = Array.isArray(localCouponIds) ? localCouponIds : [];
    if (localCouponIds.length > 1) {
      Modal.info({
        title: 'Kairaus Say',
        content: (
          <div>
            <p>You can only apply a maximum of two coupons at a time. Please remove an existing coupon to apply a new one.</p>
          </div>
        ),
      });
      return
    }
    if (!user.token) {
      const updateLocalCoupon = Array.isArray(localCoupons) ? [...localCoupons, coupon] : [coupon];
      dispatch(storeLocalCoupon(updateLocalCoupon));
      // / Update the coupons' applied status
      setCoupons((prevCoupons) =>
        prevCoupons.map((prevCoupon) => ({
          ...prevCoupon,
          applied: localCouponIds.includes(prevCoupon.id) || prevCoupon.id === couponId,
        }))
      );

      return;
    }

    // Validate the grand total against the coupon's minimum and maximum amounts
    // if (grandTotal < coupon.min_amount) {
    //   toast.error(`Minimum order amount to apply this coupon is ₹${coupon.min_amount}`, { toastId: "1" });
    //   return;
    // }

    // if (coupon.upto_amount && grandTotal > coupon.upto_amount) {
    //   toast.error(`Maximum order amount to apply this coupon is ₹${coupon.upto_amount}`, { toastId: "1" });
    //   return;
    // }

    try {
      // Prepare the form data
      const coupon_code = localCoupons?.map(coupon => coupon.coupon_code);
      const updated_coupon_code = [...coupon_code, coupon.coupon_code].join(','); // join array elements with a comma and space

      const formData = new URLSearchParams();
      formData.append('coupon_code', updated_coupon_code);

      // Fetch the coupon application result
      const response = await getApplyCouponData(formData, user.token);

      if (response?.status === '1') {
        dispatch(storeLocalCoupon(response?.data));
        
        // const { coupon_type, type_val, id, coupon_code } = response.data;
        // const couponDis = { coupon_type, type_val, id, coupon_code };

        // Update the store and local storage
        // dispatch(applyCoupon(couponDis));
        // localStorage.setItem('coupon', JSON.stringify(couponDis));

        // Update the coupon list, marking the applied coupon
        setCoupons((prevCoupons) =>
          prevCoupons.map((prevCoupon) =>
            prevCoupon.id === couponId
              ? { ...prevCoupon, applied: true }
              : prevCoupon
          )
        );
        // // Update the coupon list, marking the applied coupon
        // setCoupons((prevCoupons) =>
        //   prevCoupons.map((prevCoupon) =>
        //     prevCoupon.id === couponId
        //       ? { ...prevCoupon, applied: true }
        //       : { ...prevCoupon, applied: false }
        //   )
        // );
        // Mark that a product coupon has been applied
        setIsProductCouponApplied(true);
      } else if (response?.status === '0') {
        Modal.info({
          title: 'Kairaus Say',
          content: (
            <div>
              <p>{response.message}</p>
            </div>
          ),
        });
        // toast.error(response.message);
      }
    } catch (error) {
      if (error?.response?.data?.status === '0') {
        toast.error("Please try again later.");
        console.error('Error applying coupon:', error.response);
      }
    }
  };


  const handleRemoveCoupon = async (couponId) => {
    const updatedCoupons = localCoupons.filter(coupon => coupon.id !== couponId);

    // localStorage.setItem('localCoupons', JSON.stringify(updatedCoupons));
    try {
      setCoupons((prevCoupons) =>
        prevCoupons.map((coupon) =>
          coupon.id === couponId
            ? { ...coupon, applied: false, removed: true, showRemoveConfirmation: false }
            : coupon
        )
      );
      if (!user.token) {
        dispatch(storeLocalCoupon(updatedCoupons));
        return;
      }
      // dispatch(applyCoupon(couponnull));
      // localStorage.setItem('coupon', JSON.stringify(couponnull));
      // localStorage?.removeItem("couponApplied")
      // localStorage.setItem('localCoupon', JSON.stringify(couponnull));

      // Rmove coupon To DB
      const formData = new URLSearchParams();
      formData.append('coupon_id', couponId);
      const response = await removeCoupon(formData, user.token);
      if (response.status === "1") {
        setIsFirstOrderCouponApplied(false);
        // setIsFirstCoupon
        // setIsFirstCoupon(false)
      }

      dispatch(storeLocalCoupon(updatedCoupons));
      // Optionally, you might want to notify the user or perform additional actions after removal
    } catch (error) {
      console.error('Failed to remove coupon:', error);
    }
  };

  const toggleRemoveConfirmation = (couponId) => {
    setCoupons((prevCoupons) =>
      prevCoupons.map((coupon) =>
        coupon.id === couponId
          ? { ...coupon, showRemoveConfirmation: !coupon.showRemoveConfirmation }
          : coupon
      )
    );
  }

  const handleCouponCodeChange = (val) => {
    setCouponCode(val);
  };

  const handleApplyButtonClick = async () => {

    // const couponCodes = JSON.parse(sessionStorage.getItem('couponCodes')) || [];
    // if (!couponCodes.includes(couponCode)) {
    //   return toast.error('Oops! It looks like you forgot to enter a valid coupon. Please try again!', { toastId: 1 });
    // }
    if(localCoupons.length>1){
      Modal.info({
        title: 'Kairaus Say',
        content: (
          <div>
            <p>You can only apply a maximum of two coupons at a time. Please remove an existing coupon to apply a new one.</p>
          </div>
        ),
      });
      setCouponCode('');
      return
    }
    //
    if (couponCode != cegCouponCode) {
      toast.error("The coupon code entered is invalid. Please check and try again.");
      return;
    }
    
    //
    if(!token){
      const staticasdas={id: 15, coupon_code: "CEG20",type_val:20,coupon_type:"percent",from_date: "2024-10-25", to_date: "2025-11-25"}
      if(localCoupons?.some(item=>item?.coupon_code=='CEG20')){
        toast.success('Coupon applied');
        setCouponCode('');
        alert('if')
      }
      else{
        let cegCoupon = [...localCoupons,staticasdas]
        dispatch(storeLocalCoupon(cegCoupon));
        toast.success('Coupon applied');
        setCouponCode('');
        
      }    
      return
    }
    try {

        // Prepare the form data
        const coupon_code = localCoupons?.map(coupon => coupon.coupon_code);
        const updated_coupon_code = [...coupon_code, couponCode].join(','); // join array elements with a comma and space
        const formData = new URLSearchParams();
        formData.append('coupon_code', updated_coupon_code);
      // const formData = new URLSearchParams();
      // formData.append('coupon_code', couponCode);
      const response = await getApplyCouponData(formData, user.token);
      if (response.status === '1') {
        dispatch(storeLocalCoupon(response?.data)); 
        setCouponCode('');      
        toast.success("Coupon applied successfully! Enjoy your discount!");
      } else {
        // Show error in toast for invalid coupon
        toast.error(STRINGS.COUPON_NOT_VALID);
      }
    } catch (error) {
      console.error('Error applying coupon:', error);
      if (couponCode === '') {
        toast.error("Please enter a coupon code")
      } else {
        toast.error(STRINGS.COUPON_NOT_VALID);
      }
    }
  };
  const { coupon_code, id } = JSON.parse(localStorage.getItem('FirstOrderCouponDetails'))?.data || {};
  const { order_count } = JSON.parse(localStorage.getItem('FirstOrderCouponDetails')) || {};

  // const [isFirstCoupon, setIsFirstCoupon] = useState(true);


  const handleFirstOrder = async () => {
    if (!token) {
      if (localCoupons.length > 1) {
        Modal.info({
          title: 'Kairaus Say',
          content: (
            <div>
              <p>You can only apply a maximum of two coupons at a time. Please remove an existing coupon to apply a new one.</p>
            </div>
          ),
        });
        return
      }
      const { id, coupon_code, type_val, apply_to, coupon_type, isApplied } = appliedCoupons;
      // Toggle the isApplied value and set the state
      const newIsApplied = !isApplied;
      setIsFirstCoupon(newIsApplied);
      // Create the updated coupon object
      const appliedFirstOrderCoupon = { id, coupon_code, type_val, apply_to, coupon_type, isApplied: newIsApplied };
      // Update local storage with the new coupon object
      localStorage.setItem('appliedCoupons', JSON.stringify(appliedFirstOrderCoupon));
      if (newIsApplied) {
        const updateLocalCoupon = Array.isArray(localCoupons) ? [...localCoupons, appliedFirstOrderCoupon] : [appliedFirstOrderCoupon];
        dispatch(storeLocalCoupon(updateLocalCoupon));
      } else {
        const updatedCoupons = localCoupons.filter(coupon => coupon.id !== appliedCoupons.id);
        dispatch(storeLocalCoupon(updatedCoupons));
      }
      return;
    }
    const { id, coupon_code, type_val, apply_to, coupon_type, isApplied } = appliedCoupons;


    if (token) {
      // console.log("newIsAppliednewIsApplied   -======>",isApplied);

      try {

        const coupon_code = localCoupons?.map(coupon => coupon.coupon_code);
        const updated_coupon_code = [...coupon_code, appliedCoupons?.coupon_code].join(','); // join array elements with a comma and space
        const formData = new URLSearchParams();
        formData.append('coupon_code', updated_coupon_code);

        // Fetch the coupon application result
        const response = await getApplyCouponData(formData, user.token);
        // const response=0;

        if (response?.status == '1') {
          setIsFirstOrderCouponApplied(true);
          setIsFirstCoupon(true)
          dispatch(storeLocalCoupon(response?.data));

          setCoupons((prevCoupons) =>
            prevCoupons.map((prevCoupon) =>
              prevCoupon.id === appliedCoupons?.id
                ? { ...prevCoupon, applied: true }
                : prevCoupon
            )
          );
          const { id, coupon_code, type_val, apply_to, coupon_type } = appliedCoupons;
          const appliedFirstOrderCoupon = { id, coupon_code, type_val, apply_to, coupon_type, isApplied: false };
          // Update local storage with the new coupon object
          localStorage.setItem('appliedCoupons', JSON.stringify(appliedFirstOrderCoupon));
          setIsProductCouponApplied(true);
        } else if (response?.status === '0') {
          Modal.info({
            title: 'Kairaus Say',
            content: (
              <div>
                <p>{response.message}</p>
              </div>
            ),
          });
          // toast.error(response.message);
        }
      } catch (error) {
        if (error?.response?.data?.status === '0') {
          toast.error("Please try again later.");
          console.error('Error applying coupon:', error.response);
        }
      }
    }
    // else {
    //   const formData = new URLSearchParams();
    //   formData.append('coupon_id', appliedCoupons?.id);
    //   const response = await removeCoupon(formData, user.token);
    //   if(response.status=="1"){
    //     setIsFirstOrderCouponApplied(false);
    //       setIsFirstCoupon(false)
    //   }

    //   const updatedCoupons = localCoupons.filter(coupon => coupon.id !== appliedCoupons.id);
    //   dispatch(storeLocalCoupon(updatedCoupons));
    //   const { id, coupon_code, type_val, apply_to, coupon_type } = appliedCoupons;
    //   const appliedFirstOrderCoupon = { id, coupon_code, type_val, apply_to, coupon_type, isApplied: true };
    //   // Update local storage with the new coupon object
    //   localStorage.setItem('appliedCoupons', JSON.stringify(appliedFirstOrderCoupon));
    //   setIsFirstCoupon(false);
    // }
  };
  useEffect(() => {
    if (order_count === 0 && first_order_discount > 0) {
      setIsFirstCoupon(true);
    }
  }, [order_count]);
  // console.log('isFirstCoupon', isFirstCoupon);

  return (
    <Drawer title={`Your Cart (${cart?.length})`} onClose={drawerClose} open={openCupponDrawer} width={600}>
      <div className="drawr_cupns_main">
         <div className="cupns_input">
          <input type="text" placeholder='Enter Coupon Code' value={couponCode} onChange={(e) => handleCouponCodeChange(e.target.value)} />
          <button disabled={couponCode?.length < 1  && true } onClick={handleApplyButtonClick}>Apply</button>
        </div>
        {
          isFirstOrderCouponApplied && (<div className='sticky_div'>
            <div className='img_fixed'>
              <img src={couponsImg} alt="couponsImg" className='couponsImg' />
              <div className='coupon_number'>
                5% <br />Off
              </div>
              <div className='coupons_details'>
                <h4>FIRSTBUY</h4>
                <span>Get a special discount with our First Buy Coupon! Shop now and save on your first purchase!</span>
              </div>
              {/* <Tooltip title="Delete Coupon" placement="bottom" onClick={() => handleRemoveCoupon(9)}>
                <div className='close_iocn'>
                  <CloseOutlined />
                </div>
              </Tooltip> */}
            </div>
          </div>)
        }

        <div className="cupns_list_all">
          <div className='cupns_list_detail'>
            <div className="coupon">
              <div className="center">
                <div className='copoons_cenetr'>
                  {/* <h2 onClick={() => handleCouponCode(coupon_code)}> {coupon.coupon_code}</h2> */}
                  <h2>{coupon_code}</h2>
                  {
                     order_count === 0 ? (<button >{isFirstCoupon ? "APPLIED" : "APPLY"}</button>) : (
                      <button>OFFER REDEEMED!</button>
                    )
                    // order_count === 0 ? (<button onClick={handleFirstOrder}>{isFirstCoupon ? "APPLIED" : "APPLY"}</button>) : (
                    //   <button>OFFER REDEEMED!</button>
                    // )
                  }
                  {/* <h2> {coupon_code}</h2><button onClick={handleFirstOrder}>{isFirstCoupon ? "Applied" : "Apply"}</button> */}
                </div>
              </div>
            </div>
          </div>
          {/* // */}
          {coupons?.map((coupon) => (
            <CouponListSubItem
              key={coupon.id}
              coupon={coupon}
              onApply={handleApplyCoupon}
              onRemove={toggleRemoveConfirmation}
              handleCouponCode={handleCouponCode}
              onClose={drawerClose}
              productCouponId={productCouponId}
            />
          ))}
        </div>
      </div>

      <ProceedSection grandTotal={grandTotal} onClose={drawerClose} />

      {isProductCouponApplied && coupons?.some((coupon) => coupon.applied) && (
        <div className="show_offer_details">
          <h2>You Saved Rs. {disAmount?.toFixed(2)}</h2>
          <p>Congratulations on your savings!</p>
          <button className='proceed_btn' onClick={drawerClose}>View Cart</button>
        </div>
      )}
      {coupons?.some((coupon) => coupon.showRemoveConfirmation) && (
        <div className="show_offer_details">
          <h2>Remove Coupon</h2>
          <p>Are you sure you don’t want to use this coupon?</p>
          <div className="cancel_btns">
            <button className='remove_btns_b' onClick={() => handleRemoveCoupon(coupons.find((coupon) => coupon.showRemoveConfirmation)?.id)}>Remove</button>
            <button className='remove_btns_b' onClick={drawerClose}>Cancel</button>
          </div>
        </div>
      )}
    </Drawer>
  );
};

const CouponListSubItem = ({ coupon, onApply, onRemove, handleCouponCode, onClose, productCouponId }) => {

  const currentDate = new Date();
  const couponExpirationDate = new Date(coupon.to_date);
  currentDate.setHours(0, 0, 0, 0); // Resetting hours, minutes, seconds, and milliseconds
  couponExpirationDate.setHours(0, 0, 0, 0); // Resetting hours, minutes, seconds, and milliseconds

  return (
    <>
      <div className='cupns_list_detail'>
        <div className='per_off_detail'>
          <p>{coupon.coupon_desc}</p>
          {coupon.applied && <span><IoCheckmarkCircle style={{ fontSize: "22px" }} />Applied </span>}
        </div>
        <div className="coupon">
          <div className="center">
            <div className='copoons_cenetr'>
              <h2 onClick={() => handleCouponCode(coupon.coupon_code)}> {coupon.coupon_code}</h2>
              {
                coupon.applied ? (
                  productCouponId.some((productCoupon) => productCoupon.couponId === coupon.id) ? (
                    ""
                  ) : (
                    <button onClick={() => onRemove(coupon.id)}>Remove</button>
                  )
                ) : (
                  couponExpirationDate.getTime() >= currentDate.getTime() ? (
                    <button onClick={() => onApply(coupon.id, coupon)}>Apply</button>
                  ) : (
                    <div className='disablepayBtn'> <button disabled>Coupon Expired</button></div>
                  )
                )
              }
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default DrawerCuppon;
