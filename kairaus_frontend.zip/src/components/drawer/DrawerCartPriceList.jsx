const DrawerCartPriceList = ({
  cartPriceList = {},  // Default to an empty object to prevent destructuring errors
  handleCouponClick,
  firstOrderCouponDetail = {},  // Default empty object to handle missing details
  points = 0,
}) => {
  const {
    currency_symbol = '',  // Provide default values to prevent undefined issues
    bag_mrp = 0,
    total_item = 0,
    kairaus_saving = 0,
    orderdiscount_coupon_code = '',
    order_discount = 0,
    first_order_discount = 0,
    total_amt = 0,
    first_order_discount_coude = '',
  } = cartPriceList;

  // Helper function to render price details, handles negative values
  const renderPriceDetail = (label, amount, isNegative = true) => (
    amount > 0 && (
      <div className='prize_dra'>
        <p>{label}</p>
        <p>{isNegative ? `- ${currency_symbol} ${amount}` : `${currency_symbol} ${amount}`}</p>
      </div>
    )
  );

  // Helper function to display coupon information
  const handleCouponDisplay = (couponCode, discount) => (
    <div className='prize_dra'>
      <div className='extra_coupons'>
        <p>Coupon Discount</p>
        {couponCode && <span>({couponCode})</span>}
      </div>
      {discount > 0 ? (
        <p>- {currency_symbol} {discount.toFixed(0)}</p>
      ) : (
        <span onClick={handleCouponClick}>Apply Coupon</span>
      )}
    </div>
  );

  return (
    <div className='prize_detail'>
      {total_item <= 0 ? (
      <p>Please select items from your cart to see the total amount!</p>
    ) : (
      <>
      <h4>Price Details</h4>

      {/* Bag MRP */}
      <div className='prize_dra'>
        <p>Bag MRP ({total_item} items)</p>
        <p>{currency_symbol} {bag_mrp.toFixed(0)}</p>
      </div>

      {/* Conditional Price Details */}
      {renderPriceDetail("Kairaus Savings", kairaus_saving)}
      {handleCouponDisplay(orderdiscount_coupon_code, order_discount)}
      {renderPriceDetail(`First Order Discount (${first_order_discount_coude})`, first_order_discount)}

      {/* First Order Coupon Detail */}
      {firstOrderCouponDetail?.order_count === 0 &&
        renderPriceDetail(
          `First Order Discount (${firstOrderCouponDetail?.data?.type_val} ${firstOrderCouponDetail?.data?.coupon_type === 'percent' ? '%' : ''})`,
          firstOrderCouponDetail?.data?.amount || 0  // Assuming amount is from firstOrderCouponDetail
        )}

      {/* Reward Points Discount */}
      {renderPriceDetail("Reward Points Discount", points)}

      {/* Total Amount */}
      <div className='prize_dra'>
        <p className='p_bold'>Total</p>
        <p className='p_bold'>{currency_symbol} {total_amt}</p>
      </div>
      </>)}
    </div>
  );
};

export default DrawerCartPriceList;
