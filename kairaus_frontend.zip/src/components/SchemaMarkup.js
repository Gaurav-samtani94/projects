
import React from 'react';

const SchemaMarkup = ({ type, data }) => (
  <script type="application/ld+json">{JSON.stringify({ '@context': 'https://schema.org/', '@type': type, ...data })}</script>
);

export default SchemaMarkup;
