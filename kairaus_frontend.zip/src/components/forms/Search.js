import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getAutoSearch } from '../../services/cart/search/autoSearch';
import Routes from '../../Routes/Routes';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../../reducers/cartSlice';
import { toast } from 'react-toastify';
import { FaPlus, FaMinus } from 'react-icons/fa6';
import NoData from '../../assets/images/noData.png'
import { STRINGS } from '../../constants/Constant';
import { addCart, updateCartCount } from '../../services/cart/addCart';
import { productApi } from '../../services/product/productApi';
import { ArrowLeftOutlined } from '@ant-design/icons';


const Search = ({ onCloseSeach, searchIconClick, openSearch }) => {
  // console.log('searchIconClick', searchIconClick);
  const [isSearchContainerVisible, setIsSearchContainerVisible] = useState('');
  const [clearSearch, setClearSearch] = useState(false);
  const [autoSearchList, setAutoSearchList] = useState(null);
  const [loading, setLoading] = useState(false);
  const [imgPath, setImgPath] = useState('');
  const [searchkeyword, setSearchkeyword] = useState('');
  const [productCount, setProductCount] = useState(1);
  const [searchList, setSearchList] = useState([]);
  const [trendingList, setTrendingList] = useState([]);

  const dispatch = useDispatch();
  const navigate = useNavigate();

  // const handleSearch = (e) => {
  //   if (e.target.value.startsWith(' ')) {
  //     e.target.value = e.target.value.trimStart();
  //   }
  //   setSearchkeyword(e.target.value);

  //   setIsSearchContainerVisible((prevVisibility) => !prevVisibility);
  // };
  const handleSearch = (e) => {
    const value = e.target.value.trimStart(); // Remove leading spaces
    if (value) {
      featchData(value);  // Call only if value is not empty
      setSearchkeyword(value);
      setIsSearchContainerVisible((prevVisibility) => !prevVisibility);
    }
  };

  //

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && searchkeyword.trim() !== '') {
      navigate(`${Routes.AllProduct}`, { state: { searchValue: isSearchContainerVisible } });
      handleCloseSearch()
    }
  };

  const navigateWithSearchedList = (searchedKeyword) => {
    navigate(`${Routes.AllProduct}`, { state: { searchValue: searchedKeyword } });
    handleCloseSearch()
  }


  const featchData = async (userSearchKeyword) => {
    try {
      setLoading(true);
      // Introduce a delay of 2 seconds
      const formData = new URLSearchParams();
      formData.append('keyword', userSearchKeyword);
      const response = await getAutoSearch(formData);
      console.log('response', response);
      if (response.status === '1') {
        setAutoSearchList(response.data);
        setImgPath(response.path);
      } else {
        setAutoSearchList(null);
      }
    } catch (error) {
      console.error('Error fetching search results:', error);
      setAutoSearchList(null);
      setImgPath('');
    } finally {
      setLoading(false);
    }

  }


  const handleSearchBoxClick = async (keyword) => {
    // dispatch(setSearchQuery(e.target.value));
    setIsSearchContainerVisible(String(keyword));
    setClearSearch(false);
  };

  const handleCloseSearch = () => {
    setClearSearch(true);
    onCloseSeach()
  };


  const onChange = (value) => {
    // console.log('changed', value);
    setProductCount(value);
  };


  const handleLinkClick = () => {
    handleCloseSearch();
  };
  let cart = useSelector((state) => state.cart);
  let user = useSelector((state) => state.user);
  const excRate = useSelector(state => state.excrate);


  const addCartItemToDB = async (product) => {
    await addCart(product, user.token);
  }
  const handleAddToCart = (item) => () => {
    const { id, product_name, price, product_slug, is_wishlist, compare_price, count, weight, unit, stock_quantity, shipping_amount_type, shipping_charge, usd_price, usd_compare_price, product_buffer_days } = item;
    const image = `${imgPath}${item?.productimage?.file_name_120_x_120}`;

    const newItem = { id, product_name, product_slug, is_wishlist, compare_price, shipping_amount_type, shipping_charge, price, usd_price, usd_compare_price, image, count: count ? count : productCount, p_variant_id: 0, weight, unit, stock_quantity, isChecked: true, product_buffer_days };

    const productForDB = {
      product_id: newItem.id,
      product_variant_id: newItem.p_variant_id,
      quantity: newItem.count,

      coupon_code: "",
      usd_amount: newItem.usd_price,
      currency_code: excRate?.currencyCode,
      currency_rate: excRate?.rate,
      currency_symbol: excRate?.currencySymbol,
    }

    const existingItemIndex = cart.findIndex((item) => item.product_name === newItem.product_name);
    if (existingItemIndex === 0) {
      toast.error(`${item.product_name} ${STRINGS.ALREADY_ADDED_IN_CART}`);
    } else {
      toast.success(`${item.product_name} ${STRINGS.ADDED_IN_CART}`);
    }


    if (existingItemIndex === -1) {
      if (Object.isExtensible(cart)) {
        cart.push(newItem);
      } else {
        // If the cart is not extensible, create a new array with the existing items and the new item
        cart = [...cart, newItem];
      }
    } else {
      // If the item is already in the cart, update the count without modifying the original object
      const updatedCart = [...cart];
      updatedCart[existingItemIndex] = {
        ...updatedCart[existingItemIndex],
        count: updatedCart[existingItemIndex].count + productCount,
      };
      cart = updatedCart;
    }

    // Update localStorage and dispatch to Redux
    localStorage.setItem('cart', JSON.stringify(cart));
    dispatch(addToCart(cart));
    if (user.token) {
      addCartItemToDB([productForDB]);
    }
  };

  const fetchSearchList = async () => {
    try {
      let result = await productApi.searchByKeywords(user.token);
      if (result?.status === '1') {
        setSearchList(result?.data);
      }
      else {
        setSearchList([]);
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  const fetchTrendingSearchList = async () => {
    try {
      let result = await productApi.getTrendingSearch();
      if (result?.status === '1') {
        setTrendingList(result?.data);
      }
      else {
        setTrendingList([]);
      }
    }
    catch (e) {
      console.error(e);
    }
  }

  const showSearchList = () => {
    return searchList?.map(item => (
      <div className='search_data' onClick={() => navigateWithSearchedList(item?.product_title)}>
        <div className='seach_trending'>
          <svg width="18" height="18" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 38C30.3888 38 38 30.3888 38 21C38 11.6112 30.3888 4 21 4C11.6112 4 4 11.6112 4 21C4 30.3888 11.6112 38 21 38Z" fill="none" stroke="#333" strokeWidth="3" strokeLinejoin="round" /><path d="M26.657 14.3431C25.2093 12.8954 23.2093 12 21.0001 12C18.791 12 16.791 12.8954 15.3433 14.3431" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><path d="M33.2216 33.2217L41.7069 41.707" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg>
          <p>{item?.product_title}</p>
        </div>
        <svg width="18" height="18" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19 11H37V29" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><path d="M11.5439 36.4559L36.9997 11" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg>
      </div>
    ))
  }
  const menuItem = JSON.parse(localStorage.getItem("menuItem"));
  // console.log(menuItem,"menuItem")

  const showTrendingList = () => {
    return trendingList?.map(item => (
      <div className='search_data' onClick={() => {
        if (Array.isArray(menuItem) && menuItem?.find(id => id?.slug === item?.slug)) {
          navigate(`${item?.slug}`)
        } else {
          navigate(`${Routes.ProductCategory}/${item?.slug}`)
        }
        handleCloseSearch()
      }} >
        <div className='seach_trending'>
          <svg width="18" height="18" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 38C30.3888 38 38 30.3888 38 21C38 11.6112 30.3888 4 21 4C11.6112 4 4 11.6112 4 21C4 30.3888 11.6112 38 21 38Z" fill="none" stroke="#333" strokeWidth="3" strokeLinejoin="round" /><path d="M26.657 14.3431C25.2093 12.8954 23.2093 12 21.0001 12C18.791 12 16.791 12.8954 15.3433 14.3431" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><path d="M33.2216 33.2217L41.7069 41.707" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg>
          <p>{item?.title}</p>
        </div>
        <svg width="18" height="18" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19 11H37V29" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><path d="M11.5439 36.4559L36.9997 11" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg>
      </div>
    ))
  }


  const search_text = useRef(null);
  useEffect(() => {
    if (openSearch) {
      setTimeout(() => {
        search_text?.current?.focus();
      }, 100);
    }
  }, [openSearch])

  useEffect(() => {
    fetchSearchList();
    fetchTrendingSearchList();
  }, [searchIconClick])

  const handleClearSearch=()=>{
    setIsSearchContainerVisible('')
  }

  return (
    <div className='search_boxCont' onChange={(e) => handleSearchBoxClick(e?.target?.value)}>
      <div className='arrow_btn'>
        <button onClick={handleCloseSearch}><ArrowLeftOutlined /></button>
        <div className='input_search'>
          <div className="search_icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="19" height="19" viewBox="0 0 19 19" fill="none">
              <circle cx="7.85742" cy="7.50049" r="6.5" stroke="black" strokeWidth="1.5" />
              <path d="M7.85742 5.00049C7.3978 5.00049 6.94267 5.07809 6.51803 5.22885C6.09339 5.37961 5.70755 5.60059 5.38255 5.87917C5.05754 6.15774 4.79973 6.48846 4.62384 6.85244C4.44795 7.21641 4.35742 7.60652 4.35742 8.00049" stroke="black" strokeWidth="1.5" strokeLinecap="round" />
              <path d="M17.3574 18.0005L14.3574 14.0005" stroke="black" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
          </div>
          <input onChange={handleSearch} ref={search_text} onKeyPress={handleKeyPress} value={clearSearch ? '' : isSearchContainerVisible} placeholder='Search most beautiful products' />
          <div className='seach_close' onClick={handleClearSearch}>
            <svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 8L40 40" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><path d="M8 40L40 8" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg>
          </div>
        </div>
      </div>
      {/* {!isSearchContainerVisible && */}
      <div className='search_other_disclaimer'>
        <p><svg width="19" height="19" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M42 24V9C42 7.34315 40.6569 6 39 6H9C7.34315 6 6 7.34315 6 9V39C6 40.6569 7.34315 42 9 42H24" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><circle cx="32" cy="32" r="6" fill="none" stroke="#333" strokeWidth="3" /><path d="M37 36L42 40" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><path d="M14 16H34" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /><path d="M14 24L22 24" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg> Search History</p>
        <div className='search_history'>
          {showSearchList()}
        </div>


      </div>
      {/* } */}


      <div className='search_trends'>
        <p><svg width="19" height="19" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M19 4H37L26 18H41L17 44L22 25H8L19 4Z" fill="none" stroke="#333" strokeWidth="3" strokeLinejoin="round" /></svg> Trending Search</p>
        <div className='search_history'>
          {showTrendingList()}
        </div>
      </div>

      {isSearchContainerVisible && (
        <div className='search_container' onClick={(e) => e.stopPropagation()} style={{ display: clearSearch ? 'none' : '' }}>
          <div className='header_modelSearch'>
            <h3>Showing results for '{searchkeyword}'</h3>
            {/* <div>
              <CloseOutlined onClick={handleCloseSearch} />
            </div> */}
          </div>
          <div className='header_modelBody'>
            {loading ? (
              <></>
            ) : (
              autoSearchList?.length > 0 ? autoSearchList?.map((item, i) => (
                <SearchResultItem key={i} cart={cart} dispatch={dispatch} addToCart={addToCart} onChange={onChange} item={item} imgPath={imgPath} onLinkClick={handleLinkClick} handleAddToCart={handleAddToCart(item)} />
              )) : (
                <div className='noDataCont' style={{ marginTop: 60 }}>
                  <img src={NoData} alt='' />
                  <h5>No Data Found</h5>
                </div>
              )
            )}
          </div>
          <div className='footer_modelBody'>
            {
              autoSearchList?.length > 0 ? (<h3>
                <Link onClick={handleCloseSearch} to={Routes.AllProduct} state={{ searchValue: isSearchContainerVisible }}>View all products</Link>
              </h3>) : ''
            }
          </div>
        </div>
      )}
    </div>
  );
};

const SearchResultItem = ({ cart, onChange, addToCart, dispatch, item, imgPath, onLinkClick, handleAddToCart }) => {
  const [count, setCount] = useState(1);
  const calculateFilteredCartCount = () => {
    const filteredProduct = cart.find(product => product.id === item?.id);
    return filteredProduct ? filteredProduct.count : 0;
  };
  const user = useSelector((state) => state.user);
  const disableButton = calculateFilteredCartCount();
  const isOutOfStock = item?.stock_quantity < count;
  const handleDecrement = async (pid) => {
    if (count > 1) {
      setCount(count - 1);
    }
    item['count'] = count - 1;
    // new addon
    const itemToUpdate = cart.find(item => item.id === pid);

    if (itemToUpdate && itemToUpdate?.isChecked) {
      const formData = new URLSearchParams();
      formData.append('product_id', pid);
      formData.append('quantity', count - 1);
      try {
        // Update the cart count via API
        await updateCartCount(formData, user?.token);
        // Update cart locally
        const updatedCart = cart.map(item =>
          item.id === pid ? { ...item, count: item.count - 1 } : item
        );
        // Update state with the new cart
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        dispatch(addToCart(updatedCart));
      } catch (error) {
        console.error("Cart Updating error :", error);
      }
    }
  };

  const handleIncrement = async (pid) => {
    if (count >= item?.stock_quantity) {
      toast.error("Oops! Out Of Stock", { toastId: 1 });
      return;
    }
    setCount(count + 1);
    item['count'] = count + 1;
    // new addon
    const itemToUpdate = cart.find(item => item.id === pid);
    if (itemToUpdate && itemToUpdate?.isChecked) {
      const formData = new URLSearchParams();
      formData.append('product_id', pid);
      formData.append('quantity', count + 1);
      try {
        // Update the cart count via API
        await updateCartCount(formData, user?.token);
        // Update cart locally
        const updatedCart = cart.map(item =>
          item.id === pid ? { ...item, count: item.count + 1 } : item
        );
        // Update state with the new cart
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        dispatch(addToCart(updatedCart));
      } catch (error) {
        console.error("Cart Updating error :", error);
      }
    }
  };

  const excRate = useSelector(state => state.excrate);
  const convertedPrice = item.usd_price * (excRate?.rate || 1) || 0;
  const currencySymbol = excRate?.currencySymbol || excRate?.currencyCode || '$';
  const isINR = excRate?.currencyCode === "INR";
  return (
    <div className='header_Body'>
      <div className='haeder_title' onClick={onLinkClick}>
        {imgPath && <Link to={`${Routes?.ProductDetail}/${item.product_slug}`}><img src={`${imgPath}${item?.productimage?.file_name_120_x_120}`} alt={item.product_name} /></Link>}
        <Link to={`${Routes?.ProductDetail}/${item.product_slug}`} >
          <p>{item.product_name}</p>
        </Link>
      </div>
      {/* <h3>₹{item.price}</h3> */}
      <h3>{isINR ? `₹${item.price}` : `${currencySymbol} ${convertedPrice.toFixed(2)}`}</h3>
      {/* <span>60% off</span> */}
      <div className='buttonHeader'>
        <div className="button-box">
          <button className='btn-incriment'>
            <span onClick={() => handleDecrement(item?.id)}><FaMinus /></span>
            {disableButton ? disableButton : count}
            <span onClick={() => handleIncrement(item?.id)}><FaPlus /></span>
          </button>
        </div>
        <div className={disableButton ? "disablepayBtn" : ""}>
          <button onClick={() => handleAddToCart()} disabled={disableButton || isOutOfStock} >{disableButton ? "Added" : isOutOfStock ? "Sold Out" : "Add"}</button>
        </div>
      </div>
    </div>
  );
};

export default Search;
