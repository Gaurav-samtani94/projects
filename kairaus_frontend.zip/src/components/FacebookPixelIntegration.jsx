/* eslint-disable no-undef */
/* eslint-disable no-unused-expressions */
import React, { useEffect } from "react";
import { Helmet } from "react-helmet-async";

const FACEBOOK_PIXEL_ID = "1089663135859788";

export const handleAddToCartForPixel = (product) => {
  fbq('track', 'AddToCart', {
    content_name: product.product_name,
    content_ids: [String(product.product_id)],
    content_type: 'product',
    value: product.price,
    currency: product?.currency_code,
  });
};

export const handlePurchaseForPixel = (product) => {
  fbq('track', 'Purchase', {
    content_name: product.product_name,
    content_ids: [String(product.product_id)],
    content_type: 'product',
    value: product.price,
    currency: product?.currency_code,
  });
};

const removeHtmlTags = (html) => {
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = html;
    return tempDiv.textContent || tempDiv.innerText || "";
  };

const FacebookPixelIntegration = ({ productDetails, imgPath, category, categorySlug }) => {
  const product = {
    id: String(productDetails?.id),
    name: productDetails?.product_name,
    description: removeHtmlTags(productDetails?.description),
    price: productDetails?.price,
    currency: "INR",
    availability: "in stock",
    category: category,
    condition: "new",
    image: `${imgPath}${productDetails?.productimages[0]?.file_name}`,
    url: window.location.href,
  };

  useEffect(() => {
    !(function (f, b, e, v, n, t, s) {
      if (f.fbq) return;
      n = f.fbq = function () {
        n.callMethod
          ? n.callMethod.apply(n, arguments)
          : n.queue.push(arguments);
      };
      if (!f._fbq) f._fbq = n;
      n.push = n;
      n.loaded = !0;
      n.version = "2.0";
      n.queue = [];
      t = b.createElement(e);
      t.async = !0;
      t.src = v;
      s = b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t, s);
    })(
      window,
      document,
      "script",
      "https://connect.facebook.net/en_US/fbevents.js"
    );

    fbq("init", FACEBOOK_PIXEL_ID);
    fbq("track", "PageView");

    // Track ViewContent event for e-commerce
    fbq("track", "ViewContent", {
      content_name: product.name,
      content_category: category,
      content_ids: [product.id],
      content_type: "product",
      value: product.price,
      currency: product.currency,
    });
  }, [productDetails]);

  const structuredData = {
    "@context": "http://schema.org",
    "@type": "Product",
    "brand": "Kairaus",
    "name": product.name,
    "description": product?.description,
    "productID": product?.id,
    "url": product?.url,
    "image": product?.image,
    "offers": {
      "@type": "Offer",
      "priceCurrency": "INR",
      "price": product?.price,
      "availability": "http://schema.org/InStock",
      "itemCondition": "http://schema.org/NewCondition"
    },
  };

  return (
    <>
      <Helmet>
        {/* Facebook Pixel noscript */}
        <noscript>
          {`
           <img
           height="1"
           width="1"
           style={{ display: "none" }}
           src={https://www.facebook.com/tr?id=${FACEBOOK_PIXEL_ID}&ev=PageView&noscript=1}
         />
           `}
        </noscript>

        {/* Open Graph tags */}
        <meta property="og:title" content={product.name} />
        <meta property="og:description" content={product.description} />
        <meta property="og:image" content={product.image} />
        <meta property="og:url" content={product.url} />
        <meta property="og:type" content="product" />
        <meta property="product:price:amount" content={product.price} />
        <meta property="product:price:currency" content={product.currency} />
        <meta property="product:brand" content="Kairaus" />
        <meta property="product:availability" content="in stock" />
        <meta property="product:condition" content="new" />
        <meta property="product:retailer_item_id" content={product?.id} />
        <meta property="product:item_group_id" content={categorySlug}></meta> 

        {/* JSON-LD structured data */}
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      </Helmet>

      <div itemScope itemType="http://schema.org/Product">
        <meta itemprop="brand" content="kairaus" />
        <meta itemprop="name" content={product.name} />
        <meta itemprop="description" content={product?.description} />
        <meta itemprop="productID" content={product?.id} />
        <meta itemprop="url" content={product?.url} />
        <meta itemprop="image" content={product?.image} />

        <div itemprop="value" itemScope itemType="http://schema.org/PropertyValue">
          <span itemprop="propertyID" content={product?.id}></span>
          <meta itemprop="value" content={categorySlug} />
        </div>

        <div itemprop="offers" itemScope itemType="http://schema.org/Offer">
          <link itemprop="availability" href="http://schema.org/InStock" />
          <link itemprop="itemCondition" href="http://schema.org/NewCondition" />
          <meta itemprop="price" content={product?.price} />
          <meta itemprop="priceCurrency" content="INR" />
        </div>
      </div>
    </>
  );
};

export default FacebookPixelIntegration;
