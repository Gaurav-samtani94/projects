import React from 'react';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import 'react-lazy-load-image-component/src/effects/blur.css';
// npm i react-lazy-load-image-component

const ProductImage = ({ imgPath, imgName, alt, className, placeholderImage}) => {
  return (
    <LazyLoadImage
      alt={alt}
      src={`${imgPath}${imgName}`}
      className={className} 
      effect="blur"
      style={{ objectFit: 'cover', width: '100%', height: '100%' }} 
      wrapperProps={{
        // If you need to, you can tweak the effect transition using the wrapper style.
        style: {transitionDelay: "0.5s"},
      }}
      placeholderSrc={`${imgPath}${placeholderImage}`}
    />
  );
};

export default ProductImage;
