import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useDispatch } from "react-redux";
import { addProductCount } from '../reducers/productCountSlice'

const ScrollComponent = ({ fetchProducts, totalProductCount, slug, gridCount, setGridLayout, productSectionRef, getDynamicHeightRef }) => {
    const dispatch = useDispatch();
    const savedCount = parseInt(sessionStorage.getItem('productCount'), 10) || 0;
    const [showDiv, setShowDiv] = useState(false);
    const [count, setCount] = useState(gridCount === 'md' ? 3 : gridCount === 'sm' ? 2 : gridCount === "lg" ? 4 : 3);
    const total = totalProductCount || savedCount;
    const location = useLocation().pathname?.split('/');
    const width = window.innerWidth;

const productHeight = gridCount === 'md' ? 654 : gridCount === 'sm' && width < 768 ? 281 : gridCount === 'sm' ? 944 : gridCount === 'lg' ? 511 : 654;
const productHeightCommonPages = gridCount === 'md' ? 654 : gridCount === 'sm' && width < 768 ? 278 : gridCount === 'sm' ? 952 : gridCount === 'lg' ? 510 : 658;
const isAllItemsPage = location.includes("all-items");
const allitemHeight = gridCount === 'md' ? 525 : gridCount === 'sm' && width < 768 ? 278 : gridCount === 'sm' ? 747 : gridCount === 'lg' ? 427 : 525;
const newProductHeight = isAllItemsPage ? allitemHeight : (location.includes("collections") ? productHeight : productHeightCommonPages);
const productsPerRow = gridCount === 'md' ? 3 : gridCount === 'sm' ? 2 : gridCount === 'lg' ? 4 : 3;

const handleResize = () => {
    if (width <= 768) {
        setGridLayout("sm");
    } else if (width > 1024) {
        setGridLayout("md");
    } else {
        setGridLayout("lg");
    }
};

useEffect(() => {
    handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
        window.removeEventListener('resize', handleResize);
    };
}, [width]);

const handleScroll = () => {
    const productSectionTop = productSectionRef.current?.getBoundingClientRect().top;
    const windowHeight = window.innerHeight;
    if (productSectionTop <= windowHeight) {
        setShowDiv(true);
        const totalVisibleHeight = windowHeight - productSectionTop;
        const visibleRows = Math.floor(totalVisibleHeight / newProductHeight);
        const newCount = Math.min(visibleRows * productsPerRow, total);
        dispatch(addProductCount(false))
        if (newCount === total) {
            dispatch(addProductCount(true))
        }
        setCount(newCount);
    } else {
        setShowDiv(false);
    }
};

useEffect(() => {
    const handleScrollDebounced = () => {
        const timer = setTimeout(() => {
            handleScroll();
        }, 200);
        return () => clearTimeout(timer);
    };
    window.addEventListener('scroll', handleScrollDebounced);
    return () => {
        window.removeEventListener('scroll', handleScrollDebounced);
    };
}, [count, gridCount, total]);

useEffect(() => {
    setCount(gridCount === 'md' ? 3 : gridCount === 'sm' ? 2 : gridCount === 'lg' ? 4 : 3);
}, [gridCount]);

useEffect(() => {
    if (count > total) {
        setCount(total);
    }
}, [total]);

const shouldShowButton = count > 0 && total > 0;
const capitalizeFirstLetter = (string) => {
    return string?.charAt(0)?.toUpperCase() + string?.slice(1);
};

const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
};


return (
    <div>
        {showDiv && shouldShowButton && (
            <div className='button_loading'>
                <button onClick={scrollToTop}>
                    <svg width="17" height="17" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M24 6V42" stroke="#fff" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                        <path d="M12 18L24 6L36 18" stroke="#fff" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
                    </svg> {capitalizeFirstLetter(slug)} : {count}/{total}
                </button>
            </div>
        )}
    </div>
);
};

export default ScrollComponent;