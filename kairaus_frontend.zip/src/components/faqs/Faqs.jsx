import React, { useState, useEffect, useCallback, useRef } from 'react';
import Container from 'react-bootstrap/Container';
import { Input, Row, Col } from 'antd';
import search_icon from '../../assets/images/faqs/Frame 1.png';
import Accordion from 'react-bootstrap/Accordion';
import { getFaqCategory, getFaqList } from '../../services/faq';
import { getSearchContactUs } from '../../services/contactUs';
import Routes from '../../Routes/Routes';
import faqImg from '../../assets/images/faqs/faqsheader.webp';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import debounce from 'lodash/debounce';

// Highlighting function
const highlightText = (text, query) => {
  if (!query) return text;
  const regex = new RegExp(`(${query})`, 'gi');
  const parts = text.split(regex);
  return parts.map((part, index) => 
    regex.test(part) ? <span key={index} className="highlight">{part}</span> : part
  );
};

function Faqs() {
  const [faqData, setFaqData] = useState({ categories: null, list: null, searchQuery: '' });
  const user = useSelector((state) => state.user);
  const hasMounted = useRef(false);

  const debouncedSearch = debounce(async (query, token) => {
    if (!query) return;

    const formData = new URLSearchParams();
    formData.append('search_for', '0');
    formData.append('search_data', query);

    try {
      const searchResponse = await getSearchContactUs(formData, token);
      if (searchResponse.status === '1') {
        setFaqData((prev) => ({
          ...prev,
          list: searchResponse.data,
        }));
      }
    } catch (error) {
      console.error('Error searching FAQs:', error);
    }
  }, 300);

  const fetchData = useCallback(async () => {
    const formData = new URLSearchParams();
    formData.append('type', '0');

    try {
      const [faqResponse, faqListResponse] = await Promise.all([
        getFaqCategory(formData),
        getFaqList(formData),
      ]);

      if (faqResponse.status === '1' && faqListResponse.status === '1') {
        setFaqData((prev) => ({
          ...prev,
          categories: faqResponse.data,
          list: faqListResponse.data,
        }));
      }
    } catch (error) {
      console.error('Error fetching FAQ data:', error);
    }
  }, []);

  const handleSearch = useCallback(
    (query) => {
      if (!query) {
        fetchData();
      } else {
        debouncedSearch(query, user?.token);
      }
    },
    [fetchData, user?.token]
  );

  const onSearchChange = (e) => {
    const query = e.target.value;
    setFaqData((prev) => ({ ...prev, searchQuery: query }));
    handleSearch(query);
  };

  useEffect(() => {
    if (!hasMounted.current) {
      fetchData();
      hasMounted.current = true;
    }
  }, [fetchData]);

  return (
    <>
      <section className="section_one_faqs">
        <img src={faqImg} alt="FAQs Header" />
        <div className="full_img_text">
          <h1>Have Questions!</h1>
        </div>
      </section>

      <section className="section_two_faqs">
        <Container fluid="md">
          <Row>
            <Col sm={7}>
              <div className="faqs_right_side">
                <h4>How can we Help!</h4>
                <ul>
                  {faqData.categories &&
                    faqData.categories.map((item) => (
                      <li key={item.id}>
                        <a href={`#link${item.id}`} rel="canonical">
                          {item.name}
                        </a>
                      </li>
                    ))}
                </ul>
              </div>
            </Col>

            <Col sm={17}>
              <div className="faqs_left_side">
                <h4>FAQ</h4>
                <div className="searchbar_faqs">
                  <img src={search_icon} alt="Search Icon" />
                  <Input
                    placeholder="Search FAQ"
                    value={faqData.searchQuery}
                    onChange={onSearchChange}
                  />
                </div>

                {faqData.list &&
                  faqData.list.map((listItem) => (
                    <section className="faqs_accor_main_sec1" id={`link${listItem.id}`} key={listItem.id}>
                      <h4>{listItem.name}</h4>
                      <Accordion>
                        {listItem.faq &&
                          listItem.faq.map((faqItem) => (
                            <Accordion.Item eventKey={faqItem.id} key={faqItem.id}>
                              <Accordion.Header>{highlightText(faqItem.question, faqData.searchQuery)}?</Accordion.Header>
                              <Accordion.Body>{highlightText(faqItem.answer, faqData.searchQuery)}</Accordion.Body>
                            </Accordion.Item>
                          ))}
                      </Accordion>
                    </section>
                  ))}
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      <section className="faqs_footer_heading" id="link4">
        <div className="faqs_footer_main content">
          <p className="faq_foot_p">Need Help!</p>
          <h3>Get in Touch</h3>
          <div className="foot_faq_btn">
            <Link to={Routes.ContactUs}>
              <button>Contact Us!</button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}

export default Faqs;
