// src/components/Breadcrumb.js
import React, { useMemo, useCallback } from 'react';
import PropTypes from 'prop-types';
import { Link, useLocation, useNavigate } from "react-router-dom";
import { LiaGreaterThanSolid } from "react-icons/lia";

const Breadcrumb = ({ category }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const {
    from,
    menuSlug,
    route
  } = useMemo(() => ({
    from: location.state?.from,
    menuSlug: location.state?.menuSlug,
    categorySlug: location.state?.categorySlug,
    route: location.state?.route,
    giftData: location.state?.giftData,
    price: location.state?.price,
  }), [location.state]);

  const handleNavigate = useCallback((path) => {
    navigate(path);
  }, [navigate]);

  return (
    <div className="path_drinkware">
      <Link to="/">Home</Link>
      <LiaGreaterThanSolid />
      {from && (
        <>
          <span onClick={() => handleNavigate(`/${menuSlug}`)}>{from}</span>
          <LiaGreaterThanSolid />
        </>
      )}
      {route && (
        <>
          <span onClick={() => handleNavigate(`/${from}/${menuSlug}`)}>{route}</span>
          <LiaGreaterThanSolid />
        </>
      )}
      <p>{category && category.name}</p>
    </div>
  );
};

Breadcrumb.propTypes = {
  category: PropTypes.shape({
    name: PropTypes.string,
  }),
};

Breadcrumb.defaultProps = {
  category: null,
};

export default React.memo(Breadcrumb);
