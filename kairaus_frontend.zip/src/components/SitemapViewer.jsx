import React, { useEffect, useState } from 'react';
import axios from 'axios';

const SitemapViewer = () => {
    const [sitemapData, setSitemapData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        // Fetch sitemap data from server
        axios.get('https://demo1.growthgrids.com/api/user/get-sitemap')
            .then(response => {
                if (response.status === 200 && response.data.status === "1") {
                    setSitemapData(response.data.fileNames); // Store the sitemap data
                } else {
                    setError('Failed to fetch sitemap');
                }
            })
            .catch(err => {
                setError('An error occurred while fetching the sitemap');
            })
            .finally(() => {
                setLoading(false);
            });
    }, []);

    if (error) return <p>{error}</p>;

    return (
        <div>
            <h1>Sitemap</h1>
            <ul>
                {sitemapData.map((item, index) => (
                    <li key={index}>
                        <a
                            href={`https://api.growthgrids.com/storepedia/uploads/sitemap/${item}`}
                            download={item}
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            {item}
                        </a>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default SitemapViewer;
