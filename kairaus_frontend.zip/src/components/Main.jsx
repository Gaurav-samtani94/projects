import React from 'react'
// import Header from './includes/header/Header'
// import Footer from './includes/footer/Footer'
import Category from '../pages/category/Category'

const Main = () => {
  return (
    <div className='main_comp'>
        {/* <Header/> */}
        <Category />
        {/* <Footer /> */}
    </div>
  )
}

export default Main