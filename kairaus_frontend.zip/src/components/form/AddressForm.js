import React, { useState, useEffect, useCallback } from 'react';
import { Row, Col, Form, Input, Switch, Select, Button, message } from 'antd';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';
import { getStateList } from '../../services/user/getStateList';
import { getCityList } from '../../services/user/getCitiyList';
const { TextArea } = Input;

const AddressForm = ({ onSubmit, editMode, existingData }) => {
  // console.log('existingData',existingData);
  const user = useSelector((state) => state.user);
  let { email, token } = user;

  const [form] = Form.useForm();
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);

  const fetchStates = useCallback(async (country) => {
    const formData = new URLSearchParams();
    formData.append('country_id', '1');
    try {
      const responseData = await getStateList(formData, token);

      if (responseData.status === '1') {
        const stateData = responseData.data;
        return stateData;
      }
    } catch (error) {
      console.error('API Request Error:', error);
      message.error('Login failed. Please check your credentials and try again.');
    }
    return [];
  }, [token]);

  const fetchCities = useCallback(async (state) => {
    const formData = new URLSearchParams();
    formData.append('state_id', state);
    try {
      const responseData = await getCityList(formData, token);


      if (responseData.status === '1') {
        const cityData = responseData.data;
        return cityData;
      }
    } catch (error) {
      console.error('API Request Error:', error);
      message.error('Login failed. Please check your credentials and try again.');
    }
    return [];
  }, [token]);

  useEffect(() => {
    const selectedCountry = form.getFieldValue('country');
    const selectedState = form.getFieldValue('state');

    if (selectedCountry) {
      fetchStates(selectedCountry)
        .then((states) => setStates(states))
        .catch((error) => console.error('Error fetching states:', error));
    }

    if (selectedState) {
      fetchCities(selectedState)
        .then((cities) => setCities(cities))
        .catch((error) => console.error('Error fetching cities:', error));
    } else {
      setCities([]);
    }
  }, [form, fetchStates, fetchCities]);

  const handleCountryChange = (value) => {
    form.setFieldsValue({ state: undefined, city: undefined });
    fetchStates(value)
      .then((states) => setStates(states))
      .catch((error) => console.error('Error fetching states:', error));
  };

  const handleStateChange = (value) => {
    form.setFieldsValue({ city: undefined });
    fetchCities(value)
      .then((cities) => setCities(cities))
      .catch((error) => console.error('Error fetching cities:', error));
  };
  useEffect(() => {
    const defaultValues = {
      country: undefined,
      state: undefined,
      city: undefined,
      pincode: undefined,
      address: undefined,
      name: undefined,
      phone: undefined,
      defaultAddress: undefined,
    };

    if (editMode && existingData) {

      // console.log('existingData:', existingData.state.id);

      const { country, state, city, zip_code, address, name, mobile_number, is_default } = existingData;
      form.setFieldsValue({
        country: country.id,
        pincode: zip_code,
        address,
        name,
        phone: mobile_number,
        defaultAddress: is_default === 1, // Assuming '1' means true

        // The following lines set the state and city based on the API response
        state: state.id,
        city: city.id,
      });

      // Fetch states and set them in the form
      fetchStates(country.id)
        .then((states) => {
          setStates(states);

          // Fetch cities based on the selected state
          return fetchCities(state.id);
        })
        .then((cities) => setCities(cities))
        .catch((error) => console.error('Error fetching states/cities:', error));


    } else {
      // console.log('No existing data or not in edit mode');
      form.setFieldsValue(defaultValues);
    }
  }, [editMode, existingData, form, fetchStates, fetchCities]);
  return (
    <Form form={form} onFinish={onSubmit} autoComplete="off">
      <div className='model_form'>
        <Row gutter={18}>
          <Col span={12}>
            <Form.Item
              name="country"
              rules={[
                {
                  required: true,
                  message: 'Please select your Country!',
                },
              ]}
            >
              <Select placeholder="Select Country" onChange={handleCountryChange}>
                <Select.Option value={1}>India</Select.Option>
                {/* Add other country options as needed */}
              </Select>
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="state"
              rules={[
                {
                  required: true,
                  message: 'Please input your State!',
                },
              ]}
            >
              <Select placeholder="Select State" onChange={handleStateChange}>
                {states.map((state) => (
                  <Select.Option key={state.id} value={state.id}>
                    {state.state_name}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="city"
              rules={[
                {
                  required: true,
                  message: 'Please input your City!',
                },
              ]}
            >
              <Select placeholder="Select City">
                {cities.map((city) => (
                  <Select.Option key={city.id} value={city.id}>
                    {city.city_name}
                  </Select.Option>
                ))}
              </Select>
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="pincode"
              rules={[
                {
                  required: true,
                  message: 'Please input your Pincode!',
                },
              ]}
            >
              <Input placeholder="Enter Pincode" />
            </Form.Item>
          </Col>
        </Row>
        <Form.Item
          name="address"
          rules={[
            {
              required: true,
              message: 'Please input your Full Address!',
            },
          ]}
        >
          <TextArea placeholder="Enter Road/Area/Colony" rows={6} />
        </Form.Item>
        <div className='default_address'>
          <span>Use as Default address</span>
          <Form.Item name="defaultAddress" valuePropName="checked" initialValue={false}>
            <Switch />
          </Form.Item>
        </div>
      </div>
      <div className='contact_form_detail'>
        <h3>Contact</h3>
        <p>Information provided here will be used to contact you for delivery updates</p>
      </div>
      <div className='model_form'>
        <Form.Item
          name="name"
          rules={[
            {
              required: true,
              message: 'Please input your Name!',
            },
          ]}
        >
          <Input placeholder="Enter Name" />
        </Form.Item>
        <Form.Item
          name="phone"
          rules={[
            {
              required: true,
              message: 'Please input your Phone!',
            },
          ]}
        >
          <Input placeholder="Enter Phone" />
        </Form.Item>
        <Form.Item
          name="email"
          initialValue={email}>
          <Input readOnly />
        </Form.Item>
      </div>
      <div className='save_address_button'>
        <Button type="primary" htmlType="submit">
          Save Address
        </Button>
      </div>
    </Form>
  );
};

AddressForm.propTypes = {
  onSubmit: PropTypes.func.isRequired,
};

export default AddressForm;
