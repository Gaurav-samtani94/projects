import React, { useCallback, useEffect, useState } from 'react'
import { FaInstagram, FaFacebookF, FaPinterestP, FaLinkedinIn, FaTwitter } from "react-icons/fa";
import { CiYoutube } from "react-icons/ci";
import { Link, useNavigate } from 'react-router-dom';

import Routes from "../../Routes/Routes";
import { useDispatch, useSelector } from 'react-redux';
import { Row, Col,} from "antd";
import BulkDrawer from '../drawer/BulkDrawer';

import onlineImg from '../../assets/images/master.png';
import onlineImg2 from '../../assets/images/visa (2).png';
import onlineImg3 from '../../assets/images/amex.png';
import onlineImg4 from '../../assets/images/dinners.png';
import { getCustomerSupport } from '../../services/assurance';
import { Collapse } from 'antd';
import { addToCart } from '../../reducers/cartSlice';
import { clearBuy } from '../../reducers/buySlice';
import SeoContent from '../../pages/home/SeoContent';
import { addCart } from '../../services/cart/addCart';



const Footer = () => {
 
  const [open, setOpen] = useState(false);
  const excRate = useSelector(state => state.excrate);
  const [drawerHeading, setDrawerHeading] = useState('');
  

 
  const navigate = useNavigate();


  const user = useSelector((state) => state.user);
  const navigationMenu = useSelector((state) => state.navigationMenu);

  const categories_2 = navigationMenu.categories_2 || []; // Set default to empty array if undefined
const categories_3 = navigationMenu.categories_3 || []; 

  const handleItem = (dropDownItem) => {
    if (user?.id) {
      navigate(Routes.AccountProfile, { state: { from: dropDownItem } });
    } else {
      navigate(Routes.SignIn, { state: { from: dropDownItem } })
    }
  }

  const showDrawer = () => {
    setOpen(true);
    setDrawerHeading('Bulk Orders');
  };
  const onClose = () => {
    setOpen(false);
  };
  // Footer Content
  const [footerDescription, setFooterDescription] = useState(null);
  const [footerHeading, setFooterHeading] = useState(null);
  const [footerLinkContent, setFooterLinkContent] = useState(null);


  useEffect(() => {
    const fetchFooterData = async () => {
      try {
        const result = await getCustomerSupport();
        // console.log('getCustomerSupportgetCustomerSupportgetCustomerSupport',result)
        setFooterDescription(result?.data?.footer_description);
        setFooterHeading(result?.data?.footer_heading);
        setFooterLinkContent(result?.data?.footer_link_content);
        localStorage.setItem('customerServiceBufferdays',result?.data?.product_buffer_days);
        localStorage.setItem('order_max_amount',result?.data?.max_shipping_amount);
        localStorage.setItem('shipping_charges',result?.data?.shipping_amount);
      } catch (error) {
        console.error('Error fetching footer data:', error);
      }
    };

    fetchFooterData();

    // Clean-up function not needed since there are no dependencies
  }, []);

  const itemsFooter = [
    {
      key: '001',
      children: <div dangerouslySetInnerHTML={{ __html: footerLinkContent }} className='seo_content' />
    },
  ];

  // buy now handler     
  const dispatch = useDispatch();
  const currentSegment = window.location.pathname.split('/').pop(); // adjust to your segment retrieval logic


  
  useEffect(() => {
    const buy = JSON.parse(localStorage.getItem('buy')) || [];
    // console.log("footer buy",buy);
  
    const validSegments = new Set(['checkout', 'confirmation', 'payment', 'thanku-check','mainCheckout']);
  
    if (!validSegments.has(currentSegment) && buy.length > 0) {
      const cart = JSON.parse(localStorage.getItem('cart')) || [];
      const updatedCart = [...cart];
      const productsForDB = [];
  
      buy.forEach(item => {
        const existingItemIndex = updatedCart.findIndex(cartItem => cartItem.id === item.id);
  
        // if (existingItemIndex !== -1) {
        //   // updatedCart[existingItemIndex].count += item.count;
        // } else {
        //   item = {...item,isChecked:true}
        //   updatedCart.push(item);
        // }

        if(existingItemIndex === -1){
          item = {...item,isChecked:true}
          updatedCart.push(item);
          // Add product data to productsForDB
        productsForDB.push(createProductForDB(item, excRate));
        }
  
        
      });
  
      if (productsForDB.length > 0) {
        // Now call addCartItemToDB after the loop
        addCartItemToDB(productsForDB);
      }
  
      // Update the cart in localStorage and state
      localStorage.setItem('cart', JSON.stringify(updatedCart));
      dispatch(addToCart(updatedCart));
      dispatch(clearBuy());
      localStorage.removeItem('buy');
    }
  }, [currentSegment]);
  

  // Helper function to create productForDB object
  const createProductForDB = (item, excRate) => ({
    product_id: item.id,
    product_variant_id: item.p_variant_id,
    quantity: item.count,
    coupon_code: item.productCoupon || "",
    usd_amount: item?.usd_price,
    currency_code: excRate?.currencyCode,
    currency_rate: excRate?.rate,
    currency_symbol: excRate?.currencySymbol,
  });

  // Add Cart Item to DB Function (memoized with useCallback)
  const addCartItemToDB = useCallback(async (products) => {
    try {
      const response = await addCart(products, user.token);
      if (!response.ok) {
        throw new Error('Failed to add items to cart');
      }
    } catch (error) {
      console.error('Error adding items to DB:', error);
    }
  }, [user.token]);

  const [isBOpen, setIsBOpen] = useState(false)
  const [isAOpen, setIsAOpen] = useState(false)

  const toggleAOpen = () => {
    setIsAOpen(!isAOpen);  // Toggle A
    setIsBOpen(false);     // Close B
  };

  const toggleBOpen = () => {
    setIsBOpen(!isBOpen);  // Toggle B
    setIsAOpen(false);     // Close A
  };
  return (
    <>
      <SeoContent isAOpen={isAOpen} />
      <section className='seo_footer'>
        <Collapse activeKey={[isBOpen ? "001" : ""]} ghost items={itemsFooter} />
      </section>
      <div className='footer'>
        <div className='seo_butttons'>
          <div onClick={toggleAOpen}><svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M36 18L24 30L12 18" stroke="#333" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></svg></div>
          <div onClick={toggleBOpen}><svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M36 18L24 30L12 18" stroke="#333" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></svg></div>
        </div>
        <div className='footer_main'>
          <Row>
            <Col xs={24} sm={12} md={24} lg={8} xl={8}>
              <div className="footer_logo_Last">
                <h3>{footerHeading}</h3>
                <p>{footerDescription}</p>
              </div>
            </Col>
            <Col xs={24} sm={24} md={24} lg={16} xl={16}>
              <Row>
                <Col xs={24} sm={12} md={8} lg={8} xl={8}>
                  <div className="footer_menu">
                    <h5>Discover Kairaus</h5>
                    {categories_2?.map(item => (
                      <Link key={item?.slug} to={item?.slug} className='footer_links'> {item?.name}</Link>
                    ))}
                  </div>
                </Col>
                <Col xs={24} sm={12} md={8} lg={8} xl={8}>
                  <div className="footer_menu">
                    <h5>About Kairaus</h5>
                    {
                      categories_3?.filter(item => item.id != '232').map((item) => {

                        return (
                          <Link key={item?.slug} to={item?.slug} className='footer_links'> {item?.name}</Link>
                        )
                      })
                    }
                    {/* {!user?.id &&
                      <Link to={user?.id ? '#' : Routes.SignUp} className='footer_links'>Become a Member</Link>} */}
                  </div>
                </Col>
                <Col xs={24} sm={12} md={8} lg={8} xl={8}>
                  <div className="footer_menu">
                    <h5>Customer Service</h5>
                    <Link to={Routes?.ContactUs} >
                    <div className='footer_links'>Contact Us</div></Link>
                    <div onClick={() => handleItem("Profile")} className='footer_links'>My Account</div>
                    <div onClick={() => handleItem("orders")} className='footer_links'> Track your Order</div>

                    <Link className='footer_links' onClick={showDrawer}>Bulk Orders</Link>
                  </div>
                </Col>
              </Row>
            </Col>
          </Row>
          <Row>
            <Col xs={24} sm={12} md={8} lg={8} xl={8}>
              <div className="social_icons">
                <h6>Follow Us</h6>
                <div className="set_icons">
                <Link to="https://www.instagram.com/kairaus_official/?hl=en" target='_blank'>
                    <FaInstagram />
                  </Link>
                  <Link to="https://www.facebook.com/people/KairausOfficial/61565182179977/" target='_blank'>
                    <FaFacebookF />
                  </Link>
                  <Link to="https://www.youtube.com/@KairausOfficial" target='_blank'>
                    <CiYoutube />
                  </Link>
                  <Link to="https://in.pinterest.com/kairaus_official/" target='_blank'>
                    <FaPinterestP />
                  </Link>
                  <Link to="https://www.linkedin.com/in/kairausofficial/" target='_blank'>
                  <FaLinkedinIn />
                  </Link>
                  <Link to="https://x.com/Kairausofficial" target='_blank'>
                  <FaTwitter />
                  </Link>
                </div>
              </div>
            </Col>
            <Col xs={24} sm={24} md={16} lg={16} xl={16}>
              <div className="payment_icons">
                <h6>Secure Payment and Cash on Delivery</h6>
                <div className="set_paytm">
                  <img src={onlineImg} alt='' />
                  <img src={onlineImg2} alt='' />
                  <img src={onlineImg3} alt='' />
                  <img src={onlineImg4} alt='' />
                </div>
              </div>
            </Col>
          </Row>
          <div className="footer_btm_text">
            <span>Kairaus, a product by Storepedia | © 2024 All rights reserved.</span>
          </div>
        </div>
      </div>
      {open&&<BulkDrawer onClose={onClose} openDrawer={open} productId={'0'} drawerHeading={drawerHeading} />}
    </>
  )
}
export default Footer
