import React, { useEffect, useState } from 'react';
import { Select } from 'antd';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { addToExcRate } from '../../reducers/excRateSlice';
import { applyCoupon } from '../../reducers/couponSlice';
import { clearCart } from '../../reducers/cartSlice';
import { deleteCart } from '../../services/cart/addCart';
import indiaImg from '../../assets/images/india.png';
import usImg from '../../assets/images/us.png';
import franceImg from '../../assets/images/franch.png';
import ukImg from '../../assets/images/uk.png';
import { Modal } from 'antd';

const baseURL = process.env.REACT_APP_API_BASE_URL || 'https://demo1.growthgrids.com/api/user';

const CurrencySelect = () => {
  const [selectedOption, setSelectedOption] = useState(sessionStorage.getItem('currencyChange') || '');
  const [options, setOptions] = useState([
    { value: 'US', label: createFlagOption('US', usImg, 'US') },
    { value: 'IN', label: createFlagOption('IN', indiaImg, 'IND') },
    { value: 'FR', label: createFlagOption('FR', franceImg, 'France') },
    { value: 'GB', label: createFlagOption('GB', ukImg, 'UK') },
  ]);

  const dispatch = useDispatch();
  const cart = useSelector((state) => state.cart);
  const user = useSelector((state) => state.user);

  useEffect(() => {
    if (!sessionStorage.getItem('currencyChange')) {
      fetchIpAddress();
    }
  }, [dispatch, options]);

  const fetchIpAddress = async () => {
    try {
      // Comment for Now
      
      // const res = await axios.get("https://api.ipify.org/?format=json");
      // const formData = new URLSearchParams();
      // formData.append("ip", res?.data?.ip);

      // const { data: countryData } = await axios.post(`${baseURL}/get-country-by-ip`, formData);
      // // const { fullName: countryName, exchangeRate, currencyCode, currencySymbol, countryCode } = countryData;
    
    let countryName = 'India'
    let countryCode = 'IN'
    let currencyCode = 'INR'
    let currencySymbol = '₹'
    let exchangeRate = 83.99
    let flagUrl =  "https://flagcdn.com/in.svg"

      setSelectedOption(countryCode);
      if (!options.find((option) => option.value === countryCode)) {
        addCountryOption(countryName, countryCode, flagUrl);
      }
      updateCurrencyData({ exchangeRate, currencyCode, currencySymbol });
    } catch (error) {
      console.error('Error fetching IP or country data:', error);
    }
  };

  const addCountryOption = (countryName, countryCode, flagUrl) => {
    setOptions((prevOptions) => {
      const newOption = { value: countryCode, label: createFlagOption(countryName, flagUrl, countryName) };
      return [...prevOptions, newOption];
    });
  };
  const handleChange = async (value) => {
    const userConfirm = user.id && cart.length > 0
      ? await new Promise((resolve) => {
          Modal.confirm({
            title: 'Kairaus says',
            content: 'Changing the currency will remove all items from your cart. Are you sure?',
            okText: 'Yes',
            cancelText: 'No',
            onOk: () => resolve(true),   // Proceed with the currency change
            onCancel: () => resolve(false), // Cancel the currency change
          });
        })
      : true;
  
    // If user clicked 'No', do nothing and return
    if (!userConfirm) return;
  
    setSelectedOption(value);
    sessionStorage.setItem('currencyChange', value);
  
    // Clear cart and data if needed
    if (user.id && cart.length > 0) {
      await clearCartAndData();
    }
  
    fetchCountryCurrencyData(value);
  };
  

  const fetchCountryCurrencyData = async (countryCode) => {
    try {
      const formData = new URLSearchParams();
      formData.append("countryCode", countryCode);
      
      const { data } = await axios.post(`${baseURL}/get-country-by-ip`, formData);
      const { exchangeRate, currencyCode, currencySymbol } = data;
      
      updateCurrencyData({ exchangeRate, currencyCode, currencySymbol });
    } catch (error) {
      console.error('Error fetching country or currency data:', error);
    }
  };

  const updateCurrencyData = ({ exchangeRate, currencyCode, currencySymbol }) => {
    if (exchangeRate && currencyCode && currencySymbol) {
      dispatch(addToExcRate({ rate: exchangeRate, currencyCode, currencySymbol }));
      sessionStorage.setItem('exchangeRate', JSON.stringify({ rate: exchangeRate, currencyCode, currencySymbol }));
    }
  };

  const clearCartAndData = async () => {
    try {
      for (const product of cart) {
        const formData = new URLSearchParams();
        formData.append('id', product.id);
        await deleteCart(formData);
      }
      
      dispatch(applyCoupon({}));
      dispatch(clearCart());
      localStorage.removeItem('coupon');
      localStorage.removeItem('cart');
      localStorage.removeItem('shippingFees');
    } catch (error) {
      console.error("Error clearing cart:", error);
    }
  };

  return (
    // <Select
    //   value={selectedOption}
    //   style={{ width: 120 }}
    //   dropdownStyle={{ zIndex: 999 }}
    //   className="currency_select"
    //   onChange={handleChange}
    //   options={options}
    // />
    <></>
  );
};

// Helper function to create flag option with an image
const createFlagOption = (countryName, flagUrl, labelText) => (
  <div className="profile_icons_header">
    <img src={flagUrl} alt={`${countryName} Flag`} />
    {labelText}
  </div>
);

export default CurrencySelect;
