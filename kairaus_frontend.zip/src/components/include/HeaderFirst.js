import React, { useEffect, useRef, useState } from "react";
// import logoName from "../../assets/images/KAIRAUS_logo.svg";
import logoName from "../../assets/images/KAIRAUS_logo_383x60.svg";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Badge, Avatar, Tooltip, Dropdown, Space, Drawer, Collapse, Drawer as AntDrawer, Tabs } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { addToUser, clearUser } from "../../reducers/userSlice";
import { clearCart } from "../../reducers/cartSlice";
import { IoIosMenu } from "react-icons/io";
import { PlusOutlined, MinusOutlined, UserOutlined, HomeOutlined, GiftOutlined, LoginOutlined, BarsOutlined, HeartOutlined, } from "@ant-design/icons";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Search from "../../components/forms/Search";
import Routes from "../../Routes/Routes";
import { STRINGS } from "../../constants/Constant";
import DrawerCart from "../drawer/Drawer";
import { applyShipping } from "../../reducers/shippingSlice";
import BulkDrawer from "../drawer/BulkDrawer";
import viewedEye from '../../assets/images/viewed-product.png';
import { addToChip } from "../../reducers/filterSlice";
import CurrencySelect from "./CurrencySelect";
import { addToEventKey } from "../../reducers/eventkeySlice";
import { applyCoupon } from "../../reducers/couponSlice";
import { useMotionValueEvent, useScroll, motion } from "framer-motion";
import { storeLocalCoupon } from "../../reducers/localCouponSlice";

const HeaderFirst = () => {
  const dispatch = useDispatch();
  const cart = useSelector((state) => state.cart);
  const totalProductCount = cart.reduce((total, item) => total + item?.count, 0);
  const user = useSelector((state) => state.user);
  const isLoggedIn = useSelector((state) => state.user);
  const [loggedIn, setLoggedIn] = useState(false);
  const [openCartDrawer, setOpenCartDrawer] = useState(false);
  const navigate = useNavigate();
  // alert(openCartDrawer);
  // const [activeSpan, setActiveSpan] = useState(null);

  // const [subMenuData, setSubMenuData] = useState([]);

  const [dataName, setDataName] = useState();
  const [openCollapse, setOpenCollapse] = useState();
  const [searchIconClick, setSearchIconClick] = useState(false);

  const [openBulk, setOpenBulk] = useState(false);
  const navigationMenu = useSelector((state) => state.navigationMenu);

  const categories_2 = navigationMenu.categories_2 || []; // Set default to empty array if undefined
  const categories_1 = navigationMenu?.categories_1?.filter(item => item.name !== 'About Us') || [];

  const processedData = categories_1.map(item => ({
    ...item,
    child_items: item.child_items.filter(child => child.slug !== item.slug)
  }));
  // console.log("categories_1",categories_1[0]);
  // console.log('categories_1',categories_1);
  // const handlePanelClick = key => {
  //   setActiveKey(activeKey === key ? null : key);
  // };
  const hasMounted = useRef(false);
  const checkLoggedIn = () => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    setLoggedIn(!!(storedUser && storedUser.token));
  };
  const handleLogout = async () => {
    const couponnull = {};
    const logoutEventTimestamp = Date.now().toString();

    localStorage.removeItem("user");
    localStorage.removeItem("cart");
    localStorage.removeItem("shippingFees");
    localStorage.removeItem("FirstOrderCouponDetails");
    localStorage.removeItem("chips");
    localStorage.removeItem('maxPrice');
    localStorage.removeItem('coupon');
    localStorage.removeItem('appliedCoupons');
    localStorage.removeItem('localCoupons');
    localStorage.clear();

    dispatch(applyCoupon(couponnull));
    dispatch(clearUser());
    dispatch(clearCart());
    dispatch(applyShipping(null))
    dispatch(addToChip([]));
    dispatch(storeLocalCoupon([]));


    dispatch(addToUser({ lastLogoutTime: logoutEventTimestamp }));
    localStorage.setItem("logoutEvent", logoutEventTimestamp);
    // dispatch(addToUser(userInfo));
    navigate(Routes.SignIn);
  };
  useEffect(() => {
    checkLoggedIn();
  }, []);

  useEffect(() => {
    if (isLoggedIn.token) {
      setLoggedIn(true);
    } else {
      setLoggedIn(false);
    }

    if (hasMounted.current) return;
    hasMounted.current = true;
  }, [isLoggedIn]);

  const handleDrawerFunc = () => {
    setOpenCartDrawer(true);
    setOpenSearch(false)
  }
  const handleCart = () => {
    handleDrawerFunc();
    // if (cart.length > 0 || (cart.length < 1 && isLoggedIn.token)) {
    //   handleDrawerFunc();
    // } else {
    //   navigate(Routes.SignIn);
    // }
  };
  const previousCartLength = useRef(cart.length);

  useEffect(() => {

    if (cart?.length !== previousCartLength.current) {
      if (cart?.length > 0) {
        handleDrawerFunc();
        previousCartLength.current = cart.length; // Update to the current length
      }

    }
    previousCartLength.current = cart.length; // Update to the current length

  }, [cart]);

  const [open, setOpen] = useState(false);
  const showDrawer = () => {
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
    setOpenCartDrawer(false)
  };
  const handleIconClick = (from) => {
    // console.log(from, "from")
    switch (from) {
      case "Profile":
      case "addresses":
      case "coupons":
      case "orders":
      case "gstInfo":
      case "changePassword":
      case "favourites":
        navigate(user && user.id ? Routes.AccountProfile : Routes.SignIn, { state: { from } });
        break;
      case "viewed":
        navigate(user && user.id ? Routes.Viewed : Routes.SignIn, { state: { from } });
        break;
      case "logout":
        handleLogout();
        break;
      default:
      // handle default case
    }
  };

  const onClosed = (menuSlug) => {
    setDataName(menuSlug);
    setOpen(false);
  };

  const drawerHeader = (
    <div>
      <img
        src={logoName}
        onClick={() => {
          navigate(Routes?.Home);
          onClosed()
        }}
        alt="Drawer Header Image1"
        style={{
          width: "130px",
          maxHeight: "40px",
          objectFit: "cover",
          cursor: "pointer",
        }}
      />
    </div>
  );
  const items = [
    {
      label: (
        <div
          className="profile_icons_header"
          onClick={() => handleIconClick("Profile")}
        >
          <UserOutlined />
          My Profile
        </div>
      ),
      key: "0",
    },
    {
      label: (
        <div
          className="profile_icons_header"
          onClick={() => handleIconClick("orders")}
        >
          <GiftOutlined />
          My Orders
        </div>
      ),
      key: "1",
    },
    {
      label: (
        <div
          className="profile_icons_header"
          onClick={() => handleIconClick("addresses")}
        >
          <HomeOutlined />
          Addresses
        </div>
      ),
      key: "2",
    },
    // {
    //   label: (
    //     <div
    //       className="profile_icons_header"
    //       onClick={() => handleIconClick("gstInfo")}
    //     >
    //       <UserOutlined />
    //       GST Information
    //     </div>
    //   ),
    //   key: "3",
    // },
    {
      label: (
        <div
          className="profile_icons_header"
          onClick={() => handleIconClick("coupons")}
        >
          <BarsOutlined />
          My Coupons
        </div>
      ),
      key: "4", // Corrected key
    },
    {
      label: (
        <div
          className="profile_icons_header"
          onClick={() => handleIconClick("favourites")}
        >
          <HeartOutlined />
          My Favourites
        </div>
      ),
      key: "5",
    },
    {
      label: (
        <div
          className="profile_icons_header"
          onClick={() => handleIconClick("changePassword")}
        >
          <svg width="18" height="18" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M22.8682 24.2982C25.4105 26.7935 26.4138 30.4526 25.4971 33.8863C24.5805 37.32 21.8844 40.0019 18.4325 40.9137C14.9806 41.8256 11.3022 40.8276 8.79375 38.2986C5.02208 34.4141 5.07602 28.2394 8.91499 24.4206C12.754 20.6019 18.9613 20.5482 22.8664 24.3L22.8682 24.2982Z" fill="none" stroke="#333" stroke-width="4" stroke-linejoin="round" /><path d="M23 24L40 7" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" /><path d="M30.3052 16.9001L35.7337 22.3001L42.0671 16.0001L36.6385 10.6001L30.3052 16.9001Z" fill="none" stroke="#333" stroke-width="4" stroke-linejoin="round" /></svg>
          Change Password
        </div>
      ),
      key: "6",
    },
    {
      label: (
        <div
          className="profile_icons_header"
          onClick={() => handleIconClick("logout")}
        >
          <LoginOutlined />
          Log Out
        </div>
      ),
      key: "7",
    },
  ];

  // const handleCollapseClick = async (id) => {
  //   try {
  //     const formData = new URLSearchParams({ menu_id: id });
  //     const { status, data } = await HeaderApi.SubMenu(formData);
  //     if (status == "1") {
  //       // console.log('data===',data)
  //       setSubMenuData(data); // Set the submenu data
  //       // You may not need to update collapseItems here
  //     }
  //   } catch (error) {
  //     console.error("Error fetching submenu:", error);
  //   }
  // };

  const onChange = (key) => {
    // console.log('key===>>>', key)
    setOpenCollapse(key[key.length - 1]);
    // const clickedMenuItem = collapseItems?.find(item => item.key == key);
    // alert(clickedMenuItem.id)

    // if (clickedMenuItem) {
    // handleCollapseClick(key[key.length - 1]); // Call handleCollapseClick with the ID of the clicked menu item
    // }
  };

  const handleSubMenu = (slug, from, route) => {
    navigate(`${Routes.ProductCategory}/${slug}`, { state: { from, route } });
    onClosed();
  }

  const handleSubChild = (slug, from, route) => {
    navigate(`${Routes.ProductCategory}/${slug}`, { state: { from, route } });
    onClosed();
  }



  const [openSearch, setOpenSearch] = useState(false);
  const showSearchDrawer = () => {
    setOpenSearch(true);
  };
  const onCloseSeach = () => {
    setOpenSearch(false);
  };

  const handleItem = (dropDownItem) => {
    if (user?.id) {
      navigate(Routes.AccountProfile, { state: { from: dropDownItem } });
    } else {
      navigate(Routes.SignIn, { state: { from: dropDownItem } })
    }
  }
  const showBulkDrawer = () => {
    setOpenBulk(true);
  };

  const onClosedrawer = () => {
    setOpenBulk(false);
    onClosed();
  };



  const itemsTab = [
    {
      key: '1',
      label: (
        <p>
          Category
        </p>
      ),
      children: (
        <div className='search_other'>
          <Collapse
            onChange={onChange}
            activeKey={openCollapse}
            items={processedData?.filter(i => i?.name != "About Us")?.map((item) => ({
              key: item?.key,
              label: (
                <Link to={item?.slug !== "offers" ? item?.slug : `${Routes?.Collection}/${item?.slug}`} onClick={() => onClosed(item?.slug)}>
                  {item?.name}
                </Link>
              ),
              children: (
                <Collapse
                  defaultActiveKey={item?.key}
                  items={item?.child_items?.map((subItem) => ({
                    key: subItem?.id.toString(),
                    label: (
                      <span
                        onClick={() =>
                          handleSubMenu(subItem?.slug, dataName, subItem?.name)
                        }
                      >
                        {subItem?.name}
                      </span>
                    ),
                    children: (
                      <div>
                        {subItem?.child_items?.map((item, index) => (
                          <p
                            key={index}
                            onClick={() =>
                              handleSubChild(item?.slug, dataName, subItem?.name)
                            }
                          >
                            {item?.name}
                          </p>
                        ))}
                      </div>
                    ),
                  }))}
                  expandIcon={({ isActive }) =>
                    isActive ? <MinusOutlined /> : <PlusOutlined />
                  }
                />
              ),
            }))}
            expandIcon={({ isActive }) =>
              isActive ? <MinusOutlined /> : <PlusOutlined />
            }
          />
        </div>
      ),
    },
    {
      key: '2',
      label: (
        <p>
          Services
        </p>
      ),
      children: (<div className='search_other'>
        <Link to={Routes?.AboutUs} onClick={() => onClosed()}>About Us</Link>
        {/* <Link style={{opacity:0.5,cursor:"not-allowed"}}>Rewards Points</Link> */}
        {/* <Link to={'loyalty-program'} onClick={() => onClosed()}>Loyalty Program</Link> */}
        <Link onClick={showBulkDrawer}>Bulk Order</Link>
        <Link to={Routes?.ContactUs} onClick={() => onClosed()} >Contact Us</Link>
        <Link to={Routes?.Privacy} onClick={() => onClosed()}>Privacy Policy</Link>
      </div>),
    },
  ];
  const handleLogoClick = () => {
    const slug = window.location.href.split('/');
    const storageKey = slug[slug.length - 1];
    if (!storageKey) {
      dispatch(addToEventKey({ storageKey: 'home' })); // Dispatch action with an object containing lastSegment
    }
    navigate(Routes?.Home);
  };
  //   const currentUrl = window.location.pathname;
  //   const [secondLastSegment, lastSegment] = getLastTwoSegments(currentUrl);
  //   const {slug}=useParams();
  //   const from=`${secondLastSegment}/${lastSegment}`;
  //   const handleUserIcon=()=>{
  //  navigate(Routes.SignIn, { state: { from } });
  //   }


  const { scrollY } = useScroll()

  const [logoInHeader, setLogoInHeader] = useState(false)

  useMotionValueEvent(scrollY, "change", (current) => {
    if (current > 350) {
      setLogoInHeader(true)
    } else {
      setLogoInHeader(false)
    }
  });

  // useTransform(scrollYProgress, [0, 1], [""])

  const location = useLocation()
  const [showAni, setShowAni] = useState(false)
  const screenSize = useSelector((state) => state.uiSlice.screenSize);

  useEffect(() => {
    if (location?.pathname == '/') {
      setShowAni(true)
    } else {
      setShowAni(false)
    }
  }, [location])


  return (<>
    <div className="header_first">
      <div className="heading">
        <Row>
          <Col span={8}>
            <div className="track_thrid">
              <div onClick={showDrawer}>
                <svg width="24" height="24" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.94971 11.9497H39.9497" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /><path d="M7.94971 23.9497H39.9497" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /><path d="M7.94971 35.9497H39.9497" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /></svg>
              </div>

              {/* <p onClick={() => handleItem("orders")}><svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 6V42" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /><path d="M11 9H25L32 12H39C40.1046 12 41 12.8954 41 14V31C41 32.1046 40.1046 33 39 33H32L25 30H11V9Z" fill="none" stroke="#333" strokeWidth="4" strokeLinejoin="round" /><path d="M7 42H15" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /></svg>Track Order</p>

              <p onClick={() => navigate(Routes.ContactUs)}><svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M44 8H4V38H19L24 43L29 38H44V8Z" fill="none" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /><path d="M24 23V32" stroke="#333" strokeWidth="4" clipRule="round" /><path d="M24 16V17" stroke="#333" strokeWidth="4" clipRule="round" /></svg>Customer Support</p> */}
            </div>
          </Col>
          {
            showAni ?
              <Col span={8} className="pictures">
                <motion.img
                  src={logoName}
                  onClick={handleLogoClick}
                  alt="Kairaus"
                  style={{ cursor: "pointer", filter: `invert(${logoInHeader ? 0 : 1})` }}
                  initial={{
                    y: "-50vh",
                    width: "90%",
                  }}
                  animate={{
                    y: logoInHeader ? 0 : "-50vh",
                    width: logoInHeader ? "220px" : "90%"
                  }}
                  transition={{
                    duration: 0.4
                  }}
                />
              </Col>
              :
              <Col span={8} className="pictures">
                <motion.img
                  src={logoName}
                  onClick={handleLogoClick}
                  alt="Kairaus"
                  style={{ cursor: "pointer" }}

                />
              </Col>
          }

          <Col span={8}>
            <div className="group_icon">
              <div className="serchButton">
                <Tooltip placement="bottom" title="Search the product">
                  <button onClick={() => { showSearchDrawer(); setSearchIconClick(!searchIconClick) }}>
                    <p>Search</p>
                    <svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 38C30.3888 38 38 30.3888 38 21C38 11.6112 30.3888 4 21 4C11.6112 4 4 11.6112 4 21C4 30.3888 11.6112 38 21 38Z" fill="none" stroke="#333" strokeWidth="3" strokeLinejoin="round" /><path d="M26.657 14.3431C25.2093 12.8954 23.2093 12 21.0001 12C18.791 12 16.791 12.8954 15.3433 14.3431" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /><path d="M33.2216 33.2217L41.7069 41.707" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /></svg>
                  </button>
                </Tooltip>
              </div>
              <CurrencySelect />
              <Tooltip placement="topLeft" title="Viewed">
                <span onClick={() => handleIconClick("viewed")} className="viewedEye">
                  <img src={viewedEye} alt="" />
                </span>
              </Tooltip>

              <Badge count="" offset={[9, -4]}>
                <Tooltip placement="topLeft" title={STRINGS.FAVOURITE}>
                  <span onClick={() => handleIconClick("favourites")}>
                    <svg width="24" height="24" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 8C8.92487 8 4 12.9249 4 19C4 30 17 40 24 42.3262C31 40 44 30 44 19C44 12.9249 39.0751 8 33 8C29.2797 8 25.9907 9.8469 24 12.6738C22.0093 9.8469 18.7203 8 15 8Z" fill="none" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg>
                  </span>
                </Tooltip>
              </Badge>

              <div>
                {loggedIn ? (
                  <Dropdown menu={{ items }}>
                    <Link onClick={(e) => e.preventDefault()}>
                      <Avatar style={{ width: "35px", height: "35px" }}>
                        <span style={{ lineHeight: "224%", textTransform: "uppercase" }}>
                          {user?.userfullname !== null
                            ? user?.userfullname?.charAt(0)
                            : 'N'}
                        </span>
                      </Avatar>
                    </Link>
                  </Dropdown>
                ) : (
                  <Link to={Routes?.SignIn}>
                    {/* SVG for Sign In */}
                    <Space>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="28"
                        height="28"
                        viewBox="0 0 31 30"
                        fill="none"
                      >
                        <circle
                          cx="15.3594"
                          cy="10.0005"
                          r="4.22"
                          stroke="#222222"
                          strokeWidth="1.56"
                        // strokeLinecap="round"
                        />
                        <path
                          d="M6.70747 20.268C7.5155 17.976 9.8991 16.8755 12.3294 16.8755H18.3894C20.8196 16.8755 23.2032 17.976 24.0113 20.268C24.3292 21.1697 24.5914 22.219 24.6911 23.3758C24.7386 23.926 24.2867 24.3755 23.7344 24.3755H6.98438C6.43209 24.3755 5.98015 23.926 6.0276 23.3758C6.12735 22.219 6.38959 21.1697 6.70747 20.268Z"
                          stroke="#222222"
                          strokeWidth="1.56"
                        // strokeLinecap="round"
                        />
                      </svg>
                    </Space>
                  </Link>
                )}
              </div>

              {location?.pathname !== "/mainCheckout" &&
                <Badge count={totalProductCount} offset={[9, -4]}>
                  <Tooltip placement="topLeft" title={screenSize < 400 ? "" : STRINGS.CART}>
                    <span onClick={() => handleCart()}>
                      <svg width="24" height="24" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="10" y="12" width="28" height="30" rx="3" fill="none" stroke="#333" strokeWidth="3" strokeLinejoin="round" /><path d="M30 18V10C30 6.68629 27.3137 4 24 4V4C20.6863 4 18 6.68629 18 10V18" stroke="#333" strokeWidth="3" clipRule="round" strokeLinejoin="round" /></svg>
                    </span>
                  </Tooltip>
                </Badge>}
            </div>
          </Col>
        </Row>
      </div >
    </div >
    <div className="header_mediaScreen">
      <div className="headerPhone_screen">
        <ul className="header-list">
          <li className="menu_icon" onClick={showDrawer}>
            <IoIosMenu />
          </li>
        </ul>
        <Link to={Routes.Home}>
          <img src={logoName} alt="Kairaus" className="logoName" />
        </Link>
        <div className="group_icon">
          <div className="serchButton">
            <Tooltip placement="bottom" title={screenSize < 400 ? "" : "Search the product"}>

              <button onClick={() => { showSearchDrawer(); setSearchIconClick(!searchIconClick) }}>
                {/* <p>Search</p> */}
                <svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21 38C30.3888 38 38 30.3888 38 21C38 11.6112 30.3888 4 21 4C11.6112 4 4 11.6112 4 21C4 30.3888 11.6112 38 21 38Z" fill="none" stroke="#333" strokeWidth="3" strokeLinejoin="round" /><path d="M26.657 14.3431C25.2093 12.8954 23.2093 12 21.0001 12C18.791 12 16.791 12.8954 15.3433 14.3431" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /><path d="M33.2216 33.2217L41.7069 41.707" stroke="#333" strokeWidth="4" clipRule="round" strokeLinejoin="round" /></svg>

              </button>
            </Tooltip>
          </div>
          <div>
            {loggedIn ? (
              <Dropdown menu={{ items }}>
                <Link onClick={(e) => e.preventDefault()}>
                  <Avatar style={{ width: "35px", height: "35px" }}>
                    <span style={{ lineHeight: "224%", textTransform: "uppercase" }}>
                      {user?.userfullname !== null
                        ? user?.userfullname?.charAt(0)
                        : user?.userfullname?.charAt(0)}
                    </span>
                  </Avatar>
                </Link>
              </Dropdown>
            ) : (
              <Link to={Routes?.SignIn}>
                {/* SVG for Sign In */}
                <Space>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="28"
                    height="28"
                    viewBox="0 0 31 30"
                    fill="none"
                  >
                    <circle
                      cx="15.3594"
                      cy="10.0005"
                      r="4.22"
                      stroke="#222222"
                      strokeWidth="1.56"
                    // strokeLinecap="round"
                    />
                    <path
                      d="M6.70747 20.268C7.5155 17.976 9.8991 16.8755 12.3294 16.8755H18.3894C20.8196 16.8755 23.2032 17.976 24.0113 20.268C24.3292 21.1697 24.5914 22.219 24.6911 23.3758C24.7386 23.926 24.2867 24.3755 23.7344 24.3755H6.98438C6.43209 24.3755 5.98015 23.926 6.0276 23.3758C6.12735 22.219 6.38959 21.1697 6.70747 20.268Z"
                      stroke="#222222"
                      strokeWidth="1.56"
                    // strokeLinecap="round"
                    />
                  </svg>
                </Space>
              </Link>
            )}
          </div>

          {location?.pathname !== "/mainCheckout" &&
            <Badge count={cart?.length} offset={[9, -4]}>
              <Tooltip placement="topLeft" title={screenSize < 400 ? "" : STRINGS.CART}>
                <span onClick={() => handleCart()}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="26"
                    height="26"
                    viewBox="0 0 32 28"
                    fill="none"
                  >
                    <path
                      d="M11.7235 22.6248C10.4091 22.6248 9.33984 23.8112 9.33984 25.2696C9.33984 26.728 10.4091 27.9145 11.7235 27.9145C13.0378 27.9145 14.1071 26.728 14.1071 25.2696C14.1071 23.8112 13.0378 22.6248 11.7235 22.6248ZM11.7235 26.4376C11.143 26.4376 10.6707 25.9136 10.6707 25.2695C10.6707 24.6254 11.143 24.1014 11.7235 24.1014C12.3039 24.1014 12.7762 24.6255 12.7762 25.2695C12.7762 25.9137 12.3039 26.4376 11.7235 26.4376Z"
                      fill="black"
                    />
                    <path
                      d="M20.0868 22.6248C18.7725 22.6248 17.7031 23.8112 17.7031 25.2696C17.7031 26.728 18.7725 27.9145 20.0868 27.9145C21.4012 27.9145 22.4705 26.728 22.4705 25.2696C22.4705 23.8112 21.4011 22.6248 20.0868 22.6248ZM20.0868 26.4376C19.5063 26.4376 19.0341 25.9136 19.0341 25.2695C19.0341 24.6254 19.5064 24.1014 20.0868 24.1014C20.6673 24.1014 21.1396 24.6255 21.1396 25.2695C21.1396 25.9137 20.6673 26.4376 20.0868 26.4376Z"
                      fill="black"
                    />
                    <path
                      d="M20.6706 8.69971H11.1342C10.7667 8.69971 10.4688 9.03028 10.4688 9.43809C10.4688 9.8459 10.7667 10.1765 11.1342 10.1765H20.6706C21.0381 10.1765 21.3361 9.8459 21.3361 9.43809C21.3361 9.03022 21.0381 8.69971 20.6706 8.69971Z"
                      fill="black"
                    />
                    <path
                      d="M20.1521 12.5342H11.6537C11.2862 12.5342 10.9883 12.8648 10.9883 13.2726C10.9883 13.6804 11.2862 14.0109 11.6537 14.0109H20.152C20.5196 14.0109 20.8175 13.6804 20.8175 13.2726C20.8175 12.8648 20.5196 12.5342 20.1521 12.5342Z"
                      fill="black"
                    />
                    <path
                      d="M27.1633 5.40979C26.9096 5.06418 26.5335 4.866 26.1316 4.866H5.40308L4.98446 2.61113C4.89706 2.14077 4.60792 1.74582 4.21085 1.55451L1.28997 0.147749C0.952764 -0.0147774 0.560875 0.156912 0.414612 0.530951C0.268189 0.905108 0.422923 1.34 0.759969 1.50229L3.6809 2.90911L6.90082 20.252C7.02765 20.935 7.57586 21.4307 8.20438 21.4307H24.1471C24.5146 21.4307 24.8125 21.1001 24.8125 20.6923C24.8125 20.2845 24.5146 19.9539 24.1471 19.9539H8.20443L7.81275 17.8443H24.2703C24.8988 17.8443 25.447 17.3486 25.5738 16.6656L27.4352 6.64058C27.5163 6.20404 27.4172 5.75535 27.1633 5.40979ZM24.2703 16.3677H7.5386L5.6773 6.34272L26.1316 6.34278L24.2703 16.3677Z"
                      fill="black"
                    />
                    {/* <circle cx="27.8594" cy="5.58643" r="3.5" fill="#1D3557" /> */}
                  </svg>
                </span>
              </Tooltip>
            </Badge>
          }
        </div>
      </div>
    </div>
    {openCartDrawer && <DrawerCart onClose={onClose} openDrawer={openCartDrawer} />}
    <Drawer
      title={drawerHeader}
      onClose={onClosed}
      open={open}
      placement="left"
      width={420}
      className="drwawe_list_submenu"
    >
      <div className="titles_acd">
        <Collapse
          onChange={onChange}
          activeKey={openCollapse}
          items={categories_1?.map((item) => ({
            key: item?.key,
            label: (
              <Link to={item?.slug !== "offers" ? item?.slug : `${Routes?.Collection}/${item?.slug}`} onClick={() => onClosed(item?.slug)}>
                {item?.name}
              </Link>
            ),
            children: (
              <Collapse
                defaultActiveKey={item?.key}
                items={item?.child_items?.map((subItem) => ({
                  key: subItem?.id.toString(),
                  label: (
                    <span
                      onClick={() =>
                        handleSubMenu(subItem?.slug, dataName, subItem?.name)
                      }
                    >
                      {subItem?.name}
                    </span>
                  ),
                  children: (
                    <div>
                      {subItem?.child_items?.map((item, index) => (
                        <p
                          key={index}
                          onClick={() =>
                            handleSubChild(item?.slug, dataName, subItem?.name)
                          }
                        >
                          {item?.name}
                        </p>
                      ))}
                    </div>
                  ),
                }))}
                expandIcon={({ isActive }) =>
                  isActive ? <MinusOutlined /> : <PlusOutlined />
                }
              />
            ),
          }))}
          expandIcon={({ isActive }) =>
            isActive ? <MinusOutlined /> : <PlusOutlined />
          }
        />
      </div>

      <div className="mimimal_screens">
        <Tabs defaultActiveKey="1" items={itemsTab} onChange={onChange} />
      </div>
    </Drawer>

    <AntDrawer onClose={onCloseSeach} open={openSearch} className="search_header" width={650}>
      <Search onCloseSeach={onCloseSeach} openSearch={openSearch} searchIconClick={searchIconClick} />
    </AntDrawer>

    {openBulk && <BulkDrawer onClose={onClosedrawer} openDrawer={openBulk} productId={'0'} />}

  </>
  );
};

export default HeaderFirst;
