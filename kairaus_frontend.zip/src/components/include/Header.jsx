import React, { useEffect, useState, useRef, useCallback } from "react";
import rectangle from "../../assets/images/Rectangle 4290.png";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { HeaderApi } from "../../services/Master";
import { Skeleton, Carousel } from "antd";
import Routes from "../../Routes/Routes";
import HeaderFirst from "./HeaderFirst";
import { getFirstOrderCoupon } from "../../services/coupon/Coupon";
import { useDispatch, useSelector } from "react-redux";
import { getCart } from "../../services/cart/addCart";
import { addToCart, clearCart } from "../../reducers/cartSlice";
import { setSliceMenuData } from "../../reducers/menuSlice";
import headerSec from '../../assets/images/home decor12.jpg'
import { getApplyCouponData } from "../../services/coupon/applyCoupon";
import { storeLocalCoupon } from "../../reducers/localCouponSlice";

function Header() {
  const [isHovering, setIsHovering] = useState(false);
  const [menuData, setMenuData] = useState([]);
  const [menuCategory, setMenuCategory] = useState([]);
  const [headerOffer, setHeaderOffer] = useState('');
  const [menuName, setMenuName] = useState(null);
  const user = useSelector((state) => state.user);
  const { token } = user;
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const hasMounted = useRef(false);
  const imgPath = useRef(); // Using ref to store imgPath without triggering re-renders
  const localCoupons = useSelector((state) => state.localCoupon);


  // Fetch cart data
  useEffect(() => {
    if (!token) return;

    const getCartDataFromDB = async () => {
      try {
        const result = await getCart(token);
        if (result.status === "1" && result?.data?.length > 0) {
          const cartItems = result.data.map(item => {
            const { id, product_name, product_slug, is_wishlist, price, compare_price, stock_quantity, subtotal_amount, usd_price, usd_compare_price } = item.product;
            const image = item.product.productimages.length > 0
              ? `${result.path}${item.product.productimages[0].file_name}`
              : '';
            return {
              id,
              product_name,
              product_slug,
              is_wishlist,
              image,
              price,
              compare_price,
              usd_price,
              usd_compare_price,
              count: item.quantity,
              p_variant_id: item.product_variant_id,
              stock_quantity,
              subtotal_amount,
              isChecked: item.status === 1
            };
          });

          localStorage.setItem('cart', JSON.stringify(cartItems));
          dispatch(addToCart(cartItems));
          // applyCouponData();
        } else {
          localStorage.removeItem("cart");
          dispatch(clearCart());
        }
      } catch (error) {
        console.error('Failed to fetch cart data', error);
      }
    };

    getCartDataFromDB();
  }, [token]);

  // Fetch menu data
  const fetchData = useCallback(async () => {
    try {
      const formData = new URLSearchParams({ category_id: '1' });
      const menuResponse = await HeaderApi.Master(formData);
      if (menuResponse?.status === '1') {
        imgPath.current = menuResponse.category_path;
        const { categories_1 = [], categories_2 = [], categories_3 = [], categories_4 = [] } = menuResponse?.data || {};
        dispatch(setSliceMenuData({ menu_img_path: imgPath.current, categories_1, categories_2, categories_3, categories_4 }));
        setMenuData(categories_1);
        if (categories_1.length > 0) {
          const slugData = categories_1.map(item => item.slug).filter(Boolean);
          sessionStorage.setItem('menuSlug', JSON.stringify(slugData));
        }
      }
    } catch (error) {
      console.error("Error in MenuComponent:", error);
    }
  }, [dispatch]);

  useEffect(() => {
    if (hasMounted.current) return;
    fetchData();
    hasMounted.current = true;
  }, [fetchData]);

  // Fetch coupon for first order
//   const applyCouponData=async(couponcode)=>{
    
//     const coupon_code = localCoupons?.map(coupon => coupon.coupon_code).join(',')||[];
//     const newcode=coupon_code.length>0?coupon_code:couponcode
//     try {
      
//         const formData = new URLSearchParams();
//         formData.append('coupon_code', newcode);
//         const response=await getApplyCouponData(formData,user?.token);
        
//           dispatch(storeLocalCoupon(response?.data));
//         // console.log("responseresponseresponseresponse",response);
        
//       } catch (error) {
//         // toast.error("Please try again later.");
//           // console.error('Error applying coupon:', error.response);
//       }	
// }
  useEffect(() => {
    const getCouponForFirstOrder = async () => {
      try {
        const formData = new URLSearchParams();
        formData.append('user_id', user?.id ? user?.id : 0);
        const result = await getFirstOrderCoupon(formData);
        if (result?.status === '1') {
          setHeaderOffer(result?.order_count >= 0 ? result?.data?.coupon_desc : '');
          localStorage.setItem('FirstOrderCouponDetails', JSON.stringify(result));
         if(result?.order_count == 0){
          if(user?.id){
            // const coupon_code = localCoupons?.map(coupon => coupon.coupon_code).join(',')||[];
            // coupon_code.length < 1&&applyCouponData(result?.data?.coupon_code)
            
          }
          
          // dispatch(storeLocalCoupon(result.data));
         }
        //  else{
        //   const updatedCoupons = localCoupons.filter(coupon => coupon.id !== result?.data?.id);
        //   dispatch(storeLocalCoupon(updatedCoupons));
        //  }
        }
      } catch (error) {
        console.error('Error fetching coupon', error);
      }
    };

    getCouponForFirstOrder();
  }, [user]);

  const handleMouseOver = (childItems, menuSlug, subImg, slugData) => {
    setMenuName({ menu: menuSlug, img: subImg, imageSlug: slugData });
    setMenuCategory(childItems);
  };

  const handleSubMenu = (slug, from, menuSlug) => {
    navigate(`${Routes.ProductCategory}/${slug}`, { state: { from, menuSlug } });
    setIsHovering(false);
    setMenuCategory([]);
  };

  const location = useLocation()

  return (
    <>
      <div className='off_heading'>
        <Carousel autoplay vertical>
          {headerOffer && <span>{headerOffer}</span>}
          <span>Break-free deliveries guaranteed</span>
          <span>1000+ New Arrivals Await</span>
          <span>
            Up To 50% Off!
            <a href={`${Routes?.Collection}/offers`}>Shop now!</a>
          </span>
        </Carousel>
      </div>
      {
        location.pathname == '/' &&
        <div className="main-top-banner"></div>
      }

      <header>
        <HeaderFirst />
        <div className="header_second">
          {menuData?.length > 0 ? (
            <ul className="header-list">
              {menuData?.map((item) => (
                <li
                  key={item.id}
                  onMouseOver={() => setIsHovering(true)}
                  onMouseOut={() => setIsHovering(false)}
                  className="gifts_bows"
                >
                  <Link
                    to={item.slug !== "offers" ? item?.slug : `${Routes?.Collection}/${item?.slug}`}
                    onMouseOver={item?.menus?.menu_type !== "2" ? () => handleMouseOver(item?.child_items, item.name, item?.menus.header_image, item?.slug) : () => setMenuCategory([])}
                  >
                    {item?.menus?.show_type === 2 ? (
                      <img src={`${imgPath.current}${item?.menus?.icon_image}`} alt={item.name} />
                    ) : item.name}
                  </Link>

                  <div className={`hovar_bar ${menuCategory.length > 0 && isHovering ? "show" : ""}`}>
                    <div className="inner_content">
                      <div className="menu_new_items">
                        <div className="menu_cato">
                          {menuCategory?.map((sub, index) => (
                            <div key={index} className="bar">
                              <h4 onClick={() => handleSubMenu(sub.slug, menuName?.menu, menuName?.imageSlug)}>{sub.name}</h4>
                              <ul>
                                {sub?.child_items.map((subItem, subIndex) => (
                                  <li key={subIndex}>
                                    <Link
                                      to={`${Routes.ProductCategory}/${subItem.slug}`}
                                      state={{ from: menuName?.menu, route: sub.name, menuSlug: menuName?.imageSlug, categorySlug: sub.slug }}
                                    >
                                      {subItem.name}
                                    </Link>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="innser_allitem">
                        <Link to={menuName?.imageSlug}>
                          <div className="img_Nav">
                            {menuCategory.length === 4 ? (
                              <img className="image_one"
                                src={menuName?.img ? imgPath.current + menuName.img : rectangle}
                                alt={item.menu_name}
                              />
                            ) : (
                              <>
                                <img className="image_one"
                                  src={menuName?.img ? imgPath.current + menuName.img : rectangle}
                                  alt={item.menu_name}
                                />
                                <img className="iamge_sec"
                                  src={headerSec}
                                  alt={item.menu_name}
                                />
                              </>
                            )}
                          </div>
                          <div className="all_headerBtn">
                            <span>{menuName?.menu} {">>"}</span>
                            <Link to={`${Routes?.AllItems}/${menuName?.imageSlug}`} className="allContentHeader">
                              <span className="cpntnet_p">All Items</span>
                            </Link>
                          </div>
                        </Link>
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div style={{ display: "flex", gap: "20px", justifyContent: "space-between", alignItems: "center", width: "100%", padding: "10px 0" }}>
              <Skeleton.Button size="small" shape="circle" active />
              {Array.from({ length: 7 }).map((_, idx) => (
                <Skeleton.Input key={idx} size="small" style={{ height: "14px" }} active />
              ))}
            </div>
          )}
        </div>
      </header>
    </>
  );
}

export default Header;
