import React, { useEffect, useState } from "react";
import { getProductCoupon } from "../services/coupon/Coupon";
import { useDispatch, useSelector } from "react-redux";
import { updateProductCoupon, updateProductCouponOffer } from "../services/cart/addCart";
import { applyProductCoupon, clearProductCoupon } from "../reducers/productcouponSlice";
import { Modal } from 'antd';
import LoaderLottie from '../assets/images/coupons.json';
import LoaderLottieed from '../assets/images/checked.json';
import codLottie from '../assets/images/codd.png';
import shippIng from '../assets/images/shippingg.png';
import lampFest from '../assets/images/lamp.png'
import Lottie from 'react-lottie';
import { storeLocalCoupon } from "../reducers/localCouponSlice";
import { getApplyCouponData, removeCoupon } from "../services/coupon/applyCoupon";

const ProductCoupon = ({ productDetails }) => {
    const [productCouponList, setProductCouponList] = useState([]);
    const [error, setError] = useState(null);
    const { id, token } = useSelector(state => state.user);
    const [isCouponApplied, setIsCouponApplied] = useState(false);
    const [appliedCouponCode, setAppliedCouponCode] = useState(null);
    const cart = useSelector((state) => state.cart);
    // console.log('cart',cart.id);  
    const dispatch = useDispatch();
    // console.log('isProductInCart',isProductInCart);
    const productCoupon = useSelector(state => state.productCoupon);
    const { currencyCode, currencySymbol, rate = 1 } = useSelector(state => state.excrate);
    const isINR = currencyCode === "INR";
    const [appliedPrice, setAppliedPrice] = useState(null);
    const { order_count } = (JSON.parse(localStorage.getItem('FirstOrderCouponDetails'))) || {};
    const localCoupons = useSelector((state) => state.localCoupon);
    // Reset appliedPrice to null when currencyCode, currencySymbol, or rate change
    // useEffect(() => {
    //     setAppliedPrice(null);
    //     setAppliedCouponCode(null);
    //     setAppliedCouponCode(null);
    //     sessionStorage.removeItem(`coupon_${productDetails.id}`);
    //     sessionStorage.removeItem(`appliedPrice_${productDetails.id}`);
    // }, [currencyCode, currencySymbol, rate]);

    // useEffect(() => {
    //     const fetchData = async () => {
    //         try {
    //             const formData = new URLSearchParams();
    //             formData.append('product_id', productDetails.id);
    //             formData.append('user_id', id ? id : 0);
    //             const response = await getProductCoupon(formData);
    //             // console.log('response',response);
    //             if (response.status === '1') {
    //                 setProductCouponList(response.data);
    //                 setError(null);
    //             }
    //             const storedCouponCode = sessionStorage.getItem(`coupon_${productDetails.id}`);
    //             const storedNewPrice = sessionStorage.getItem(`appliedPrice_${productDetails.id}`);
    //             if (storedCouponCode && storedNewPrice) {
    //                 setAppliedCouponCode(storedCouponCode);
    //                 setAppliedPrice(storedNewPrice);
    //             }
    //             if (productCoupon && !storedCouponCode) {
    //                 dispatch(clearProductCoupon());
    //             }
    //             if (storedCouponCode && response?.couponDetails?.subtotal_amount) {
    //                 dispatch(clearProductCoupon());
    //                 sessionStorage.removeItem(`coupon_${productDetails.id}`);
    //                 sessionStorage.removeItem(`appliedPrice_${productDetails.id}`);
    //             }
    //             if (response?.couponDetails?.subtotal_amount) {
    //                 setIsCouponApplied(true);
    //                 setAppliedPrice(response?.couponDetails?.subtotal_amount);
    //                 setAppliedCouponCode(response?.couponDetails?.coupon_code);
    //             }

    //         } catch (error) {
    //             setError('Error fetching data');
    //         }
    //     };

    //     fetchData();
    // }, [productDetails, id]);

    // Handle coupon application
    // const handleCopyClick = async (couponCode, coupon_type, type_val) => {
    //     const coupon_Code = isCouponApplied && appliedCouponCode === couponCode ? "" : couponCode;
    //     // const convertedPrice = usd_price * (rate ?? 1) * count;
    //     const isProductInCart = cart.some(item => item.id === productDetails.id);

    //     if (!isProductInCart) {
    //         const product_id = productDetails.id;
    //         if (coupon_Code === "") {
    //             setIsCouponApplied(false);
    //             setAppliedCouponCode(null);
    //             sessionStorage.removeItem(`coupon_${product_id}`);
    //             sessionStorage.removeItem(`appliedPrice_${product_id}`);
    //             dispatch(clearProductCoupon());
    //         } else {
    //             setIsCouponApplied(true);
    //             setAppliedCouponCode(coupon_Code);
    //             dispatch(applyProductCoupon(coupon_Code));
    //             sessionStorage.setItem(`coupon_${product_id}`, coupon_Code);
    //             // Calculate discount based on coupon type

    //             // Calculate discount amount
    //             const discountAmount = coupon_type === 'percent'
    //                 ? isINR
    //                     ? productDetails.price * (type_val / 100)
    //                     : productDetails.usd_price * (rate ?? 1) * (type_val / 100)
    //                 : type_val;
    //             // Calculate applied price
    //             const appliedPrice = isINR
    //                 ? productDetails.price - discountAmount
    //                 : productDetails.usd_price * (rate ?? 1) - discountAmount;

    //             setAppliedPrice(appliedPrice);
    //             // Store the applied price in sessionStorage
    //             sessionStorage.setItem(`appliedPrice_${product_id}`, appliedPrice);
    //         }
    //     }
    //     try {
    //         const formData = new URLSearchParams({
    //             product_id: productDetails.id,
    //             coupon_code: coupon_Code,
    //         });
    //         if (appliedCouponCode || isProductInCart) {
    // const productCouRes = await updateProductCoupon(formData, token);
    //             if (productCouRes.data.status === "1") {
    //                 setIsCouponApplied(true);
    //                 setAppliedPrice(productCouRes?.data?.finalAmount);
    //                 setAppliedCouponCode(couponCode);
    //                 dispatch(applyProductCoupon(coupon_Code));
    //                 sessionStorage.setItem(`coupon_${productDetails.id}`, coupon_Code);
    //             } else if (productCouRes.data.status === "0") {
    //                 sessionStorage.removeItem(`coupon_${productDetails.id}`);
    //                 setIsCouponApplied(false);
    //                 setAppliedCouponCode(null);
    //             } else if (productCouRes.data.status === "2") {
    //                 // toast.error(productCouRes?.data?.message);
    //                 Modal.info({
    //                     title: 'Kairaus Say',
    //                     content: (
    //                         <div>
    //                             <p>{productCouRes?.data?.message}</p>
    //                         </div>
    //                     ),
    //                 });
    //                 console.log('clicked');
    //                 setIsCouponApplied(false);
    //                 setAppliedCouponCode(null);
    //             }
    //         }

    //     } catch (error) {
    //         console.error("Cart Updating error:", error);
    //     }
    // }

    const fetchData = async () => {
        try {
            const formData = new URLSearchParams();

            formData.append('user_id', '5');
            // formData.append('user_id', (id) ? id : '5');
            const response = await updateProductCouponOffer(formData);
            if (response?.data?.status === '1') {
                setProductCouponList(response?.data?.coupon);
                setError(null);
            }
            // const storedCouponCode = sessionStorage.getItem(`coupon_${productDetails.id}`);
            // const storedNewPrice = sessionStorage.getItem(`appliedPrice_${productDetails.id}`);
            // if (storedCouponCode && storedNewPrice) {
            //     setAppliedCouponCode(storedCouponCode);
            //     setAppliedPrice(storedNewPrice);
            // }
            // if (productCoupon && !storedCouponCode) {
            //     dispatch(clearProductCoupon());
            // }
            // if (storedCouponCode && response?.couponDetails?.subtotal_amount) {
            //     dispatch(clearProductCoupon());
            //     sessionStorage.removeItem(`coupon_${productDetails.id}`);
            //     sessionStorage.removeItem(`appliedPrice_${productDetails.id}`);
            // }
            // if (response?.couponDetails?.subtotal_amount) {
            //     setIsCouponApplied(true);
            //     setAppliedPrice(response?.couponDetails?.subtotal_amount);
            //     setAppliedCouponCode(response?.couponDetails?.coupon_code);
            // }

        } catch (error) {
            setError('Error fetching data');
        }
    };

    useEffect(() => {


        fetchData();
    }, []);

    const defaultOptions = {
        loop: true,
        autoplay: true,
        animationData: LoaderLottie,
        rendererSettings: {
            preserveAspectRatio: 'xMidYMid slice'
        }
    };

    const defaultOptionsed = {
        loop: true,
        autoplay: true,
        animationData: LoaderLottieed,
        rendererSettings: {
            preserveAspectRatio: 'xMidYMid slice'
        }
    };

    const [isClicked, setIsClicked] = useState(false);

    const handleClick = async (couponId, coupon) => {
        setIsClicked(true);
       let clickedCoupon =  productCouponList?.find(item=>item?.id == couponId);

        // Get the IDs from the localCoupon array
        const localCouponIds = localCoupons?.map((coupon) => coupon.id) || [];
        // localCouponIds = Array.isArray(localCouponIds) ? localCouponIds : [];
        if (localCouponIds.length > 1) {
            Modal.info({
                title: 'Kairaus Say',
                content: (
                    <div>
                        <p>You can only apply a maximum of two coupons at a time. Please remove an existing coupon to apply a new one.</p>
                    </div>
                ),
            });
            return
        }
        if (!token) {
            const updateLocalCoupon = Array.isArray(localCoupons) ? [...localCoupons, clickedCoupon] : [clickedCoupon];
            dispatch(storeLocalCoupon(updateLocalCoupon));
            return;
        }
        try {
            // Prepare the form data
            const coupon_code = localCoupons?.map(coupon => coupon.coupon_code);
            const updated_coupon_code = [...coupon_code, coupon].join(','); // join array elements with a comma and space

            const formData = new URLSearchParams();
            formData.append('coupon_code', updated_coupon_code);

            // Fetch the coupon application result
            const response = await getApplyCouponData(formData, token);
            if (response?.status === '1') {
                dispatch(storeLocalCoupon(response?.data));
                // Mark that a product coupon has been applied
            } else if (response?.status === '0') {
                Modal.info({
                    title: 'Kairaus Say',
                    content: (
                        <div>
                            <p>{response.message}</p>
                        </div>
                    ),
                });
                // toast.error(response.message);
            }
        } catch (error) {
            if (error?.response?.data?.status === '0') {
                // toast.error("Please try again later.");
                console.error('Error applying coupon:', error.response);
            }
        }

    };
    const handleRemove = async(couponId) => {
      
            const updatedCoupons = localCoupons.filter(coupon => coupon.id !== couponId);
            
            // localStorage.setItem('localCoupons', JSON.stringify(updatedCoupons));
              
            if (!token) {
                dispatch(storeLocalCoupon(updatedCoupons));
                return;
              }
            try {
              // Rmove coupon To DB
              const formData = new URLSearchParams();
              formData.append('coupon_id', couponId);
              await removeCoupon(formData,token);
              dispatch(storeLocalCoupon(updatedCoupons));
            } catch (error) {
              console.error('Failed to remove coupon:', error);
            }
          
        
        //
    }

    // console.log('localCoupons?.some((localcoupon) => localcoupon.id === coupon.id)',localCoupons?.some((localcoupon) => localcoupon.id === 12));
    

    return (
        <>
            {/* {productCouponList?.length > 0 && (
                <div className='coupons_containers'>
                    <h4>Best offers for you!</h4>
                    {error && <div>Error: {error}</div>}
                    <div className='product_best_offer_row'>
                        {productCouponList?.map(item => (
                            <div key={item.coupon_code} className='product_best_offer_item'>
                                <div className='product_best_offer_info'>
                                    <strong>{item?.coupon_desc}</strong>
                                </div>
                                <div className='product_best_offer_code'>
                                     <span className='code_info'>Use Code:</span> 
                                    <div className={appliedCouponCode === item.coupon_code ? 'offer_code appliedOffer' : 'offer_code'}>
                                        <span className='copy_code' onClick={() => handleCopyClick(item?.coupon_code, item?.coupon_type, item?.type_val)}>
                                            <div className='applied_span'>
                                                {appliedCouponCode === item.coupon_code ? <p>COUPON APPLIED!</p> : item?.coupon_code}
                                            </div>
                                        </span>
                                    </div>
                                    {appliedCouponCode === item.coupon_code &&
                                        <div className='applied_couponsSpan'>
                                            <h6><span>After applying the coupon, Your New Price :</span> ₹{appliedPrice}  </h6>
                                        </div>}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )} */}
            <div className='coupons_containers'>
                <h4>Best offers for you!</h4>
                {error && <div>Error: {error}</div>}
                <div className='product_best_offer_row'>
                    {order_count === 0 ? (<div className='product_best_offer_item'>
                        <div className='product_best_offer_info'>
                            <Lottie options={defaultOptions}
                                max-height={30}
                                width={30}
                                style={{ maxHeight: 30, width: 30, margin: "0px 5px 0px 0px" }}
                            />
                            <strong>
                                First time here? Get an extra 5% off on your cart.
                            </strong>
                        </div>
                        <div className='applied_span'>
                            {/* <p>Offer Applied!</p> */}
                            { localCoupons?.some((localcoupon) => localcoupon.id === 9)?(<p>Offer Applied! </p>):(<p>Available </p>)}

                        </div>
                    </div>) : (<div className='product_best_offer_item redeemedText'>
                        <div className='product_best_offer_info'>
                            <Lottie options={defaultOptions}
                                max-height={30}
                                width={30}
                            />
                            <strong>
                                First time here? Get an extra 5% off on your cart.
                            </strong>
                        </div>
                        <div className='applied_span'>
                            <p>Offer Redeemed!</p>
                        </div>
                    </div>)}
                    {productDetails?.discount > 0 &&
                        <div className='product_best_offer_item'>
                            <div className='product_best_offer_info'>
                                <Lottie options={defaultOptionsed}
                                    style={{ maxHeight: 30, width: 30, margin: "0px 5px 0px 0px" }}
                                />

                                <strong>Cheers! You’ve unlocked a {productDetails?.discount}% discount—happy shopping!</strong>
                            </div>
                            <div className='applied_span'>
                                <p>Offer Applied! </p>
                            </div>
                        </div>}
                    {
                        productCouponList?.map((coupon, index) => {
                            return (
                                <div className='product_best_offer_item'>
                                    <div className='product_best_offer_info'>
                                        <img src={lampFest} alt="" style={{ maxHeight: 28, width: 28, margin: "0px 8px 0px 0px" }} />
                                        <strong>
                                            {coupon.coupon_desc}
                                        </strong>
                                    </div>
                                    <div>
                                        {
                                            localCoupons?.some((localcoupon) => localcoupon.id === coupon.id) ? (
                                                <div
                                                    className='applied_span'
                                                    onClick={() => handleRemove(coupon.id)}
                                                >
                                                    <span className='copy_code'>
                                                        <div className='applied_span'>
                                                            <p>COUPON APPLIED!</p>
                                                        </div>
                                                    </span>
                                                </div>
                                            ) : (
                                                <div
                                                    className='applied_span'
                                                    onClick={() => handleClick(coupon.id, coupon.coupon_code)}
                                                >
                                                    <span className='copy_code'>
                                                        <div className='applied_span'>
                                                            <p>APPLY COUPON!</p>
                                                        </div>
                                                    </span>
                                                </div>
                                            )
                                        }



                                    </div>
                                </div>
                            )
                        })
                    }


                    {/* <div className='product_best_offer'>
                        <div className='product_best_offer_info'>
                            <img src={codLottie} alt="" style={{ maxHeight: 30, width: 30, margin: "0px 8px 0px 0px" }} />

                            <strong>Shop hassle-free with our COD - Cash on Delivery option.</strong>
                        </div>
                    </div> */}
                    {/* <div className='product_best_offer'>
                        <div className='product_best_offer_info'>
                            <img src={shippIng} alt="" style={{ maxHeight: 30, width: 30, margin: "0px 8px 0px 0px" }} />
                            <strong>
                                Enjoy Free shipping on orders over ₹1000. </strong>
                        </div>
                    </div> */}
                </div>
            </div>
        </>
    );
}

export default React.memo(ProductCoupon);
