import { Spin } from 'antd';
import React, { memo } from 'react';
import { useSelector } from 'react-redux';

const ProductPrice = ({ product }) => {
    const { currencyCode, currencySymbol, rate = 1 } = useSelector(state => state.excrate);
    const {
        price = 0,
        compare_price = 0,
        usd_price = 0,
        usd_compare_price = 0,
        newPrice = 0,
        count = 1,
    } = product || {};

    const isINR = currencyCode === "INR";
    const isUSD = currencyCode === "USD";
    const displayPrice = newPrice || price;
    const updatePrice = displayPrice * count;
    const convertedPrice = usd_price * (rate ?? 1) * count;
    const showComparePrice = compare_price > 0 && parseFloat(price) !== parseFloat(compare_price);
    const convertedComparePrice = usd_compare_price * (rate ?? 1) * count;
    const displaySymbol = currencySymbol || currencyCode;

    if (displaySymbol === undefined) {
        return <Spin />;
    }

    return (
        <>
            <span>
                {isINR
                    ? `₹${Math.round(updatePrice)}`
                    : `${displaySymbol} ${Math.round(convertedPrice)}`} 
                {(!isUSD && !isINR) && `/ USD ${Math.round(usd_price)}`}
            </span>
            {showComparePrice && (
                <p>
                    {isINR
                        ? `₹${Math.round(compare_price * count)}`
                        : usd_compare_price > 0 && `${displaySymbol} ${Math.round(convertedComparePrice)}`}
                </p>
            )}
        </>
    );
};

export default memo(ProductPrice);
