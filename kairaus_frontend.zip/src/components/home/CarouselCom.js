import React, { useState, memo } from 'react';
import { Carousel } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const CarouselCom = ({ sliderList }) => {
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

  // Check if sliderList and sliderList.data exist and are not empty
  if (!sliderList?.data?.length) {
    return <></>; // Add a loader or a placeholder UI here
  }

  return (
    <section className="home_img_full">
      <Carousel activeIndex={index} onSelect={handleSelect}>
        {sliderList?.data.map((slide) => {
          const imageUrl = `${sliderList?.path}${slide?.image}`; // Precompute the image URL
          return (
            <Carousel.Item key={slide?.id}>
              <Link to={slide.button_link || "/"}>
                {/* Lazy load images for better performance */}
                <img
                  src={imageUrl}
                  alt={`Slide ${slide?.id} - ${slide?.title} - ${slide?.sub_title}`}
                  loading="lazy"
                />
                <Carousel.Caption>
                  {/* You can add any caption or leave it empty */}
                </Carousel.Caption>
              </Link>
            </Carousel.Item>
          );
        })}
      </Carousel>
    </section>
  );
};

// Use React.memo to prevent unnecessary re-renders
export default memo(CarouselCom);
