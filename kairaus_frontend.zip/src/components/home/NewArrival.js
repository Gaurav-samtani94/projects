import { Link, useNavigate } from "react-router-dom";
import { useRef } from "react";
import Slider from 'react-slick';
import dImg from '../../assets/images/d.png';
import Routes from "../../Routes/Routes";
import Wishlist from "../../function/Wishlist";
import AddToCart from "../../function/AddToCart";
import ProductPrice from "../ProductPrice";
import ProductImage from "../ProductImage";

// Arrow component for the slider navigation
const SliderArrow = ({ direction, onClick }) => (
  <div className={`sa_${direction}Arrow`} onClick={onClick}>
    <svg xmlns="http://www.w3.org/2000/svg" width="19" height="29" viewBox="0 0 19 29" fill="none">
      <path d={direction === "prev" ? "M17 27L3 14.5L17 2" : "M2 27L16 14.5L2 2"} stroke="black" strokeOpacity="0.3" strokeWidth="5" strokeLinejoin="round" />
    </svg>
  </div>
);

// const defaultOptions = {
//   loop: true,
//   autoplay: true,
//   animationData: LoaderLottie,
//   rendererSettings: {
//     preserveAspectRatio: 'xMidYMid slice'
//   }
// };

// Extract loading spinner component
// const LoadingSpinner = () => <Lottie options={defaultOptions} height={150} width={200} />;


const NewArrival = ({ productData = [], imagePath, title, discr, type }) => {
  const sliderRef = useRef(null);
  const navigate = useNavigate();

  const settings = {
    dots: false,
    infinite: productData.length > 4,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [
      { breakpoint: 1200, settings: { slidesToShow: 3, slidesToScroll: 1 } },
      { breakpoint: 992, settings: { slidesToShow: 2, slidesToScroll: 1 } },
      { breakpoint: 576, settings: { slidesToShow: 1, slidesToScroll: 1 } },
    ],
  };

  const handleNavigate = () => {
    const routeMapping = {
      newarrival: Routes.NewArrivalProducts,
      bestseller: Routes.BestSeller,
      offer: Routes.BigSaving,
      fitness: Routes.FinestProduct,
    };
    navigate(routeMapping[type]);
  };

  const renderArrows = () => (
    <div className="slider-arrow">
      <SliderArrow direction="prev" onClick={() => sliderRef.current?.slickPrev()} />
      <SliderArrow direction="next" onClick={() => sliderRef.current?.slickNext()} />
    </div>
  );

  return (
    <section className='access_by_categ'>
      <div className="container-fluid">
        <div className='row'>
          <h3 className='store_headings'>{title}</h3>
          <p className="para_subheading">{discr}</p>

          <div className='dinner_slider'>
            <Slider {...settings} ref={sliderRef}>
              {productData.map(product => (
                <div className='dinner_sliderImg' key={product.id}>
                  {product.productimages?.length > 0 ? (
                    <div className="imageContainer">
                      <Link to={`/product/${product.product_slug}`} state={{ ProductId: product.id }}>
                        <ProductImage imgPath={imagePath} imgName={product.productimages[0]?.file_name} alt={product.product_name} />
                        {product.productimages[1]?.file_name && (
                          <ProductImage imgPath={imagePath} imgName={product.productimages[1]?.file_name} alt="" className='hoverImage' />
                        )}
                      </Link>
                      {product.stock_quantity <= 0 ? (
                        <div className="sold_off_chips"><p>Sold Out</p></div>
                      ) : product.discount !== 0 ? (
                        <div className="off_chips"><p>{product.discount}% off</p></div>
                      ) : null}
                      <Wishlist is_wishlist={product.is_wishlist} pId={product.id} path={`${Routes.ProductDetail}/${product.product_slug}`} mode='HeartOutlined' />
                      <AddToCart productList={product} imgPath={imagePath} routeName={Routes.Home} />
                    </div>
                  ) : (
                    <img src={dImg} alt="Placeholder" />
                  )}

                  <div className='dinnerSlider_details'>
                    <Link to={`/product/${product.product_slug}`} state={{ ProductId: product.id }}>
                      <p>{product.product_name}</p>
                    </Link>
                    <div className='dinnerSliderSpan'>
                      <ProductPrice product={product} />
                    </div>
                  </div>
                </div>
              ))}
            </Slider>

            <button className="common_btns" onClick={handleNavigate}>View More</button>
          </div>

          {renderArrows()}
        </div>
      </div>
    </section>
  );
};

export default NewArrival;
