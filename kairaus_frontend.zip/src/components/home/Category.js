import React from 'react';
import { Link } from 'react-router-dom';
import dImg from '../../assets/images/d.png'
import Routes from '../../Routes/Routes';

const Category = ({ categoryList, imagePath }) => {
  // console.log('categoryList',categoryList);
  // Check if categoryList is undefined or empty
  if (!categoryList || categoryList.length === 0) {
    return null; // or you can render a loading indicator or an error message
  }

  return (
    <section className="categ_main">
      <div className="shop_by_categ row mx-0">
        <h4>Shop By Categories</h4>
        <p>Bring home luxury and charm to elevate your space!</p>
        <div className="col-md-4 col-sm-6 col-12 img_flex">
          {categoryList?.slice(0, 2).map((category) => (
            <Link key={category?.menus?.id} to={category?.menus?.slug == 'collections' ? 'collections/offers' :category?.menus?.slug} className='img_decor'>
              {/* <div className='shopCate_head'>
                <h3>{category?.menus.name}</h3>
              </div> */}
              <img
                // src={imagePath + category.image}
                src={category?.menus?.image ? imagePath + category?.menus?.image : dImg}
                alt={category?.menus?.name}
              />
            </Link>
          ))}
        </div>
        <div className="col-md-4 col-sm-6 col-12 img_flex">
          {categoryList.slice(2, 3).map((category) => (
            <Link key={category?.menus?.id} to={category?.menus?.slug} className='img_decor'>
              <img
                // src={imagePath + category.image}
                src={category?.menus?.image ? imagePath + category?.menus.image : dImg}
                alt={category?.menus?.name}
              />
              {/* <div className='shopCate_head'>
                <h3>{category?.menus.name}</h3>
              </div> */}
            </Link>
          ))}
        </div>
        <div className="col-md-4 col-sm-6 col-12 img_flex">
          {categoryList.slice(3).map((category) => (
            <Link key={category?.menus?.id} to={category?.menus?.slug !== "offers" ? category?.menus?.slug : `${Routes?.Collection}/${category?.menus?.slug}`} className='img_decor'>
              {/* <div className='shopCate_head'>
                <h3>{category?.menus.name}</h3>
              </div> */}
              <img
                // src={imagePath + category.image}
                src={category?.menus?.image ? imagePath + category?.menus?.image : dImg}
                alt={category?.menus?.name}
              />
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Category;
