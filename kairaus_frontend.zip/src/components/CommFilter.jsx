import { Checkbox, Slider, Switch, Radio, Button, Select } from 'antd';
import { CloseOutlined } from '@ant-design/icons';
import { useCallback, useEffect, useRef, useState } from 'react';
import { DiscountList, MaterialList, TypeList } from '../services/filter/categories';
import { useDispatch, useSelector } from 'react-redux';
import { addToChip } from '../reducers/filterSlice';
import { getColor } from '../services/filter/color';
import FilterDrawer from './MobileViewFilter';
import { DownOutlined, UpOutlined } from '@ant-design/icons';
import debounce from 'lodash.debounce';
import { useMotionValueEvent, useScroll } from 'framer-motion'


const CommFilter = ({isFetching, slug, setProductList, searchValue, fetchProducts, maxPrice, setimgPath, setCategoryImgPath, setSliderPath, setCategory, pagination, setPagination, productListRef, stockToggle, setStockToggle, setSelectedSorting, selectedSorting,breadcrumb_title}) => {
    const [materialList, setMaterialList] = useState(null);
    const chips = useSelector(state => state.chips);
    const dispatch = useDispatch();
    const [colorList, setColorList] = useState(null);
    const urlName = window?.location?.href.split('/');
    const lastSegment = urlName[urlName.length - 1];
    const [colorPath, setColorPath] = useState(null);
    const [priceRange, setPriceRange] = useState([0, maxPrice]);
    const newChipsData = chips.filter(chipsItem => chipsItem?.pagneName === lastSegment);
    const user = useSelector((state) => state.user);
    // const [stockToggle, setStockToggle] = useState(0);
    const [marks, setMarks] = useState({});
    const [checkedColors, setCheckedColors] = useState([]);
    const [selectedDiscount, setSelectedDiscount] = useState('')
    const [discountList, setDiscountList] = useState(null)
    // console.log('priceRangepriceRangepriceRange',price);
    const saveMaxPrice = localStorage.getItem("maxPrice");
    // const [selectedSorting, setSelectedSorting] = useState(null);

    useEffect(() => {
        const newMaxPrice = maxPrice > 0 ? maxPrice : saveMaxPrice;
        const existingIndex = newChipsData.findIndex(item => item.priceRangeID === 1);
        if (existingIndex !== -1) {
            const [existingMinPrice, existingMaxPrice] = chips[existingIndex].priceRange;
            setPriceRange([existingMinPrice, existingMaxPrice]);
        } else {
            setPriceRange([0, newMaxPrice]);
        }
        localStorage.setItem("maxPrice", maxPrice);
    }, [maxPrice]);

    useEffect(() => {
        const stockToggleItem = newChipsData.find(item => item.type === 'stockToggle');
        const existingDiscount = newChipsData.find(item => item.discountID === 1);
        if (stockToggleItem) setStockToggle(stockToggleItem.value);
        if (existingDiscount) setSelectedDiscount(existingDiscount.minDiscount);
    }, [newChipsData]);

    useEffect(() => {
        if (maxPrice > 1) {
            const updatedMarks = {
                0: '0',
                [maxPrice]: {
                    style: {
                        color: '#000',
                    },
                    label: <strong>{maxPrice}</strong>,
                },
            };
            setMarks(updatedMarks);

        }
    }, [maxPrice]);

    const handleSelectChange = (value) => {
        setSelectedSorting(value);
        setStockToggle(1);
        setPagination({
            limit: 20,
            page_number: 1,
        })
        // console.log('setSelectedSorting',e.target.value);
    }

    const [typeList, setTypeList] = useState(null); //TypeList
    //
    const fetchList = async (apiFunction, setState, lastSegment, searchValue, userToken = null) => {
        try {
            const formData = new URLSearchParams();
            formData.append('slug', lastSegment);
            if (lastSegment === 'allProduct') {
                formData.append('keyword', searchValue);
            }
            const response = await apiFunction(formData, userToken);
            if (response?.status === '1') {
                setState(response?.data);
                return response?.path || null;  // Return path if available (for colors)
            }
        } catch (error) {
            console.error('Error fetching list:', error);
        }
    };

    useEffect(() => {
        const fetchAllLists = async () => {
            // Fetch Type List
            await fetchList(TypeList, setTypeList, lastSegment, searchValue);

            // Fetch Material List
            await fetchList(MaterialList, setMaterialList, lastSegment, searchValue);

            // Fetch Color List and handle the color path separately
            const colorPath = await fetchList(getColor, setColorList, lastSegment, searchValue, user?.token);
            if (colorPath) {
                setColorPath(colorPath);
            }

            // Fetch Discount List
            await fetchList(DiscountList, setDiscountList, lastSegment, searchValue);
        };

        fetchAllLists();
    }, [lastSegment, searchValue, user?.token]);
    //

    const handleTypeChange = (typedata) => {
        const { id, type_name } = typedata
        const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
        const existingIndex = namesArray.findIndex(item => item.typeId === id);
        if (existingIndex !== -1) {
            namesArray.splice(existingIndex, 1);
        } else {
            namesArray.push({ typeId: id, childName: type_name, pagneName: lastSegment });
        }

        localStorage.setItem('chips', JSON.stringify(namesArray));
        dispatch(addToChip(namesArray));
        setPagination({
            limit: 20,
            page_number: 1,
        })
    };

    const removeOutOfStocks = () => {
        const newStockToggle = stockToggle === 0 ? 1 : 0;
        setStockToggle(newStockToggle);
        let updatedNames;
        if (newStockToggle === 0) {
            updatedNames = chips.filter(item => item.type !== 'stockToggle');
        } else {
            updatedNames = chips.map(item =>
                item.type === 'stockToggle'
                    ? { ...item, value: newStockToggle }
                    : item
            );

            // If the stockToggle item doesn't exist, add it
            if (!updatedNames.find(item => item.type === 'stockToggle')) {
                updatedNames.push({ type: 'stockToggle', value: newStockToggle, pagneName: lastSegment });
            }
        }

        localStorage.setItem('chips', JSON.stringify(updatedNames));
        dispatch(addToChip(updatedNames));
        setPagination({
            limit: 20,
            page_number: 1
        })
    };
    const handleDiscount = (value) => {
        setSelectedDiscount(value);

        const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
        const discountFormat = value === 0 ? 'Discount: All' : `Discount: ${value}% Above`;

        const existingIndex = namesArray.findIndex(item => item.discountID === 1);

        const discountData = { discountID: 1, childName: discountFormat, minDiscount: value, pagneName: lastSegment };

        if (existingIndex !== -1) {
            namesArray[existingIndex] = discountData; // Update existing discount
        } else {
            namesArray.push(discountData); // Add new discount
        }

        localStorage.setItem('chips', JSON.stringify(namesArray));
        dispatch(addToChip(namesArray));
        setPagination({
            limit: 20,
            page_number: 1,
        })
    };
    const handleMaterialChange = (materialData) => {
        const { id, material_name } = materialData
        const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
        const existingIndex = namesArray.findIndex(item => item.materialId === id);
        if (existingIndex !== -1) {
            namesArray.splice(existingIndex, 1);
        } else {
            namesArray.push({ materialId: id, childName: material_name, pagneName: lastSegment });
        }

        localStorage.setItem('chips', JSON.stringify(namesArray));
        dispatch(addToChip(namesArray));
        setPagination({
            limit: 20,
            page_number: 1,
        })
    };
    const onChanged = (colorId) => {
        const { color, id, image } = colorId;
        const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
        const existingIndex = newChipsData.findIndex(item => item.colorid === id);
        if (existingIndex !== -1) {
            namesArray.splice(existingIndex, 1);
        } else {
            namesArray.push({ colorid: id, childName: color, image, pagneName: lastSegment });
        }
        localStorage.setItem('chips', JSON.stringify(namesArray));
        dispatch(addToChip(namesArray));
        setCheckedColors(namesArray.map(chip => chip.colorid));
        setPagination({
            limit: 20,
            page_number: 1,
        })
    };
    const fetchTimeout = useRef(null);
    const handlePriceChange = (value) => {
        // setPriceRange(value);
        const [min, max] = value;
        if (min > max) {
            setPriceRange([max, max]);
        } else {
            setPriceRange(value);
        }
        // Clear the previous timeout
        if (fetchTimeout.current) {
            clearTimeout(fetchTimeout.current);
        }

        // Set a new timeout
        fetchTimeout.current = setTimeout(() => {
            const namesArray = JSON.parse(localStorage.getItem('chips')) || [];
            const existingIndex = newChipsData.findIndex(item => item.priceRangeID === 1);

            if (existingIndex !== -1) {
                // Replace the existing item
                namesArray[existingIndex] = { priceRangeID: 1, priceRange: value, childName: `Price: ${min} - ${max}`, maxPrice: maxPrice, pagneName: lastSegment };
            } else {
                // Add a new item
                namesArray.push({ priceRangeID: 1, priceRange: value, childName: `Price: ${min} - ${max}`, maxPrice: maxPrice, pagneName: lastSegment });
            }

            localStorage.setItem('chips', JSON.stringify(namesArray));
            dispatch(addToChip(namesArray));
        }, 400);
        setPagination({
            limit: 20,
            page_number: 1,
        })
    };

    const handleReset = () => {
        setPriceRange([0, maxPrice])
        localStorage.removeItem('chips')
        dispatch(addToChip([]));
        setStockToggle(0)
        setCheckedColors([]);
        setSelectedDiscount('')
        setSelectedSorting(null)
        setPagination({
            limit: 20,
            page_number: 1,
            totalItems: '',
            totalPages: '',
            perPagedata: ''
        })
    }
    const handleRemoveChildName = (identifier, value) => {
        setPagination({
            limit: 20,
            page_number: 1,
        })
        // Update chips array
        let updatedNames;
        switch (identifier) {
            case 'id':
                updatedNames = chips.filter((item) => item.id !== value);
                break;
            case 'typeId':
                updatedNames = chips.filter((item) => item.typeId !== value);
                break;
            case 'materialId':
                updatedNames = chips.filter((item) => item.materialId !== value);
                break;
            case 'colorid':
                updatedNames = chips.filter((item) => item.colorid !== value);
                break;
            case 'discountID':
                setSelectedDiscount('')
                updatedNames = chips.filter((item) => item.discountID !== value);
                break;
            case 'priceRangeID':
                setPriceRange([0, saveMaxPrice])
                updatedNames = chips.filter((item) => item.priceRangeID !== value);
                break;
            case 'stockToggle':
                updatedNames = chips.filter((item) => item.type !== 'stockToggle');
                setStockToggle(0);
                break;
            default:
                updatedNames = chips;
        }
        localStorage.setItem('chips', JSON.stringify(updatedNames));

        // Dispatch an action or update state as needed
        dispatch(addToChip(updatedNames));
        setCheckedColors(updatedNames.map(chip => chip.colorid));
    };
    const handleScroll = () => {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const windowHeight = window?.innerHeight;

        // const lastProduct = productListRef?.current?.lastElementChild;
        // if (lastProduct) {
        //     const lastProductOffset = lastProduct.offsetTop + lastProduct.clientHeight;
        //     const pageOffset = scrollTop + windowHeight;

        //     if (pageOffset >= lastProductOffset - 100) {
        //         if (pagination?.page_number <= pagination?.totalPages) {
        //             setPagination((prevPagination) => ({
        //                 ...prevPagination,
        //                 page_number: prevPagination.page_number + 1,
        //             }));
        //             fetchProducts();
        //         }
        //     }
        // }
        const productList = productListRef?.current?.children;
        const fourthLastIndex = productList.length >= 5 ? productList.length - 5 : 0;
        const targetProduct = productList[fourthLastIndex];
        if (targetProduct) {
            const targetProductOffset = targetProduct.offsetTop + targetProduct.clientHeight;
            const pageOffset = scrollTop + windowHeight;

            // Trigger API call when nearing the target product
            // page_number: prevPagination.page_number + 1,
            if (pageOffset >= targetProductOffset - 400) {
                if (!isFetching && pagination?.page_number <= pagination?.totalPages) {
                    setPagination((prevPagination) => {
                        const updatedPageNumber = prevPagination.page_number + 1;
                        return {
                            ...prevPagination,
                            page_number: updatedPageNumber,
                        };
                    });
                }
            }
        }
    }

    const debouncedScrollHandler = useCallback(debounce(handleScroll, 100), [isFetching]);

    useEffect(() => {
        if (pagination.page_number > 1) {
            if (pagination?.page_number <= pagination?.totalPages) {
                fetchProducts();
            }
        }
    }, [pagination.page_number]);

    useEffect(() => {
        window.addEventListener('scroll', debouncedScrollHandler);
        return () => {
            window.removeEventListener('scroll', debouncedScrollHandler);
        };
    }, [debouncedScrollHandler]);
    useEffect(() => {
        if(newChipsData?.length>0 || selectedSorting){
            window?.scrollTo(0,0)
        }
        fetchProducts()
    }, [chips, selectedSorting]);

    const discountItem = (discountList) => [{
        key: "discounts-panel",
        label: "Discount",
        children: (
            <Radio.Group value={selectedDiscount} onChange={(e) => handleDiscount(e?.target?.value)} >
                <div className="SubCategory">
                    {discountList?.map((discountVal, discountIndex) => (
                        <span key={`discount-${discountIndex}`} className=''>
                            <Radio value={discountVal.from_discount_val}>
                                {discountVal.from_discount_val === 0 && discountVal.to_discount_val === 100 ? 'All' : `${discountVal.from_discount_val}% Above`}
                            </Radio>
                        </span>
                    ))}
                </div>
            </Radio.Group>
        ),
    }];
    //
    const typeListItems = [
        {
            key: 'typeList-panel',
            label: 'Type',
            children: (
                <div className="SubCategory">
                    {typeList && typeList.map(({ id, type_name }) => (
                        <span key={`id-${id}`}>
                            <Checkbox
                                checked={newChipsData.some(chip => chip.typeId === id)}
                                onChange={() => handleTypeChange({ id, type_name })}
                            >
                                {type_name}
                            </Checkbox>
                        </span>
                    ))}
                </div>
            ),
        },
    ];
    const itemsMaterial = (materialList) => [{
        key: 'materials-panel',
        label: "Material",
        children: (
            <div className="SubCategory">
                {materialList?.map(material => (
                    <span key={`material-${material.id}`} className=''>
                        <Checkbox checked={newChipsData?.some(chip => chip.materialId === material.id)} onChange={() => handleMaterialChange(material)}>{material.material_name}</Checkbox>
                    </span>
                ))}
            </div>
        ),
    }];

    const [isDrawerVisible, setIsDrawerVisible] = useState(false);

    const toggleDrawerVisibility = () => {
        setIsDrawerVisible(!isDrawerVisible);
    };

    const closeDrawer = () => {
        setIsDrawerVisible(false);
    };
    const [isDropMenuOpen, setIsDropMenuOpen] = useState(false)
    const [currentMenu, setCurrentMenu] = useState('')


    const handleToggel = (type) => {
        if (!currentMenu) {
            setCurrentMenu(type)
            setIsDropMenuOpen(true)
        } else {
            if (currentMenu == type) {
                setCurrentMenu('')
                setIsDropMenuOpen(false)
            } else {
                setCurrentMenu(type)
                setIsDropMenuOpen(true)
            }
        }
    }

    const [isSticky, setIsSticky] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 500) { // Adjust the value based on when you want the nav to be sticky
                setIsSticky(true);
            } else {
                setIsSticky(false);
            }
        };

        window.addEventListener('scroll', handleScroll);

        // Cleanup the event listener on component unmount
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const { scrollY } = useScroll()
    const sticyRef = useRef(null)
    const [isInTop, setIsInTop] = useState(false)

    useMotionValueEvent(scrollY, "change", (current) => {
        if (current > (window.innerHeight - 70)) {
            setIsInTop(true)
        } else {
            setIsInTop(false)
        }
    })

    return (
        <>
            <div className={`chips_designs ${isSticky ? 'stickyFilter' : ''}`}>
                <div className={`accordian_section ${isInTop ? "dfsdf" : ""}`} ref={sticyRef}>
                    <div className='dropdown_sectionAll'>
                        <span>Filter : </span>
                        <div className='accordian_dropdowns'>
                            <Button onClick={() => handleToggel('1')}>
                                Type {newChipsData?.filter(item => item.typeId).length ? `(${newChipsData?.filter(item => item.typeId).length})` : ''}
                                {currentMenu === '1' ? <UpOutlined /> : <DownOutlined />}
                            </Button>

                            <Button onClick={() => handleToggel('2')}>
                                Material {newChipsData?.filter(item => item.materialId).length ? `(${newChipsData?.filter(item => item.materialId).length})` : ''}
                                {currentMenu === '2' ? <UpOutlined /> : <DownOutlined />}
                            </Button>

                            {!breadcrumb_title &&
                            <Button onClick={() => handleToggel('3')}>
                                Color {newChipsData?.filter(item => item.colorid).length ? `(${newChipsData?.filter(item => item.colorid).length})` : ''}
                                {currentMenu === '3' ? <UpOutlined /> : <DownOutlined />}
                            </Button>}

                            <Button onClick={() => handleToggel('4')}>
                                Price {currentMenu === '4' ? <UpOutlined /> : <DownOutlined />}
                            </Button>

                            <Button onClick={() => handleToggel('5')}>
                                Discount {currentMenu === '5' ? <UpOutlined /> : <DownOutlined />}
                            </Button>
                            <div className='out_stock_box'>
                                <span>Remove Out of Stock Items</span>
                                <Switch checked={stockToggle} onChange={removeOutOfStocks} />
                            </div>
                        </div>
                    </div>
                    <div className='flex-clear-sort'>
                        {(newChipsData?.some(item => item.type !== 'stockToggle') || selectedSorting) && (
                            <button className='clearData_btn' onClick={handleReset}>Clear All</button>
                        )}
                        <div className='path_sortSerch'>
                            <div className='filter_categoryPage'>
                                <div className="drinkware_sort">
                                    <span> SORT BY :</span>
                                    <Select
                                        style={{
                                            width: 'auto',
                                            minWidth: 180,
                                        }}
                                        onChange={handleSelectChange}
                                        value={selectedSorting || null}
                                        placeholder="Select"
                                        options={[
                                            {
                                                value: 'a-z',
                                                label: 'A-Z',
                                            },
                                            {
                                                value: 'z-a',
                                                label: 'Z-A',
                                            },
                                            {
                                                value: 'new_arrival',
                                                label: 'New Arrivals',
                                            },
                                            {
                                                value: 'high_to_low',
                                                label: 'Price: High to Low',
                                            },
                                            {
                                                value: 'low_to_high',
                                                label: 'Price: Low to High',
                                            }]}>
                                    </Select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='chips_filterContainer'>
                    <div className='accordian_filterCont'>
                        {newChipsData?.filter(item => item.type !== 'stockToggle')
                            .map((item, index) => (
                                <div className='chipsDesign' key={`chip-${item.id}`}>
                                    {item?.image && <img src={`${colorPath}${item?.image}`} alt='' />} {item.childName} <CloseOutlined onClick={() => handleRemoveChildName(item.id ? 'id' :
                                        item.typeId ? 'typeId' :
                                            item.materialId ? 'materialId' :
                                                item.colorid ? 'colorid' :
                                                    item.priceRangeID ? 'priceRangeID' :
                                                        item.discountID ? 'discountID' :
                                                            item.type === 'stockToggle' ? 'stockToggle' : '',
                                        item.typeId || item.id || item.materialId || item.colorid || item.priceRangeID || item.type === 'stockToggle' || item.discountID
                                    )} />
                                </div>
                            ))}
                        {(newChipsData?.some(item => item.type !== 'stockToggle') || selectedSorting) && (
                            <button className='clearPhonw_btn' onClick={handleReset}>Clear All</button>
                        )}
                    </div>
                </div>
                <div className={`drop-down-menu-col ${isDropMenuOpen ? "open" : ""}`} onMouseLeave={() => { setIsDropMenuOpen(false); setCurrentMenu('') }}>
                    {currentMenu === '1'
                        && <div className="SubCategory">
                            {typeList && typeList.map(({ id, type_name }) => (
                                <span key={`id-${id}`} className='checkbox-types'>
                                    <Checkbox
                                        checked={newChipsData.some(chip => chip.typeId === id)}
                                        onChange={() => handleTypeChange({ id, type_name })}
                                    >
                                        {type_name}
                                    </Checkbox>
                                </span>
                            ))}
                        </div>
                    }

                    {currentMenu === '2'
                        && <div className="SubCategory">
                            {materialList?.map(material => (
                                <span key={`material-${material.id}`} className='checkbox-types'>
                                    <Checkbox checked={newChipsData?.some(chip => chip.materialId === material.id)} onChange={() => handleMaterialChange(material)}>{material.material_name}</Checkbox>
                                </span>
                            ))}
                        </div>
                    }

                    {currentMenu === '3'
                        && <div className='color_imageCat'>
                            <Checkbox.Group style={{ width: '100%' }} value={checkedColors}>
                                <div className='color_checkoutbox'>
                                    {colorList?.map(color => (
                                        <Checkbox
                                            onChange={() => onChanged(color)}
                                            checked={checkedColors?.includes(color.id)}
                                            key={color.id}
                                            value={color.id}
                                        >
                                            <img src={`${colorPath}${color.image}`} alt={color.color} />
                                            <p>{color.color}</p>
                                        </Checkbox>
                                    ))}
                                </div>
                            </Checkbox.Group>
                        </div>
                    }

                    {currentMenu === '4'
                        && <div className='accordion_range'>
                            <Slider
                                range
                                marks={marks}
                                max={maxPrice}
                                onChange={handlePriceChange}
                                value={priceRange}
                                defaultValue={[0, maxPrice]}
                            />
                        </div>
                    }

                    {currentMenu === '5'
                        && <Radio.Group value={selectedDiscount} onChange={(e) => handleDiscount(e?.target?.value)} >
                            <div className="SubCategory">
                                {discountList?.map((discountVal, discountIndex) => (
                                    <span key={`discount-${discountIndex}`} className=''>
                                        <Radio value={discountVal.from_discount_val}>
                                            {discountVal.from_discount_val === 0 && discountVal.to_discount_val === 100 ? 'All' : `${discountVal.from_discount_val}% Above`}
                                        </Radio>
                                    </span>
                                ))}
                            </div>
                        </Radio.Group>
                    }

                </div>
            </div>

            <div className='filterButton'>
                <div className='filterdropdownBtn'>
                    <button onClick={toggleDrawerVisibility}> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 32 32">
                        <path fill="currentColor" d="M3 9a1 1 0 0 1 1-1h24a1 1 0 1 1 0 2H4a1 1 0 0 1-1-1m4 7a1 1 0 0 1 1-1h16a1 1 0 1 1 0 2H8a1 1 0 0 1-1-1m5 6a1 1 0 1 0 0 2h8a1 1 0 1 0 0-2z" />
                    </svg> Filter</button>
                    <div className='path_sortSerch'>
                        <div className='filter_categoryPage'>
                            <div className="drinkware_sort">
                                <span> SORT BY :</span>
                                <Select
                                    style={{
                                        width: 'auto',
                                        minWidth: 180,
                                    }}
                                    onChange={handleSelectChange}
                                    value={selectedSorting || null}
                                    placeholder="Select"
                                    options={[
                                        {
                                            value: 'a-z',
                                            label: 'A-Z',
                                        },
                                        {
                                            value: 'z-a',
                                            label: 'Z-A',
                                        },
                                        {
                                            value: 'new_arrival',
                                            label: 'New Arrivals',
                                        },
                                        {
                                            value: 'high_to_low',
                                            label: 'Price: High to Low',
                                        },
                                        {
                                            value: 'low_to_high',
                                            label: 'Price: Low to High',
                                        }]}>
                                </Select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <FilterDrawer isDrawerVisible={isDrawerVisible} closeDrawer={closeDrawer} items={typeListItems} colorList={colorList} materialList={materialList} itemsMaterial={itemsMaterial} checkedColors={checkedColors} colorPath={colorPath} onChanged={onChanged} marks={marks} maxPrice={maxPrice} handlePriceChange={handlePriceChange} priceRange={priceRange} discountItem={discountItem} discountList={discountList} stockToggle={stockToggle} removeOutOfStocks={removeOutOfStocks} />
            {isDropMenuOpen &&
                <div className='filter-overlay' onClick={() => {
                    setCurrentMenu('')
                    setIsDropMenuOpen(false)
                }}
                    style={{
                        position: 'fixed',
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100vh",
                        background: "transparent",
                        zIndex: 10
                    }}
                >

                </div>
            }
        </>
    );
};

export default CommFilter;