import React, { useState, useEffect, useRef } from 'react';
import popIMg from '../../assets/images/pop up.jpg'
import { Link, useNavigate } from 'react-router-dom';
import Routes from '../../Routes/Routes';

const WelcomePop = () => {
    const [isVisible, setIsVisible] = useState(true);
    const modalRef = useRef(null);
    const navigate = useNavigate();

    useEffect(() => {

        const timer = setTimeout(() => {
            setIsVisible(false);
        }, 3000);

        return () => clearTimeout(timer);
    }, []);

    const closePopup = () => {
        setIsVisible(false);
    };

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (modalRef.current && !modalRef.current.contains(event.target)) {
                setIsVisible(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);
    const handleNavigate = () => {
        navigate(`${Routes?.Collection}/offers`);
        closePopup();
    };

    return (
        isVisible && (
        <div className="welcome-popup" >
            <div className='welcome-inner'>
                <div className="popup-content" ref={modalRef} onClick={handleNavigate}>
                    <div className='pop_img'>
                        <img src={popIMg} alt='dewali banner' />
                    </div>
                    <div className='subscribe_contPop'>
                        <h3><strong>New to our store?</strong> <br /> Get an extra <span>5% OFF</span> on your first order!</h3>
                        <button className='shopNowBtn'>Shop Now!</button><br />
                        {/* <span>Celebrate this festival with luxurious savings.<button className='show_nowPop'> Shop now!</button></span><br /> */}
                        {/* <span>#KairausWaliDiwali</span> */}
                    </div>
                </div>
                <button onClick={closePopup} className="close-btn"><svg width="20" height="20" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14 14L34 34" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" /><path d="M14 34L34 14" stroke="#333" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" /></svg></button>
            </div>
        </div>
        )
    );
};

export default WelcomePop;
