import React, { useEffect, useState } from 'react';
import { Modal, Input } from 'antd';
import ReactStars from 'react-rating-stars-component';
import {addReviews, editReviews} from '../../services/reviews'
import { useSelector } from 'react-redux';
import { toast } from 'react-toastify';

const { TextArea } = Input;

const RatingModal = ({ isModalOpen, handleCancel ,productDetails,reviewDetail,setRating,rating,setFeedbackText,feedbackText}) => {
  console.log(reviewDetail,"reviewDetail");
  const user = useSelector((state) => state.user);
  const {token } = user;
  // const [rating, setRating] = useState(0);
  // const [feedbackText, setFeedbackText] = useState('');
  const ratingChanged = (newRating) => {
    setRating(newRating);
  }

  const handleFeedbackTextChange = (e) => {
    const text = e.target.value;
    setFeedbackText(text);
  }

  useEffect(()=>{
    if(reviewDetail?.id){
      setRating(reviewDetail?.rating)
      setFeedbackText(reviewDetail?.review)
    }
  },[reviewDetail?.id])

  const handleSubmit = async() => {
    if (!rating) {
      toast.error("Rating is required");
      return;
    }
    if(reviewDetail?.id){
      const formData = new URLSearchParams();
        formData.append('id', reviewDetail?.id);
        formData.append('rating',rating);
        formData.append('review',feedbackText)
            try {
                const response = await editReviews(formData, token);
                // console.log(response,"response")
                if (response.status === '1') {
                  handleCancel()
                  setRating(response?.data?.rating)
                  setFeedbackText(response?.data?.review)
                }
            } catch (error) {
                console.error('Error fetching data:', error);
            }

    }else{
      const formData = new URLSearchParams();
        formData.append('product_id', productDetails?.id);
        formData.append('rating',rating);
        formData.append('review',feedbackText)
            try {
                const response = await addReviews(formData, token);
                if (response.status === '1') {
                  handleCancel()
                }
            } catch (error) {
                console.error('Error fetching data:', error);
            }
    }

  }

  return (
    <Modal
      title={reviewDetail?.id ? "Edit Review" : "Write a Review"}
      open={isModalOpen}
      // onOk={handleSubmit}
      onCancel={handleCancel}
      className='review_model'
      footer={[
        <button key="back" onClick={handleCancel} className='cancelBtn'>
          Cancel
        </button>,
        <button key="submit" onClick={handleSubmit} className='submitBtn'>
          {reviewDetail?.id ? "Update Feedback" : "Submit Feedback"}
        </button>,
      ]}
    >
      <div className='model_reviewBody'>
        <span>How likely are you to recommend our Services!</span>
        <ReactStars
          key={`react-stars-${rating}`}
          count={5}
          onChange={ratingChanged}
          value={rating ? rating : 0}
          size={28}
          isHalf={true}
          color="#d1d1d1"
          activeColor="#ffd700"
          edit={true}
        />

        <h5>What Feature can we add to improve?</h5>
        <TextArea
          rows={4}
          placeholder="maximum words limit 250"
          maxLength={250}
          value={feedbackText}
          onChange={handleFeedbackTextChange}
        />
      </div>
    </Modal>
  );
};

export default RatingModal;
