import React, { memo } from "react";
import ReactStars from "react-rating-stars-component";

const RenderRating = ({ ratingData, handleRatingClick }) => {
    if (!ratingData) {
        return <span>Loading rating...</span>;
    }

    const { StarRating, Rating } = ratingData;

    return (
        <div className="rating_testimonial">
            Rating:
            <ReactStars
                count={5}
                value={parseFloat(StarRating)}
                size={20}
                isHalf={true}
                activeColor="#ffd700"
                color="#d1d1d1"
                edit={false}
                classNames="rating-star"
            />
            <span onClick={handleRatingClick} style={{ cursor: "pointer" }}>
                ({Rating})
            </span>
        </div>
    );
};

export default memo(RenderRating);
