import React, { useEffect, useState } from 'react';
import { FaPlus, FaMinus } from "react-icons/fa6";
import AddToCart from "../../function/AddToCart";
import Wishlist from "../../function/Wishlist";
import Routes from "../../Routes/Routes";
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import OutOfStock from '../OutOfStock';
import { addToBuy } from '../../reducers/buySlice';
import { addToBuyDB, updateCartCount } from '../../services/cart/addCart';
import DrawerCart from "../drawer/Drawer";
import { handlePurchaseForPixel } from "../../components/FacebookPixelIntegration.jsx";
import { addToCart } from '../../reducers/cartSlice.js';
import { getApplyCouponData } from '../../services/coupon/applyCoupon.js';
import { storeLocalCoupon } from '../../reducers/localCouponSlice';

const ProductDetailButtonBox = ({ responseData, handleAddToCartForPixel, setProductCount, productCount }) => {
    const [productDetails, setProductDetails] = useState(null);
    const [is_wishlistt, setIs_wishlist] = useState(null);
    const [imgPath, setImgPath] = useState(null);
    const [openCartDrawer, setOpenCartDrawer] = useState(false);    
    const sCoupon = useSelector(state => state.productCoupon);
    const storedCouponCode = sessionStorage.getItem(`coupon_${productDetails?.id}`);
    const productCoupon = sCoupon || storedCouponCode || "";
    const excRate = useSelector(state => state.excrate);
    const localCoupons = useSelector((state) => state.localCoupon);
    const firstOrderCoupDetail = JSON.parse(localStorage.getItem('FirstOrderCouponDetails'));
    const cart = useSelector(state => state.cart);

    useEffect(() => {
        setProductDetails(responseData?.data);
        setImgPath(responseData?.path);
        setIs_wishlist(responseData?.is_wishlist);
    }, [responseData])

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const user = useSelector(state => state.user);
    const applied = useSelector(state => state.applied);
    const appliedPrice = useSelector(state => state.appliedPrice);
    const productCouponId = useSelector(state => state.productCouponId);
    const isProductOutOfStock = OutOfStock({
        productId: productDetails?.id,
        stockQuantity: productDetails?.stock_quantity,
    });

    const showDrawer = () => {
        setOpenCartDrawer(true);
    };
    const onClose = () => {
        setOpenCartDrawer(false)
    };

    const handleCountDec = async () => {
        if (productCount <= 1) {
            return;
        }
        setProductCount(prevCount => prevCount - 1);

        const itemToUpdate = cart.find(item => item.id === productDetails?.id);

        if (itemToUpdate && itemToUpdate?.isChecked) {
            const formData = new URLSearchParams();
            formData.append('product_id', productDetails?.id);
            formData.append('quantity', productCount - 1);
            try {
                // Update the cart count via API
                await updateCartCount(formData, user?.token);
                // Update cart locally
                const updatedCart = cart.map(item =>
                    item.id === productDetails?.id ? { ...item, count: item.count - 1 } : item
                );
                // Update state with the new cart
                localStorage.setItem('cart', JSON.stringify(updatedCart));
                dispatch(addToCart(updatedCart));
            } catch (error) {
                console.error("Cart Updating error :", error);
            }
        }
    };

    const handleCountInc = async (stock_quantity) => {
        if (productCount < stock_quantity) {
            setProductCount(productCount + 1);
        } else {
            toast.error("Oops, the count has exceeded the available stock", {
                toastId: "1",
            });
        }

        const itemToUpdate = cart.find(item => item.id === productDetails?.id);
        if (itemToUpdate && itemToUpdate?.isChecked) {
            const formData = new URLSearchParams();
            formData.append('product_id', productDetails?.id);
            formData.append('quantity', productCount + 1);
            try {
                // Update the cart count via API
                await updateCartCount(formData, user?.token);
                // Update cart locally
                const updatedCart = cart.map(item =>
                    item.id === productDetails?.id ? { ...item, count: item.count + 1 } : item
                );
                // Update state with the new cart
                localStorage.setItem('cart', JSON.stringify(updatedCart));
                dispatch(addToCart(updatedCart));
            } catch (error) {
                console.error("Cart Updating error :", error);
            }
        }
    };

    const applyCouponData = async (userToken) => {
        const coupon_code = localCoupons?.map(coupon => coupon.coupon_code).join(',') || [];
        try {
            const formData = new URLSearchParams();
            formData.append('coupon_code', coupon_code);
            const response = await getApplyCouponData(formData, userToken);
            if (response?.status === '1') {
                dispatch(storeLocalCoupon(response?.data));
            }
        } catch (error) {
            if (error?.response?.data?.status === '0') {
                toast.error("Please try again later.");
                console.error('Error applying coupon:', error.response);
            }
        }
    }

    const handleBuyNowClick = () => {
        let newItems = [];
        const { id, product_name, compare_price, product_slug, is_wishlist, weight, unit, stock_quantity, shipping_amount_type, shipping_charge, usd_price, product_buffer_days } = productDetails;
        const image = `${imgPath}${productDetails?.productimages[0]?.file_name}`;
        const price = applied ? appliedPrice : productDetails?.price;
        const newItem = { id, product_name, product_slug, is_wishlist, price, compare_price, shipping_amount_type, shipping_charge, image, count: productCount, p_variant_id: 0, weight, isChecked: true, unit, stock_quantity, usd_price, productCoupon };
        newItems.push(newItem);
        dispatch(addToBuy(newItems));
        localStorage.setItem("buy", JSON.stringify(newItems));
        applied && localStorage.setItem("productCoupon", JSON.stringify(productCouponId));
        if (user?.id) {
            const addToDB = async () => {
                const dataToSend = [
                    {
                        // product_id: id,            // Use the actual product ID
                        // quantity: productCount,     // Use the actual quantity
                        // product_coupon: productCoupon, // Use the actual coupon code
                        // usd_amount:usd_price,
                        // currency_code:excRate?.currencyCode,
                        // currency_rate:excRate?.rate,
                        // currency_symbol:excRate?.currencySymbol

                        product_id: id,
                        product_variant_id: 0,
                        quantity: productCount,
                        coupon_code: productCoupon,
                        usd_amount: usd_price,
                        currency_code: excRate?.currencyCode,
                        currency_rate: excRate?.rate,
                        currency_symbol: excRate?.currencySymbol,

                    }
                ];
                try {
                    const CartData = await addToBuyDB(dataToSend, user.token);
                    if (CartData.status === "1") {
                        const metaData = {
                            product_id: id,            // Use the actual product ID
                            quantity: productCount,     // Use the actual quantity
                            product_coupon: productCoupon, // Use the actual coupon code
                            usd_amount: usd_price,
                            currency_code: excRate?.currencyCode,
                            currency_rate: excRate?.rate,
                            currency_symbol: excRate?.currencySymbol,
                            product_name: product_name,
                            price: price
                        }
                      
                        if (user?.token && firstOrderCoupDetail?.order_count<1) {
                            applyCouponData(user?.token)
                        }
                        handlePurchaseForPixel(metaData)
                        navigate(Routes?.MainCheckout);
                    }
                     else {
                        toast.error("There was an issue processing your cart. Please check your connection or try again later.");
                    }

                } catch (e) {
                    //
                }
            }
            addToDB();

        } else {
            // navigate(Routes?.SignIn, { state: { from: Routes?.MainCheckout } });
            navigate(Routes?.MainCheckout);
        }
    };

    return (
        <div className="buttons_threeNumber">
            <button className="btn-incriment">
                <span onClick={handleCountDec}><FaMinus /></span>
                {productCount}
                {(!isProductOutOfStock && productCount < productDetails?.stock_quantity) ? (
                    <span onClick={() => handleCountInc(productDetails?.stock_quantity)}>
                        <FaPlus />
                    </span>
                ) : (
                    <span style={{ opacity: 0.5, cursor: 'not-allowed' }}>
                        <FaPlus />
                    </span>
                )}
            </button>
            {cart?.find(item => item.id == productDetails?.id) ? (
                <div className='goCart_Btn'> <button onClick={() => showDrawer()}> Go to Cart</button></div>
            ) : <AddToCart
                imgPath={imgPath}
                productList={productDetails}
                productCount={productCount}
                appliedPrice={appliedPrice}
                applied={applied}
                myClass="add-to-cart"
                handleAddToCartForPixel={handleAddToCartForPixel}
            />}
            {!isProductOutOfStock && (
                <button onClick={handleBuyNowClick} className="buy-now">BUY NOW</button>
            )}
            <div className="wishlist">
                {is_wishlistt !== null && (
                    <Wishlist
                        is_wishlist={is_wishlistt}
                        pId={productDetails?.id}
                        path={`${Routes.ProductDetail}/${productDetails?.product_slug}`}
                        mode="HeartOutlined"
                    />
                )}
            </div>
            <DrawerCart onClose={onClose} openDrawer={openCartDrawer} />
        </div>
    );

};

export default ProductDetailButtonBox;
