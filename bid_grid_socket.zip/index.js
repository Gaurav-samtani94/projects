const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const { Sequelize, DataTypes, Op } = require('sequelize');
const app = express();
const server = http.createServer(app);
const io = socketIo(server);
var dbConn = require('./config/database');
const getCurrentDateTime = () => new Date();
const path = require('path');
const multer = require('multer');
const admin = require("firebase-admin");
const fs = require('fs');
const cors = require('cors');
const serviceAccountapp = require('./google-services.json');
const serviceAccountweb = require('./chatweb-14c48-firebase-adminsdk-fwhja-e80f0212e5.json');

//=========================== MODELS DEFINED HERE ===============================
const Chat = require('./models/chats');
const Users = require('./models/Users');
const ChatRooms = require("./models/Chatroom");
const Todo_comments = require('./models/Todo_comments');
const Todo_main_task = require('./models/Todo_main_task');
const ProjectTodo = require('./models/Projecttodo');
const Tender_comments = require('./models/Tender_comments');
const ProjectTodoCommentModel = require('./models/ProjectTodoCommentModel');
const notification = require('./models/Notification_history');
const Arrangementsmodel = require('./models/ChatarrangementsModel');
const Arrangementsgroupmodel = require('./models/ChatarrangementsgroupModel');
const Todolist = require('./models/Todolist');
const Assignedtask = require('./models/AssigntaskModel');
const CompanyLogo = require('./models/CompanyLogoModel');
const ChatselectesModel = require('./models/ChatselectesModel');
const createTenderModel = require('./models/TenderModel');
const TenderAssignManagerModel = require('./models/TenderAssignManagerModel');
const TenderBdRoleModel = require('./models/TenderBdRoleModel');
const project_todo_assigned_tasks = require('./models/ProjectAssignedtask');

app.use('/uploads', express.static('./uploads'));
const firebaseApp = admin.initializeApp({
    credential: admin.credential.cert(serviceAccountapp),
}, "appInstance");

// // Initialize Firebase Admin instance for the second set of credentials
const firebaseweb = admin.initializeApp({
    credential: admin.credential.cert(serviceAccountweb),
}, "webInstance");
// // https.createServer(httpsOptions, app).listen(8443);

// // http.createServer((req, res) => {
// //     res.writeHead(301, { "Location": "https://" + req.headers['host'] + req.url });
// //     res.end();
// // }).listen(8080);// dbConn.sync()
// //     .then(() => {
// //         console.log('Database and tables synced');
// //     })
// //     .catch((error) => {
// //         console.error('Error syncing database:', error);
// //     });
const typinggroupusers = [];
const connectusers = [];
const connectedUsers = {};
const onlineUsers = new Set();

const userSockets = new Map();
const userConnections = {}; 
// // Socket.IO connection
io.on('connection', async (socket) => {
    socket.emit("me", socket.id);
    const user_id = socket.handshake.query.user_id;
    console.log(socket.id,"===========Connected================")
    //=============================================================================================

    // if (user_id) {
    //     // const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'userfullname'] })

    //     // Handle socket disconnection
    //     socket.on('disconnect', async () => {

    //         //=========================== Abhimanyu's code==========================================
    //         if (user_id) {
    //             await ChatselectesModel.update({ to_user_id: null }, { where: { from_user_id: user_id, } })
    //         }
    //         delete connectedUsers[user_id];
    //         const index = connectusers.indexOf(userIds);
    //         if (index > -1) { // only splice array when item is found
    //             connectusers.splice(index, 1); // 2nd parameter means remove one item only
    //         }
    //         io.emit('userStatus', { data: connectusers, online: false });
    //         //=================================== End Abi code =====================================
    //     });
    // }

    //=================================================================================

    // if (connectedUsers[user_id]) {
    //     socket.disconnect(true);
    // }
    connectedUsers[user_id] = socket;
    const userIds = user_id;
    socket.join(Number(user_id));
    if (!connectusers.includes(user_id)) {
        connectusers.push(user_id);
    }


    socket.on('join', (userId) => {
        onlineUsers.add(userId);
        io.emit('userStatus', { data: connectusers, online: true });
    });
    //----------------- single chat start----------------------
    // console.log(socket, 'abhi')
    socket.on('send', async (data) => {

        // admin.initializeApp({
        //     credential: admin.credential.cert(serviceAccountweb),
        //     // databaseURL: "chatbidgrid" + Math.floor(Math.random() * '100000000000000000000000000')
        // });

        // admin.initializeApp({
        //     credential: admin.credential.cert(serviceAccountweb),
        // }, "chatbidgrid" + Math.floor(Math.random() * '100000000000000000000000000'));

        const authorization = data.authorization;
        const from_user_id = data.from_user_id;
        const comp_id = data.comp_id;
        const to_user_id = data.to_user_id;
        const message = data.message;
        // const group_id = data.group_id;
        try {
            // const complogo = await CompanyLogo.findOne({ where: { user_comp_id: comp_id, status: '1' }, attributes: ['id', 'logo_file_path', 'logo_file_name'] })
            const user_details = await Users.findOne({ where: { id: data.to_user_id, isactive: '1' }, attributes: ['id', 'device_token', 'web_push_notification_token'] })
            const user_details_from = await Users.findOne({ where: { id: from_user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname', 'profileimg_path', 'profileimg'] });
            const chat_check_room_first = await ChatRooms.findOne({ where: { user_comp_id: comp_id, from_user_id: from_user_id, to_user_id: data.to_user_id, status: '1' }, attributes: ['id'] });
            const chat_check_room_second = await ChatRooms.findOne({ where: { user_comp_id: comp_id, from_user_id: to_user_id, to_user_id: from_user_id, status: '1' }, attributes: ['id'] });


            if ((chat_check_room_first) || (chat_check_room_second)) {
                var roor_id = (chat_check_room_first) ? chat_check_room_first.id : chat_check_room_second.id;

            } else {
                const insert_val = {
                    user_comp_id: comp_id,
                    from_user_id: from_user_id,
                    to_user_id: to_user_id,
                    created_at: getCurrentDateTime(),
                    created_by: from_user_id,
                }
                const insert_room = await ChatRooms.create(insert_val);
                var roor_id = insert_room.id;
            }
            const check_read = await ChatselectesModel.findOne({ where: { user_comp_id: comp_id, from_user_id: to_user_id, to_user_id: from_user_id }, attributes: ['id'] })
            let read = null;
            if (check_read) {
                read = 1;
            } else {
                read = 0;
            }
            if (roor_id) {
                const insert_val = {
                    user_comp_id: comp_id,
                    from_user_id: from_user_id,
                    to_user_id: to_user_id,
                    message: message,
                    read: (check_read) ? '1' : '0',
                    chat_room_id: roor_id,
                    created_at: getCurrentDateTime(),
                }
                const chat_insert = await Chat.create(insert_val);
                socket.emit('receive', {
                    id: chat_insert.id,
                    from_user_id: from_user_id,
                    read: read,
                    to_user_id: to_user_id,
                    message: message,
                    created_at: chat_insert.created_at
                });
                socket.to(Number(to_user_id)).emit("received", {
                    id: chat_insert.id,
                    from_user_id: from_user_id,
                    to_user_id: to_user_id,
                    message: message,
                    created_at: chat_insert.created_at
                });
                if (user_details?.dataValues?.device_token) {
                    const message_notification = {
                        notification: {
                            title: user_details_from.userfullname,
                            body: message,
                        },
                        data: {
                            id: `${chat_insert.id}`,
                            from_user_id: `${from_user_id}`,
                            to_user_id: `${to_user_id}`,
                            userfullname: `${user_details_from.userfullname}`,
                            profileimg_path: `${user_details_from.dataValues.profileimg_path}`,
                            profileimg: `${user_details_from.dataValues.profileimg}`,
                            compprofile: '',
                            // compprofile: `https://web.growthgrids.com/${complogo.logo_file_path + '/' + complogo.logo_file_name}`,
                            email: `${user_details_from.dataValues.email}`,
                        },
                        token: `${user_details?.dataValues?.device_token}`,
                    };
                    sendMessageapp(message_notification, "appInstance")
                        .then((response) => {
                            console.log('Successfully sent message to app instance:', response);
                        })
                        .catch((error) => {
                            console.log('Error sending message to app instance:', error);
                        });
                }
                if (user_details?.dataValues?.web_push_notification_token) {
                    const message_notification_web = {
                        notification: {
                            title: user_details_from.userfullname,
                            body: message,
                        },
                        data: {
                            id: `${chat_insert.id}`,
                            from_user_id: `${from_user_id}`,
                            to_user_id: `${to_user_id}`,
                            userfullname: `${user_details_from.userfullname}`,
                            profileimg_path: `${user_details_from.dataValues.profileimg_path}`,
                            profileimg: `${user_details_from.dataValues.profileimg}`,
                            // file_name: `${user_details_from.dataValues.profileimg_path + '/' + user_details_from.dataValues.profileimg}`,
                            // compprofile: `https://web.growthgrids.com/${complogo.logo_file_path + '/' + complogo.logo_file_name}`,
                            compprofile: '',
                            email: `${user_details_from.dataValues.email}`,
                        },
                        token: `${user_details?.dataValues?.web_push_notification_token}`
                    }
                    sendMessageweb(message_notification_web, "webInstance")
                        .then((response) => {
                            console.log('Successfully sent message to web instance:', response);
                        })
                        .catch((error) => {
                            console.log('Error sending message to web instance:', error);
                        });

                }

                const user_details_rec = await Users.findAll({
                    where: {
                        id: {
                            [Op.ne]: data.from_user_id
                        },
                        comp_id: data.comp_id,
                        isactive: '1'
                    }, attributes: ['id'],

                })
                if (user_details_rec[0]) {
                    for (const user_id of user_details_rec) {
                        const check_exist = await Arrangementsmodel.count({ where: { user_comp_id: data.comp_id, from_user_id: data.from_user_id, to_user_id: user_id.id, status: '1' }, attributes: ['id'] })
                        if (check_exist < 1) {
                            await Arrangementsmodel.create({
                                user_comp_id: data.comp_id,
                                from_user_id: data.from_user_id,
                                to_user_id: user_id.id,
                                created_by: data.from_user_id,
                                created_at: getCurrentDateTime()
                            })
                        }
                    }
                    for (const user_id of user_details_rec) {
                        const check_exist = await Arrangementsmodel.count({ where: { user_comp_id: data.comp_id, from_user_id: user_id.id, to_user_id: data.from_user_id, status: '1' }, attributes: ['id'] })
                        if (check_exist < 1) {
                            await Arrangementsmodel.create({
                                user_comp_id: data.comp_id,
                                from_user_id: user_id.id,
                                to_user_id: data.from_user_id,
                                created_by: data.from_user_id,
                                created_at: getCurrentDateTime()
                            })
                        }
                    }

                }

                await Arrangementsmodel.update({
                    updated_at: getCurrentDateTime(),
                    updated_by: data.from_user_id,

                },
                    {
                        where: {
                            user_comp_id: data.comp_id,
                            from_user_id: data.to_user_id,
                            to_user_id: data.from_user_id,
                            status: '1'
                        },

                    })
                await Arrangementsmodel.update({
                    updated_at: getCurrentDateTime(),
                    updated_by: data.from_user_id,

                },
                    {
                        where: {
                            user_comp_id: data.comp_id,
                            from_user_id: data.from_user_id,
                            to_user_id: data.to_user_id,
                            status: '1'
                        },

                    })

            }
            const UserList = await Arrangementsmodel.findAll({
                where: {
                    user_comp_id: data.comp_id,
                    from_user_id: data.from_user_id,
                    status: '1'
                }, attributes: ['to_user_id'], order: [['updated_at', 'DESC']],

            })
            socket.emit('receive_sorting_ids', UserList);
            socket.to(Number(to_user_id)).emit("received_sorting_ids", UserList);

        } catch (error) {
            console.log('error', error)

        }
    });

    function sendMessageweb(messageData, instanceName) {
        return firebaseweb.messaging().send(messageData);
    }
    function sendMessageapp(messageData, instanceName) {
        return firebaseApp.messaging().send(messageData);
    }
    // --------------single chat end--------------------
    //dpouble tick And singl start
    socket.on('video_call_sender', async (data) => {
        // const chat_unread_count = await Chat.count({ where: { from_user_id: data.from_user_id, is_group: '1', to_user_id: data.to_user_id, read: '0' } });
        // if (chat_unread_count > 0) {
        socket.to(23).emit("received_video_call_sender", {
            data
        });
        // }

    });
    socket.on('video_call_sender_answer', async (data) => {
        // const chat_unread_count = await Chat.count({ where: { from_user_id: data.from_user_id, is_group: '1', to_user_id: data.to_user_id, read: '0' } });
        // if (chat_unread_count > 0) {
        console.log(data, 'datadatadatadata');
        socket.to(2).emit("received_video_call_sender_answer", {
            data
        });
        // }

    });
    //git calling
    socket.on("callUser", ({ userToCall, signalData, from, name }) => {
        console.log(userToCall, signalData, from, name, '++++')
        socket.to(220).emit("callUser_R", { signalData });
    });

    socket.on("updateMyMedia", ({ type, currentMediaStatus }) => {
        console.log("updateMyMedia");
        socket.broadcast.emit("updateUserMedia", { type, currentMediaStatus });
    });

    socket.on("msgUser", ({ name, to, msg, sender }) => {
        socket.to(to).emit("msgRcv", { name, msg, sender });
    });

    socket.on("answerCall", (data) => {
        socket.broadcast.emit("updateUserMedia", {
            type: data.type,
            currentMediaStatus: data.myMediaStatus,
        });
        socket.to(data.to).emit("callAccepted", data);
    });
    socket.on("endCall", ({ id }) => {
        socket.to(id).emit("endCall");
    });

    //git calling
    socket.on('ICEcandidate', async (data) => {
        // const chat_unread_count = await Chat.count({ where: { from_user_id: data.from_user_id, is_group: '1', to_user_id: data.to_user_id, read: '0' } });
        // if (chat_unread_count > 0) {
        console.log(data, 'datadatadatadata');
        socket.to(2).emit("received_ICEcandidate", {
            data
        });
        // }

    });

    socket.on('offer', (offer, roomId) => {
        socket.to(offer.userId).emit('received_offer', offer);
    });

    socket.on('answer', (data) => {
        socket.to(data.userId).emit('received_answer', data.answer);
    });
    socket.on('ice_candidate', (data) => {
        socket.to(data.userId).emit('received_ice_candidate', data);
    });


    //ausdio call 
    // --------------typing Event start--------------------
    socket.on('typing_event_start', async (data) => {
        socket.to(Number(data.to_user_id)).emit("received_typing_event_start", {
            from_user_id: data.from_user_id,
        });
    });
    socket.on('typing_event_End', async (data) => {
        socket.to(Number(data.to_user_id)).emit("received_typing_event_end", {
            from_user_id: data.from_user_id,
        });
    });


    // --------------typing Event End--------------------
    //----------------Group Chat start------------------
    var getRoomUsers = [];
    socket.on('joinRoom', async (group_id) => {
        const user = { "socket_id": socket.id, "from_user_id": user_id, "group_id": group_id };
        // const userAlreadyInGroup = getRoomUsers.some(roomUser => roomUser.from_user_id === user.from_user_id && roomUser.group_id === user.group_id);
        // getRoomUsers.includes(user.from_user_id)
        if (getRoomUsers.includes(Number(user.from_user_id))) {
            return false;
        } else {
            socket.join(Number(user.group_id));
            socket.to(Number(user.group_id)).emit('roomUsers', {
                group_id: Number(user.group_id),
                from_user_id: getRoomUsers.push(Number(user.from_user_id))
            });
        }
        console.log(getRoomUsers, 'getRoomUsers----------------+++++++++++', group_id)
        socket.on('send_group_message', async (data) => {
            console.log(getRoomUsers, 'getRoomUsers----------------+++++++++++', data, group_id)
            const user_details = await Users.findOne({ where: { id: Number(user_id), isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname', 'profileimg_path', 'profileimg'] });
            try {
                if (user_details) {
                    const message = data.message;
                    const group_id = data.group_id;
                    const insert_val = {
                        user_comp_id: user_details.comp_id,
                        from_user_id: user_id,
                        group_id: group_id,
                        message: message,
                        is_group: '2',
                        created_at: getCurrentDateTime(),
                    }
                    const chat_insert = await Chat.create(insert_val);
                    const username = {
                        userfullname: user_details.userfullname,
                        profileimg_path: user_details.profileimg_path,
                        profileimg: user_details.profileimg,
                    }
                    socket.emit('receive_group_message', {
                        chat_id: chat_insert.id,
                        from_user_id: user_details.id,
                        group_id: group_id,
                        user: username,
                        message: message,
                        created_at: chat_insert.created_at
                    });
                    socket.to(Number(group_id)).emit("received_group_message", {
                        chat_id: chat_insert.id,
                        from_user_id: user_details.id,
                        group_id: group_id,
                        user: username,
                        message: message,
                        created_at: chat_insert.created_at
                    });
                    await Arrangementsgroupmodel.update({
                        updated_at: getCurrentDateTime(),
                        updated_by: user_details.id,

                    },
                        {
                            where: {
                                user_comp_id: user_details.comp_id,
                                group_id: group_id,
                                status: '1'
                            },

                        })
                    const response = await Arrangementsgroupmodel.findAll({
                        where: {
                            user_comp_id: user_details.comp_id,
                            group_id: group_id,
                            status: '1'
                        }
                    })
                    socket.emit('group_receive_sorting_ids', response);
                    socket.to(Number(group_id)).emit("group_received_sorting_ids", response);
                } else {
                    console.log('somethig Went Wrong')
                }
            } catch (error) {
                console.error('Error in send_group_message event:', error);
            }
        });
    });
    //----------------Group Chat End------------------
    //----------------single caht file upload start---------
    socket.on('send_file', async (data) => {
        const complogo = await CompanyLogo.findOne({ where: { user_comp_id: data.comp_id, status: '1' }, attributes: ['id', 'logo_file_path', 'logo_file_name'] })
        const user_details = await Users.findOne({ where: { id: data.to_user_id, isactive: '1' }, attributes: ['id', 'device_token', 'web_push_notification_token'] })
        const user_details_from = await Users.findOne({ where: { id: data.from_user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname', 'profileimg_path', 'profileimg'] });
        socket.emit('receive', {
            is_file: '1',
            original_file_name: data.original_file_name,
            created_at: data.created_at,
            file_type: data.file_type,
            from_user_id: data.from_user_id,
            to_user_id: data.to_user_id,
            file_name: data.single_chat_image,
            comp_id: data.comp_id
        });
        socket.to(Number(data.to_user_id)).emit("received", {
            original_file_name: data.original_file_name,
            is_file: '1',
            file_type: data.file_type,
            from_user_id: data.from_user_id,
            to_user_id: data.to_user_id,
            file_name: data.single_chat_image,
            comp_id: data.comp_id,
            created_at: data.created_at,
        });

        if (user_details?.dataValues?.device_token) {
            const message_notification = {
                notification: {
                    title: user_details_from.userfullname,
                    body: data.file_type,
                    // imageUrl: `${complogo.logo_file_path}/${complogo.logo_file_name}`
                },
                data: {
                    from_user_id: `${data.from_user_id}`,
                    to_user_id: `${data.to_user_id}`,
                    userfullname: `${user_details_from.userfullname}`,
                    profileimg_path: `${user_details_from.dataValues.profileimg_path}`,
                    profileimg: `${user_details_from.dataValues.profileimg}`,
                    compprofile: `https://web.growthgrids.com/${complogo.logo_file_path + '/' + complogo.logo_file_name}`,
                    email: `${user_details_from.dataValues.email}`,
                },
                token: `${user_details?.dataValues?.device_token}`,
            };
            sendMessageapp(message_notification, "appInstance")
                .then((response) => {
                    console.log('Successfully sent message to app instance:', response);
                })
                .catch((error) => {
                    console.log('Error sending message to app instance:', error);
                });
        }
        if (user_details?.dataValues?.web_push_notification_token) {
            const message_notification_web = {
                notification: {
                    title: data.file_type,
                    body: data.original_file_name,
                },
                data: {
                    from_user_id: `${data.from_user_id}`,
                    to_user_id: `${data.to_user_id}`,
                    userfullname: `${user_details_from.userfullname}`,
                    profileimg_path: `${user_details_from.dataValues.profileimg_path}`,
                    profileimg: `${user_details_from.dataValues.profileimg}`,
                    compprofile: `https://web.growthgrids.com/${complogo.logo_file_path + '/' + complogo.logo_file_name}`,
                    email: `${user_details_from.dataValues.email}`,
                },
                token: `${user_details?.dataValues?.web_push_notification_token}`
            }
            sendMessageweb(message_notification_web, "webInstance")
                .then((response) => {
                    console.log('Successfully sent message to web instance:', response);
                })
                .catch((error) => {
                    console.log('Error sending message to web instance:', error);
                });

        }

        const user_details_rec = await Users.findAll({
            where: {
                id: {
                    [Op.ne]: data.from_user_id
                },
                comp_id: data.comp_id,
                isactive: '1'
            }, attributes: ['id'],

        })
        if (user_details_rec[0]) {
            for (const user_id of user_details_rec) {
                const check_exist = await Arrangementsmodel.count({ where: { user_comp_id: data.comp_id, from_user_id: data.from_user_id, to_user_id: user_id.id, status: '1' }, attributes: ['id'] })
                if (check_exist < 1) {
                    await Arrangementsmodel.create({
                        user_comp_id: data.comp_id,
                        from_user_id: data.from_user_id,
                        to_user_id: user_id.id,
                        created_by: data.from_user_id,
                        created_at: getCurrentDateTime()
                    })
                }
            }
            for (const user_id of user_details_rec) {
                const check_exist = await Arrangementsmodel.count({ where: { user_comp_id: data.comp_id, from_user_id: user_id.id, to_user_id: data.from_user_id, status: '1' }, attributes: ['id'] })
                if (check_exist < 1) {
                    await Arrangementsmodel.create({
                        user_comp_id: data.comp_id,
                        from_user_id: user_id.id,
                        to_user_id: data.from_user_id,
                        created_by: data.from_user_id,
                        created_at: getCurrentDateTime()
                    })
                }
            }

        }

        await Arrangementsmodel.update({
            updated_at: getCurrentDateTime(),
            updated_by: data.from_user_id,

        },
            {
                where: {
                    user_comp_id: data.comp_id,
                    from_user_id: data.to_user_id,
                    to_user_id: data.from_user_id,
                    status: '1'
                },

            })
        await Arrangementsmodel.update({
            updated_at: getCurrentDateTime(),
            updated_by: data.from_user_id,

        },
            {
                where: {
                    user_comp_id: data.comp_id,
                    from_user_id: data.from_user_id,
                    to_user_id: data.to_user_id,
                    status: '1'
                },

            })
        const UserList = await Arrangementsmodel.findAll({
            where: {
                user_comp_id: data.comp_id,
                from_user_id: data.from_user_id,
                status: '1'
            }, attributes: ['to_user_id'], order: [['updated_at', 'DESC']],

        })
        socket.emit('receive_sorting_ids', UserList);
        socket.to(Number(data.to_user_id)).emit("received_sorting_ids", UserList);
    });
    //----------------single caht file upload END---------

    //----------------group chat file upload start---------
    // socket.on('joinRoom_file', async (group_id) => {
    //     const user = { "socket_id": socket.id, "from_user_id": user_id, "group_id": group_id };
    //     if (getRoomUsers.includes(user.from_user_id)) {
    //         return false;
    //     } else {
    //         socket.join(user.group_id);
    //         socket.to(user.group_id).emit('roomUsers', {
    //             group_id: user.group_id,
    //             from_user_id: getRoomUsers.push(user.from_user_id)
    //         });
    //     }
    socket.on('send_group_file', async (data) => {

        const group_id = data.group_id;
        const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname', 'profileimg_path', 'profileimg'] });
        const username = {
            userfullname: user_details.userfullname,
            profileimg_path: user_details.profileimg_path,
            profileimg: user_details.profileimg,
        }
        socket.emit('receive_group_message', {
            original_file_name: data.original_file_name,
            from_user_id: user_details.id,
            group_id: group_id,
            is_file: '1',
            file_type: data.file_type,
            file_name: data.single_chat_image,
            user: username,
            created_at: data.created_at
        });
        socket.to(Number(group_id)).emit("received_group_message", {
            original_file_name: data.original_file_name,
            from_user_id: user_details.id,
            is_file: '1',
            group_id: group_id,
            file_type: data.file_type,
            file_name: data.single_chat_image,
            user: username,
            created_at: data.created_at
        });

        await Arrangementsgroupmodel.update({
            updated_at: getCurrentDateTime(),
            updated_by: user_details.id,

        },
            {
                where: {
                    user_comp_id: user_details.comp_id,
                    group_id: group_id,
                    status: '1'
                },

            })

        const response = await Arrangementsgroupmodel.findAll({
            where: {
                user_comp_id: user_details.comp_id,
                group_id: group_id,
                status: '1'
            }
        })
        socket.emit('group_receive_sorting_ids', response);
        socket.to(Number(group_id)).emit("group_received_sorting_ids", response);
    });
    // });

    socket.on('group_typing_event_start', async (data) => {
        if (!typinggroupusers.some(user => user.from_user_id === data.from_user_id)) {
            const obj = {
                from_user_id: data.from_user_id,
                group_id: data.group_id
            };

            typinggroupusers.push(obj);
        }
        socket.to(Number(data.group_id)).emit("received_group_typing_event_start", {
            data: typinggroupusers
        });
    });
    socket.on('group_typing_event_end', async (data) => {
        const index = typinggroupusers.findIndex(user => user.from_user_id === data.from_user_id);
        if (index > -1) {
            typinggroupusers.splice(index, 1);
        }
        
        socket.to(Number(data.group_id)).emit("received_group_typing_event_end", {
            data: typinggroupusers
        });
    });

    //============================================================================================

    //================== Get User By Id  ===========================
    async function getUserDetailsByUserId(user_id, tableName) {
        console.log(tableName, "===============")
        const user_details = await tableName.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })
        return (user_details) ? user_details : false;
    }

    //==================== Add To Do Commnent ==========================
    async function insertToDoCommentByUser(insert_val, comment_id) {

        if (comment_id != null) {

            if (insert_val.file_attachment) {
                let updFileObj = { file_attachment: insert_val.file_attachment, file_path: insert_val.file_path }
                const update_comment = await Todo_comments.update(updFileObj, { where: { id: comment_id, status: "1" } });
            }
            let updObj = { comment_txt: insert_val.comment_txt }
            const update_comment = await Todo_comments.update(updObj, { where: { id: comment_id, status: "1" } });
        } else {
            const create_comment = await Todo_comments.create(insert_val);
            var comnt_id = create_comment.id;
        }

        let whereCondLastCmnt = { id: (comment_id) ? comment_id : comnt_id }
        const getLastComment = await Todo_comments.findOne({
            order: [['id', 'DESC']],
            where: whereCondLastCmnt,
            attributes: ['id', 'user_comp_id', 'task_id', 'comment_txt', 'parent_id', 'file_attachment', 'file_path', 'ping_users_info', 'created_by', 'created_at'],
            include: [
                {
                    model: Todo_main_task,
                    attributes: ['id', 'task_name'],
                    required: false,
                }
            ]
        });
        
        const getTotalComment = await Todo_comments.count({
            where: { task_id: insert_val.task_id },
        });

        const responseObj =
        {
            id: getLastComment.id,
            task_id: getLastComment.task_id,
            task_name: getLastComment.todo_main_task.task_name,
            comment_txt: getLastComment.comment_txt,
            parent_id: getLastComment.parent_id,
            ping_users_info: getLastComment.ping_users_info,
            file_name: getLastComment.file_attachment,
            file_path: getLastComment.file_path,
            created_by: getLastComment.created_by,
            created_at: getLastComment.created_at,
            total_comment: getTotalComment,
            message_key: "todo_comment"
        };

        return { responseObj: responseObj, getLastComment: getLastComment };
    }


    //=================== Task Comment Start ======================
    socket.on('comment', async (data) => {
        
        const comment_id = data.comment_id;
        const comment_txt = data.comment_txt;
        const task_id = data.task_id;
        const ping_users = data.ping_users_info;
        const remarks = data.remarks;
        const parent_id = (data.parent_id) ? data.parent_id : 0;
        try {

            if (!data?.file?.[0]) {

                const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

                if (user_details) {
                    const insert_val = {
                        user_comp_id: user_details.comp_id,
                        task_id: task_id,
                        parent_id: parent_id,
                        comment_txt: comment_txt,
                        ping_users_info: ping_users,
                        created_at: getCurrentDateTime(),
                        created_by: user_id,
                    }

                    const addComment = await insertToDoCommentByUser(insert_val, comment_id);

                    const existingPingUsers = (addComment.getLastComment.ping_users_info) ? addComment.getLastComment.ping_users_info.split(',') : [];
                    const newPingUsers = (ping_users) ? ping_users.split(',') : [];
                    const extraPingUsers = newPingUsers.filter(user => !existingPingUsers.includes(user));

                    if (extraPingUsers[0] || newPingUsers[0]) {

                        var userIdNotify = (comment_id) ? extraPingUsers : newPingUsers;
                        if (comment_id) {
                            let updObj = { ping_users_info: ping_users }
                            const updatePingUsers = await Todo_comments.update(updObj, { where: { id: comment_id, status: "1" } });

                        }
                        await Promise.all(userIdNotify.map(async (item, index) => {
                            const addNotification = {
                                user_comp_id: user_details.comp_id,
                                mentioned_by: user_details.userfullname,
                                comment_text: addComment.getLastComment.comment_txt,
                                category_id: addComment.getLastComment.task_id,
                                category_details: addComment.getLastComment.todo_main_task.task_name,
                                ping_users_info: item,
                                remarks:remarks,
                                category_types: "to_do_comments",
                                created_at: getCurrentDateTime(),
                                created_by: user_id,
                            }

                            const notificationAdd = await notification.create(addNotification);

                            socket.to(Number(item)).emit(item, {
                                mentioned_by: notificationAdd.mentioned_by,
                                comment_text: notificationAdd.comment_text,
                                category_id: notificationAdd.category_id,
                                category_details: notificationAdd.category_details,
                                category_types: notificationAdd.category_types,
                                is_viewed: notificationAdd.is_viewed,
                                is_clicked: notificationAdd.is_clicked,
                                id: notificationAdd.id,
                                remarks: notificationAdd.remarks,
                                created_at: notificationAdd.created_at,
                                created_by:Number(notificationAdd.created_by)
                                

                            });
                        }));
                    }

                    // io.emit('task_comment_receive', responseObj);
                    io.emit(task_id, addComment.responseObj);

                    io.emit("all_notifications", addComment.responseObj);

                }

            } else {
                const fileFullName = data.file[0].name;
                const extension = path.extname(data.file[0].name);
                const fileName = path.parse(data.file[0].name).name;
                const uploadFile = fileName + `-${Date.now()}` + extension;
                const fileData = Buffer.from(data.file[0].originFileObj, 'base64');
                const filePath = "uploads/todo_comments/";

                fs.writeFile(`uploads/todo_comments/${uploadFile}`, fileData, 'utf8', async (err) => {

                    if (err) {
                        console.error('Error saving file:', err);
                    } else {
                        const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

                        if (user_details) {
                            const insert_val = {
                                user_comp_id: user_details.comp_id,
                                task_id: task_id,
                                parent_id: parent_id,
                                comment_txt: comment_txt,
                                ping_users_info: ping_users,
                                file_attachment: uploadFile,
                                file_path: filePath,
                                created_at: getCurrentDateTime(),
                                created_by: user_id,
                            }

                            const addComment = await insertToDoCommentByUser(insert_val, comment_id);

                            const existingPingUsers = (addComment.getLastComment.ping_users_info) ? addComment.getLastComment.ping_users_info.split(',') : [];
                            const newPingUsers = (ping_users) ? ping_users.split(',') : [];
                            const extraPingUsers = newPingUsers.filter(user => !existingPingUsers.includes(user));

                            if (extraPingUsers[0] || newPingUsers[0]) {

                                var userIdNotify = (comment_id) ? extraPingUsers : newPingUsers;
                                if (comment_id) {
                                    let updObj = { ping_users_info: ping_users }
                                    const updatePingUsers = await Todo_comments.update(updObj, { where: { id: comment_id, status: "1" } });

                                }
                                await Promise.all(userIdNotify.map(async (item, index) => {
                                    const addNotification = {
                                        user_comp_id: user_details.comp_id,
                                        mentioned_by: user_details.userfullname,
                                        comment_text: addComment.getLastComment.comment_txt,
                                        category_id: addComment.getLastComment.task_id,
                                        category_details: addComment.getLastComment.todo_main_task.task_name,
                                        ping_users_info: item,
                                        remarks:remarks,
                                        category_types: "to_do_comments",
                                        created_at: getCurrentDateTime(),
                                        created_by: user_id,
                                    }

                                    const notificationAdd = await notification.create(addNotification);

                                    socket.to(Number(item)).emit(item, {
                                        mentioned_by: notificationAdd.mentioned_by,
                                        comment_text: notificationAdd.comment_text,
                                        category_id: notificationAdd.category_id,
                                        category_details: notificationAdd.category_details,
                                        category_types: notificationAdd.category_types,
                                        is_viewed: notificationAdd.is_viewed,
                                        is_clicked: notificationAdd.is_clicked,
                                        id: notificationAdd.id,
                                        remarks: notificationAdd.remarks,
                                        created_at: notificationAdd.created_at,
                                        created_by:Number(notificationAdd.created_by)

                                    });
                                }));
                            }

                            // io.emit('task_comment_receive', responseObj);
                            io.emit(task_id, addComment.responseObj)

                            io.emit("all_notifications", addComment.responseObj);

                        }
                    }
                })
            }

        } catch (error) {
            console.log('error', error)

        }
    });
    //================= Task Comment End ==========================

    //==================== Add Tender Commnent ==========================
    async function insertTenderCommentByUser(insert_val, comment_id, comp_id) {
        if (comment_id != null) {
            if (insert_val.file_attachment) {
                let updFileObj = { file_attachment: insert_val.file_attachment, file_path: insert_val.file_path }
                await Tender_comments.update(updFileObj, { where: { id: comment_id, status: "1" } });
            }
            let updObj = { comment_txt: insert_val.comment_txt }
            const update_comment = await Tender_comments.update(updObj, { where: { id: comment_id, status: "1" } });
        } else {
            const create_comment = await Tender_comments.create(insert_val);
            var comnt_id = create_comment.id;
        }

        let whereCondLastCmnt = { id: (comment_id) ? comment_id : comnt_id }
        const getLastComment = await Tender_comments.findOne({
            order: [['id', 'DESC']],
            where: whereCondLastCmnt,
            attributes: ['id', 'user_comp_id', 'file_attachment', 'file_path', 'tender_id', 'comment_txt', 'parent_id', 'ping_users_info', 'created_by', 'created_at'],

        });

        const tender_details = await createTenderModel(comp_id).findOne({
            order: [['id', 'DESC']],
            where: {id:insert_val.tender_id},
            attributes: ['id', 'tender_name',],

        });

        const getTotalComment = await Tender_comments.count({
            where: { tender_id: insert_val.tender_id },
        });

        const responseObj = {
            id: getLastComment.id,
            tender_id: Number(getLastComment.tender_id),
            tender_name: tender_details?.tender_name,
            comment_txt: getLastComment.comment_txt,
            parent_id: Number(getLastComment.parent_id),
            ping_users_info: getLastComment.ping_users_info,
            file_name: getLastComment.file_attachment,
            file_path: getLastComment.file_path,
            created_by: Number(getLastComment.created_by),
            created_at: getLastComment.created_at,
            total_comment: getTotalComment,
            message_key: "tender_comment"
        };

        return { responseObj: responseObj, getLastComment: getLastComment, tender_details:tender_details };
    }

    //==================== End add tender comment ==========================

    //=================== Tender Comment Start ======================
    socket.on('tender_comment', async (data) => {

        const comment_id = data.comment_id;
        const comment_txt = data.comment_txt;
        const tender_id = data.tender_id;
        const ping_users = data.ping_users_info;
        const remarks = data.remarks;
        const parent_id = (data.parent_id) ? data.parent_id : 0;
        try {
            if (!data?.file?.[0]) {
                const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

                if (user_details) {
                    const insert_val = {
                        user_comp_id: user_details.comp_id,
                        tender_id: tender_id,
                        parent_id: parent_id,
                        comment_txt: comment_txt,
                        ping_users_info: ping_users,
                        created_at: getCurrentDateTime(),
                        created_by: user_id,
                    }

                    const addComment = await insertTenderCommentByUser(insert_val, comment_id, user_details.comp_id);

                    const existingPingUsers = (addComment.getLastComment.ping_users_info) ? addComment.getLastComment.ping_users_info.split(',') : [];
                    const newPingUsers = (ping_users) ? ping_users.split(',') : [];
                    const extraPingUsers = newPingUsers.filter(user => !existingPingUsers.includes(user));

                    if (extraPingUsers[0] || newPingUsers[0]) {

                        var userIdNotify = (comment_id) ? extraPingUsers : newPingUsers;
                        if (comment_id) {
                            let updObj = { ping_users_info: ping_users }
                            const updatePingUsers = await Tender_comments.update(updObj, { where: { id: comment_id, status: "1" } });

                        }

                        await Promise.all(userIdNotify.map(async (item) => {

                            const addNotification = {
                                user_comp_id: user_details.comp_id,
                                mentioned_by: user_details.userfullname,
                                comment_text: addComment.getLastComment.comment_txt,
                                tender_id: addComment.getLastComment.tender_id,
                                category_details: addComment.tender_details.tender_name,
                                ping_users_info: item,
                                remarks:remarks,
                                category_types: "tender_comments",
                                created_at: getCurrentDateTime(),
                                created_by: user_id,
                            }

                            const notificationAdd = await notification.create(addNotification);
                            
                            socket.to(Number(item)).emit(item, {
                                mentioned_by: notificationAdd.mentioned_by,
                                comment_text: notificationAdd.comment_text,
                                tender_id: notificationAdd.tender_id,
                                category_details: notificationAdd.category_details,
                                category_types: notificationAdd.category_types,
                                is_viewed: notificationAdd.is_viewed,
                                is_clicked: notificationAdd.is_clicked,
                                id: notificationAdd.id,
                                remarks: notificationAdd.remarks,
                                created_at: notificationAdd.created_at,
                                created_by:Number(notificationAdd.created_by)
                            });

                        }));
                    }

                    io.emit(tender_id, addComment.responseObj)
                    io.emit("all_notifications", addComment.responseObj);
                    // io.emit('tender_comment_receive', responseObj);
                }

            } else {

                const fileFullName = data.file[0].name;
                const extension = path.extname(data.file[0].name);
                const fileName = path.parse(data.file[0].name).name;
                const uploadFile = fileName + `-${Date.now()}` + extension;
                const fileData = Buffer.from(data.file[0].originFileObj, 'base64');
                const filePath = "uploads/tender_comments/";

                fs.writeFile(`uploads/tender_comments${uploadFile}`, fileData, 'utf8', async (err) => {

                    if (err) {
                        console.error('Error saving file:', err);
                    } else {
                        const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'], },);

                        if (user_details) {
                            const insert_val = {
                                user_comp_id: user_details.comp_id,
                                tender_id: tender_id,
                                parent_id: parent_id,
                                comment_txt: comment_txt,
                                file_attachment: uploadFile,
                                file_path: filePath,
                                ping_users_info: ping_users,
                                created_at: getCurrentDateTime(),
                                created_by: user_id,
                            }

                            const addComment = await insertTenderCommentByUser(insert_val, comment_id, user_details.comp_id);

                            const existingPingUsers = (addComment.getLastComment.ping_users_info) ? addComment.getLastComment.ping_users_info.split(',') : [];
                            const newPingUsers = (ping_users) ? ping_users.split(',') : [];
                            const extraPingUsers = newPingUsers.filter(user => !existingPingUsers.includes(user));

                            if (extraPingUsers[0] || newPingUsers[0]) {

                                var userIdNotify = (comment_id) ? extraPingUsers : newPingUsers;
                                if (comment_id) {
                                    let updObj = { ping_users_info: ping_users }
                                    const updatePingUsers = await Tender_comments.update(updObj, { where: { id: comment_id, status: "1" } });

                                }

                                await Promise.all(userIdNotify.map(async (item) => {

                                    const addNotification = {
                                        user_comp_id: user_details.comp_id,
                                        mentioned_by: user_details.userfullname,
                                        comment_text: addComment.getLastComment.comment_txt,
                                        tender_id: addComment.getLastComment.tender_id,
                                        category_details: addComment.tender_details.tender_name,
                                        ping_users_info: item,
                                        remarks:remarks,
                                        category_types: "tender_comments",
                                        created_at: getCurrentDateTime(),
                                        created_by: user_id,
                                    }

                                    const notificationAdd = await notification.create(addNotification);

                                    socket.to(Number(item)).emit(item, {
                                        mentioned_by: notificationAdd.mentioned_by,
                                        comment_text: notificationAdd.comment_text,
                                        tender_id: notificationAdd.tender_id,
                                        category_details: notificationAdd.category_details,
                                        category_types: notificationAdd.category_types,
                                        is_viewed: notificationAdd.is_viewed,
                                        is_clicked: notificationAdd.is_clicked,
                                        id: notificationAdd.id,
                                        remarks: notificationAdd.remarks,
                                        created_at: notificationAdd.created_at,
                                        created_by:Number(notificationAdd.created_by)
                                    });

                                }));
                            }

                            io.emit(tender_id, addComment.responseObj)
                            io.emit("all_notifications", addComment.responseObj);

                        }
                    }
                })
            }

        } catch (error) {
            console.log('error', error)

        }

    });
    //================= Tender Comment End ==========================

    //=================== Tender Request Start ======================
    socket.on('tender_request', async (data) => {

        const tender_id = data.tender_id;
        const tender_req_id = data.tender_req_id;
        const ping_users = data.ping_users_info;
        const request_subject = data.request_subject;
        const remarks = data.remarks;
        try {
            const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

            if (user_details) {

                const user_id_arr = ping_users.split(',');

                if (user_id_arr[0]) {

                    const insert_val = {
                        user_comp_id: user_details.comp_id,
                        mentioned_by: user_details.userfullname,
                        tender_id: tender_id,
                        category_id: tender_req_id,
                        category_details: request_subject,
                        ping_users_info: user_id_arr[0],
                        remarks:remarks,
                        category_types: "tender_request",
                        created_at: getCurrentDateTime(),
                        created_by: user_id,
                    }

                    const notificationAdd = await notification.create(insert_val);

                    socket.to(Number(user_id_arr[0])).emit(user_id_arr[0], {
                        mentioned_by: notificationAdd.mentioned_by,
                        tender_id: notificationAdd.tender_id,
                        category_id: notificationAdd.category_id,
                        category_details: notificationAdd.category_details,
                        category_types: notificationAdd.category_types,
                        is_viewed: notificationAdd.is_viewed,
                        is_clicked: notificationAdd.is_clicked,
                        id: notificationAdd.id,
                        remarks: notificationAdd.remarks,
                        created_at: notificationAdd.created_at,
                        created_by:Number(notificationAdd.created_by)
                    });

                }

            }
        } catch (error) {
            console.log('error', error)

        }
    });
    // ================= Tender Request End ==========================

    //=================== Status Tender Request Start ======================
    socket.on('tender_request_status', async (data) => {

        const notifyUserId = data.user_id;
        const tender_req_id = data.tender_req_id;
        const tender_id = data.tender_id;
        const remarks = data.remarks;
        try {
            const user_details = await Users.findOne({ where: { id: notifyUserId, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

            if (user_details) {

                // const user_id_arr = ping_users.split(',');

                if (notifyUserId) {

                    const insert_val = {
                        user_comp_id: user_details.comp_id,
                        mentioned_by: user_details.userfullname,
                        tender_id: tender_id,
                        category_id: tender_req_id,
                        category_details: request_subject,
                        ping_users_info: notifyUserId,
                        remarks:remarks,
                        category_types: "tender_request",
                        created_at: getCurrentDateTime(),
                        created_by: user_id,
                    }

                    const notificationAdd = await notification.create(insert_val);

                    socket.to(Number(notifyUserId)).emit(notifyUserId, {
                        mentioned_by: notificationAdd.mentioned_by,
                        tender_id: notificationAdd.tender_id,
                        category_id: notificationAdd.category_id,
                        category_details: notificationAdd.category_details,
                        category_types: notificationAdd.category_types,
                        is_viewed: notificationAdd.is_viewed,
                        is_clicked: notificationAdd.is_clicked,
                        id: notificationAdd.id,
                        remarks: notificationAdd.remarks,
                        created_at: notificationAdd.created_at,
                        created_by:Number(notificationAdd.created_by)
                    });

                }

            }
        } catch (error) {
            console.log('error', error)

        }
    });
    // ========================= End ================================


    // =================== Meeting Schedule Start ======================
    socket.on('meeting_scheduled', async (data) => {

        const tender_id = data.tender_id;
        const meeting_id = data.meeting_id;
        const ping_users = data.ping_users_info;
        const meeting_title = data.meeting_title;
        const remarks = data.remarks;
        try {

            const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })
            if (user_details) {

                const user_id_arr = ping_users.split(',');

                if (user_id_arr[0]) {

                    await Promise.all(user_id_arr.map(async (item) => {

                        const insert_val = {
                            user_comp_id: user_details.comp_id,
                            mentioned_by: user_details.userfullname,
                            tender_id: tender_id,
                            category_id: meeting_id,
                            category_details: meeting_title,
                            category_types: "meeting_schedule",
                            ping_users_info: item,
                            remarks:remarks,
                            created_at: getCurrentDateTime(),
                            created_by: user_id,
                        }

                        const notificationAdd = await notification.create(insert_val);

                        // socket.to(Number(item)).emit("meeting_received", {
                        socket.to(Number(item)).emit(item, {
                            mentioned_by: notificationAdd.mentioned_by,
                            tender_id: notificationAdd.tender_id,
                            category_id: notificationAdd.category_id,
                            category_details: notificationAdd.category_details,
                            category_types: notificationAdd.category_types,
                            is_viewed: notificationAdd.is_viewed,
                            is_clicked: notificationAdd.is_clicked,
                            id: notificationAdd.id,
                            remarks: notificationAdd.remarks,
                            created_at: notificationAdd.created_at,
                            created_by:Number(notificationAdd.created_by)
                        });
                    }));
                }
            }

        } catch (error) {
            console.log('error', error)
        }
    });
    // ================= Meeting Schedule End ==========================

    //==================== Add To Do Commnent ==========================
    async function insertTenderTodoCommentByUser(insert_val, comment_id, comp_id) {

        if (comment_id != null) {
            if (insert_val.file_attachment) {
                let updFileObj = { file_attachment: insert_val.file_attachment, file_path: insert_val.file_path }
                await ProjectTodoCommentModel.update(updFileObj, { where: { id: comment_id, status: "1" } });
            }
            let updObj = { comment_txt: insert_val.comment_txt }
            const update_comment = await ProjectTodoCommentModel.update(updObj, { where: { id: comment_id, status: "1" } });
        } else {
            const create_comment = await ProjectTodoCommentModel.create(insert_val);
            var comnt_id = create_comment.id;
        }
        
        let whereCondLastCmnt = { id: (comment_id) ? comment_id : comnt_id }
        const getLastComment = await ProjectTodoCommentModel.findOne({
            order: [['id', 'DESC']],
            where: whereCondLastCmnt,
            attributes: ['id', 'user_comp_id', 'file_attachment', 'file_path', ['project_id', 'tender_id'], 'task_id', 'comment_txt', 'parent_id', 'ping_users_info', 'created_by', 'created_at'],
        });

        const tender_details = await createTenderModel(comp_id).findOne({
            order: [['id', 'DESC']],
            where: {id:insert_val.project_id},
            attributes: ['id', 'tender_name',],

        });

        const getTotalComment = await ProjectTodoCommentModel.count({
            where: { task_id: insert_val.task_id, project_id: insert_val.project_id },
        });

        const taskDetails = await ProjectTodo.findOne({
            where: { id: insert_val.task_id },
            attributes: ['id', 'task_name']
        })

        const responseObj = {
            id: getLastComment.id,
            tender_id: insert_val.project_id,
            task_id: getLastComment.task_id,
            tender_name: tender_details?.tender_name,
            comment_txt: getLastComment.comment_txt,
            parent_id: getLastComment.parent_id,
            ping_users_info: getLastComment.ping_users_info,
            file_name: getLastComment.file_attachment,
            file_path: getLastComment.file_path,
            created_by: getLastComment.created_by,
            created_at: getLastComment.created_at,
            total_comment: getTotalComment,
            message_key: "tender_todo_comment"
        };

        return { responseObj: responseObj, getLastComment: getLastComment, taskDetails: taskDetails, tender_details: tender_details };
    }

    //==================== End add tender comment ==========================

    // =================== Tender Comment Start ======================
    socket.on('tender_todo_comment', async (data) => {

        const comment_id = data.comment_id;
        const comment_txt = data.comment_txt;
        const tender_id = data.tender_id;
        const task_id = data.task_id;
        const ping_users = data.ping_users_info;
        const parent_id = (data.parent_id) ? data.parent_id : 0;
        const remarks = data.remarks;

        try {

            if (!data?.file?.[0]) {
                const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

                if (user_details) {
                    const insert_val = {
                        user_comp_id: user_details.comp_id,
                        project_id: tender_id,
                        task_id: task_id,
                        parent_id: parent_id,
                        comment_txt: comment_txt,
                        ping_users_info: ping_users,
                        created_at: getCurrentDateTime(),
                        created_by: user_id,
                    }

                    const addComment = await insertTenderTodoCommentByUser(insert_val, comment_id, user_details.comp_id);

                    const existingPingUsers = (addComment.getLastComment.ping_users_info) ? addComment.getLastComment.ping_users_info.split(',') : [];
                    const newPingUsers = (ping_users) ? ping_users.split(',') : [];
                    const extraPingUsers = newPingUsers.filter(user => !existingPingUsers.includes(user));

                    if (extraPingUsers[0] || newPingUsers[0]) {

                        var userIdNotify = (comment_id) ? extraPingUsers : newPingUsers;
                        if (comment_id) {
                            let updObj = { ping_users_info: ping_users }
                            const updatePingUsers = await ProjectTodoCommentModel.update(updObj, { where: { id: comment_id, status: "1" } });

                        }

                        await Promise.all(userIdNotify.map(async (item) => {

                            const addNotification = {
                                user_comp_id: user_details.comp_id,
                                mentioned_by: user_details.userfullname,
                                comment_text: addComment.getLastComment.comment_txt,
                                tender_id: addComment?.tender_details?.id,
                                category_id: addComment.getLastComment.task_id,
                                category_details: addComment.taskDetails.task_name,
                                category_types: "tender_todo_comments",
                                ping_users_info: item,
                                remarks: remarks,
                                created_at: getCurrentDateTime(),
                                created_by: user_id,
                            }

                            const notificationAdd = await notification.create(addNotification);

                            socket.to(Number(item)).emit(item, {
                                mentioned_by: notificationAdd.mentioned_by,
                                comment_text: notificationAdd.comment_text,
                                tender_id: notificationAdd.tender_id,
                                category_id: notificationAdd.category_id,
                                category_details: notificationAdd.category_details,
                                category_types: notificationAdd.category_types,
                                is_viewed: notificationAdd.is_viewed,
                                is_clicked: notificationAdd.is_clicked,
                                id: notificationAdd.id,
                                remarks: notificationAdd.remarks,
                                created_at: notificationAdd.created_at,
                                created_by:Number(notificationAdd.created_by)
                            });

                        }));
                    }
                    
                    // io.emit(tender_id, responseObj)
                    io.emit(task_id, addComment.responseObj);
                    io.emit("all_notifications", addComment.responseObj);
                }

            } else {
                const fileFullName = data.file[0].name;
                const extension = path.extname(data.file[0].name);
                const fileName = path.parse(data.file[0].name).name;
                const uploadFile = fileName + `-${Date.now()}` + extension;
                const fileData = Buffer.from(data.file[0].originFileObj, 'base64');
                const filePath = "uploads/tender_comments/";

                fs.writeFile(`uploads/todo_comments/${uploadFile}`, fileData, 'utf8', async (err) => {

                    if (err) {
                        console.error('Error saving file:', err);
                    } else {

                        const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

                        if (user_details) {
                            const insert_val = {
                                user_comp_id: user_details.comp_id,
                                project_id: tender_id,
                                task_id: task_id,
                                parent_id: parent_id,
                                comment_txt: comment_txt,
                                file_attachment: uploadFile,
                                file_path: filePath,
                                ping_users_info: ping_users,
                                created_at: getCurrentDateTime(),
                                created_by: user_id,
                            }

                            const addComment = await insertTenderTodoCommentByUser(insert_val, comment_id, user_details.comp_id);

                            const existingPingUsers = (addComment.getLastComment.ping_users_info) ? addComment.getLastComment.ping_users_info.split(',') : [];
                            const newPingUsers = (ping_users) ? ping_users.split(',') : [];
                            const extraPingUsers = newPingUsers.filter(user => !existingPingUsers.includes(user));

                            if (extraPingUsers[0] || newPingUsers[0]) {

                                var userIdNotify = (comment_id) ? extraPingUsers : newPingUsers;
                                if (comment_id) {
                                    let updObj = { ping_users_info: ping_users }
                                    const updatePingUsers = await ProjectTodoCommentModel.update(updObj, { where: { id: comment_id, status: "1" } });

                                }

                                await Promise.all(userIdNotify.map(async (item) => {

                                    const addNotification = {
                                        user_comp_id: user_details.comp_id,
                                        mentioned_by: user_details.userfullname,
                                        comment_text: addComment.getLastComment.comment_txt,
                                        tender_id: addComment?.tender_details?.id,
                                        category_id: addComment.getLastComment.task_id,
                                        category_details: addComment.taskDetails.task_name,
                                        category_types: "tender_todo_comments",
                                        ping_users_info: item,
                                        remarks: remarks,
                                        created_at: getCurrentDateTime(),
                                        created_by: user_id,
                                    }
                                    
                                    const notificationAdd = await notification.create(addNotification);

                                    socket.to(Number(item)).emit(item, {
                                        mentioned_by: notificationAdd.mentioned_by,
                                        comment_text: notificationAdd.comment_text,
                                        tender_id: notificationAdd.tender_id,
                                        category_id: notificationAdd.category_id,
                                        category_details: notificationAdd.category_details,
                                        category_types: notificationAdd.category_types,
                                        is_viewed: notificationAdd.is_viewed,
                                        is_clicked: notificationAdd.is_clicked,
                                        id: notificationAdd.id,
                                        remarks: notificationAdd.remarks,
                                        created_at: notificationAdd.created_at,
                                        created_by:Number(notificationAdd.created_by)
                                    });

                                }));
                            }

                            // io.emit(tender_id, responseObj)
                            io.emit(task_id, addComment.responseObj);
                            io.emit("all_notifications", addComment.responseObj);

                        }
                    }
                })
            }



        } catch (error) {
            console.log('error', error)

        }
    });
    //================= Tender Todo Comment End ==========================


    // =================== Reminder Start ======================
    socket.on('reminder', async (data) => {

        try {

            const now = moment();
            let todayDate = now.format('YYYY-MM-DD')
            let reminderTime = "10:00:00 PM";
            if(now.format('HH:mm:ss a') > reminderTime){
                console.log(now.format('YYYY-MM-DD')); 
                console.log(now.format('HH:mm:ss a')); 
            }

        } catch (error) {
            console.log('error', error)
        }
    });
    // ========================= End ==============================

    // =================== Task Assign and Create Start ======================
    socket.on('create_task', async (data) => { 

        const task_id = data.task_id;
        const tender_todo = data.tender_todo;
        const remarks = data.remarks;
        try {

            const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })
            if(tender_todo == true) {
                const tenderTodoTask = await ProjectTodo.findOne({ 
                    where: { id: task_id, status: '1' },
                    attributes: ['id', 'user_comp_id', 'task_name'],
                })
    
                const assignedTask = await project_todo_assigned_tasks.findAll({ 
                    where: { task_id: task_id, status: '1' },
                    attributes: ['id', 'task_id','user_comp_id', 'assigned_to_userid'],
                })
    
                await Promise.all(assignedTask.map(async (item, index) => {
                        const addNotification = {
                            user_comp_id: item.user_comp_id,
                            mentioned_by: user_details.userfullname,
                            comment_text: null,
                            category_id: item.task_id,
                            tender_id: tenderTodoTask.project_id,
                            category_details: tenderTodoTask.task_name,
                            ping_users_info: item.assigned_to_userid,
                            remarks: remarks,
                            category_types: "create_task",
                            created_at: getCurrentDateTime(),
                            created_by: user_id,
                        }
    
                        const notificationAdd = await notification.create(addNotification);
    
                        socket.to(Number(item.assigned_to_userid)).emit(item.assigned_to_userid, {
                            mentioned_by:notificationAdd.mentioned_by,
                            category_id: notificationAdd.category_id,
                            tender_id: notificationAdd.tender_id,
                            category_details: notificationAdd.category_details,
                            category_types: notificationAdd.category_types,
                            is_viewed: notificationAdd.is_viewed,
                            is_clicked: notificationAdd.is_clicked,
                            id: notificationAdd.id,
                            remarks: notificationAdd.remarks,
                            created_at: notificationAdd.created_at,
                            created_by:Number(notificationAdd.created_by)
                        });
                }))
            } else {
                const todoTask = await Todolist.findOne({ 
                    where: { id: task_id, status: '1' },
                    attributes: ['id', 'user_comp_id', 'task_name'],
                })
    
                const assignedTask = await Assignedtask.findAll({ 
                    where: { task_id: task_id, status: '1' },
                    attributes: ['id', 'task_id','user_comp_id', 'assigned_to_userid'],
                })
    
                await Promise.all(assignedTask.map(async (item, index) => {
                        const addNotification = {
                            user_comp_id: item.user_comp_id,
                            mentioned_by: user_details.userfullname,
                            comment_text: null,
                            category_id: item.task_id,
                            category_details: todoTask.task_name,
                            ping_users_info: item.assigned_to_userid,
                            remarks: remarks,
                            category_types: "create_task",
                            created_at: getCurrentDateTime(),
                            created_by: user_id,
                        }
    
                        const notificationAdd = await notification.create(addNotification);
    
                        socket.to(Number(item.assigned_to_userid)).emit(item.assigned_to_userid, {
                            mentioned_by:notificationAdd.mentioned_by,
                            category_id: notificationAdd.category_id,
                            category_details: notificationAdd.category_details,
                            category_types: notificationAdd.category_types,
                            is_viewed: notificationAdd.is_viewed,
                            is_clicked: notificationAdd.is_clicked,
                            id: notificationAdd.id,
                            remarks: notificationAdd.remarks,
                            created_at: notificationAdd.created_at,
                            created_by:Number(notificationAdd.created_by)
                        });
                }))
            }
            

        } catch (error) {
            console.log('error', error)
        }
    });
    // ========================= End ==============================

    // =================== Assign Manager on Tender Start ======================
    socket.on('assign_manager', async (data) => {
        
        const tender_id = data.tender_id;
        const assigned_user_id = data.assigned_user_id;
        const remarks = data.remarks;
        try {

            const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

            if(user_details){
                const TenderModel = createTenderModel(user_details.comp_id);
                await TenderModel.performOperation();
                const tenderData = await TenderModel.findOne({ 
                    where: { id: tender_id, status: '1' },
                    attributes: ['id', 'user_comp_id', 'tender_name'],
                })

                const tndrAssignMngr = await TenderAssignManagerModel.findOne({ 
                    where: { tender_id: tender_id, assign_to: assigned_user_id, status: '1' },
                    attributes: ['id', 'tender_id','user_comp_id', 'assign_to'], 
                    // include: [
                    //     {
                    //       model:TenderBdRoleModel,
                    //       where:{ status:"1" },
                    //       attributes:["id", "role_name"]
                    //     }
                    //   ]
                })
                
                const addNotification = {
                    user_comp_id: tndrAssignMngr.user_comp_id,
                    mentioned_by: user_details.userfullname,
                    comment_text: null,
                    tender_id: tender_id,
                    category_id: null,
                    category_details: tenderData.tender_name,
                    ping_users_info: tndrAssignMngr.assign_to,
                    remarks: remarks,
                    category_types: "tender_assign_manager",
                    created_at: getCurrentDateTime(),
                    created_by: user_id,
                }

                const notificationAdd = await notification.create(addNotification);

                socket.to(Number(assigned_user_id)).emit(assigned_user_id, {
                    id: notificationAdd.id,
                    tender_id:notificationAdd.tender_id,
                    mentioned_by:notificationAdd.mentioned_by,
                    category_id: notificationAdd.category_id,
                    category_details: notificationAdd.category_details,
                    category_types: notificationAdd.category_types,
                    remarks: notificationAdd.remarks,
                    is_viewed: notificationAdd.is_viewed,
                    is_clicked: notificationAdd.is_clicked,
                    created_at: notificationAdd.created_at,
                    created_by:Number(notificationAdd.created_by)
                });
                
            }

        } catch (error) {
            console.log('error', error)
        }
    });
    // ========================= End ==============================

    // =================== Assign Manager on Tender Start ======================
    socket.on('scope_change', async (data) => {
        
        const tender_id = data.tender_id;
        const remarks = data.remarks;
        try {
            const user_details = await Users.findOne({ where: { id: user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

            if(user_details){
                const TenderModel = createTenderModel(user_details.comp_id);
                await TenderModel.performOperation();
                const tenderData = await TenderModel.findOne({ 
                    where: { id: tender_id, status: '1' },
                    attributes: ['id', 'user_comp_id', 'tender_name'],
                })

                const tndrAssignMngr = await TenderAssignManagerModel.findAll({ 
                    where: { tender_id: tender_id, status: '1' },
                    order: [['id', 'DESC']],
                    attributes: ['id', 'tender_id','user_comp_id', 'assign_to'], 
                    include: [
                        {
                          model:TenderBdRoleModel,
                          where:{ status:"1" },
                          attributes:["id", "role_name"]
                        }
                      ]
                })
                
                const uniqueAssignTo = [...new Set(tndrAssignMngr.map(item => item.assign_to))];

                await Promise.all(uniqueAssignTo.map(async (assignTo) => {
                    
                    const item = tndrAssignMngr.find(i => i.assign_to === assignTo);
                    if (!item) return;

                        const addNotification = {
                            user_comp_id: item.user_comp_id,
                            mentioned_by: user_details.userfullname,
                            comment_text: null,
                            tender_id: tender_id,
                            category_id: null,
                            category_details: tenderData.tender_name,
                            ping_users_info: item.assign_to,
                            remarks: remarks,
                            category_types: "scope_change",
                            created_at: getCurrentDateTime(),
                            created_by: user_id,
                        }

                        const notificationAdd = await notification.create(addNotification);

                        socket.to(Number(item.assign_to)).emit(item.assign_to, {
                            id: notificationAdd.id,
                            mentioned_by:notificationAdd.mentioned_by,
                            tender_id:notificationAdd.tender_id,
                            category_id: notificationAdd.category_id,
                            category_details: notificationAdd.category_details,
                            category_types: notificationAdd.category_types,
                            remarks: notificationAdd.remarks,
                            is_viewed: notificationAdd.is_viewed,
                            is_clicked: notificationAdd.is_clicked,
                            created_at: notificationAdd.created_at,
                            created_by:Number(notificationAdd.created_by)
                        });

                }))
            }

        } catch (error) {
            console.log('error', error)
        }
    });
    // ========================= End ==============================

    // =================== User Update notification Start ======================
    socket.on('user_update', async (data) => {
        
        const upd_user_id = data.user_id;
        const comp_id = data.comp_id;
        try {

            if(comp_id){
                
                const usersByComp = await Users.findAll({ where: { comp_id: comp_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname', 'is_user_notified'] })
                
                if(usersByComp[0]) {
                
                    await Promise.all(usersByComp.map(async (item) => {
                        const upd_userData = await Users.update({is_user_notified:'1'}, { where: { id: item.id, isactive: "1" } })
                    }));
                
                    io.emit('is_refresh', {
                        is_user_notified: 1,
                        isNotifiedBool : true
                    });
                }
            } else {
                const user_details = await Users.findOne({ where: { id: upd_user_id, isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname', 'is_user_notified'] })
                
                if(user_details){
                    const addNotification = {
                        user_comp_id: user_details.comp_id,
                        mentioned_by: user_details.userfullname,
                        comment_text: null,
                        tender_id: null,
                        category_id: null,
                        category_details: "User update notification",
                        ping_users_info: upd_user_id,
                        remarks: null,
                        category_types: "user_update_notify",
                        created_at: getCurrentDateTime(),
                        created_by: user_id,
                    }

                    const notificationAdd = await notification.create(addNotification);

                    io.emit(`is_refresh_${upd_user_id}`, {
                        id: notificationAdd.id,
                        mentioned_by:notificationAdd.mentioned_by,
                        category_details: notificationAdd.category_details,
                        category_types: notificationAdd.category_types,
                        is_viewed: notificationAdd.is_viewed,
                        is_clicked: notificationAdd.is_clicked,
                        created_at: notificationAdd.created_at,
                        created_by:Number(notificationAdd.created_by)
                    });
                }
            }

        } catch (error) {
            console.log('error', error)
        }
    });
    // ========================= End ==============================


    // =================== Assign Manager on Tender Start ======================
    socket.on('todo_scope_change', async (data) => {
        
        const task_id = data.task_id;
        const remarks = data.remarks;
        const tender_todo = data.tender_todo;
        const tender_id = data.tender_id;
        try {

            const user_details = await Users.findOne({ where: { id: Number(user_id), isactive: '1' }, attributes: ['id', 'comp_id', 'userfullname'] })

            if(user_details){
    
                if(tender_todo){
                    const tenderTodoTask = await ProjectTodo.findOne({ 
                        where: { id: task_id, status: '1' },
                    })
        
                    const assignedTask = await project_todo_assigned_tasks.findAll({ 
                        where: { task_id: task_id, project_id:tender_id, status: '1' },
                        order: [['id', 'DESC']],
                    })

                    const uniqueAssignTo = [...new Set(assignedTask.map(item => item.assigned_to_userid))];
                    
                    await Promise.all(uniqueAssignTo.map(async (assigned_to_userid) => {
                        
                        const item = assignedTask.find(i => i.assigned_to_userid === assigned_to_userid);
                        if (!item) return;
                            const addNotification = {
                                user_comp_id: item.user_comp_id,
                                mentioned_by: user_details.userfullname,
                                comment_text: null,
                                tender_id: tender_id,
                                category_id: task_id,
                                category_details: tenderTodoTask.task_name,
                                ping_users_info: item.assigned_to_userid,
                                remarks: remarks,
                                category_types: "tender_todo_scope_change",
                                created_at: getCurrentDateTime(),
                                created_by: user_id,
                            }

                            const notificationAdd = await notification.create(addNotification);
                            socket.to(Number(item.assigned_to_userid)).emit(item.assigned_to_userid, {
                                id: notificationAdd.id,
                                mentioned_by:notificationAdd.mentioned_by,
                                tender_id:notificationAdd.tender_id,
                                category_id: notificationAdd.category_id,
                                category_details: notificationAdd.category_details,
                                category_types: notificationAdd.category_types,
                                remarks: notificationAdd.remarks,
                                is_viewed: notificationAdd.is_viewed,
                                is_clicked: notificationAdd.is_clicked,
                                created_at: notificationAdd.created_at,
                                created_by:Number(notificationAdd.created_by)
                            });

                    }))
    
                }else{
                    const taskData = await Todolist.findOne({ 
                        where: { id: task_id, status: '1' },
                    })
    
                    const taskAssignMngr = await Assignedtask.findAll({ 
                        where: { task_id: task_id, status: '1' },
                        order: [['id', 'DESC']],
                        
                    })
                    
                    const uniqueAssignTo = [...new Set(taskAssignMngr.map(item => item.assigned_to_userid))];

                    await Promise.all(uniqueAssignTo.map(async (assigned_to_userid) => {
                        
                        const item = taskAssignMngr.find(i => i.assigned_to_userid === assigned_to_userid);
                        if (!item) return;
    
                            const addNotification = {
                                user_comp_id: item.user_comp_id,
                                mentioned_by: user_details.userfullname,
                                comment_text: null,
                                tender_id: null,
                                category_id: task_id,
                                category_details: taskData.task_name,
                                ping_users_info: item.assigned_to_userid,
                                remarks: remarks,
                                category_types: "todo_scope_change",
                                created_at: getCurrentDateTime(),
                                created_by: user_id,
                            }
    
                            const notificationAdd = await notification.create(addNotification);
                            socket.to(Number(item.assigned_to_userid)).emit(item.assigned_to_userid, {
                                id: notificationAdd.id,
                                mentioned_by:notificationAdd.mentioned_by,
                                tender_id:notificationAdd.tender_id,
                                category_id: notificationAdd.category_id,
                                category_details: notificationAdd.category_details,
                                category_types: notificationAdd.category_types,
                                remarks: notificationAdd.remarks,
                                is_viewed: notificationAdd.is_viewed,
                                is_clicked: notificationAdd.is_clicked,
                                created_at: notificationAdd.created_at,
                                created_by:Number(notificationAdd.created_by)
                            });
    
                    }))
                }   
            }   
            

        } catch (error) {
            console.log('error', error)
        }
    });
    // ========================= End ==============================

    //----------------connected user id start----------------
    // socket.emit('receive_connected_user_list', {
    //     user_id: connectusers,
    // });

    // console.log("User Connected with User Id ", user_id);
    // if (connectusers.includes(user_id)) {
    //     return false;
    // } else {
    //     connectusers.push(user_id)

    // }

    //----------------connected user id end----------------
    // Disconnect event
    // socket.on('disconnect', async () => {
    //     // const index = connectusers.indexOf(user_id);
    //     console.log(user_id, 'User disconnected');
    //     // if (index !== -1) {
    //     //     connectusers.splice(index, 1);
    //     //     socket.emit('receive_connected_user_list', {
    //     //         user_id: connectusers,
    //     //     });
    //     //     return true;
    //     // }

    // });
    // socket.to(Number(user_id)).emit('received_connected_user_list', {
    //     user_id: connectusers,
    // });

    //======================================Abi's Code==========================================================
    socket.on('disconnect', async () => {
        if (user_id) {
            await ChatselectesModel.update({ to_user_id: null }, { where: { from_user_id: user_id, } })
        }
        delete connectedUsers[user_id];
        console.log(`User ${user_id} disconnected`);

        const index = connectusers.indexOf(userIds);
        if (index > -1) { // only splice array when item is found
            connectusers.splice(index, 1); // 2nd parameter means remove one item only
        }
        console.log(socket.id,"===========DISCONNECTED================")
        io.emit('userStatus', { data: connectusers, online: false });
    });
    //==============================================================================================================

});

function scheduleReminders() {
    console.log("ffffffffffff");
}

// setInterval(scheduleReminders, 10 * 1000); 
// scheduleReminders();

// // Start the server
const PORT = 4001;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});



