const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
const Todo_main_task = require('./Todo_main_task');




const Todo_comments = sequelize.define('todo_comments', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    task_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    parent_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: '0',
    },
    comment_txt: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_attachment: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_path: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    ping_users_info: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    is_viewed: {
        type: DataTypes.INTEGER,
        defaultValue: 0,
    },
    status: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '0', '1', '2'

        ],
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

});

Todo_comments.belongsTo(Todo_main_task, {
    foreignKey: 'task_id',
});

module.exports = Todo_comments;
