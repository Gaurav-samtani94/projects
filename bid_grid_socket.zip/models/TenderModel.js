const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');// Import your Sequelize instance

const createTenderModel = (comp_id) => {
    const tableName = `bg_tndr_details_${comp_id}s`;
    const TenderModel = sequelize.define(tableName, {
        id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            autoIncrement: true,
            primaryKey: true,
        },
        bg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
            index: true,
        },
        tg_tender_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,

        },
        gg_tenderID: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        user_comp_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true,

        },
        tender_name: {
            type: DataTypes.TEXT,
            allowNull: true,

        },
        tnd_ref_id: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        tender_gov_id: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        tender_cost: {
            type: DataTypes.DOUBLE,
            allowNull: false,
            defaultValue: '0',

        },
        tender_emd_amnt_val: {
            type: DataTypes.DOUBLE,
            allowNull: true,

        },

        client_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true,

        },
        currency_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
            // foreignKey: true

        },
        region_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
            // foreignKey: true

        },
        country_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: false,
            foreignKey: true,

        },
        state_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,

        },
        city_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
            // foreignKey: true

        },
        sector_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,

        },

        funding_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,

        },
        tender_result_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,

        },

        cycle_id: {
            type: DataTypes.BIGINT(20).UNSIGNED,
            allowNull: true,
            // foreignKey: true

        },
        client_cont_person: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        client_cont_address: {
            type: DataTypes.TEXT,
            allowNull: true,

        },
        email_id: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        phone_no: {
            type: DataTypes.STRING,
            allowNull: true,

        },

        publication_date: {
            type: DataTypes.DATE,
            allowNull: true,

        },
        submission_start_date: {
            type: DataTypes.DATE,
            allowNull: true,

        },
        submission_end_date: {
            type: DataTypes.DATE,
            allowNull: true,

        },
        bid_opening_place: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        bid_validity_date: {
            type: DataTypes.DATE,
            allowNull: true,

        },
        source_id: {
            type: DataTypes.ENUM,
            values: [
                '1', '2'

            ],
            defaultValue: '1'
        },
        national_intern: {
            type: DataTypes.ENUM,
            values: [
                '1', '2'

            ],
            allowNull: true,

        },
        pre_bid_meeting_place: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        pre_bid_meeting_address: {
            type: DataTypes.TEXT,
            allowNull: true,

        },
        pre_bid_meeting_date: {
            type: DataTypes.DATE,
            allowNull: true,

        },
        pre_bid_meeting_time: {
            type: DataTypes.TIME,
            allowNull: true,

        },
        tnd_url: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        pre_bid_meeting_link: {
            type: DataTypes.STRING,
            allowNull: true,

        },
        pre_bid_mode: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        tender_category: {
            type: DataTypes.INTEGER,
            allowNull: true,
        },
        is_details_update: {
            type: DataTypes.ENUM,
            values: [
                '1', '2'

            ],
            defaultValue: '2'
        },
        pre_bid_attend_by: {
            type: DataTypes.BIGINT,
            allowNull: true,
        },
        is_corri_update: {
            type: DataTypes.INTEGER,
            allowNull: true,
            defaultValue: '0',
        },
        created_by: {
            type: DataTypes.INTEGER,
            allowNull: true,
            defaultValue: '0',

        },
        status: {
            type: DataTypes.ENUM,
            values: [
                '0', '1'

            ],
            defaultValue: '1'
        },
        modified_by: {
            type: DataTypes.INTEGER,
            allowNull: true,

        },
        created_at: {
            type: DataTypes.DATE,
            allowNull: true,

        },
        updated_at: {
            type: DataTypes.DATE,
            allowNull: true,

        }
    });
    // Add other attributes here...

    TenderModel.performOperation = async () => {
        try {
            return 'Operation successful';
        } catch (error) {
            throw new Error('Error performing operation: ' + error.message);
        }
    };

    // const TenderDocModel = createTenderModeDocs(comp_id);
    // TenderModel.hasOne(TenderDocModel, {
    //     foreignKey: 'bg_tender_id',
    //     sourceKey: 'id',
    //     as: 'tender_docs'

    // });
    // TenderModel.belongsTo(Country, {
    //     foreignKey: 'country_id',
    // });
    // TenderModel.belongsTo(State, {
    //     foreignKey: 'state_id',
    // });
    // TenderModel.belongsTo(City, {
    //     foreignKey: 'city_id',
    // });

    // TenderModel.belongsTo(Tendersector, {
    //     foreignKey: 'sector_id',
    // });
    // TenderModel.hasMany(TenderCycleAssignInactionModel, {
    //     foreignKey: 'cycle_id',
    //     sourceKey: 'cycle_id', // The field to compare in the source model (TenderModel)
    //     as: 'inactions',
    // });
    // TenderModel.belongsTo(Tenderscope, {
    //     foreignKey: 'cycle_id',
    // });
    // TenderCycleAssignInactionModel.belongsTo(TenderCycleInactionModel, {
    //     foreignKey: 'inaction_id',
    // });

    // // added by gaurav
    // TenderModel.belongsTo(Client, {
    //     foreignKey: 'client_id',
    // });
    // TenderModel.belongsTo(Client, {
    //     foreignKey: 'client_id',
    // });
    // TenderModel.hasOne(TenderGeneratedTypeIdModel,
    //     {
    //         sourceKey: 'id',
    //         foreignKey: 'tender_id'
    //     });
    // TenderModel.hasOne(TenderGeneratedTypeIdModel,
    //     {
    //         sourceKey: 'id',
    //         foreignKey: 'tender_id',
    //         as: 'tender_ger_id',
    //     });
    // TenderModel.hasOne(TenderCommentModel,
    //     {
    //         sourceKey: 'id',
    //         foreignKey: 'tender_id',

    //     });
    // TenderScopeModel.hasMany(TenderModel, {
    //     foreignKey: 'cycle_id',
    // });
    // TenderMovedHistroyByUserModel.belongsTo(TenderModel, {
    //     foreignKey: 'tender_id', // This is the foreign key in TenderGeneratedTypeIdModel
    //     // targetKey: 'id',
    // });
    // TenderDocModel.belongsTo(TenderModel, {
    //     foreignKey: 'tender_id', // This is the foreign key in TenderGeneratedTypeIdModel
    //     // targetKey: 'id',
    // });
    // WishlistTender.belongsTo(TenderModel, {
    //     foreignKey: 'tender_id',
    // });
    // TenderModel.hasMany(TenderAssignManagerModel, {
    //     foreignKey: 'tender_id',
    //     sourceKey: 'id', // The field to compare in the source model (TenderModel)
    //     as: 'assign_tender',
    // });

    // TenderModel.belongsTo(TenderStatusManage, {
    //     foreignKey: 'id',
    // });
    // TenderStatusManage.hasMany(TenderModel, {
    //     foreignKey: 'id',
    // });

    // TenderModel.hasOne(TenderStatusManage, {
    //     sourceKey: 'id',
    //     foreignKey: 'project_id',
    // });

    TenderModel.sync();
    return TenderModel;
};
module.exports = createTenderModel;