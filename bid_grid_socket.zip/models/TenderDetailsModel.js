const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance

const TenderDetailsModel = sequelize.define('bg_tndr_details_4s', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    gg_tenderID: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    tender_name: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    tnd_ref_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    tender_gov_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    tender_cost: {
        type: DataTypes.DOUBLE,
        allowNull: false,
        defaultValue: '0'
    },
    tender_emd_amnt_val: {
        type: DataTypes.DOUBLE,
        allowNull: true,
    },

    client_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    currency_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    region_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    country_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    state_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    city_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    sector_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },

    funding_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
    },

    cycle_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    client_cont_person: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    client_cont_address: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    email_id: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    phone_no: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    publication_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    submission_start_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    submission_end_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    bid_opening_place: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    bid_validity_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    source_id: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ],
        defaultValue: '1'
    },
    national_intern: {
        type: DataTypes.ENUM,
        values: [
            '1', '2'

        ]
    },
    pre_bid_meeting_place: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    pre_bid_meeting_address: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    pre_bid_meeting_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    pre_bid_meeting_time: {
        type: DataTypes.TIME,
        allowNull: true,
    },
    tnd_url: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    pre_bid_meeting_link: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    pre_bid_mode: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: '0'
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }

});

module.exports = TenderDetailsModel;
