const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
// const Todo_main_task = require('./Todo_main_task');
const createTenderModel = require('./TenderModel');

const Tender_comments = sequelize.define('tender_comments', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    tender_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    parent_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: '0',
    },
    comment_txt: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_attachment: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    file_path: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    ping_users_info: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
            '0', '1', '2'

        ],
        defaultValue: '1',
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

});

// const createTenderCommentsAssociation = (comp_id) => {
//     const Tender = createTenderModel(comp_id);

//     Tender_comments.belongsTo(Tender, {
//         foreignKey: 'tender_id',
//         as: 'tenderDetails'
//     });
// };

module.exports = Tender_comments;
