const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
const Todo_comments = require('./Todo_comments');




const Todo_main_task = sequelize.define('todo_main_tasks', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    task_type: {
        type: DataTypes.TINYINT,
        allowNull: false,
        values: [
           '1', '2'

        ],
        defaultValue: '1',
    },
    task_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    task_priority: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    hash_tags: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    current_scope: {
        type: DataTypes.ENUM,
        allowNull: false,
        values: [
           '1', '2', '3'

        ],
        defaultValue: '1',
    },
    assign_type: {
        type: DataTypes.TINYINT,
        values: [
           '1', '2'

        ],
        defaultValue: '1',
        allowNull: true,
    },
    user_creater_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    deadline_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    attachments: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    task_description: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.TINYINT,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

});





module.exports = Todo_main_task;
