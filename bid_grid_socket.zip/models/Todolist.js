
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
// const ToDoTaskMoveHistoryModel = require('./ToDoTaskMoveHistoryModel');
// const AssigntaskModel = require('./Assignedtask');
// const TodoCommentDocs = require('./TodoCommentDocuments');
// const Assignedtaskserialnumber = require('./Assigntaskserialnumber');
const Todolist = sequelize.define('todo_main_tasks', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },

    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    task_type: {
        type: DataTypes.TINYINT,
        allowNull: false,
    },

    task_name: {
        type: DataTypes.TEXT,
        allowNull: false,
    },

    task_priority: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    hash_tags: {
        type: DataTypes.TEXT,
        allowNull: false,
    },

    current_scope: {
        type: DataTypes.ENUM,
        values: ['1', '2', '3'],
        defaultValue: '1'
    },

    assign_type: {
        type: DataTypes.TINYINT,
        defaultValue: '1'
    },

    user_creater_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    deadline_date: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    attachments: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    task_description: {
        type: DataTypes.TEXT,
        allowNull: true,
    },

    project_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    status: {
        type: DataTypes.ENUM,
        values: ['1', '2'],
        defaultValue: '1'
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },

    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
});


// Todolist.hasMany(AssigntaskModel, {
//     foreignKey: 'task_id',
//     sourceKey: 'id',
//     as: 'assigned_users',
// });

// Todolist.hasMany(ToDoTaskMoveHistoryModel, {
//     foreignKey: 'task_id',
//     sourceKey: 'id'
// });

// Todolist.hasMany(TodoCommentDocs, {
//     foreignKey: 'task_id',
//     sourceKey: 'id'
// });
// Todolist.hasMany(Assignedtaskserialnumber, {
//     foreignKey: 'task_id',
//     sourceKey: 'id',
//     as: 'assigned_users1',
// });

module.exports = Todolist;
