const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
const Users = require('./Users');
// const TenderBdRoleModel = require('./TenderBdRoleModel');
const TenderModel = require('./TenderModel');
const TenderBdRoleModel = require('./TenderBdRoleModel');
const TenderAssignManagerModel = sequelize.define('bg_tndr_assign_managers', {
    id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        autoIncrement: true,
        primaryKey: true,
    },
    user_comp_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    bd_role_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    tender_id: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: false,
        foreignKey: true
    },
    assign_to: {
        type: DataTypes.BIGINT(20).UNSIGNED,
        allowNull: true,
        foreignKey: true
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: '0'
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
});

TenderAssignManagerModel.belongsTo(Users, {
    foreignKey: 'assign_to',
});
TenderAssignManagerModel.belongsTo(TenderBdRoleModel, {
    foreignKey: 'bd_role_id',
});
// TenderAssignManagerModel.hasMany(TenderBdRoleModel, {
//     foreignKey: 'bd_role_id',
// });
module.exports = TenderAssignManagerModel;