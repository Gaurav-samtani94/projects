const { DataTypes } = require('sequelize');
const sequelize = require('../config/database'); // Import your Sequelize instance
const TenderDetailsModel = require('./TenderDetailsModel');
const ProjectTodoCommentModel = sequelize.define('project_todo_comments', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },

    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        foreignKey: true
    },
    project_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    task_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        foreignKey: true
    },
    parent_id: {
        type: DataTypes.TINYINT,
        allowNull: false,
        defaultValue: '0'
    },
    comment_txt: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    file_attachment: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    file_path: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    ping_users_info: {
        type: DataTypes.TEXT,
        allowNull: true,
    },

    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,
    }
});

// ProjectTodoCommentModel.belongsTo(TenderDetailsModel, {
//     foreignKey: 'project_id',
//     as: 'tender_details'
// });

module.exports = ProjectTodoCommentModel;