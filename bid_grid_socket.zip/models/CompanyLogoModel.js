const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');// Import your Sequelize instance
const CompanyLogo = sequelize.define('bg_company_logos', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    user_comp_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    logo_file_name: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    logo_file_path: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    status: {
        type: DataTypes.ENUM,
        values: [
            '0', '1'

        ],
        defaultValue: '1'
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },
    updated_at: {
        type: DataTypes.DATE,
        allowNull: true,

    },
    modified_by: {
        type: DataTypes.INTEGER,
        allowNull: true,

    },


});

module.exports = CompanyLogo;    