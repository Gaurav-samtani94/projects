const { Sequelize } = require('sequelize');
const sequelize = new Sequelize({
    dialect: 'mysql', // Change this to your database dialect
    // host: '202.131.122.249',
    // username: 'bid_grid_node',
    // password: 'as#$&fD$#afs22',
    // database: 'big_grid_node',
     host: '202.131.122.246',
     username: 'bid_grid_demo',
     password: 'as#$&fD$#afs22',
     database: 'bid_grid_staging',
    timezone: '+05:30',
    define: {
        timestamps: false, // Sequelize will enable timestamps by default
    },
});

module.exports = sequelize;