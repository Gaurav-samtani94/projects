export const COLORS = {
  RED: '\x1b[31m',
  RESET: '\x1b[0m',
  GRAY: '\x1b[90m',
  BLUE: '\x1b[34m',
  CYAN: '\x1b[36m',
  GREEN: '\x1b[32m',
  WHITE: '\x1b[37m',
  YELLOW: '\x1b[33m',
  MAGENTA: '\x1b[35m',
  LIGHT_GRAY: '\x1b[37m',
  SOFT_GRAY: '\x1b[38;5;244m',
}
