export interface coloredLabel {
    id: string;
    label: string;
    color: string;
}

export interface person {
    id: string;
    name: string;
    avatar: string;
}

export interface TaskRowTypes {
    project_id?: any;
    id: string;
    name: string;
    status?: coloredLabel;
    priority?: coloredLabel;
    type?: coloredLabel;
    assigned?: person;
    assignedBy?: person;
    createdBy?: person;
    est_hr?: number;
    deadline?: string;
    taskId?: string;
    children: TaskRowTypes[];
};