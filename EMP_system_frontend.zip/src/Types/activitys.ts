export interface SystemActivity {
    id: string
    status: string
    startTime: string
    endTime: string
}