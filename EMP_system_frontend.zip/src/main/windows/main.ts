import { app, desktopCapturer, session } from 'electron'
import { join } from 'node:path'
import { createWindow } from 'lib/electron-app/factories/windows/create'
import { ENVIRONMENT } from 'shared/constants'
import { displayName } from '~/package.json'

export async function MainWindow() {
  const window = createWindow({
    id: 'main',
    title: displayName,
    frame: false,
    width: 1440,
    height: 720,
    show: false,
    center: true,
    movable: true,
    resizable: true,
    alwaysOnTop: false,
    autoHideMenuBar: false,


    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  })

  // Allow screen capture with custom source if needed
  session.defaultSession.setDisplayMediaRequestHandler((request, callback) => {
    desktopCapturer.getSources({ types: ['screen', 'window'] }).then((sources) => {
      console.log("sources", sources)
      callback({ video: sources[0], audio: 'loopback' });
    });
  }, { useSystemPicker: true });


  window.webContents.on('did-finish-load', () => {
    if (ENVIRONMENT.IS_DEV) {
      window.webContents.openDevTools({ mode: 'bottom' })
    }

    window.show()
  })

  app.on('window-all-closed', () => {
    app.quit();
  });

  return window
}
