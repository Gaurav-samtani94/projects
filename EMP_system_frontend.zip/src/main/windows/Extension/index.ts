// import { BrowserWindow } from 'electron';
// import { createElectronRouter } from 'electron-router-dom';
// import { join } from 'node:path';

// export function createExtensionWindow() {
//     const extensionWindow = new BrowserWindow({
//         width: 600,
//         height: 400,
//         title: 'Extension Screen',
//         webPreferences: {
//             preload: join(__dirname, '../../preload/index.js'),
//         },
//     });

//     const extensionRoute = createElectronRouter('extension', 'index.html');
//     extensionWindow.loadURL(extensionRoute);

//     return extensionWindow;
// }