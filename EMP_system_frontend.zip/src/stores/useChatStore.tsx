import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ChatState {
    selectedUser: any;
    activeChat: any;
    selectGroup: any;
    selectGroupID: any;
    selectGroupCallActive: any;
    chatInfo: any;
    selectedToken: string | null;
    selectCallerInfo: any;
    callEnd: boolean;
    group_UserId: any;
    groupID: any;
    currentTab: any;
    callFlag: any;
    runningCallId: any;
    allUsers: any[];
    setSelectedUser: (user: any) => void;
    setActiveChat: (activeChat: any) => void;
    setSelectGroup: (group: any) => void;
    setSelectGroupCallActive: (callActive: any) => void;
    setGroupId: (groupID: any) => void;
    setAllUsers: (users: any[]) => void;
    setSelectGroupID: (group_id: any) => void;
    setChatInfo: (chat: any) => void;
    setSelectedToken: (token: string) => void;
    setSelectCallerInfo: (callerInfo: any) => void;
    setCallEnd: (callEnd: boolean) => void;
    setGroupUserId: (group_UserId: any) => void;
    setCurrentTab: (currentTab: any) => void;
    setFlag: (callFlag: boolean) => void;
    setRunningCallId: (runningCallId: boolean) => void;
}

export const useChatStore = create<ChatState>()(
    persist(
        (set) => ({
            selectedUser: null,
            chatInfo: null,
            selectedToken: null,
            selectCallerInfo: null,
            selectGroup: null,
            selectGroupID: null,
            activeChat: null,
            selectGroupCallActive: null,
            callEnd: false,
            group_UserId: null,
            currentTab: null,
            callFlag: null,
            runningCallId: null,
            groupID: null,
            allUsers: [],
            setActiveChat: (activeChat) => set({ activeChat }),
            setSelectedUser: (user) => set({ selectedUser: user }),
            setAllUsers: (users) => set({ allUsers: users }),
            setSelectGroupCallActive: (callActive) => set({ selectGroupCallActive: callActive }),
            setSelectGroup: (group) => set({ selectGroup: group }),
            setGroupId: (groupID) => set({ groupID }),
            setSelectGroupID: (group_id) => set({ selectGroupID: group_id }),
            setChatInfo: (chat) => set({ chatInfo: chat }),
            setSelectedToken: (token) => set({ selectedToken: token }),
            setSelectCallerInfo: (callerInfo) => set({ selectCallerInfo: callerInfo }),
            setCallEnd: (callEnd) => set({ callEnd }),
            setGroupUserId: (group_UserId) => set({ group_UserId }),
            setCurrentTab: (currentTab) => set({ currentTab }),
            setFlag: (callFlag) => set({ callFlag }),
            setRunningCallId: (runningCallId) => set({ runningCallId }),
        }),
        {
            name: 'chat-store',
            partialize: (state): Partial<ChatState> => ({ groupID: state.groupID, allUsers: state.allUsers }),
        }
    )
);

interface Page {
    pagecount: number;
    setPageCount: (pagecount: number) => void;
}

export const usePageStore = create<Page>((set) => ({
    pagecount: 1,
    setPageCount: (count) => set({ pagecount: count }),
}));


