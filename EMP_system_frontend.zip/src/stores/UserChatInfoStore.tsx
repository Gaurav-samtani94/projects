import { create } from 'zustand';

interface ChatState {
    chatInfo: any;
    setChatInfo: (chat: any) => void;


}


export const UserChatInfoStore = create<ChatState>((set) => ({
    chatInfo: null,
    setChatInfo: (chat) => set({ chatInfo: chat }),
}));

