import { type BrowserWindow, dialog, ipcMain, Notification } from 'electron'
// biome-ignore lint/style/useNodejsImportProtocol: <explanation>
import path from 'path';
// biome-ignore lint/style/useNodejsImportProtocol: <explanation>
import os from 'os';
// biome-ignore lint/style/useNodejsImportProtocol: <explanation>
import fs from 'fs';
// biome-ignore lint/style/useNodejsImportProtocol: <explanation>
import https from 'https';
import useAuthStore from 'renderer/store/AuthStore';

import { windowStateManager } from 'renderer/utils/state-manager';
import { clearActivityLog, getActivityLog, getSystemLog } from 'ElectronStore/activityStore';



export function HeaderIpcHandlers(mainWindow: BrowserWindow) {
  const user = useAuthStore.getState().getUser();
  ipcMain.on('window-minimize', () => mainWindow.minimize())

  ipcMain.on('window-maximize', () => {
    if (mainWindow.isMaximized()) {
      mainWindow.restore()
    } else {
      mainWindow.maximize()
    }
  })

  ipcMain.on('window-close', () => mainWindow.close())

  ipcMain.on('window-go-back', () => {
    if (mainWindow.webContents.navigationHistory.canGoBack()) {
      mainWindow.webContents.navigationHistory.goBack()
    }
  })


  ipcMain.on('window-go-forward', () => {
    if (mainWindow.webContents.navigationHistory.canGoForward()) {
      mainWindow.webContents.navigationHistory.goForward()
    }
  })

  ipcMain.on('window-toggle-devtools', () => {
    mainWindow.webContents.toggleDevTools()
  })


  ipcMain.handle('window-activity', async () => {
    await windowStateManager.updateState();


    return windowStateManager.getState();
  });

  ipcMain.handle('activity-log', () => {
    return getActivityLog();
  });
  ipcMain.handle('system-log', () => {
    return getSystemLog();
  });

  ipcMain.handle('clear-activity-log', async () => {
    await clearActivityLog();
    return getActivityLog();
  });


  ipcMain.on("show-notification", async (_event, { title, body }) => {
    new Notification({
      title: `${title.type} from ${title?.name}`,
    }).show();
  });

  ipcMain.on("meeting-notification", async (_event, { title, body }) => {
    new Notification({
      title: `${title}`,
    }).show();
  });

  ipcMain.on("message-notification", async (_event, { title, body, route }) => {
    const notification = new Notification({
      title: `${title.name}: ${title.message}`,
    });

    notification.on("click", () => {
      mainWindow.webContents.send("notification-clicked", route);
    });

    notification.show();
  });

  function getUniqueFilePath(directory: any, filename: any) {
    const ext = path.extname(filename);
    const name = path.basename(filename, ext);
    let filePath = path.join(directory, filename);
    let counter = 1;

    while (fs.existsSync(filePath)) {
      filePath = path.join(directory, `${name}(${counter})${ext}`);
      counter++;
    }

    return filePath;
  }

  // ipcMain.on("download-file", (event, { url, filename }) => {
  //   const downloadsDir = path.join(os.homedir(), "Downloads");
  //   const filePath = getUniqueFilePath(downloadsDir, filename);
  //   const file = fs.createWriteStream(filePath);

  //   https.get(url, (response) => {
  //     response.pipe(file);
  //     file.on("finish", () => {
  //       file.close();
  //       event.sender.send("download-complete", {
  //         success: true,
  //         filePath,
  //       });
  //     });
  //   }).on("error", (err) => {
  //     event.sender.send("download-complete", {
  //       success: false,
  //       error: err.message,
  //     });
  //   });
  // });

  ipcMain.on("download-file", async (event, { url, filename }) => {
    try {
      // Prompt user to select folder
      const result = await dialog.showOpenDialog({
        properties: ["openDirectory"],
        title: "Select download folder",
        defaultPath: path.join(os.homedir(), "Downloads"),
      });

      if (result.canceled || result.filePaths.length === 0) {
        event.sender.send("download-complete", {
          success: false,
          error: "Download cancelled by user.",
        });
        return;
      }

      const selectedDir = result.filePaths[0];
      const filePath = getUniqueFilePath(selectedDir, filename);
      const file = fs.createWriteStream(filePath);

      https.get(url, (response) => {
        response.pipe(file);
        file.on("finish", () => {
          file.close();
          event.sender.send("download-complete", {
            success: true,
            filePath,
          });
        });
      }).on("error", (err) => {
        event.sender.send("download-complete", {
          success: false,
          error: err.message,
        });
      });
    } catch (err: any) {
      event.sender.send("download-complete", {
        success: false,
        error: err?.message,
      });
    }
  });

}
