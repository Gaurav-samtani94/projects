import type { EditorConfig } from "../../../Types/editor";
import ThemeControlPanel from "renderer/components/sections/theme-control-panel"
import ThemePreviewPanel from "renderer/components/sections/theme-preview-panel";
import { generateThemeCode } from "renderer/utils/theme-style-generator";
import { defaultThemeState } from "renderer/config/theme";

export const themeEditorConfig: EditorConfig = {
  type: "theme",
  name: "Theme",
  description: "Customize your global theme colors",
  defaultState: defaultThemeState,
  controls: ThemeControlPanel,
  preview: ThemePreviewPanel,
  codeGenerator: {
    generateComponentCode: generateThemeCode,
  },
};
