import ApiUrl from "./apiUrl";
import axiosInstance from "./axiosInstance"


export const getProjectInprogress = async () => {
    const response = await axiosInstance.get(ApiUrl.get_project_inprogress_list, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const addTaskTime = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.add_task_time, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const getTaskTrackList = async () => {
    const response = await axiosInstance.get(ApiUrl.get_task_track_list, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const addTotalStats = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.add_total_stats, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const addAppActivity = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.add_daily_app_activity, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const addAppUsage = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.add_daily_app_usage, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const addSystemStats = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.add_daily_system_stats, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}