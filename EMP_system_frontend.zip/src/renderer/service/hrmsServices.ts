import axiosInstance from "./axiosInstance";

// Leave CURD

export const leaveListApi = async () => {
    const response = await axiosInstance.get('/api/Hrms/apply-leave-list', {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    })
    return response.data
}

export const applyLeaveApi = async (leaveData: { user_id: string; reason: string; appliedleavescount: string; leavetypeid: string; leaveday: string; from_date: string; to_date: string; halfDayLeave: string; shortLeave: string }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("user_id", leaveData.user_id);
    urlencoded.append("reason", leaveData.reason);
    urlencoded.append("leavetypeid", leaveData.leavetypeid);
    urlencoded.append("leaveday", leaveData.leaveday);
    urlencoded.append("from_date", leaveData.from_date);
    urlencoded.append("to_date", leaveData.to_date);
    leaveData.halfDayLeave && urlencoded.append("hd_pre_post_lunch", leaveData.halfDayLeave);
    leaveData.shortLeave && urlencoded.append("sort_leave_exptime", leaveData.shortLeave);
    urlencoded.append("appliedleavescount", leaveData.appliedleavescount);
    const response = await axiosInstance.post('/api/Hrms/apply-leave', urlencoded, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    })
    return response.data
}

export const editLeaveApi = async (editData: { id: string; reason: string }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("id", editData.id);
    urlencoded.append("reason", editData.reason);
    const response = await axiosInstance.post('/api/Hrms/apply-leave-edit', urlencoded, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    })
    return response.data
}

export const deleteLeaveApi = async (deleteData: { id: string; }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("id", deleteData.id);
    const response = await axiosInstance.delete('/api/Hrms/apply-leave-dlt', { data: urlencoded })
    return response.data
}


// Holiday API's

export const holidayListApi = async (holidayData: { groupid: string; holidayyear: string }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("groupid", holidayData.groupid);
    urlencoded.append("holidayyear", holidayData.holidayyear);
    const response = await axiosInstance.post('/api/Hrms/holiday-list', urlencoded, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    })
    return response.data
}

// Tour CURD

export const tourListApi = async () => {
    const response = await axiosInstance.get('/api/Hrms/tour-list', {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    })
    return response.data
}
export const form16List = async () => {
    const response = await axiosInstance.get('/api/hrms/user-form-number-list')
    return response.data
}

export const getPayslipList = async (payload: { year: string; }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("year", payload.year);

    try {
        const response = await axiosInstance.post(
            '/api/hrms/User-pay-slip-list',
            urlencoded,
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }
        );

        return response.data;
    } catch (error) {
        console.error("Payslip list fetch failed:", error);
        throw error;
    }
};

export const projectListApi = async () => {
    const response = await axiosInstance.get('/api/Hrms/project-list', {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    })
    return response.data
}


export const applyTourApi = async (tourData: { project_id: string; tour_location: string; description: string; tour_type: string; start_date: string; end_date: string }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("project_id", tourData.project_id);
    urlencoded.append("tour_location", tourData.tour_location);
    urlencoded.append("description", tourData.description);
    urlencoded.append("tour_type", tourData.tour_type);
    urlencoded.append("start_date", tourData.start_date);
    urlencoded.append("end_date", tourData.end_date);
    const response = await axiosInstance.post('/api/Hrms/apply-tour', urlencoded, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    })
    return response.data
}


export const editTourApi = async (editData: { id: string; project_id: string; tour_location: string; description: string }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("id", editData.id);
    urlencoded.append("project_id", editData.project_id);
    urlencoded.append("tour_location", editData.tour_location);
    urlencoded.append("description", editData.description);
    const response = await axiosInstance.post('/api/Hrms/edit-apply-tour', urlencoded, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    })
    return response.data
}

export const deleteTourApi = async (deleteData: { id: string; }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("id", deleteData.id);
    const response = await axiosInstance.delete('/api/Hrms/dlt-apply-tour', { data: urlencoded })
    return response.data
}


// Attendence Api's

export const AttendenceListApi = async (attendenceData: { month: string; year: string }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("month", attendenceData.month);
    urlencoded.append("year", attendenceData.year);
    const response = await axiosInstance.post('/api/Hrms/user-attendance-list', urlencoded, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    })
    return response.data
}
