import ApiUrl from "./apiUrl";
import axiosInstance from "./axiosInstance"

export const createMeetings = async (data: {
    meeting_name: string;
    team_member: any;
    start_time: string | null;
    end_time: string | null;
    description: string;
}) => {
    const response = await axiosInstance.post(ApiUrl.meeting_room_create, data, {
        headers: {
            'Content-Type': 'application/json',
        },
    })
    return response.data
}


export const fetchMeetingList = async () => {
    const response = await axiosInstance.get(ApiUrl.meeting_rooms_get_custom, {
        headers: {
            'Accept': 'application/json',
        },
    });
    return response.data;
};

export const joinMeeting = async (url: string) => {
    const response = await axiosInstance.get(`${ApiUrl.meeting_room_join}/${url}`, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cookie': 'lng=en',
        },
    });
    return response.data;
};

export const fetchMeetingDetails = async (id: string) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("meeting_id", id);
    const response = await axiosInstance.post(ApiUrl.meeting_rooms_meeting_detail, urlencoded,
        {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': 'lng=en',
            },
        }
    )
    return response.data
}

export const updateMeeting = async (data: {
    meeting_name: string;
    team_member: any;
    start_time: string | null;
    end_time: string | null;
    description: string;
    password: string;
    is_public: string;
    meeting_id: string;
}) => {
    const response = await axiosInstance.post(`${ApiUrl.meeting_rooms_update_meeting}`, data, {
        headers: {
            'Content-Type': 'application/json',
        },
    })
    return response.data
}


export const addMeetingAttachment = async (meetings: any) => {
    const formData = new FormData();
    formData.append("meeting_id", meetings?.meeting_id);
    meetings?.files?.forEach((file: any) => {
        formData.append("files", file);
    })

    const response = await axiosInstance.post(ApiUrl.meeting_rooms_add_attachment, formData,
        {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                // 'Cookie': 'lng=en',
            },
        }
    )
    return response.data
}

export const fetchMeetingAttachments = async (id: string) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("meeting_id", id);
    const response = await axiosInstance.post(ApiUrl.meeting_rooms_attachment_list, urlencoded,
        {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': 'lng=en',
            },
        }
    )
    return response.data
}

export const deleteMeetingAttachments = async (id: string) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("attachment_id", id);
    const response = await axiosInstance.post(ApiUrl.meeting_rooms_delete_attachment, urlencoded,
        {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': 'lng=en',
            },
        }
    )
    return response.data
}

