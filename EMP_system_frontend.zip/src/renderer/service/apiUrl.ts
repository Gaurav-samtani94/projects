const ApiUrl: { [key: string]: string } = {

    user_login: '/api/user/login',
    all_users: '/api/user/all-users',
    user_list: '/api/chats/user-list',
    delete_chat: '/api/chats/user-chat-delete',
    mark_as_read: '/api/chats/mark-as-read',
    group_list: '/api/chats/group-list',
    update_group: '/api/chats/update-group',
    livekit_create_room: '/api/livekit/create-room',
    create_group: '/api/chats/create-group',
    single_messages: '/api/chats/single/messages',
    single_documents: '/api/chats/single/documents',
    chat_history: '/api/chats/single/chat-history',
    calls_end: '/api/chats/calls/end',
    start_call: '/api/chats/calls/start',
    user_other_detail: '/api/hrms/user-other-detail',
    user_personal_detail: '/api/hrms/user-personal-detail',
    user_team_list: '/api/hrms/User-team-list',
    user_change_password: '/api/hrms/User-change-password',
    group_room_create: '/api/livekit/group-room-create',
    group_messages: '/api/chats/group/messages',
    group_chat_history: '/api/chats/group/chat-history',
    group_documents: '/api/chats/group/documents',



    // for Meeting Rooms api 
    meeting_room_create: '/api/meeting/custom',
    meeting_room_join: "/api/meeting/join",
    meeting_rooms_get_custom: '/api/meeting/costom-meeting-list',
    meeting_rooms_meeting_detail: '/api/meeting/meeting-details',
    meeting_rooms_update_meeting: '/api/meeting/update-meeting',
    meeting_rooms_add_attachment: '/api/meeting/add-meeting-attachment',
    meeting_rooms_attachment_list: '/api/meeting/meeting-attachment',
    meeting_rooms_delete_attachment: '/api/meeting/attachments-delete',

    rejoin_call: 'api/livekit/rejoin-call',


    // For Project api 
    create_project: '/api/pmt/create-project',
    create_task: '/api/pmt/project-task-list',
    project_list: '/api/pmt/project-list',
    custom_fields: '/api/pmt/all-custom-fields',
    add_custom_fields: '/api/pmt/add-custom-field',
    update_projects: '/api/pmt/update-project',
    default_projects_fields: '/api/pmt/custom-field-project-wise',
    delete_custom_fields: '/api/pmt/delete-custom-field',
    task_list: '/api/pmt/project-task-list',
    project_task_add: '/api/pmt/project-task-add',
    update_all_fields: '/api/pmt/update-all-fields',
    update_task_serial: '/api/pmt/update-task-serial',
    custom_options_list: '/api/pmt/custom-field-options',
    add_custom_options: '/api/pmt/add-custom-field-option',
    delete_custom_options: '/api/pmt/delete-custom-field-option',
    update_custom_options: '/api/pmt/update-custom-field-option',
    update_custom_fields: '/api/pmt/update-project-field',
    delete_projects: '/api/pmt/delete-project',
    update_order_options: '/api/pmt/update-option-order',
    update_default_option_order: '/api/pmt/update-custom-field-order',
    upload_attachments: '/api/pmt/add-project-attachment',

    task_field_update: '/api/pmt/task-field-update',
    project_task_delete: '/api/pmt/project-task-delete',
    get_task_comment_list: '/api/pmt/task-comment-list',
    delete_task_comments: '/api/pmt/delete-task-comment',
    update_task_comments: '/api/pmt/update-task-comment',
    get_project_comment_list: '/api/pmt/project-comment-list',
    delete_project_comments: '/api/pmt/delete-project-comment',
    update_project_comments: '/api/pmt/update-project-comment',
    project_status_option: '/api/pmt/project-status-options',

    // for dashboard api
    get_project_inprogress_list: '/api/pmt/project-list-inprogress',
    add_task_time: '/api/pmt/task-time-track',
    get_task_track_list: '/api/pmt/task-track-list',
    delete_attachments: '/api/pmt/delete-project-attachment',
    add_total_stats: '/api/user/activity/add-daily-calculated-system-stats',
    add_daily_app_activity: '/api/user/activity/add-daily-app-activity',
    add_daily_app_usage: '/api/user/activity/add-daily-app-usage',
    add_daily_system_stats: '/api/user/activity/add-daily-system-stats'



};

export default ApiUrl;