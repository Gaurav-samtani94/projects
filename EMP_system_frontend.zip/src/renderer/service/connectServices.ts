import ApiUrl from "./apiUrl";
import axiosInstance from "./axiosInstance";

export const getToken = async (RoomName: string, name: string, userId: string, metadata: any) => {

    try {
        const response = await axiosInstance.post('/api/livekit/generate-token', {
            roomName: RoomName,
            participantName: name,
            userId: userId,
            metadata: metadata,
        }, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': 'Bearer devkey'
            }
        });
        return response.data;
    } catch (error) {
        // biome-ignore lint/complexity/noUselessCatch: <explanation>
        throw error;  // Rethrow to handle it properly
    }
}



export const createRoom = async (fromUserId: string, toUserId: string) => {
    const params = new URLSearchParams();
    params.append('user1_id', fromUserId);
    params.append('user2_id', toUserId);
    const response = await axiosInstance.post('/api/livekit/create-room-chat', params, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    });

    return response.data;
}

export const createGroupRoom = async (groupId: any, toUserId: any) => {
    const params = new URLSearchParams();
    params.append('groupId', groupId);
    params.append('userIds', JSON.stringify(toUserId));
    const response = await axiosInstance.post('/api/livekit/group-room-create', params, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    });

    return response.data;
}
export const forwardMessage = async (sender_id: any, chat_id: any, message_id: any) => {
    const params = new URLSearchParams();
    params.append('sender_id', sender_id);
    params.append('chat_id', chat_id);
    params.append('message_id', message_id);
    const response = await axiosInstance.post('/api/chats/chat-forward', params, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    });

    return response.data;
}

