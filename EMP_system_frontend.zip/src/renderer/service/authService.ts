import ApiUrl from "./apiUrl";
import axiosInstance from "./axiosInstance"

export const userLogin = async (credentials: { email: string; password: string }) => {
    const urlencoded = new URLSearchParams();
    urlencoded.append("email", credentials.email);
    urlencoded.append("password", credentials.password);
    const response = await axiosInstance.post(ApiUrl.user_login, urlencoded, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',

        },
    })
    return response.data
}

export const GetChatUser = async () => {
    const response = await axiosInstance.post(ApiUrl.user_list, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    });
    return response.data; // ✅ Send JSON response to React
}
export const GetUser = async () => {
    const response = await axiosInstance.get(ApiUrl.all_users, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    });
    return response.data; // ✅ Send JSON response to React
}


export const Chat_history = async ({ chat_id, limit, page_number }: { chat_id: string, limit: string, page_number: any }) => {
    const response = await axiosInstance.post(ApiUrl.chat_history, { chat_id, limit, page_number }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data; // ✅ Send JSON response to React
}

export const DeleteChat = async ({ msgId }: { msgId: string }) => {
    const response = await axiosInstance.delete(ApiUrl.delete_chat, {
        headers: {
            'Content-Type': 'application/json',
        },
        data: { msgId }, // 👈 Correct way to send data in DELETE request
    });
    return response.data;
};


export const markAsRead = async (user_id: any) => {
    const response = await axiosInstance.post(ApiUrl.mark_as_read, { user_id }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data; // ✅ Send JSON response to React
}

export const SaveMassage = async ({ sender_id, text, chat_id, reply_to_id }: { sender_id: string, text: string, chat_id: string, reply_to_id: string }) => {
    const response = await axiosInstance.post(ApiUrl.single_messages, { sender_id, text, chat_id, reply_to_id }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data;
};




export const SaveFiles = async ({ sender_id, file, chat_id, reply_to_id }: { sender_id: string; file: File, chat_id: string, reply_to_id: string }) => {
    const urlencoded = new FormData();
    urlencoded.append("sender_id", sender_id);
    urlencoded.append("chat_id", chat_id);
    urlencoded.append("file", file);
    urlencoded.append("reply_to_id", String(reply_to_id));

    const response = await axiosInstance.post(ApiUrl.single_documents, urlencoded, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    })
    return response.data
}

export const GroupProfileUpdate = async ({ group_id, group_name, description, file, user_ids }: { group_id: string; group_name: string; description: string; file: any; user_ids: string[]; }) => {
    const urlencoded = new FormData();
    urlencoded.append("group_id", group_id);
    urlencoded.append("group_name", group_name);
    urlencoded.append("description", description);
    urlencoded.append("file", file);
    // biome-ignore lint/complexity/noForEach: <explanation>
    user_ids.forEach((id) => {
        urlencoded.append("user_ids[]", id);
    });

    const response = await axiosInstance.post(ApiUrl.update_group, urlencoded, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    });
    return response.data;
};


export const GroupSaveMassage = async ({ sender_id, group_id, text, reply_to_id }: { sender_id: string, group_id: string, text: string, reply_to_id: string }) => {
    const response = await axiosInstance.post(ApiUrl.group_messages, { sender_id, group_id, text, reply_to_id }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data;
};

export const GroupFiles = async ({ sender_id, group_id, file, reply_to_id }: { sender_id: string; group_id: string; file: File; reply_to_id: string }) => {
    const urlencoded = new FormData();
    urlencoded.append("sender_id", sender_id);
    urlencoded.append("group_id", group_id);
    urlencoded.append("file", file);
    urlencoded.append("reply_to_id", String(reply_to_id));


    const response = await axiosInstance.post(ApiUrl.group_documents, urlencoded, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    })
    return response.data
}


export const ChatGroup_history = async ({ group_id, limit, page_number }: { group_id: string, limit: string, page_number: any }) => {
    const response = await axiosInstance.post(ApiUrl.group_chat_history, { group_id, limit, page_number }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data; // ✅ Send JSON response to React
}
export const Group_IconUpdate = async ({ group_id, limit, page_number }: { group_id: string, limit: string, page_number: any }) => {
    const response = await axiosInstance.post(ApiUrl.group_chat_history, { group_id, limit, page_number }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data; // ✅ Send JSON response to React
}

export const Calls_ends_Api = async ({ call_id }: { call_id: string }) => {
    const response = await axiosInstance.put(ApiUrl.calls_end, { call_id }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data; // ✅ Send JSON response to React
}
export const Calls_ends_Group_Api = async ({ call_id, group_id }: { call_id: string, group_id: string }) => {
    const response = await axiosInstance.put(ApiUrl.calls_end, { call_id, group_id }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response // ✅ Send JSON response to React
}





export const startCall = async ({ chat_id, caller_id, call_type }: { chat_id: string, caller_id: string, call_type: string }) => {
    const response = await axiosInstance.post(ApiUrl.start_call, { chat_id, caller_id, call_type }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data; // ✅ Send JSON response to React
}

export const startCallGroup = async ({ group_id, caller_id, call_type }: { group_id: string, caller_id: string, call_type: string }) => {
    const response = await axiosInstance.post(ApiUrl.start_call, { group_id, caller_id, call_type }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data; // ✅ Send JSON response to React
}


export const createGroup = async ({ group_name, created_by, user_ids }: { group_name: string, created_by: number, user_ids: string[] }) => {
    const response = await axiosInstance.post(ApiUrl.create_group, { group_name, created_by, user_ids, }, {
        headers: {
            'Content-Type': 'application/json',
        },
    });
    return response.data;
};

export const rejoin_call_Group = async ({ callerId, }: { callerId: any, }) => {
    const response = await axiosInstance.post(ApiUrl.rejoin_call, { callerId, }, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    });
    return response.data;
};



export const ChangePassword = async ({
    oldPassword,
    newPassword,
    confirmPassword,
}: {
    oldPassword: string
    newPassword: string
    confirmPassword: string
}) => {
    const response = await axiosInstance.post(ApiUrl.user_change_password, { oldPassword, newPassword, confirmPassword }, {
        headers: {
            'Content-Type': 'application/json',
        },
    })
    return response.data
}

export const GetGroup = async () => {
    const response = await axiosInstance.get(ApiUrl.group_list, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',

        },
    });
    return response.data; // ✅ Send JSON response to React
}

export const UserOtherDetail = async () => {
    const response = await axiosInstance.get(ApiUrl.user_other_detail, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',

        },
    });
    return response.data; // ✅ Send JSON response to React
}

export const UserPersonalDetail = async () => {
    const response = await axiosInstance.get(ApiUrl.user_personal_detail, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',

        },
    });
    return response.data; // ✅ Send JSON response to React
}

export const UserTeamList = async () => {
    const response = await axiosInstance.get(ApiUrl.user_team_list, {
        headers: {
            'Accept': 'application/json',
        },
    });
    return response.data;
};
