import ApiUrl from "./apiUrl";
import axiosInstance from "./axiosInstance"


export const projectCreate = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.create_project, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const getProject = async () => {
    const response = await axiosInstance.get(ApiUrl.project_list, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const createTask = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.project_task_add, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const customFieldsList = async () => {
    const response = await axiosInstance.get(ApiUrl.custom_fields, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',

        },
    })
    return response.data
}

export const createCustomFields = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.add_custom_fields, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',

        },
    })
    return response.data
}

export const updateProjects = async (data: any) => {
    const response = await axiosInstance.put(ApiUrl.update_projects, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const defaultProjectsFields = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.default_projects_fields, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',

        },
    })
    return response.data
}

export const deleteCustomFields = async (data: any) => {
    const response = await axiosInstance.put(ApiUrl.delete_custom_fields, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    });
    return response.data

}

export const getTaskList = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.task_list, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const updateTask = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.update_all_fields, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const getCustomOptionsList = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.custom_options_list, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const updateTaskOrderSerial = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.update_task_serial, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const addCustomOptions = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.add_custom_options, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const deleteCustomOptions = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.delete_custom_options, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const updateCustomOptions = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.update_custom_options, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const updateCustomFields = async (data: any) => {
    const response = await axiosInstance.put(ApiUrl.update_custom_fields, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const deleteProjects = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.delete_projects, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const updateOptionsOrder = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.update_order_options, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

// export const updateTaskField = async (data: any) => {
//     const response = await axiosInstance.put(ApiUrl.task_field_update, data, {
//         headers: {
//             'Content-Type': 'application/x-www-form-urlencoded',
//         },
//     })
//     return response.data
// }

export const updateTaskField = async (data: any) => {
    const formData = new FormData();

    for (const key in data) {
        formData.append(key, data[key]);
    }

    const response = await axiosInstance.put(ApiUrl.task_field_update, formData)
    return response.data
}

export const deleteTask = async (data: any) => {
    const response = await axiosInstance.delete(ApiUrl.project_task_delete, {
        data: data,
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}


export const deleteAttachments = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.delete_attachments, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const getCommentList = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.get_task_comment_list, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const deleteTaskComments = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.delete_task_comments, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const updateTaskComments = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.update_task_comments, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const getProjectComments = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.get_project_comment_list, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const deleteProjectComments = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.delete_project_comments, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const updateProjectsComments = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.update_project_comments, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}


export const updateDefaultOptionsOrder = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.update_default_option_order, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data
}

export const uploadAttachments = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.upload_attachments, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}

export const fetchFiltersList = async (data: any) => {
    const response = await axiosInstance.post(ApiUrl.project_status_option, data, {
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
    })
    return response.data;
}
