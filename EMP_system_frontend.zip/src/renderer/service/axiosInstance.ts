import axios from 'axios';
import useAuthStore from 'renderer/store/AuthStore';
import BaseUrl from './BaseUrl';
const axiosInstance = axios.create({
    baseURL: BaseUrl?.Url_Base,
});
// http://192.168.11.161:/api/
// https://staging-emp.growthgrids.com/api/


axiosInstance.interceptors.request.use(
    (config) => {
        // const state = store.getState();
        // const token = state.auth.token;
        const token = useAuthStore.getState().getToken();
        if (token) {
            // biome-ignore lint/complexity/useLiteralKeys: <explanation>
            config.headers['Authorization'] = `${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

axiosInstance.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response && error.response.status === 401) {
            useAuthStore.getState().logout();
        }
        return Promise.reject(error);
    }
);



export default axiosInstance;