const BaseUrl: { [key: string]: string } = {
    // Server URl
    Url_Base: 'https://staging-emp.growthgrids.com',
    LIVEKIT_URL: 'wss://livekit.growthgrids.com/',
    // WEB_URL: 'https://staging-emp.growthgrids.com',
    WEB_URL: 'http://localhost:5173',

    // Local URl
    // Url_Base: 'http://192.168.11.161:3536',
    // LIVEKIT_URL: 'ws://192.168.11.130:7880',


};

export default BaseUrl;