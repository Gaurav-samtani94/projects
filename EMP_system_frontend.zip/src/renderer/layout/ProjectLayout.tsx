import { useState } from "react";
import { Button } from "renderer/components/ui/button";
import {
    ResizableHandle,
    ResizablePanel,
    ResizablePanelGroup,
} from "renderer/components/ui/resizable";
import { ScrollArea, ScrollBar } from "renderer/components/ui/scroll-area";
import {
    List,
    Folder,
    Circle,
    Flag,
    SquareStack,
    BookTemplate,
    Plus,
    CheckCircle,
    Tag,
    HelpCircle,
    File,
    CheckCheckIcon,
    Timer,
    LandPlot,
    LayoutList,
    SlidersHorizontal,
} from "lucide-react";
import { Outlet } from "react-router-dom";
import AddTaskDrawer from "renderer/components/sections/AddTaskDrawer";
import { Popover, PopoverContent, PopoverTrigger } from "renderer/components/ui/popover";
import { Label } from "renderer/components/ui/label";
import { Switch } from "renderer/components/ui/switch";
import { FacetedFilter } from "renderer/components/sections/FactedFilter";
import { priorities, statuses } from "renderer/utils/taskData";
import { Input } from "renderer/components/ui/input";
import { Drawer, DrawerClose, DrawerContent, DrawerDescription, DrawerFooter, DrawerHeader, DrawerTitle, DrawerTrigger } from "renderer/components/ui/drawer";
import CreateProjectModal from "renderer/components/sections/Project/create-or-edit-project";

export default function ProjectLayout() {
    const [selectedProject, setSelectedProject] = useState("WELCOME TO HULY!");

    return (
        <ResizablePanelGroup direction="horizontal">
            <ResizablePanel defaultSize={15} minSize={12} maxSize={30} className="border-r sticky top-[125px]">
                <div className="flex items-center justify-between p-4 border-b">
                    <p className="text-xl">
                        ALL Projects
                    </p>
                    <Drawer>
                        <DrawerTrigger>Open</DrawerTrigger>
                        <DrawerContent>
                            <DrawerHeader className="flex justify-between flex-row">
                                <div>
                                    <DrawerTitle>Create Project</DrawerTitle>
                                    <DrawerDescription>Enter Project Details</DrawerDescription>
                                </div>
                                <div className="flex justify-end gap-4">
                                    <Button>
                                        Save
                                    </Button>
                                    <Button variant="outline">
                                        Cancel
                                    </Button>
                                </div>
                            </DrawerHeader>
                            <div>
                                <ScrollArea className="h-[50vh] p-4">
                                    <CreateProjectModal />
                                </ScrollArea>
                            </div>
                        </DrawerContent>
                    </Drawer>
                    {/* <AddTaskDrawer /> */}
                </div>
                <ScrollArea className="h-[calc(100vh-194px)]">
                    <div className="mt-4 flex flex-col gap-2 ">
                        <div className="mb-3 border-b px-4">
                            <div className="inline-flex gap-2 items-center cursor-pointer bg-secondary w-fit pr-4 rounded-sm overflow-hidden">
                                <div className="p-2 bg-accent text-accent-foreground">
                                    <File className="w-5 h-5" />
                                </div>
                                <p className="ml-2 text-base">Project 1</p>
                            </div>
                            <div className="ml-4 border-l p-2">
                                <div className=" flex flex-col gap-2">
                                    <p className="text-base hover:text-accent-foreground duration-150 hover:underline cursor-pointer flex gap-2 items-center">
                                        <CheckCheckIcon className="w-4 h-4" />
                                        Tasks
                                    </p>
                                    <p className="text-base hover:text-accent-foreground duration-150 hover:underline cursor-pointer flex gap-2 items-center">
                                        <Timer className="w-4 h-4" />
                                        Backlogs
                                    </p>
                                    <p className="text-base hover:text-accent-foreground duration-150 hover:underline cursor-pointer flex gap-2 items-center">
                                        <LandPlot className="w-4 h-4" />
                                        Milestone
                                    </p>
                                    <p className="text-base hover:text-accent-foreground duration-150 hover:underline cursor-pointer flex gap-2 items-center">
                                        <LayoutList className="w-4 h-4" />
                                        Project Template
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div className="mb-3 border-b px-4">
                            <div className="inline-flex gap-2 items-center cursor-pointer bg-secondary w-fit pr-4 rounded-sm overflow-hidden">
                                <div className="p-2 bg-accent text-accent-foreground">
                                    <File className="w-5 h-5" />
                                </div>
                                <p className="ml-2 text-base">Project 2</p>
                            </div>
                            <div className="ml-4 border-l p-2">
                                <div className=" flex flex-col gap-2">
                                    <p className="text-base hover:text-accent-foreground duration-150 hover:underline cursor-pointer flex gap-2 items-center">
                                        <CheckCheckIcon className="w-4 h-4" />
                                        Tasks
                                    </p>
                                    <p className="text-base hover:text-accent-foreground duration-150 hover:underline cursor-pointer flex gap-2 items-center">
                                        <Timer className="w-4 h-4" />
                                        Backlogs
                                    </p>
                                    <p className="text-base hover:text-accent-foreground duration-150 hover:underline cursor-pointer flex gap-2 items-center">
                                        <LandPlot className="w-4 h-4" />
                                        Milestone
                                    </p>
                                    <p className="text-base hover:text-accent-foreground duration-150 hover:underline cursor-pointer flex gap-2 items-center">
                                        <LayoutList className="w-4 h-4" />
                                        Project Template
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </ScrollArea>
            </ResizablePanel>

            <ResizableHandle />

            <ResizablePanel defaultSize={80}>
                <div className="p-4 border-b flex items-center justify-between">
                    <div className="flex gap-5 items-center">
                        <p className="text-xl">
                            Projects 1
                        </p>
                        {/* <Input
                            placeholder="Search Task"
                            className="w-[300px]"
                        // value={searchValue}
                        // onChange={(e) => setSearchValue(e.target.value)}
                        /> */}
                    </div>
                    <div className="flex gap-2">
                        <FacetedFilter
                            title="Status"
                            options={statuses} type={undefined} handleUpdateTaskField={undefined} taskFieldObj={undefined} />
                        <FacetedFilter
                            title="Priority"
                            options={priorities} type={undefined} handleUpdateTaskField={undefined} taskFieldObj={undefined} />
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button variant="outline" className="border-dashed" >
                                    <SlidersHorizontal className="w-5 h-5" />
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-72" align="end" sideOffset={5}>
                                <div className="grid gap-4">
                                    <div className="space-y-2">
                                        <h4 className="font-medium leading-none">Visible Columns</h4>
                                        <p className="text-sm text-muted-foreground">
                                            Adjust the columns that are visible
                                        </p>
                                    </div>
                                    <div className="flex flex-col gap-3">
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Status</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Priority</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Type</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Assigned To</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Assigned By</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Create By</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Reviewer</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">QA</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Deadline</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Expected Hours</Label>
                                        </div>
                                        <div className="flex items-center space-x-2 ">
                                            <Switch id="status" defaultChecked={true} />
                                            <Label htmlFor="status">Task Id </Label>
                                        </div>
                                    </div>
                                </div>
                            </PopoverContent>
                        </Popover>
                        {/* <AddTaskDrawer children={undefined} getData={function (): { row: any; heads: any; } {
                            throw new Error("Function not implemented.");
                        } } refetchTaskList={undefined} users={undefined} >
                            <Button variant="outline" >
                                <Plus className="w-5 h-5" />
                                Add Task
                            </Button>
                        </AddTaskDrawer> */}


                    </div>
                </div>
                <ScrollArea className="h-[calc(100vh-194px)] w-full">
                    <div className="hello">
                        <Outlet />
                    </div>
                    <ScrollBar orientation="horizontal" />
                    <ScrollBar orientation="vertical" />
                </ScrollArea>
            </ResizablePanel>
        </ResizablePanelGroup>
    );
}
