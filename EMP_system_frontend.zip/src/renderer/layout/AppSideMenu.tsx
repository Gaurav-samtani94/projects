"use client"

import { Link, useLocation } from "react-router-dom"
import {
    BellDot,
    LayoutDashboard,
    Calendar,
    MessageSquare,
    Users,
    FolderKanban,
    Clock,
    ChevronDown,
    Airplay,
    Paintbrush
} from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "renderer/components/ui/avatar"
import { Button } from "renderer/components/ui/button"
import useAuthStore from "renderer/store/AuthStore"
import { useNavigate } from "react-router-dom"
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "renderer/components/ui/dropdown-menu"
import { Separator } from "renderer/components/ui/separator"
import {
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
} from "renderer/components/ui/tooltip"
import { Drawer, DrawerContent, DrawerTrigger } from "renderer/components/ui/drawer"
import { ScrollArea } from "renderer/components/ui/scroll-area"
import MainEditor from "renderer/screens/MainEditor"
import ChatController from "renderer/Controller/ChatController"
// import path from "path"

const { App } = window


const navItems = [
    // { name: "Projects", path: "/projects", icon: FolderKanban },
    { name: "Hrms", path: "/hrms", icon: Users },
    { name: "Calendar", path: "/calendar", icon: Calendar },
    { name: "Schedule", path: "/scheduled", icon: Clock },
    { name: "Chat", path: "/chat", icon: MessageSquare },
    { name: "Projects", path: "/project", icon: FolderKanban },
]

export function AppSidebar() {
    const pathname = useLocation().pathname
    const navigate = useNavigate()
    const logout = useAuthStore((state) => state.logout)
    const { isAuthenticated } = useAuthStore()

    const handleLogout = async () => {
        await logout()
    }

    // const socket = ChatController.getSocket();
    // if (!socket) {
    //     return;
    // }

    // socket.on('project-notification', (data: any) => {

    //     console.log('Project Createddddddd67====>>>>>>>', data);
    //      App.meetingNotification(data?.title, "meeting-notification");
    // })

    return (
        <div className="flex h-full justify-center items-center w-[69px] pt-2 flex-col border-r bg-background">

            {/* Navigation */}
            <TooltipProvider>
                <div className="flex-1 overflow-auto py-2 w-fit">
                    <nav className="space-y-1 px-2 w-fit">
                        <Tooltip>
                            <TooltipTrigger asChild>
                                <Link
                                    to="/"
                                    className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-muted ${pathname === '/' ? 'text-primary' : ''}`}
                                >
                                    <LayoutDashboard />
                                </Link>
                            </TooltipTrigger>
                            <TooltipContent side="right">
                                Dashboard
                            </TooltipContent>
                        </Tooltip>

                        {navItems.map(item => (
                            <Tooltip key={item.name}>
                                <TooltipTrigger asChild>
                                    <Link
                                        to={item.path}
                                        className={`flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-muted ${pathname.includes(item.path) ? 'text-primary' : ''}`}
                                    >
                                        <item.icon className="h-5 w-5" />
                                    </Link>
                                </TooltipTrigger>
                                <TooltipContent side="right">
                                    {item.name}
                                </TooltipContent>
                            </Tooltip>
                        ))}
                    </nav>
                </div>
            </TooltipProvider>

            {/* Footer */}
            <div className="border-t py-3">
                <div className="space-y-2 flex flex-col justify-center items-center">
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <div
                                className="flex items-center gap-2 rounded-md p-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
                            >
                                {pathname !== '/login' &&
                                    <Drawer direction='right'>
                                        <DrawerTrigger>
                                            <Paintbrush className="h-5 w-5" />
                                        </DrawerTrigger>
                                        <DrawerContent>
                                            <div className='pt-[40px]'>
                                                <ScrollArea className='h-[calc(100vh-40px)] p-4'>
                                                    <MainEditor />
                                                </ScrollArea>
                                            </div>
                                        </DrawerContent>
                                    </Drawer>
                                }

                            </div>
                        </TooltipTrigger>
                        <TooltipContent side="right">
                            Customize Theme
                        </TooltipContent>
                    </Tooltip>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Link
                                to="/notification"
                                className="flex items-center gap-2 rounded-md p-2 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground"
                            >
                                <BellDot className="h-5 w-5" />{10}
                            </Link>
                        </TooltipTrigger>
                        <TooltipContent side="right">
                            Notifications
                        </TooltipContent>
                    </Tooltip>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <button className="flex w-full items-center gap-2 rounded-md p-2 text-sm font-medium text-muted-foreground hover:bg-muted">
                                <Avatar className="h-6 w-6">
                                    <AvatarImage src="https://github.com/shadcn.png" />
                                    <AvatarFallback>CN</AvatarFallback>
                                </Avatar>
                                <ChevronDown className="h-5 w-5" />
                            </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>My Account</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                                <Link to="/profile/general">Profile</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                                <Link to="/profile/account">Account</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                                <Link to="/profile">Settings</Link>
                            </DropdownMenuItem>
                            <Separator />
                            <DropdownMenuItem>
                                <Button variant={isAuthenticated ? "destructive" : "default"} onClick={handleLogout} className="w-full">
                                    {isAuthenticated ? "Logout" : ""}
                                </Button>
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>

                </div>
            </div>
        </div >
    )
}
