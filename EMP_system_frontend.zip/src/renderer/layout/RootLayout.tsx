import Footer from './Footer'
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import WindowHeader from './WindowHeader'
import useAuthStore from 'renderer/store/AuthStore'
import { useEffect, useMemo, useState } from 'react'
import { QueryClient, QueryClientProvider, useMutation } from '@tanstack/react-query'
import { ThemeProvider } from './theme-provider'
import { AppSidebar } from './AppSideMenu';
import { Toaster } from 'sonner'
import { useActivityLogStore, useSystemStatusStore } from 'renderer/store/LoggingStore'
import { addAppActivity, addAppUsage, addSystemStats, addTotalStats } from 'renderer/service/dashboard'
import { customCalculations } from 'renderer/utils/customCalculations'
import { lastSentLogStore } from 'renderer/store/lastSentLogStore'
import ChatController from 'renderer/Controller/ChatController'
import { useChatStore, usePageStore } from 'stores/useChatStore'
import { createGroupRoom, createRoom, getToken } from 'renderer/service/connectServices'
import { GetChatUser, GetGroup, startCall, startCallGroup } from 'renderer/service/authService'
import { trackingStore } from 'renderer/store/trackingStore'


const StatsFetcher = () => {
  const { timeStats, timeStatsInSeconds, calculateDurations } = customCalculations()
  const { chatInfo, } = useChatStore()

  const getSystemLog = useSystemStatusStore((state) => state.systemStatus)
  // console.log("getSystemLog", getSystemLog)
  const getActivityLog = useActivityLogStore((state) => state.activityLog);
  const { lastSentSystemLog, lastSentActivityLog, setLastSentSystemLog, setLastSentActivityLog } = lastSentLogStore();
  const isTracking = trackingStore(state => state.isTracking);
  const user = useAuthStore.getState().getUser();
  const ConnectUser = async () => {
    console.log('====>>++++')
    await ChatController.connectUser(user?.id || "")
  }
  useEffect(() => {
    ConnectUser()
  }, [])

  const addTotalTimeMutation = useMutation({
    mutationFn: addTotalStats
  })

  const appActivityMutation = useMutation({
    mutationFn: addAppActivity,
  })

  const systemStatsMutation = useMutation({
    mutationFn: addSystemStats
  })

  const addAppsUsageMutation = useMutation({
    mutationFn: addAppUsage
  })

  const getFormattedLogsWithDuration = (logs: any) => {
    return logs?.slice().reverse().map((log: any) => {
      const cleanStart = log.start_time.replace(/AM|PM/i, "").trim();
      const cleanEnd = log.end_time.replace(/AM|PM/i, "").trim();
      const [startHours, startMinutes, startSeconds] = cleanStart.split(":").map(Number)
      const [endHours, endMinutes, endSeconds] = cleanEnd.split(":").map(Number)

      const start = new Date()
      start.setHours(startHours, startMinutes, startSeconds, 0)

      const end = new Date()
      end.setHours(endHours, endMinutes, endSeconds, 0)

      const diffInSeconds = Math.floor((end.getTime() - start.getTime()) / 1000)

      const { path, ...rest } = log

      return {
        ...rest,
        duration: diffInSeconds
      }
    })
  }

  const groupLogsByOwner = (logs: any) => {
    const grouped: Record<string, {
      duration: number;
      id: number;
    }> = {};

    // biome-ignore lint/complexity/noForEach: <explanation>
    logs.forEach((log: any) => {
      try {
        const owner = log.owner;
        const durationSeconds = Math.max(getSeconds(log.end_time) - getSeconds(log.start_time), 0);

        if (grouped[owner]) {
          grouped[owner].duration += durationSeconds;
        } else {
          grouped[owner] = {
            duration: durationSeconds,
            id: log.id
          };
        }
      } catch (err) {
        console.warn("Invalid log entry:", log);
      }
    });

    return Object.entries(grouped).map(([owner, data]) => ({
      owner,
      duration: data.duration,
      id: data.id
    }));
  }

  const getSeconds = (timeStr: string): number => {
    const [h, m, s] = timeStr.split(':').map(Number);
    return h * 3600 + m * 60 + (s || 0);
  };

  const getDateTimeObject = (dateStr: string, timeStr: string): Date => {
    const [day, month, year] = dateStr.split('-').map(Number);
    return new Date(`${year}-${month}-${day} ${timeStr}`);
  };

  useEffect(() => {
    if (!isTracking) {
      calculateDurations(getSystemLog)
      const apiData = () => {
        const activityLogs = getFormattedLogsWithDuration(getActivityLog)
        const systemLogs = getFormattedLogsWithDuration(getSystemLog)
        const appsusageLogs = groupLogsByOwner(getActivityLog);

        const filteredSystemLogs = lastSentSystemLog?.end_time
          ? systemLogs?.filter((log: any) => {
            const logDateTime = getDateTimeObject(log.date, log.end_time);
            const storedDateTime = getDateTimeObject(lastSentSystemLog.date, lastSentSystemLog.end_time);
            return logDateTime > storedDateTime;
          })
          : systemLogs;

        if (systemLogs?.length > 0) {
          const lastsystemLog = systemLogs[0];
          setLastSentSystemLog(lastsystemLog);
        }

        const filteredActivityLogs = lastSentActivityLog?.end_time
          ? activityLogs?.filter((log: any) => {
            const logDateTime = getSeconds(log.end_time);
            const storedDateTime = getSeconds(lastSentActivityLog.end_time);
            return logDateTime > storedDateTime;
          })
          : activityLogs;


        if (activityLogs?.length > 0) {
          const lastFormattedLog = activityLogs[activityLogs.length - 1];
          setLastSentActivityLog(lastFormattedLog);
        }

        addTotalTimeMutation.mutate(timeStatsInSeconds)
        appActivityMutation.mutate({
          logs: JSON.stringify(filteredActivityLogs)
        })
        systemStatsMutation.mutate({
          logs: JSON.stringify(filteredSystemLogs)
        })
        addAppsUsageMutation.mutate({
          logs: JSON.stringify(appsusageLogs)
        })
      }
      apiData()
    }
  }, [isTracking])

  useEffect(() => {
    calculateDurations(getSystemLog)
    const sendData = () => {
      const activityLogs = getFormattedLogsWithDuration(getActivityLog)
      const systemLogs = getFormattedLogsWithDuration(getSystemLog)
      const appsusageLogs = groupLogsByOwner(getActivityLog);

      const filteredSystemLogs = lastSentSystemLog?.end_time
        ? systemLogs?.filter((log: any) => {
          const logDateTime = getDateTimeObject(log.date, log.end_time);
          const storedDateTime = getDateTimeObject(lastSentSystemLog.date, lastSentSystemLog.end_time);
          return logDateTime > storedDateTime;
        })
        : systemLogs;

      if (systemLogs?.length > 0) {
        const lastsystemLog = systemLogs[0];
        setLastSentSystemLog(lastsystemLog);
      }

      const filteredActivityLogs = lastSentActivityLog?.end_time
        ? activityLogs?.filter((log: any) => {
          const logDateTime = getSeconds(log.end_time);
          const storedDateTime = getSeconds(lastSentActivityLog.end_time);
          return logDateTime > storedDateTime;
        })
        : activityLogs;


      if (activityLogs?.length > 0) {
        const lastFormattedLog = activityLogs[activityLogs.length - 1];
        setLastSentActivityLog(lastFormattedLog);
      }

      addTotalTimeMutation.mutate(timeStatsInSeconds)
      appActivityMutation.mutate({
        logs: JSON.stringify(filteredActivityLogs)
      })
      systemStatsMutation.mutate({
        logs: JSON.stringify(filteredSystemLogs)
      })
      addAppsUsageMutation.mutate({
        logs: JSON.stringify(appsusageLogs)
      })
    }
    const interval = setInterval(() => { sendData() }, 2 * 60 * 60 * 1000)
    return () => clearInterval(interval)
  }, [getSystemLog])
  return null
}

const RootLayout = () => {
  const { App } = window
  const pathname = useLocation().pathname
  const navigate = useNavigate()
  const { selectedUser, chatInfo, selectedToken, selectGroup, callFlag, selectCallerInfo, selectGroupID, group_UserId, setSelectedUser, setChatInfo, setSelectedToken, setSelectGroup, setSelectGroupCallActive, setSelectCallerInfo, setSelectGroupID } = useChatStore();
  const { isAuthenticated } = useAuthStore()
  const { setPageCount } = usePageStore();
  const [incomingCall, setIncomingCall] = useState<any>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [isAduioCall, setisAduioCall] = useState<any>(null);
  const addLog = useActivityLogStore((state) => state.addActivityLog);
  const replaceLog = useActivityLogStore((state) => state.replaceActivityLog);
  const replaceSytemLog = useSystemStatusStore((state) => state.replaceSystemLog);
  const addSytemLog = useSystemStatusStore((state) => state.setSystemStatus);
  const systemLog = useSystemStatusStore((state) => state.systemStatus);
  const getActivityLog = useActivityLogStore((state) => state.activityLog);
  const ResUser = useAuthStore.getState().getUser();


  const activityWindow = async () => {
    const activityLog = await App.activityLog()
    const systemLog = await App.systemLog()
    replaceSytemLog(systemLog);
    replaceLog(activityLog);
  }
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login')
    }
  }, [isAuthenticated, navigate])



  useEffect(() => {
    GetGroupList()
    let cleanupFn: (() => void) | undefined;
    const setupSocket = async () => {
      cleanupFn = await SocketHandle();
    };
    setupSocket();
    return () => {
      cleanupFn?.();
    };
  }, []);

  const GetGroupList = async () => {
    const response = await GetGroup();
    const groupIds = response.data.map((group: any) => (group.groupId));
    setSelectGroupID(groupIds)
  }

  const SocketHandle = async () => {
    let socket: any;

    const handleCallNotification = (data: any) => {
      console.log("📞==== Received call-notification:", data)
      const latestSelectGroupID = useChatStore.getState().groupID;
      console.log("latestSelectGroupID", latestSelectGroupID)
      if (data.chat_type === 'Group') {
        if (data.to !== Number(ResUser?.id)) {
          if (!latestSelectGroupID || !Array.isArray(latestSelectGroupID)) {
            return;
          }
          if (latestSelectGroupID.includes(Number(data.groupId))) {
            setIncomingCall(data);
            setisAduioCall(false)
          }
        }

      } else {
        console.log("🚀==== SocketHandle initialized", ResUser);
        if (data.to === String(ResUser?.id)) {
          setIncomingCall(data);
          setisAduioCall(false)
        }
      }

    }
    const handleCallEndedNotification = async (data: any) => {
      setIncomingCall(null);
      setSelectCallerInfo(null)
    };

    const handleRejionNotification = async (RejionNotification: any) => {
      if (!selectCallerInfo) {
        setSelectCallerInfo(RejionNotification.data)
      }
    };
    const handleRejionEndNotification = async (RejionNotification: any) => {
      if (selectCallerInfo) {
        setSelectCallerInfo('')
      }
    };

    const setupListeners = () => {
      socket = ChatController.getSocket();
      if (!socket) return;
      socket.on("rejoin-start", handleRejionNotification)
      socket.on("rejoin-end", handleRejionEndNotification)
      socket.on("call-notification", handleCallNotification)
      socket.on("call-ended", handleCallEndedNotification);

    };
    const cleanupListeners = () => {
      if (!socket) return;
      socket.off("rejoin-start", handleRejionNotification)
      socket.off("rejoin-end", handleRejionEndNotification)
      socket.off("call-notification", handleCallNotification)
      socket.off("call-ended", handleCallEndedNotification);


    };

    const waitForSocketReady = () => {
      return new Promise<void>((resolve) => {
        if (ChatController.isSocketConnected === 1) return resolve();

        const interval = setInterval(() => {
          if (ChatController.isSocketConnected === 1) {
            clearInterval(interval);
            resolve();
          }
        }, 300);
      });
    };
    await waitForSocketReady();
    setupListeners();
    return () => {
      cleanupListeners();
    };
  }

  useEffect(() => {
    activityWindow()
    const listener = (_event: any, activity: any, action: any) => {
      // console.log('Current activity received in React:', activity);
      // console.log('Action:', action);
      if (action === 'new') {
        replaceLog(activity)
      } else {
        addLog(activity)
      }
    };
    const systemListener = (_event: any, status: any) => {
      // console.log('Current status received in React:', status, action);
      // console.log('system status from electron', status);
      // const exists = systemLog.some((log) => log.id === status.id);
      replaceSytemLog(status);
    };

    App.currentActivity(listener);
    App.currentStatus(systemListener);
    return () => {
      App.clearCurrentListener();
      App.clearSystemListener();
    };
  }, []);


  const handleDeclineCall = (callData: any) => {
    setIncomingCall(null);
    if (callData.chat_type === 'User') {
      const data = {
        callerId: String(callData.from),
        chat_type: selectGroup ? 'Group' : 'User'
      }
      ChatController.callbackSocket('callEnded', data)
    }

  };

  const handleAcceptCall = async (callData: any) => {
    if (!callData) return;
    const isVideo = callData?.type === 'video';
    const isUserCall = callData?.chat_type === 'User';
    const isGroupCall = callData?.chat_type === 'Group';
    if (isVideo) {
      if (isUserCall) {
        if (selectedUser && callData.from === String(selectedUser.id)) {
          console.log('handleAcceptCall====RootLayout')
          await setIncomingCall(null);
          const data = {
            senderId: String(callData.from),
          }
          ChatController.callbackSocket('callAccepted', data)
          navigate('/connect/RoomMeeting', { state: { token: selectedToken, selectedUser: callData } });
          //  handleCall("1", callData);

        } else {
          UserConnectChatVideo(callData);
        }
      } else if (isGroupCall) {
        if (selectGroup && callData.groupId === selectGroup.groupId) {
          const data = {
            senderId: String(callData.from),
          }
          ChatController.callbackSocket('callAccepted', data)
          navigate('/connect/RoomGroupMeeting', { state: { token: selectedToken, selectedUser: callData } });
          handleCall("1", callData, chatInfo);
          await setIncomingCall(null);
        } else {
          GroupConnectChatVideo(callData);
        }
      }
    } else {
      if (isUserCall) {
        if (selectedUser && callData.from === String(selectedUser.id)) {
          setIncomingCall(null);
          const data = {
            senderId: String(callData.from),
          }
          ChatController.callbackSocket('callAccepted', data)
          handleCall('0', callData, chatInfo)
          navigate('/connect/AudioMeeting', {
            state: {
              token: selectedToken,
              selectedUser: callData,
              screenType: 'ChatLayout',
            },
          });
        } else {
          UserConnectChat(callData);
        }
      } else if (isGroupCall) {
        if (selectGroup && callData.groupId === selectGroup.groupId) {
          setIncomingCall(null);
          const data = {
            senderId: String(callData.from),
            groupId: callData.groupId,
            chat_type: 'Group'
          }
          ChatController.callbackSocket('callAccepted', data)

          navigate('/connect/AudioGroupMeeting', { state: { token: selectedToken, selectedUser: callData, screenType: 'ChatLayout' } })
        }
        else {
          UserConnectGroupChat(callData)
        }

        setSelectGroupCallActive(callData);
      }
    }
  };


  const UserConnectChat = async (CallUser: any) => {
    try {

      if (!ResUser?.id || !CallUser?.from) {
        console.warn("User IDs missing, cannot create room");
        return;
      }
      const createRoomPayload = {
        fromUserId: ResUser.id,
        toUserId: CallUser.from,
      };

      const roomResponse = await createRoom(
        createRoomPayload.fromUserId,
        createRoomPayload.toUserId
      );
      setPageCount(1);
      const response = await GetChatUser();
      const filteredUsers = response?.data?.filter((user: any) => user?.tbl_User?.id === CallUser.senderId).map((user: any) => user?.tbl_User);
      setSelectedUser(filteredUsers[0]);
      setChatInfo(roomResponse?.chat);
      if (roomResponse.room) {
        const userDetails = {
          roomName: roomResponse.room.name,
          participantName: ResUser.firstname,
          userId: CallUser.from,
          metadata: JSON.stringify({
            callerId: CallUser.id,
            callerName: ResUser.firstname,
          }),
        };

        const tokenRes = await getToken(
          userDetails.roomName,
          userDetails.participantName,
          userDetails.userId,
          userDetails.metadata
        );

        setSelectedToken(tokenRes.token);
        handleCall('0', CallUser, roomResponse.chat)
        setIncomingCall(null);
        const data = {
          senderId: String(CallUser.from),
          groupId: '',
          chat_type: 'User'

        }
        ChatController.callbackSocket('callAccepted', data)
        navigate('/connect/AudioMeeting', { state: { token: tokenRes.token, selectedUser: CallUser, screenType: 'ChatLayout' } })

      }
    } catch (err) {
      console.error("❌ Error in initializeChat:", err);
    }
  };
  const UserConnectChatVideo = async (CallUser: any) => {
    try {

      if (!ResUser?.id || !CallUser?.from) {
        console.warn("User IDs missing, cannot create room");
        return;
      }
      const createRoomPayload = {
        fromUserId: ResUser.id,
        toUserId: CallUser.from,
      };

      const roomResponse = await createRoom(
        createRoomPayload.fromUserId,
        createRoomPayload.toUserId
      );
      setPageCount(1);
      const response = await GetChatUser();
      const filteredUsers = response?.data?.filter((user: any) => user?.tbl_User?.id === CallUser.senderId).map((user: any) => user?.tbl_User);
      setSelectedUser(filteredUsers[0]);
      setChatInfo(roomResponse?.chat);
      if (roomResponse.room) {
        const userDetails = {
          roomName: roomResponse.room.name,
          participantName: ResUser.firstname,
          userId: CallUser.from,
          metadata: JSON.stringify({
            callerId: CallUser.id,
            callerName: ResUser.firstname,
          }),
        };

        const tokenRes = await getToken(
          userDetails.roomName,
          userDetails.participantName,
          userDetails.userId,
          userDetails.metadata
        );

        setSelectedToken(tokenRes.token);
        handleCall('1', CallUser, roomResponse.chat)
        setIncomingCall(null);
        const data = {
          senderId: String(CallUser.from),
          groupId: '',
          chat_type: 'User',
          roomResponse: roomResponse.chat

        }
        ChatController.callbackSocket('callAccepted', data)
        navigate('/connect/RoomMeeting', { state: { token: tokenRes.token, selectedUser: CallUser } })

      }
    } catch (err) {
      console.error("❌ Error in initializeChat:", err);
    }
  }

  const UserConnectGroupChat = async (CallGroup: any) => {
    try {
      if (!ResUser?.id) {
        return;
      }

      const createRoomPayload = {
        userIds: CallGroup.memberIds,
        groupId: CallGroup.groupId,
      };

      const roomResponse = await createGroupRoom(
        createRoomPayload.groupId,
        createRoomPayload.userIds
      );
      setPageCount(1);
      setSelectGroup(CallGroup);

      setChatInfo(CallGroup);
      if (roomResponse.room) {
        const userDetails = {
          roomName: roomResponse.room.name,
          participantName: ResUser.firstname,
          userId: ResUser?.id,
          metadata: JSON.stringify({
            callerId: ResUser?.id,
            callerName: ResUser.firstname,
          }),
        };

        const tokenRes = await getToken(
          userDetails.roomName,
          userDetails.participantName,
          userDetails.userId,
          userDetails.metadata
        );

        setSelectedToken(tokenRes.token);
        setIncomingCall(null);
        const data = {
          senderId: String(CallGroup.from),
          groupId: CallGroup.groupId,
          chat_type: 'Group'
        }
        ChatController.callbackSocket('callAccepted', data)
        navigate('/connect/AudioGroupMeeting', { state: { token: tokenRes.token, selectedUser: CallGroup, screenType: 'ChatLayout' } })
      }
    } catch (err) {
    }

  }
  const GroupConnectChatVideo = async (CallGroup: any) => {
    try {
      if (!ResUser?.id) {
        return;
      }

      const createRoomPayload = {
        userIds: CallGroup.memberIds,
        groupId: CallGroup.groupId,
      };

      const roomResponse = await createGroupRoom(
        createRoomPayload.groupId,
        createRoomPayload.userIds
      );
      setPageCount(1);
      setSelectGroup(CallGroup);
      setChatInfo(CallGroup);
      if (roomResponse.room) {
        const userDetails = {
          roomName: roomResponse.room.name,
          participantName: ResUser.firstname,
          userId: ResUser?.id,
          metadata: JSON.stringify({
            callerId: CallGroup.groupId,
            callerName: ResUser.firstname,
          }),
        };

        const tokenRes = await getToken(
          userDetails.roomName,
          userDetails.participantName,
          userDetails.userId,
          userDetails.metadata
        );

        setSelectedToken(tokenRes.token);
        handleCall('1', CallGroup, roomResponse.chat)
        setIncomingCall(null);
        const data = {
          senderId: String(CallGroup.from),
          groupId: CallGroup.groupId,
          chat_type: 'Group'

        }
        ChatController.callbackSocket('callAccepted', data)
        navigate('/connect/RoomGroupMeeting', { state: { token: tokenRes.token, selectedUser: CallGroup } })

      }
    } catch (err) {
      console.error("❌ Error in initializeChat:", err);
    }

  }

  // const selectedHandleCall = async (callData: any) => {
  //   if (callData.chat_type === 'User') {
  //     const data = {
  //       callerId: String(callData.from),
  //       chat_type: selectGroup ? 'Group' : 'User'
  //     }
  //     ChatController.callbackSocket('callEnded', data)
  //   }
  //   setIncomingCall(null);
  //   setSelectCallerInfo(null)
  // }
  const handleCall = async (call_types: any, callData: any, Chatinfo: any) => {
    if (callData.chat_type === "Group") {
      const response = await startCallGroup({ group_id: callData?.groupId, caller_id: String(callData?.senderId) || "", call_type: call_types });
      if (response?.data) {
        setSelectCallerInfo(response.data)
        ChatController.callbackSocket('StartAudioCall', {
          audioCallerId: response.data.id,
        });
      }
    } else {
      const response = await startCall({ chat_id: Chatinfo?.id, caller_id: callData?.senderId || "", call_type: call_types });
      if (response?.data) {
        setSelectCallerInfo(response.data)
        ChatController.callbackSocket('StartAudioCall', {
          audioCallerId: response.data.id,
        });

      }

    }
  }

  const queryClient = useMemo(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            retry: 0,
          },
          mutations: {
            retry: 0,
          },
        },
      }),
    []
  )
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <div className="flex flex-col min-h-screen bg-background">
          <WindowHeader />
          <StatsFetcher />

          <div className="flex items-start w-full">
            <div
              className="sticky top-10 h-[calc(100vh-68px)] inset-y-0 z-20 transform transition duration-200 ease-in-out"
            >
              {pathname !== '/login' && <AppSidebar />}
            </div>

            {/* Main content */}
            <main className="flex-grow w-1/2 flex flex-col h-full">
              <Outlet />
            </main>
          </div>
          {pathname !== '/login' && <Footer />}
          <Toaster richColors={true} />
        </div>
        {incomingCall && (
          <div className="fixed top-0 left-0 w-full h-full bg-black bg-opacity-40 flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl shadow-xl p-6 w-[300px] text-center">
              <h2 className="text-xl font-semibold mb-4">📞 Incoming Call</h2>
              <p className="mb-6">{incomingCall.name || 'Unknown User'} is calling...</p>
              <div className="flex justify-around">
                <button
                  onClick={() => handleAcceptCall(incomingCall)}
                  className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded-xl"
                >
                  Accept
                </button>
                <button
                  onClick={() => handleDeclineCall(incomingCall)}
                  className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-xl"
                >
                  Decline
                </button>
              </div>
            </div>
          </div>
        )}
      </ThemeProvider>
    </QueryClientProvider>
  )
}

export default RootLayout
