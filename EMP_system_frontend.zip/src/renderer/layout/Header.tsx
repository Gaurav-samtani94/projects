import { Link, useLocation, useNavigate } from 'react-router-dom'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar"
import { Button } from 'renderer/components/ui/button'
import useAuthStore from 'renderer/store/AuthStore'
import { BellDot, UserRound } from 'lucide-react'


const navItems = [
  // { name: 'Dashboard', path: '/' },
  { name: 'Projects', path: '/projects' },
  { name: 'Hrms', path: '/hrms' },
  // { name: 'Connect', path: '/connect' },
  { name: 'Calendar', path: '/calendar' },
  { name: 'Schedule', path: '/scheduled' },
  { name: 'Chat', path: '/chat' },
  { name: 'Instant Meeting', path: '/connect/RoomMeeting' },
  // { name: 'calendar', path: '/calendar' },
  // { name: 'Editor', path: '/editor' },
]

const Header = () => {
  const pathname = useLocation().pathname
  const navigate = useNavigate();
  const logout = useAuthStore((state) => state.logout);
  const { isAuthenticated } = useAuthStore()
  const handleLogout = () => {
    logout(); // Clear auth state
    navigate('/login'); // Redirect to login
  };

  return (
    <header className="sticky !top-10 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="px-4 flex h-14 items-center justify-between">
        <nav className="flex items-center space-x-8 mr-10">
          <Link

            to="/"
            className={`text-sm font-medium transition-colors hover:text-primary text-muted-foreground ${pathname === '/' ? 'text-primary' : ''
              }`}
          >
            Dashboard
          </Link>
          {navItems.map(item => (
            <Link
              key={item.name}
              to={item.path}
              className={`text-sm font-medium transition-colors hover:text-primary text-muted-foreground ${pathname.includes(item.path) ? 'text-primary' : ''
                }`}
            >
              {item.name}
            </Link>
          ))}
        </nav>
        <div className="flex items-center space-x-4">
          <Button variant={isAuthenticated ? 'destructive' : 'default'} onClick={handleLogout}
          >
            {isAuthenticated ? 'Logout' : 'LogIn'}
          </Button>

          <Link to="/notification">
            <button>
              <BellDot className='w-5 h-5 mt-2' />
            </button>
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger>
              <Avatar>
                <AvatarImage src="https://github.com/shadcn.png" />
                <AvatarFallback>CN</AvatarFallback>
              </Avatar>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem><Link to="/profile/general">Profile</Link></DropdownMenuItem>
              <DropdownMenuItem><Link to="/profile/account">account</Link></DropdownMenuItem>
              <DropdownMenuItem><Link to="/profile">Profile</Link></DropdownMenuItem>
              {/* <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuItem>Logout</DropdownMenuItem> */}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

export default Header
