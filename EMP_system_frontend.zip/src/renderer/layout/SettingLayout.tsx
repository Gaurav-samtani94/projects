"use client";
import React from 'react'
import { Outlet } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from 'renderer/components/ui/tabs'
import { SettingSidebar } from 'renderer/layout/SettingSidebar';

const sidebarNavItems = [

    {
        title: "General",
        href: "/profile/settings/notification/",
    },

    {
        title: "Chat",
        href: "/profile/settings/notification/chat",
    },

    {
        title: "Persons",
        href: "/profile/sign-out",
    },

    {
        title: "Human Resources",
        href: "/profile/sign-out",
    },

    {
        title: "Documents",
        href: "/profile/sign-out",
    },

    {
        title: "Requests",
        href: "/profile/sign-out",
    },
];

const settingLayout = () => {
    return (
        <div className="space-y-6 w-full">
            <Tabs defaultValue="notification">
                <TabsList className='p-0 w-full'>
                    <TabsTrigger value="notification">Notification</TabsTrigger>
                    <TabsTrigger value="customizeTheme">Customize Theme</TabsTrigger>
                    <TabsTrigger value="appearance">Appearance </TabsTrigger>
                </TabsList>
                <TabsContent value="notification" className='mt-5'>
                    <div className="flex gap-7 space-y-8">
                        {/* Sidebar */}
                        <aside className="w-[22%] pr-7 border-r border-gray-200 h-auto">
                            <SettingSidebar items={sidebarNavItems} />
                        </aside>

                        {/* Main Content */}
                        <div className="flex-1">
                            <Outlet />
                        </div>
                    </div>
                </TabsContent>
            </Tabs>
        </div>
    )
}

export default settingLayout