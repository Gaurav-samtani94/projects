import React from 'react'

const Footer = () => {
  return (
    <div className=" text-center text-sm py-1 w-full bg-secondary backdrop-blur fixed bottom-0">
      employee management system @2025 copyright
    </div>
  )
}

export default Footer
