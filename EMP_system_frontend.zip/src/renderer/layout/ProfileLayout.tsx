import React from "react";
import { Outlet } from "react-router-dom";
// import { SidebarNav } from "./ProfileSidebar";
import { ProfileSidebar } from "./ProfileSidebar";
import { Avatar, AvatarFallback, AvatarImage } from "renderer/components/ui/avatar";
import useAuthStore from "renderer/store/AuthStore";

const sidebarNavItems = [
    {
        title: "Profile",
        href: "/profile/general",
    },
    {
        title: "Settings",
        href: "/profile/settings/notification/",
    },
    {
        title: "Change Password",
        href: "/profile/changePassword",
    },
    {
        title: "Team View",
        href: "/profile/team",
    },
    {
        title: "Sign Out",
        href: "/profile/sign-out",
    },
];

const ProfileLayout = () => {
    const { getUser } = useAuthStore();
    const user = getUser();
    console.log("user", user)
    return (
        <>
            {/* Mobile View - Display Image Placeholder */}
            {/* <div className="md:hidden">
                <img
                    src="/examples/forms-light.png"
                    width={1280}
                    height={791}
                    alt="Profile"
                    className="block dark:hidden"
                />
                <img
                    src="/examples/forms-dark.png"
                    width={1280}
                    height={791}
                    alt="Profile"
                    className="hidden dark:block"
                />
            </div> */}

            {/* Main Layout */}
            <div className="hidden space-y-6 p-10 pb-16 md:block">
                {/* Page Header */}
                <div className="flex items-center space-x-4">
                    <Avatar className="size-20">
                        <AvatarImage src={user?.profile_image ?? ""} alt={user?.userfullname} className="rounded-full object-cover" />
                        <AvatarFallback className="capitalize">{user?.userfullname?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="space-y-0.5">
                        <h2 className="text-xl font-medium tracking-tight">{user?.firstname}</h2>
                        <p className="text-muted-foreground text-sm">{user?.designation ?? "-"}</p>
                    </div>
                </div>

                {/* Separator */}
                <hr className="my-6 border-gray-300 dark:border-gray-700" />

                {/* Sidebar & Content Layout */}
                <div className="flex flex-col space-y-8 lg:flex-row lg:space-x-12 lg:space-y-0 w-full">
                    {/* Sidebar */}
                    <aside className="w-[20%] pr-5 border-r border-gray-200">
                        <ProfileSidebar items={sidebarNavItems} />
                    </aside>

                    {/* Main Content */}
                    <div className="flex-1">
                        <Outlet />
                    </div>
                </div>
            </div>
        </>
    );
};

export default ProfileLayout;
