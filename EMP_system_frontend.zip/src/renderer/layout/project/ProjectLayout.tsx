import { useQuery } from '@tanstack/react-query';
import { Folder, Plus } from 'lucide-react';
import React, { useEffect, useRef } from 'react'
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import AddProjectModal from 'renderer/components/sections/AddProjectModal';
import { Button } from 'renderer/components/ui/button';
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from 'renderer/components/ui/resizable';
import { ScrollArea } from 'renderer/components/ui/scroll-area';
import { uiConstants } from 'renderer/contants/uiConstants';
import ChatController from 'renderer/Controller/ChatController';
import Sidemenu from 'renderer/layout/project/Sidemenu';
import { getProject } from 'renderer/service/project';
import useAuthStore from 'renderer/store/AuthStore';

const ProjectLayoutNew = () => {
    const navigate = useNavigate()
    const isFirstLoad = useRef(true);
    const user = useAuthStore.getState().getUser();
    const { data: projectList, isSuccess, refetch } = useQuery({
        queryKey: ['projectList'],
        queryFn: () => getProject(),
    });

    useEffect(() => {
        const projects = projectList?.data;

        if (!projects || projects.length === 0) {
            navigate("/project/create-new-project");
            return;
        }

        if (isFirstLoad.current) {
            navigate(`/project/${projects[0].id}`, {
                state: { projectDetails: projects[0] }
            });
            isFirstLoad.current = false;
        }

    }, [projectList?.data])

    const ConnectUser = async () => {
        await ChatController.connectUser(user?.id || "")
    }
    useEffect(() => {
        ConnectUser()
    }, [])

    return (

        <ResizablePanelGroup direction="horizontal" className="flex relative items-start !overflow-visible space-y-8 w-full">
            {/* Sidebar */}
            <ResizablePanel defaultSize={20} minSize={15} maxSize={30} className={`h-[calc(100vh-${uiConstants.windowHeaderHeight + uiConstants.footerHeight}px)] sticky top-[40px] p-4`}>
                <ScrollArea className={`h-[calc(100vh-${uiConstants.windowHeaderHeight + uiConstants.footerHeight}px)] pb-6 pr-4 `}>
                    <div className='flex items-center justify-between mb-5'>

                        <h2 className='text-2xl'>Projects</h2>
                        {user?.isReportingManager === true &&
                            <AddProjectModal refetch={refetch}>
                                <Button
                                    variant={"outline"}
                                    size="icon"
                                >
                                    <Plus className="size-5" />
                                </Button>
                            </AddProjectModal>}
                    </div>

                    <Sidemenu items={projectList?.data} refetch={refetch} />
                </ScrollArea>
            </ResizablePanel>
            {/* Resizable Handle */}
            <ResizableHandle withHandle className={`h-[calc(100vh-${uiConstants.windowHeaderHeight + uiConstants.footerHeight}px)] sticky top-[40px]`} />

            {/* Project Detail Panel */}
            <ResizablePanel defaultSize={75} className="overflow-auto">
                <Outlet />
            </ResizablePanel>
        </ResizablePanelGroup>
    )
}

export default ProjectLayoutNew