import { Link, useLocation, useParams } from "react-router-dom";
import { buttonVariants } from "../../components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "renderer/components/ui/dropdown-menu";
import { ArchiveRestore, MoreHorizontal, Trash2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { deleteProjects } from "renderer/service/project";
import { toast } from "sonner";
import { Folder, Plus } from 'lucide-react';

function cn(...classes: (string | undefined)[]) {
    return classes.filter(Boolean).join(" ");
}

interface SidebarNavProps extends React.HTMLAttributes<HTMLElement> {
    items: any;
    refetch: any
}

const iconMap: { [key: string]: React.ReactNode } = {
    folder: <Folder size={20} />,
};

export function Sidemenu({ className, items, refetch, ...props }: SidebarNavProps) {
    // const location = useLocation();
    const { id } = useParams();

    const deleteProjectMutation = useMutation({
        mutationFn: deleteProjects,
        onSuccess: (response) => {
            refetch()
            toast.success(response?.message)

        },
        onError: (error: any) => {
            toast.error(error?.message)
        },
    })
    const handleDelete = (id: any) => {
        deleteProjectMutation.mutate({
            project_id: id
        })
    }

    return (
        <nav
            className={cn(
                "flex flex-col space-y-1",
                className
            )}
            {...props}
        >
            {items?.map((item: any) => (
                <div key={item?.id} className="flex items-center justify-between group">
                    <Link
                        to={`/project/${item?.id}`}
                        state={{ projectDetails: item }}
                        className={cn(
                            buttonVariants({ variant: "ghost" }),
                            id == item.id
                                ? "bg-primary hover:bg-primary text-primary-foreground hover:text-primary-foreground    "
                                : "hover:bg-transparent hover:underline",
                            "w-full flex items-center !justify-between space-x-2"
                        )}
                    >

                        <div className="flex w-1/2 grow items-center space-x-2">
                            {iconMap[item?.icon] ?? <Folder size={20} />}
                            <span className="truncate">{item?.project_name}</span>
                        </div>
                        {/* Dropdown */}
                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <button className="opacity-0 group-hover:opacity-100 transition  p-2">
                                    <MoreHorizontal size={16} />
                                </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-28">
                                {/* <DropdownMenuItem onClick={() => alert(`Archived ${item?.id}`)}>
                                    <ArchiveRestore /> Archive
                                </DropdownMenuItem> */}
                                <DropdownMenuItem onClick={() => handleDelete(item?.id)} className="text-red-600">
                                    <Trash2 className="text-red-600" /> Delete
                                </DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </Link>

                </div>
            ))}
        </nav>
    );
}

export default Sidemenu;
