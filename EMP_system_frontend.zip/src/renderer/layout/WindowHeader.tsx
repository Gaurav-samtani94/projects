import {
  ArrowLeft,
  ArrowRight,
  Braces,
  House,
  Maximize,
  Minus,
  X,
} from 'lucide-react'
import { Link } from 'react-router-dom'
import { ModeToggle } from 'renderer/components/ui/ThemeButton'

const { App } = window
const WindowHeader = () => {

  return (
    <div className="window-header w-full flex justify-between items-center select-none bg-secondary sticky top-0 z-[99999999999999999]">
      <div className="flex gap-0 items-center">
        <Link
          to="/"
          className="cursor-pointer duration-300 hover:bg-accent px-4 py-2.5 no-drag"
        >
          <House className="size-4" />
        </Link>
        <button
          className="cursor-pointer duration-300 hover:bg-accent px-4 py-2.5 no-drag"
          onClick={() => App.goBack()}
        >
          <ArrowLeft className="size-4" />
        </button>
        <button
          className="cursor-pointer duration-300 hover:bg-accent px-4 py-2.5 no-drag"
          onClick={() => App.goForward()}
        >
          <ArrowRight className="size-4" />
        </button>
        <p className="px-4 py-2.5 text-sm font-bold">EMS</p>
      </div>
      <div className="flex gap-0">
        <div className='no-drag'>

          <ModeToggle />
        </div>

        <button
          className="cursor-pointer duration-300 hover:bg-accent px-4 py-2.5 no-drag"
          onClick={() => App.toggleDevTools()}
        >
          <Braces className="size-4" />
        </button>
        <button
          className="cursor-pointer duration-300 hover:bg-accent px-4 py-2.5 no-drag"
          onClick={() => App.minimize()}
        >
          <Minus className="size-4" />
          {/* <Minimize2 /> */}
        </button>
        <button
          className="cursor-pointer duration-300 hover:bg-accent px-4 py-2.5 no-drag"
          onClick={() => App.maximize()}
        >
          <Maximize className="size-4" />
        </button>
        <button
          className="cursor-pointer duration-300 hover:bg-red-500 hover:text-white px-4 py-2.5 no-drag"
          onClick={() => App.close()}
        >
          <X className="size-4" />
        </button>
      </div>
    </div>
  )
}

export default WindowHeader
