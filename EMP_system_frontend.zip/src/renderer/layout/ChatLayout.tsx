import { useEffect, useMemo, useRef, useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import ChatHeader from 'renderer/components/sections/ChatHeader'
import ChatMessageInput from 'renderer/components/sections/ChatMessageInput'
import ChatSidebar from 'renderer/components/sections/ChatSidebar'
import { Room, RoomEvent } from 'livekit-client';
import { Chat_history, ChatGroup_history, rejoin_call_Group } from 'renderer/service/authService';
import { useMutation } from '@tanstack/react-query';
import useAuthStore from 'renderer/store/AuthStore';
import BaseUrl from 'renderer/service/BaseUrl';
import ChatController from 'renderer/Controller/ChatController';
import { useChatStore, usePageStore } from 'stores/useChatStore';
import ChatHeaderGroup from 'renderer/components/sections/ChatHeaderGroup';
import ChatMessageGroup from 'renderer/components/sections/ChatMessageGroup';
import { createRoom, getToken } from 'renderer/service/connectServices';
const serverUrl = BaseUrl.LIVEKIT_URL;

const ChatLayout = () => {
    const pathname = useLocation().pathname
    const { selectedUser, chatInfo, selectedToken, selectGroup, callFlag, selectCallerInfo, setSelectedUser, setChatInfo, setSelectedToken, setSelectGroup, setSelectGroupCallActive, setSelectCallerInfo } = useChatStore();
    const { setPageCount } = usePageStore();
    const [activeChat, setActiveChat] = useState<any>();
    const [replyMessage, setReplyMessage] = useState<any>(null);
    const { pagecount } = usePageStore();
    const [forwardMessage, setForwardMessage] = useState<any>(null);
    const [room, setRoom] = useState<Room | null>(null);
    const fileChunksRef = useRef<{ [key: string]: { chunks: string[]; fileName: string } }>({});
    const [messages, setMessages] = useState<{ sender: string; text: string; file: string, sender_id: string, delivered_at: string, msg_id: string, }[]>([]);
    const [incomingCall, setIncomingCall] = useState<any>(null);
    const [activeTab, setActiveTab] = useState<string>(pathname === "/chat/group" ? "groups" : 'users');
    const [isAduioCall, setisAduioCall] = useState<any>(null);
    const timeoutRef = useRef<NodeJS.Timeout | null>(null);
    const ResUser = useAuthStore.getState().getUser();
    const selectedUserId = useMemo(() => selectedUser?.id, [selectedUser]);
    const selectGroupId = useMemo(() => selectGroup?.groupId, [selectGroup]);


    useEffect(() => {
        ConnectUser()
        Rejoin_call_Group()

        if (!selectedToken) return;
        const connectRoom = async () => {
            const livekitRoom = new Room({ adaptiveStream: true, dynacast: true });
            try {
                await livekitRoom.connect(serverUrl, selectedToken);
                setRoom(livekitRoom);
                livekitRoom.on(RoomEvent.DataReceived, (payload, participant) => {
                    try {
                        const data = JSON.parse(new TextDecoder().decode(payload));
                        console.log('data=======>>>', data)
                        ChatController.callbackSocket('messageDelivered', { msg_id: data.id })

                        const isGroup = data.toGroup ? data.toGroup : data.sender_id;
                        const isSelect = data.toGroup ? selectGroup.groupId : selectedUser?.id;

                        if (String(isGroup ?? '') === String(isSelect ?? '')) {
                            if (data.isChunk) {
                                const { fileId, fileName, delivered_at, sender_id, chunk, isLast, isReply, replyTo, replyMessage } = data;
                                if (!fileChunksRef.current[fileId]) {
                                    fileChunksRef.current[fileId] = { chunks: [], fileName };
                                }
                                fileChunksRef.current[fileId].chunks.push(chunk);
                                if (isLast) {
                                    setTimeout(() => {
                                        const isGroupChat = !!chatInfo?.groupId;
                                        const chatId = isGroupChat ? chatInfo.groupId : chatInfo?.id;

                                        if (chatId) {
                                            if (data.toUser === ResUser?.id && data.chat_type === 'User') {
                                                getChat_historys(chatId);
                                            }
                                            if (data.chat_type === 'Group') {
                                                getChat_historys(chatId);

                                            }

                                        }

                                        delete fileChunksRef.current[fileId];
                                    }, 300);

                                }
                            } else {
                                if (data.isReply) {
                                    const isGroupChat = !!chatInfo?.groupId;
                                    const chatId = isGroupChat ? chatInfo.groupId : chatInfo?.id;

                                    if (chatId) {
                                        if (data.toUser === ResUser?.id && data.chat_type === 'User') {
                                            getChat_historys(chatId);

                                        }
                                        if (data.chat_type === 'Group') {
                                            getChat_historys(chatId);

                                        }

                                    }

                                } else {
                                    const lastMsgId = messages.length > 0 ? Number(messages[messages.length - 1]?.msg_id) : 0;
                                    const nextMsgId = lastMsgId + 1;

                                    if (data.toUser === ResUser?.id && data.chat_type === 'User') {
                                        console.log('sdaasd')
                                        setMessages((prev) => [
                                            ...prev,
                                            { sender: participant?.name ?? "", sender_id: String(data.sender_id), text: data.text, delivered_at: data.delivered_at, file: data.file || null, isReply: data.isReply, replyTo: data.replyTo, replyMessage: data.replyMessage || null, msg_id: data.id, status: 'delivered' },
                                        ]);
                                        ChatController.callbackSocket('messageRead', { msg_id: data.id })

                                    }
                                    if (data.chat_type === 'Group') {
                                        setMessages((prev) => [
                                            ...prev,
                                            { sender: participant?.name ?? "", sender_id: String(data.sender_id), text: data.text, delivered_at: data.delivered_at, file: data.file || null, isReply: data.isReply, replyTo: data.replyTo, replyMessage: data.replyMessage || null, msg_id: data.id, status: '' },
                                        ]);
                                    }


                                }
                            }
                        }

                    } catch (error) {
                    }
                });
                livekitRoom.on(RoomEvent.ConnectionStateChanged, async (state) => {
                    if (state === "disconnected") {
                        try {
                        } catch (error) {
                        }
                    }
                });
            } catch (error) {
                console.error("❌ Failed to connect to LiveKit:", error);
            }
        };
        if (callFlag) {
            connectRoom()
        }



        return () => {
            room?.disconnect();
        };
    }, [selectedToken, selectedUserId, selectGroupId]);


    const ConnectUser = async () => {
        await ChatController.connectUser(ResUser?.id || "")
    }


    const Rejoin_call_Group = async () => {
        if (selectCallerInfo) {
            getRejio_Call.mutate({
                callerId: selectCallerInfo?.id,
            })
        }

    }

    useEffect(() => {
        setMessages([]);
        const isGroupChat = !!chatInfo?.groupId;
        const chatId = isGroupChat ? chatInfo.groupId : chatInfo?.id;
        if (chatId) {
            getChat_historys(chatId);
        }
    }, [selectedUser, selectGroup]);


    useEffect(() => {
        if (activeTab === 'users') {
            setSelectGroup(null)
        } else if (activeTab === 'groups') {
            setSelectedUser(null)
        }
    }, [activeTab])


    useEffect(() => {
        let cleanupFn: (() => void) | undefined;
        const setupSocket = async () => {
            cleanupFn = await SocketHandle();
        };
        setupSocket();
        return () => {
            cleanupFn?.();
        };
    }, [selectedUser]);

    const SocketHandle = async () => {
        let socket: any;
        const handleRejionNotification = async (RejionNotification: any) => {
            console.log('RejionNotification', RejionNotification)
            if (!selectCallerInfo) {
                setSelectCallerInfo(RejionNotification.data)
            }
        };
        const handleRejionEndNotification = async (RejionNotification: any) => {
            if (selectCallerInfo) {
                setSelectCallerInfo('')
            }
        };
        const handleReceivedNotification = async (data: any) => {
            if (!selectedUser) {
                return;
            }
            if (data.to !== ResUser?.id) return;
            if (data.chat_type !== "User") return;
            if (data.isForward && selectedUser.id === data.sender_id) {
                getForward_historys(data.chat_id, '1', '10')
                ForwardReconnect(data)
            } else {


            }
        };





        const setupListeners = () => {
            socket = ChatController.getSocket();
            if (!socket) return;
            socket.on("rejoin-start", handleRejionNotification)
            socket.on("rejoin-end", handleRejionEndNotification)
            socket.on("notification", handleReceivedNotification);
            // socket.on("call-notification", handleCallNotification)
            // socket.on("call-ended", handleCallEndedNotification);

        };
        const cleanupListeners = () => {
            if (!socket) return;
            socket.off("rejoin-start", handleRejionNotification)
            socket.off("rejoin-end", handleRejionEndNotification)
            socket.off("notification", handleReceivedNotification);
            // socket.off("call-ended", handleCallEndedNotification);

        };

        const waitForSocketReady = () => {
            return new Promise<void>((resolve) => {
                if (ChatController.isSocketConnected === 1) return resolve();

                const interval = setInterval(() => {
                    if (ChatController.isSocketConnected === 1) {
                        clearInterval(interval);
                        resolve();
                    }
                }, 300);
            });
        };
        await waitForSocketReady();
        // ChatController.onUserStatus(handleStatus)
        setupListeners();
        return () => {
            cleanupListeners();
            // ChatController.offUserStatus(handleStatus)

        };
    }

    const getChat_historys = async (chatInfo: any) => {
        //  await setMessages([])
        if (!chatInfo) {
            return;
        }
        if (pagecount === 1) {
            if (selectGroup?.groupType === "group") {
                getChatGroup_history.mutate({
                    group_id: chatInfo,
                    page_number: pagecount,
                    limit: '10',
                })
            } else {
                getChat_history.mutate({
                    chat_id: chatInfo,
                    page_number: String(pagecount),
                    limit: '10',
                })
            }
        } else {
            return null;
        }
    }

    const getForward_historys = async (chat_id: any, page_number: any, limit: any) => {
        getChat_history.mutate({
            chat_id: chat_id,
            page_number: page_number,
            limit: limit,
        });
    }

    const getChat_history = useMutation({
        mutationFn: Chat_history,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const formattedMessages = response.data.map((msg: any) => ({
                    sender: msg?.sender?.userfullname ?? "Unknown",
                    sender_id: String(msg?.sender_id ?? ""),
                    text: msg?.text ?? msg?.file_name?.split('_').slice(1).join('_'),
                    delivered_at: msg?.delivered_at ?? msg.createdAt,
                    file: msg.text ? "" : msg?.file_name ? `${BaseUrl.Url_Base}/${msg?.file_path}/${msg?.file_name}` : "",
                    msg_id: String(msg?.id),
                    reply_to_id: msg?.reply_to_id || null,
                    replyTo: msg?.replyTo || null,
                    forwardedFrom: msg?.forwardedFrom || null,
                    start_time: msg?.start_time || null,
                    end_time: msg?.end_time || null,
                    duration: msg?.duration || null,
                    chat_type: msg?.chat_type || null,
                    call_type: msg?.call_type || null,
                    status: 'read'
                }));
                setMessages(formattedMessages);
                const lastElement = formattedMessages[formattedMessages.length - 1];
                ChatController.callbackSocket('messageRead', { msg_id: lastElement.msg_id })
            }

        },
        onError: error => {
            console.error('Error fetching chat history:', error);
        },
    })
    const getChatGroup_history = useMutation({
        mutationFn: ChatGroup_history,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const formattedMessages = response.data.map((msg: any) => ({
                    sender: msg.sender?.userfullname ?? "Unknown",
                    sender_id: String(msg.sender_id ?? ""),
                    text: msg?.text ?? msg?.file_name?.split('_').slice(1).join('_'),
                    delivered_at: msg?.delivered_at ?? msg.createdAt,
                    file: msg?.text ? "" : msg?.file_name ? `${BaseUrl.Url_Base}/${msg?.file_path}/${msg?.file_name}` : "",
                    msg_id: String(msg?.id),
                    reply_to_id: msg?.reply_to_id || null,
                    replyTo: msg?.replyTo || null,
                    forwardedFrom: msg?.forwardedFrom || null,
                    start_time: msg?.start_time || null,
                    end_time: msg?.end_time || null,
                    duration: msg?.duration || null,
                    chat_type: msg?.chat_type || null,
                    call_type: msg?.call_type || null,
                    status: ''
                }));
                setMessages(formattedMessages);
            }

        },
        onError: error => {
            console.error('Error fetching chat history:', error);
        },
    })

    const getRejio_Call = useMutation({
        mutationFn: rejoin_call_Group,
        onSuccess: response => {
            if (response.data === 404 && response.Status === "0") {
                setSelectCallerInfo('')
            }
        },
        onError: error => {
            console.error('Error fetching chat history:', error);
        },
    })

    const HandleMassage = (data: any) => {
        if (data.type === 'group') {
            if (data.isReply) {
                const chatId = chatInfo?.groupId;
                getChat_historys(chatId);
            }
            else {
                setMessages((prev) => [
                    ...prev,
                    { msg_id: data.id, sender: data?.sender ?? "", sender_id: String(data.sender_id), text: data.text, delivered_at: data.delivered_at, file: data.file || undefined, isReply: data.isReply, replyTo: data.replyTo, replyMessage: data.replyMessage || null, status: '' },
                ]);
            }

            setForwardMessage(null);
            setReplyMessage(null);
        } else {
            if (data.isReply) {
                const chatId = chatInfo?.id;
                getChat_historys(chatId);
            }
            else {
                setMessages((prev) => [
                    ...prev,
                    { msg_id: data.id, sender: data?.sender ?? "", sender_id: String(data.sender_id), text: data.text, delivered_at: data.delivered_at, file: data.file || undefined, isReply: data.isReply, replyTo: data.replyTo, replyMessage: data.replyMessage || null, status: 'sent' },
                ]);
            }

            setForwardMessage(null);
            setReplyMessage(null);
        }
    };

    const ForwardReconnect = async (ForwardInfo: any) => {
        // console.log('ForwardInfo', ForwardInfo)
        const createRoomPayload = {
            fromUserId: ForwardInfo.to,
            toUserId: ForwardInfo?.sender_id,
        };
        // console.log('createRoomPayload', createRoomPayload)
        const roomResponse = await createRoom(
            createRoomPayload.fromUserId,
            createRoomPayload.toUserId
        );
        setChatInfo(roomResponse.chat);
        setPageCount(1);
        setSelectedUser(selectedUser);
        // console.log('roomResponse', roomResponse)
        if (roomResponse.room) {
            const userDetails = {
                roomName: roomResponse.room.name,
                participantName: ResUser?.userfullname ?? 'Unknown',
                userId: ForwardInfo?.sender_id,
                metadata: JSON.stringify({
                    callerId: ForwardInfo?.sender_id,
                    callerName: ResUser?.userfullname ?? 'Unknown',
                }),
            };

            const tokenRes = await getToken(
                userDetails.roomName,
                userDetails.participantName,
                userDetails.userId,
                userDetails.metadata
            );
            // setFlag(true)
            // readmark(roomResponse.chat.id, selectedUser.id)
            setSelectedToken(tokenRes.token);
        }
    }



    return (
        <div className='flex h-full flex-grow'>
            <ChatSidebar room={room} forwardedChat={activeChat} activeTab={activeTab} setActiveTab={(t: string) => setActiveTab(t)} setReplyReset={() => setReplyMessage(null)} />
            {selectGroup && room && (
                <div className='w-1/2 flex-grow flex flex-col h-[calc(100vh-67px)]'>
                    <ChatHeaderGroup groupInfo={chatInfo} room={room} selectGroup={selectGroup} chatInfo={chatInfo} selectedToken={selectedToken ?? undefined} isAudioCall={isAduioCall} selectCallerInfo={selectCallerInfo} />

                    <div className='flex-grow overflow-auto'>
                        <Outlet context={{
                            room, selectedToken, messages, activeTab, setActiveTab, selectGroup, selectedUser, setReplyMessage, replyMessage, forwardMessage, setForwardMessage, setActiveChat, appendMessages: (newMessages: []) => {
                                setMessages(prev => [...newMessages, ...prev])
                            }, setMessages
                        }} />
                    </div>
                    <ChatMessageGroup
                        room={room}
                        groupInfo={chatInfo}
                        messages={messages}
                        selectGroup={selectGroup}
                        setReplyMessage={setReplyMessage}
                        replyMessage={replyMessage}
                        setForwardMessage={setForwardMessage}
                        HandleMassage={HandleMassage}
                    />

                </div>
            )}

            {selectedUser && room && (
                <div className='w-1/2 flex-grow flex flex-col h-[calc(100vh-67px)]'>

                    <ChatHeader room={room} selectedUser={selectedUser} chatInfo={chatInfo} selectedToken={selectedToken ?? ''} isAudioCall={isAduioCall} />

                    <div className='flex-grow overflow-auto'>
                        <Outlet context={{
                            room, selectedToken, activeTab, setActiveTab, messages, selectedUser, setReplyMessage, replyMessage, forwardMessage, setForwardMessage, setActiveChat, setMessages, appendMessages: (newMessages: []) => {
                                setMessages(prev => [...newMessages, ...prev])
                            }
                        }} />
                    </div>

                    <ChatMessageInput room={room} selectedUser={selectedUser} chatInfo={chatInfo} HandleMassage={HandleMassage} setReplyMessage={setReplyMessage} setForwardMessage={setForwardMessage} replyMessage={replyMessage} />

                </div>
            )}
        </div>
    )
}

export default ChatLayout