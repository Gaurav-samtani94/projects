import BaseUrl from "renderer/service/BaseUrl";
import { io, type Socket } from "socket.io-client";
import { useChatStore } from "stores/useChatStore";

const { App } = window
const ChatUrl = BaseUrl.Url_Base
// biome-ignore lint/complexity/noStaticOnlyClass: <explanation>
class ChatController {

  private static socket: Socket | null = null;
  static isSocketConnected = 0;
  // https://staging-emp.growthgrids.com
  // http://192.168.11.161:3536

  static onUserStatus(cb: (data: any) => void) {
    ChatController.socket?.on("userStatus", cb);
  }

  static offUserStatus(cb: (data: any) => void) {
    ChatController.socket?.off("userStatus", cb);
  }

  static connectUser(userId: string): void {

    if (ChatController.isSocketConnected === 0) {
      ChatController.socket = io(ChatUrl, {
        query: { user_id: userId },
        autoConnect: true,
      });

      ChatController.reConnect();
      if (ChatController.socket) {
        ChatController.socket.on("notification", async (data) => {
          console.log('notification', data)
          if (data.chat_type === "Group") {
            const latestSelectGroupID = useChatStore.getState().selectGroupID;
            if (data.to !== userId) {
              if (!latestSelectGroupID || !Array.isArray(latestSelectGroupID)) {
                return;
              }
              if (latestSelectGroupID.includes(Number(data.groupId))) {
                App.messageNotification(data, "message-notification");
              }
            }
          } else {
            if (data.to === userId) {
              App.messageNotification(data, "message-notification");
            }
          }

        });
        ChatController.socket.on("new-group-message", async (data) => {
          if (data.chat_type === "Group") {
            const latestSelectGroupID = useChatStore.getState().selectGroupID;
            if (data.to !== userId) {
              if (!latestSelectGroupID || !Array.isArray(latestSelectGroupID)) {
                return;
              }
              if (latestSelectGroupID.includes(Number(data.groupId))) {
                App.messageNotification(data, "message-notification");
              }
            }
          } else {
            if (data.to === userId) {
              App.messageNotification(data, "message-notification");
            }
          }

        });



        ChatController.socket.on("call-notification", async (data) => {
          if (data.chat_type === "Group") {
            const latestSelectGroupID = useChatStore.getState().selectGroupID;
            if (data.to !== userId) {
              if (!latestSelectGroupID || !Array.isArray(latestSelectGroupID)) {
                return;
              }
              if (latestSelectGroupID.includes(Number(data.groupId))) {
                App.showNotification(data, "Show-notification");
              }
            }
          }
          else {
            if (data.to === String(userId)) {
              App.showNotification(data, "Show-notification");
            }
          }
        });



        ChatController.socket.on("meeting-notification", async (data) => {
          console.log('meeting-event====>>', data)
          const create_by = data?.create_by;
          const currentUserId = userId;
          console.log('create_by====>>', create_by)
          console.log('currentUserId====>>', currentUserId)
          if (Number(create_by) !== Number(currentUserId)) {
            App.meetingNotification(data?.title, "meeting-notification");
          } else {
            console.log(`Skipping notification for user ID ${currentUserId}`);
          }
        });

        ChatController.socket.on("call-accepted", async (data) => {
          // console.log('call-accepted ChatController====>>', data)
        });
        ChatController.socket.on("call-ended", async (data) => {
          // console.log('call-ended====>>++++++', data)
        });
        ChatController.socket.on("userStatus", async (data) => {
          console.log('userStatus=====+++', data)
        });



        ChatController.socket.on("connect", () => {
          ChatController.isSocketConnected = 1;
          console.log("✅ Socket Connected");
        });

        ChatController.socket.on("disconnect", (data) => {
          ChatController.isSocketConnected = 0;
          console.log("⚠️ Socket Disconnected", data);
        });

        ChatController.socket.on("connect_error", (error) => {
          ChatController.isSocketConnected = 0;
          console.log("❌ Socket Connection Error", error);
        });
      }
    } else {
      console.log('reConnect......else')
      ChatController.reConnect();
    }

    ChatController.socket?.on('project-notification', async (data) => {
      console.log('data===aya updatee', data);

      App.meetingNotification(data?.notification_data?.title, "meeting-notification");
    })

  }

  static reConnect(): void {
    // console.log("🔁 Attempting reConnect...");
    if (ChatController.socket) {
      // console.log("Socket exists. Connected?", ChatController.socket.connected);
      // console.log("Disconnected?", ChatController.socket.disconnected);
    }

    if (ChatController.socket && (ChatController.socket.disconnected || !ChatController.socket.connected)) {
      console.log("🔄 Reconnecting socket...");
      ChatController.socket.connect();
    }
  }

  static disconnectUser(): void {
    if (ChatController.socket) {
      ChatController.socket.disconnect();
      ChatController.isSocketConnected = -1;
    }
  }

  static callbackSocket(eventName: string, formData: any): void {
    console.log("📡 Emitting Event:", eventName, formData);
    if (ChatController.socket && !ChatController.socket.connected) {
      ChatController.reConnect();
    }
    ChatController.socket?.emit(eventName, formData);
  }

  static getSocket(): Socket | null {
    return ChatController.socket
  }


}

export default ChatController;
