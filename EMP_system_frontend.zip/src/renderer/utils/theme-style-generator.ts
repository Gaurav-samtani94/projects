import type { ThemeEditorState, ThemeStyles } from "../../Types/theme";
import { colorFormatter } from "./color-convert";
import type { ColorFormat } from "../../Types/uni";
import { getShadowMap } from "./shadows";

type ThemeMode = "light" | "dark";

const generateColorVariables = (
    themeStyles: ThemeStyles,
    mode: ThemeMode,
    formatColor: (color: string) => string
): string => {
    const styles = themeStyles[mode];
    return `
  --background: ${formatColor(styles.background as string)};
  --foreground: ${formatColor(styles.foreground as string)};
  --card: ${formatColor(styles.card as string)};
  --card-foreground: ${formatColor(styles["card-foreground"] as string)};
  --popover: ${formatColor(styles.popover as string)};
  --popover-foreground: ${formatColor(styles["popover-foreground"] as string)};
  --primary: ${formatColor(styles.primary as string)};
  --primary-foreground: ${formatColor(styles["primary-foreground"] as string)};
  --secondary: ${formatColor(styles.secondary as string)};
  --secondary-foreground: ${formatColor(styles["secondary-foreground"] as string)};
  --muted: ${formatColor(styles.muted as string)};
  --muted-foreground: ${formatColor(styles["muted-foreground"] as string)};
  --accent: ${formatColor(styles.accent as string)};
  --accent-foreground: ${formatColor(styles["accent-foreground"] as string)};
  --destructive: ${formatColor(styles.destructive as string)};
  --destructive-foreground: ${formatColor(styles["destructive-foreground"] as string)};
  --border: ${formatColor(styles.border as string)};
  --input: ${formatColor(styles.input as string)};
  --ring: ${formatColor(styles.ring as string)};
  --chart-1: ${formatColor(styles["chart-1"] as string)};
  --chart-2: ${formatColor(styles["chart-2"] as string)};
  --chart-3: ${formatColor(styles["chart-3"] as string)};
  --chart-4: ${formatColor(styles["chart-4"] as string)};
  --chart-5: ${formatColor(styles["chart-5"] as string)};
  --sidebar: ${formatColor(styles.sidebar as string)};
  --sidebar-foreground: ${formatColor(styles["sidebar-foreground"] as string)};
  --sidebar-primary: ${formatColor(styles["sidebar-primary"] as string)};
  --sidebar-primary-foreground: ${formatColor(styles["sidebar-primary-foreground"] as string)};
  --sidebar-accent: ${formatColor(styles["sidebar-accent"] as string)};
  --sidebar-accent-foreground: ${formatColor(styles["sidebar-accent-foreground"] as string)};
  --sidebar-border: ${formatColor(styles["sidebar-border"] as string)};
  --sidebar-ring: ${formatColor(styles["sidebar-ring"] as string)};`;
};

const generateFontVariables = (
    themeStyles: ThemeStyles,
    mode: ThemeMode
): string => {
    const styles = themeStyles[mode];
    return `
  --font-sans: ${styles["font-sans"]};
  --font-serif: ${styles["font-serif"]};
  --font-mono: ${styles["font-mono"]};`;
};

const generateShadowVariables = (shadowMap: Record<string, string>): string => {
    return `
  --shadow-2xs: ${shadowMap["shadow-2xs"]};
  --shadow-xs: ${shadowMap["shadow-xs"]};
  --shadow-sm: ${shadowMap["shadow-sm"]};
  --shadow: ${// biome-ignore lint/complexity/useLiteralKeys: <explanation>
        shadowMap["shadow"]};
  --shadow-md: ${shadowMap["shadow-md"]};
  --shadow-lg: ${shadowMap["shadow-lg"]};
  --shadow-xl: ${shadowMap["shadow-xl"]};
  --shadow-2xl: ${shadowMap["shadow-2xl"]};`;
};

const generateThemeVariables = (
    themeStyles: ThemeStyles,
    mode: ThemeMode,
    formatColor: (color: string) => string
): string => {
    return `${mode === "dark" ? ".dark" : ":root"} {${generateColorVariables(
        themeStyles,
        mode,
        formatColor
    )}${generateFontVariables(themeStyles, mode)}
  --radius: ${themeStyles[mode].radius};${generateShadowVariables(
        getShadowMap({ styles: themeStyles, currentMode: mode })
    )}
}\n\n`;
};

const generateTailwindV4ThemeInline = (): string => {
    return `@theme inline {
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --color-card: var(--card);
  --color-card-foreground: var(--card-foreground);
  --color-popover: var(--popover);
  --color-popover-foreground: var(--popover-foreground);
  --color-primary: var(--primary);
  --color-primary-foreground: var(--primary-foreground);
  --color-secondary: var(--secondary);
  --color-secondary-foreground: var(--secondary-foreground);
  --color-muted: var(--muted);
  --color-muted-foreground: var(--muted-foreground);
  --color-accent: var(--accent);
  --color-accent-foreground: var(--accent-foreground);
  --color-destructive: var(--destructive);
  --color-destructive-foreground: var(--destructive-foreground);
  --color-border: var(--border);
  --color-input: var(--input);
  --color-ring: var(--ring);
  --color-chart-1: var(--chart-1);
  --color-chart-2: var(--chart-2);
  --color-chart-3: var(--chart-3);
  --color-chart-4: var(--chart-4);
  --color-chart-5: var(--chart-5);
  --color-sidebar: var(--sidebar);
  --color-sidebar-foreground: var(--sidebar-foreground);
  --color-sidebar-primary: var(--sidebar-primary);
  --color-sidebar-primary-foreground: var(--sidebar-primary-foreground);
  --color-sidebar-accent: var(--sidebar-accent);
  --color-sidebar-accent-foreground: var(--sidebar-accent-foreground);
  --color-sidebar-border: var(--sidebar-border);
  --color-sidebar-ring: var(--sidebar-ring);

  --font-sans: var(--font-sans);
  --font-mono: var(--font-mono);
  --font-serif: var(--font-serif);

  --radius-sm: calc(var(--radius) - 4px);
  --radius-md: calc(var(--radius) - 2px);
  --radius-lg: var(--radius);
  --radius-xl: calc(var(--radius) + 4px);

  --shadow-2xs: var(--shadow-2xs);
  --shadow-xs: var(--shadow-xs);
  --shadow-sm: var(--shadow-sm);
  --shadow: var(--shadow);
  --shadow-md: var(--shadow-md);
  --shadow-lg: var(--shadow-lg);
  --shadow-xl: var(--shadow-xl);
  --shadow-2xl: var(--shadow-2xl);
}`;
};

export const generateThemeCode = (
    themeEditorState: ThemeEditorState,
    colorFormat: ColorFormat = "hsl",
    tailwindVersion: "3" | "4" = "3"
): string => {
    if (
        !themeEditorState ||
        !("light" in themeEditorState.styles) ||
        !("dark" in themeEditorState.styles)
    ) {
        throw new Error("Invalid theme styles: missing light or dark mode");
    }

    const themeStyles = themeEditorState.styles as ThemeStyles;
    const formatColor = (color: string) =>
        colorFormatter(color, colorFormat, tailwindVersion);

    const lightTheme = generateThemeVariables(themeStyles, "light", formatColor);
    const darkTheme = generateThemeVariables(themeStyles, "dark", formatColor);

    if (tailwindVersion === "4") {
        return `${lightTheme}${darkTheme}${generateTailwindV4ThemeInline()}`;
    }

    return `${lightTheme}${darkTheme}`;
};
