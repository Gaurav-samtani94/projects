import { addActivityLog } from "ElectronStore/activityStore";
import { windowStateManager } from "./state-manager";
import { type BrowserWindow, powerMonitor } from "electron";
import moment from "moment-timezone";



const IDLE_THRESHOLD = 30;
let hasStartedMonitoring = false;
let monitoringInterval: NodeJS.Timeout | null = null;

let systemActivityIntervalId: NodeJS.Timeout | null = null;
let appActivityIntervalId: NodeJS.Timeout | null = null;


function startSystemActivity(window: BrowserWindow) {
    console.log('Starting system activity tracking');
    if (systemActivityIntervalId) return;
    systemActivityIntervalId = setInterval(() => {
        const idleTime = powerMonitor.getSystemIdleTime();
        if (idleTime >= IDLE_THRESHOLD) {
            windowStateManager.updateSystemStatus('idle', window);
        } else {
            windowStateManager.updateSystemStatus('online', window);
        }
    }, 10000);
}

const startAppActivity = async (window: BrowserWindow) => {
    console.log('Starting app activity tracking');
    if (appActivityIntervalId) return;

    appActivityIntervalId = setInterval(async () => {
        try {
            const idleTime = powerMonitor.getSystemIdleTime();
            if (idleTime >= IDLE_THRESHOLD) {
                windowStateManager.closeCurrentActivity();
                return;
                // biome-ignore lint/style/noUselessElse: <explanation>
            } else {
                // area for online state
                await windowStateManager.updateState();
                const finishedActivity = windowStateManager.getLastLogged();
                console.log('Updating app activity', finishedActivity);
                if (finishedActivity) {
                    console.log('Logging activity:', finishedActivity);
                    const currentLog = {
                        id: finishedActivity.id,
                        title: finishedActivity.title,
                        owner: finishedActivity.owner,
                        path: finishedActivity.path,
                        start_time: moment(finishedActivity.start_time).tz('Asia/Kolkata').format('HH:mm:ss'),
                        end_time: moment(finishedActivity.end_time).tz('Asia/Kolkata').format('HH:mm:ss'),
                        date: moment(finishedActivity.start_time).tz('Asia/Kolkata').format('DD-MM-YYYY'),
                    }
                    const action = await addActivityLog(currentLog);
                    console.log('Current activity:', currentLog);
                    window.webContents.send('currentActivity', currentLog, action);
                    console.log('Activity logged:');
                }
            }
        } catch (error) {
            console.log('Error logging activity:', error);
        }
    }, 10000);
}

export const startTracking = async (window: BrowserWindow) => {
    startSystemActivity(window);
    startAppActivity(window);
}

export const stopTracking = (window: BrowserWindow) => {
    if (systemActivityIntervalId) {
        clearInterval(systemActivityIntervalId);
        systemActivityIntervalId = null;
        windowStateManager.closeCurrentActivity();
    }
    if (appActivityIntervalId) {
        clearInterval(appActivityIntervalId);
        appActivityIntervalId = null;
        windowStateManager.endCurrentSystemSession(window)
    }
    return 'Activity and System tracking stopped';
}

export const Tracking = () => !!(systemActivityIntervalId && appActivityIntervalId);



export const logActivity = async (mainWindow: BrowserWindow) => {
    try {
        const currentStatus = windowStateManager.getCurrentStatus();
        console.log('Current status:', currentStatus);
        if (currentStatus === 'idle' || currentStatus === 'offline') return;
        await windowStateManager.updateState();
        const finishedActivity = windowStateManager.getLastLogged();
        if (finishedActivity) {
            console.log('Logging activity:', finishedActivity);
            const currentLog = {
                id: finishedActivity.id,
                title: finishedActivity.title,
                owner: finishedActivity.owner,
                path: finishedActivity.path,
                start_time: moment(finishedActivity.start_time).tz('Asia/Kolkata').format('HH:mm A'),
                end_time: moment(finishedActivity.end_time).tz('Asia/Kolkata').format('HH:mm A'),
                date: moment(finishedActivity.start_time).tz('Asia/Kolkata').format('DD-MM-YYYY'),
            }
            const action = await addActivityLog(currentLog);
            console.log('Current activity:', currentLog);
            mainWindow.webContents.send('currentActivity', currentLog, action);
            console.log('Activity logged:');
        }
    } catch (error) {
        console.log('Error logging activity:', error);
    }
};

export function startMonitoringSystemStatus(window: BrowserWindow) {
    if (hasStartedMonitoring) return;
    hasStartedMonitoring = true;
    monitoringInterval = setInterval(() => {
        const idleTime = powerMonitor.getSystemIdleTime();
        if (idleTime >= IDLE_THRESHOLD) {
            windowStateManager.updateSystemStatus('idle', window);
        } else {
            windowStateManager.updateSystemStatus('online', window);
        }
    }, 10000);

    powerMonitor.on('suspend', () => {
        console.log('System is going to sleep');
        windowStateManager.updateSystemStatus('offline', window);
    });

    powerMonitor.on('resume', () => {
        windowStateManager.updateSystemStatus('online', window);
    });
}

export function stopMonitoringSystemStatus() {
    if (monitoringInterval) {
        clearInterval(monitoringInterval);
        monitoringInterval = null;
        hasStartedMonitoring = false;
        console.log('Stopped system monitoring');
    }
}