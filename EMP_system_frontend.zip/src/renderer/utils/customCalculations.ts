// utils/useDurationCalculator.ts
import { useState } from "react";

interface TimeStats {
    total: string;
    online: string;
    idle: string;
    offline: string;
}

export const customCalculations = () => {
    const [timeStats, setTimeStats] = useState<TimeStats>({
        total: "0h 0m",
        online: "0h 0m",
        idle: "0h 0m",
        offline: "0h 0m",
    });

    const [timeStatsInSeconds, setTimeStatsInSeconds] = useState({
        totalTime: 0,
        onlineTime: 0,
        idleTime: 0,
        offlineTime: 0,
    });

    const calculateDurations = (getSystemLog: any) => {
        if (!getSystemLog || getSystemLog.length === 0) {
            setTimeStats({
                total: formatDuration(0),
                online: formatDuration(0),
                idle: formatDuration(0),
                offline: formatDuration(0),
            });
            setTimeStatsInSeconds({
                totalTime: 0,
                onlineTime: 0,
                idleTime: 0,
                offlineTime: 0,
            });
            return;
        }

        const intervals: { start: number; end: number; status: string }[] = [];
        let minStart = Infinity;
        let maxEnd = 0;

        getSystemLog.forEach((entry: any) => {
            const start = parseDateTime(entry?.date, entry.start_time);
            const end = parseDateTime(entry?.date, entry.end_time);
            if (start < minStart) minStart = start;
            if (end > maxEnd) maxEnd = end;
            intervals.push({ start, end, status: entry.status });
        });

        intervals.sort((a, b) => a.start - b.start);

        let onlineMs = 0;
        let idleMs = 0;

        intervals.forEach(({ start, end, status }) => {
            const duration = end - start;
            if (status === "online") {
                onlineMs += duration;
            } else if (status === "idle") {
                idleMs += duration;
            }
        });

        const totalMs = maxEnd - minStart;
        const offlineMs = Math.max(0, totalMs - (onlineMs + idleMs));

        setTimeStats({
            total: formatDuration(totalMs),
            online: formatDuration(onlineMs),
            idle: formatDuration(idleMs),
            offline: formatDuration(offlineMs),
        });

        setTimeStatsInSeconds({
            totalTime: Math.floor(totalMs / 1000),
            onlineTime: Math.floor(onlineMs / 1000),
            idleTime: Math.floor(idleMs / 1000),
            offlineTime: Math.floor(offlineMs / 1000),
        });
    };

    return { timeStats, timeStatsInSeconds, calculateDurations };
};

const parseDateTime = (dateStr: string, timeStr: string) => {
    const cleanedTime = timeStr?.replace(/(AM|PM)/gi, "").trim();
    const [day, month, year] = dateStr?.split("-");
    return new Date(`${year}-${month}-${day} ${cleanedTime}`).getTime();
};

const formatDuration = (ms: number) => {
    const totalMinutes = Math.floor(ms / 60000);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}h ${minutes}m`;
};
