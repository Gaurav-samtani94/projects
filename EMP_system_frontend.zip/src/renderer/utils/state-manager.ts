import { updateSystemStatusArray } from 'ElectronStore/activityStore';
import { activeWindow } from 'get-windows';
import type { BrowserWindow } from 'electron';
import moment from 'moment';

type Activity = {
    id: number;
    title: string;
    owner: string;
    path: string;
    start_time: string;
    end_time: string | null;
};

type SystemStatus = 'online' | 'idle' | 'offline';

type SystemLog = {
    id: number;
    status: SystemStatus;
    start_time: string;
    end_time: string | null;
    date: string;
};

function statemanager() {
    const state: {
        current: Activity | null;
        previous: Activity | null;
        lastLogged: Activity | null;
        currentSystemLog: {
            id: number;
            status: SystemStatus;
            start_time: string;
            end_time: string | null;
            date: string;
        } | null;
    } = {
        current: null,
        previous: null,
        lastLogged: null,
        currentSystemLog: null,
    };

    const currentStatus: SystemStatus | null = null;

    function closeCurrentActivity() {
        if (state.current && !state.current.end_time) {
            state.current.end_time = new Date().toISOString();
            state.lastLogged = { ...state.current };
        }
    }


    async function endCurrentSystemSession(window: BrowserWindow) {
        if (!lastStatusObj || lastStatusObj.end_time) return;

        const endTime = moment().tz('Asia/Kolkata').format('HH:mm:ss A');
        const endedSession = { ...lastStatusObj, end_time: endTime };

        const updatedData = await updateSystemStatusArray(endedSession);
        window.webContents.send('systemStatus', updatedData);
        lastStatusObj = null;
    }


    async function updateState() {
        try {
            const activity = await activeWindow();
            if (
                activity &&
                state.current &&
                activity.title === state.current.title
            ) {
                return;
            }

            closeCurrentActivity();
            state.previous = state.current;

            if (activity) {
                state.current = {
                    id: activity.id,
                    title: activity.title,
                    owner: activity.owner.name,
                    path: activity.owner.path,
                    start_time: new Date().toISOString(),
                    end_time: null,
                };
            } else {
                state.current = {
                    id: 0,
                    title: 'Active Window Undefined',
                    owner: 'PERMISSION_ERROR',
                    path: '',
                    start_time: new Date().toISOString(),
                    end_time: null,
                };
            }
        } catch (error) {
            console.error('Error fetching active window:', error);
        }
    }

    function getState(): Activity | null {
        return state.current;
    }

    function getPreviousState(): Activity | null {
        return state.previous;
    }

    function getLastLogged(): Activity | null {
        const temp = state.lastLogged;
        state.lastLogged = null;
        return temp;
    }

    let lastStatusObj: SystemLog | null = null

    async function updateSystemStatus(newStatus: SystemStatus, window: BrowserWindow) {
        if (lastStatusObj && lastStatusObj.status === newStatus) return;

        if (lastStatusObj) {
            const oldObj = { ...lastStatusObj };
            oldObj.end_time = moment().tz('Asia/Kolkata').format('HH:mm:ss A');
            const newData = await updateSystemStatusArray(oldObj as SystemLog);
            window.webContents.send('systemStatus', newData)
            lastStatusObj.status = newStatus;
            lastStatusObj.start_time = moment().tz('Asia/Kolkata').format('HH:mm:ss A');
            lastStatusObj.end_time = null;
        }

        lastStatusObj = {
            id: Date.now(),
            status: newStatus,
            start_time: moment().tz('Asia/Kolkata').format('HH:mm:ss A'),
            end_time: null,
            date: moment().tz('Asia/Kolkata').format('DD-MM-YYYY'),
        };


        // lastStatusObj = {
        //     id: Date.now(),
        //     status: newStatus,
        //     start_time: moment().tz('Asia/Kolkata').format('HH:mm:ss'),
        //     end_time: null,
        //     date: moment().tz('Asia/Kolkata').format('DD-MM-YYYY'),
        // };


        // if (newStatus === currentStatus) return;

        // const now = moment().tz('Asia/Kolkata').format('HH:mm:ss')
        // if (state.currentSystemLog) {
        //     state.currentSystemLog.end_time = now;
        //     console.log('Updating system log:', state.currentSystemLog);
        //     await addSystemLog(state.currentSystemLog)
        //     state.currentSystemLog = null;
        // }

        // if (newStatus === 'idle' || newStatus === 'offline') {
        //     closeCurrentActivity();
        //     const last = getLastLogged();
        //     if (last) {
        //         await addActivityLog(last);
        //     }
        // }

        // const logs = await getSystemLog();
        // const existingLog = logs.find(log => log.status === newStatus && log.end_time === null);

        // if (existingLog) {
        //     existingLog.end_time = now;
        //     const action = await addSystemLog(existingLog);
        //     window.webContents.send('systemStatus', existingLog, action);
        //     console.log('System status updated:', existingLog);
        // } else {
        //     const nextId = Date.now();
        //     state.currentSystemLog = {
        //         id: nextId,
        //         status: newStatus,
        //         start_time: moment().tz('Asia/Kolkata').format('HH:mm:ss A'),
        //         end_time: null,
        //         date: moment().tz('Asia/Kolkata').format('DD-MM-YYYY'),
        //     };
        //     const action = await addSystemLog(state.currentSystemLog);
        // }

        // currentStatus = newStatus;
        // console.log(`[System Status]: ${newStatus}`);
    }




    function getCurrentStatus(): SystemStatus | null {
        return currentStatus;
    }

    return {
        updateState,
        getState,
        getPreviousState,
        getLastLogged,
        updateSystemStatus,
        getCurrentStatus,
        closeCurrentActivity,
        endCurrentSystemSession
    };
}

export const windowStateManager = statemanager();
