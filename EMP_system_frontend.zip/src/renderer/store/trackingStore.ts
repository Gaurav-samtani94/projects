import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface TrackingStore {
    isTracking: boolean;
    setTracking: (value: boolean) => void;
    clearTracking: () => void;
}

export const trackingStore = create<TrackingStore>()(
    persist(
        (set) => ({
            isTracking: false,
            setTracking: (value) => set({ isTracking: value }),
            clearTracking: () => set({ isTracking: false }),
        }),
        {
            name: 'tracking-store',
        }
    )
);
