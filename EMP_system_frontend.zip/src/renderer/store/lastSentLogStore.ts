import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface SystemLog {
  id: number;
  status: string;
  start_time: string;
  end_time: string;
  date: string;
}

interface ActivityLog {
  id: number;
  title: string;
  owner: string;
  path: string;
  start_time: string;
  end_time: string;
  date: string;
}

interface lastSentLogStore {
  lastSentSystemLog: SystemLog | null;
  lastSentActivityLog: ActivityLog | null;
  setLastSentSystemLog: (log: SystemLog) => void;
  setLastSentActivityLog: (log: ActivityLog) => void;
  clearLastLogs: () => void;
}

export const lastSentLogStore = create<lastSentLogStore>()(
  persist(
    (set) => ({
      lastSentSystemLog: null,
      lastSentActivityLog: null,
      setLastSentSystemLog: (log) => set({ lastSentSystemLog: log }),
      setLastSentActivityLog: (log) => set({ lastSentActivityLog: log }),
      clearLastLogs: () =>
        set({
          lastSentSystemLog: null,
          lastSentActivityLog: null
        }),
    }),
    {
      name: 'last-sent-log-store',
    }
  )
);
