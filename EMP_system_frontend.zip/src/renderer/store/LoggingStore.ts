import { create } from 'zustand';

interface ActivityLog {
    id: number;
    title: string;
    owner: string;
    path: string;
    start_time: string;
    end_time: string;
    date: string;
}

interface SystemStatus {
    entries: any[];
    id: number;
    status: string;
    start_time: string;
    end_time: string;
}

interface SystemStatusStore {
    systemStatus: SystemStatus[];
    setSystemStatus: (status: SystemStatus) => void;
    replaceSystemLog: (log: any) => void;
    clearSystemStatus: () => void;
}


interface ActivityLogStore {
    activityLog: ActivityLog[];
    addActivityLog: (log: ActivityLog) => void;
    replaceActivityLog: (log: ActivityLog) => void;
    clearActivityLogs: () => void;
}

export const useSystemStatusStore = create<SystemStatusStore>((set) => ({
    systemStatus: [],
    setSystemStatus: (log) =>
        set((state) => ({ systemStatus: [...state.systemStatus, log] })),
    replaceSystemLog: (log: any) =>
        set(() => ({ systemStatus: Array.isArray(log) ? log : [log] })),
    clearSystemStatus: () => set({ systemStatus: [] }),
}));

export const useActivityLogStore = create<ActivityLogStore>((set) => ({
    activityLog: [],
    addActivityLog: (log) =>
        set((state) => ({ activityLog: [...state.activityLog, log] })),
    replaceActivityLog: (log: any) =>
        set(() => ({ activityLog: Array.isArray(log) ? log : [log] })),
    clearActivityLogs: () => set({ activityLog: [] }),
}));