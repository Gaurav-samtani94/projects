import ChatController from "renderer/Controller/ChatController";
import { create } from "zustand";
import { devtools, persist } from "zustand/middleware";

// Define the User type (adjust based on your actual user model)
interface User {
    id: string;
    firstname: string;
    user_id: string;
    lastname: string;
    reporting_manager_name: string;
    email: string;
    phone: string;
    date_of_joining: string;
    userfullname: string;
    [key: string]: any; // Allows additional dynamic properties
}

// Define the AuthStore state and actions
interface AuthState {
    user: User | null;
    token: string | null;
    isAuthenticated: boolean;
    login: (user: User, token: string) => void;
    logout: () => void;
    updateProfile: (updatedUser: Partial<User>) => void;
    setUser: (user: User) => void;
    setToken: (token: string) => void;
    getUser: () => User | null;
    getToken: () => string | null;
}

// Zustand store with TypeScript support
const useAuthStore = create<AuthState>()(
    persist(
        devtools((set, get) => ({
            user: null,
            token: null,
            isAuthenticated: false,

            // Login method
            login: (user, token) =>
                set({ user, token, isAuthenticated: true }),

            // Logout method
            // In your useAuthStore
            logout: () => {
                ChatController.disconnectUser();
                set({ user: null, token: null, isAuthenticated: false });
            },

            // Update user profile method
            updateProfile: (updatedUser) =>
                set((state) => ({
                    user: state.user ? { ...state.user, ...updatedUser } : null,
                })),

            // Setter methods
            setUser: (user) => set({ user }),
            setToken: (token) => set({ token }),

            // Getter methods
            getUser: () => get().user,
            getToken: () => get().token,
            getAuthState: () => get().isAuthenticated,
        })),
        {
            name: "auth-store",
            partialize: (state) => ({
                user: state.user,
                token: state.token,
                isAuthenticated: state.isAuthenticated,
            }), // Persist only login-related state
        }
    )
);

export default useAuthStore;
