import { Route } from 'react-router-dom'
import { Router } from 'lib/electron-router-dom'
import { MainScreen } from './screens/main'
import LoginScreen from './screens/login'
import NotificationScreen from './screens/notification/Page'
import RootLayout from './layout/RootLayout'
import HrmsDetail from './screens/hrms/hrmsDetail'
// import Home from './screens/connect/Home'
// import ChatList from './screens/connect/ChatList'
// import ChatScreen from './screens/connect/ChatScreen'
// import JoinRoom from './screens/connect/JoinRoom'
import RoomMeeting from './screens/connect/RoomMeeting'
import ProfileLayout from './layout/ProfileLayout'
import { ProfileForm } from './screens/profile/profileForm'
import ChangePasswordForm from './screens/profile/ChangePasswordForm'
import TeamView from './screens/profile/TeamView'
import SettingLayout from './layout/SettingLayout'
import ChatLayout from './layout/ChatLayout'
import ChatBoard from './components/sections/ChatBoard'
import ProjectManagement from './screens/project/ProjectManagement'
import ProjectLayout from './layout/ProjectLayout'
import MainEditor from './screens/MainEditor'
import Calendar from './components/sections/Calendar/Calendar'
import GeneralPage from './screens/settings/GeneralPage'
import ChatSetting from './screens/settings/ChatSetting'
import Schedule from './screens/schedule/Schedule'
import MeetingSchedule from './screens/schedule/MeetingSchedule'
import ChatBoardGroup from './components/sections/ChatBoardGroup'
import ProjectMg from './screens/projectMg/ProjectMg'
// import ProjectDetailMg from './screens/projectMg/ProjectDetailMg'
import ProjectOne from './screens/projectMg/ProjectOne'
import ProjectLayoutNew from './layout/project/ProjectLayout'
import AudioMeeting from './screens/connect/AudioMeeting'
import AudioGroupMeeting from './screens/connect/AudioGroupMeeting'
import RoomGroupMeeting from './screens/connect/RoomGroupMeeting'
import CustomMeetingRoom from './screens/connect/customMeetingRoom'
export function AppRoutes() {
  return (
    <Router
      main={
        <Route path="/" element={<RootLayout />}>
          <Route index element={<MainScreen />} />
          <Route path="/login" element={<LoginScreen />} />
          <Route path="/editor" element={<MainEditor />} />
          <Route path="/calendar" element={<Calendar />} />
          <Route path='/notification' element={<NotificationScreen />} />
          <Route path='/projects' element={<ProjectLayout />}>
            <Route index element={<ProjectManagement />} />
          </Route>
          <Route path='/project' element={<ProjectLayoutNew />}>
            <Route index element={<div>
            </div>} />
            <Route path='/project/:id' element={<ProjectOne />} />
            <Route path='/project/create-new-project' element={<ProjectMg />} />
          </Route>
          <Route path='/scheduled' >
            <Route index element={<Schedule />} />
            <Route path='/scheduled/meetings' element={<MeetingSchedule />} />
          </Route>
          <Route path="/hrms" element={<HrmsDetail />} />
          <Route path="/profile" element={<ProfileLayout />} >
            <Route index path='/profile/general' element={<ProfileForm />} />
            <Route path='/profile/settings' element={<SettingLayout />} >
              <Route path='/profile/settings/notification'>
                <Route index element={<GeneralPage />} />
                <Route path='/profile/settings/notification/chat' element={<ChatSetting />} />
                <Route path='/profile/settings/notification/persons' element={<GeneralPage />} />
                <Route path='/profile/settings/notification/human-resources' element={<GeneralPage />} />
                <Route path='/profile/settings/notification/documents' element={<GeneralPage />} />
                <Route path='/profile/settings/notification/requests' element={<GeneralPage />} />
              </Route>
            </Route>
            <Route path='/profile/changePassword' element={<ChangePasswordForm />} />
            <Route path='/profile/team' element={<TeamView />} />
          </Route>

          <Route path="/chat" element={<ChatLayout />} >
            <Route index element={<ChatBoard />} />
            <Route path='/chat/group' element={<ChatBoardGroup />} />
          </Route>
          <Route path="*" element={<div>404 </div>} />
          {/* <Route */}
          <Route path="/connect">
            <Route path="RoomMeeting" element={<RoomMeeting />} />
            <Route path="AudioMeeting" element={<AudioMeeting />} />
            <Route path="AudioGroupMeeting" element={<AudioGroupMeeting />} />
            <Route path="RoomGroupMeeting" element={<RoomGroupMeeting />} />
            <Route path="/connect/custom-meeting-room" element={<CustomMeetingRoom />} />

          </Route>
        </Route>
      }
    />
  )
}
