const useAny = () => {
  return <div>useAny</div>
}

export default useAny
