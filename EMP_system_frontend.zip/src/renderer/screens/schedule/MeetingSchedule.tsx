import React, { useEffect, useState } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from 'renderer/components/ui/avatar'
import { Button } from 'renderer/components/ui/button'
import { Input } from 'renderer/components/ui/input'
import { Label } from 'renderer/components/ui/label'
import { RadioGroup, RadioGroupItem } from 'renderer/components/ui/radio-group'
import RichText from 'renderer/components/ui/RichText'
import { Check, Download, Eye, EyeOff, Loader2, Plus, Trash2 } from 'lucide-react'
import {
    Dialog,
    DialogTrigger,
    DialogContent,
    DialogHeader,
    DialogFooter,
    DialogDescription,
} from "renderer/components/ui/dialog";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "renderer/components/ui/command";
import { useMutation } from '@tanstack/react-query'
import { addMeetingAttachment, deleteMeetingAttachments, fetchMeetingAttachments, fetchMeetingDetails, joinMeeting, updateMeeting } from 'renderer/service/MeetingRoomService'
import { toast } from 'sonner'
import { useLocation, useNavigate } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from 'renderer/components/ui/form'
import DateTimePicker from 'renderer/components/ui/date-time-picker'
import dayjs from 'dayjs'
import { GetUser } from 'renderer/service/authService'
import useAuthStore from 'renderer/store/AuthStore'
import { DialogTitle } from '@radix-ui/react-dialog'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { type ColumnDef, flexRender, getCoreRowModel, useReactTable } from '@tanstack/react-table'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from 'renderer/components/ui/table'
import {
    FileText,
    Image as ImageIcon,
    FileArchive,
    FileSpreadsheet,
    FileCode,
    FileAudio,
    FileVideo,
    File as GenericFileIcon,
} from "lucide-react";
import BaseUrl from 'renderer/service/BaseUrl'
import ChatController from 'renderer/Controller/ChatController'

interface meetingData {
    meeting_name: string;
    team_member: any;
    start_time: Date | null;
    end_time: Date | null;
    description: string;
    is_public: any;
    password: any;
    created_by: any;
}
const { App } = window



const MeetingSchedule = () => {
    const [saveMeetingDetails, setSaveMeetingDetails] = useState<any>({})
    const [showPassword, setShowPassword] = useState<boolean>(false)
    const [users, setUsers] = React.useState<any[]>([])
    const current_User = useAuthStore.getState().getUser();
    const [selectedUsers, setSelectedUsers] = React.useState<any>([])
    const [updateApiStatus, setUpdateApiStatus] = useState('');
    const [isUserPopUp, setIsUserPopUp] = useState(false)
    const [attachmentList, setAttachmentList] = useState<any[]>([]);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState({
        status: false,
        id: ''
    });

    const location = useLocation()
    const navigate = useNavigate()
    const id = location.state?.id;

    const getFileIcon = (ext: string) => {
        switch (ext) {
            case ".png":
            case ".jpg":
            case ".jpeg":
            case ".gif":
            case ".webp":
                return <ImageIcon className="w-5 h-5 text-blue-500" />;
            case ".pdf":
            // return <FilePdf className="w-5 h-5 text-red-500" />;
            case ".zip":
            case ".rar":
                return <FileArchive className="w-5 h-5 text-yellow-500" />;
            case ".csv":
            case ".xls":
            case ".xlsx":
                return <FileSpreadsheet className="w-5 h-5 text-green-600" />;
            case ".mp3":
            case ".wav":
                return <FileAudio className="w-5 h-5 text-purple-500" />;
            case ".mp4":
            case ".mov":
            case ".avi":
                return <FileVideo className="w-5 h-5 text-purple-700" />;
            case ".js":
            case ".ts":
            case ".json":
            case ".html":
            case ".css":
                return <FileCode className="w-5 h-5 text-indigo-500" />;
            case ".txt":
                return <FileText className="w-5 h-5 text-gray-600" />;
            default:
                return <GenericFileIcon className="w-5 h-5 text-gray-400" />;
        }
    };

    // Attachment Table Columns
    const columns: ColumnDef<any>[] = [
        {
            header: "File",
            accessorKey: "file_name",
            cell: ({ row }) => {
                const file = row.original;
                const ext = file.file_type?.toLowerCase();
                return (
                    <div className="flex items-center gap-2">
                        <div className="w-10 h-10 bg-gray-100 flex items-center justify-center rounded">
                            {getFileIcon(ext)}
                        </div>
                        <span className="truncate max-w-[180px]">{file.file_name}</span>
                    </div>
                );
            },
        },
        {
            header: "Uploaded By",
            accessorKey: "uploaded_by.userfullname",
        },
        {
            header: "Actions",
            id: "actions",
            cell: ({ row }) => {
                const file = row.original;


                const handleImageDownload = async () => {
                    const fileUrl = `${BaseUrl.Url_Base}/${file?.file_path}`;

                    try {
                        // Fetch image as a blob
                        // const response = await fetch(fileUrl, {
                        //     method: 'GET',
                        //     mode: 'no-cors'
                        // });

                        // if (!response.ok) {
                        //     throw new Error("Failed to fetch the image");
                        // }

                        // Convert the response into a Blob
                        // const blob = await response.blob();
                        // const url = window.URL.createObjectURL(blob);

                        // Create an anchor element and simulate a click to trigger the download
                        const a = document.createElement("a");
                        a.href = fileUrl;
                        a.target = "_blank"; // Open in a new tab
                        a.download = file?.file_name || "download"; // Provide a default name if not available
                        document.body.appendChild(a);
                        a.click(); // Trigger the download
                        a.remove(); // Clean up the DOM
                        // window.URL.revokeObjectURL(url); // Revoke the object URL
                    } catch (error) {
                        console.error("Download failed:", error);
                    }
                };

                const handleDownload = () => {
                    const url = `${BaseUrl.Url_Base}/${file?.file_path}`;

                    try {
                        const filename = url?.split('/').pop();
                        if (!filename) {
                            console.error("Filename could not be determined from URL.");
                            return;
                        }

                        App.downloadFile(url, filename);
                        App.onDownloadComplete((_event, data) => {
                            if (data.success) {
                                toast.success("File downloaded!");
                            } else {
                                toast.error("Download failed.");
                                console.error("❌ Download failed:", data.error);
                            }
                        });

                    } catch (error) {
                        console.error("Error during download:", error);
                    }
                };

                return (
                    <div className="flex gap-2">
                        <button type='button' onClick={handleImageDownload}>
                            <Eye className="w-4 h-4 text-purple-600 hover:text-purple-800" />
                        </button>
                        <button type='button' onClick={handleDownload}>
                            <Download className="w-4 h-4 text-blue-600 hover:text-blue-800" />
                        </button>
                        <button type='button'
                            onClick={() => setIsDeleteDialogOpen({
                                status: true,
                                id: file?.attachment_id
                            })}
                        >
                            <Trash2 className="w-4 h-4 text-red-600 hover:text-red-800" />
                        </button>
                    </div>
                );
            },
        },
    ];

    // Meeting Detail Schema
    const meetingScheduleSchema = z.object({
        meeting_name: z.string().optional(),  // no validation but included
        team_member: z.array(z.any()).optional(),
        start_time: z.any().optional(),
        end_time: z.any().optional(),
        description: z.string().optional(),
        is_public: z.string(),
        password: z.string().nullable().optional(),
    }).superRefine((data, ctx) => {
        if (data.is_public === '2') {
            const password = data.password ?? ''; // coerce null/undefined to empty string

            if (password.length < 8) {
                ctx.addIssue({
                    path: ['password'],
                    code: z.ZodIssueCode.too_small,
                    type: 'string',
                    minimum: 8,
                    inclusive: true,
                    message: 'Password must be at least 8 characters',
                });
            }

            if (!/[A-Z]/.test(password)) {
                ctx.addIssue({
                    path: ['password'],
                    code: z.ZodIssueCode.custom,
                    message: 'Password must contain at least one uppercase letter',
                });
            }

            if (!/[a-z]/.test(password)) {
                ctx.addIssue({
                    path: ['password'],
                    code: z.ZodIssueCode.custom,
                    message: 'Password must contain at least one lowercase letter',
                });
            }

            if (!/[0-9]/.test(password)) {
                ctx.addIssue({
                    path: ['password'],
                    code: z.ZodIssueCode.custom,
                    message: 'Password must contain at least one number',
                });
            }

            if (!/[^A-Za-z0-9]/.test(password)) {
                ctx.addIssue({
                    path: ['password'],
                    code: z.ZodIssueCode.custom,
                    message: 'Password must contain at least one special character',
                });
            }
        }
    });


    // Form validation schema
    const form = useForm<any>({
        resolver: zodResolver(meetingScheduleSchema),
        defaultValues: {
            meeting_name: "",
            team_member: [],
            start_time: null,
            end_time: null,
            description: '',
            is_public: '1',
            password: ''
        },
        mode: "onChange",
    })

    // Fetch User List
    const getUserMutation = useMutation({
        mutationFn: GetUser,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const filteredUsers = response.data.filter((user: any) => user.id !== current_User?.id);
                setUsers(filteredUsers);
            }
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })


    // Join Meeting
    const joinMeetingMutation = useMutation({
        mutationFn: joinMeeting,
        onSuccess: (data) => {
            toast.success(data?.message)
            const Meeting = {
                Title: `${saveMeetingDetails?.meeting_name} meeting has Started.`,
                Description: saveMeetingDetails?.description,
                userIds: selectedUsers,
                create_by: current_User?.id,
            };
            ChatController.callbackSocket('MeetingEvent', Meeting);
            navigate('/connect/custom-meeting-room', {
                state: { token: data?.data?.livekit_token }
            })
        },
        onError: (error) => {
            toast.error('Failed to join meeting')
        },
    })

    const handleMemberJoin = (meetingUrl: string) => {
        joinMeetingMutation.mutate(meetingUrl)
    }

    // Fetch Meeting Detail
    const meetingDetailMutation = useMutation({
        mutationFn: fetchMeetingDetails,
        onSuccess: (data) => {
            console.log('Meeting Details:', data)
            if (data?.status === true) {
                setSaveMeetingDetails(data?.data[0])
                const meetingData = data?.data[0];
                let allId = []
                if (meetingData?.participants?.length > 0) {
                    allId = meetingData?.participants?.map((item: any) => item?.tbl_User?.id)
                    setSelectedUsers(allId)
                } else {
                    setSelectedUsers([])
                }

                form.setValue('meeting_name', meetingData?.meeting_name);
                form.setValue('team_member', allId);
                form.setValue('start_time', meetingData?.start_time ? new Date(meetingData?.start_time) : null);
                form.setValue('end_time', meetingData?.end_time ? new Date(meetingData?.end_time) : null);
                form.setValue('description', meetingData?.description);
                form.setValue('is_public', String(meetingData?.is_public));
                form.setValue('password', meetingData?.password);
                // form.setValue('created_by', users?.find((item: any) => item?.id === meetingData?.created_by)?.userfullname)


            } else {
                setSaveMeetingDetails({})
            }

        },
        onError: error => {
            setSaveMeetingDetails({})
            // toast.error('Failed to create meeting')
        },
    })

    useEffect(() => {
        const allUsers = [...users, current_User]
        if (allUsers?.length > 0 && saveMeetingDetails?.created_by) {
            const createdByUser = allUsers.find((item: any) => item?.id === saveMeetingDetails?.created_by);
            if (createdByUser) {
                form.setValue('created_by', createdByUser?.userfullname);
            }
        }
    }, [users, saveMeetingDetails])


    // Update Meeting
    const updateMeetingMutation = useMutation({
        mutationFn: async ({ type, allData }: any) => {
            return await updateMeeting(allData)
        },

        onSuccess: (data, newParam) => {
            const meeting = data?.data
            setUpdateApiStatus(newParam?.type)
            toast.success(newParam?.type === 'add user' ? 'User updated successfully' : 'Meeting updated successfully')
            const Meeting = {
                Title: `${meeting?.meeting_name} meeting has been updated.`,
                Description: meeting?.description,
                userIds: selectedUsers,
                create_by: current_User?.id,
            };
            ChatController.callbackSocket('MeetingEvent', Meeting);
            newParam?.type === 'add user' && setIsUserPopUp(false)
            meetingDetailMutation.mutate(id)
        },
        onError: error => {
            toast.error('Failed to update meeting')
        },
    })

    const onSubmit = (data: meetingData) => {
        const allData: any = {
            meeting_id: id,
            meeting_name: data?.meeting_name,
            description: data?.description,
            start_time: data?.start_time ? dayjs(data.start_time).format('YYYY-MM-DD HH:mm:ss') : null,
            end_time: data?.end_time ? dayjs(data.end_time).format('YYYY-MM-DD HH:mm:ss') : null,
            team_member: saveMeetingDetails?.participants?.map((item: any) => item?.user_id) || [],
            is_public: Number(data?.is_public),
            password: data?.password,
        }

        updateMeetingMutation.mutate({ allData, type: 'meeting update' })
    }

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword)
    }

    function timeDiffInWords(updatedAt: any) {
        const currentTime: any = new Date(); // Current time
        const updatedTime: any = new Date(updatedAt); // Convert updatedAt to Date object

        const diffInSeconds = Math.floor((currentTime - updatedTime) / 1000); // Get the difference in seconds

        if (diffInSeconds < 60) {
            return `Edited at ${diffInSeconds}second${diffInSeconds !== 1 ? 's' : ''}ago`
        } if (diffInSeconds < 3600) {
            const minutes = Math.floor(diffInSeconds / 60);
            return `Edited at ${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
        } if (diffInSeconds < 86400) {
            const hours = Math.floor(diffInSeconds / 3600);
            return `Edited at ${hours} hour${hours !== 1 ? 's' : ''} ago`;
        }
        const days = Math.floor(diffInSeconds / 86400);
        return `${days} day${days !== 1 ? 's' : ''} ago`;

    }

    // Fetch Attachment List
    const meetingFileMutation = useMutation({
        mutationFn: fetchMeetingAttachments,
        onSuccess: (data) => {
            if (data?.status === '1') {
                setAttachmentList(data?.data)
            } else {
                setAttachmentList(data?.data)

            }
        },
        onError: error => {
            setAttachmentList([])

        },
    })

    const getUserMeetingDetail = async () => {
        meetingDetailMutation.mutate(id)
    }

    const geAttachmentDetails = async () => {
        meetingFileMutation.mutate(id)
    }

    useEffect(() => {
        getUserMutation.mutate()
        getUserMeetingDetail()
        geAttachmentDetails()
    }, [])

    // Upload Attachments
    const fileUploadMutation = useMutation({
        mutationFn: addMeetingAttachment,
        onSuccess: (data) => {
            meetingFileMutation.mutate(id)
            toast.success("Files uploaded successfully");
        },
        onError: (error) => {
            toast.error("File upload failed", {
                description: error.message,
            });
        },
    });

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const filesArray = Array.from(e.target.files);
            // setSelectedFiles(filesArray); // Optional: for preview or future use

            const allMeetings = {
                meeting_id: id,
                files: filesArray
            }

            // Trigger the upload API immediately
            fileUploadMutation.mutate(allMeetings);
        }
    };

    // Delete Attachments 
    const deleteFileMutation = useMutation({
        mutationFn: deleteMeetingAttachments,
        onSuccess: (data) => {
            meetingFileMutation.mutate(id)
            handleCloseDialog()
        },
        onError: error => {
        },
    })

    // Show Table
    const table = useReactTable({
        data: attachmentList,
        columns,
        getCoreRowModel: getCoreRowModel(),

    })

    // Call Meeting Update When User Add
    const handleUpdateUsers = () => {
        const allData: any = {
            meeting_id: saveMeetingDetails?.id,
            meeting_name: saveMeetingDetails?.meeting_name,
            description: saveMeetingDetails?.description,
            start_time: saveMeetingDetails.start_time ? dayjs(saveMeetingDetails.start_time).format('YYYY-MM-DD HH:mm:ss') : null,
            end_time: saveMeetingDetails.end_time ? dayjs(saveMeetingDetails.end_time).format('YYYY-MM-DD HH:mm:ss') : null,
            team_member: selectedUsers,
            is_public: Number(saveMeetingDetails?.is_public),
            password: saveMeetingDetails?.password,
        }
        updateMeetingMutation.mutate({ allData, type: 'add user' })
    }

    // Close Delete Dialog Box
    const handleCloseDialog = () => {
        setIsDeleteDialogOpen({
            status: false,
            id: ''
        })
    }
    useEffect(() => {
        // Only set value if data is available and hasn't been set already
        if (meetingDetailMutation.isSuccess && saveMeetingDetails?.description !== undefined) {
            form.setValue('description', saveMeetingDetails?.description);
        }
    }, [meetingDetailMutation.isSuccess, saveMeetingDetails?.description]);


    const generateLink = () => {
        const params = new URLSearchParams({
            meetingName: saveMeetingDetails?.meeting_name,
            meetingId: saveMeetingDetails?.meeting_url,
            isPrivate: String(saveMeetingDetails?.is_public),
        });

        // biome-ignore lint/style/useTemplate: <explanation>
        const link = BaseUrl.WEB_URL + `/public/joinMeeting?${params.toString()}`;
        navigator.clipboard.writeText(link).then(() => {
            toast.success("Meeting link copied to clipboard");
        });
    };

    return (
        <>
            <div className='flex gap-9 p-5 mt-2'>

                <Form {...form}>
                    <form className='w-[100%] flex' onSubmit={form.handleSubmit(onSubmit)}>
                        <div className='w-[70%] pr-5 border-r-2'>
                            <div className='flex justify-between items-end'>
                                <div className='grid gap-2'>
                                    <h2 className='mb-0 text-2xl'>{saveMeetingDetails?.meeting_name}</h2>

                                    {
                                        saveMeetingDetails?.participants?.length > 0 && (
                                            <div className="grid grid-cols-5 gap-2.5">
                                                {saveMeetingDetails?.participants?.slice(0, 3)?.map((member: any, memberIndex: number) => (
                                                    <Avatar key={memberIndex} className="rounded-sm aspect-square size-9">
                                                        {/* <AvatarImage src={member.avatar} /> */}
                                                        <AvatarFallback className='rounded-sm'>{member?.tbl_User?.userfullname[0]}</AvatarFallback>
                                                    </Avatar>
                                                ))}

                                                {saveMeetingDetails?.participants?.length > 3 && (
                                                    <Dialog>
                                                        <DialogTrigger asChild>
                                                            <Avatar
                                                                className="aspect-square w-full h-full rounded-sm cursor-pointer bg-muted text-xs flex items-center justify-center relative"
                                                                title="See more members"
                                                            >
                                                                {/* <AvatarImage src="https://github.com/shadcn.png" /> */}
                                                                <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white font-semibold rounded-sm">
                                                                    +{saveMeetingDetails?.participants?.length - 3}
                                                                </div>
                                                            </Avatar>
                                                        </DialogTrigger>
                                                        <DialogContent className="p-0">
                                                            <DialogHeader className='p-4 pb-0'>
                                                                <DialogTitle>All Members</DialogTitle>
                                                            </DialogHeader>
                                                            <Command className='bg-transparent'>
                                                                <CommandInput placeholder="Type a command or search..." />
                                                                <CommandList>
                                                                    <CommandEmpty>No results found.</CommandEmpty>
                                                                    <CommandGroup heading="Team Members">
                                                                        {saveMeetingDetails?.participants?.map((member: any, index: any) => (
                                                                            <CommandItem key={index} className="gap-3 py-2">
                                                                                <Avatar className="w-8 h-8">
                                                                                    {/* <AvatarImage src={member.avatar} /> */}
                                                                                    <AvatarFallback>{member?.tbl_User?.userfullname[0]}</AvatarFallback>
                                                                                </Avatar>
                                                                                <div className="flex flex-col">
                                                                                    <span className="text-sm font-medium">{member?.tbl_User?.userfullname}</span>
                                                                                    {/* <span className="text-xs text-muted-foreground">{member.designation}</span>                                                                                                 <span className="text-xs text-muted-foreground">{member.designation}</span> */}
                                                                                </div>
                                                                            </CommandItem>
                                                                        ))}
                                                                    </CommandGroup>
                                                                </CommandList>
                                                            </Command>

                                                        </DialogContent>
                                                    </Dialog>
                                                )}
                                                <Button size="icon" type="button" onClick={() => { setIsUserPopUp(true) }}>
                                                    <Plus className="cursor-pointer w-5" />
                                                </Button>
                                            </div>
                                        )
                                    }


                                </div>
                                <div className='flex flex-col items-end gap-2'>
                                    <div className='flex justify-between items-center'>
                                        <div className='border text-xs rounded-sm p-2 text-grey'>
                                            {timeDiffInWords(saveMeetingDetails?.updatedAt)}
                                        </div>
                                    </div>
                                    <div className='flex items-center gap-3'>
                                        <Button type='button' variant={'outline'} onClick={generateLink}>Copy Meeting Link</Button>
                                        <Button type='button' onClick={() => handleMemberJoin(saveMeetingDetails?.meeting_url)}>Start Meeting</Button>
                                    </div>
                                </div>
                            </div>
                            <div className='grid grid-cols-2 gap-4 mt-10'>
                                <div className='flex gap-2 w-full'>
                                    <FormField
                                        control={form.control}
                                        name="created_by"
                                        render={({ field }) => (
                                            <FormItem className='w-full'>
                                                <FormLabel>
                                                    Created by -
                                                </FormLabel>
                                                <FormControl>
                                                    <Input
                                                        type="text"
                                                        placeholder="Enter here.."
                                                        {...field}
                                                        disabled={true}
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />

                                </div>
                                <div className='flex flex-col gap-2'>
                                    <Label>Created when - </Label>
                                    <Input type='text' placeholder='Enter here...' disabled={true} value={dayjs(saveMeetingDetails?.createdAt).format('DD/MM/YYYY')} />
                                </div>
                            </div>
                            <div className='grid grid-cols-2 gap-4 mt-5'>
                                <div className='col-span-1'>
                                    <FormField
                                        control={form.control}
                                        name="description"

                                        render={({ field }) => (
                                            <FormItem className='col-span-2'>
                                                <FormLabel>
                                                    Description
                                                </FormLabel>
                                                <FormControl>
                                                    <RichText
                                                        value={field.value}
                                                        onChange={(newValue) => field.onChange(newValue)}
                                                        key={meetingDetailMutation.data}
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>
                                <div className='col-span-1 flex flex-col gap-4'>
                                    <FormField
                                        control={form.control}
                                        name="meeting_name"
                                        render={({ field }) => (
                                            <FormItem className='col-span-2'>
                                                <FormLabel>
                                                    Meeting Name
                                                </FormLabel>
                                                <FormControl>
                                                    <Input
                                                        type="text"
                                                        placeholder="Enter your meeting room name"
                                                        {...field}
                                                    // disabled={loginMutation.isPending}
                                                    />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <RadioGroup value={form.watch("is_public")} onValueChange={(value) => form.setValue('is_public', value)} className='flex gap-4'>
                                        <div className="flex items-center space-x-2">
                                            <RadioGroupItem value="1" id="r1" />
                                            <Label htmlFor="r1">Public</Label>
                                        </div>
                                        <div className="flex items-center space-x-2">
                                            <RadioGroupItem value="2" id="r2" />
                                            <Label htmlFor="r2">Private</Label>
                                        </div>
                                    </RadioGroup>

                                    <FormField
                                        control={form.control}
                                        name="password"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>
                                                    Password
                                                </FormLabel>
                                                <FormControl>
                                                    <div className="relative">
                                                        <Input
                                                            type={showPassword ? "text" : "password"}
                                                            placeholder="Enter your password"
                                                            {...field}
                                                        />
                                                        <button
                                                            type="button"
                                                            onClick={togglePasswordVisibility}
                                                            className="absolute right-3 top-1/2 transform -translate-y-1/2"
                                                        >
                                                            {showPassword ? (
                                                                <EyeOff className="h-4 w-4 text-gray-500" />
                                                            ) : (
                                                                <Eye className="h-4 w-4 text-gray-500" />
                                                            )}
                                                        </button>
                                                    </div>
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="start_time"
                                        // rules={{
                                        //     validate: validateEmail,
                                        // }}
                                        render={({ field }) => (
                                            <FormItem className='col-span-1'>
                                                <FormLabel>
                                                    Start Time
                                                </FormLabel>
                                                <FormControl>
                                                    <DateTimePicker
                                                        onChange={field.onChange} value={field.value} />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="end_time"
                                        render={({ field }) => (
                                            <FormItem className='col-span-1'>
                                                <FormLabel>
                                                    End Time
                                                </FormLabel>
                                                <FormControl>
                                                    <DateTimePicker
                                                        onChange={field.onChange} value={field.value} />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                </div>
                            </div>
                            <div className='flex justify-end'>
                                <Button type='submit' size="lg" className=' mt-6'>
                                    {
                                        (updateMeetingMutation?.isPending && updateApiStatus === 'meeting update') && (
                                            <Loader2 className="animate-spin" />
                                        )
                                    }
                                    Update
                                </Button>
                            </div>
                        </div>
                        <div className='pl-5 w-[25%] grow'>

                            <FormField
                                control={form.control}
                                name="attachments"
                                render={() => (
                                    <FormItem>
                                        <FormLabel>Room Attachments</FormLabel>
                                        <FormControl>
                                            <Input
                                                type="file"
                                                multiple
                                                onChange={handleFileChange}
                                                accept="*/*"
                                                disabled={fileUploadMutation.isPending}
                                            />
                                        </FormControl>
                                        <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <Table className='mt-5'>
                                <TableHeader>
                                    {table.getHeaderGroups().map(headerGroup => (
                                        <TableRow key={headerGroup.id}>
                                            {headerGroup.headers.map(header => {
                                                return (
                                                    <TableHead key={header.id}>
                                                        {header.isPlaceholder
                                                            ? null
                                                            : flexRender(
                                                                header.column.columnDef.header,
                                                                header.getContext()
                                                            )}
                                                    </TableHead>
                                                )
                                            })}
                                        </TableRow>
                                    ))}
                                </TableHeader>
                                <TableBody>
                                    {table.getRowModel().rows?.length ? (
                                        table.getRowModel().rows.map((row, index) => (
                                            <TableRow
                                                key={row.id}
                                                data-state={row.getIsSelected() && 'selected'}
                                            >
                                                {row.getVisibleCells().map(cell => (
                                                    <TableCell key={cell.id}>
                                                        {flexRender(
                                                            cell.column.columnDef.cell,
                                                            cell.getContext()
                                                        )}
                                                    </TableCell>
                                                ))}
                                            </TableRow>
                                        ))
                                    ) : (
                                        <TableRow>
                                            <TableCell
                                                colSpan={columns?.length}
                                                className="h-24 text-center"
                                            >
                                                No results.
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                        </div>

                    </form>


                </Form>
                <Dialog open={isUserPopUp} onOpenChange={setIsUserPopUp}>
                    <DialogContent className="gap-0 p-0 outline-none">
                        <DialogHeader className="px-4 pb-4 pt-5">
                            <DialogTitle>Add Member</DialogTitle>
                        </DialogHeader>

                        <Command className="overflow-hidden rounded-t-none bg-transparent">
                            <CommandInput placeholder="Search user..." />
                            <CommandList>
                                <CommandEmpty>No users found.</CommandEmpty>
                                <CommandGroup className="p-2">
                                    {users?.map((user: any) => (
                                        <CommandItem
                                            key={user?.emailaddress}
                                            className="flex items-center px-2"
                                            onSelect={() => {

                                                const newSelctedUser = selectedUsers?.includes(user?.id)
                                                    ? selectedUsers?.filter((selectedUser: any) => selectedUser !== user.id)
                                                    : [...selectedUsers, user?.id]

                                                setSelectedUsers(newSelctedUser)
                                                // form.setValue('team_member', newSelctedUser)
                                            }}
                                        >
                                            <Avatar>
                                                <AvatarImage src={user?.profileimg || ''} alt="Image" />
                                                <AvatarFallback>{user?.userfullname[0]}</AvatarFallback>
                                            </Avatar>
                                            <div className="ml-2">
                                                <p className="text-sm font-medium leading-none">
                                                    {user?.userfullname}
                                                </p>
                                                <p className="text-sm text-muted-foreground">
                                                    {user?.emailaddress}
                                                </p>
                                            </div>
                                            {selectedUsers?.includes(user?.id) ? (
                                                <Check className="ml-auto flex h-5 w-5 text-primary" />
                                            ) : null}
                                        </CommandItem>
                                    ))}
                                </CommandGroup>
                            </CommandList>
                        </Command>
                        <DialogFooter className="flex items-center border-t p-4 sm:justify-between">
                            {selectedUsers?.length > 0 ? (
                                <div className="flex -space-x-2 overflow-hidden">
                                    {users?.filter((item: any) => selectedUsers?.includes(item?.id))?.map((user: any) => (
                                        <Avatar
                                            key={user?.emailaddress}
                                            className="inline-block border-2 border-background"
                                        >
                                            <AvatarImage src={user?.profileimg || ''} />
                                            <AvatarFallback>{user?.userfullname[0]}</AvatarFallback>
                                        </Avatar>
                                    ))}
                                </div>
                            ) : (
                                <p className="text-sm text-muted-foreground">
                                    Select users to add to this group.
                                </p>
                            )}

                            <Button
                                onClick={handleUpdateUsers}
                            >
                                {
                                    (updateMeetingMutation?.isPending && updateApiStatus === 'add user') && (
                                        <Loader2 className="animate-spin" />
                                    )
                                }
                                Continue
                            </Button>

                        </DialogFooter>
                    </DialogContent>
                </Dialog>



            </div >


            <Dialog open={isDeleteDialogOpen?.status} onOpenChange={handleCloseDialog}>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <DialogTitle>Delete Attachment</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to delete this Attachment
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button variant="outline" onClick={handleCloseDialog}>Cancel</Button>
                        <Button variant="destructive" onClick={() => deleteFileMutation.mutate(isDeleteDialogOpen?.id)}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    )
}

export default MeetingSchedule