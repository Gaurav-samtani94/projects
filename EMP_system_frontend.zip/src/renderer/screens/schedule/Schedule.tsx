import { useEffect, useState } from "react";
import React from 'react'
import { Avatar, AvatarFallback, AvatarImage } from 'renderer/components/ui/avatar'
import { Card } from 'renderer/components/ui/card'
import { Separator } from 'renderer/components/ui/separator'
import {
    Dialog,
    DialogTrigger,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogFooter
} from "renderer/components/ui/dialog";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "renderer/components/ui/command";
import { Check, Loader2, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "renderer/components/ui/button";
import CreateMeetingRoom from "renderer/components/sections/MeetingRooms/CreateMeetingRoom";
import { fetchMeetingList, joinMeeting, updateMeeting } from "renderer/service/MeetingRoomService";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { GetUser } from "renderer/service/authService";
import useAuthStore from "renderer/store/AuthStore";
import dayjs from "dayjs";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "renderer/components/ui/hover-card";

const members = [
    { name: "Alice", avatar: "https://github.com/shadcn.png", designation: "web designers" },
    { name: "Bob", avatar: "https://github.com/shadcn.png", designation: "web designers" },
    { name: "Charlie", avatar: "https://github.com/shadcn.png", designation: "web designers" },
    { name: "David", avatar: "https://github.com/shadcn.png", designation: "web designers" },
    { name: "Eve", avatar: "https://github.com/shadcn.png", designation: "web designers" },
    { name: "Frank", avatar: "https://github.com/shadcn.png", designation: "web designers" },
    { name: "Frank", avatar: "https://github.com/shadcn.png", designation: "web designers" },
    { name: "Frank", avatar: "https://github.com/shadcn.png", designation: "web designers" },
    { name: "Frank", avatar: "https://github.com/shadcn.png", designation: "web designers" },
];
const MAX_VISIBLE = 5;

const Schedule = () => {
    const visibleMembers = members.slice(0, MAX_VISIBLE);
    const hiddenMembers = members.slice(MAX_VISIBLE);
    const [isUserPopUp, setIsUserPopUp] = useState(false)
    const [users, setUsers] = React.useState<any>([])
    const [selectedUsers, setSelectedUsers] = React.useState<any>([])
    const [userData, setUserData] = useState<any>({})
    const [meetingList, setMeetingList] = useState<any>({
        customMeeting: [],
        scheduleMeeting: [],
        projectMeeting: [],
    })
    const navigate = useNavigate()
    const user = useAuthStore.getState().getUser();

    // Fetch Meeting List
    const { data: saveMeetingList, isSuccess, refetch } = useQuery({
        queryKey: ['meetingList'],
        queryFn: () => fetchMeetingList(),
    });

    // Meeting join
    const joinMeetingMutation = useMutation({
        mutationFn: joinMeeting,
        onSuccess: (data) => {
            toast.success(data?.message)
            navigate('/connect/custom-meeting-room', {
                state: { token: data?.data?.livekit_token }
            })
        },
        onError: (error) => {
            toast.error('Failed to join meeting')
        },
    })

    const handleMemberJoin = (meetingUrl: string) => {
        joinMeetingMutation.mutate(meetingUrl)
    }

    // Fetch User List
    const getUserMutation = useMutation({
        mutationFn: GetUser,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const currentUserId = useAuthStore.getState().getUser()?.id;
                const filteredUsers = response.data.filter((user: any) => user.id !== currentUserId)
                setUsers(filteredUsers);
            }
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })

    const getUserList = async () => {
        getUserMutation.mutate()
    }

    // Update Meeting
    const updateMeetingMutation = useMutation({
        mutationFn: updateMeeting,
        onSuccess: data => {
            toast.success('Meeting updated successfully')
            handleCloseUser()
            refetch()
        },
        onError: error => {
            toast.error('Failed to update meeting')
        },
    })


    const handleUpdateUsers = () => {
        const allData: any = {
            meeting_id: userData?.id,
            meeting_name: userData?.meeting_name,
            description: userData?.description,
            start_time: userData.start_time ? dayjs(userData.start_time).format('YYYY-MM-DD HH:mm:ss') : null,
            end_time: userData.end_time ? dayjs(userData.end_time).format('YYYY-MM-DD HH:mm:ss') : null,
            team_member: selectedUsers,
            is_public: Number(userData?.is_public),
            password: userData?.password,
        }
        updateMeetingMutation.mutate(allData)
    }

    useEffect(() => {
        getUserList()
    }, [])
    useEffect(() => {
        if (userData?.participants?.length > 0) {
            const allId = userData?.participants?.map((item: any) => item?.tbl_User?.id)
            setSelectedUsers(allId)
        } else {
            setSelectedUsers([])
        }
    }, [userData])

    const handleCloseUser = () => {
        setIsUserPopUp(false)
        setSelectedUsers([])
        setUserData({})
    }
    useEffect(() => {
        if (saveMeetingList?.data?.length > 0) {
            const meetings = saveMeetingList?.data
            const customMeeting = meetings?.filter((item: any) => item?.start_time === null && item?.end_time === null)
            const scheduleMeeting = meetings?.filter((item: any) => item?.start_time !== null && item?.end_time !== null)
            setMeetingList({
                customMeeting,
                scheduleMeeting,

            })
        } else {
            setMeetingList({
                customMeeting: [],
                scheduleMeeting: [],
                projectMeeting: [],
            })
        }

    }, [isSuccess, saveMeetingList])
    return (
        <div>
            <div className='p-5 flex justify-between items-center'>
                <h1 className="text-3xl font-bold tracking-tight">Meeting Rooms</h1>
                <CreateMeetingRoom />
            </div>
            <Separator />
            <div className='grid grid-cols-3 gap-4 mt-7 px-10'>
                {/* <div>
                    <p className='mb-5 text-lg'>Projects</p>
                    <div className='grid grid-cols-2 gap-4 w-full'>
                        <Card className="p-5 !gap-2">
                            <p className="mb-1 font-medium text-sm">Ideal Coffee Machine</p>
                            <div className="grid grid-cols-3 gap-2.5">

                                {visibleMembers.map((member, index) => (
                                    <Avatar key={index} className="rounded-sm aspect-square w-full h-full">
                                        <AvatarImage src={member.avatar} />
                                        <AvatarFallback>{member.name[0]}</AvatarFallback>
                                    </Avatar>
                                ))}

                                {hiddenMembers.length > 0 && (
                                    <Dialog>
                                        <DialogTrigger asChild>
                                            <Avatar
                                                className="aspect-square w-full h-full rounded-sm cursor-pointer bg-muted text-xs flex items-center justify-center relative"
                                                title="See more members"
                                            >
                                                <AvatarImage src="https://github.com/shadcn.png" />
                                                <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white font-semibold rounded-sm">
                                                    +{hiddenMembers.length}
                                                </div>
                                            </Avatar>
                                        </DialogTrigger>
                                        <DialogContent className="p-4">
                                            <DialogHeader>
                                                <DialogTitle>All Members</DialogTitle>
                                            </DialogHeader>
                                            <Command>
                                                <CommandInput placeholder="Type a command or search..." />
                                                <CommandList>
                                                    <CommandEmpty>No results found.</CommandEmpty>
                                                    <CommandGroup heading="Team Members">
                                                        {members.map((member, index) => (
                                                            <CommandItem key={index} className="gap-3 py-2">
                                                                <Avatar className="w-8 h-8">
                                                                    <AvatarImage src={member.avatar} />
                                                                    <AvatarFallback>{member.name[0]}</AvatarFallback>
                                                                </Avatar>
                                                                <div className="flex flex-col">
                                                                    <span className="text-sm font-medium">{member.name}</span>
                                                                    <span className="text-xs text-muted-foreground">{member.designation}</span>
                                                                </div>
                                                            </CommandItem>
                                                        ))}
                                                    </CommandGroup>
                                                </CommandList>
                                            </Command>

                                        </DialogContent>
                                    </Dialog>
                                )}
                            </div>
                        </Card>
                        <Card className="p-5 !gap-2">
                            <p className="mb-1 font-medium text-sm">Kairaus</p>
                            <div className="grid grid-cols-3 gap-2.5">
                                {visibleMembers.map((member, index) => (
                                    <Avatar key={index} className="rounded-sm aspect-square w-full h-full">
                                        <AvatarImage src={member.avatar} />
                                        <AvatarFallback>{member.name[0]}</AvatarFallback>
                                    </Avatar>
                                ))}

                                {hiddenMembers.length > 0 && (
                                    <Dialog>
                                        <DialogTrigger asChild>
                                            <Avatar
                                                className="aspect-square w-full h-full rounded-sm cursor-pointer bg-muted text-xs flex items-center justify-center relative"
                                                title="See more members"
                                            >
                                                <AvatarImage src="https://github.com/shadcn.png" />
                                                <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white font-semibold rounded-sm">
                                                    +{hiddenMembers.length}
                                                </div>
                                            </Avatar>
                                        </DialogTrigger>
                                        <DialogContent className="p-4">
                                            <DialogHeader>
                                                <DialogTitle>All Members</DialogTitle>
                                            </DialogHeader>
                                            <Command>
                                                <CommandInput placeholder="Type a command or search..." />
                                                <CommandList>
                                                    <CommandEmpty>No results found.</CommandEmpty>
                                                    <CommandGroup heading="Team Members">
                                                        {members.map((member, index) => (
                                                            <CommandItem key={index} className="gap-3 py-2">
                                                                <Avatar className="w-8 h-8">
                                                                    <AvatarImage src={member.avatar} />
                                                                    <AvatarFallback>{member.name[0]}</AvatarFallback>
                                                                </Avatar>
                                                                <div className="flex flex-col">
                                                                    <span className="text-sm font-medium">{member.name}</span>
                                                                    <span className="text-xs text-muted-foreground">{member.designation}</span>
                                                                </div>
                                                            </CommandItem>
                                                        ))}
                                                    </CommandGroup>
                                                </CommandList>
                                            </Command>

                                        </DialogContent>
                                    </Dialog>
                                )}
                            </div>
                        </Card>
                        <Card className="p-5 !gap-2">
                            <p className="mb-1 font-medium text-sm">Tender Grid</p>
                            <div className="grid grid-cols-3 gap-2.5">
                                {visibleMembers.map((member, index) => (
                                    <Avatar key={index} className="rounded-sm aspect-square w-full h-full">
                                        <AvatarImage src={member.avatar} />
                                        <AvatarFallback>{member.name[0]}</AvatarFallback>
                                    </Avatar>
                                ))}

                                {hiddenMembers.length > 0 && (
                                    <Dialog>
                                        <DialogTrigger asChild>
                                            <Avatar
                                                className="aspect-square w-full h-full rounded-sm cursor-pointer bg-muted text-xs flex items-center justify-center relative"
                                                title="See more members"
                                            >
                                                <AvatarImage src="https://github.com/shadcn.png" />
                                                <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white font-semibold rounded-sm">
                                                    +{hiddenMembers.length}
                                                </div>
                                            </Avatar>
                                        </DialogTrigger>
                                        <DialogContent className="p-4">
                                            <DialogHeader>
                                                <DialogTitle>All Members</DialogTitle>
                                            </DialogHeader>
                                            <Command>
                                                <CommandInput placeholder="Type a command or search..." />
                                                <CommandList>
                                                    <CommandEmpty>No results found.</CommandEmpty>
                                                    <CommandGroup heading="Team Members">
                                                        {members.map((member, index) => (
                                                            <CommandItem key={index} className="gap-3 py-2">
                                                                <Avatar className="w-8 h-8">
                                                                    <AvatarImage src={member.avatar} />
                                                                    <AvatarFallback>{member.name[0]}</AvatarFallback>
                                                                </Avatar>
                                                                <div className="flex flex-col">
                                                                    <span className="text-sm font-medium">{member.name}</span>
                                                                    <span className="text-xs text-muted-foreground">{member.designation}</span>
                                                                </div>
                                                            </CommandItem>
                                                        ))}
                                                    </CommandGroup>
                                                </CommandList>
                                            </Command>

                                        </DialogContent>
                                    </Dialog>
                                )}
                            </div>
                        </Card>
                        <Card className="p-5 !gap-2">
                            <p className="mb-1 font-medium text-sm">Growth Grids</p>
                            <div className="grid grid-cols-3 gap-2.5">
                                {visibleMembers.map((member, index) => (
                                    <Avatar key={index} className="rounded-sm aspect-square w-full h-full">
                                        <AvatarImage src={member.avatar} />
                                        <AvatarFallback>{member.name[0]}</AvatarFallback>
                                    </Avatar>
                                ))}

                                {hiddenMembers.length > 0 && (
                                    <Dialog>
                                        <DialogTrigger asChild>
                                            <Avatar
                                                className="aspect-square w-full h-full rounded-sm cursor-pointer bg-muted text-xs flex items-center justify-center relative"
                                                title="See more members"
                                            >
                                                <AvatarImage src="https://github.com/shadcn.png" />
                                                <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white font-semibold rounded-sm">
                                                    +{hiddenMembers.length}
                                                </div>
                                            </Avatar>
                                        </DialogTrigger>
                                        <DialogContent className="p-4">
                                            <DialogHeader>
                                                <DialogTitle>All Members</DialogTitle>
                                            </DialogHeader>
                                            <Command>
                                                <CommandInput placeholder="Type a command or search..." />
                                                <CommandList>
                                                    <CommandEmpty>No results found.</CommandEmpty>
                                                    <CommandGroup heading="Team Members">
                                                        {members.map((member, index) => (
                                                            <CommandItem key={index} className="gap-3 py-2">
                                                                <Avatar className="w-8 h-8">
                                                                    <AvatarImage src={member.avatar} />
                                                                    <AvatarFallback>{member.name[0]}</AvatarFallback>
                                                                </Avatar>
                                                                <div className="flex flex-col">
                                                                    <span className="text-sm font-medium">{member.name}</span>
                                                                    <span className="text-xs text-muted-foreground">{member.designation}</span>
                                                                </div>
                                                            </CommandItem>
                                                        ))}
                                                    </CommandGroup>
                                                </CommandList>
                                            </Command>

                                        </DialogContent>
                                    </Dialog>
                                )}
                            </div>
                        </Card>
                    </div>
                </div> */}


                {
                    meetingList?.customMeeting?.length > 0 && (
                        <div>
                            <p className='mb-5 text-lg'>Custom Meetings</p>
                            <div className='grid grid-cols-2 gap-4'>

                                {
                                    meetingList?.customMeeting?.map((item: any, index: number) => {
                                        return (
                                            <Card className="p-5" key={index}>
                                                <div className="flex gap-2 justify-between items-center">
                                                    {/* biome-ignore lint/a11y/useKeyWithClickEvents: <explanation> */}
                                                    <p className="mb-0 font-medium text-base text-foreground" onClick={() => { navigate('/scheduled/meetings', { state: { id: item?.id } }) }}>{item?.meeting_name}</p>
                                                    <div className="flex gap-2">
                                                        <Button variant="default" type="button" onClick={() => handleMemberJoin(item?.meeting_url)}>Join</Button>
                                                        <Button variant="outline" type="button" onClick={() => { setIsUserPopUp(true); setUserData(item) }}>
                                                            <Plus className="cursor-pointer w-5" />
                                                        </Button>
                                                    </div>
                                                </div>

                                                {
                                                    item?.participants?.length > 0 && (
                                                        <div className="grid grid-cols-4 gap-2.5">
                                                            {item?.participants?.slice(0, 3)?.map((member: any, memberIndex: number) => (

                                                                // biome-ignore lint/correctness/useJsxKeyInIterable: <explanation>
                                                                <HoverCard openDelay={100} closeDelay={100}>
                                                                    <HoverCardTrigger asChild>
                                                                        <Avatar key={memberIndex} className="rounded-sm aspect-square w-full h-full cursor-pointer">
                                                                            {/* <AvatarImage src={member.avatar} /> */}
                                                                            <AvatarFallback className="rounded-sm">{member?.tbl_User?.userfullname.slice(0, 2)}</AvatarFallback>
                                                                        </Avatar>
                                                                    </HoverCardTrigger>
                                                                    <HoverCardContent className="w-auto">
                                                                        <div className="flex space-x-4">
                                                                            <Avatar>
                                                                                {/* <AvatarImage src="https://github.com/vercel.png" /> */}
                                                                                <AvatarFallback className="rounded-sm   ">{member?.tbl_User?.userfullname.slice(0, 2)}</AvatarFallback>
                                                                            </Avatar>
                                                                            <div className="space-y-0">
                                                                                <h4 className="text-sm font-semibold">{member?.tbl_User?.userfullname}</h4>
                                                                                <p className="text-sm">
                                                                                    {member?.tbl_User?.emailaddress}
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </HoverCardContent>
                                                                </HoverCard>
                                                            ))}


                                                            {item?.participants.length > 3 && (
                                                                <Dialog>
                                                                    <DialogTrigger asChild>
                                                                        <Avatar
                                                                            className="aspect-square w-full h-full rounded-sm cursor-pointer bg-muted text-xs flex items-center justify-center relative"
                                                                            title="See more members"
                                                                        >
                                                                            {/* <AvatarImage src="https://github.com/shadcn.png" /> */}
                                                                            <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white font-semibold rounded-sm">
                                                                                +{item?.participants.length - 3}
                                                                            </div>
                                                                        </Avatar>
                                                                    </DialogTrigger>
                                                                    <DialogContent className="p-0">
                                                                        <DialogHeader className="p-5 pb-0 ">
                                                                            <DialogTitle>All Members</DialogTitle>
                                                                        </DialogHeader>
                                                                        <Command className="bg-transparent">
                                                                            <CommandInput placeholder="Type a command or search..." />
                                                                            <CommandList>
                                                                                <CommandEmpty>No results found.</CommandEmpty>
                                                                                <CommandGroup heading="Team Members">
                                                                                    {item?.participants?.map((member: any, index: any) => (
                                                                                        <CommandItem key={index} className="gap-3 py-2">
                                                                                            <Avatar className="w-8 h-8">
                                                                                                {/* <AvatarImage src={member.avatar} /> */}
                                                                                                <AvatarFallback>{member?.tbl_User?.userfullname[0]}</AvatarFallback>
                                                                                            </Avatar>
                                                                                            <div className="flex flex-col">
                                                                                                <span className="text-sm font-medium">{member?.tbl_User?.userfullname}</span>
                                                                                                {/* <span className="text-xs text-muted-foreground">{member.designation}</span>                                                                                                 <span className="text-xs text-muted-foreground">{member.designation}</span> */}
                                                                                            </div>
                                                                                        </CommandItem>
                                                                                    ))}
                                                                                </CommandGroup>
                                                                            </CommandList>
                                                                        </Command>
                                                                    </DialogContent>
                                                                </Dialog>
                                                            )}
                                                        </div>
                                                    )
                                                }

                                            </Card>
                                        )
                                    })
                                }


                            </div>
                        </div>
                    )

                }

                {
                    meetingList?.scheduleMeeting?.length > 0 && (
                        <div>
                            <p className='mb-5 text-lg'>Scheduled Meeting</p>
                            <div className='grid grid-cols-2 gap-4'>

                                {
                                    meetingList?.scheduleMeeting?.map((item: any, index: number) => {
                                        return (
                                            <Card className="p-5" key={index}>

                                                <div className="flex gap-2 justify-between items-center">
                                                    {/* biome-ignore lint/a11y/useKeyWithClickEvents: <explanation> */}
                                                    <p className="mb-0 font-medium text-base text-foreground" onClick={() => navigate('/scheduled/meetings', { state: { id: item?.id } })}>{item?.meeting_name}</p>
                                                    <div className="flex gap-2">
                                                        <Button variant="default" type="button" onClick={() => handleMemberJoin(item?.meeting_url)}>Join</Button>
                                                        <Button variant="outline" type="button" onClick={() => { setIsUserPopUp(true); setUserData(item) }}>
                                                            <Plus className="cursor-pointer w-5" />
                                                        </Button>
                                                    </div>
                                                </div>

                                                {
                                                    item?.participants?.length > 0 && (
                                                        <div className="grid grid-cols-4 gap-2.5">
                                                            {item?.participants?.slice(0, 3)?.map((member: any, memberIndex: number) => (

                                                                <>
                                                                    <HoverCard key={index} openDelay={100} closeDelay={100}>
                                                                        <HoverCardTrigger asChild>
                                                                            <Avatar key={memberIndex} className="rounded-sm aspect-square w-full h-full cursor-pointer">
                                                                                {/* <AvatarImage src={member.avatar} /> */}
                                                                                <AvatarFallback className="rounded-sm">{member?.tbl_User?.userfullname.slice(0, 2)}</AvatarFallback>
                                                                            </Avatar>
                                                                        </HoverCardTrigger>
                                                                        <HoverCardContent className="w-auto">
                                                                            <div className="flex space-x-4">
                                                                                <Avatar>
                                                                                    {/* <AvatarImage src="https://github.com/vercel.png" /> */}
                                                                                    <AvatarFallback className="rounded-sm   ">{member?.tbl_User?.userfullname.slice(0, 2)}</AvatarFallback>
                                                                                </Avatar>
                                                                                <div className="space-y-0">
                                                                                    <h4 className="text-sm font-semibold">{member?.tbl_User?.userfullname}</h4>
                                                                                    <p className="text-sm">
                                                                                        {member?.tbl_User?.emailaddress}
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </HoverCardContent>
                                                                    </HoverCard>

                                                                </>
                                                            ))}

                                                            {item?.participants.length > 3 && (
                                                                <Dialog>
                                                                    <DialogTrigger asChild>
                                                                        <Avatar
                                                                            className="aspect-square w-full h-full rounded-sm cursor-pointer bg-muted text-xs flex items-center justify-center relative"
                                                                            title="See more members"
                                                                        >
                                                                            {/* <AvatarImage src="https://github.com/shadcn.png" /> */}
                                                                            <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-white font-semibold rounded-sm">
                                                                                +{item?.participants.length - 3}
                                                                            </div>
                                                                        </Avatar>
                                                                    </DialogTrigger>
                                                                    <DialogContent className="p-0">
                                                                        <DialogHeader className="p-5 pb-0 ">
                                                                            <DialogTitle>All Members</DialogTitle>
                                                                        </DialogHeader>
                                                                        <Command className="bg-transparent">
                                                                            <CommandInput placeholder="Type a command or search..." />
                                                                            <CommandList>
                                                                                <CommandEmpty>No results found.</CommandEmpty>
                                                                                <CommandGroup heading="Team Members">
                                                                                    {item?.participants?.map((member: any, index: any) => (
                                                                                        <CommandItem key={index} className="gap-3 py-2">
                                                                                            <Avatar className="w-8 h-8">
                                                                                                {/* <AvatarImage src={member.avatar} /> */}
                                                                                                <AvatarFallback>{member?.tbl_User?.userfullname[0]}</AvatarFallback>
                                                                                            </Avatar>
                                                                                            <div className="flex flex-col">
                                                                                                <span className="text-sm font-medium">{member?.tbl_User?.userfullname}</span>
                                                                                                {/* <span className="text-xs text-muted-foreground">{member.designation}</span>                                                                                                 <span className="text-xs text-muted-foreground">{member.designation}</span> */}
                                                                                            </div>
                                                                                        </CommandItem>
                                                                                    ))}
                                                                                </CommandGroup>
                                                                            </CommandList>
                                                                        </Command>
                                                                    </DialogContent>
                                                                </Dialog>
                                                            )}
                                                        </div>
                                                    )
                                                }

                                            </Card>
                                        )
                                    })
                                }


                            </div>
                        </div>

                    )
                }

            </div>


            <Dialog open={isUserPopUp} onOpenChange={handleCloseUser}>
                <DialogContent className="gap-0 p-0 outline-none">
                    <DialogHeader className="px-4 pb-4 pt-5">
                        <DialogTitle>Add User</DialogTitle>
                    </DialogHeader>

                    <Command className="overflow-hidden rounded-t-none border-t bg-transparent">
                        <CommandInput placeholder="Search user..." />
                        <CommandList>
                            <CommandEmpty>No users found.</CommandEmpty>
                            <CommandGroup className="p-2">
                                {users?.map((user: any) => (
                                    <CommandItem
                                        key={user?.emailaddress}
                                        className="flex items-center px-2"
                                        onSelect={() => {
                                            if (selectedUsers?.includes(user?.id)) {
                                                return setSelectedUsers(
                                                    selectedUsers?.filter(
                                                        (selectedUser: any) => selectedUser !== user?.id
                                                    )
                                                )
                                            }


                                            return setSelectedUsers([
                                                ...selectedUsers,
                                                user?.id, // Only store ID
                                            ]);
                                        }}
                                    >
                                        <Avatar>
                                            <AvatarImage src={user?.profileimg || ''} alt="Image" />
                                            <AvatarFallback>{user?.userfullname[0]}</AvatarFallback>
                                        </Avatar>
                                        <div className="ml-2">
                                            <p className="text-sm font-medium leading-none">
                                                {user?.userfullname}
                                            </p>
                                            <p className="text-sm text-muted-foreground">
                                                {user?.emailaddress}
                                            </p>
                                        </div>
                                        {selectedUsers?.includes(user?.id) ? (
                                            <Check className="ml-auto flex h-5 w-5 text-primary" />
                                        ) : null}
                                    </CommandItem>
                                ))}
                            </CommandGroup>
                        </CommandList>
                    </Command>
                    <DialogFooter className="flex items-center border-t p-4 sm:justify-between">
                        {selectedUsers?.length > 0 ? (
                            <div className="flex -space-x-2 overflow-hidden">
                                {users?.filter((item: any) => selectedUsers?.includes(item?.id))?.map((user: any) => (
                                    <Avatar
                                        key={user?.emailaddress}
                                        className="inline-block border-2 border-background"
                                    >
                                        <AvatarImage src={user?.profileimg || ''} />
                                        <AvatarFallback>{user?.userfullname[0]}</AvatarFallback>
                                    </Avatar>
                                ))}
                            </div>
                        ) : (
                            <p className="text-sm text-muted-foreground">
                                Select users to add to this group.
                            </p>
                        )}
                        <Button
                            onClick={handleUpdateUsers}
                        >
                            {
                                updateMeetingMutation?.isPending && (
                                    <Loader2 className="animate-spin" />
                                )
                            }
                            Continue
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    )
}

export default Schedule