import { NotificationDashboard } from "renderer/components/sections/notification/notification-dashboard"

export default function Home() {
    return (
        <div className="min-h-screen bg-background">
            <NotificationDashboard />
        </div>
    )
}
