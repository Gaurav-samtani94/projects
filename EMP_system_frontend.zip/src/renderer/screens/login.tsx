"use client"

import type React from "react"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useForm } from "react-hook-form"
import { useMutation } from "@tanstack/react-query"
import { toast } from "sonner"
import { Eye, EyeOff } from "lucide-react"

import { Button } from "renderer/components/ui/button"
import { Input } from "renderer/components/ui/input"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "renderer/components/ui/form"
import { PermissionsModal } from "./permissons"
import useAuthStore from "renderer/store/AuthStore"
import { userLogin } from "renderer/service/authService"
import { validateEmail } from "renderer/utils/Validations"
import loginImage from '../../assets/login.webp';

// Define types for form and API data
interface LoginFormValues {
  email: string
  password: string
  rememberMe: boolean
}

const Login: React.FC = () => {
  const { login } = useAuthStore()
  const navigate = useNavigate()
  const [showPassword, setShowPassword] = useState<boolean>(false)
  const [showPermissionsModal, setShowPermissionsModal] = useState<boolean>(false)
  const [loginData, setLoginData] = useState<any>(null)
  // Form validation schema
  const form = useForm<LoginFormValues>({
    defaultValues: {
      email: "",
      password: "",
    },
    mode: "onBlur",
  })

  // Login mutation with TanStack Query
  const loginMutation = useMutation({
    mutationFn: userLogin,
    onSuccess: (data) => {
      // Store login data but don't navigate yet
      setLoginData(data)
      // Show permissions modal instead of immediately logging in
      setShowPermissionsModal(true)
    },
    onError: (error) => {
      toast.error("Login Failed", {
        description: error.message,
      })
    },
  })

  const onSubmit = (values: LoginFormValues) => {
    loginMutation.mutate({
      email: values.email,
      password: values.password,
    })
  }

  const handlePermissionsAccepted = () => {
    // Complete the login process after permissions are accepted
    toast.success("Login Successful", {
      description: "You have been logged in successfully.",
    })

    login(
      {
        id: loginData.user.id,
        user_id: loginData.user.user_id,
        email: loginData.user.emailaddress,
        phone: loginData.user.contactnumber,
        firstname: loginData.user.firstname,
        lastname: loginData.user.firstname,
        userfullname: loginData.user.userfullname,
        date_of_joining: loginData.user.date_of_joining,
        reporting_manager_name: loginData.user.reporting_manager_name,
        isReportingManager: loginData?.user?.isReportingManager
      },
      loginData.token,
    )

    // Close modal and navigate to homepage
    setShowPermissionsModal(false)
    navigate("/")
  }

  const handlePermissionsDenied = () => {
    // Handle case where user denies permissions
    setShowPermissionsModal(false)
    toast.info("Login canceled", {
      description: "You need to accept permissions to continue.",
    })
  }

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword)
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row h-[95vh] w-full">
        {/* Form Section */}
        <div className="w-full md:w-1/2 flex items-center justify-center p-6 md:p-10">
          <div className="w-full max-w-md">
            <div className="text-center mb-6">
              <h2 className="text-3xl md:text-4xl font-semibold">Welcome back!</h2>
              <p className="text-gray-500">Enter to get unlimited access to data & information.</p>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="email"
                  rules={{
                    validate: validateEmail,
                  }}
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Email <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder="Enter your mail address"
                          {...field}
                          disabled={loginMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Password <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter your password"
                            {...field}
                            disabled={loginMutation.isPending}
                          />
                          <button
                            type="button"
                            onClick={togglePasswordVisibility}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2"
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4 text-gray-500" />
                            ) : (
                              <Eye className="h-4 w-4 text-gray-500" />
                            )}
                          </button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={loginMutation.isPending}>
                  {loginMutation.isPending ? "Logging in..." : "Log In"}
                </Button>
              </form>
            </Form>
          </div>
        </div>

        {/* Image Section */}
        <div className="hidden md:block md:w-1/2">
          <img src={loginImage} alt="Login" className="h-full w-full object-cover" />
        </div>
      </div>

      {/* Permissions Modal */}
      <PermissionsModal
        isOpen={showPermissionsModal}
        onAccept={handlePermissionsAccepted}
        onDeny={handlePermissionsDenied}
      />
    </div>
  )
}

export default Login
