import {
  LiveKitRoom,
  RoomAudioRenderer,
  VideoConference,
  formatChatMessageLinks,
} from '@livekit/components-react'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import ChatController from 'renderer/Controller/ChatController'
import { Calls_ends_Api, startCall } from 'renderer/service/authService'
import useAuthStore from 'renderer/store/AuthStore'
import '@livekit/components-styles';
import '@livekit/components-styles/prefabs';
import { useChatStore } from 'stores/useChatStore'
import BaseUrl from 'renderer/service/BaseUrl'

const serverUrl = BaseUrl.LIVEKIT_URL;
const ResUser = useAuthStore.getState().getUser()



export default function RoomMeeting() {
  const { chatInfo } = useChatStore()
  const location = useLocation()
  const token = location.state?.token
  const selectedUser = location.state?.selectedUser
  const [selectcallerId, setSelectcallerId] = useState<'' | null>(null);

  const navigate = useNavigate()


  useEffect(() => {
    let cleanupFn: (() => void) | undefined;
    const setupSocket = async () => {
      cleanupFn = await SocketHandle();
    };
    setupSocket();
    return () => {
      cleanupFn?.();
    };
  }, []);

  const SocketHandle = async () => {
    let socket: any;

    const handleCallEndedNotification = (data: any) => {
      // setCallStartTime(Date.now());
      handleCall(data);
    };

    const setupSocketListeners = async () => {
      await waitForSocketReady();
      socket = ChatController.getSocket();
      if (!socket) return;
      socket.on("call-accepted", handleCallNotification);
      socket.on("call-ended", handleCallEndedNotification);
    };

    const cleanupListeners = () => {
      if (!socket) return;
      socket.off("call-accepted", handleCallNotification);
      socket.off("call-ended", handleCallEndedNotification);
    };

    const waitForSocketReady = () => {
      return new Promise<void>((resolve) => {
        if (ChatController.isSocketConnected === 1) return resolve();
        const interval = setInterval(() => {
          if (ChatController.isSocketConnected === 1) {
            clearInterval(interval);
            resolve();
          }
        }, 300);
      });
    };
    setupSocketListeners();
    return () => {
      cleanupListeners();
    };
  }



  const handleCallNotification = (data: any) => {
    console.log('call data video room meeting', data)
    handleCalls(data);
  };
  const handleCalls = async (callData: any) => {
    const response = await startCall({ chat_id: chatInfo?.id, caller_id: callData?.senderId || "", call_type: '1' });
    if (response?.data) {
      setSelectcallerId(response.data.id)
    }
  }

  const handleCall = async (data: any) => {
    navigate('/chat')
  }




  const HandleCallEndApi = async () => {
    const CallPayload = {
      call_id: String(selectedUser.senderId), // make sure this is a valid string
    };
    const callEndResponse = await Calls_ends_Api(CallPayload);
    const data = {
      callerId: String(ResUser?.id),
      chat_type: selectedUser.chat_type ? 'Group' : 'User',
      sendercallId: selectedUser.senderId

    }
    ChatController.callbackSocket('callEnded', data)
    navigate('/chat')
  }




  return (
    <LiveKitRoom
      video={true}
      audio={true}
      token={token}
      onDisconnected={() => { HandleCallEndApi() }}
      serverUrl={serverUrl}
      data-lk-theme="default"
      style={{ height: 'calc(100vh - 125px)' }}
    >
      <RoomAudioRenderer />
      <VideoConference chatMessageFormatter={formatChatMessageLinks} />
      {/* <RemoteParticipantsList setRemote={setRemoteParticipants} /> */}
    </LiveKitRoom>
  )
}
