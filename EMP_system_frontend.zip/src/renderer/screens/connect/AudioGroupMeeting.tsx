import {
    LiveKitRoom,
    RoomAudioRenderer,
    useParticipants,
} from '@livekit/components-react'
import { useEffect, useState } from 'react'
import { Button } from "renderer/components/ui/button";
import { useLocation, useNavigate } from 'react-router-dom'
import { Avatar, AvatarImage, AvatarFallback } from "renderer/components/ui/avatar";
import ChatController from 'renderer/Controller/ChatController'
import { Calls_ends_Group_Api, startCallGroup } from 'renderer/service/authService'
import useAuthStore from 'renderer/store/AuthStore'
import '@livekit/components-styles';
import '@livekit/components-styles/prefabs';
import { useChatStore } from 'stores/useChatStore'
import { useRoomContext } from '@livekit/components-react';
import BaseUrl from 'renderer/service/BaseUrl';
import { Users2 } from 'lucide-react';

const serverUrl = BaseUrl.LIVEKIT_URL;
const ResUser = useAuthStore.getState().getUser()


const user = {
    name: "Alice Johnson",
    department: "Sales",
    online: true,
};



function ParticipantCount({ onParticipantUpdate, onRoom }: { onParticipantUpdate: (count: number) => void, onRoom: any }) {
    const participants = useParticipants();
    const livekitRoom = useRoomContext();

    onParticipantUpdate(participants.length);
    onRoom(livekitRoom);
    return (
        <div className="flex text-xs items-center justify-center text-black my-3">
            {participants.length} participant(s) in call
        </div>
    );
}
const LiveUsersToggle = () => {
    const [isOpen, setIsOpen] = useState(false);
    const participants = useParticipants();

    return (
        <div className=" top-2 right-10 z-50">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="bg-white dark:bg-gray-800 p-2 rounded-full shadow hover:bg-gray-100 dark:hover:bg-gray-700 transition"
            >
                <Users2 className="w-5 h-5 text-gray-800 dark:text-gray-100" />
            </button>

            {isOpen && (
                <div className="mt-2 bg-black/80 backdrop-blur-sm p-3 rounded-lg shadow-lg max-w-sm w-60 border border-white/10">
                    <h2 className="text-sm font-bold mb-2 text-white">
                        Live Users ({participants.length})
                    </h2>
                    <ul className="space-y-1 max-h-60 overflow-auto">
                        {participants.map((p) => {
                            const meta = p.metadata ? JSON.parse(p.metadata) : {};
                            const name = meta.name || p.name || p.identity;
                            const avatar =
                                meta.avatar ||
                                'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y';

                            return (
                                <li key={p.identity} className="flex items-center gap-2 text-sm text-white">
                                    <img src={avatar} alt={name} className="w-6 h-6 rounded-full" />
                                    <span>{name}</span>
                                </li>
                            );
                        })}
                    </ul>
                </div>
            )}
        </div>

    );
};

export default function AudioGroupMeeting() {
    const { chatInfo, selectCallerInfo, setSelectCallerInfo, setFlag } = useChatStore()
    const [participantCount, setParticipantCount] = useState(0);
    const [livekitRoom, setLivekitRoom] = useState<any>(null);
    const [isCallStart, setisCallStart] = useState<any>(true);

    const [callStartTime, setCallStartTime] = useState<number | null>(null);
    const [elapsedTime, setElapsedTime] = useState("00:00");
    const location = useLocation()
    const token = location.state?.token
    const selectedUser = location.state?.selectedUser
    const screenType = location.state?.screenType
    const room = location.state?.room
    const navigate = useNavigate()

    useEffect(() => {
        setFlag(false)
        let cleanupFn: (() => void) | undefined;
        const setupSocket = async () => {
            cleanupFn = await SocketHandle();
        };
        setupSocket();
        return () => {
            cleanupFn?.();
        };
    }, []);

    const SocketHandle = async () => {
        let socket: any;

        const handleCallNotification = (data: any) => {
            console.log('call data AudioGroupMeeting', data)
            setCallStartTime(Date.now());
            if (data.senderId === String(ResUser?.id) && isCallStart) {
                handleCall(data);
            }
        };

        const handleCallEndedNotification = (data: any) => {
            navigate('/chat')

        };

        const setupSocketListeners = async () => {
            await waitForSocketReady();
            socket = ChatController.getSocket();
            if (!socket) return;
            socket.on("call-ended", handleCallEndedNotification);
            socket.on("call-accepted", handleCallNotification);
        };

        const cleanupListeners = () => {
            if (!socket) return;
            socket.off("call-ended", handleCallEndedNotification);
            socket.off("call-accepted", handleCallNotification);
        };

        const waitForSocketReady = () => {
            return new Promise<void>((resolve) => {
                if (ChatController.isSocketConnected === 1) return resolve();

                const interval = setInterval(() => {
                    if (ChatController.isSocketConnected === 1) {
                        clearInterval(interval);
                        resolve();
                    }
                }, 300);
            });
        };
        setupSocketListeners();
        return () => {
            cleanupListeners();
        };
    }


    useEffect(() => {
        if (callStartTime === null) return;
        const timer = window.setInterval(() => {
            const duration = Math.floor((Date.now() - callStartTime) / 1000);
            const minutes = Math.floor(duration / 60).toString().padStart(2, "0");
            const seconds = (duration % 60).toString().padStart(2, "0");
            setElapsedTime(`${minutes}:${seconds}`);
        }, 1000);
        return () => clearInterval(timer);
    }, [callStartTime]);



    useEffect(() => {
        const now = Date.now();
        if (screenType === 'ChatLayout' && !callStartTime) {
            setCallStartTime(now);
        }
    }, [screenType]);


    const handleCall = async (callData: any) => {
        const response = await startCallGroup({ group_id: chatInfo?.groupId, caller_id: callData?.senderId || "", call_type: '0' });
        if (response?.data) {
            setSelectCallerInfo(response.data)
            setisCallStart(false)
            ChatController.callbackSocket('rejoinStart', response.data)
        }

    }

    const HandleCallEndApi = async (data: any) => {
        const CallPayload = {
            call_id: selectedUser.senderId,
            group_id: String(selectedUser?.groupId),
        };
        const callEndResponse = await Calls_ends_Group_Api(CallPayload);
        if (callEndResponse.data.success) {
            ChatController.callbackSocket('rejoinEnd', null)
        }
        // setSelectCallerInfo('')
    }


    const handleCallEnd = async () => {

        if (participantCount <= 2) {
            const data = {
                callerId: String(selectedUser.senderId),
                chat_type: 'Group',
            }
            ChatController.callbackSocket('callEnded', data)
            HandleCallEndApi('')

        } else {
            if (livekitRoom) {
                await livekitRoom.disconnect();
            }

            navigate('/chat')
        }
        // setCallEnd(!callEnd)

    };


    return (
        <div className='px-10 py-10 h-screen bg-black align-center flex flex-col items-center'>
            <LiveKitRoom
                audio={true}
                video={false}
                token={token}
                serverUrl={serverUrl}

                connect={true}
                // onConnected={() => HandleStart()}
                onDisconnected={() => handleCallEnd()}
                data-lk-theme="default"
                style={{ height: '0vh' }}
            >

                <ParticipantCount onParticipantUpdate={setParticipantCount} onRoom={setLivekitRoom} />
                <RoomAudioRenderer />
                <LiveUsersToggle />
            </LiveKitRoom>
            <div className="flex flex-col items-center border-2 gap-4 p-56 py-20 rounded-lg bg-secondary">
                <Avatar className="w-20 h-20">
                    <AvatarImage src={`https://i.pravatar.cc/80?u=${user.name}`} alt={user.name} />
                    <AvatarFallback>
                        {selectedUser?.userfullname?.split(" ").map((n: string) => n[0]).join("").toUpperCase()}
                    </AvatarFallback>
                </Avatar>
                <p className="text-lg text-black"> {participantCount > 1 ? `${elapsedTime}` : `Calling ${selectedUser?.userfullname ? `${selectedUser?.firstname} ${selectedUser.lastname ?? ''}` : selectedUser?.name}...`}</p>
                <Button variant="destructive" onClick={() => handleCallEnd()}>
                    End Call
                </Button>
            </div>
        </div>
    )
}
