import {
    LiveKitRoom,
    RoomAudioRenderer,
    useParticipants,
} from '@livekit/components-react'
import { useEffect, useState } from 'react'
import { Button } from "renderer/components/ui/button";
import { useLocation, useNavigate } from 'react-router-dom'
import { Avatar, AvatarImage, AvatarFallback } from "renderer/components/ui/avatar";
import ChatController from 'renderer/Controller/ChatController'
import { Calls_ends_Api, startCall } from 'renderer/service/authService'
import useAuthStore from 'renderer/store/AuthStore'
import '@livekit/components-styles';
import '@livekit/components-styles/prefabs';
import { useChatStore } from 'stores/useChatStore'
import BaseUrl from 'renderer/service/BaseUrl';

const serverUrl = BaseUrl.LIVEKIT_URL;
const ResUser = useAuthStore.getState().getUser()


const user = {
    name: "Alice Johnson",
    department: "Sales",
    online: true,
};



function ParticipantCount({ onParticipantUpdate }: { onParticipantUpdate: (count: number) => void }) {
    const { selectedUser } = useChatStore()
    const participants = useParticipants();
    onParticipantUpdate(participants.length);
    const participantNames = participants[1]?.name ?? `${selectedUser?.firstname} ${selectedUser.lastname ?? ''}`;

    return (
        <div className="flex text-xs items-center justify-center text-black my-3">
            Calling {participantNames?.charAt(0).toUpperCase() + participantNames?.slice(1)}
            {/* {participants.length} participant(s) in call */}
        </div>
    );
}

export default function AudioMeeting() {
    const { chatInfo, selectCallerInfo, selectedUser } = useChatStore()
    const [participantCount, setParticipantCount] = useState(0);
    const [selectcallerId, setSelectcallerId] = useState<'' | null>(null);
    const [hasSentAudioCall, setHasSentAudioCall] = useState(false);

    const [callStartTime, setCallStartTime] = useState<number | null>(null);
    const [seconds, setseconds] = useState<number | null>(null);

    const [elapsedTime, setElapsedTime] = useState("00:00");

    const location = useLocation()
    const token = location.state?.token
    const selectedUserLoc = location.state?.selectedUser
    const screenType = location.state?.screenType
    const navigate = useNavigate()

    useEffect(() => {
        let cleanupFn: (() => void) | undefined;
        const setupSocket = async () => {
            cleanupFn = await SocketHandle();
        };
        setupSocket();
        return () => {
            cleanupFn?.();
        };
    }, [participantCount, callStartTime]);

    const SocketHandle = async () => {
        let socket: any;
        const handleCallNotification = (data: any) => {
            console.log('call data AudioMeeting', data)
            setCallStartTime(Date.now());


        };
        const handleCallEndedNotification = async (data: any) => {
            navigate('/chat')
        }
        const handleStartAudioCallNotification = (data: any) => {
            setSelectcallerId(data.id);
        };

        const setupSocketListeners = async () => {
            await waitForSocketReady();
            socket = ChatController.getSocket();
            if (!socket) return;
            socket.on("call-accepted", handleCallNotification);
            socket.on("call-ended", handleCallEndedNotification);
            socket.on("start-audio-Call", handleStartAudioCallNotification);
        };

        const cleanupListeners = () => {
            if (!socket) return;
            socket.off("call-accepted", handleCallNotification);
            socket.off("call-ended", handleCallEndedNotification);
            socket.off("start-audio-Call", handleStartAudioCallNotification);
        };

        const waitForSocketReady = () => {
            return new Promise<void>((resolve) => {
                if (ChatController.isSocketConnected === 1) return resolve();

                const interval = setInterval(() => {
                    if (ChatController.isSocketConnected === 1) {
                        clearInterval(interval);
                        resolve();
                    }
                }, 300);
            });
        };
        setupSocketListeners();
        return () => {
            cleanupListeners();
        };
    }

    useEffect(() => {
        if (callStartTime === null) return;
        const timer = window.setInterval(() => {
            const duration = Math.floor((Date.now() - callStartTime) / 1000);
            const minutes = Math.floor(duration / 60).toString().padStart(2, "0");
            const seconds = (duration % 60).toString().padStart(2, "0");
            setseconds(Number(seconds))
            setElapsedTime(`${minutes}:${seconds}`);
        }, 1000);
        return () => clearInterval(timer);
    }, [callStartTime]);



    useEffect(() => {
        const now = Date.now();
        if (screenType === 'ChatLayout' && !callStartTime) {
            setCallStartTime(now);
        }
    }, [screenType]);


    const handleCall = async (callData: any) => {
        const response = await startCall({ chat_id: chatInfo?.id, caller_id: callData?.senderId || "", call_type: '0' });
        if (response?.data) {
            setSelectcallerId(response.data.id)
        }
        // const response = await startCall({ chat_id: chatInfo?.id, caller_id: ResUser?.id || "", call_type: '0' });
    }

    const HandleCallEndApi = async (data: any) => {
        const CallPayload = {
            call_id: String(selectedUserLoc.senderId ?? ''),
        };
        const callEndResponse = await Calls_ends_Api(CallPayload);
    }


    const handleCallEnd = () => {
        const data = {
            callerId: String(chatInfo?.id),
            chat_type: 'User',
            sendercallId: selectedUserLoc.senderId
        }
        ChatController.callbackSocket('callEnded', data)
        HandleCallEndApi('')
        navigate('/chat')

        // setCallEnd(!callEnd)

    };
    return (
        <div className='px-10 py-10 h-screen bg-black align-center flex flex-col items-center'>
            <LiveKitRoom
                audio={true}
                video={false}
                token={token}
                serverUrl={serverUrl}
                // onConnected={() => HandleStart()}
                // onDisconnected={() => }
                data-lk-theme="default"
                style={{ height: '0vh' }}
            >

                <ParticipantCount onParticipantUpdate={setParticipantCount} />
                <RoomAudioRenderer />
            </LiveKitRoom>
            <div className="flex flex-col items-center border-2 gap-4 p-56 py-20 rounded-lg bg-secondary">
                <Avatar className="w-20 h-20">
                    <AvatarImage src={`https://i.pravatar.cc/80?u=${user.name}`} alt={user.name} />
                    <AvatarFallback>
                        {selectedUser?.userfullname?.split(" ").map((n: string) => n[0]).join("").toUpperCase()}
                    </AvatarFallback>
                </Avatar>
                <p className="text-lg text-black"> {participantCount > 1 ? `${elapsedTime}` : 'Ringing'}</p>
                <Button variant="destructive" onClick={() => handleCallEnd()}>
                    End Call
                </Button>
            </div>
        </div>
    )
}
