import { formatChatMessageLinks, LiveKitRoom, RoomAudioRenderer, useRoomContext, VideoConference } from '@livekit/components-react';
import React from 'react'
import { useLocation, useNavigate } from 'react-router-dom';
import BaseUrl from 'renderer/service/BaseUrl';
import { LocalVideoTrack } from 'livekit-client';

const serverUrl = BaseUrl.LIVEKIT_URL;
const { App } = window


export async function getScreenShareStream(): Promise<MediaStream> {
    const sources = await window.App.getDesktopSources({ types: ['screen', 'window'] });

    if (!sources || sources.length === 0) {
        throw new Error('No desktop sources available');
    }

    const selectedSource = sources[0];

    const constraints: any = {
        audio: false,
        video: {
            mandatory: {
                chromeMediaSource: 'desktop',
                chromeMediaSourceId: selectedSource.id,
                minWidth: 1280,
                maxWidth: 1920,
                minHeight: 720,
                maxHeight: 1080,
            }
        }
    };

    return await navigator.mediaDevices.getUserMedia(constraints);
}


function CustomShare() {
    const room = useRoomContext();

    const handleShare = async () => {
        try {
            const stream = await getScreenShareStream();
            const [track] = stream.getVideoTracks();
            const localTrack = new LocalVideoTrack(track);
            await room.localParticipant.publishTrack(localTrack);
            console.log('Screen sharing started');
        } catch (err) {
            console.error('Failed to start screen sharing', err);
        }
    };

    return (
        <button onClick={handleShare}>
            Share Screen
        </button>
    )
}

const CustomMeetingRoom = () => {
    const location = useLocation()
    const token = location.state?.token

    const navigate = useNavigate()




    return (
        <>

            <LiveKitRoom
                video={true}
                audio={true}
                token={token}
                onDisconnected={() => { navigate(-1) }}
                serverUrl={serverUrl}
                data-lk-theme="default"
                style={{ height: 'calc(100vh - 125px)' }}
            >
                <RoomAudioRenderer />
                <VideoConference chatMessageFormatter={formatChatMessageLinks} />
                <CustomShare />
                {/* <RemoteParticipantsList setRemote={setRemoteParticipants} /> */}
            </LiveKitRoom>


        </>
    )
}

export default CustomMeetingRoom