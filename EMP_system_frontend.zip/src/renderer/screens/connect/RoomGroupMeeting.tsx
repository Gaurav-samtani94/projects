import {
    LiveKitRoom,
    RoomAudioRenderer,
    VideoConference,
    formatChatMessageLinks,
    useParticipants,
    useRoomContext,
} from '@livekit/components-react'
import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import ChatController from 'renderer/Controller/ChatController'
import { Calls_ends_Group_Api } from 'renderer/service/authService'
import useAuthStore from 'renderer/store/AuthStore'
import '@livekit/components-styles';
import '@livekit/components-styles/prefabs';
import { useChatStore } from 'stores/useChatStore'
import BaseUrl from 'renderer/service/BaseUrl'
import { Users2 } from 'lucide-react'

const serverUrl = BaseUrl.LIVEKIT_URL;
const ResUser = useAuthStore.getState().getUser()


function ParticipantCount({ onParticipantUpdate, onRoom }: { onParticipantUpdate: (count: number) => void, onRoom: any }) {
    const participants = useParticipants();
    const livekitRoom = useRoomContext();

    onParticipantUpdate(participants.length);
    onRoom(livekitRoom);
    return (
        <div className="flex text-xs items-center justify-center text-black my-3">
            {participants.length} participant(s) in call
        </div>
    );
}

const LiveUsersToggle = () => {
    const [isOpen, setIsOpen] = useState(false);
    const participants = useParticipants();

    return (
        <div className="absolute top-2 right-10 z-50">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className=" bg-white dark:bg-gray-800 p-2 rounded-full shadow hover:bg-gray-100 dark:hover:bg-gray-700 transition"
            >
                <Users2 className="w-5 h-5 text-gray-800 dark:text-gray-100" />
            </button>

            {isOpen && (
                <div className="mt-2 bg-black/80 backdrop-blur-sm p-3 rounded-lg shadow-lg max-w-sm w-60 border border-white/10">
                    <h2 className="text-sm font-bold mb-2 text-white">
                        Live Users ({participants.length})
                    </h2>
                    <ul className="space-y-1 max-h-60 overflow-auto">
                        {participants.map((p) => {
                            const meta = p.metadata ? JSON.parse(p.metadata) : {};
                            const name = meta.name || p.name || p.identity;
                            const avatar =
                                meta.avatar ||
                                'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y';

                            return (
                                <li key={p.identity} className="flex items-center gap-2 text-sm text-white">
                                    <img src={avatar} alt={name} className="w-6 h-6 rounded-full" />
                                    <span>{name}</span>
                                </li>
                            );
                        })}
                    </ul>
                </div>
            )}
        </div>

    );
};

export default function RoomGroupMeeting() {
    const { chatInfo, setFlag } = useChatStore()
    const location = useLocation()
    const token = location.state?.token
    const selectedUser = location.state?.selectedUser
    const [participantCount, setParticipantCount] = useState(0);
    const [livekitRoom, setLivekitRoom] = useState<any>(null);
    const [selectcallerId, setSelectcallerId] = useState<'' | null>(null);
    const navigate = useNavigate()


    useEffect(() => {
        setFlag(false)
        let cleanupFn: (() => void) | undefined;
        const setupSocket = async () => {
            cleanupFn = await SocketHandle();
        };
        setupSocket();
        return () => {
            cleanupFn?.();
        };
    }, []);

    const SocketHandle = async () => {
        let socket: any;

        const handleCallEndedNotification = (data: any) => {
            navigate('/chat')
        };

        const setupSocketListeners = async () => {
            await waitForSocketReady();
            socket = ChatController.getSocket();
            if (!socket) return;
            socket.on("call-ended", handleCallEndedNotification);
        };

        const cleanupListeners = () => {
            if (!socket) return;
            socket.off("call-ended", handleCallEndedNotification);
        };

        const waitForSocketReady = () => {
            return new Promise<void>((resolve) => {
                if (ChatController.isSocketConnected === 1) return resolve();
                const interval = setInterval(() => {
                    if (ChatController.isSocketConnected === 1) {
                        clearInterval(interval);
                        resolve();
                    }
                }, 300);
            });
        };
        setupSocketListeners();
        return () => {
            cleanupListeners();
        };
    }

    const HandleCallEndApi = async (data: any) => {
        const CallPayload = {
            call_id: String(selectedUser.senderId),
            group_id: String(selectedUser?.groupId),
        };
        const callEndResponse = await Calls_ends_Group_Api(CallPayload);

        const datas = {
            callerId: String(ResUser?.id),
            chat_type: selectedUser.chat_type ? 'Group' : 'User',
            sendercallId: selectedUser.senderId
        }
        ChatController.callbackSocket('callEnded', datas)

    }


    const handleCallEnd = async () => {
        if (participantCount <= 2) {
            HandleCallEndApi('')
            navigate('/chat')
        } else {
            if (livekitRoom) {
                await livekitRoom.disconnect();
            }
            navigate('/chat')
        }
    };



    return (
        <div className='px-1 py-1 h-screen bg-black align-center flex flex-col items-center'>


            <LiveKitRoom
                video={true}
                audio={true}
                token={token}
                onDisconnected={() => { handleCallEnd(); }}
                serverUrl={serverUrl}
                data-lk-theme="default"
                style={{ height: 'calc(100vh - 125px)' }}
            >
                <RoomAudioRenderer />
                <VideoConference chatMessageFormatter={formatChatMessageLinks} />
                <ParticipantCount onParticipantUpdate={setParticipantCount} onRoom={setLivekitRoom} />
                <LiveUsersToggle />
            </LiveKitRoom>


        </div>
    )
}
