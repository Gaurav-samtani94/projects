"use client"

import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from "renderer/components/ui/dialog"
import { Button } from "renderer/components/ui/button"
import { ScrollArea } from "renderer/components/ui/scroll-area"

interface TermsAndConditionsModalProps {
    isOpen: boolean
    onClose: () => void
}

export function TermsAndConditionsModal({ isOpen, onClose }: TermsAndConditionsModalProps) {
    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-2xl max-h-[90vh]">
                <DialogHeader>
                    <DialogTitle className="text-center text-xl">Terms and Conditions</DialogTitle>
                    <DialogDescription className="text-center">Please read our terms and conditions carefully</DialogDescription>
                </DialogHeader>

                <ScrollArea className="h-[50vh] rounded-md border p-4">
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold">1. Introduction</h3>
                        <p>
                            Welcome to our application. These Terms and Conditions govern your use of our application and provide
                            information about the service we provide, outlined below. When you use our service, you are agreeing to
                            these terms.
                        </p>

                        <h3 className="text-lg font-semibold">2. Data Collection and Privacy</h3>
                        <p>We collect various types of information for the following purposes:</p>
                        <ul className="list-disc pl-6 space-y-2">
                            <li>
                                <strong>Account Information:</strong> We collect information such as your name, email address, and other
                                contact details when you create an account.
                            </li>
                            <li>
                                <strong>Device Information:</strong> We collect information about the device you use to access our
                                service, including hardware model, operating system, unique device identifiers, and mobile network
                                information.
                            </li>
                            <li>
                                <strong>Usage Data:</strong> We collect information about how you use our service, such as the features
                                you use, the time and duration of your activities, and other details about your interaction with our
                                application.
                            </li>
                        </ul>

                        <h3 className="text-lg font-semibold">3. Notifications</h3>
                        <p>By accepting notifications, you agree to receive updates, alerts, and messages related to:</p>
                        <ul className="list-disc pl-6 space-y-2">
                            <li>Account activity and security alerts</li>
                            <li>New features and updates</li>
                            <li>Promotional content (which you can opt out of at any time)</li>
                            <li>Important service announcements</li>
                        </ul>

                        <h3 className="text-lg font-semibold">4. Data Storage</h3>
                        <p>We store your data securely on our servers. By accepting data storage, you agree that we may:</p>
                        <ul className="list-disc pl-6 space-y-2">
                            <li>Store your account information and preferences</li>
                            <li>Cache certain data locally on your device to improve performance</li>
                            <li>Backup your data to prevent loss</li>
                            <li>Retain your data for as long as your account is active or as needed to provide services</li>
                        </ul>

                        <h3 className="text-lg font-semibold">5. User Responsibilities</h3>
                        <p>As a user of our service, you agree to:</p>
                        <ul className="list-disc pl-6 space-y-2">
                            <li>Provide accurate and complete information when creating your account</li>
                            <li>Maintain the security of your account credentials</li>
                            <li>Use the service in compliance with applicable laws and regulations</li>
                            <li>Not engage in any activity that could harm, disable, or impair the service</li>
                        </ul>

                        <h3 className="text-lg font-semibold">6. Termination</h3>
                        <p>
                            We reserve the right to suspend or terminate your access to our service if you violate these Terms and
                            Conditions or if we reasonably believe that you have violated any laws or regulations.
                        </p>

                        <h3 className="text-lg font-semibold">7. Changes to Terms</h3>
                        <p>
                            We may update these Terms and Conditions from time to time. We will notify you of any changes by posting
                            the new Terms and Conditions on this page and updating the "Last Updated" date.
                        </p>

                        <h3 className="text-lg font-semibold">8. Contact Us</h3>
                        <p>If you have any questions about these Terms and Conditions, please contact us at: support@example.com</p>

                        <p className="text-sm text-muted-foreground pt-4">Last Updated: April 17, 2025</p>
                    </div>
                </ScrollArea>

                <DialogFooter>
                    <Button onClick={onClose} className="w-full">
                        I Understand
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}
