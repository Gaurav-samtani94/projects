"use client"

import type React from "react"
import { useState } from "react"
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from "renderer/components/ui/dialog"
import { Button } from "renderer/components/ui/button"
import { Checkbox } from "renderer/components/ui/checkbox"
import { Check, X, Link } from "lucide-react"
import { TermsAndConditionsModal } from "./terms-and-conditions-modal"

interface PermissionsModalProps {
    isOpen: boolean
    onAccept: () => void
    onDeny: () => void
}

export function PermissionsModal({ isOpen, onAccept, onDeny }: PermissionsModalProps) {
    const [permissions, setPermissions] = useState({
        notifications: false,
        deviceInfo: false,
        dataStorage: false,
        termsAndConditions: false,
        privacyPolicy: false,
        fileWritePermission: false,
        fileReadPermission: false,
        knowMoreAboutPermission: false,
    })

    const requiredPermissions: (keyof typeof permissions)[] = [
        "termsAndConditions",
        "privacyPolicy",
        "fileWritePermission",
        "fileReadPermission",
        "knowMoreAboutPermission",
    ]

    const [showTermsModal, setShowTermsModal] = useState(false)

    const allChecked = requiredPermissions.every((key) => permissions[key])

    const handleCheckboxChange = (permission: keyof typeof permissions) => {
        setPermissions((prev) => ({
            ...prev,
            [permission]: !prev[permission],
        }))
    }

    const handleSelectAll = () => {
        setPermissions({
            notifications: true,
            deviceInfo: true,
            dataStorage: true,
            termsAndConditions: true,
            privacyPolicy: true,
            fileWritePermission: true,
            fileReadPermission: true,
            knowMoreAboutPermission: true,
        })
    }

    const openTermsModal = (e: React.MouseEvent) => {
        e.preventDefault()
        setShowTermsModal(true)
    }

    return (
        <>
            <Dialog
                open={isOpen}
                onOpenChange={(open) => {
                    if (!open) onDeny()
                }}
            >
                <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                        <DialogTitle className="text-center text-xl">App Permissions Required</DialogTitle>
                        <DialogDescription className="text-center">
                            Please accept the following permissions to continue
                        </DialogDescription>
                    </DialogHeader>

                    <div className="space-y-4 py-4">
                        <div className="flex items-center space-x-6">
                            <Checkbox
                                id="termsAndConditions"
                                checked={permissions.termsAndConditions}
                                onCheckedChange={() => handleCheckboxChange("termsAndConditions")}
                            />
                            <label htmlFor="termsAndConditions" className="flex gap-2 font-medium cursor-pointer">
                                Terms and Conditions
                                <Link onClick={openTermsModal} className="text-primary w-5 underline hover:text-primary/80">
                                    <span>Read About</span>
                                </Link>
                            </label>
                        </div>
                        <div className="flex items-center space-x-6">
                            <Checkbox
                                id="privacyPolicy"
                                checked={permissions.privacyPolicy}
                                onCheckedChange={() => handleCheckboxChange("privacyPolicy")}
                            />
                            <label htmlFor="privacyPolicy" className="flex gap-2 font-medium cursor-pointer">
                                Privacy Policy
                                <Link onClick={openTermsModal} className="text-primary w-5 underline hover:text-primary/80">
                                    Privacy Policy
                                </Link>
                            </label>
                        </div>
                        <div className="flex items-center space-x-6">
                            <Checkbox
                                id="fileWritePermission"
                                checked={permissions.fileWritePermission}
                                onCheckedChange={() => handleCheckboxChange("fileWritePermission")}
                            />
                            <label htmlFor="fileWritePermission" className="flex gap-2 font-medium cursor-pointer">
                                File Write Permission
                                <Link onClick={openTermsModal} className="text-primary w-5 underline hover:text-primary/80">
                                    File Write Permission
                                </Link>
                            </label>
                        </div>
                        <div className="flex items-center space-x-6">
                            <Checkbox
                                id="fileReadPermission"
                                checked={permissions.fileReadPermission}
                                onCheckedChange={() => handleCheckboxChange("fileReadPermission")}
                            />
                            <label htmlFor="fileReadPermission" className="flex gap-2 font-medium cursor-pointer">
                                File Read Permission
                                <Link onClick={openTermsModal} className="text-primary w-5 underline hover:text-primary/80">
                                    File Read Permission
                                </Link>
                            </label>
                        </div>
                        <div className="flex items-center space-x-6">
                            <Checkbox
                                id="knowMoreAboutPermission"
                                checked={permissions.knowMoreAboutPermission}
                                onCheckedChange={() => handleCheckboxChange("knowMoreAboutPermission")}
                            />
                            <label htmlFor="knowMoreAboutPermission" className="flex gap-2 font-medium cursor-pointer">
                                Know More About Permission
                                <Link onClick={openTermsModal} className="text-primary w-5 underline hover:text-primary/80">
                                    Know More About Permission
                                </Link>
                            </label>
                        </div>
                    </div>

                    <DialogFooter className="flex flex-col sm:flex-row gap-2">
                        <Button variant="outline" onClick={onDeny} className="sm:w-1/3 flex items-center gap-2">
                            <X className="h-4 w-4" />
                            Deny
                        </Button>
                        <Button variant="outline" onClick={handleSelectAll} className="sm:w-1/3 flex items-center gap-2">
                            <Check className="h-4 w-4" />
                            Select All
                        </Button>
                        <Button onClick={onAccept} disabled={!allChecked} className="sm:w-1/3 flex items-center gap-2">
                            <Check className="h-4 w-4" />
                            Continue
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <TermsAndConditionsModal isOpen={showTermsModal} onClose={() => setShowTermsModal(false)} />
        </>
    )
}
