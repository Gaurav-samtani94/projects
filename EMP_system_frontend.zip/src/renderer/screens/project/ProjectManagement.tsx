import { Plus } from "lucide-react"
import AddProjectDrawer from "renderer/components/sections/AddProjectDrawer"
import AddTaskDrawer from "renderer/components/sections/AddTaskDrawer"
import HierarchicalTable from "renderer/components/sections/nLevelTask"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "renderer/components/ui/accordion"
import { Button } from "renderer/components/ui/button"

const ProjectManagement = () => {
    return (
        <div className="overflow-auto w-full">
            <HierarchicalTable taskData={[]} />
        </div>
    )
}

export default ProjectManagement