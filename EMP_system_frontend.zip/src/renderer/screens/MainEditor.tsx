import Editor from './themeEditor'
import { getEditorConfig } from 'renderer/config/editors'

const MainEditor = () => {
    return (
        <Editor config={getEditorConfig("theme")} />
    )
}

export default MainEditor