import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

import ChatController from 'renderer/Controller/ChatController'
import useAuthStore from 'renderer/store/AuthStore'
import Dashboard from 'renderer/components/sections/dashboard/Dashboard'

const { App } = window
export function MainScreen() {
  const user = useAuthStore.getState().getUser();
  const { App } = window
  const navigate = useNavigate();

  useEffect(() => {
    // ConnectUser()
    // check the console on dev tools
    // App.sayHelloFromBridge()
  }, [])
  useEffect(() => {
    App.onNotificationClick((route: any) => {
      navigate('/chat');
    });
  }, []);
  const ConnectUser = async () => {
    console.log('====>>>+++====', user?.id)
    await ChatController.connectUser(user?.id || "")
  }

  const userName = App.username || 'there'

  return (
    <main className="flex flex-col">
      <Dashboard />
    </main>
  )
}
