import React from 'react'

const ChatSetting = () => {
    return (
        <div>ChatSetting</div>
    )
}

export default ChatSetting