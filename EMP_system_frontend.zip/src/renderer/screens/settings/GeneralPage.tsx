import React from 'react'
import { Label } from 'renderer/components/ui/label'
import { Switch } from 'renderer/components/ui/switch'

const GeneralPage = () => {
    return (
        <div className='space-y-8'>
            <div className='flex items-center gap-10'>
                <p className='text-sm font-normal w-[120px]'>Collaboration</p>
                <div className="flex items-center space-x-2 w-[150px]">
                    <Switch id="airplane-mode" />
                    <Label htmlFor="airplane-mode" className='text-sm font-light'>Airplane Mode</Label>
                </div>
                <div className="flex items-center space-x-2 w-[150px]">
                    <Switch id="airplane-mode" />
                    <Label htmlFor="airplane-mode" className='text-sm font-light'>Online</Label>
                </div>
            </div>
            <div className='flex items-center gap-10'>
                <p className='text-sm font-normal w-[120px]'>Email</p>
                <div className="flex items-center space-x-2 w-[150px]">
                    <Switch id="airplane-mode" />
                    <Label htmlFor="airplane-mode" className='text-sm font-light'>SMS</Label>
                </div>
                <div className="flex items-center space-x-2 w-[150px]">
                    <Switch id="airplane-mode" />
                    <Label htmlFor="airplane-mode" className='text-sm font-light'>Video Call</Label>
                </div>
                <div className="flex items-center space-x-2 w-[150px]">
                    <Switch id="airplane-mode" />
                    <Label htmlFor="airplane-mode" className='text-sm font-light'>Airplane Mode</Label>
                </div>
            </div>
        </div>
    )
}

export default GeneralPage