import React, { useState } from 'react'
import { Button } from 'renderer/components/ui/button'
import { Input } from 'renderer/components/ui/input'
import { Label } from 'renderer/components/ui/label'
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    DialogFooter,
} from 'renderer/components/ui/dialog'
import { useForm } from 'react-hook-form'
import { ChangePassword } from 'renderer/service/authService'
import { useMutation } from '@tanstack/react-query'
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from 'renderer/components/ui/form'
import { toast } from 'sonner'
import { validatePassword } from 'renderer/utils/Validations'
import { Eye, EyeOff } from 'lucide-react'
interface ChangePasswordFormValues {
    changePassword: string
    newPassword: string
    renewPassword: string
}

const ChangePasswordForm = () => {
    const [showPassword, setShowPassword] = useState<boolean>(false)
    const [showNewPassword, setShowNewPassword] = useState<boolean>(false)
    const [showConfirmPassword, setShowConfirmPassword] = useState<boolean>(false)
    // Form validation schema
    const form = useForm<ChangePasswordFormValues>({
        defaultValues: {
            changePassword: '',
            newPassword: '',
            renewPassword: '',
        },
        mode: 'onBlur',
    })

    const changePasswordMutation = useMutation({
        mutationFn: ChangePassword,
        onSuccess: (data) => {
            console.log('Password changed successfully:', data)
            toast.success('Password changed successfully')
        },
        onError: (error) => {
            console.error('Error changing password:', error)
            toast.error('Error changing password')
        },
    })

    const onSubmit = (values: ChangePasswordFormValues) => {
        changePasswordMutation.mutate({
            oldPassword: values.changePassword,
            newPassword: values.newPassword,
            confirmPassword: values.renewPassword,
        })
    }

    return (
        <div className='flex flex-col gap-6'>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)}>
                    <FormField
                        control={form.control}
                        name="changePassword"
                        rules={{
                            validate: validatePassword,
                        }}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel className="mt-4 mb-1">Current Password</FormLabel>
                                <FormControl className='w-sm'>
                                    <div className="relative">
                                        <Input
                                            id="changePassword"
                                            placeholder="Enter Current Password"
                                            type={showPassword ? 'text' : 'password'}
                                            {...field}
                                            disabled={changePasswordMutation.isPending}
                                            className="pr-10"
                                        />
                                        <button
                                            type="button"
                                            onClick={() => setShowPassword((prev) => !prev)}
                                            className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
                                            tabIndex={-1}
                                        >
                                            {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                        </button>
                                    </div>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    {/* Dialog for Forget Password */}
                    <Dialog>
                        <DialogTrigger asChild>
                            <button className="text-xs text-primary hover:text-primary/80 text-left">
                                Forget Password?
                            </button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-md">
                            <DialogHeader>
                                <DialogTitle>Reset Your Password</DialogTitle>
                                <DialogDescription>
                                    We'll send you instructions to reset your password.
                                </DialogDescription>
                            </DialogHeader>
                            <DialogFooter>
                                <Button type="submit">Send Reset Link</Button>
                            </DialogFooter>
                        </DialogContent>
                    </Dialog>

                    <FormField
                        control={form.control}
                        name="newPassword"
                        rules={{
                            validate: validatePassword,
                        }}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel className='mt-4 mb-1'>New Password</FormLabel>
                                <FormControl className='w-sm'>
                                    <div className="relative">
                                        <Input
                                            id="newPassword"
                                            placeholder="Enter New Password"
                                            type={showNewPassword ? 'text' : 'password'}
                                            {...field}
                                            disabled={changePasswordMutation.isPending}
                                            className="pr-10"
                                        />
                                        <button
                                            type="button"
                                            onClick={() => setShowNewPassword((prev) => !prev)}
                                            className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
                                            tabIndex={-1}
                                        >
                                            {showNewPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                        </button>
                                    </div>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />

                    <FormField
                        control={form.control}
                        rules={{
                            validate: validatePassword,
                        }}
                        name="renewPassword"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel className='mt-4 mb-1'>Confirm Password</FormLabel>
                                <FormControl className='w-sm'>
                                    <div className="relative">
                                        <Input id="renewPassword" placeholder="Enter Confirm Password"
                                            type={showConfirmPassword ? 'text' : 'password'}
                                            {...field}
                                            disabled={changePasswordMutation.isPending}
                                            className='pr-10' />
                                        <button
                                            type="button"
                                            onClick={() => setShowConfirmPassword((prev) => !prev)}
                                            className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground"
                                            tabIndex={-1}
                                        >
                                            {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                        </button>
                                    </div>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <div className='flex items-center gap-4'>
                        <Button type="submit" className="w-fit mt-8" disabled={changePasswordMutation.isPending} >Change Password</Button>
                        <Button type="button" variant='outline' className="w-fit mt-8" disabled={changePasswordMutation.isPending} >Reset</Button>
                    </div>
                </form>
            </Form >
        </div >
    )
}

export default ChangePasswordForm
