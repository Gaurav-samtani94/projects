import { useQuery } from '@tanstack/react-query'
import React from 'react'
import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger
} from 'renderer/components/ui/accordion'
import {
    Avatar,
    AvatarFallback,
    AvatarImage
} from 'renderer/components/ui/avatar'
import { UserTeamList } from 'renderer/service/authService'

const TeamView = () => {
    const { data, isLoading, isError } = useQuery({
        queryKey: ['user-team-list'],
        queryFn: UserTeamList
    })

    if (isLoading) return <p>Loading team data...</p>
    if (isError) return <p>Error fetching team data.</p>

    return (
        <div>
            <h2 className='text-2xl font-bold mb-4'>Team View Details</h2>
            <Accordion type="single" collapsible className="w-full">
                {data?.data?.map((user: any, index: number) => (
                    <AccordionItem key={user.id} value={`item-${index}`}>
                        <AccordionTrigger>
                            <div className="flex items-center gap-4">
                                <Avatar>
                                    <AvatarImage
                                        src="/default-avatar.png"
                                        alt={`@${user.userfullname}`}
                                    />
                                    <AvatarFallback>
                                        {user.userfullname?.slice(0, 2).toUpperCase()}
                                    </AvatarFallback>
                                </Avatar>
                                <div>
                                    <p className="font-medium">{user.userfullname}</p>
                                    <p className="text-sm text-gray-500">{user.position_name || 'No designation'}</p>
                                </div>
                            </div>
                        </AccordionTrigger>
                        <AccordionContent>
                            <p>Email: {user.emailaddress || 'N/A'}</p>
                            <p>Contact: {user.contactnumber || 'N/A'}</p>
                            <p>Department: {user.department_name || 'N/A'}</p>

                            {/* Nested Accordion for child users */}
                            {user.childUser && user.childUser.length > 0 && (
                                <Accordion type="single" collapsible className="mt-4 pl-4 border-l border-muted">
                                    {user.childUser.map((childUser: any, childIndex: number) => (
                                        <AccordionItem key={childUser.id} value={`sub-item-${childIndex}`}>
                                            <AccordionTrigger>
                                                <div className="flex items-center gap-4">
                                                    <Avatar>
                                                        <AvatarImage src="/default-avatar.png" alt={`@${childUser.userfullname}`} />
                                                        <AvatarFallback>{childUser.userfullname?.slice(0, 2).toUpperCase()}</AvatarFallback>
                                                    </Avatar>
                                                    <div>
                                                        <p className="font-medium">{childUser.userfullname}</p>
                                                        <p className="text-sm">{childUser.position_name || 'No designation'}</p>
                                                    </div>
                                                </div>
                                            </AccordionTrigger>
                                            <AccordionContent>
                                                <ul className="list-disc ml-6 text-sm">
                                                    <p>Email: {childUser.emailaddress || 'N/A'}</p>
                                                    <p>Contact: {childUser.contactnumber || 'N/A'}</p>
                                                    <p>Department: {childUser.department_name || 'N/A'}</p>
                                                </ul>
                                            </AccordionContent>
                                        </AccordionItem>
                                    ))}
                                </Accordion>
                            )}
                        </AccordionContent>
                    </AccordionItem>
                ))}
            </Accordion>
        </div>
    )
}

export default TeamView
