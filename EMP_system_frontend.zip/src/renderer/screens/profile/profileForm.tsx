"use client";
import { useQuery } from '@tanstack/react-query';
import React, { useState } from 'react';
import { Separator } from 'renderer/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from 'renderer/components/ui/tabs';
import { UserPersonalDetail, UserOtherDetail } from 'renderer/service/authService';
import { date } from 'zod';

export function ProfileForm() {

    const { data } = useQuery({
        queryKey: ['userOtherDetail'],
        queryFn: () => UserOtherDetail()
    })

    const { data: dataPersonal } = useQuery({
        queryKey: ['userPersonalDetail'],
        queryFn: () => UserPersonalDetail()
    })

    return (

        <div className="space-y-6 w-full">
            <Tabs defaultValue="offical" className="w-full">
                <TabsList className='w-full p-0'>
                    <TabsTrigger value="offical" className='w-full'>Offical Details</TabsTrigger>
                    <TabsTrigger value="personal" className='w-full'>Personal Details</TabsTrigger>
                </TabsList>
                <div className="space-y-6 mt-7">
                    <TabsContent value="offical">
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Employee Code : </h4>
                                <p className='text-muted-foreground font-normal text-md'>{data?.data?.hrmsOtherOfficialData?.employeeId ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Title : </h4>
                                <p className='text-muted-foreground font-normal text-md'>{data?.data?.user_title ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>First Name : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.firstname ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Last Name : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.lastname ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Official Email : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.emailaddress ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Business Unit : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.businessunit_name ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Reporting Manager (IO) :</h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.reporting_manager_name ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Reporting Manager (RO) : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.reporting_managerRo_name ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Role :</h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.emprole_name ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Job Group :</h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.job_group ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Designation :</h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.jobtitle_name ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Employment Status :</h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.employment_status ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Department :</h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.department_name ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Sub Department :</h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.hrmsOtherOfficialData?.sub_department ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Date of Joining :</h4>
                                <p className="text-muted-foreground font-normal text-md w-1/2">
                                    {data?.data?.date_of_joining
                                        ? new Date(data.data.date_of_joining).toLocaleDateString('en-US', {
                                            day: '2-digit',
                                            month: 'short',
                                            year: 'numeric',
                                        })
                                        : '-'}
                                </p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Total Experience : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>
                                    {data?.data?.years_exp
                                        ? new Date(data.data.years_exp).toLocaleDateString('en-US', {
                                            day: '2-digit',
                                            month: 'short',
                                            year: "numeric",
                                        })
                                        : '-'}
                                </p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Contact Number : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.contactnumber ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Extension : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.extension_number ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Probation Period :</h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.probation_period_no ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Notice Period : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>{data?.data?.noticeperiod ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Date of Leaving : </h4>
                                <p className='text-muted-foreground font-normal text-md w-1/2'>
                                    {data?.data?.date_of_leaving
                                        ? new Date(data.data.date_of_leaving).toLocaleDateString('en-US', {
                                            day: '2-digit',
                                            month: 'short',
                                            year: 'numeric'
                                        })
                                        : '-'}
                                </p>
                            </div>
                        </div>
                    </TabsContent>
                </div>
                <div className="space-y-6">
                    <TabsContent value="personal">
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Mother's Name :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.mother_nm ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Mother's Contact No : </h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.mothers_contact_no ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Father's Name :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.father_nm ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Father's Contact No : </h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.fathers_contact_no ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Gender :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.genderDetails ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Marital Status :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.maritalstatusid ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Marriage Date (If Married) :</h4>
                                <p className='text-muted-foreground font-normal text-md'>
                                    {dataPersonal?.data?.marriage_date
                                        ? new Date(dataPersonal.data.marriage_date).toLocaleDateString('en-US', {
                                            day: '2-digit',
                                            month: 'short',
                                            year: 'numeric'
                                        })
                                        : '-'}
                                </p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Spouse Name :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.spouse_name ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Spouse Contact No :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.spouse_contact_no ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Spouse Occupation :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.spouse_occupation ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Nationality :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.nationalityid ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Mother Tongue :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.language_known ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Religion :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.religion ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Date of Birth :</h4>
                                <p className='text-muted-foreground font-normal text-md'>
                                    {dataPersonal?.data?.dob
                                        ? new Date(dataPersonal.data.dob).toLocaleDateString('en-US', {
                                            day: '2-digit',
                                            month: 'short',
                                            year: 'numeric'
                                        })
                                        : '-'}
                                </p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Blood Group :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.bloodgroup ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Height (cm) :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.height_in_cm ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Weight :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.weight ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Passport No. :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.passport_no ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Pan No. :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.pan_no ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Driving License No. :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.driving_license_no ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Ration Card :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.ration_card ?? '-'}</p>
                            </div>
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Aadhar No. :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.aadhar_no_enrolment ?? '-'}</p>
                            </div>
                        </div>
                        <Separator />
                        <div className="grid grid-cols-2 my-5">
                            <div className="flex gap-3 items-center">
                                <h4 className='font-normal text-md'>Skype ID :</h4>
                                <p className='text-muted-foreground font-normal text-md'>{dataPersonal?.data?.skypee_id ?? '-'}</p>
                            </div>
                        </div>
                    </TabsContent>
                </div>
            </Tabs>
        </div>

    );
}
