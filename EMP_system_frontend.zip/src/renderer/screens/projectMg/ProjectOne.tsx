"use client"
import React, { useEffect, useMemo, useRef, useState } from 'react'
import { zodResolver } from "@hookform/resolvers/zod"
import { format } from "date-fns"
import { CalendarIcon, Check, ClipboardPlus, Download, Edit, Eye, FolderCode, FormInput, GripVertical, Plus, SlidersHorizontal, Trash2 } from 'lucide-react'
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Button } from "renderer/components/ui/button"
import { Calendar } from "renderer/components/ui/calendar"
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "renderer/components/ui/form"
import { Input } from "renderer/components/ui/input"
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "renderer/components/ui/popover"
import RichText from 'renderer/components/ui/RichText'
import {
    Tabs,
    TabsContent,
    TabsList,
    TabsTrigger,
} from "renderer/components/ui/tabs"
import { cn } from "renderer/lib/utils"
import CommentBox from '../../components/sections/CommentBox'
import { Avatar, AvatarFallback, AvatarImage } from 'renderer/components/ui/avatar'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from 'renderer/components/ui/dialog'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from 'renderer/components/ui/command'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from 'renderer/components/ui/card'
import CreateTemplate from 'renderer/components/sections/Project/create-template'
import { ScrollArea, ScrollBar } from 'renderer/components/ui/scroll-area'
import {
    Sheet,
    SheetClose,
    SheetContent,
    SheetDescription,
    SheetFooter,
    SheetHeader,
    SheetTitle,
    SheetTrigger,
} from "renderer/components/ui/sheet"
import type { TaskRowTypes as Row } from 'Types/Tasks';
import { RenderRows } from '../../components/sections/TaskRaw';
import {
    SortableContext,
    verticalListSortingStrategy,
    useSortable,
    arrayMove,
} from '@dnd-kit/sortable';
import { Label } from 'renderer/components/ui/label'
import { Checkbox } from 'renderer/components/ui/checkbox'
import { Tooltip, TooltipContent, TooltipTrigger } from 'renderer/components/ui/tooltip'
import HierarchicalTable from 'renderer/components/sections/nLevelTask'
import AddCustomColumn from 'renderer/components/sections/Project/AddCustomColumn'
import { useLocation } from 'react-router-dom'
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from 'renderer/components/ui/select'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { GetUser } from 'renderer/service/authService'
import useAuthStore from 'renderer/store/AuthStore'
import { createTask, defaultProjectsFields, deleteAttachments, deleteCustomFields, updateDefaultOptionsOrder, updateProjects, uploadAttachments, fetchFiltersList } from 'renderer/service/project'

import { toast } from 'sonner'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from 'renderer/components/ui/table'
// import { useMutation } from '@tanstack/react-query'
import { getTaskList } from 'renderer/service/project'
import { FacetedFilter } from 'renderer/components/sections/FactedFilter'
import { Switch } from 'renderer/components/ui/switch'
import { priorities, statuses } from 'renderer/utils/taskData'
import { useVirtualizer } from '@tanstack/react-virtual'
import AddCustomModal from 'renderer/components/sections/AddCustomModal'
import { closestCenter, DndContext, PointerSensor, useSensor, useSensors } from '@dnd-kit/core'
import { CSS } from '@dnd-kit/utilities';
import BaseUrl from 'renderer/service/BaseUrl'
import { MultiSelectFilter } from 'renderer/components/sections/MultiSelectFilter'
import DynamicAvatarGroup from 'renderer/components/sections/DynamicAvatarGroups'
import ChatController from 'renderer/Controller/ChatController'

const formSchema = z.object({
    name: z.string().min(1, {
        message: "Project name must be at least one characters.",
    }),
    priority: z.string().min(1, {
        message: "Please select atleast one priority.",
    }),
    status: z.string().optional(),
    owner: z.string().optional(),
    images: z.any().optional(),
    description: z.string().optional(),
    extTime: z.string()
        .optional()
        .refine((val) => {
            if (!val) return true;
            const regex = /^(\d+w)?\s*(\d+d)?\s*(\d+h)?\s*(\d+m)?$/;
            return regex.test(val.trim());
        }, {
            message: "Please enter a valid format like 15w 10d 5h 2m.",
        }),
    startDate: z.date().nullable().optional(),
    endDate: z.date().nullable().optional(),
})

// === Initial Data ===
const initialRows: Row[] = [
    {
        id: '1',
        name: 'Marketing',
        status: {
            color: "#dc2626",
            label: 'Not Started',
            id: "1"
        },
        priority: {
            color: "#dc2626",
            label: 'High',
            id: "1"
        },
        children: [
            {
                id: '1-1',
                name: 'Social Media Campaign',
                status: {
                    color: "#dc2626",
                    label: 'Not Started',
                    id: "1"
                },
                priority: {
                    color: "#dc2626",
                    label: 'High',
                    id: "1"
                },
                children: [
                    {
                        id: '1-1-1',
                        name: 'Content Creation',
                        status: {
                            color: "#dc2626",
                            label: 'Not Started',
                            id: "1"
                        },
                        priority: {
                            color: "#dc2626",
                            label: 'High',
                            id: "1"
                        },
                        children: []
                    },
                    {
                        id: '1-1-2',
                        name: 'Scheduling',
                        status: {
                            color: "#dc2626",
                            label: 'Not Started',
                            id: "1"
                        },
                        priority: {
                            color: "#dc2626",
                            label: 'High',
                            id: "1"
                        },
                        children: []
                    }
                ]
            },
            {
                id: '1-2',
                name: 'Email Newsletter',
                status: {
                    color: "#dc2626",
                    label: 'Not Started',
                    id: "1"
                },
                priority: {
                    color: "#dc2626",
                    label: 'High',
                    id: "1"
                },
                children: []
            }
        ]
    },
    {
        id: '2',
        name: 'Development',
        status: {
            color: "#dc2626",
            label: 'Not Started',
            id: "1"
        },
        priority: {
            color: "#dc2626",
            label: 'High',
            id: "1"
        },
        children: [
            {
                id: '2-1',
                name: 'Frontend Updates',
                status: {
                    color: "#dc2626",
                    label: 'Not Started',
                    id: "1"
                },
                priority: {
                    color: "#dc2626",
                    label: 'High',
                    id: "1"
                },
                children: []
            },
            {
                id: '2-2',
                name: 'Backend API',
                status: {
                    color: "#dc2626",
                    label: 'Not Started',
                    id: "1"
                },
                priority: {
                    color: "#dc2626",
                    label: 'High',
                    id: "1"
                },
                children: []
            }
        ]
    }
];


function SortableItem({ field, onEdit, onDelete }: any) {
    const {
        attributes,
        listeners,
        setNodeRef,
        setActivatorNodeRef,
        transform,
        transition
    } = useSortable({ id: field.id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition
    };

    return (
        <div
            ref={setNodeRef}
            style={style}
            className="flex w-full items-center space-x-2"
        >
            {/* Drag Handle */}
            <div ref={setActivatorNodeRef} {...listeners} {...attributes} className="cursor-grab text-muted-foreground">
                <GripVertical className="size-5" />
            </div>

            <Input value={field?.label_name} className="p-5" readOnly />

            {field?.type?.field_value_type === 2 && field?.is_default === 1 && (
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="outline"
                            type="button"
                            className="p-5"
                            onClick={() => onEdit(field)}
                        >
                            <Edit className="size-5" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>Edit {field.label_name} Options</TooltipContent>
                </Tooltip>
            )}

            {field?.is_default === 1 && field.label_name !== 'Status' && field.label_name !== 'Priority' && (
                <Tooltip>
                    <TooltipTrigger asChild>
                        <Button
                            variant="destructive"
                            type="button"
                            className="p-5"
                            onClick={() => onDelete(field.id)}
                        >
                            <Trash2 className="size-5" />
                        </Button>
                    </TooltipTrigger>
                    <TooltipContent>Delete {field.label_name}</TooltipContent>
                </Tooltip>
            )}
        </div>
    );
}



const flattenRows = (rows: Row[]): Row[] =>
    rows?.flatMap(row => [row, ...flattenRows(row.children)]);

const ProjectOne = () => {
    const [rows, setRows] = useState<Row[]>(initialRows);
    const [tableHeads, setTableHeads] = useState<Row[]>([]);
    const [expanded, setExpanded] = useState<string[]>(['1']);
    const [columnName, setColumnName] = useState("");
    const [typeId, setTypeId] = useState('')
    const [initialColumnName, setInitialColumnName] = useState("");
    const [open, setOpen] = useState(false);
    const [selectedType, setSelectedType] = useState<string | null>(null);
    const [statusFiltering, setStatusFiltering] = useState<any>([]);
    const [priorityFiltering, setPriorityFiltering] = useState<any>([]);
    const [selectedUsers, setSelectedUsers] = React.useState<any[]>([])
    const [selectedProjectLeads, setSelectedProjectLeads] = React.useState<any[]>([])

    const location = useLocation()
    const token = useAuthStore.getState().getToken();
    const [projectCreated, setProjectCreated] = useState<any>('')
    const { App } = window
    const queryClient = useQueryClient();
    const projectDetail = location?.state?.projectDetails;
    const fileInputRef = useRef<HTMLInputElement>(null);
    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            name: "",
            description: "",
            priority: '',
            status: '',
            images: [],
            extTime: '',
            endDate: null,
        },
    })
    const startDate = form.watch("startDate");
    const user = useAuthStore.getState().getUser();



    function onSubmit(values: z.infer<typeof formSchema>) {
        const formData = new URLSearchParams();

        formData.append("project_id", projectDetail?.team?.project_id ?? "");
        formData.append("estimated_time", String(values?.extTime));
        formData.append("project_name", values?.name);
        formData.append("description", values?.description ?? "");
        formData.append("priority", values?.priority);
        formData.append("project_status", String(values?.status));
        formData.append("user_ids", String(selectedUsers));
        formData.append("project_lead_ids", String(selectedProjectLeads));
        if (values.startDate) {
            formData.append("start_date", values.startDate.toISOString().split("T")[0]);
        }

        if (values.endDate) {
            formData.append("end_date", values.endDate.toISOString().split("T")[0]);
        }

        // for (let i = 0; i < selectedImages.length; i++) {
        //     formData.append("files", selectedImages[i]);
        // }
        updateProjectMutation.mutate(formData);
    }

    const { data: membersList, isSuccess } = useQuery({
        queryKey: ["userList"],
        queryFn: () => GetUser(),
        enabled: !!token
    })



    useEffect(() => {
        const userIdsInTeam = projectDetail?.team?.user_ids
            ?.split(",")
            ?.map((id: any) => Number(id.trim())) || [];

        setSelectedUsers(userIdsInTeam);
        const pLeadIds = projectDetail?.project_lead_ids?.split(",")?.map((id: any) => Number(id.trim())) || [];
        setSelectedProjectLeads(pLeadIds);
        const ownerName = membersList?.data?.find((item: any) => (item?.id === projectDetail?.created_by))?.userfullname;
        setProjectCreated(ownerName)

    }, [projectDetail]);

    const toggleExpand = (id: string) => {
        setExpanded(prev => prev?.includes(id) ? prev?.filter(i => i !== id) : [...prev, id]);
    };

    useEffect(() => {
        if (projectDetail) {
            form.setValue("name", projectDetail?.project_name ?? "");
            form.setValue("description", projectDetail?.description ?? "");
            form.setValue("priority", projectDetail?.priority);
            form.setValue("status", projectDetail?.project_status);
            form.setValue("extTime", projectDetail?.estimated_time ?? '');
            if (projectDetail?.start_date) {
                form.setValue("startDate", new Date(projectDetail.start_date));
            } else {
                form.setValue("startDate", null);
            }

            if (projectDetail?.end_date) {
                form.setValue("endDate", new Date(projectDetail.end_date));
            } else {
                form.setValue("endDate", null);
            }

            if (projectDetail?.attachment?.length > 0) {
                const normalizedAttachments = projectDetail?.attachment?.map((file: any) => ({
                    id: file?.id,
                    name: file?.file_name,
                    path: `${BaseUrl?.Url_Base}/${file?.file_path}`,
                    size: file?.file_size,
                }));
                setSelectedImages(normalizedAttachments);
            } else {
                setSelectedImages([])
            }


        }

    }, [form, projectDetail]);
    console.log(projectDetail, "projectDetail")

    const updateProjectMutation = useMutation({
        mutationFn: updateProjects,
        onSuccess: (response, variable) => {
            ChatController.callbackSocket('project', {
                user_ids: variable?.user_ids,
                project_id: response?.data?.id,
                is_project: 'update',
                created_by: user?.id
            });
            toast.success('Project updated successfully')
            queryClient.invalidateQueries({ queryKey: ['projectList'] });
        },
        onError: (error: any) => {
            toast.error(error?.message)
        },
    })

    const { data: defaultList, refetch } = useQuery({
        queryKey: ["defaultList", projectDetail?.id],
        queryFn: () => defaultProjectsFields({ project_id: projectDetail?.team?.project_id }),
    })

    const deleteCustomFieldMutation = useMutation({
        mutationFn: deleteCustomFields,
        onSuccess: (response) => {
            refetch()
            refetchTaskList()
            toast.success(response?.message)
        },
        onError: (error: any) => {
            toast.error('Project creation failed', {
                description: error.message,
            })
        },
    })

    const deleteCustomField = (id: any) => {
        deleteCustomFieldMutation.mutate({
            project_id: projectDetail?.team?.project_id,
            field_id: id
        })
    }
    const [selectedImages, setSelectedImages] = useState<File[]>([]);
    console.log(selectedImages, "selectedImages")
    const [getNewTask, setNewTask] = useState('');
    const [getData, setData] = useState<any>(null);

    const uploadAttachmentsMutation = useMutation({
        mutationFn: uploadAttachments,
    })

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        console.log(files, "files")
        if (files && files.length > 0) {
            const fileList = Array.from(files);
            const formData = new FormData();
            fileList.forEach((file) => {
                formData.append("files", file);
            });
            formData.append("project_id", projectDetail?.id);
            uploadAttachmentsMutation.mutate(formData, {
                onSuccess: (response) => {
                    const normalizedAttachments = response?.data?.map((file: any) => ({
                        id: file?.id,
                        name: file?.file_name,
                        path: `${BaseUrl?.Url_Base}/${file?.file_path}`,
                        size: file?.file_size,
                    }));
                    setSelectedImages((prev) => [...prev, ...normalizedAttachments]);
                    toast.success(response?.message);
                    queryClient.invalidateQueries({ queryKey: ['projectList'] });
                },
                onError: (error: any) => {
                    toast.error(error?.message);
                },
            });
        }
    };

    const deleteImagesMutation = useMutation({
        mutationFn: deleteAttachments
    })

    const removeImage = (id: any) => {
        deleteImagesMutation?.mutate({
            attachment_id: id
        }, {
            onSuccess: (response) => {
                toast.success(response?.message);
                const updatedFiles = selectedImages.filter((file: any) => file.id !== id);
                setSelectedImages(updatedFiles);
                if (updatedFiles.length === 0 && fileInputRef.current) {
                    fileInputRef.current.value = '';
                }
                queryClient.invalidateQueries({ queryKey: ['projectList'] });
            },
            onError: (error: any) => {
                toast.error(error?.message);
            },
        })
    };

    const { data: taskList, refetch: refetchTaskList, isError } = useQuery({
        queryKey: ["taskList", projectDetail?.id],
        queryFn: () => getTaskList({ project_id: projectDetail?.id }),
    })

    const { data: filtersList, refetch: refetchFiltersList, isError: IsErrorInFilterList } = useQuery({
        queryKey: ["filtersList", projectDetail?.id],
        queryFn: () => fetchFiltersList({ project_id: projectDetail?.id }),
    })

    useEffect(() => {
        setData(taskList)
    }, [taskList])

    const mutationCreateTask = useMutation({
        mutationFn: createTask,
        onSuccess: response => {
            if (response?.status == 1) {
                setNewTask('');
                refetchTaskList();
            }

        },
        onError: error => {
            console.log('error', error);
        }
    })

    // To Create the Task.
    const handleCreateTask = () => {
        if (getNewTask?.length) {
            mutationCreateTask.mutate({ project_id: projectDetail?.id, sr_no: 1, parent_id: 0, task_name: getNewTask })
        }
        else {
            alert('Please enter the Task name')
        }
    }
    const updateOrderMutation = useMutation({
        mutationFn: updateDefaultOptionsOrder,
        onSuccess: () => {
            refetchTaskList();
        }
    })

    const [items, setItems] = useState([]);

    useEffect(() => {
        const filteredList = defaultList?.data?.filter((item: any) => item?.config_detail !== 'rich_text') || [];
        setItems(filteredList.sort((a: any, b: any) => a.sr_no - b.sr_no))
    }, [defaultList?.data])
    const sensors = useSensors(useSensor(PointerSensor));

    const handleDragEnd = (event: any) => {
        const { active, over } = event;
        if (active.id !== over.id) {
            const oldIndex = items.findIndex((item: any) => item.id === active.id);
            const newIndex = items.findIndex((item: any) => item.id === over.id);
            const reordered = arrayMove(items, oldIndex, newIndex);
            const payload = {
                project_id: projectDetail?.id,
                data: JSON.stringify(reordered.map((item: any) => item?.id))
            };
            updateOrderMutation.mutate(payload)
            setItems(arrayMove(items, oldIndex, newIndex));
        }
    };

    const handleDownload = (url: string | null) => {
        if (!url) {
            console.warn("No URL provided for download.");
            return;
        }

        try {
            const filename = url?.split('/').pop();
            if (!filename) {
                console.error("Filename could not be determined from URL.");
                return;
            }

            App.downloadFile(url, filename);
            App.onDownloadComplete((_event, data) => {
                if (data.success) {
                    toast.success("File downloaded!");
                } else {
                    toast.error("Download failed.");
                    console.error("❌ Download failed:", data.error);
                }
            });

        } catch (error) {
            console.error("Error during download:", error);
        }
    };

    const previewDoc = async (url: string) => {
        console.log("Previewing document:", url);
        const fileUrl = url;

        try {
            // Fetch image as a blob
            // const response = await fetch(fileUrl, {
            //     method: 'GET',
            //     mode: 'no-cors'
            // });

            // if (!response.ok) {
            //     throw new Error("Failed to fetch the image");
            // }

            // Convert the response into a Blob
            // const blob = await response.blob();
            // const url = window.URL.createObjectURL(blob);
            const filename = url?.split('/').pop();
            // Create an anchor element and simulate a click to trigger the download
            const a = document.createElement("a");
            a.href = fileUrl;
            a.target = "_blank"; // Open in a new tab
            a.download = filename || "download"; // Provide a default name if not available
            document.body.appendChild(a);
            a.click(); // Trigger the download
            a.remove(); // Clean up the DOM
            // window.URL.revokeObjectURL(url); // Revoke the object URL
        } catch (error) {
            console.error("Download failed:", error);
        }
    };
    // Filter task list by Status & Priority
    const filteredData = useMemo(() => {
        if (!getData?.data) return [];
        const hasStatusFilter = statusFiltering?.size > 0;
        const hasPriorityFilter = priorityFiltering?.size > 0;
        if (!hasStatusFilter && !hasPriorityFilter) {
            return getData.data;
        }
        return getData?.data?.filter((item: any) => {
            const statusMatch = !hasStatusFilter || item?.task_fields.some((field: any) =>
                field.type_key_id == filtersList?.data?.project_status[0]?.type_key_id && statusFiltering?.has(Number(field.select_val))
            );
            const priorityMatch = !hasPriorityFilter || item.task_fields?.some((field: any) =>
                field.type_key_id == filtersList?.data?.project_priority[0]?.type_key_id && priorityFiltering.has(Number(field.select_val))
            );
            return statusMatch && priorityMatch;
        });
    }, [getData, statusFiltering, priorityFiltering]);


    return (
        <div className='p-6 max-w-full'>
            <Tabs defaultValue="info" className='max-w-full'>
                <TabsList>
                    <TabsTrigger value="info" className='!px-20'>Info</TabsTrigger>
                    <TabsTrigger value="task" className='!px-20'>Task</TabsTrigger>
                    {/* <TabsTrigger value="report" className='!px-20'>Report</TabsTrigger> */}
                </TabsList>
                <hr className='mt-3' />
                <TabsContent value="info" >
                    <div className='flex gap-5'>
                        <div className=' w-[70%] mt-6 mb-6'>
                            <Form {...form}>
                                <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-12 gap-6">
                                    <div className='col-span-12'>
                                        <div className="flex gap-6 items-center">
                                            <div>
                                                <p className='mb-2'>Project Members</p>
                                                <div className='flex gap-4 items-center'>
                                                    {/* <div className="flex items-center space-x-[-12px]">
                                                        {membersList?.data?.filter((item: any) => selectedUsers?.includes(item?.id))?.slice(0, 2)?.map((showMembers: any) => (
                                                            <Avatar className="size-10">
                                                                <AvatarImage src="" alt="@shadcn" />
                                                                <AvatarFallback>{showMembers?.userfullname[0]?.toUpperCase()}</AvatarFallback>
                                                            </Avatar>
                                                        ))}

                                                        {selectedUsers?.length > 2 &&
                                                            <Popover>
                                                                <PopoverTrigger asChild>
                                                                    <button type="button">
                                                                        <Avatar className="size-10 cursor-pointer">
                                                                            <AvatarFallback className="text-sm font-semibold">+{selectedUsers?.length - 2}</AvatarFallback>
                                                                        </Avatar>
                                                                    </button>
                                                                </PopoverTrigger>
                                                                <PopoverContent className="w-auto text-sm font-medium">
                                                                    {selectedUsers?.map((userId: any) => {
                                                                        const member = membersList?.data?.find((item: any) => item.id === userId);
                                                                        if (!member) return null;
                                                                        return (
                                                                            <ul>
                                                                                <li className='flex gap-2 items-center mb-3'> <Avatar className="size-10">
                                                                                    <AvatarImage src="" alt="@shadcn" />
                                                                                    <AvatarFallback>{member?.userfullname[0]?.toUpperCase()}</AvatarFallback>
                                                                                </Avatar>{member?.userfullname}</li>
                                                                            </ul>
                                                                        );
                                                                    })}
                                                                </PopoverContent>
                                                            </Popover>
                                                        }
                                                    </div> */}
                                                    <DynamicAvatarGroup
                                                        membersList={membersList?.data || []}
                                                        selectedUsers={selectedUsers}
                                                    />
                                                    <AddCustomModal membersList={membersList} selectedUsers={selectedUsers} setSelectedUsers={setSelectedUsers} title={'Add Members'} />
                                                </div>
                                            </div>
                                            <div>
                                                <p className='mb-2'>Project Leads</p>
                                                <div className='flex gap-4 items-center'>
                                                    {/* <div className="flex items-center space-x-[-12px]">
                                                        {membersList?.data?.filter((item: any) => selectedUsers?.includes(item?.id))?.slice(0, 2)?.map((showMembers: any) => (
                                                            <Avatar className="size-10">
                                                                <AvatarImage src="" alt="@shadcn" />
                                                                <AvatarFallback>{showMembers?.userfullname[0]?.toUpperCase()}</AvatarFallback>
                                                            </Avatar>
                                                        ))}

                                                        {selectedUsers?.length > 2 &&
                                                            <Popover>
                                                                <PopoverTrigger asChild>
                                                                    <button type="button">
                                                                        <Avatar className="size-10 cursor-pointer">
                                                                            <AvatarFallback className="text-sm font-semibold">+{selectedUsers?.length - 2}</AvatarFallback>
                                                                        </Avatar>
                                                                    </button>
                                                                </PopoverTrigger>
                                                                <PopoverContent className="w-auto text-sm font-medium">
                                                                    {selectedUsers?.map((userId: any) => {
                                                                        const member = membersList?.data?.find((item: any) => item.id === userId);
                                                                        if (!member) return null;
                                                                        return (
                                                                            <ul>
                                                                                <li className='flex gap-2 items-center mb-3'> <Avatar className="size-10">
                                                                                    <AvatarImage src="" alt="@shadcn" />
                                                                                    <AvatarFallback>{member?.userfullname[0]?.toUpperCase()}</AvatarFallback>
                                                                                </Avatar>{member?.userfullname}</li>
                                                                            </ul>
                                                                        );
                                                                    })}
                                                                </PopoverContent>
                                                            </Popover>
                                                        }
                                                    </div> */}
                                                    <DynamicAvatarGroup
                                                        membersList={membersList?.data || []}
                                                        selectedUsers={selectedProjectLeads}
                                                    />
                                                    <AddCustomModal membersList={membersList} selectedUsers={selectedProjectLeads} setSelectedUsers={setSelectedProjectLeads} title={'Add Project Leads'} />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='col-span-6'>
                                        <FormField
                                            control={form.control}
                                            name="owner"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Owner</FormLabel>
                                                    <FormControl>
                                                        <Input placeholder="Enter your owner name" value={projectCreated} disabled />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className='col-span-6'>
                                        <FormField
                                            control={form.control}
                                            name="name"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Project Name</FormLabel>
                                                    <FormControl>
                                                        <Input placeholder="Enter your project name" {...field} />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className='col-span-6'>
                                        <FormField
                                            control={form.control}
                                            name="startDate"
                                            render={({ field }) => (
                                                <FormItem className="flex flex-col">
                                                    <FormLabel>Start Date</FormLabel>
                                                    <Popover>
                                                        <PopoverTrigger asChild>
                                                            <FormControl>
                                                                <Button
                                                                    variant={"outline"}
                                                                    className={cn(
                                                                        "w-full pl-3 text-left font-normal",
                                                                        !field.value && "text-muted-foreground"
                                                                    )}
                                                                >
                                                                    {field.value ? (
                                                                        format(field.value, "PPP")
                                                                    ) : (
                                                                        <span>Pick a date</span>
                                                                    )}
                                                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                                                </Button>
                                                            </FormControl>
                                                        </PopoverTrigger>
                                                        <PopoverContent className="w-auto p-0" align="start">
                                                            <Calendar
                                                                mode="single"
                                                                selected={field.value ?? undefined}
                                                                onSelect={field.onChange}
                                                                initialFocus
                                                            />
                                                        </PopoverContent>
                                                    </Popover>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className='col-span-6'>
                                        <FormField
                                            control={form.control}
                                            name="endDate"
                                            render={({ field }) => (
                                                <FormItem className="flex flex-col">
                                                    <FormLabel>End Date</FormLabel>
                                                    <Popover>
                                                        <PopoverTrigger asChild>
                                                            <FormControl>
                                                                <Button
                                                                    variant={"outline"}
                                                                    className={cn(
                                                                        "w-full pl-3 text-left font-normal",
                                                                        !field.value && "text-muted-foreground"
                                                                    )}
                                                                    disabled={!startDate}
                                                                >
                                                                    {field.value ? (
                                                                        format(field.value, "PPP")
                                                                    ) : (
                                                                        <span>Pick a date</span>
                                                                    )}
                                                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                                                </Button>
                                                            </FormControl>
                                                        </PopoverTrigger>
                                                        <PopoverContent className="w-auto p-0" align="start">
                                                            <Calendar
                                                                mode="single"
                                                                selected={field.value ?? undefined}
                                                                onSelect={field.onChange}
                                                                disabled={(date: Date) => !startDate || date <= startDate}
                                                                initialFocus
                                                            />
                                                        </PopoverContent>
                                                    </Popover>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className='col-span-12'>
                                        <FormField
                                            control={form.control}
                                            name="description"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Description</FormLabel>
                                                    <FormControl>
                                                        <RichText value={field.value} onChange={field.onChange} key={projectDetail} />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className='col-span-4'>
                                        <FormField
                                            control={form.control}
                                            name="priority"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Priority</FormLabel>
                                                    <Select onValueChange={field.onChange} value={field.value}>
                                                        <SelectTrigger className="w-full">
                                                            <SelectValue
                                                                placeholder="Select a Priority"
                                                                className="flex items-center gap-2"
                                                            />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            <SelectGroup>
                                                                <SelectItem value="1">
                                                                    <div className="flex items-center gap-2">
                                                                        <span className="h-2 w-2 rounded-full bg-red-500" />
                                                                        High
                                                                    </div>
                                                                </SelectItem>
                                                                <SelectItem value="2">
                                                                    <div className="flex items-center gap-2">
                                                                        <span className="h-2 w-2 rounded-full bg-yellow-500" />
                                                                        Medium
                                                                    </div>
                                                                </SelectItem>
                                                                <SelectItem value="3">
                                                                    <div className="flex items-center gap-2">
                                                                        <span className="h-2 w-2 rounded-full bg-green-500" />
                                                                        Low
                                                                    </div>
                                                                </SelectItem>
                                                            </SelectGroup>
                                                        </SelectContent>
                                                    </Select>
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className='col-span-4'>
                                        <FormField
                                            control={form.control}
                                            name="status"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Status</FormLabel>
                                                    <Select onValueChange={field.onChange} value={field.value}>
                                                        <SelectTrigger className="w-full">
                                                            <SelectValue
                                                                placeholder="Select a Status"
                                                                className="flex items-center gap-2"
                                                            />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            <SelectGroup>
                                                                <SelectItem value="1">
                                                                    <div className="flex items-center gap-2">
                                                                        <span className="h-2 w-2 rounded-full bg-red-500" />
                                                                        Not-started
                                                                    </div>
                                                                </SelectItem>
                                                                <SelectItem value="2">
                                                                    <div className="flex items-center gap-2">
                                                                        <span className="h-2 w-2 rounded-full bg-yellow-500" />
                                                                        Inprogress
                                                                    </div>
                                                                </SelectItem>
                                                                <SelectItem value="3">
                                                                    <div className="flex items-center gap-2">
                                                                        <span className="h-2 w-2 rounded-full bg-green-500" />
                                                                        Completed
                                                                    </div>
                                                                </SelectItem>
                                                            </SelectGroup>
                                                        </SelectContent>
                                                    </Select>
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className='col-span-4'>
                                        <FormField
                                            control={form.control}
                                            name="extTime"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Estimated Time</FormLabel>
                                                    <FormControl>
                                                        <Input placeholder="Enter your estimated time" {...field} />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    </div>

                                    <div className='col-span-12 flex justify-end'>
                                        <Button type="submit" size="lg">Save changes</Button>
                                    </div>

                                    <div className='border-b col-span-12' />
                                    <div className="col-span-12 mb-4">
                                        <FormField
                                            control={form.control}
                                            name="images"
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Add Attachment</FormLabel>
                                                    <FormControl>
                                                        <Input id="picture" type="file" multiple ref={fileInputRef}
                                                            onChange={(e) => {
                                                                field.onChange(e.target.files);
                                                                handleFileChange(e);
                                                            }} />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />

                                        <div className="">
                                            {selectedImages.length > 0 &&
                                                <>
                                                    <h2 className="text-sm font-semibold mb-2 mt-4">Attachments</h2>
                                                    <Table>
                                                        <TableHeader>
                                                            <TableRow>
                                                                <TableHead>Name</TableHead>
                                                                <TableHead>Type</TableHead>
                                                                <TableHead>Size</TableHead>
                                                                <TableHead className="text-right">Actions</TableHead>
                                                            </TableRow>
                                                        </TableHeader>
                                                        <TableBody>
                                                            {selectedImages.map((file: any, index: any) => (
                                                                <TableRow key={file?.id || index}>
                                                                    <TableCell>{file?.name}</TableCell>
                                                                    <TableCell>{file?.type ? file?.type?.split("/")[1] : file?.name?.split(".").pop()}</TableCell>
                                                                    <TableCell>{file?.size
                                                                        ? `${(file.size / 1024).toFixed(2)} KB`
                                                                        : "—"}</TableCell>
                                                                    <TableCell className="text-right space-x-2">
                                                                        <Button variant="outline" size="sm" type="button" onClick={() => previewDoc(file?.path)}>
                                                                            <Eye className="h-4 w-4" />
                                                                        </Button>
                                                                        <Button variant="outline" size="sm" type="button" onClick={() => handleDownload(file?.path)}>
                                                                            <Download className="h-4 w-4" />
                                                                        </Button>
                                                                        <Button variant="destructive" size="sm" type="button" onClick={() => removeImage(file?.id)}>
                                                                            <Trash2 className="h-4 w-4" />
                                                                        </Button>
                                                                    </TableCell>
                                                                </TableRow>
                                                            ))}
                                                        </TableBody>
                                                    </Table>
                                                </>
                                            }
                                        </div>
                                    </div>
                                </form>
                                <div className='border-b w-full mt-4 mb-8' />
                                <p>Project Comments</p>

                                <CommentBox projectDetail={projectDetail} users={membersList?.data} />
                            </Form>
                        </div>
                        <div className='w-[30%] p-5 pt-0 border-l mt-6'>
                            <div>
                                <h4 className='text-2xl text-foreground '>Task Properties</h4>
                            </div>
                            <div className='mt-7 mb-6 grid gap-4'>
                                {items.length > 0 &&
                                    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                                        <SortableContext items={items.map((item: any) => item.id)} strategy={verticalListSortingStrategy}>
                                            {items.map((field: any) => (
                                                <SortableItem
                                                    key={field.id}
                                                    field={field}
                                                    onEdit={(f: any) => {
                                                        console.log("boom boom boom", f);
                                                        setOpen(true);
                                                        setSelectedType(f.config_detail);
                                                        setTypeId(f.id);
                                                        setColumnName(f.label_name);
                                                        setInitialColumnName(f.label_name);
                                                    }}
                                                    onDelete={deleteCustomField}
                                                />
                                            ))}
                                        </SortableContext>
                                    </DndContext>
                                }
                            </div>
                            <AddCustomColumn projectDetail={projectDetail} refetch={refetch} setOpen={setOpen} open={open} setSelectedType={setSelectedType} selectedType={selectedType} typeId={typeId} setTypeId={setTypeId} setColumnName={setColumnName} columnName={columnName} initialColumnName={initialColumnName} refetchTaskList={refetchTaskList} refetchFiltersList={refetchFiltersList} />
                        </div>
                    </div>
                </TabsContent>

                { /* Task Tab  */}
                <TabsContent value="task" className='max-w-full'>
                    <div className="p-4 border-b flex items-center justify-between">
                        <div className="flex gap-5 items-center">
                            <p className="text-xl">
                                {projectDetail?.project_name}
                            </p>
                            {/* <Input
                                placeholder="Search Task"
                                className="w-[300px]"
                            // value={searchValue}
                            // onChange={(e) => setSearchValue(e.target.value)}
                            /> */}
                        </div>
                        <div className="flex gap-2">
                            <MultiSelectFilter title='Status' options={filtersList?.data?.project_status} setStatusFiltering={setStatusFiltering} setPriorityFiltering={undefined} />
                            <MultiSelectFilter title='Priority' options={filtersList?.data?.project_priority} setStatusFiltering={undefined} setPriorityFiltering={setPriorityFiltering} />
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button variant="outline" className="border-dashed" >
                                        <SlidersHorizontal className="w-5 h-5" />
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-72" align="end" sideOffset={5}>
                                    <div className="grid gap-4">
                                        <div className="space-y-2">
                                            <h4 className="font-medium leading-none">Visible Columns</h4>
                                            <p className="text-sm text-muted-foreground">
                                                Adjust the columns that are visible
                                            </p>
                                        </div>
                                        <div className="flex flex-col gap-3">
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Status</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Priority</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Type</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Assigned To</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Assigned By</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Create By</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Reviewer</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">QA</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Deadline</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Expected Hours</Label>
                                            </div>
                                            <div className="flex items-center space-x-2 ">
                                                <Switch id="status" defaultChecked={true} />
                                                <Label htmlFor="status">Task Id </Label>
                                            </div>
                                        </div>
                                    </div>
                                </PopoverContent>
                            </Popover>
                        </div>
                    </div>
                    {!isError ? <ScrollArea className="w-full">
                        <HierarchicalTable taskData={filteredData} heads={getData?.typeKeys} refetchTaskList={refetchTaskList} users={membersList?.data} />
                        <ScrollBar orientation="horizontal" />
                    </ScrollArea>
                        :
                        <div>
                            {/* <p style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>No Task Found</p> */}
                            <Card className="w-full max-w-md shadow-xl rounded-2xl mx-auto mt-10">
                                <CardHeader>
                                    <CardTitle className="text-2xl">Create Your First Task</CardTitle>
                                    <CardDescription className="text-gray-600 mt-1">
                                        Start by creating a simple task. by just writing a name and hitting enter.
                                    </CardDescription>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="relative flex items-center gap-2">
                                        <Input
                                            placeholder="First Task"
                                            className="pr-6"
                                            onChange={(e) => setNewTask(e.target.value)}
                                            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                                                if (e.key === ' ' && getNewTask.length === 0) {
                                                    e.preventDefault();
                                                }
                                                if (e.key === 'Enter') {
                                                    e.preventDefault();
                                                    handleCreateTask();
                                                }
                                            }}
                                            value={getNewTask}
                                        />

                                        <Button
                                            size="icon"
                                            variant="outline"
                                            className=""
                                            onClick={() => handleCreateTask()}
                                        >
                                            <Plus className="h-4 w-4" />
                                        </Button>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    }
                </TabsContent>

            </Tabs>
        </div >
    )
}

export default ProjectOne
