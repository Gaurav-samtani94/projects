import React from 'react'
import AddProjectModal from 'renderer/components/sections/AddProjectModal'
import useAuthStore from 'renderer/store/AuthStore';

const ProjectMg = () => {
    const user = useAuthStore.getState().getUser();
    return (
        <div className="flex items-center flex-col gap-10 justify-center h-[calc(100vh-120px)]">
            {!user?.isReportingManager ? "You don’t have any projects assigned yet. Please contact your reporting manager." :
                <>
                    <h1 className='text-2xl font-semibold'>Your Projects</h1>
                    <AddProjectModal />
                </>
            }
        </div>
    )
}

export default ProjectMg
