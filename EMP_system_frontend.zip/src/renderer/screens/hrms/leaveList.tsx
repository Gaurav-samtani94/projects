import React, { useState, useEffect } from 'react'
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
} from 'renderer/components/ui/card'
import { Input } from 'renderer/components/ui/input'
import { Button } from 'renderer/components/ui/button'
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from 'renderer/components/ui/select'
import {
    type ColumnDef,
    type ColumnFiltersState,
    type SortingState,
    type VisibilityState,
    flexRender,
    getCoreRowModel,
    getFilteredRowModel,
    getPaginationRowModel,
    getSortedRowModel,
    useReactTable,
} from '@tanstack/react-table'
import { ArrowUpDown, ChevronDown } from 'lucide-react'
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuTrigger,
} from 'renderer/components/ui/dropdown-menu'
import { useForm } from "react-hook-form";
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
} from "../../components/ui/form";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from 'renderer/components/ui/table'



import { toast } from 'sonner'
import { useMutation } from '@tanstack/react-query';
import { holidayListApi } from "../../../renderer/service/hrmsServices"
import dayjs from 'dayjs'

interface HolidayFormValues {
    groupid: string
    holidayyear: string
}

export type Attendance = {
    id: string
    holidaydate: string
    groupid: string
    holidayname: string
    description: string
    // status: 'present' | 'absent' | 'half-day'
}

export const columns: ColumnDef<Attendance>[] = [
    {
        accessorKey: 'srNo',
        header: 'Sr. No',
        cell: ({ row }) => <div className="text-left">{row.index + 1}</div>,
    },
    {
        accessorKey: 'holidayname',
        header: 'Holiday Name',
        cell: ({ row }) => <div>{row.getValue('holidayname') || '-'}</div>,
    },
    {
        accessorKey: 'groupid',
        header: 'Holiday Type',
        cell: ({ row }) => {
            const leaveType = row.getValue('groupid') as string;
            const textColor = leaveType == '2' ? 'text-green-500' : 'text-red-500';

            return <div className={`capitalize ${textColor}`}>{leaveType == "1" ? "PL" : leaveType == "2" ? "RH" : "-"}</div>;
        },
    },
    {
        accessorKey: 'holidaydate',
        header: ({ column }) => (
            <Button
                className="!p-0 !px-0"
                variant="ghost"
                onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
            >
                Holiday Date
                <ArrowUpDown className="ml-2 h-4 w-4" />
            </Button>
        ),
    },
    {
        accessorKey: 'description',
        header: 'Description',
        cell: ({ row }) => <div>{row.getValue('description') || '-'}</div>,
    },
]

const leaveList = () => {

    const [sorting, setSorting] = React.useState<SortingState>([])
    const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
        []
    )
    const [showHolidayData, setShowHolidayData] = useState<Attendance[]>([]);

    const [columnVisibility, setColumnVisibility] =
        React.useState<VisibilityState>({})
    const [rowSelection, setRowSelection] = React.useState({})
    const currentYear = dayjs().format('YYYY');


    const form = useForm<HolidayFormValues>({
        defaultValues: {
            groupid: '',
            holidayyear: currentYear,
        },
        mode: 'onChange',
    })

    const holidayListMutation = useMutation({
        mutationFn: holidayListApi,
        onSuccess: data => {
            setShowHolidayData(data.data)
            toast.success('Holiday list loaded successfully!')
        },
        onError: error => {
            toast.error('Failed to load holiday list')
        },
    })

    function onSubmit(data: HolidayFormValues) {
        holidayListMutation.mutate({
            groupid: data.groupid,
            holidayyear: data.holidayyear,
        })
    }

    function handleReset() {
        form?.reset()
    }

    useEffect(() => {
        holidayListMutation.mutate({
            groupid: '',
            holidayyear: currentYear,
        });
    }, [])

    const table = useReactTable({
        data: showHolidayData,
        columns,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        onColumnVisibilityChange: setColumnVisibility,
        onRowSelectionChange: setRowSelection,
        state: {
            sorting,
            columnFilters,
            columnVisibility,
            rowSelection,
        },
    })

    return (
        <div>
            <Card>
                <CardHeader>
                    <CardTitle className="font-medium text-3xl mt-1 mb-2 text-left">
                        Leave List
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1 w-full flex gap-4">
                    <Form {...form} >
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 w-full">
                            <div className="w-full grid grid-cols-4 gap-4">
                                <FormField
                                    control={form.control}
                                    name="groupid"
                                    render={({ field }) => (
                                        <FormItem className="w-full">
                                            <FormLabel>Leave Type:</FormLabel>
                                            <div className="w-full">
                                                <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value}  >
                                                    <FormControl>
                                                        <SelectTrigger className=" w-full">
                                                            <SelectValue placeholder="Select a Leave Type" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        <SelectItem value="1">Holidays</SelectItem>
                                                        <SelectItem value="2">RH</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="holidayyear"
                                    render={({ field }) => (
                                        <FormItem className="w-full">
                                            <FormLabel>Year:</FormLabel>
                                            <div className="w-full">
                                                <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value} >
                                                    <FormControl>
                                                        <SelectTrigger className=" w-full">
                                                            <SelectValue placeholder="Select Year" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        <SelectItem value="2025">2025</SelectItem>
                                                        <SelectItem value="2024">2024</SelectItem>
                                                        <SelectItem value="2023">2023</SelectItem>
                                                        <SelectItem value="2022">2022</SelectItem>
                                                        <SelectItem value="2021">2021</SelectItem>
                                                        <SelectItem value="2020">2020</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </FormItem>
                                    )}
                                />
                            </div>
                            <Button className="mt-6">Filter Record</Button>
                            <Button type='button' onClick={handleReset} className="mt-6 ml-6">Reset</Button>
                        </form>
                    </Form>
                </CardContent>
            </Card>
            <div className="w-full mt-5">
                <div className="flex items-center py-4">
                    <Input
                        placeholder="Filter by date..."
                        value={
                            (table.getColumn('date')?.getFilterValue() as string) ?? ''
                        }
                        onChange={event =>
                            table.getColumn('date')?.setFilterValue(event.target.value)
                        }
                        className="max-w-sm"
                    />
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="outline" className="ml-auto">
                                Columns <ChevronDown className="ml-2 h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            {table
                                .getAllColumns()
                                .filter(column => column.getCanHide())
                                .map(column => {
                                    return (
                                        <DropdownMenuCheckboxItem
                                            key={column.id}
                                            className="capitalize"
                                            checked={column.getIsVisible()}
                                            onCheckedChange={value =>
                                                column.toggleVisibility(!!value)
                                            }
                                        >
                                            {column.id}
                                        </DropdownMenuCheckboxItem>
                                    )
                                })}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            {table.getHeaderGroups().map(headerGroup => (
                                <TableRow key={headerGroup.id}>
                                    {headerGroup.headers.map(header => {
                                        return (
                                            <TableHead key={header.id}>
                                                {header.isPlaceholder
                                                    ? null
                                                    : flexRender(
                                                        header.column.columnDef.header,
                                                        header.getContext()
                                                    )}
                                            </TableHead>
                                        )
                                    })}
                                </TableRow>
                            ))}
                        </TableHeader>
                        <TableBody>
                            {table.getRowModel().rows?.length ? (
                                table.getRowModel().rows.map((row, index) => (
                                    <TableRow
                                        key={row.id}
                                        data-state={row.getIsSelected() && 'selected'}
                                    >
                                        {row.getVisibleCells().map(cell => (
                                            <TableCell key={cell.id}>
                                                {flexRender(
                                                    cell.column.columnDef.cell,
                                                    cell.getContext()
                                                )}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell
                                        colSpan={columns.length}
                                        className="h-24 text-center"
                                    >
                                        No results.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
                <div className="flex items-center justify-end space-x-2 py-4">
                    <div className="flex-1 text-sm text-muted-foreground">
                        {table.getFilteredSelectedRowModel().rows.length} of{' '}
                        {table.getFilteredRowModel().rows.length} row(s) selected.
                    </div>
                    <div className="space-x-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.previousPage()}
                            disabled={!table.getCanPreviousPage()}
                        >
                            Previous
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.nextPage()}
                            disabled={!table.getCanNextPage()}
                        >
                            Next
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default leaveList