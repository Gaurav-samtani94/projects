import React, { useEffect, useState } from "react";
import { Calendar } from "../../components/ui/calendar"
import { Calendar as CalendarIcon } from "lucide-react"
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "../../components/ui/popover"
import { useForm } from "react-hook-form";
import { toast } from 'sonner'
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "../../components/ui/form";
import { cn } from "../../lib/utils";
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
} from 'renderer/components/ui/card'
import { Label } from 'renderer/components/ui/label'
import { Input } from 'renderer/components/ui/input'
import { Button } from 'renderer/components/ui/button'
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from 'renderer/components/ui/select'
import {
    type ColumnDef,
    type ColumnFiltersState,
    type SortingState,
    type VisibilityState,
    flexRender,
    getCoreRowModel,
    getFilteredRowModel,
    getPaginationRowModel,
    getSortedRowModel,
    useReactTable,
} from '@tanstack/react-table'
import { ArrowUpDown, ChevronDown } from 'lucide-react'
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuTrigger,
} from 'renderer/components/ui/dropdown-menu'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from 'renderer/components/ui/table'
import { useQuery, useMutation } from '@tanstack/react-query';
import { leaveListApi, applyLeaveApi, deleteLeaveApi, editLeaveApi } from "../../../renderer/service/hrmsServices"
import dayjs from 'dayjs'
import { Edit, Trash } from "lucide-react"
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "renderer/components/ui/dialog"
import useAuthStore from '../../../renderer/store/AuthStore'


export type Attendance = {
    id: string
    leavetypeid: string
    leaveday: string
    leavestatus: string
    reason: string
    from_date: string
    to_date: string
    appliedleavescount: number
    createddate: string
}

interface ProfileFormValues {
    reason: string
    leavetypeid: string
    halfDayLeave: string
    shortLeave: string
    leaveday: string
    from_date: string
    to_date: string
    appliedleavescount: string
    rememberMe: boolean
}

const ApplyLeave = () => {
    const [isEditLeaveOpen, setIsEditLeaveOpen] = useState(false);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [selectedRow, setSelectedRow] = useState<Attendance | null>(null);
    const [leaveListReCall, setLeaveListReCall] = useState<string | null>(null);

    const handleEdit = (rowData: Attendance) => {
        setSelectedRow(rowData)
        setIsEditLeaveOpen(true);
    };

    const deleteLeaveFun = useMutation({
        mutationFn: deleteLeaveApi,
        onSuccess: data => {
            toast.success('Leave Deleted', {
                description: 'Leave Deleted.',
            })
            setLeaveListReCall(Date.now().toString())
            setIsDeleteDialogOpen(false);
        },
        onError: error => {
        },
    })

    const handleDeleteClick = (rowData: Attendance) => {
        setSelectedRow(rowData);
        setIsDeleteDialogOpen(true);
    };

    const editLeaveFun = useMutation({
        mutationFn: editLeaveApi,
        onSuccess: data => {
            toast.success('Your leave details have been successfully updated!')
            setLeaveListReCall(Date.now().toString())
            setIsEditLeaveOpen(false);
        },
        onError: error => {
            console.log(error, "emailRegex")
        },
    })

    const confirmEdit = () => {
        if (selectedRow) {
            editLeaveFun.mutate({
                id: selectedRow?.id,
                reason: selectedRow?.reason
            })
        }
    }

    const confirmDelete = () => {
        if (selectedRow) {
            deleteLeaveFun.mutate({
                id: selectedRow?.id,
            })
        }
    };

    const columns: ColumnDef<Attendance>[] | [] = [
        {
            accessorKey: 'srNo',
            header: 'Sr. No',
            cell: ({ row }) => <div className="text-left">{row.index + 1}</div>,
        },
        {
            accessorKey: 'leavetypeid',
            header: 'Leave Type',
        },
        {
            accessorKey: 'leaveday',
            header: 'Leave For',
        },
        {
            accessorKey: 'reason',
            header: 'Reason',
        },
        {
            accessorKey: 'from_date',
            header: ({ column }) => {
                return (
                    <Button
                        className="!p-0 !px-0"
                        variant="ghost"
                        onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
                    >
                        From Date
                        <ArrowUpDown className="ml-2 h-4 w-4" />
                    </Button>
                )
            },
        },
        {
            accessorKey: 'to_date',
            header: ({ column }) => {
                return (
                    <Button
                        className="!p-0 !px-0"
                        variant="ghost"
                        onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
                    >
                        To Date
                        <ArrowUpDown className="ml-2 h-4 w-4" />
                    </Button>
                )
            },
        },
        {
            accessorKey: 'appliedleavescount',
            header: 'Days',
        },
        {
            accessorKey: 'createddate',
            header: 'Applied On',
        },
        {
            accessorKey: 'leavestatus',
            header: 'Status',
            cell: ({ row }) => (
                <div className="capitalize">{(row.getValue('leavestatus'))?.name}</div>
            ),
        },
        {
            id: "actions",
            header: "Actions",
            cell: ({ row }) => (
                <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" disabled={row.original?.leavestatus?.status !== 1} onClick={() => handleEdit(row.original)}>
                        <Edit className="h-4 w-4 text-blue-500" />
                    </Button>
                    <Button variant="outline" size="icon" disabled={row.original?.leavestatus?.status !== 1} onClick={() => handleDeleteClick(row.original)}>
                        <Trash className="h-4 w-4 text-red-500" />
                    </Button>
                </div>
            ),
        },
    ]

    const { getUser } = useAuthStore()

    const form = useForm<ProfileFormValues>({
        defaultValues: {
            reason: '',
            leavetypeid: '',
            halfDayLeave: '',
            shortLeave: '',
            leaveday: '',
            from_date: '',
            to_date: '',
            appliedleavescount: ''
        },
        mode: 'onChange',
    })

    const [sorting, setSorting] = React.useState<SortingState>([])
    const [wrapData, setWrapData] = React.useState<Attendance[] | []>([]);
    const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
        []
    )
    const [columnVisibility, setColumnVisibility] =
        React.useState<VisibilityState>({})
    const [rowSelection, setRowSelection] = React.useState({})

    const { data: getLeaveList, isSuccess } = useQuery({
        queryKey: ['leaveListing', leaveListReCall],
        queryFn: () => leaveListApi(),
    });

    useEffect(() => {
        if (isSuccess && getLeaveList?.data) {
            const getWrappedData = (getLeaveList.data as Attendance[]).map((item) => ({
                id: item?.id,
                leavetypeid: item?.leavetypeid == "1" ? "PL" : item?.leavetypeid == "2" ? "RH" : "-",
                leaveday: item?.leaveday == "1" ? "Full Day" : item?.leaveday == "2" ? "Half Day" : item?.leaveday == "3" ? "short Leave" : "-",
                leavestatus: item?.leavestatus,
                reason: item?.reason,
                from_date: dayjs(item?.from_date).format("DD-MM-YYYY"),
                to_date: dayjs(item?.to_date).format("DD-MM-YYYY"),
                appliedleavescount: item?.appliedleavescount,
                createddate: dayjs(item?.createddate).format("DD-MM-YYYY"),
            }));
            setWrapData(getWrappedData)
        }
    }, [isSuccess, getLeaveList?.data]);

    function handleReset() {
        form?.reset()
    }

    const table = useReactTable({
        data: wrapData,
        columns,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        onColumnVisibilityChange: setColumnVisibility,
        onRowSelectionChange: setRowSelection,
        state: {
            sorting,
            columnFilters,
            columnVisibility,
            rowSelection,
        },
    })

    const applyLeaveFun = useMutation({
        mutationFn: applyLeaveApi,
        onSuccess: data => {
            toast.success('Leave Applied', {
                description: 'Leave Applied successfully.',
            })
            setLeaveListReCall(Date.now().toString())
            form.reset()
        },
        onError: error => {
            console.log(error, "emailRegex")
            form.reset()
        },
    })

    function onSubmit(data: ProfileFormValues) {
        applyLeaveFun.mutate({
            user_id: getUser()?.id || '',
            reason: data.reason,
            leavetypeid: data.leavetypeid,
            leaveday: data.leaveday,
            from_date: dayjs(data.from_date).format("YYYY-MM-DD"),
            to_date: dayjs(data.to_date).format("YYYY-MM-DD"),
            halfDayLeave: data.halfDayLeave,
            // leaveday: data.leaveday,
            shortLeave: data.shortLeave,
            appliedleavescount: data.appliedleavescount
        })
    }


    return (
        <>
            <Card>
                <CardHeader>
                    <CardTitle className="font-medium text-3xl mt-1 mb-2 text-left">
                        Apply Leave
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1 w-full gap-4">
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 w-full">
                            {/* Username Field */}
                            <div className="w-full grid grid-cols-4 gap-4">
                                <FormField
                                    control={form.control}
                                    name="leavetypeid"
                                    rules={{ required: "Leave Type is required" }}
                                    render={({ field }) => (
                                        <FormItem className="w-full">
                                            <FormLabel>Leave Type<span className="text-red-500">*</span></FormLabel>
                                            <div className="w-full">
                                                <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value} disabled={(Boolean(form.watch().from_date) && Boolean(form.watch().to_date)) || form.watch().leaveday === "1"} >
                                                    <FormControl>
                                                        <SelectTrigger className=" w-full">
                                                            <SelectValue placeholder="Select a Leave Type" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        <SelectItem value="1">PL</SelectItem>
                                                        <SelectItem value="2">RH</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="leaveday"
                                    // rules={{ required: "Leave For is required" }}
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Leave For<span className="text-red-500">*</span></FormLabel>
                                            <div className="w-full">
                                                <Select onValueChange={field.onChange} value={form.watch().leavetypeid === "2" ? "1" : field.value} defaultValue={form.watch().leavetypeid === "2" ? "Full day" : field.value} disabled={(form.watch().leavetypeid === "2" || Boolean(form.watch().halfDayLeave) || Boolean(form.watch().shortLeave)) || (form.watch().leavetypeid === "1" && form.watch().leaveday === "1" && Boolean(form.watch().from_date))} >
                                                    <FormControl>
                                                        <SelectTrigger className=" w-full">
                                                            <SelectValue placeholder="Select a Leave For" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        <SelectItem value="1">Full Day</SelectItem>
                                                        <SelectItem value="2">Half Day</SelectItem>
                                                        <SelectItem value="3">Short Leave</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </FormItem>
                                    )}
                                />
                                {form.watch("leaveday") === "2" && (
                                    <FormField
                                        control={form.control}
                                        name="halfDayLeave"
                                        rules={{ required: "Half day Type is required" }}
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Select Half Day Leave<span className="text-red-500">*</span></FormLabel>
                                                <div className="w-full">
                                                    <Select onValueChange={field.onChange} defaultValue={field.value} >
                                                        <FormControl>
                                                            <SelectTrigger className="w-full">
                                                                <SelectValue placeholder="Select a Half Day Leave" />
                                                            </SelectTrigger>
                                                        </FormControl>
                                                        <SelectContent>
                                                            <SelectItem value="1">Pre Lunch</SelectItem>
                                                            <SelectItem value="2">Post Lunch</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>
                                            </FormItem>
                                        )}
                                    />
                                )}

                                {
                                    form.watch().leaveday === "3" &&
                                    (
                                        <FormField
                                            control={form.control}
                                            name="shortLeave"
                                            rules={{ required: "Expected Time is required" }}
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormLabel>Expected Time (Out):<span className="text-red-500">*</span></FormLabel>
                                                    <FormControl>
                                                        <Input type="time" {...field} />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    )
                                }

                                <FormField
                                    control={form.control}
                                    name="from_date"
                                    rules={{ required: "From date is required" }}
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>From Date<span className="text-red-500">*</span></FormLabel>
                                            <FormControl>
                                                <Popover>
                                                    <PopoverTrigger asChild>
                                                        <Button
                                                            variant={"outline"}
                                                            className={cn(
                                                                "justify-start text-left font-normal",
                                                                // !date && "text-muted-foreground"
                                                            )}
                                                            disabled={(form.watch().leavetypeid === "2" || form.watch().leaveday === "2" || form.watch().leaveday === "3") && Boolean(form.watch().from_date) || (form.watch().leavetypeid === "1" && form.watch().leaveday === "1" && Boolean(form.watch().to_date))}

                                                        >
                                                            <CalendarIcon className="mr-2 h-4 w-4" />
                                                            {field.value ? dayjs(field.value).format("DD-MM-YYYY") : <span>Pick a date</span>}
                                                        </Button>
                                                    </PopoverTrigger>
                                                    <PopoverContent className="w-auto p-0">
                                                        <Calendar
                                                            mode="single"
                                                            selected={field.value ? new Date(field.value) : undefined}
                                                            onSelect={(date) => {
                                                                field.onChange(date);
                                                                if ((form.watch().leavetypeid === "2" || form.watch().leaveday === "2" || form.watch().leaveday === "3") && date) {
                                                                    form.setValue("to_date", date ? date.toISOString() : ""); // Check before calling .toISOString()
                                                                }
                                                            }}
                                                            initialFocus
                                                        />
                                                    </PopoverContent>
                                                </Popover>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="to_date"
                                    rules={{ required: "To Date is required" }}
                                    render={({ field }) => {
                                        const startDate = form.watch("from_date");
                                        return (
                                            <FormItem>
                                                <FormLabel>To Date<span className="text-red-500">*</span></FormLabel>
                                                <FormControl className="w-full">
                                                    <Popover>
                                                        <PopoverTrigger asChild>
                                                            <Button
                                                                variant={"outline"}
                                                                className={cn(
                                                                    "justify-start text-left font-normal",
                                                                    // !date && "text-muted-foreground"
                                                                )}
                                                                // disabled={(form.watch().leavetypeid == "2" || form.watch().leaveday == "2" || form.watch().leaveday == "3") && Boolean(form.watch().from_date) || (form.watch().leavetypeid == "1" && form.watch().leaveday == "1" && Boolean(form.watch().from_date) && Boolean(form.watch().to_date))}
                                                                disabled={
                                                                    !Boolean(form.watch().from_date) ||
                                                                    (form.watch().leavetypeid === "2" ||
                                                                        form.watch().leaveday === "2" ||
                                                                        form.watch().leaveday === "3") ||
                                                                    (form.watch().leavetypeid === "1" &&
                                                                        form.watch().leaveday === "1" &&
                                                                        Boolean(form.watch().from_date) &&
                                                                        Boolean(form.watch().to_date) &&
                                                                        !Boolean(form.watch().to_date))
                                                                }
                                                            >
                                                                <CalendarIcon className="mr-2 h-4 w-4" />
                                                                {field.value ? dayjs(field.value).format("DD-MM-YYYY") : <span>Pick a date</span>}
                                                            </Button>
                                                        </PopoverTrigger>
                                                        <PopoverContent className="w-auto p-0">
                                                            <Calendar
                                                                mode="single"
                                                                selected={field.value ? new Date(field.value) : undefined}
                                                                onSelect={field.onChange}
                                                                disabled={(form.watch().leavetypeid === "2" || form.watch().leaveday === "2" || form.watch().leaveday === "3") && Boolean(form.watch().from_date)}
                                                                fromDate={startDate ? new Date(startDate) : undefined}
                                                            />
                                                        </PopoverContent>
                                                    </Popover>
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        )


                                    }}
                                />

                                <FormField
                                    control={form.control}
                                    name="reason"
                                    rules={{ required: "Reason is required" }}
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Reason<span className="text-red-500">*</span></FormLabel>
                                            <FormControl>
                                                <Input type='text' {...field} placeholder="Enter Reason" />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="appliedleavescount"
                                    rules={{ required: "Leave Count is required" }}
                                    render={({ field }) => {
                                        // Moved calculation to a useEffect to prevent infinite renders
                                        React.useEffect(() => {
                                            const fromDate = form.watch().from_date ? new Date(form.watch().from_date) : null;
                                            const toDate = form.watch().to_date ? new Date(form.watch().to_date) : null;
                                            let leaveDays;

                                            if (fromDate && toDate) {
                                                const timeDiff = toDate.getTime() - fromDate.getTime();
                                                if (timeDiff >= 0) {
                                                    leaveDays = timeDiff / (1000 * 60 * 60 * 24) + 1; // +1 to count both start and end date
                                                }
                                            }

                                            if (form.watch().leavetypeid === "2" && Boolean(form.watch().from_date) && Boolean(form.watch().to_date)) {
                                                leaveDays = 1;
                                            } else if (form.watch().leaveday === "2" && Boolean(form.watch().from_date) && Boolean(form.watch().to_date)) {
                                                leaveDays = 0.5;
                                            } else if (form.watch().leaveday === "3" && Boolean(form.watch().from_date) && Boolean(form.watch().to_date)) {
                                                leaveDays = 0.25;
                                            }

                                            if (leaveDays !== undefined) {
                                                form.setValue("appliedleavescount", leaveDays.toString() || "0", { shouldValidate: true });
                                            }
                                        }, [form.watch().from_date, form.watch().to_date, form.watch().leavetypeid, form.watch().leaveday]);

                                        return (
                                            <FormItem>
                                                <FormLabel>Count Leave<span className="text-red-500">*</span></FormLabel>
                                                <FormControl>
                                                    <Input {...field} disabled />
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        );
                                    }}
                                />
                            </div>
                            <Button type="submit">Update Profile</Button>
                            <Button type="button" onClick={handleReset} className="ml-4">Reset</Button>
                        </form>
                    </Form>
                </CardContent>
            </Card>
            <div className="w-full mt-5">
                <div className="flex items-center py-4">
                    <Input
                        placeholder="Filter by date..."
                        value={
                            (table.getColumn('date')?.getFilterValue() as string) ?? ''
                        }
                        onChange={event =>
                            table.getColumn('date')?.setFilterValue(event.target.value)
                        }
                        className="max-w-sm"
                    />
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="outline" className="ml-auto">
                                Columns <ChevronDown className="ml-2 h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            {table
                                .getAllColumns()
                                .filter(column => column.getCanHide())
                                .map(column => {
                                    return (
                                        <DropdownMenuCheckboxItem
                                            key={column.id}
                                            className="capitalize"
                                            checked={column.getIsVisible()}
                                            onCheckedChange={value =>
                                                column.toggleVisibility(!!value)
                                            }
                                        >
                                            {column.id}
                                        </DropdownMenuCheckboxItem>
                                    )
                                })}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            {table.getHeaderGroups().map(headerGroup => (
                                <TableRow key={headerGroup.id}>
                                    {headerGroup.headers.map(header => {
                                        return (
                                            <TableHead key={header.id}>
                                                {header.isPlaceholder
                                                    ? null
                                                    : flexRender(
                                                        header.column.columnDef.header,
                                                        header.getContext()
                                                    )}
                                            </TableHead>
                                        )
                                    })}
                                </TableRow>
                            ))}
                        </TableHeader>
                        <TableBody>
                            {table.getRowModel().rows?.length ? (
                                table.getRowModel().rows.map(row => (
                                    <TableRow
                                        key={row.id}
                                        data-state={row.getIsSelected() && 'selected'}
                                    >
                                        {row.getVisibleCells().map(cell => (
                                            <TableCell key={cell.id}>
                                                {flexRender(
                                                    cell.column.columnDef.cell,
                                                    cell.getContext()
                                                )}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell
                                        colSpan={columns.length}
                                        className="h-24 text-center"
                                    >
                                        No results.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
                <div className="flex items-center justify-end space-x-2 py-4">
                    <div className="flex-1 text-sm text-muted-foreground">
                        {table.getFilteredSelectedRowModel().rows.length} of{' '}
                        {table.getFilteredRowModel().rows.length} row(s) selected.
                    </div>
                    <div className="space-x-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.previousPage()}
                            disabled={!table.getCanPreviousPage()}
                        >
                            Previous
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.nextPage()}
                            disabled={!table.getCanNextPage()}
                        >
                            Next
                        </Button>
                    </div>
                </div>
            </div>
            {/* Edit Leave Dialog */}
            <Dialog open={isEditLeaveOpen} onOpenChange={setIsEditLeaveOpen}>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <DialogTitle>Edit Leave</DialogTitle>
                        <DialogDescription>
                            Make changes to your leave details here. Click save when you're done.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="leaveType" className="text-right">
                                Leave Type:
                            </Label>
                            <Input
                                id="leaveType"
                                className="col-span-3"
                                name="leavetypeid"
                                value={(selectedRow?.leavetypeid == "1" ? "PL" : selectedRow?.leavetypeid == "2" ? "RH" : "")}
                                disabled
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="leaveFor" className="text-right">
                                Leave For:
                            </Label>
                            <Input
                                id="leaveFor"
                                className="col-span-3"
                                name="leaveFor"
                                value={selectedRow?.leaveFor || ""}
                                disabled
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="from_date" className="text-right">
                                From Date:
                            </Label>
                            <Input
                                id="from_date"
                                className="col-span-3"
                                name="from_date"
                                value={selectedRow?.from_date || ""}
                                disabled
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="to_date" className="text-right">
                                To Date:
                            </Label>
                            <Input
                                id="to_date"
                                className="col-span-3"
                                name="to_date"
                                value={selectedRow?.to_date || ""}
                                disabled
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="count_leave" className="text-right">
                                Count Leave:
                            </Label>
                            <Input
                                id="count_leave"
                                className="col-span-3"
                                name="appliedleavescount"
                                value={selectedRow?.appliedleavescount || ""}
                                disabled
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="leave_reason" className="text-right">
                                Leave Reason:
                            </Label>
                            <Input
                                id="leave_reason"
                                className="col-span-3"
                                name="reason"
                                value={selectedRow?.reason || ""}
                                onChange={(e) =>
                                    setSelectedRow({
                                        ...(selectedRow as Attendance),
                                        reason: e.target.value
                                    })
                                }
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button type="submit" onClick={confirmEdit} >Save changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
            {/* Delete Confirmation Dialog */}
            <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <DialogTitle>Delete Leave</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to delete this leave request? This action cannot be undone.
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>Cancel</Button>
                        <Button variant="destructive" onClick={confirmDelete}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    )
}

export default ApplyLeave;
