import React from 'react'
import { Download } from 'lucide-react'
import { Button } from 'renderer/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "renderer/components/ui/table"
import { useQuery } from '@tanstack/react-query'
import { form16List } from 'renderer/service/hrmsServices'

const form16 = () => {
    const { data } = useQuery({
        queryKey: ['form16'],
        queryFn: form16List
    })
    return (
        <div>
            <h4 className="font-medium text-3xl mt-1 mb-5 text-left">Form 16</h4>

            <div className="overflow-auto">
                <Table className='border'>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Sr No</TableHead>
                            <TableHead>First Name</TableHead>
                            <TableHead>Last Name</TableHead>
                            <TableHead>Financial Year</TableHead>
                            <TableHead>File Name</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Contact</TableHead>
                            <TableHead className="text-center">Action</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {data?.data?.map((user: any, index: number) => (
                            <TableRow key={user.id}>
                                <TableCell>{index + 1}</TableCell>
                                <TableCell>{user.firstname}</TableCell>
                                <TableCell>{user.lastname}</TableCell>
                                <TableCell>{user.finyear}</TableCell>
                                <TableCell>{user.file_path}</TableCell>
                                <TableCell>{user.emailaddress}</TableCell>
                                <TableCell>{user.contactnumber}</TableCell>
                                <TableCell className="text-center">

                                    <a href={user.form_urls} download target="_blank" rel="noopener noreferrer">
                                        <Button>
                                            <Download className="w-4 h-4 mr-1" />
                                            Download
                                        </Button>
                                    </a>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </div>
        </div>
    )
}

export default form16