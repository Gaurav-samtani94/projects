import React, { useState } from 'react'
import { Button } from 'renderer/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from 'renderer/components/ui/card'
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from 'renderer/components/ui/form'
import { Label } from 'renderer/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from 'renderer/components/ui/select'
import { useForm } from "react-hook-form";
import { toast } from 'sonner'
import { Input } from 'renderer/components/ui/input'
import { Popover, PopoverContent, PopoverTrigger } from 'renderer/components/ui/popover'
import { CalendarIcon, ChevronDown, Edit, Trash } from 'lucide-react'
import dayjs from 'dayjs'
import { Calendar } from 'renderer/components/ui/calendar'
import { cn } from 'renderer/lib/utils'
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuTrigger,
} from 'renderer/components/ui/dropdown-menu'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from 'renderer/components/ui/table'
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "renderer/components/ui/dialog"
import {
    type ColumnDef,
    type ColumnFiltersState,
    type SortingState,
    type VisibilityState,
    flexRender,
    getCoreRowModel,
    getFilteredRowModel,
    getPaginationRowModel,
    getSortedRowModel,
    useReactTable,
} from '@tanstack/react-table'
import { useMutation, useQuery } from '@tanstack/react-query'
import { applyTourApi, deleteTourApi, editTourApi, projectListApi, tourListApi } from 'renderer/service/hrmsServices'

export type TourData = {
    id: string
    project_id: string
    tour_type: string
    start_date: string
    end_date: string
    tour_location: string
    description: string
}
interface TourFormValues {
    project_id: string
    tour_location: string
    description: string
    tour_type: string
    start_date: string
    end_date: string
}

const applyTour = () => {
    const [sorting, setSorting] = React.useState<SortingState>([])
    const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
        []
    )
    const [columnVisibility, setColumnVisibility] =
        React.useState<VisibilityState>({})
    const [rowSelection, setRowSelection] = React.useState({})
    const [tourListReCall, setTourListReCall] = useState<string | null>(null);
    const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
    const [isEditLeaveOpen, setIsEditLeaveOpen] = useState(false);
    const [selectedRow, setSelectedRow] = useState<TourData | null>(null);

    const { data: getProjectList } = useQuery({
        queryKey: ['projectListing'],
        queryFn: () => projectListApi(),
    });

    const { data: getTourList, isSuccess } = useQuery({
        queryKey: ['tourListing', tourListReCall],
        queryFn: () => tourListApi(),
    });

    const handleEdit = (rowData: TourData) => {
        setSelectedRow(rowData)
        setIsEditLeaveOpen(true);
    };

    const editTourFun = useMutation({
        mutationFn: editTourApi,
        onSuccess: data => {
            toast.success('Your Tour details have been successfully updated!')
            setTourListReCall(Date.now().toString())
            setIsEditLeaveOpen(false);
        },
        onError: error => {
            console.log(error, "emailRegex")
        },
    })

    const confirmEdit = () => {
        if (selectedRow) {
            editTourFun.mutate({
                id: selectedRow?.id,
                project_id: selectedRow?.project_id,
                tour_location: selectedRow?.tour_location,
                description: selectedRow?.description
            })
        }
    }

    const handleDeleteClick = (rowData: TourData) => {
        setSelectedRow(rowData);
        setIsDeleteDialogOpen(true);
    };

    const deleteTourFun = useMutation({
        mutationFn: deleteTourApi,
        onSuccess: data => {
            toast.success('Tour Deleted', {
                description: 'Tour Deleted.',
            })
            setTourListReCall(Date.now().toString())
            setIsDeleteDialogOpen(false);
        },
        onError: error => {
            console.log(error, "emailRegex")
        },
    })

    const confirmDelete = () => {
        if (selectedRow) {
            deleteTourFun.mutate({
                id: selectedRow?.id,
            })
        }
    };

    const columns: ColumnDef<TourData>[] | [] = [
        {
            accessorKey: 'srNo',
            header: 'Sr. No',
            cell: ({ row }) => <div className="text-left">{row.index + 1}</div>,
        },
        {
            accessorKey: 'Project',
            header: 'Project',
            cell: ({ row }) => <div className="text-left font-medium">{(row.getValue('Project')?.project_name)}</div>,
        },
        {
            accessorKey: 'tour_type',
            header: 'Tour Type',
            cell: ({ row }) => <div className="capitalize">{row.getValue('tour_type') === 1 ? "General" : row.getValue('tour_type') === 2 ? "Short Tour" : "-"}</div>,
        },
        {
            accessorKey: 'start_date',
            header: 'From Date',
        },
        {
            accessorKey: 'end_date',
            header: 'To Date',
        },
        {
            accessorKey: 'tour_location',
            header: 'Location',
            cell: ({ row }) => <div className="text-left">{row.getValue('tour_location')}</div>,
        },
        {
            accessorKey: 'description',
            header: 'Description',
            cell: ({ row }) => <div className="text-left">{row.getValue('description') ? row.getValue('description') : '-'}</div>,
        },
        {
            accessorKey: 'actions',
            header: 'Action',
            cell: ({ row }) => (
                <div className="flex gap-2">
                    <Button variant="outline" size="icon" onClick={() => handleEdit(row.original)} >
                        <Edit className="h-4 w-4 text-blue-500" />
                    </Button>
                    <Button variant="outline" size="icon" disabled={row.original?.approved_bypmanager !== 0} onClick={() => handleDeleteClick(row.original)}>
                        <Trash className="h-4 w-4 text-red-500" />
                    </Button>
                </div>
            ),
        },
    ]

    const table = useReactTable({
        data: getTourList?.data || [],
        columns,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        onColumnVisibilityChange: setColumnVisibility,
        onRowSelectionChange: setRowSelection,
        state: {
            sorting,
            columnFilters,
            columnVisibility,
            rowSelection,
        },
    })

    const form = useForm<TourFormValues>({
        defaultValues: {
            project_id: '',
            tour_location: '',
            description: '',
            tour_type: '',
            start_date: '',
            end_date: '',
        },
        mode: 'onChange',
    })

    const applyTourFun = useMutation({
        mutationFn: applyTourApi,
        onSuccess: data => {
            setTourListReCall(Date.now().toString())
            toast.success(data?.message)
        },
        onError: error => {
            toast.error('Failed to apply tour')
            console.log(error, "error")
        },
    })

    function handleReset() {
        form?.reset()
    }

    function onSubmit(data: TourFormValues) {
        applyTourFun.mutate({
            project_id: data.project_id,
            tour_location: data.tour_location,
            description: data.description,
            tour_type: data.tour_type,
            start_date: data.start_date,
            end_date: data.end_date,
        })
    }

    return (
        <div>
            <Card>
                <CardHeader>
                    <CardTitle className="font-medium text-3xl mt-1 mb-2 text-left">
                        Apply Tour
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1 w-full gap-4">
                    <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 w-full">
                            {/* Username Field */}
                            <div className="w-full grid grid-cols-4 gap-4">
                                <FormField
                                    control={form.control}
                                    name="project_id"
                                    render={({ field }) => (
                                        <FormItem className="w-full">
                                            <FormLabel>Project</FormLabel>
                                            <div className="w-full">
                                                <Select onValueChange={field.onChange} value={field.value} defaultValue={field.value}>
                                                    <FormControl>
                                                        <SelectTrigger className=" w-full">
                                                            <SelectValue placeholder="Select a Project" />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        {getProjectList?.data?.map((proj: any) => (
                                                            <SelectItem key={proj?.id} value={String(proj?.id)}>
                                                                {proj?.project_name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="tour_type"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Tour Type </FormLabel>
                                            <div className="w-full">
                                                <Select onValueChange={field.onChange} value={field.value} defaultValue={field.value} >
                                                    <FormControl>
                                                        <SelectTrigger className=" w-full">
                                                            <SelectValue placeholder="Select a Tour Type " />
                                                        </SelectTrigger>
                                                    </FormControl>
                                                    <SelectContent>
                                                        <SelectItem value="1">General</SelectItem>
                                                        <SelectItem value="2">Short Tour</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="start_date"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>From Date</FormLabel>
                                            <FormControl>
                                                <Popover>
                                                    <PopoverTrigger asChild>
                                                        <Button
                                                            variant={"outline"}
                                                            className={cn("justify-start text-left font-normal")}
                                                        >
                                                            <CalendarIcon className="mr-2 h-4 w-4" />
                                                            {field.value
                                                                ? dayjs(field.value).format("DD-MM-YYYY")
                                                                : <span>Pick a date</span>}
                                                        </Button>
                                                    </PopoverTrigger>
                                                    <PopoverContent className="w-auto p-0">
                                                        <Calendar
                                                            mode="single"
                                                            selected={field.value ? new Date(field.value) : undefined}
                                                            onSelect={(date) => {
                                                                field.onChange(date);
                                                                form.setValue("end_date", undefined); // clear end_date if start_date changes
                                                            }}
                                                            initialFocus
                                                        />
                                                    </PopoverContent>
                                                </Popover>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <FormField
                                    control={form.control}
                                    name="end_date"
                                    render={({ field }) => {
                                        const startDate = form.watch("start_date");

                                        return (
                                            <FormItem>
                                                <FormLabel>To Date</FormLabel>
                                                <FormControl className="w-full">
                                                    <Popover>
                                                        <PopoverTrigger asChild>
                                                            <Button
                                                                variant={"outline"}
                                                                disabled={!startDate} // Disable if start_date not selected
                                                                className={cn("justify-start text-left font-normal")}
                                                            >
                                                                <CalendarIcon className="mr-2 h-4 w-4" />
                                                                {field.value
                                                                    ? dayjs(field.value).format("DD-MM-YYYY")
                                                                    : <span>Pick a date</span>}
                                                            </Button>
                                                        </PopoverTrigger>
                                                        <PopoverContent className="w-auto p-0">
                                                            <Calendar
                                                                mode="single"
                                                                selected={field.value ? new Date(field.value) : undefined}
                                                                onSelect={field.onChange}
                                                                disabled={!startDate}
                                                                // Only allow selecting end date after start date
                                                                fromDate={startDate ? new Date(startDate) : undefined}
                                                            />
                                                        </PopoverContent>
                                                    </Popover>
                                                </FormControl>
                                                <FormMessage />
                                            </FormItem>
                                        );
                                    }}
                                />


                                <FormField
                                    control={form.control}
                                    name="tour_location"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Tour/Project Location</FormLabel>
                                            <FormControl>
                                                <Input type='text' {...field} placeholder="Enter Tour/Project Location" />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="description"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Tour Description</FormLabel>
                                            <FormControl>
                                                <Input type='text' {...field} placeholder="Enter Tour Description" />
                                            </FormControl>
                                        </FormItem>
                                    )}
                                />
                            </div>
                            <Button type="submit">Submit</Button>
                            <Button type="button" onClick={handleReset} className="ml-4">Reset</Button>
                        </form>
                    </Form>
                </CardContent>
            </Card>
            <div className="w-full mt-5">
                <div className="flex items-center py-4">
                    <Input
                        placeholder="Filter by date..."
                        value={
                            (table.getColumn('date')?.getFilterValue() as string) ?? ''
                        }
                        onChange={event =>
                            table.getColumn('date')?.setFilterValue(event.target.value)
                        }
                        className="max-w-sm"
                    />
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="outline" className="ml-auto">
                                Columns <ChevronDown className="ml-2 h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            {table
                                .getAllColumns()
                                .filter(column => column.getCanHide())
                                .map(column => {
                                    return (
                                        <DropdownMenuCheckboxItem
                                            key={column.id}
                                            className="capitalize"
                                            checked={column.getIsVisible()}
                                            onCheckedChange={value =>
                                                column.toggleVisibility(!!value)
                                            }
                                        >
                                            {column.id}
                                        </DropdownMenuCheckboxItem>
                                    )
                                })}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            {table.getHeaderGroups().map(headerGroup => (
                                <TableRow key={headerGroup.id}>
                                    {headerGroup.headers.map(header => {
                                        return (
                                            <TableHead key={header.id}>
                                                {header.isPlaceholder
                                                    ? null
                                                    : flexRender(
                                                        header.column.columnDef.header,
                                                        header.getContext()
                                                    )}
                                            </TableHead>
                                        )
                                    })}
                                </TableRow>
                            ))}
                        </TableHeader>
                        <TableBody>
                            {table.getRowModel().rows?.length ? (
                                table.getRowModel().rows.map((row, index) => (
                                    <TableRow
                                        key={row.id}
                                        data-state={row.getIsSelected() && 'selected'}
                                    >
                                        {row.getVisibleCells().map(cell => (
                                            <TableCell key={cell.id}>
                                                {flexRender(
                                                    cell.column.columnDef.cell,
                                                    cell.getContext()
                                                )}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell
                                        colSpan={columns.length}
                                        className="h-24 text-center"
                                    >
                                        No results.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>
                <div className="flex items-center justify-end space-x-2 py-4">
                    <div className="flex-1 text-sm text-muted-foreground">
                        {table.getFilteredSelectedRowModel().rows.length} of{' '}
                        {table.getFilteredRowModel().rows.length} row(s) selected.
                    </div>
                    <div className="space-x-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.previousPage()}
                            disabled={!table.getCanPreviousPage()}
                        >
                            Previous
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.nextPage()}
                            disabled={!table.getCanNextPage()}
                        >
                            Next
                        </Button>
                    </div>
                </div>
            </div>

            {/* Edit Leave Dialog */}
            <Dialog open={isEditLeaveOpen} onOpenChange={setIsEditLeaveOpen}>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <DialogTitle>Edit Tour</DialogTitle>
                        <DialogDescription>
                            Make changes to your leave details here. Click save when you're done.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="leaveType" className="text-right">
                                Project:
                            </Label>
                            <select
                                id="leaveType"
                                className="col-span-3 border px-3 py-2 rounded"
                                name="leaveType"
                                value={selectedRow?.project_id}
                                onChange={(e) => {
                                    setSelectedRow({
                                        ...(selectedRow as TourData),
                                        project_id: e.target.value,
                                    });
                                }}
                            >
                                <option value="">Select a project</option>
                                {getProjectList?.data?.map((project: any) => (
                                    <option key={project.id} value={project.id}>
                                        {project.project_name}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="tour_type" className="text-right">
                                Tour Type:
                            </Label>
                            <Input
                                id="tour_type"
                                className="col-span-3"
                                name="tour_type"
                                value={selectedRow?.tour_type == "1" ? "General" : selectedRow?.tour_type == "2" ? "Short Tour" : ""}
                                disabled
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="start_date" className="text-right">
                                Start Date:
                            </Label>
                            <Input
                                id="start_date"
                                className="col-span-3"
                                name="start_date"
                                value={selectedRow?.start_date || ""}
                                disabled
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="end_date" className="text-right">
                                End Date:
                            </Label>
                            <Input
                                id="end_date"
                                className="col-span-3"
                                name="end_date"
                                value={selectedRow?.end_date || ""}
                                disabled
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="tour_location" className="text-right">
                                Tour/Project Location:
                            </Label>
                            <Input
                                id="tour_location"
                                className="col-span-3"
                                name="tour_location"
                                value={selectedRow?.tour_location || ""}
                                onChange={(e) =>
                                    setSelectedRow({
                                        ...(selectedRow as TourData),
                                        tour_location: e.target.value
                                    })
                                }
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="description" className="text-right">
                                Description:
                            </Label>
                            <Input
                                id="description"
                                className="col-span-3"
                                name="description"
                                value={selectedRow?.description || ""}
                                onChange={(e) =>
                                    setSelectedRow({
                                        ...(selectedRow as TourData),
                                        description: e.target.value
                                    })
                                }
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button type="submit" onClick={confirmEdit} >Save changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <DialogTitle>Delete Leave</DialogTitle>
                        <DialogDescription>
                            Are you sure you want to delete this leave request? This action cannot be undone.
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>Cancel</Button>
                        <Button variant="destructive" onClick={confirmDelete}>Delete</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    )
}

export default applyTour