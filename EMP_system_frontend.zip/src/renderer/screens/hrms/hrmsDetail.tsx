import React, { useEffect, useState } from 'react'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from 'renderer/components/ui/tabs'
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from 'renderer/components/ui/card'
import { Input } from 'renderer/components/ui/input'
import { Button } from 'renderer/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from 'renderer/components/ui/select'
import {
  type ColumnDef,
  type ColumnFiltersState,
  type SortingState,
  type VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table'
import { ArrowUpDown, ChevronDown } from 'lucide-react'
import { useForm } from "react-hook-form";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
} from "../../components/ui/form";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../../components/ui/accordion"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from 'renderer/components/ui/dropdown-menu'
import { toast } from 'sonner'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from 'renderer/components/ui/table'
import ApplyLeave from './applyLeave';
import LeaveList from './leaveList';
import SalarySlip from './salarySlip';
import Form16 from './form16';
import ApplyTour from './applyTour';
import { useMutation } from '@tanstack/react-query'
import { AttendenceListApi } from 'renderer/service/hrmsServices'
import dayjs from 'dayjs';

export type Attendance = {
  id: string
  date: string
  status: 'present' | 'absent' | 'half-day'
  in_time: string
  out_time: string
  late_by: string | null
  early_by: string | null
  working_hour: number
  working_status: string | null
}
interface AttendenceFormValues {
  month: string
  year: string
}

export const columns: ColumnDef<Attendance>[] = [
  {
    accessorKey: 'srNo',
    header: 'Sr. No',
    cell: ({ row }) => <div className="text-left">{row.index + 1}</div>,
  },
  {
    accessorKey: 'date',
    header: ({ column }) => (
      <Button
        className="!p-0 !px-0"
        variant="ghost"
        onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}
      >
        Date
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    ),
  },
  {
    accessorKey: 'in_time',
    header: 'Check In',
  },
  {
    accessorKey: 'out_time',
    header: 'Check Out',
  },
  {
    accessorKey: 'late_by',
    header: 'Late By',
    cell: ({ row }) => {
      const lateBy = row.getValue('late_by') as string | null
      return <div className="text-red-500">{lateBy || '-'}</div>
    },
  },
  {
    accessorKey: 'early_by',
    header: 'Early By',
    cell: ({ row }) => {
      const earlyBy = row.getValue('early_by') as string | null
      return <div className="text-orange-500">{earlyBy || '-'}</div>
    },
  },
  {
    accessorKey: 'working_hour',
    header: 'Working Hours',
    cell: ({ row }) => {
      const workingHours = row.getValue('working_hour')
      const workingHoursStr = `${workingHours}` // or use `.toString()`
      return <div className="text-left font-medium">{workingHoursStr} hrs</div>
    },
  },
  {
    accessorKey: 'action',
    header: 'Status',
    cell: ({ row }) => (
      <Accordion type="single" collapsible>
        <AccordionItem value="item-1">
          <AccordionTrigger>Details</AccordionTrigger>
          <AccordionContent>
            <div className='flex gap-x-8'>
              <div>
                {
                  (row.getValue('action') as Array<[string, string]>)?.map((item, index) => {
                    return (
                      <p key={`action-${index}-0`}>{item[0]}</p>
                    )
                  })
                }
              </div>
              <div>
                {
                  (row.getValue('action') as Array<[string, string]>)?.map((item, index) => {
                    return (
                      <p key={`action-${index}-1`}>{item[1]}</p>
                    )
                  })
                }
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    ),
  },
  {
    accessorKey: 'working_status',
    header: 'Remaining Time',
    cell: ({ row }) => (
      <div className="capitalize">{row.getValue('working_status')}</div>
    ),
  },
]


const HrmsDetail = () => {
  const [sorting, setSorting] = React.useState<SortingState>([])
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  )
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({})
  const [rowSelection, setRowSelection] = React.useState({})
  const [showAttendenceData, setShowAttendenceData] = useState<Attendance[]>([]);
  const currentMonth = dayjs().format('M');
  const currentYear = dayjs().format('YYYY');

  const form = useForm<AttendenceFormValues>({
    defaultValues: {
      month: currentMonth,
      year: currentYear,
    },
    mode: 'onChange',
  })

  const attendenceListMutation = useMutation({
    mutationFn: AttendenceListApi,
    onSuccess: data => {
      setShowAttendenceData(data.data)
      toast.success('Attendence list loaded successfully!')
    },
    onError: (error: any) => {
      if (error?.status === 404) {
        toast.error('There is no Attendance on this select month')
      } else {
        toast.error(error?.response?.data?.message)
      }
      setShowAttendenceData([])
    },
  })

  function onSubmit(data: AttendenceFormValues) {
    attendenceListMutation.mutate({
      month: data.month,
      year: data.year,
    })
  }

  function handleReset() {
    form?.reset();
  }

  useEffect(() => {
    attendenceListMutation.mutate({
      month: currentMonth,
      year: currentYear,
    });
  }, [])


  const table = useReactTable({
    data: showAttendenceData || [],
    columns,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
    },
  })

  return (
    <div className="p-8">
      <Tabs defaultValue="attendanceInfo" className="rounded-md">
        <TabsList className="grid w-full grid-cols-6 mb-6">
          <TabsTrigger value="attendanceInfo">Attendance Info</TabsTrigger>
          <TabsTrigger value="applyLeave">Apply Leave</TabsTrigger>
          <TabsTrigger value="leaveList">Leave List</TabsTrigger>
          <TabsTrigger value="salarySlip">Salary Slip</TabsTrigger>
          <TabsTrigger value="form16">Form 16</TabsTrigger>
          <TabsTrigger value="applyTour">Apply Tour</TabsTrigger>
        </TabsList>
        <TabsContent value="attendanceInfo">
          <Card>
            <CardHeader>
              <CardTitle className="font-medium text-3xl mt-1 mb-2 text-left">
                Attendance Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1 w-full flex gap-4">
              <Form {...form} >
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 w-full">
                  <div className="w-full grid grid-cols-4 gap-4">
                    <FormField
                      control={form.control}
                      name="month"
                      render={({ field }) => (
                        <FormItem className="w-full">
                          <FormLabel>Year:</FormLabel>
                          <div className="w-full">
                            <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value} >
                              <FormControl>
                                <SelectTrigger className=" w-full">
                                  <SelectValue placeholder="Select Year" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="1">January</SelectItem>
                                <SelectItem value="2">February</SelectItem>
                                <SelectItem value="3">March</SelectItem>
                                <SelectItem value="4">April</SelectItem>
                                <SelectItem value="5">May</SelectItem>
                                <SelectItem value="6">June</SelectItem>
                                <SelectItem value="7">July</SelectItem>
                                <SelectItem value="8">August</SelectItem>
                                <SelectItem value="9">September</SelectItem>
                                <SelectItem value="10">October</SelectItem>
                                <SelectItem value="11">November</SelectItem>
                                <SelectItem value="12">December</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="year"
                      render={({ field }) => (
                        <FormItem className="w-full">
                          <FormLabel>Year:</FormLabel>
                          <div className="w-full">
                            <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value} >
                              <FormControl>
                                <SelectTrigger className=" w-full">
                                  <SelectValue placeholder="Select Year" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="2025">2025</SelectItem>
                                <SelectItem value="2024">2024</SelectItem>
                                <SelectItem value="2023">2023</SelectItem>
                                <SelectItem value="2022">2022</SelectItem>
                                <SelectItem value="2021">2021</SelectItem>
                                <SelectItem value="2020">2020</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>
                  <Button className="mt-6">Filter Record</Button>
                  <Button type='button' className="mt-6 ml-6" onClick={handleReset} >Reset</Button>
                </form>
              </Form>

            </CardContent>
          </Card>
          <div className="w-full mt-5">
            <div className="flex items-center py-4">
              <Input
                placeholder="Filter by date..."
                value={
                  (table.getColumn('date')?.getFilterValue() as string) ?? ''
                }
                onChange={event =>
                  table.getColumn('date')?.setFilterValue(event.target.value)
                }
                className="max-w-sm"
              />
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="ml-auto">
                    Columns <ChevronDown className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {table
                    .getAllColumns()
                    .filter(column => column.getCanHide())
                    .map(column => {
                      return (
                        <DropdownMenuCheckboxItem
                          key={column.id}
                          className="capitalize"
                          checked={column.getIsVisible()}
                          onCheckedChange={value =>
                            column.toggleVisibility(!!value)
                          }
                        >
                          {column.id}
                        </DropdownMenuCheckboxItem>
                      )
                    })}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  {table.getHeaderGroups().map(headerGroup => (
                    <TableRow key={headerGroup.id}>
                      {headerGroup.headers.map(header => {
                        return (
                          <TableHead key={header.id}>
                            {header.isPlaceholder
                              ? null
                              : flexRender(
                                header.column.columnDef.header,
                                header.getContext()
                              )}
                          </TableHead>
                        )
                      })}
                    </TableRow>
                  ))}
                </TableHeader>
                <TableBody>
                  {table.getRowModel().rows?.length ? (
                    table.getRowModel().rows.map((row, index) => (
                      <TableRow
                        key={row.id}
                        data-state={row.getIsSelected() && 'selected'}
                      // className={index % 2 === 0 ? 'bg-secondary' : ''} // Even rows get gray, odd rows white
                      >
                        {row.getVisibleCells().map(cell => (
                          <TableCell key={cell.id}>
                            {flexRender(
                              cell.column.columnDef.cell,
                              cell.getContext()
                            )}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={columns.length}
                        className="h-24 text-center"
                      >
                        No results.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
            <div className="flex items-center justify-end space-x-2 py-4">
              <div className="flex-1 text-sm text-muted-foreground">
                {table.getFilteredSelectedRowModel().rows.length} of{' '}
                {table.getFilteredRowModel().rows.length} row(s) selected.
              </div>
              <div className="space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => table.previousPage()}
                  disabled={!table.getCanPreviousPage()}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => table.nextPage()}
                  disabled={!table.getCanNextPage()}
                >
                  Next
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="applyLeave">
          <ApplyLeave />
        </TabsContent>

        <TabsContent value="leaveList">
          <LeaveList />
        </TabsContent>

        <TabsContent value="salarySlip">
          <SalarySlip />
        </TabsContent>

        <TabsContent value="form16">
          <Form16 />
        </TabsContent>

        <TabsContent value="applyTour">
          <ApplyTour />
        </TabsContent>

      </Tabs>
    </div>
  )
}

export default HrmsDetail
