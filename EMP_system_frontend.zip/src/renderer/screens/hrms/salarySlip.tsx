import React, { useMemo, useState } from 'react'
import { Button } from 'renderer/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from 'renderer/components/ui/card'
import { Label } from 'renderer/components/ui/label'
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from 'renderer/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "renderer/components/ui/table"
import { Download } from "lucide-react"
import { useQuery } from '@tanstack/react-query'
import { getPayslipList } from 'renderer/service/hrmsServices'


const salarySlip = () => {
    const currentYear = new Date().getFullYear()
    const [selectedYear, setSelectedYear] = useState(currentYear.toString())

    const years = useMemo(() => {
        const yearList = []
        for (let y = currentYear; y >= 2016; y--) {
            yearList.push(y)
        }
        return yearList
    }, [currentYear])

    const { data } = useQuery({
        queryKey: ['payslipList', selectedYear],
        queryFn: () => getPayslipList({ year: selectedYear })
    })
    console.log("Payslip API Response:", data);

    return (
        <div>
            <Card>
                <CardHeader>
                    <CardTitle className="font-medium text-3xl mt-1 mb-2 text-left">
                        Salary Slip
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1 w-full flex gap-4">
                    <div className="space-y-3 w-[35%]">
                        <Label htmlFor="year">Year</Label>
                        <Select value={selectedYear} onValueChange={setSelectedYear}>
                            <SelectTrigger className="w-full">
                                <SelectValue placeholder="Select a Year" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectGroup>
                                    <SelectLabel>Year</SelectLabel>
                                    {years.map((year) => (
                                        <SelectItem key={year} value={year.toString()}>
                                            {year}
                                        </SelectItem>
                                    ))}
                                </SelectGroup>
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>
            <div className="mt-5 overflow-auto">
                <Table className='border'>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Sr No</TableHead>
                            <TableHead>Year</TableHead>
                            <TableHead>Month</TableHead>
                            <TableHead>File Name</TableHead>
                            <TableHead className="text-center">Action</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {Array.isArray(data?.data?.payslipdetails) && data?.data?.payslipdetails.length > 0 ? (
                            data?.data?.payslipdetails?.map((user: any, index: number) => (
                                <TableRow key={user.id}>
                                    <TableCell>{index + 1}</TableCell>
                                    <TableCell>{user.year}</TableCell>
                                    <TableCell>{user.month}</TableCell>
                                    <TableCell>{user.filename}</TableCell>
                                    <TableCell className="text-center">
                                        <a href={data?.data?.defalut_urls + user.fullpath} download target="_blank" rel="noopener noreferrer">
                                            <Button>
                                                <Download className="w-4 h-4 mr-1" />
                                                Download
                                            </Button>
                                        </a>
                                    </TableCell>
                                </TableRow>
                            ))
                        ) : (
                            <TableRow>
                                <TableCell colSpan={7} className="text-center">
                                    No Payslips Available
                                </TableCell>
                            </TableRow>
                        )}
                    </TableBody>
                </Table>
            </div>
        </div>
    )
}

export default salarySlip