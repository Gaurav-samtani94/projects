export const uiConstants = {
  windowHeaderHeight: 40,
  footerHeight: 28,
}
