import * as React from "react";
// import { CalendarIcon } from "@radix-ui/react-icons";
import { format } from "date-fns";

import { cn } from "renderer/lib/utils";
import { Button } from "renderer/components/ui/button";
import { Calendar } from "renderer/components/ui/calendar";
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "renderer/components/ui/popover";
import { ScrollArea, ScrollBar } from "renderer/components/ui/scroll-area";
import { CalendarIcon } from "lucide-react";
import dayjs from "dayjs";

interface DateTimePickerProps {
    value: Date | null;
    onChange: (date: Date) => void;
    isOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    minDate?: Date;
    disabled?: boolean; // Add the disabled prop here
    minTime?: Date;
    maxTime?: Date; // Time-based validation for start time

}

function DateTimePicker({
    value,
    onChange,
    isOpen,
    onOpenChange,
    minDate,
    disabled,
    minTime,
    maxTime
}: DateTimePickerProps) {
    const hours = Array.from({ length: 12 }, (_, i) => i + 1);

    const handleDateSelect = (selectedDate: Date | undefined) => {
        if (selectedDate) {
            if (minDate && dayjs(selectedDate).isBefore(minDate, 'day')) {
                // If the selected date is before minDate, we don't update the value
                return;
            }
            const newDate = new Date(selectedDate);
            // If time is already set, keep it
            if (value) {
                newDate.setHours(value.getHours());
                newDate.setMinutes(value.getMinutes());
            }
            onChange(newDate);
        }
    };

    const handleTimeChange = (
        type: "hour" | "minute" | "ampm",
        newValue: string
    ) => {
        if (!value) return;

        const newDate = new Date(value);
        if (type === "hour") {
            newDate.setHours(
                (Number.parseInt(newValue) % 12) + (newDate.getHours() >= 12 ? 12 : 0)
            );
        } else if (type === "minute") {
            newDate.setMinutes(Number.parseInt(newValue));
        } else if (type === "ampm") {
            const hours = newDate.getHours();
            if (newValue === "PM" && hours < 12) newDate.setHours(hours + 12);
            if (newValue === "AM" && hours >= 12) newDate.setHours(hours - 12);
        }

        // Ensure the new date is after the minimum time (for end time)
        // if (minTime && newDate <= minTime) {
        //     return; // Do not allow setting a time before the start time
        // }

        // if (maxTime && maxTime >= newDate) {
        //     return; // Do not allow setting a start time after the end time
        // }

        onChange(newDate);
    };

    // const isStartTimeDisabled = (hour: number, minute: number) => {
    //     const now = new Date();
    //     const selectedDate = new Date(value || now); // If value is not set, use current time
    //     selectedDate.setHours(hour);
    //     selectedDate.setMinutes(minute);

    //     return selectedDate <= now; // Disable any time earlier than the current time
    // };


    return (
        <Popover open={isOpen} onOpenChange={onOpenChange}>
            <PopoverTrigger asChild>
                <Button
                    variant="outline"
                    className={cn(
                        "w-full justify-start text-left font-normal",
                        !value && "text-muted-foreground"
                    )}
                    disabled={disabled}
                >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {value ? format(value, "MM/dd/yyyy hh:mm aa") : "MM/DD/YYYY hh:mm aa"}
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
                <div className="sm:flex">
                    <Calendar
                        mode="single"
                        selected={value ?? undefined}
                        onSelect={handleDateSelect}
                        initialFocus
                        disabled={disabled}
                    />
                    <div className="flex flex-col sm:flex-row sm:h-[300px] divide-y sm:divide-y-0 sm:divide-x">
                        <ScrollArea className="w-64 sm:w-auto">
                            <div className="flex sm:flex-col p-2">
                                {hours
                                    .slice()
                                    .reverse()
                                    .map((hour) => (
                                        <Button
                                            key={hour}
                                            size="icon"
                                            variant={
                                                value && value.getHours() % 12 === hour % 12
                                                    ? "default"
                                                    : "ghost"
                                            }
                                            className="sm:w-full shrink-0 aspect-square"
                                            onClick={() => handleTimeChange("hour", hour.toString())}
                                            disabled={disabled}
                                        >
                                            {hour}
                                        </Button>
                                    ))}
                            </div>
                            <ScrollBar orientation="horizontal" className="sm:hidden" />
                        </ScrollArea>
                        <ScrollArea className="w-64 sm:w-auto">
                            <div className="flex sm:flex-col p-2">
                                {Array.from({ length: 12 }, (_, i) => i * 5).map((minute) => (
                                    <Button
                                        key={minute}
                                        size="icon"
                                        variant={
                                            value && value.getMinutes() === minute
                                                ? "default"
                                                : "ghost"
                                        }
                                        className="sm:w-full shrink-0 aspect-square"
                                        onClick={() =>
                                            handleTimeChange("minute", minute.toString())
                                        }
                                        disabled={disabled}
                                    >
                                        {minute}
                                    </Button>
                                ))}
                            </div>
                            <ScrollBar orientation="horizontal" className="sm:hidden" />
                        </ScrollArea>
                        <ScrollArea>
                            <div className="flex sm:flex-col p-2">
                                {["AM", "PM"].map((ampm) => (
                                    <Button
                                        key={ampm}
                                        size="icon"
                                        variant={
                                            value &&
                                                ((ampm === "AM" && value.getHours() < 12) ||
                                                    (ampm === "PM" && value.getHours() >= 12))
                                                ? "default"
                                                : "ghost"
                                        }
                                        className="sm:w-full shrink-0 aspect-square"
                                        onClick={() => handleTimeChange("ampm", ampm)}
                                        disabled={disabled}
                                    >
                                        {ampm}
                                    </Button>
                                ))}
                            </div>
                        </ScrollArea>
                    </div>
                </div>
            </PopoverContent>
        </Popover>
    );
}

export default DateTimePicker