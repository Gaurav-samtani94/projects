import { Moon, Sun } from "lucide-react"
import { Button } from "./button"
import { useTheme } from "renderer/layout/theme-provider";

export function ModeToggle() {
    // const { setTheme } = useTheme()
    const { theme, toggleTheme } = useTheme();


    const handleThemeToggle = (event: React.MouseEvent<HTMLButtonElement>) => {
        const { clientX: x, clientY: y } = event;
        toggleTheme({ x, y });
    };
    return (
        <div>
            <Button
                variant="ghost"
                size="icon"
                className="border-dashed"
                onClick={handleThemeToggle}
            >
                {theme === "dark" ? (
                    <Moon className="size-3" />
                ) : (
                    <Sun className="size-3" />
                )}
            </Button>
        </div>
    )
}
