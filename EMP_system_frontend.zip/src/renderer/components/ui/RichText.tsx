import React, { useEffect, useRef, useState } from 'react'
import {
    BlockTypeSelect,
    BoldItalicUnderlineToggles,
    CreateLink,
    headingsPlugin,
    imagePlugin,
    InsertImage,
    InsertTable,
    linkDialogPlugin,
    linkPlugin,
    listsPlugin,
    ListsToggle,
    markdownShortcutPlugin,
    MDXEditor,
    quotePlugin,
    Separator,
    tablePlugin,
    thematicBreakPlugin,
    toolbarPlugin,
    UndoRedo
} from "@mdxeditor/editor";
import '@mdxeditor/editor/style.css'


interface DateTimePickerProps {
    value?: string | undefined;
    onChange?: (value: string) => void;
    key?: any
}

const RichText = ({
    value,
    onChange,
    key
}: DateTimePickerProps) => {

    const [tempValue, setTempValue] = useState('')
    const editorRef = useRef<any>(null);

    useEffect(() => {
        if (editorRef.current && value !== undefined) {
            editorRef.current.setMarkdown(value);
        }
    }, [value]);

    const handleUpdateRichTextValue = (v: string) => {
        if (onChange) {
            onChange(v)
        } else {
            setTempValue(v)
        }

    }
    return (
        <MDXEditor
            // key={value ?? tempValue}
            ref={editorRef}
            key={key}
            markdown={value ?? tempValue}
            onChange={handleUpdateRichTextValue}
            placeholder="Write a description..."
            className="border rounded-lg prose-sm md:prose max-w-full editor-content text-muted-foreground"
            contentEditableClassName="overflow-y-auto py-2 whitespace-normal text-start"
            plugins={
                [
                    toolbarPlugin({
                        toolbarContents: () => (
                            <div className={'flex gap-1'}>
                                {' '}
                                <UndoRedo />
                                <ListsToggle />
                                <Separator />
                                {/* <InsertImage /> */}
                                {/*<Select  items={}/>*/}
                                <div className={'hidden md:flex gap-1'}>
                                    <BoldItalicUnderlineToggles />
                                    <BlockTypeSelect />
                                    <CreateLink />
                                    <InsertTable />
                                </div>
                            </div>
                        )
                    }),
                    headingsPlugin(),
                    listsPlugin(),
                    quotePlugin(),
                    thematicBreakPlugin(),
                    markdownShortcutPlugin(),
                    tablePlugin(),
                    // imagePlugin({
                    //     imageUploadHandler: onUpload,
                    // }),
                    linkPlugin(),
                    linkDialogPlugin(),
                ]}
        />
    )
}

export default RichText