import React from 'react';
import { Pencil, Plus } from 'lucide-react';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle
} from '../ui/dialog';
import { Avatar, AvatarImage } from '../ui/avatar';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '../ui/command';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { useChatStore } from 'stores/useChatStore';
import { GroupProfileUpdate } from 'renderer/service/authService';
import { toast } from 'sonner';

type GroupEditProps = {
    selectGroup: any;
    group_UserId: any;
};

const GroupEdit = ({ selectGroup, group_UserId }: GroupEditProps) => {
    const { allUsers, setSelectGroup } = useChatStore();
    const [open, setOpen] = React.useState(false);
    const [groupName, setGroupName] = React.useState(selectGroup?.groupName);
    const [groupDescription, setGroupDescription] = React.useState('');
    const [selectedMembers, setSelectedMembers] = React.useState<string[]>([...group_UserId]);
    const [avatarFile, setAvatarFile] = React.useState<File>();
    const [add, setAdd] = React.useState(false);

    const handleMemberToggle = (name: string) => {
        setSelectedMembers((prev) =>
            prev.includes(name) ? prev.filter((m) => m !== name) : [...prev, name]
        );
    };


    const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) setAvatarFile(file);
    };

    const changeAvatar = async () => {
        try {
            await GroupProfileUpdate({
                group_id: selectGroup.groupId,
                group_name: groupName,
                description: "",
                file: avatarFile,
                user_ids: selectedMembers.map(String),
            });

            toast.success("Group updated successfully!");
            setOpen(false);
            setSelectGroup(null);
        } catch (error) {
            console.error("Avatar update failed:", error);
            toast.error("Failed to update group avatar");
        }
    };

    console.log("Selected members:", selectedMembers);

    return (
        <div>
            {/* biome-ignore lint/a11y/useKeyWithClickEvents: <explanation> */}
            <div onClick={() => setOpen(true)} className="cursor-pointer text-black hover:underline">
                Edit Group
            </div>

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="gap-0 p-0 outline-none">
                    <DialogHeader className="px-4 pb-2 pt-5">
                        <DialogTitle>Edit Group</DialogTitle>
                        <DialogDescription>Update group details and members.</DialogDescription>
                    </DialogHeader>

                    <div className="flex flex-col gap-4 px-4 py-3">
                        {/* Avatar */}
                        <div className="self-center relative w-20 h-20">
                            <Avatar className="w-full h-full">
                                <AvatarImage
                                    src={
                                        avatarFile
                                            ? URL.createObjectURL(avatarFile)
                                            : "https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y"
                                    }
                                />
                            </Avatar>
                            <input
                                type="file"
                                id="changeinnerAvatar"
                                onChange={handleAvatarChange}
                                style={{ display: 'none' }}
                            />
                            <button
                                className="absolute bottom-0 right-0 bg-white rounded-full p-1 shadow hover:bg-gray-100"
                                title="Change Avatar"
                                onClick={() => document.getElementById('changeinnerAvatar')?.click()}
                            >
                                <Pencil className="w-4 h-4 text-gray-700" />
                            </button>
                        </div>
                        <Input
                            placeholder="Group Title"
                            value={groupName}
                            onChange={(e) => setGroupName(e.target.value)}
                        />

                        <Textarea
                            placeholder="Group Description"
                            value={groupDescription}
                            onChange={(e) => setGroupDescription(e.target.value)}
                        />
                        <div>
                            <div className="flex items-center justify-between px-3 py-2 bg-gray-50 rounded-md shadow-sm border border-gray-200 mb-3">
                                <div className="text-sm font-semibold text-gray-800">Add Members</div>
                                <button onClick={() => setAdd(!add)} className="p-1 rounded hover:bg-gray-200 transition-colors duration-150">
                                    <Plus className="w-4 h-4 text-gray-600" />
                                </button>
                            </div>

                            {add && <Command className="border rounded-md max-h-48 overflow-y-auto">
                                <CommandInput placeholder="Search members..." />
                                <CommandList>
                                    <CommandEmpty>No users found.</CommandEmpty>
                                    <CommandGroup>
                                        {allUsers.map((user) => (
                                            <CommandItem
                                                key={user?.id}
                                                value={user?.userfullname}
                                                onSelect={() => handleMemberToggle(user.id)}
                                            >
                                                <span className="flex items-center gap-2">
                                                    <input
                                                        type="checkbox"
                                                        checked={selectedMembers.includes(user.id)}
                                                        readOnly
                                                    />
                                                    {user.userfullname}
                                                </span>
                                            </CommandItem>
                                        ))}
                                    </CommandGroup>
                                </CommandList>
                            </Command>}
                        </div>
                    </div>

                    <DialogFooter className="p-4">
                        <Button type="submit" onClick={() => {
                            changeAvatar();
                        }}>
                            Save Changes
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default GroupEdit;
