import { useState } from "react"
import { Check, PlusCircle } from "lucide-react"

import { cn } from "renderer/lib/utils"
import { Badge } from "renderer/components/ui/badge"
import { Button } from "renderer/components/ui/button"
import {
    Command,
    CommandEmpty,
    CommandGroup,
    CommandInput,
    CommandItem,
    CommandList,
    CommandSeparator,
} from "renderer/components/ui/command"
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "renderer/components/ui/popover"
import { Separator } from "renderer/components/ui/separator"

const staticOptions = [
    { label: "Option A", value: "a" },
    { label: "Option B", value: "b" },
    { label: "Option C", value: "c" },
]

interface DataTableFacetedFilterProps {
    title?: string;
    options: any;
    setStatusFiltering?: any;
    setPriorityFiltering?: any;

}

export function MultiSelectFilter({ title, options, setStatusFiltering, setPriorityFiltering }: DataTableFacetedFilterProps) {
    const [selectedValues, setSelectedValues] = useState<Set<string>>(new Set())

    const toggleValue = (value: string) => {
        const newSelected = new Set(selectedValues)
        if (newSelected.has(value)) {
            newSelected.delete(value)
        } else {
            newSelected.add(value)
        }
        setSelectedValues(newSelected)

        if (setStatusFiltering) {
            setStatusFiltering(newSelected)
        }
        if (setPriorityFiltering) {
            setPriorityFiltering(newSelected)
        }
    }

    const clearAll = () => {
        setSelectedValues(new Set());
        if (setStatusFiltering) {
            setStatusFiltering(new Set());
        }
        if (setPriorityFiltering) {
            setPriorityFiltering(new Set());
        }
    }

    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button variant="outline" className="border-dashed">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    {title}
                    {selectedValues.size > 0 && (
                        <>
                            <Separator orientation="vertical" className="mx-2 h-4" />
                            <Badge variant="secondary" className="rounded-sm px-1 font-normal">
                                {selectedValues.size} selected
                            </Badge>
                        </>
                    )}
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[200px] p-0" align="start">
                <Command>
                    <CommandInput placeholder="Search..." />
                    <CommandList>
                        <CommandEmpty>No results found.</CommandEmpty>
                        <CommandGroup>
                            {options?.map((option: any) => {
                                const isSelected = selectedValues.has(option.id)
                                return (
                                    <CommandItem
                                        key={option.id}
                                        onSelect={() => toggleValue(option.id)}
                                        style={{ cursor: "pointer" }}
                                    >
                                        <div
                                            className={cn(
                                                "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                                isSelected
                                                    ? "bg-primary text-primary-foreground"
                                                    : "opacity-50 [&_svg]:invisible"
                                            )}
                                        >
                                            <Check className="text-white" />
                                        </div>
                                        <span>{option.option_name}</span>
                                    </CommandItem>
                                )
                            })}
                        </CommandGroup>
                        {selectedValues.size > 0 && (
                            <>
                                <CommandSeparator />
                                <CommandGroup>
                                    <CommandItem
                                        onSelect={clearAll}
                                        className="justify-center text-center cursor-pointer"
                                    >
                                        Clear filters
                                    </CommandItem>
                                </CommandGroup>
                            </>
                        )}
                    </CommandList>
                </Command>
            </PopoverContent>
        </Popover>
    )
}
