"use client"

import { NotificationContent } from "renderer/components/sections/notification/notification-content"

export function NotificationDashboard() {
  return (
    <div className="flex h-screen overflow-hidden">
      <NotificationContent />
    </div>
  )
}
