"use client"

import { useState } from "react"
import { Filter, Search } from "lucide-react"
import { Button } from "renderer/components/ui/button"
import { Input } from "renderer/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "renderer/components/ui/tabs"
import { NotificationItem } from "renderer/components/sections/notification/notification-item"
import { NotificationDetail } from "renderer/components/sections/notification/notification-detail"
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "renderer/components/ui/resizable"

// Sample notification data
const notifications = [
  {
    id: "1",
    title: "Welcome to the platform!",
    icon: "bell",
    time: "20 hours ago",
    read: false,
    type: "system",
    content: "Welcome to our notification system! Get started by exploring the features.",
  },
  {
    id: "2",
    title: "New task assigned",
    icon: "check",
    time: "3 days ago",
    read: false,
    type: "task",
    content: "You have been assigned a new task. Please review and take action.",
  },
  {
    id: "3",
    title: "Project update",
    icon: "bell",
    time: "3 days ago",
    read: true,
    type: "system",
    content: "The project has been updated with new requirements. Check the latest changes.",
  },
  {
    id: "4",
    title: "Meeting reminder",
    icon: "calendar",
    time: "3 days ago",
    read: true,
    type: "reminder",
    content: "Don't forget about the team meeting scheduled for tomorrow at 10:00 AM.",
  },
  {
    id: "5",
    title: "System maintenance",
    icon: "settings",
    time: "4 days ago",
    read: true,
    type: "system",
    content: "The system will undergo maintenance this weekend. Please save your work.",
  },
]

export function NotificationContent() {
  const [selectedNotification, setSelectedNotification] = useState(notifications[0])
  const [activeTab, setActiveTab] = useState("all")

  const filteredNotifications =
    activeTab === "all" ? notifications : notifications.filter((notification) => notification.type === activeTab)

  return (
    <ResizablePanelGroup direction="horizontal" className="h-full w-full rounded-lg">
      {/* Notification List Panel */}
      <ResizablePanel defaultSize={25} minSize={20} maxSize={40} className="flex flex-col">
        <div className="border-b p-4 flex items-center justify-between">
          <h2 className="font-semibold text-lg">Inbox</h2>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        <div className="p-3 border-b">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search notifications..." className="pl-8 h-9" />
          </div>
        </div>

        <Tabs defaultValue="all" className="flex-1 flex flex-col" onValueChange={setActiveTab}>
          <div className="border-b px-2">
            <TabsList className="w-full justify-start h-10 bg-transparent p-0">
              <TabsTrigger
                value="all"
                className="rounded-none border-0 data-[state=active]:shadow-none"
              >
                All
              </TabsTrigger>
              <TabsTrigger
                value="system"
                className="rounded-none border-0 data-[state=active]:shadow-none"
              >
                System
              </TabsTrigger>
              <TabsTrigger
                value="task"
                className="rounded-none border-0 data-[state=active]:shadow-none"
              >
                Tasks
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value={activeTab} className="flex-1 overflow-auto mt-0 p-0">
            <div className="divide-y">
              {filteredNotifications.map((notification) => (
                <NotificationItem
                  key={notification.id}
                  notification={notification}
                  isSelected={selectedNotification?.id === notification.id}
                  onClick={() => setSelectedNotification(notification)}
                />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </ResizablePanel>

      {/* Resizable Handle */}
      <ResizableHandle withHandle />

      {/* Notification Detail Panel */}
      <ResizablePanel defaultSize={75} className="overflow-auto">
        {selectedNotification && <NotificationDetail notification={selectedNotification} />}
      </ResizablePanel>
    </ResizablePanelGroup>
  )
}
