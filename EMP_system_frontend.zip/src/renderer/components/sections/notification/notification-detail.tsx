import { Button } from "renderer/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "renderer/components/ui/card"
import { Bell, Calendar, Check, MoreVertical, Settings } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "renderer/components/ui/dropdown-menu"

interface Notification {
  id: string
  title: string
  icon: string
  time: string
  read: boolean
  type: string
  content: string
}

interface NotificationDetailProps {
  notification: Notification
}

export function NotificationDetail({ notification }: NotificationDetailProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "bell":
        return <Bell className="h-5 w-5" />
      case "check":
        return <Check className="h-5 w-5" />
      case "calendar":
        return <Calendar className="h-5 w-5" />
      case "settings":
        return <Settings className="h-5 w-5" />
      default:
        return <Bell className="h-5 w-5" />
    }
  }

  return (
    <div className="p-6 h-full">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center h-10 w-10 rounded-full bg-primary/10 text-primary">
            {getIcon(notification.icon)}
          </div>
          <div>
            <h2 className="text-xl font-semibold">{notification.title}</h2>
            <p className="text-sm text-muted-foreground">{notification.time}</p>
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem>Mark as read</DropdownMenuItem>
            <DropdownMenuItem>Delete notification</DropdownMenuItem>
            <DropdownMenuItem>Mute this type</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{notification.title}</CardTitle>
          <CardDescription>
            {notification.type.charAt(0).toUpperCase() + notification.type.slice(1)} notification
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p>{notification.content}</p>

          {notification.type === "task" && (
            <div className="mt-6 p-4 bg-muted rounded-lg">
              <h4 className="font-medium mb-2">Task Details</h4>
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary" />
                  <span>Review the latest changes</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary" />
                  <span>Update documentation</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary" />
                  <span>Share feedback with the team</span>
                </li>
              </ul>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-end gap-2">
          {notification.type === "task" && <Button variant="outline">Dismiss</Button>}
          <Button>{notification.type === "task" ? "Complete Task" : "Acknowledge"}</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
