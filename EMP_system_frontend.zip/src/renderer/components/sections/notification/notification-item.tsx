"use client"

import { Bell, Calendar, Check, Settings } from "lucide-react"
import { cn } from "renderer/lib/utils"

interface Notification {
  id: string
  title: string
  icon: string
  time: string
  read: boolean
  type: string
  content: string
}

interface NotificationItemProps {
  notification: Notification
  isSelected: boolean
  onClick: () => void
}

export function NotificationItem({ notification, isSelected, onClick }: NotificationItemProps) {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "bell":
        return <Bell className="h-4 w-4" />
      case "check":
        return <Check className="h-4 w-4" />
      case "calendar":
        return <Calendar className="h-4 w-4" />
      case "settings":
        return <Settings className="h-4 w-4" />
      default:
        return <Bell className="h-4 w-4" />
    }
  }

  return (
    // biome-ignore lint/a11y/useKeyWithClickEvents: <explanation>
    <div
      className={cn(
        "p-4 cursor-pointer hover:bg-muted/50 flex items-start gap-3",
        isSelected && "bg-muted",
        !notification.read && "bg-muted/30",
      )}
      onClick={onClick}
    >
      <div
        className={cn(
          "flex items-center justify-center h-8 w-8 rounded-full bg-primary/10 text-primary",
          !notification.read && "bg-primary/20",
        )}
      >
        {getIcon(notification.icon)}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <h3 className={cn("text-sm", !notification.read && "font-medium")}>{notification.title}</h3>
          <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">{notification.time}</span>
        </div>
        <p className="text-xs text-muted-foreground mt-1 truncate">{notification.content}</p>
      </div>
    </div>
  )
}
