import React, { useState } from "react";
import type { ThemeEditorControlsProps } from "../../../Types/theme";
import ControlSection from "./themeEditor/control-section";
import ColorPicker from "./themeEditor/color-picker";
import ResetButton from "./themeEditor/reset-button";
import { ScrollArea } from "../ui/scroll-area";
import ThemePresetSelect from "./themeEditor/theme-perset-select";
import { presets } from "../../utils/theme-presets";
import { useEditorStore } from "../../store/editor-store";
import { Label } from "../ui/label";
import { SliderWithInput } from "./themeEditor/slider-with-input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "renderer/components/ui/tabs";
// import ThemeFontSelect from "./theme-font-select";
import {
  DEFAULT_FONT_MONO,
  DEFAULT_FONT_SANS,
  DEFAULT_FONT_SERIF,
  COMMON_STYLES,
} from "../../config/theme";
import { Separator } from "../ui/separator";
import { AlertCircle, FileCode } from "lucide-react";
import { Button } from "../ui/button";
import CssImportDialog from "./themeEditor/css-import-dialog";
// import { toast } from "../ui/use-toast";
import { parseCssInput } from "renderer/utils/parse-css-input";
import ShadowControl from "./themeEditor/shadow-control";
import { toast } from "sonner";

const ThemeControlPanel = ({
  styles,
  currentMode,
  onChange,
  onReset,
  hasChanges = false,
}: ThemeEditorControlsProps) => {
  const { applyThemePreset, themeState } = useEditorStore();
  const [cssImportOpen, setCssImportOpen] = useState(false);

  const currentStyles = styles?.[currentMode];

  const updateStyle = React.useCallback(
    <K extends keyof typeof currentStyles>(
      key: K,
      value: (typeof currentStyles)[K]
    ) => {
      // apply common styles to both light and dark modes
      if (COMMON_STYLES.includes(key)) {
        onChange({
          ...styles,
          light: { ...styles.light, [key]: value },
          dark: { ...styles.dark, [key]: value },
        });
        return;
      }

      onChange({
        ...styles,
        [currentMode]: {
          ...currentStyles,
          [key]: value,
        },
      });
    },
    [onChange, styles, currentMode, currentStyles]
  );

  const handleCssImport = (css: string) => {
    // This just shows a success toast for now
    const { lightColors, darkColors } = parseCssInput(css);
    onChange({
      ...styles,
      light: { ...styles.light, ...lightColors },
      dark: { ...styles.dark, ...darkColors },
    });

    // The actual CSS parsing and theme application logic would be implemented later
    toast.success("CSS imported", {
      description: "Your custom CSS has been imported successfully",
    });
  };

  // Ensure we have valid styles for the current mode
  if (!currentStyles) {
    return null; // Or some fallback UI
  }

  const radius = Number.parseFloat((currentStyles.radius ?? "").replace("rem", ""));

  return (
    <div className="space-y-4 h-full">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-semibold">Theme Editor</h2>
        </div>
        <div className="flex items-center gap-0">
          {hasChanges && <ResetButton onReset={onReset} label="Reset theme" />}
          <Button
            variant="link"
            size="sm"
            onClick={() => setCssImportOpen(true)}
            className="text-muted-foreground hover:text-foreground p-0"
          >
            <FileCode className="size-4" />
            Import
          </Button>
        </div>
      </div>

      <div className="mb-6">
        <ThemePresetSelect
          presets={presets}
          currentPreset={themeState.preset as string}
          onPresetChange={applyThemePreset}
        />
      </div>

      <Tabs defaultValue="colors" className="w-full h-full">
        <TabsList className="grid grid-cols-2 mb-3 w-full">
          <TabsTrigger value="colors">Colors</TabsTrigger>
          {/* <TabsTrigger value="typography">Typography</TabsTrigger> */}
          <TabsTrigger value="other">Other</TabsTrigger>
        </TabsList>

        <ScrollArea className="h-full pb-40">
          <TabsContent value="colors">
            <ControlSection title="Primary Colors" id="primary-colors" expanded>
              <ColorPicker
                color={currentStyles.primary as string}
                onChange={(color) => updateStyle("primary", color)}
                label="Primary"
              />
              <ColorPicker
                color={currentStyles["primary-foreground"] as string}
                onChange={(color) => updateStyle("primary-foreground", color)}
                label="Primary Foreground"
              />
            </ControlSection>

            <ControlSection title="Secondary Colors" expanded>
              <ColorPicker
                color={currentStyles.secondary as string}
                onChange={(color) => updateStyle("secondary", color)}
                label="Secondary"
              />
              <ColorPicker
                color={currentStyles["secondary-foreground"] as string}
                onChange={(color) => updateStyle("secondary-foreground", color)}
                label="Secondary Foreground"
              />
            </ControlSection>

            <ControlSection title="Accent Colors" expanded>
              <ColorPicker
                color={currentStyles.accent as string}
                onChange={(color) => updateStyle("accent", color)}
                label="Accent"
              />
              <ColorPicker
                color={currentStyles["accent-foreground"] as string}
                onChange={(color) => updateStyle("accent-foreground", color)}
                label="Accent Foreground"
              />
            </ControlSection>

            <ControlSection title="Base Colors">
              <ColorPicker
                color={currentStyles.background as string}
                onChange={(color) => updateStyle("background", color)}
                label="Background"
              />
              <ColorPicker
                color={currentStyles.foreground as string}
                onChange={(color) => updateStyle("foreground", color)}
                label="Foreground"
              />
            </ControlSection>

            <ControlSection title="Card Colors">
              <ColorPicker
                color={currentStyles.card as string}
                onChange={(color) => updateStyle("card", color)}
                label="Card Background"
              />
              <ColorPicker
                color={currentStyles["card-foreground"] as string}
                onChange={(color) => updateStyle("card-foreground", color)}
                label="Card Foreground"
              />
            </ControlSection>

            <ControlSection title="Popover Colors">
              <ColorPicker
                color={currentStyles.popover as string}
                onChange={(color) => updateStyle("popover", color)}
                label="Popover Background"
              />
              <ColorPicker
                color={currentStyles["popover-foreground"] as string}
                onChange={(color) => updateStyle("popover-foreground", color)}
                label="Popover Foreground"
              />
            </ControlSection>

            <ControlSection title="Muted Colors">
              <ColorPicker
                color={currentStyles.muted as string}
                onChange={(color) => updateStyle("muted", color)}
                label="Muted"
              />
              <ColorPicker
                color={currentStyles["muted-foreground"] as string}
                onChange={(color) => updateStyle("muted-foreground", color)}
                label="Muted Foreground"
              />
            </ControlSection>

            <ControlSection title="Destructive Colors">
              <ColorPicker
                color={currentStyles.destructive as string}
                onChange={(color) => updateStyle("destructive", color)}
                label="Destructive"
              />
              <ColorPicker
                color={currentStyles["destructive-foreground"] as string}
                onChange={(color) => updateStyle("destructive-foreground", color)}
                label="Destructive Foreground"
              />
            </ControlSection>

            <ControlSection title="Border & Input Colors">
              <ColorPicker
                color={currentStyles.border as string}
                onChange={(color) => updateStyle("border", color)}
                label="Border"
              />
              <ColorPicker
                color={currentStyles.input as string}
                onChange={(color) => updateStyle("input", color)}
                label="Input"
              />
              <ColorPicker
                color={currentStyles.ring as string}
                onChange={(color) => updateStyle("ring", color)}
                label="Ring"
              />
            </ControlSection>

            <ControlSection title="Chart Colors">
              <ColorPicker
                color={currentStyles["chart-1"] as string}
                onChange={(color) => updateStyle("chart-1", color)}
                label="Chart 1"
              />
              <ColorPicker
                color={currentStyles["chart-2"] as string}
                onChange={(color) => updateStyle("chart-2", color)}
                label="Chart 2"
              />
              <ColorPicker
                color={currentStyles["chart-3"] as string}
                onChange={(color) => updateStyle("chart-3", color)}
                label="Chart 3"
              />
              <ColorPicker
                color={currentStyles["chart-4"] as string}
                onChange={(color) => updateStyle("chart-4", color)}
                label="Chart 4"
              />
              <ColorPicker
                color={currentStyles["chart-5"] as string}
                onChange={(color) => updateStyle("chart-5", color)}
                label="Chart 5"
              />
            </ControlSection>

            <ControlSection title="Sidebar Colors">
              <ColorPicker
                color={currentStyles.sidebar as string}
                onChange={(color) => updateStyle("sidebar", color)}
                label="Sidebar Background"
              />
              <ColorPicker
                color={currentStyles["sidebar-foreground"] as string}
                onChange={(color) => updateStyle("sidebar-foreground", color)}
                label="Sidebar Foreground"
              />
              <ColorPicker
                color={currentStyles["sidebar-primary"] as string}
                onChange={(color) => updateStyle("sidebar-primary", color)}
                label="Sidebar Primary"
              />
              <ColorPicker
                color={currentStyles["sidebar-primary-foreground"] as string}
                onChange={(color) =>
                  updateStyle("sidebar-primary-foreground", color)
                }
                label="Sidebar Primary Foreground"
              />
              <ColorPicker
                color={currentStyles["sidebar-accent"] as string}
                onChange={(color) => updateStyle("sidebar-accent", color)}
                label="Sidebar Accent"
              />
              <ColorPicker
                color={currentStyles["sidebar-accent-foreground"] as string}
                onChange={(color) => updateStyle("sidebar-accent-foreground", color)}
                label="Sidebar Accent Foreground"
              />
              <ColorPicker
                color={currentStyles["sidebar-border"] as string}
                onChange={(color) => updateStyle("sidebar-border", color)}
                label="Sidebar Border"
              />
              <ColorPicker
                color={currentStyles["sidebar-ring"] as string}
                onChange={(color) => updateStyle("sidebar-ring", color)}
                label="Sidebar Ring"
              />
            </ControlSection>
          </TabsContent>
          <TabsContent value="other">
            <ControlSection title="Radius" expanded>
              <SliderWithInput
                value={radius}
                onChange={(value) => updateStyle("radius", `${value}rem`)}
                min={0}
                max={5}
                step={0.025}
                unit="rem"
                label="Radius"
              />
            </ControlSection>
            <div className="mt-6">
              <ShadowControl
                shadowColor={currentStyles["shadow-color"] as string}
                shadowOpacity={Number.parseFloat(currentStyles["shadow-opacity"] as string)}
                shadowBlur={Number.parseFloat(
                  currentStyles["shadow-blur"]?.replace("px", "") as string
                )}
                shadowSpread={Number.parseFloat(
                  currentStyles["shadow-spread"]?.replace("px", "") as string
                )}
                shadowOffsetX={Number.parseFloat(
                  currentStyles["shadow-offset-x"]?.replace("px", "") as string
                )}
                shadowOffsetY={Number.parseFloat(
                  currentStyles["shadow-offset-y"]?.replace("px", "") as string
                )}
                onChange={(key: any, value) => {
                  if (key === "shadow-color") {
                    updateStyle(key, value);
                  } else if (key === "shadow-opacity") {
                    updateStyle(key, value.toString());
                  } else {
                    updateStyle(key, `${value}px`);
                  }
                }}
              />
            </div>
          </TabsContent>
        </ScrollArea>
      </Tabs>

      <CssImportDialog
        open={cssImportOpen}
        onOpenChange={setCssImportOpen}
        onImport={handleCssImport}
      />
    </div>
  );
};

export default ThemeControlPanel;
