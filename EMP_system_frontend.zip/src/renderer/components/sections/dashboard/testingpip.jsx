import React, { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
// import './pip.css' // We'll style this later

const FloatingPiP = ({ onClose }) => {
  const [position, setPosition] = useState({ x: 100, y: 100 })
  const [dragging, setDragging] = useState(false)
  const [rel, setRel] = useState({ x: 0, y: 0 })

  const handleMouseDown = e => {
    setDragging(true)
    setRel({
      x: e.pageX - position.x,
      y: e.pageY - position.y,
    })
    e.preventDefault()
  }

  const handleMouseMove = e => {
    if (!dragging) return
    setPosition({
      x: e.pageX - rel.x,
      y: e.pageY - rel.y,
    })
    e.preventDefault()
  }

  const handleMouseUp = () => {
    setDragging(false)
  }

  return createPortal(
    <div
      className="fixed w-80 h-60 bg-gray-800 text-white rounded-lg shadow-lg overflow-hidden z-50 cursor-move"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      style={{ left: position.x, top: position.y }}
    >
      {/* Header */}
      <div className="flex justify-between items-center px-3 py-1 bg-gray-900">
        <span className="text-sm font-medium">Interactive PiP</span>
        <button
          onClick={onClose}
          className="text-white hover:text-red-500 text-lg font-bold"
        >
          ×
        </button>
      </div>

      {/* Body (video placeholder) */}
      <div className="relative h-full bg-black">
        <video
          autoPlay
          muted
          playsInline
          className="w-full h-full object-cover"
        />

        {/* Controls */}
        <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-2 px-2">
          <button
            onClick={() => alert('Reframe clicked')}
            className="bg-gray-700 hover:bg-gray-600 text-white px-2 py-1 rounded text-sm"
          >
            📷 Reframe
          </button>
          <button
            onClick={() => alert('Mic toggled')}
            className="bg-gray-700 hover:bg-gray-600 text-white px-2 py-1 rounded text-sm"
          >
            🎤
          </button>
          <button
            onClick={() => alert('Camera toggled')}
            className="bg-gray-700 hover:bg-gray-600 text-white px-2 py-1 rounded text-sm"
          >
            📹
          </button>
          <button
            onClick={onClose}
            className="bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded text-sm"
          >
            ❌
          </button>
        </div>
      </div>
    </div>,
    document.body
  )
}

const PipTesting = () => {
  const [showPiP, setShowPiP] = useState(false)

  useEffect(() => {
    // Optional: attach webcam stream
    if (showPiP) {
      navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
        const video = document.querySelector('video')
        if (video) {
          video.srcObject = stream
          video.play()
        }
      })
    }
  }, [showPiP])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100">
      <h1 className="text-2xl font-bold mb-4">React + Tailwind Custom PiP</h1>
      <button
        onClick={() => setShowPiP(true)}
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Open Custom PiP
      </button>

      {showPiP && <FloatingPiP onClose={() => setShowPiP(false)} />}
    </div>
  )
}

export default PipTesting
