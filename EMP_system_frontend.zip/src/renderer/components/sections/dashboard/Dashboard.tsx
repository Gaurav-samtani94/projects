"use client"
import type React from "react"
import { useEffect, useState } from "react"
import { Button } from "renderer/components/ui/button"
import { Badge } from "renderer/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "renderer/components/ui/card"
import { Separator } from "renderer/components/ui/separator"
import { ScrollArea } from "renderer/components/ui/scroll-area"
import { Users, User, Check, File, Calendar, Clock, MessageSquare, Mic, Video } from "lucide-react";
import AppUsesGraph from "./AppUsesGraph"
import AppActivityTable from "./AppActivityTable"
import TaskActivityTable from "./TaskActivityTable"
import QuickTaskPlayAndPause from "./QuickTaskPlayAndPause"
import { useSystemStatusStore } from "renderer/store/LoggingStore"
import { useQuery } from "@tanstack/react-query"
import { getProjectInprogress, getTaskTrackList } from "renderer/service/dashboard"
import { customCalculations } from "renderer/utils/customCalculations"
import PipTesting from "./testingpip"
import { trackingStore } from "renderer/store/trackingStore"
import ChatController from "renderer/Controller/ChatController"
import useAuthStore from "renderer/store/AuthStore"

type Meeting = {
    id: number
    title: string
    time: string
    participants: number
    type: "Audio" | "Video"
}

type MessageType = {
    id: number;
    sender: string;
    content: string;
    timestamp: string;
    isGroup: boolean;
};

const meetings: Meeting[] = [
    {
        id: 1,
        title: "Team Sync-up",
        time: "10:00 AM",
        participants: 5,
        type: "Video",
    },
    {
        id: 2,
        title: "Client Call",
        time: "2:00 PM",
        participants: 3,
        type: "Audio",
    },
    {
        id: 3,
        title: "CEO with Team Meeting",
        time: "5:00 PM",
        participants: 7,
        type: "Video",
    },
]

const initialMessages = [
    {
        id: "1",
        sender: "Marketing Team",
        isGroup: true,
        content: "Hey everyone, just a reminder about tomorrow's meeting. Please prepare your quarterly reports.",
        timestamp: "10:45 AM",
        isFile: false,
    },
    {
        id: "2",
        sender: "Sarah Johnson",
        isGroup: false,
        content: "I've reviewed the proposal and have some feedback. Can we discuss?",
        timestamp: "9:30 AM",
        isFile: false,
    },
    {
        id: "3",
        sender: "Project Taskforce",
        isGroup: true,
        content: "The client has approved the design mockups! We can proceed to the next phase.",
        timestamp: "Yesterday",
        isFile: false,
    },
    {
        id: "4",
        sender: "Alex Chen",
        isGroup: false,
        content: "",
        timestamp: "Yesterday",
        isFile: true,
        fileName: "Q3_Budget_Report.xlsx",
    },
]

export default function Dashboard() {
    const { App } = window
    const [isTracking, setIsTracking] = useState(true);
    const [messages, setMessages] = useState(initialMessages)
    const [triggerDurationCalc, setTriggerDurationCalc] = useState(false);
    const getSystemLog = useSystemStatusStore((state) => state.systemStatus)
    const { timeStats, timeStatsInSeconds, calculateDurations } = customCalculations();
    const setTracking = trackingStore((state) => state.setTracking);
    const user = useAuthStore?.getState()?.getUser();

    console.log('user==========109======>>>>>>>>>.', user);


    useEffect(() => {
        trackingStatus()
    }, [])
    const handleMessageClick = (messageId: string) => {
        console.log(`Navigating to message ${messageId}`)
    }

    const data = Array.from({ length: 20 }, (_, i) => ({
        value: Math.floor(Math.random() * 100),
    }))




    const trackingStatus = async () => {
        const result = await App.isTracking()
        console.log('Tracking Status:', result)
    }

    const stats = [
        {
            title: "Total Time",
            value: timeStats.total,
            color: "bg-primary",
            textColor: "text-accent",
            bgColor: "bg-gradient-to-br",
        },
        {
            title: "Total Offline Time",
            value: timeStats.offline,
            textColor: "text-foreground",
            bgColor: "",
        },
        {
            title: "Total Online Time",
            value: timeStats.online,
            textColor: "text-foreground",
            bgColor: "",
        },
        {
            title: "Total Idle Time",
            value: timeStats.idle,
            color: "bg-primary",
            textColor: "text-accent",
            bgColor: "bg-gradient-to-br",
        },
    ]

    useEffect(() => {
        calculateDurations(getSystemLog)
    }, [getSystemLog])

    // const calculateDurations = () => {
    //     if (!getSystemLog || getSystemLog.length === 0) {
    //         setTimeStats({
    //             total: formatDuration(0),
    //             online: formatDuration(0),
    //             idle: formatDuration(0),
    //             offline: formatDuration(0),
    //         });
    //         return;
    //     }
    //     const intervals: { start: number; end: number; status: string }[] = [];

    //     // biome-ignore lint/style/useNumberNamespace: <explanation>
    //     let minStart = Infinity;
    //     let maxEnd = 0;

    //     // biome-ignore lint/complexity/noForEach: <explanation>
    //     getSystemLog.forEach((entry: any) => {
    //         const start = parseDateTime(entry?.date, entry.start_time);
    //         const end = parseDateTime(entry?.date, entry.end_time);

    //         if (start < minStart) minStart = start;
    //         if (end > maxEnd) maxEnd = end;

    //         intervals.push({ start, end, status: entry.status });
    //     });

    //     intervals.sort((a, b) => a.start - b.start);

    //     let onlineMs = 0;
    //     let idleMs = 0;

    //     // biome-ignore lint/complexity/noForEach: <explanation>
    //     intervals.forEach(({ start, end, status }) => {
    //         const duration = end - start;
    //         if (status === "online") {
    //             onlineMs += duration;
    //         } else if (status === "idle") {
    //             idleMs += duration;
    //         }
    //     });

    //     const totalMs = maxEnd - minStart;
    //     const offlineMs = Math.max(0, totalMs - (onlineMs + idleMs));

    //     setTimeStats({
    //         total: formatDuration(totalMs),
    //         online: formatDuration(onlineMs),
    //         idle: formatDuration(idleMs),
    //         offline: formatDuration(offlineMs),
    //     });
    // };

    // const parseDateTime = (dateStr: string, timeStr: string) => {
    //     const cleanedTime = timeStr?.replace(/(AM|PM)/gi, '').trim();
    //     const [day, month, year] = dateStr?.split("-");
    //     return new Date(`${year}-${month}-${day} ${cleanedTime}`).getTime();
    // };
    // const formatDuration = (ms: number) => {
    //     const totalMinutes = Math.floor(ms / 60000);
    //     const hours = Math.floor(totalMinutes / 60);
    //     const minutes = totalMinutes % 60;
    //     return `${hours}h ${minutes}m`;
    // };


    const markAsRead = (e: React.MouseEvent, messageId: string) => {
        e.stopPropagation()
        setMessages(messages.filter((message) => message.id !== messageId))
        console.log(`Marked message ${messageId} as read`)
    }
    const getMessagePreview = (message: (typeof initialMessages)[0]) => {
        if (message.isFile) {
            return (
                <div className="flex items-center gap-1.5 text-muted-foreground">
                    <File className="h-4 w-4" />
                    <span>{message.fileName}</span>
                </div>
            )
        }

        return message.content.slice(0, 100) + (message.content.length > 100 ? '...' : '');
    }

    const { data: tractTaskList, refetch } = useQuery({
        queryKey: ["trackTaskList"],
        queryFn: () => getTaskTrackList(),
    })

    useEffect(() => {
        const checkTrackingStatus = async () => {
            const tracking = await App.isTracking();
            setIsTracking(tracking);
            setTracking(tracking)
        };
        checkTrackingStatus();
    })

    const stopWatch = async () => {
        const result = await App.stopWatching();
        console.log('Tracking Stop', result)
        const tracking = await App.isTracking()
        setIsTracking(tracking);
        localStorage?.removeItem("last-sent-log-store")
        setTracking(tracking)
    }

    const socket = ChatController.getSocket();
    if (!socket) {
        return;
    }

    socket.on('313', (data: any) => {
        console.log('task_assign_notification dataaaaaaaaaaa====', data);

    })

    return (
        <div className="px-6 py-6">
            <div className="mb-8 flex items-end justify-between">
                <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
                <div>
                    <p className="text-right uppercase text-xs mb-1 tracking-widest">Tracking</p>
                    <div className="flex items-center gap-2">
                        {!isTracking && (
                            <>
                                <Button size="sm" variant="outline" onClick={async () => {
                                    App.startWatching(); console.log('Tracking Started'); setTriggerDurationCalc(prev => !prev); const tracking = await App.isTracking();
                                    setIsTracking(tracking);
                                    setTracking(tracking)
                                }}>Start</Button>
                            </>
                        )}

                        {isTracking && (
                            <>
                                <Button size="sm" variant="outline" onClick={stopWatch}>Stop</Button>
                                <Button size="sm" variant="destructive" onClick={() => { App.clearAllActivity(); console.log('Electron Store Cleared') }}> Clear Store</Button>
                            </>)}
                    </div>
                </div>
            </div>
            <div className="flex gap-5 h-full mb-5">
                <div className="flex-1">
                    <h2 className="text-lg font-semibold mb-5">System Statistics</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {stats.map((stat, index) => (
                            <Card key={index} className={`overflow-hidden border-0 shadow-lg ${stat.bgColor} ${stat.color}`}>
                                <CardContent className="p-6 relative">
                                    <div className="absolute top-0 right-0 left-0 bottom-0 opacity-20 pointer-events-none">
                                    </div>
                                    <div className="relative z-10">
                                        <p className={`text-sm font-medium opacity-80 ${stat.textColor}`}>{stat.title}</p>
                                        <p className={`text-3xl font-bold mt-2 ${stat.textColor}`}>{stat.value}</p>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
                <div className="overflow-hidden flex-1">
                    <Card className="!shadow-none border-border !pt-4 !gap-5">
                        <CardHeader className="pb-1 !gap-0 !px-4">
                            <div className="flex items-center justify-between">
                                <CardTitle className="text-lg font-semibold">Today's Meetings</CardTitle>
                                <Badge className="px-2.5 py-1">{meetings.length} Scheduled</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Your upcoming audio and video conferences</p>
                        </CardHeader>
                        <Separator />
                        <ScrollArea className="h-[230px]">
                            <CardContent className="!py-0 !px-2">
                                <div className="divide-y divide-border">
                                    {meetings.map((meeting) => (
                                        <div key={meeting.id} className="py-2 px-2 hover:bg-accent/50 transition-colors">
                                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
                                                <div className="space-y-1">
                                                    <div className="flex items-center gap-2">
                                                        <h3 className="font-semibold text-[15px]">{meeting.title}</h3>
                                                        <Badge
                                                            variant="outline"
                                                            className={`${meeting.type === "Video"
                                                                ? "bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800"
                                                                : "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800"
                                                                } px-2 py-0.5 flex items-center gap-1.5`}
                                                        >
                                                            {meeting.type === "Video" ? <Video className="h-3 w-3" /> : <Mic className="h-3 w-3" />}
                                                            {meeting.type}
                                                        </Badge>
                                                    </div>
                                                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                                                        <div className="flex items-center gap-1">
                                                            <Clock className="h-3 w-3" />
                                                            <span className="text-xs">  {meeting.time}</span>
                                                        </div>
                                                        <div className="flex items-center gap-1">
                                                            <Users className="h-3 w-3" />
                                                            <span className="text-xs"> {meeting.participants} Participant{meeting.participants > 1 ? "s" : ""}</span>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="flex gap-3 sm:justify-end">
                                                    <Button variant="outline" size="sm" className="h-9">
                                                        See Participants
                                                    </Button>
                                                    <Button size="sm" className="h-9">
                                                        Join Now
                                                    </Button>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                {meetings.length === 0 && (
                                    <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
                                        <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
                                        <h3 className="text-lg font-medium mb-1">No meetings scheduled</h3>
                                        <p className="text-sm text-muted-foreground max-w-sm">
                                            You don't have any meetings scheduled for today. Enjoy your free time!
                                        </p>
                                    </div>
                                )}
                            </CardContent>
                        </ScrollArea>
                    </Card>
                </div>
                <div className="overflow-hidden flex-1">
                    <Card className="!shadow-none border-border !pt-4 !gap-4">
                        <CardHeader className="pb-1 !gap-0 !px-4">
                            <div className="flex items-center justify-between">
                                <CardTitle className="text-lg font-semibold">Unread Messages</CardTitle>
                                <Badge className="px-2.5 py-1">{messages.length} Unread</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">Your unread conversations and notifications</p>
                        </CardHeader>
                        <Separator />
                        <ScrollArea className="h-[300px]">
                            <CardContent className="!py-0 !px-2">
                                <div className="divide-y divide-border">
                                    {messages.map((message) => (
                                        // biome-ignore lint/a11y/useKeyWithClickEvents: <explanation>
                                        <div
                                            key={message.id}
                                            className="py-2 px-2 hover:bg-accent/50 transition-colors cursor-pointer"
                                            onClick={() => handleMessageClick(message.id)}
                                        >
                                            <div className="flex items-start justify-between gap-4 mb-1">
                                                <div className="">
                                                    <div className="flex items-center gap-2">
                                                        <h3 className="font-semibold text-[15px]">{message.sender}</h3>
                                                        <Badge
                                                            variant="outline"
                                                            className={`${message.isGroup
                                                                ? "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800"
                                                                : "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800"
                                                                } px-2 py-0.5 flex items-center gap-1.5`}
                                                        >
                                                            {message.isGroup ? <Users className="h-3 w-3" /> : <User className="h-3 w-3" />}
                                                            {message.isGroup ? "Group" : "Direct"}
                                                        </Badge>
                                                        <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                                                    </div>
                                                    <p className="text-xs text-muted-foreground">{getMessagePreview(message)}</p>
                                                </div>
                                                <Button variant="ghost" size="sm" className="h-8 mt-1" onClick={(e) => markAsRead(e, message.id)}>
                                                    <Check className="h-4 w-4 mr-1" />
                                                    Mark Read
                                                </Button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                {messages.length === 0 && (
                                    <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
                                        <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
                                        <h3 className="text-lg font-medium mb-1">No unread messages</h3>
                                        <p className="text-sm text-muted-foreground max-w-sm">
                                            You've caught up with all your messages. Great job staying on top of your communications!
                                        </p>
                                    </div>
                                )}
                            </CardContent>
                        </ScrollArea>
                    </Card>
                </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
                <TaskActivityTable tractTaskList={tractTaskList} />
                <QuickTaskPlayAndPause refetch={refetch} />
            </div>

            <div className="flex gap-5 w-full">
                <AppUsesGraph />
                <AppActivityTable />
            </div>
            {/* <PipTesting /> */}
        </div>
    )
}
