"use client"

import * as React from "react"
import {
    type ColumnDef,
    type ColumnFiltersState,
    type SortingState,
    type VisibilityState,
    flexRender,
    getCoreRowModel,
    getFilteredRowModel,
    getPaginationRowModel,
    getSortedRowModel,
    useReactTable,
} from '@tanstack/react-table'
import { ArrowUpDown, ChevronDown, MoreHorizontal } from "lucide-react"

import { Button } from "renderer/components/ui/button"
import { Checkbox } from "renderer/components/ui/checkbox"
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "renderer/components/ui/dropdown-menu"
import { Input } from "renderer/components/ui/input"
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "renderer/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "renderer/components/ui/card"
import { Separator } from "renderer/components/ui/separator"
import { useQuery } from "@tanstack/react-query"
import { getTaskTrackList } from "renderer/service/dashboard"
import moment from "moment"

const data: Payment[] = [
    {
        id: "m5gr84i9",
        projectName: 'ICM',
        taskName: 'Home Page Design',
        startTime: 11,
        endTime: 14,
        totalTime: 2
    },
    {
        id: "3u1reuv4",
        projectName: 'CVM',
        startTime: 12,
        taskName: 'API Integration',
        endTime: 13,
        totalTime: 1
    },
    {
        id: "derv1ws0",
        projectName: 'Kairaus',
        taskName: 'Product Detail Page API Integrate',
        startTime: 15,
        endTime: 16,
        totalTime: 1
    },
    {
        id: "5kma53ae",
        projectName: 'Tendergrid',
        taskName: 'Tendergrid figma design start',
        startTime: 14,
        endTime: 15,
        totalTime: 1
    },
    {
        id: "bhqecj4p",
        projectName: 'CEG',
        taskName: 'CEG Final Design',
        startTime: 13,
        endTime: 14,
        totalTime: 1
    },
]

export type Payment = {
    id: string
    projectName: string
    taskName: string
    startTime: number
    endTime: number
    totalTime: number
}

export const columns: ColumnDef<any>[] = [
    {
        header: "Project Name",
        cell: ({ row }) => {
            const project = row.original
            return (
                <div className="capitalize">{project?.projects?.project_name}</div>
            )
        },
    },
    {
        accessorKey: "task_name",
        header: "Task Name",
        cell: ({ row }) => (
            <div className="capitalize">{row.getValue("task_name")}</div>
        ),
    },
    {
        accessorKey: "startTime",
        header: "Start Time",
        cell: ({ row }) => (
            <div className="capitalize">{row.getValue("startTime")}</div>
        ),
    },
    {
        accessorKey: "endTime",
        header: "End Time",
        cell: ({ row }) => (
            <div className="capitalize">{row.getValue("endTime")}</div>
        ),
    },
    {
        accessorKey: "totalTime",
        header: "Total Time",
        cell: ({ row }) => (
            <div className="capitalize">{row.getValue("totalTime")}</div>
        ),
    },
]

const calData = [{
    "id": 64,
    "sr_no": 1,
    "parent_id": 0,
    "project_name": "newnew",
    "task_name": "dfsdfs",
    "project_id": 77,
    "is_working": 0,
    "status": "1",
    "created_by": 8,
    "created_at": "2025-05-02T10:20:23.000Z",
    "updated_by": null,
    "updated_at": null,
    "taskTime": [
        {
            "id": 4,
            "task_id": 64,
            "user_id": 8,
            "start_time": "2025-05-05 09:16 PM",
            "end_time": "2025-05-05 10:50 PM",
            "total_time": null,
            "work_date": "2025-05-05",
            "status": "1",
            "created_by": 8,
            "created_at": "2025-05-05T15:47:28.000Z"
        }
    ]
}]

type props = {
    tractTaskList: any
}

const TaskActivityTable = ({ tractTaskList }: props) => {
    const [sorting, setSorting] = React.useState<SortingState>([])
    const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
        []
    )
    const [columnVisibility, setColumnVisibility] =
        React.useState<VisibilityState>({})
    const [rowSelection, setRowSelection] = React.useState({})

    const processedData = tractTaskList?.data?.map((task: any) => {
        const taskTimes = task.taskTime?.filter((t: any) => t.start_time) || [];

        let startTime = "";
        let endTime = "";
        let totalTime = "";

        if (taskTimes.length > 0) {
            const first = taskTimes[0];
            const last = taskTimes[taskTimes.length - 1];

            const start = moment(first.start_time, "YYYY-MM-DD hh:mm A");
            const end = last.end_time ? moment(last.end_time, "YYYY-MM-DD hh:mm A") : null;

            startTime = start.isValid() ? start.format("hh:mm A") : "";

            if (end && end.isValid()) {
                endTime = end.format("hh:mm A");

                const diffMinutes = end.diff(start, "minutes");
                const hours = Math.floor(diffMinutes / 60);
                const minutes = diffMinutes % 60;
                totalTime = `${hours}h ${minutes}m`;
            } else {
                endTime = "In Progress";
                totalTime = "00";
            }
        }

        return {
            ...task,
            startTime,
            endTime,
            totalTime,
        };
    });

    const table = useReactTable({
        data: processedData?.reverse() || [],
        columns,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        onColumnVisibilityChange: setColumnVisibility,
        onRowSelectionChange: setRowSelection,
        state: {
            sorting,
            columnFilters,
            columnVisibility,
            rowSelection,
        },
    })

    return (
        <Card className="w-full h-fit">
            <CardHeader className="!gap-0">
                <CardTitle className="text-lg font-semibold">Task Activity</CardTitle>
                <CardDescription className="text-sm text-muted-foreground">Manage and review payment records here.</CardDescription>
            </CardHeader>
            <Separator />
            <CardContent>
                <div className="flex items-center py-4">
                    <Input
                        placeholder="Filter emails..."
                        value={(table.getColumn("task_name")?.getFilterValue() as string) ?? ""}
                        onChange={(event) =>
                            table.getColumn("task_name")?.setFilterValue(event.target.value)
                        }
                        className="max-w-sm"
                    />
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="outline" className="ml-auto">
                                Columns <ChevronDown />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            {table
                                .getAllColumns()
                                .filter((column) => column.getCanHide())
                                .map((column) => (
                                    <DropdownMenuCheckboxItem
                                        key={column.id}
                                        className="capitalize"
                                        checked={column.getIsVisible()}
                                        onCheckedChange={(value) =>
                                            column.toggleVisibility(!!value)
                                        }
                                    >
                                        {column.id}
                                    </DropdownMenuCheckboxItem>
                                ))}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>

                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            {table.getHeaderGroups().map((headerGroup) => (
                                <TableRow key={headerGroup.id}>
                                    {headerGroup.headers.map((header) => (
                                        <TableHead key={header.id}>
                                            {header.isPlaceholder
                                                ? null
                                                : flexRender(
                                                    header.column.columnDef.header,
                                                    header.getContext()
                                                )}
                                        </TableHead>
                                    ))}
                                </TableRow>
                            ))}
                        </TableHeader>
                        <TableBody>
                            {table.getRowModel().rows?.length ? (
                                table.getRowModel().rows.map((row) => (
                                    <TableRow
                                        key={row.id}
                                        data-state={row.getIsSelected() && "selected"}
                                    >
                                        {row.getVisibleCells().map((cell) => (
                                            <TableCell key={cell.id}>
                                                {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={columns.length} className="h-24 text-center">
                                        No results.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>

                <div className="flex items-center justify-end space-x-2 py-4">
                    <div className="flex-1 text-sm text-muted-foreground">
                        {table.getFilteredSelectedRowModel().rows.length} of{" "}
                        {table.getFilteredRowModel().rows.length} row(s) selected.
                    </div>
                    <div className="space-x-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.previousPage()}
                            disabled={!table.getCanPreviousPage()}
                        >
                            Previous
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.nextPage()}
                            disabled={!table.getCanNextPage()}
                        >
                            Next
                        </Button>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}

export default TaskActivityTable