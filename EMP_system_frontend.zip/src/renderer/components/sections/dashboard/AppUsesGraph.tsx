"use client"
import { TrendingUp } from "lucide-react"
import { Bar, BarChart, CartesianGrid, LabelList, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "renderer/components/ui/card"
import { type ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "renderer/components/ui/chart"
import { Separator } from "renderer/components/ui/separator"
import { useActivityLogStore } from "renderer/store/LoggingStore"
import { useMemo } from "react"

const chartConfig = {
    usage: {
        label: "Usage (minutes)",
        color: "var(--primary)",
    },
    label: {
        color: "var(--primary-foreground)",
    }
} satisfies ChartConfig

const getMinutes = (timeStr: string): number => {
    const [time, ampm] = timeStr.split(" ");
    let [hour, minute] = time.split(":").map(Number);
    if (ampm === "PM" && hour < 12) hour += 12;
    if (ampm === "AM" && hour === 12) hour = 0;
    return hour * 60 + minute;
};

const getGroupedUsageData = (logs: any[]) => {
    const grouped: Record<string, number> = {};

    // biome-ignore lint/complexity/noForEach: <explanation>
    logs.forEach(log => {
        try {
            const diffMinutes = Math.max(getMinutes(log.end_time) - getMinutes(log.start_time), 0);
            grouped[log.owner] = (grouped[log.owner] || 0) + diffMinutes;
        } catch {
            return 0;
        }
    });

    return Object.entries(grouped).map(([app, usage]) => ({
        app,
        usage: Math.round(usage),
    })).filter(item => item.usage > 0);
};

const AppUsesGraph = () => {
    const getActivityLog = useActivityLogStore((state) => state.activityLog);

    const chartData = useMemo(() => getGroupedUsageData(getActivityLog), [getActivityLog]);

    const mostUsedApp = chartData.reduce((prev, current) =>
        current.usage > prev.usage ? current : prev,
        { app: "", usage: 0 }
    );

    return (
        <div className="w-full">
            <Card className="h-fit w-full mt-5">
                <CardHeader className="!gap-0">
                    <CardTitle className="text-lg font-semibold">App Usage Statistics</CardTitle>
                    <CardDescription className="text-sm text-muted-foreground">Total usage time by app</CardDescription>
                </CardHeader>
                <Separator />
                <CardContent className="w-full">
                    {chartData.length === 0 ? (
                        <div className="flex items-center justify-center w-full h-full p-4 text-sm text-muted-foreground">
                            No usage data available
                        </div>
                    ) : null}
                    {chartData.length > 0 &&
                        <ChartContainer config={chartConfig} >
                            <BarChart
                                accessibilityLayer
                                data={chartData}
                                layout="vertical"
                                margin={{
                                    right: 16,
                                }}

                            >
                                <CartesianGrid horizontal={false} />
                                <YAxis dataKey="app" type="category" tickLine={false} tickMargin={10} axisLine={false} hide />
                                <XAxis type="number" hide />
                                <ChartTooltip cursor={false} content={<ChartTooltipContent indicator="line" />} />
                                <Bar dataKey="usage" layout="vertical" radius={4} fill={chartConfig.usage.color}>
                                    <LabelList
                                        dataKey="app"
                                        position="insideLeft"
                                        offset={8}
                                        fontSize={12}
                                        color={chartConfig.label.color}
                                        fill={chartConfig.label.color}
                                    />
                                    <LabelList dataKey="usage" position="right" offset={8} fontSize={12} />
                                </Bar>
                            </BarChart>
                        </ChartContainer>
                    }
                </CardContent>
                <CardFooter className="flex-col items-start gap-2 text-sm">
                    <div className="flex gap-2 font-medium leading-none">
                        {mostUsedApp.app} has the highest usage at {mostUsedApp.usage} minutes <TrendingUp className="h-4 w-4" />
                    </div>
                    <div className="leading-none text-muted-foreground">Based on application usage logs</div>
                </CardFooter>
            </Card>
        </div>
    )
}

export default AppUsesGraph