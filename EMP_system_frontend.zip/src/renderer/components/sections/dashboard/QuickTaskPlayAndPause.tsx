// components/QuickTaskPlayAndPause.tsx
import React, { useState } from "react";
import { Button } from "renderer/components/ui/button";
import { PlayIcon, PauseIcon } from "lucide-react";
import {
    Accordion,
    AccordionItem,
    AccordionTrigger,
    AccordionContent,
} from "renderer/components/ui/accordion";
import { Card, CardContent } from "renderer/components/ui/card";
import { ScrollArea } from "renderer/components/ui/scroll-area";
import { useMutation, useQuery } from "@tanstack/react-query";
import { addTaskTime, getProjectInprogress } from "renderer/service/dashboard";
import { toast } from "sonner";

type Task = {
    id: number;
    name: string;
    isRunning: boolean;
};

type Project = {
    id: number;
    name: string;
    tasks: Task[];
};

const initialProjects: Project[] = [
    {
        id: 1,
        name: "Project Alpha",
        tasks: [
            { id: 1, name: "Design", isRunning: false },
            { id: 2, name: "Development", isRunning: false },
        ],
    },
    {
        id: 2,
        name: "Project Beta",
        tasks: [
            { id: 3, name: "Research", isRunning: false },
            { id: 4, name: "Testing", isRunning: false },
        ],
    }
];

type props = {
    refetch: any

}

export default function QuickTaskPlayAndPause({ refetch }: props) {
    const [projects, setProjects] = useState(initialProjects);

    const addTaskMutation = useMutation({
        mutationFn: addTaskTime,
        onSuccess: (response) => {
            toast.success(response?.message)
            refetch()
            refetchList()
        },
        onError: (error: any) => {
            toast.error(error?.message)
        },
    })

    // const toggleTask = (projectId: number, taskId: number) => {
    //     setProjects((prev) =>
    //         prev.map((project) => ({
    //             ...project,
    //             tasks: project.tasks.map((task) => {
    //                 if (project.id === projectId && task.id === taskId) {
    //                     // Toggle the selected task
    //                     return { ...task, isRunning: !task.isRunning };
    //                 }
    //                 // Pause all other tasks
    //                 return { ...task, isRunning: false };
    //             }),
    //         }))
    //     );
    // };

    const toggleTask = (task: any) => {
        console.log(task, "task")
        const now = new Date();
        const formattedTime = now.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true,
        });
        if (task?.is_working === 1) {
            addTaskMutation.mutate({
                task_id: task.id,
                start_time: '',
                is_working: 2,
                end_time: formattedTime,
            });
        } else if (task?.is_working === 2) {
            const currentlyRunningTask = inProgressList?.data?.flatMap((project: any) => project?.tasks || [])
                .find((task: any) => task.is_working === 1);
            addTaskMutation.mutate({
                task_id: task.id,
                start_time: formattedTime,
                is_working: 1,
                end_time: '',
            });
            addTaskMutation.mutate({
                task_id: currentlyRunningTask?.id,
                start_time: '',
                is_working: 2,
                end_time: formattedTime,
            });
        } else {
            const currentlyRunningTask = inProgressList?.data?.flatMap((project: any) => project?.tasks || [])
                .find((task: any) => task.is_working === 1);

            if (task?.is_working === 0) {
                addTaskMutation.mutate({
                    task_id: task?.id,
                    start_time: formattedTime,
                    is_working: 1,
                    end_time: '',
                });
            }

            if (currentlyRunningTask) {
                addTaskMutation.mutate({
                    task_id: currentlyRunningTask.id,
                    start_time: '',
                    is_working: 2,
                    end_time: formattedTime,
                });
            }
        }
    };

    const { data: inProgressList, refetch: refetchList } = useQuery({
        queryKey: ['inprogressList'],
        queryFn: () => getProjectInprogress()
    })

    return (
        <Card className="p-4">
            <ScrollArea className="max-h-[472px] w-full pr-1">
                <CardContent>
                    <Accordion type="multiple" className="w-full" defaultValue={["project-1"]}>
                        {inProgressList?.data?.map((project: any) => (
                            <AccordionItem value={`project-${project?.id}`} key={project?.id} className="border-b-0">
                                <AccordionTrigger className="text-lg font-semibold">
                                    {project?.project_name}
                                </AccordionTrigger>
                                <AccordionContent>
                                    <div className="grid grid-cols-3 gap-2 text-sm font-medium text-muted-foreground border-b pb-2">
                                        <div>Task Name</div>
                                        <div>Status</div>
                                        <div>Action</div>
                                    </div>
                                    {project?.tasks?.map((task: any) => (
                                        <div
                                            key={task?.id}
                                            className="grid grid-cols-3 gap-2 py-2 border-b items-center"
                                        >
                                            <div>{task?.task_name}</div>
                                            <div
                                                className={`p-2 w-fit rounded ${task.isRunning ? "bg-green-100" : "bg-red-100"}`}
                                            >{task.is_working === 0
                                                ? "Not Started"
                                                : task.is_working === 1
                                                    ? "Running"
                                                    : "Paused"}</div>
                                            <div>
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => toggleTask(task)}
                                                >
                                                    {task.is_working === 1 ? (
                                                        <>
                                                            <PauseIcon className="w-4 h-4 mr-1" /> Pause
                                                        </>
                                                    ) : (
                                                        <>
                                                            <PlayIcon className="w-4 h-4 mr-1" /> Play
                                                        </>
                                                    )}
                                                </Button>
                                            </div>
                                        </div>
                                    ))}
                                </AccordionContent>
                            </AccordionItem>
                        ))}
                    </Accordion>
                </CardContent>
            </ScrollArea>
        </Card>
    );
}
