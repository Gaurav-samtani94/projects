// import React from 'react'
// import { VictoryAxis, VictoryBar, VictoryChart, VictoryZoomContainer, VictoryBrushLine } from 'victory';
// import useDimensions from 'react-cool-dimensions';
// import moment from 'moment';


// const domainPadding: any = { y: 35, x: 10 };

// const BAR_WIDTH = 25;

// const CHART_PADDING: any = { left: 0, top: 0, bottom: 20, right: 10 };

// const CHART_SCALE: any = { y: 'time', x: 'linear' };

// const MainTimelineChart = () => {
//     const { observe, width } = useDimensions();
//     const domain: any = {
//         y: [moment().startOf('day'), moment().endOf('day')],
//         x: [1, 3],
//     };
//     return (
//         <div ref={observe}>
//             <VictoryChart
//                 // theme={chartTheme}
//                 height={100}
//                 width={width}
//                 domainPadding={domainPadding}
//                 padding={CHART_PADDING}
//                 scale={CHART_SCALE}
//                 horizontal
//                 domain={domain}
//                 containerComponent={
//                     <VictoryZoomContainer
//                         responsive={false}
//                         zoomDimension="y"
//                         zoomDomain={{ y: rangeToDate(visibleTimerange) }}
//                         key={selectedTimelineItem && selectedTimelineItem.id}
//                         onZoomDomainChange={debounce(handleZoom, 300)}
//                     />
//                 }
//             >
//                 <VictoryAxis dependentAxis tickCount={20} />

//                 <VictoryBar
//                     // style={barStyle(chartTheme.isDark)}
//                     x={getTrackItemOrderFn}
//                     y={(d) => d.beginDate}
//                     y0={(d) => d.endDate}
//                     data={timelineData}
//                     dataComponent={
//                         <BarWithTooltip
//                             popoverTriggerRef={popoverTriggerRef}
//                             // theme={chartTheme}
//                             getTooltipLabel={getTooltipLabel}
//                             onClickBarItem={handleSelectionChanged}
//                             centerTime
//                         />
//                     }
//                 />
//                 <VictoryAxis
//                     tickValues={[3]}
//                     tickFormat={['']}
//                     style={axisStyle}
//                     gridComponent={
//                         <VictoryBrushLine
//                             disable={
//                                 !selectedTimelineItem || selectedTimelineItem.taskName !== TrackItemType.LogTrackItem
//                             }
//                             width={BAR_WIDTH}
//                             dimension="y"
//                             brushDomain={[
//                                 selectedTimelineItem ? selectedTimelineItem.beginDate : 0,
//                                 selectedTimelineItem ? selectedTimelineItem.endDate : 0,
//                             ]}
//                             onBrushDomainChange={handleEditBrushDebounced}
//                             brushStyle={{
//                                 pointerEvents: 'none',
//                                 // stroke: chartTheme.isDark ? 'white' : 'black',
//                                 // fill: chartTheme.isDark ? 'white' : 'black',
//                                 opacity: ({ active }) => (active ? 0.5 : 0.4),
//                             }}
//                             handleComponent={<BrushHandle viewBox="0 -2 8 30" />}
//                             brushAreaStyle={{
//                                 stroke: 'none',
//                                 fill: 'transparent',
//                                 opacity: 0,
//                             }}
//                         />
//                     }
//                 />
//             </VictoryChart>
//         </div>
//     )
// }

// export default MainTimelineChart