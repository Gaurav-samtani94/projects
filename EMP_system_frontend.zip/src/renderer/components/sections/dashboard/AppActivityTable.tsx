"use client"

import * as React from "react"
import {
    type ColumnDef,
    type ColumnFiltersState,
    type SortingState,
    type VisibilityState,
    flexRender,
    getCoreRowModel,
    getFilteredRowModel,
    getPaginationRowModel,
    getSortedRowModel,
    useReactTable,
} from '@tanstack/react-table'
import { ArrowUpDown, ChevronDown, MoreHorizontal } from "lucide-react"

import { Button } from "renderer/components/ui/button"
import { Checkbox } from "renderer/components/ui/checkbox"
import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "renderer/components/ui/dropdown-menu"
import { Input } from "renderer/components/ui/input"
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "renderer/components/ui/table"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "renderer/components/ui/card"
import { Separator } from "renderer/components/ui/separator"
import { useActivityLogStore } from "renderer/store/LoggingStore"

const data: Payment[] = [
    {
        id: "m5gr84i9",
        appName: 'Whatsapp',
        pageName: 'Chrome',
        startTime: 11,
        endTime: 14,
        totalTime: 2
    },
    {
        id: "3u1reuv4",
        appName: 'VS Code',
        startTime: 12,
        pageName: 'Chrome',
        endTime: 13,
        totalTime: 1
    },
    {
        id: "derv1ws0",
        appName: 'YouTube',
        pageName: 'Chrome',
        startTime: 15,
        endTime: 16,
        totalTime: 1
    },
    {
        id: "5kma53ae",
        appName: 'Google',
        pageName: 'Chrome',
        startTime: 14,
        endTime: 15,
        totalTime: 1
    },
    {
        id: "bhqecj4p",
        appName: 'Mail',
        pageName: 'Chrome',
        startTime: 13,
        endTime: 14,
        totalTime: 1
    },
]

export type Payment = {
    id: string
    appName: string
    startTime: number
    pageName: string
    endTime: number
    totalTime: number
}


const AppActivityTable = () => {

    const [sorting, setSorting] = React.useState<SortingState>([])
    const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
    const getActivityLog = useActivityLogStore((state) => state.activityLog);
    const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>({})
    const [rowSelection, setRowSelection] = React.useState({})

    const columns: ColumnDef<any>[] = [

        {
            accessorKey: "owner",
            header: "App Name",
            cell: ({ row }) => (
                <div className="capitalize">{row.getValue("owner")}</div>
            ),
        },
        {
            accessorKey: "title",
            header: "Page Name",
            cell: ({ row }) => (
                <div className="capitalize">{row.getValue("title")}</div>
            ),
        },
        {
            accessorKey: "start_time",
            header: "Start Time",
            cell: ({ row }) => (
                <div className="capitalize">{convertTo12HourFormat(row.getValue("start_time"))}</div>
            ),
        },
        {
            accessorKey: "end_time",
            header: "End Time",
            cell: ({ row }) => (
                <div className="capitalize">{convertTo12HourFormat(row.getValue("end_time"))}</div>
            ),
        },
        {
            accessorKey: "totalTime",
            header: "Total Time",
            cell: ({ row }) => {
                const start = row.getValue("start_time") as string;
                const end = row.getValue("end_time") as string;
                return (
                    <div className="capitalize">{calculateTimeDifference(start, end)}</div>
                );
            },
        },
    ]

    const table = useReactTable({
        data: getActivityLog?.reverse(),
        columns,
        onSortingChange: setSorting,
        onColumnFiltersChange: setColumnFilters,
        getCoreRowModel: getCoreRowModel(),
        getPaginationRowModel: getPaginationRowModel(),
        getSortedRowModel: getSortedRowModel(),
        getFilteredRowModel: getFilteredRowModel(),
        onColumnVisibilityChange: setColumnVisibility,
        onRowSelectionChange: setRowSelection,
        state: {
            sorting,
            columnFilters,
            columnVisibility,
            rowSelection,
        },
    })

    const calculateTimeDifference = (start: string, end: string) => {
        const cleanStart = start.replace(/AM|PM/i, "").trim();
        const cleanEnd = end.replace(/AM|PM/i, "").trim();

        const [startHours, startMinutes] = cleanStart.split(":").map(Number);
        const [endHours, endMinutes] = cleanEnd.split(":").map(Number);

        const startTotal = startHours * 60 + startMinutes;
        const endTotal = endHours * 60 + endMinutes;

        const diff = endTotal - startTotal;

        const hours = Math.floor(diff / 60);
        const minutes = diff % 60;

        if (hours > 0) {
            return `${hours} hr ${minutes} min`;
        }
        return `${minutes} min`;
    };


    const convertTo12HourFormat = (timeStr: string) => {
        const [hours, minutes] = timeStr.split(":");
        let hour = parseInt(hours, 10);
        hour = hour % 12 || 12;
        return `${hour}:${minutes}`;
    }

    return (
        <Card className="mt-5 w-full h-fit">
            <CardHeader className="!gap-0">
                <CardTitle className="text-lg font-semibold">App Activity</CardTitle>
                <CardDescription className="text-sm text-muted-foreground">Manage and review payment records here.</CardDescription>
            </CardHeader>
            <Separator />
            <CardContent>
                <div className="flex items-center py-4">
                    <Input
                        placeholder="Filter emails..."
                        value={(table.getColumn("owner")?.getFilterValue() as string) ?? ""}
                        onChange={(event) =>
                            table.getColumn("owner")?.setFilterValue(event.target.value)
                        }
                        className="max-w-sm"
                    />
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="outline" className="ml-auto">
                                Columns <ChevronDown />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            {table
                                .getAllColumns()
                                .filter((column) => column.getCanHide())
                                .map((column) => (
                                    <DropdownMenuCheckboxItem
                                        key={column.id}
                                        className="capitalize"
                                        checked={column.getIsVisible()}
                                        onCheckedChange={(value) =>
                                            column.toggleVisibility(!!value)
                                        }
                                    >
                                        {column.id}
                                    </DropdownMenuCheckboxItem>
                                ))}
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>

                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            {table.getHeaderGroups().map((headerGroup) => (
                                <TableRow key={headerGroup.id}>
                                    {headerGroup.headers.map((header) => (
                                        <TableHead key={header.id}>
                                            {header.isPlaceholder
                                                ? null
                                                : flexRender(
                                                    header.column.columnDef.header,
                                                    header.getContext()
                                                )}
                                        </TableHead>
                                    ))}
                                </TableRow>
                            ))}
                        </TableHeader>
                        <TableBody>
                            {table.getRowModel().rows?.length ? (
                                table.getRowModel().rows.map((row) => (
                                    <TableRow
                                        key={row.id}
                                        data-state={row.getIsSelected() && "selected"}
                                    >
                                        {row.getVisibleCells().map((cell) => (
                                            <TableCell key={cell.id}>
                                                {flexRender(cell.column.columnDef.cell, cell.getContext())}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={columns.length} className="h-24 text-center">
                                        No results.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </div>

                <div className="flex items-center justify-end space-x-2 py-4">
                    <div className="flex-1 text-sm text-muted-foreground">
                        {table.getFilteredSelectedRowModel().rows.length} of{" "}
                        {table.getFilteredRowModel().rows.length} row(s) selected.
                    </div>
                    <div className="space-x-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.previousPage()}
                            disabled={!table.getCanPreviousPage()}
                        >
                            Previous
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => table.nextPage()}
                            disabled={!table.getCanNextPage()}
                        >
                            Next
                        </Button>
                    </div>
                </div>
            </CardContent>
        </Card>
    )
}

export default AppActivityTable