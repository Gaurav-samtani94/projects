import { Input } from "renderer/components/ui/input";
import { ScrollArea } from "renderer/components/ui/scroll-area";
import { Avatar, AvatarImage } from "renderer/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "renderer/components/ui/tabs";
import { Dot, Search } from "lucide-react";
import { useEffect, useState } from "react";
import useAuthStore from "renderer/store/AuthStore";
import { GetChatUser, GetGroup, GetUser, markAsRead } from "renderer/service/authService";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { createGroupRoom, createRoom, getToken } from "renderer/service/connectServices";
import AddGroup from "./AddGroup";
import { useChatStore, usePageStore } from "stores/useChatStore";
import { useNavigate } from "react-router-dom";
import { cn } from "renderer/lib/utils";
import ChatController from "renderer/Controller/ChatController";
import BaseUrl from "renderer/service/BaseUrl";




interface Userlist {
    user_id: string;
    id: string;
    firstname: string;
    lastname: string;
    emailaddress: string;
    phone: string;
    tbl_User: any;
    lastmsg: string;
    chat_unread_count: number;
    reporting_manager_name: string;
    date_of_joining: string;
    userfullname: string;
    chat_status: string;
    unread_message_count: number;
}
interface Grouplist {
    id: string;
    group_name: string;
    type: string,
    groupId: string,
    members: [];

}

interface User {
    user_id: string;
    id: string;
    firstname: string;
    lastname: string;
    email: string;
    phone: string;
    reporting_manager_name: string;
    date_of_joining: string;
}



export default function ChatSidebar({ room, forwardedChat, activeTab, setActiveTab, setReplyReset }: { room: any, forwardedChat: any, activeTab: string, setActiveTab: (val: string) => void, setReplyReset: () => void; }) {
    const { setSelectedUser, setChatInfo, setSelectedToken, selectGroup, setSelectGroup, setSelectGroupID, selectedUser, setFlag, setGroupUserId, setCurrentTab, setGroupId, groupID, setAllUsers, allUsers } = useChatStore();
    const { setPageCount } = usePageStore();
    const fallbacksrc = 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y'
    const [searchText, setSearchText] = useState<string>('')
    const [activeChat, setActiveChat] = useState<any>(null);
    const [activeGroup, setActiveGroup] = useState<any>();
    const [UserList, setUserList] = useState<Userlist[]>([]);
    const [groups, setGroups] = useState<any[]>([]);
    const [userInfo, setUserInfo] = useState<User | null>(null);
    const ResUser = useAuthStore.getState().getUser();
    const [unreadGroupMessages, setUnreadGroupMessages] = useState<{ [groupId: string]: number }>({});
    const [status, setStatus] = useState<string[]>([]);
    const hasUnread = UserList.map(user => user?.chat_unread_count).reduce((acc, count) => acc + count, 0) > 0;
    const hasGroupUnread = Object.values(unreadGroupMessages).some(count => count > 0);
    const navigator = useNavigate()

    useEffect(() => {
        let cleanupFn: (() => void) | undefined;
        const setupSocket = async () => {
            cleanupFn = await SocketHandle();
        };
        setupSocket();
        return () => {
            cleanupFn?.();
        };
    }, [selectGroup, selectedUser]);
    // console.log('selectGroup', selectGroup)


    const SocketHandle = async () => {
        let socket: any;

        const handleuserStatusNotification = async (data: any) => {
            setStatus(Array.isArray(data) ? data : [String(data)]);
        };

        const handleMessageAlign = (data: any) => {
            const userId = Number(ResUser?.id);
            const groupIdSet = new Set(groupID);
            if (data?.chat_type === 'User') {
                const isIncoming = data?.to === userId;
                const isOutgoing = data?.sender_Id === userId;
                const targetId = isIncoming ? data?.sender_Id : data?.to;
                setUserList(prevList => {
                    const userMap = new Map(prevList.map(user => [user.id, { ...user }]));
                    const user = userMap.get(targetId);
                    if (!user) return prevList;
                    user.lastmsg = data.message;
                    if (isIncoming && Number(targetId) !== Number(activeChat)) {
                        user.chat_unread_count = (user.chat_unread_count || 0) + 1;
                    }
                    const newList = [user, ...prevList.filter(u => u.id !== targetId)];
                    return newList;
                });

            } else if (data?.chat_type === 'Group' && groupIdSet.has(data?.groupId)) {
                if (data?.groupId !== selectGroup?.groupId) {
                    setUnreadGroupMessages(prev => ({
                        ...prev,
                        [data.groupId]: (prev[data.groupId] || 0) + 1
                    }));
                }

                setGroups(prevList => {
                    const groupMap = new Map(prevList.map(g => [g.groupId, { ...g }]));
                    const group = groupMap.get(data.groupId);
                    if (!group) return prevList;

                    group.lastMessage = data.message;
                    const newList = [group, ...prevList.filter(g => g.groupId !== data.groupId)];
                    return newList;
                });

            } else {
                console.log('else');
            }
        };


        const setupSocketListeners = async () => {
            await waitForSocketReady();

            socket = ChatController.getSocket();
            if (!socket) return;
            socket.on("online-users", handleuserStatusNotification);
            socket.on("notification", handleMessageAlign);
            ChatController.callbackSocket('userStatus', {
                userId: Number(ResUser?.id),
                chat_status: "online",
                status: 1
            });
        };

        const cleanupListeners = () => {
            if (!socket) return;
            socket.off("online-users", handleuserStatusNotification)
            socket.off("notification", handleMessageAlign)

        };


        const waitForSocketReady = () => {
            return new Promise<void>((resolve) => {
                if (ChatController.isSocketConnected === 1) return resolve();

                const interval = setInterval(() => {
                    if (ChatController.isSocketConnected === 1) {
                        clearInterval(interval);
                        resolve();
                    }
                }, 300);
            });
        };



        // await waitForSocketReady();
        setupSocketListeners();
        return () => {
            cleanupListeners();
        };
    }


    useEffect(() => {
        ChatController.callbackSocket('userStatus', { userId: Number(ResUser?.id), chat_status: "online", status: 1, })
        getUserList()
        getUserDetails()
    }, [selectGroup])

    useEffect(() => {
        if (forwardedChat) {
            initializeChat(forwardedChat);
            setActiveChat(forwardedChat?.id);
        }
    }, [forwardedChat]);

    const getUserDetails = async () => {
        const ResUser = useAuthStore.getState().getUser();
        setUserInfo(ResUser)
    }

    const getUserList = async () => {
        getUserMutation.mutate()
        getGroupMutation.mutate()
    }
    const getUserMutation = useMutation({
        mutationFn: GetChatUser,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const currentUserId = useAuthStore.getState().getUser()?.id;
                const filteredUsers = response.data.filter((user: Userlist) => user?.tbl_User && user?.tbl_User?.id !== currentUserId).map((user: Userlist) => user?.tbl_User)
                if (allUsers.length === 0) {
                    setAllUsers(filteredUsers);
                }
                setUserList(filteredUsers);
            }
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })

    const getGroupMutation = useMutation({
        mutationFn: GetGroup,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                setGroups(response.data)
                const groupIds = response.data.map((group: any) => (group.groupId));
                setGroupId(groupIds)

            }
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })

    const initializeChat = async (UserChat?: Userlist) => {
        setActiveChat(Number(UserChat?.id));
        setSelectGroup(null);
        setReplyReset()
        try {
            let selectedUser = UserChat;
            if (!selectedUser) {
                const response = await GetUser();
                const currentUserId = useAuthStore.getState().getUser()?.id;
                const filteredUsers = response.data.filter((user: Userlist) => user.id !== currentUserId).map((user: Userlist) => user?.tbl_User);
                selectedUser = filteredUsers[0]
                setActiveChat(filteredUsers[0]?.id)
            }
            if (!selectedUser) {
                console.warn("No users found");
                return;
            }
            if (!ResUser?.id || !selectedUser?.id) {
                console.warn("User IDs missing, cannot create room");
                return;
            }
            const createRoomPayload = {
                fromUserId: ResUser.id,
                toUserId: selectedUser.id,
            };

            const roomResponse = await createRoom(
                createRoomPayload.fromUserId,
                createRoomPayload.toUserId
            );
            setChatInfo(roomResponse.chat);
            setPageCount(1);
            setSelectedUser(selectedUser);

            if (roomResponse.room) {
                const userDetails = {
                    roomName: roomResponse.room.name,
                    participantName: ResUser.firstname,
                    userId: selectedUser.id,
                    metadata: JSON.stringify({
                        callerId: selectedUser.id,
                        callerName: ResUser.firstname,
                    }),
                };

                const tokenRes = await getToken(
                    userDetails.roomName,
                    userDetails.participantName,
                    userDetails.userId,
                    userDetails.metadata
                );
                setFlag(true)
                setSelectedToken(tokenRes.token);
                ChatController.callbackSocket('userStatus', { userId: Number(selectedUser.id), chat_status: "online", status: 1, })
                ChatController.callbackSocket('stop-typing', { userId: ResUser?.id, isTyping: false, name: ResUser?.firstname, type: 'user' })

            }
        } catch (err) {
            console.error("❌ Error in initializeChat:", err);
        }
    };
    const initializeGroup = async (Groups?: Grouplist) => {
        setActiveChat(null);
        setSelectedUser(null)
        setReplyReset()
        const groupMemberUserIds = Groups?.members?.map((member: any) => member.userId) || [];
        await setSelectGroupID(groupMemberUserIds)
        const groupMemberIds = Groups?.members?.map((member: any) => member.memberId) || [];
        console.log('groupMemberIds', groupMemberIds)
        setGroupUserId(groupMemberIds)
        try {
            let selectedGroup = Groups;
            if (!selectedGroup) {
                const response = await GetGroup();
                const filteredGroup = response.data[0];
                selectedGroup = response.data[0]
                setActiveGroup(filteredGroup?.groupId)
            }

            if (!ResUser?.id) {
                console.warn("User IDs missing, cannot create room");
                return;
            }
            if (!selectedGroup) {
                console.warn("No users found");
                return;
            }

            const createRoomPayload = {
                userIds: String(groupMemberIds),
                groupId: selectedGroup.groupId,
            };

            const roomResponse = await createGroupRoom(
                createRoomPayload.groupId,
                createRoomPayload.userIds
            );
            setPageCount(1);
            setSelectGroup(selectedGroup);
            setChatInfo(selectedGroup);
            await setActiveGroup(selectedGroup?.groupId)
            if (roomResponse.room) {
                const userDetails = {
                    roomName: roomResponse.room.name,
                    participantName: ResUser.firstname,
                    userId: ResUser.id,
                    metadata: JSON.stringify({
                        callerId: selectedGroup.groupId,
                        callerName: ResUser.firstname,
                    }),
                };

                const tokenRes = await getToken(
                    userDetails.roomName,
                    userDetails.participantName,
                    userDetails.userId,
                    userDetails.metadata
                );
                setFlag(true)
                setSelectedToken(tokenRes.token);
                ChatController.callbackSocket('userStatus', { userId: Number(ResUser?.id), chat_status: "online", status: 1, })
                ChatController.callbackSocket('stop-typing', { userId: ResUser?.id, isTyping: false, name: ResUser?.firstname, GroupId: selectedGroup.groupId, type: 'group' })

            }
        } catch (err) {
            console.error("❌ Error in initializeChat:", err);
        }
    }

    const handleGroupCreated = () => {
        getGroupMutation.mutate()
    }

    const resetUnreadMessages = async (userId: any, unread: number) => {
        const read = await markAsRead(userId);
        if (unread > 0) {
            setUserList(prevList => {
                const idx = prevList.findIndex(user => user?.id === userId);
                if (idx === -1) return prevList;
                const selectedUser = {
                    ...prevList[idx],
                    chat_unread_count: (0),
                };
                return [selectedUser, ...prevList.filter((_, i) => i !== idx)];
            });
        }
    };
    const resetGroupUnreadMessages = (groupId: string) => {
        setUnreadGroupMessages(prev => ({
            ...prev,
            [groupId]: 0
        }));
    };


    const leaveGroupChat = (groupId: any) => {
        const data = {
            userId: Number(ResUser?.id),
            groupId: selectGroup.groupId,
        }
        ChatController.callbackSocket('leaveGroupChat', data)
    }

    return (
        <div className="w-72 h-[calc(100vh-40px)] overflow-y-auto border-r flex flex-col">
            <div className="p-4">
                <div className="relative">
                    {/* biome-ignore lint/style/useTemplate: <explanation> */}
                    <Input value={searchText} onChange={(t) => setSearchText(t.target.value)} placeholder={"Search for " + activeTab + "..."} className="rounded-lg pl-10" />
                    <Search className="absolute left-3 top-2.5" size={18} />
                    {searchText && activeTab === 'users' && (
                        <ul className="absolute z-10 mt-1 w-full rounded-lg bg-white shadow-lg border border-gray-200">
                            {UserList.filter(user =>
                                user.userfullname?.toLowerCase().includes(searchText.toLowerCase())
                            ).length > 0 ? (
                                UserList.filter(user =>
                                    user.userfullname?.toLowerCase().includes(searchText.toLowerCase())
                                ).map(user => (
                                    <li
                                        key={user.id}
                                        onClick={() => {
                                            setActiveChat(Number(user.id));
                                            initializeChat(user);
                                            setSelectGroup(null);
                                            setSearchText('');
                                        }}
                                        onKeyDown={(e) => {
                                            if (e.key === 'Enter' || e.key === ' ') {
                                                setActiveChat(Number(user.id));
                                                initializeChat(user);
                                                setSelectGroup(null);
                                            }
                                        }}
                                        className="p-2 hover:bg-gray-100 cursor-pointer"
                                    >
                                        {user.userfullname}
                                    </li>
                                ))
                            ) : (
                                <li className="p-2 text-gray-500">No User Found</li>
                            )}
                        </ul>
                    )}


                    {searchText && activeTab === 'groups' && (
                        <ul className="absolute z-10 mt-1 w-full rounded-lg bg-white shadow-lg border border-gray-200">
                            {groups
                                .filter((group) =>
                                    group.groupName.toLowerCase().includes(searchText.toLowerCase())
                                ).length > 0 ? (groups
                                    .filter((group) =>
                                        group.groupName.toLowerCase().includes(searchText.toLowerCase())
                                    )
                                    .map((group) => (
                                        <li key={group.id}
                                            onClick={() => {
                                                setActiveGroup(group.groupId)
                                                initializeGroup(group);
                                                setSelectedUser(null)
                                                setSearchText('')
                                                ChatController.callbackSocket('userStatus', { userId: Number(ResUser?.id), chat_status: "online", status: 1, })
                                            }}
                                            onKeyDown={(e) => {
                                                if (e.key === 'Enter' || e.key === ' ') {
                                                    setActiveGroup(group?.id);
                                                    initializeChat(group);
                                                    setSelectGroup(null);
                                                    setSearchText('')
                                                    ChatController.callbackSocket('userStatus', { userId: selectedUser?.id, chat_status: "online", status: 1, })

                                                }
                                            }}
                                            className="p-2 hover:bg-gray-100 cursor-pointer">
                                            {group.groupName}
                                        </li>
                                    ))) : (
                                <li className="p-2 text-gray-500">No Group Found</li>
                            )}
                        </ul>
                    )}
                </div>
            </div>

            <Tabs value={activeTab} onValueChange={(val) => setActiveTab(val)} className="flex-1">
                <TabsList className="grid grid-cols-2 rounded-lg mx-4">
                    <TabsTrigger value="users" onClick={() => { navigator('/chat'); }}>Users {hasUnread ? <div className="w-2 h-2 rounded-full bg-red-500 mb-2 flex items-center justify-center shadow-md" /> : ''}</TabsTrigger>
                    <TabsTrigger value="groups" onClick={() => { navigator('/chat/group'); }}>Groups {hasGroupUnread ? <div className="w-2 h-2 rounded-full mb-2 bg-red-500 flex items-center justify-center shadow-md" /> : ''}</TabsTrigger>
                </TabsList>

                <TabsContent value="users">
                    <ScrollArea className="h-[calc(100vh-238px)]">
                        {UserList?.filter(user => user?.id !== userInfo?.id).map((user, index) => {
                            const Status = Array.isArray(status) && status.includes(String(user?.id));
                            return (

                                // biome-ignore lint/a11y/useKeyWithClickEvents: <explanation>
                                <div
                                    key={index}
                                    className={cn(
                                        "w-100 flex items-center gap-3 p-4 border-b cursor-pointer border-border rounded-md transition-colors",
                                        selectedUser?.id === Number(user?.id) ? "bg-muted" : "",
                                        "hover:bg-accent"
                                    )}
                                    onClick={() => {

                                        initializeChat(user);
                                        setSelectGroup(null)
                                        resetUnreadMessages(user.id, user.chat_unread_count);
                                        setCurrentTab('users')
                                        ChatController.callbackSocket('userStatus', { userId: Number(ResUser?.id), chat_status: "online", status: 1, })
                                    }}
                                >
                                    <Avatar className="w-12 h-12">
                                        <AvatarImage
                                            src={'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y'}
                                            alt={user?.userfullname}
                                        />
                                    </Avatar>
                                    <div className="flex mt-1 flex-col w-40 overflow-hidden whitespace-nowrap text-ellipsis">
                                        <span className="text-sm">{user?.userfullname}</span>
                                        <span className="text-sm text-gray-400 ml-1 mt-0.5">{user?.lastmsg}</span>
                                    </div>
                                    {user?.chat_unread_count > 0 ? (
                                        <div className="w-5 h-5 rounded-full bg-red-500 text-white text-xs font-semibold flex items-center justify-center shadow-md">
                                            {user?.chat_unread_count}
                                        </div>
                                    ) :
                                        <Dot className={cn(Status ? "text-green-500" : "text-gray-400")} />
                                    }
                                </div>

                            );
                        })}

                    </ScrollArea>
                </TabsContent>

                <TabsContent value="groups">
                    <ScrollArea className="h-[calc(100vh-238px)]">
                        <div className="flex justify-between items-center px-4 mb-4">
                            <p>Groups</p>
                            <AddGroup OnCreateGroup={() => { handleGroupCreated() }} />
                        </div>
                        {groups?.map((group, index) => (
                            // biome-ignore lint/a11y/useKeyWithClickEvents: <explanation>
                            <div key={index} className={`flex items-center gap-3 p-4 border-b border-border cursor-pointer rounded-md transition-colors ${activeGroup === Number(group.groupId) ? "bg-muted" : ""}`}
                                onClick={() => {
                                    initializeGroup(group);
                                    resetGroupUnreadMessages(group.groupId);
                                    ChatController.callbackSocket('userStatus', { userId: Number(ResUser?.id), chat_status: "online", status: 1, })
                                    leaveGroupChat(group.groupId)
                                }}>
                                <Avatar>
                                    <AvatarImage src={group.profilePath ? `${BaseUrl.Url_Base}${group.profilePath}` : fallbacksrc} alt={group.group_name} />
                                </Avatar>
                                <div className="flex mt-1 flex-col w-40 overflow-hidden whitespace-nowrap text-ellipsis">
                                    <span className="text-sm">{group?.groupName}</span>
                                    <span className="text-sm text-gray-400 ml-1 mt-0.5">{group?.lastMessage}</span>
                                </div>
                                {
                                    unreadGroupMessages[group.groupId] > 0 && (
                                        <div className="w-5 h-5 rounded-full bg-red-500 text-white text-xs font-semibold flex items-center justify-center shadow-md">
                                            {unreadGroupMessages[group.groupId]}
                                        </div>
                                    )
                                }
                            </div>

                        ))}
                    </ScrollArea>
                </TabsContent>
            </Tabs>
        </div>
    );
}
