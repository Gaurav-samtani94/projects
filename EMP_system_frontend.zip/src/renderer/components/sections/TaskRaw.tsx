import { useSortable } from "@dnd-kit/sortable";
import { CalendarIcon, Check, ChevronDown, ChevronRight, ChevronsUpDown, Delete, DeleteIcon, Grip, Plus, Trash2 } from "lucide-react";
import React, { useEffect, useMemo, useRef, useState } from "react";
import type { coloredLabel, TaskRowTypes as Row } from "Types/Tasks";

import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Popover, PopoverTrigger, PopoverContent } from "../ui/popover";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from "../ui/command";
import { cn } from "renderer/lib/utils";
import { Label } from "../ui/label";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "../ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "../ui/form";
import { useForm } from "react-hook-form";
import { format, set, setDate } from "date-fns";
import { Calendar } from "../ui/calendar";
import AddTaskDrawer from "./AddTaskDrawer";
import { useMutation } from "@tanstack/react-query";
import { createTask, deleteTask, updateTaskField } from "renderer/service/project";
import { FacetedFilter } from "./FactedFilter";
import { Checkbox } from "../ui/checkbox";
import { toast } from "sonner";
import ChatController from "renderer/Controller/ChatController";
import useAuthStore from "renderer/store/AuthStore";

const baseUrl = 'https://staging-emp.growthgrids.com/';


type SortableRowProps = {
    // row: Row;
    row: any;
    level: number;
    expanded: string[];
    toggleExpand: (id: string) => void;
    addItem: (parentId: string) => void;
    heads: any;
    refetchTaskList: any;
    setSubTaskAdd: any;
    users: any,
    projectDetail?: any
};

type RenderRowsProps = {
    rows: Row[];
    level: number;
    expanded: string[];
    toggleExpand: (id: string) => void;
    addItem: (parentId: string) => void;
    heads: any;
    refetchTaskList: any;
    setSubTaskAdd: any
    users: any,
    projectDetail?: any
};

type StatusSelectProps = {
    name: string;
    initialValue?: any;
    taskFieldObj: any;
    handleUpdateTaskField: any;
    type: any;

};

const StatusSelect = ({ name, initialValue, taskFieldObj, handleUpdateTaskField, type }: StatusSelectProps) => {
    const currentArray = Array.isArray(initialValue) ? initialValue : [];

    const [selected, setSelected] = useState<any | null>();

    useEffect(() => {
        const newVal = currentArray?.find((item: any) => item.id == (taskFieldObj[name]?.select_val)) || null
        setSelected(newVal);
    }, [currentArray])
    const [openDialog, setOpenDialog] = useState(false);
    const [open, setOpen] = useState(false);

    const form = useForm({
        defaultValues: {
            label: "",
            color: "#000000",
        },
        mode: "onBlur",
    });



    return (
        <>
            <Popover open={open} onOpenChange={setOpen}>
                <PopoverTrigger asChild>
                    <div
                        className="flex w-full items-center justify-between rounded-md border px-3 py-2 text-xs shadow-sm whitespace-nowrap cursor-pointer"
                    >
                        {selected ? (
                            <div className="flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: selected.color || '#ccc' }} />
                                <span>{selected?.option_name}</span>
                            </div>
                        ) : (
                            <span className="text-muted-foreground">Select {name}</span>
                        )}
                        <ChevronsUpDown className="ml-auto h-4 w-4 text-muted-foreground" />
                    </div>
                </PopoverTrigger>
                <PopoverContent className="p-0" align="start">
                    <Command>
                        <CommandInput placeholder="Search status..." />
                        <CommandEmpty>
                            <div className="flex items-center justify-between text-sm text-muted-foreground px-2">
                                <span>Create {name}</span>
                                <Button
                                    size="icon"
                                    variant="outline"
                                    onClick={() => setOpenDialog(true)}
                                >
                                    <Plus />
                                </Button>
                            </div>
                        </CommandEmpty>
                        <CommandGroup>
                            {currentArray?.map((status: any) => (
                                <CommandItem key={status?.id} className="flex items-center justify-between gap-2 cursor-pointer"
                                    onSelect={() => {
                                        setSelected(status);
                                        handleUpdateTaskField(status, taskFieldObj[name], type);
                                        setOpen(false);
                                    }}
                                // value={ }
                                >
                                    <div className="flex items-center gap-3">
                                        <div className="w-2 h-2 rounded-full" style={{ backgroundColor: status.color || '#ccc' }} />
                                        <span>{status?.option_name}</span>
                                    </div>
                                    <Check
                                        className={cn(
                                            "ml-auto h-4 w-4",
                                            selected?.id == status.id
                                                ? "opacity-100"
                                                : "opacity-0"
                                        )}
                                    />
                                </CommandItem>
                            ))}
                        </CommandGroup>
                    </Command>
                </PopoverContent>
            </Popover>
        </>
    );
}

interface DateSelectProps {
    name: string;
    value?: Date | null;
    taskFieldObj: any,
    handleUpdateTaskField: any,
    type: any
}

const DateSelect: React.FC<DateSelectProps> = ({ name, value, taskFieldObj, handleUpdateTaskField, type }) => {
    const [selectedDate, setSelectedDate] = useState<Date | null>(value || null);
    const [open, setOpen] = useState(false);

    useEffect(() => {
        if (value) {
            setSelectedDate(value)
        }
    }, [value])

    return (
        <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger asChild>
                <Button
                    variant={"outline"}
                    className={cn(
                        "w-full pl-3 text-left font-normal",
                        !selectedDate && "text-muted-foreground"
                    )}
                >
                    {selectedDate ? (
                        format(selectedDate, "PPP")
                    ) : (
                        <span>Pick a date</span>
                    )}
                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                    mode="single"
                    selected={selectedDate || undefined}
                    onSelect={(date: any) => {
                        setSelectedDate(date);
                        handleUpdateTaskField(date, taskFieldObj[name], type);
                        setOpen(false);
                    }}
                    // disabled={{ before: new Date() }}
                    initialFocus
                />
            </PopoverContent>
        </Popover>
    );
};

// === Components ===
const SortableRow: React.FC<SortableRowProps> = ({ row, level, expanded, toggleExpand, addItem, heads, refetchTaskList, setSubTaskAdd, users, projectDetail }) => {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging
    } = useSortable({ id: row.id });
    const [editedFields, setEditedFields] = useState<Record<string, any>>({});
    const user = useAuthStore.getState().getUser();

    const style: React.CSSProperties = {
        transform: transform ? `translate3d(0, ${transform.y}px, 0)` : undefined,
        transition,
        opacity: isDragging ? 0.5 : 1,
        position: 'relative',
        zIndex: isDragging ? 1 : 0,
        paddingLeft: `${level * 32}px`
    };



    const { data: rowData, taskFieldObj } = useMemo(() => {
        const data: Record<string, any> = {};
        const taskFieldObj: Record<string, any> = {};
        row?.task_fields?.forEach((field: any) => {
            const matchedHead = heads?.find((head: any) => head.id === field.type_key_id);
            if (matchedHead) {
                const fieldName = matchedHead.config_detail;
                taskFieldObj[matchedHead.label_name] = field;

                if (fieldName === 'select_val') {
                    data[matchedHead.label_name] = field['single_select'];
                } else if (fieldName === 'multi_select_val') {
                    data[matchedHead.label_name] = field['multi_select'];
                }
                else if (fieldName === 'relation_val') {
                    data[matchedHead.label_name] = field['multi_select'];
                }
                else if (fieldName === 'person_val') {
                    data[matchedHead.label_name] = field['multi_select'];
                }
                else if (fieldName === 'checkbox_val') {
                    data[matchedHead.label_name] = field['checkbox_val'];
                }
                else if (fieldName === 'created_at_val') {
                    data[matchedHead.label_name] = field['created_at_val'];
                }
                else if (fieldName === 'created_by_val') {
                    data[matchedHead.label_name] = field?.creater?.userfullname;
                }
                else if (fieldName === 'updated_at_val') {
                    data[matchedHead.label_name] = field['updated_at_val'] || '-';
                }
                else if (fieldName === 'updated_by_val') {
                    data[matchedHead.label_name] = field?.updater?.userfullname || '-';
                }
                else {
                    data[matchedHead.label_name] = field[fieldName];
                }
            }
        });

        return { data, taskFieldObj };
    }, [row?.task_fields, heads]);

    const updateTaskRowField = useMutation({
        mutationFn: updateTaskField,
        onSuccess: (_data, variable) => {
            refetchTaskList();
            toast.success(_data?.message)

        },
        onError: (error: any) => {
            console.log('error============', error);
            toast.error(error?.response?.data?.message)
        }
    })

    // console.log('row?.task_fields=========', row?.task_fields);

    // To update Single field.
    const handleUpdateTaskField = (field: any, taskFieldObjByName: any, type: any) => {
        const data = ((type === 'select_val' || type === 'multi_select') ? field?.id : type === 'date' ? field : field);

        updateTaskRowField.mutate({ project_id: taskFieldObjByName?.project_id, id: taskFieldObjByName?.id, type_id: taskFieldObjByName?.type_id, task_id: taskFieldObjByName?.task_id, type_key_id: taskFieldObjByName?.type_key_id, data: type === 'attachment_val' ? null : data, file: type === 'attachment_val' ? field : null })
    }

    const deleteTaskMutation = useMutation({
        mutationFn: deleteTask,
        onSuccess: () => {
            refetchTaskList();
        },
        onError: (error: any) => {
            alert(error?.response?.data?.message || 'Something went wrong !!')
            // console.log('error============', error);
        }
    })

    const handleDeleteTask = (taskId: string) => {
        deleteTaskMutation.mutate({ id: taskId })
    }


    return (
        <div ref={setNodeRef} style={style} className="group w-max min-w-full">
            <div className=''>
                <div className="flex items-center border border-collapse">
                    <div className="p-2 cursor-grab touch-none w-8" {...attributes} {...listeners}>
                        <Grip className="h-4 w-4 text-gray-400" />
                    </div>

                    <div className="p-2 flex items-center gap-3 flex-1 min-w-sm">
                        {row?.children?.length > 0 && (
                            <button
                                onClick={() => toggleExpand(row.id)}
                                className="mr-1 focus:outline-none"
                            >
                                {expanded?.includes(row.id) ? (
                                    <ChevronDown className="h-4 w-4" />
                                ) : (
                                    <ChevronRight className="h-4 w-4" />
                                )}
                            </button>
                        )}

                        {heads?.filter((item: any) => item?.config_detail !== 'rich_text').map((headItem: any) => {
                            // console.log('rheadItem.label_name====', taskFieldObj[headItem.label_name]?.select_val);


                            return (
                                <div key={headItem.id} className="flex-1 p-2 min-w-sm">
                                    {headItem?.config_detail === 'select_val' ? (
                                        <StatusSelect name={headItem.label_name} initialValue={rowData[headItem.label_name]} taskFieldObj={taskFieldObj} handleUpdateTaskField={handleUpdateTaskField} type={headItem?.config_detail} />

                                    )
                                        :
                                        headItem?.config_detail === 'person_val' ? (
                                            <FacetedFilter
                                                title={headItem.label_name}
                                                type={headItem.config_detail}
                                                hasAvatar={true}
                                                options={rowData[headItem.label_name]?.map((item: any) => {
                                                    return { value: item.id, label: item?.userfullname }
                                                })}
                                                taskFieldObj={taskFieldObj[headItem.label_name]}
                                                handleUpdateTaskField={handleUpdateTaskField}
                                            />
                                        )

                                            : headItem?.config_detail === 'date_val' ? (
                                                <DateSelect name={headItem.label_name} value={rowData[headItem.label_name]}
                                                    taskFieldObj={taskFieldObj} handleUpdateTaskField={handleUpdateTaskField}
                                                    type={'date'}
                                                />
                                            ) :
                                                (headItem?.config_detail === 'text_val' || headItem?.config_detail === 'number_val') ? (
                                                    headItem.label_name === "Name" ?

                                                        <div className="flex gap-3 items-center">
                                                            <AddTaskDrawer getData={() => ({ row, heads })} refetchTaskList={refetchTaskList} users={users} projectDetail={projectDetail}>
                                                                <span className="font-medium uppercase hover:underline duration-150"> {rowData[headItem.label_name] || "-"}
                                                                </span>
                                                            </AddTaskDrawer>
                                                            <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                                                                <Button
                                                                    variant="ghost"
                                                                    size="sm"
                                                                    onClick={() => setSubTaskAdd({ val: row?.id, isChecked: true })}
                                                                    className="h-6 w-6 p-0"
                                                                >
                                                                    <Plus className="h-4 w-4" />
                                                                </Button>
                                                            </div>
                                                            <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                                                                <Button
                                                                    variant="destructive"
                                                                    size="sm"
                                                                    onClick={() => handleDeleteTask(row.id)}
                                                                    className="h-6 w-6 p-0"
                                                                >
                                                                    <Trash2 className="h-4 w-4" />
                                                                </Button>
                                                            </div>
                                                        </div>

                                                        :
                                                        <Input placeholder={headItem.label_name} name={headItem.label_name}
                                                            value={editedFields[headItem.label_name] ?? (rowData[headItem.label_name] || '')}

                                                            onChange={(e) => {
                                                                const inputVal = e.target.value;
                                                                if (headItem?.config_detail === 'number_val') {
                                                                    // Allow only digits (you can extend to allow decimal if needed)
                                                                    if (/^\d*$/.test(inputVal)) {
                                                                        setEditedFields((prev) => ({
                                                                            ...prev,
                                                                            [headItem.label_name]: inputVal,
                                                                        }));
                                                                    }
                                                                } else {
                                                                    // No validation for text_val or others
                                                                    setEditedFields((prev) => ({
                                                                        ...prev,
                                                                        [headItem.label_name]: inputVal,
                                                                    }));
                                                                }

                                                            }}

                                                            onBlur={() => {
                                                                const newValue = editedFields[headItem.label_name];
                                                                if (newValue !== undefined && newValue !== rowData[headItem.label_name]) {
                                                                    handleUpdateTaskField(newValue, taskFieldObj[headItem.label_name], headItem.config_detail);
                                                                }
                                                                else {
                                                                    console.log('===')
                                                                }
                                                            }}
                                                        />
                                                )
                                                    :
                                                    headItem?.config_detail === 'relation_val' ? (
                                                        <FacetedFilter
                                                            title={headItem.label_name}
                                                            type={headItem.config_detail}
                                                            options={rowData[headItem.label_name]?.map((item: any) => {
                                                                return { value: item.id, label: item?.task_name }
                                                            })}
                                                            taskFieldObj={taskFieldObj[headItem.label_name]}
                                                            handleUpdateTaskField={handleUpdateTaskField}
                                                        />
                                                    )
                                                        :

                                                        headItem?.config_detail == 'multi_select_val' ?
                                                            (<FacetedFilter
                                                                title={headItem.label_name}
                                                                type={headItem.config_detail}
                                                                options={rowData[headItem.label_name]?.map((item: any) => {
                                                                    return { value: item.id, label: item?.option_name }
                                                                })}
                                                                taskFieldObj={taskFieldObj[headItem.label_name]}
                                                                handleUpdateTaskField={handleUpdateTaskField}
                                                            />
                                                            )
                                                            :
                                                            headItem?.config_detail === 'checkbox_val' ?
                                                                <div className="">
                                                                    <Checkbox
                                                                        checked={editedFields[headItem.label_name] == 1 || (rowData[headItem.label_name] == 1)}

                                                                        onCheckedChange={(checked) => {
                                                                            const valueToStore = checked ? 1 : 0;
                                                                            setEditedFields((prev) => ({
                                                                                ...prev,
                                                                                [headItem.label_name]: valueToStore,
                                                                            }));
                                                                            handleUpdateTaskField(valueToStore, taskFieldObj[headItem.label_name], headItem.config_detail);
                                                                        }}
                                                                        aria-label="Select all"
                                                                    />

                                                                </div>

                                                                :
                                                                headItem?.config_detail === 'attachment_val' ? (
                                                                    <div className="flex flex-col gap-2">
                                                                        {/* Upload Input */}
                                                                        <input
                                                                            type="file"
                                                                            style={{ backgroundColor: 'orange', width: '200px', borderRadius: '8px', padding: '10px', cursor: 'pointer' }}
                                                                            accept=".png,.jpg,.jpeg,.gif,.pdf,.doc,.docx,.xls,.xlsx"
                                                                            onChange={(e) => {
                                                                                const file = e.target.files?.[0];
                                                                                if (file) {
                                                                                    setEditedFields((prev) => ({
                                                                                        ...prev,
                                                                                        [headItem.label_name]: file,
                                                                                    }));
                                                                                    handleUpdateTaskField(file, taskFieldObj[headItem.label_name], headItem.config_detail);
                                                                                }
                                                                            }}
                                                                        />

                                                                        {/* Preview or Download link if attachment exists */}
                                                                        {rowData[headItem.label_name] && (
                                                                            <div className="flex items-center gap-2">
                                                                                {typeof rowData[headItem.label_name] === 'string' &&
                                                                                    rowData[headItem.label_name].match(/\.(jpeg|jpg|png|gif)$/i) ? (
                                                                                    <img
                                                                                        src={baseUrl + rowData[headItem.label_name]}
                                                                                        alt="attachment"
                                                                                        className="w-16 h-16 object-cover rounded"
                                                                                    />
                                                                                ) : (
                                                                                    <span className="text-sm text-gray-700">
                                                                                        {rowData[headItem.label_name]?.split('/').pop()}
                                                                                    </span>
                                                                                )}
                                                                                <a
                                                                                    href={rowData[headItem.label_name]}
                                                                                    target="_blank"
                                                                                    rel="noopener noreferrer"
                                                                                    className="text-blue-600 underline text-sm"
                                                                                >
                                                                                    Download
                                                                                </a>
                                                                            </div>
                                                                        )}

                                                                    </div>
                                                                )
                                                                    :
                                                                    headItem?.config_detail === 'estimated_val' ? (
                                                                        <Input placeholder={headItem.label_name} name={headItem.label_name}
                                                                            value={editedFields[headItem.label_name] ?? (rowData[headItem.label_name] || '')}

                                                                            onChange={(e) => {
                                                                                const inputVal = e.target.value;
                                                                                const partialPattern = /^(\d+[wWdDhH]?[\s]*)*$/;

                                                                                // Allow empty or partially valid input
                                                                                if (inputVal === '' || partialPattern.test(inputVal)) {
                                                                                    setEditedFields((prev) => ({
                                                                                        ...prev,
                                                                                        [headItem.label_name]: inputVal,
                                                                                    }));
                                                                                }
                                                                            }}


                                                                            onBlur={() => {
                                                                                const newValue = editedFields[headItem.label_name];
                                                                                if (newValue !== undefined && newValue !== rowData[headItem.label_name]) {
                                                                                    handleUpdateTaskField(newValue, taskFieldObj[headItem.label_name], headItem.config_detail);
                                                                                }
                                                                                else {
                                                                                    console.log('===')
                                                                                }
                                                                            }}
                                                                        />
                                                                    )
                                                                        :
                                                                        rowData[headItem.label_name]
                                    }
                                </div>
                            )
                        })}

                    </div>

                    {/*  <FacetedFilter
                                title="Priority"
                                options={priorities}
                            /> */}

                </div>
            </div>
        </div>
    );
};

export const RenderRows: React.FC<RenderRowsProps> = ({ rows, heads, level, expanded, toggleExpand, addItem, refetchTaskList, setSubTaskAdd, users, projectDetail }) => {

    const [getNewTask, setNewTask] = useState('');
    const [getTaskDetail, setTaskDetail] = useState<any>(null);
    const mutationCreateTask = useMutation({
        mutationFn: createTask,
        onSuccess: response => {
            if (response?.status == 1) {
                setNewTask('');
                refetchTaskList();
            }

        },
        onError: error => {
            console.log('error', error);
        }
    })

    // To find Maximum Serial Number.
    function findMaxSrNo(tasks: any) {
        let maxSrNo = -Infinity;
        function traverse(taskList: any) {
            for (const task of taskList) {
                if (typeof task?.sr_no === 'number') {
                    maxSrNo = Math.max(maxSrNo, task?.sr_no);
                }
                if (task?.children && task?.children.length > 0) {
                    traverse(task?.children);
                }
            }
        }

        traverse(tasks);
        return maxSrNo + 1;
    }

    // To Create the Task.
    const handleCreateTask = (items: any) => {
        const srNumber = findMaxSrNo(items);
        if (getNewTask?.length) {
            mutationCreateTask.mutate({ project_id: items[0]?.project_id, sr_no: srNumber ? srNumber : 0, parent_id: items[0]?.parent_id ? items[0]?.parent_id : 0, task_name: getNewTask })
        }
        else {
            alert('Please enter the Task name')
        }
    }

    // const handleOpenDrawer = () => {
    //     setTaskDetail(rows);
    // }

    return (
        <>
            <div className='relative max-w-max min-w-full' style={{ paddingLeft: `${level * 32}px` }} >
                <div className="sortable-row-header mt-6 flex items-center bg-secondary border">
                    <div className="w-8 h-full flex">
                        <Grip className="opacity-0" />
                        {level !== 0
                            && <div className="h-6  absolute bottom-10 w-[1px] bg-border" />
                        }
                    </div>
                    {(heads?.sort((a: any, b: any) => a.sr_no - b.sr_no) ?? [])?.filter((item: any) => item?.config_detail !== 'rich_text')?.map((item: any) => {
                        return (
                            <div className="flex-1 p-2 min-w-sm ">
                                <p>{item?.label_name}</p>
                            </div>
                        )
                    })}
                </div>
            </div>
            {(rows ?? [])?.map(row => (
                <React.Fragment key={row.id}>
                    <SortableRow
                        row={row}
                        level={level}
                        expanded={expanded}
                        toggleExpand={toggleExpand}
                        addItem={addItem}
                        heads={heads}
                        refetchTaskList={refetchTaskList}
                        setSubTaskAdd={setSubTaskAdd}
                        users={users}
                        projectDetail={projectDetail}

                    />
                    {expanded?.includes(row.id) && row?.children?.length > 0 && (
                        <>
                            <RenderRows
                                rows={row?.children}
                                level={level + 1}
                                expanded={expanded}
                                toggleExpand={toggleExpand}
                                addItem={addItem}
                                heads={heads}
                                refetchTaskList={refetchTaskList}
                                setSubTaskAdd={setSubTaskAdd}
                                users={users}
                                projectDetail={projectDetail}

                            />
                            <div className="mb-6">

                            </div>
                        </>
                    )}
                </React.Fragment>
            ))}
            {/* Enter new task */}
            <div className='relative min-w-full' style={{ paddingLeft: `${level * 32}px` }}>
                <div className="sortable-row-footer flex items-center border">
                    <div className="w-8 h-full flex">
                    </div>
                    <div className="p-2 min-w-sm ">
                        <div className="relative flex items-center gap-2">
                            <Input
                                placeholder="Enter new task"
                                className="pr-6"
                                onChange={(e) => setNewTask(e.target.value)}
                                onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                                    if (e.key === ' ' && getNewTask.length === 0) {
                                        e.preventDefault();
                                    }
                                    if (e.key === 'Enter') {
                                        e.preventDefault();
                                        handleCreateTask(rows);
                                    }
                                }}
                                value={getNewTask}
                            />
                            <Button
                                size="icon"
                                variant="outline"
                                className=""
                                onClick={() => handleCreateTask(rows)}
                            >
                                <Plus className="h-4 w-4" />
                            </Button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};
