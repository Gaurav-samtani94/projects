import React from 'react'
import { Drawer, DrawerClose, DrawerContent, DrawerDescription, DrawerFooter, DrawerHeader, DrawerTitle, DrawerTrigger } from '../ui/drawer'
import { Button } from '../ui/button'
import { Plus } from 'lucide-react'
import { Form, FormField } from '../ui/form'
import { useForm } from 'react-hook-form'


const AddProjectDrawer = () => {

    return (
        <Drawer>
            <DrawerTrigger>
                <Button
                    size="icon"
                    variant="outline"
                    className="ml-auto rounded-full"
                >
                    <Plus />
                    <span className="sr-only">Create Project</span>
                </Button>
            </DrawerTrigger>
            <DrawerContent>
                <DrawerHeader>
                    <DrawerTitle>Create Project</DrawerTitle>
                    <DrawerDescription>Please Enter these fields to create project</DrawerDescription>
                </DrawerHeader>
            </DrawerContent>
        </Drawer>
    )
}

export default AddProjectDrawer