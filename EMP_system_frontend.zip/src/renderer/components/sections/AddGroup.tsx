import React, { useEffect } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../ui/dialog'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '../ui/command'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'
import { Check, Plus } from 'lucide-react'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { useMutation } from '@tanstack/react-query'
import { GetChatUser, createGroup } from 'renderer/service/authService'
import { toast } from 'sonner'
import useAuthStore from 'renderer/store/AuthStore'

interface Userlist {
    user_id: string;
    id: string;
    firstname: string;
    lastname: string;
    emailaddress: string;
    phone: string;
    tbl_User: any;
    reporting_manager_name: string;
    date_of_joining: string;
    userfullname: string;
    chat_status: string
}


const AddGroup = ({ OnCreateGroup }: any) => {
    const [open, setOpen] = React.useState(false)
    const [users, setUsers] = React.useState<any[]>([])
    const [groupName, setGroupName] = React.useState('')
    const [selectedUsers, setSelectedUsers] = React.useState<any[]>([])
    const user = useAuthStore.getState().getUser();

    useEffect(() => {
        getUserList()
    }, [])

    const getUserMutation = useMutation({
        mutationFn: GetChatUser,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const currentUserId = useAuthStore.getState().getUser()?.id;
                const filteredUsers = response.data.filter((user: Userlist) => user.id !== currentUserId && user.tbl_User !== null).map((user: Userlist) => user?.tbl_User)
                setUsers(filteredUsers);
            }
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })
    const createGroupMutation = useMutation({
        mutationFn: createGroup,
        onSuccess: response => {
            toast.success('Group created successfully')
            setGroupName('')
            setSelectedUsers([])
            OnCreateGroup();
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })

    const getUserList = async () => {
        getUserMutation.mutate()

    }

    const handleCreateGroup = async () => {
        if (typeof user?.id === "number") {
            createGroupMutation.mutate({
                group_name: groupName,
                created_by: user.id,
                user_ids: selectedUsers.map((user) => user.id),
            });
        } else {
            console.error("User ID is undefined! Cannot create group.");
        }
    }

    return (
        <div>
            <Button
                size="icon"
                variant="outline"
                className="ml-auto rounded-full"
                onClick={() => setOpen(true)}
            >
                <Plus />
                <span className="sr-only">Create Group</span>
            </Button>
            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="gap-0 p-0 outline-none">
                    <DialogHeader className="px-4 pb-4 pt-5">
                        <DialogTitle>Create Group</DialogTitle>
                        <DialogDescription>
                            Enter Group Name and select members
                        </DialogDescription>
                        <Input placeholder='Enter Group Name' value={groupName} onChange={(event) => setGroupName(event.target.value)} />
                    </DialogHeader>
                    <Command className="overflow-hidden rounded-t-none border-t bg-transparent">
                        <CommandInput placeholder="Search user..." />
                        <CommandList>
                            <CommandEmpty>No users found.</CommandEmpty>
                            <CommandGroup className="p-2">
                                {users.length > 0 && users.map((user) => (
                                    <CommandItem
                                        key={user?.emailaddress}
                                        className="flex items-center px-2"
                                        onSelect={() => {
                                            if (selectedUsers.includes(user)) {
                                                return setSelectedUsers(
                                                    selectedUsers.filter(
                                                        (selectedUser) => selectedUser !== user
                                                    )
                                                )
                                            }

                                            return setSelectedUsers(
                                                [...users].filter((u) =>
                                                    [...selectedUsers, user].includes(u)
                                                )
                                            )
                                        }}
                                    >
                                        <Avatar>
                                            <AvatarImage src={user?.firstname?.slice(0, 2)} alt="Image" />
                                            <AvatarFallback>{user?.firstname?.slice(0, 2)}</AvatarFallback>
                                        </Avatar>
                                        <div className="ml-2">
                                            <p className="text-sm font-medium leading-none">
                                                {user?.firstname}
                                            </p>
                                            <p className="text-sm text-muted-foreground">
                                                {user?.emailaddress}
                                            </p>
                                        </div>
                                        {selectedUsers.includes(user) ? (
                                            <Check className="ml-auto flex h-5 w-5 text-primary" />
                                        ) : null}
                                    </CommandItem>
                                ))}
                            </CommandGroup>
                        </CommandList>
                    </Command>
                    <DialogFooter className="flex items-center border-t p-4 sm:justify-between">
                        {selectedUsers.length > 0 ? (
                            <div className="flex -space-x-2 overflow-hidden">
                                {selectedUsers?.slice(0, 8).map((user) => (
                                    <Avatar
                                        key={user.emailaddress}
                                        className="inline-block border-2 border-background"
                                    >
                                        <AvatarImage src={user?.userfullname} />
                                        <AvatarFallback>{user?.firstname.slice(0, 2)}</AvatarFallback>
                                    </Avatar>
                                ))}
                                {selectedUsers.length > 8 ? (
                                    <Avatar className="inline-block border-2 border-background">
                                        <AvatarFallback>+{selectedUsers.length - 8}</AvatarFallback>
                                    </Avatar>
                                ) : null}
                            </div>
                        ) : (
                            <p className="text-sm text-muted-foreground">
                                Select users to add to this group.
                            </p>
                        )}
                        <Button
                            disabled={selectedUsers.length < 2}
                            onClick={() => {
                                handleCreateGroup()
                                setOpen(false)
                            }}
                        >
                            Continue
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    )
}

export default AddGroup