import { useEffect, useState } from "react"
import { Check, PlusCircle } from "lucide-react"

import { cn } from "renderer/lib/utils"
import { Badge } from "renderer/components/ui/badge"
import { Button } from "renderer/components/ui/button"
import {
    Command,
    CommandEmpty,
    CommandGroup,
    CommandInput,
    CommandItem,
    CommandList,
    CommandSeparator,
} from "renderer/components/ui/command"
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "renderer/components/ui/popover"
import { Separator } from "renderer/components/ui/separator"
import { Avatar, AvatarImage } from "../ui/avatar"
import { AvatarFallback } from "@radix-ui/react-avatar"

interface DataTableFacetedFilterProps {
    title?: string;
    type: any;
    hasAvatar?: boolean;
    options: {
        label: string
        value: string
        icon?: React.ComponentType<{ className?: string }>
    }[];
    handleUpdateTaskField: any;
    taskFieldObj: any;
    onChange?: (selected: string[]) => void
}

export function FacetedFilter({
    title,
    options,
    hasAvatar,
    type,
    handleUpdateTaskField,
    taskFieldObj,
    onChange,
}: DataTableFacetedFilterProps) {
    const [selectedValues, setSelectedValues] = useState<Set<string>>(new Set())
    const [preSelectedValues, setPreSelectedValues] = useState(taskFieldObj?.[type])

    let idsString = '';
    const toggleValue = (value: string) => {
        const newSelected = new Set(selectedValues)
        if (newSelected.has(String(value))) {
            newSelected.delete(String(value))
        } else {
            newSelected.add(String(value))
        }
        setSelectedValues(newSelected)
        idsString = Array.from(newSelected).join(',');
        handleUpdateTaskField(idsString, taskFieldObj, type)
        onChange?.(Array.from(newSelected))
    }

    const clearAll = () => {
        setSelectedValues(new Set());
        onChange?.([]);
        handleUpdateTaskField("", taskFieldObj, type);
    }

    useEffect(() => {
        if (preSelectedValues) {
            const idsArray = preSelectedValues?.split(",").map((id: any) => id.trim())
            setSelectedValues(new Set(idsArray))
        }
    }, [preSelectedValues])


    useEffect(() => {
        setPreSelectedValues(taskFieldObj?.[type]);
    }, [taskFieldObj?.[type]])
    console.log("hasAvatar", type, hasAvatar, options)

    return (
        <Popover>
            <PopoverTrigger asChild>
                <Button variant="outline" className="border-dashed">
                    <PlusCircle />
                    {title}
                    {selectedValues.size > 0 && (
                        <>
                            <Separator orientation="vertical" className="mx-2 h-4" />
                            <Badge
                                variant="secondary"
                                className="rounded-sm px-1 font-normal lg:hidden"
                            >
                                {selectedValues.size}
                            </Badge>
                            <div className="hidden space-x-1 lg:flex">
                                {selectedValues.size > 2 ? (
                                    <Badge
                                        variant="secondary"
                                        className="rounded-sm px-1 font-normal"
                                    >
                                        {selectedValues.size} selected
                                    </Badge>
                                ) : (
                                    options
                                        .filter((option) => selectedValues.has(String(option.value)))
                                        .map((option) => (
                                            <Badge
                                                variant="secondary"
                                                key={option.value}
                                                className="rounded-sm px-1 font-normal"
                                            >
                                                {option.label}
                                            </Badge>
                                        ))
                                )}
                            </div>
                        </>
                    )}
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[200px] p-0" align="start">
                <Command>
                    <CommandInput placeholder={title} />
                    <CommandList>
                        <CommandEmpty>No results found.</CommandEmpty>
                        <CommandGroup>
                            {options?.map((option) => {
                                const isSelected = selectedValues.has(String(option.value));
                                return (
                                    <CommandItem
                                        key={option.value}
                                        onSelect={() => toggleValue(option.value)}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        <div
                                            className={cn(
                                                "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                                isSelected
                                                    ? "bg-primary text-primary-foreground"
                                                    : "opacity-50 [&_svg]:invisible"
                                            )}
                                        >
                                            <Check className="text-white" />
                                        </div>
                                        {option.icon && (
                                            <option.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                                        )}
                                        {/* {hasAvatar && (
                                            <Avatar className="mr-2 h-4 w-4">
                                                <AvatarImage src={option.label} alt="Image" />
                                                <AvatarFallback>{option.label?.slice(0, 2)}</AvatarFallback>
                                            </Avatar>
                                        )} */}
                                        <span>{option.label}</span>
                                    </CommandItem>
                                )
                            })}
                        </CommandGroup>
                        {selectedValues.size > 0 && (
                            <>
                                <CommandSeparator />
                                <CommandGroup>
                                    <CommandItem
                                        onSelect={clearAll}
                                        className="justify-center text-center cursor-pointer"
                                    >
                                        Clear filters
                                    </CommandItem>
                                </CommandGroup>
                            </>
                        )}
                    </CommandList>
                </Command>
            </PopoverContent>
        </Popover>
    )
}
