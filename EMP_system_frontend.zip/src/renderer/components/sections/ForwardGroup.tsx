import React, { useEffect } from 'react'
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '../ui/dialog'
import {
    Command,
    CommandEmpty,
    CommandGroup,
    CommandInput,
    CommandItem,
    CommandList,
} from '../ui/command'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'
import { Check } from 'lucide-react'
import { Button } from '../ui/button'
import { useMutation } from '@tanstack/react-query'
import { GetChatUser, GetGroup } from 'renderer/service/authService'
import { toast } from 'sonner'
import useAuthStore from 'renderer/store/AuthStore'
import { createGroupRoom, createRoom, forwardMessage, getToken } from 'renderer/service/connectServices'
import ChatController from 'renderer/Controller/ChatController'
import { useOutletContext } from 'react-router-dom'
import { useChatStore, usePageStore } from 'stores/useChatStore'


interface Userlist {
    user_id: string;
    id: string;
    firstname: string;
    lastname: string;
    email: string;
    phone: string;
    reporting_manager_name: string;
    date_of_joining: string;
    userfullname: string;
    isactive: boolean

}
type ChatOutletContext = {
    setActiveChat: (msg: any) => void;
    setActiveTab: (tab: any) => void;
};

const ForwardGroup = ({ msg_id, room, forwardSendMassage, openFun, OlduserSelect, chat_type }: any) => {
    const [open, setOpen] = React.useState(false)
    const ResUser = useAuthStore.getState().getUser();
    const useActiveoutlet = () => useOutletContext<ChatOutletContext>();
    const useActiveTaboutlet = () => useOutletContext<ChatOutletContext>();
    const { setActiveTab } = useActiveTaboutlet();
    const { setActiveChat } = useActiveoutlet();
    const { setSelectedToken, setChatInfo, setSelectGroup } = useChatStore();
    const { setPageCount } = usePageStore();
    const [users, setUsers] = React.useState<any[] | null>([])
    const [selectedUser, setSelectedUser] = React.useState<any | undefined>(null)
    const user = useAuthStore.getState().getUser()

    useEffect(() => {
        getUserList()
    }, [])

    const getUserMutation = useMutation({
        mutationFn: GetChatUser,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const filteredUsers = response.data.filter(
                    (u: { tbl_User: any }) => u?.tbl_User && u?.tbl_User?.id !== OlduserSelect?.id && u?.tbl_User?.id !== user?.id).map((user: any) => user?.tbl_User);
                setUsers(filteredUsers)
            }
        },
        onError: error => {
            toast.error('API Failed', {
                description: error.message,
            })
        },
    })

    const getGroupMutation = useMutation({
        mutationFn: GetGroup,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                setUsers((prevUsers) => [...(prevUsers || []), ...response.data]);
            }
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })

    const forwardMutation = useMutation({
        mutationFn: ({ fromUserId, toUserId }: { fromUserId: string, toUserId: string }) =>
            createRoom(fromUserId, toUserId),
        onSuccess: async response => {
            await forwardMessageMutation(response.chat.id, 'users')
            await setSelectGroup(null)
            await setActiveChat(selectedUser)
            openFun()
        },
        onError: error => {
            toast.error('API Failed', {
                description: error.message,
            })
        },
    })

    const groupMemberIds = selectedUser?.members?.map((member: any) => member.memberId) || [];
    const forwardGropMutation = useMutation({
        mutationFn: ({ groupId, groupMemberIds }: { groupMemberIds: string, groupId: string }) =>
            createGroupRoom(groupId, groupMemberIds),
        onSuccess: async (response, groupId) => {
            // await forwardMessageMutation(response.chat.id, 'users');
            const userDetails = {
                roomName: response.room.name,
                participantName: ResUser?.firstname,
                userId: ResUser?.id,
                metadata: JSON.stringify({
                    callerId: groupId,
                    callerName: ResUser?.firstname,
                }),
            };
            setPageCount(1);
            setSelectGroup(selectedUser);
            setChatInfo(selectedUser);
            const tokenRes = await getToken(
                userDetails.roomName,
                userDetails.participantName ?? '',
                userDetails.userId ?? '',
                userDetails.metadata
            );
            setSelectedToken(tokenRes.token);
            // setActiveGroup
            openFun();
            setSelectedUser(null);
        },

        onError: (error: Error) => {
            toast.error('API Failed', {
                description: error.message,
            });
        },
    });


    const forwardMessageMutation = async (chat_id: any, type: string) => {
        const response = await forwardMessage(user?.id, chat_id, msg_id)
        if (response.status) {
            sendMessage(chat_id)
        }
        await toast.success('Message forwarded successfully')
        if (type === 'users') {
            setActiveTab('users')
            setActiveChat(user?.id)
        }
        if (type === 'groups') {
            setActiveTab('groups')
            setActiveChat(user?.groupId)
        }
    }


    const getUserList = async () => {
        getUserMutation.mutate()
        getGroupMutation.mutate()
    }
    const sendMessage = async (chat_id: any) => {
        const ResUser = useAuthStore.getState().getUser();
        try {
            ChatController.callbackSocket('sendMessage', {
                receiverId: selectedUser.id,
                sender_Id: ResUser?.id,
                message: forwardSendMassage.text,
                name: ResUser?.firstname,
                isReply: false,
                isForward: true,
                chat_id: chat_id,
                chat_type: 'User',

            });
        } catch (error) {
            console.error("Failed to send message:", error);
        }
    };

    const handleForward = async () => {
        if (typeof user?.id === 'number' && selectedUser.id) {
            forwardMutation.mutate({
                fromUserId: user.id ?? ''.toString(),
                toUserId: selectedUser.id.toString(),
            })

        } else {
            forwardGropMutation.mutate({
                groupMemberIds: groupMemberIds,
                groupId: selectedUser.groupId,
            })
        }
    }


    return (
        <div>
            {/* biome-ignore lint/a11y/useKeyWithClickEvents: <explanation> */}
            <div onClick={() => setOpen(true)}>Forward</div>
            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent className="gap-0 p-0 outline-none">
                    <DialogHeader className="px-4 pb-4 pt-5">
                        <DialogTitle>Forward Message</DialogTitle>
                        <DialogDescription>
                            Select a user to forward the message to.
                        </DialogDescription>
                    </DialogHeader>
                    <Command className="overflow-hidden rounded-t-none border-t bg-transparent">
                        <CommandInput placeholder="Search user..." />
                        <CommandList>
                            <CommandEmpty>No users found.</CommandEmpty>
                            <CommandGroup className="p-2">
                                {users?.map((user) => (

                                    <CommandItem
                                        key={user.id}
                                        className="flex items-center px-2"
                                        onSelect={() => {
                                            if (
                                                (selectedUser?.id && selectedUser.id === user.id) ||
                                                (selectedUser?.groupId && selectedUser.groupId === user.groupId)
                                            ) {
                                                setSelectedUser(null);
                                            } else {
                                                setSelectedUser(user);
                                            }
                                        }}
                                    >
                                        <Avatar>
                                            <AvatarImage src={user.avatar} alt="Image" />
                                            <AvatarFallback>{user?.firstname?.[0] || user?.groupName?.[0] || 'U'}</AvatarFallback>

                                        </Avatar>
                                        <div className="ml-2">
                                            <p className="text-sm font-medium leading-none">
                                                {user.firstname || user.groupName}
                                            </p>
                                            <p className="text-sm text-muted-foreground">
                                                {user.email}
                                            </p>
                                        </div>
                                        {(selectedUser?.id && selectedUser.id === user.id) ||
                                            (selectedUser?.groupId && selectedUser.groupId === user.groupId) ? (
                                            <Check className="ml-auto flex h-5 w-5 text-primary" />
                                        ) : null}
                                    </CommandItem>
                                ))}
                            </CommandGroup>
                        </CommandList>
                    </Command>
                    <DialogFooter className="flex items-center border-t p-4 sm:justify-between">
                        {selectedUser ? (
                            <div className="flex -space-x-2 overflow-hidden">
                                <Avatar
                                    key={selectedUser.id}
                                    className="inline-block border-2 border-background"
                                >
                                    <AvatarImage src={selectedUser.avatar} />
                                    <AvatarFallback> {selectedUser.firstname?.[0] || selectedUser.groupName?.[0] || 'U'}</AvatarFallback>
                                </Avatar>
                            </div>
                        ) : (
                            <p className="text-sm text-muted-foreground">
                                Select a user to forward the message to.
                            </p>
                        )}
                        <Button
                            disabled={!selectedUser}
                            onClick={() => {
                                handleForward()
                                setOpen(false)
                            }}
                        >
                            Continue
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    )
}

export default ForwardGroup
