import React, { useEffect, useRef, useState } from 'react'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from 'renderer/components/ui/dialog'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from 'renderer/components/ui/command'
import { Avatar, AvatarFallback, AvatarImage } from 'renderer/components/ui/avatar'
import { Check, ChevronsUpDown, Loader2, Plus } from 'lucide-react'
import { Button } from 'renderer/components/ui/button'
import { Input } from 'renderer/components/ui/input'
import { useMutation, useQuery } from '@tanstack/react-query'
import { GetUser, createGroup } from 'renderer/service/authService'
import { toast } from 'sonner'
import useAuthStore from 'renderer/store/AuthStore'
import { useForm } from 'react-hook-form'
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from 'renderer/components/ui/form'
import DateTimePicker from 'renderer/components/ui/date-time-picker'
import RichText from 'renderer/components/ui/RichText'
import { RadioGroup, RadioGroupItem } from 'renderer/components/ui/radio-group'
import { Label } from 'renderer/components/ui/label'
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from 'renderer/components/ui/collapsible'
import { createMeetings, fetchMeetingList } from 'renderer/service/MeetingRoomService'
import dayjs from 'dayjs'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import ChatController from 'renderer/Controller/ChatController'

interface Userlist {
    user_id: string;
    id: string;
    firstname: string;
    lastname: string;
    emailaddress: string;
    phone: string;
    reporting_manager_name: string;
    date_of_joining: string;
    userfullname: string;
    chat_status: string;
    profileimg: string
}

interface meetingData {
    meeting_name: string;
    team_member: any;
    start_time: Date | null;
    end_time: Date | null;
    description: string;
}

type Participant = {
    user_id: number;
    [key: string]: any; // if other keys exist and you don't want to define them all
};


const CreateMeetingRoom = ({ OnCreateGroup }: any) => {
    const [open, setOpen] = React.useState(false)
    const [users, setUsers] = React.useState<Userlist[]>([])
    const [groupName, setGroupName] = React.useState('')
    const [selectedUsers, setSelectedUsers] = React.useState<Userlist[]>([])
    const [showMember, setShowMember] = useState<boolean>(false)
    const user = useAuthStore.getState().getUser();
    const [fetchOnSuccess, setFetchOnSuccess] = useState(false);
    const [startTime, setStartTime] = useState<any>(null);
    const [endTime, setEndTime] = useState<any>(null);
    const meetingNameRef = useRef<HTMLInputElement>(null); // Create a ref for the meeting name field

    const currentDate = new Date();
    const minStartDate = currentDate;
    const minEndDate = startTime ? new Date(startTime.getTime() + 10 * 60 * 1000) : currentDate

    const meetingSchema = z.object({
        meeting_name: z.string().min(1, 'Meeting name is required'),
        description: z.string().min(1, "Description is required"),
        team_member: z.array(z.any()).min(1, "Please select at least one member"),
        start_time: z.date().nullable(),
        end_time: z.date().nullable(),
        roomType: z.string(),
    }).superRefine((data, ctx) => {
        if (data.roomType === 'scheduled') {
            if (!data.start_time) {
                ctx.addIssue({
                    path: ['start_time'],
                    message: 'Start time is required for scheduled meeting',
                    code: z.ZodIssueCode.custom,
                });
            }

            if (!data.end_time) {
                ctx.addIssue({
                    path: ['end_time'],
                    message: 'End time is required for scheduled meeting',
                    code: z.ZodIssueCode.custom,
                });
            }
        }
    })

    // Form validation schema
    const form = useForm<z.infer<typeof meetingSchema>>({
        resolver: zodResolver(meetingSchema),
        defaultValues: {
            meeting_name: "",
            team_member: [],
            start_time: null,
            end_time: null,
            description: '',
            roomType: 'permanent'
        },
        mode: "onSubmit",
    })
    const roomType: any = form.watch("roomType");

    const createGroupMutation = useMutation({
        mutationFn: createGroup,
        onSuccess: response => {
            toast.success('Group created successfully')
            setGroupName('')
            setSelectedUsers([])
            OnCreateGroup();
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })

    const handleCreateGroup = async () => {
        if (typeof user?.id === "number") {
            createGroupMutation.mutate({
                group_name: groupName,
                created_by: user.id,
                user_ids: selectedUsers.map((user) => user.id),
            });
        } else {
            console.error("User ID is undefined! Cannot create group.");
        }
    }

    // Fetch Meeting List
    const { data: saveMeetingList } = useQuery({
        queryKey: ['meetingList'],
        queryFn: () => fetchMeetingList(),
        enabled: fetchOnSuccess
    });


    // Create Meeting
    const createMeetingMutation = useMutation({
        mutationFn: createMeetings,
        onSuccess: response => {
            const meeting = response?.data?.meeting;
            const participants: Participant[] = meeting?.participants || [];
            const userIds = participants.map((participant) => participant.user_id);
            toast.success('Meeting created successfully');
            handleCloseModal();
            setFetchOnSuccess(true);

            const Meeting = {
                Title: `This meeting has been created ${meeting?.meeting_name}`,
                Description: 'This is a team meeting scheduled for discussion.',
                userIds: userIds,
                create_by: user?.id,
            };
            console.log('Meeting Object:', Meeting);
            ChatController.callbackSocket('MeetingEvent', Meeting);
        },
        onError: error => {
            toast.error('Failed to create meeting')
        },
    })
    const onSubmit = (data: meetingData) => {
        createMeetingMutation.mutate({
            meeting_name: data?.meeting_name,
            team_member: data?.team_member?.map((item: any) => item?.id) || [],
            start_time: data.start_time ? dayjs(data.start_time).format('YYYY-MM-DD HH:mm:ss') : null,
            end_time: data.end_time ? dayjs(data.end_time).format('YYYY-MM-DD HH:mm:ss') : null,
            description: data?.description,
        })
    }

    // Fetch User List
    const getUserMutation = useMutation({
        mutationFn: GetUser,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const currentUserId = useAuthStore.getState().getUser()?.id;
                const filteredUsers = response.data.filter((user: Userlist) => user.id !== currentUserId)
                setUsers(filteredUsers);
            }
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })

    const getUserList = async () => {
        getUserMutation.mutate()
    }


    const handleCloseModal = () => {
        form.reset()  // This will reset the form values to their default state
        setOpen(false)
        setSelectedUsers([]);  // Reset selected users as well
        setStartTime(null); // Clear start time state
        setEndTime(null);   // Clear end time state
    }

    useEffect(() => {
        getUserList()
    }, [])

    const handleStartTimeChange = (value: Date | null) => {
        setStartTime(value)
        form.setValue('start_time', value);
        if (value) {
            setEndTime(null)
        }
    }

    const handleEndTimeChange = (value: Date | null) => {
        setEndTime(value);
        form.setValue('end_time', value);
    };

    const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>, fieldName: string) => {
        const target = event.target as HTMLInputElement;
        if (event.key === ' ' && target.selectionStart === 0) {
            event.preventDefault();
        }
    };

    useEffect(() => {
        if (roomType === 'permanent') {
            form.clearErrors(['start_time', 'end_time']); // Clear errors for start_time and end_time if permanent
        }

    }, [roomType]);

    useEffect(() => {
        if (open && meetingNameRef.current) {
            meetingNameRef.current.focus();

        }
    }, [open])

    return (
        <div>
            <Button
                size="icon"
                variant="outline"
                className="ml-auto rounded-full"
                onClick={() => setOpen(true)}
            >
                <Plus />
                <span className="sr-only">
                    Create Meeting Room
                </span>
            </Button>
            <Dialog open={open} onOpenChange={handleCloseModal}>
                <DialogContent className="gap-0 p-0 outline-none sm:max-w-[625px]">
                    <DialogHeader className="px-4 pb-4 pt-5">
                        <DialogTitle>
                            Create Meeting Room
                        </DialogTitle>
                        {/* <DialogDescription>
                            Enter Group Name and select members
                        </DialogDescription> */}
                    </DialogHeader>
                    <div className='p-4'>
                        <Form {...form}>
                            <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-2 gap-4">
                                <FormField
                                    control={form.control}
                                    name="meeting_name"
                                    render={({ field }) => (
                                        <FormItem className='col-span-2'>
                                            <FormLabel>
                                                Meeting Name <span className="text-red-500">*</span>
                                            </FormLabel>
                                            <FormControl>
                                                <Input
                                                    type="text"
                                                    placeholder="Enter your meeting room name"
                                                    {...field}
                                                    onKeyDown={(event) => handleKeyDown(event, 'meeting_name')}
                                                    ref={meetingNameRef}
                                                // disabled={loginMutation.isPending}
                                                />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <div className='col-span-2'>
                                    <Label className='mb-3'>Meeting Room Type {roomType === "scheduled" && <span className="text-red-500">*</span>}</Label>
                                    <RadioGroup value={roomType} onValueChange={(value) => form.setValue('roomType', value)} className='flex gap-4'>
                                        <div className="flex items-center space-x-2">
                                            <RadioGroupItem value="scheduled" id="r1" />
                                            <Label htmlFor="r1">Scheduled</Label>
                                        </div>
                                        <div className="flex items-center space-x-2">
                                            <RadioGroupItem value="permanent" id="r2" />
                                            <Label htmlFor="r2">Permanent</Label>
                                        </div>
                                    </RadioGroup>
                                </div>
                                {roomType === 'scheduled' &&
                                    <>
                                        <FormField
                                            control={form.control}
                                            name="start_time"
                                            // rules={{
                                            //     validate: validateEmail,
                                            // }}
                                            render={({ field }) => (
                                                <FormItem className='col-span-1'>
                                                    <FormLabel>
                                                        Start Time<span className="text-red-500">*</span>
                                                    </FormLabel>
                                                    <FormControl>
                                                        <DateTimePicker
                                                            value={startTime}
                                                            onChange={handleStartTimeChange}
                                                            minDate={minStartDate}
                                                            maxTime={new Date()}
                                                        />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                        <FormField
                                            control={form.control}
                                            name="end_time"
                                            // rules={{
                                            //     validate: validateEmail,
                                            // }}
                                            render={({ field }) => (
                                                <FormItem className='col-span-1'>
                                                    <FormLabel>
                                                        End Time<span className="text-red-500">*</span>
                                                    </FormLabel>
                                                    <FormControl>
                                                        <DateTimePicker
                                                            value={endTime}
                                                            onChange={handleEndTimeChange}
                                                            minDate={minEndDate} // Only allow end time after start time
                                                            disabled={!startTime} // Disable until start time is selected
                                                            minTime={startTime}
                                                        />
                                                    </FormControl>
                                                    <FormMessage />
                                                </FormItem>
                                            )}
                                        />
                                    </>
                                }
                                <FormField
                                    control={form.control}
                                    name="description"
                                    // rules={{
                                    //     validate: validateEmail,
                                    // }}
                                    render={({ field }) => (
                                        <FormItem className='col-span-2'>
                                            <FormLabel>
                                                Description<span className="text-red-500">*</span>
                                            </FormLabel>
                                            <FormControl>
                                                <RichText
                                                    value={field.value}
                                                    onChange={field.onChange}

                                                />
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="team_member"
                                    // rules={{
                                    //     validate: validateEmail,
                                    // }}
                                    render={({ field }) => (
                                        <FormItem className='col-span-2'>
                                            <FormLabel>
                                                Meeting Room Members<span className="text-red-500">*</span>
                                            </FormLabel>
                                            <FormControl>
                                                <Collapsible
                                                    open={showMember}
                                                    onOpenChange={setShowMember}
                                                    className="w-full    space-y-2"
                                                >
                                                    <CollapsibleTrigger asChild>
                                                        <div className="flex items-center justify-between space-x-4 pl-4 border rounded">
                                                            <h4 className="text-sm">
                                                                Select Room Members
                                                            </h4>
                                                            <Button variant="ghost" size="sm">
                                                                <ChevronsUpDown className="h-4 w-4" />
                                                                <span className="sr-only">Toggle</span>
                                                            </Button>
                                                        </div>
                                                    </CollapsibleTrigger>
                                                    <CollapsibleContent className="space-y-2">
                                                        <Command className="overflow-hidden rounded-t-none bg-transparent">
                                                            <CommandInput placeholder="Search user..." />
                                                            <CommandList>
                                                                <CommandEmpty>No users found.</CommandEmpty>
                                                                <CommandGroup className="p-2">
                                                                    {users?.map((user) => (
                                                                        <CommandItem
                                                                            key={user?.id}
                                                                            className="flex items-center px-2 !bg-transparent hover:!bg-accent cursor-pointer"
                                                                            onSelect={(v) => {
                                                                                const newSelctedUser = selectedUsers?.includes(user)
                                                                                    ? selectedUsers?.filter((selectedUser) => selectedUser !== user)
                                                                                    :
                                                                                    [...selectedUsers, user]

                                                                                setSelectedUsers(newSelctedUser)
                                                                                form.setValue('team_member', newSelctedUser)
                                                                                form.trigger('team_member');

                                                                            }}
                                                                        // value=''
                                                                        >
                                                                            <Avatar>
                                                                                <AvatarImage src={user?.profileimg || ''} alt="Image" />
                                                                                <AvatarFallback>{user.userfullname[0]}</AvatarFallback>
                                                                            </Avatar>
                                                                            <div className="ml-2">
                                                                                <p className="text-sm font-medium leading-none">
                                                                                    {user.userfullname}
                                                                                </p>
                                                                                <p className="text-sm text-muted-foreground">
                                                                                    {user.emailaddress}
                                                                                </p>
                                                                            </div>
                                                                            {selectedUsers.includes(user) ? (
                                                                                <Check className="ml-auto flex h-5 w-5 text-primary" />
                                                                            ) : null}
                                                                        </CommandItem>
                                                                    ))}
                                                                </CommandGroup>
                                                            </CommandList>
                                                        </Command>
                                                    </CollapsibleContent>
                                                </Collapsible>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                <Button type='submit' disabled={createMeetingMutation.isPending}>
                                    {
                                        createMeetingMutation?.isPending && (
                                            <Loader2 className="animate-spin" />
                                        )
                                    }
                                    Continue
                                </Button>
                            </form>
                        </Form>
                    </div>




                    {/* <Input placeholder='Enter Group Name' value={groupName} onChange={(event) => setGroupName(event.target.value)} /> */}




                    <DialogFooter className="flex items-center border-t p-4 sm:justify-between">
                        {selectedUsers?.length > 0 ? (
                            <div className="flex -space-x-2 overflow-hidden">
                                {selectedUsers?.map((user) => (
                                    <Avatar
                                        key={user.emailaddress}
                                        className="inline-block border-2 border-background"
                                    >
                                        <AvatarImage src={user?.profileimg} />
                                        <AvatarFallback>{user?.userfullname[0]}</AvatarFallback>
                                    </Avatar>
                                ))}
                            </div>
                        ) : (
                            <p className="text-sm text-muted-foreground">
                                Select users to add to this group.
                            </p>
                        )}

                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    )
}

export default CreateMeetingRoom