import type React from 'react';
import { useEffect, useState } from 'react';
import {
    DndContext,
    closestCenter,
    KeyboardSensor,
    PointerSensor,
    useSensor,
    useSensors,
    DragOverlay,
    type DragStartEvent,
    type DragEndEvent
} from '@dnd-kit/core';
import {
    SortableContext,
    verticalListSortingStrategy,
    useSortable,
} from '@dnd-kit/sortable';
import {
    restrictToVerticalAxis,
    restrictToParentElement
} from '@dnd-kit/modifiers';
import { Button } from 'renderer/components/ui/button';
import { ChevronRight, ChevronDown, Grip, Plus } from 'lucide-react';
import type { TaskRowTypes as Row } from 'Types/Tasks';
import { RenderRows } from './TaskRaw';
import { useMutation } from '@tanstack/react-query';
import { createTask, updateTaskOrderSerial } from 'renderer/service/project';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Input } from '../ui/input';

// === Utility Functions ===
const flattenRows = (rows: Row[]): Row[] =>
    rows?.flatMap(row => [row, ...flattenRows(row.children)]);

const findRowById = (rows: Row[], id: string): Row | null => {
    for (const row of rows) {
        if (row?.id === id) return row;
        const found = findRowById(row?.children, id);
        if (found) return found;
    }
    return null;
};

const findParentRow = (rows: Row[], id: string, parent: Row | null = null): Row | null => {
    for (const row of rows) {
        if (row?.id === id) return parent;
        const found = findParentRow(row?.children, id, row);
        if (found) return found;
    }
    return null;
};

const removeRowFromParent = (rows: Row[], id: string): Row[] =>
    rows?.map(row => ({
        ...row,
        children: row?.children?.some(child => child.id === id)
            ? row?.children?.filter(child => child.id !== id)
            : removeRowFromParent(row.children, id)
    }));

type HierarchicalTableProps = {
    taskData: Row[];
    heads: any;
    refetchTaskList: any;
    users: any,
    projectDetail?: any
};

// === Main Component ===
const HierarchicalTable: React.FC<HierarchicalTableProps> = ({ taskData, heads, refetchTaskList, users, projectDetail }) => {
    const [rows, setRows] = useState<Row[]>(taskData);
    const [expanded, setExpanded] = useState<string[]>(['1']);
    const [activeId, setActiveId] = useState<string | null>(null);
    const [subTaskAdd, setSubTaskAdd] = useState<any>({ val: '', isChecked: false });
    const [getNewTask, setNewTask] = useState('');

    const sensors = useSensors(
        useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
        useSensor(KeyboardSensor)
    );

    const toggleExpand = (id: string) => {
        setExpanded(prev => prev?.includes(id) ? prev?.filter(i => i !== id) : [...prev, id]);
    };

    const handleDragStart = (event: DragStartEvent) => {
        setActiveId(event.active.id as string);
    };

    const updateOrderSerialMutation = useMutation({
        mutationFn: updateTaskOrderSerial,
        onSuccess: () => {
            console.log('Order Updated=========');
        },
        onError: () => {
            console.log('Order Not Updated=========');
        }
    })

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;
        if (!over || active.id === over.id) return;

        const activeRow = findRowById(rows, active.id as string);
        const overRow = findRowById(rows, over.id as string);
        const activeParent = findParentRow(rows, active.id as string);
        const overParent = findParentRow(rows, over.id as string);
        if (!activeRow || !overRow) return;

        let newRows = [...rows];
        let updatedChildRows: any[] = [];

        if (activeParent) {
            newRows = removeRowFromParent(newRows, active.id as string);
        } else {
            newRows = newRows?.filter(r => r.id !== active.id);
        }

        if (overParent) {

            const insert = (r: Row[]): Row[] => r?.map(row => {
                if (row?.id === overParent.id) {
                    const idx = row?.children?.findIndex(child => child.id === over.id);
                    const updated = [...row?.children];
                    updatedChildRows = updated;
                    updated.splice(idx, 0, activeRow);
                    return { ...row, children: updated };
                }
                return { ...row, children: insert(row.children) };
            });
            newRows = insert(newRows);
        } else {
            const idx = newRows?.findIndex(row => row.id === over.id);
            newRows?.splice(idx + 1, 0, activeRow);
            // let idx = newRows.findIndex(row => row.id === over.id);
            // const draggedIndex = rows.findIndex(row => row.id === active.id);

            // If dragging downward, adjust index
            // if (draggedIndex < idx) {
            //     idx -= 1;
            // }

            // newRows.splice(idx + 1, 0, activeRow);
        }
        setRows(newRows);
        setActiveId(null);
        // console.log('updatedChildRowa======', updatedChildRows);

        const updatedTaskIds = overParent ? updatedChildRows?.map((item: any) => item?.id) : newRows?.map((item: any) => item?.id);
        updateOrderSerialMutation.mutate({ project_id: newRows[0]?.project_id, data: JSON.stringify(updatedTaskIds) });
    };

    const addItem = (parentId: any) => {
        const newId = `${Date.now()}`;
        const newItem: Row = {
            id: newId,
            name: 'New Item',
            status: {
                color: "#dc2626",
                label: 'Not Started',
                id: "1"
            },
            priority: {
                color: "#dc2626",
                label: 'High',
                id: "1"
            },
            children: []
        };

        if (parentId) {
            const insert = (r: Row[]): Row[] => r?.map(row => {
                if (row.id === parentId) {
                    return { ...row, children: [...row.children, newItem] };
                }
                return { ...row, children: insert(row.children) };
            });
            setRows(insert(rows));
            if (!expanded?.includes(parentId)) setExpanded([...expanded, parentId]);
        } else {
            setRows([...rows, newItem]);
        }
    };

    const flatRows = flattenRows(rows);
    const draggedRow = activeId ? findRowById(rows, activeId) : null;

    useEffect(() => {
        setRows(taskData);
    }, [taskData]);

    // Create task Mutation.
    const mutationCreateTask = useMutation({
        mutationFn: createTask,
        onSuccess: response => {
            if (response?.status == 1) {
                setNewTask('');
                setSubTaskAdd({ val: '', isChecked: false })
                refetchTaskList();
            }

        },
        onError: error => {
            console.log('error', error);
        }
    })

    // To find Maximum Serial Number.
    function findMaxSrNo(tasks: any) {
        let maxSrNo = -Infinity;
        function traverse(taskList: any) {
            for (const task of taskList) {
                if (typeof task.sr_no === 'number') {
                    maxSrNo = Math.max(maxSrNo, task.sr_no);
                }
                if (task.children && task.children.length > 0) {
                    traverse(task.children);
                }
            }
        }

        traverse(tasks);
        return maxSrNo + 1;
    }

    // To Create the Task.
    const handleCreateTask = (items: any) => {
        const srNumber = findMaxSrNo(items);
        if (getNewTask?.length) {
            mutationCreateTask.mutate({ project_id: items[0]?.project_id, sr_no: srNumber ? srNumber : 0, parent_id: subTaskAdd?.val ? subTaskAdd?.val : 0, task_name: getNewTask })
        }
        else {
            alert('Please enter the Task name')
        }
    }

    return (
        <div className="w-full overflow-hidden  rounded-lg">
            {/* <div className="bg-secondary p-4 flex items-center justify-between">
                <h2 className="text-lg font-semibold">Project Tasks</h2>
                <Button onClick={() => addItem(null)} size="sm">
                    Add Task
                </Button>
            </div> */}

            <div className="overflow-auto px-4 w-full">
                <div className="min-w-full w-max">
                    <DndContext
                        sensors={sensors}
                        collisionDetection={closestCenter}
                        onDragStart={handleDragStart}
                        onDragEnd={handleDragEnd}
                        modifiers={[restrictToVerticalAxis, restrictToParentElement]}
                    >
                        <SortableContext items={(flatRows ?? [])?.map(row => row.id)} strategy={verticalListSortingStrategy}>
                            <RenderRows
                                rows={rows}
                                level={0}
                                expanded={expanded}
                                toggleExpand={toggleExpand}
                                addItem={addItem}
                                heads={heads}
                                refetchTaskList={refetchTaskList}
                                setSubTaskAdd={setSubTaskAdd}
                                users={users}
                                projectDetail={projectDetail}
                            />
                        </SortableContext>

                        <DragOverlay>
                            {activeId && draggedRow && (
                                <div className=" shadow-lg border rounded p-2">
                                    <div className="flex items-center bg-background">
                                        <Grip className="h-4 w-4 mr-2" />
                                        <span>{draggedRow.name}</span>
                                    </div>
                                </div>
                            )}
                        </DragOverlay>
                    </DndContext>
                </div>
            </div>

            <Dialog open={subTaskAdd?.isChecked} onOpenChange={() => setSubTaskAdd({ val: '', isChecked: false })}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>
                            <h3>Add Sub Task</h3>
                        </DialogTitle>
                    </DialogHeader>
                    <Input placeholder='Add Task Name' onChange={(e) => setNewTask(e.target.value)}
                        onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
                            if (e.key === ' ' && getNewTask.length === 0) {
                                e.preventDefault();
                            }
                            if (e.key === 'Enter') {
                                e.preventDefault();
                                handleCreateTask(rows);
                            }
                        }}
                        value={getNewTask} />
                    <Button onClick={() => handleCreateTask(rows)}>Submit</Button>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default HierarchicalTable;
