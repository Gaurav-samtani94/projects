// import type React from 'react'
import React, { useEffect, useRef } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '../ui/dialog'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '../ui/command'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'
import { Check } from 'lucide-react'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { GetUser } from 'renderer/service/authService'
import { toast } from 'sonner'
import useAuthStore from 'renderer/store/AuthStore'
import { Link, useNavigate } from 'react-router-dom'
import { projectCreate } from 'renderer/service/project'
import { DialogTrigger } from '@radix-ui/react-dialog'
import { useVirtualizer } from '@tanstack/react-virtual'
import ChatController from 'renderer/Controller/ChatController'

interface Userlist {
    user_id: string;
    id: string;
    firstname: string;
    lastname: string;
    email: string;
    phone: string;
    reporting_manager_name: string;
    date_of_joining: string;
    userfullname: string;
    chat_status: string
}

const AddProjectModal = ({
    children,
    refetch
}: {
    children?: React.ReactNode
    refetch?: any
}) => {
    const [open, setOpen] = React.useState(false)
    const [users, setUsers] = React.useState<any[]>([])
    const [projectName, setProjectName] = React.useState('')
    const [selectedUsers, setSelectedUsers] = React.useState<any[]>([])
    const user = useAuthStore.getState().getUser();
    const navigate = useNavigate();
    const queryClient = useQueryClient();

    // Mutations definition...
    const getUserMutation = useMutation({
        mutationFn: GetUser,
        onSuccess: response => {
            if (response?.data?.length > 0) {
                const currentUserId = useAuthStore.getState().getUser()?.id;
                const filteredUsers = response.data.filter((user: Userlist) => user.id !== currentUserId)
                setUsers(filteredUsers);
            }
        },
        onError: error => {
            toast.error('api Failed', {
                description: error.message,
            })
        },
    })

    const createProjectMutation = useMutation({
        mutationFn: projectCreate,
        onSuccess: (response, variable) => {

            ChatController.callbackSocket('project', {
                user_ids: variable?.user_ids,
                project_id: response?.data?.id,
                is_project: 'create',
                created_by: user?.id
            });

            toast.success('Project created successfully')
            setProjectName('')
            setSelectedUsers([])
            setOpen(false);
            setTimeout(() => {
                queryClient.invalidateQueries({ queryKey: ['projectList'] });
            }, 300);
            const newProject = response?.data;
            if (newProject?.id) {
                navigate(`/project/${newProject.id}`, {
                    state: { projectDetails: newProject }
                });
            }
        },
        onError: (error: any) => {
            console.log('errorrrrrrrrrrrrrrrrrrrrrr', error);

            toast.error('Project creation failed', {
                description: error?.response?.data?.message || 'Some thing went wrong',
            })
        },
    })

    // Functions...
    const handleProjectCreate = async () => {
        const userIds = selectedUsers.map((user) => user)?.join(',');
        if (typeof user?.id === "number") {
            createProjectMutation.mutate({
                project_name: projectName,
                user_ids: userIds,
            });
        } else {
            console.error("User ID is undefined! Cannot create project.");
        }
    }

    const getUserList = async () => {
        getUserMutation.mutate()

    }

    //Hooks...
    useEffect(() => {
        getUserList()
    }, [])

    useEffect(() => {
        let timeoutId = setTimeout(() => {
            rowVirtualizer.measure();
        }, 100);
        return () => clearTimeout(timeoutId)
    }, [open]);

    const [searchQuery, setSearchQuery] = React.useState('');

    const filteredUsers = React.useMemo(() => {
        return users.filter(
            (user) =>
                user.userfullname &&
                user.userfullname.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [searchQuery, users]);

    const parentRef = useRef(null);

    const rowVirtualizer = useVirtualizer({
        count: filteredUsers.length,
        getScrollElement: () => parentRef.current,
        estimateSize: () => 60,
        // overscan: 10,
    });

    return (
        <div>
            <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild>
                    {children
                        ? children
                        : <Button
                            className='p-6 text-lg rounded-xl'
                            onClick={() => setOpen(true)}
                        >
                            Create Your First Project
                        </Button>
                    }
                </DialogTrigger>
                <DialogContent className="gap-0 p-0 outline-none">
                    <DialogHeader className="px-4 pb-4 pt-5">
                        <DialogTitle>Create Project</DialogTitle>
                        <DialogDescription>
                            Enter Project Name
                        </DialogDescription>
                        <Input placeholder='Enter Project Name' value={projectName} onChange={(event) => setProjectName(event.target.value)} />
                    </DialogHeader>
                    <Command className="overflow-hidden rounded-t-none border-t bg-transparent">
                        <Input
                            placeholder="Search user..."
                            className='border-none outline-none border-b focus:outline-none rounded-none'
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                        <CommandList style={{ height: '300px', overflow: 'auto', position: 'relative' }}>
                            {filteredUsers?.length === 0 ? (
                                <CommandEmpty>No users found.</CommandEmpty>
                            ) : (
                                <div
                                    ref={parentRef}
                                    style={{ height: '300px', overflow: 'auto', position: 'relative' }}
                                    className="border-t bg-background"
                                >
                                    <div
                                        style={{
                                            height: rowVirtualizer.getTotalSize(),
                                            position: 'relative',
                                        }}
                                    >
                                        {rowVirtualizer.getVirtualItems().map((virtualRow) => {
                                            const user = filteredUsers[virtualRow.index];
                                            if (!user) return null;

                                            return (
                                                <CommandItem
                                                    key={user.email}
                                                    style={{
                                                        transform: `translateY(${virtualRow.start}px)`,
                                                        position: 'absolute',
                                                        top: 0,
                                                        left: 0,
                                                        width: '100%',
                                                        height: `${virtualRow.size}px`,
                                                        cursor: 'pointer'
                                                    }}
                                                    className="flex items-center px-2"
                                                    onSelect={() => {
                                                        if (selectedUsers.includes(user?.id)) {
                                                            setSelectedUsers(
                                                                selectedUsers.filter((selectedUser) => selectedUser !== user?.id)
                                                            );
                                                        } else {
                                                            setSelectedUsers([...selectedUsers, user?.id]);
                                                        }
                                                    }}
                                                >
                                                    <Avatar>
                                                        <AvatarImage src={user.avatar} alt="Image" />
                                                        <AvatarFallback>{user?.firstname?.[0]}</AvatarFallback>
                                                    </Avatar>
                                                    <div className="ml-2">
                                                        <p className="text-sm font-medium leading-none">{user.firstname}</p>
                                                        <p className="text-sm text-muted-foreground">{user.emailaddress}</p>
                                                    </div>
                                                    {selectedUsers.includes(user?.id) && (
                                                        <Check className="ml-auto flex h-5 w-5 text-primary" />
                                                    )}
                                                </CommandItem>
                                            );
                                        })}
                                    </div>
                                </div>
                            )}
                        </CommandList>
                    </Command>
                    <DialogFooter className="flex items-center border-t p-4 sm:justify-between">
                        {selectedUsers?.length > 0 ? (
                            <div className="flex -space-x-2 overflow-hidden">
                                {selectedUsers?.slice(0, 8)?.map((user) => {
                                    const member = users?.find((item: any) => item.id == user);
                                    if (!member) return null;
                                    return (
                                        <Avatar
                                            key={member.email}
                                            className="inline-block border-2 border-background"
                                        >
                                            <AvatarImage src="" alt="@shadcn" />
                                            <AvatarFallback>{member.firstname[0]}</AvatarFallback>
                                        </Avatar>

                                    )

                                })}
                                {selectedUsers?.length > 8 && (
                                    <Avatar className="inline-block border-2 border-background">
                                        <AvatarFallback>+{selectedUsers?.length - 8}</AvatarFallback>
                                    </Avatar>
                                )}
                            </div>
                        ) : (
                            <p className="text-sm text-muted-foreground">
                                Select users to add to this project.
                            </p>
                        )}
                        <Button
                            disabled={selectedUsers.length === 0 || !projectName}
                            onClick={() => handleProjectCreate()}
                        >
                            Create
                        </Button>

                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    )
}

export default AddProjectModal