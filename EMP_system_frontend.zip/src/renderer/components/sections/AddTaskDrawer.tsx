import React, { useEffect, useMemo, useState, type ReactNode } from 'react'
import { Drawer, DrawerClose, DrawerContent, DrawerDescription, DrawerFooter, DrawerHeader, DrawerTitle, DrawerTrigger } from '../ui/drawer'
import { Button } from '../ui/button'
import { Bug, CalendarIcon, Check, CheckSquare, ChevronsUpDown, Plus, PlusCircle, Sparkles } from 'lucide-react'
import { Form, FormControl, FormItem, FormField, FormLabel, FormMessage } from '../ui/form'
import { useForm } from 'react-hook-form'
import { Input } from '../ui/input'
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover'
import { Calendar } from '../ui/calendar'
import { cn } from "../../lib/utils"
import { format } from "date-fns"
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from '../ui/select'
import { ScrollArea } from '../ui/scroll-area'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'
import {
    Command,
    CommandEmpty,
    CommandGroup,
    CommandInput,
    CommandItem,
    CommandList,
    CommandSeparator,
} from "../ui/command";
import RichText from '../ui/RichText'
import CommentBox from './CommentBox'
import { Separator } from '../ui/separator'
import { useMutation } from '@tanstack/react-query'
import { updateTask } from 'renderer/service/project'
import { FacetedFilter } from './FactedFilter'
import { Badge } from '../ui/badge'
import { Checkbox } from '../ui/checkbox'
import { toast } from "sonner";


const assignees = [
    {
        label: "Mansi Gupta",
        value: "mansi",
        image:
            "https://images.unsplash.com/photo-1743674445265-b311b0ba8118?w=600&auto=format&fit=crop&q=60",
    },
    {
        label: "Krishna Soni",
        value: "krishna",
        image: "https://images.unsplash.com/photo-1743378905365-1629c70d089a?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDh8dG93SlpGc2twR2d8fGVufDB8fHx8fA%3D%3D",
    },
    {
        label: "Ashif Ali",
        value: "ashif",
        image: "https://images.unsplash.com/photo-1742210595290-f021aba0d9f2?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDE5fHRvd0paRnNrcEdnfHxlbnwwfHx8fHw%3D",
    },
];

const assignedList = [
    {
        value: "rahul",
        label: "Rahul Sir",
        avatar: "https://plus.unsplash.com/premium_photo-1689568126014-06fea9d5d341?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D",
    },
    {
        value: "krishna",
        label: "Krishna Soni",
        avatar: "https://plus.unsplash.com/premium_photo-1689568126014-06fea9d5d341?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D",
    },
    {
        value: "ashif",
        label: "Ashif Ali",
        avatar: "https://plus.unsplash.com/premium_photo-1689568126014-06fea9d5d341?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D",
    },
];

const createdByList = [
    { value: "rahul", label: "Rahul Sir", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fHByb2ZpbGV8ZW58MHx8MHx8fDA%3D" },
    { value: "krishna", label: "Krishna Soni", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fHByb2ZpbGV8ZW58MHx8MHx8fDA%3D" },
    { value: "ashif", label: "Ashif Ali", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fHByb2ZpbGV8ZW58MHx8MHx8fDA%3D" },
];

const reviewByList = [
    { value: "rahul", label: "Rahul Sir", avatar: "https://plus.unsplash.com/premium_photo-1690407617542-2f210cf20d7e?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D" },
    { value: "krishna", label: "Krishna Soni", avatar: "https://plus.unsplash.com/premium_photo-1690407617542-2f210cf20d7e?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D" },
    { value: "ashif", label: "Ashif Ali", avatar: "https://plus.unsplash.com/premium_photo-1690407617542-2f210cf20d7e?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D" },
];

const qaList = [
    { value: "rahul", label: "Rahul Sir", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D" },
    { value: "krishna", label: "Krishna Soni", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D" },
    { value: "ashif", label: "Ashif Ali", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D" },
];

const AddTaskDrawer = ({ children, getData, refetchTaskList, users, projectDetail,
}: {
    children: React.ReactNode;
    getData: () => { row: any; heads: any };
    refetchTaskList: any
    users: any,
    projectDetail?: any
}) => {
    const [open, setOpen] = useState(false);
    const [taskData, setTaskData] = React.useState<{ row: any; heads: any } | null>(null);
    const [date, setDate] = React.useState<Date>()
    const [taskName, setTaskName] = React.useState<any>('')
    const [getDescription, setDescription] = useState<any>('');
    const [getDescriptionData, setDescriptionData] = useState<any>('');

    const form = useForm({ defaultValues: {} });

    useEffect(() => {
        if (open) {
            const fetchedData = getData();
            setTaskData(fetchedData);
        }
    }, [open])

    // To show the value of each colomn
    const showValues = (row: any, heads: any) => {
        const values: any = {};
        const data: any = {};

        heads?.forEach((head: any) => {
            const field = row.task_fields.find((f: any) => f.type_key_id === head.id);
            // console.log('head.config_detailhead.config_detailhead.config_detail', head.config_detail);

            if (!field) return;

            switch (head.config_detail) {

                case 'text_val':
                    if (head?.label_name === 'Name') {
                        setTaskName(field.text_val)
                    }
                    values[head.label_name] = field.text_val || '';

                    break;

                case 'select_val':
                    values[head.label_name] = field.select_val || '';
                    break;

                case 'multi_select_val':
                    values[head.label_name] = field.multi_select_val || '';
                    break;

                case 'date_val':
                    values[head.label_name] = field.date_val ? new Date(field.date_val) : null;
                    break;

                case 'number_val':
                    values[head.label_name] = field.number_val || 0;
                    break;

                case 'person_val':
                    values[head.label_name] = field.person_val || '';
                    break;

                case 'attachment_val':
                    values[head.label_name] = field.attachment_val || null;
                    break;

                case 'url_val':
                    values[head.label_name] = field.url_val || '';
                    break;

                case 'relation_val':
                    values[head.label_name] = field?.relation_val || '';
                    break;

                case 'checkbox_val':
                    values[head.label_name] = field?.checkbox_val || '';
                    break;
                case 'rich_text':
                    values[head.label_name] = field?.rich_text || '';
                    setDescriptionData(field)
                    break;
                case 'created_at_val':
                    values[head.label_name] = field?.created_at_val || '';
                    break;
                case 'created_by_val':
                    values[head.label_name] = field?.created_by_val
                        || '';
                    break;
                case 'updated_at_val':
                    values[head.label_name] = field?.updated_at_val || '';
                    break;
                case 'updated_by_val':
                    values[head.label_name] = field?.updated_by_val || '';
                    break;

                case 'estimated_val':
                    values[head.label_name] = field?.estimated_val || '';
                    break;

                default:
                    values[head.label_name] = '';
                    break;
            }
        });
        // console.log('values----175=======', values);

        return values;
    };

    // Dropdown Options for Select / Multi-Select; 
    const selectOptionsMap = useMemo(() => {
        const map: Record<string, any[]> = {};

        taskData?.heads?.forEach((head: any) => {
            if (head.config_detail === 'select_val') {
                const field = taskData?.row?.task_fields?.find((f: any) => f.type_key_id === head.id);
                if (field) {
                    map[head.label_name] = field?.single_select || [];
                }
            }
            else if (head.config_detail === 'relation_val' || head.config_detail === 'multi_select_val' || head.config_detail === 'person_val') {
                const field = taskData?.row?.task_fields?.find((f: any) => f.type_key_id === head.id);
                if (field) {
                    map[head.label_name] = field?.multi_select || [];
                }
            }


        });

        return map;
    }, [taskData?.row, taskData?.heads]);

    // Rendering of Colomns
    const renderDynamicField = (head: any, fieldValue: any, form: any) => {
        const name = head.label_name;

        switch (head.config_detail) {
            case 'text_val':
                return (
                    <FormField
                        key={head.id}
                        control={form.control}
                        name={name}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{head.label_name}</FormLabel>
                                <FormControl>
                                    <Input placeholder={`Enter ${head.label_name}`} {...field} className='w-full' />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                );

            case 'select_val':
                return (
                    <FormField
                        key={head.id}
                        control={form.control}
                        name={name}
                        render={({ field }) => {
                            const options = selectOptionsMap[head.label_name] || [];
                            return (
                                <FormItem>
                                    <FormLabel>{head.label_name}</FormLabel>
                                    <Select
                                        value={field.value?.toString()}
                                        onValueChange={(selectedId) => field.onChange(selectedId)}
                                    >
                                        <SelectTrigger className="w-full">
                                            <SelectValue placeholder={`Select ${head.label_name}`} />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectGroup>
                                                {options?.map((opt: any) => (
                                                    <SelectItem key={opt.id} value={opt.id.toString()}>
                                                        {opt.option_name}
                                                    </SelectItem>
                                                ))}
                                            </SelectGroup>
                                        </SelectContent>
                                    </Select>
                                </FormItem>
                            )
                        }}
                    />
                );

            case 'date_val':
                return (
                    <FormField
                        key={head.id}
                        control={form.control}
                        name={name}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{head.label_name}</FormLabel>
                                <Popover>
                                    <PopoverTrigger asChild>
                                        <Button variant="outline" className="w-full text-left">
                                            <CalendarIcon className="mr-2 h-4 w-4" />
                                            {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                        </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-0">
                                        <Calendar
                                            mode="single"
                                            selected={field.value}
                                            onSelect={field.onChange}
                                            initialFocus
                                        />
                                    </PopoverContent>
                                </Popover>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                );

            case 'number_val':
                return (
                    <FormField
                        key={head.id}
                        control={form.control}
                        name={name}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{head.label_name}</FormLabel>
                                <FormControl>
                                    <Input placeholder={`Enter ${head.label_name}`} {...field} className='w-full' />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                );

            case 'relation_val':
                return (
                    <FormField
                        key={head.id}
                        control={form.control}
                        name={name}
                        render={({ field }) => {
                            const options = selectOptionsMap[head.label_name]?.map((item: any) => {
                                return { value: item.id, label: item?.task_name }
                            }) || [];
                            const selectedValues = new Set(
                                Array.isArray(field.value)
                                    ? field.value.map(String)
                                    : String(field.value).split(',').filter(Boolean)
                            );
                            const toggleValue = (val: string) => {
                                const updated = new Set(Array.from(selectedValues));
                                if (updated.has(val)) {
                                    updated.delete(val);
                                } else {
                                    updated.add(val);
                                }
                                field.onChange(Array.from(updated));
                            };


                            const clearAll = () => field.onChange([]);

                            return (
                                <FormItem>
                                    <FormLabel>{head.label_name}</FormLabel>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button variant="outline" className="border-dashed w-full justify-start">
                                                <PlusCircle className="mr-2 h-4 w-4" />
                                                {selectedValues.size > 0 ? (
                                                    <div className="flex gap-1 flex-wrap">
                                                        {selectedValues.size > 2 ? (
                                                            <Badge variant="secondary" className="rounded-sm px-1 font-normal">
                                                                {selectedValues.size} selected
                                                            </Badge>
                                                        ) : (
                                                            options
                                                                .filter((opt: any) => selectedValues.has(String(opt.value)))
                                                                .map((opt: any) => (
                                                                    <Badge key={opt.value} variant="secondary" className="rounded-sm px-1 font-normal">
                                                                        {opt.label}
                                                                    </Badge>
                                                                ))
                                                        )}
                                                    </div>
                                                ) : (
                                                    <span>Select {head.label_name}</span>
                                                )}
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-[250px] p-0" align="start">
                                            <Command>
                                                <CommandInput placeholder={`Search ${head.label_name}`} />
                                                <CommandList>
                                                    <CommandEmpty>No results found.</CommandEmpty>
                                                    <CommandGroup>
                                                        {options?.map((opt: any) => {
                                                            const isSelected = selectedValues?.has(String(opt.value));
                                                            return (
                                                                <CommandItem key={opt.value} onSelect={() => toggleValue(opt.value)}>
                                                                    <div
                                                                        className={cn(
                                                                            "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                                                            isSelected
                                                                                ? "bg-primary text-primary-foreground"
                                                                                : "opacity-50 [&_svg]:invisible"
                                                                        )}
                                                                    >
                                                                        <Check className="h-4 w-4 text-white" />
                                                                    </div>
                                                                    {opt.icon && (
                                                                        <opt.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                                                                    )}
                                                                    <span>{opt.label}</span>
                                                                </CommandItem>
                                                            );
                                                        })}
                                                    </CommandGroup>
                                                    {selectedValues?.size > 0 && (
                                                        <>
                                                            <CommandSeparator />
                                                            <CommandGroup>
                                                                <CommandItem onSelect={clearAll} className="justify-center text-center">
                                                                    Clear all
                                                                </CommandItem>
                                                            </CommandGroup>
                                                        </>
                                                    )}
                                                </CommandList>
                                            </Command>
                                        </PopoverContent>
                                    </Popover>
                                    <FormMessage />
                                </FormItem>
                            );
                        }}
                    />
                );

            case 'checkbox_val':
                return (
                    <FormField
                        key={head.id}
                        control={form.control}
                        name={name}
                        render={({ field }) => (
                            <FormItem className="flex flex-row items-center space-x-3 space-y-0 p-2">
                                <FormControl>
                                    <Checkbox
                                        checked={field.value === 1}
                                        onCheckedChange={(checked) => field.onChange(checked ? 1 : 0)}
                                    />
                                </FormControl>
                                <FormLabel className="text-sm font-medium">
                                    {head.label_name}
                                </FormLabel>
                            </FormItem>
                        )}
                    />
                );

            case 'person_val':
                return (
                    <FormField
                        key={head.id}
                        control={form.control}
                        name={name}
                        render={({ field }) => {
                            const options = selectOptionsMap[head.label_name]?.map((item: any) => {
                                return { value: item.id, label: item?.userfullname }
                            }) || [];
                            const selectedValues = new Set(
                                Array.isArray(field.value)
                                    ? field.value.map(String)
                                    : String(field.value).split(',').filter(Boolean)
                            );
                            const toggleValue = (val: string) => {

                                const updated = new Set(Array.from(selectedValues));
                                if (updated.has(String(val))) {
                                    updated.delete(String(val));
                                } else {
                                    updated.add(String(val));
                                }
                                field.onChange(Array.from(updated));
                            };


                            const clearAll = () => field.onChange([]);

                            return (
                                <FormItem>
                                    <FormLabel>{head.label_name}</FormLabel>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button variant="outline" className="border-dashed w-full justify-start">
                                                <PlusCircle className="mr-2 h-4 w-4" />
                                                {selectedValues.size > 0 ? (
                                                    <div className="flex gap-1 flex-wrap">
                                                        {selectedValues.size > 2 ? (
                                                            <Badge variant="secondary" className="rounded-sm px-1 font-normal">
                                                                {selectedValues.size} selected
                                                            </Badge>
                                                        ) : (
                                                            options
                                                                .filter((opt: any) => selectedValues.has(String(opt.value)))
                                                                .map((opt: any) => (
                                                                    <Badge key={opt.value} variant="secondary" className="rounded-sm px-1 font-normal">
                                                                        {opt.label}
                                                                    </Badge>
                                                                ))
                                                        )}
                                                    </div>
                                                ) : (
                                                    <span>Select {head.label_name}</span>
                                                )}
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-[250px] p-0" align="start">
                                            <Command>
                                                <CommandInput placeholder={`Search ${head.label_name}`} />
                                                <CommandList>
                                                    <CommandEmpty>No results found.</CommandEmpty>
                                                    <CommandGroup>
                                                        {options?.map((opt: any) => {
                                                            const isSelected = selectedValues?.has(String(opt.value));
                                                            return (
                                                                <CommandItem key={opt.value} onSelect={() => toggleValue(opt.value)}>
                                                                    <div
                                                                        className={cn(
                                                                            "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                                                            isSelected
                                                                                ? "bg-primary text-primary-foreground"
                                                                                : "opacity-50 [&_svg]:invisible"
                                                                        )}
                                                                    >
                                                                        <Check className="h-4 w-4 text-white" />
                                                                    </div>
                                                                    {opt.icon && (
                                                                        <opt.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                                                                    )}
                                                                    <span>{opt.label}</span>
                                                                </CommandItem>
                                                            );
                                                        })}
                                                    </CommandGroup>
                                                    {selectedValues?.size > 0 && (
                                                        <>
                                                            <CommandSeparator />
                                                            <CommandGroup>
                                                                <CommandItem onSelect={clearAll} className="justify-center text-center">
                                                                    Clear all
                                                                </CommandItem>
                                                            </CommandGroup>
                                                        </>
                                                    )}
                                                </CommandList>
                                            </Command>
                                        </PopoverContent>
                                    </Popover>
                                    <FormMessage />
                                </FormItem>
                            );
                        }}
                    />
                );

            case 'estimated_val':
                return (
                    <FormField
                        key={head.id}
                        control={form.control}
                        name={name}
                        rules={{
                            validate: (value) => {
                                const pattern = /^(\d+[wW])?(\s*\d+[dD])?(\s*\d+[hH])?$/;
                                return (
                                    value === '' || pattern.test(value.trim()) || "Invalid format. Use like: 4w 5d 6h"
                                );
                            },
                        }}
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{head.label_name}</FormLabel>
                                <FormControl>
                                    <Input placeholder={`Enter ${head.label_name}`} {...field} className='w-full' />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                );

            case 'multi_select_val':
                return (
                    <FormField
                        key={head.id}
                        control={form.control}
                        name={name}
                        render={({ field }) => {
                            const options = selectOptionsMap[head.label_name]?.map((item: any) => {
                                return { value: item.id, label: item?.option_name }
                            }) || [];
                            const selectedValues = new Set(
                                Array.isArray(field.value)
                                    ? field.value.map(String)
                                    : String(field.value).split(',').filter(Boolean)
                            );
                            const toggleValue = (val: string) => {
                                const updated = new Set(Array.from(selectedValues));
                                if (updated.has(String(val))) {
                                    updated.delete(String(val));
                                } else {
                                    updated.add(String(val));
                                }
                                field.onChange(Array.from(updated));
                            };


                            const clearAll = () => field.onChange([]);

                            return (
                                <FormItem>
                                    <FormLabel>{head.label_name}</FormLabel>
                                    <Popover>
                                        <PopoverTrigger asChild>
                                            <Button variant="outline" className="border-dashed w-full justify-start">
                                                <PlusCircle className="mr-2 h-4 w-4" />
                                                {selectedValues.size > 0 ? (
                                                    <div className="flex gap-1 flex-wrap">
                                                        {selectedValues.size > 2 ? (
                                                            <Badge variant="secondary" className="rounded-sm px-1 font-normal">
                                                                {selectedValues.size} selected
                                                            </Badge>
                                                        ) : (
                                                            options
                                                                .filter((opt: any) => selectedValues.has(String(opt.value)))
                                                                .map((opt: any) => (
                                                                    <Badge key={opt.value} variant="secondary" className="rounded-sm px-1 font-normal">
                                                                        {opt.label}
                                                                    </Badge>
                                                                ))
                                                        )}
                                                    </div>
                                                ) : (
                                                    <span>Select {head.label_name}</span>
                                                )}
                                            </Button>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-[250px] p-0" align="start">
                                            <Command>
                                                <CommandInput placeholder={`Search ${head.label_name}`} />
                                                <CommandList>
                                                    <CommandEmpty>No results found.</CommandEmpty>
                                                    <CommandGroup>
                                                        {options?.map((opt: any) => {
                                                            const isSelected = selectedValues?.has(String(opt.value));
                                                            return (
                                                                <CommandItem key={opt.value} onSelect={() => toggleValue(opt.value)}>
                                                                    <div
                                                                        className={cn(
                                                                            "mr-2 flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                                                            isSelected
                                                                                ? "bg-primary text-primary-foreground"
                                                                                : "opacity-50 [&_svg]:invisible"
                                                                        )}
                                                                    >
                                                                        <Check className="h-4 w-4 text-white" />
                                                                    </div>
                                                                    {opt.icon && (
                                                                        <opt.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                                                                    )}
                                                                    <span>{opt.label}</span>
                                                                </CommandItem>
                                                            );
                                                        })}
                                                    </CommandGroup>
                                                    {selectedValues?.size > 0 && (
                                                        <>
                                                            <CommandSeparator />
                                                            <CommandGroup>
                                                                <CommandItem onSelect={clearAll} className="justify-center text-center">
                                                                    Clear all
                                                                </CommandItem>
                                                            </CommandGroup>
                                                        </>
                                                    )}
                                                </CommandList>
                                            </Command>
                                        </PopoverContent>
                                    </Popover>
                                    <FormMessage />
                                </FormItem>
                            );
                        }}
                    />
                );


            default:
                return null;
        }
    };

    // To set the form fields value.
    useEffect(() => {
        if (taskData?.row && taskData?.heads && open) {
            const values = showValues(taskData.row, taskData.heads);
            form.reset(values);
            setDescription(values?.Description)
        }
    }, [taskData?.row, taskData?.heads, open]);

    const mutationUpdateTask = useMutation({
        mutationFn: updateTask,
        onSuccess: (res) => {
            // console.log('res===============', res);

            setOpen(false);
            refetchTaskList();
            toast.success(res?.message)
        },
        onError: (error) => {
            console.error('Update failed:', error);
        },
    });

    function onSubmit() {
        form.handleSubmit((formData: any) => {
            let payload = taskData?.heads?.map((head: any) => {

                const formValue = formData[head.label_name];
                const taskField = taskData?.row?.task_fields?.find((f: any) => f.type_key_id === head.id);
                if (!taskField) return null;
                return {
                    id: taskField.id,
                    value: Array.isArray(formValue) ? formValue.join(',') : String(formValue ?? ''),
                };
            }).filter(Boolean); // remove nulls        

            payload = payload?.map((item: any) =>
                item.id == getDescriptionData?.id
                    ? { ...item, value: getDescription || '' }
                    : item
            );

            mutationUpdateTask.mutate({
                project_id: taskData?.row?.project_id,
                task_id: taskData?.row?.id,
                data: JSON.stringify(payload),
            });

        })();
    }

    return (
        <Drawer open={open} onOpenChange={setOpen}>
            <DrawerTrigger>
                {children ?? <Button
                    size="icon"
                    variant="outline"
                >
                    <Plus />
                </Button>}

            </DrawerTrigger>
            <DrawerContent>
                <DrawerHeader className='flex !flex-row justify-between'>
                    <div>
                        <DrawerTitle> {taskName}</DrawerTitle>
                        <DrawerDescription >Please Enter these fields to update project</DrawerDescription>
                    </div>
                    <Button className='w-fit' onClick={() => onSubmit()}>
                        Update Task
                    </Button>
                </DrawerHeader>
                <ScrollArea className="h-[60vh] w-full rounded-md border p-4">
                    <div className='p-5 space-y-4 flex gap-4 w-full'>
                        <div className='text-sm text-gray-500 w-[70%]'>
                            <p className='mb-2 text-lg font-medium text-black'>Description</p>
                            <RichText value={getDescription} onChange={(value: string) => setDescription(value)} />
                            <Separator className="mb-5 mt-8" />
                            <div className='mt-4 w-full'>
                                <p className="mb-2 text-lg font-medium text-black">Add Comment</p>
                                <CommentBox taskData={taskData} users={users} projectDetail={projectDetail} />
                            </div>
                        </div>
                        <div className='w-[30%]'>
                            <Form {...form}>
                                <form className="space-y-8">
                                    <div className='w-full flex flex-col gap-4'>
                                        {taskData?.heads?.map((head: any) => {
                                            const fieldValue = taskData?.row.task_fields.find((f: any) => f.type_key_id === head.id);
                                            return renderDynamicField(head, fieldValue, form);
                                        })}
                                    </div>
                                </form>
                            </Form>

                        </div>
                    </div>
                </ScrollArea>
            </DrawerContent>
        </Drawer>
    )
}

export default AddTaskDrawer