import { useEffect, useState } from "react";
import { Avatar, AvatarImage } from "renderer/components/ui/avatar";
import { Button } from "renderer/components/ui/button";
import { Dot, Pencil, Phone, Video } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "../ui/sheet";
import { useNavigate } from "react-router-dom";
import ChatController from "renderer/Controller/ChatController";
import useAuthStore from "renderer/store/AuthStore";
import { useChatStore } from "stores/useChatStore";
import BaseUrl from "renderer/service/BaseUrl";
import { cn } from "renderer/lib/utils";
import { toast } from "sonner";
import { GroupProfileUpdate } from "renderer/service/authService";
import GroupEdit from "./GroupEdit";


const user = {
    name: "Alice Johnson",
    department: "Sales",
    online: true,
};

interface ChatHeaderProps {

    selectGroup: {
        id: number,
        type: string
        groupName: string
        member: any,
        groupId: any,
        profilePath: string
    }
    selectedToken: string | undefined;
    selectCallerInfo:
    {
        id: number,
        call_type: string,
        group_id: string
    };
    room: any;
    isAudioCall: any;
    chatInfo: any;
    groupInfo: any;

}


export default function ChatHeaderGroup({ groupInfo, room, selectGroup, selectedToken, isAudioCall, chatInfo, selectCallerInfo }: ChatHeaderProps) {
    const { setSelectGroup, setSelectGroupCallActive, group_UserId, selectGroupID, } = useChatStore();
    const navigate = useNavigate();
    const fallbacksrc = 'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y';
    const ResUser = useAuthStore.getState().getUser();
    const [status, setStatus] = useState<string[]>([]);
    const [participantCount, setParticipantCount] = useState(0);



    useEffect(() => {
        SocketHandle()
    }, [selectGroupID]);


    const SocketHandle = async () => {
        let socket: any;
        const handleuserStatusNotification = async (data: any) => {
            const aStrSet = new Set(selectGroupID.map(String));
            const commonCount = data.filter((val: unknown) => aStrSet.has(val)).length;
            setParticipantCount(commonCount)
            setStatus(Array.isArray(data) ? data : [String(data)]);

        };


        const setupSocketListeners = async () => {
            await waitForSocketReady();
            socket = ChatController.getSocket();
            if (!socket) return;
            socket.on("online-users", handleuserStatusNotification)
            // Now emit userStatus
            ChatController.callbackSocket('userStatus', {
                userId: Number(ResUser?.id),
                chat_status: "online",
                status: 1
            });
        };

        const cleanupListeners = () => {
            if (!socket) return;
            socket.off("online-users", handleuserStatusNotification)
        };

        const waitForSocketReady = () => {
            return new Promise<void>((resolve) => {
                if (ChatController.isSocketConnected === 1) return resolve();
                const interval = setInterval(() => {
                    if (ChatController.isSocketConnected === 1) {
                        clearInterval(interval);
                        resolve();
                    }
                }, 300);
            });
        };
        setupSocketListeners();
        return () => {
            cleanupListeners();

        };
    }
    console.log("selectGroupID???", selectGroupID);

    const HandleStart = () => {

        if (!isAudioCall && selectGroup && ResUser) {
            const data = {
                receiverId: Number(ResUser?.id),
                senderId: Number(ResUser.id),
                callType: 'audio',
                name: selectGroup?.groupName,
                roomname: '',
                token: '',
                groupId: selectGroup?.groupId,
                chat_type: 'Group',
                memberIds: group_UserId,

            }
            setSelectGroupCallActive(data)

            const isSameCaller = selectCallerInfo?.call_type === "0" && selectCallerInfo?.group_id === selectGroup?.groupId
            if (!isSameCaller) {
                ChatController.callbackSocket('callUser', data);
            }

            navigate('/connect/AudioGroupMeeting', { state: { token: selectedToken, selectedUser: data, screenType: 'ChatHeader' } })
        }
    }


    const handleVideoCall = () => {
        const data = {
            senderId: Number(ResUser?.id),
            receiverId: Number(ResUser?.id),
            callType: 'video',
            name: selectGroup?.groupName,
            chat_type: 'Group',
            groupId: selectGroup?.groupId,
            memberIds: group_UserId,

        }
        setSelectGroupCallActive(data)
        const isSameCaller = selectCallerInfo?.call_type === "1" && selectCallerInfo?.group_id === selectGroup?.groupId
        if (!isSameCaller) {
            ChatController.callbackSocket('callUser', data);
        }

        navigate('/connect/RoomGroupMeeting', { state: { token: selectedToken, selectedUser: data, screenType: 'ChatGroupHeader' } })
    }

    const changeAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || !selectGroup) return;

        console.log("File selected:", file);

        try {
            await GroupProfileUpdate({
                group_id: selectGroup.groupId,
                group_name: selectGroup.groupName,
                description: "",
                file,
                user_ids: selectGroupID.map(String),
            });

            toast.success("Group avatar updated successfully!");
            setSelectGroup(null);
        } catch (error) {
            console.error("Avatar update failed:", error);
            toast.error("Failed to update group avatar");
        }
    };

    return (
        <div className="w-full flex items-center justify-between bg-secondary p-4 border-b">
            <Sheet>
                <SheetTrigger>
                    <div className="flex items-center gap-3">
                        <Avatar>
                            <AvatarImage src={selectGroup.profilePath ? `${BaseUrl.Url_Base}${selectGroup.profilePath}` : fallbacksrc} alt={user.name} />
                        </Avatar>
                        <div className="text-left">
                            <h2 className="text-md font-semibold">{selectGroup?.groupName}</h2>
                        </div>
                    </div>
                    <p className="absolute left-104 text-xs text-gray-500">{participantCount} Online</p>

                </SheetTrigger>
                <SheetContent className="w-[90%] sm:w-[540px] pt-16 px-4">
                    <div className="relative">
                        <input
                            type="file"
                            id="changeAvatar"
                            onChange={changeAvatar}
                            style={{ display: "none" }}
                        />
                        <div className="relative w-20 h-20">
                            <Avatar className="w-full h-full">
                                <AvatarImage src={selectGroup.profilePath ? `${BaseUrl.Url_Base}${selectGroup.profilePath}` : fallbacksrc} alt={user.name} />
                            </Avatar>
                            <button
                                className="absolute bottom-0 right-0 bg-white rounded-full p-1 shadow hover:bg-gray-100"
                                title="Change Avatar"
                                onClick={() => {
                                    document.getElementById("changeAvatar")?.click()
                                }}
                            >
                                <Pencil className="w-4 h-4 text-gray-700" />
                            </button>
                        </div>
                        <div className="mt-2 w-full">
                            <h4 className="text-1xl text-black">{selectGroup?.groupName}</h4>
                        </div>

                        <div className="mt-4 w-full">
                            <div className="flex gap-2">
                                <Button
                                    variant="outline"
                                    size="icon"
                                    onClick={HandleStart}
                                    className="relative group"
                                >
                                    {(selectCallerInfo?.call_type === "0" && selectCallerInfo?.group_id === selectGroup?.groupId) ? (
                                        <Phone className="text-green-400 group-hover:scale-150 transition-transform duration-150" size={20} />
                                    ) : (
                                        <Phone className="text-accent-foreground group-hover:scale-110 transition-transform duration-150" size={20} />
                                    )}
                                </Button>
                                <Button variant="outline" size="icon" onClick={() => { handleVideoCall() }}>
                                    {(selectCallerInfo?.call_type === "1" && selectCallerInfo?.group_id === selectGroup?.groupId) ? (
                                        <Video className="text-green-400 group-hover:scale-150 transition-transform duration-150" size={20} />
                                    ) : (
                                        <Video className="text-accent-foreground group-hover:scale-110 transition-transform duration-150" size={20} />
                                    )}
                                </Button>
                                <Button variant="outline">
                                    <GroupEdit selectGroup={selectGroup} group_UserId={selectGroupID} />
                                </Button>
                            </div>

                        </div>

                        <div className="mt-2 w-full">
                            <h4 className="text-2xl text-black">Group Member list</h4>
                        </div>

                        {groupInfo?.members?.length > 0 ? (
                            groupInfo.members.map((member: any, index: number) => {
                                const isOnline = Array.isArray(status) && status.includes(String(member?.userId));; // Adjusted to use member
                                return (
                                    <div
                                        key={index}
                                        className="flex items-center justify-between py-2 px-4 mb-2 border-b border-gray-200 rounded-md"
                                    >
                                        <p className="text-black-500 text-base">{member.memberName}</p>
                                        <Dot className={cn("ml-2", isOnline ? "text-green-500" : "text-gray-400")} />
                                    </div>
                                );
                            })
                        ) : (
                            <p className="text-base text-gray-400 italic">No members found</p>
                        )}


                    </div>
                </SheetContent>
            </Sheet>

            <div className="flex gap-2">
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={HandleStart}
                    className="relative group"
                >
                    {(selectCallerInfo?.call_type === "0" && selectCallerInfo?.group_id === selectGroup?.groupId) ? (
                        <Phone className="text-green-400 group-hover:scale-150 transition-transform duration-150" size={20} />
                    ) : (
                        <Phone className="text-accent-foreground group-hover:scale-110 transition-transform duration-150" size={20} />
                    )}
                </Button>

                <Button variant="ghost" size="icon" onClick={() => { handleVideoCall() }}>
                    {(selectCallerInfo?.call_type === "1" && selectCallerInfo?.group_id === selectGroup?.groupId) ? (
                        <Video className="text-green-400 group-hover:scale-150 transition-transform duration-150" size={20} />
                    ) : (
                        <Video className="text-accent-foreground group-hover:scale-110 transition-transform duration-150" size={20} />
                    )}
                </Button>
            </div>

        </div>
    );
}
