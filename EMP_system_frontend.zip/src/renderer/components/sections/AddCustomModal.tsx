import React, { useEffect, useRef, useState } from 'react'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from 'renderer/components/ui/dialog'
import { Button } from '../ui/button'
import { Check, Plus } from 'lucide-react'
import { useVirtualizer } from '@tanstack/react-virtual'
import { Command, CommandEmpty, CommandItem, CommandList } from '../ui/command'
import { Input } from '../ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar'

const AddCustomModal = (props: any) => {
    const { membersList, selectedUsers, setSelectedUsers, title } = props
    const [openDialog, setOpenDialog] = useState(false)
    const [searchQuery, setSearchQuery] = React.useState('');
    const parentRef = useRef(null);

    const filteredUsers = React.useMemo(() => {
        return membersList?.data?.filter(
            (user: any) =>
                user.userfullname &&
                user.userfullname.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [searchQuery, membersList?.data]);

    const rowVirtualizer = useVirtualizer({
        count: filteredUsers?.length,
        getScrollElement: () => parentRef.current,
        estimateSize: () => 60,
    });



    useEffect(() => {
        let timeoutId = setTimeout(() => {
            rowVirtualizer.measure();
        }, 100);
        return () => clearTimeout(timeoutId)
    }, [openDialog])
    return (
        <Dialog open={openDialog} onOpenChange={setOpenDialog}>

            <DialogTrigger>
                <Button variant="outline" className='text-sm' type='button'> <Plus /> {title} </Button>
            </DialogTrigger>

            <DialogContent className="p-0">
                <DialogTitle className='p-4'>{title}</DialogTitle>

                <Command className='bg-transparent'>
                    <Input
                        placeholder="Search user..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <CommandList
                        style={{
                            height: '300px',
                            overflow: 'auto',
                            position: 'relative',
                        }}
                    >
                        {filteredUsers?.length === 0 ? (
                            <CommandEmpty>No results found.</CommandEmpty>
                        ) : (
                            <div
                                ref={parentRef}
                                style={{ height: '300px', overflow: 'auto', position: 'relative' }}
                                className="border-t"
                            >
                                <div
                                    style={{
                                        height: rowVirtualizer.getTotalSize(),
                                        position: 'relative',
                                    }}
                                >
                                    {rowVirtualizer.getVirtualItems().map((virtualRow) => {
                                        const member = filteredUsers[virtualRow.index];
                                        if (!member) return null;

                                        return (
                                            <CommandItem
                                                key={member?.id}
                                                style={{
                                                    position: 'absolute',
                                                    top: 0,
                                                    left: 0,
                                                    width: '100%',
                                                    height: `${virtualRow.size}px`,
                                                    transform: `translateY(${virtualRow.start}px)`,
                                                }}
                                                className="gap-3 py-2"
                                                onSelect={() => {
                                                    if (selectedUsers?.includes(member.id)) {
                                                        setSelectedUsers((prevSelected: any) =>
                                                            prevSelected?.filter((id: string) => id !== member.id)
                                                        );
                                                    } else {
                                                        setSelectedUsers((prevSelected: any) => [...prevSelected, member.id]);
                                                    }
                                                }}
                                            >
                                                <Avatar className="w-8 h-8">
                                                    <AvatarImage src={member.avatar} />
                                                    <AvatarFallback>{member.userfullname.slice(0, 1)}</AvatarFallback>
                                                </Avatar>
                                                <div className="flex flex-col">
                                                    <span className="text-sm font-medium">{member.userfullname}</span>
                                                    <span className="text-xs text-muted-foreground">{member.jobtitle_name}</span>
                                                </div>
                                                {selectedUsers?.includes(member?.id) ? (
                                                    <Check className="ml-auto flex h-5 w-5 text-primary" />
                                                ) : null}
                                            </CommandItem>
                                        );
                                    })}
                                </div>
                            </div>
                        )}
                    </CommandList>
                </Command>
                <DialogFooter className='p-4'>
                    <Button onClick={() => setOpenDialog(false)}>
                        Save
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

export default AddCustomModal