"use client"

import { useState } from "react"
import { Calendar as BigCalendar, dateFnsLocalizer, Views, type SlotInfo } from "react-big-calendar"
import { format, parse, startOfWeek, getDay, addMinutes } from "date-fns"
import { enUS } from "date-fns/locale/en-US"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "renderer/components/ui/tabs"
import { Card } from "renderer/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "renderer/components/ui/dialog"
import { Button } from "renderer/components/ui/button"
import { Input } from "renderer/components/ui/input"
import { Label } from "renderer/components/ui/label"
import { Textarea } from "renderer/components/ui/textarea"

// Import the CSS for react-big-calendar
import "react-big-calendar/lib/css/react-big-calendar.css"

// Setup the localizer for BigCalendar
const locales = {
    "en-US": enUS,
}

const localizer = dateFnsLocalizer({
    format,
    parse,
    startOfWeek,
    getDay,
    locales,
})

// Sample events data
const initialEvents = [
    {
        id: 1,
        title: "Team Meeting",
        description: "Weekly team sync-up",
        start: new Date(2025, 3, 15, 10, 0), // April 15, 2025, 10:00 AM
        end: new Date(2025, 3, 15, 11, 30), // April 15, 2025, 11:30 AM
    },
    {
        id: 2,
        title: "Client Presentation",
        description: "Present Q1 results to client",
        start: new Date(2025, 3, 17, 14, 0), // April 17, 2025, 2:00 PM
        end: new Date(2025, 3, 17, 15, 0), // April 17, 2025, 3:00 PM
    },
    {
        id: 3,
        title: "Project Review",
        description: "Review project milestones",
        start: new Date(2025, 3, 20, 9, 0), // April 20, 2025, 9:00 AM
        end: new Date(2025, 3, 20, 10, 0), // April 20, 2025, 10:00 AM
    },
    {
        id: 4,
        title: "Sprint Planning",
        description: "Plan tasks for next sprint",
        start: new Date(2025, 3, 22, 13, 0), // April 22, 2025, 1:00 PM
        end: new Date(2025, 3, 22, 14, 30), // April 22, 2025, 2:30 PM
    },
    {
        id: 5,
        title: "Product Demo",
        description: "Demonstrate new features",
        start: new Date(2025, 3, 25, 15, 0), // April 25, 2025, 3:00 PM
        end: new Date(2025, 3, 25, 16, 0), // April 25, 2025, 4:00 PM
    },
]

// Define the view types
const viewTypes = [
    { key: "month", label: "Month", value: Views.MONTH },
    { key: "week", label: "Week", value: Views.WEEK },
    { key: "day", label: "Day", value: Views.DAY },
    { key: "agenda", label: "List", value: Views.AGENDA },
]

interface Event {
    id: number
    title: string
    description: string
    start: Date
    end: Date
}

interface EventFormData {
    id?: number
    title: string
    description: string
    start: Date
    end: Date
}

export default function Calendar() {
    const [view, setView] = useState(Views.MONTH)
    const [events, setEvents] = useState<Event[]>(initialEvents)
    const [isDialogOpen, setIsDialogOpen] = useState(false)
    const [isEditMode, setIsEditMode] = useState(false)
    const [newEvent, setNewEvent] = useState<EventFormData>({
        title: "",
        description: "",
        start: new Date(),
        end: new Date(),
    })

    const handleViewChange = (newView: string) => {
        setView(newView as any)
    }

    const handleSelectSlot = (slotInfo: SlotInfo) => {
        // Only respond to doubleClick or selecting a range by dragging
        if (slotInfo.action === "doubleClick" || slotInfo.action === "select") {
            // Default end time is 1 hour after start time if not a range selection
            const endTime = slotInfo.action === "doubleClick" ? addMinutes(slotInfo.start, 60) : slotInfo.end

            setNewEvent({
                title: "",
                description: "",
                start: slotInfo.start,
                end: endTime,
            })
            setIsEditMode(false)
            setIsDialogOpen(true)
        }
    }

    const handleSelectEvent = (event: Event) => {
        setNewEvent({
            id: event.id,
            title: event.title,
            description: event.description || "",
            start: event.start,
            end: event.end,
        })
        setIsEditMode(true)
        setIsDialogOpen(true)
    }

    const handleSaveEvent = () => {
        if (newEvent.title.trim() === "") return

        if (isEditMode && newEvent.id) {
            // Update existing event
            setEvents(
                events.map((event) =>
                    event.id === newEvent.id
                        ? {
                            ...event,
                            title: newEvent.title,
                            description: newEvent.description,
                            start: newEvent.start,
                            end: newEvent.end,
                        }
                        : event,
                ),
            )
        } else {
            // Create new event
            const createdEvent = {
                id: events.length > 0 ? Math.max(...events.map((e) => e.id)) + 1 : 1,
                title: newEvent.title,
                description: newEvent.description,
                start: newEvent.start,
                end: newEvent.end,
            }

            setEvents([...events, createdEvent])
        }

        setIsDialogOpen(false)
        resetForm()
    }

    const handleDeleteEvent = () => {
        if (isEditMode && newEvent.id) {
            setEvents(events.filter((event) => event.id !== newEvent.id))
            setIsDialogOpen(false)
            resetForm()
        }
    }

    const resetForm = () => {
        setNewEvent({
            title: "",
            description: "",
            start: new Date(),
            end: new Date(),
        })
        setIsEditMode(false)
    }

    const formatDate = (date: Date) => {
        return format(date, "MMMM dd, yyyy")
    }

    const formatTime = (date: Date) => {
        return format(date, "h:mm a")
    }

    return (
        <>
            <Card className="p-4">
                <Tabs defaultValue="month" onValueChange={handleViewChange}>
                    <TabsList className="mb-4">
                        {viewTypes.map((viewType) => (
                            <TabsTrigger key={viewType.key} value={viewType.key}>
                                {viewType.label}
                            </TabsTrigger>
                        ))}
                    </TabsList>

                    {viewTypes.map((viewType) => (
                        <TabsContent key={viewType.key} value={viewType.key} className="mt-0">
                            <div className="h-[700px]">
                                <BigCalendar
                                    localizer={localizer}
                                    events={events}
                                    startAccessor="start"
                                    endAccessor="end"
                                    view={viewType.value}
                                    views={[viewType.value]}
                                    toolbar={false}
                                    className="rounded-md"
                                    selectable
                                    onSelectSlot={handleSelectSlot}
                                    onSelectEvent={handleSelectEvent}
                                // doubleClickDelay={250}
                                />
                            </div>
                        </TabsContent>
                    ))}
                </Tabs>
            </Card>

            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogContent className="sm:max-w-[425px]">
                    <DialogHeader>
                        <DialogTitle>{isEditMode ? "Edit Event" : "Create New Event"}</DialogTitle>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                            <Label htmlFor="title">Event Title</Label>
                            <Input
                                id="title"
                                value={newEvent.title}
                                onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                                placeholder="Enter event title"
                            />
                        </div>
                        <div className="grid gap-2">
                            <Label htmlFor="description">Description</Label>
                            <Textarea
                                id="description"
                                value={newEvent.description}
                                onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                                placeholder="Enter event description"
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="grid gap-2">
                                <Label>Start</Label>
                                <div className="text-sm">
                                    <div>{formatDate(newEvent.start)}</div>
                                    <div>{formatTime(newEvent.start)}</div>
                                </div>
                            </div>
                            <div className="grid gap-2">
                                <Label>End</Label>
                                <div className="text-sm">
                                    <div>{formatDate(newEvent.end)}</div>
                                    <div>{formatTime(newEvent.end)}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <DialogFooter className="flex justify-between sm:justify-between">
                        <div>
                            {isEditMode && (
                                <Button variant="destructive" onClick={handleDeleteEvent}>
                                    Delete
                                </Button>
                            )}
                        </div>
                        <div className="flex gap-2">
                            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                                Cancel
                            </Button>
                            <Button onClick={handleSaveEvent}>{isEditMode ? "Update" : "Create"}</Button>
                        </div>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    )
}
