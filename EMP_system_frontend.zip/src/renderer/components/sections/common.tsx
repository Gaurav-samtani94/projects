const common = () => {
  return <div>common</div>
}

export default common
