import { format } from 'date-fns'
import { Bold, CalendarIcon, Check, ClipboardPlus, FolderCode, Italic, Plus, Underline } from 'lucide-react'
import React from 'react'
import { useForm } from 'react-hook-form'
import { Button } from 'renderer/components/ui/button'
import { Calendar } from 'renderer/components/ui/calendar'
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from 'renderer/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from 'renderer/components/ui/dialog'
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from 'renderer/components/ui/form'
import { Input } from 'renderer/components/ui/input'
import { Popover, PopoverContent, PopoverTrigger } from 'renderer/components/ui/popover'
import RichText from 'renderer/components/ui/RichText'
import { ScrollArea } from 'renderer/components/ui/scroll-area'
import { Toggle } from 'renderer/components/ui/toggle'
import { ToggleGroup, ToggleGroupItem } from 'renderer/components/ui/toggle-group'
import { cn } from 'renderer/lib/utils'
import CreateTemplate from './create-template'

const CreateProjectModal = () => {
  const form = useForm()
  const [date, setDate] = React.useState<Date>()
  return (
    <Form {...form}>
      <div className='grid grid-cols-12 gap-4'>
        <div className='flex gap-4 col-span-8 flex-col'>
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Project Name</FormLabel>
                <FormControl>
                  <Input placeholder="Enter Project name" {...field} className='w-full' />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Project Description</FormLabel>
                <FormControl>
                  <RichText />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className='flex gap-4 flex-col col-span-4'>
          <FormField
            control={form.control}
            name="estimatedtime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Deadline Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "justify-start text-left font-normal",
                        !date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon />
                      {date ? format(date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align='start'>
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </FormItem>
            )}
          />
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className='text-left justify-start'>
                <Check />
                Select Project Template
              </Button>
            </DialogTrigger>
            <DialogContent className='sm:max-w-[750px]'>
              <DialogHeader>
                <DialogTitle>Project Template</DialogTitle>
              </DialogHeader>
              <div className="flex flex-col">
                <Input id="search" placeholder='Search For Template' className="w-full mx-auto" />
                <Card className='mt-4'>
                  <CardHeader>
                    <CardTitle>
                      <ClipboardPlus className='size-8 mb-4' />
                      Create Custom
                    </CardTitle>
                  </CardHeader>
                  <CardFooter>
                    <CreateTemplate>
                      <Button className="w-full">
                        <Plus /> Create
                      </Button>
                    </CreateTemplate>
                  </CardFooter>
                </Card>
                <ScrollArea className='h-[50vh] py-4'>
                  <div className="grid grid-cols-2 items-center gap-4">
                    {Array(6).fill(0).map((_, i: number) => {
                      return (
                        <Card key={i}>
                          <CardHeader>
                            <CardTitle>
                              <FolderCode className='size-8 mb-4' />
                              For IT
                            </CardTitle>
                            <CardDescription>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex quaerat, temporibus magni mollitia at nostrum</CardDescription>
                          </CardHeader>
                          <CardFooter>
                            <Button className="w-full" variant="outline">
                              <Check /> Select
                            </Button>
                          </CardFooter>
                        </Card>
                      )
                    })}
                  </div>
                </ScrollArea>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </Form>
  )
}

export default CreateProjectModal