import { Plus } from 'lucide-react'
import type React from 'react'
import { Button } from 'renderer/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from 'renderer/components/ui/dialog'
import { Input } from 'renderer/components/ui/input'
import { Label } from 'renderer/components/ui/label'
import { Toggle } from 'renderer/components/ui/toggle'
import CustomColumn from './custom-column'

const CreateTemplate = ({ children }: { children: React.ReactNode }) => {
    return (
        <Dialog>
            <DialogTrigger asChild>
                {children ??
                    <Button variant="outline"><Plus /></Button>
                }
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Create Template</DialogTitle>
                    <DialogDescription>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt dolore debitis impedit.
                    </DialogDescription>
                </DialogHeader>
                <div>
                    <form>
                        <div className="grid w-full items-center gap-4">
                            <div className="flex flex-col space-y-1.5">
                                <Label htmlFor="name">Name</Label>
                                <Input id="name" placeholder="Name of your template" />
                            </div>
                            <div className="flex flex-col space-y-1.5">
                                <Label htmlFor="picture">Template Icon or image</Label>
                                <Input id="picture" type="file" />
                            </div>
                            <div className="flex flex-col space-y-1.5">
                                <Label htmlFor="picture mb-1">Choose Columns</Label>
                                <div className='flex flex-wrap items-center gap-2 '>
                                    <Toggle variant="outline" value="Name" pressed={true}>Name</Toggle>
                                    <Toggle variant="outline" value="Description" pressed={true}>Description</Toggle>
                                    <Toggle variant="outline" value="Status" defaultPressed={true}>Status</Toggle>
                                    <Toggle variant="outline" value="Priority" defaultPressed={true}>Priority</Toggle>
                                    <Toggle variant="outline" value="Type" defaultPressed={true}>Type</Toggle>
                                    <Toggle variant="outline" value="AssignTo" defaultPressed={true}>Assign To</Toggle>
                                    <Toggle variant="outline" value="AssignBy" defaultPressed={true}>Assign By</Toggle>
                                    <Toggle variant="outline" value="Created" defaultPressed={true}>Created By</Toggle>
                                    <Toggle variant="outline">Reviewer</Toggle>
                                    <Toggle variant="outline">QA</Toggle>
                                    <Toggle variant="outline">Deadline</Toggle>
                                    <Toggle variant="outline">Est. Hours</Toggle>
                                    <Toggle variant="outline">Dependency</Toggle>
                                    <CustomColumn>
                                        <Button className='' variant="outline" type='button'>
                                            <Plus />
                                            Add Custom
                                        </Button>
                                    </CustomColumn>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <DialogFooter>
                    <Button type="submit">Save changes</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}

export default CreateTemplate