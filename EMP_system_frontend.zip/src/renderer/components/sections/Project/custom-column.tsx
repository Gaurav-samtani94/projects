import { DialogTitle } from "@radix-ui/react-dialog"
import { Calculator, Calendar, Smile } from "lucide-react"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "renderer/components/ui/command"
import { Dialog, DialogContent, DialogHeader, DialogTrigger } from "renderer/components/ui/dialog"

const CustomColumn = ({ children }: { children: React.ReactNode }) => {
    return (
        <Dialog>
            <DialogTrigger>
                {children}
            </DialogTrigger>
            <DialogContent className="gap-0 p-0 outline-none">
                <DialogHeader className="px-4 pb-4 pt-5">
                    <DialogTitle>
                        Custom Column
                    </DialogTitle>
                </DialogHeader>
                <Command className="overflow-hidden rounded-t-none border-t bg-transparent">
                    <CommandInput placeholder="Type a command or search..." />
                    <CommandList>
                        <CommandEmpty>No results found.</CommandEmpty>
                        <CommandGroup heading="Suggestions">
                            <CommandItem>
                                <Calendar />
                                <span>Calendar</span>
                            </CommandItem>
                            <CommandItem>
                                <Smile />
                                <span>Search Emoji</span>
                            </CommandItem>
                            <CommandItem disabled>
                                <Calculator />
                                <span>Calculator</span>
                            </CommandItem>
                        </CommandGroup>
                    </CommandList>
                </Command>
            </DialogContent>
        </Dialog>
    )
}

export default CustomColumn