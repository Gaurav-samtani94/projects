import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, MoreVertical } from "lucide-react";
import { useEffect, useState } from "react";
import { Input } from "renderer/components/ui/input";
import { Button } from "renderer/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "renderer/components/ui/popover";

export function SortableItem({
    id,
    label,
    color,
    onUpdate,
    onDelete,
    defaultColors,
    isDisabled
}: any) {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });
    const [editLabel, setEditLabel] = useState(label);
    const [selectedColor, setSelectedColor] = useState(color);
    const [isOpen, setIsOpen] = useState(false);

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
    };

    useEffect(() => {
        setSelectedColor(color);
        setEditLabel(label);
    }, [color, label]);

    return (
        <div
            ref={setNodeRef}
            style={style}
            className="flex items-center justify-between rounded-md border p-2 bg-muted"
        >
            <div className="flex items-center gap-2">
                <GripVertical className="h-4 w-4 cursor-move" {...attributes} {...listeners} />
                <div
                    className="h-3 w-3 rounded-full"
                    style={{ backgroundColor: selectedColor }}
                />
                <span>{editLabel}</span>
            </div>

            <Popover open={isOpen} onOpenChange={setIsOpen}>
                <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon" disabled={isDisabled}>
                        <MoreVertical className="h-4 w-4" />
                    </Button>
                </PopoverTrigger>

                <PopoverContent className="w-64">
                    <div className="space-y-3">
                        <Input
                            value={editLabel}
                            onChange={(e) => setEditLabel(e.target.value)}
                            placeholder="Option name"
                            disabled={isDisabled}
                        />
                        <div className="flex flex-wrap gap-2">
                            {defaultColors?.map((c: any) => (
                                <button
                                    key={c.color}
                                    className="h-5 w-5 rounded-full"
                                    style={{ backgroundColor: c.color }}
                                    onClick={() => setSelectedColor(c.color)}
                                    disabled={isDisabled}
                                />
                            ))}
                        </div>
                        <Input
                            type="color"
                            value={selectedColor}
                            onChange={(e) => setSelectedColor(e.target.value)}
                            disabled={isDisabled}
                        />
                        <div className="flex justify-between pt-2">
                            <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => onDelete(id)}
                                disabled={isDisabled}
                            >
                                Delete
                            </Button>
                            <Button
                                size="sm"
                                onClick={() => onUpdate(id, editLabel, selectedColor, () => setIsOpen(false))}
                                disabled={isDisabled}
                            >
                                Save
                            </Button>
                        </div>
                    </div>
                </PopoverContent>
            </Popover>
        </div>
    );
}
