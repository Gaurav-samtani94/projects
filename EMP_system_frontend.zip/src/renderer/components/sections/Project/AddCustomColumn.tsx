import { Command, CommandInput, CommandItem, CommandList } from "renderer/components/ui/command";
import {
    Text,
    Hash,
    Circle,
    List,
    Sparkles,
    Calendar,
    Users,
    Paperclip,
    CheckSquare,
    Link,
    Mail,
    Phone,
    Sigma,
    ArrowUpRight,
    Clock,
    User,
    Edit3,
    SquareArrowOutUpRight,
    // MousePointerSquare,
    Hash as Hash2,
    MousePointer,
    Plus,
} from "lucide-react";
import {
    DndContext,
    closestCenter,
    PointerSensor,
    useSensor,
    useSensors,
} from "@dnd-kit/core";
import {
    arrayMove,
    SortableContext,
    verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { Sheet, SheetClose, SheetContent, SheetFooter, SheetHeader, SheetTitle, SheetTrigger } from "renderer/components/ui/sheet";
import { Button } from "renderer/components/ui/button";
import { useEffect, useRef, useState } from "react";
import { Input } from "renderer/components/ui/input";
import { SortableItem } from "./SortableItem";
import { useMutation, useQuery } from "@tanstack/react-query";
import { addCustomOptions, createCustomFields, customFieldsList, deleteCustomOptions, getCustomOptionsList, updateCustomFields, updateCustomOptions, updateOptionsOrder } from "renderer/service/project";
import { toast } from "sonner";

const menuItems = [
    { id: "text", icon: Text, label: "Text" },
    { id: "number", icon: Hash, label: "Number" },
    { id: "select", icon: Circle, label: "Select" },
    { id: "multi-select", icon: List, label: "Multi-select" },
    { id: "status", icon: Sparkles, label: "Status" },
    { id: "date", icon: Calendar, label: "Date" },
    { id: "person", icon: Users, label: "Person" },
    { id: "files-media", icon: Paperclip, label: "Files & media" },
    { id: "checkbox", icon: CheckSquare, label: "Checkbox" },
    { id: "relation", icon: ArrowUpRight, label: "Relation" },
    { id: "created-time", icon: Clock, label: "Created time" },
    { id: "created-by", icon: User, label: "Created by" },
    { id: "last-edited-time", icon: Edit3, label: "Last edited time" },
    { id: "last-edited-by", icon: User, label: "Last edited by" },
];


const defaultColors = [
    { name: "Gray", color: "#9CA3AF" },
    { name: "Brown", color: "#92400E" },
    { name: "Orange", color: "#F97316" },
    { name: "Yellow", color: "#EAB308" },
    { name: "Green", color: "#22C55E" },
    { name: "Blue", color: "#3B82F6" },
    { name: "Purple", color: "#8B5CF6" },
    { name: "Pink", color: "#EC4899" },
    { name: "Red", color: "#EF4444" },
];

const iconMap: Record<string, React.ElementType> = {
    Text,
    Circle,
    Hash,
    List,
    Calendar,
    Users,
    Paperclip,
    ArrowUpRight,
    Sparkles,
    CheckSquare,
    Clock,
    User,
    Edit3,
};

type PROJECTDETAILS = {
    projectDetail: any,
    refetch: any,
    open: any,
    setOpen: any,
    setSelectedType: any,
    selectedType: any,
    typeId: any,
    setTypeId: any,
    setColumnName: any,
    columnName: any,
    initialColumnName: any,
    refetchTaskList: any,
    refetchFiltersList: any
};

export default function AddCustomColumn({ projectDetail, refetch, open, setOpen, selectedType, setSelectedType, typeId, setTypeId, setColumnName, columnName, initialColumnName, refetchTaskList, refetchFiltersList }: PROJECTDETAILS) {
    const [options, setOptions] = useState<
        { id: string; label: string; color: string; sr_no: number, type_key_id: string, is_disabled: string }[]
    >([]);
    const [newOption, setNewOption] = useState("");
    const [fieldId, setFieldId] = useState("");
    const newOptionRef = useRef<HTMLInputElement>(null);

    const handleSelect = (item: any) => {
        setSelectedType(item?.field_code);
        setOpen(true);
        setOptions([]);
        setNewOption("");
        setFieldId(item?.id)
    };

    const addCustomOptionMutation = useMutation({
        mutationFn: addCustomOptions,
        onSuccess: (response) => {
            toast.success(response?.message)
            refetchCustomOptions()
            refetchTaskList();
            refetchFiltersList();
        },
        onError: (error: any) => {
            toast.error(error?.message)
        },
    })

    const handleAddOption = () => {
        if (newOption.trim()) {
            const maxSrNo = data?.data?.length
                ? Math.max(...data?.data?.map((item: any) => Number(item.sr_no) || 0))
                : 0;
            const nextSrNo = maxSrNo + 1;
            setNewOption('')
            addCustomOptionMutation.mutate({
                type_key_id: typeId,
                option_name: newOption,
                sr_no: nextSrNo ?? '1',
                color: "#9CA3AF"
            });
        }
    };

    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: { distance: 5 },
        })
    );

    const { data, refetch: refetchCustomOptions, } = useQuery({
        queryKey: ['optionsList', typeId],
        queryFn: () => getCustomOptionsList({ type_key_id: typeId }),
        enabled: !!typeId,
    })

    // useEffect(() => {
    //     refetchTaskList();
    // }, [data])

    useEffect(() => {
        if (data?.data) {
            const normalizedOptions = data?.data?.map((item: any) => ({
                id: item.id,
                label: item.option_name,
                color: item.color !== '' ? item.color : "#9CA3AF",
                sr_no: item?.sr_no,
                type_key_id: item?.type_key_id,
                is_disabled: item?.is_disabled
            }));
            const sortedOptions = normalizedOptions?.sort((a: any, b: any) => a.sr_no - b.sr_no);

            setOptions(sortedOptions);
        }
    }, [data]);

    const updateOptionOrder = useMutation({
        mutationFn: updateOptionsOrder
    })

    const handleDragEnd = (event: any) => {
        const { active, over } = event;
        if (active.id !== over.id) {
            setOptions((items) => {
                const oldIndex = items.findIndex((i) => i.id === active.id);
                const newIndex = items.findIndex((i) => i.id === over.id);
                const reordered = arrayMove(items, oldIndex, newIndex);
                const payload = {
                    type_key_id: typeId,
                    data: JSON.stringify(reordered.map((item) => item.id))
                };
                updateOptionOrder.mutate(payload)
                return arrayMove(items, oldIndex, newIndex);
            });
        }
    };

    const updateCustomOptionMutation = useMutation({
        mutationFn: updateCustomOptions
    })

    const updateOption = (id: string, newLabel: string, newColor: string, onSuccessCallback?: () => void) => {
        updateCustomOptionMutation.mutate(
            {
                option_id: id,
                option_name: newLabel,
                color: newColor ?? "#9CA3AF",
            },
            {
                onSuccess: (response) => {
                    setOptions((opts) =>
                        opts.map((opt) =>
                            opt.id === id ? { ...opt, label: newLabel, color: newColor } : opt
                        )
                    );
                    toast.success(response?.message);
                    refetchTaskList();
                    refetchFiltersList();
                    onSuccessCallback?.();
                },
                onError: (err: any) => {
                    toast.error(err?.message || "Failed to update option");
                }
            }
        );
    };

    const { data: customFields, isSuccess } = useQuery({
        queryKey: ['customFileds', projectDetail?.id],
        queryFn: () => customFieldsList(),
    })

    const updateFieldMutation = useMutation({
        mutationFn: updateCustomFields,
        onSuccess: (response) => {
            refetch()
            refetchTaskList();
            refetchFiltersList();
            toast.success(response?.message)
        },
        onError: (error: any) => {
            toast.error(error?.message)
        },
    })

    const createFieldsMutation = useMutation({
        mutationFn: createCustomFields,
        onSuccess: (response) => {
            refetch()
            toast.success(response?.message)
            setTypeId(response?.data?.id)
            refetchTaskList();
            refetchFiltersList();

            if (selectedType !== 'multi_select_val' && selectedType !== 'select_val') {
                setColumnName('')
            }

        },
        onError: (error: any) => {
            toast.error(error?.message)
        },
    })

    const deleteCustomOptionMutation = useMutation({
        mutationFn: deleteCustomOptions,
    })

    const deleteOption = (id: string) => {
        deleteCustomOptionMutation.mutate({ option_id: id }, {
            onSuccess: (response) => {
                toast.success(response?.message);
                setOptions((opts) => opts.filter((opt) => opt.id !== id));
                refetchCustomOptions()
                refetchTaskList();
                refetchFiltersList();
            },
            onError: (error: any) => {
                toast.error(error?.message);
            },
        });
    };

    const handleSubmit = () => {
        if (typeId) {
            if (columnName.trim() === initialColumnName.trim()) return;
            updateFieldMutation.mutate({
                field_id: typeId,
                label_name: columnName
            })
        } else {
            if (columnName.trim()) {
                createFieldsMutation.mutate({
                    label_name: columnName,
                    project_id: projectDetail?.team?.project_id,
                    field_code: selectedType,
                    field_type_id: fieldId,
                });
            }
        }
        if (["multi_select_val", "select_val"].includes(selectedType)) {
            setTimeout(() => {
                newOptionRef.current?.focus();
            }, 0);
        }
    }

    return (
        <>
            <Sheet>
                <SheetTrigger asChild>
                    <Button><Plus /> Add more</Button>
                </SheetTrigger>
                <SheetContent className="pt-12 gap">
                    <SheetHeader>
                        <SheetTitle>Add Task Property</SheetTitle>
                    </SheetHeader>

                    <Command className="w-full bg-transparent px-4">
                        <CommandInput placeholder="Search..." className="border-none bg-transparent text-sm" />
                        <CommandList className="max-h-full mt-4">
                            {customFields?.data?.filter((it: any) => it?.field_code !== 'rich_text' && it?.field_code !== 'estimated_val').map((item: any, index: any) => {
                                const IconComponent = iconMap[item.icon];
                                const disabledFieldCodes = ["created_at_val", "created_by_val", "updated_by_val", "updated_at_val"];
                                const isDisabled = disabledFieldCodes.includes(item.field_code);
                                return (
                                    <CommandItem
                                        key={item.field_code}
                                        id={item.field_code}
                                        className="flex items-center gap-3"
                                        onSelect={() => {
                                            if (isDisabled) {
                                                createFieldsMutation.mutate({
                                                    label_name: item?.field_name,
                                                    project_id: projectDetail?.team?.project_id,
                                                    field_code: item?.field_code,
                                                    field_type_id: item?.id,
                                                });
                                            } else {
                                                handleSelect(item);
                                                setOpen(true);
                                            }
                                        }}
                                    >
                                        {IconComponent && <IconComponent className="h-4 w-4" />}
                                        <span>{item?.field_name}</span>
                                    </CommandItem>
                                );
                            })}
                        </CommandList>
                    </Command>
                </SheetContent>
            </Sheet>
            <Sheet open={open} onOpenChange={(isOpen) => {
                setOpen(isOpen);
                if (!isOpen) {
                    setColumnName("");
                    setTypeId('')
                }
            }}>
                <SheetContent className="space-y-6 px-4 pt-14 gap-0">
                    <SheetHeader className="p-0">
                        <SheetTitle >
                            {selectedType === "multi_select_val"
                                ? "Create Multi-Select Column"
                                : selectedType === "status_val"
                                    ? "Create Status Column"
                                    : "Create Column"}
                        </SheetTitle>
                    </SheetHeader>

                    {/* Column Name Input */}
                    <div className="space-y-2">
                        {/* biome-ignore lint/a11y/noLabelWithoutControl: <explanation> */}
                        <label className="text-sm font-medium">Column Name</label>
                        <Input
                            placeholder="Enter column name"
                            value={columnName}
                            onChange={(e) => setColumnName(e.target.value)}
                            onBlur={() => { handleSubmit() }}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    e.preventDefault();
                                    e.currentTarget.blur();
                                }
                            }}
                            disabled={["Priority", "Status"].includes(columnName.trim())}
                        />
                    </div>

                    {(selectedType === "multi_select_val" || selectedType === "select_val") && (
                        <>
                            {/* Add New Option */}
                            <div className="flex items-center gap-2">
                                <Input
                                    placeholder="New option"
                                    value={newOption}
                                    onChange={(e) => setNewOption(e.target.value)}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            handleAddOption();
                                        }
                                    }}
                                    ref={newOptionRef}
                                />
                                <Button size="icon" onClick={handleAddOption}>
                                    <Plus className="h-4 w-4" />
                                </Button>
                            </div>

                            {/* Draggable List */}
                            <DndContext
                                sensors={sensors}
                                collisionDetection={closestCenter}
                                onDragEnd={handleDragEnd}
                            >
                                <SortableContext
                                    items={(options ?? [])?.map((o) => o.id)}
                                    strategy={verticalListSortingStrategy}
                                >
                                    <div className="space-y-2">
                                        {(options ?? [])?.map((opt) => (
                                            <SortableItem
                                                key={opt.id}
                                                id={opt.id}
                                                label={opt.label}
                                                color={opt.color}
                                                onUpdate={updateOption}
                                                onDelete={deleteOption}
                                                defaultColors={defaultColors}
                                                isDisabled={opt.is_disabled === "1"}
                                            />
                                        ))}
                                    </div>
                                </SortableContext>
                            </DndContext>
                        </>
                    )} {/* Multi-select Options */}

                    {/* Status Options */}
                    {selectedType === "status_val" && (
                        <div className="space-y-4">
                            <div className="flex items-center gap-2">
                                <Input
                                    placeholder="New status"
                                    value={newOption}
                                    onChange={(e) => setNewOption(e.target.value)}
                                />
                                <Button size="icon" onClick={handleAddOption}>
                                    <Plus className="h-4 w-4" />
                                </Button>
                            </div>
                            <div className="space-y-3">
                                {options.map((opt, idx) => (
                                    <div
                                        key={idx}
                                        className="flex items-center gap-2 border p-2 rounded-md bg-muted"
                                    >
                                        <div className="h-3 w-3 rounded-full bg-green-500" />
                                        <span className="text-sm">{opt.label}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </SheetContent>
            </Sheet>
        </>
    );
}
