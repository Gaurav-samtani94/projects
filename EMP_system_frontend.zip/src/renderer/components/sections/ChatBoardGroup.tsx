import { ChartNoAxesGantt, CornerUpRight } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from "renderer/components/ui/avatar";
import { Popover, PopoverTrigger, PopoverContent } from "renderer/components/ui/popover";
import { useNavigate, useOutletContext } from 'react-router-dom';
import useAuthStore from 'renderer/store/AuthStore';
import moment from "moment";
import { useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import { useMutation } from '@tanstack/react-query';
import { ChatGroup_history } from 'renderer/service/authService';
import BaseUrl from 'renderer/service/BaseUrl';
import { useChatStore, usePageStore } from 'stores/useChatStore';
import ForwardGroup from './ForwardGroup';
import ChatController from 'renderer/Controller/ChatController';
import { useParticipants } from '@livekit/components-react';

const { App } = window


interface ReplyToFrom {
    id: string;
    sender_name: string;
    original_msg: Message;
}
interface ForwardedFrom {
    sender_name: string;
    original_msg: Message;
}

interface Message {
    id: string;
    sender: string;
    text: string | null;
    file: string | null;
    sender_id: string;
    delivered_at: string;
    replyTo?: ReplyToFrom;
    msg_id: string;
    forwardMessage?: string | null;
    forwardedFrom?: ForwardedFrom;
    isForward?: boolean;
    chat_type: string;
    start_time: any;
    end_time: any;
    duration: any;
    call_type: string
}

type ReplyContextType = {
    replyMessage: any;
    setReplyMessage: (msg: any) => void;
};
type ForwardContextType = {
    forwardMessage: any;
    setForwardMessage: (msg: any) => void;
};
export const useReplyOutlet = () => useOutletContext<ReplyContextType>();
export const useForwardOutlet = () => useOutletContext<ForwardContextType>();

const ChatBoardGroup = () => {
    // alert("hello")
    const { chatInfo, selectGroupCallActive } = useChatStore();
    const { messages, appendMessages } = useOutletContext<{
        messages: Message[],
        appendMessages: (newMessages: Message[]) => void
    }>();
    const navigator = useNavigate()
    const { setPageCount } = usePageStore();
    const [hasmore, sethasmore] = useState<boolean | null>(true);
    const { selectedUser } = useOutletContext<{ selectedUser: any }>();
    const [isLoading, setIsLoading] = useState(true)
    const [page_count, setPage_count] = useState(1)
    const { room } = useOutletContext<{ room: any }>();
    const ResUser = useAuthStore.getState().getUser();
    const messageEndRef = useRef<HTMLDivElement | null>(null);
    const messageRefs = useRef<{ [key: string]: HTMLDivElement | null }>({});
    const [open, setOpen] = useState<string | null>(null);
    const [openself, setOpenself] = useState<string | null>(null);
    const [UserTypeingName, setUserTypeingName] = useState('');
    const [isTypeing, setIsTypeing] = useState(false);
    const { setReplyMessage } = useReplyOutlet();
    const { setForwardMessage } = useForwardOutlet();
    const scrollContainerRef = useRef<HTMLDivElement | null>(null);
    const [isAtBottom, setIsAtBottom] = useState(true);

    useEffect(() => {
        messageEndRef.current?.scrollIntoView({ behavior: 'instant' });
    }, [messages]);

    useEffect(() => {
        if (isAtBottom) {
            messageEndRef.current?.scrollIntoView({ behavior: 'instant' });
        }
    }, [messages, isTypeing]);



    useEffect(() => {
        joinGroupChat()

        const handleTypingStatusNotification = (UserInfo: any) => {
            const { userId, isTyping, name, type, GroupId } = UserInfo?.data || {};
            if (type !== 'group') return;
            if (isTyping) {
                if (GroupId === chatInfo.groupId) {
                    if (userId !== ResUser?.id) {
                        setUserTypeingName(name);
                        setIsTypeing(true);

                    } else {
                        setIsTypeing(false);
                    }
                }
            }
            else {
                setIsTypeing(false);
            }
        };
        const socket = ChatController.getSocket();
        if (!socket) {
            return;
        }
        socket.on("typingStatus", handleTypingStatusNotification)
        return () => {
            socket.off("typingStatus", handleTypingStatusNotification)
        };
    }, [chatInfo.groupId, ResUser?.id]);

    // ChatController.callbackSocket('sendMessage', data)

    const joinGroupChat = () => {
        const data = {
            userId: Number(ResUser?.id),
            groupId: chatInfo.groupId,
        }
        ChatController.callbackSocket('joinGroupChat', data)
    }


    useEffect(() => {
        if (messages.length === 0) {
            setIsLoading(true);
            const timer = setTimeout(() => {
                setIsLoading(false);
            }, 1500);

            return () => clearTimeout(timer);
            // biome-ignore lint/style/noUselessElse: <explanation>
        } else {
            setIsLoading(false);
        }
    }, [messages]);


    useEffect(() => {
        const container = scrollContainerRef.current;
        if (!container) return;

        const handleScroll = () => {
            const isBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 50;
            setIsAtBottom(isBottom);
            if (container.scrollTop === 0 && !isLoading && hasmore) {
                setPage_count(prev => prev + 1);
                setPageCount(page_count + 1);
            }
        };

        container.addEventListener('scroll', handleScroll);
        return () => {
            container.removeEventListener('scroll', handleScroll);
        };
    }, [isLoading, hasmore]);


    useEffect(() => {
        if (!chatInfo?.groupId) return;
        if (page_count > 1) { getForward_historys(chatInfo.groupId, String(page_count), '10'); }
    }, [page_count]);

    useEffect(() => {
        setPage_count(1);
        sethasmore(true);
    }, [chatInfo?.groupId]);

    const getForward_historys = (group_id: any, page_number: any, limit: any) => {
        getChatGroup_history.mutate({ group_id, page_number, limit });
    };


    const getChatGroup_history = useMutation({
        mutationFn: ChatGroup_history,
        onSuccess: response => {
            if (response?.pagination?.total_messages > messages.length) {
                sethasmore(true);
            } else {
                sethasmore(false);
            }
            if (response?.data?.length > 0) {
                const formattedMessages = response.data.map((msg: any) => ({
                    sender: msg.sender?.firstname ?? "Unknown",
                    sender_id: String(msg.sender_id ?? ""),
                    text: msg.text ?? msg.file_name?.split('_').slice(1).join('_'),
                    delivered_at: msg.delivered_at ?? msg.createdAt,
                    file: msg.text ? "" : msg.file_name ? `${BaseUrl.Url_Base}/${msg.file_path}/${msg.file_name}` : "",
                    msg_id: String(msg?.id),
                    reply_to_id: msg?.reply_to_id || null,
                    replyTo: msg?.replyTo || null,
                    forwardedFrom: msg.forwardedFrom || null,
                    start_time: msg.start_time || null,
                    end_time: msg.end_time || null,
                    duration: msg.duration || null,
                    chat_type: msg.chat_type || null,
                    call_type: msg.call_type || null

                }));
                appendMessages(formattedMessages);
            }

        },
        onError: error => {
            console.error('Error fetching chat history:', error);
        },
    })

    const handleDownload = (url: string | null) => {
        if (!url) {
            console.warn("No URL provided for download.");
            return;
        }

        try {
            const filename = url?.split('/').pop();
            if (!filename) {
                return;
            }
            App.downloadFile(url, filename);

            App.onDownloadComplete((_event, data) => {
                if (data.success) {
                    toast.success("File downloaded!");
                } else {
                    toast.error("Download failed.");
                }
            });

        } catch (error) {
        }
    };


    const scrollToMessage = (id: string) => {
        setTimeout(() => {
            const el = messageRefs.current[id];
            if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else {
            }
        }, 100);
    };

    const ReplyPreview = ({ reply, }: { reply: any, }) => {
        return (
            // biome-ignore lint/a11y/useKeyWithClickEvents: <explanation>
            <div className="mb-2 border-l-4 border-blue-500 pl-2 text-sm text-gray-600 dark:text-gray-300"
                onClick={() => scrollToMessage(reply.id)}
            >
                {reply.text ? (
                    <div className="truncate">{reply?.text}</div>
                ) : reply.file_name ? (
                    <div className="italic text-xs text-gray-500 truncate">
                        📎 {reply.file_name.startsWith('data:') ? '[Image/File Attachment]' : reply.file_name?.split('/').pop()}
                    </div>
                ) : null}
            </div>
        );
    };

    const ForwardedPreview = ({ forward }: { forward: any }) => {
        return (
            <div className="flex items-center gap-1 text-xs text-gray-500 italic mb-1">
                <CornerUpRight className="w-4 h-4" />
                Forwarded
            </div>
        );
    };

    const Openfun = () => {
        navigator('/chat')
        setOpen(null)
    }
    const OpenFunself = () => {
        setOpenself(null)
    }
    const getCallDuration = (callStartTime: string | Date, callEndTime: string | Date) => {
        if (!callStartTime || !callEndTime) return null;

        // Ensure both are Date objects
        const start = typeof callStartTime === "string" ? new Date(callStartTime) : callStartTime;
        const end = typeof callEndTime === "string" ? new Date(callEndTime) : callEndTime;

        const durationMs = end.getTime() - start.getTime();
        const minutes = Math.floor(durationMs / 60000);
        const seconds = Math.floor((durationMs % 60000) / 1000);
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    };

    return (
        <>
            {isLoading && messages.length === 0 ? (
                <div className="flex flex-col justify-center items-center h-full py-10 space-y-2">
                    {/* biome-ignore lint/style/useSelfClosingElements: <explanation> */}
                    <div className="w-8 h-8 border-4 border-gray-300 border-t-blue-500 rounded-full animate-spin"></div>
                    <span className="text-sm text-gray-500 dark:text-gray-400">Loading messages...</span>
                </div>
            ) : messages.length > 0 ? (
                <div ref={scrollContainerRef} className='flex flex-col gap-3 p-4 overflow-y-auto h-full'>
                    {messages?.map((msg, index) => (
                        <div key={msg.msg_id} >
                            {String(msg.sender_id) !== String(ResUser?.id) ?
                                <div className='flex justify-start'>
                                    <div
                                        className="flex items-start gap-2.5">
                                        <Avatar>
                                            <AvatarImage src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y" />
                                        </Avatar>

                                        <div key={msg?.msg_id}
                                            ref={(el) => {
                                                if (el) {
                                                    messageRefs.current[msg?.msg_id] = el;
                                                } else {
                                                    delete messageRefs.current[msg?.msg_id];
                                                }
                                            }} className="flex flex-col w-full max-w-[320px] leading-1.5 p-4 border-gray-200 bg-gray-100 rounded-e-xl rounded-es-xl dark:bg-gray-700">
                                            <div className="flex items-center min-w-0  space-x-2 rtl:space-x-reverse">
                                                <span className="text-sm font-semibold text-gray-900 dark:text-white">{msg.sender}</span>
                                                <span className="text-sm font-normal text-gray-500 dark:text-gray-400">{msg.chat_type === 'call' ? moment(msg.end_time ? msg.end_time : msg.start_time).format("hh:mm A") : moment(msg.delivered_at).format("hh:mm A")}</span>
                                            </div>
                                            {msg.replyTo && <ReplyPreview reply={msg.replyTo} />}
                                            {msg.forwardedFrom && <ForwardedPreview forward={msg.forwardedFrom} />}
                                            {msg.file && (
                                                <div className="group relative my-2.5">
                                                    {msg.file.startsWith('data:image/') || msg.file.match(/\.(png|jpe?g)$/i) ? (
                                                        <>
                                                            <div className="absolute w-full h-full bg-gray-900/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-center justify-center">
                                                                <button onClick={() => handleDownload(msg.file)} data-tooltip-target="download-image" className="inline-flex items-center justify-center rounded-full h-10 w-10 bg-white/30 hover:bg-white/50 focus:ring-4 focus:outline-none dark:text-white focus:ring-gray-50">
                                                                    <svg className="w-5 h-5 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 18">
                                                                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 1v11m0 0 4-4m-4 4L4 8m11 4v3a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-3" />
                                                                    </svg>
                                                                </button>
                                                                <div id="download-image" role="tooltip" className="absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-xs opacity-0 tooltip dark:bg-gray-700">
                                                                    Download image
                                                                </div>
                                                            </div>
                                                            <img src={msg.file} className="rounded-lg" alt="File preview" />
                                                        </>
                                                    ) : (
                                                        <div>
                                                            <div className="p-4 bg-gray-900/50 absolute w-full h-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-center justify-center">
                                                                <div className="text-center">
                                                                    <button onClick={() => handleDownload(msg.file)} data-tooltip-target="download-image" className="inline-flex items-center justify-center rounded-full h-10 w-10 bg-white/30 hover:bg-white/50 focus:ring-4 focus:outline-none dark:text-white focus:ring-gray-50">
                                                                        <svg className="w-5 h-5 text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 18">
                                                                            <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 1v11m0 0 4-4m-4 4L4 8m11 4v3a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-3" />
                                                                        </svg>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                            <svg className="w-12 h-16 mx-auto text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                                            </svg>
                                                        </div>
                                                    )}
                                                </div>
                                            )}
                                            {msg.chat_type === 'call' &&
                                                <div className="text-sm font-normal text-gray-500 dark:text-gray-400 py-2.5">
                                                    {msg?.call_type === "0" ? 'voice ' : 'video '} call {msg.end_time ? `${getCallDuration(msg.start_time, msg.end_time ? msg.end_time : msg.start_time)}` : "started"}
                                                </div>
                                            }

                                            <p className="text-sm font-normal py-2.5 text-gray-900 dark:text-white">{msg.text}</p>
                                        </div>
                                        {msg.chat_type !== 'call' &&
                                            <Popover open={open === msg.msg_id}
                                                onOpenChange={(isOpen) => {
                                                    setOpen(isOpen ? msg.msg_id : null)
                                                }
                                                }
                                            >
                                                <PopoverTrigger className='self-center'>
                                                    <ChartNoAxesGantt />
                                                </PopoverTrigger>
                                                <PopoverContent className='p-0' align='start'>
                                                    <ul className="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdownMenuIconButton">
                                                        <li>
                                                            {/* biome-ignore lint/a11y/useKeyWithClickEvents: <explanation> */}
                                                            <div onClick={() => { setReplyMessage(msg) }} className="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Reply</div>
                                                        </li>
                                                        <li>

                                                            {/* biome-ignore lint/a11y/useKeyWithClickEvents: <explanation> */}
                                                            <div onClick={() => { setForwardMessage(msg); }} className="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                                                <ForwardGroup chat_type={'Group'} msg_id={msg.msg_id} room={room} forwardSendMassage={msg} openFun={() => { Openfun() }} OlduserSelect={selectedUser} />
                                                            </div>
                                                        </li>
                                                        {/* <li>
                                                            <div className="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Delete</div>
                                                        </li> */}
                                                    </ul>
                                                </PopoverContent>
                                            </Popover>}
                                    </div>


                                </div>
                                :
                                <div>
                                    <div className='flex justify-end'>
                                        <div className="flex items-start gap-2.5">
                                            <Avatar>
                                                <AvatarImage src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y" alt="Alice Johnson" />
                                                <AvatarFallback>Alice Johnson</AvatarFallback>
                                            </Avatar>
                                            <div className="flex flex-col gap-1">
                                                <div key={msg?.msg_id}
                                                    ref={(el) => {
                                                        if (el) {
                                                            messageRefs.current[msg?.msg_id] = el;
                                                        } else {
                                                            delete messageRefs.current[msg?.msg_id];
                                                        }
                                                    }}
                                                    className="flex flex-col w-full max-w-[320px] leading-1.5 p-4 border-gray-200 bg-gray-100 rounded-e-xl rounded-es-xl dark:bg-gray-700">
                                                    <div className="flex items-center space-x-2 rtl:space-x-reverse mb-2">
                                                        <span className="text-sm font-semibold text-gray-900 dark:text-white">You</span>
                                                        <span className="text-sm font-normal text-gray-500 dark:text-gray-400">{msg.chat_type === 'call' ? moment(msg.end_time ? msg.end_time : msg.start_time).format("hh:mm A") : moment(msg.delivered_at).format("hh:mm A")}</span>
                                                    </div>
                                                    {msg.replyTo && <ReplyPreview reply={msg.replyTo} />}
                                                    {msg.forwardedFrom && <ForwardedPreview forward={msg.forwardedFrom} />}
                                                    {msg.file && (
                                                        <div className="group relative my-2.5">
                                                            {msg.file.startsWith('data:image/') || msg.file.match(/\.(png|jpe?g)$/i) ? (
                                                                <>
                                                                    <div className="absolute w-full h-full bg-gray-900/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-center justify-center">
                                                                    </div>
                                                                    <img src={msg.file} alt="preview" className="rounded-lg" />
                                                                </>
                                                            ) : (
                                                                <div className="flex items-center justify-center p-4 bg-gray-100 rounded-lg">
                                                                    <div className="absolute w-full h-full bg-gray-900/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-lg flex items-center justify-center">
                                                                    </div>
                                                                    <div className="text-center">
                                                                        <svg className="w-18 h-18 mx-auto text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                                                        </svg>
                                                                    </div>
                                                                </div>
                                                            )}
                                                        </div>
                                                    )}

                                                    {msg.chat_type === 'call' &&
                                                        <div className="text-sm font-normal text-gray-500 dark:text-gray-400 py-2.5">
                                                            {msg?.call_type === "0" ? 'voice ' : 'video '} call {msg.end_time ? `${getCallDuration(msg.start_time, msg.end_time)}` : "started"}
                                                        </div>
                                                    }
                                                    <p className="text-sm font-normal py-2.5 text-gray-900 dark:text-white">{msg.text}</p>
                                                </div>
                                            </div>
                                            {msg.chat_type !== 'call' &&
                                                <Popover open={openself === msg.msg_id}
                                                    onOpenChange={(isOpen) => {
                                                        setOpenself(isOpen ? msg.msg_id : null)
                                                    }
                                                    }>
                                                    <PopoverTrigger className='self-center'>
                                                        <ChartNoAxesGantt />
                                                    </PopoverTrigger>
                                                    <PopoverContent className='p-0' align='end'>
                                                        <ul className="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdownMenuIconButton">
                                                            <li>
                                                                {/* biome-ignore lint/a11y/useKeyWithClickEvents: <explanation> */}
                                                                <div onClick={() => { setReplyMessage(msg); setOpenself(null) }} className="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Reply</div>
                                                            </li>
                                                            <li>
                                                                {/* biome-ignore lint/a11y/useKeyWithClickEvents: <explanation> */}
                                                                <div onClick={() => { setForwardMessage(msg); }} className="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">
                                                                    <ForwardGroup chat_type={'Group'} msg_id={msg.msg_id} room={room} forwardSendMassage={msg} openFun={() => { OpenFunself() }} OlduserSelect={selectedUser} />
                                                                </div>
                                                            </li>
                                                            {/* <li>
                                                                <div className="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Delete</div>
                                                            </li> */}
                                                        </ul>
                                                    </PopoverContent>
                                                </Popover>}
                                        </div>
                                    </div>

                                </div>
                            }
                            <div ref={messageEndRef} />
                        </div>
                    ))}

                    {isTypeing && (
                        <div className="flex justify-start ml-1">
                            <div className="flex items-start gap-2.5">
                                <Avatar>
                                    <AvatarImage src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y" />
                                </Avatar>
                                <div className="flex flex-col gap-1">
                                    <div className="flex flex-col w-full max-w-[320px] leading-1.5 p-4 border-gray-200 bg-gray-100 rounded-e-xl rounded-es-xl dark:bg-gray-700">
                                        <span className="text-sm font-black text-gray-500 dark:text-white mb-1">
                                            {UserTypeingName} is typing...
                                        </span>
                                        <div className="w-10 h-3 mt-2 flex items-center space-x-1">
                                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div >

            ) : (
                <>

                    {isTypeing ?
                        <div className="flex justify-start items-end h-full py-10">
                            <div className="flex items-start">
                                <Avatar>
                                    <AvatarImage src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y" />
                                </Avatar>
                                <div className="flex flex-col gap-1">
                                    <div className="flex flex-col w-full max-w-[320px] leading-1.5 p-4 border-gray-200 bg-gray-100 rounded-e-xl rounded-es-xl dark:bg-gray-700">
                                        <span className="text-sm font-black text-gray-500 dark:text-white mb-1">
                                            {UserTypeingName} is typing...
                                        </span>
                                        <div className="w-10 h-3 mt-2 flex items-center space-x-1">
                                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        :
                        <div className="flex justify-center items-center h-full py-10">
                            <span className="text-sm text-gray-500 dark:text-gray-400">No messages yet.</span>
                        </div>}
                </>

            )}


        </>
    )
}

export default ChatBoardGroup