import React, { useEffect, useMemo, useRef, useState } from 'react'
import {
    BoldItalicUnderlineToggles,
    headingsPlugin,
    linkDialogPlugin,
    listsPlugin,
    ListsToggle,
    markdownShortcutPlugin,
    MDXEditor,
    quotePlugin,
    Separator,
    thematicBreakPlugin,
    toolbarPlugin,
    UndoRedo
} from "@mdxeditor/editor";
import '@mdxeditor/editor/style.css'
import { MoreVertical, Smile, ThumbsUp, Trash, Edit, Link, Reply, Cross, X } from 'lucide-react';
import { Button } from '../ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import ChatController from 'renderer/Controller/ChatController';
import { useMutation, useQuery } from '@tanstack/react-query';
import { deleteProjectComments, deleteTaskComments, getCommentList, getProjectComments, updateProjectsComments, updateTaskComments } from 'renderer/service/project';
import moment from 'moment';
import { toast } from 'sonner';
import useAuthStore from 'renderer/store/AuthStore';

const emojis = ["😀", "😂", "😍", "😎", "😭", "👍", "🎉"];

type TASKDATA = {
    taskData?: any
    projectDetail?: any
    users?: any
}

export default function CommentSection({ taskData, projectDetail, users }: TASKDATA) {
    const [tempValue, setTempValue] = useState('');
    const [parentCommentId, setParentCommentId] = useState<any>()
    const [replyValue, setReplyValue] = useState<string>("")
    const [isEdit, setIsEdit] = useState<any>(false)
    const editorRef = useRef<any>(null);

    console.log("replyValue", replyValue)

    const { data: commentList, refetch: refetchCommentList } = useQuery({
        queryKey: ['commentList', taskData?.row?.id],
        queryFn: async () => {
            try {
                return await getCommentList({ task_id: taskData?.row?.id });
            } catch (error) {
                if ((error as any)?.response?.status === 404) {
                    return { data: [] };
                }
            }
        },
        enabled: !!taskData?.row?.id,
    })

    const { data: projectList, refetch: refetchProjectList } = useQuery({
        queryKey: ['projectComments', projectDetail?.id],
        queryFn: async () => {
            try {
                return await getProjectComments({ project_id: projectDetail?.id });
            } catch (error) {
                if ((error as any)?.response?.status === 404) {
                    return { data: [] };
                }
            }
        },
        enabled: !!projectDetail?.id,
    })

    const comments = taskData?.row?.id ? commentList?.data : projectList?.data;
    const refetch = taskData?.row?.id ? refetchCommentList : refetchProjectList;
    const isTaskComment = !!taskData?.row?.id;

    return (
        <div className="w-full mx-auto space-y-4">
            <CommentBox replyValue={replyValue} setReplyValue={setReplyValue} taskItem={taskData} refetch={refetch} setTempValue={setTempValue} tempValue={tempValue} editorRef={editorRef} parentCommentId={parentCommentId} isEdit={isEdit} setIsEdit={setIsEdit} projectDetail={projectDetail} users={users} setParentCommentId={setParentCommentId} />
            {comments?.map((comment: any) => (
                <CommentItem key={comment.id} comment={comment} setTempValue={setTempValue} editorRef={editorRef} setParentCommentId={setParentCommentId} refetch={refetch} setIsEdit={setIsEdit} isTaskComment={isTaskComment} projectDetail={projectDetail} tempValue={tempValue} parentCommentId={parentCommentId} taskItem={taskData} setReplyValue={(v) => setReplyValue(v)} />
            ))}
        </div>
    );
}

// Comment Input Box
const CommentBox = ({ taskItem, refetch, tempValue, setTempValue, editorRef, parentCommentId, isEdit, setIsEdit, projectDetail, users, setParentCommentId, replyValue, setReplyValue }: any) => {
    const user = useAuthStore.getState().getUser();
    const [mentionOpen, setMentionOpen] = useState(false);
    const [mentionQuery, setMentionQuery] = useState('');
    const [mentionPosition, setMentionPosition] = useState({ top: 0, left: 0 });
    const [pingUserIds, setPingUserIds] = useState<number[]>([]);

    useEffect(() => {
        if (!isEdit) {
            setTempValue('');
            editorRef?.current?.setMarkdown?.('');
            setParentCommentId(0);
        }
        const handleTaskComment = (data: any) => {
            if (taskItem?.row?.id == data?.task_id) {
                refetch();
            }
        };

        const handleProjectComment = (data: any) => {
            if (projectDetail?.id == data?.project_id) {
                refetch();
            }
        };

        const socket = ChatController.getSocket();
        if (!socket) {
            return;
        }

        socket.on(`${taskItem?.row?.id}`, handleTaskComment);
        socket.on(`${projectDetail?.id}`, handleProjectComment);

        return () => {
            socket.off(`${taskItem?.row?.id}`, handleTaskComment);
            socket.off(`${projectDetail?.id}`, handleProjectComment);
        };
    }, [taskItem?.row?.id, projectDetail?.id]);

    useEffect(() => {
        if (isEdit) {
            editorRef?.current?.setMarkdown?.(tempValue || '')
        }
    }, [isEdit, tempValue]);

    const handleSubmitComment = () => {
        if (taskItem) {
            if (isEdit) {
                const commentData = {
                    task_id: taskItem?.row?.id,
                    parent_comment_id: parentCommentId ?? 0,
                    comment_text: tempValue,
                    ping_users_ids: pingUserIds?.map((it: any) => it).join(','),
                    project_id: taskItem?.row?.project_id,
                    parent_task_id: taskItem?.row?.parent_id,
                    from_user_id: taskItem?.row?.creater?.id,
                    isUpdate: '1',
                    comment_id: parentCommentId
                };
                ChatController.callbackSocket("task_comment", commentData);
                setTempValue('')
                setParentCommentId(0)
                editorRef?.current?.setMarkdown?.('');
                setIsEdit(false)
            } else {
                const commentData = {
                    task_id: taskItem?.row?.id,
                    parent_comment_id: parentCommentId ?? 0,
                    comment_text: tempValue,
                    ping_users_ids: pingUserIds?.map((it: any) => it).join(','),
                    project_id: taskItem?.row?.project_id,
                    parent_task_id: taskItem?.row?.parent_id,
                    from_user_id: taskItem?.row?.creater?.id,
                };
                ChatController.callbackSocket("task_comment", commentData);
                setTempValue('')
                editorRef?.current?.setMarkdown?.('');
            }
        } else {
            if (isEdit) {
                const commentData = {
                    parent_proj_cmnt_id: parentCommentId ?? 0,
                    comment_text: tempValue,
                    ping_users_ids: pingUserIds?.map((it: any) => it).join(','),
                    project_id: projectDetail?.id,
                    from_user_id: user?.id,
                    comment_id: parentCommentId,
                    isUpdate: '1'
                };
                ChatController.callbackSocket("project_comment", commentData);
                setTempValue('')
                setParentCommentId(0)
                editorRef?.current?.setMarkdown?.('');
                setIsEdit(false)
            } else {
                const commentData = {
                    parent_proj_cmnt_id: parentCommentId ?? 0,
                    comment_text: tempValue,
                    ping_users_ids: pingUserIds?.map((it: any) => it).join(','),
                    project_id: projectDetail?.id,
                    from_user_id: user?.id,
                };
                ChatController.callbackSocket("project_comment", commentData);
                setTempValue('')
                editorRef?.current?.setMarkdown?.('');
            }
        }
        setReplyValue('')
        setParentCommentId(null)
        setTempValue('')
    }

    const handleEditorChange = (value: string) => {
        setTempValue(value);

        const match = value.match(/@([\w]*)$/);
        if (match) {
            setMentionQuery(match[1]);
            setMentionOpen(true);

            const selection = window.getSelection();
            if (selection?.rangeCount) {
                const range = selection.getRangeAt(0).cloneRange();
                const rect = range.getBoundingClientRect();
                setMentionPosition({ top: rect.bottom + window.scrollY, left: rect.left + window.scrollX });
            }
        } else {
            setMentionOpen(false);
        }
    };

    const handleMentionClick = (user: any) => {
        const newText = tempValue?.replace(/@[\w]*$/, `@${user.userfullname} `);
        setTempValue(newText);
        setMentionOpen(false);
        setMentionQuery('');
        setPingUserIds(prev => prev.includes(user?.id) ? prev : [...prev, user?.id]);

        editorRef.current?.setMarkdown?.(newText);
    };

    const teamUserIds = projectDetail?.team?.user_ids?.split(",")?.map((id: any) => parseInt(id?.trim()));

    const filteredUsers = users?.filter((user: any) =>
        teamUserIds?.includes(user?.id) &&
        user?.userfullname?.toLowerCase()?.includes(mentionQuery?.toLowerCase())
    );

    return (
        <div className="mb-4">
            {replyValue && (
                <div className='flex items-center justify-between my-2'>
                    <div className="flex items-center gap-2 ">
                        <span className="text-sm text-gray-500">{isEdit ? "Editing" : "Replying To"}:</span>
                        <span className="font-semibold">{replyValue}</span>
                    </div>
                    <Button onClick={() => {
                        setReplyValue('')
                        setParentCommentId(null)
                        setTempValue('')
                    }} size={'icon'}><X /></Button>
                </div>
            )}

            <MDXEditor
                ref={editorRef}
                markdown={tempValue}
                onChange={handleEditorChange}
                placeholder="Write a comment..."
                className="border rounded-lg prose-sm md:prose max-w-full editor-content"
                contentEditableClassName="overflow-y-auto py-2 whitespace-normal text-start"
                plugins={[
                    toolbarPlugin({
                        toolbarContents: () => (
                            <div className={'flex gap-1'}>
                                <UndoRedo />
                                <ListsToggle />
                                <Separator />
                                <div className={'hidden md:flex gap-1'}>
                                    <BoldItalicUnderlineToggles />
                                </div>
                            </div>
                        )
                    }),
                    headingsPlugin(),
                    listsPlugin(),
                    quotePlugin(),
                    thematicBreakPlugin(),
                    markdownShortcutPlugin(),
                    linkDialogPlugin(),
                ]}
            />
            {mentionOpen && filteredUsers?.length > 0 && (
                <ul
                    className="absolute z-50 bg-white border border-gray-300 rounded-md shadow-md"
                // style={{ top: mentionPosition.top + 5, left: mentionPosition.left }}
                >
                    {filteredUsers?.map((user: any) => (
                        <li
                            key={user.id}
                            className="px-4 py-2 cursor-pointer hover:bg-gray-100"
                            onClick={() => handleMentionClick(user)}
                        >
                            {user?.userfullname}
                        </li>
                    ))}
                </ul>
            )
            }
            <Button className="mt-4" type="button" onClick={() => handleSubmitComment()}>Submit</Button>
        </div >
    );
};

// Single Comment Item
const CommentItem = ({ comment, setTempValue, editorRef, setParentCommentId, refetch, setIsEdit, isTaskComment, parentCommentId, projectDetail, taskItem, setReplyValue }: any) => {
    const [menuOpen, setMenuOpen] = useState(false);
    const [message, setMessage] = useState("");
    const user = useAuthStore.getState().getUser();
    const renderCommentText = (text: string) => {
        const mentionRegex = /@(\w+)/g;
        const parts = text.split(mentionRegex).map((part, index) => {
            if (index % 2 === 1) {
                return (
                    <span key={index} className="font-bold text-blue-600">
                        @{part}
                    </span>
                );
            }
            return part;
        });
        return parts;
    };
    const handleReplyClick = (action: string) => {
        if (action === "edit") {
            setIsEdit(true)
        } else {
            setIsEdit(false)
        }
        setReplyValue(comment?.comment_text)
        setTempValue(comment?.comment_text);
        setParentCommentId(comment?.id)
        setTimeout(() => {
            editorRef?.current?.focus?.();
        }, 100);
    };

    // const deleteTaskCommentMutation = useMutation({
    //     mutationFn: deleteTaskComments,
    //     onSuccess: response => {
    //         if (response) {
    //             toast.success(response?.message)
    //             refetch()
    //         }

    //     },
    //     onError: error => {
    //         toast.error(error?.message)
    //     }
    // })
    // const deleteProjectCommentMutation = useMutation({
    //     mutationFn: deleteProjectComments,
    //     onSuccess: response => {
    //         if (response) {
    //             toast.success(response?.message)
    //             refetch()
    //         }

    //     },
    //     onError: error => {
    //         toast.error(error?.message)
    //     }
    // })

    const handleDeleteComments = () => {
        if (isTaskComment) {
            const commentData = {
                task_id: taskItem?.row?.id,
                parent_comment_id: parentCommentId ?? 0,
                comment_text: comment?.comment_text,
                ping_users_ids: '',
                project_id: taskItem?.row?.project_id,
                parent_task_id: taskItem?.row?.parent_id,
                from_user_id: taskItem?.row?.creater?.id,
                isDeleted: '1',
                comment_id: comment?.id
            };
            ChatController.callbackSocket("task_comment", commentData);
        } else {
            const commentData = {
                parent_proj_cmnt_id: parentCommentId ?? 0,
                comment_text: comment?.comment_text,
                ping_users_ids: '',
                project_id: projectDetail?.id,
                from_user_id: user?.id,
                isDeleted: '1',
                comment_id: comment?.id
            };
            ChatController.callbackSocket("project_comment", commentData);
        }
    }

    return (
        <div className="border p-3 rounded-lg shadow-sm">
            <div className="flex justify-between">
                <span className="font-semibold">{comment?.comment_by?.userfullname}</span>
                <div className="relative">
                    <Button variant={"outline"} type='button' onClick={() => setMenuOpen(!menuOpen)}>
                        <MoreVertical size={18} />
                    </Button>
                    {menuOpen && (
                        <div className="absolute right-0 mt-1 w-28 bg-white border rounded-md shadow-md">
                            <div className="w-full px-3 py-1 text-left hover:bg-gray-100 flex items-center gap-2" onClick={() => { handleReplyClick("edit"); setMenuOpen(false) }}>
                                <Edit size={14} /> Edit
                            </div>
                            <div className="w-full px-3 py-1 text-left text-red-600 hover:bg-gray-100 flex items-center gap-2" onClick={() => handleDeleteComments()}>
                                <Trash size={14} /> Delete
                            </div>
                        </div>
                    )}
                </div>
            </div>

            <p className="text-sm text-gray-700 mt-1">{renderCommentText(comment?.comment_text)}</p>
            <div className="flex items-center gap-3 text-sm text-gray-500 mt-2">
                {/* Emoji Picker */}
                <Popover>
                    <PopoverTrigger asChild>
                        <Button variant={"outline"} size="icon">
                            <Smile className="text-gray-600" size={20} />
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="flex gap-2 p-2 bg-white shadow-md rounded-md">
                        {emojis.map((emoji, index) => (
                            <button
                                key={index}
                                className="text-xl hover:scale-110 transition"
                                onClick={() => setMessage(message + emoji)}
                            >
                                {emoji}
                            </button>
                        ))}
                    </PopoverContent>
                </Popover>
                <Button size="sm" onClick={() => handleReplyClick("reply")} type='button'>Reply</Button>
                <span>• {moment(comment?.created_at).fromNow()}</span>
            </div>

            {/* Replies Section */}
            {comment?.childComment && (
                <div className="ml-6 mt-3 space-y-2">
                    {comment?.childComment?.map((reply: any) => (
                        <CommentItem key={reply.id} comment={reply} isTaskComment={isTaskComment} refetch={refetch} projectDetail={projectDetail} taskItem={taskItem} editorRef={editorRef} setParentCommentId={setParentCommentId} setTempValue={setTempValue} setIsEdit={setIsEdit} setReplyValue={(v) => setReplyValue(v)} />
                    ))}
                </div>
            )}
        </div>
    );
};
