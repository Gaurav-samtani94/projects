import React from "react";
import { Avatar, AvatarFallback, AvatarImage } from 'renderer/components/ui/avatar'
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from "renderer/components/ui/popover"

interface Member {
    id: string | number;
    userfullname: string;
}

interface DynamicAvatarGroupProps {
    membersList: Member[];
    selectedUsers: (string | number)[];
}

const DynamicAvatarGroup: React.FC<DynamicAvatarGroupProps> = ({ membersList, selectedUsers }) => {
    const selectedMembers = membersList?.filter(member => selectedUsers?.includes(member.id));

    return (
        <div className="flex items-center space-x-[-12px]">
            {selectedMembers?.slice(0, 2).map((member) => (
                <Avatar key={member.id} className="size-10">
                    <AvatarImage src="" alt={member.userfullname} />
                    <AvatarFallback>{member.userfullname[0]?.toUpperCase()}</AvatarFallback>
                </Avatar>
            ))}

            {selectedMembers?.length > 2 && (
                <Popover>
                    <PopoverTrigger asChild>
                        <button type="button">
                            <Avatar className="size-10 cursor-pointer">
                                <AvatarFallback className="text-sm font-semibold">
                                    +{selectedMembers?.length - 2}
                                </AvatarFallback>
                            </Avatar>
                        </button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto text-sm font-medium">
                        <ul>
                            {selectedMembers?.map((member) => (
                                <li key={member.id} className="flex gap-2 items-center mb-3">
                                    <Avatar className="size-10">
                                        <AvatarImage src="" alt={member?.userfullname} />
                                        <AvatarFallback>{member?.userfullname[0]?.toUpperCase()}</AvatarFallback>
                                    </Avatar>
                                    {member?.userfullname}
                                </li>
                            ))}
                        </ul>
                    </PopoverContent>
                </Popover>
            )}
        </div>
    );
};

export default DynamicAvatarGroup;
