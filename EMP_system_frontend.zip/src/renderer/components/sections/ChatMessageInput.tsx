import { useEffect, useState } from "react";
import { Input } from "renderer/components/ui/input";
import { Button } from "renderer/components/ui/button";
import { Paperclip, Send, Smile } from "lucide-react";
import { Popover, PopoverTrigger, PopoverContent } from "renderer/components/ui/popover";
import ChatController from "renderer/Controller/ChatController";
import useAuthStore from "renderer/store/AuthStore";
import { SaveFiles, SaveMassage } from "renderer/service/authService";
import { toast } from "sonner";

const emojis = ["😀", "😂", "😍", "😎", "😭", "👍", "🎉"];



export default function ChatMessageInput({ room, HandleMassage, selectedUser, chatInfo, replyMessage, setReplyMessage, forwardMessage, setForwardMessage }: any) {
    const [inputMessage, setInputMessage] = useState('');
    const CHUNK_SIZE = 60 * 1024;
    const MAX_FILE_SIZE = 50 * 1024 * 1024;
    const ResUser = useAuthStore.getState().getUser();


    useEffect(() => {
        if (selectedUser) {
            setInputMessage('');
        }
    }, [selectedUser]);

    const sendMessage = async () => {
        if (room.state === 'disconnected') {
            toast.error("Please reconnect to the room");
            return;
        }
        const ResUser = useAuthStore.getState().getUser();
        if (!inputMessage.trim()) return;
        const isReply = !!replyMessage;
        const isForward = !!forwardMessage;
        if (!ResUser?.id) {
            return;
        }
        const SendMassage = {
            sender_id: ResUser?.id,
            text: inputMessage,
            chat_id: chatInfo?.id ?? "",
            reply_to_id: isReply ? String(replyMessage?.msg_id) : "",
        };
        const SendMassageResponse = await SaveMassage(SendMassage);

        try {
            // Emit socket message
            ChatController.callbackSocket('sendMessage', {
                receiverId: selectedUser.id,
                message: inputMessage,
                name: ResUser?.firstname,
                sender_Id: ResUser?.id,
                isReply,
                isForward,
                chat_id: '',
                chat_type: 'User',
                groupId: '',
                groupName: ''
            });

            handleUploadBefor(SendMassageResponse?.data?.id)

            // SaveMassageMutationChat(inputMessage, isReply, isForward);
            setReplyMessage(null);
            setForwardMessage(null);
            ChatController.callbackSocket('stop-typing', { userId: ResUser?.id, isTyping: false, name: ResUser?.firstname, type: 'user' })
        } catch (error) {
        }
    };

    const SaveMassageMutationChat = async (inputMessage: any, isReply: any, isForward: any) => {
        if (!ResUser || !ResUser.id) {
            return;
        }
        // SaveMassageMutation.mutate({
        //     sender_id: ResUser?.id,
        //     text: inputMessage,
        //     chat_id: chatInfo?.id ?? "",
        //     reply_to_id: replyMessage?.msg_id,
        // });
    }

    // const SaveMassageMutation = useMutation({
    //     mutationFn: SaveMassage,
    //     onSuccess: response => {
    //         handleUploadBefor(response.data.id)

    //     },
    //     onError: error => {

    //     },
    // })

    const handleUploadBefor = async (id: any) => {
        const isReply = !!replyMessage;
        const isForward = !!forwardMessage;

        const messagePayload = {
            id: id,
            text: inputMessage,
            sender_id: ResUser?.id,
            toUser: selectedUser?.id,
            file: null,
            isReply,
            isForward,
            replyTo: isReply ? replyMessage : null,
            delivered_at: new Date().toISOString(),
            sender: room.localParticipant.identity,
            chat_type: 'User',
            forwardedFrom: isForward ? {
                sender_name: forwardMessage.sender,
                original_msg: forwardMessage,
            } : undefined,
        };

        const messageData = JSON.stringify(messagePayload);

        await room?.localParticipant.publishData(
            new TextEncoder().encode(messageData)
        );

        HandleMassage({
            id: id,
            sender: "You",
            type: 'user',
            sender_id: String(ResUser?.id),
            toUser: String(selectedUser?.id),
            text: inputMessage,
            file: null,
            delivered_at: new Date().toISOString(),
            msg_id: String(Date.now()), // or generate unique ID
            replyTo: isReply ? replyMessage : null,
            isForward,
            isReply,
            replyMessage: inputMessage,
            chat_type: 'User',
            forwardMessage: isForward ? forwardMessage.text : null,
            forwardedFrom: isForward ? {
                sender_name: forwardMessage.sender,
                original_msg: forwardMessage,
            } : undefined,
        });
        setInputMessage("");
        ChatController.callbackSocket('stop-typing', { userId: ResUser?.id, isTyping: false, name: ResUser?.firstname, type: 'user' })

    }



    const sendFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
        if (room.state === 'disconnected') {
            toast.error("Please reconnect to the room");
            return;
        }
        if (!event.target.files || event.target.files.length === 0) return;
        const file = event.target.files[0];
        const createRoomPayload = {
            sender_id: ResUser?.id ?? "",
            file: file,
            chat_id: chatInfo?.id ?? "",
            reply_to_id: String(replyMessage?.msg_id),
        };

        const roomResponse = await SaveFiles(createRoomPayload);
        const reader = new FileReader();
        if (file.size > MAX_FILE_SIZE) {
            alert("File exceeds 50MB limit!");
            return;
        }
        reader.onload = async (e) => {
            if (!e.target?.result) return;
            const fileData = e.target.result as string;
            const fileId = `${file.name}-${Date.now()}`;
            const totalChunks = Math.ceil(fileData.length / CHUNK_SIZE);

            for (let i = 0; i < totalChunks; i++) {
                const chunk = await fileData.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);
                const isLastChunk = i === totalChunks - 1;
                const chunkData = await JSON.stringify({
                    isChunk: true,
                    fileId,
                    fileName: file.name,
                    toUser: selectedUser?.id,
                    sender_id: String(ResUser?.id),
                    chunk,
                    isLast: i === totalChunks - 1,
                    chat_type: 'User',
                    id: roomResponse.data.id,
                });

                try {
                    await room?.localParticipant.publishData(
                        new TextEncoder().encode(chunkData),
                    );

                    if (isLastChunk) {
                        const isReply = !!replyMessage;
                        const isForward = !!forwardMessage;
                        HandleMassage({
                            id: roomResponse.data.id,
                            sender: "You",
                            type: 'user',
                            sender_id: String(ResUser?.id),
                            replyTo: isReply ? replyMessage : null,
                            isReply,
                            replyMessage: inputMessage,
                            text: `${file.name}`,
                            file: fileData,
                            fileName: file.name,
                            delivered_at: new Date().toISOString()
                        });
                        setInputMessage("");
                        const data = {
                            sender_Id: String(ResUser?.id),
                            receiverId: Number(selectedUser.id),
                            message: 'Image/files',
                            name: ResUser?.firstname,
                            isReply,
                            isForward,
                            chat_id: '',
                            chat_type: 'User',
                            groupId: '',
                            groupName: ''
                        }
                        ChatController.callbackSocket('sendMessage', data)

                    }
                } catch (error) {
                    return;
                }
            }
        };

        reader.readAsDataURL(file);
    };



    return (
        <div>
            {replyMessage && (<div className="flex items-start justify-between px-4 py-2 bg-blue-50 border-l-4 border-green-500 text-sm text-gray-800">
                <div className="flex-1">
                    <div className="font-semibold text-green-500">Replying to</div>
                    <div className="truncate max-w-[800px]">{replyMessage?.text}</div>
                </div>
                <button
                    className="text-gray-500 hover:text-gray-700"
                    onClick={() => setReplyMessage(null)}
                >
                    ✕
                </button>
            </div>)}
            <div className="w-full flex items-center gap-2 p-4 border-t border-b">
                {/* Attachment Button */}
                <input
                    type="file"
                    id="fileInput"
                    onChange={sendFile}
                    style={{ display: "none" }}
                />
                <Button variant="ghost" size="icon" onClick={() => document.getElementById("fileInput")?.click()}>
                    <Paperclip className="text-gray-600" size={20} />
                </Button>

                {/* Emoji Picker */}
                <Popover>
                    <PopoverTrigger asChild>
                        <Button variant="ghost" size="icon">
                            <Smile className="text-gray-600" size={20} />
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent className="flex gap-2 p-2 bg-white shadow-md rounded-md">
                        {emojis.map((emoji, index) => (
                            <button
                                key={index}
                                className="text-xl hover:scale-110 transition"
                                onClick={() => { setInputMessage(inputMessage + emoji); ChatController.callbackSocket('typing', { userId: String(ResUser?.id), isTyping: true, name: ResUser?.userfullname, }) }}
                            >
                                {emoji}
                            </button>
                        ))}
                    </PopoverContent>
                </Popover>

                {/* Message Input */}
                <Input
                    value={inputMessage}
                    onChange={(e) => { setInputMessage(e.target.value); ChatController.callbackSocket('typing', { userId: ResUser?.id, isTyping: true, name: ResUser?.firstname, SenderId: selectedUser.id, type: 'user' }) }}
                    placeholder="Type a message..."
                    className="flex-1 rounded-lg"
                    onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                />

                {/* Send Button */}
                <Button onClick={sendMessage} size="icon">
                    <Send className="text-white" size={20} />
                </Button>
            </div>
        </div>
    );
}
