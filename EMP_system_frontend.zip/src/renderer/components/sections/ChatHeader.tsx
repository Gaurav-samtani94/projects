import { Avatar, AvatarImage, AvatarFallback } from "renderer/components/ui/avatar";
import { Button } from "renderer/components/ui/button";
import { Dot, Phone, Video } from "lucide-react";
import { cn } from "renderer/lib/utils";
import { Sheet, SheetContent, SheetTrigger } from "../ui/sheet";
import { useNavigate } from "react-router-dom";
import ChatController from "renderer/Controller/ChatController";
import useAuthStore from "renderer/store/AuthStore";
import { useEffect, useState } from "react";


const user = {
    name: "Alice Johnson",
    department: "Sales",
    online: true,
};

interface ChatHeaderProps {
    selectedUser: {
        firstname: string;
        lastname: string;
        userfullname: string;
        position_name: string;
        id: number;
        emailaddress: string;
    } | null;
    selectedToken: string | undefined;
    room: any;
    isAudioCall: any;
    chatInfo: any;

}


export default function ChatHeader({ room, selectedUser, selectedToken, isAudioCall, chatInfo }: ChatHeaderProps) {
    const navigate = useNavigate();
    const ResUser = useAuthStore.getState().getUser();
    const [status, setStatus] = useState<string[]>([]); // or number[] if IDs are numbers

    useEffect(() => {
        SocketHandle()
    }, [selectedUser]);


    const SocketHandle = async () => {
        let socket: any;
        const handleuserStatusNotification = async (data: any) => {
            console.log('data', data)
            setStatus(data);
        };

        const setupListeners = () => {
            socket = ChatController.getSocket();
            if (!socket) return;
            socket.on("online-users", handleuserStatusNotification)
            ChatController.callbackSocket('userStatus', {
                userId: Number(ResUser?.id),
                chat_status: "online",
                status: 1
            });
        };
        const cleanupListeners = () => {
            if (!socket) return;
            socket.off("online-users", handleuserStatusNotification)
        };

        const waitForSocketReady = () => {
            return new Promise<void>((resolve) => {
                if (ChatController.isSocketConnected === 1) return resolve();

                const interval = setInterval(() => {
                    if (ChatController.isSocketConnected === 1) {
                        clearInterval(interval);
                        resolve();
                    }
                }, 300);
            });
        };
        await waitForSocketReady();
        setupListeners();
        return () => {
            cleanupListeners();

        };
    }




    const HandleStart = () => {
        if (!isAudioCall) {
            const data = {
                receiverId: String(selectedUser?.id),
                callType: 'audio',
                name: ResUser?.firstname,
                roomname: '',
                token: '',
                chat_type: 'User',
                groupId: '',
                senderId: ResUser?.id

            }
            ChatController.callbackSocket('callUser', data)
            navigate('/connect/AudioMeeting', { state: { token: selectedToken, selectedUser: data, screenType: 'ChatHeader' } })
            // const RoomName = `${room?.roomInfo?.name}-audio`;
            // AudioCall_User(selectedUser, RoomName)
        }


    }

    const handleVideoCall = () => {
        const data = {
            receiverId: String(selectedUser?.id),
            callType: 'video',
            name: ResUser?.firstname,
            chat_type: 'User',
            groupId: '',
            senderId: ResUser?.id


        }
        ChatController.callbackSocket('callUser', data)
        navigate('/connect/RoomMeeting', { state: { token: selectedToken, selectedUser: data } })
    }

    return (
        <div className="w-full flex items-center justify-between bg-secondary p-4 border-b border-t">
            <Sheet>
                <SheetTrigger>
                    <div className="flex items-center gap-3">
                        <Avatar>
                            <AvatarImage src={'https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y'} alt={user.name} />
                            <AvatarFallback>{user.name[0]}</AvatarFallback>
                        </Avatar>
                        <div className="text-left">
                            <h2 className="text-md font-semibold">{`${selectedUser?.firstname} ${selectedUser?.lastname ?? ''}`}</h2>
                            <p className="text-xs text-gray-500">{selectedUser?.position_name}</p>

                        </div>

                        <Dot className={cn("ml-2", status?.includes(String(selectedUser?.id)) ? "text-green-500" : "text-gray-400")} />
                    </div>

                </SheetTrigger>
                <SheetContent className="w-[90%] sm:w-[540px] pt-16 px-4">
                    <div className="relative">
                        <Avatar className="w-20 h-20">
                            <AvatarImage src="https://flowbite.com/application-ui/demo/images/users/" alt={user.name} />
                            <AvatarFallback>{selectedUser?.userfullname}</AvatarFallback>
                        </Avatar>
                        <h4 className="text-3xl text-black">{`${selectedUser?.firstname} ${selectedUser?.lastname ?? ''}`}</h4>
                        <p className="text-base text-gray-500">{selectedUser?.emailaddress}</p>
                        <p className="text-base text-gray-500">{selectedUser?.position_name}</p>
                        <div className="mt-4 w-full">
                            <div className="flex gap-2">
                                <Button variant="outline" onClick={() => HandleStart()}>
                                    <Phone className="text-accent-foreground" size={20} />
                                    Voice Call
                                </Button>
                                <Button variant="outline" onClick={() => navigate('/connect/RoomMeeting', { state: { token: selectedToken } })}>
                                    <Video className="text-accent-foreground" size={20} />
                                    Video Call
                                </Button>
                            </div>
                        </div>
                    </div>
                </SheetContent>
            </Sheet>

            {/* Call Buttons */}
            <div className="flex gap-2">
                <Button variant="ghost" size="icon" onClick={() => { HandleStart(); }}>
                    <Phone className="text-accent-foreground" size={20} />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => { handleVideoCall() }}>
                    <Video className="text-accent-foreground" size={20} />
                </Button>
            </div>
        </div >
    );
}
