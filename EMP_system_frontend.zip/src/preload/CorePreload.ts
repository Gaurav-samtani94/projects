import { desktopCapturer, ipcRenderer } from 'electron'
ipcRenderer.setMaxListeners(20); // or a higher number

export const coreWindowPreload = {
    minimize: () => ipcRenderer.send('window-minimize'),
    maximize: () => ipcRenderer.send('window-maximize'),
    close: () => ipcRenderer.send('window-close'),
    goBack: () => ipcRenderer.send('window-go-back'),
    goForward: () => ipcRenderer.send('window-go-forward'),
    toggleDevTools: () => ipcRenderer.send('window-toggle-devtools'),
    activity: () => ipcRenderer.invoke('window-activity'),
    activityLog: () => ipcRenderer.invoke('activity-log'),
    systemLog: () => ipcRenderer.invoke('system-log'),
    startWatching: () => ipcRenderer.invoke('start-monitoring'),
    clearAllActivity: () => ipcRenderer.invoke('clear-activity-log'),
    stopWatching: () => ipcRenderer.invoke('stop-monitoring'),
    isTracking: () => ipcRenderer.invoke('is-tracking'),
    currentActivity: (call: any) => ipcRenderer.on('currentActivity', call),
    currentStatus: (call: any) => ipcRenderer.on('systemStatus', call),
    clearCurrentListener: () => ipcRenderer.removeListener('currentActivity', () => { }),
    clearSystemListener: () => ipcRenderer.removeListener('systemStatus', () => { }),
    showNotification: (title: any, body: string) =>
        ipcRenderer.send('show-notification', { title, body }),
    messageNotification: (title: any, body: string) =>
        ipcRenderer.send('message-notification', { title, body }),
    meetingNotification: (title: any, body: string) =>
        ipcRenderer.send('meeting-notification', { title, body }),
    downloadFile: (url: string, filename: string) => {
        ipcRenderer.send('download-file', { url, filename })
    },
    onNotificationClick: (callback: any) => {
        ipcRenderer.on("notification-clicked", (_event, route) => {
            callback(route);
        });
    },
    onDownloadComplete: (callback: (event: any, data: any) => void) => {
        ipcRenderer.once('download-complete', callback)
    },

}
