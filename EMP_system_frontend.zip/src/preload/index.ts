import { contextBridge } from 'electron'
import { coreWindowPreload } from './CorePreload'
declare global {
  interface Window {
    App: typeof API
  }
}

const API = {
  sayHelloFromBridge: () => console.log('\nHello from bridgeAPI! 👋\n\n'),
  username: process.env.USER,
  ...coreWindowPreload, // Expose the core window functions
}

contextBridge.exposeInMainWorld('App', API)

import './CorePreload'
