export const loadStore = async () => {
  const { default: ElectronStore } = await import('electron-store');
  return new ElectronStore();
};

export const setStoreData = async (key: string, value: any) => {
  const store = await loadStore();
  store.set(key, value);
};

export const getStoreData = async <T>(key: string, defaultValue?: T): Promise<T> => {
  const store = await loadStore();
  return store.get(key, defaultValue) as T;
};

export const deleteStoreData = async (key: string) => {
  const store = await loadStore();
  store.delete(key);
};
