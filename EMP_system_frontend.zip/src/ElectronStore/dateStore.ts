import { getStoreData, setStoreData } from "./store";

interface DateStore {
    date: string;
}


export async function setDateStore(date: DateStore) {
    await setStoreData('date', date);
}

export async function getDateStore(): Promise<DateStore> {
    const date = await getStoreData('date', { date: new Date().toISOString() });
    return date;
}

export async function clearDateStore() {
    await setStoreData('date', '');
}