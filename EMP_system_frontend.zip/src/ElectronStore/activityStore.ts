import { getDateStore } from "./dateStore";
import { getStoreData, setStoreData } from "./store";

type Activity = {
    id: number;
    title: string;
    owner: string;
    path: string;
    start_time: string;
    end_time: string | null;
};

type SystemLog = {
    id: number;
    status: string;
    start_time: string;
    end_time: string | null;
}

export async function addActivityLog(entry: Activity) {
    const oldDate = await getDateStore();
    if (new Date(oldDate.date).toDateString() === new Date().toDateString()) {
        const oldLog: Activity[] = await getStoreData('activityLog', []);
        oldLog.push(entry);
        await setStoreData('activityLog', oldLog)
        return 'append';
        // biome-ignore lint/style/noUselessElse: <explanation>
    } else {
        await setStoreData('date', { date: new Date().toISOString() });
        await setStoreData('activityLog', [entry]);
        return 'new';
    }
}

export async function getActivityLog(): Promise<Activity[]> {
    return await getStoreData('activityLog', []);
}

export async function clearActivityLog() {
    await setStoreData('activityLog', []);
    await setStoreData('date', { date: '' });
    await setStoreData('systemLog', {});
}
export async function clearSystemLog() {
    await setStoreData('systemLog', []);
}

// export async function addSystemLog(entry: SystemLog) {

//     const oldDate = await getDateStore();
//     console.log('Old date:', oldDate.date);
//     console.log('New date:', new Date().toISOString());
//     const oneDayEarlier = new Date();
//     oneDayEarlier.setDate(oneDayEarlier.getDate() - 1);
//     if (new Date(oldDate.date).toDateString() === new Date().toDateString()) {
//         const oldLog: SystemLog[] = await getStoreData('systemLog', []);
//         console.log('Adding system log:', oldLog);
//         oldLog.push(entry);
//         await setStoreData('date', { date: oneDayEarlier.toISOString() });
//         await setStoreData('systemLog', oldLog)
//         return 'append';
//         // biome-ignore lint/style/noUselessElse: <explanation>
//     } else {
//         //    const newLog = [{ entry, logDate: new Date().toDateString() }];
//         await setStoreData('systemLog', [entry]);
//         await setStoreData('date', { date: new Date().toISOString() });
//         return 'new';
//     }

// }


type SystemLogData = {
    id: number;
    status: 'online' | 'idle' | 'offline';
    start_time: string;
    end_time: string | null;
    date: string;
};

interface LogEntry {
    logDate: { date: string };
    entries: SystemLogData[];
}

interface SystemStore {
    date: string,
    data: SystemLogData[]
}

export async function updateSystemStatusArray(entry: SystemLogData) {
    // const oldDate = await getDateStore();
    // console.log("datas", oldDate.date, new Date().toISOString());
    const formattedDate = new Date().toLocaleDateString('en-US');   //the date format is MM/DD/YYYY
    const oldLog: SystemStore = await getStoreData('systemLog');
    if (oldLog?.date === formattedDate) {
        // const logEntry = oldLog.find((log: any) => log?.logDate.date === formattedDate);
        oldLog?.data.push(entry);
        await setStoreData('systemLog', oldLog);
        console.log('Adding system log:', oldLog);
        return oldLog.data;
        // biome-ignore lint/style/noUselessElse: <explanation>
    } else {
        const newLog = {
            date: formattedDate,
            data: [entry]
        };
        await setStoreData('systemLog', newLog);
        console.log('Replaced system log:', newLog);

        return newLog.data;
    }
}


export async function getSystemLog(): Promise<SystemLog[]> {
    const oldLog: SystemStore = await getStoreData('systemLog');
    return oldLog.data || [];
}