import { getStoreData, setStoreData } from "./store";



interface TrackButton {
    status: boolean;
}



export async function trackButtonStore(entry: TrackButton) {
    await setStoreData('trackButton', entry);
}


export async function getTrackButton(): Promise<TrackButton> {
    const trackButton = await getStoreData('trackButton', { status: false });
    return trackButton;
}