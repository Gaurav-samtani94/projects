<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Script extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->helper(array('form', 'url'));
        $this->load->library('session', 'form_validation');
        $this->load->model('Mastermodel', 'mastermodel');
        $this->load->model('appraisalonproject/Appraisalonproject_model', 'assignappronproj');

        if ($this->session->userdata('loginid') == "") {
            redirect(base_url('admin'));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
            
        } else {
            redirect(base_url(""));
        }

        $this->appr_mmyy = '04-2024';
        $this->appr_fullmmyy = 'April 2024';
    }
    public function get_all_apprisal_data()
    {
        $this->db->select('c.fld_id,c.current_status,a.reporting_manager,a.reporting_manager_name,b.employeeId,b.emailaddress,b.department_name,b.position_name,b.jobtitle_name');
        $this->db->from("main_employees_summary as a");
        $this->db->join("main_employees_summary as b", "a.reporting_manager=b.user_id", "LEFT");
        $this->db->join("appr_proj_assignbyhr as c", "(c.rep_manager_id=a.reporting_manager AND c.appr_session='04-2022')", "LEFT");
        $this->db->where(array("a.isactive" => "1", "a.businessunit_id" => "3"));
        $this->db->group_by('a.reporting_manager');
        $list =  $this->db->get()->result();
        $ab =0;
        ?>
      
        <table class="table table-striped">
        <tr>
    <th></th>
    <th></th>
    <th>Sr.No</th>
    <th>Emp. Name</th>
    <th>Emp. ID</th>
    <th>RO Name</th>
    <th>Designation</th>
    <th>Appraisal Due Date</th>
    <th>IO Name</th>
    <th>IO EMP ID</th>
</tr><?php
$i=0;
        foreach($list as $keys=>$empRow)
        {
            // print_R($empRow);
            // die();
            $CurrStatusArr = array("1" => "<small style='color:#667eea'>Assigned</small>",
            "2" => "<small>Assigned</small>",
            "3" => "<small>Filled & Locked</small>",
            "4" => "<small> Approved </small>",
            "5" => "<small> Rejected </small>");

      ?>
           <!-- <tr>

           </tr> -->
           <!-- <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>

             <td></td>

             <td></td>
           </tr>
           <tr>
            <th>Sr.No</th>
            <th>IO Emp. Name</th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
           </tr>
            <tr>
                <td><?php//= $ab + 1 ?></td>
                <td><?php//= $empRow->reporting_manager_name ?></td>
                <td><?php //= $empRow->employeeId;?></td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
               
            </tr> -->

    <?php
    // die();
    //  Code Start For Script
    $this->db->select("a.userfullname,a.employeeId,a.position_name,c.userfullname as ro_userfullname,d.appraisalduedate");
    $this->db->from("main_employees_summary as a");
    $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
    $this->db->join("main_employees_summary as c", "b.reviewing_officer_ro=c.user_id", "LEFT");
    $this->db->join("main_empsalarydetails as d", "a.user_id=d.user_id", "LEFT");
    $this->db->where(["a.reporting_manager" => $empRow->reporting_manager, "a.isactive" => "1","d.appraisalduedate"=>"April 2023"]);
    $this->db->group_by("a.user_id");
    $recordArr = $this->db->get()->result();
    // echo"<pre>";
    // print_R($recordArr);
    // die();
   //
    ?>

<!-- <p id="ioname" style="color:green"> <?//= get_ro_details_by_Id($empRow->reporting_manager); ?></p> -->

<!-- <thead> -->
<!-- <tr>
    <th></th>
    <th></th>
    <th>Sr.No</th>
    <th>Emp. Name</th>
    <th>Emp. ID</th>
    <th>RO Name</th>
    <th>Designation</th>
    <th>Appraisal Due Date</th>
    <th>IO Name</th>
    <th>IO EMP ID</th>
</tr> -->
<!-- </thead> -->
<?php
// die();

        // if ($recordArr) {
            foreach($recordArr as $key=>$recdD) {
                // print_R($recdD->appraisalduedate);
                // die();
                                    // echo "<pre>";
                                    // print_R($recdD->userfullname);
                                    // die();
                    if($recdD->appraisalduedate)
                    {
                     ?>
                        <tr>
                        <td></td>
    <td></td>
                            <td><?= $i ++; ?></td>
                            <td><?= $recdD->userfullname; ?></td>
                            <td><?= $recdD->employeeId; ?></td>
                            <td><?= $recdD->ro_userfullname; ?></td>
                            <td><?= $recdD->position_name; ?></td>
                            <td><?= ($recdD->appraisalduedate) ? $recdD->appraisalduedate : ""; ?></td>
                          <td><?=  $empRow->reporting_manager_name ?></td>
                             <td><?= $empRow->employeeId;?></td>
                        </tr>
                        <?php
                        // die();
                        // die();
                       
                    }
          
        // }
        $i++;

        $ab++;
        }

       
    }
        ?>
 <?php

    // Code End 
       ?>
    </table>
    <?php    
}
        // }

        // }
    



}