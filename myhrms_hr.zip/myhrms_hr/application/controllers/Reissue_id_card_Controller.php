<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Reissue_id_card_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Reissue_id_card_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function reissue_id_card() {
        $id = $this->session->userdata('loginid');
        if ($_REQUEST) {
            $insrtArr = array('user_id' => $id,
                'reason_reissue' => $this->input->post('reason_reissue'));
            $this->Reissue_id_card_model->InsertData($insrtArr, 'hrm_reissue_idcard');
        }
        $data['idcardDetailArr'] = $this->Reissue_id_card_model->GetDetailForidCardRecByID($id);
        $data['idcardDetailtableArr'] = $this->Reissue_id_card_model->GetDetailofappliedIdCard($id);
        $data['title'] = "Re-issue id Card";
        $this->load->view("reissue_id_card/reissue_id_card_view", $data);
    }

}
