<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Emp_exp_appraisal_list_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Empreporteduexpappraisal_model', 'emprepeduexpappraisal');
        $this->load->model('Employeereportnewjoin_model', 'empreportnewjoin');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }

    
	//11-03-2020.... Start Here .. Gaurav
    public function employee_expr_appraisal() {
        $data['error'] = array();
        $data['title'] = "ANNUAL INCREMENT RECOMMENDATION";
        $this->load->helper('url');
        $this->load->helper('form');
        $businessunit = $this->empreportnewjoin->get_list_businessunit();
        $opt = array('' => 'All Business Unit');
        foreach ($businessunit as $unit) {
            $opt[$unit] = $unit;
        }
        $companyname = $this->empreportnewjoin->get_list_companyname();
        $data['companyname'] = $companyname;
        $data['form_businessunit'] = form_dropdown('', $opt, '', 'id="businessunit_name" class="form-control"');
        $this->load->view('new_report/emp_list_eduexp_appraisal', $data);
    }

    public function ajax_list_empeduexp_appraisal() {
        $list = $this->emprepeduexpappraisal->get_datatables();
		// echo "<pre>"; print_r($list); die;
        $data = array();
        $no = $_POST['start'];
        $currdate = date('d-m-Y');
        foreach ($list as $customers) {
		$roName = get_ro_details_by_Id($customers->reviewing_officer_ro);
		$empctc = get_empctc_detail($customers->id);
		$empctc_seventeen = $this->GetCtc_seventeen($customers->id);
		$empctc_eighteen = $this->GetCtc_eighteen($customers->id);
		$emp_loyalty_bonus = $this->Get_loyaltybonus_byID($customers->id);
		$Get_ratingA = $this->Get_ratingA($customers->id);
		$Get_ratingB = $this->Get_ratingB($customers->id);
		$Get_ratingC = $this->Get_ratingB($customers->id);
		// echo "<pre>"; print_r($empctc_seventeen); die;
            $years = 0;
            $months = 0;
            $diff = 0;
            $CountCegExp = 0;
            $countOtherExp = 0;
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($customers->employeeId) ? $customers->employeeId : '';
            $row[] = ($customers->userfullname) ? $customers->userfullname : '';
            $row[] = ($customers->position_name) ? $customers->position_name : '';
            $row[] = ($customers->department_name) ? $customers->department_name : '';
            $row[] = ($customers->department_name) ? $customers->department_name : '';
            $selecteddate = ($customers->selecteddate) ? date("d-m-Y", strtotime($customers->selecteddate)) : '';
            $diff = abs(strtotime($selecteddate) - strtotime($currdate));
            $years = floor($diff / (365 * 60 * 60 * 24));
            $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
            $CountCegExp = $years . '.' . $months;
            $countOtherExp = round($this->get_total_otherexp($customers->id), 1);
            $row[] = ($customers->reporting_manager_name) ? $customers->reporting_manager_name : '';
            $row[] = $roName;
            $row[] = ($customers->date_of_joining) ? date("d-m-Y", strtotime($customers->date_of_joining)) : '';
            $row[] = ($customers->jobtitle_name) ? $customers->jobtitle_name : '';
            $row[] = $CountCegExp;
            $row[] = ($customers->years_exp) ? $customers->years_exp : 'NA';
			if($customers->years_exp == ''):
				$row[] = $CountCegExp;
			else:
				$row[] = ($CountCegExp + $customers->years_exp);
			endif;
            $row[] = ($customers->appraisalduedate) ? $customers->appraisalduedate : 'NA';
            $row[] = ($customers->institution_name) ? $customers->institution_name : '-';
            $row[] = ($customers->from_date) ? $customers->from_date : 'NA';
			if(count($emp_loyalty_bonus) != ''):
				$row[] = ($emp_loyalty_bonus->loyaltybonus) ? $emp_loyalty_bonus->loyaltybonus : 'NA';
				$row[] = ($emp_loyalty_bonus->empepf) ? $emp_loyalty_bonus->empepf : 'NA';
				$row[] = ($emp_loyalty_bonus->emp_esi) ? $emp_loyalty_bonus->emp_esi : 'NA';
				$row[] = ($emp_loyalty_bonus->medical_allowance) ? $emp_loyalty_bonus->medical_allowance : 'NA';
				$row[] = ($emp_loyalty_bonus->emp_sal_gpai) ? $emp_loyalty_bonus->emp_sal_gpai : 'NA';
				$row[] = ($emp_loyalty_bonus->emp_gratuity) ? $emp_loyalty_bonus->emp_gratuity : 'NA';
			else:
				$row[] = 'NA';
				$row[] = 'NA';
				$row[] = 'NA';
				$row[] = 'NA';
				$row[] = 'NA';
				$row[] = 'NA';
			endif;
            $row[] = ($empctc) ? number_format($empctc, 2) : '';
            $row[] = ($customers->salary) ? $customers->salary : '';
			
			if(count($empctc_eighteen) == ''):
				$row[] = 'NA';
				$row[] = 'NA';
			else:
				$row[] = ($empctc_eighteen->empctc) ? number_format($empctc_eighteen->empctc, 2) : '';
				$row[] = ($empctc_eighteen->grosssalary) ? number_format($empctc_eighteen->grosssalary, 2) : '';
			endif;
			
			if(count($empctc_seventeen) == ''):
				$row[] = 'NA';
				$row[] = 'NA';
			else:
				$row[] = ($empctc_seventeen->empctc) ? number_format($empctc_seventeen->empctc, 2) : '';
				$row[] = ($empctc_seventeen->grosssalary) ? number_format($empctc_seventeen->grosssalary, 2) : '';
			endif;
			
			if(count($Get_ratingA) == ''):
				$row[] = '';
				$row[] = '';
				$row[] = '';
			else:
				// $row[] = print_r($Get_ratingA);
				$row[] = ($Get_ratingA->perform_fact_rating) ? $Get_ratingA->perform_fact_rating : 'NA';
				$row[] = ($Get_ratingA->io_rating) ? $Get_ratingA->io_rating : 'NA';
				$row[] = ($Get_ratingA->ro_rating) ? $Get_ratingA->ro_rating : 'NA';
			endif;
			
			if(count($Get_ratingB) == ''):
				$row[] = '';
				$row[] = '';
				$row[] = '';
			else:
				// $row[] = print_r($Get_ratingB);
				$row[] = ($Get_ratingB->perform_fact_rating) ? $Get_ratingB->perform_fact_rating : 'NA';
				$row[] = ($Get_ratingB->io_rating) ? $Get_ratingB->io_rating : 'NA';
				$row[] = ($Get_ratingB->ro_rating) ? $Get_ratingB->ro_rating : 'NA';
			endif;
			
			if(count($Get_ratingC) == ''):
				$row[] = '';
				$row[] = '';
				$row[] = '';
			else:
				// $row[] = print_r($Get_ratingC);
				$row[] = ($Get_ratingC->perform_fact_rating) ? $Get_ratingC->perform_fact_rating : 'NA';
				$row[] = ($Get_ratingC->io_rating) ? $Get_ratingC->io_rating : 'NA';
				$row[] = ($Get_ratingC->ro_rating) ? $Get_ratingC->ro_rating : 'NA';
			endif;
			
            // $row[] = ($customers->ctc_seventeen) ? number_format($customers->ctc_seventeen, 2) : '';
            // $row[] = ($customers->gross_seventeen) ? number_format($customers->gross_seventeen, 2) : '';
            // $row[] = ($customers->gross_seventeen) ? number_format($customers->gross_seventeen, 2) : '';
			
            // $row[] = ($customers->self_ratingA) ? $customers->self_ratingA : '';
            // $row[] = ($customers->io_ratingA) ? $customers->io_ratingA : '';
            // $row[] = ($customers->ro_ratingA) ? $customers->ro_ratingA : '';
            // $row[] = ($customers->self_ratingB) ? $customers->self_ratingB : '';
            // $row[] = ($customers->io_ratingB) ? $customers->io_ratingB : '';
            // $row[] = ($customers->ro_ratingB) ? $customers->ro_ratingB : '';
            // $row[] = ($customers->self_ratingC) ? $customers->self_ratingC : '';
            // $row[] = ($customers->io_ratingC) ? $customers->io_ratingC : '';
            // $row[] = ($customers->ro_ratingC) ? $customers->ro_ratingC : '';
            // $row[] = ($CountCegExp + $countOtherExp);
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->emprepeduexpappraisal->count_all(),
            "recordsFiltered" => $this->emprepeduexpappraisal->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }
	
	//Get Total Exp.
    public function get_total_otherexp($empid) {
        $getmonth = 0;
        $otherExpArr = $this->mastermodel->GetTableData('main_empexperiancedetails', array('user_id' => $empid, 'isactive' => '1'));
        if ($otherExpArr):
            foreach ($otherExpArr as $recRw) {
                $getmonth += getDateDiffMonth($recRw->from_date, $recRw->to_date);
            }
            return ($getmonth > 0) ? number_format(($getmonth / 12), 2) : 0;
        else:
            return 0;
        endif;
    }
	
	//Get 2017 CTC and Gross..
    public function Get_loyaltybonus_byID($id) {
        $arr = array('user_id' => $id, 'isactive' => '1');
        $this->db->SELECT('loyaltybonus,empepf,emp_esi,medical_allowance,emp_sal_gpai,emp_gratuity');
        $this->db->from('main_empsal_increment');
        $this->db->where($arr);
        $this->db->where("appraisal_datemmyy LIKE '%2019%'");
        $this->db->order_by("id", "DESC");
        // $this->db->limit("1");
        $result = $this->db->get()->row();
        return $result;
    }
	
	//Get 2017 CTC and Gross..
    public function GetCtc_seventeen($id) {
        $arr = array('user_id' => $id, 'isactive' => '1');
        $this->db->SELECT('empctc,grosssalary');
        $this->db->from('main_empsal_increment');
        $this->db->where($arr);
        $this->db->where("appraisal_datemmyy LIKE '%2017%'");
        $this->db->order_by("id", "DESC");
        // $this->db->limit("1");
        $result = $this->db->get()->row();
        return $result;
    }
	
	//Get 2018 CTC EMpid Wise...
    public function GetCtc_eighteen($id) {
        $arr = array('user_id' => $id, 'isactive' => '1');
        $this->db->SELECT('empctc,grosssalary');
        $this->db->from('main_empsal_increment');
        $this->db->where($arr);
        $this->db->where("appraisal_datemmyy LIKE '%2018%'");
        $this->db->order_by("id", "DESC");
        // $this->db->limit("1");
        $result = $this->db->get()->row();
        return $result;
    }
	
	//Get Self Rating A..
    public function Get_ratingA($userID) {
        //Get Total For Rep..
        $arr = array('user_id' => $userID, 'status' => '1', 'emp_self_lock' => '1','appraisal_cycle_id' => '12');
        $this->db->SELECT('fld_id');
        $this->db->from('appr_action_master');
        $this->db->where($arr);
        $resulArr = $this->db->get()->row();
		// echo "<pre>"; print_r($resulArr); die;
        //$Retarr = '';
		if(count($resulArr) != ''):
			if ($resulArr->fld_id) {
				//appr_performancefactor_master
				$this->db->SELECT('fld_id');
				$this->db->from('appr_performancefactor_master');
				$this->db->where(array("parent_id" => "1", "status" => "1", "master_group" => "1"));
				$array1 = $this->db->get()->result_array();
				$Retarr = array_map(function($value) {
					return $value['fld_id'];
				}, $array1);
				//Next Layer..
				$this->db->select_sum('a.perform_fact_rating');
				$this->db->select_sum('a.ro_rating');
				$this->db->select_sum('a.io_rating');
				$this->db->from('appr_performfactor as a');
				$this->db->where_in("perform_fact_masterid",$Retarr);
				$this->db->where(array("a.emp_id" => $userID, "a.appr_parent_id" => $resulArr->fld_id, "a.status" => "1"));
				$RecorArrData = $this->db->get()->row();
			}
			return ($RecorArrData) ? $RecorArrData : false;
		
		endif;
			
    }
	
	 //Get Self Rating A..
    public function Get_ratingB($userID) {
        //Get Total For Rep..
        $arr = array('user_id' => $userID, 'status' => '1', 'emp_self_lock' => '1');
        $this->db->SELECT('fld_id');
        $this->db->from('appr_action_master');
        $this->db->where($arr);
        $resulArr = $this->db->get()->row();
        //$Retarr = '';
		if(count($resulArr) != ''):
			if ($resulArr->fld_id) {
				//appr_performancefactor_master
				$this->db->SELECT('fld_id');
				$this->db->from('appr_performancefactor_master');
				$this->db->where(array("parent_id" => "2", "status" => "1", "master_group" => "1"));
				$array1 = $this->db->get()->result_array();
				$Retarr = array_map(function($value) {
					return $value['fld_id'];
				}, $array1);
				//Next Layer..
				$this->db->select_sum('a.perform_fact_rating');
				$this->db->select_sum('a.ro_rating');
				 $this->db->select_sum('a.io_rating');
				$this->db->from('appr_performfactor as a');
				$this->db->where_in("perform_fact_masterid",$Retarr);
				$this->db->where(array("a.emp_id" => $userID, "a.appr_parent_id" => $resulArr->fld_id, "a.status" => "1"));
				$RecorArrData = $this->db->get()->row();
			}
			return ($RecorArrData) ? $RecorArrData : false;
		
		endif;
    }
    
    
     public function Get_ratingC($userID) {
        //Get Total For Rep..
        $arr = array('user_id' => $userID, 'status' => '1', 'emp_self_lock' => '1');
        $this->db->SELECT('fld_id');
        $this->db->from('appr_action_master');
        $this->db->where($arr);
        $resulArr = $this->db->get()->row();
        //$Retarr = '';
		if(count($resulArr) != ''):
			if ($resulArr->fld_id) {
				//appr_performancefactor_master
				$this->db->SELECT('fld_id');
				$this->db->from('appr_performancefactor_master');
				$this->db->where(array("parent_id" => "3", "status" => "1", "master_group" => "1"));
				$array1 = $this->db->get()->result_array();
				$Retarr = array_map(function($value) {
					return $value['fld_id'];
				}, $array1);
				//Next Layer..
				$this->db->select_sum('a.perform_fact_rating');
				$this->db->select_sum('a.ro_rating');
				 $this->db->select_sum('a.io_rating');
				$this->db->from('appr_performfactor as a');
				$this->db->where_in("perform_fact_masterid",$Retarr);
				$this->db->where(array("a.emp_id" => $userID, "a.appr_parent_id" => $resulArr->fld_id, "a.status" => "1"));
				$RecorArrData = $this->db->get()->row();
			}
			return ($RecorArrData) ? $RecorArrData : false;
		
		endif;
    }
}
