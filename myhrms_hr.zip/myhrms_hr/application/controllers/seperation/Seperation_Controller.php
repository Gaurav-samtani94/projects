<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Seperation_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
		$this->load->model('seperation/Exitprocedures/Exitprocedures_Model');
		
        $this->load->model('seperation/Seperation_Model');
        $this->load->model('seperation/Seperationall_Model');
        $this->load->model('seperation/SeperationNotice_Model');
        $this->load->model('seperation/Resignation_Model');
        $this->load->model('seperation/Resignationleft_Model');
        $this->load->model('seperation/Severance_Model');
        $this->load->model('seperation/Demobilization_Model');
    }

    //Seperation List Controller... Report
    public function seperation_report_list() {
        $data['error'] = array();
        $data['title'] = "E-Seperation";
        $businessunit = $this->Seperation_Model->get_list_businessunit();
        $companyname = $this->Seperation_Model->get_list_companyname();
        $position = $this->Seperation_Model->get_list_designation();
        $deptname = $this->Seperation_Model->get_list_department();
	$emp_status = $this->Seperation_Model->get_list_empstatus();
        $resignation = $this->Seperation_Model->get_list_resignation();
        $data['form_businessunit'] = $businessunit;
        $data['companyname'] = $companyname;
        $data['position'] = $position;
        $data['departmentname'] = $deptname;
	$data['emp_sta'] = $emp_status;
        $data['resignation'] = $resignation;
        
        $user_id = $this->session->userdata('loginid');
        if (!is_null($user_id)) {
            $this->load->view('seperation/Seperation_Report', $data);
        } else {
            redirect('admin', true);
        }
        //$this->load->view('seperation/Seperation_Report', $data);
    }

    public function ajax_seperation_notice_list() {
        $user_id = $this->session->userdata('login');
        $list = $this->SeperationNotice_Model->get_datatables($user_id);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            //if (!empty($value->reviewing_officer_ro)) {
            // $results = $this->Seperation_Model->getUsernameByID($value->reviewing_officer_ro);
            //  $RO = isset($results[0]->userfullname) ? $results[0]->userfullname : '';
            //} else {
            //      $RO = '';
            //  }  
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
            $row[] = isset($value->exit_type) ? $value->exit_type : '';
            $row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
           // $row[] = isset($value->notice_period) ? $value->notice_period : '';
           // $row[] = date("Y-m-d", strtotime($value->relieving_date . "+$value->noticeperiod day"));
            $row[] = date("Y-m-d", strtotime($value->last_working_date));
           // $row[] = isset($value->overall_status) ? $value->overall_status : '';
            //$row[] = isset($value->l1_status) ? $value->l1_status : '';
           // $row[] = isset($value->l2_status) ? $value->l2_status : '';
            //$row[] = '<a href="#" data-toggle="modal" id="add_initiate_seperation" data-target="#add_seperation" onclick="myFunction(' . "'" . $value->user_id . "'" . ')"><li class="fa fa-edit"></li></a>';
            $data[] = $row;
            // $row[] = isset($value->reporting_manager_name) ? $value->reporting_manager_name : '';
            // $row[] = $RO;
            //$row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
            // $row[] = isset($value->date_of_joining) ? date("d-m-Y", strtotime($value->date_of_joining)) : '';
            //$row[] = isset($value->emp_status_name) ?  $value->emp_status_name : '';
            // $row[] = '<a href="#" data-toggle="modal" id="edit_seperation" data-target="#add_seperation" onclick="myFunction(' . "'" . $value->user_id . "'".')"><li class="fa fa-edit"></li></a>';
            //$data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->SeperationNotice_Model->count_all($user_id),
            "recordsFiltered" => $this->SeperationNotice_Model->count_filtered($user_id),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }
    
    public function ajax_seperation_all_list() {
        $user_id = $this->session->userdata('login');
        $list = $this->Seperationall_Model->get_datatables($user_id);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
           if (!empty($value->reviewing_officer_ro)) {
                $results = $this->Seperationall_Model->getUsernameByID($value->reviewing_officer_ro);
                $RO = isset($results[0]->userfullname) ? $results[0]->userfullname : '';
            } else {
                $RO = '';
            }
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
            $row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
            $row[] = isset($value->reporting_manager_name) ? $value->reporting_manager_name	 : '';
            $row[] = $RO;
            $row[] = isset($value->emp_status_name) ? $value->emp_status_name	 : '';
            if($value->emp_id){
                $row[] = '';
            }
            else{
              $row[] = '<a href="#" data-toggle="modal" id="add_initiate_seperation" data-target="#add_seperation" onclick="myFunction(' . "'" . $value->user_id . "'" . ')"><li class="fa fa-edit"></li></a>';
            }
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Seperationall_Model->count_all($user_id),
            "recordsFiltered" => $this->Seperationall_Model->count_filtered($user_id),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }
    
    
    public function ajax_seperation_active_list() {
        $user_id = $this->session->userdata('login');
        $list = $this->Seperation_Model->get_datatables($user_id);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
           if (!empty($value->reviewing_officer_ro)) {
                $results = $this->Seperation_Model->getUsernameByID($value->reviewing_officer_ro);
                $RO = isset($results[0]->userfullname) ? $results[0]->userfullname : '';
            } else {
                $RO = '';
            }
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
            $row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
            $row[] = isset($value->reporting_manager_name) ? $value->reporting_manager_name	 : '';
            $row[] = $RO;
            $row[] = isset($value->emp_status_name) ? $value->emp_status_name	 : '';
            $dataArr = array('190','175','173','734','2');
            if(!in_array($value->user_id, $dataArr)){
              $row[] = '<a href="#" data-toggle="modal" id="add_initiate_seperation" data-target="#add_seperation" onclick="myFunction(' . "'" . $value->user_id . "'" . ')"><li class="fa fa-edit"></li></a>';
            }
            elseif($value->emp_id){
                $row[] = '';
            }
            else{
                $row[] = '';
            }
//            else{
//              $row[] = '<a href="#" data-toggle="modal" id="add_initiate_seperation" data-target="#add_seperation" onclick="myFunction(' . "'" . $value->user_id . "'" . ')"><li class="fa fa-edit"></li></a>';
//            }
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Seperation_Model->count_all($user_id),
            "recordsFiltered" => $this->Seperation_Model->count_filtered($user_id),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }
    
    public function ajax_seperation_inactive_list() {
        $user_id = $this->session->userdata('login');
        $list = $this->Seperation_Model->get_datatables($user_id);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
           if (!empty($value->reviewing_officer_ro)) {
                $results = $this->Seperation_Model->getUsernameByID($value->reviewing_officer_ro);
                $RO = isset($results[0]->userfullname) ? $results[0]->userfullname : '';
            } else {
                $RO = '';
            }
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
            $row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
            $row[] = isset($value->reporting_manager_name) ? $value->reporting_manager_name	 : '';
            $row[] = $RO;
            $row[] = isset($value->emp_status_name) ? $value->emp_status_name	 : '';
            if($value->emp_id){
                $row[] = '';
            }
            else{
              $row[] = '<a href="#" data-toggle="modal" id="add_initiate_seperation" data-target="#add_seperation" onclick="myFunction(' . "'" . $value->user_id . "'" . ')"><li class="fa fa-edit"></li></a>';
            }
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Seperation_Model->count_all($user_id),
            "recordsFiltered" => $this->Seperation_Model->count_filtered($user_id),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }
    
//    public function ajax_seperation_notice_list() {
//        $user_id = $this->session->userdata('login');
//        $list = $this->SeperationNotice_Model->get_datatables($user_id);
//        $data = array();
//        $no = $_POST['start'];
//        foreach ($list as $value) {
//           if (!empty($value->reviewing_officer_ro)) {
//                $results = $this->SeperationNotice_Model->getUsernameByID($value->reviewing_officer_ro);
//                $RO = isset($results[0]->userfullname) ? $results[0]->userfullname : '';
//            } else {
//                $RO = '';
//            }
//            $no++;
//            $row = array();
//            $row[] = $no;
//            $row[] = isset($value->employeeId) ? $value->employeeId : '';
//            $row[] = isset($value->userfullname) ? $value->userfullname : '';
//            $row[] = isset($value->position_name) ? $value->position_name : '';
//            $row[] = isset($value->department_name) ? $value->department_name : '';
//            $row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
//            $row[] = isset($value->reporting_manager_name) ? $value->reporting_manager_name	 : '';
//            $row[] = $RO;
//            $row[] = isset($value->emp_status_name) ? $value->emp_status_name	 : '';
//            $row[] = '<a href="#" data-toggle="modal" id="add_initiate_seperation" data-target="#add_seperation" onclick="myFunction(' . "'" . $value->user_id . "'" . ')"><li class="fa fa-edit"></li></a>';
//
//            $data[] = $row;
//        }
//        $output = array(
//            "draw" => $_POST['draw'],
//            "recordsTotal" => $this->SeperationNotice_Model->count_all($user_id),
//            "recordsFiltered" => $this->SeperationNotice_Model->count_filtered($user_id),
//            "data" => $data,
//        );
//        //output to json format
//        echo json_encode($output);
//    }


    public function insert_seperation() {
        $arr = $_REQUEST;
        $data = array('emp_id' => $arr['emp_id'], 'type_of_seperation' => $arr['type_seperation'], 'resignation' => $arr['resignation'], 'other_resignation' => $arr['other_resignation'], 'resignation_and_left' => $arr['resignation-left'], 'severance' => $arr['severance'], 'other_severance' => $arr['other_severance'], 'demobilization' => $arr['demobilization'], 'early_relieving' => date('Y-m-d', strtotime($arr['early_relieving'])), 'late_relieving' => date('Y-m-d', strtotime($arr['late_relieving'])), 'notice_period' => $arr['notice_period'], 'last_working_date' => date('Y-m-d', strtotime($arr['last_working_day'])), 'actual_last_working_date' => date('Y-m-d', strtotime($arr['actual_working_day'])), 'isactive' => 1);
        $query = $this->db->get_where('main_seperation', array('emp_id' => $arr['emp_id']));

        if ($query->num_rows() > 0) {
            $this->session->set_flashdata('error', 'Record already exist');
        } else {
            $result = $this->db->insert('main_seperation', $data);
            $this->session->set_flashdata('msg', 'Initiated successfully');
        }
        redirect(base_url('seperation_report'), true);
    }

    public function update_seperation() {
        $arr = $_REQUEST;
        $data = array('type_of_seperation' => $arr['type_seperation'], 'resignation' => $arr['resignation'], 'other_resignation' => $arr['other_resignation'], 'resignation_and_left' => $arr['resignation-left'], 'severance' => $arr['severance'], 'other_severance' => $arr['other_severance'], 'demobilization' => $arr['demobilization'], 'early_relieving' => date('Y-m-d', strtotime($arr['early_relieving'])), 'late_relieving' => date('Y-m-d', strtotime($arr['late_relieving'])), 'notice_period' => $arr['notice_period'], 'last_working_date' => date('Y-m-d', strtotime($arr['last_working_day'])), 'actual_last_working_date' => date('Y-m-d', strtotime($arr['actual_working_day'])), 'isactive' => 1);
        if ($this->db->affected_rows() > 0) {
            $this->session->set_flashdata('error', 'Record already Updated');
        } else {
            $this->db->where(array('emp_id' => $arr['emp_id']));
            $result = $this->db->update('main_seperation', $data);
            $this->session->set_flashdata('msg', 'Record updated successfully');
        }
        redirect($_SERVER["HTTP_REFERER"]);
    }

    public function getDataByid() {
        $ids = $_REQUEST['id'];
		//echo $id;
		//die;
        if ($ids) {
            $this->db->select('a.*,b.noticeperiod,d.type_of_seperation,c.relieving_date');
            $this->db->from('main_employees_summary as a');
            $this->db->join('emp_otherofficial_data as b', 'b.user_id=a.user_id', 'left');
            $this->db->join('main_exit_process as c', 'c.employee_id=a.user_id', 'left');
            $this->db->join('main_seperation as d', 'd.emp_id=a.user_id', 'left');
            $this->db->where('a.user_id', $ids);
            $query = $this->db->get()->result_array();
            $res = $query[0];
            echo json_encode($res);
        }
    }

    public function getactualdate() {
        $rperday = $_REQUEST['rperday'];
        $nperday = $_REQUEST['nperday'];
        $enddate = date("Y-m-d", strtotime($rperday . "+$nperday day"));
        echo $enddate;
        exit();
    }

    public function resignation_report_list() {
        $data['title'] = 'Resignation Report';
        $data['error'] = array();
        $businessunit = $this->Resignation_Model->get_list_businessunit();
        $companyname = $this->Resignation_Model->get_list_companyname();
        $position = $this->Resignation_Model->get_list_designation();
        $deptname = $this->Resignation_Model->get_list_department();
        $resignation = $this->Seperation_Model->get_list_resignation();
        $data['resignation'] = $resignation;
        $data['form_businessunit'] = $businessunit;
        $data['companyname'] = $companyname;
        $data['position'] = $position;
        $data['departmentname'] = $deptname;
        $data['title'] = ' Resignation Report';    
        $user_id = $this->session->userdata('loginid');
        if (!is_null($user_id)) {
            $this->load->view('seperation/Resignation_Report', $data);
        } else {
            redirect('admin', true);
        }
    }

    public function ajax_resignation_list() {
        $list = $this->Resignation_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
           // $row[] = isset($value->early_relieving) ? date("d-m-Y", strtotime($value->early_relieving)) : '';
          //  $row[] = isset($value->late_relieving) ? date("d-m-Y", strtotime($value->late_relieving)) : '';
                        $row[] = isset($value->last_working_date) ? date("d-m-Y", strtotime($value->last_working_date)) : '';

            $row[] = isset($value->notice_period) ? $value->notice_period : '';
         //   $row[] = isset($value->actual_last_working_date) ? date("d-m-Y", strtotime($value->actual_last_working_date)) : '';
            $row[] = isset($value->l1_status) ? $value->l1_status : '';
            $row[] = isset($value->l2_status) ? $value->l2_status : '';
            if(($value->approve_status == '1') AND ($value->withdrawal_status == '0')){
              $row[] = '<button class="btn btn-danger" data-toggle="modal" id="add_withdrawal_new_resignation" data-target="#add_withdrawal_resignation" onclick="myWithdrawal(' . "'" . $value->emp_id . "'" . ')"><i class="fa fa-edit">Withdrawal</i></button>';
            }
            else if(($value->withdrawal_status == '1') AND ($value->approve_status == '0')){
              $row[] = '<button  data-toggle="modal" id="add_approval_new_resignation" data-target="#add_approval_resignation" onclick="myApproval(' . "'" . $value->emp_id . "'" . ')" class="btn btn-success"><i class="fa fa-edit">Approval</i></button>';
            }
            else if(($value->withdrawal_status == '1') AND ($value->approve_status == '1')){
              //$row[] = '<button  data-toggle="modal" id="add_approval_new_resignation" data-target="#add_approval_resignation" onclick="myApproval(' . "'" . $value->emp_id . "'" . ')" class="btn btn-success"><i class="fa fa-edit">Approval</i></button>';
              $row[] = '';
            }
            else {
               $row[] = '<button  data-toggle="modal" id="add_approval_new_resignation" data-target="#add_approval_resignation" onclick="myApproval(' . "'" . $value->emp_id . "'" . ')" class="btn btn-success"><i class="fa fa-edit">Approval</i></button>&nbsp;<button class="btn btn-danger" data-toggle="modal" id="add_withdrawal_new_resignation" data-target="#add_withdrawal_resignation" onclick="myWithdrawal(' . "'" . $value->emp_id . "'" . ')"><i class="fa fa-edit">Withdrawal</i></button>';
            }
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Resignation_Model->count_all(),
            "recordsFiltered" => $this->Resignation_Model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }
    
    public function add_resignation_type(){
        $user_id = $this->session->userdata('loginid');
        $Arr_resign = $this->input->post();
        $InserArr = array(
           'emp_id'=>$Arr_resign['id'],
           'type_id'=>$Arr_resign['type_id'],
           'approval_received'=>$Arr_resign['approval_received'],
           'not_accepted_reason'=>$Arr_resign['not_accepted_reason'],
           'date_of_approval'=>date('Y-m-d',strtotime($Arr_resign['approval_date'])),
           'relieving_date'=>date('Y-m-d',strtotime($Arr_resign['relieving_date'])),
           'notice_period_waived_off'=>$Arr_resign['notice_period_waived_off'],
           'approve_status'=>'1',
           'createdby'=>$user_id,
           'modifiedby'=>$user_id
         );
        $UpdateArr = array(
           'withdrawal_date'=>date('Y-m-d',strtotime($Arr_resign['withdrawal_date'])),
           'reason_for_withdrawal'=>$Arr_resign['reason_for_withdrawal'],
           'withdrawal_status'=>'1'
         );
       $check_exist = $this->db->get_where('sep_resignation', array('emp_id'=>$Arr_resign['id'])); 
       if($check_exist->num_rows()>0)
       {
           $this->db->where(array('emp_id'=>$Arr_resign['id']));
           $this->db->update('sep_resignation', $UpdateArr);
           $this->session->set_flashdata('success','Resignation Withdrawal successfully');
       }
       else{
           $this->db->insert('sep_resignation', $InserArr);
           $this->session->set_flashdata('success','Resignation Approved successfully');
       }
       redirect(base_url('resignation_report'), true);
       
    }

    public function getDataByresignationid() {
        $ids = $_POST['id'];
        if ($ids) {
//            $this->db->select('b.*,c.type_of_seperation');
//            $this->db->from('main_exit_process as a');
//            $this->db->join('main_employees_summary as b', 'b.user_id=a.employee_id', 'left');
//            $this->db->join('main_seperation as c', 'c.emp_id=a.employee_id', 'left');
//            $this->db->where('a.employee_id', $ids);
//            $query = $this->db->get()->result_array();
//            $res = $query[0];
//            echo json_encode($res);  
            $this->db->select('b.*,a.type_of_seperation');
            $this->db->from('main_seperation as a');
            $this->db->join('main_employees_summary as b', 'b.user_id=a.emp_id', 'left');
            //$this->db->join('main_seperation as c', 'c.emp_id=a.employee_id', 'left');
            $this->db->where('a.emp_id', $ids);
            $query = $this->db->get()->result_array();
            $res = $query[0];
            echo json_encode($res);   
			
        }	
    }

    public function resignation_left_report_list() {
        $data['error'] = array();
        $data['title'] = 'Resignation and Left';
        $businessunit = $this->Seperation_Model->get_list_businessunit();
        $companyname = $this->Seperation_Model->get_list_companyname();
        $position = $this->Seperation_Model->get_list_designation();
        $deptname = $this->Seperation_Model->get_list_department();
        $resignation = $this->Seperation_Model->get_list_resignation();
        $data['resignation'] = $resignation;
        $data['form_businessunit'] = $businessunit;
        $data['companyname'] = $companyname;
        $data['position'] = $position;
        $data['departmentname'] = $deptname;
        $data['title'] = ' Resignation Left Report';  
        $user_id = $this->session->userdata('user_id');
        if (!is_null($user_id)) {
            $this->load->view('seperation/Resignation_Left_Report', $data);
        } else {
            redirect('admin', true);
        }
    }

    public function ajax_resignationleft_list() {
        
		$list = $this->Resignationleft_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
            //$row[] = isset($value->early_relieving) ? date("d-m-Y", strtotime($value->early_relieving)) : '';
            //$row[] = isset($value->late_relieving) ? date("d-m-Y", strtotime($value->late_relieving)) : '';
            $row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
            //$row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
            $row[] = date('Y-m-d',strtotime("$value->noticeperiod day", strtotime('now')));
	    $row[] = isset($value->l1_status) ? $value->l1_status : '';
            $row[] = isset($value->l2_status) ? $value->l2_status : '';
	    //date("Y-m-d", strtotime(now . "+$value->noticeperiod day"));
	    //$row[] = isset($value->last_working_date) ? date("d-m-Y", strtotime($value->last_working_date)) : '';
            //$row[] = isset($value->actual_last_working_date) ? date("d-m-Y", strtotime($value->actual_last_working_date)) : '';
            $check = $this->db->get_where('sep_resignation', array('emp_id'=>$value->employee_id))->row_array();  
            if(($check['date_of_approval'] =='') AND ($check['approval_received'] =='') or ($check['not_accepted_reason'] =='') AND ($check['relieving_date'] =='') AND ($check['notice_period_waived_off	'] =='') AND ($check['withdrawal_date	'] =='') AND ($check['reason_for_withdrawal'] =='')){
                $row[] = '<a href="#" data-toggle="modal" id="add_approavl_new_resignation_left" data-target="#add_approavl_resignation_left" onclick="myApproval(' . "'" . $value->employee_id . "'" . ')" class="btn btn-success"><li class="fa fa-edit">Approved</li></a>&nbsp;<a href="#" class="btn btn-danger" data-toggle="modal" id="add_withdrawal_new_resignation_left" data-target="#add_withdrawal_resignation_left" onclick="myWithdrawal(' . "'" . $value->employee_id . "'" . ')"><li class="fa fa-edit">Withdrawal</li></a>';
            }
            else{
            $row[] = '';	
            }
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Resignationleft_Model->count_all(),
            "recordsFiltered" => $this->Resignationleft_Model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
			
    }

    public function severance_report_list() {
        $data['error'] = array();     
        $data['title'] = "Severance";
        $businessunit = $this->Severance_Model->get_list_businessunit();
        $companyname = $this->Severance_Model->get_list_companyname();
        $position = $this->Severance_Model->get_list_designation();
        $deptname = $this->Severance_Model->get_list_department();
        $resignation = $this->Seperation_Model->get_list_resignation();
        $data['resignation'] = $resignation;
        $data['form_businessunit'] = $businessunit;
        $data['companyname'] = $companyname;
        $data['position'] = $position;
        $data['departmentname'] = $deptname;
        $data['title'] = ' Severance Report';
        $user_id = $this->session->userdata('loginid');
        if (!is_null($user_id)) {
            $this->load->view('seperation/Severance_Report', $data);
        } else {
            redirect('admin', true);
        }
    }

    public function ajax_severance_list() {
        $list = $this->Severance_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
            $row[] = isset($value->early_relieving) ? date("d-m-Y", strtotime($value->early_relieving)) : '';
            $row[] = isset($value->late_relieving) ? date("d-m-Y", strtotime($value->late_relieving)) : '';
            $row[] = isset($value->notice_period) ? $value->notice_period : '';
            $row[] = isset($value->last_working_date) ? date("d-m-Y", strtotime($value->last_working_date)) : '';
            $row[] = isset($value->actual_last_working_date) ? date("d-m-Y", strtotime($value->actual_last_working_date)) : '';
            $row[] = '<a href="#" data-toggle="modal" id="add_new_severance" data-target="#add_severance" onclick="myFunction(' . "'" . $value->emp_id . "'" . ')"><li class="fa fa-edit"></li></a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Severance_Model->count_all(),
            "recordsFiltered" => $this->Severance_Model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output); 
    }
    
    public function add_severance_type(){
        $user_id  = $this->session->userdata('loginid');
        $Arr_resign = $this->input->post();
       $InserArr = array(
           'emp_id'=>$Arr_resign['id'],
           'type_id'=>$Arr_resign['type_id'],
           'cancellation_date'=>$Arr_resign['cancellation_date'],
           'reason_for_cancellation'=>$Arr_resign['reason_for_cancellation'],
           'ff_processing_date'=>$Arr_resign['ff_processing_date'],
           'actual_last_working_date'=>$Arr_resign['actual_last_working_date'],
           'ff_amount'=>$Arr_resign['ff_amount'],
           'cheque_no'=>$Arr_resign['cheque_no'],
           'bank_name'=>$Arr_resign['bank_name'],
           'exp_certificate_issue_date'=>$Arr_resign['exp_certificate_issue_date'],
           'cheque_clearing_date'=>$Arr_resign['cheque_clearing_date'],
           'eligible_for_rehire'=>$Arr_resign['eligible_for_rehire'],
           'last_working_day'=>$Arr_resign['last_working_day'],
           'notice_period_waived_off'=>$Arr_resign['notice_period_waived_off'],
           'createdby'=>$user_id,
           'modifiedby'=>$user_id,
         );
       $check_exist = $this->db->get_where('sep_severance', array('emp_id'=>$Arr_resign['id'])); 
       if($check_exist->num_rows()>0)
       {
           $this->session->set_flashdata('error','record already exist');
       }
       else{
           $this->db->insert('sep_severance', $InserArr);
           $this->session->set_flashdata('success','record added successfully');
       }
       redirect('severance_report', true);
       
    }

    public function demobilization_report_list() {
        $data['error'] = array();             
        $businessunit = $this->Demobilization_Model->get_list_businessunit();
        $companyname = $this->Demobilization_Model->get_list_companyname();
        $position = $this->Demobilization_Model->get_list_designation();
        $deptname = $this->Demobilization_Model->get_list_department();
        $resignation = $this->Seperation_Model->get_list_resignation();
        $data['resignation'] = $resignation;
        $data['form_businessunit'] = $businessunit;
        $data['companyname'] = $companyname;
        $data['position'] = $position;
        $data['departmentname'] = $deptname;
        $data['title'] = ' Demobilization Report';
        $user_id = $this->session->userdata('loginid');
        
	if (!is_null($user_id)) {
            $this->load->view('seperation/Demobilization_Report', $data);
        } else {
            redirect('admin', true);
        }	
    }

    public function ajax_demobilization_list() {
	$list = $this->Demobilization_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
            $row[] = isset($value->early_relieving) ? date("d-m-Y", strtotime($value->early_relieving)) : '';
            $row[] = isset($value->late_relieving) ? date("d-m-Y", strtotime($value->late_relieving)) : '';
            $row[] = isset($value->notice_period) ? $value->notice_period : '';
            $row[] = isset($value->last_working_date) ? date("d-m-Y", strtotime($value->last_working_date)) : '';
            $row[] = isset($value->actual_last_working_date) ? date("d-m-Y", strtotime($value->actual_last_working_date)) : '';
            $row[] = '<a href="#" data-toggle="modal" id="add_new_demobilization" data-target="#add_demobilization" onclick="myFunction(' . "'" . $value->emp_id . "'" . ')"><li class="fa fa-edit"></li></a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Demobilization_Model->count_all(),
            "recordsFiltered" => $this->Demobilization_Model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
		
    }
    
    public function add_demobilization_type(){
       $user_id  = $this->session->userdata('loginid');
       $Arr_resign = $this->input->post();
       $InserArr = array(
           'emp_id'=>$Arr_resign['id'],
           'type_id'=>$Arr_resign['type_id'],
           'extension_for_demobilization'=>$Arr_resign['extension_for_demobilization'],
           'reason_for_extension'=>$Arr_resign['reason_for_extension'],
           'date_of_extension'=>$Arr_resign['date_of_extension'],
           'extension_upto'=>$Arr_resign['extension_upto'],
           'special_comment'=>$Arr_resign['special_comment'], 
           'cancellation_date'=>$Arr_resign['cancellation_date'],
           'reason_for_cancellation'=>$Arr_resign['reason_for_cancellation'],
           'ff_processing_date'=>$Arr_resign['ff_processing_date'],
           'actual_last_working_date'=>$Arr_resign['actual_last_working_date'],
           'ff_amount'=>$Arr_resign['ff_amount'],
           'cheque_no'=>$Arr_resign['cheque_no'],
           'bank_name'=>$Arr_resign['bank_name'],
           'exp_certificate_issue_date'=>$Arr_resign['exp_certificate_issue_date'],
           'cheque_clearing_date'=>$Arr_resign['cheque_clearing_date'],
           'eligible_for_rehire'=>$Arr_resign['eligible_for_rehire'],
           'createdby'=>$user_id,
           'modifiedby'=>$user_id
         );
       $check_exist = $this->db->get_where('sep_demobilization', array('emp_id'=>$Arr_resign['id'])); 
       if($check_exist->num_rows()>0)
       {
           $this->session->set_flashdata('error','record already exist');
       }
       else{
           $this->db->insert('sep_demobilization', $InserArr);
           $this->session->set_flashdata('success','record added successfully');
       }
       redirect('demobilization_report', true);
       
    }

}
