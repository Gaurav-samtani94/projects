<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Exitprocedures_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('seperation/Exitprocedures/Exitprocedures_Model');
        $this->load->model('seperation/Exitprocedures/ExitproceduresAsIO_Model');
        $this->load->model('seperation/Exitprocedures/ExitproceduresAsRO_Model');
    }

    public function Initiate_Check_Status() {
        $user_id = $this->session->userdata('loginid');
        $data['title'] = "Initiate/Check Status";
        $data['error'] = '';
        $exit_type = $this->Exitprocedures_Model->get_list_exittype();
        $data['exit_type'] = $exit_type;
        $data['title'] = 'Initiate Check Status';
        $data['numRows'] = $this->db->get_where('main_exit_process',array("employee_id"=>$user_id))->row_array();
        $data['row_detail'] = $this->Exitprocedures_Model->GetUserdetail($user_id);
		//echo "<pre>";  print_r($data['row_detail']); echo "</pre>"; die;
        $this->load->view('seperation/Exitprocedures/InitiateCheck_Status', $data);
    }

    public function ajax_exit_process_list() {
        $list = $this->Exitprocedures_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
           // $row[] = isset($value->exit_type) ? $value->exit_type : '';
            $row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
            $row[] = isset($value->relieving_date) ? $value->relieving_date : '';
            $row[] = date("Y-m-d", strtotime($value->relieving_date . "+$value->noticeperiod day"));
            $row[] = isset($value->l1_status) ? $value->l1_status : '';
            $row[] = isset($value->hr_manager_status) ? $value->hr_manager_status : '';
            $row[] = isset($value->l2_status) ? $value->l2_status : '';
            //$row[] = '<a href="#" data-toggle="modal" id="edit_initaiate" data-target="#edit_initaiate_status" onclick="myFunction(' . "'" . $value->employee_id . "'" . ')"><li class="fa fa-edit"></li></a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Exitprocedures_Model->count_all(),
            "recordsFiltered" => $this->Exitprocedures_Model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }
    
    //code by durgesh for add initiate resign process of employee
    public function insert_employee_check_status() {
        $arr = $this->input->post();
        $emp_id = $this->session->userdata('loginid');
        $Insertdata = array('employee_id' => $emp_id, 'exit_type_id' => $arr['exit_type'], 'project_id' => $arr['exit_project_id'],'employee_comments' => $arr['each_of_comment'],'createdby'=>$this->session->userdata('user_id'),'modifiedby'=>$this->session->userdata('user_id'),'modifieddate'=>date('Y-m-d'));
        $check = $this->db->get_where('main_exit_process', array('employee_id' => $emp_id));
        $Email = $this->Exitprocedures_Model->GetRecordForEmailTemplate($emp_id);
	$from = $this->db->get_where('main_users',array('id'=>$emp_id))->row_array();
	$row_detail = $this->Exitprocedures_Model->GetUserdetail($emp_id);
	$io = $this->db->get_where('main_users', array('id'=>$row_detail['reporting_manager']))->row_array();
	$ro = $this->db->get_where('main_users', array('id'=>$row_detail['reviewing_officer_ro']))->row_array();
		
	if ($check->num_rows() > 0) {
            $this->session->set_flashdata('error', 'Record Already Exist');
        } 
        else {
            //$this->db->set('relieving_date', 'NOW()', FALSE);
            //$this->db->insert('main_exit_process', $Insertdata);
            $project_name= $this->db->get_where('tm_projects', array('id'=>$arr['exit_project_id'],'is_active'=>1))->row_array();
            $email_tem_data['Email'] = $Email;
            $email_tem_data['project_name'] = $project_name;
            $email_tem_data['arr'] = $arr;
	    $msg = $this->load->view('email_template/resign_template_email', $email_tem_data, true);
            //$recipients = array($io["emailaddress"],$ro["emailaddress"],'hr3@cegindia.com','gmhr@cegindia.com','dgmhr1@cegindia.com');
            // $recipients = array($io["emailaddress"], 'durgeshgarg32@gmail.com');
            $recipients = array('durgeshgarg32@gmail.com');
	    $to = implode(',', $recipients);
	    $this->sendMail($to,"durgeshgarg32@gmail.com", "Notice for Resignation", $msg);
            //$this->sendMail($to, $from['emailaddress'], "Notice for Resignation", $msg);
            $this->session->set_flashdata('success', 'Record Added Successfully');
        }
        redirect(base_url('initiate_check_status'), true);
    }
	
    //Code by durgesh Mail Library
    function sendMail($to, $from, $subject, $msgDetails) {
        //return true;
        $CI = & get_instance();
        $CI->load->library('email');
	$CI->email->set_mailtype("html");
        $CI->email->initialize(array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        ));
        $CI->email->from($from, 'Do_not_reply');
        $CI->email->to($to);
	//marketing@cegindia.com
	$CI->email->cc($from);
        $CI->email->bcc('marketing@cegindia.com');
        $CI->email->subject($subject);
        $CI->email->message($msgDetails);
        $resp = $CI->email->send();
        return ($resp) ? $resp : $CI->email->print_debugger();
    }
	
    // public function getDataByid() {
        // $ids = $_POST['id'];
        // if ($ids) {
            // $this->db->select('employee_id,exit_type_id,employee_comments');
            // $this->db->from('main_exit_process');
            // $this->db->where('employee_id', $ids);
            // $query = $this->db->get()->result_array();
            // $res = $query[0];
            // echo json_encode($res);
        // }
    // }

    // public function update_employee_check_status() {
        // $arr = $this->input->post();
        // $Insertdata = array('employee_id' => $arr['id'], 'exit_type_id' => $arr['exit_type'], 'employee_comments' => $arr['each_of_comment']);
        // if ($this->db->affected_rows() > 0) {
            // $this->session->set_flashdata('error', 'Record Already updated');
        // } else {
            // $this->db->set('relieving_date', 'NOW()', FALSE);
            // $this->db->update('main_exit_process', $Insertdata);
            // $this->session->set_flashdata('success', 'Record updated Successfully');
        // }
        // redirect('seperation/Exitprocedures_Controller/Initiate_Check_Status', true);
    // }

    public function Exit_Procedures_As_IO() {
        $data['error'] = array();
        $data['title'] = 'Exit Procedures As IO';
        $this->load->view('seperation/Exitprocedures/View_Exit _Procedures_As_Io', $data);
    }

    public function ajax_exit_process_as_Io_list() {
        $list = $this->ExitproceduresAsIO_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
            $row[] = isset($value->exit_type) ? $value->exit_type : '';
            $row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
            $row[] = isset($value->relieving_date) ? $value->relieving_date : '';
            $row[] = date("Y-m-d", strtotime($value->relieving_date . "+$value->noticeperiod day"));
            $row[] = isset($value->overall_status) ? $value->overall_status : '';
            $row[] = isset($value->hr_manager_status) ? $value->hr_manager_status : '';
            $row[] = isset($value->l1_status) ? $value->l1_status : '';
            $row[] = '<a href="#" data-toggle="modal" id="add_ro" data-target="#add_ro_initaiate_status" onclick="myFunction(' . "'" . $value->employee_id . "'" . ')"><li class="fa fa-edit"></li></a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->ExitproceduresAsIO_Model->count_all(),
            "recordsFiltered" => $this->ExitproceduresAsIO_Model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    public function getioDataByid() {
        $ids = $_POST['id'];
        if ($ids) {
            $this->db->select('a.employee_id,a.l1_status,a.l1_comments,b.*');
            $this->db->from('main_exit_process as a');
            $this->db->where('a.employee_id', $ids);
            $this->db->join('main_employees_summary as b','b.user_id=a.employee_id','left');
            $query = $this->db->get()->result_array();
            $res = $query[0];
            echo json_encode($res);
        }
    }

    public function update_io_check_status() {
        $arr = $this->input->post();
        $Insertdata = array('l1_status' => $arr['io_approval'], 'l1_comments' => $arr['io_of_comment']);
        $check = $this->db->get_where('main_exit_process', array('employee_id' => $$arr['id']));
        if ($check->num_rows() > 0) {
            $this->session->set_flashdata('error', 'Record Already updated');
        } else {
            $this->db->where('employee_id', $arr['id']);
            $this->db->update('main_exit_process', $Insertdata);
            $this->session->set_flashdata('success', 'Record updated Successfully');
        }
        redirect('seperation/Exitprocedures_Controller/Exit_Procedures_As_IO', true);
    }

    public function Exit_Procedures_As_RO() {
        $data['error'] = array();
        $data['title'] = 'Exit Procedures As RO';
        $this->load->view('seperation/Exitprocedures/View_Exit _Procedures_As_Ro', $data);
    }

    public function ajax_exit_process_as_Ro_list() {
        $list = $this->ExitproceduresAsRO_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($value->employeeId) ? $value->employeeId : '';
            $row[] = isset($value->userfullname) ? $value->userfullname : '';
            $row[] = isset($value->position_name) ? $value->position_name : '';
            $row[] = isset($value->department_name) ? $value->department_name : '';
            $row[] = isset($value->exit_type) ? $value->exit_type : '';
            $row[] = isset($value->noticeperiod) ? $value->noticeperiod : '';
            $row[] = isset($value->relieving_date) ? $value->relieving_date : '';
            $row[] = date("Y-m-d", strtotime($value->relieving_date . "+$value->noticeperiod day"));
            $row[] = isset($value->overall_status) ? $value->overall_status : '';
            $row[] = isset($value->hr_manager_status) ? $value->hr_manager_status : '';
            $row[] = isset($value->l2_status) ? $value->l2_status : '';
            $row[] = '<a href="#" data-toggle="modal" id="add_ro" data-target="#add_ro_initaiate_status" onclick="myFunction(' . "'" . $value->employee_id . "'" . ')"><li class="fa fa-edit"></li></a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->ExitproceduresAsRO_Model->count_all(),
            "recordsFiltered" => $this->ExitproceduresAsRO_Model->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    public function getroDataByid() {
        $ids = $_POST['id'];
        if ($ids) {
            $this->db->select('a.employee_id,a.l2_status,a.l2_comments,b.*');
            $this->db->from('main_exit_process as a');
            $this->db->where('a.employee_id', $ids);
            $this->db->join('main_employees_summary as b','b.user_id=a.employee_id','left');
            $query = $this->db->get()->result_array();
            $res = $query[0];
            echo json_encode($res);
        }
    }

    public function update_ro_check_status() {
        $arr = $this->input->post();
        $Insertdata = array('l2_status' => $arr['ro_approval'], 'l2_comments' => $arr['ro_of_comment']);
        $check = $this->db->get_where('main_exit_process', array('employee_id' => $$arr['id']));
        if ($check->num_rows() > 0) {
            $this->session->set_flashdata('error', 'Record Already updated');
        } else {
            $this->db->where('employee_id', $arr['id']);
            $this->db->update('main_exit_process', $Insertdata);
            $this->session->set_flashdata('success', 'Record updated Successfully');
        }
        redirect('seperation/Exitprocedures_Controller/Exit_Procedures_As_RO', true);
    }

}
