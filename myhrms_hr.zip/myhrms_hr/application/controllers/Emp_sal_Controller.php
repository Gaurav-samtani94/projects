<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Emp_sal_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Empsalaryreportdetail_model');
        $this->load->model('Update_emp_sal_details_Model');
        // $this->load->model('Emp_on_leave_tour_report_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
         $permission = GetUserIDHRPermission();
            if (in_array($this->session->userdata('loginid'), $permission)) {
                
            }
            else{
                redirect(base_url(""));
            }
    }

    //26-05-2018 Code For Salary Details...
    public function employee_salarydetails() {
        $data['error'] = array();
        $data['title'] = "Employee Salary Details Report";
        $this->load->view('new_report/emp_list_salarydetails', $data);

    }
	
   //New Function For Salary 26-05-2018....
    public function ajax_list_empsalarydetails() {
        $list = $this->Empsalaryreportdetail_model->get_datatables();
        // echo '<pre>';
        // print_r($list);
        // die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = (@$customers->employeeId) ? @$customers->employeeId : '';
            $row[] = (@$customers->userfullname) ? @$customers->userfullname : '';
            $row[] = (@$customers->position_name) ? @$customers->position_name : '';
            $row[] = (@$customers->department_name) ? @$customers->department_name : '';
            $row[] = (@$customers->bankname) ? @$customers->bankname : '';
            $row[] = (@$customers->accountholder_name) ? @$customers->accountholder_name : '';
            $row[] = (@$customers->branchname) ? @$customers->branchname : '';
            $row[] = (@$customers->accountnumber) ? @$customers->accountnumber : '';
            $row[] = (@$customers->payrollcode) ? @$customers->payrollcode : '';
            $row[] = (@$customers->ifsc_code) ? @$customers->ifsc_code : '';
            $row[] = (@$customers->pancard_no) ? @$customers->pancard_no : '';
            $row[] = (@$customers->empctc) ? number_format(@$customers->empctc, 2) : '';
            $row[] = (@$customers->grosssalary) ? number_format(@$customers->grosssalary, 2) : '';
            $row[] = (@$customers->appraisal_datemmyy) ? date("d-m-Y", strtotime(@$customers->appraisal_datemmyy)) : '';
            $row[] = (@$customers->basicsalary) ? number_format(@$customers->basicsalary, 2) : '';
            $row[] = (@$customers->appraisalduedate) ? @$customers->appraisalduedate : '';
            $row[] = (@$customers->emp_hra) ? number_format(@$customers->emp_hra, 2) : '';
            $row[] = (@$customers->education_allowance) ? number_format(@$customers->education_allowance, 2) : '';
            $row[] = (@$customers->tele_empsal_allowance) ? number_format(@$customers->tele_empsal_allowance, 2) : '';
            $row[] = (@$customers->medical_allowance) ? number_format(@$customers->medical_allowance, 2) : '';
            $row[] = (@$customers->transportation_allowance) ? number_format(@$customers->transportation_allowance, 2) : '';
            $row[] = (@$customers->special_allowance) ? number_format(@$customers->special_allowance, 2) : '';
            $row[] = (@$customers->project_allowance) ? number_format(@$customers->project_allowance, 2) : '';
            $row[] = (@$customers->statutory_deduct) ? number_format(@$customers->statutory_deduct, 2) : '';
            $row[] = (@$customers->empepf) ? number_format(@$customers->empepf, 2) : '';
            $row[] = (@$customers->emp_esi) ? number_format(@$customers->emp_esi, 2) : '';
            $row[] = (@$customers->emp_gratuity) ? number_format(@$customers->emp_gratuity, 2) : '';
            $row[] = (@$customers->emp_sal_gpai) ? number_format(@$customers->emp_sal_gpai, 2) : '';
            $row[] = (@$customers->loyaltybonus) ? number_format(@$customers->loyaltybonus, 2) : '';
            $row[] = (@$customers->projectcomp_bonus) ? number_format(@$customers->projectcomp_bonus, 2) : '';
            $row[] = (@$customers->empctcp1) ? number_format(@$customers->empctcp1, 2) : '';
            $row[] = (@$customers->empctcp2) ? number_format(@$customers->empctcp2, 2) : '';
            $row[] = (@$customers->driver_wagers) ? number_format(@$customers->driver_wagers, 2) : '';
            $row[] = (@$customers->vehicle_agreement) ? number_format(@$customers->vehicle_agreement, 2) : '';
            $row[] = (@$customers->fuel_expenses) ? number_format(@$customers->fuel_expenses, 2) : '';
            $row[] = (@$customers->food_expenses) ? number_format(@$customers->food_expenses, 2) : '';
            $row[] = (@$customers->leave_travel_allowance) ? number_format(@$customers->leave_travel_allowance, 2) : '';
            $row[] = (@@$customers->sal_other) ? number_format(@$customers->sal_other, 2) : '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Empsalaryreportdetail_model->count_all(),
            "recordsFiltered" => $this->Empsalaryreportdetail_model->count_filtered(),
            "data" => $data
        );
        echo json_encode($output);
    }
	
	//05-07-2021 Code For Salary Details Update...
	public function allEmployeeListForUpdateDetails() {
		$data['error'] = array();
        $data['title'] = "Employee List for Update";
        $this->load->view('salary_details_update/emp_list_forUpdate', $data);
	}
    public function UpdateEmployee_salarydetails() {
		// $userID = $this->uri->segment(2);
        $data['error'] = array();
        $data['title'] = "Employee Salary Details";
		// $data['list'] = $this->Update_emp_sal_details_Model->getSingleEmpSalDetail($userID);
		// $data['user_id'] = $userID;
		// echo "dd<pre>"; print_r($data['list']); die;
        $this->load->view('salary_details_update/edit_emp_salarydetails', $data);

    }
	public function updateSalaryDetails() {
		// echo "test"; die;
		// echo "dd<pre>"; print_r($_REQUEST); die;
		$userID = $_REQUEST['userID'];
		// echo $userID; die;
		if($_REQUEST):
			$data = array(
				'currencyid' => $_REQUEST['sal_currency'],
				'salary' => $_REQUEST['gross_sal'],
				'bankname' => $_REQUEST['bank_name'],
				'accountholder_name' => $_REQUEST['acc_holder'],
				'branchname' => $_REQUEST['bank_branch'],
				'ifsc_code' => $_REQUEST['ifsc_code'],
				'pancard_no' => $_REQUEST['pan_number'],
				'accountnumber' => $_REQUEST['acc_number'],
				'appraisalduedate' => $_REQUEST['appr_due_date']
			);
			
			// echo "dd<pre>"; print_r($data); die;
			$where = $this->db->where(array('user_id'=>$userID));
			$res = $this->db->update("main_empsalarydetails",$data,$where);
			if($res):
				$message = "Details Updated Successfully";
				// redirect(base_url('UpdateEmployee_salarydetails/'.$userID));
				// redirect(base_url('allEmployeeListForUpdateDetails'));
			else:
				// $this->session->set_flashdata('error_msg', "Something Went Wrong.");
				$message = "Something Went Wrong.";
			endif;
			
		endif;
		
		$output = array(
            "msg" => $message,
        );
        echo json_encode($output);
	}
	  
	public function updateAppr_relatedDetailsView() {
		$userID = $this->uri->segment(2);
		$data['error'] = array();
        $data['title'] = "Appraisal Releted Form";
		$data['list'] = $this->Update_emp_sal_details_Model->getSingleEmpApprRelatedDetail($userID);
		// echo "dd<pre>"; print_r($data['list']); die;
        $this->load->view('salary_details_update/appr_related_form_view', $data);
	}
	
	public function update_appr_related_details1() {
		$userID = $_REQUEST['emp_id'];
		$fldID = $_REQUEST['fld_id'];
		// $this->session->set_flashdata('error_msg', "Page is Under Maintenance...!");
		// redirect(base_url('updateAppr_relatedDetailsView/'.$userID));
		// echo $userID; die;
		if($_REQUEST):
			$data = array(
					'appraisal_datemmyy' => $_REQUEST['appr_due_date'],
					'basicsalary' => $_REQUEST['basic_sal'],
					'emp_hra' => $_REQUEST['hra'],
					'education_allowance' => $_REQUEST['educational_allow'],
					'tele_empsal_allowance' => $_REQUEST['teleph_allow'],
					'medical_allowance' => $_REQUEST['medical_allow'],
					'transportation_allowance' => $_REQUEST['transport_allow'],
					'special_allowance' => $_REQUEST['spcl_allow'],
					'project_allowance' => $_REQUEST['project_allow'],
					'bonus_adv' => $_REQUEST['bonus_adv'],
					// 'sal_other' => $_REQUEST['salery_head_other']
					
					'statutory_deduct' => $_REQUEST['statutory_deduct'],
					'empepf' => $_REQUEST['contribut_pf'],
					'emp_esi' => $_REQUEST['contribut_esi'],
					'emp_gratuity' => $_REQUEST['gratuity'],
					'emp_sal_gpai' => $_REQUEST['gpai'],
					'loyaltybonus' => $_REQUEST['loyalty_bonus'],
					'projectcomp_bonus' => $_REQUEST['project_compl_bonus'],
					'grosssal_mediclaim' => $_REQUEST['medi_clain'],
					'empctc' => $_REQUEST['ctc'],
					// 'grosssal_other' => $_REQUEST['gross_sal_other'],
					
					'empctcp1' => $_REQUEST['p1'],
					'empctcp2' => $_REQUEST['p2'],
					'driver_wagers' => $_REQUEST['driver_wagers'],
					'vehicle_agreement' => $_REQUEST['vehicle_agreement'],
					'fuel_expenses' => $_REQUEST['fuel_exp'],
					'food_expenses' => $_REQUEST['food_exp'],
					'leave_travel_allowance' => $_REQUEST['leave_travel_allow'],
					'pcb_employer' => $_REQUEST['emp_pcb'],
					// 'salsec_other' => $_REQUEST['Reimbursement_other'],
					
					'increment_amnt' => $_REQUEST['increment_amt'],
					'rating_grade' => $_REQUEST['rating'],
				);
				// echo "<pre>"; print_r($data); die;
				$where = $this->db->where(array('id'=>$fldID));
				$res = $this->db->update("main_empsal_increment",$data,$where);
				if($res):
					$this->session->set_flashdata('success_msg', "Details Updated Successfully");
					redirect(base_url('updateAppr_relatedDetailsView/'.$userID));
					// redirect(base_url('allEmployeeListForUpdateDetails'));
				else:
					$this->session->set_flashdata('error_msg', "Something Went Wrong.");
					redirect(base_url('updateAppr_relatedDetailsView/'.$userID));
				endif;
		endif;
	}
}
