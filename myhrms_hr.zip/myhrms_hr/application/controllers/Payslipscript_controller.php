<?php
defined('BASEPATH') or exit('No direct script access allowed');
require "vendor/autoload.php";

use NcJoes\OfficeConverter\OfficeConverter;
use \PhpOffice\PhpWord\PhpWord;

use mikehaertl\pdftk\Pdf;
use mikehaertl\pdftk\XfdfFile;
use mikehaertl\pdftk\FdfFile;
use DocxMerge\DocxMerge;



class Payslipscript_controller extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('Mastermodel');
		if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
			redirect(base_url(""));
		}
	}
	public function payslip_index()
	{
		$data['title']='Payslip Script';
		$this->load->view("payslip/Payslip_index",$data);
	}
	//Pay Slip..
	public function payslip()
	{
		$oldpath = "public/uploads/payslips/";
		$newpath = "../public/uploads/payslipsnew";
		if (file_exists($oldpath)) {
			if ($dh = opendir($oldpath)) {
				while (($file = readdir($dh)) !== false) {
					if (($file != ".") and ($file != "..")) :
						// echo "<pre>";
						// print_r($file);
						$exp = explode("(", $file);

						$payrolcode = str_replace("PaySlip-", "", "$exp[0]");
						$this->db->select('a.*,b.dob');
						$this->db->from("emp_otherofficial_data as a");
						$this->db->join("main_emppersonaldetails as b", "b.user_id=a.user_id", "LEFT");
						$this->db->join("main_users as c","c.id=a.user_id","LEFT");
						$this->db->where("a.payrollcode", $payrolcode);
						$this->db->where("c.isactive","1");
						$employe =	$this->db->get()->row();
// print_r($employe);

// Check pass

$this->db->select("a.*");
$this->db->from("payslip_pass as a");
$this->db->where("a.payroll_with_name",$employe->payroll_with_name);
$pass = $this->db->get()->row();
if($pass)
{
	$user_pdf_pass = $pass->password;
}
else{
	$user_pdf_pass = rand(10000,1000000);
}
// print_r($employe);
// print_r($user_pdf_pass);
// die();

						// echo"<pre>";
						// print_R($employe);
						// die();
						$mpdf = new \Mpdf\Mpdf();
						$oldpath = "public/uploads/payslips/$file";
						$newpath = "public/uploads/payslipsnew/$file";
						$pagecount = $mpdf->SetSourceFile("$oldpath");
						$tplId = $mpdf->ImportPage($pagecount);
						$mpdf->UseTemplate($tplId);
						$mpdf->SetProtection(array(), $user_pdf_pass, $user_pdf_pass);
						$exp_year = explode("_", $file);
						// print_R($exp_year[1]);
						$yearpdf =	$exp_year[2];
						$dob = $employe->dob;
						$uppass = array(
							'password' => $user_pdf_pass,
							'userid' => $employe->user_id,
							'payroll_with_name' => $employe->payroll_with_name
						);

						$year = str_replace(".pdf", "", "$yearpdf");
						$this->db->select('a.*');
						$this->db->from('payslip_filepath as a');
						
						$this->db->where("a.year", $year);
						$this->db->where("a.month", $exp_year[1]);
						$this->db->where("a.payrollid", $payrolcode);
					
						$result = $this->db->get()->num_rows();
						if ($result > 0) {
						} else {
							// print_r($year);
							$ins_array = array(
								'year' => $year,
								'month' => $exp_year[1],
								'payrollid' => $payrolcode,
								'payroll_with_name' => $employe->payroll_with_name,
								'fullpath' => "public/uploads/payslipsnew/$file",
								'filename' => $file,
							);
							$this->db->insert("payslip_filepath", $ins_array);
							if(!$pass)
								{

									$this->db->insert("payslip_pass", $uppass);
									}
							
							$mpdf->Output("$newpath", 'F');
							unlink("public/uploads/payslips/$file");
						}
						
					endif;
				}
				$this->session->set_flashdata('success', 'Script run Successfully');
					 redirect(base_url('payslip_index'));
			}
		}
	}

	public function index()
	{
		$data['title'] = "MRF For New And Existing Employee ";
		// $data['manpower_list'] = $this->tracker_manpower();
		$this->load->view("tracker/tracker_view", $data);
	}



	public function addProjecttask()
	{
		$project_ids = $this->input->post('project_id');
		$empid = $this->input->post('employe_id');
		// print_r($project_ids);
		// die();
		$ProjectList = array($project_ids);

		foreach ($ProjectList as $ProjectID) {
			// print_r($ProjectID);
			// die();
			if ($empid) {
				$allempList = array((object)['id' => $empid]);
			} else {
				$allempList = $this->GetAllActiveEmployee();
			}
			// echo "<pre>";
			// print_r($allempList);
			// die();
			if ($allempList) {
				foreach ($allempList as $userRow) {
					$userID = $userRow->id;
					$empdata = $this->getemp_projectaddornot($userID, $ProjectID);
					// print_R($empdata);
					// die();
					if (!$empdata) {
						$this->add_emp_project($userID, $ProjectID);
						$projecttaskas = $this->getallprojecttask($ProjectID);
						foreach ($projecttaskas as $key => $val) {
							$this->projecttaskassignorno($userID, $val->project_id, $val->task_id, $val->id);
						}
					}
				}
			}
		}
		return redirect(base_url('Assign_project_task'));
	}


	public function GetAllActiveEmployee()
	{
		$this->db->select('id,userfullname,employeeId');
		$this->db->from('main_users');
		$this->db->where('isactive', "1");
		$this->db->where('id>', "194");

		$employeAllData  = $this->db->get()->result();
		return ($employeAllData) ? $employeAllData : null;
	}
	public function getemp_projectaddornot($empid, $project_id)
	{
		$this->db->select('a.*');
		$this->db->from("tm_project_employees as a");
		$this->db->where("project_id", $project_id);
		$this->db->where("emp_id", $empid);

		$data =	$this->db->get()->row();
		// print_r($data);
		// die();
		return $data ? $data : null;
		// print_r($data);
		// die();
	}
	public function add_emp_project($userID, $ProjectID)
	{
		$addemp = array(
			'project_id' => $ProjectID,
			'emp_id' => $userID,
			'is_active' => '1',
			'created_by' => '2787'
		);
		$return = $this->db->insert('tm_project_employees', $addemp);
		return $return ? $return : null;
	}
	public function getallprojecttask($project_id)
	{
		$this->db->select('*');
		$this->db->from('tm_project_tasks');
		$this->db->where('project_id', $project_id);
		$this->db->where('is_active	', '1');
		$projecttask =	$this->db->get()->result();

		return $projecttask ? $projecttask : null;
	}
	public function projecttaskassignorno($userID, $project_id, $task_id, $projecttaskid)
	{
		$this->db->select('*');
		$this->db->from('tm_project_task_employees');
		$this->db->where("project_id", $project_id);
		$this->db->where("emp_id", $userID);
		$this->db->where("task_id", $task_id);
		$this->db->where("project_task_id", $projecttaskid);
		$assign_or_not = $this->db->get()->row();
		if (!$assign_or_not) {
			$ins_emp_project_task = array(
				'project_id' => $project_id,
				'emp_id' => $userID,
				'task_id' => $task_id,
				'project_task_id' => $projecttaskid
			);
			$this->db->insert('tm_project_task_employees', $ins_emp_project_task);
		}
	}
	public function Assign_project_task()
	{
		$data['title'] = 'Add Project Task To All';
		$this->db->select('*');
		$this->db->from('tm_projects');
		$this->db->where('is_active', '1');
		$data['project'] = $this->db->get()->result();
		$data['employelist'] = $this->GetAllActiveEmployee();
		$this->load->view('script/addprojectand_all_task_toallemp', $data);
	}
}
//
		// die;

		// $this->db->select('a.*');
		// $this->db->from("tm_project_employees as a");
		// $data =	$this->db->get()->result();



		// print_R($emparray);
		// echo "<pre>";
		// print_r($data);
		// die();

		// $emp = array();
		// foreach ($emparray as $key => $val) {
		// 	$empo_pro = $val['project_id'];
		// 	$empo_id = $val['emp_id'];
		// 	$this->db->select('*');
		// 	$this->db->from('tm_project_tasks');
		// 	$this->db->where('project_id', $empo_pro);
		// 	$this->db->where('is_active	', '1');
		// 	$task =	$this->db->get()->result();
		// 	foreach ($task as $ke => $vall) {

		// 		$tm_projecttask = $vall->id;
		// 		//project_id
		// 		//task_id
		// 		$this->db->select('*');
		// 		$this->db->from('tm_project_task_employees');
		// 		$this->db->where('project_id', $vall->project_id);
		// 		$this->db->where('task_id', $vall->task_id);
		// 		$this->db->where('emp_id', $empo_id);
		// 		$this->db->where('project_task_id', $tm_projecttask);
		// 		$employe_data  = $this->db->get()->row();
		// 		// print_r($employe_data);
		// 		// die();
		// 		if (!$employe_data) {
		// 			$arremp = array(
		// 				'project_id' => $vall->project_id,
		// 				'task_id' => $vall->task_id,
		// 				'emp_id' => $empo_id,
		// 				'project_task_id' => $tm_projecttask,
		// 				'is_active' => '1',
		// 				'created_by' => '2787'
		// 			);
		// 			$this->db->insert('tm_project_task_employees', $arremp);
		// 		}
		// 	}
		// 	// print_r($task);

		// }
		// echo "<pre>";
		// print_r($emp);
		// die();
