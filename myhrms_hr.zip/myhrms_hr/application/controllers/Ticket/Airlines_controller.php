<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Airlines_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('report/Airlines_model', 'Airlines_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }




    public function Airlines_index()
    {

        $data['title'] = "Airlines";


        $this->load->view('new_report/airlines_view', $data);
    }


    public function Book_airlines()
    {
        $airlines_name = $this->input->post('air_lines');
        $air_slug = $this->input->post('slug');
        $res = $this->Airlines_model->check_main_airlines($airlines_name, $air_slug);
        if ($res == TRUE) {
            $this->session->set_flashdata('success_msg', " slug book  successfully");
        } else {
            $this->session->set_flashdata('sorry_msg', "This slug already book");
        }
        redirect(base_url('Airlines_index'));
    }


    public function Airlines_data()
    {
        // $data = array();
        // $user_id = $this->session->userdata('loginid');
        $list = $this->Airlines_model->get_datatables();
        $no = 0;
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $value->air_lines;
            $row[] = $value->slug;
            $data[] = $row;
        }

        $output = array(
            "draw" =>  $_POST['draw'],
            "recordsTotal" => $this->Airlines_model->count_all(),
            "recordsFiltered" => $this->Airlines_model->count_filtered(),
            "data" => $data,
        );

        echo json_encode($output);
    }
}
