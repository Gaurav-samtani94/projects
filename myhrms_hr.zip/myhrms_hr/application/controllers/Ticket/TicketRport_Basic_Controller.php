<?php
defined('BASEPATH') or exit('No direct script access allowed');

class TicketRport_Basic_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('mastermodel');
        //======================code start by durgesh (06-08-2020)=====================//
        $this->load->model('report/Ticket_model', 'Ticket_model');
        $this->load->model('report/Ticket_Basic_model', 'Ticket_Basic_model');
        //======================code end by durgesh (06-08-2020)=====================//
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }


    public function Ticketbasicreport()
    {
        $data['title'] = "Ticket Basic Report";
        $data['Category'] = $this->Ticket_Basic_model->GetCatehorybasicecord();
        $data['Employee'] = $this->Ticket_Basic_model->GetEmployeebasiccord();
        $this->load->view('new_report/ticket_basic_report', $data);
    }

    public function Ticket_report_basic()
    {

        $catgory_id = $this->input->post('catgory_id');
        $emp_id = $this->input->post('emp_id');
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');
        $list = $this->Ticket_Basic_model->get_datatables($catgory_id, $emp_id, $start_date, $end_date);
        // echo "<pre>";
        // print_r($list);
        // die;
        $no = 0;
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $value->ticket_no;
            $row[] = ($value->userfullname) . '&nbsp;&nbsp;' . '[' . $value->employeeId . ']';
            $row[] = $value->c_name;
            $row[] = $value->entry_date;
            $data[] = $row;
        }
        $output = array(
            "draw" =>  $_POST['draw'],
            "recordsTotal" => $this->Ticket_Basic_model->count_all(),
            "recordsFiltered" => $this->Ticket_Basic_model->count_filtered(),
            "data" => $data,
        );

        echo json_encode($output);
    }
}
