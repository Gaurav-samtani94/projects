<?php
defined('BASEPATH') or exit('No direct script access allowed');

class TicketRport_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('mastermodel');
        //======================code start by durgesh (06-08-2020)=====================//
        $this->load->model('report/Ticket_model', 'Ticket_model');
        //======================code end by durgesh (06-08-2020)=====================//
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }





    public function Ticketreport()
    {
        $data['title'] = "Ticket Report";
        $data['Category'] = $this->Ticket_model->GetCatehoryecord();
        $data['Employee'] = $this->Ticket_model->GetEmployeeecord();
        $data['status'] = $this->Ticket_model->Getstatuscord();

        $this->load->view('new_report/ticket_report', $data);
    }





    public function Ticket_report()
    {
        $TickStatusArr = array("" => "", "1" => " Open", "2" => " In Progress ", "3" => " Done ");
        $catgory_id = $this->input->post('catgory_id');
        $emp_id = $this->input->post('emp_id');
        $tick_status = $this->input->post('tick_status');
        $list = $this->Ticket_model->get_datatables($catgory_id, $emp_id, $tick_status);
        $no = 0;
        foreach ($list as $value) {
            $reactedArr = $this->Getparentecord($value->fld_id);
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $value->ticket_no;
            $row[] = ($value->userfullname) . '&nbsp;&nbsp;' . '[' . $value->employeeId . ']';
            $row[] = $value->department_name;
            $row[] = $value->c_name;
            $row[] = $reactedArr;
            $row[] = $TickStatusArr[$value->tick_status];
            $row[] = $value->entry_date;
            $data[] = $row;
        }
        //($recRow->user_fullname) ? $recRow->user_fullname : "";
        $output = array(
            "draw" =>  $_POST['draw'],
            "recordsTotal" => $this->Ticket_model->count_all(),
            "recordsFiltered" => $this->Ticket_model->count_filtered(),
            "data" => $data,
        );

        echo json_encode($output);
    }

    public function Getparentecord($parent_id)
    {
        $this->db->select('fld_id');
        $this->db->from('tick_ticket_raise');
        $this->db->where('parent_id', $parent_id);
        $RecRows = $this->db->get()->num_rows();
        return ($RecRows) ?   $RecRows  : '0';
    }




    // public function Ticketbasicreport()
    // {
    //     $data['title'] = "Ticket Basic Report";
    //     $data['Category'] = $this->Ticket_model->GetCatehorybasicecord();
    //     $data['Employee'] = $this->Ticket_model->GetEmployeebasiccord();
    //     $this->load->view('new_report/ticket_basic_report', $data);
    // }

    // public function Ticket_report_basic()
    // {

    //     $catgory_id = $this->input->post('catgory_id');
    //     $emp_id = $this->input->post('emp_id');
    //     $start_date = $this->input->post('start_date');
    //     $end_date = $this->input->post('end_date');
    //     $list = $this->Ticket_model->get_datatables_basic($catgory_id, $emp_id, $start_date, $end_date);
    //     // echo "<pre>";
    //     // print_r($list);
    //     // die;
    //     $no = 0;
    //     foreach ($list as $value) {
    //         $no++;
    //         $row = array();
    //         $row[] = $no;
    //         $row[] = $value->ticket_no;
    //         $row[] = ($value->userfullname) . '&nbsp;&nbsp;' . '[' . $value->employeeId . ']';
    //         $row[] = $value->c_name;
    //         $row[] = $value->entry_date;
    //         $data[] = $row;
    //     }
    //     $output = array(
    //         "draw" =>  $_POST['draw'],
    //         "recordsTotal" => $this->Ticket_model->count_all_basic(),
    //         "recordsFiltered" => $this->Ticket_model->count_filtered_basic(),
    //         "data" => $data,
    //     );

    //     echo json_encode($output);
    // }
}
