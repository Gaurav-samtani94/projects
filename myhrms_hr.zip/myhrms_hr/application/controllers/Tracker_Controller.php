<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tracker_Controller extends CI_Controller {

	function __construct() {
        parent::__construct();
		$this->load->model('Mastermodel');
		if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }

	public function hod_panel(){ 
		$data['title'] ="MRF For New And Existing Employee ";
		$data['manpower_list'] = $this->tracker_manpower(); 
		$this->load->view("tracker/tracker_view", $data);
	}

	public function mrf(){  
		$data['title'] ="Manpower Requisition"; 
		$data['dept_list'] = $this->getEmpDeptList();
		$data['desig_list'] = $this->getEmpDesigList();
		$data['emp_list'] = $this->getEmpUserList();
		$data['ro_list'] = $this->getROList();
		$data['comp_list'] = $this->Mastermodel->GetTableData('tbl_ofclocation', array('is_active'=>'1')); 
		$data['edulevel_list'] = $this->Mastermodel->GetTableData('main_educationlevelcode', array('isactive'=>'1')); 
		$data['country_list'] = $this->Mastermodel->GetloginCountries();  
		$this->load->view("tracker/mrf_view", $data);
	}

	public function edit_mrf($id = null){  
		$this->db->select('a.*,m.userfullname as position_initiated_userfullname');
        $this->db->from('tracker_manpower as a');
        $this->db->join('main_users as m','m.id=a.position_initiated_by','left');
        $this->db->where('fld_id',$id);
        $record_row = $this->db->get()->row();
        
        $data['tracker_manpower_list'] = $record_row;
        if(empty($data['tracker_manpower_list'])){
            redirect(base_url('hod_panel'));
        }
		$data['title'] ="Edit Manpower Requisition"; 
		$data['dept_list'] = $this->getEmpDeptList();
		$data['desig_list'] = $this->getEmpDesigList();
		$data['emp_list'] = $this->getEmpUserList();
		$data['ro_list'] = $this->getROList();
		$data['comp_list'] = $this->Mastermodel->GetTableData('tbl_ofclocation', array('is_active'=>'1')); 
		$data['edulevel_list'] = $this->Mastermodel->GetTableData('main_educationlevelcode', array('isactive'=>'1')); 
		$data['country_list'] = $this->Mastermodel->GetloginCountries();  
		$this->load->view("tracker/edit_mrf_view", $data);  
	}

	public function state($countryID) {
        if ($countryID) {
			$this->db->select('id,state_name');
			$this->db->from('tbl_states');
			$this->db->where('isactive', '1');
			$this->db->order_by('state_name', 'asc');
			$this->db->where('country_id', $countryID);
			$query = $this->db->get();
			$result = $query->result_array();
            echo json_encode($result);
        }
        exit();
    }

	public function city($stateID) {
        if ($stateID) {
			$this->db->select('id,city_name');
			$this->db->from('tbl_cities');
			$this->db->where('is_active', '1');
			$this->db->order_by('city_name', 'asc');
			$this->db->where('state_id', $stateID);
			$query = $this->db->get();
			$result = $query->result_array();
            echo json_encode($result);
        }
        exit();
    } 

	//======get data by id=======//

	public function getEmpUserList(){ 
		$emp_id = $this->session->userdata('loginid'); 
		if($emp_id){
			$this->db->select('a.id,a.userfullname,b.department_id,b.department_name,b.position_id,b.position_name');
			$this->db->from('main_users as a');
			$this->db->join('main_employees_summary as b','b.user_id=a.id','left');
			$this->db->where(array('b.isactive'=>'1','b.reporting_manager'=>$emp_id));
			$resultArr = $this->db->get()->result();
				if($resultArr){
					return $resultArr;
				}
				else{
					return '';
				}
		}
	}

	public function tracker_manpower(){ 
		$this->db->select('a.fld_id,a.lock,a.position,a.position_initiated_on,a.no_of_position_vacant,c.userfullname,c.department_id,c.department_name,c.position_id,c.position_name');
		$this->db->from('tracker_manpower as a');
		$this->db->join('main_users as b','a.position_initiated_by=b.id','left');
		$this->db->join('main_employees_summary as c','c.user_id=b.id','left');
		$this->db->where(array('c.isactive'=>'1'));
		$resultArr = $this->db->get()->result();
		if($resultArr){
			return $resultArr;
		}
		else{
			return '';
		}
	}

	public function getROList(){ 
		$this->db->select('a.id,a.userfullname');
		$this->db->from('main_users as a');
		$this->db->join('main_employees_summary as b','b.user_id=a.id','left');
		$this->db->where(array('b.isactive'=>'1'));
		$resultArr = $this->db->get()->result();
		if($resultArr){
			return $resultArr;
		}
		else{
			return '';
		}
	}

	public function getEmpDeptList(){ 
		$emp_id = $this->session->userdata('loginid'); 
		if($emp_id){
			$this->db->select('b.department_id,b.department_name');
			$this->db->from('main_users as a');
			$this->db->join('main_employees_summary as b','b.user_id=a.id','left');
			$this->db->where(array('b.isactive'=>'1','b.reporting_manager'=>$emp_id));
			$this->db->group_by('b.department_id');
			$resultArr = $this->db->get()->result();
				if($resultArr){
					return $resultArr;
				}
				else{
					return '';
				}
		}
	}

	public function getEmpDesigList(){ 
		$emp_id = $this->session->userdata('loginid'); 
		if($emp_id){
			$this->db->select('b.position_id,b.position_name');
			$this->db->from('main_users as a');
			$this->db->join('main_employees_summary as b','b.user_id=a.id','left');
			$this->db->where(array('b.isactive'=>'1','b.reporting_manager'=>$emp_id));
			$this->db->group_by('b.position_id');
			$resultArr = $this->db->get()->result();
				if($resultArr){
					return $resultArr;
				}
				else{
					return '';
				}
		}
	}

	public function getAjaxRequestData(){ 
		$emp_id = $_REQUEST['emp_name_val']; 
			if($emp_id){
			$this->db->select('a.department_id,a.position_id,c.id');
			$this->db->from('main_employees_summary as a');
			$this->db->join('emp_otherofficial_data as b','b.user_id=a.user_id','left');
			$this->db->join('tbl_ofclocation as c','c.id=b.company_location','left');
			$this->db->where(array('a.isactive'=>'1','a.user_id'=>$emp_id));
			$rowArr = $this->db->get()->row();
				if($rowArr){
					echo json_encode($rowArr);
				}
			}
	}

	public function save_manpower_data(){
		$this->load->library('email');
		$mrf_id = $this->input->post('mrf_id');
		//$count = $this->db->get_where('tracker_manpower',array('department'=>$this->input->post('department_name'),'position_name'=>$this->input->post('position_name')))->num_rows();
		if (!empty($mrf_id)) {
			$updatedata = array(
				'position'=>$this->input->post('position'),
				'emp_name'=>$this->input->post('emp_name')?$this->input->post('emp_name'):"",
				'position_initiated_on'=>date('Y-m-d', strtotime($this->input->post('position_initiated_on'))),
				'position_initiated_by'=>$this->session->userdata('loginid'),
				'position_name'=>$this->input->post('position_name'),
				'base_location'=>$this->input->post('base_location'),
				'no_of_position_vacant'=>$this->input->post('position_vacant'),
				'technical_non_technical'=>$this->input->post('technical_non_technical'),
				'department'=>$this->input->post('department_name'),
				'tenture'=>$this->input->post('tenure'),
				'budgeted_non_budgeted'=>$this->input->post('budgeted_non_budgeted'),
				'reason_of_requirement'=>$this->input->post('reason_for_requirement'),
				'qualifications_desired'=>$this->input->post('qualifications_desired'),
				'qualifications_desired_course'=>$this->input->post('qualifications_desired_course'),
				'age_group_from'=>$this->input->post('age_group_from_range'),
				'age_group_to'=>$this->input->post('age_group_to_range'),
				'relevant_qualification'=>$this->input->post('relevant_qualification'),
				'relevant_qualification_course'=>$this->input->post('relevant_qualification_course'),
				'relevant_from_exp'=>$this->input->post('relevant_from_exp'),
				'relevant_to_exp'=>$this->input->post('relevant_to_exp'),
				'work_exp_from_range'=>$this->input->post('work_exp_from_range'),
				'work_exp_to_range'=>$this->input->post('work_exp_to_range'),
				'gross_salary_from_range'=>$this->input->post('gross_salary_from_range'),
				'gross_salary_to_range'=>$this->input->post('gross_salary_to_range'),
				'reporting_location_country'=>$this->input->post('reporting_location_country'),
				'reporting_location_state'=>$this->input->post('reporting_location_state'),
				'reporting_location_city'=>$this->input->post('reporting_location_city'),
				'reporting_officer'=>$this->input->post('reporting_officer'),
				'expected_date_of_joining'=>date("Y-m-d", strtotime($this->input->post('expected_date_of_joining'))),
				'job_description'=>$this->input->post('job_description'),
				'mrf_handed_over_cru'=>date("Y-m-d", strtotime($this->input->post('mrf_handed_over_cru'))),
				'expected_date_position_closure'=>date("Y-m-d", strtotime($this->input->post('expected_date_position_closure'))),
				'offer_issued'=>date("Y-m-d", strtotime($this->input->post('offer_issued'))),
				'is_active'=>'1',
				'modified_by'=>$this->session->userdata('loginid') 
			);
			$resp = $this->Mastermodel->UpdataRecord('tracker_manpower',$updatedata, ['fld_id' => $mrf_id]);
			$message = 'Vacant Position Updated Successfully';
		} 
		else{
			$insertdata = array(
				'position'=>$this->input->post('position'),
				'emp_name'=>$this->input->post('emp_name')?$this->input->post('emp_name'):"",
				'position_initiated_on'=>date('Y-m-d', strtotime($this->input->post('position_initiated_on'))),
				'position_initiated_by'=>$this->session->userdata('loginid'),
				'position_name'=>$this->input->post('position_name'),
				'base_location'=>$this->input->post('base_location'),
				'no_of_position_vacant'=>$this->input->post('position_vacant'),
				'technical_non_technical'=>$this->input->post('technical_non_technical'),
				'department'=>$this->input->post('department_name'),
				'tenture'=>$this->input->post('tenure'),
				'budgeted_non_budgeted'=>$this->input->post('budgeted_non_budgeted'),
				'reason_of_requirement'=>$this->input->post('reason_for_requirement'),
				'qualifications_desired'=>$this->input->post('qualifications_desired'),
				'qualifications_desired_course'=>$this->input->post('qualifications_desired_course'),
				'age_group_from'=>$this->input->post('age_group_from_range'),
				'age_group_to'=>$this->input->post('age_group_to_range'),
				'relevant_qualification'=>$this->input->post('relevant_qualification'),
				'relevant_qualification_course'=>$this->input->post('relevant_qualification_course'),
				'relevant_exp_from'=>$this->input->post('relevant_from_exp'),
				'relevant_exp_to'=>$this->input->post('relevant_to_exp'),
				'work_exp_from'=>$this->input->post('work_exp_from_range'),
				'work_exp_to'=>$this->input->post('work_exp_to_range'),
				'gross_salary_from'=>$this->input->post('gross_salary_from_range'),
				'gross_salary_to'=>$this->input->post('gross_salary_to_range'),
				'reporting_location_country'=>$this->input->post('reporting_location_country'),
				'reporting_location_state'=>$this->input->post('reporting_location_state'),
				'reporting_location_city'=>$this->input->post('reporting_location_city'),
				'reporting_officer'=>$this->input->post('reporting_officer'),
				'expected_date_joining'=>date("Y-m-d", strtotime($this->input->post('expected_date_of_joining'))),
				'job_description'=>$this->input->post('job_description'),
				'mrf_handed_over_cru'=>date("Y-m-d", strtotime($this->input->post('mrf_handed_over_cru'))),
				'expected_date_position_closure'=>date("Y-m-d", strtotime($this->input->post('expected_date_position_closure'))),
				'offer_issued'=>date("Y-m-d", strtotime($this->input->post('offer_issued'))), 
				'is_active'=>'1',
				'created_by'=>$this->session->userdata('loginid') 
			);
			//$msg = $this->load->view('email_template/mrf_template_email', true);
			//$recipients = array('durgeshgarg32@gmail.com');
	    	//$to = implode(',', $recipients);
			//$this->sendMail($to,"marketing@cegindia.com", 'Man Power Vacant Position', $msg);
			$resp = $this->Mastermodel->InsertMasterData($insertdata, 'tracker_manpower');
			$message = 'Vacant Position Added Successfully';
		} 
		$arrMessage = array(
            'msg' => $message
        );
		echo json_encode($arrMessage); 	
	}

	public function lock(){
		$fld_id = $this->input->post('fld_id');	
		$row_id = $this->input->post('row_id');	
		
		if((!empty($fld_id)) AND (!empty($row_id))){
			$this->db->where(array('fld_id'=>$fld_id));
			$this->db->update('tracker_manpower', array('lock'=>$row_id,'lock_by'=>$this->session->userdata('loginid'),'lock_date'=>date('Y-m-d h:i:s')));
			//$msg = $this->load->view('email_template/lock_email', true);
			//$recipients = array('durgeshgarg32@gmail.com');
	    	//$to = implode(',', $recipients);
			//$this->sendMail($to,"marketing@cegindia.com", 'Man Power New/Vacant Position Locked', $msg);
			$message = 'Vacant Position Updated Successfully';
		}
		else{
			$message = 'Some Error';
		}
		$arrMessage = array(
            'msg' => $message
        );
		echo json_encode($arrMessage); 
	} 
	

	function sendMail($to, $from, $subject, $msgDetails) { 
        $CI = & get_instance();
        $CI->load->library('email');
		$CI->email->set_mailtype("html");
        $CI->email->initialize(array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        ));
        $CI->email->from($from, 'Do_not_reply');
        $CI->email->to($to);
		$CI->email->cc($from);
         $CI->email->bcc('marketing@cegindia.com');
        $CI->email->subject($subject);
        $CI->email->message($msgDetails);
        $resp = $CI->email->send();
        return ($resp) ? $resp : $CI->email->print_debugger();
    }


}
