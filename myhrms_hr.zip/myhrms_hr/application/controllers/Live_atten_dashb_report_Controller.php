<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Live_atten_dashb_report_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Live_atten_report_model');
        $this->load->library('form_validation');
		$this->load->helper('common_helper');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function live_atten_report_data() {
		$data = array();
		$id = $this->session->userdata('loginid');
		// echo $id; die;
		// $presentEmpCeg12 = $this->Live_atten_report_model->update_location_data();
		// echo "<pre>"; print_r($presentEmpCeg12); die;
		// return $presentEmpCeg12;
		
		
		
		$presentEmpCeg = $this->Live_atten_report_model->live_atten_report_ceg_busunit(1);
		$presentEmpCegth = $this->Live_atten_report_model->live_atten_report_ceg_busunit(2);
		$presentEmpCegpro = $this->Live_atten_report_model->live_atten_report_ceg_busunit(3);
		
        $PresentEmployeejpr = $this->Live_atten_report_model->live_atten_report_ceg(1);
        $PresentEmployeeDelhi = $this->Live_atten_report_model->live_atten_report_ceg(2);
        $PresentEmployeeBlr = $this->Live_atten_report_model->live_atten_report_ceg(4);
        $PresentEmployeeMumbai = $this->Live_atten_report_model->live_atten_report_ceg(5);

		$activeEmployeejpr = $this->Live_atten_report_model->getTotalActiveEmployeeCeg(1);
		$activeEmployeeDelhi = $this->Live_atten_report_model->getTotalActiveEmployeeCeg(2);
		$activeEmployeeBlr = $this->Live_atten_report_model->getTotalActiveEmployeeCeg(4);
		$activeEmployeeMumbai = $this->Live_atten_report_model->getTotalActiveEmployeeCeg(5);
		
		// echo "<pre>"; print_r($activeEmployeejpr); die;
		// .$activeEmployeeDelhi; die;

		// $presentEmp = (($activeEmployeeCeg-$presentDetailCeg)/$activeEmployeeCeg)*100;
		$presentEmpjpr = round(($PresentEmployeejpr/$activeEmployeejpr)*100);
		$presentEmpDelhi = round(($PresentEmployeeDelhi/$activeEmployeeDelhi)*100);
		$presentEmpBlr = round(($PresentEmployeeBlr/$activeEmployeeMumbai)*100);
		$presentEmpMumbai = round(($PresentEmployeeMumbai/$activeEmployeeMumbai)*100);
		// $presentEmp = round((50/100)*100);
		
		// echo "<pre>"; print_r($PresentEmployeeDelhi); die;
		// echo "<pre>"; print_r($activeEmployeeMumbai); die;
		
		
		// echo $presentEmpjpr; die;
		$emp_present = $this->Live_atten_report_model->live_atten_report_graph(1);
		// echo "<pre>"; print_r($emp_present); die;
		$emp_atten1 = array();
		$emp_atten2 = array();
		$emp_atten3 = array();
		$emp_atten4 = array();
		$emp_atten5 = array();
		$emp_atten6 = array();
		$emp_atten7 = array();
		foreach($emp_present as $val):
		$intime= date("h:i:s A", strtotime(($val->LogDate)));
            if((strtotime($intime) > strtotime('09:00:00 AM') and strtotime($intime) < strtotime('09:15:01 AM'))) {
				$emp_atten1[] = $intime; 
			}
		endforeach;
		foreach($emp_present as $val):
		$intime= date("h:i:s A", strtotime(($val->LogDate)));
            if((strtotime($intime) > strtotime('09:15:00 AM') and strtotime($intime) < strtotime('09:30:01 AM'))) {
				$emp_atten2[] = $intime; 
			}
		endforeach;
		foreach($emp_present as $val):
		$intime= date("h:i:s A", strtotime(($val->LogDate)));
            if((strtotime($intime) > strtotime('09:30:00 AM') and strtotime($intime) < strtotime('09:35:01 AM'))) {
				$emp_atten3[] = $intime; 
			}
		endforeach;
		foreach($emp_present as $val):
		$intime= date("h:i:s A", strtotime(($val->LogDate)));
            if((strtotime($intime) > strtotime('09:35:00 AM') and strtotime($intime) < strtotime('09:40:01 AM'))) {
				$emp_atten4[] = $intime; 
			}
		endforeach;
		foreach($emp_present as $val):
		$intime= date("h:i:s A", strtotime(($val->LogDate)));
            if((strtotime($intime) > strtotime('09:40:00 AM') and strtotime($intime) < strtotime('09:50:01 AM'))) {
				$emp_atten5[] = $intime; 
			}
		endforeach;
		foreach($emp_present as $val):
		$intime= date("h:i:s A", strtotime(($val->LogDate)));
            if((strtotime($intime) > strtotime('09:50:00 AM') and strtotime($intime) < strtotime('10:00:01 AM'))) {
				$emp_atten6[] = $intime; 
			}
		endforeach;
		foreach($emp_present as $val):
		$intime= date("h:i:s A", strtotime(($val->LogDate)));
            if((strtotime($intime) > strtotime('10:00:00 AM') and strtotime($intime) < strtotime('10:30:01 AM'))) {
				$emp_atten7[] = $intime; 
			}
		endforeach;
		
		$emp_atten_start1 = (count($emp_atten1));
		$emp_atten_start2 = (count($emp_atten2));
		$emp_atten_start3 = (count($emp_atten3));
		$emp_atten_start4 = (count($emp_atten4));
		$emp_atten_start5 = (count($emp_atten5));
		$emp_atten_start6 = (count($emp_atten6));
		$emp_atten_start7 = (count($emp_atten7));
		
        //======================================================================================================
		
		$emp_presentdelhi = $this->Live_atten_report_model->live_atten_report_graph(2);
		// echo "<pre>"; print_r($emp_presentdelhi); die;
		$emp_atten1dl = array();
		$emp_atten2dl = array();
		$emp_atten3dl = array();
		$emp_atten4dl = array();
		$emp_atten5dl = array();
		$emp_atten6dl = array();
		$emp_atten7dl = array();
		if($emp_presentdelhi):
			foreach($emp_presentdelhi as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:00:00 AM') and strtotime($intime) < strtotime('09:15:01 AM'))) {
					$emp_atten1dl[] = $intime; 
				}
			endforeach;
			foreach($emp_presentdelhi as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:15:00 AM') and strtotime($intime) < strtotime('09:30:01 AM'))) {
					$emp_atten2dl[] = $intime; 
				}
			endforeach;
			foreach($emp_presentdelhi as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:30:00 AM') and strtotime($intime) < strtotime('09:35:01 AM'))) {
					$emp_atten3dl[] = $intime; 
				}
			endforeach;
			foreach($emp_presentdelhi as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:35:00 AM') and strtotime($intime) < strtotime('09:40:01 AM'))) {
					$emp_atten4dl[] = $intime; 
				}
			endforeach;
			foreach($emp_presentdelhi as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:40:00 AM') and strtotime($intime) < strtotime('09:50:01 AM'))) {
					$emp_atten5dl[] = $intime; 
				}
			endforeach;
			foreach($emp_presentdelhi as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:50:00 AM') and strtotime($intime) < strtotime('10:00:01 AM'))) {
					$emp_atten6dl[] = $intime; 
				}
			endforeach;
			foreach($emp_presentdelhi as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('10:00:00 AM') and strtotime($intime) < strtotime('10:30:01 AM'))) {
					$emp_atten7dl[] = $intime; 
				}
			endforeach;
			
			$emp_atten_start1dl = (count($emp_atten1dl));
			$emp_atten_start2dl = (count($emp_atten2dl));
			$emp_atten_start3dl = (count($emp_atten3dl));
			$emp_atten_start4dl = (count($emp_atten4dl));
			$emp_atten_start5dl = (count($emp_atten5dl));
			$emp_atten_start6dl = (count($emp_atten6dl));
			$emp_atten_start7dl = (count($emp_atten7dl));
		endif;
        //================================================================================================================
		$emp_presentmumbai = $this->Live_atten_report_model->live_atten_report_graph(5);
		$emp_atten1Mum = array();
		$emp_atten2Mum = array();
		$emp_atten3Mum = array();
		$emp_atten4Mum = array();
		$emp_atten5Mum = array();
		$emp_atten6Mum = array();
		$emp_atten7Mum = array();
		if($emp_presentmumbai):
			foreach($emp_presentmumbai as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:00:00 AM') and strtotime($intime) < strtotime('09:15:01 AM'))) {
					$emp_atten1Mum[] = $intime; 
				}
			endforeach;
			foreach($emp_presentmumbai as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:15:00 AM') and strtotime($intime) < strtotime('09:30:01 AM'))) {
					$emp_atten2Mum[] = $intime; 
				}
			endforeach;
			foreach($emp_presentmumbai as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:30:00 AM') and strtotime($intime) < strtotime('09:35:01 AM'))) {
					$emp_atten3Mum[] = $intime; 
				}
			endforeach;
			foreach($emp_presentmumbai as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:35:00 AM') and strtotime($intime) < strtotime('09:40:01 AM'))) {
					$emp_atten4Mum[] = $intime; 
				}
			endforeach;
			foreach($emp_presentmumbai as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:40:00 AM') and strtotime($intime) < strtotime('09:50:01 AM'))) {
					$emp_atten5Mum[] = $intime; 
				}
			endforeach;
			foreach($emp_presentmumbai as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('09:50:00 AM') and strtotime($intime) < strtotime('10:00:01 AM'))) {
					$emp_atten6Mum[] = $intime; 
				}
			endforeach;
			foreach($emp_presentmumbai as $val):
			$intime= date("h:i:s A", strtotime(($val->LogDate)));
				if((strtotime($intime) > strtotime('10:00:00 AM') and strtotime($intime) < strtotime('10:30:01 AM'))) {
					$emp_atten7Mum[] = $intime; 
				}
			endforeach;
			
			$emp_atten_start1Mum = (count($emp_atten1Mum));
			$emp_atten_start2Mum = (count($emp_atten2Mum));
			$emp_atten_start3Mum = (count($emp_atten3Mum));
			$emp_atten_start4Mum = (count($emp_atten4Mum));
			$emp_atten_start5Mum = (count($emp_atten5Mum));
			$emp_atten_start6Mum = (count($emp_atten6Mum));
			$emp_atten_start7Mum = (count($emp_atten7Mum));
			
		endif;
        $title = "Live Attendance Report";
		$timelateEmpCeg = $this->Live_atten_report_model->getTotalTimeLateEmployeeCeg($id);
		$emp_atten_time = '';
		$checkTime = strtotime('09:30:59');
		foreach($timelateEmpCeg as $val):
		$intime= date("h:i:s A", strtotime(($val->LogDate)));
            if(strtotime($intime) > strtotime('09:00:59 AM')) {
				$emp_atten_time = $intime; 
			}
		endforeach;
		$loginTime = strtotime($emp_atten_time);
		$diff = $checkTime - $loginTime;
        $ActiveEmployeedata = $this->Live_atten_report_model->ActiveEmployeedata();
        $InActiveEmployeedata = $this->Live_atten_report_model->InActiveEmployeedata();
        $PresentEmployeedata = $this->Live_atten_report_model->get_employee_leave_data();
        $this->load->view("dashboard_attendance_report/userdashboard_view", compact('InActiveEmployeedata','ActiveEmployeedata','PresentEmployeedata','emp_atten_start1Mum','emp_atten_start2Mum','emp_atten_start3Mum','emp_atten_start4Mum','emp_atten_start5Mum','emp_atten_start6Mum','emp_atten_start7Mum','emp_atten_start1dl','emp_atten_start2dl','emp_atten_start3dl','emp_atten_start4dl','emp_atten_start5dl','emp_atten_start6dl','emp_atten_start7dl','presentEmpDelhi','presentEmpBlr','presentEmpMumbai','emp_atten_start7','emp_atten_start6','emp_atten_start5','emp_atten_start4','emp_atten_start3','emp_atten_start2','emp_atten_start1','presentEmpjpr','title','presentEmpCeg','presentEmpCegth','presentEmpCegpro'));
	}
	
	
	public function feedback_report_new() {

            //HR Section..
            //*** average 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "6", "a.group_name" => "general_climate"));
            $hravgTotRow1 = $this->db->Get()->num_rows();
            //*** average 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "7", "a.group_name" => "general_climate"));
            $hravgTotRow2 = $this->db->Get()->num_rows();
            //*** average 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "8", "a.group_name" => "general_climate"));
            $hravgTotRow3 = $this->db->Get()->num_rows();
            //*** average 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "9", "a.group_name" => "general_climate"));
            $hravgTotRow4 = $this->db->Get()->num_rows();
            //*** average 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "10", "a.group_name" => "general_climate"));
            $hravgTotRow5 = $this->db->Get()->num_rows();
			//*** average 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "11", "a.group_name" => "general_climate"));
            $hravgTotRow6 = $this->db->Get()->num_rows();
			//*** average 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "12", "a.group_name" => "general_climate"));
            $hravgTotRow7 = $this->db->Get()->num_rows();
			//*** average 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "13", "a.group_name" => "general_climate"));
            $hravgTotRow8 = $this->db->Get()->num_rows();
			//*** average 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "14", "a.group_name" => "general_climate"));
            $hravgTotRow9 = $this->db->Get()->num_rows();
			//*** average 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "15", "a.group_name" => "general_climate"));
            $hravgTotRow10 = $this->db->Get()->num_rows();
			//*** average 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "16", "a.group_name" => "general_climate"));
            $hravgTotRow11 = $this->db->Get()->num_rows();

//================================================================================================================

            //*** need_improvement 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "6", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow1 = $this->db->Get()->num_rows();
            //*** need_improvement 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "7", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow2 = $this->db->Get()->num_rows();
            //*** need_improvement 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "8", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow3 = $this->db->Get()->num_rows();
            //*** need_improvement 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "9", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow4 = $this->db->Get()->num_rows();
            //*** need_improvement 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "10", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow5 = $this->db->Get()->num_rows();
			//*** need_improvement 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "11", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow6 = $this->db->Get()->num_rows();
			//*** need_improvement 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "12", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow7 = $this->db->Get()->num_rows();
			//*** need_improvement 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "13", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow8 = $this->db->Get()->num_rows();
			//*** need_improvement 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "14", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow9 = $this->db->Get()->num_rows();
			//*** need_improvement 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "15", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow10 = $this->db->Get()->num_rows();
			//*** need_improvement 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "16", "a.group_name" => "general_climate"));
            $hrNeedImpTotRow11 = $this->db->Get()->num_rows();

//==================================================================================================================

            //*** satisfactory 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "6", "a.group_name" => "general_climate"));
            $hrSatisfTotRow1 = $this->db->Get()->num_rows();
            //*** satisfactory 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "7", "a.group_name" => "general_climate"));
            $hrSatisfTotRow2 = $this->db->Get()->num_rows();
            //*** satisfactory 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "8", "a.group_name" => "general_climate"));
            $hrSatisfTotRow3 = $this->db->Get()->num_rows();
            //*** satisfactory 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "9", "a.group_name" => "general_climate"));
            $hrSatisfTotRow4 = $this->db->Get()->num_rows();
            //*** satisfactory 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "10", "a.group_name" => "general_climate"));
            $hrSatisfTotRow5 = $this->db->Get()->num_rows();
			//*** satisfactory 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "11", "a.group_name" => "general_climate"));
            $hrSatisfTotRow6 = $this->db->Get()->num_rows();
			//*** satisfactory 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "12", "a.group_name" => "general_climate"));
            $hrSatisfTotRow7 = $this->db->Get()->num_rows();
			//*** satisfactory 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "13", "a.group_name" => "general_climate"));
            $hrSatisfTotRow8 = $this->db->Get()->num_rows();
			//*** satisfactory 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "14", "a.group_name" => "general_climate"));
            $hrSatisfTotRow9 = $this->db->Get()->num_rows();
			//*** satisfactory 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "15", "a.group_name" => "general_climate"));
            $hrSatisfTotRow10 = $this->db->Get()->num_rows();
			//*** satisfactory 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "16", "a.group_name" => "general_climate"));
            $hrSatisfTotRow11 = $this->db->Get()->num_rows();

//=================================================================================================================

            //*** very_good 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "6", "a.group_name" => "general_climate"));
            $hrVgoodTotRow1 = $this->db->Get()->num_rows();
            //*** very_good 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "7", "a.group_name" => "general_climate"));
            $hrVgoodTotRow2 = $this->db->Get()->num_rows();
            //*** very_good 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "8", "a.group_name" => "general_climate"));
            $hrVgoodTotRow3 = $this->db->Get()->num_rows();
            //*** very_good 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "9", "a.group_name" => "general_climate"));
            $hrVgoodTotRow4 = $this->db->Get()->num_rows();
            //*** very_good 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "10", "a.group_name" => "general_climate"));
            $hrVgoodTotRow5 = $this->db->Get()->num_rows();
			//*** very_good 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "11", "a.group_name" => "general_climate"));
            $hrVgoodTotRow6 = $this->db->Get()->num_rows();
			//*** very_good 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "12", "a.group_name" => "general_climate"));
            $hrVgoodTotRow7 = $this->db->Get()->num_rows();
			//*** very_good 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "13", "a.group_name" => "general_climate"));
            $hrVgoodTotRow8 = $this->db->Get()->num_rows();
			//*** very_good 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "14", "a.group_name" => "general_climate"));
            $hrVgoodTotRow9 = $this->db->Get()->num_rows();
			//*** very_good 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "15", "a.group_name" => "general_climate"));
            $hrVgoodTotRow10 = $this->db->Get()->num_rows();
			//*** very_good 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "16", "a.group_name" => "general_climate"));
            $hrVgoodTotRow11 = $this->db->Get()->num_rows();

//=================================================================================================================

            //*** excellent 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "6", "a.group_name" => "general_climate"));
            $hrExclTotRow1 = $this->db->Get()->num_rows();
            //*** excellent 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "7", "a.group_name" => "general_climate"));
            $hrExclTotRow2 = $this->db->Get()->num_rows();
            //*** excellent 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "8", "a.group_name" => "general_climate"));
            $hrExclTotRow3 = $this->db->Get()->num_rows();
            //*** excellent 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "9", "a.group_name" => "general_climate"));
            $hrExclTotRow4 = $this->db->Get()->num_rows();
            //*** excellent 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "10", "a.group_name" => "general_climate"));
            $hrExclTotRow5 = $this->db->Get()->num_rows();
			//*** excellent 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "11", "a.group_name" => "general_climate"));
            $hrExclTotRow6 = $this->db->Get()->num_rows();
			//*** excellent 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "12", "a.group_name" => "general_climate"));
            $hrExclTotRow7 = $this->db->Get()->num_rows();
			//*** excellent 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "13", "a.group_name" => "general_climate"));
            $hrExclTotRow8 = $this->db->Get()->num_rows();
			//*** excellent 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "14", "a.group_name" => "general_climate"));
            $hrExclTotRow9 = $this->db->Get()->num_rows();
			//*** excellent 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "15", "a.group_name" => "general_climate"));
            $hrExclTotRow10 = $this->db->Get()->num_rows();
			//*** excellent 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "16", "a.group_name" => "general_climate"));
            $hrExclTotRow11 = $this->db->Get()->num_rows();

//=================================================================================================================


            //octapac...
            //*************** octapac Dept ************************
            //*** average 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "17", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow1 = $this->db->Get()->num_rows();
            //*** average 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "18", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow2 = $this->db->Get()->num_rows();
            //*** average 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "19", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow3 = $this->db->Get()->num_rows();
            //*** average 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "20", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow4 = $this->db->Get()->num_rows();
            //*** average 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "21", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow5 = $this->db->Get()->num_rows();
			//*** average 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "22", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow6 = $this->db->Get()->num_rows();
			//*** average 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "23", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow7 = $this->db->Get()->num_rows();
			//*** average 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "24", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow8 = $this->db->Get()->num_rows();
			//*** average 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "25", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow9 = $this->db->Get()->num_rows();
			//*** average 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "26", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow10 = $this->db->Get()->num_rows();
			//*** average 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "27", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow11 = $this->db->Get()->num_rows();
			//*** average 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "28", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow12 = $this->db->Get()->num_rows();
			//*** average 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "29", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow13 = $this->db->Get()->num_rows();
			//*** average 14
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "30", "a.group_name" => "OCTAPAC"));
            $AccountavgTotRow14 = $this->db->Get()->num_rows();

//=================================================================================================================

            //*** need_improvement 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "17", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow1 = $this->db->Get()->num_rows();
            //*** need_improvement 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "18", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow2 = $this->db->Get()->num_rows();
            //*** need_improvement 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "19", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow3 = $this->db->Get()->num_rows();
            //*** need_improvement 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "20", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow4 = $this->db->Get()->num_rows();
            //*** need_improvement 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "21", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow5 = $this->db->Get()->num_rows();
			//*** need_improvement 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "22", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow6 = $this->db->Get()->num_rows();
			//*** need_improvement 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "23", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow7 = $this->db->Get()->num_rows();
			//*** need_improvement 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "24", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow8 = $this->db->Get()->num_rows();
			//*** need_improvement 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "25", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow9 = $this->db->Get()->num_rows();
			//*** need_improvement 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "26", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow10 = $this->db->Get()->num_rows();
			//*** need_improvement 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "27", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow11 = $this->db->Get()->num_rows();
			//*** need_improvement 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "28", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow12 = $this->db->Get()->num_rows();
			//*** need_improvement 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "29", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow13 = $this->db->Get()->num_rows();
			//*** need_improvement 14
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "30", "a.group_name" => "OCTAPAC"));
            $AccountNeedImpTotRow14 = $this->db->Get()->num_rows();
			
//=================================================================================================================

            //*** satisfactory 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "17", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow1 = $this->db->Get()->num_rows();
            //*** satisfactory 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "18", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow2 = $this->db->Get()->num_rows();
            //*** satisfactory 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "19", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow3 = $this->db->Get()->num_rows();
            //*** satisfactory 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "20", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow4 = $this->db->Get()->num_rows();
            //*** satisfactory 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "21", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow5 = $this->db->Get()->num_rows();
			//*** satisfactory 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "22", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow6 = $this->db->Get()->num_rows();
			//*** satisfactory 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "23", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow7 = $this->db->Get()->num_rows();
			//*** satisfactory 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "24", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow8 = $this->db->Get()->num_rows();
			//*** satisfactory 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "25", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow9 = $this->db->Get()->num_rows();
			//*** satisfactory 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "26", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow10 = $this->db->Get()->num_rows();
			//*** satisfactory 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "27", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow11 = $this->db->Get()->num_rows();
			//*** satisfactory 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "28", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow12 = $this->db->Get()->num_rows();
			//*** satisfactory 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "29", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow13 = $this->db->Get()->num_rows();
			//*** satisfactory 14
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "30", "a.group_name" => "OCTAPAC"));
            $AccountSatisfTotRow14 = $this->db->Get()->num_rows();
			
//=================================================================================================================

            //*** very_good 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "17", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow1 = $this->db->Get()->num_rows();
            //*** very_good 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "18", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow2 = $this->db->Get()->num_rows();
            //*** very_good 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "19", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow3 = $this->db->Get()->num_rows();
            //*** very_good 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "20", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow4 = $this->db->Get()->num_rows();
            //*** very_good 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "21", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow5 = $this->db->Get()->num_rows();
			//*** very_good 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "22", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow6 = $this->db->Get()->num_rows();
			//*** very_good 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "23", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow7 = $this->db->Get()->num_rows();
			//*** very_good 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "24", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow8 = $this->db->Get()->num_rows();
			//*** very_good 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "25", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow9 = $this->db->Get()->num_rows();
			//*** very_good 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "26", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow10 = $this->db->Get()->num_rows();
			//*** very_good 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "27", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow11 = $this->db->Get()->num_rows();
			//*** very_good 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "28", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow12 = $this->db->Get()->num_rows();
			//*** very_good 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "29", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow13 = $this->db->Get()->num_rows();
			//*** very_good 14
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "30", "a.group_name" => "OCTAPAC"));
            $AccountVgoodTotRow14 = $this->db->Get()->num_rows();
			
//=================================================================================================================

            //*** excellent 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "17", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow1 = $this->db->Get()->num_rows();
            //*** excellent 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "18", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow2 = $this->db->Get()->num_rows();
            //*** excellent 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "19", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow3 = $this->db->Get()->num_rows();
            //*** excellent 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "20", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow4 = $this->db->Get()->num_rows();
            //*** excellent 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "21", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow5 = $this->db->Get()->num_rows();
			//*** excellent 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "22", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow6 = $this->db->Get()->num_rows();
			//*** excellent 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "23", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow7 = $this->db->Get()->num_rows();
			//*** excellent 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "24", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow8 = $this->db->Get()->num_rows();
			//*** excellent 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "25", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow9 = $this->db->Get()->num_rows();
			//*** excellent 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "26", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow10 = $this->db->Get()->num_rows();
			//*** excellent 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "27", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow11 = $this->db->Get()->num_rows();
			//*** excellent 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "28", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow12 = $this->db->Get()->num_rows();
			//*** excellent 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "29", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow13 = $this->db->Get()->num_rows();
			//*** excellent 14
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "30", "a.group_name" => "OCTAPAC"));
            $AccountExclTotRow14 = $this->db->Get()->num_rows();
			
//=================================================================================================================


            //HRD Mechanism...
            //*************** HRD Mechanism ************************
            //*** average 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "31", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow1 = $this->db->Get()->num_rows();
            //*** average 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "32", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow2 = $this->db->Get()->num_rows();
            //*** average 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "33", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow3 = $this->db->Get()->num_rows();
            //*** average 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "34", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow4 = $this->db->Get()->num_rows();
            //*** average 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "35", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow5 = $this->db->Get()->num_rows();
			//*** average 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "36", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow6 = $this->db->Get()->num_rows();
			//*** average 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "37", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow7 = $this->db->Get()->num_rows();
			//*** average 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "38", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow8 = $this->db->Get()->num_rows();
			//*** average 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "39", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow9 = $this->db->Get()->num_rows();
			//*** average 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "40", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow10 = $this->db->Get()->num_rows();
			//*** average 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "41", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow11 = $this->db->Get()->num_rows();
			//*** average 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "42", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow12 = $this->db->Get()->num_rows();
			//*** average 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "average", "a.isactive" => "1", "a.master_key_id" => "43", "a.group_name" => "hrd_mechanism"));
            $StoresavgTotRow13 = $this->db->Get()->num_rows();
			
//=================================================================================================================

            //*** need_improvement 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "31", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow1 = $this->db->Get()->num_rows();
            //*** need_improvement 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "32", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow2 = $this->db->Get()->num_rows();
            //*** need_improvement 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "33", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow3 = $this->db->Get()->num_rows();
            //*** need_improvement 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "34", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow4 = $this->db->Get()->num_rows();
            //*** need_improvement 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "35", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow5 = $this->db->Get()->num_rows();
			//*** need_improvement 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "36", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow6 = $this->db->Get()->num_rows();
			//*** need_improvement 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "37", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow7 = $this->db->Get()->num_rows();
			//*** need_improvement 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "38", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow8 = $this->db->Get()->num_rows();
			//*** need_improvement 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "39", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow9 = $this->db->Get()->num_rows();
			//*** need_improvement 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "40", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow10 = $this->db->Get()->num_rows();
			//*** need_improvement 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "41", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow11 = $this->db->Get()->num_rows();
			//*** need_improvement 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "42", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow12 = $this->db->Get()->num_rows();
			//*** need_improvement 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "need_improvement", "a.isactive" => "1", "a.master_key_id" => "43", "a.group_name" => "hrd_mechanism"));
            $StoresNeedImpTotRow13 = $this->db->Get()->num_rows();
			
//=================================================================================================================

            //*** satisfactory 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "31", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow1 = $this->db->Get()->num_rows();
            //*** satisfactory 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "32", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow2 = $this->db->Get()->num_rows();
            //*** satisfactory 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "33", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow3 = $this->db->Get()->num_rows();
            //*** satisfactory 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "34", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow4 = $this->db->Get()->num_rows();
            //*** satisfactory 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "35", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow5 = $this->db->Get()->num_rows();
			//*** satisfactory 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "36", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow6 = $this->db->Get()->num_rows();
			//*** satisfactory 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "37", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow7 = $this->db->Get()->num_rows();
			//*** satisfactory 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "38", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow8 = $this->db->Get()->num_rows();
			//*** satisfactory 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "39", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow9 = $this->db->Get()->num_rows();
			//*** satisfactory 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "40", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow10 = $this->db->Get()->num_rows();
			//*** satisfactory 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "41", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow11 = $this->db->Get()->num_rows();
			//*** satisfactory 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "42", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow12 = $this->db->Get()->num_rows();
			//*** satisfactory 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "satisfactory", "a.isactive" => "1", "a.master_key_id" => "43", "a.group_name" => "hrd_mechanism"));
            $StoresSatisfTotRow13 = $this->db->Get()->num_rows();
			
//=================================================================================================================

            //*** very_good 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "31", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow1 = $this->db->Get()->num_rows();
            //*** very_good 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "32", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow2 = $this->db->Get()->num_rows();
            //*** very_good 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "33", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow3 = $this->db->Get()->num_rows();
            //*** very_good 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "34", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow4 = $this->db->Get()->num_rows();
            //*** very_good 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "35", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow5 = $this->db->Get()->num_rows();
			//*** very_good 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "36", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow6 = $this->db->Get()->num_rows();
			//*** very_good 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "37", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow7 = $this->db->Get()->num_rows();
			//*** very_good 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "38", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow8 = $this->db->Get()->num_rows();
			//*** very_good 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "39", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow9 = $this->db->Get()->num_rows();
			//*** very_good 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "40", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow10 = $this->db->Get()->num_rows();
			//*** very_good 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "41", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow11 = $this->db->Get()->num_rows();
			//*** very_good 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "42", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow12 = $this->db->Get()->num_rows();
			//*** very_good 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "very_good", "a.isactive" => "1", "a.master_key_id" => "43", "a.group_name" => "hrd_mechanism"));
            $StoresVgoodTotRow13 = $this->db->Get()->num_rows();
			
//=================================================================================================================

            //*** excellent 1
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "31", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow1 = $this->db->Get()->num_rows();
            //*** excellent 2
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "32", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow2 = $this->db->Get()->num_rows();
            //*** excellent 3
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "33", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow3 = $this->db->Get()->num_rows();
            //*** excellent 4
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "34", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow4 = $this->db->Get()->num_rows();
            //*** excellent 5
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "35", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow5 = $this->db->Get()->num_rows();
			//*** excellent 6
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "36", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow6 = $this->db->Get()->num_rows();
			//*** excellent 7
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "37", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow7 = $this->db->Get()->num_rows();
			//*** excellent 8
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "38", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow8 = $this->db->Get()->num_rows();
			//*** excellent 9
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "39", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow9 = $this->db->Get()->num_rows();
			//*** excellent 10
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "40", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow10= $this->db->Get()->num_rows();
			//*** excellent 11
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "41", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow11 = $this->db->Get()->num_rows();
			//*** excellent 12
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "42", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow12 = $this->db->Get()->num_rows();
			//*** excellent 13
            $this->db->select("a.id");
            $this->db->From("emp_feedback as a");
            $this->db->where(array("a.feedback" => "excellent", "a.isactive" => "1", "a.master_key_id" => "43", "a.group_name" => "hrd_mechanism"));
            $StoresExclTotRow13 = $this->db->Get()->num_rows();
			
            ?>


        <table align="center" border="1">
            <tr>
                <th colspan="7">General Climate</th>
            </tr>
            <tr>
                <th>Sr.No</th>
                <th>Name</th>
                <th>Average</th>
                <th>Need improvement</th>
                <th>Satisfactory</th>
                <th>Very Good</th>
                <th>Excellent</th>
            </tr>
            <tr>
                <td>1</td>
                <td>1.The top management of this organisation goes out of its way to make sure that employees enjoyed their work.</td>
                <td><?= $hravgTotRow1; ?></td>
                <td><?= $hrNeedImpTotRow1 ?></td>
                <td><?= $hrSatisfTotRow1; ?></td>
                <td><?= $hrVgoodTotRow1; ?></td>
                <td><?= $hrExclTotRow1; ?></td>
            </tr>
            <tr>
                <td>2</td>
                <td>2.The top management believes that human resources are extremely important resource that they have to be treated more humanly.</td>
                <td><?= $hravgTotRow2; ?></td>
                <td><?= $hrNeedImpTotRow2; ?></td>
                <td><?= $hrSatisfTotRow2; ?></td>
                <td><?= $hrVgoodTotRow2; ?></td>
                <td><?= $hrExclTotRow2; ?></td>
            </tr>
            <tr>
                <td>3</td>
                <td>3.Development of the subordinates is seen as an important part of the job by the managers/ officers herein.</td>
                <td><?= $hravgTotRow3; ?></td>
                <td><?= $hrNeedImpTotRow3; ?></td>
                <td><?= $hrSatisfTotRow3; ?></td>
                <td><?= $hrVgoodTotRow3; ?></td>
                <td><?= $hrExclTotRow3; ?></td>
            </tr>
            <tr>
                <td>4</td>
                <td>4.The personal policies in this organisation facilitate employs development.</td>
                <td><?= $hravgTotRow4; ?></td>
                <td><?= $hrNeedImpTotRow4; ?></td>
                <td><?= $hrSatisfTotRow4; ?></td>
                <td><?= $hrVgoodTotRow4; ?></td>
                <td><?= $hrExclTotRow4; ?></td>
            </tr>
            <tr>
                <td>5</td>
                <td>The top management is willing to invest their time and energy including other organisational resources to ensure employees development.</td>
                <td><?= $hravgTotRow5; ?></td>
                <td><?= $hrNeedImpTotRow5; ?></td>
                <td><?= $hrSatisfTotRow5; ?></td>
                <td><?= $hrVgoodTotRow5; ?></td>
                <td><?= $hrExclTotRow5; ?></td>
            </tr>
			<tr>
                <td>6</td>
                <td>Senior officers/executive in this organisation takes active interest in their juniors and helps them learn their job.</td>
                <td><?= $hravgTotRow6; ?></td>
                <td><?= $hrNeedImpTotRow6 ?></td>
                <td><?= $hrSatisfTotRow6; ?></td>
                <td><?= $hrVgoodTotRow6; ?></td>
                <td><?= $hrExclTotRow6; ?></td>
            </tr>
            <tr>
                <td>7</td>
                <td>People lacking competence in doing their jobs are helped to acquire competence rather than being left unattended.</td>
                <td><?= $hravgTotRow7; ?></td>
                <td><?= $hrNeedImpTotRow7; ?></td>
                <td><?= $hrSatisfTotRow7; ?></td>
                <td><?= $hrVgoodTotRow7; ?></td>
                <td><?= $hrExclTotRow7; ?></td>
            </tr>
            <tr>
                <td>8</td>
                <td>Management in this organisation believes that employs behaviour can be changed and people can be developed at any stage of their life.</td>
                <td><?= $hravgTotRow8; ?></td>
                <td><?= $hrNeedImpTotRow8; ?></td>
                <td><?= $hrSatisfTotRow8; ?></td>
                <td><?= $hrVgoodTotRow8; ?></td>
                <td><?= $hrExclTotRow8; ?></td>
            </tr>
            <tr>
                <td>9</td>
                <td>The psychological climate in this organisation is very conducive to any employee interested in developing oneself by acquiring new knowledge and skills.</td>
                <td><?= $hravgTotRow9; ?></td>
                <td><?= $hrNeedImpTotRow9; ?></td>
                <td><?= $hrSatisfTotRow9; ?></td>
                <td><?= $hrVgoodTotRow9; ?></td>
                <td><?= $hrExclTotRow9; ?></td>
            </tr>
            <tr>
                <td>10</td>
                <td>The top management of this organisation makes efforts to identify and utilise employs potential.</td>
                <td><?= $hravgTotRow10; ?></td>
                <td><?= $hrNeedImpTotRow10; ?></td>
                <td><?= $hrSatisfTotRow10; ?></td>
                <td><?= $hrVgoodTotRow10; ?></td>
                <td><?= $hrExclTotRow10; ?></td>
            </tr>
			<tr>
                <td>11</td>
                <td>The organizations future plans are made known to managerial staff to help them develop their juniors and prepare them for future.</td>
                <td><?= $hravgTotRow11; ?></td>
                <td><?= $hrNeedImpTotRow11; ?></td>
                <td><?= $hrSatisfTotRow11; ?></td>
                <td><?= $hrVgoodTotRow11; ?></td>
                <td><?= $hrExclTotRow11; ?></td>
            </tr>
            <tr>
                <th colspan="2">  Total </th>
                <th><?= ($hravgTotRow1 + $hravgTotRow2 + $hravgTotRow3 + $hravgTotRow4 + $hravgTotRow5 + $hravgTotRow6 + $hravgTotRow7 + $hravgTotRow8 + $hravgTotRow9 + $hravgTotRow10 + $hravgTotRow11); ?></th>
                <th><?= ($hrNeedImpTotRow1 + $hrNeedImpTotRow2 + $hrNeedImpTotRow3 + $hrNeedImpTotRow4 + $hrNeedImpTotRow5 + $hrNeedImpTotRow6 + $hrNeedImpTotRow7 + $hrNeedImpTotRow8 + $hrNeedImpTotRow9 + $hrNeedImpTotRow10 + $hrNeedImpTotRow11); ?></th>
                <th><?= ($hrSatisfTotRow1 + $hrSatisfTotRow2 + $hrSatisfTotRow3 + $hrSatisfTotRow4 + $hrSatisfTotRow5 + $hrSatisfTotRow6 + $hrSatisfTotRow7 + $hrSatisfTotRow8 + $hrSatisfTotRow9 + $hrSatisfTotRow10 + $hrSatisfTotRow11); ?></th>
                <th><?= ($hrVgoodTotRow5 + $hrVgoodTotRow2 + $hrVgoodTotRow3 + $hrVgoodTotRow4 + $hrVgoodTotRow5 + $hrVgoodTotRow6 + $hrVgoodTotRow7 + $hrVgoodTotRow8 + $hrVgoodTotRow9 + $hrVgoodTotRow10 + $hrVgoodTotRow11); ?></th>
                <th><?= ($hrExclTotRow1 + $hrExclTotRow2 + $hrExclTotRow3 + $hrExclTotRow4 + $hrExclTotRow5 + $hrExclTotRow6 + $hrExclTotRow7 + $hrExclTotRow8 + $hrExclTotRow9 + $hrExclTotRow10 + $hrExclTotRow11); ?></th>
            </tr>


            <tr>
                <th colspan="7">OCTAPAC (openness, confrontation, trust, autonomy, proactivity, authenticity and collaboration) Culture </th>
            </tr>
            <tr>
                <th>Sr.No</th>
                <th>Name</th>
                <th>Average</th>
                <th>Need improvement</th>
                <th>Satisfactory</th>
                <th>Very Good</th>
                <th>Excellent</th>
            </tr>
            <tr>
                <td>1</td>
                <td>People in this organisation are helpful to each other.</td>
                <td><?= $AccountavgTotRow1; ?></td>
                <td><?= $AccountNeedImpTotRow1 ?></td>
                <td><?= $AccountSatisfTotRow1; ?></td>
                <td><?= $AccountVgoodTotRow1; ?></td>
                <td><?= $AccountExclTotRow1; ?></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Employees in this organisation are very informal and do not hesitate to discuss their personal problems with their supervisors.</td>
                <td><?= $AccountavgTotRow2; ?></td>
                <td><?= $AccountNeedImpTotRow2; ?></td>
                <td><?= $AccountSatisfTotRow2; ?></td>
                <td><?= $AccountVgoodTotRow2; ?></td>
                <td><?= $AccountExclTotRow2; ?></td>
            </tr>
            <tr>
                <td>3</td>
                <td>People in this organisation do not have any fixed mental impressions about each other.</td>
                <td><?= $AccountavgTotRow3; ?></td>
                <td><?= $AccountNeedImpTotRow3; ?></td>
                <td><?= $AccountSatisfTotRow3; ?></td>
                <td><?= $AccountVgoodTotRow3; ?></td>
                <td><?= $AccountExclTotRow3; ?></td>
            </tr>
            <tr>
                <td>4</td>
                <td>Employees are encouraged to experiment with new methods and try out creative ideas</td>
                <td><?= $AccountavgTotRow4; ?></td>
                <td><?= $AccountNeedImpTotRow4; ?></td>
                <td><?= $AccountSatisfTotRow4; ?></td>
                <td><?= $AccountVgoodTotRow4; ?></td>
                <td><?= $AccountExclTotRow4; ?></td>
            </tr>
            <tr>
                <td>5</td>
                <td>When any employee makes a mistake his supervisors treat it with understanding and help him to learn from such mistakes rather than punishing him or discouraging him.</td>
                <td><?= $AccountavgTotRow5; ?></td>
                <td><?= $AccountNeedImpTotRow5; ?></td>
                <td><?= $AccountSatisfTotRow5; ?></td>
                <td><?= $AccountVgoodTotRow5; ?></td>
                <td><?= $AccountExclTotRow5; ?></td>
            </tr>
			<tr>
                <td>6</td>
                <td>When behaviour feedback is given to employees they take it seriously and use it for development.</td>
                <td><?= $AccountavgTotRow6; ?></td>
                <td><?= $AccountNeedImpTotRow6 ?></td>
                <td><?= $AccountSatisfTotRow6; ?></td>
                <td><?= $AccountVgoodTotRow6; ?></td>
                <td><?= $AccountExclTotRow6; ?></td>
            </tr>
			<tr>
                <td>7</td>
                <td>Employees in this organisation take pains to find out there strength and weaknesses from the supervising officers or Colleagues.</td>
                <td><?= $AccountavgTotRow7; ?></td>
                <td><?= $AccountNeedImpTotRow7 ?></td>
                <td><?= $AccountSatisfTotRow7; ?></td>
                <td><?= $AccountVgoodTotRow7; ?></td>
                <td><?= $AccountExclTotRow7; ?></td>
            </tr>
			<tr>
                <td>8</td>
                <td>Employs returning from training programs are given opportunities to try out what they have learnt.</td>
                <td><?= $AccountavgTotRow8; ?></td>
                <td><?= $AccountNeedImpTotRow8; ?></td>
                <td><?= $AccountSatisfTotRow8; ?></td>
                <td><?= $AccountVgoodTotRow8; ?></td>
                <td><?= $AccountExclTotRow8; ?></td>
            </tr>
			<tr>
                <td>9</td>
                <td>People trust each other in this organisation.</td>
                <td><?= $AccountavgTotRow9; ?></td>
                <td><?= $AccountNeedImpTotRow9; ?></td>
                <td><?= $AccountSatisfTotRow9; ?></td>
                <td><?= $AccountVgoodTotRow9; ?></td>
                <td><?= $AccountExclTotRow9; ?></td>
            </tr>
			<tr>
                <td>10</td>
                <td>Employs are not afraid to express or discuss their feelings with their supervisors/superiors.</td>
                <td><?= $AccountavgTotRow10; ?></td>
                <td><?= $AccountNeedImpTotRow10; ?></td>
                <td><?= $AccountSatisfTotRow10; ?></td>
                <td><?= $AccountVgoodTotRow10; ?></td>
                <td><?= $AccountExclTotRow10; ?></td>
            </tr>
			<tr>
                <td>11</td>
                <td>Employs are not afraid to express or discuss their feelings with their subordinates.</td>
                <td><?= $AccountavgTotRow11; ?></td>
                <td><?= $AccountNeedImpTotRow11; ?></td>
                <td><?= $AccountSatisfTotRow11; ?></td>
                <td><?= $AccountVgoodTotRow11; ?></td>
                <td><?= $AccountExclTotRow11; ?></td>
            </tr>
			<tr>
                <td>12</td>
                <td>Employees are encouraged to take initiative and do things on their own without having to wait for instructions from supervisors.</td>
                <td><?= $AccountavgTotRow12; ?></td>
                <td><?= $AccountNeedImpTotRow12; ?></td>
                <td><?= $AccountSatisfTotRow12; ?></td>
                <td><?= $AccountVgoodTotRow12; ?></td>
                <td><?= $AccountExclTotRow12; ?></td>
            </tr>
			<tr>
                <td>13</td>
                <td>Delegation of authority to encourage juniors to develop handling higher responsibilities is quite common in this organisation.</td>
                <td><?= $AccountavgTotRow13; ?></td>
                <td><?= $AccountNeedImpTotRow13; ?></td>
                <td><?= $AccountSatisfTotRow13; ?></td>
                <td><?= $AccountVgoodTotRow13; ?></td>
                <td><?= $AccountExclTotRow13; ?></td>
            </tr>
			<tr>
                <td>14</td>
                <td>When seniors delegate authority to juniors, the juniors use it as an opportunity for development.</td>
                <td><?= $AccountavgTotRow14; ?></td>
                <td><?= $AccountNeedImpTotRow14; ?></td>
                <td><?= $AccountSatisfTotRow14; ?></td>
                <td><?= $AccountVgoodTotRow14; ?></td>
                <td><?= $AccountExclTotRow14; ?></td>
            </tr>
            <tr>
                <th colspan="2">  Total </th>
                <th><?= ($AccountavgTotRow1 + $AccountavgTotRow2 + $AccountavgTotRow3 + $AccountavgTotRow4 + $AccountavgTotRow5 + $AccountavgTotRow6 + $AccountavgTotRow7 + $AccountavgTotRow8 + $AccountavgTotRow9 + $AccountavgTotRow10 + $AccountavgTotRow11 + $AccountavgTotRow12 + $AccountavgTotRow13 + $AccountavgTotRow14); ?></th>
                <th><?= ($AccountNeedImpTotRow1 + $AccountNeedImpTotRow2 + $AccountNeedImpTotRow3 + $AccountNeedImpTotRow4 + $AccountNeedImpTotRow5 + $AccountNeedImpTotRow6 + $AccountNeedImpTotRow7 + $AccountNeedImpTotRow8 + $AccountNeedImpTotRow9 + $AccountNeedImpTotRow10 + $AccountNeedImpTotRow11 + $AccountNeedImpTotRow12 + $AccountNeedImpTotRow13 + $AccountNeedImpTotRow14); ?></th>
                <th><?= ($AccountSatisfTotRow1 + $AccountSatisfTotRow2 + $AccountSatisfTotRow3 + $AccountSatisfTotRow4 + $AccountSatisfTotRow5 + $AccountSatisfTotRow6 + $AccountSatisfTotRow7 + $AccountSatisfTotRow8 + $AccountSatisfTotRow9 + $AccountSatisfTotRow10 + $AccountSatisfTotRow11 + $AccountSatisfTotRow12 + $AccountSatisfTotRow13 + $AccountSatisfTotRow14); ?></th>
                <th><?= ($AccountVgoodTotRow5 + $AccountVgoodTotRow2 + $AccountVgoodTotRow3 + $AccountVgoodTotRow4 + $AccountVgoodTotRow5 + $AccountVgoodTotRow6 + $AccountVgoodTotRow7 + $AccountVgoodTotRow8 + $AccountVgoodTotRow9 + $AccountVgoodTotRow10 + $AccountVgoodTotRow11 + $AccountVgoodTotRow12 + $AccountVgoodTotRow13 + $AccountVgoodTotRow14); ?></th>
                <th><?= ($AccountExclTotRow1 + $AccountExclTotRow2 + $AccountExclTotRow3 + $AccountExclTotRow4 + $AccountExclTotRow5 + $AccountExclTotRow6 + $AccountExclTotRow7 + $AccountExclTotRow8 + $AccountExclTotRow9 + $AccountExclTotRow10 + $AccountExclTotRow11 + $AccountExclTotRow12 + $AccountExclTotRow13 + $AccountExclTotRow14); ?></th>
            </tr>


            <tr>
                <th colspan="7">HRD Mechanism</th>
            </tr>
            <tr>
                <th>Sr.No</th>
                <th>Name</th>
                <th>Average</th>
                <th>Need improvement</th>
                <th>Satisfactory</th>
                <th>Very Good</th>
                <th>Excellent</th>
            </tr>
            <tr>
                <td>1</td>
                <td>Seniors guide their juniors and prepare them for future responsibilities/rules they are likely to take up.</td>
                <td><?= $StoresavgTotRow1; ?></td>
                <td><?= $StoresNeedImpTotRow1 ?></td>
                <td><?= $StoresSatisfTotRow1; ?></td>
                <td><?= $StoresVgoodTotRow1; ?></td>
                <td><?= $StoresExclTotRow1; ?></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Promotion decisions are based on the suitability of the promotee rather than based on any favouritism or partiality.</td>
                <td><?= $StoresavgTotRow2; ?></td>
                <td><?= $StoresNeedImpTotRow2; ?></td>
                <td><?= $StoresSatisfTotRow2; ?></td>
                <td><?= $StoresVgoodTotRow2; ?></td>
                <td><?= $StoresExclTotRow2; ?></td>
            </tr>
            <tr>
                <td>3</td>
                <td>There are mechanisms in the organisation to reward any good work done or any contribution made by the employees.</td>
                <td><?= $StoresavgTotRow3; ?></td>
                <td><?= $StoresNeedImpTotRow3; ?></td>
                <td><?= $StoresSatisfTotRow3; ?></td>
                <td><?= $StoresVgoodTotRow3; ?></td>
                <td><?= $StoresExclTotRow3; ?></td>
            </tr>
            <tr>
                <td>4</td>
                <td>When an employee does good work his supervising officers take special care to appreciate it.</td>
                <td><?= $StoresavgTotRow4; ?></td>
                <td><?= $StoresNeedImpTotRow4; ?></td>
                <td><?= $StoresSatisfTotRow4; ?></td>
                <td><?= $StoresVgoodTotRow4; ?></td>
                <td><?= $StoresExclTotRow4; ?></td>
            </tr>
            <tr>
                <td>5</td>
                <td>Performance appraisal reports in this organisation are based on objective assessment and adequate information and not on the favouritism or partiality.</td>
                <td><?= $StoresavgTotRow5; ?></td>
                <td><?= $StoresNeedImpTotRow5; ?></td>
                <td><?= $StoresSatisfTotRow5; ?></td>
                <td><?= $StoresVgoodTotRow5; ?></td>
                <td><?= $StoresExclTotRow5; ?></td>
            </tr>
			<tr>
                <td>6</td>
                <td>Weaknesses of employees are communicated to them in a non-threatening way.</td>
                <td><?= $StoresavgTotRow6; ?></td>
                <td><?= $StoresNeedImpTotRow6; ?></td>
                <td><?= $StoresSatisfTotRow6; ?></td>
                <td><?= $StoresVgoodTotRow6; ?></td>
                <td><?= $StoresExclTotRow6; ?></td>
            </tr>
			
			<tr>
                <td>7</td>
                <td>When employees are sponsored for training, they take it seriously and try to learn from the programs they attend.</td>
                <td><?= $StoresavgTotRow7; ?></td>
                <td><?= $StoresNeedImpTotRow7; ?></td>
                <td><?= $StoresSatisfTotRow7; ?></td>
                <td><?= $StoresVgoodTotRow7; ?></td>
                <td><?= $StoresExclTotRow7; ?></td>
            </tr>
			<tr>
                <td>8</td>
                <td>Employees are sponsored for training programmes on the basis of genuine training needs.</td>
                <td><?= $StoresavgTotRow8; ?></td>
                <td><?= $StoresNeedImpTotRow8; ?></td>
                <td><?= $StoresSatisfTotRow8; ?></td>
                <td><?= $StoresVgoodTotRow8; ?></td>
                <td><?= $StoresExclTotRow8; ?></td>
            </tr>
			<tr>
                <td>9</td>
                <td>Team spirit is of high order in this organisation.</td>
                <td><?= $StoresavgTotRow9; ?></td>
                <td><?= $StoresNeedImpTotRow9; ?></td>
                <td><?= $StoresSatisfTotRow9; ?></td>
                <td><?= $StoresVgoodTotRow9; ?></td>
                <td><?= $StoresExclTotRow9; ?></td>
            </tr>
			<tr>
                <td>10</td>
                <td>When problems arise people discuss these problems openly and try to solve them rather than keep accusing each other behind the back.</td>
                <td><?= $StoresavgTotRow10; ?></td>
                <td><?= $StoresNeedImpTotRow10; ?></td>
                <td><?= $StoresSatisfTotRow10; ?></td>
                <td><?= $StoresVgoodTotRow10; ?></td>
                <td><?= $StoresExclTotRow10; ?></td>
            </tr>
			<tr>
                <td>11</td>
                <td>Carrier opportunities are pointed out to juniors by senior officers in the organisation.</td>
                <td><?= $StoresavgTotRow11; ?></td>
                <td><?= $StoresNeedImpTotRow11; ?></td>
                <td><?= $StoresSatisfTotRow11; ?></td>
                <td><?= $StoresVgoodTotRow11; ?></td>
                <td><?= $StoresExclTotRow11; ?></td>
            </tr>
			<tr>
                <td>12</td>
                <td>This organisation ensures employees welfare to such an extent that the employees can save a lot of their mental energy for work purposes..</td>
                <td><?= $StoresavgTotRow12; ?></td>
                <td><?= $StoresNeedImpTotRow12; ?></td>
                <td><?= $StoresSatisfTotRow12; ?></td>
                <td><?= $StoresVgoodTotRow12; ?></td>
                <td><?= $StoresExclTotRow12; ?></td>
            </tr>
			<tr>
                <td>13</td>
                <td>Job rotation in this organisation facilitates employee development.</td>
                <td><?= $StoresavgTotRow13; ?></td>
                <td><?= $StoresNeedImpTotRow13; ?></td>
                <td><?= $StoresSatisfTotRow13; ?></td>
                <td><?= $StoresVgoodTotRow13; ?></td>
                <td><?= $StoresExclTotRow13; ?></td>
            </tr>
            <tr>
                <th colspan="2">  Total </th>
                <th><?= ($StoresavgTotRow1 + $StoresavgTotRow2 + $StoresavgTotRow3 + $StoresavgTotRow4 + $StoresavgTotRow5 + $StoresavgTotRow6 + $StoresavgTotRow7 + $StoresavgTotRow8 + $StoresavgTotRow9 + $StoresavgTotRow10 + $StoresavgTotRow11 + $StoresavgTotRow12 + $StoresavgTotRow13); ?></th>
                <th><?= ($StoresNeedImpTotRow1 + $StoresNeedImpTotRow2 + $StoresNeedImpTotRow3 + $StoresNeedImpTotRow4 + $StoresNeedImpTotRow5 + $StoresNeedImpTotRow6 + $StoresNeedImpTotRow7 + $StoresNeedImpTotRow8 + $StoresNeedImpTotRow9 + $StoresNeedImpTotRow10 + $StoresNeedImpTotRow11 + $StoresNeedImpTotRow12 + $StoresNeedImpTotRow13); ?></th>
                <th><?= ($StoresSatisfTotRow1 + $StoresSatisfTotRow2 + $StoresSatisfTotRow3 + $StoresSatisfTotRow4 + $StoresSatisfTotRow5 + $StoresSatisfTotRow6 + $StoresSatisfTotRow7 + $StoresSatisfTotRow8 + $StoresSatisfTotRow9 + $StoresSatisfTotRow10 + $StoresSatisfTotRow11 + $StoresSatisfTotRow12 + $StoresSatisfTotRow13); ?></th>
                <th><?= ($StoresVgoodTotRow5 + $StoresVgoodTotRow2 + $StoresVgoodTotRow3 + $StoresVgoodTotRow4 + $StoresVgoodTotRow5 + $StoresVgoodTotRow6 + $StoresVgoodTotRow7 + $StoresVgoodTotRow8 + $StoresVgoodTotRow9 + $StoresVgoodTotRow10 + $StoresVgoodTotRow11 + $StoresVgoodTotRow12 + $StoresVgoodTotRow13); ?></th>
                <th><?= ($StoresExclTotRow1 + $StoresExclTotRow2 + $StoresExclTotRow3 + $StoresExclTotRow4 + $StoresExclTotRow5 + $StoresExclTotRow6 + $StoresExclTotRow7 + $StoresExclTotRow8 + $StoresExclTotRow9 + $StoresExclTotRow10 + $StoresExclTotRow11 + $StoresExclTotRow12 + $StoresExclTotRow13); ?></th>
            </tr>



            <!--<tr>
                <th colspan="7">IT</th>
            </tr>
            <tr>
                <th>Sr.No</th>
                <th>Name</th>
                <th>Average</th>
                <th>Need improvement</th>
                <th>Satisfactory</th>
                <th>Very Good</th>
                <th>Excellent</th>
            </tr>
            <tr>
                <td>1</td>
                <td>Process Knowledge of Procedures & Regulations</td>
                <td><?= $ITavgTotRow1; ?></td>
                <td><?= $ITNeedImpTotRow1 ?></td>
                <td><?= $ITSatisfTotRow1; ?></td>
                <td><?= $ITVgoodTotRow1; ?></td>
                <td><?= $ITExclTotRow1; ?></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Responsiveness & Reliability</td>
                <td><?= $ITavgTotRow2; ?></td>
                <td><?= $ITNeedImpTotRow2; ?></td>
                <td><?= $ITSatisfTotRow2; ?></td>
                <td><?= $ITVgoodTotRow2; ?></td>
                <td><?= $ITExclTotRow2; ?></td>
            </tr>
            <tr>
                <td>3</td>
                <td>Problem Solving & Result Orientation</td>
                <td><?= $ITavgTotRow3; ?></td>
                <td><?= $ITNeedImpTotRow3; ?></td>
                <td><?= $ITSatisfTotRow3; ?></td>
                <td><?= $ITVgoodTotRow3; ?></td>
                <td><?= $ITExclTotRow3; ?></td>
            </tr>
            <tr>
                <td>4</td>
                <td>Accessibility</td>
                <td><?= $ITavgTotRow4; ?></td>
                <td><?= $ITNeedImpTotRow4; ?></td>
                <td><?= $ITSatisfTotRow4; ?></td>
                <td><?= $ITVgoodTotRow4; ?></td>
                <td><?= $ITExclTotRow4; ?></td>
            </tr>
            <tr>
                <td>5</td>
                <td>Friendingness & Professionalism</td>
                <td><?= $ITavgTotRow5; ?></td>
                <td><?= $ITNeedImpTotRow5; ?></td>
                <td><?= $ITSatisfTotRow5; ?></td>
                <td><?= $ITVgoodTotRow5; ?></td>
                <td><?= $ITExclTotRow5; ?></td>
            </tr>
            <tr>
                <th colspan="2">  Total </th>
                <th><?= ($ITavgTotRow1 + $ITavgTotRow2 + $ITavgTotRow3 + $ITavgTotRow4 + $ITavgTotRow5); ?></th>
                <th><?= ($ITNeedImpTotRow1 + $ITNeedImpTotRow2 + $ITNeedImpTotRow3 + $ITNeedImpTotRow4 + $ITNeedImpTotRow5); ?></th>
                <th><?= ($ITSatisfTotRow1 + $ITSatisfTotRow2 + $ITSatisfTotRow3 + $ITSatisfTotRow4 + $ITSatisfTotRow5); ?></th>
                <th><?= ($ITVgoodTotRow5 + $ITVgoodTotRow2 + $ITVgoodTotRow3 + $ITVgoodTotRow4 + $ITVgoodTotRow5); ?></th>
                <th><?= ($ITExclTotRow1 + $ITExclTotRow2 + $ITExclTotRow3 + $ITExclTotRow4 + $ITExclTotRow5); ?></th>
            </tr>


            <tr>
                <th colspan="7"> Admin </th>
            </tr>
            <tr>
                <th>Sr.No</th>
                <th>Name</th>
                <th>Average</th>
                <th>Need improvement</th>
                <th>Satisfactory</th>
                <th>Very Good</th>
                <th>Excellent</th>
            </tr>
            <tr>
                <td>1</td>
                <td>Process Knowledge of Procedures & Regulations</td>
                <td><?= $AdministrationavgTotRow1; ?></td>
                <td><?= $AdministrationNeedImpTotRow1 ?></td>
                <td><?= $AdministrationSatisfTotRow1; ?></td>
                <td><?= $AdministrationVgoodTotRow1; ?></td>
                <td><?= $AdministrationExclTotRow1; ?></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Responsiveness & Reliability</td>
                <td><?= $AdministrationavgTotRow2; ?></td>
                <td><?= $AdministrationNeedImpTotRow2; ?></td>
                <td><?= $AdministrationSatisfTotRow2; ?></td>
                <td><?= $AdministrationVgoodTotRow2; ?></td>
                <td><?= $AdministrationExclTotRow2; ?></td>
            </tr>
            <tr>
                <td>3</td>
                <td>Problem Solving & Result Orientation</td>
                <td><?= $AdministrationavgTotRow3; ?></td>
                <td><?= $AdministrationNeedImpTotRow3; ?></td>
                <td><?= $AdministrationSatisfTotRow3; ?></td>
                <td><?= $AdministrationVgoodTotRow3; ?></td>
                <td><?= $AdministrationExclTotRow3; ?></td>
            </tr>
            <tr>
                <td>4</td>
                <td>Accessibility</td>
                <td><?= $AdministrationavgTotRow4; ?></td>
                <td><?= $AdministrationNeedImpTotRow4; ?></td>
                <td><?= $AdministrationSatisfTotRow4; ?></td>
                <td><?= $AdministrationVgoodTotRow4; ?></td>
                <td><?= $AdministrationExclTotRow4; ?></td>
            </tr>
            <tr>
                <td>5</td>
                <td>Friendingness & Professionalism</td>
                <td><?= $AdministrationavgTotRow5; ?></td>
                <td><?= $AdministrationNeedImpTotRow5; ?></td>
                <td><?= $AdministrationSatisfTotRow5; ?></td>
                <td><?= $AdministrationVgoodTotRow5; ?></td>
                <td><?= $AdministrationExclTotRow5; ?></td>
            </tr>
            <tr>
                <th colspan="2">  Total </th>
                <th><?= ($AdministrationavgTotRow1 + $AdministrationavgTotRow2 + $AdministrationavgTotRow3 + $AdministrationavgTotRow4 + $AdministrationavgTotRow5); ?></th>
                <th><?= ($AdministrationNeedImpTotRow1 + $AdministrationNeedImpTotRow2 + $AdministrationNeedImpTotRow3 + $AdministrationNeedImpTotRow4 + $AdministrationNeedImpTotRow5); ?></th>
                <th><?= ($AdministrationSatisfTotRow1 + $AdministrationSatisfTotRow2 + $AdministrationSatisfTotRow3 + $AdministrationSatisfTotRow4 + $AdministrationSatisfTotRow5); ?></th>
                <th><?= ($AdministrationVgoodTotRow5 + $AdministrationVgoodTotRow2 + $AdministrationVgoodTotRow3 + $AdministrationVgoodTotRow4 + $AdministrationVgoodTotRow5); ?></th>
                <th><?= ($AdministrationExclTotRow1 + $AdministrationExclTotRow2 + $AdministrationExclTotRow3 + $AdministrationExclTotRow4 + $AdministrationExclTotRow5); ?></th>
            </tr>


            <tr>
                <th colspan="7"> Software Department </th>
            </tr>
            <tr>
                <th>Sr.No</th>
                <th>Name</th>
                <th>Average</th>
                <th>Need improvement</th>
                <th>Satisfactory</th>
                <th>Very Good</th>
                <th>Excellent</th>
            </tr>
            <tr>
                <td>1</td>
                <td>Process Knowledge of Procedures & Regulations</td>
                <td><?= $SoftavgTotRow1; ?></td>
                <td><?= $SoftNeedImpTotRow1 ?></td>
                <td><?= $SoftSatisfTotRow1; ?></td>
                <td><?= $SoftVgoodTotRow1; ?></td>
                <td><?= $SoftExclTotRow1; ?></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Responsiveness & Reliability</td>
                <td><?= $SoftavgTotRow2; ?></td>
                <td><?= $SoftNeedImpTotRow2; ?></td>
                <td><?= $SoftSatisfTotRow2; ?></td>
                <td><?= $SoftVgoodTotRow2; ?></td>
                <td><?= $SoftExclTotRow2; ?></td>
            </tr>
            <tr>
                <td>3</td>
                <td>Problem Solving & Result Orientation</td>
                <td><?= $SoftavgTotRow3; ?></td>
                <td><?= $SoftNeedImpTotRow3; ?></td>
                <td><?= $SoftSatisfTotRow3; ?></td>
                <td><?= $SoftVgoodTotRow3; ?></td>
                <td><?= $SoftExclTotRow3; ?></td>
            </tr>
            <tr>
                <td>4</td>
                <td>Accessibility</td>
                <td><?= $SoftavgTotRow4; ?></td>
                <td><?= $SoftNeedImpTotRow4; ?></td>
                <td><?= $SoftSatisfTotRow4; ?></td>
                <td><?= $SoftVgoodTotRow4; ?></td>
                <td><?= $SoftExclTotRow4; ?></td>
            </tr>
            <tr>
                <td>5</td>
                <td>Friendingness & Professionalism</td>
                <td><?= $SoftavgTotRow5; ?></td>
                <td><?= $SoftNeedImpTotRow5; ?></td>
                <td><?= $SoftSatisfTotRow5; ?></td>
                <td><?= $SoftVgoodTotRow5; ?></td>
                <td><?= $SoftExclTotRow5; ?></td>
            </tr>
            <tr>
                <th colspan="2">  Total </th>
                <th><?= ($SoftavgTotRow1 + $SoftavgTotRow2 + $SoftavgTotRow3 + $SoftavgTotRow4 + $SoftavgTotRow5); ?></th>
                <th><?= ($SoftNeedImpTotRow1 + $SoftNeedImpTotRow2 + $SoftNeedImpTotRow3 + $SoftNeedImpTotRow4 + $SoftNeedImpTotRow5); ?></th>
                <th><?= ($SoftSatisfTotRow1 + $SoftSatisfTotRow2 + $SoftSatisfTotRow3 + $SoftSatisfTotRow4 + $SoftSatisfTotRow5); ?></th>
                <th><?= ($SoftVgoodTotRow5 + $SoftVgoodTotRow2 + $SoftVgoodTotRow3 + $SoftVgoodTotRow4 + $SoftVgoodTotRow5); ?></th>
                <th><?= ($SoftExclTotRow1 + $SoftExclTotRow2 + $SoftExclTotRow3 + $SoftExclTotRow4 + $SoftExclTotRow5); ?></th>
            </tr>-->
        </table>
        <?php
    }
	

}
