<?php
defined('BASEPATH') or exit('No direct script access allowed');
error_reporting(0);
class Financial_statement_controller extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('mastermodel');
		$this->load->library('form_validation');

		$this->db1 = $this->load->database('default', TRUE);
		$this->db2 = $this->load->database('default', TRUE);
		$this->db3 = $this->load->database('accdept_db', TRUE);


		if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
			redirect(base_url(""));
		}

		$this->loginid = $this->session->userdata('loginid');
	}

	//Financial Statement..
	public function financial_statement()
	{
		$db1 = $this->db1->database;
		$db2 = $this->db2->database;
		$db3 = $this->db3->database;

		$this->db->select("$db3.a.*");
		$this->db->from("$db3.financial_year_slot as a");
		$this->db->where(array("$db3.a.status" => "1"));
		$recArr = $this->db->get()->result();

		$data['error'] = '';
		$data['title'] = 'Financial Statement';
		$data['Financ_statementArr'] = $recArr;

		$this->load->view("financial_statement/financ_statement_list_views", $data);
	}


	//Financial Statement Entry by Hr..,
	public function financial_statement_entry($finc_id)
	{
		$db1 = $this->db1->database;
		$db2 = $this->db2->database;
		$db3 = $this->db3->database;

		$this->db->select("$db3.a.*");
		$this->db->from("$db3.financial_year_ofc_loc_master as a");
		$this->db->where(array("$db3.a.status" => "1"));
		$OfcLocationRecordArr = $this->db->get()->result();

		$data['error'] = '';
		$data['title'] = 'Office Location List';
		$data['OfcLocationRecordArr'] = $OfcLocationRecordArr;
		$data['FinancialYearDetailsArr'] = $this->financialYearDetailsByID($finc_id);
		$this->load->view("financial_statement/fin_s_ofc_location_list_views", $data);
	}


	//Single Entry By Hr ...
	public function financial_statement_hr_entry()
	{
		$finc_id = $this->uri->segment(2);
		$ofc_loc_id = $this->uri->segment(3);

		$data['error'] = '';
		$data['title'] = 'Office Location List';
		$data['OfcLocationRecordArr'] = $this->ofc_locationDetailsByID($ofc_loc_id);
		$data['FinancialYearDetailsArr'] = $this->financialYearDetailsByID($finc_id);
		$data['AllCategoryDetailsArr'] = $this->GetAllCategoryDetails($ofc_loc_id);
		$data['AllDetailsMasterArr'] = $this->DetailsMasterAll();

		$data['ExistsExpensEntryRecArr'] = $this->GetExpenseAmountEntryDetails($finc_id, $ofc_loc_id);


		// echo "<pre>ee";
		// print_r($data['ExistsExpensEntryRecArr']);
		// die;

		$this->load->view("financial_statement/financialyear_entry_by_hr_views", $data);
	}


	public function GetExpenseAmountEntryDetails($finc_id, $ofc_loc_id)
	{
		$db1 = $this->db1->database;
		$db2 = $this->db2->database;
		$db3 = $this->db3->database;

		$returnArr = array();
		$AllCategoryDetailsArr = $this->GetAllCategoryDetails($ofc_loc_id);
		if ($AllCategoryDetailsArr) {
			foreach ($AllCategoryDetailsArr as $row) {

				$this->db->select("$db3.a.*");
				$this->db->from("$db3.financial_year_entryhr as a");
				$this->db->where(array("$db3.a.status" => "1", "$db3.a.slot_id" => $finc_id,  "$db3.a.ofc_location_id" => $ofc_loc_id, "$db3.a.type_id" => $row->category_id));
				$RowRecordArr = $this->db->get()->result_array();

				$retArray = array();
				if ($RowRecordArr) {
					foreach ($RowRecordArr as $Rows) {
						$Rows['sumAmount'] = ($Rows['curr_01'] + $Rows['curr_02'] + $Rows['curr_03'] + $Rows['curr_04'] + $Rows['curr_05'] + $Rows['curr_06'] + $Rows['curr_07'] + $Rows['curr_08'] + $Rows['curr_09'] + $Rows['curr_10'] + $Rows['curr_11'] + $Rows['curr_12']);
						$retArray[$Rows['category_id']] = $Rows;
					}
				}
				$returnArr[$row->category_id] = $retArray;
			}
		}
		return ($returnArr) ? $returnArr : null;
	}



	public function financialYearDetailsByID($finc_id)
	{
		$db1 = $this->db1->database;
		$db2 = $this->db2->database;
		$db3 = $this->db3->database;

		$this->db->select("$db3.a.*");
		$this->db->from("$db3.financial_year_slot as a");
		$this->db->where(array("$db3.a.status" => "1", "$db3.a.fld_id" => $finc_id));
		$RowRecordArr = $this->db->get()->row();
		return ($RowRecordArr) ? $RowRecordArr : null;
	}


	//Single Ofc Location Details By ID...
	public function ofc_locationDetailsByID($ofcloc_id)
	{
		$db1 = $this->db1->database;
		$db2 = $this->db2->database;
		$db3 = $this->db3->database;

		$this->db->select("$db3.a.*");
		$this->db->from("$db3.financial_year_ofc_loc_master as a");
		$this->db->where(array("$db3.a.status" => "1", "$db3.a.fld_id" => $ofcloc_id));
		$RowRecordArr = $this->db->get()->row();
		return ($RowRecordArr) ? $RowRecordArr : null;
	}

	//Get All Category Details..,
	public function GetAllCategoryDetails($ofc_loc_id)
	{
		$db1 = $this->db1->database;
		$db2 = $this->db2->database;
		$db3 = $this->db3->database;

		$this->db->select("$db3.a.*,$db3.b.categ_name");
		$this->db->from("$db3.financial_year_assign_category as a");
		$this->db->join("$db3.financial_year_manpower_categ as b", "$db3.a.category_id=$db3.b.fld_id", "LEFT");
		$this->db->where(array("$db3.a.status" => "1", "$db3.a.ofc_loc_id" => $ofc_loc_id));
		$RowRecordArr = $this->db->order_by("$db3.a.fld_id", "ASC");
		$RowRecordArr = $this->db->get()->result();
		return ($RowRecordArr) ? $RowRecordArr : null;
	}

	//Details Category Master..,
	public function DetailsMasterAll()
	{
		$db1 = $this->db1->database;
		$db2 = $this->db2->database;
		$db3 = $this->db3->database;

		$this->db->select("$db3.a.*");
		$this->db->from("$db3.financial_year_detail_master_hr as a");
		$this->db->where(array("$db3.a.status" => "1"));
		$this->db->order_by("$db3.a.fld_id", "ASC");
		$RowRecordArr = $this->db->get()->result();
		return ($RowRecordArr) ? $RowRecordArr : null;
	}


	//E#ntry And Update By HR/.... Code By 17-01-2022
	public function financial_entrybyhr_save_upd()
	{
		$db1 = $this->db1->database;
		$db2 = $this->db2->database;
		$db3 = $this->db3->database;

		$fin_slotid = $_REQUEST['fin_slotid'];
		$ofc_location_id = $_REQUEST['ofc_location_id'];
		$categ_idactArr = $_REQUEST['categ_idact'];
		$type_id = $_REQUEST['type_id'];

		// echo "<pre>";
		// print_r($_REQUEST);
		// die;


		$respU = '';
		$resp = '';

		if ($fin_slotid and $ofc_location_id and $categ_idactArr) {
			foreach ($categ_idactArr as $rOws) {

				$curr_04 = $_REQUEST['curr_' . $rOws][0];
				$curr_05 = $_REQUEST['curr_' . $rOws][1];
				$curr_06 = $_REQUEST['curr_' . $rOws][2];
				$curr_07 = $_REQUEST['curr_' . $rOws][3];
				$curr_08 = $_REQUEST['curr_' . $rOws][4];
				$curr_09 = $_REQUEST['curr_' . $rOws][5];
				$curr_10 = $_REQUEST['curr_' . $rOws][6];
				$curr_11 = $_REQUEST['curr_' . $rOws][7];
				$curr_12 = $_REQUEST['curr_' . $rOws][8];
				$curr_01 = $_REQUEST['curr_' . $rOws][9];
				$curr_02 = $_REQUEST['curr_' . $rOws][10];
				$curr_03 = $_REQUEST['curr_' . $rOws][11];

				//All Ready Exist..
				$whereArr = array(
					"$db3.financial_year_entryhr.slot_id" => $fin_slotid,
					"$db3.financial_year_entryhr.ofc_location_id" => $ofc_location_id,
					"$db3.financial_year_entryhr.type_id" => $type_id,
					"$db3.financial_year_entryhr.category_id" => $rOws,
					"$db3.financial_year_entryhr.status" => "1"
				);

				$num_results = $this->db
					->where($whereArr)
					->count_all_results("$db3.financial_year_entryhr");
				if ($num_results < 1) {

					$insert_Arr = array(
						"$db3.financial_year_entryhr.slot_id" => $fin_slotid,
						"$db3.financial_year_entryhr.ofc_location_id" => $ofc_location_id,
						"$db3.financial_year_entryhr.type_id" => $type_id,
						"$db3.financial_year_entryhr.category_id" => $rOws,
						"$db3.financial_year_entryhr.curr_04" => ($curr_04) ? $curr_04 : '0',
						"$db3.financial_year_entryhr.curr_05" => ($curr_05) ? $curr_05 : '0',
						"$db3.financial_year_entryhr.curr_06" => ($curr_06) ? $curr_06 : '0',
						"$db3.financial_year_entryhr.curr_07" => ($curr_07) ? $curr_07 : '0',
						"$db3.financial_year_entryhr.curr_08" => ($curr_08) ? $curr_08 : '0',
						"$db3.financial_year_entryhr.curr_09" => ($curr_09) ? $curr_09 : '0',
						"$db3.financial_year_entryhr.curr_10" => ($curr_10) ? $curr_10 : '0',
						"$db3.financial_year_entryhr.curr_11" => ($curr_11) ? $curr_11 : '0',
						"$db3.financial_year_entryhr.curr_12" => ($curr_12) ? $curr_12 : '0',
						"$db3.financial_year_entryhr.curr_01" => ($curr_01) ? $curr_01 : '0',
						"$db3.financial_year_entryhr.curr_02" => ($curr_02) ? $curr_02 : '0',
						"$db3.financial_year_entryhr.curr_03" => ($curr_03) ? $curr_03 : '0',
						"$db3.financial_year_entryhr.update_by" => $this->loginid,
						"$db3.financial_year_entryhr.last_update" => date("Y-m-d h:i:s")
					);
					$resp = $this->db->insert("$db3.financial_year_entryhr", $insert_Arr);
				} else {

					$updateDataArr = array(
						"$db3.financial_year_entryhr.curr_04" => ($curr_04) ? $curr_04 : '0',
						"$db3.financial_year_entryhr.curr_05" => ($curr_05) ? $curr_05 : '0',
						"$db3.financial_year_entryhr.curr_06" => ($curr_06) ? $curr_06 : '0',
						"$db3.financial_year_entryhr.curr_07" => ($curr_07) ? $curr_07 : '0',
						"$db3.financial_year_entryhr.curr_08" => ($curr_08) ? $curr_08 : '0',
						"$db3.financial_year_entryhr.curr_09" => ($curr_09) ? $curr_09 : '0',
						"$db3.financial_year_entryhr.curr_10" => ($curr_10) ? $curr_10 : '0',
						"$db3.financial_year_entryhr.curr_11" => ($curr_11) ? $curr_11 : '0',
						"$db3.financial_year_entryhr.curr_12" => ($curr_12) ? $curr_12 : '0',
						"$db3.financial_year_entryhr.curr_01" => ($curr_01) ? $curr_01 : '0',
						"$db3.financial_year_entryhr.curr_02" => ($curr_02) ? $curr_02 : '0',
						"$db3.financial_year_entryhr.curr_03" => ($curr_03) ? $curr_03 : '0',
						"$db3.financial_year_entryhr.entry_by" => $this->loginid
					);

					$this->db->where($whereArr);
					$respU = $this->db->update("$db3.financial_year_entryhr",  $updateDataArr);
				}
			}
		}

		if ($resp) :
			$this->session->set_flashdata('success_msg', "Amount Inserted Successfulll done. ");
		endif;

		if ($respU) :
			$this->session->set_flashdata('success_msg', "Amount Updated Successfulll done. ");
		endif;
		redirect($_SERVER['HTTP_REFERER']);
	}
}
