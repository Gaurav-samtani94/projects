<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();

        //$this->load->model('attendance');
        $this->load->model('mastermodel');
        $this->load->model('attendance/Attendance_Model','attendance_model');
        $this->load->library('session');
        $this->load->library("user_agent");
    }

    //Attendance Controller..
    public function index() {
        // epd("see");
        $recData = array('');
        $userid = '';
        $bus_id = '';
        $dpt_id = '';
        $recData['title'] = "Monthly Employee Attendance";
        $recData['userrecArr'] = $this->empUserID($userid, $bus_id, $dpt_id);
        $recData['UnitNameArr']=$this->mastermodel->getBusinessUnit();
        if ($_REQUEST["attendance_month"]) {
            $recData['atten_month']=$_REQUEST["attendance_month"];
            $recData['atten_year']=$_REQUEST["attendance_year"];
            $recData['user_id']=($_REQUEST["user_id"]) ? $_REQUEST["user_id"] : '';
            $recData['departmentids']=($_REQUEST["departmentids"]) ? $_REQUEST["departmentids"] : '';
            $recData['businessunit']=($_REQUEST["businessunit"]) ? $_REQUEST["businessunit"] : '';
            $from_date = $_REQUEST["attendance_year"] . '-' . $_REQUEST["attendance_month"] . "" . "-01";
            $to_date = date("t-m-Y", strtotime($from_date));
            $recData['dateRangeArr']= $this->mastermodel->getDatesFromRange($from_date, $to_date);
            $recData['month_last_date']= date("t", strtotime($from_date));
            $recData['attendance']=$this->attendance_model->Get_Monthly_Attendance($to_date, $recData['user_id'], $recData['departmentids'],$recData['businessunit']);
        }else{
            $recData['atten_year'] = date("Y");
            $from_date = "01-" . date("m-Y");
            $to_date = date("t-m-Y", strtotime($from_date));
            $recData['dateRangeArr']= $this->mastermodel->getDatesFromRange($from_date, $to_date);
            $recData['month_last_date']= date("t", strtotime($from_date));
            $recData['attendance']=$this->attendance_model->Get_Monthly_Attendance($to_date, $user_id='', $departmentids='',$businessunit='');
            $recData['atten_month']=date("m", strtotime($from_date));
        }
        // epd($recData['attendance']);
        $this->load->view('attendance/monthly_attendance_view', $recData);
    }
    public function empUserID($userId, $bus_id, $dpt_id) {
        $this->db->select("a.user_id,a.userfullname,a.employeeId,b.machine_id,a.department_name,a.department_id");
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        if ($userId != ''):
            $this->db->where(array('a.user_id' => $userId));
        endif;
        if ($bus_id != ''):
            $this->db->where(array('a.businessunit_id' => $bus_id));
        endif;
        if ($dpt_id != ''):
            $this->db->where(array('a.department_id' => $dpt_id));
        endif;
        $this->db->where(array('a.isactive' => '1'));
        $this->db->where('b.machine_id !=', null);
        $this->db->where_not_in('a.user_id',[2,173,175,190]);
        $this->db->group_by("a.user_id");
        $userRec = $this->db->get()->result();
        return ($userRec) ? $userRec : null;
    }

    public function Attendance_Monthly_Script(){
        $leaveArr = array(1 => 'L', 2 => 'HDL', 3 => 'SL', 4=>'RH', 5=>'H', 6=>'T',7=>'WFH');
        $list=$this->attendance_model->get_datatables();
        $atten_month = date("m", strtotime("first day of previous month"));
        // $atten_month="08";
        $atten_year = date("Y", strtotime("first day of previous month"));
        $from_date = "01-".$atten_month.'-'.$atten_year;
        // $from_date ="01-08-2023";
        $to_date = date("t-m-Y", strtotime($from_date));
        $dateRangeArr= $this->getDatesFromRange($from_date, $to_date);
        // epd($dateRangeArr); 
        foreach ($list as $keys=>$roWs) {
            $countql=array();
            $counthd=array();

            $countlhd=array();
            $countlql=array();
            $AllPunchStatus=array();
            $AllPunchP=array();
            $wfhRec=array();
            // Total Count
            $countlql1=0;
            $TotalLateCount=0;
            if ($dateRangeArr) {
                foreach ($dateRangeArr as $kEy => $dataRow) {
                    // epd($dataRow);
                    $Dispdate = date("d-m-Y", strtotime($dataRow));
                    $wfh=$this->mastermodel->WorkFromHome($roWs->user_id, $atten_month, $atten_year, $Dispdate);
                    if($wfh == 1){
                        $wfhRec[$dataRow]='7';
                    }
                    $AllPunchStatus[$kEy]=$this->mastermodel->GetAllPunchDetail($Dispdate, $roWs->machine_id);
                    if($AllPunchStatus[$kEy] == 'P'){
                        $AllPunchP[$kEy]=$dataRow;
                    }
                    // epd($AllPunchP);
                    $punchRec = $this->mastermodel->getSingleDateAttByUserID($Dispdate, $roWs->machine_id, $roWs->user_id);
                    // epd($punchRec);
                    $late_by_count = (@$punchRec['lateby']) ? round(@$punchRec['lateby']) : "0";
                    $early_by_count = (@$punchRec['earlyby']) ? round(@$punchRec['earlyby']) : "0";
                    $totalcount = ($late_by_count + $early_by_count) ? ($late_by_count + $early_by_count) : "";
                    if ($totalcount){
                        if (($totalcount > 60) AND ($totalcount <= 135)){
                            $qlprint = 'QL';
                            $countql[$kEy]='QL';
                        }elseif(($totalcount > 135) AND ($totalcount < 270)){
                            $hdprint = 'HD';
                            $counthd[$kEy]='HD';
                        }elseif ($totalcount > 270){
                             $hdprint = 'HD';
                             $counthd[$kEy]='HD';
                        }elseif ($totalcount < 60){
                            $lqlprint = 'LQL';
                            $lhdprint = 'LHD';
                            $TotalLateCount += @$totalcount;
                            if ($TotalLateCount > 60) {
                                $lqlprint2 = 1;
                                $countlql1 += $lqlprint2;
                                if ($countlql1 > 8) {
                                    $countlhd[$kEy]='LHD';
                                } else {
                                    $countlql[$kEy]='LQL';
                                }
                            }
                        }
                    }
                   
                }
            }
            $leaveCombineArr = $this->mastermodel->GetAllLeaveListArr(date('Y-m-d', strtotime($from_date)), date('Y-m-d', strtotime($to_date)), $roWs->user_id);
            $holidaysDateArr = $this->mastermodel->holidayCount(date('Y-m-d', strtotime($from_date)), date('Y-m-d', strtotime($to_date)));
            if($holidaysDateArr){
                $leaveCombineArr=array_merge($leaveCombineArr,$holidaysDateArr);
            }
            $tourDateArr = $this->mastermodel->GetAllTourListArr($from_date, $to_date, $roWs->user_id);
            if($tourDateArr){
                 $leaveCombineArr=array_merge($leaveCombineArr,$tourDateArr);
            }
            if($wfhRec){
                $leaveCombineArr=array_merge($leaveCombineArr,$wfhRec);
            }
            // epd($leaveCombineArr);
            $leaveCount=array_count_values($leaveCombineArr);
            $leaveDateArr=array_keys($leaveCombineArr);

            $updateArr=array(
                'user_id'=>$roWs->user_id,
                'B_unit_id'=>$roWs->businessunit_id,
                'department_id'=>$roWs->department_id,
                'Year'=>$atten_year,
                'Month'=>$atten_month,
                'S_in_time'=>$roWs->shift_in_time,
                'S_out_time'=>$roWs->shift_out_time,
                'd_01'=>((date('D', strtotime($dateRangeArr[0])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[0], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[0]]] : (($countql[0]) ? 'QL' : (($counthd[0]) ? 'HD' : (($countlql[0]) ? 'LQL' : (($countlhd[0]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[0])) == 'Sat') ? (($AllPunchStatus[0]=='P') ? $AllPunchStatus[0] : 'WO') : $AllPunchStatus[0]))))))),
			    'd_02'=>((date('D', strtotime($dateRangeArr[1])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[1], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[1]]] : (($countql[1]) ? 'QL' : (($counthd[1]) ? 'HD' : (($countlql[1]) ? 'LQL' : (($countlhd[1]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[1])) == 'Sat') ? (($AllPunchStatus[1]=='P') ? $AllPunchStatus[1] : 'WO') : $AllPunchStatus[1]))))))),
                'd_03'=>((date('D', strtotime($dateRangeArr[2])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[2], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[2]]] : (($countql[2]) ? 'QL' : (($counthd[2]) ? 'HD' : (($countlql[2]) ? 'LQL' : (($countlhd[2]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[2])) == 'Sat') ? (($AllPunchStatus[2]=='P') ? $AllPunchStatus[2] : 'WO') : $AllPunchStatus[2]))))))),
			    'd_04'=>((date('D', strtotime($dateRangeArr[3])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[3], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[3]]] : (($countql[3]) ? 'QL' : (($counthd[3]) ? 'HD' : (($countlql[3]) ? 'LQL' : (($countlhd[3]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[3])) == 'Sat') ? (($AllPunchStatus[3]=='P') ? $AllPunchStatus[3] : 'WO') : $AllPunchStatus[3]))))))),
			    'd_05'=>((date('D', strtotime($dateRangeArr[4])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[4], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[4]]] : (($countql[4]) ? 'QL' : (($counthd[4]) ? 'HD' : (($countlql[4]) ? 'LQL' : (($countlhd[4]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[4])) == 'Sat') ? (($AllPunchStatus[4]=='P') ? $AllPunchStatus[4] : 'WO') : $AllPunchStatus[4]))))))),
			    'd_06'=>((date('D', strtotime($dateRangeArr[5])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[5], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[5]]] : (($countql[5]) ? 'QL' : (($counthd[5]) ? 'HD' : (($countlql[5]) ? 'LQL' : (($countlhd[5]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[5])) == 'Sat') ? (($AllPunchStatus[5]=='P') ? $AllPunchStatus[5] : 'WO') : $AllPunchStatus[5]))))))),
			    'd_07'=>((date('D', strtotime($dateRangeArr[6])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[6], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[6]]] : (($countql[6]) ? 'QL' : (($counthd[6]) ? 'HD' : (($countlql[6]) ? 'LQL' : (($countlhd[6]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[6])) == 'Sat') ? (($AllPunchStatus[6]=='P') ? $AllPunchStatus[6] : 'WO') : $AllPunchStatus[6]))))))),
                'd_08'=>((date('D', strtotime($dateRangeArr[7])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[7], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[7]]] : (($countql[7]) ? 'QL' : (($counthd[7]) ? 'HD' : (($countlql[7]) ? 'LQL' : (($countlhd[7]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[7])) == 'Sat') ? (($AllPunchStatus[7]=='P') ? $AllPunchStatus[7] : 'WO') : $AllPunchStatus[7]))))))),
			    'd_09'=>((date('D', strtotime($dateRangeArr[8])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[8], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[8]]] : (($countql[8]) ? 'QL' : (($counthd[8]) ? 'HD' : (($countlql[8]) ? 'LQL' : (($countlhd[8]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[8])) == 'Sat') ? (($AllPunchStatus[8]=='P') ? $AllPunchStatus[8] : 'WO') : $AllPunchStatus[8]))))))),
			    'd_10'=>((date('D', strtotime($dateRangeArr[9])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[9], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[9]]] : (($countql[9]) ? 'QL' : (($counthd[9]) ? 'HD' : (($countlql[9]) ? 'LQL' : (($countlhd[9]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[9])) == 'Sat') ? (($AllPunchStatus[9]=='P') ? $AllPunchStatus[9] : 'WO') : $AllPunchStatus[9]))))))),
			    'd_11'=>((date('D', strtotime($dateRangeArr[10])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[10], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[10]]] : (($countql[10]) ? 'QL' : (($counthd[10]) ? 'HD' : (($countlql[10]) ? 'LQL': (($countlhd[10]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[10])) == 'Sat') ? (($AllPunchStatus[10]=='P') ? $AllPunchStatus[10] : 'WO') : $AllPunchStatus[10]))))))),
			    'd_12'=>((date('D', strtotime($dateRangeArr[11])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[11], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[11]]] : (($countql[11]) ? 'QL' : (($counthd[11]) ? 'HD' : (($countlql[11]) ? 'LQL': (($countlhd[11]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[11])) == 'Sat') ? (($AllPunchStatus[11]=='P') ? $AllPunchStatus[11] : 'WO') : $AllPunchStatus[11]))))))),
                'd_13'=>((date('D', strtotime($dateRangeArr[12])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[12], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[12]]] : (($countql[12]) ? 'QL' : (($counthd[12]) ? 'HD' : (($countlql[12]) ? 'LQL': (($countlhd[12]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[12])) == 'Sat') ? (($AllPunchStatus[12]=='P') ? $AllPunchStatus[12] : 'WO') : $AllPunchStatus[12]))))))),
			    'd_14'=>((date('D', strtotime($dateRangeArr[13])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[13], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[13]]] : (($countql[13]) ? 'QL' : (($counthd[13]) ? 'HD' : (($countlql[13]) ? 'LQL': (($countlhd[13]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[13])) == 'Sat') ? (($AllPunchStatus[13]=='P') ? $AllPunchStatus[13] : 'WO') : $AllPunchStatus[13]))))))),
			    'd_15'=>((date('D', strtotime($dateRangeArr[14])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[14], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[14]]] : (($countql[14]) ? 'QL' : (($counthd[14]) ? 'HD' : (($countlql[14]) ? 'LQL': (($countlhd[14]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[14])) == 'Sat') ? (($AllPunchStatus[14]=='P') ? $AllPunchStatus[14] : 'WO') : $AllPunchStatus[14]))))))),
			    'd_16'=>((date('D', strtotime($dateRangeArr[15])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[15], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[15]]] : (($countql[15]) ? 'QL' : (($counthd[15]) ? 'HD' : (($countlql[15]) ? 'LQL': (($countlhd[15]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[15])) == 'Sat') ? (($AllPunchStatus[15]=='P') ? $AllPunchStatus[15] : 'WO') : $AllPunchStatus[15]))))))),
			    'd_17'=>((date('D', strtotime($dateRangeArr[16])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[16], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[16]]] : (($countql[16]) ? 'QL' : (($counthd[16]) ? 'HD' : (($countlql[16]) ? 'LQL': (($countlhd[16]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[16])) == 'Sat') ? (($AllPunchStatus[16]=='P') ? $AllPunchStatus[16] : 'WO') : $AllPunchStatus[16]))))))),
                'd_18'=>((date('D', strtotime($dateRangeArr[17])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[17], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[17]]] : (($countql[17]) ? 'QL' : (($counthd[17]) ? 'HD' : (($countlql[17]) ? 'LQL': (($countlhd[17]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[17])) == 'Sat') ? (($AllPunchStatus[17]=='P') ? $AllPunchStatus[17] : 'WO') : $AllPunchStatus[17]))))))),
			    'd_19'=>((date('D', strtotime($dateRangeArr[18])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[18], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[18]]] : (($countql[18]) ? 'QL' : (($counthd[18]) ? 'HD' : (($countlql[18]) ? 'LQL': (($countlhd[18]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[18])) == 'Sat') ? (($AllPunchStatus[18]=='P') ? $AllPunchStatus[18] : 'WO') : $AllPunchStatus[18]))))))),
			    'd_20'=>((date('D', strtotime($dateRangeArr[19])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[19], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[19]]] : (($countql[19]) ? 'QL' : (($counthd[19]) ? 'HD' : (($countlql[19]) ? 'LQL': (($countlhd[19]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[19])) == 'Sat') ? (($AllPunchStatus[19]=='P') ? $AllPunchStatus[19] : 'WO') : $AllPunchStatus[19]))))))),
			    'd_21'=>((date('D', strtotime($dateRangeArr[20])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[20], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[20]]] : (($countql[20]) ? 'QL' : (($counthd[20]) ? 'HD' : (($countlql[20]) ? 'LQL': (($countlhd[20]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[20])) == 'Sat') ? (($AllPunchStatus[20]=='P') ? $AllPunchStatus[20] : 'WO') : $AllPunchStatus[20]))))))),
			    'd_22'=>((date('D', strtotime($dateRangeArr[21])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[21], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[21]]] : (($countql[21]) ? 'QL' : (($counthd[21]) ? 'HD' : (($countlql[21]) ? 'LQL': (($countlhd[21]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[21])) == 'Sat') ? (($AllPunchStatus[21]=='P') ? $AllPunchStatus[21] : 'WO') : $AllPunchStatus[21]))))))),
                'd_23'=>((date('D', strtotime($dateRangeArr[22])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[22], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[22]]] : (($countql[22]) ? 'QL' : (($counthd[22]) ? 'HD' : (($countlql[22]) ? 'LQL': (($countlhd[22]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[22])) == 'Sat') ? (($AllPunchStatus[22]=='P') ? $AllPunchStatus[22] : 'WO') : $AllPunchStatus[22]))))))),
			    'd_24'=>((date('D', strtotime($dateRangeArr[23])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[23], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[23]]] : (($countql[23]) ? 'QL' : (($counthd[23]) ? 'HD' : (($countlql[23]) ? 'LQL': (($countlhd[23]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[23])) == 'Sat') ? (($AllPunchStatus[23]=='P') ? $AllPunchStatus[23] : 'WO') : $AllPunchStatus[23]))))))),
			    'd_25'=>((date('D', strtotime($dateRangeArr[24])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[24], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[24]]] : (($countql[24]) ? 'QL' : (($counthd[24]) ? 'HD' : (($countlql[24]) ? 'LQL': (($countlhd[24]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[24])) == 'Sat') ? (($AllPunchStatus[24]=='P') ? $AllPunchStatus[24] : 'WO') : $AllPunchStatus[24]))))))),
			    'd_26'=>((date('D', strtotime($dateRangeArr[25])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[25], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[25]]] : (($countql[25]) ? 'QL' : (($counthd[25]) ? 'HD' : (($countlql[25]) ? 'LQL': (($countlhd[25]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[25])) == 'Sat') ? (($AllPunchStatus[25]=='P') ? $AllPunchStatus[25] : 'WO') : $AllPunchStatus[25]))))))),
			    'd_27'=>((date('D', strtotime($dateRangeArr[26])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[26], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[26]]] : (($countql[26]) ? 'QL' : (($counthd[26]) ? 'HD' : (($countlql[26]) ? 'LQL': (($countlhd[26]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[26])) == 'Sat') ? (($AllPunchStatus[26]=='P') ? $AllPunchStatus[26] : 'WO') : $AllPunchStatus[26]))))))),
                'd_28'=>((date('D', strtotime($dateRangeArr[27])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[27], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[27]]] : (($countql[27]) ? 'QL' : (($counthd[27]) ? 'HD' : (($countlql[27]) ? 'LQL': (($countlhd[27]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[27])) == 'Sat') ? (($AllPunchStatus[27]=='P') ? $AllPunchStatus[27] : 'WO') : $AllPunchStatus[27]))))))),
                'd_29'=>((date('D', strtotime($dateRangeArr[28])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[28], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[28]]] : (($countql[28]) ? 'QL' : (($counthd[28]) ? 'HD' : (($countlql[28]) ? 'LQL': (($countlhd[28]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[28])) == 'Sat') ? (($AllPunchStatus[28]=='P') ? $AllPunchStatus[28] : 'WO') : $AllPunchStatus[28]))))))),
			    'd_30'=>((date('D', strtotime($dateRangeArr[29])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[29], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[29]]] : (($countql[29]) ? 'QL' : (($counthd[29]) ? 'HD' : (($countlql[29]) ? 'LQL': (($countlhd[29]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[29])) == 'Sat') ? (($AllPunchStatus[29]=='P') ? $AllPunchStatus[29] : 'WO') : $AllPunchStatus[29]))))))),
                'd_31'=>((date('D', strtotime($dateRangeArr[30])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[30], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[30]]] : (($countql[30]) ? 'QL' : (($counthd[30]) ? 'HD' : (($countlql[30]) ? 'LQL': (($countlhd[30]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[30])) == 'Sat') ? (($AllPunchStatus[30]=='P') ? $AllPunchStatus[30] : 'WO') : $AllPunchStatus[30]))))))),
                'countlql'=>$countlql1,
                'totallatecount'=>$TotalLateCount
            );
            // epd($updateArr);
            $this->db->where(array('isactive' => '1', 'user_id' => $roWs->user_id));
            $this->db->where('Year',date('Y', strtotime($from_date)));
            $this->db->where('Month',date('m', strtotime($from_date)));
            $this->db->update('monthly_attendance_report', $updateArr);
            // epd($insertArr);
            // $this->db->insert('monthly_attendance_report', $insertArr);
        }

        echo "done";

    }
    public function Attendance_Daily_Script(){
        $leaveArr = array(1 => 'L', 2 => 'HDL', 3 => 'SL', 4=>'RH', 5=>'H', 6=>'T',7=>'WFH');
        $list=$this->attendance_model->get_datatables();
        // epd($list);
        $day=date("d", strtotime("yesterday"));
        $from_date=date("d-m-Y", strtotime("yesterday"));
        $to_date =date("d-m-Y", strtotime("yesterday"));

        $atten_month = date("m", strtotime("$from_date"));
        $atten_year = date("Y", strtotime("$to_date"));

        // $day=date("d", strtotime("01-08-2023"));
        // $from_date='01-08-2023';
        // $to_date ='01-08-2023';
        // $atten_month = date("m", strtotime("$from_date"));
        // $atten_year = date("Y", strtotime("$to_date"));
        $dateRangeArr= $this->getDatesFromRange($from_date, $to_date);
        // epd($dateRangeArr);
        foreach ($list as $keys=>$roWs) {
            $countql=array();
            $counthd=array();

            $countlhd=array();
            $countlql=array();
            $AllPunchStatus=array();
            $AllPunchP=array();
            $wfhRec=array();
            // Total Count
            $countlql1=0;
            $TotalLateCount=0;
            if ($dateRangeArr) {
                foreach ($dateRangeArr as $kEy => $dataRow) {
                    $Dispdate = date("d-m-Y", strtotime($dataRow));
                    $wfh=$this->mastermodel->WorkFromHome($roWs->user_id, $atten_month, $atten_year, $Dispdate);
                    if($wfh == 1){
                        $wfhRec[$dataRow]='7';
                    }
                    $AllPunchStatus[$kEy]=$this->mastermodel->GetAllPunchDetail($Dispdate, $roWs->machine_id);
                    if($AllPunchStatus[$kEy] == 'P'){
                        $AllPunchP[$kEy]=$dataRow;
                    }
                    // epd($AllPunchP);
                    $punchRec = $this->mastermodel->getSingleDateAttByUserID($Dispdate, $roWs->machine_id, $roWs->user_id);
                    // epd($punchRec);
                    $late_by_count = (@$punchRec['lateby']) ? round(@$punchRec['lateby']) : "0";
                    $early_by_count = (@$punchRec['earlyby']) ? round(@$punchRec['earlyby']) : "0";
                    $totalcount = ($late_by_count + $early_by_count) ? ($late_by_count + $early_by_count) : "";
                    if ($totalcount){
                        if (($totalcount > 60) AND ($totalcount <= 135)){
                            $qlprint = 'QL';
                            $countql[$kEy]='QL';
                        }elseif(($totalcount > 135) AND ($totalcount < 270)){
                            $hdprint = 'HD';
                            $counthd[$kEy]='HD';
                        }elseif ($totalcount > 270){
                             $hdprint = 'HD';
                             $counthd[$kEy]='HD';
                        }elseif ($totalcount < 60){
                            $lqlprint = 'LQL';
                            $lhdprint = 'LHD';
                            $TLateCount=$this->TotalLateCount($roWs->user_id,$dataRow);
                            $TotalLateCount += @$TLateCount;
                            $TotalLateCount += @$totalcount;
                            if ($TotalLateCount > 60) {
                                $res_count=$this->Get_countLQL($roWs->user_id,$dataRow);
                                $countlql1 += @$res_count;
                                $lqlprint2 = 1;
                                $countlql1 += $lqlprint2;
                                if ($countlql1 > 8) {
                                    $countlhd[$kEy]='LHD';
                                } else {
                                    $countlql[$kEy]='LQL';
                                }
                            }
                        }
                    }
                   
                }
            }
            $leaveCombineArr = $this->mastermodel->GetAllLeaveListArr(date('Y-m-d', strtotime($from_date)), date('Y-m-d', strtotime($to_date)), $roWs->user_id);
            $holidaysDateArr = $this->mastermodel->holidayCount(date('Y-m-d', strtotime($from_date)), date('Y-m-d', strtotime($to_date)));
            if($holidaysDateArr){
                $leaveCombineArr=array_merge($leaveCombineArr,$holidaysDateArr);
            }
            $tourDateArr = $this->mastermodel->GetAllTourListArr($from_date, $to_date, $roWs->user_id);
            if($tourDateArr){
                 $leaveCombineArr=array_merge($leaveCombineArr,$tourDateArr);
            }
            if($wfhRec){
                $leaveCombineArr=array_merge($leaveCombineArr,$wfhRec);
            }
            
            $leaveCount=array_count_values($leaveCombineArr);
            $leaveDateArr=array_keys($leaveCombineArr);
            if($countlql1 == 0){
                $countlql1=$this->Get_countLQL($roWs->user_id,$dataRow);
            }
            if($TotalLateCount == 0){
                $TotalLateCount=$this->TotalLateCount($roWs->user_id,$dataRow);
            }
            if($day == 01){
                $insertArr=array(
                    'user_id'=>$roWs->user_id,
                    'B_unit_id'=>$roWs->businessunit_id,
                    'department_id'=>$roWs->department_id,
                    'Year'=>$atten_year,
                    'Month'=>$atten_month,
                    'S_in_time'=>$roWs->shift_in_time,
                    'S_out_time'=>$roWs->shift_out_time,
                    'd_'.$day=>((date('D', strtotime($dateRangeArr[0])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[0], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[0]]] : (($countql[0]) ? 'QL' : (($counthd[0]) ? 'HD' : (($countlql[0]) ? 'LQL' : (($countlhd[0]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[0])) == 'Sat') ? (($AllPunchStatus[0]=='P') ? $AllPunchStatus[0] : 'WO') : $AllPunchStatus[0]))))))),
                    'countlql'=>$countlql1,
                    'totallatecount'=>$TotalLateCount
                );
                $this->db->insert('monthly_attendance_report', $insertArr);
            }else{
                $updateArr=array(
                    'd_'.$day=>((date('D', strtotime($dateRangeArr[0])) == 'Sun') ? 'WO' : ((in_array($dateRangeArr[0], $leaveDateArr)) ? $leaveArr[$leaveCombineArr[$dateRangeArr[0]]] : (($countql[0]) ? 'QL' : (($counthd[0]) ? 'HD' : (($countlql[0]) ? 'LQL' : (($countlhd[0]) ? 'LHD' : ((date('D', strtotime($dateRangeArr[0])) == 'Sat') ? (($AllPunchStatus[0]=='P') ? $AllPunchStatus[0] : 'WO') : $AllPunchStatus[0]))))))),
                    'countlql'=>$countlql1,
                    'totallatecount'=>$TotalLateCount
                );
                $this->db->where(array('isactive' => '1', 'user_id' => $roWs->user_id));
                $this->db->where('Year',date('Y', strtotime($from_date)));
                $this->db->where('Month',date('m', strtotime($from_date)));
                $resP=$this->db->update('monthly_attendance_report', $updateArr);
            }
        }
        echo $resP;
        echo "done";
    }
    public function Get_countLQL($empId,$date){
        $this->db->select('a.countlql');
        $this->db->from('monthly_attendance_report as a');
        $this->db->where(array('isactive' => '1', 'user_id' => $empId));
        $this->db->where('Year',date('Y', strtotime($date)));
        $this->db->where('Month',date('m', strtotime($date)));
        $LQLcount = $this->db->get()->row()->countlql;
        return $LQLcount;
    }
    public function TotalLateCount($empId,$date){
        $this->db->select('a.totallatecount');
        $this->db->from('monthly_attendance_report as a');
        $this->db->where(array('isactive' => '1', 'user_id' => $empId));
        $this->db->where('Year',date('Y', strtotime($date)));
        $this->db->where('Month',date('m', strtotime($date)));
        $LQLcount = $this->db->get()->row()->totallatecount;
        return $LQLcount;
    }
    function getDatesFromRange($startDate, $endDate)
    {
        $return = array($startDate);
        $start = $startDate;
        $i = 1;
        if (strtotime($startDate) < strtotime($endDate)) {
            while (strtotime($start) < strtotime($endDate)) {
                $start = date('d-m-Y', strtotime($startDate . '+' . $i . ' days'));
                $return[] = $start;
                $i++;
            }
        }
        return $return;
    }

}