<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Comp_opn_cls_report_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Menpower_report_model');
        $this->load->library('form_validation');
        $this->load->helper('common_helper');
        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
        } else {
            redirect(base_url(""));
        }
    }

    public function com_wise_opn_cls_report()
    {
        $title = "Company wise Report";
        if (@$_REQUEST['filter']) {
            $com_name = $_REQUEST['company_name'];
            //$unit_name = $_REQUEST['unit_name'];
        }
        $this->load->view("company_wise_report/companywise_report_view", compact('title', 'com_name'));
    }
}
