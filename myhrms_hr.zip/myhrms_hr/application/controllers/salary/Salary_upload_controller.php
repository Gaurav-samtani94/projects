<?php
       

// if (!defined('BASEPATH'))
//     exit('No direct script access allowed');
// error_reporting(0);
require_once APPPATH . 'third_party/PHPExcel.php';

// use PhpOffice\PhpSpreadsheet\Spreadsheet;
// use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
// require_once APPPATH.'third_party/PHPExcel.php';
		// $this->load->library('PHPExcel/IOFactory');
defined('BASEPATH') OR exit('No direct script access allowed');


class Salary_upload_controller extends CI_Controller {

    function __construct() {
       
        parent::__construct();
        $this->loginid = $this->session->userdata('loginid');
        if ($this->loginid == "") {
            redirect(base_url());
        }
        date_default_timezone_set('Asia/Kolkata');
        $this->load->model('Front_model');
        $this->load->model('Mastermodel');
        // $this->load->model('salary_sheet/SalarySheet_Model');
        // $this->load->model('permission/Permission_model', 'permissionmodel');
        $this->load->library('form_validation');
        $this->db1 = $this->load->database('online', TRUE);
        // $this->db2 = $this->load->database('another_db', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);
        
    }


    public function SalarySheet()
    {
       
        // $db1 = $this->db1->database;
        // $db2 = $this->db2->database;
        // $db3 = $this->db3->database;
        // // $RespNo = $this->permissionmodel->CheckAccessPermDenied(
        //     'Salarysheet_Controller.php',
        //     'empSalarySheet'
        // );
        $data['title'] = "Employee Salary Upload";
        // $data['AllEmpList'] =$this->SalarySheet_Model->GetAllEmpList();
        // echo "<pre>";
        // print_r($data['AllEmpList']);
        // die();
        // $toDate=date('Y-03',strtotime('+1 year'));
        // $fromDate=date('Y-04');
        // $data['fromDates'] = $fromDate;
        // $data['toDates'] = $toDate;
        // echo "seesds";
        // die();
        $this->load->view('salary_update/emp_salary_upload_view', $data);
    }

    //10-06-2022 ========(vivek)========================================================================
    public function financial_year_salary_upload_file(){
        // epd("seee");

       
        // $db1 = $this->db1->database;
        // $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        $postRecord = $this->input->post();
        $fromDate = $postRecord['from_date'];
       
        $from_date_month =  date('m', strtotime($fromDate));
       
        $from_date_year =  date('Y', strtotime($fromDate));
      
        if ($_FILES['salary_file']['name']) {
           
            $upload_file = $_FILES['salary_file']['name'];
            $extension = pathinfo($upload_file, PATHINFO_EXTENSION);
            if ($extension == 'xlsx') {
                $configThm = $this->uploadConfig();
                $this->load->library('upload', $configThm);
                $this->upload->initialize($configThm);
                if ($this->upload->do_upload('salary_file')) {
                    $uploadData = $this->upload->data();
                }

                $path = $_FILES["salary_file"]["tmp_name"];
                $object = PHPExcel_IOFactory::load($path);
                $sno = 0;
                foreach ($object->getWorksheetIterator() as $worksheet) {
                    $highestRow = $worksheet->getHighestRow();
                  
                    $highestColumn = $worksheet->getHighestColumn();
                    
                    for ($row = 2; $row <= $highestRow; $row++) {
                        $sno++;
                        $emp_id = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
                        $payroll_code = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
                        $ctc = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
                        if ($emp_id && $payroll_code && $ctc && $_REQUEST['go_upload']) {
                            $getEmpId = $this->GetEmpIdByUserID($emp_id);
                            // epd($getEmpId);
                           $empId =$getEmpId->id;
                            //All Ready Exist..
                            $whereArr = array(
                                "$db3.mis_salary_sheet.emp_id" => $empId,
                                "$db3.mis_salary_sheet.payroll_code" => $payroll_code,
                                "$db3.mis_salary_sheet.month_year" => date('Y-m', strtotime($fromDate)),
                                "$db3.mis_salary_sheet.status" => "1"
                            );
                            $num_results = $this->db->where($whereArr)->count_all_results("$db3.mis_salary_sheet");
                            
                            if ($num_results < 1) {
                                   $month = strtotime($fromDate);
                                        $insert_Arr = array(
                                            "$db3.mis_salary_sheet.emp_id" => $empId,
                                            "$db3.mis_salary_sheet.payroll_code" => $payroll_code,
                                            "$db3.mis_salary_sheet.month" => date('m', $month),
                                            "$db3.mis_salary_sheet.year" => date('Y', $month),
                                            "$db3.mis_salary_sheet.month_year" => date('Y-m', $month),
                                            "$db3.mis_salary_sheet.ctc" => ($ctc) ? $ctc : '0',
                                            "created_by" => $this->loginid
                                        );
                                        // ep('insert');
                                        // epd($insert_Arr);
                                        $resp = $this->db->insert("$db3.mis_salary_sheet", $insert_Arr);
                            } else {
                                   $month = strtotime($fromDate);
                                        $update_Arr = array(
                                            "$db3.mis_salary_sheet.emp_id" => $empId,
                                            "$db3.mis_salary_sheet.payroll_code" => $payroll_code,
                                            "$db3.mis_salary_sheet.month" => date('m', $month),
                                            "$db3.mis_salary_sheet.year" => date('Y', $month),
                                            "$db3.mis_salary_sheet.month_year" => date('Y-m', $month),
                                            "$db3.mis_salary_sheet.ctc" => ($ctc) ? $ctc : '0',
                                            "update_by" => $this->loginid,
                                            "last_update" => date("Y-m-d h:i:s")
                                        );
                                        $whereUpdate_Arr = array(
                                            "$db3.mis_salary_sheet.emp_id" => $empId,
                                            "$db3.mis_salary_sheet.payroll_code" => $payroll_code,
                                            "$db3.mis_salary_sheet.month" => date('m', $month),
                                            "$db3.mis_salary_sheet.year" => date('Y', $month),
                                            "$db3.mis_salary_sheet.month_year" => date('Y-m', $month),
                                            "$db3.mis_salary_sheet.status" => "1"
                                        );
                                        $this->db->where($whereUpdate_Arr);
                                       // $this->db->where($master_id);
                                        $respU = $this->db->update("$db3.mis_salary_sheet",  $update_Arr);
                            }
                        }
                    }
                    if ($resp) :
                        $this->session->set_flashdata('msg', "CSV File Inserted Successfulll done. ");
                    endif;

                    if ($respU) :
                        $this->session->set_flashdata('msg', "CSV File Updated Successfulll done. ");
                    endif;
                    redirect($_SERVER['HTTP_REFERER']);
                }
            } else {
                //    $error = '';
                $this->session->set_flashdata('error', "This File Type not support.");
                redirect($_SERVER['HTTP_REFERER']);
            }
        } else {
            $this->session->set_flashdata('error', "Please Attach File.");
            redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function GetEmpIdByUserID($emp_id)
    {
        // $db2 = $this->db2->database;
        $this->db->select("a.employeeId,a.id");
        $this->db->from("main_users as a");
        $this->db->where(["a.employeeId" => $emp_id]);
        $recordArr = $this->db->get()->row();
        return ($recordArr) ? $recordArr : NULL;
    }

    // nvoice_file
    protected function uploadConfig(){
        $config = array();
        $config['upload_path'] = './uploads/salarysheet/';
        $config['allowed_types'] = 'xlsx';
        $config['max_size'] = '200000'; //20MB
        $config['file_name'] = "salary_file" . '.xlsx';
        return $config;
    }

    protected function getIvoiceUploadConfig(){
        $config = array();
        $config['upload_path'] = './uploads/salarysheet/';
        $config['allowed_types'] = 'xlsx';
        $config['max_size'] = '200000'; //20MB
        $config['file_name'] = "invoice_file" . '.xlsx';
        return $config;
    }
    //=======03-06-2022=================(vivek)==========================================!
    public function empSalarySheet()
    {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        $RespNo = $this->permissionmodel->CheckAccessPermDenied(
            'Salarysheet_Controller.php',
            'empSalarySheet'
        );
        $data['title'] = "Employee Salary Upload";
        $data['AllEmpList'] =$this->SalarySheet_Model->GetAllEmpList();
        // echo "<pre>";
        // print_r($data['AllEmpList']);
        // die();
        $toDate=date('Y-03',strtotime('+1 year'));
        $fromDate=date('Y-04');
        $data['fromDates'] = $fromDate;
        $data['toDates'] = $toDate;
        $this->load->view('salary_sheet/emp_salary_sheet_view', $data);
    }
    
    public function getPayrollCode_ajax()
    {
        $empId = $_REQUEST["emp_id"];
        if ($empId) {
            $AllEmpArr = $this->SalarySheet_Model->getPayrollCode_ajax($empId);
            echo ($AllEmpArr) ? json_encode($AllEmpArr) : FALSE;
        }
    }
    public function uploadEmpSalary()
    {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        $postRecord = $this->input->post();
        $emp_id = $postRecord['emp_id'];
        $payrollCode = $postRecord['payrollCode_id'];
        $added_amount = $postRecord['added_amount'];
        $from_date = $postRecord['fil_from_date'];
        $to_date = $postRecord['fil_to_date'];
        $from_date_month =  date('m', strtotime($from_date));
        $to_date_month= date('m', strtotime($to_date));
        $from_date_year =  date('Y', strtotime('+1 year', strtotime($from_date)));
        $to_date_year =  date('Y', strtotime($to_date));
        $whereArr = array(
            "$db3.mis_salary_sheet.emp_id" => $emp_id,
            "$db3.mis_salary_sheet.payroll_code" => $payrollCode,
            "$db3.mis_salary_sheet.month" => $to_date_month,
            "$db3.mis_salary_sheet.year" => $to_date_year,
            "$db3.mis_salary_sheet.status" => "1"
        );

    $num_results = $this->db
        ->where($whereArr)
        ->count_all_results("$db3.mis_salary_sheet");
    if ($num_results < 1) {
        if($from_date_month==04 && $to_date_month==03){
            if($from_date_year==$to_date_year)
            {
                if ($emp_id && $payrollCode && $added_amount && $from_date && $to_date && $_REQUEST['go_submit']) {
                    $divd= 12;
                    $month_wise_slry =($added_amount/$divd);
                    if ($month_wise_slry > 0) {
                        $start = $month = strtotime($from_date);
                        $end = strtotime($to_date);
                        while($month <= $end)
                        {
                            $insert_Arr = array(
                                "$db3.mis_salary_sheet.emp_id" => $emp_id,
                                "$db3.mis_salary_sheet.payroll_code" => $payrollCode,
                                "$db3.mis_salary_sheet.month" => date('m', $month),
                                "$db3.mis_salary_sheet.year" => date('Y', $month),
                                "$db3.mis_salary_sheet.month_year" => date('Y-m', $month),
                                "$db3.mis_salary_sheet.ctc" => ($month_wise_slry) ? $month_wise_slry : '0',
                                "created_by" => $this->loginid
                            );
                            $resp = $this->db->insert("$db3.mis_salary_sheet", $insert_Arr);
                            $month = strtotime("+1 month", $month);
                        }
                    }
                    $this->session->set_flashdata('msg', "Amount Inserted Successfulll done. ");
                    redirect($_SERVER['HTTP_REFERER']);
                }
                else{
                    $this->session->set_flashdata('error', "Something Went Wrong ! ");
                    redirect($_SERVER['HTTP_REFERER']); 
                }
            }else{
                $this->session->set_flashdata('error', "Please Select Financial Year ! ");
                redirect($_SERVER['HTTP_REFERER']);
            }
        }else{
            $this->session->set_flashdata('error', "Please Select From_Date April Month And To_Date March Month ! ");
            redirect($_SERVER['HTTP_REFERER']);
        }
    }else{
        $this->session->set_flashdata('error', "Already Exists Employee Salary. ! ");
        redirect($_SERVER['HTTP_REFERER']);
    } 
    }
    // =====07/06/2022 vivek =====================!
    public function getAllEmpList(){
        $RespNo = $this->permissionmodel->CheckAccessPermDenied(
            'Salarysheet_Controller.php',
            'getAllEmpList'
        );
        $data['title'] = "Employee Salary List";
         $data['AllEmpList'] =$this->SalarySheet_Model->GetAllEmpList();
        $data['AllEmpSalaryList'] =$this->SalarySheet_Model->GetAllEmpSalaryList();
        $data['totalctc'] =$this->SalarySheet_Model->GetAllEmpSalaryBalance(); 
        
        $toDate=date('Y-03',strtotime('+1 year'));
        $fromDate=date('Y-04');
        $data['fromDates'] = $fromDate;
        $data['toDates'] = $toDate;
        if ($_REQUEST['go_submit']) {
            $empId = $_REQUEST['emp_id'];
            $fromDate = $_REQUEST['from_date'];
            $toDate = $_REQUEST['to_date'];
            $data['AllEmpSalaryList'] =$this->SalarySheet_Model->GetAllEmpSalaryListById($empId,$fromDate,$toDate);
            $data['totalctc'] =$this->SalarySheet_Model->GetAllEmpSalaryBalanceById($empId,$fromDate,$toDate);
        }
        $data['employee_id'] = $_REQUEST['emp_id'];
        
     $this->load->view('salary_sheet/emp_salary_list_view', $data);
    }



    // salary upload script===============================================
    public function salary(){
    
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        $notmatch = array();
        $data['salaryList'] =$this->SalarySheet_Model->salaryList();
        // epd($data['salaryList']);
        foreach($data['salaryList'] as $rOws){
            $emp_id=$rOws->user_id;
            $employeeId=$rOws->employeeId;
            $userfullName=$rOws->userfullname;
            $departmentName=$rOws->department_name;
            $dateofjoining=$rOws->date_of_joining;
            $dateofleaving=$rOws->date_of_leaving;
            $payrollCode=$rOws->payrollcode;
             $fromDate=$rOws->createddate;
             $frommonthYear =  date('Y-m', strtotime($fromDate));
             $tomonthYear =  date('Y-01', strtotime("2022"));
             $month =  date('m', strtotime($fromDate));
             $year =  date('Y', strtotime($fromDate));
            $whereArr = array(
                "$db3.mis_salary_sheet.emp_id" => $emp_id,
                "$db3.mis_salary_sheet.payroll_code" => $payrollCode,
                "$db3.mis_salary_sheet.month" => $month,
                "$db3.mis_salary_sheet.year" => $year,
                "$db3.mis_salary_sheet.status" => "1"
            );
        
          $num_results = $this->db
            ->where($whereArr)
            ->count_all_results("$db3.mis_salary_sheet");
         if ($num_results < 1) {
                    if ($emp_id && $month && $year) {
                        // $divd= 12;
                        // $month_wise_slry =($added_amount/$divd);
                         $month_wise_slry =1000;
                        if ($month_wise_slry > 0) {
                            $start = $month = strtotime($frommonthYear);
                            $end = strtotime($tomonthYear);
                            while($month <= $end)
                            {
                                $insert_Arr = array(
                                    "$db3.mis_salary_sheet.emp_id" => $emp_id,
                                    "$db3.mis_salary_sheet.payroll_code" => ($payrollCode) ? $payrollCode :"",
                                    "$db3.mis_salary_sheet.month" => date('m', $month),
                                    "$db3.mis_salary_sheet.year" => date('Y', $month),
                                    "$db3.mis_salary_sheet.month_year" => date('Y-m', $month),
                                    "$db3.mis_salary_sheet.ctc" => ($month_wise_slry) ? $month_wise_slry : '0',
                                    "created_by" => $this->loginid
                                );
                                $resp = $this->db->insert("$db3.mis_salary_sheet", $insert_Arr);
                                $month = strtotime("+1 month", $month);
                            }
                        }
                    }
                    // else{
                    //     $notmatchh  = array(
                    //         'userfullname'=>$userfullName,
                    //         'empid'=>$employeeId,
                    //         'departname'=>$departmentName,
                    //         'joining'=>$dateofjoining,
                    //         'leaving'=>$dateofleaving,
                    //     );
                    //     array_push($notmatch,$notmatchh); // first entry
                    // }     
                
        }    
        }
        print($resp);
        die();
    //  $a = "<table class='table' border='1'>
    //     <thead>
    //       <tr>
    //       <th>SNO.</th>
    //         <th>Emp Name</th>
    //         <th>EMPID</th>
    //         <th>Department Name</th>
    //         <th>Date Of Joining</th>
    //         <th>DateOfLeaving</th>
    //       </tr>
    //     </thead>
    //     <tbody>";
    //     foreach($notmatch as $key=>$rOws)
    //     {
    //         $SNo++;
    //         $a.="<tr><td>"." $SNo "."</td><td>".$rOws['userfullname']."</td><td>".$rOws['empid']."</td><td>".$rOws['departname']."</td><td>".$rOws['joining']."</td><td>".$rOws['leaving']."</td></tr>";
    //     }
    //     $a.="  <tr>
    //     <th>Emp Name</th>
    //     <th>EMPID</th>
    //     <th>Department Name</th>
    //     <th>Date Of Joining</th>
    //     <th>DateOfLeaving</th>
    //   </tr>  </tbody>
    //     </table>";
    //    echo($a);
    //    die();
        
   

}


public function payrollMainSalaryScript(){
       $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        $this->db->select("$db1.a.fin_year,$db1.a.user_id,$db1.a.apr_month,$db1.a.may_month,$db1.a.june_month,$db1.a.july_month,$db1.a.aug_month,$db1.a.sep_month,$db1.a.oct_month,$db1.a.nov_month,$db1.a.dec_month,$db1.a.jan_month,$db1.a.feb_month,$db1.a.march_month");
        $this->db->from("$db1.payroll_main_salary as a");
        $this->db->where(["$db1.a.type_id"=>"2","$db1.a.status"=>"1"]);
        $responRecdArr = $this->db->get()->result_array();

        //epd($responRecdArr);
        if($responRecdArr){
            foreach($responRecdArr as $rOws){
               $fin_year = Explode("-",$rOws['fin_year']);

               $FromYear = $fin_year[0];
               $ToYear = $fin_year[1];

               $code =$this->SalarySheet_Model->GetpayrollcodeById($rOws['user_id']);
               $payrollcode = $code->payrollcode;


            $monthsRecdArr = array('apr_month'=>$FromYear."-04-01",
                'may_month'=>$FromYear."-05-01",
                'june_month'=>$FromYear."-06-01",
                'july_month'=>$FromYear."-07-01",
                'aug_month'=>$FromYear."-08-01",
                'sep_month'=>$FromYear."-09-01",
                'oct_month'=>$FromYear."-10-01",
                'nov_month'=>$FromYear."-11-01",
                'dec_month'=>$FromYear."-12-01",
                'jan_month'=>$ToYear."-01-01",
                'feb_month'=>$ToYear."-02-01",
                'march_month'=>$ToYear."-03-01",
            );

            foreach($monthsRecdArr as $keys=>$yymm_row){

                 $ctc = 0;
                 $ctc = $rOws[$keys];

                    $whereCondArr = array(
                        "$db3.mis_salary_sheet.emp_id" => $rOws['user_id'], 
                        "$db3.mis_salary_sheet.month_year" => date('Y-m', strtotime($yymm_row)),
                        "$db3.mis_salary_sheet.status" => "1"
                    );

                  $num_results = $this->db->where($whereCondArr)->count_all_results("$db3.mis_salary_sheet");
                  if ($num_results < 1){
                        $insert_Arr = array("$db3.mis_salary_sheet.emp_id" => $rOws['user_id'],
                                    "$db3.mis_salary_sheet.payroll_code" => ($payrollcode) ? $payrollcode :"",
                                    "$db3.mis_salary_sheet.month" => date('m', strtotime($yymm_row)),
                                    "$db3.mis_salary_sheet.year" => date('Y', strtotime($yymm_row)),
                                    "$db3.mis_salary_sheet.month_year" => date('Y-m', strtotime($yymm_row)),
                                    "$db3.mis_salary_sheet.ctc" => ($ctc) ? $ctc: '0',
                                    "created_by" => $this->loginid);
                                $respon = $this->db->insert("$db3.mis_salary_sheet", $insert_Arr);
                                if($respon):
                                    $this->session->set_flashdata('msg', "Salary Inserted Successfulll done. ");
                                endif;

                  } else {
                    //Update Code..
                    $updateArr = array("$db3.mis_salary_sheet.last_update" => date('Y-m-d h:i:s'),
                                     "$db3.mis_salary_sheet.payroll_code" => ($payrollcode) ? $payrollcode :"",
                                    "$db3.mis_salary_sheet.ctc" => $rOws[$keys],
                                    "update_by" => $this->loginid);   
                                    $this->db->where($whereCondArr);
                    $responU = $this->db->update("$db3.mis_salary_sheet", $updateArr);
                    if($responU):
                        $this->session->set_flashdata('msg', "Salary Updated Successfulll done. ");
                    endif;
                  }
             }
           }
        }
        redirect(base_url('salary_sheet'));
   }
   // vivek march 18 2024
   public function GetUploadMonthlySalary(){
    $db1 = $this->db1->database;
    $db2 = $this->db2->database;
    $db3 = $this->db3->database;
    $postArr=$this->input->post();
    // ep($postArr);

$currmonthYear = date("Y-m", strtotime("first day of previous month"));
$filtermonth=($postArr['go_reset'])?$currmonthYear:$postArr['monthyear'];
// epd($filtermonth);
if ($postArr['go_Approved']) {
   
    $updData = array('appr_status' => "1",'last_update' => date('Y-m-d H:i:s'),'update_by' => $this->session->userdata('loginid'));
    // epd($updData);
    $this->db3->where(array('month_year' => $postArr['monthyear']));
    $this->db3->update('mis_salary_sheet', $updData);
}

// epd($postArr);
$this->db3->select("a.month_year");
$this->db3->FROM("mis_salary_sheet as a");
$this->db3->where(["a.status" => '1']);
$this->db3->group_by("a.month_year");
$this->db3->order_by('a.month_year', 'DESC');
$data['monthyear']= $this->db3->get()->result();
//

$this->db->select("$db3.a.payroll_code,$db3.a.month_year,$db3.a.ctc,$db3.a.appr_status,$db2.b.userfullname,$db2.b.employeeId");
$this->db->FROM("$db3.mis_salary_sheet as a");
$this->db->join("$db2.main_employees_summary as b", "$db2.b.user_id=$db3.a.emp_id", "LEFT");
$this->db->where(["$db3.a.status" => '1']);
$this->db->where("$db3.a.month_year",$filtermonth);
// $this->db->order_by('$db3.a.month_year', 'DESC');  monthyear 2024-01,monthyear 2024-02
$data['emplist']= $this->db->get()->result();
$data['filtermonth']=$filtermonth?$filtermonth:$currmonthYear;
// epd( $data['emplist']);
$this->load->view('salary_sheet/emp_salary_view',$data);
}
//php close
}