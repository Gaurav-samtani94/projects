<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Salary_manage_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session', 'form_validation');
		// require_once APPPATH.'third_party/PHPExcel.php';
		// $this->load->library('PHPExcel/IOFactory');
		$this->load->model('updated_salary_temp_model');
		$this->load->model('salary_inc_tbl_model');
		$this->load->model('Mastermodel','mastermodel');
        $this->load->database();
    }

    public function index() { 
        $data['error'] = '';
        $data['title'] = 'Update Salary';
        $this->load->view("salary_update/salary_update_view", $data);
    }
	
	public function salary_increment() { 
        $data['error'] = '';
        $data['title'] = 'Download Increment CSV';
        $this->load->view("salary_update/salary_update_increment_view", $data);
    }
	
	public function upload_increment_csv() { 
        $data['error'] = '';
        $data['title'] = 'Update Salary Increment';
        $this->load->view("salary_update/salary_csv_increment_view", $data);
    }
	
	public function download_increment_sal_csv() {
		$list = $this->salary_inc_tbl_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        // echo "<pre>"; print_r($list); die;
        foreach ($list as $value) {
			
			// $disbl = ($value->main_status == 2) ? "disabled=disabled" : "";
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($value->id)? $value->id : "";
            $row[] = ($value->user_id)? $value->user_id : "";
            $row[] = ($value->salary_id)? $value->salary_id : "";
            $row[] = ($value->emp_salary_historyID)? $value->emp_salary_historyID : "";
            $row[] = ($value->appraisal_datemmyy)? $value->appraisal_datemmyy : "";
            $row[] = ($value->empctc)? $value->empctc : "";
            $row[] = ($value->grosssalary)? $value->grosssalary : "";
            $row[] = ($value->basicsalary)? $value->basicsalary : "";
            $row[] = ($value->empepf)? $value->empepf : "";
            $row[] = ($value->loyaltybonus)? $value->loyaltybonus : "";
            $row[] = ($value->emp_hra)? $value->emp_hra : "";
            $row[] = ($value->emp_esi)? $value->emp_esi : "";
            $row[] = ($value->projectcomp_bonus)? $value->projectcomp_bonus : "";
            $row[] = ($value->special_allowance)? $value->special_allowance : "";
            $row[] = ($value->emp_gratuity)? $value->emp_gratuity : "";
            $row[] = ($value->transportation_allowance)? $value->transportation_allowance : "";
            $row[] = ($value->emp_sal_gpai)? $value->emp_sal_gpai : "";
            $row[] = ($value->tele_empsal_allowance)? $value->tele_empsal_allowance : "";
            $row[] = ($value->education_allowance)? $value->education_allowance : "";
            $row[] = ($value->medical_allowance)? $value->medical_allowance : "";
            $row[] = ($value->statutory_deduct)? $value->statutory_deduct : "";
            $row[] = ($value->sal_other)? $value->sal_other : "";
            $row[] = ($value->leave_travel_allowance)? $value->leave_travel_allowance : "";
            $row[] = ($value->food_expenses)? $value->food_expenses : "";
            $row[] = ($value->fuel_expenses)? $value->fuel_expenses : "";
            $row[] = ($value->vehicle_agreement)? $value->vehicle_agreement : "";
            $row[] = ($value->driver_wagers)? $value->driver_wagers : "";
            $row[] = ($value->empctcp1)? $value->empctcp1 : "";
            $row[] = ($value->empctcp2)? $value->empctcp2 : "";
            $row[] = ($value->project_allowance)? $value->project_allowance : "";
            $row[] = ($value->bonus_adv)? $value->bonus_adv : "";
            $row[] = ($value->salsec_other)? $value->salsec_other : "";
            $row[] = ($value->grosssal_mediclaim)? $value->grosssal_mediclaim : "";
            $row[] = ($value->grosssal_other)? $value->grosssal_other : "";
            $row[] = ($value->pcb_employer)? $value->pcb_employer : "";
            $row[] = ($value->createdby)? $value->createdby : "";
            $row[] = ($value->modifiedby)? $value->modifiedby : "";
            $row[] = ($value->createddate)? $value->createddate : "";
            $row[] = ($value->modifieddate)? $value->modifieddate : "";
            $row[] = ($value->isactive)? $value->isactive : "";
            $row[] = ($value->rating_grade)? $value->rating_grade : "";
            $row[] = ($value->increment_amnt)? $value->increment_amnt : "";
            // $row[] = '<input type="hidden" name="checkboxArr[]" value="'.$value->fld_id.'">&ensp;
			// <button class="btn btn-danger" '.$disbl.'onclick="delete_temp_salary_details('.$value->fld_id.')">Delete</button>';
            // $row[] = ;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->salary_inc_tbl_model->count_all(),
            "recordsFiltered" => $this->salary_inc_tbl_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
	}
	
	public function update_salary_increment_by_csv(){
		$entry_by = $this->session->userdata('loginid');
							// echo "test"; die;
		if ($_FILES['salary_file']['tmp_name']) {
            $configThm = $this->getUploadConfig();
            $this->load->library('upload', $configThm);
            $this->upload->initialize($configThm);
            if ($this->upload->do_upload('salary_file')) {
               $uploadData = $this->upload->data();
                $filepath = $uploadData['full_path'];
                $file = fopen($filepath, 'r');
                $n = 0;
                while (($line = fgetcsv($file)) !== FALSE) {	
                    if ($n > 0) {
					
							$insertArr = array(
								'user_id' => $line[2], 'salary_id' => $line[3],
								'emp_salary_historyID' => $line[4], 'appraisal_datemmyy' => $line[5],
								'empctc' => $line[6], 'grosssalary' => $line[7],'basicsalary' => $line[8],
								'empepf' => $line[9], 'loyaltybonus' => $line[10],
								'emp_hra' => $line[11], 'emp_esi' => $line[12], 'projectcomp_bonus' => $line[13],
								'special_allowance' => $line[14], 'emp_gratuity' => $line[15], 'transportation_allowance' => $line[16],
								'emp_sal_gpai' => $line[17], 'tele_empsal_allowance' => $line[18], 'education_allowance' => $line[19],
								'medical_allowance' => $line[20], 'statutory_deduct' => $line[21], 'sal_other' => $line[22],
								'leave_travel_allowance' => $line[23], 'food_expenses' => $line[24], 'fuel_expenses' => $line[25],
								'vehicle_agreement' => $line[26], 'driver_wagers' => $line[27], 'empctcp1' => $line[28],
								'empctcp2' => $line[29], 'project_allowance' => $line[30], 'bonus_adv' => $line[31],
								'salsec_other' => $line[32], 'grosssal_mediclaim' => $line[33], 'grosssal_other' => $line[34],
								'pcb_employer' => $line[35], 'createdby' => $line[36], 'modifiedby' => 1, 'modifieddate' => $line[39], 'isactive' => $line[40],
								'rating_grade' => $line[41], 'increment_amnt' => $line[42]
							
							);
							// echo "<pre>"; print_r($insertArr); die;
							$resps = $this->db->insert('main_empsal_increment',$insertArr);
                    }
                    $n++;
                }

               
                fclose($file);
                
            } else{
				$this->session->set_flashdata('errormsg', "File Upload Failed");
				redirect(base_url('salary_details_update'));
			}
        }
		
		if($resps){
			$this->session->set_flashdata('successmsg', "Csv Uploaded Successfully");
			redirect(base_url('salary_details_update'));
		}else{
			$this->session->set_flashdata('errormsg', "Something Went Wrong");
			redirect(base_url('salary_details_update'));
		}
	}
	
	public function update_salary_by_csv(){
		$entry_by = $this->session->userdata('loginid');
		if ($_FILES['salary_file']['tmp_name']) {
            $configThm = $this->getUploadConfig();
            $this->load->library('upload', $configThm);
            $this->upload->initialize($configThm);
            if ($this->upload->do_upload('salary_file')) {
               $uploadData = $this->upload->data();
                $filepath = $uploadData['full_path'];
                $file = fopen($filepath, 'r');
                $n = 0;
                while (($line = fgetcsv($file)) !== FALSE) {	
                    if($n>0) {
						$user_id = get_emp_user_id_by_emp_code($line[1]);	
						$line7 = ltrim($line[7],"`");
						$query = $this->db->get_where('main_empsalarydetails', array('user_id' => $user_id,'isactive'=>'1'));
						$count = $query->num_rows();
						if($count<1){
							$InsrtrecArr = array(
								'user_id' => $user_id, 
								'currencyid' => $line[2], 
								'salarytype' => $line[3], 
								'salary' => $line[4], 
								'bankname' => $line[5], 
								'accountholder_name' => $line[6], 
								'accountnumber' => $line7, 
								'branchname' => $line[8], 
								'ifsc_code' => $line[9], 
								'pancard_no' => $line[10], 
								'appraisalduedate' => $line[11], 
								'entry_by' => $entry_by,
								'createddate'=>date('Y-m-d h:i:s'),
								'flag'=>'1'
							);
							// $InsrtrecArr2 = array(
							// 	'user_id' => $user_id, 
							// 	'currencyid' => $line[2], 
							// 	'salarytype' => $line[3], 
							// 	'salary' => $line[4], 
							// 	'bankname' => $line[5], 
							// 	'accountholder_name' => $line[6], 
							// 	'accountnumber' => $line7, 
							// 	'branchname' => $line[8], 
							// 	'ifsc_code' => $line[9], 
							// 	'pancard_no' => $line[10], 
							// 	'appraisalduedate' => $line[11], 
							// 	'entry_by' => $entry_by,
							// 	'entry_date'=>date('Y-m-d h:i:s'),
							// 	'main_status'=>1
							// );
							$resps = $this->db->insert('main_empsalarydetails', $InsrtrecArr);
							//$resps = $this->db->insert('temp_salary_details', $InsrtrecArr2);
						}else{
							$where = array("user_id" => $user_id);
							$updateArr = array(
								'currencyid' => $line[2], 
								'salarytype' => $line[3], 
								'salary' => $line[4], 
								'bankname' => $line[5], 
								'accountholder_name' => $line[6], 
								'accountnumber' => $line7, 
								'branchname' => $line[8], 
								'ifsc_code' => $line[9], 
								'pancard_no' => $line[10], 
								'appraisalduedate' => $line[11],
								'modifiedby' => $entry_by,
								'modifieddate'=>date('Y-m-d h:i:s'),
								'flag'=>'1'
							);
							$this->db->where($where);
							$resps = $this->db->update('main_empsalarydetails', $updateArr);
						}
                    }
                    $n++;
                }
                fclose($file); 
            } 
        }
		if($resps){
			$this->session->set_flashdata('successmsg', "Csv Uploaded Successfully");
			redirect(base_url('salary_details_update'));
		}else{
			$this->session->set_flashdata('errormsg', "Something Went Wrong");
			redirect(base_url('salary_details_update'));
		}
	}
	
	
    //Add Product Summery All Assets...
    public function ajax_list_temp_sal_details() {
        $list = $this->updated_salary_temp_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        // echo "<pre>"; print_r($list); die;
        foreach ($list as $value) {
			
			//$disbl = ($value->main_status == 2) ? "disabled=disabled" : "";
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($value->userfullname)? $value->userfullname : "";
            $row[] = ($value->currencycode)? $value->currencycode : "";
		
			
            $row[] = ($value->salarytype)? $value->salarytype : "";
            $row[] = ($value->salary)? $value->salary : "";
            $row[] = ($value->bankname)? $value->bankname : "";
            $row[] = ($value->accountholder_name)? $value->accountholder_name : "";
            $row[] = ($value->accountnumber)? $value->accountnumber : "";
            $row[] = ($value->branchname)? $value->branchname : "";
            $row[] = ($value->ifsc_code)? $value->ifsc_code : "";
            $row[] = ($value->pancard_no)? $value->pancard_no : "";
            $row[] = ($value->appraisalduedate)? $value->appraisalduedate : "";
            // $row[] = '<input type="hidden" name="checkboxArr[]" value="'.$value->fld_id.'">&ensp;
			// <button class="btn btn-danger" '.$disbl.'onclick="delete_temp_salary_details('.$value->fld_id.')">Delete</button>';
            // $row[] = ;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->updated_salary_temp_model->count_all(),
            "recordsFiltered" => $this->updated_salary_temp_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }
	
	protected function getUploadConfig() {
        $config = array();
        $config['upload_path'] = './uploads/salary_update_csv/';
        $config['allowed_types'] = 'xlsx|csv|xls';
        $config['max_size'] = '200000'; //20MB
        $config['file_name'] = "New_salary". time() . '.xls';
        return $config;
    }
	
	public function delete_temp_salary() {
		$fld_id = $_REQUEST['fld_id'];
		// echo json_encode($fld_id);
		// $this->db->where(array("is_active" =>1,"fld_id"=>$fld_id));
		$this->db->where("fld_id",$fld_id);
		$resp = $this->db->delete("temp_salary_details");
		if($resp){
			echo json_encode("Details Deleted Successfully");
		}else{
			echo json_encode("Something Went Wrong");
		}
		
	}
	
	public function udpate_emp_sal_detail() {
		// echo "<pre>"; print_r($_REQUEST['checkboxArr']);
		$checkboxArr = $_REQUEST['checkboxArr'];
		if($checkboxArr){
			foreach($checkboxArr as $value){
				$resps = $this->get_temp_salary_details($value);
				// echo "<pre>"; print_r($resps); die;
				if($resps){
					// echo "test"; die;
					foreach($resps as $vals){
						$userDetail = $this->check_user_exist_in_salDetails($vals->user_id);
						if($userDetail){
							$where = array("user_id" => $vals->user_id,"isactive" => 1);
							$updateArr = array("currencyid" => $vals->currencyid,"salarytype" => $vals->salarytype,"salary" => $vals->salary,
							"bankname" => $vals->bankname,"accountholder_name" => $vals->accountholder_name,"accountnumber" => $vals->accountnumber,
							"branchname" => $vals->branchname,"ifsc_code" => $vals->ifsc_code,"pancard_no" => $vals->pancard_no,
							"appraisalduedate" => $vals->appraisalduedate,"modifiedby" => $loginUser,"modifieddate" => date("Y-m-d h:i:s"));
							// echo "<pre>"; print_r($updateArr); die;
							$this->db->update("main_empsalarydetails",$updateArr,$where);
							
							$json_salDetail = array("id"=>$userDetail->id,"user_id"=>$userDetail->user_id,"currencyid"=>$userDetail->currencyid,"salarytype"=>$userDetail->salarytype,"salary"=>$userDetail->salary,
							"bankname"=>$userDetail->bankname,"accountholder_name"=>$userDetail->accountholder_name,"accountnumber"=>$userDetail->accountnumber,
							"branchname"=>$userDetail->branchname,"ifsc_code"=>$userDetail->ifsc_code,"pancard_no"=>$userDetail->pancard_no,"appraisalduedate"=>$userDetail->appraisalduedate);
							
							$insertArr = array("salary_id" => $userDetail->id,"emp_id" =>$vals->user_id,"curr_sal"=>$userDetail->salary,"updated_by" => $loginUser,
							"Notification"=>"Salary_Details_Updated","all_details"=>json_encode($json_salDetail));
							$this->db->insert("emp_salary_history",$insertArr);
							
							
						}else{
							$insertArr = array("user_id" => $vals->user_id,"currencyid" => $vals->currencyid,"salarytype" => $vals->salarytype,"salary" => $vals->salary,
							"bankname" => $vals->bankname,"accountholder_name" => $vals->accountholder_name,"accountnumber" => $vals->accountnumber,
							"branchname" => $vals->branchname,"ifsc_code" => $vals->ifsc_code,"pancard_no" => $vals->pancard_no,
							"appraisalduedate" => $vals->appraisalduedate,"createdby"=>$loginUser,"createddate"=>date("Y-m-d h:i:s"));
							$this->db->insert("main_empsalarydetails",$insertArr);
							
							$json_salDetail = array("id"=>$userDetail->id,"user_id"=>$userDetail->user_id,"currencyid"=>$userDetail->currencyid,"salarytype"=>$userDetail->salarytype,"salary"=>$userDetail->salary,
							"bankname"=>$userDetail->bankname,"accountholder_name"=>$userDetail->accountholder_name,"accountnumber"=>$userDetail->accountnumber,
							"branchname"=>$userDetail->branchname,"ifsc_code"=>$userDetail->ifsc_code,"pancard_no"=>$userDetail->pancard_no,"appraisalduedate"=>$userDetail->appraisalduedate);
							
							$insertArr1 = array("salary_id" => $userDetail->id,"emp_id" =>$vals->user_id,"curr_sal"=>$userDetail->salary,"updated_by" => $loginUser,
							"Notification"=>"Salary_Details_Updated","all_details"=>json_encode($json_salDetail));
							$this->db->insert("emp_salary_history",$insertArr1);
						}
						
						
						$tempUpdate = array("main_status" =>2);
						$whereData = array("fld_id"=>$value);
						$response = $this->db->update("temp_salary_details",$tempUpdate,$whereData);
					}
						
				}
			}
		}
		if($response){
			$this->session->set_flashdata('successmsg', 'Salary Details Updated Successfully');
			redirect(base_url('salary_details_update'));
		}else{
			$this->session->set_flashdata('errormsg', 'Something Went Wrong');
			redirect(base_url('salary_details_update'));
		}
	}
	
	// public function update_temp_to_real_sal_details() {
		// $fld_id = $_REQUEST['fld_id'];
		// $loginUser = $this->session->userdata('loginid');
		// $resps = $this->get_temp_salary_details($fld_id);
		// if($resps){
			// foreach($resps as $vals){
				// $userDetail = $this->check_user_exist_in_salDetails($vals->user_id);
				// if($userDetail){
					// $where = array("user_id" => $vals->user_id,"isactive" => 1);
					// $updateArr = array("currencyid" => $vals->currencyid,"salarytype" => $vals->salarytype,"salary" => $vals->salary,
					// "bankname" => $vals->bankname,"accountholder_name" => $vals->accountholder_name,"accountnumber" => $vals->accountnumber,
					// "branchname" => $vals->branchname,"ifsc_code" => $vals->ifsc_code,"pancard_no" => $vals->pancard_no,
					// "appraisalduedate" => $vals->appraisalduedate,"modifiedby" => $loginUser,"modifieddate" => date("Y-m-d h:i:s"));
			
					// $this->db->update("main_empsalarydetails",$updateArr,$where);
					
					// $json_salDetail = array("id"=>$userDetail->id,"user_id"=>$userDetail->user_id,"currencyid"=>$userDetail->currencyid,"salarytype"=>$userDetail->salarytype,"salary"=>$userDetail->salary,
					// "bankname"=>$userDetail->bankname,"accountholder_name"=>$userDetail->accountholder_name,"accountnumber"=>$userDetail->accountnumber,
					// "branchname"=>$userDetail->branchname,"ifsc_code"=>$userDetail->ifsc_code,"pancard_no"=>$userDetail->pancard_no,"appraisalduedate"=>$userDetail->appraisalduedate);
					
					// $insertArr = array("salary_id" => $userDetail->id,"emp_id" =>$vals->user_id,"curr_sal"=>$userDetail->salary,"updated_by" => $loginUser,
					// "Notification"=>"Salary_Details_Updated","all_details"=>json_encode($json_salDetail));
					// $this->db->insert("emp_salary_history",$insertArr);
					
					
				// }else{
					// $insertArr = array("user_id" => $vals->user_id,"currencyid" => $vals->currencyid,"salarytype" => $vals->salarytype,"salary" => $vals->salary,
					// "bankname" => $vals->bankname,"accountholder_name" => $vals->accountholder_name,"accountnumber" => $vals->accountnumber,
					// "branchname" => $vals->branchname,"ifsc_code" => $vals->ifsc_code,"pancard_no" => $vals->pancard_no,
					// "appraisalduedate" => $vals->appraisalduedate,"createdby"=>$loginUser,"createddate"=>date("Y-m-d h:i:s"));
					// $this->db->insert("main_empsalarydetails",$insertArr);
					
					// $json_salDetail = array("id"=>$userDetail->id,"user_id"=>$userDetail->user_id,"currencyid"=>$userDetail->currencyid,"salarytype"=>$userDetail->salarytype,"salary"=>$userDetail->salary,
					// "bankname"=>$userDetail->bankname,"accountholder_name"=>$userDetail->accountholder_name,"accountnumber"=>$userDetail->accountnumber,
					// "branchname"=>$userDetail->branchname,"ifsc_code"=>$userDetail->ifsc_code,"pancard_no"=>$userDetail->pancard_no,"appraisalduedate"=>$userDetail->appraisalduedate);
					
					// $insertArr1 = array("salary_id" => $userDetail->id,"emp_id" =>$vals->user_id,"curr_sal"=>$userDetail->salary,"updated_by" => $loginUser,
					// "Notification"=>"Salary_Details_Updated","all_details"=>json_encode($json_salDetail));
					// $this->db->insert("emp_salary_history",$insertArr1);
				// }
				
				
				// $tempUpdate = array("main_status" =>2);
				// $whereData = array("fld_id"=>$fld_id);
				// $response = $this->db->update("temp_salary_details",$tempUpdate,$whereData);
			// }
				
		// }
		// if($response){
			// echo json_encode("Details Updated Successfully");
		// }else{
			// echo json_encode("Something Went Wrong");
		// }
	// }
	
	public function check_user_exist_in_salDetails($user_id) {
		$this->db->select('*');
        $this->db->from("main_empsalarydetails");
        $this->db->where(array("isactive" => 1,"user_id" => $user_id));
		$result = $this->db->get()->row();
        return ($result) ? $result : null;
	}
	
	public function get_temp_salary_details($fld_id) {
		$this->db->select('*');
        $this->db->from("temp_salary_details");
        $this->db->where(array("is_active" => '1',"fld_id" => $fld_id));
		$this->db->order_by("fld_id","DESC");
        $this->db->group_by("fld_id");
		$result = $this->db->get()->result();
        return ($result) ? $result : null;
	}
	
}
