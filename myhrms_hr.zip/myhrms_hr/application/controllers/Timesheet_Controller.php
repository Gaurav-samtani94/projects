<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Timesheet_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        //======================code start by durgesh (06-08-2020)=====================//
        $this->load->model('Timesheet/Report_timesheet_attendance_model', 'reptimesheetattenmodel');
        //======================code end by durgesh (06-08-2020)=====================//
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }

    //=========================code start by durgesh (06-08-2020)==========//
    public function timesheet_attenreport() {
        $data['error'] = '';
        $unit_arr = $this->db->get_where('main_businessunits', array('isactive' => '1'))->result();
        $title = "Timesheet Report";
        $this->load->view('timesheet/timesheet_attenreport', compact('title', 'unit_arr'));
    }

    public function ajax_list_attentimesheet() {
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');
        $list = $this->reptimesheetattenmodel->get_datatables($start_date, $end_date);

        $data = array();
        $no = $_POST['start'];

        foreach ($list as $val) {
            $no++;
            $GotTotLeave = 0;

            if (!empty($start_date) && !empty($end_date)) {
                $hour = $this->reptimesheetattenmodel->getattenreport($val->user_id, $start_date, $end_date);
                $another_hour = $this->reptimesheetattenmodel->getanotherattenreport($val->user_id, $start_date, $end_date);
                $total = (($hour->total_hour) + ($another_hour->another_hour));

                $f_date = date("Y-m-01", strtotime($start_date));
                $e_date = date("Y-m-t", strtotime($end_date));

                $GotTotLeave = $this->GotTotLeaveCount($val->user_id, $f_date, $e_date);
            } else {
                $total = '';
            }

            $row = array();
            $row[] = $no;
            $row[] = $val->employeeId;
            $row[] = $val->userfullname;
            $row[] = $val->department_name;
            $row[] = $val->position_name;
            $row[] = date("Y-m-d", strtotime($val->date_of_joining));
            $row[] = $total;
            $row[] = $GotTotLeave;
            $row[] = $val->isactive;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->reptimesheetattenmodel->count_all(),
            "recordsFiltered" => $this->reptimesheetattenmodel->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    //=============code end by durgesh(06-08-2020)==============================//
    //Leave Count Between Start Date And End Date Code By Asheesh 26-11-2020...
    public function GotTotLeaveCount($user_id, $start_date, $end_date) {
        $month = date('m', strtotime($end_date));
        $year = date('Y', strtotime($end_date));
        $fixdate = $year . '-' . $month . '-' . '01';
        $datechk = date('Y-m-d', strtotime($fixdate));
        $where_date = "((l.from_date >='$start_date' AND l.to_date <= '$end_date') OR (l.to_date >= '$datechk' AND l.to_date <= '$end_date'))";

        $this->db->select_sum('l.appliedleavescount');
        $this->db->from("main_leaverequest_summary as l");
        $this->db->where($where_date);
        $this->db->where(["l.user_id" => $user_id, "l.isactive" => "1"]);
        $this->db->where("l.leavestatus!=", "Cancel");
        $resultArr = $this->db->get()->row();
        return ($resultArr->appliedleavescount) ? $resultArr->appliedleavescount : "0";
    }

    public function mytsreport() {
        $start_date = "2020-04-01";
        $end_date = "2020-11-25";
        ?>
        <table id="tabledata" class="table table-striped display" border="1" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Sr. No</th>
                    <th>Emp Code</th>
                    <th>Emp Name</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>D.O.J - Resignation</th>
                    <th>Total Hour</th>
                    <th>Total Leave</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $this->db->select('a.position_name,a.employeeId,a.user_id,a.userfullname,a.department_name,a.date_of_joining,a.isactive,a.date_of_leaving');
                $this->db->from("main_employees_summary as a");
                $this->db->where_not_in('a.jobtitle_id', '8');
                $this->db->where('a.date_of_joining<', $end_date);
                $this->db->where('a.businessunit_id', '1');
                $this->db->group_by('a.user_id');
                $this->db->order_by('a.user_id');
                $listArr = $this->db->get()->result();


                // $listArr = $this->reptimesheetattenmodel->get_datatables($start_date, $end_date);
                if ($listArr) {
                    foreach ($listArr as $key => $val) {

                        if (!empty($start_date) && !empty($end_date)) {
                            $hour = $this->reptimesheetattenmodel->getattenreport($val->user_id, $start_date, $end_date);
                            $another_hour = $this->reptimesheetattenmodel->getanotherattenreport($val->user_id, $start_date, $end_date);
                            $total = (($hour->total_hour) + ($another_hour->another_hour));
                            $f_date = date("Y-m-01", strtotime($start_date));
                            $e_date = date("Y-m-t", strtotime($end_date));
                            $GotTotLeave = $this->GotTotLeaveCount($val->user_id, $f_date, $e_date);
                        }

                      //  if (($val->date_of_leaving == "") OR ( strtotime($rOws->date_of_leaving) > strtotime("2020-04-01"))) {  ?>
                            
                              <tr>
                                <td><?= $key + 1; ?></td>
                                <td><?= $val->employeeId; ?></td>
                                <td><?= $val->userfullname; ?></td>
                                <td><?= $val->department_name; ?></td>
                                <td><?= $val->position_name; ?></td>
                                <td><?= date("Y-m-d", strtotime($val->date_of_joining)); ?> - <?= ($val->date_of_leaving) ? date("Y-m-d", strtotime($val->date_of_leaving)) : ""; ?></td>
                                <td><?= $total; ?></td>
                                <td><?= $GotTotLeave; ?></td>
                                <td><?= $val->isactive; ?></td>
                            </tr>
                            
                            <?php
                       // }
                    }
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Sr. No</th>
                    <th>Emp Code</th>
                    <th>Emp Name</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>D.O.J - Resignation</th>
                    <th>Total Hour</th>
                    <th>Total Leave</th>
                    <th>Status</th>
                </tr>
            </tfoot>
        </table>
        <?php
        // echo "<pre>";
        // print_r($listArr);
        // die;
    }

}
