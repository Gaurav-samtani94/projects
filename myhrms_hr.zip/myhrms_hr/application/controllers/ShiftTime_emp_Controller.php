<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ShiftTime_emp_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function shiftTimings() {
        $data['title'] = "Update Shift Timings";
        $data['AllRecArr'] = $this->empReqshiftTimings();
		//echo "<pre>"; print_r($data['AllRecArr']); die;
		if ($this->input->post()) {
            
            $result = $this->input->post();
			//echo "<pre>"; print_r($result); die;
            $dept = $this->input->post('dept');
            $empids = $this->input->post('employees');
			if($empids == '77777'):
				$reqdata = $this->empReqByid($dept);
				//$insertArr = array();
				foreach($reqdata as $val):
					$where = ["user_id" => $val->user_id]; 
					$insertArr = [
						'shift_in_time' => $this->input->post('shift_in_time'),
						'shift_out_time' => $this->input->post('shift_out_time')
					];
					//echo "<pre>"; print_r($insertArr); die;
					$resp_updt = $this->db->update('emp_otherofficial_data',$insertArr,$where);
				endforeach;
				//echo "<pre>"; print_r($insertArr); die;
			else:
				$emp = $this->input->post('employees');
				$where = ["user_id" => $emp];
				$insertArr = [
						'shift_in_time' => $this->input->post('shift_in_time'),
						'shift_out_time' => $this->input->post('shift_out_time')
					];
				$resp_updt = $this->db->update('emp_otherofficial_data',$insertArr,$where);
			endif;
            //$resp_updt = $this->db->update('emp_otherofficial_data',$result,array('' => $dept));
            if ($resp_updt):
                $this->session->set_flashdata('success_msg', 'Data Updated successfully');
                redirect(base_url('shiftTimings'));
            else:
                $this->session->set_flashdata('error_msg', 'Something went wrong');
                redirect(base_url('shiftTimings'));
            endif;
        }
		else{
			$this->load->view("shift_time/shift_time_view", $data);
		}
    }
	
	public function ajax_subdpt_getbydpt() {
        $deptid = $_REQUEST['department'];
		$this->db->select("*");
		$this->db->from("main_subdepartments");
		$this->db->where("is_active", "1");
		$this->db->where("deptid", $deptid);
		$result = $this->db->get()->result();
        echo json_encode($result);
    }

	public function ajax_emp_getbydept() {
		// echo "<pre>"; print_r($_REQUEST); die;
		// echo json_encode("test"); die;
        $deptid = $_REQUEST['department'];
        // $deptid = $_REQUEST['department'];
		// echo json_encode("testing"); die;
		$this->db->select("user_id,userfullname");
		$this->db->from("main_employees_summary");
		$this->db->where("isactive", "1");
		$this->db->where("department_id", $deptid);
		$result = $this->db->get()->result();
        echo json_encode($result);
    }
	
	public function empReqByid($deptid) {
		$this->db->select("user_id");
		$this->db->from("main_employees_summary");
		$this->db->where("isactive", "1");
		$this->db->where("department_id", $deptid);
		$result = $this->db->get()->result();
        return $result;
    }
	
	public function empReqshiftTimings() {
		$this->db->select("a.user_id,a.userfullname,department_name,jobtitle_name,b.shift_in_time,b.shift_out_time");
		$this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
		$this->db->where("a.isactive", "1");
		$this->db->group_by("a.user_id");
		$result = $this->db->get()->result();
        return $result;
    }
	
	

}
