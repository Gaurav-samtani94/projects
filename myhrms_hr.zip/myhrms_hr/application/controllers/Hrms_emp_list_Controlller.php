<?php

defined('BASEPATH') or exit('No direct script access allowed');
//require_once('vendor/autoload.php');
//use PhpOffice\PhpSpreadsheet\Spreadsheet;
//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
class Hrms_emp_list_Controlller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('All_employee_list_Model');
        $this->load->model('Employecsv_model');
        $this->load->library('form_validation');
        $this->load->helper('download');
        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
        } else {
            redirect(base_url(""));
        }
    }

    public function emp_list()
    {
        $data['title'] = "Employee List : All";
        $data['Hr_EmpDetailsArr'] = $this->Hr_EmpDetailsArr();
        $this->load->view("hrms_employee_list/employee_list", $data);
    }

    public function emp_list_active()
    {
        $data['title'] = "Employee List : Active";
        $data['Hr_EmpDetailsArr'] = $this->Hr_EmpDetailsArr_active();
        $this->load->view("hrms_employee_list/employee_list", $data);
    }

    public function emp_list_inactive()
    {
        $data['title'] = "Employee List : In Active";
        $data['Hr_EmpDetailsArr'] = $this->Hr_EmpDetailsArr_inactive();
        $this->load->view("hrms_employee_list/employee_list", $data);
    }

    public function Hr_EmpDetailsArr()
    {
        $this->load->database();
        $this->db->select('main_employees_summary.*');
        $this->db->from("main_employees_summary");
        $res = $this->db->get()->result();
        return ($res) ? $res : "";
    }

    public function Hr_EmpDetailsArr_active()
    {
        $this->load->database();
        $this->db->select('main_employees_summary.*');
        $this->db->from("main_employees_summary");
        $this->db->where("isactive", "1");
        $res = $this->db->get()->result();
        return ($res) ? $res : "";
    }

    public function Hr_EmpDetailsArr_inactive()
    {
        $this->load->database();
        $this->db->select('main_employees_summary.*');
        $this->db->from("main_employees_summary");
        $status_array = array("0", "2", "3", "4");
        $this->db->where_in("isactive", $status_array);
        $res = $this->db->get()->result();
        return ($res) ? $res : "";
    }

    public function ajax_getsingleemp_id()
    {
        $emp_id = $_REQUEST['emp_id'];
        // print_r($emp_id);
        if ($emp_id) {
            $this->load->database();
            $this->db->select('*');
            $this->db->from('main_employees_summary');
            $this->db->where("id", $emp_id);
            $NewsRecord = $this->db->get()->row();
            echo json_encode($NewsRecord);
        }
    }

    //================Emp list for profile PDF =============================
    public function ajax_employee_list()
    {
        $list = $this->All_employee_list_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $dataRow) {
            $image1 = '<img src="' . HOSTNAME . "public/uploads/profile/profile_pic.png" . '" class="rounded-circle avatar" alt="" style="height:50px; width:50px;">';
            if ($dataRow->profileimg) {
                $image = '';
                $image .= isset($dataRow->profileimg) ? $dataRow->profileimg : '';
                $imageCr = str_replace("index.php/", "", $image);
                $image1 = '<img src="' . EMPLPROFILE . $imageCr . '" class="rounded-circle avatar" alt="" style="height:50px; width:50px;">';
            }
            $employeeStatus = $dataRow->isactive ? $dataRow->isactive : '0';
            if ($employeeStatus == "0") {
                $empStatus =  "<span class='btn btn-danger'>Inactive</span>";
            } elseif ($employeeStatus == "1") {
                $empStatus =  "<span class='btn btn-success'>Active</span>";
            } elseif ($employeeStatus == "2") {
                $empStatus = "<span class='btn btn-danger'>Resigned</span>";
            } elseif ($employeeStatus == "3") {
                $empStatus = "<span class='btn btn-info'>Left</span>";
            } elseif ($employeeStatus == "4") {
                $empStatus = "<span class='btn btn-info'>Suspended</span>";
            }
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($dataRow->userfullname) ? $image1 . "&nbsp;&nbsp;" . $dataRow->userfullname . "" : '';
            $row[] = isset($dataRow->contactnumber) ? $dataRow->contactnumber : '';
            $row[] = isset($dataRow->emailaddress) ? $dataRow->emailaddress : '';
            $row[] = isset($dataRow->department_name) ? $dataRow->department_name : '';
            $row[] = isset($dataRow->businessunit_name) ? $dataRow->businessunit_name : '';
            $row[] = $empStatus;
            //$row[] = "<span style='display:flex;flex-direction: row-reverse;'><a href='".base_url("pdfgenerate/".$dataRow->user_id)."' class='btn btn-info' target='_blank' title='Download'><i class='fa fa-download'></i></a>&ensp;<a href='".base_url("employee_edit/".$dataRow->user_id)."' class='btn btn-info' title='Edit'><i class='fa fa-edit'></i></a>&nbsp; <a href='" . base_url("excelgenerate/" . $dataRow->user_id) . "' class='btn btn-info' target='_blank' title='Download Excel'><i class='fa fa-file-excel-o'></i></a></span>";
            $row[] = "<input type='hidden' class='txt_csrfname' name='" . $this->security->get_csrf_token_name() . "' value='" . $this->security->get_csrf_hash() . "'><span style='display:flex;'><a href='" . base_url("pdfgenerate/" . $dataRow->user_id) . "' class='btn btn-info' target='_blank' title='Download'><i class='fa fa-download'></i></a>&ensp;<a href='" . base_url("employee_edit/" . $dataRow->user_id) . "' class='btn btn-info' title='Edit'><i class='fa fa-edit'></i></a>&nbsp;<span style='float:left'> <form method='POST' action='" . base_url('FetchEmp_ReportData') . "'><input type='hidden' name='Employe_id' value='" . $dataRow->user_id . "'> <button type='submit' class='btn btn-info'><i class='fa fa-file-excel-o'></i></button></form></span></span>";

            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->All_employee_list_Model->count_all(),
            "recordsFiltered" => $this->All_employee_list_Model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    //================== Download Employee profile data in pdf ======================
    public function pdfgenerate()
    {
        $empID = $this->uri->segment(2);
        $empDetail = $this->mastermodel->getEmpDetailsByUserID($empID);
        // echo "<pre>"; print_r($empDetail); die;
        $contact = $this->mastermodel->GetContactDetailRecByID($empID);
        $skill = $this->mastermodel->GetRecEmplSkillsDetails($empID);
        $jobHistory = $this->mastermodel->GetRecEmpljobhistoryDetails($empID);
        $family = $this->mastermodel->GetRecEmplFamilyDetails($empID);
        $paySlip = $this->mastermodel->GetRecentPayslipDetails($empID);
        $experience = $this->mastermodel->GetTableData("main_empexperiancedetails", ["isactive" => "1", "user_id" => $empID]);
        $eduDetail = $this->mastermodel->GetTableData("main_empeducationdetails", ["isactive" => "1", "user_id" => $empID]);
        $certificate = $this->mastermodel->GetTableData("main_empcertificationdetails", ["isactive" => "1", "user_id" => $empID]);
        $itr = $this->mastermodel->GetTableData("main_itr", ["is_active" => "1", "user_id" => $empID]);
        $referencesDetails = $this->mastermodel->GetReferencesDetailRecByID($empID);

        $empDocs = $this->mastermodel->GetEmployeeDocsDetailRecByID($empID);
        $empOtherDetail = $this->mastermodel->getOtherUserRecordByUserID($empID);
        // echo "dd<pre>"; print_r($data); die;
        $this->load->library('mp_pdf');
        $data['title'] = 'Employee Info';

        // echo "dd<pre>"; print_r($referencesDetails); die;
        $po_view = $this->load->view('employee/emp_info_pdf', compact('referencesDetails', 'empOtherDetail', 'empDocs', 'empDetail', 'contact', 'skill', 'jobHistory', 'family', 'paySlip', 'experience', 'eduDetail', 'certificate', 'itr'), true);
        // echo $po_view; die;
        // $po_view = "test";


        $pdfFilePath = "employee_info.pdf";
        $this->mp_pdf->pdf->mirrorMargins = 1;
        $this->mp_pdf->pdf->shrink_tables_to_fit = 1;
        $this->mp_pdf->pdf->SetTitle('Employee Info');
        ob_clean();
        ob_flush();
        $this->mp_pdf->pdf->WriteHTML($po_view);
        $this->mp_pdf->pdf->Output($pdfFilePath, "D");
        ob_end_flush();
        ob_end_clean();
    }
    public function excelgenerate()
    {
        $empID = $this->uri->segment(2);

        $this->load->library('excel');
        $spreadsheet = new PHPExcel();

        $HeadeingArray =
            array(
                'font'    => array(
                    'bold'      => true
                ),


            );
        $styleArray =
            array(
                'font'    => array(
                    'bold'      => true
                ),
                'alignment' => array(
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_RIGHT,
                ),
                'borders' => array(
                    'top'     => array(
                        'style' => PHPExcel_Style_Border::BORDER_THIN
                    )
                ),
                'fill' => array(
                    'type'       => PHPExcel_Style_Fill::FILL_SOLID,
                    'rotation'   => 90,
                    'startcolor' => array(
                        'argb' => 'FFA0A0A0'
                    ),

                )

            );
        $count = 1;
        $empDetail[] = $this->Employecsv_model->getEmpDetailsByUserID($empID);
        $contact[] = $this->Employecsv_model->GetContactDetailRecByID($empID);
        $skill = $this->Employecsv_model->GetRecEmplSkillsDetails($empID);
        $jobHistory = $this->Employecsv_model->GetRecEmpljobhistoryDetails($empID);


        // die();
        $family = $this->Employecsv_model->GetRecEmplFamilyDetails($empID);

        // // print_r($family);
        // // die();
        $paySlip = $this->Employecsv_model->GetRecentPayslipDetails($empID);
        // echo "<pre>";
        // print_r($paySlip);
        // die();
        // // print_r($paySlip);
        // // die();
        $experience = $this->Employecsv_model->GetTableData("main_empexperiancedetails", ["isactive" => "1", "user_id" => $empID]);
        // // print_r($experience);
        $eduDetail = $this->Employecsv_model->GetTableData("main_empeducationdetails", ["isactive" => "1", "user_id" => $empID]);
        $certificate = $this->Employecsv_model->GetTableData("main_empcertificationdetails", ["isactive" => "1", "user_id" => $empID]);
        $itr = $this->Employecsv_model->GetTableData("main_itr", ["is_active" => "1", "user_id" => $empID]);
        $referencesDetails = $this->Employecsv_model->GetReferencesDetailRecByID($empID);
        $empOtherDetail = $this->Employecsv_model->getOtherUserRecordByUserID($empID);
        //print_r($empOtherDetail);
        // echo "<pre>";
        // print_R($empOtherDetail);
        // die();

        // echo "<pre>";
        // print_R($empDetail->rolename);
        // die();
        // echo "<pre>";
        //1. Persinoal Information 
        // $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        // $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Persional Detail')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        //n.rolename,b.firstname,b.lastname,m.gendername,i.*,l.religion_name,k.nationalitycode,j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.sub_department,c.probation_period_no,,c.noticeperiod,C.floor_number,C.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.date_of_leaving,b.profileimg,b.years_exp,b.emp_status_name,b.extension_number,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Rol Name')->getStyle('A' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'First Name')->getStyle('B' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Last Lame.')->getStyle('C' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Gender')->getStyle('D' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'Religion Name')->getStyle('E' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'Nationality Code')->getStyle('F' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Marital Status Name')->getStyle('G' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('H' . $count, 'Mother Name')->getStyle('H' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Father Name')->getStyle('I' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('J' . $count, 'Pancard No')->getStyle('J' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('K' . $count, 'Appraisal Due Date')->getStyle('K' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('L' . $count, 'Bank Name')->getStyle('L' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('M' . $count, 'Accountholder Name')->getStyle('M' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('N' . $count, 'Account Number')->getStyle('N' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('O' . $count, 'Branch Name')->getStyle('O' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('P' . $count, 'IFSC Code')->getStyle('P' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('Q' . $count, 'Frequency Type')->getStyle('Q' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('R' . $count, 'Sub Department')->getStyle('R' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('S' . $count, 'Probation Period No')->getStyle('S' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('T' . $count, 'Notice Period')->getStyle('T' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('U' . $count, 'Floor Number')->getStyle('U' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('V' . $count, 'Payroll Code')->getStyle('V' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('W' . $count, 'City Name')->getStyle('W' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('X' . $count, 'Ro Name')->getStyle('X' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('Y' . $count, 'Sub Department')->getStyle('Y' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('Z' . $count, 'User Full Name')->getStyle('Z' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AA' . $count, 'Email Address')->getStyle('AA' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AB' . $count, 'Contact Number')->getStyle('AB' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AC' . $count, 'Employee Id')->getStyle('AC' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AD' . $count, 'Date Of Leaving')->getStyle('AD' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AE' . $count, 'Profile Image')->getStyle('AE' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AF' . $count, 'Years Exp')->getStyle('AF' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AG' . $count, 'Employe Status Name')->getStyle('AG' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AH' . $count, 'Extension Number')->getStyle('AH' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AI' . $count, 'Businessunit Name')->getStyle('AI' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AJ' . $count, 'Department Name')->getStyle('AJ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AK' . $count, 'Jobtitle Name')->getStyle('AK' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AL' . $count, 'Reporting Manager Name')->getStyle('AL' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AM' . $count, 'Position Name')->getStyle('AM' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AN' . $count, 'Date Of Joining')->getStyle('AN' . $count)->applyFromArray($styleArray);
        // $spreadsheet->getActiveSheet()->setCellValue('AO' . $count, 'Gender')->getStyle('AO' . $count)->applyFromArray($styleArray);
        // $spreadsheet->getActiveSheet()->setCellValue('AP' . $count, 'Gender')->getStyle('AP' . $count)->applyFromArray($styleArray);

        $count++;
        foreach ($empDetail as $key => $rows) {
            // echo "<pre>";
            // print_R($rows);

            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $rows->rolename);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $rows->firstname);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $rows->lastname);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $rows->gendername);
            //n.rolename,b.firstname,b.lastname,m.gendername,i.*,l.religion_name,k.nationalitycode,j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.sub_department,c.probation_period_no,,c.noticeperiod,C.floor_number,C.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.date_of_leaving,b.profileimg,b.years_exp,b.emp_status_name,b.extension_number,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining

            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $rows->religion_name);
            $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $rows->nationalitycode);
            $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $rows->maritalstatusname);
            $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $rows->mother_nm); //->getStyle('H' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $rows->father_nm); //->getStyle('I' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('J' . $count, $rows->pancard_no); //->getStyle('J' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('K' . $count, $rows->appraisalduedate); //->getStyle('K' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('L' . $count, $rows->bankname); //->getStyle('L' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('M' . $count, $rows->accountholder_name); //->getStyle('M' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('N' . $count, $rows->accountnumber); //->getStyle('N' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('O' . $count, $rows->ifsc_code); //->getStyle('O' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('P' . $count, $rows->freqtype); //->getStyle('P' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('Q' . $count, $rows->salary); //->getStyle('Q' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('R' . $count, $rows->sub_department); //->getStyle('R' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('S' . $count, $rows->probation_period_no); //->getStyle('S' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('T' . $count, $rows->noticeperiod); //->getStyle('T' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('U' . $count, $rows->floor_number); //->getStyle('U' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('V' . $count, $rows->payrollcode); //->getStyle('V' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('W' . $count, $rows->city_name); //->getStyle('W' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('X' . $count, $rows->roName); //->getStyle('X' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('Y' . $count, $rows->subdepartment); ///->getStyle('Y' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('Z' . $count, $rows->userfullname); //->getStyle('Z' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AA' . $count, $rows->emailaddress); //->getStyle('AA' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AB' . $count, $rows->contactnumber); //->getStyle('AB' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AC' . $count, $rows->employeeId); //->getStyle('AC' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AD' . $count, $rows->date_of_leaving); //->getStyle('AD' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AE' . $count, $rows->profileimg); //->getStyle('AE' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AF' . $count, $rows->years_exp); //->getStyle('AF' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AG' . $count, $rows->emp_status_name); //->getStyle('AG' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AH' . $count, $rows->extension_number); //->getStyle('AH' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AI' . $count, $rows->businessunit_name); //->getStyle('AI' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AJ' . $count, $rows->department_name); //->getStyle('AJ' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AK' . $count, $rows->jobtitle_name); //->getStyle('AK' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AL' . $count, $rows->reporting_manager_name); //->getStyle('AL' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AM' . $count, $rows->position_name); //->getStyle('AM' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AN' . $count, $rows->date_of_joining); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $count++;
        }
        //  die();
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Employee Detail')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Email')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'Permanent Streat Address')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Current Address')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Emergency Number')->getStyle('D' . $count)->applyFromArray($styleArray);
        $count++;
        // Retrieve the current active worksheet





        //2Employee Contact Nyumber
        foreach ($contact as $key => $row) {
            // echo "<pre>";
            // print_R($row);

            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $row->personalemail);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $row->perm_streetaddress);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $row->current_streetaddress);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $row->emergency_number);
            $count++;
        }
        //3. Skilols 
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Skills Detail')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Skill Name')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'Year Of Experience')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Year Last Used')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Trainingv Type')->getStyle('D' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'University')->getStyle('E' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'Marks Obtained')->getStyle('F' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Tenure From To')->getStyle('G' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('H' . $count, 'Percentage Grade')->getStyle('H' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Competency Level')->getStyle('I' . $count)->applyFromArray($styleArray);







        $count++;

        foreach ($skill as $key => $skil) {
            // echo "<pre>";
            // print_R($skil);

            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $skil->skillname);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $skil->yearsofexp);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $skil->year_skill_last_used);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $skil->training_type);
            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $skil->university);
            $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $skil->marks_obtained);
            $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $skil->tenure_from_to);
            $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $skil->percentage_grade);
            $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $skil->competency_level);

            $count++;
        }

        //4. $jobHistory
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'JobHistory')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Start Date')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'End Date')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Unit Name')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Deptname')->getStyle('D' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'University')->getStyle('E' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'Jobtitle Name')->getStyle('F' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Position Name')->getStyle('G' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('H' . $count, 'Company Name')->getStyle('H' . $count)->applyFromArray($styleArray);
        // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Competency Level');
        $count++;
        foreach ($jobHistory as $keys => $job) {
            // echo "<pre>";
            // print_R($jobHistory);
            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $job->start_date);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $skil->end_date);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $skil->unitname);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $skil->deptname);
            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $skil->University);
            $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $skil->jobtitlename);
            $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $skil->positionname);
            $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $skil->company_name);
            // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $skil->competency_level);

            $count++;
        }


        //5. family
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Family History')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Dependent Name')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'Dependent Relation')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Dependent Custody')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Dependent Dob')->getStyle('D' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'Dependent Age')->getStyle('E' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'Aadhar No')->getStyle('F' . $count)->applyFromArray($styleArray);
        // $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Position Name');
        // $spreadsheet->getActiveSheet()->setCellValue('H' . $count, 'Company Name');
        // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Competency Level');
        $count++;
        foreach ($family as $keys => $fam) {
            // echo "<pre>";
            // print_R($jobHistory);
            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $fam->dependent_name);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $fam->dependent_relation);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $fam->dependent_custody);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $fam->dependent_dob);
            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $fam->dependent_age);
            $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $fam->aadhar_no);
            // $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $fam->positionname);
            // $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $fam->company_name);
            // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $skil->competency_level);

            $count++;
        }
        //6. paySlip Detail
        // $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        // $count++;
        // $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'PaySlip History');
        // $count++;
        // $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'year ');
        // $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'month ');
        // $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'payroll_with_name ');
        // // $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Dependent Dob');
        // // $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'Dependent Age');
        // // $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'Aadhar No');
        // // $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Position Name');
        // // $spreadsheet->getActiveSheet()->setCellValue('H' . $count, 'Company Name');
        // // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Competency Level');
        // $count++;
        // foreach ($paySlip as $keys => $pay) {
        //     // echo "<pre>";
        //     // print_R($jobHistory);
        //     $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $pay->year);

        //     $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $pay->month);

        //     $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $pay->payroll_with_name);

        //     // $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $fam->dependent_dob);
        //     // $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $fam->dependent_age);
        //     // $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $fam->aadhar_no);
        //     // $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $fam->positionname);
        //     // $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $fam->company_name);
        //     // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $skil->competency_level);

        //     $count++;
        // }


        //7.experience Detail 
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Experience History')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Company Name ')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'Company Website ')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'company location ')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Designation')->getStyle('D' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'From Date')->getStyle('E' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'To Date')->getStyle('F' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Resasion For Leaving')->getStyle('G' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('H' . $count, 'Refrence Name')->getStyle('H' . $count)->applyFromArray($styleArray);
        // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Competency Level');
        $count++;
        foreach ($experience as $keys => $exp) {
            // echo "<pre>";
            // print_R($exp);
            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $exp->comp_name);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $exp->comp_website);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $exp->comp_location);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $exp->designation);
            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $exp->from_date);
            $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $exp->to_date);
            $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $exp->reason_for_leaving);
            $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $exp->reference_name);
            // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $skil->competency_level);

            $count++;
        }
        //8. eduDetail Detail
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Education Detail')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Institution Name')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'Course ')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, ' Spc Location')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Specialization ')->getStyle('D' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'From Date')->getStyle('E' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'To Date')->getStyle('F' . $count)->applyFromArray($styleArray);
        // $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'To Date');
        $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Percentage')->getStyle('G' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('H' . $count, 'Education Type')->getStyle('H' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Marks Obtained')->getStyle('I' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('J' . $count, 'Total Marks')->getStyle('J' . $count)->applyFromArray($styleArray);

        $count++;
        foreach ($eduDetail as $keys => $edu) {

            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $edu->institution_name);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $edu->course);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $edu->spc_location);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $edu->specialization);
            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $edu->from_date);
            $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $edu->to_date);
            $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $edu->percentage);
            $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $edu->education_type);
            $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $edu->marks_obtained);
            $spreadsheet->getActiveSheet()->setCellValue('J' . $count, $edu->total_marks);


            $count++;
        }
        //9.certificate Histaory 
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Certification History')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Cource Name')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'Description')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Cource Level')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Offred By ')->getStyle('D' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'Certification Name')->getStyle('E' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'issued Date')->getStyle('F' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Marks Obtained')->getStyle('G' . $count)->applyFromArray($styleArray);
        // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Total Marks');

        $count++;
        foreach ($certificate as $keys => $cer) {

            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $cer->course_name);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $cer->description);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $cer->course_level);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $cer->course_offered_by);
            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $cer->certification_name);
            $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $cer->issued_date);
            $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $cer->marks_obtained);
            // $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $cer->education_type);
            // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $cer->marks_obtained);
            // $spreadsheet->getActiveSheet()->setCellValue('J' . $count, $cer->total_marks);


            $count++;
        }
        //10. Itr History 
        // $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        // $count++;
        // $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Itr History');
        // $count++;
        // $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Pan Number');
        // $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'Fin Year');
        // // $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Cource Level');
        // // $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Offred By ');
        // // $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'Certification Name');
        // // $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'issued Date');

        // // $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Marks Obtained');
        // // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Total Marks');

        // $count++;
        // foreach ($itr as $keys => $it) {

        //     $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $it->pancardno);

        //     $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $it->finyear);

        //     // $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $itr->course_level);

        //     // $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $itr->course_offered_by);
        //     // $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $cer->certification_name);
        //     // $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $cer->issued_date);
        //     // $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $cer->marks_obtained);
        //     // $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $cer->education_type);
        //     // $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $cer->marks_obtained);
        //     // $spreadsheet->getActiveSheet()->setCellValue('J' . $count, $cer->total_marks);


        //     $count++;
        // }
        //11.referencesDetails
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Refrence History')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Refrence Name')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'Organisation')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Designation')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Contact Number ')->getStyle('D' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'Refrence Type')->getStyle('E' . $count)->applyFromArray($styleArray);


        $count++;
        foreach ($referencesDetails as $keys => $refdet) {

            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $refdet->reference_name);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $refdet->organisation);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $refdet->designation);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $refdet->contact_no);
            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $refdet->reference_type);



            $count++;
        }

        //12.empOtherDetail

        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, '');
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Employe Other History')->getStyle('A' . $count)->applyFromArray($HeadeingArray);
        $count++;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'Candidate Source')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'Candidate Refrence')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Criminal Offense')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Drug Alcohal Abuse ')->getStyle('D' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'Criminal Offense Detail')->getStyle('E' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'Drug Abuse Detail')->getStyle('F' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'Pre Existing Illness')->getStyle('G' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('H' . $count, 'Partial Disabilities')->getStyle('H' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'Pre Existing Illness Detail')->getStyle('I' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('J' . $count, 'Partial Disabilities Detail')->getStyle('J' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('k' . $count, 'Relative Employed Ceg')->getStyle('K' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('L' . $count, 'Employed Ceg Relation')->getStyle('L' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('M' . $count, 'Previous employee Code')->getStyle('M' . $count)->applyFromArray($styleArray);

        $count++;

        foreach ($empOtherDetail as $keys => $empoth) {
            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $empoth->candidate_source);
            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $empoth->candidate_reference);
            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $empoth->criminal_offense);
            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $empoth->drug_alcohal_abuse);
            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $empoth->criminal_offense_detail);
            $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $empoth->drug_abuse_detail);
            $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $empoth->pre_existing_illness);
            $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $empoth->partial_disabilities);
            $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $empoth->pre_existing_illness_detail);
            $spreadsheet->getActiveSheet()->setCellValue('J' . $count, $empoth->partial_disabilities_detail);
            $spreadsheet->getActiveSheet()->setCellValue('K' . $count, $empoth->relative_employed_ceg);
            $spreadsheet->getActiveSheet()->setCellValue('L' . $count, $empoth->employed_ceg_relation);
            $spreadsheet->getActiveSheet()->setCellValue('M' . $count, $empoth->previous_employee_code);



            $count++;
        }



        // header('Content-Type: application/vnd.ms-excel');
        // header('Content-Disposition: attachment;filename="Employee Data.xlsx"');
        // $writer->save('abc.xlsx');

        $writer = PHPExcel_IOFactory::createWriter($spreadsheet, 'Excel5');
        $name = rand(1000000, 10000000);
        $file_name = "report_$name.xls";
        $location = "assets/report/";
        $writer->save($location . $file_name);
        // force_download($location . $file_name, NULL);
        $user_id = $this->session->userdata('loginid');
        // print_r($user_id);
        // die();
        $report_Filename = array(
            'user_id' => $user_id,
            'file_name' =>  $file_name
        );
        $this->db->insert('Employe_single_report_download', $report_Filename);
        $this->db->select('file_name');
        $this->db->from('Employe_single_report_download');
        $this->db->where('user_id', $user_id);
        $this->db->where('file_name', $file_name);
        $this->db->order_by('id', 'desc');
        $selectfilename = $this->db->get()->row();
        //  print_R(($location . $selectfilename->file_name));
        force_download($location . $selectfilename->file_name, null);
        // //  $requestlocation =  $this->db->get()->row();
    }
}
