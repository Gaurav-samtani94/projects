<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Visiting_card_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Visiting_card_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function applyvisitingcard() {
        $id = $this->session->userdata('loginid');
        // echo $id; die;
        if ($_REQUEST) {
            $insrtArr = array('user_id' => $id,
                'approved_by' => $this->input->post('approved_by'),
                'date_of_initiation' => date("Y-d-m h:i:s"));

            $this->Visiting_card_model->InsertData($insrtArr, 'hrm_visiting_card');
        }

        $data['visitingDetailArr'] = $this->Visiting_card_model->GetDetailForVisitingCardRecByID($id);
        $data['appliedvisitingDetailArr'] = $this->Visiting_card_model->GetDetailofappliedVisitingCard($id);
        $data['appliedvisitingDetailArr1'] = $this->Visiting_card_model->GetDetailofappliedVisitingCard1($id);
        $data['appliedvisitingDetailArr2'] = $this->Visiting_card_model->GetDetailofappliedVisitingCard_for_hr();
        // $dpt_id = get_emp_dpt_data($id);
        // echo "<pre>";print_r($data['userdptdata']); die;
        $data['title'] = "Apply Visiting Card";
        $data['idUser'] = $this->session->userdata('loginid');
        $this->load->view("visiting_card/apply_visiting_card_view", $data);
    }

    //update..
    public function update_visiting_card_rqst() {
        // echo "test"; die;
        $record_num = $this->uri->segment(2);
        $data['appliedvisitingDetailArr'] = $this->Visiting_card_model->GetDetailofappliedVisitingCard($record_num);
        $userid = $data['appliedvisitingDetailArr'][0]->user_id;
        $table = 'hrm_visiting_card';
        $Where = 'user_id=' . $userid;
        $data = array(
            'status' => '1',
        );
        $this->Visiting_card_model->update_visitingcard_rqst($table, $Where, $data);
        redirect(base_url("applyvisitingcard"));
    }

    //update by HR..
    public function update_visiting_card_rqst_hr() {
        // echo "test"; die;
        $record_num = $this->uri->segment(2);
        $data['appliedvisitingDetailArr'] = $this->Visiting_card_model->GetDetailofappliedVisitingCard($record_num);
        $userid = $data['appliedvisitingDetailArr'][0]->user_id;
        $table = 'hrm_visiting_card';
        $Where = 'user_id=' . $userid;
        $data = array(
            'status' => '2',
        );
        $this->Visiting_card_model->update_visitingcard_rqst($table, $Where, $data);
        redirect(base_url("applyvisitingcard"));
    }

    //update..
    public function update_visiting_card_rqst_reject() {
        $record_num = $this->uri->segment(2);
        // echo $record_num; die;
        $data['appliedvisitingDetailArr'] = $this->Visiting_card_model->GetDetailofappliedVisitingCard($record_num);
        $userid = $data['appliedvisitingDetailArr'][0]->user_id;
        // echo $record_num."=".$userid; die;
        $table = 'hrm_visiting_card';
        $Where = 'user_id=' . $userid;
        $data = array(
            'status' => '3',
        );
        $this->Visiting_card_model->update_visitingcard_rqst($table, $Where, $data);
        redirect(base_url("applyvisitingcard"));
    }

}
