<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Project_Attendance_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('project_attendance/Attendance_model', 'attendancemodel');
        $this->load->model('project_attendance/Accountdept_model', 'accdeptmodel');
        $this->load->library('form_validation');

        if ($this->session->userdata('loginid') == "") {
            $this->session->set_flashdata('error_msg', "Permission Denied.");
            redirect(base_url(""));
        }

        if ($this->session->userdata('assign_role') == "1") {
            $this->session->set_flashdata('error_msg', "Permission Denied.");
            redirect(base_url(""));
        }


        $this->db1 = $this->load->database('default', TRUE);
        $this->db2 = $this->load->database('online', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);
    }

    public function fill_attendance() {
        $data['error'] = '';
        $data['title'] = 'Fill Attendance';
        $UserId = $this->session->userdata('loginid');
        //$data['ProjectListRecArr'] = $this->attendancemodel->ProjectListAll();
        //code change by durgesh(21-10-2020)
        $data['ProjectListRecArr'] = $this->attendancemodel->AllProjectIDListNewArr();
        $data['ProjIDesRecArr'] = $this->attendancemodel->AllProjectIDListArr();
        // echo "dd<pre>"; print_r($data['ProjIDesRecArr']); die;
        $this->load->view('project_attendance/attendancelist_view', $data);
    }

    public function fill_attendance_project($hrmsProjID) {
        $data['error'] = '';
        $data['title'] = 'Fill Attendance';
        $UserId = $this->session->userdata('loginid');
		// echo $hrmsProjID; die;
        if (@$_REQUEST['filterAttend'] && @$_REQUEST['year_rcd'] && @$_REQUEST['month_rcd']) {
            $month = $_REQUEST['month_rcd'];
            $year = $_REQUEST['year_rcd'];
        } else {
            $month = date("m");
            $year = date("Y");
        }

        $a_date = $year . "-" . $month . "-01";
        $data['lastdate_month'] = date("t", strtotime($a_date));


        $data['DesignCategList'] = $this->accdeptmodel->GetAllDesignCategAndTeamByProjID($hrmsProjID);
		// echo "ddd<pre>"; print_r($data['DesignCategList']); die;
        $data['DesignationAllList'] = $this->accdeptmodel->GetProjectDesignationListArr($hrmsProjID);
        
		$data['projectinfo'] = $this->accdeptmodel->GetAccountInfoData($hrmsProjID);
        $bDpRojectID = $data['projectinfo']->project_id;

        $data['SatDay_List'] = getSundays($year, $month, 6);
        $data['SunDay_List'] = getSundays($year, $month, 7);
		// echo "ddd<pre>"; print_r($data['SatDay_List']); die;
        $data['Holiday_List'] = $this->accdeptmodel->getHolidaysArr($month, $year, $hrmsProjID);
        $data['getmonth'] = $month;
        $data['getyear'] = $year;
        $data['existAttendRec'] = $this->accdeptmodel->GetAttendRec($hrmsProjID, $year, $month);

        $ProjIDesRecArr = $this->attendancemodel->AllProjectIDListArr();
        if (in_array($hrmsProjID, $ProjIDesRecArr) == "") {
            $this->session->set_flashdata('error_msg', "Permission Denied.");
            redirect(base_url("fill_attendance"));
        }

        $this->load->view('project_attendance/fill_attendance_view', $data);
    }

	
    //Project Attendance ...
    public function addsaveupd_attendance() {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;

        if ($_REQUEST['assign_designation_onproj'] and $_REQUEST['attend_projid'] and $_REQUEST['attend_year'] and $_REQUEST['attend_month']) {
            $AssignfinalteamidArr = $_REQUEST['assign_designation_onproj'];
            $projID = $_REQUEST['attend_projid'];
            $year = $_REQUEST['attend_year'];
            $month = $_REQUEST['attend_month'];

            foreach ($AssignfinalteamidArr as $KEYy => $designID) {
                $WhereArr = ['year' => $year, 'month' => $month, 'is_active' => '1', 'project_id' => $projID, 'designation_id' => $designID];
                $numRows = $this->db->where($WhereArr)->from("$db2.timeshet_fill")->count_all_results();

                if ($numRows < 1) {
                    //Single Row Insert into timeshet_fill Table ..
                    $insertArr = array("designation_id" => $designID, "emp_id" => ($_REQUEST['emplid_act'][$KEYy]) ? $_REQUEST['emplid_act'][$KEYy] : "", "project_id" => $projID, "fill_date" => date("Y-m-d"), "year" => $year, "month" => $month,
                        "`1`" => ($_REQUEST['atten_' . $designID . '_1']) ? $_REQUEST['atten_' . $designID . '_1'] : "",
                        "`2`" => ($_REQUEST['atten_' . $designID . '_2']) ? $_REQUEST['atten_' . $designID . '_2'] : "",
                        "`3`" => ($_REQUEST['atten_' . $designID . '_3']) ? $_REQUEST['atten_' . $designID . '_3'] : "",
                        "`4`" => $_REQUEST['atten_' . $designID . '_4'] ? $_REQUEST['atten_' . $designID . '_4'] : "",
                        "`5`" => $_REQUEST['atten_' . $designID . '_5'] ? $_REQUEST['atten_' . $designID . '_5'] : "",
                        "`6`" => $_REQUEST['atten_' . $designID . '_6'] ? $_REQUEST['atten_' . $designID . '_6'] : "",
                        "`7`" => $_REQUEST['atten_' . $designID . '_7'] ? $_REQUEST['atten_' . $designID . '_7'] : "",
                        "`8`" => $_REQUEST['atten_' . $designID . '_8'] ? $_REQUEST['atten_' . $designID . '_8'] : "",
                        "`9`" => $_REQUEST['atten_' . $designID . '_9'] ? $_REQUEST['atten_' . $designID . '_9'] : "",
                        "`10`" => $_REQUEST['atten_' . $designID . '_10'] ? $_REQUEST['atten_' . $designID . '_10'] : "",
                        "`11`" => $_REQUEST['atten_' . $designID . '_11'] ? $_REQUEST['atten_' . $designID . '_11'] : "",
                        "`12`" => $_REQUEST['atten_' . $designID . '_12'] ? $_REQUEST['atten_' . $designID . '_12'] : "",
                        "`13`" => $_REQUEST['atten_' . $designID . '_13'] ? $_REQUEST['atten_' . $designID . '_13'] : "",
                        "`14`" => $_REQUEST['atten_' . $designID . '_14'] ? $_REQUEST['atten_' . $designID . '_14'] : "",
                        "`15`" => $_REQUEST['atten_' . $designID . '_15'] ? $_REQUEST['atten_' . $designID . '_15'] : "",
                        "`16`" => $_REQUEST['atten_' . $designID . '_16'] ? $_REQUEST['atten_' . $designID . '_16'] : "",
                        "`17`" => $_REQUEST['atten_' . $designID . '_17'] ? $_REQUEST['atten_' . $designID . '_17'] : "",
                        "`18`" => $_REQUEST['atten_' . $designID . '_18'] ? $_REQUEST['atten_' . $designID . '_18'] : "",
                        "`19`" => $_REQUEST['atten_' . $designID . '_19'] ? $_REQUEST['atten_' . $designID . '_19'] : "",
                        "`20`" => $_REQUEST['atten_' . $designID . '_20'] ? $_REQUEST['atten_' . $designID . '_20'] : "",
                        "`21`" => $_REQUEST['atten_' . $designID . '_21'] ? $_REQUEST['atten_' . $designID . '_21'] : "",
                        "`22`" => $_REQUEST['atten_' . $designID . '_22'] ? $_REQUEST['atten_' . $designID . '_22'] : "",
                        "`23`" => $_REQUEST['atten_' . $designID . '_23'] ? $_REQUEST['atten_' . $designID . '_23'] : "",
                        "`24`" => $_REQUEST['atten_' . $designID . '_24'] ? $_REQUEST['atten_' . $designID . '_24'] : "",
                        "`25`" => $_REQUEST['atten_' . $designID . '_25'] ? $_REQUEST['atten_' . $designID . '_25'] : "",
                        "`26`" => $_REQUEST['atten_' . $designID . '_26'] ? $_REQUEST['atten_' . $designID . '_26'] : "",
                        "`27`" => $_REQUEST['atten_' . $designID . '_27'] ? $_REQUEST['atten_' . $designID . '_27'] : "",
                        "`28`" => $_REQUEST['atten_' . $designID . '_28'] ? $_REQUEST['atten_' . $designID . '_28'] : "",
                        "`29`" => $_REQUEST['atten_' . $designID . '_29'] ? $_REQUEST['atten_' . $designID . '_29'] : "",
                        "`30`" => $_REQUEST['atten_' . $designID . '_30'] ? $_REQUEST['atten_' . $designID . '_30'] : "",
                        "`31`" => $_REQUEST['atten_' . $designID . '_31'] ? $_REQUEST['atten_' . $designID . '_31'] : "",
                        "entryby" => $this->session->userdata('loginid'),
                        "created" => date("Y-m-d"));
                    $this->db->insert("$db2.timeshet_fill", $insertArr);
                } else {
                    //Update Record...
                    $UpdateArr = array("`1`" => $_REQUEST['atten_' . $designID . '_1'], "`2`" => $_REQUEST['atten_' . $designID . '_2'], "`3`" => $_REQUEST['atten_' . $designID . '_3'], "`4`" => $_REQUEST['atten_' . $designID . '_4'], "`5`" => $_REQUEST['atten_' . $designID . '_5'], "`6`" => $_REQUEST['atten_' . $designID . '_6'], "`7`" => $_REQUEST['atten_' . $designID . '_7'], "`8`" => $_REQUEST['atten_' . $designID . '_8'], "`9`" => $_REQUEST['atten_' . $designID . '_9'], "`10`" => $_REQUEST['atten_' . $designID . '_10'], "`11`" => $_REQUEST['atten_' . $designID . '_11'], "`12`" => $_REQUEST['atten_' . $designID . '_12'], "`13`" => $_REQUEST['atten_' . $designID . '_13'], "`14`" => $_REQUEST['atten_' . $designID . '_14'], "`15`" => $_REQUEST['atten_' . $designID . '_15'], "`16`" => $_REQUEST['atten_' . $designID . '_16'], "`17`" => $_REQUEST['atten_' . $designID . '_17'], "`18`" => $_REQUEST['atten_' . $designID . '_18'], "`19`" => $_REQUEST['atten_' . $designID . '_19'], "`20`" => $_REQUEST['atten_' . $designID . '_20'], "`21`" => $_REQUEST['atten_' . $designID . '_21'], "`22`" => $_REQUEST['atten_' . $designID . '_22'], "`23`" => $_REQUEST['atten_' . $designID . '_23'], "`24`" => $_REQUEST['atten_' . $designID . '_24'], "`25`" => $_REQUEST['atten_' . $designID . '_25'], "`26`" => $_REQUEST['atten_' . $designID . '_26'], "`27`" => $_REQUEST['atten_' . $designID . '_27'], "`28`" => $_REQUEST['atten_' . $designID . '_28'], "`29`" => $_REQUEST['atten_' . $designID . '_29'], "`30`" => $_REQUEST['atten_' . $designID . '_30'], "`31`" => $_REQUEST['atten_' . $designID . '_31'], 'modified' => date('Y-m-d'));
                    $this->db->where($WhereArr);
                    $this->db->update("$db2.timeshet_fill", $UpdateArr);
                }
            }
            $this->session->set_flashdata('msg', "Attendance Record Details Submitted Successfully.");
        }
        redirect(base_url("fill_attendance_project/" . $projID));
    }

}
