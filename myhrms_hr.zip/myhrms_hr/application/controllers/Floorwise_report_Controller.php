<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Floorwise_report_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Floorwise_report_model');
        $this->load->library('form_validation');
        $this->load->helper('common_helper');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function floorwise_report_data() {
        $title = "Floor Emp list";
        $this->load->view("floor_wise_emp_report/floor_wise_report_view", compact('title'));
    }

    public function ajax_floorwise_report_data() {
        $list = array("-1" => "-1", "0" => "0", "1" => "1", "2" => "2", "3" => "3", "4" => "4", "5" => "5", "6" => "6", "7" => "7");
        $data = array();
        $no = $_POST['start'];
        $recData = array();
        $rowTotal = 0;
        $rowTotal2 = 0;
        $colTotal1 = 0;
        $colTotal2 = 0;
        $colTotal3 = 0;
        $colTotal4 = 0;
        $colTotal5 = 0;
        $colTotal6 = 0;
        $colTotal7 = 0;
        foreach ($list as $kkeY => $rOws) {
            $no++;
            $GroupNumA = $this->countemponfloor($kkeY+2, "8");
            $GroupNumB = $this->countemponfloor($kkeY+2, "9");
            $GroupNumC = $this->countemponfloor($kkeY+2, "10");
            $GroupNumD = $this->countemponfloor($kkeY+2, "11");
            $GroupNumE = $this->countemponfloor($kkeY+2, "12");
            $GroupNumF = $this->countemponfloor($kkeY+2, "13");
            $rowTotal = $GroupNumA + $GroupNumB + $GroupNumC + $GroupNumD + $GroupNumE + $GroupNumF;
            $row = array();
            $row[] = $no;
            $row[] = $rOws;
            $row[] = $GroupNumA;
            $row[] = $GroupNumB;
            $row[] = $GroupNumC;
            $row[] = $GroupNumD;
            $row[] = $GroupNumE;
            $row[] = $GroupNumF;
            $row[] = '<b>' . $rowTotal . '</b>';
            $data[] = $row;
        }
        foreach ($list as $kkeY => $rOws) {
            $no++;
            $GroupNumA = $this->countemponfloor($kkeY+2, "8");
            $GroupNumB = $this->countemponfloor($kkeY+2, "9");
            $GroupNumC = $this->countemponfloor($kkeY+2, "10");
            $GroupNumD = $this->countemponfloor($kkeY+2, "11");
            $GroupNumE = $this->countemponfloor($kkeY+2, "12");
            $GroupNumF = $this->countemponfloor($kkeY+2, "13");
            $rowTotal2 = $GroupNumA + $GroupNumB + $GroupNumC + $GroupNumD + $GroupNumE + $GroupNumF;
            $colTotal1 += $GroupNumA;
            $colTotal2 += $GroupNumB;
            $colTotal3 += $GroupNumC;
            $colTotal4 += $GroupNumD;
            $colTotal5 += $GroupNumE;
            $colTotal6 += $GroupNumF;
            $colTotal7 += $rowTotal2;
        }
        $row = array();
        $row[] = '8';
        $row[] = '-';
        $row[] = "<b>" . $colTotal1 . "</b>";
        $row[] = "<b>" . $colTotal2 . "</b>";
        $row[] = "<b>" . $colTotal3 . "</b>";
        $row[] = "<b>" . $colTotal4 . "</b>";
        $row[] = "<b>" . $colTotal5 . "</b>";
        $row[] = "<b>" . $colTotal6 . "</b>";
        $row[] = "<b>" . $colTotal7 . "</b>";
        $data[] = $row;
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => count($list),
            "recordsFiltered" => count($list),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function countemponfloor($floorId, $groupID) {
        $this->db->select("b.user_id");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->where(array("a.isactive" => "1", "b.status" => "1", "b.floor_number" => $floorId, "a.jobtitle_id" => $groupID));
        $this->db->group_by("a.user_id");
        $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }

}
