<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Menpower_report_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Menpower_report_model');
        $this->load->library('form_validation');
        $this->load->helper('common_helper');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function gradewise_menpower_report() {
        $title = "Floor Emp list";
        $this->load->view("men_power_report/menpower_report_view", compact('title', 'from_date', 'to_date'));
    }

    /* public function ajax_menpower_report_data() {
      $list = array("8" => "A","9" => "B", "10" => "C", "11" => "D", "12" => "E", "13" => "F");
      $data = array();
      $no = $_POST['start'];
      $recData = array();
      $colTotal1 = 0;
      $colTotal2 = 0;
      $colTotal3 = 0;
      $colTotal4 = 0;
      foreach ($list as $kkeY => $rOws) {
      $no++;
      $left = $this->countmenpower($kkeY);
      $join = $this->countmenpower_joined($kkeY);
      $open_bal = $this->countmenpower_open_bal($kkeY);
      $close_bal = $this->countmenpower_close_bal($kkeY);
      $cls = $open_bal-$left+$join;
      // $rowTotal = $GroupNumA+$GroupNumB+$GroupNumC+$GroupNumD+$GroupNumE+$GroupNumF;
      $row = array();
      $row[] = $no;
      $row[] = $rOws;
      $row[] = $open_bal;
      $row[] = $join;
      $row[] = $left;
      $row[] = $cls;
      $data[] = $row;
      }

      foreach ($list as $kkeY => $rOws) {
      $no++;
      $left = $this->countmenpower($kkeY);
      $join = $this->countmenpower_joined($kkeY);
      $open_bal = $this->countmenpower_open_bal($kkeY);
      $close_bal = $this->countmenpower_close_bal($kkeY);
      $cls = $open_bal-$left+$join;
      // $rowTotal = $GroupNumA+$GroupNumB+$GroupNumC+$GroupNumD+$GroupNumE+$GroupNumF;
      $colTotal1 += $open_bal;
      $colTotal2 += $join;
      $colTotal3 += $left;
      $colTotal4 += $close_bal;

      }
      $row = array();
      $row[] = '7';
      $row[] = '<b>Total</b>';
      $row[] = "<b>".$colTotal1."</b>";
      $row[] = "<b>".$colTotal2."</b>";
      $row[] = "<b>".$colTotal3."</b>";
      $row[] = "<b>".$colTotal4."</b>";
      $data[] = $row;
      $output = array(
      "draw" => @$_POST['draw'],
      "recordsTotal" => count($list),
      "recordsFiltered" => count($list),
      "data" => $data,
      );
      echo json_encode($output);
      }


      public function countmenpower($groupID) {
      $st_date= date("Y-n-j", strtotime("first day of previous month"));
      $end_date= date("Y-n-j", strtotime("last day of previous month"));
      $this->db->select('a.*');
      $this->db->from('main_users as a');
      $this->db->where_not_in('b.isactive','1');
      $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
      $this->db->where('date_of_leaving >=', $st_date);
      $this->db->where('date_of_leaving <=', $end_date);
      $this->db->where(array("b.jobtitle_id" => $groupID));
      $this->db->group_by('b.user_id');
      // $recArr = $this->db->count_all_results();
      $recArr = $this->db->get()->num_rows();
      return ($recArr) ? $recArr : '0';
      }

      public function countmenpower_joined($groupID) {
      $st_date= date("Y-n-j", strtotime("first day of previous month"));
      $end_date= date("Y-n-j", strtotime("last day of previous month"));
      $this->db->select('a.*');
      $this->db->from('main_users as a');
      $this->db->where('b.isactive','1');
      $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
      $this->db->where('date_of_joining >=', $st_date);
      $this->db->where('date_of_joining <=', $end_date);
      $this->db->where(array("b.jobtitle_id" => $groupID));
      $this->db->group_by('b.user_id');
      // $recArr = $this->db->count_all_results();
      $recArr = $this->db->get()->num_rows();
      return ($recArr) ? $recArr : '0';
      }

      public function countmenpower_open_bal($groupID) {
      $st_date= date("Y-n-j", strtotime("first day of previous month"));
      $end_date= date("Y-n-j", strtotime("last day of previous month"));
      $this->db->select('a.*');
      $this->db->from('main_users as a');
      $this->db->where('b.isactive','1');
      $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
      $this->db->where('date_of_joining <', $st_date);
      // $this->db->where('date_of_joining <=', $end_date);
      $this->db->where(array("b.jobtitle_id" => $groupID));
      $this->db->group_by('b.user_id');
      // $recArr = $this->db->count_all_results();
      $recArr = $this->db->get()->num_rows();
      return ($recArr) ? $recArr : '0';
      }

      public function countmenpower_close_bal($groupID) {
      $st_date= date("Y-n-j", strtotime("first day of previous month"));
      $end_date= date("Y-n-j", strtotime("last day of previous month"));
      $this->db->select('a.*');
      $this->db->from('main_users as a');
      $this->db->where('b.isactive','1');
      $this->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
      $this->db->where('date_of_joining <', $end_date);
      // $this->db->where('date_of_leaving <', $end_date);
      $this->db->where(array("b.jobtitle_id" => $groupID));
      $this->db->group_by('b.user_id');
      // $recArr = $this->db->count_all_results();
      $recArr = $this->db->get()->num_rows();
      return ($recArr) ? $recArr : '0';
      } */
}
