<?php

defined('BASEPATH') OR exit('No direct script access allowed');


use PhpOffice\PhpSpreadsheet\Spreadsheet;
//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

use PhpOffice\PhpSpreadsheet\Reader\Xls;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Writer;
use PhpOffice\PhpSpreadsheet\IOFactory;

class SalStructureController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('PHPExcel');
        $this->load->library('excel');
        $this->load->model('All_employee_list_appr_Model');
        $this->load->model('All_employee_list_project_Model');
        $this->load->library('form_validation');
        if ($this->session->userdata('loginid') == "") {
            redirect(base_url(""));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
            // redirect(base_url("userdashboard"));
        } else {
            $this->logout();
            redirect('../../../myhrms', 'refresh');
        }
    }


    public function sal_structure() {
        // echo "testijsidgjijdsgf"; die;
        $this->form_validation->set_rules('user_id', 'User', 'required');
        $this->form_validation->set_rules('ctc', 'CTC', 'required');
        // echo $this->input->post('user_id');
        $userDetails = $this->All_employee_list_appr_Model->getDataByUserId($this->input->post('user_id'));
// echo "<pre>"; print_r($userDetails); die;
        if ($this->form_validation->run() == FALSE) {
            $data['title']='Salary Structure';
            $this->load->view("salary_structure/employee_list_appr",$data);
        }
         else {
             if($this->input->post('redirect_aft_upd') == 1 && $this->input->post('user_id'))
            {
                    $user_id = $userDetails->user_id;
                    // $user_id = $this->uri->segment(2);
                    // echo $user_id; die;
                    $salArrToObj = $this->All_employee_list_appr_Model->getRowCountSalaryAnexture($user_id);
                    $userDetails = $this->All_employee_list_appr_Model->getDataByUserId($user_id);
                    $net_sal = $salArrToObj->gross + ($salArrToObj->emp_pf + $salArrToObj->emp_vpf + $salArrToObj->emp_esi);
                    $salArrToObj = (object) array_merge( (array)$salArrToObj, array( 'user_id' => $user_id ) );
                    
                    $reqArr = $this->input->post();
                    if($this->input->post()){
                        $updateArr = array(
                            "basic_sal" => $reqArr['basic_salary'],
                            "hra" => $reqArr['hra'],
                            "edu_allow" => $reqArr['edu_allow'],
                            "tele_allow" => $reqArr['tele_allow'],
                            "bonus_adv" => $reqArr['bonus_adv'],
                            "gadget_allow" => $reqArr['gadget_allow'],
                            "special_allow" => $reqArr['special_allow'],
                            "gross" => $reqArr['gross'],
                            "employer_gratuity" => $reqArr['employer_gratuity'],
                            "gpai" => $reqArr['gpai'],
                            "mediclaim" => $reqArr['mediclaim'],
                            "monthly_ctc" => $reqArr['monthly_ctc'],
                            "ann_bonus" => $reqArr['ann_bonus'],
                            "total_ctc" => $reqArr['total_ctc'],
                        );
                        
        
                        // echo "<pre>"; print_r($updateArr);
                        $this->db->where('user_id',$user_id);
                        $resp = $this->db->update('temp_sal_structure',$updateArr);
                        //    echo $user_id.'__'.$resp; die;
                        if($resp){
                            // $data['reloadFlag'] = 1;
                            $salArrToObj = $this->All_employee_list_appr_Model->getRowCountSalaryAnexture($user_id);
                            $userDetails = $this->All_employee_list_appr_Model->getDataByUserId($user_id);
                            $data['salArrToObj'] = $salArrToObj;
                            $data['userDetails'] = $userDetails;
                            // echo "<pre>"; print_r($data); die;
                            // $data['salArr'] = $salArrToObj;
                            $this->load->view("salary_structure/show_salary_structure_view",$data);
                        }else{
                            $this->session->set_flashdata('error_msg',"Some thing went wrong. Please try to update again");
                            redirect(base_url('salary_structure_edit'));
                        }
                }    
                
            }
            else{
                // echo "test4"; die;
                // echo "<pre>"; print_r($this->input->post());
                $gradeArr = array('1'=>'A','2'=>'B','3'=>'C','4'=>'D','5'=>'E','6'=>'F');
                $userDetails = $this->All_employee_list_appr_Model->getDataByUserId($this->input->post('user_id'));
                // echo $userDetails->on_project;
                // echo rtrim($userDetails->on_project, ","); die;
                // echo "<pre>"; print_r($userDetails); die;
                $data['gpaiTeleFixAmt'] = $this->All_employee_list_appr_Model->getGpaiTeleAmt(array_search ($userDetails->jobtitle_name, $gradeArr));
                $data['mediclaim_prem'] = $this->All_employee_list_appr_Model->getMediclaimPremiumAmt();

                $pf_applicable = $this->input->post('pf_applicable');
                $vpf_applicable = $this->input->post('vpf_applicable');
                $metro_non = $this->input->post('metro_non_metro');
                $effective_date = $this->input->post('effective_date');
                $gratuity_applicable = 1;

                $esi_applicable = 1;
                $mediclaim_applicable = 0;
                $edu_allow = 200;
                $ann_bonus = 0;
                $ctc = $this->input->post('ctc');
                $tax_fig = 1000;
                // echo "tetrstjsktjj"; die;
                $dataArr = $this->reCalculateSalary($no=1,$data['gpaiTeleFixAmt'],$data['mediclaim_prem'],$ctc, $tax_fig,$userDetails, $metro_non, $pf_applicable, $edu_allow, $esi_applicable,$mediclaim_applicable, $gratuity_applicable, $vpf_applicable );
    // echo "d<pre>"; print_r($dataArr); die;
                $total_ctc = $dataArr['ann_bonus'] + $dataArr['monthly_ctc'];
                $net_sal = $dataArr['gross'] + ($dataArr['emp_pf'] + $dataArr['emp_vpf'] + $dataArr['emp_esi']);
                $ctc_in_words = $this->convert_number($total_ctc);
                $dataArr['gadget_allow'] = $this->getGadgetAllowance($dataArr['gross'], $total_ctc);
                // echo $dataArr['gadget_allow']; die;
                if($total_ctc > 125000){
                    $dataArr['special_allow'] = round($dataArr['gross'] - ($dataArr['basic_sal'] + $dataArr['hra'] + $dataArr['edu_allow'] + $dataArr['tele_allow'] + $dataArr['bonus_adv'] + $dataArr['gadget_allow']) );
                }
                $salArr = array('metro_non' => $metro_non,
                    'ctc'=> $ctc,
                    'mediclaim_applicable'=>$mediclaim_applicable,
                    'pf_applicable'=>$pf_applicable,
                    'vpf_applicable'=>$vpf_applicable,
                    'esi_applicable'=>$esi_applicable,
                    'gratuity_applicable'=>$gratuity_applicable,
                    'annual_bonus_applicable'=>$dataArr['annual_bonus_applicable'],
                    'ann_bonus' => $ann_bonus,
                    'edu_allow' => $edu_allow,
                    "net_sal" => $net_sal,
                    "total_ctc" => $total_ctc,
                    "effective_date" => $effective_date,
                    "ctc_in_words" => $ctc_in_words,
                    // "gadget_allow" => $gadget_allow,
                );

                $finalArr = array_merge($salArr,$dataArr);
                $data['userDetails']  = $userDetails;
                $data['salArrToObj'] = $this->ToObject($finalArr);

                // echo "dd<pre>";
                // // print_r($gadget_allow); die;
                // print_r($this->ToObject($finalArr));
                // die;
                $addAnexture = $this->All_employee_list_appr_Model->addSalaryAnextureDataTemp($userDetails,$this->ToObject($finalArr));
                $data['fld_id'] = $addAnexture; 
                // echo $addAnexture; die;
                if($addAnexture){
                        $this->session->set_flashdata('success_msg', 'Please Check Anexture before download.');
                        // $data['title'] = "Salary Structure";
                        $salArrToObj = $this->All_employee_list_appr_Model->getRowOfSalaryAnextureByFldId($data['fld_id']);
                        $data['salArrToObj'] = $salArrToObj;
                        // echo "<pre>"; print_r($salArrToObj); die;
                        echo $this->load->view("salary_structure/show_salary_structure_view",$data); die;
                    }else{
                        // echo "inside else"; die;
                        $this->session->set_flashdata('error_msg', 'Something Went Wrong.');
                        redirect(base_url('sal_structure'));
                }
            }
        }
    }



    public function reCalculateSalary( $no,$gpaiTeleFixAmt, $mediclaim_prem,$ctc, $tax_fig,$userDetails, $metro_non, $pf_applicable, $edu_allow, $esi_applicable,$mediclaim_applicable, $gratuity_applicable ) {
        $vpf_applicable = $this->input->post('vpf_applicable'); 
        
        $yearCtc = $ctc *12;
        $annual_bonus_applicable = 0;
        $annual_bonus = 0;
        $gpai = $gpaiTeleFixAmt->gpai;
        $tele_allow = $gpaiTeleFixAmt->telephone;

        $gross = $this->getGrossSalary($ctc, $tax_fig, $userDetails->businessunit_id, $annual_bonus, 0);
        $basic_sal = $this->getBasicSalary($gross);
        $hra = $this->getHraAmount($metro_non, $basic_sal);
        $bonus_adv = $this->getBonusAmount($gross, $basic_sal);
        
            if($gross > 21000){
                $esi_applicable = 0;
            }

            if($esi_applicable){
                $mediclaim_applicable = 0;
                $mediclaim_amount = 0;
            }else{
                $mediclaim_applicable = 1;
                $mediclaim_amount =$mediclaim_prem->self;
            }
            
            $special_allow = round($gross - ($basic_sal + $hra + $edu_allow + $tele_allow + $bonus_adv) );

            $employer_esi = $this->getemployerEsiAmount($esi_applicable, $gross);
            $gratuity_amount = $this->getGratuityAmount($gratuity_applicable, $basic_sal);
            $emp_esi = $this->getEmpEsiAmount($esi_applicable, $gross);
            $employer_pf = $this->getPfAmount($pf_applicable,$basic_sal ,$edu_allow ,$tele_allow ,$special_allow);
            $emp_vpf = $this->getEmpVPfAmount($vpf_applicable, $basic_sal ,$edu_allow ,$tele_allow ,$special_allow);
            $emp_pf = $this->getEmpPfAmount($pf_applicable, $basic_sal ,$edu_allow ,$tele_allow ,$special_allow);

            $deduction = $employer_pf + $employer_esi + $gratuity_amount + $gpai + $mediclaim_amount;
            $monthly_ctc = $gross+$deduction;
            
            if($userDetails->jobtitle_name != 'F' && $userDetails->businessunit_id != 3){
                $annual_bonus = round(( ( $ctc - $tax_fig ) / 13 ), 0);
                $annual_bonus_applicable = 1;
            }
            
            $totalCtc = $annual_bonus + $monthly_ctc;
                        
            $returnArr = array('gross' => $gross,'basic_sal' => $basic_sal,'hra' => $hra,'bonus_adv' => $bonus_adv,'employer_pf' => $employer_pf,'emp_pf' => $emp_pf,
            'gpai' => $gpai,'tele_allow' => $tele_allow, 'esi_applicable' => $esi_applicable,'mediclaim_applicable' => $mediclaim_applicable,
            'mediclaim' => $mediclaim_amount,'employer_esi' => $employer_esi,'employer_gratuity' => $gratuity_amount,
            'emp_vpf' => $emp_vpf,'emp_esi' => $emp_esi,'special_allow' => $special_allow,'monthly_ctc' => $monthly_ctc,'deduction' => $deduction,
            'ann_bonus' => $annual_bonus,'annual_bonus_applicable' => $annual_bonus_applicable,'deduction' => $deduction,'tax_fig' => $tax_fig,'edu_allow' => $edu_allow);

            if($tax_fig != $deduction){
                $tax_fig = $tax_fig - ($tax_fig - $deduction); 
                $fArr = $this->reCalculateSalary($no,$gpaiTeleFixAmt, $mediclaim_prem,$ctc, $tax_fig,$userDetails, $metro_non, $pf_applicable, $edu_allow, $esi_applicable,$mediclaim_applicable, $gratuity_applicable );
                return $fArr;
            }
            else {
                $returnArr = array('gross' => $gross,'basic_sal' => $basic_sal,'hra' => $hra,'bonus_adv' => $bonus_adv,'employer_pf' => $employer_pf,'emp_pf' => $emp_pf,
                'gpai' => $gpai,'tele_allow' => $tele_allow, 'esi_applicable' => $esi_applicable,'mediclaim_applicable' => $mediclaim_applicable,
                'mediclaim' => $mediclaim_amount,'employer_esi' => $employer_esi,'employer_gratuity' => $gratuity_amount,
                'emp_vpf' => $emp_vpf,'emp_esi' => $emp_esi,'special_allow' => $special_allow,'monthly_ctc' => $monthly_ctc,'deduction' => $deduction,
                'ann_bonus' => $annual_bonus,'annual_bonus_applicable' => $annual_bonus_applicable,'deduction' => $deduction,'tax_fig' => $tax_fig,'edu_allow' => $edu_allow);
                 
            }
            return $returnArr;
    }

    public function ToObject($Array) {
        $object = new stdClass();
          foreach ($Array as $key => $value) {
            if (is_array($value)) {
                $value = $this->ToObject($value);
            }
            $object->$key = $value;
          }
        return $object;
    }

    public function salary_structure_edit()
	{
        $user_id = $this->uri->segment(2);
        // echo $user_id; die;
        $salArrToObj = $this->All_employee_list_appr_Model->getRowCountSalaryAnexture($user_id);
        $userDetails = $this->All_employee_list_appr_Model->getDataByUserId($user_id);
        $net_sal = $salArrToObj->gross + ($salArrToObj->emp_pf + $salArrToObj->emp_vpf + $salArrToObj->emp_esi);
        $salArrToObj = (object) array_merge( (array)$salArrToObj, array( 'user_id' => $user_id ) );
        
        // $data['title'] = 'Salary Structure ';

        // // echo "dd<pre>"; print_r($salArrToObj); die;
        // $reqArr = $this->input->post();
        // if($this->input->post()){
        //     // echo "<pre>"; print_r($reqArr); die;
        //     $updateArr = array(
        //         "basic_sal" => $reqArr['basic_salary'],
        //         "hra" => $reqArr['hra'],
        //         "edu_allow" => $reqArr['edu_allow'],
        //         "tele_allow" => $reqArr['tele_allow'],
        //         "bonus_adv" => $reqArr['bonus_adv'],
        //         "gadget_allow" => $reqArr['gadget_allow'],
        //         "special_allow" => $reqArr['special_allow'],
        //         "gross" => $reqArr['gross'],
        //         "employer_gratuity" => $reqArr['employer_gratuity'],
        //         "gpai" => $reqArr['gpai'],
        //         "mediclaim" => $reqArr['mediclaim'],
        //         "monthly_ctc" => $reqArr['monthly_ctc'],
        //         "ann_bonus" => $reqArr['ann_bonus'],
        //         "total_ctc" => $reqArr['total_ctc'],
        //     );
            

        //     // echo "<pre>"; print_r($updateArr);
        //     $this->db->where('user_id',$user_id);
        //     $resp = $this->db->update('temp_sal_structure',$updateArr);
        //     //    echo $res; die;
        //     if($resp){
        //         $data['reloadFlag'] = 1;
        //         $data['salArrToObj'] = $salArrToObj;
        //         $data['userDetails'] = $userDetails;
        //         redirect(base_url('sal_structure'));
        //     }else{
        //         $this->session->set_flashdata('error_msg',"Some thing went wrong. Please try to update again");
        //         redirect(base_url('salary_structure_edit'));
        //     }
            
        // }
        $this->load->view('salary_structure/salary_structure_edit_view', compact('salArrToObj'), true);
	}

    public function redirectAfterUpdate() {

    }
    
    public function download_sal_anexture_pdf()
	{
        $user_id = $this->uri->segment(2);
        $salArrToObj = $this->All_employee_list_appr_Model->getRowCountSalaryAnexture($user_id);
        $userDetails = $this->All_employee_list_appr_Model->getDataByUserId($user_id);
        $net_sal = $salArrToObj->gross + ($salArrToObj->emp_pf + $salArrToObj->emp_vpf + $salArrToObj->emp_esi);
        $salArrToObj = (object) array_merge( (array)$salArrToObj, array( 'net_sal' => '1234' ) );
        // echo "<pre>"; print_r($salArrToObj); die;
        $this->load->view('salary_structure/sal_structure_pdf', compact('salArrToObj','userDetails'), true);
        // echo "dd<pre>"; print_r($salArrToObj); die;
        // echo $salArrToObj->ctc; die;
        $this->load->library('mp_pdf');
        $data['title'] = 'Employee Info';

        // echo "dd<pre>"; print_r($referencesDetails); die;
        $po_view = $this->load->view('salary_structure/sal_structure_pdf', compact('salArrToObj'), true);

        $pdfFilePath = "salary.pdf";
        $this->mp_pdf->pdf->mirrorMargins = 1;
        $this->mp_pdf->pdf->shrink_tables_to_fit = 1;
        $this->mp_pdf->pdf->SetTitle('Salary');
        ob_clean();
        ob_flush();
        $this->mp_pdf->pdf->WriteHTML($po_view);
        $this->mp_pdf->pdf->Output($pdfFilePath, "D");
        ob_end_flush();
        ob_end_clean();
	}

    //Gross Salary Calculation
    public function getGrossSalary($ctc, $tax_fig, $company_val, $annual_bonus, $department) {
        if($company_val != 3){
            return round((($ctc*12)-($tax_fig*12))/13);
        }else {
            if($department == 1){
                return round((($ctc*12)-($tax_fig*12))/12)-$annual_bonus;    
            } else {
                return round((($ctc*12)-($tax_fig*12))/12);
            }
        }
    }

    //Gratuity Amount Calculation
    public function getGratuityAmount($gratuity_applicable, $basic_sal) {
        if($gratuity_applicable == 1){
            $gratuity_amount = round($basic_sal * (4.81 /100));
        }else {
            $gratuity_amount = 0;
        }
        return $gratuity_amount;
    }

    //Employee ESI Amount Calculation
    public function getEmpEsiAmount($esi_applicable, $gross) {
        if($esi_applicable == 1){
            $esi_amount = round($gross * (0.75 /100));
        }else {
            $esi_amount = 0;
        }
        return $esi_amount;
    }
    
    //Employers ESI Amount Calculation
    public function getemployerEsiAmount($esi_applicable, $gross) {
        if($esi_applicable == 1){
            $esi_amount = round($gross * (3.25 /100));
        }else {
            $esi_amount = 0;
        }
        return $esi_amount;
    }

    //Employee VPF Amount Calculation
    public function getEmpVPfAmount($pf_applicable, $basic_sal ,$edu_allow ,$tele_allow ,$special_allow) {
        if($pf_applicable == 1 && $basic_sal < 15001){
            $pf_enable_for = $basic_sal + $edu_allow + $tele_allow + $special_allow;
            $emp_pf = ($pf_enable_for * (12 / 100));
            $emp_pf_min = min($emp_pf,1800);
        }else if($pf_applicable == 1 && $basic_sal > 15000){
            $emp_pf_min = ($basic_sal * (12 / 100));
        }
        return round($emp_pf_min);
    }

    //Employers PF Amount Calculation
     public function getEmpPfAmount($pf_applicable, $basic_sal ,$edu_allow ,$tele_allow ,$special_allow) {
        // if($pf_applicable == 1 && $basic_sal < 15001){
        //     $pf_enable_for = $basic_sal + $edu_allow + $tele_allow + $special_allow;
        //     $emp_pf = ($pf_enable_for * (12 / 100));
        //     $emp_pf_min = min($emp_pf,1800);
        // }else if($pf_applicable == 1 && $basic_sal > 15000){
        //     $emp_pf = ($basic_sal * (12 / 100));
        // }
        if($pf_applicable == 1 && $basic_sal < 15001){
            $pf_enable_for = $basic_sal + $edu_allow + $tele_allow + $special_allow;
            $emp_pf = ($pf_enable_for * (12 / 100));
            // echo $emp_pf; die;
            $emp_pf_min = min($emp_pf,1800);
        }else if($pf_applicable == 1 && $basic_sal > 15000){
            $emp_pf = ($basic_sal * (12 / 100));
        }
        // echo $basic_sal.'__'.$emp_pf; die;
        return round($emp_pf);
    }

    //Employees PF Amount Calculation
     public function getPfAmount($pf_applicable, $basic_sal ,$edu_allow ,$tele_allow ,$special_allow) {
        if($pf_applicable == 1 && $basic_sal < 15001){
            $pf_enable_for = $basic_sal + $edu_allow + $tele_allow + $special_allow;
            $employeer_pf = ($pf_enable_for * (12 / 100));
        }else {
            if($pf_applicable == 1 && $basic_sal > 15000){
                $employeer_pf = 1800;
            }else{
                $employeer_pf = 0;
            }
        }
        return round($employeer_pf);
    }

    //Bonus Amount Calculation
    public function getBonusAmount($gross, $basic_sal) {
        if( $gross < 21001 ){
            if( $basic_sal > 7000){
                $bonus_adv = (7000 * (20 / 100));
            }else {
                $bonus_adv = ($basic_sal * (20 / 100));
            }
        }else {
            $bonus_adv = 0;
        }
        return round($bonus_adv);
    }

    //HRA Amount Calculation
    public function getHraAmount($metro_non, $basic_sal) {
        if($metro_non == 1){
            return round($basic_sal * (50 / 100));
        }else {
            return round($basic_sal * (40 / 100));
        }
    }

    //Basic Salary Amount Calculation
    public function getBasicSalary($gross){
        if($gross > 16450 && $gross < 50001){
            $basic_sal = 15050;
        }else{
            if($gross < 16450) {
                $basic_sal = ($gross * (52 / 100));
            }else {
                $basic_sal = ($gross * (30 / 100));
            }
        }
        return round($basic_sal);
    }


    public function getGadgetAllowance($gross, $totalCtc) {
        if($totalCtc < 125000) {
            $gadgetAllow = ($gross * (0 / 100));
        }else{
            $gross_percent = ($gross * (10 / 100));
            if($gross_percent > 16666 ) {
                $gadgetAllow = 16666;
            }else {
                $gadgetAllow = ($gross * (10 / 100));
            }
        }
        
        
        // if($gross > 124999 && $gross < 125000) {
        //     $gadgetAllow = 0;
        // }else{
        //     if($gross < 125000) {
        //         $gadgetAllow = ($gross * (0 / 100));
        //     }else {
        //         $gadgetAllow = ($gross * (10 / 100));
        //     }
        // }
        return round($gadgetAllow);
    }
    
    //convert obj to array
    function cvf_convert_object_to_array($data) {

	    if (is_object($data)) {
		$data = get_object_vars($data);
	    }

	    if (is_array($data)) {
		return array_map(__FUNCTION__, $data);
	    }
	    else {
		return $data;
	    }
	}


    public function emp_list()
    {
        $data['title'] = "Employee List : All";
        $data['Hr_EmpDetailsArr'] = $this->Hr_EmpDetailsArr();
        $this->load->view("salary_structure/employee_list_appr", $data);
    }

    public function emp_list_active()
    {
        $data['title'] = "Employee List : Active";
        $data['Hr_EmpDetailsArr'] = $this->Hr_EmpDetailsArr_active();
        $this->load->view("hrms_employee_list/employee_list_appr", $data);
    }

    public function emp_list_inactive()
    {
        $data['title'] = "Employee List : In Active";
        $data['Hr_EmpDetailsArr'] = $this->Hr_EmpDetailsArr_inactive();
        $this->load->view("hrms_employee_list/employee_list_appr", $data);
    }

    public function Hr_EmpDetailsArr()
    {
        $this->load->database();
        $this->db->select('main_employees_summary.*');
        $this->db->from("main_employees_summary");
        $res = $this->db->get()->result();
        return ($res) ? $res : "";
    }

    public function Hr_EmpDetailsArr_active()
    {
        $this->load->database();
        $this->db->select('main_employees_summary.*');
        $this->db->from("main_employees_summary");
        $this->db->where("isactive", "1");
        $res = $this->db->get()->result();
        return ($res) ? $res : "";
    }

    public function Hr_EmpDetailsArr_inactive()
    {
        $this->load->database();
        $this->db->select('main_employees_summary.*');
        $this->db->from("main_employees_summary");
        $status_array = array("0", "2", "3", "4");
        $this->db->where_in("isactive", $status_array);
        $res = $this->db->get()->result();
        return ($res) ? $res : "";
    }

    public function ajax_getsingleemp_id()
    {
        $emp_id = $_REQUEST['emp_id'];
        // print_r($emp_id);
        if ($emp_id) {
            $this->load->database();
            $this->db->select('*');
            $this->db->from('main_employees_summary');
            $this->db->where("id", $emp_id);
            $NewsRecord = $this->db->get()->row();
            echo json_encode($NewsRecord);
        }
    }

    //================Emp list for profile PDF =============================
    public function ajax_employee_list()
    {
        $list = $this->All_employee_list_appr_Model->get_datatables();
        // echo "<pre>"; print_r($list); die;
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $dataRow) {
            $image1 = '<img src="' . HOSTNAME . "public/uploads/profile/profile_pic.png" . '" class="rounded-circle avatar" alt="" style="height:50px; width:50px;">';
            if ($dataRow->profileimg) {
                $image = '';
                $image .= isset($dataRow->profileimg) ? $dataRow->profileimg : '';
                $imageCr = str_replace("index.php/", "", $image);
                $image1 = '<img src="' . EMPLPROFILE . $imageCr . '" class="rounded-circle avatar" alt="" style="height:50px; width:50px;">';
            }
            $employeeStatus = $dataRow->isactive ? $dataRow->isactive : '0';
            if ($employeeStatus == "0") {
                $empStatus =  "<span class='btn btn-danger'>Inactive</span>";
            } elseif ($employeeStatus == "1") {
                $empStatus =  "<span class='btn btn-success'>Active</span>";
            } elseif ($employeeStatus == "2") {
                $empStatus = "<span class='btn btn-danger'>Resigned</span>";
            } elseif ($employeeStatus == "3") {
                $empStatus = "<span class='btn btn-info'>Left</span>";
            } elseif ($employeeStatus == "4") {
                $empStatus = "<span class='btn btn-info'>Suspended</span>";
            }
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($dataRow->userfullname) ? $image1 . "&nbsp;&nbsp;" . $dataRow->userfullname . "" : '';
            $row[] = isset($dataRow->contactnumber) ? $dataRow->contactnumber : '';
            $row[] = isset($dataRow->emailaddress) ? $dataRow->emailaddress : '';
            $row[] = isset($dataRow->department_name) ? $dataRow->department_name : '';
            $row[] = isset($dataRow->businessunit_name) ? $dataRow->businessunit_name : '';
            $row[] = $empStatus;
            $row[] = "<a class='btn btn-info' href='javascript:void(0);' onclick='setUserIdForSalStructure(".$dataRow->user_id.")' data-toggle='modal' data-target='#ctcModal'>ADD CTC</a>";
            // $row[] = '<button type="button" class="btn btn-primary" onclick="setUserIdForSalStructure("'. $dataRow->id.'")" data-toggle="modal" data-target="#exampleModal">Add CTC</button>';
            //$row[] = "<span style='display:flex;flex-direction: row-reverse;'><a href='".base_url("pdfgenerate/".$dataRow->user_id)."' class='btn btn-info' target='_blank' title='Download'><i class='fa fa-download'></i></a>&ensp;<a href='".base_url("employee_edit/".$dataRow->user_id)."' class='btn btn-info' title='Edit'><i class='fa fa-edit'></i></a>&nbsp; <a href='" . base_url("excelgenerate/" . $dataRow->user_id) . "' class='btn btn-info' target='_blank' title='Download Excel'><i class='fa fa-file-excel-o'></i></a></span>"; -->
            // $row[] = "<input type='hidden' class='txt_csrfname' name='" . $this->security->get_csrf_token_name() . "' value='" . $this->security->get_csrf_hash() . "'><span style='display:flex;flex-direction: row-reverse;'><a href='" . base_url("pdfgenerate/" . $dataRow->user_id) . "' class='btn btn-info' target='_blank' title='Download'><i class='fa fa-download'></i></a>&ensp;<a href='" . base_url("employee_edit/" . $dataRow->user_id) . "' class='btn btn-info' title='Edit'><i class='fa fa-edit'></i></a>&nbsp;<span style='float:right'> <form method='POST' action='" . base_url('FetchEmp_ReportData') . "'><input type='hidden' name='Employe_id' value='" . $dataRow->user_id . "'> <button type='submit' class='btn btn-info'><i class='fa fa-file-excel-o'></i></button></form></span></span>";

            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->All_employee_list_appr_Model->count_all(),
            "recordsFiltered" => $this->All_employee_list_appr_Model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function convert_number($number) {
		if (($number < 0) || ($number > 999999999)) {
			throw new Exception("Number is out of range");
		}

		$Gn = floor($number / 1000000);
		/* Millions (giga) */
		$number -= $Gn * 1000000;
		$kn = floor($number / 1000);
		/* Thousands (kilo) */
		$number -= $kn * 1000;
		$Hn = floor($number / 100);
		/* Hundreds (hecto) */
		$number -= $Hn * 100;
		$Dn = floor($number / 10);
		/* Tens (deca) */
		$n = $number % 10;
		/* Ones */

		$res = "";

		if ($Gn) {
			$res .= $this->convert_number($Gn) .  "Million";
		}

		if ($kn) {
			$res .= (empty($res) ? "" : " ") .$this->convert_number($kn) . " Thousand";
		}

		if ($Hn) {
			$res .= (empty($res) ? "" : " ") .$this->convert_number($Hn) . " Hundred";
		}

		$ones = array("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen", "Nineteen");
		$tens = array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", "Seventy", "Eigthy", "Ninety");

		if ($Dn || $n) {
			if (!empty($res)) {
				$res .= " and ";
			}

			if ($Dn < 2) {
				$res .= $ones[$Dn * 10 + $n];
			} else {
				$res .= $tens[$Dn];

				if ($n) {
					$res .= "-" . $ones[$n];
				}
			}
		}

		if (empty($res)) {
			$res = "zero";
		}

		return $res;
	}

    public function salAnexFixedAmt() {
        // if ($this->form_validation->run() == FALSE) {
        if (!$_REQUEST) {
            $data['gpaiFixedAmt'] = $this->All_employee_list_appr_Model->getGpaiTeleAmount();
            $data['mediPremFixedAmt'] = $this->All_employee_list_appr_Model->getMediclaimPremiumAmt();
            $data['title']='Salary Structure';
            $this->load->view("salary_structure/update__sal_tax_view",$data);
        }
        else {
            // echo "<pre>"; print_r($this->input->post()); die;
            if($this->input->post('mediclaim_submit') == 'mediclaim_submit'){

                // $this->form_validation->set_rules('self', 'Self', 'required');
                // $this->form_validation->set_rules('spouse', 'Spouse', 'required');
                // $this->form_validation->set_rules('child', 'Child', 'required');
                if (count($_REQUEST) <= 1) {
                    $this->session->set_flashdata('error_msg', 'Please add details ');
                    $data['gpaiFixedAmt'] = $this->All_employee_list_appr_Model->getGpaiTeleAmount();
                    $data['mediPremFixedAmt'] = $this->All_employee_list_appr_Model->getMediclaimPremiumAmt();
                    $data['title']='Salary Structure';
                    $this->load->view("salary_structure/update__sal_tax_view",$data);
                }
                else{
                    // echo "<pre>"; print_r(count($_REQUEST)); die;
                    if($this->input->post('self') != '' ||$this->input->post('spouse') != '' ||$this->input->post('child') != ''){
                        $fixedAmt = $this->All_employee_list_appr_Model->getMediclaimPremiumAmt();
                
                        $requestArr = array(
                            'self' => $_POST['self'],
                            'spouse' => $_POST['spouse'],
                            'child' => $_POST['child'],
                        );
                        // // echo "<pre>"; print_r($fixedAmt); die;
                        if(count($fixedAmt) > 0) {
                            $requestArr = array_merge($requestArr,array('modified_by'=>1));
                            $data = $this->All_employee_list_appr_Model->updateFixedAmt('sal_anex_mediclaim_premium',$requestArr,$fixedAmt->fld_id);
                            $this->session->set_flashdata('success_msg', 'Mediclaim Premium Added Successfully');
                            redirect(base_url('fixed_anx_amt'));
                            // echo $data; die;
                        }else{
                            $requestArr = array_merge($requestArr,array('created_by'=>1));
                            $data = $this->All_employee_list_appr_Model->insertFixedAmt('sal_anex_mediclaim_premium',$requestArr);
                            $this->session->set_flashdata('success_msg', 'Mediclaim Premium inserted Successfully');
                            redirect(base_url('fixed_anx_amt'));
                        }
                    }else {
                        $this->session->set_flashdata('error_msg', 'at least 1 Field is Required to fill in Mediclaim Premium Section.');
                        redirect(base_url('fixed_anx_amt'));
                    }
                    
                }
            }
            elseif($this->input->post('gpai_tele_submit') == 'gpai_tele_submit'){
                if (count($_REQUEST) <= 1) {
                    $data['title']='Salary Structure';
                    $data['gpaiFixedAmt'] = $this->All_employee_list_appr_Model->getGpaiTeleAmount();
                    $data['mediPremFixedAmt'] = $this->All_employee_list_appr_Model->getMediclaimPremiumAmt();
                    $this->load->view("salary_structure/update__sal_tax_view",$data);
                }
                else{
                    // echo $this->input->post('grade');
                    if($this->input->post('grade') != '' || $this->input->post('gpai') != '' || $this->input->post('telephone') != '' || $this->input->post('edu_allowance')){
                        $fixedAmt = $this->All_employee_list_appr_Model->getGpaiTeleAmt($this->input->post('grade'));
                    
                        $requestArr = array(
                            'grade' => ($_POST['grade']) ? $_POST['grade'] : $fixedAmt->grade,
                            'gpai' => ($_POST['gpai']) ? $_POST['gpai'] : $fixedAmt->gpai,
                            'telephone' => ($_POST['telephone']) ? $_POST['telephone'] : $fixedAmt->telephone,
                            'edu_allowance' => ($_POST['edu_allowance']) ? $_POST['edu_allowance'] : $fixedAmt->edu_allowance,
                        );
                        // echo "<pre>"; print_r($fixedAmt); die;
                        if($fixedAmt > 0) {
                            $requestArr = array_merge($requestArr,array('modified_by'=>1));
                            $data = $this->All_employee_list_appr_Model->updateFixedAmt('sal_anex_fixed_amt_master',$requestArr,$fixedAmt->fld_id);
                            $this->session->set_flashdata('success_msg', 'GPAI TELEPHONE Amount Updated Successfully');
                            redirect(base_url('fixed_anx_amt'));
                            // echo $data; die;
                        }else{
                            $requestArr = array_merge($requestArr,array('created_by'=>1));
                            $data = $this->All_employee_list_appr_Model->insertFixedAmt('sal_anex_fixed_amt_master',$requestArr);
                            $this->session->set_flashdata('success_msg', 'GPAI TELEPHONE Amount Added Successfully ');
                            redirect(base_url('fixed_anx_amt'));
                        }
                    }else {
                        $this->session->set_flashdata('error_msg', 'at least 1 Field is Required to fill from GPAI Telephone.');
                        redirect(base_url('fixed_anx_amt'));
                    }
                }
            }
            
        }
    }



    public function updateSalAnextureAmt(){
        $this->form_validation->set_rules('self', 'Self', 'required');
        $this->form_validation->set_rules('spouse', 'Spouse', 'required');
        $this->form_validation->set_rules('child', 'Child', 'required');
        if ($this->form_validation->run() == FALSE) {
            $data['title']='Salary Structure';
            redirect(base_url('salAnexFixedAmt'));
        }
        else {
            $fixedAmt = $this->All_employee_list_appr_Model->getMediclaimPremiumAmt();
            
            $requestArr = array(
                'self' => ($_POST['self']),
                'spouse' => ($_POST['spouse']),
                'child' => ($_POST['child']),
            );
            
            if(count($fixedAmt) > 0) {
                $requestArr = array_merge($requestArr,array('modified_by'=>1));
                $data = $this->All_employee_list_appr_Model->updateFixedAmt($requestArr);
                $this->session->set_flashdata('success_msg', 'Mediclaim Premium Added Successfully');
                redirect(base_url('salAnexFixedAmt'));
                // echo $data; die;
            }else{
                $requestArr = array_merge($requestArr,array('created_by'=>1));
                $data = $this->All_employee_list_appr_Model->insertFixedAmt($requestArr);
                $this->session->set_flashdata('success_msg', 'Mediclaim Premium Added Successfully');
                redirect(base_url('salAnexFixedAmt'));
            }
        }
    }

    public function updateSalAnextureAmt_(){
        echo "test"; die;
        $fixedAmt = $this->All_employee_list_appr_Model->getGpaiTeleAmt($_POST['grade']);
        echo "<pre>"; print_r($fixedAmt); die;
        // $fixedAmt = 0;
        $requestArr = array(
            'gpai' => ($_POST['gpai']) ? $_POST['gpai'] : $fixedAmt->gpai,
            'grade' => ($_POST['grade']) ? $_POST['grade'] : $fixedAmt->grade,
            'telephone' => ($_POST['telephone']) ? $_POST['telephone'] : $fixedAmt->gratelephonee,
        );
        if(count($fixedAmt) > 0) {
            $requestArr = array_merge($requestArr,array('modified_by'=>1));
            $data = $this->All_employee_list_appr_Model->updateFixedAmt($requestArr);
            echo $data; die;
        }else{
            $requestArr = array_merge($requestArr,array('created_by'=>1));
            $data = $this->All_employee_list_appr_Model->insertFixedAmt($requestArr);
            echo $data; die;
        }
    }

    public function ajax_sal_anx_fixedAmt(){
        $list = $this->Sal_anx_fixed_amt_Model->get_datatables();
        // echo "<pre>"; print_r($list); die;
        $data = array();
        $no = $_POST['start'];
        $gradeArr = array(1 => 'A', 2=>'B', 3=>'C', 4=>'D', 5=>'E', 6=>'F');
        foreach ($list as $dataRow) {
           
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($dataRow->grade) ? $gradeArr[$dataRow->grade] : '';
            $row[] = isset($dataRow->gpai) ? $dataRow->gpai : '';
            $row[] = isset($dataRow->telephone) ? $dataRow->telephone : '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Sal_anx_fixed_amt_Model->count_all(),
            "recordsFiltered" => $this->Sal_anx_fixed_amt_Model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function ajax_sal_anx_mediclaim_premium(){
        // echo "test"; die;
        $list = $this->Sal_anex_mediclaim_premium_model->get_datatables();
        // echo "tet"; die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $dataRow) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = isset($dataRow->self) ? $dataRow->self : '';
            $row[] = isset($dataRow->spouse) ? $dataRow->spouse : '';
            $row[] = isset($dataRow->child) ? $dataRow->child : '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Sal_anex_mediclaim_premium_model->count_all(),
            "recordsFiltered" => $this->Sal_anex_mediclaim_premium_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function mytest() {
        echo $_FILES(['ctc_file']['name']); die;
        // if($_REQUEST){
        //     echo "inside if"; 
        //     // echo "<pre>"; print_r($_FILES['ctc_file']); 
        //     echo $_FILES(['ctc_file']['name']);
        //     if($_FILES(['ctc_file','name'])){
        //         echo "Nested inside if"; die;
        //     }
        // }else {
        //     echo "mm";
        // }
    }

    public function uploadCtcExcel() {
        if (!empty($_FILES['salary_file']['name']))
        {
            $this->form_validation->set_rules('salary_file', 'CTC Excel', 'required');
        }
        if(empty($_FILES['salary_file']['name'])){

            $data['gpaiFixedAmt'] = $this->All_employee_list_appr_Model->getGpaiTeleAmount();
            $data['mediPremFixedAmt'] = $this->All_employee_list_appr_Model->getMediclaimPremiumAmt();
            $data['title']='Salary Structure';
            $this->load->view("salary_structure/upload_ctc_excel_view",$data);
        }
        else {
            $entry_by = $this->session->userdata('loginid');
            // echo 'mytest'.$_FILES['salary_file']['name']; die;
            if ($_FILES['salary_file']['name']) {
                // echo "test"; die;
                $configThm = $this->getUploadConfig('salary');
                $this->load->library('upload', $configThm);
                $this->upload->initialize($configThm);
                // echo "test"; die;
                if ($this->upload->do_upload('salary_file')) {
                    // echo "inside if"; die;
                    // echo "new inside else"; die;
                    $uploadData = $this->upload->data();
                    $filepath = $uploadData['full_path'];
                    $file = fopen($filepath, 'r');
                    $n = 0;
                    while (($line = fgetcsv($file)) !== FALSE) {	
                        if($n>0) {
                            // echo $line[1]; 
                            $user_id = get_emp_user_id_by_emp_code($line[1]);	
                            // echo 'test'.$user_id; die;
                            $line7 = ltrim($line[7],"`");
                            $query = $this->db->get_where('main_empsalarydetails', array('user_id' => $user_id,'isactive'=>'1'));
                            // echo $query->num_rows(); die;
                            $count = $query->num_rows();
                            if($count<1){
                                $InsrtrecArr = array(
                                    'user_id' => $user_id, 
                                    'currencyid' => $line[2], 
                                    'salarytype' => $line[3], 
                                    'salary' => $line[4], 
                                    'bankname' => $line[5], 
                                    'accountholder_name' => $line[6], 
                                    'accountnumber' => $line7, 
                                    'branchname' => $line[8], 
                                    'ifsc_code' => $line[9], 
                                    'pancard_no' => $line[10], 
                                    'appraisalduedate' => $line[11], 
                                    'entry_by' => $entry_by,
                                    'createddate'=>date('Y-m-d h:i:s'),
                                    'flag'=>'1'
                                );
                                echo "<pre>"; print_r($InsrtrecArr); die;
                                $resps = $this->db->insert('main_empsalarydetails', $InsrtrecArr);
                                //$resps = $this->db->insert('temp_salary_details', $InsrtrecArr2);
                            }else{
                                $where = array("user_id" => $user_id);
                                $updateArr = array(
                                    'currencyid' => $line[2], 
                                    'salarytype' => $line[3], 
                                    'salary' => $line[4], 
                                    'ctcsalary' => $line[5], 
                                    'bankname' => $line[6], 
                                    'accountholder_name' => $line[7], 
                                    'accountnumber' => $line[8], 
                                    'branchname' => $line[9], 
                                    'ifsc_code' => $line[10], 
                                    'pancard_no' => $line[11], 
                                    'appraisalduedate' => $line[12],
                                    'modifiedby' => $entry_by,
                                    'modifieddate'=>date('Y-m-d h:i:s'),
                                    'flag'=>'1'
                                );
                                // echo "sd<pre>"; print_r($updateArr); die;
                                $this->db->where($where);
                                $resps = $this->db->update('main_empsalarydetails', $updateArr);
                                $userSalDetail = $this->db->get_where('main_empsalarydetails', array('user_id' => $user_id,'isactive'=>'1'))->row();
                            }
                        }
                        $n++;
                    }
                    fclose($file); 
                } 
            }
            if($resps){
                $this->session->set_flashdata('success_msg', "CTC csv Uploaded Successfully...! ");
                redirect(base_url('uploadCtcDetailsExcel/'.$userSalDetail->id));
            }else{
                $this->session->set_flashdata('error_msg', "new");
                redirect(base_url('uploadCtcExcel'));
            }
        }
    }

    public function uploadCtcDetailsExcel($salary_id) {
        // echo $this->uri->segment(2); die;
        // $salary_id = $this->uri->segment(2); 
        // echo $salary_id; die;
            if (!empty($_FILES['salary_details']['name']))
            {
                // echo "est"; die;
                // echo "<pre>"; print_r($_FILES); die;
                $this->form_validation->set_rules('salary_details', 'CTC Excel', 'required');
            }
            if(empty($_FILES['salary_details']['name'])){
                $data['csv_file_2'] = 2;
                $data['salary_id'] = $salary_id;
                $data['gpaiFixedAmt'] = $this->All_employee_list_appr_Model->getGpaiTeleAmount();
                $data['mediPremFixedAmt'] = $this->All_employee_list_appr_Model->getMediclaimPremiumAmt();
                $data['title']='Salary Structure';
                $this->load->view("salary_structure/upload_ctc_excel_view",$data);
            }
            else {
                // echo "test"; die;
                $entry_by = $this->session->userdata('loginid');
                if ($_FILES['salary_details']['name']) {
                    $configThm = $this->getUploadConfig('salary');
                    $this->load->library('upload', $configThm);
                    $this->upload->initialize($configThm);
                    // echo "test"; die;
    
                    if ($this->upload->do_upload('salary_details')) {
                        // echo "inside if"; die;
                        // echo "new inside else"; die;
                        $uploadData = $this->upload->data();
                        $filepath = $uploadData['full_path'];
                        $file = fopen($filepath, 'r');
                        $n = 0;
                        while (($line = fgetcsv($file)) !== FALSE) {	
                            if($n>0) {
                                // echo $line[1]; 
                                $user_id = get_emp_user_id_by_emp_code($line[1]);	
                                $userSalDetail = $this->db->get_where('main_empsalarydetails', array('id' => $salary_id,'isactive'=>'1'))->row();
                                // echo 'test'.$user_id; die;
                                // $line7 = ltrim($line[7],"`");
                                echo $line[29].'<br>';
                                // $query = $this->db->get_where('main_empsal_increment', array('user_id' => $user_id,'isactive'=>'1'));
                                // echo $query->num_rows(); die;
                                // $count = $query->num_rows();
                                // if($count<1){
                                    $InsrtrecArr = array(
                                        'user_id' => $userSalDetail->user_id, 
                                        'salary_id' => $salary_id, 
                                        // 'emp_salary_historyID' => $line[4], 
                                        'appraisal_datemmyy' => $line[2], 
                                        'empctc' => $line[3], 
                                        'grosssalary' => $line[4], 
                                        'basicsalary' => $line[5], 
                                        'empepf' => $line[6], 
                                        'loyaltybonus' => $line[7], 
                                        'emp_hra' => $line[8], 
                                        'emp_esi' => $line[9], 
                                        'projectcomp_bonus' => $line[10], 
                                        'special_allowance' => $line[11], 
                                        'emp_gratuity' => $line[12], 
                                        'transportation_allowance' => $line[13], 
                                        'emp_sal_gpai' => $line[14], 
                                        'tele_empsal_allowance' => $line[15], 
                                        'education_allowance' => $line[16], 
                                        'medical_allowance' => $line[17], 
                                        'statutory_deduct' => $line[18], 
                                        'sal_other' => $line[19], 
                                        'leave_travel_allowance' => $line[20], 
                                        'food_expenses' => $line[21], 
                                        'fuel_expenses' => $line[22], 
                                        'vehicle_agreement' => $line[23], 
                                        'driver_wagers' => $line[24], 
                                        'empctcp1' => $line[25], 
                                        'empctcp2' => $line[26], 
                                        'project_allowance' => $line[27], 
                                        'bonus_adv' => $line[28], 
                                        'salsec_other' => $line[29], 
                                        'grosssal_mediclaim' => $line[30], 
                                        'grosssal_other' => $line[31], 
                                        'pcb_employer' => $line[32], 
                                        'createdby' => $entry_by,
                                        'createddate'=>date('Y-m-d h:i:s'),
                                        'flag'=>'1'
                                    );
                            }
                            $n++;
                        }
                        die;
                        fclose($file); 
                    } 
                }
                if($resps){
                    
                    $this->session->set_flashdata('success_msg', "Csv Uploaded Successfully");
                    redirect(base_url('uploadCtcDetailsExcel/'.$salary_id));
                }else{
                    $this->session->set_flashdata('error_msg', "Something Went Wrong");
                    redirect(base_url('uploadCtcDetailsExcel/'.$salary_id));
                }
            }
        }

    protected function getUploadConfig($folderName) {
        $config = array();
        $config['upload_path'] = './uploads/'.$folderName.'/';
        $config['allowed_types'] = 'xlsx|csv|xls|xlsm';
        $config['max_size'] = '200000'; //20MB
        $config['file_name'] = "New_salary". time() . '.csv';
        return $config;
    }

    // save data
    public function saveUpdateCtcExcel(){
        $this->form_validation->set_rules('self', 'Self', 'required');
        $this->form_validation->set_rules('spouse', 'Spouse', 'required');
        $this->form_validation->set_rules('child', 'Child', 'required');
        if ($this->form_validation->run() == FALSE) {
            $data['title']='Salary Structure';
            redirect(base_url('uploadCtcExcel'));
        }
        else {
            $fixedAmt = $this->All_employee_list_appr_Model->getMediclaimPremiumAmt();
            
            $requestArr = array(
                'self' => ($_POST['self']),
                'spouse' => ($_POST['spouse']),
                'child' => ($_POST['child']),
            );
            
            if(count($fixedAmt) > 0) {
                $requestArr = array_merge($requestArr,array('modified_by'=>1));
                $data = $this->All_employee_list_appr_Model->updateFixedAmt($requestArr);
                $this->session->set_flashdata('success_msg', 'Mediclaim Premium Added Successfully');
                redirect(base_url('uploadCtcExcel'));
                // echo $data; die;
            }else{
                $requestArr = array_merge($requestArr,array('created_by'=>1));
                $data = $this->All_employee_list_appr_Model->insertFixedAmt($requestArr);
                $this->session->set_flashdata('success_msg', 'Mediclaim Premium Added Successfully');
                redirect(base_url('uploadCtcExcel'));
            }
        }
    }

    //========================== code for salary anaxture ===========================
    public function emplist_project()
    {
        $data['title'] = "Employee List : All";
        $data['Hr_EmpDetailsArr'] = $this->Hr_EmpDetailsArr("ceg_project");
        $this->load->view("salary_structure/employee_list_project", $data);
    }

    // employee list project
    public function ajax_employee_list_project()
    {
        $list = $this->All_employee_list_project_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $dataRow) {
            $image1 = '<img src="' . HOSTNAME . "public/uploads/profile/profile_pic.png" . '" class="rounded-circle avatar" alt="" style="height:50px; width:50px;">';
            if ($dataRow->profileimg) {
                $image = '';
                $image .= isset($dataRow->profileimg) ? $dataRow->profileimg : '';
                $imageCr = str_replace("index.php/", "", $image);
                $image1 = '<img src="' . EMPLPROFILE . $imageCr . '" class="rounded-circle avatar" alt="" style="height:50px; width:50px;">';
            }
            $employeeStatus = $dataRow->isactive ? $dataRow->isactive : '0';
            if ($employeeStatus == "0") {
                $empStatus =  "<span class='btn btn-danger'>Inactive</span>";
            } elseif ($employeeStatus == "1") {
                $empStatus =  "<span class='btn btn-success'>Active</span>";
            } elseif ($employeeStatus == "2") {
                $empStatus = "<span class='btn btn-danger'>Resigned</span>";
            } elseif ($employeeStatus == "3") {
                $empStatus = "<span class='btn btn-info'>Left</span>";
            } elseif ($employeeStatus == "4") {
                $empStatus = "<span class='btn btn-info'>Suspended</span>";
            }
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($dataRow->userfullname) ? $image1 . "&nbsp;&nbsp;" . $dataRow->userfullname . "" : '';
            $row[] = isset($dataRow->contactnumber) ? $dataRow->contactnumber : '';
            $row[] = isset($dataRow->emailaddress) ? $dataRow->emailaddress : '';
            $row[] = isset($dataRow->department_name) ? $dataRow->department_name : '';
            $row[] = isset($dataRow->businessunit_name) ? $dataRow->businessunit_name : '';
            $row[] = $empStatus;
            $row[] = "<a class='btn btn-info' href='javascript:void(0);' onclick='setUserIdForSalStructure(".$dataRow->user_id.")' data-toggle='modal' data-target='#ctcModal'>ADD CTC</a>";
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->All_employee_list_project_Model->count_all(),
            "recordsFiltered" => $this->All_employee_list_project_Model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function sal_structure_project() {
        $this->form_validation->set_rules('user_id', 'User', 'required');
        $this->form_validation->set_rules('ctc', 'CTC', 'required');
        $userDetails = $this->All_employee_list_project_Model->getDataByUserId($this->input->post('user_id'));
        $reqArr = $this->input->post();
        if ($this->form_validation->run() == FALSE) {
            $data['title']='Salary Structure';
            $this->load->view("salary_structure/employee_list_appr",$data);
        }
         else {
             if($this->input->post('redirect_aft_upd') == 1 && $this->input->post('user_id'))
            {
                $user_id = $userDetails->user_id;
                $salArrToObj = $this->All_employee_list_project_Model->getRowCountSalaryAnexture($user_id);
                $userDetails = $this->All_employee_list_project_Model->getDataByUserId($user_id);
                $net_sal = $salArrToObj->gross + ($salArrToObj->emp_pf + $salArrToObj->emp_vpf + $salArrToObj->emp_esi);
                $salArrToObj = (object) array_merge( (array)$salArrToObj, array( 'user_id' => $user_id ) );
                
                
                if($this->input->post()){
                    $updateArr = array(
                        "basic_sal" => $reqArr['basic_salary'],
                        "hra" => $reqArr['hra'],
                        "edu_allow" => $reqArr['edu_allow'],
                        "tele_allow" => $reqArr['tele_allow'],
                        "bonus_adv" => $reqArr['bonus_adv'],
                        "gadget_allow" => $reqArr['gadget_allow'],
                        "special_allow" => $reqArr['special_allow'],
                        "gross" => $reqArr['gross'],
                        "employer_gratuity" => $reqArr['employer_gratuity'],
                        "gpai" => $reqArr['gpai'],
                        "mediclaim" => $reqArr['mediclaim'],
                        "annual_bonus_applicable" => $reqArr['annual_bonus_applicable'],
                        "monthly_ctc" => $reqArr['monthly_ctc'],
                        "ann_bonus" => $reqArr['annual_bonus'],
                        "total_ctc" => $reqArr['total_ctc'],
                        "department" => $reqArr['department'],
                    );
                    
                    $this->db->where('user_id',$user_id);
                    $resp = $this->db->update('temp_sal_structure_project',$updateArr);
                    if($resp){
                        $salArrToObj = $this->All_employee_list_project_Model->getRowCountSalaryAnexture($user_id);
                        $userDetails = $this->All_employee_list_project_Model->getDataByUserId($user_id);
                        $data['salArrToObj'] = $salArrToObj;
                        $data['userDetails'] = $userDetails;
                        $this->load->view("salary_structure/show_project_salary_structure_view",$data);
                    }else{
                        $this->session->set_flashdata('error_msg',"Some thing went wrong. Please try to update again");
                        redirect(base_url('salary_structure_edit'));
                    }
                }    
            }
            else{
                $gradeArr = array('1'=>'A','2'=>'B','3'=>'C','4'=>'D','5'=>'E','6'=>'F');
                $userDetails = $this->All_employee_list_project_Model->getDataByUserId($this->input->post('user_id'));
                $data['gpaiTeleFixAmt'] = $this->All_employee_list_project_Model->getGpaiTeleAmt(array_search ($userDetails->jobtitle_name, $gradeArr));
                $data['mediclaim_prem'] = $this->All_employee_list_project_Model->getMediclaimPremiumAmt();

                $pf_applicable = $this->input->post('pf_applicable');
                $vpf_applicable = $this->input->post('vpf_applicable');
                $metro_non = $this->input->post('metro_non_metro');
                $effective_date = $this->input->post('effective_date');
                $department = $this->input->post('department');
                $gratuity_applicable = 1;

                $esi_applicable = 1;
                $mediclaim_applicable = 0;
                $edu_allow = 200;
                // $ann_bonus = 0;
                $ctc = $this->input->post('ctc');
                $tax_fig = 1000;
                
                $dataArr = $this->reCalculateSalary_project($no=1,$data['gpaiTeleFixAmt'],$data['mediclaim_prem'],$ctc, $tax_fig,$userDetails, $metro_non, $pf_applicable, $edu_allow, $esi_applicable,$mediclaim_applicable, $gratuity_applicable, $vpf_applicable );
                $total_ctc = ($department == 1) ? $dataArr['ann_bonus'] + $dataArr['monthly_ctc'] : $dataArr['monthly_ctc'];
                $net_sal = $dataArr['gross'] + ($dataArr['emp_pf'] + $dataArr['emp_vpf'] + $dataArr['emp_esi']);
                $ctc_in_words = $this->convert_number($total_ctc);
                $dataArr['gadget_allow'] = $this->getGadgetAllowance($dataArr['gross'], $total_ctc);
                if($total_ctc > 125000){
                    $dataArr['special_allow'] = round($dataArr['gross'] - ($dataArr['basic_sal'] + $dataArr['hra'] + $dataArr['edu_allow'] + $dataArr['tele_allow'] + $dataArr['bonus_adv'] + $dataArr['gadget_allow']) );
                }
                $salArr = array('metro_non' => $metro_non,
                    'ctc'=> $ctc,
                    'mediclaim_applicable'=>$mediclaim_applicable,
                    'pf_applicable'=>$pf_applicable,
                    'vpf_applicable'=>$vpf_applicable,
                    'esi_applicable'=>$esi_applicable,
                    'gratuity_applicable'=>$gratuity_applicable,
                    'annual_bonus_applicable'=>$dataArr['annual_bonus_applicable'],
                    'ann_bonus' => $dataArr['ann_bonus'],
                    'edu_allow' => $edu_allow,
                    "net_sal" => $net_sal,
                    "total_ctc" => $total_ctc,
                    "effective_date" => $effective_date,
                    "ctc_in_words" => $ctc_in_words,
                    'department'=>$department,
                );

                $finalArr = array_merge($salArr,$dataArr);
                $data['userDetails']  = $userDetails;
                $data['salArrToObj'] = $this->ToObject($finalArr);

                // echo "dd<pre>";
                // // // print_r($gadget_allow); die;
                // print_r($this->ToObject($finalArr));
                // die;
                $addAnexture = $this->All_employee_list_project_Model->addSalaryAnextureDataTemp($userDetails,$this->ToObject($finalArr));
                $data['fld_id'] = $addAnexture; 
                if($addAnexture){
                        $this->session->set_flashdata('success_msg', 'Please Check Anexture before download.');
                        // $data['title'] = "Salary Structure";
                        $salArrToObj = $this->All_employee_list_project_Model->getRowOfSalaryAnextureByFldId($data['fld_id']);
                        $data['salArrToObj'] = $salArrToObj;
                        $this->load->view("salary_structure/show_project_salary_structure_view",$data);
                    }else{
                        // echo "inside else"; die;
                        $this->session->set_flashdata('error_msg', 'Something Went Wrong.');
                        redirect(base_url('sal_structure'));
                }
            }
        }
    }



    public function reCalculateSalary_project( $no,$gpaiTeleFixAmt, $mediclaim_prem,$ctc, $tax_fig,$userDetails, $metro_non, $pf_applicable, $edu_allow, $esi_applicable,$mediclaim_applicable, $gratuity_applicable ) {    
        $vpf_applicable = $this->input->post('vpf_applicable'); 
        $annual_bonus = $this->input->post('annual_bonus'); 
        $annual_bonus_applicable = $this->input->post('annual_bonus_applicable'); 
        $department = $this->input->post('department'); 
        $yearCtc = $ctc *12;
        $gpai = $gpaiTeleFixAmt->gpai;
        $tele_allow = $gpaiTeleFixAmt->telephone;
        $gross = $this->getGrossSalary($ctc, $tax_fig, $userDetails->businessunit_id, $annual_bonus, $department);

            $basic_sal = $this->getBasicSalary($gross);
            $hra = $this->getHraAmount($metro_non, $basic_sal);
            $bonus_adv = $this->getBonusAmount($gross, $basic_sal);

            if($gross > 21000){
                $esi_applicable = 0;
            }

            if($esi_applicable){
                $mediclaim_applicable = 0;
                $mediclaim_amount = 0;
            }else{
                $mediclaim_applicable = 1;
                $mediclaim_amount =$mediclaim_prem->self;
            }
            
            $special_allow = round($gross - ($basic_sal + $hra + $edu_allow + $tele_allow + $bonus_adv) );

            $employer_esi = $this->getemployerEsiAmount($esi_applicable, $gross);
            $gratuity_amount = $this->getGratuityAmount($gratuity_applicable, $basic_sal);
            $emp_esi = $this->getEmpEsiAmount($esi_applicable, $gross);
            $employer_pf = $this->getPfAmount($pf_applicable,$basic_sal ,$edu_allow ,$tele_allow ,$special_allow);
            $emp_vpf = $this->getEmpVPfAmount($vpf_applicable, $basic_sal ,$edu_allow ,$tele_allow ,$special_allow);
            $emp_pf = $this->getEmpPfAmount($pf_applicable, $basic_sal ,$edu_allow ,$tele_allow ,$special_allow);

            $deduction = $employer_pf + $employer_esi + $gratuity_amount + $gpai + $mediclaim_amount;
            $monthly_ctc = $gross+$deduction;

            $totalCtc = $annual_bonus + $monthly_ctc;
            $returnArr = array('gross' => $gross,'basic_sal' => $basic_sal,'hra' => $hra,'bonus_adv' => $bonus_adv,'employer_pf' => $employer_pf,'emp_pf' => $emp_pf,
            'gpai' => $gpai,'tele_allow' => $tele_allow, 'esi_applicable' => $esi_applicable,'mediclaim_applicable' => $mediclaim_applicable,
            'mediclaim' => $mediclaim_amount,'employer_esi' => $employer_esi,'employer_gratuity' => $gratuity_amount,
            'emp_vpf' => $emp_vpf,'emp_esi' => $emp_esi,'special_allow' => $special_allow,'monthly_ctc' => $monthly_ctc,'deduction' => $deduction,
            'ann_bonus' => $annual_bonus,'annual_bonus_applicable' => $annual_bonus_applicable,'deduction' => $deduction,'tax_fig' => $tax_fig,'edu_allow' => $edu_allow);

            if($tax_fig != $deduction){

                $tax_fig = $tax_fig - ($tax_fig - $deduction); 
                $fArr = $this->reCalculateSalary_project($no,$gpaiTeleFixAmt, $mediclaim_prem,$ctc, $tax_fig,$userDetails, $metro_non, $pf_applicable, $edu_allow, $esi_applicable,$mediclaim_applicable, $gratuity_applicable, );
                return $fArr;
            }
            else {
                // echo "test"; die;
                $returnArr = array('gross' => $gross,'basic_sal' => $basic_sal,'hra' => $hra,'bonus_adv' => $bonus_adv,'employer_pf' => $employer_pf,'emp_pf' => $emp_pf,
                'gpai' => $gpai,'tele_allow' => $tele_allow, 'esi_applicable' => $esi_applicable,'mediclaim_applicable' => $mediclaim_applicable,
                'mediclaim' => $mediclaim_amount,'employer_esi' => $employer_esi,'employer_gratuity' => $gratuity_amount,
                'emp_vpf' => $emp_vpf,'emp_esi' => $emp_esi,'special_allow' => $special_allow,'monthly_ctc' => $monthly_ctc,'deduction' => $deduction,
                'ann_bonus' => $annual_bonus,'annual_bonus_applicable' => $annual_bonus_applicable,'deduction' => $deduction,'tax_fig' => $tax_fig,'edu_allow' => $edu_allow);
                 
            }
            return $returnArr;
    }


    public function project_salary_structure_edit()
	{
        $user_id = $this->uri->segment(2);
        $salArrToObj = $this->All_employee_list_project_Model->getRowCountSalaryAnexture($user_id);
        $userDetails = $this->All_employee_list_project_Model->getDataByUserId($user_id);
        $net_sal = $salArrToObj->gross + ($salArrToObj->emp_pf + $salArrToObj->emp_vpf + $salArrToObj->emp_esi);
        $salArrToObj = (object) array_merge( (array)$salArrToObj, array( 'user_id' => $user_id ) );
        $this->load->view('salary_structure/project_salary_structure_edit_view', compact('salArrToObj'), true);
	}

    public function download_project_sal_anexture_pdf()
	{
        $user_id = $this->uri->segment(2);
        $salArrToObj = $this->All_employee_list_project_Model->getRowCountSalaryAnexture($user_id);
        $userDetails = $this->All_employee_list_project_Model->getDataByUserId($user_id);
        $net_sal = $salArrToObj->gross + ($salArrToObj->emp_pf + $salArrToObj->emp_vpf + $salArrToObj->emp_esi);
        $salArrToObj = (object) array_merge( (array)$salArrToObj, array( 'net_sal' => '1234' ) );
        // echo "<pre>"; print_r($salArrToObj); die;
        $html = $this->load->view('salary_structure/project_sal_structure_pdf', compact('salArrToObj','userDetails'));
        echo $html; die;
        // echo "dd<pre>"; print_r($html); die;
        // // echo $salArrToObj->ctc; die;
        $this->load->library('mp_pdf');
        $data['title'] = 'Employee Info';

        // echo "dd<pre>"; print_r($referencesDetails); die;
        $po_view = $this->load->view('salary_structure/project_sal_structure_pdf', compact('salArrToObj'));
        // echo $po_view; die;
        // echo "dd<pre>"; print_r($po_view); die;
        $pdfFilePath = "salary.pdf";
        $this->mp_pdf->pdf->mirrorMargins = 1;
        $this->mp_pdf->pdf->shrink_tables_to_fit = 1;
        $this->mp_pdf->pdf->SetTitle('Salary');
        ob_clean();
        ob_flush();
        $this->mp_pdf->pdf->WriteHTML($po_view);
        $this->mp_pdf->pdf->Output($pdfFilePath, "D");
        ob_end_flush();
        ob_end_clean();
	}


}
