<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
class Write_to_us_Controller extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
		$this->load->model('mastermodel');
		if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }
	
	//  Write To Us View Show 
    public function writetous(){
		$data['title'] ="Write To Us";
		$message_status ="1"; // 1-- write to us message
		$data['message_list']= $this->message_list($message_status);
		//echo '<pre>'; print_r($data); echo '</pre>'; die;
		$this->load->view("/write_to_us/write_to_us_view",$data);		
	}
	
	//  Write To Us data add on database (table-hr_messages)
	public function message_add(){
		$id = $this->session->userdata('loginid');
        $title = $_REQUEST['title'];
        $description = $_REQUEST['desc'];
        $date = $_REQUEST['date'];
		
		$data = array(
			'title' => $title,
			'description' => $description, 
			'add_date' => $date,  
			'message_status' => "1",   // 1-- write to us message , 2-- Confidential Message
			'entryby' => $id, 
		);
		$insert_arr = $this->db->insert('hr_messages', $data);	
		if ($insert_arr){
			$this->session->set_flashdata('success_msg', 'Message Added Successfully !');
			redirect(base_url('writetous'));
		}else{
			$this->session->set_flashdata('error_msg', 'Something went gone wrong');
			redirect(base_url('writetous'));
		}	
	}
	
	//  Confidential Message View Show 
    public function confidential_message(){
		$data['title'] ="Confidential Message";
		$message_status ="2"; // 2-- Confidential Message
		$data['confidential_message_list']= $this->message_list($message_status);
		//echo '<pre>'; print_r($data); echo '</pre>'; die;
		$this->load->view("/write_to_us/confidential_message_view",$data);		
	}
	
	// Confidential Message data add on database (table-hr_messages)
	public function confidential_message_add(){
		$id = $this->session->userdata('loginid');
        $title = $_REQUEST['title'];
        $description = $_REQUEST['desc'];
        $date = $_REQUEST['date'];
		
		$data = array(
			'title' => $title,
			'description' => $description, 
			'add_date' => $date,  
			'message_status' => "2",   // 1-- write to us message , 2-- Confidential Message
			'entryby' => $id, 
		);
		$insert_arr = $this->db->insert('hr_messages', $data);	
		if ($insert_arr){
			$this->session->set_flashdata('success_msg', 'Message Added Successfully !');
			redirect(base_url('confidential_message'));
		}else{
			$this->session->set_flashdata('error_msg', 'Something went gone wrong');
			redirect(base_url('confidential_message'));
		}	
	}
	
	public function message_list($message_status){
		$id = $this->session->userdata('loginid');
		$this->db->select("*");
		$this->db->from("hr_messages");
		$this->db->where(array("status" => "1" , "message_status" => $message_status));
		//$this->db->where("entryby",$id);
		$this->db->order_by("id","desc");
		$result= $this->db->get()->result();
		return ($result) ? $result : "";
	}
	
	
	
}
