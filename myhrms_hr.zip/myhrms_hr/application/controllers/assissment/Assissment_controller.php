
<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Assissment_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('assissment/Assissment_model');
        $this->db3 = $this->load->database('accdept_db', TRUE);
    //    $this->load->model('Mastermodel');
    //    $this->load->model('Department/Department_model');
       if($this->session->userdata('loginid') == '')
       {
        redirect(base_url(''));
       }
    }
    public function index()
    {
       $data['employess']= $this->Assissment_model->get_all_employess();
       $data['assesment'] = $this->Assissment_model->get_all_assesment();
       $data['financial_year_slot'] = $this->Assissment_model->financial_year_slot();
		 $this->form_validation->set_rules('user_id', 'Employee', 'required');
         $this->form_validation->set_rules('assessment_id', 'Assessement', 'required');
         $this->form_validation->set_rules('financial_year', 'Financial Year', 'required');

    if ($this->form_validation->run() == FALSE) {
		//  $data['countries'] = $this->Mastermodel->GetCountries();
        // $data['business_unit'] = $this->get_all_bussiness_unit();
        $data['title']='Assessment Parameters Assign';
        $this->load->view("assissment/Assissment_parametter_assign",$data);
    }
    else{
       $input =  $this->input->post();
     
      $return_data =  $this->get_assissment_assign_ornot($input);
      if($return_data <=0 )
      {
       
               $up_data= $this->Assissment_model->assign_assessment_parametter($input);
               if($up_data)
               {
                $this->session->set_flashdata('success_msg', 'Assessment Parameters Added Successfully.');
               }
               else{
                $this->session->set_flashdata('error_msg', 'Something went wrong.');
               }
      }
      else{
        $this->session->set_flashdata('error_msg', 'Assessment Parameters Already Assigned.');
      }
     redirect(base_url('assiss_param_assign'));
         

    }
    }
    public function employee_assissment_parametter_ajax()
    {
        
    //    $user_id = $this->uri->segment(4);
    //    $sloat_id = $this->uri->segment(5);
        $list = $this->Assissment_model->get_datatables();
        // echo "<pre>";
        // print_r($list);
        // die;
       // .userfullname,c.employeeId,b.assisment_question,d.slot_name
        $no = 0;
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $value->assisment_question;
            $row[] = $value->userfullname."[".$value->employeeId."]";
            $row[] = $value->slot_name;
           //$marks_obtain = $this->get_emp_io_review_marks($value->id,$user_id);
           //  $row[] = '<input type="number" name="question_'.$value->id.'" value="'.$value->marks_obtain.'" class="form-control">';//javascript:void(0);
            $data[] = $row;
        }
        //($recRow->user_fullname) ? $recRow->user_fullname : "";
        $output = array(
            "draw" =>  $_POST['draw'],
            "recordsTotal" => $this->Assissment_model->count_all(),
            "recordsFiltered" => $this->Assissment_model->count_filtered(),
            "data" => $data,
        );

        echo json_encode($output);
   
        
    }
    public function get_assissment_assign_ornot($input)
    {
        // print_R($input);
        $this->db->select("*");
        $this->db->from("assessment_assign_fin");
        $this->db->where("user_id",$input['user_id']);
        $this->db->where("assissment_id",$input['assessment_id']);
        $this->db->where("financial_year_id",$input['financial_year']);
        $return = $this->db->get()->num_rows();
        // print_R($return);
        // die();
        return $return;
    }
   
}
