<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Live_attendance_report_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Live_attendance_report_model');
        $this->load->library('form_validation');
        $this->load->helper('common_helper');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function live_attendance() {
        $sub_dpt = array();
        $id = $this->session->userdata('loginid');
        // $liveAttenDetailArr = $this->Live_attendance_report_model->live_punch_report();
		// epd($liveAttenDetailArr);
        // echo "<pre>"; print_r($liveAttenDetailArr); die;
        $title = "Live Attendance Report";
        $this->load->view("live_attendance/live_attendance_view", compact('title', 'liveAttenDetailArr'));
    }

    //Ajax List.. Attendance Report..
    public function ajax_live_attendance_report_list() {
        // echo "test"; die;
        $no = 1;
        $list = $this->Live_attendance_report_model->get_datatables();
        // echo "<pre>"; print_r($list); die;
        $data = array();
        $no = $_POST['start'];
		if($list):
			foreach ($list as $recemp) {
				$time = date('H:i:s A', strtotime($recemp->LogDate));
				$no ++;
				$row = array();
				$row[] = $no;
				$row[] = ($recemp->DevicesName) ? $recemp->DevicesName : "";
				$row[] = ($recemp->DeviceLocation) ? $recemp->DeviceLocation : "";
				$row[] = ($recemp->employeeId) ? $recemp->employeeId : "";
				$row[] = ($recemp->userfullname) ? $recemp->userfullname : "";
				$row[] = ($time) ? $time : "";
				$row[] = ($recemp->C5) ? $recemp->C5 : "";
				if($recemp->floor_number == 1):
					$floorNo = '-1';
				elseif($recemp->floor_number == 2):
					$floorNo = '0';
				elseif($recemp->floor_number == 3):
					$floorNo = '1';
				elseif($recemp->floor_number == 4):
					$floorNo = '2';
				elseif($recemp->floor_number == 5):
					$floorNo = '3';	
				elseif($recemp->floor_number == 6):
					$floorNo = '4';
				elseif($recemp->floor_number == 7):
					$floorNo = '5';	
				elseif($recemp->floor_number == 8):
					$floorNo = '6';
				elseif($recemp->floor_number == 9):
					$floorNo = '7';	
				endif;	
					
				$row[] = ($floorNo) ? $floorNo : "";
				$data[] = $row;
			}
		endif;

		$output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Live_attendance_report_model->count_all(),
            "recordsFiltered" => $this->Live_attendance_report_model->count_filtered(),
            "data" => $data,
        );
        // $output = array(
        //     "draw" => $_POST['draw'],
        //     "recordsTotal" => count($list),
        //     "recordsFiltered" => count($list),
        //     "data" => $data
        // );
        echo json_encode($output);
    }

}
