<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Late_atten_report_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Late_atten_report_model');
        $this->load->library('form_validation');
		$this->load->helper('common_helper');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function late_attendance() {
		$sub_dpt = array();
		$id = $this->session->userdata('loginid');

        $lateattenArr = $this->Late_atten_report_model->late_atten_();
		
        // $cur_month_st = date('n/1/Y');
        // $cur_month_st = date('n/j/Y');
		// $end_date= date("Y-n-j", strtotime("last day of current month"));
		// echo $cur_month_st; die;
		// echo "<pre>"; print_r($lateattenArr); die;
		// $a = array();
		// foreach($lateattenArr as $val):
		// $intime= date("h:i:s A", strtotime(($val->FirstIn)));
            // if((strtotime($intime) > strtotime('09:30:01 AM'))) {
				// echo $val->user_id.'<br>';
				
				// if($val->user_id == $preid):
				// $a[] = $val->user_id;
				// endif;
			// }
			// endforeach;
			// echo "<pre>"; print_r($a); die;
			// die;
		// print_r($_REQUEST); die;
		if (@$_REQUEST['filter']) {
            $selected_month = $_REQUEST['selected_month'];
            $joiningDetailArr = $this->Late_atten_report_model->late_atten_($selected_month);
			// echo "<pre>"; print_r($data['joiningDetailArr']); die;
        } 
        $title = "Late Attendance Report";
        $this->load->view("late_attendance/late_atten_report_view", compact('title','lateattenArr','selected_month'));
    }
}
