<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Team_fun_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Emp_on_leave_tour_report_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function team_under_officers() {
		$id = $this->session->userdata('loginid');
        $data['myTeamDetailsRec'] = count($this->mastermodel->GetMyTeamDetailsRecByID($id));
        $data['myTeamTourDetailsRec'] = count($this->mastermodel->tour_atten_report_ceg1($id));
		$data['myTeamLeaveDetailsRecArr'] = count($this->mastermodel->leave_atten_report_ceg_list($id));
        // echo "<pre>"; print_r(count($data['myTeamTourDetailsRec'])); die;
		
		$myTeamDetailsRec = count($this->mastermodel->GetMyTeamDetailsRecByID($id));
        $myTeamTourDetailsRec = count($this->mastermodel->tour_atten_report_ceg1($id));
		$myTeamLeaveDetailsRecArr = count($this->mastermodel->leave_atten_report_ceg_list($id));
		// $myTeamLeaveDetailsRecArr = $this->mastermodel->leave_atten_report_ceg_list($id);
		$myTeamPresentDetailsRecArr = count($this->mastermodel->count_present_atten_report_ceg_list($id));
		// $myTeamPresentDetailsRecArr = $this->mastermodel->count_present_atten_report_ceg_list($id);
        // echo "<pre>"; print_r($myTeamLeaveDetailsRecArr); die;
		$data['myTeamAbsentDetailsRecArr'] = $myTeamDetailsRec - ($myTeamTourDetailsRec + $myTeamLeaveDetailsRecArr + $myTeamPresentDetailsRecArr);
		// echo "<pre>"; print_r($data['myTeamAbsentDetailsRecArr']); die;
		// echo $myTeamPresentDetailsRecArr; die;
		
        $today = date("Y-m-d");
        $data['title'] = "Teams";

        $this->load->view("Team_functions/Team_functions_view", $data);
    }
	public function team_under_officers_list() {
		$id = $this->session->userdata('loginid');
        $data['myTeamDetailsRecArr'] = $this->mastermodel->GetMyTeamDetailsRecByID($id);
        // echo "<pre>"; print_r($presentEmpLeave); die;
        $today = date("Y-m-d");
        $data['title'] = "Teams";

        $this->load->view("Team_functions/myteam_list_view", $data);
    }
	
	public function tour_under_officers_list() {
		$id = $this->session->userdata('loginid');
		// echo $id; die;
        $data['myTeamTourDetailsRecArr'] = $this->mastermodel->tour_atten_report_ceg1($id);
        // $myTeamTourDetailsRecArr = $this->mastermodel->tour_atten_report_ceg1($id);
        // echo "<pre>"; print_r($data['myTeamTourDetailsRecArr']); die;
        $today = date("Y-m-d");
        $data['title'] = "Tours";

        $this->load->view("Team_functions/myteam_Tour_list_view", $data);
    }
	public function leave_under_officers_list() {
		$id = $this->session->userdata('loginid');
        $data['myTeamLeaveDetailsRecArr'] = $this->mastermodel->leave_atten_report_ceg_list($id);
        // echo "<pre>"; print_r($data['myTeamLeaveDetailsRecArr']); die;
        $today = date("Y-m-d");
        $data['title'] = "Team Emp on Leave";

        $this->load->view("Team_functions/myteam_Leave_list_view", $data);
    }
	
	public function absent_under_officers_list() {
		$id = $this->session->userdata('loginid');
        $myTeamDetailsRec = $this->mastermodel->GetMyTeamDetailsRecByID($id);
        $myTeamTourDetailsRec = $this->mastermodel->tour_atten_report_ceg1($id);
		$myTeamLeaveDetailsRecArr = $this->mastermodel->leave_atten_report_ceg_list($id);
		$myTeamPresentDetailsRecArr = $this->mastermodel->count_present_atten_report_ceg_list($id);
		$test = array();
		// echo "<pre>"; print_r($myTeamDetailsRec); die;
		// foreach($$myTeamDetailsRec as $key => $val):
			// for()
		// endforeach
        $ab = array_merge($myTeamTourDetailsRec,$myTeamLeaveDetailsRecArr);
        $abc = count(array_merge($ab,$myTeamPresentDetailsRecArr));
		// $abcd = array_diff($abc,$myTeamDetailsRec);
		// $result=array_diff($myTeamDetailsRec,$abc);
		// echo "<pre>"; print_r($abc); die;
        $today = date("Y-m-d");
        $data['title'] = "Team Emp on Leave";
		
        $this->load->view("Team_functions/myteam_Leave_list_view", $data);
    }
	
}
