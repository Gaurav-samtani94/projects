<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Education_report_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Educationalreport_model', "educationalreportmodel");
        $this->load->library('form_validation');
        $this->load->helper('common_helper');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function educationalreport() {
        $data['error'] = '';
        $data['title'] = "Educational Report";
        $this->load->view('Educational_report/educationalreport_view', $data);
    }
	
	public function educationalreport_ajax() {
		// echo "test"; die;
        $list = $this->educationalreportmodel->get_datatables();
        // print_r($list); die;
        $data = array();
        $no = $_POST['start'];
        $currdate = date('d-m-Y');
        $CountCegExp = "";

        foreach ($list as $value) {

            $empid = $value->user_id;
//            $eduRecArr1 = $this->cegproj_edulvldetails($empid, '1');
//            $eduRecArr2 = $this->cegproj_edulvldetails($empid, '2');
//            $eduRecArr3 = $this->cegproj_edulvldetails($empid, '3');
//            $eduRecArr4 = $this->cegproj_edulvldetails($empid, '4');
//            $eduRecArr5 = $this->cegproj_edulvldetails($empid, '5');
//            $eduRecArr6 = $this->cegproj_edulvldetails($empid, '6');
//            $eduRecArr7 = $this->cegproj_edulvldetails($empid, '7');

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $value->employeeId;
			if($value->userfullname !='Tbn'){
            $row[] = $value->prefix_name . "&nbsp;" . ucwords($value->userfullname);
			}
			else{
			 $row[]	= '';
			}
            //$row[] = '<a target="_blank" style="color: cornflowerblue;" href="' . base_url('projectplanning/userprofile/' . $value->id) . '">' . $value->userfullname . '<a>';
            $row[] = ucwords($value->position_name);
            $row[] = ucwords($value->department_name);


            $selecteddate = ($value->selecteddate) ? date("d-m-Y", strtotime($value->selecteddate)) : '';
            $diff = abs(strtotime($selecteddate) - strtotime($currdate));
            $years = floor($diff / (365 * 60 * 60 * 24));
            $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
            $CountCegExp = $years . '.' . $months;
            $row[] = $CountCegExp;
            //For Other Exp..
            $row[] = $value->years_exp;


//            $row[] = ($value->educationlevelcode1) ? $value->educationlevelcode1 : '';
//            $row[] = ($value->institution_name1) ? $value->institution_name1 : '';
//            $row[] = ($value->course1) ? $value->course1 : '';
//            $row[] = ($value->spc_location1) ? $value->spc_location1 : '';
//            $row[] = ($value->specialization1) ? $value->specialization1 : '';
//            $row[] = ($value->from_date1) ? $value->from_date1 : '';
//            $row[] = ($value->percentage1) ? $value->percentage1 : '';
//
//            $row[] = ($value->educationlevelcode2) ? $value->educationlevelcode2 : '';
//            $row[] = ($value->institution_name2) ? $value->institution_name2 : '';
//            $row[] = ($value->course2) ? $value->course2 : '';
//            $row[] = ($value->spc_location2) ? $value->spc_location2 : '';
//            $row[] = ($value->specialization2) ? $value->specialization2 : '';
//            $row[] = ($value->from_date2) ? $value->from_date2 : '';
//            $row[] = ($value->percentage2) ? $value->percentage2 : '';

            //$row[] = ($value->educationlevelcode3) ? $value->educationlevelcode3 : '';
            $row[] = ($value->institution_name3) ? $value->institution_name3 : '';
            $row[] = ($value->course3) ? $value->course3 : '';
            $row[] = ($value->spc_location3) ? $value->spc_location3 : '';
            $row[] = ($value->specialization3) ? $value->specialization3 : '';
            $row[] = ($value->from_date3) ? $value->from_date3 : '';
           // $row[] = ($value->percentage3) ? $value->percentage3 : '';

            //$row[] = ($value->educationlevelcode4) ? $value->educationlevelcode4 : '';
            $row[] = ($value->institution_name4) ? $value->institution_name4 : '';
            $row[] = ($value->course4) ? $value->course4 : '';
            $row[] = ($value->spc_location4) ? $value->spc_location4 : '';
            $row[] = ($value->specialization4) ? $value->specialization4 : '';
            $row[] = ($value->from_date4) ? $value->from_date4 : '';
           // $row[] = ($value->percentage4) ? $value->percentage4 : '';

            //$row[] = ($value->educationlevelcode5) ? $value->educationlevelcode5 : '';
            $row[] = ($value->institution_name5) ? $value->institution_name4 : '';
            $row[] = ($value->course5) ? $value->course5 : '';
            $row[] = ($value->spc_location5) ? $value->spc_location5 : '';
            $row[] = ($value->specialization5) ? $value->specialization5 : '';
            $row[] = ($value->from_date5) ? $value->from_date5 : '';
            //$row[] = ($value->percentage5) ? $value->percentage5 : '';

            //$row[] = ($value->educationlevelcode6) ? $value->educationlevelcode6 : '';
           // $row[] = ($value->institution_name6) ? $value->institution_name6 : '';
           // $row[] = ($value->course6) ? $value->course6 : '';
          //  $row[] = ($value->spc_location6) ? $value->spc_location6 : '';
           // $row[] = ($value->specialization6) ? $value->specialization6 : '';
           // $row[] = ($value->from_date6) ? $value->from_date6 : '';
           // $row[] = ($value->percentage6) ? $value->percentage6 : '';

           // $row[] = ($value->educationlevelcode7) ? $value->educationlevelcode7 : '';
           // $row[] = ($value->institution_name7) ? $value->institution_name7 : '';
           // $row[] = ($value->course7) ? $value->course7 : '';
          //  $row[] = ($value->spc_location7) ? $value->spc_location7 : '';
           // $row[] = ($value->specialization7) ? $value->specialization7 : '';
          //  $row[] = ($value->from_date7) ? $value->from_date7 : '';
           // $row[] = ($value->percentage7) ? $value->percentage7 : '';

            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->educationalreportmodel->count_all(),
            "recordsFiltered" => $this->educationalreportmodel->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

}
