<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Emp_sal_Controller_test extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Empsalaryreportdetail_model_test');
        // $this->load->model('Emp_on_leave_tour_report_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
         $permission = GetUserIDHRPermission();
            if (in_array($this->session->userdata('loginid'), $permission)) {
                
            }
            else{
                redirect(base_url(""));
            }
    }

    //26-05-2018 Code For Salary Details...
    public function employee_salarydetails_test() {
        $data['error'] = array();
        $data['title'] = "Employee Salary Details Report";
        $this->load->view('new_report/emp_list_salarydetails_test', $data);

    }
	
   //New Function For Salary 26-05-2018....
    public function ajax_list_empsalarydetails_test() {
        $list = $this->Empsalaryreportdetail_model_test->get_datatables();
        // echo '<pre>';
        // print_r($list);
        // die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = (@$customers->employeeId) ? @$customers->employeeId : '';
            $row[] = (@$customers->userfullname) ? @$customers->userfullname : '';
            $row[] = (@$customers->position_name) ? @$customers->position_name : '';
            $row[] = (@$customers->department_name) ? @$customers->department_name : '';
            $row[] = (@$customers->bankname) ? @$customers->bankname : '';
            $row[] = (@$customers->accountholder_name) ? @$customers->accountholder_name : '';
            $row[] = (@$customers->branchname) ? @$customers->branchname : '';
            $row[] = (@$customers->accountnumber) ? @$customers->accountnumber : '';
            $row[] = (@$customers->payrollcode) ? @$customers->payrollcode : '';
            $row[] = (@$customers->ifsc_code) ? @$customers->ifsc_code : '';
            $row[] = (@$customers->pancard_no) ? @$customers->pancard_no : '';
            $row[] = (@$customers->empctc) ? number_format(@$customers->empctc, 2) : '';
            $row[] = (@$customers->grosssalary) ? number_format(@$customers->grosssalary, 2) : '';
            $row[] = (@$customers->appraisal_datemmyy) ? date("d-m-Y", strtotime(@$customers->appraisal_datemmyy)) : '';
            $row[] = (@$customers->basicsalary) ? number_format(@$customers->basicsalary, 2) : '';
            $row[] = (@$customers->appraisalduedate) ? @$customers->appraisalduedate : '';
			
            // $row[] = (@$customers->emp_hra) ? number_format(@$customers->emp_hra, 2) : '';
            // $row[] = (@$customers->education_allowance) ? number_format(@$customers->education_allowance, 2) : '';
            // $row[] = (@$customers->tele_empsal_allowance) ? number_format(@$customers->tele_empsal_allowance, 2) : '';
            // $row[] = (@$customers->medical_allowance) ? number_format(@$customers->medical_allowance, 2) : '';
            // $row[] = (@$customers->transportation_allowance) ? number_format(@$customers->transportation_allowance, 2) : '';
            // $row[] = (@$customers->special_allowance) ? number_format(@$customers->special_allowance, 2) : '';
            // $row[] = (@$customers->project_allowance) ? number_format(@$customers->project_allowance, 2) : '';
            // $row[] = (@$customers->statutory_deduct) ? number_format(@$customers->statutory_deduct, 2) : '';
            // $row[] = (@$customers->empepf) ? number_format(@$customers->empepf, 2) : '';
            // $row[] = (@$customers->emp_esi) ? number_format(@$customers->emp_esi, 2) : '';
            // $row[] = (@$customers->emp_gratuity) ? number_format(@$customers->emp_gratuity, 2) : '';
            // $row[] = (@$customers->emp_sal_gpai) ? number_format(@$customers->emp_sal_gpai, 2) : '';
            // $row[] = (@$customers->loyaltybonus) ? number_format(@$customers->loyaltybonus, 2) : '';
			
            // $row[] = (@$customers->projectcomp_bonus) ? number_format(@$customers->projectcomp_bonus, 2) : '';
            // $row[] = (@$customers->empctcp1) ? number_format(@$customers->empctcp1, 2) : '';
            // $row[] = (@$customers->empctcp2) ? number_format(@$customers->empctcp2, 2) : '';
            // $row[] = (@$customers->driver_wagers) ? number_format(@$customers->driver_wagers, 2) : '';
            // $row[] = (@$customers->vehicle_agreement) ? number_format(@$customers->vehicle_agreement, 2) : '';
            // $row[] = (@$customers->fuel_expenses) ? number_format(@$customers->fuel_expenses, 2) : '';
            // $row[] = (@$customers->food_expenses) ? number_format(@$customers->food_expenses, 2) : '';
            // $row[] = (@$customers->leave_travel_allowance) ? number_format(@$customers->leave_travel_allowance, 2) : '';
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
			
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            $row[] = "test";
            // $row[] = (@@$customers->sal_other) ? number_format(@$customers->sal_other, 2) : '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Empsalaryreportdetail_model_test->count_all(),
            "recordsFiltered" => $this->Empsalaryreportdetail_model_test->count_filtered(),
            "data" => $data
        );
        echo json_encode($output);
    }
	  

}
