<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Joining_report_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Joining_report_model');
        $this->load->library('form_validation');
        $this->load->helper('common_helper');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function joining_report_data() {
        $sub_dpt = array();
        $id = $this->session->userdata('loginid');
        $joiningDetailArr = $this->Joining_report_model->joining_details_current_month();
        // print_r($_REQUEST); die;
        if (@$_REQUEST['filter']) {

            $from_date = $_REQUEST['from_date'];
            $to_date = $_REQUEST['to_date'];
            $joiningDetailArr = $this->Joining_report_model->joining_details_current_month($from_date, $to_date);
            // echo "<pre>"; print_r($data['joiningDetailArr']); die;
        }
        // echo "<pre>"; print_r($data['joiningDetailArr']); die;
        $title = "Joining Report";
        $this->load->view("joining_report/joning_report_view", compact('title', 'joiningDetailArr', 'from_date', 'to_date'));
    }

}
