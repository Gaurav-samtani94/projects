<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
class Policylist_Controller extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
		$this->load->model('mastermodel');
		if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$this->load->model("Policy_list_model","Policy_list_model");
    }

    public function policy_list(){
		$data['title'] = "Policy List";
		$data['GetAllPolicys'] = $this->Policy_list_model->GetAllPolicys();
		$data['loginid'] = $this->session->userdata('loginid');
		$data['HrPermUserIdsArr'] = GetUserIDHRPermission();
		//echo '<pre>'; print_r($data); echo '</pre>'; die;
		$this->load->view("/company_policy/company_policy_view",$data);	
	}
	
	public function policy_add(){
		$data['title'] = "Add Policy";
		$this->load->view("/company_policy/company_policy_add_view",$data);	
	}
	
	public function ajax_getsinglepolicy_id(){
		$policy_id = $_REQUEST['policy_id'];
        if ($policy_id) {
            $singleRecPolicy = $this->Policy_list_model->GetSinglePolicyDetailsByID($policy_id);
        }
        echo json_encode($singleRecPolicy);
	}
	
	public function policy_insert(){
		//echo '<pre>'; print_r($_REQUEST); echo '</pre>'; die;
		
		$id = $this->session->userdata('loginid');
		$policy_name = ($_REQUEST['policy_name']) ? $_REQUEST['policy_name']: "";
        $policy_desc = ($_REQUEST['policy_desc']) ? $_REQUEST['policy_desc'] : "";
		$business_unit = ($_REQUEST['business_unit']) ? $_REQUEST['business_unit'] : "";
		$dept_id = ($_REQUEST['dept_id']) ? $_REQUEST['dept_id'] : "";
		$projectID = ($_REQUEST['projectID']) ? $_REQUEST['projectID'] : "";
		$start_date = ($_REQUEST['start_date']) ? date('Y-m-d', strtotime($_REQUEST['start_date'])) : "";
		$end_date = date('Y-m-d', strtotime($_REQUEST['end_date']));
		$location = ($_REQUEST['location']) ? $_REQUEST['location'] : "";
		$company_id = ($_REQUEST['company_id']) ? $_REQUEST['company_id'] : "";
		
		$config = array(
			'upload_path' => "public/uploads/policy/",
			'allowed_types' => "gif|jpg|png|jpeg|pdf|doc|docx|xls|xlsx|ppt|pptx|csv",
			'overwrite' => TRUE,
			'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
			'encrypt_name' => FALSE,
        );
		
		$array = explode('.', $_FILES['policy_doc']['name']);
		
		$extension = end($array);
		$new_name = 'policy_'.time().'.'.$extension;
		$config['file_name'] = $new_name;
		$this->load->library('upload', $config);
		
		if($this->upload->do_upload('policy_doc')){
			$data = array(
				'policy_name' => $policy_name,
				'policy_desc' => $policy_desc,
				'policy_doc' => $new_name,
				'business_unit' => $business_unit,
				'dept_id' => $dept_id,
				'projectID' => $projectID,
				'location' => $location,
				'start_date' => $start_date,
				'end_date' => $end_date,
				'company_id' => $company_id,
				'created_by' => $id,  
				'is_active' => "1",  
			);
			$insert_arr = $this->db->insert('policy_master', $data);	
			if ($insert_arr){
				$this->session->set_flashdata('success_msg', 'Policy Added Successfully !');
				redirect(base_url('policy_list'));
			}else{
				$this->session->set_flashdata('error_msg', 'Something went gone wrong');
				redirect(base_url('policy_list'));
			}	
		}else{
			$this->session->set_flashdata('error_msg', 'Document Upload Failed !!');
			redirect(base_url('policy_list'));
		}	
		
		
		
	}
	
	public function policy_delete($policy_id){
		$updateArr = array("is_active" => "0");
        $this->db->where('id',$policy_id);
        $returnResp = $this->db->update('policy_master', $updateArr);
        if ($returnResp):
            $this->session->set_flashdata('success_msg', 'Policy Deleteted Successfully.');
        endif;
        redirect(base_url("policy_list"));
	}
	
	public function policy_update(){
		//echo '<pre>'; print_r($_REQUEST); echo '</pre>';
		//echo '<pre>'; print_r($_FILES['edit_policy_doc']); echo '</pre>'; die;
		
		$policy_id = $_REQUEST['uppolicy_id'];
		$id = $this->session->userdata('loginid');
		$policy_name = $_REQUEST['edit_policy_name'];
        $policy_desc = $_REQUEST['edit_policy_desc'];
		$projectID = $_REQUEST['edit_projectID'];
		$business_unit = $_REQUEST['edit_business_unit'];
		$dept_id = $_REQUEST['edit_dept_id'];
		$location = $_REQUEST['edit_location'];
		$company_id = $_REQUEST['edit_company_id'];
		$start_date = date('Y-m-d', strtotime($_REQUEST['edit_start_date']));
		$end_date =  date('Y-m-d',strtotime($_REQUEST['edit_end_date']));

		$config = array(
			'upload_path' => "public/uploads/policy/",
			'allowed_types' => "gif|jpg|png|jpeg|pdf|doc|docx|xls|xlsx|ppt|pptx|csv",
			'overwrite' => TRUE,
			'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
			'encrypt_name' => FALSE,
        );
		
		$array = explode('.', $_FILES['edit_policy_doc']['name']);
		$extension = end($array);
		$new_name = 'policy__'.time().'.'.$extension;
		$config['file_name'] = $new_name;
		$this->load->library('upload', $config);
		
		if($this->upload->do_upload('edit_policy_doc')){
			$updArr = array(
				'policy_name' => $policy_name,
				'policy_desc' => $policy_desc,
				'policy_doc' => $new_name,
				'business_unit' => $business_unit,
				'dept_id' => $dept_id,
				'projectID' => $projectID,
				'location' => $location,
				'start_date' => $start_date,
				'end_date' => $end_date,
				'company_id' => $company_id,
				'update_by' => $id,  
				'update_date' => date("Y-m-d H:i:s"), 
				'is_active' => "1", 	
			);
			
			$this->db->where(['id' => $policy_id]);
			
            $returnResp = $this->db->update('policy_master',$updArr);
			
			if ($returnResp){
				$this->session->set_flashdata('success_msg', 'Policy Edit/Updated Successfully !');
				redirect(base_url('policy_list'));
			}else{
				$this->session->set_flashdata('error_msg', 'Something went gone wrong');
				redirect(base_url('policy_list'));
			
			}
		}	
		
	}
	
	public function get_dept_name_base_unit(){
		$unit_id = $_REQUEST['unit_id'];
        if ($unit_id) {
            $singleRecdept = $this->Policy_list_model->Getmain_departmentsByID($unit_id);
        }
        echo json_encode($singleRecdept);
	}
	
	
}
