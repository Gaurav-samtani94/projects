<?php

// require_once 'bootstrap.php';
defined('BASEPATH') or exit('No direct script access allowed');
require 'vendor/autoload.php';

class JobsController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('download');

        $this->load->library('session');
        $this->load->model('Mastermodel', 'mastermodel');
        $this->load->model('job/JobsModel');
        $this->load->model('job/InterviewModel');
        $this->db1 = $this->load->database('default', true);
        $this->db2 = $this->load->database('online', true);
        $this->db3 = $this->load->database('accdept_db', true);
        $this->db4 = $this->load->database('cvmanager', true);
        //$this->load->model('job/ConsultancyCompanyModel ');

        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->loginuser_id = $this->session->userdata('loginid');
        if (($this->session->userdata('loginid') == '') or ($this->session->userdata('assign_role') == '')) {
            redirect(base_url(''));
        }
    }

    public function index()
    {
        $data['title'] = 'Jobs List';
        $this->load->view('job/list_jobs', $data);
    }
    public function  ajax_jobs_list()
    {
        $list = $this->JobsModel->get_datatables();
        $data = [];
        $no = $_POST['start'];
        foreach ($list as $temp) {
            ++$no;
            $row = [];
            $row[] = $no;
            $row[] = $temp->title;
            $row[] = $temp->unitname . '(' . $temp->unitcode . ')';
            $row[] = $temp->company_name;
            $row[] = $temp->company_locaation_name;
            $row[] = $temp->country_name;
            $row[] = $temp->state_name;
            $row[] = $temp->positionname;

            $link1 = '&nbsp;<a href="' . base_url("edit_jobs/$temp->id") . '"><i class="fa fa-edit"></i></a>&nbsp;<a href="' . base_url("job_interview?job_id=".$temp->id) . '"><i class="fa fa-list"></i></a>&nbsp;';
            $row[] = $link1;
            $data[] = $row;
        }
        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->JobsModel->count_all(),
            'recordsFiltered' => $this->JobsModel->count_filtered(),
            'data' => $data,
        ];
        echo json_encode($output);
    }
    public function add_jobs()
    {

        $this->form_validation->set_rules('title', 'title', 'trim|required');
        $this->form_validation->set_rules('business_unit_id', 'Business Unit', 'trim|required');
        $this->form_validation->set_rules('position', 'Position', 'trim|required');
        $this->form_validation->set_rules('company_id', 'Company Name', 'trim|required');
        $this->form_validation->set_rules('company_location_id', 'Company Location', 'trim|required');
        $this->form_validation->set_rules('location', 'Location', 'trim|required');
        $this->form_validation->set_rules('country_id', 'Country', 'trim|required');
        $this->form_validation->set_rules('state_id', 'State', 'trim|required');
        $this->form_validation->set_rules('city_id', 'City', 'trim|required');
        $this->form_validation->set_rules('min_experience', 'Min Experience', 'trim|required');
        $this->form_validation->set_rules('max_experience', 'Max Experience', 'trim|required');
        $this->form_validation->set_rules('qualifications', 'Qualifications', 'trim|required');
        $this->form_validation->set_rules('courses', 'Courses', 'trim|required');
        $this->form_validation->set_rules('skills', 'Skills', 'trim|required');
        $this->form_validation->set_rules('employment_type', 'Employment Type', 'trim|required');
        $this->form_validation->set_rules('work_mode', 'Work Mode', 'trim|required');
        $this->form_validation->set_rules('min_annual_salary', 'Min Annual Salary', 'trim|required');
        $this->form_validation->set_rules('max_annual_salary', 'Max Annual Salary', 'trim|required');
        $this->form_validation->set_rules('requirement', 'Requirement', 'trim|required');
        $this->form_validation->set_rules('description', 'Description', 'trim|required');
        if ($this->form_validation->run() == false) {
            $e = $this->form_validation->error_array();
            // print_r($e);
            // die;

            $data['title'] = 'Add Jobs ';
            $data['empList'] = $this->db->get_where('mstr_employment_type', array('status' => '1'))->result_array();

            $this->load->view('job/add_job', $data);
        } else {
            $records = $this->input->post();
            $record_jobs = [];
            $record_jobs['title'] = (!empty($records['title']) ? $records['title'] : null);
            $record_jobs['business_unit_id'] = (!empty($records['business_unit_id']) ? $records['business_unit_id'] : null);
            $record_jobs['company_id'] = (!empty($records['company_id']) ? $records['company_id'] : null);
            $record_jobs['company_location_id'] = (!empty($records['company_location_id']) ? $records['company_location_id'] : null);
            $record_jobs['employment_type'] = (!empty($records['employment_type']) ? $records['employment_type'] : null);
            $record_jobs['work_mode'] = (!empty($records['work_mode']) ? $records['work_mode'] : null);
            $record_jobs['min_experience'] = (!empty($records['min_experience']) ? $records['min_experience'] : null);
            $record_jobs['max_experience'] = (!empty($records['max_experience']) ? $records['max_experience'] : null);
            $record_jobs['country_id'] = (!empty($records['country_id']) ? $records['country_id'] : null);
            $record_jobs['state_id'] = (!empty($records['state_id']) ? $records['state_id'] : null);
            $record_jobs['city_id'] = (!empty($records['city_id']) ? $records['city_id'] : null);
            $record_jobs['location'] = (!empty($records['location']) ? $records['location'] : null);
            $record_jobs['position'] = (!empty($records['position']) ? $records['position'] : null);
            $record_jobs['qualifications'] = (!empty($records['qualifications']) ? $records['qualifications'] : null);
            $record_jobs['courses'] = (!empty($records['courses']) ? $records['courses'] : null);
            $record_jobs['min_annual_salary'] = (!empty($records['min_annual_salary']) ? $records['min_annual_salary'] : null);
            $record_jobs['max_annual_salary'] = (!empty($records['max_annual_salary']) ? $records['max_annual_salary'] : null);
            $record_jobs['skills'] = (!empty($records['skills']) ? $records['skills'] : null);
            $record_jobs['requirement'] = (!empty($records['requirement']) ? $records['requirement'] : null);
            $record_jobs['description'] = (!empty($records['description']) ? $records['description'] : null);
            // echo "<pre>";
            // print_r($record_jobs);die;
            $this->db->insert('jobs', $record_jobs);
            $ins_id = $this->db->insert_id();
            if ($ins_id) {
                //Temp ID Update..
                $this->session->set_flashdata('success_msg', 'Jobs Added Successfully');
                redirect(base_url('jobs'));
            } else {
                $this->session->set_flashdata('error_msg', 'Something Went Wrong !! ');
                redirect(base_url('add_jobs'));
            }
        }
    }
    public function edit_jobs($job_id)
    {
        $this->form_validation->set_rules('title', 'title', 'trim|required');
        $this->form_validation->set_rules('business_unit_id', 'Business Unit', 'trim|required');
        $this->form_validation->set_rules('company_id', 'Company Name', 'trim|required');
        $this->form_validation->set_rules('company_location_id', 'Company Location', 'trim|required');
        $this->form_validation->set_rules('employment_type', 'Employment Type', 'trim|required');
        $this->form_validation->set_rules('work_mode', 'Work Mode', 'trim|required');
        $this->form_validation->set_rules('min_experience', 'Min Experience', 'trim|required');
        $this->form_validation->set_rules('max_experience', 'Max Experience', 'trim|required');
        $this->form_validation->set_rules('country_id', 'Country', 'trim|required');
        $this->form_validation->set_rules('state_id', 'State', 'trim|required');
        $this->form_validation->set_rules('city_id', 'City', 'trim|required');
        $this->form_validation->set_rules('location', 'Location', 'trim|required');
        $this->form_validation->set_rules('position', 'Position', 'trim|required');
        $this->form_validation->set_rules('qualifications', 'Qualifications', 'trim|required');
        $this->form_validation->set_rules('courses', 'Courses', 'trim|required');
        $this->form_validation->set_rules('min_annual_salary', 'Min Annual Salary', 'trim|required');
        $this->form_validation->set_rules('max_annual_salary', 'Max Annual Salary', 'trim|required');
        $this->form_validation->set_rules('skills', 'Skills', 'trim|required');
        $this->form_validation->set_rules('requirement', 'Requirement', 'trim|required');
        $this->form_validation->set_rules('description', 'Description', 'trim|required');
        if ($this->form_validation->run() == false) {
            // $this->form_validation->error_array();
            // epd($job_id);
            $data['title'] = 'Edit Jobs';
            $data['empList'] = $this->db->get_where('mstr_employment_type', array('status' => '1'))->result_array();
            $data['job_record'] = $this->db->get_where('jobs', ['id' => $job_id])->row_array();
            // epd($data['job_record']);
            $this->load->view('job/edit_job', $data);
        } else {
            $records = $this->input->post();
            $record_jobs = [];
            $record_jobs['title'] = (!empty($records['title']) ? $records['title'] : null);
            $record_jobs['business_unit_id'] = (!empty($records['business_unit_id']) ? $records['business_unit_id'] : null);
            $record_jobs['company_id'] = (!empty($records['company_id']) ? $records['company_id'] : null);
            $record_jobs['company_location_id'] = (!empty($records['company_location_id']) ? $records['company_location_id'] : null);
            $record_jobs['employment_type'] = (!empty($records['employment_type']) ? $records['employment_type'] : null);
            $record_jobs['work_mode'] = (!empty($records['work_mode']) ? $records['work_mode'] : null);
            $record_jobs['min_experience'] = (!empty($records['min_experience']) ? $records['min_experience'] : null);
            $record_jobs['max_experience'] = (!empty($records['max_experience']) ? $records['max_experience'] : null);
            $record_jobs['country_id'] = (!empty($records['country_id']) ? $records['country_id'] : null);
            $record_jobs['state_id'] = (!empty($records['state_id']) ? $records['state_id'] : null);
            $record_jobs['city_id'] = (!empty($records['city_id']) ? $records['city_id'] : null);
            $record_jobs['location'] = (!empty($records['location']) ? $records['location'] : null);
            $record_jobs['position'] = (!empty($records['position']) ? $records['position'] : null);
            $record_jobs['qualifications'] = (!empty($records['qualifications']) ? $records['qualifications'] : null);
            $record_jobs['courses'] = (!empty($records['courses']) ? $records['courses'] : null);
            $record_jobs['min_annual_salary'] = (!empty($records['min_annual_salary']) ? $records['min_annual_salary'] : null);
            $record_jobs['max_annual_salary'] = (!empty($records['max_annual_salary']) ? $records['max_annual_salary'] : null);
            $record_jobs['skills'] = (!empty($records['skills']) ? $records['skills'] : null);
            $record_jobs['requirement'] = (!empty($records['requirement']) ? $records['requirement'] : null);
            $record_jobs['description'] = (!empty($records['description']) ? $records['description'] : null);
            $this->db->where('id', $job_id);
            $this->db->update('jobs', $record_jobs);
            $this->session->set_flashdata('success_msg', 'Jobs updated Successfully');
            redirect(base_url('edit_jobs/' . $job_id));
        }
    }

    //  -------------------------------------------  Job Interview   -------------------------------------------  //

    public function list_interview()
    {
        $job_id = $this->input->get('job_id');
        if(!empty($job_id)){
            $job_record = $this->db->get_where('job_interview',['job_id'=>$job_id,'status'=>1])->row();
            if(empty($job_record)){
                redirect(base_url('job_interview'));
            }
        }
        $data['job_id'] = $job_id;
        $data['title'] = 'Job Interview';
        

        $data['getEmpList'] = $this->db->get_where('main_users', array('isactive' => '1', 'id!=' => '1'))->result_array();
        $this->load->view('job/list_interview', $data);
    }

    public function add_interview()
    {
        // Form validation rules
        $this->form_validation->set_rules('job_id', 'Jobs', 'trim|required');
        
        $this->form_validation->set_rules('types', 'Types', 'trim|required');

        // Check if 'types' is '1' (Consultancy) or '2' (Reference) to set validation rules accordingly
        if ($this->input->post('types') == '1') {
            $this->form_validation->set_rules('consultancy_company_id', 'Consultancy Company', 'trim|required');
        } elseif ($this->input->post('types') == '2') {
            $this->form_validation->set_rules('reference_id', 'Reference', 'trim|required');
        }

        $this->form_validation->set_rules('prefix', 'Prefix', 'trim|required');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('dob', 'DOB', 'trim|required');
        // $this->form_validation->set_rules('userfullname', 'User Name', 'trim|required');
        $this->form_validation->set_rules('contact', 'Contact', 'trim|required');
        $this->form_validation->set_rules('email_id', 'Email', 'trim|required|valid_email|is_unique[job_interview.email_id]');
        $this->form_validation->set_rules('country_id', 'Country', 'trim|required');
        $this->form_validation->set_rules('state_id', 'State', 'trim|required');
        $this->form_validation->set_rules('city_id', 'City', 'trim|required');
        $this->form_validation->set_rules('pincode', 'Pincode', 'trim|required');
        $this->form_validation->set_rules('address', 'Address', 'trim|required');
        // $this->form_validation->set_rules('interview_round', 'Interview Round', 'trim|required');
        $this->form_validation->set_rules('total_exp', 'Total Experience', 'trim|required');
        $this->form_validation->set_rules('qualification_id[]', 'Qualification', 'trim|required'); 


        if ($this->form_validation->run() == FALSE) {
            $data['title'] = 'Add Job Interview';
            $data['getJobList'] = $this->db->get_where('jobs', array('status' => '1'))->result_array();
            $data['getCompList'] = $this->db->get_where('consultancy_company_job', array('status' => '1'))->result_array();
            $data['getPrefixList'] = $this->db->get_where('main_prefix', array('isactive' => '1'))->result_array();
            $data['getRefList'] = $this->db->get_where('main_users', array('isactive' => '1', 'id!=' => '1'))->result_array();
            $data['getQualification'] = $this->db->get_where('main_educationlevelcode', array('isactive' => '1'))->result_array();
            $lastId = $this->getLastInterviewId();
            $nextId = ($lastId) ? ++$lastId : '001';
            $data['inter_emp_id'] = 'INTEMP' . str_pad($nextId, 3, '0', STR_PAD_LEFT);
            $this->load->view('job/add_interview', $data);
        } else {

            
            $original_filename= $_FILES['cv_document']['name'];
            
            if($original_filename != ''){
                //epd($_FILES['cv_document']);

                $docs_filename = '';
                $config = array(
                    'upload_path' => "public/uploads/job_interview_doc/",
                    'allowed_types' => "pdf|docx",
                    'overwrite' => TRUE,
                    'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
                    'encrypt_name' => FALSE,
                );
            
                $array = explode('.', $_FILES['cv_document']['name']);
                $extension = end($array);
                $new_name = 'cv_'.time().'.'.$extension;
                $config['file_name'] = $new_name;

                $this->load->library('upload', $config);
                
                if($this->upload->do_upload('cv_document')){
                    
                    $docs_filename = $new_name;
                }  else {
                    $msg = 'image not upload';
                }
                
                // Form validation passed, process your form data here
                $userfullname = trim($this->input->post('first_name') . ' ' . $this->input->post('middle_name') . ' ' . $this->input->post('last_name'));

                $params = array(
                    'job_id' => $this->input->post('job_id'),
                    'inter_emp_id' => $this->input->post('inter_emp_id'),
                    'types' => $this->input->post('types'),
                    'consultancy_company_id' => $this->input->post('consultancy_company_id') ? $this->input->post('consultancy_company_id') : NULL,
                    'emp_reference_id' => $this->input->post('reference_id') ? $this->input->post('reference_id') : NULL,
                    'prefix' => $this->input->post('prefix'),
                    'first_name' => $this->input->post('first_name'),
                    'middle_name' => $this->input->post('middle_name'),
                    'last_name' => $this->input->post('last_name'),
                    'dob' => $this->input->post('dob'),
                    'userfullname' => $userfullname,
                    'contact' => $this->input->post('contact'),
                    'email_id' => $this->input->post('email_id'),
                    'country_id' => $this->input->post('country_id'),
                    'state_id' => $this->input->post('state_id'),
                    'city_id' => $this->input->post('city_id'),
                    'pincode' => $this->input->post('pincode'),
                    'address' => $this->input->post('address'),
                    'cv_document' => $docs_filename,
                    // 'interview_round' => $this->input->post('interview_round'),
                    'total_exp' => $this->input->post('total_exp'),
                    'qualification_id' => implode(',', $this->input->post('qualification_id')),
                    'created_by' => $this->session->userdata('loginid'),
                );
            
                
                $this->db->insert('job_interview', $params);
                $ins_id = $this->db->insert_id();

                if ($ins_id) {
                    // Loop through qualification details and insert into 'qualification_job' table
                    $qualificationDetails = $this->input->post('qualification_details');
                    if (!empty($qualificationDetails)) {
                        foreach ($qualificationDetails as $optionId => $qualification) {
                            $qualificationParams = array(
                                'interview_id' => $ins_id,
                                'qualification_id' => $qualification['qualification_id'],
                                'year_passing' => $qualification['year_of_passing'],
                                'marks_grade' => $qualification['marks_grade'],
                                'main_subject' => $qualification['stream_subject'],
                                'institution_name' => $qualification['institution'],
                                'place' => $qualification['place'],
                                'created_by' => $this->session->userdata('loginid'),
                                'education_type' => $qualification['regular_correspondence']
                            );
                            
                            $this->db->insert('qualification_job', $qualificationParams);
                        }
                    }
                    // Redirect to a success page
                    $this->session->set_flashdata('success_msg', 'Job Interview Added Successfully');
                    redirect(base_url('job_interview'));
                } else {
                    // If insertion into 'job_interview' fails, redirect with error message
                    $this->session->set_flashdata('error_msg', 'Something Went Wrong !! ');
                    redirect(base_url('add_job_interview'));
                }
            } else {
                $this->session->set_flashdata('error_msg', 'Cv  Not Upload ');
                redirect(base_url('add_job_interview'));
            }
            
        }
    }

    public function edit_interview($interview_id)
    {
        // Form validation rules
        $this->form_validation->set_rules('job_id', 'Jobs', 'trim|required');
        $this->form_validation->set_rules('types', 'Types', 'trim|required');

        // Check if 'types' is '1' (Consultancy) or '2' (Reference) to set validation rules accordingly
        if ($this->input->post('types') == '1') {
            $this->form_validation->set_rules('consultancy_company_id', 'Consultancy Company', 'trim|required');
        } elseif ($this->input->post('types') == '2') {
            $this->form_validation->set_rules('reference_id', 'Reference', 'trim|required');
        }

        $this->form_validation->set_rules('prefix', 'Prefix', 'trim|required');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required');
        $this->form_validation->set_rules('dob', 'DOB', 'trim|required');
        $this->form_validation->set_rules('contact', 'Contact', 'trim|required');
        $this->form_validation->set_rules('email_id', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('country_id', 'Country', 'trim|required');
        $this->form_validation->set_rules('state_id', 'State', 'trim|required');
        $this->form_validation->set_rules('city_id', 'City', 'trim|required');
        $this->form_validation->set_rules('pincode', 'Pincode', 'trim|required');
        $this->form_validation->set_rules('address', 'Address', 'trim|required');
        $this->form_validation->set_rules('total_exp', 'Total Experience', 'trim|required');
        $this->form_validation->set_rules('qualification_id[]', 'Qualification', 'trim|required');
        $intreviewRecord = $this->db->get_where('job_interview', array('id' => $interview_id))->row_array();
        if ($this->form_validation->run() == FALSE) {
            // Form validation failed, load the edit view again
            //epd($intreviewRecord);
            $data['title'] = 'Edit Job Interview';
            $data['getJobList'] = $this->db->get_where('jobs', array('status' => '1'))->result_array();
            $data['getCompList'] = $this->db->get_where('consultancy_company_job', array('status' => '1'))->result_array();
            $data['getPrefixList'] = $this->db->get_where('main_prefix', array('isactive' => '1'))->result_array();
            $data['getRefList'] = $this->db->get_where('main_users', array('isactive' => '1', 'id !=' => '1'))->result_array();
            $data['edit_int'] = $intreviewRecord;
            $data['getQualification'] = $this->db->get_where('main_educationlevelcode', array('isactive' => '1'))->result_array();
            // Load qualification details for the selected interview
            $data['qualification_details'] = $this->db->get_where('qualification_job', array('interview_id' => $interview_id))->result_array();
           // epd($data['qualification_details']);
            $data['getState'] = $this->db->get_where('tbl_states', array('isactive' => '1'))->result_array();
            $data['getCity'] = $this->db->get_where('tbl_cities', array('is_active' => '1'))->result_array();

            // Prepare the qualification details table HTML
            /*
            $qualification_details_table = '';
            if (!empty($data['qualification_details'])) {
                foreach ($data['qualification_details'] as $detail) {
                    $qualification_details_table .= '<tr>' .
                        '<td>' . $detail['qualification_id'] . '</td>' .
                        '<td><input type="text" name="qualification_details[' . $detail['id'] . '][year_of_passing]" class="form-control" value="' . $detail['year_passing'] . '"></td>' .
                        '<td><input type="text" name="qualification_details[' . $detail['id'] . '][marks_grade]" class="form-control" value="' . $detail['marks_grade'] . '"></td>' .
                        '<td><input type="text" name="qualification_details[' . $detail['id'] . '][stream_subject]" class="form-control" value="' . $detail['main_subject'] . '"></td>' .
                        '<td><input type="text" name="qualification_details[' . $detail['id'] . '][institution]" class="form-control" value="' . $detail['institution_name'] . '"></td>' .
                        '<td><input type="text" name="qualification_details[' . $detail['id'] . '][place]" class="form-control" value="' . $detail['place'] . '"></td>' .
                        '<td><input type="text" name="qualification_details[' . $detail['id'] . '][regular_correspondence]" class="form-control" value="' . $detail['eduction_type'] . '"></td>' .
                        '</tr>';
                }
            } */
            //$data['qualification_details_table'] = $qualification_details_table;

            $this->load->view('job/edit_interview', $data);
        } else {
            $original_filename= $_FILES['cv_document']['name'];
            $docs_filename = (!empty($intreviewRecord->cv_document)? $intreviewRecord->cv_document:null);
            if($original_filename != ''){
                //epd($_FILES['cv_document']);
                $config = array(
                    'upload_path' => "public/uploads/job_interview_doc/",
                    'allowed_types' => "pdf",
                    'overwrite' => TRUE,
                    'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
                    'encrypt_name' => FALSE,
                );
            
                $array = explode('.', $_FILES['cv_document']['name']);
                $extension = end($array);
                $new_name = 'cv_'.time().'.'.$extension;
                $config['file_name'] = $new_name;

                $this->load->library('upload', $config);
                
                if($this->upload->do_upload('cv_document')){
                    
                    $docs_filename = $new_name;
                }  else {
                    $msg = 'image not upload';
                }
            }
            $qualificationArr = implode(',',$this->input->post('qualification_id'));
           // epd($qualificationArr);
            // Form validation passed, process your form data here
            $userfullname = trim($this->input->post('first_name') . ' ' . $this->input->post('middle_name') . ' ' . $this->input->post('last_name'));

            $params = array(
                'job_id' => $this->input->post('job_id'),
                'inter_emp_id' => $this->input->post('inter_emp_id'),
                'types' => $this->input->post('types'),
                'consultancy_company_id' => $this->input->post('consultancy_company_id') ? $this->input->post('consultancy_company_id') : NULL,
                'emp_reference_id' => $this->input->post('reference_id') ? $this->input->post('reference_id') : NULL,
                'prefix' => $this->input->post('prefix'),
                'first_name' => $this->input->post('first_name'),
                'middle_name' => $this->input->post('middle_name'),
                'last_name' => $this->input->post('last_name'),
                'dob' => date('Y-m-d', strtotime($this->input->post('dob'))),
                'userfullname' => $userfullname,
                'contact' => $this->input->post('contact'),
                'email_id' => $this->input->post('email_id'),
                'country_id' => $this->input->post('country_id'),
                'state_id' => $this->input->post('state_id'),
                'city_id' => $this->input->post('city_id'),
                'pincode' => $this->input->post('pincode'),
                'address' => $this->input->post('address'),
                'cv_document' => $docs_filename,
                'total_exp' => $this->input->post('total_exp'),
                'qualification_id' => $qualificationArr,
                'modefied_by' => $this->session->userdata('loginid'),
            );
           // epd($params);

            // Update job_interview table
            $this->db->where('id', $interview_id);
            $this->db->update('job_interview', $params);

            // Update or delete qualification_job records based on submitted data
            $qualification_details_post = $this->input->post('qualification_details');
            //epd($qualification_details_post);
            // Handle deletion of qualification_job records for deleted qualifications
            // Fetch existing qualification_job records
            //$existing_qualifications = $this->db->get_where('qualification_job', array('interview_id' => $interview_id))->result_array();

            // Determine deleted qualification IDs
            //$submitted_qualifications = array_keys($qualification_details_post);
            //$existing_qualification_ids = array_column($existing_qualifications, 'fld_id');
            //$deleted_qualifications = array_diff($existing_qualification_ids, $submitted_qualifications);

            // Delete qualification_job records for deleted qualifications
            

            // Update or insert qualification_job records for submitted qualifications
            if (!empty($qualification_details_post)) {
                $this->db->where('interview_id', $interview_id);
                $this->db->delete('qualification_job');
                foreach ($qualification_details_post as $qual_id => $qual_details) {
                    $qual_params = array(
                        'interview_id' => $interview_id,
                        'qualification_id' => $qual_details['qualification_id'],
                        'year_passing' => $qual_details['year_of_passing'],
                        'marks_grade' => $qual_details['marks_grade'],
                        'main_subject' => $qual_details['stream_subject'],
                        'institution_name' => $qual_details['institution'],
                        'place' => $qual_details['place'],
                        'education_type' => $qual_details['regular_correspondence'],
                        'created_by' => $this->session->userdata('loginid')
                    );
                    $this->db->insert('qualification_job', $qual_params);
                    /*
                    // Check if this is an update or insert operation
                    if (in_array($qual_id, $existing_qualification_ids)) {
                        // Update existing qualification_job record
                        $this->db->where('fld_id', $qual_id);
                        $this->db->where('interview_id', $interview_id);
                        $this->db->update('qualification_job', $qual_params);
                    } else {
                        // Insert new qualification_job record
                        $this->db->insert('qualification_job', $qual_params);
                    } */
                }
            }

            $this->session->set_flashdata('success_msg', 'Job Interview Updated Successfully');
            redirect(base_url('job_interview'));
        }
    }

    public function update_interview_round()
    {
        $this->form_validation->set_rules('interview_round', 'Interview Round', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            $errors = array(
                'interview_round' => strip_tags(form_error('interview_round'))
            );
            echo json_encode(['status' => 'error', 'message' => $errors['interview_round']]);
        } else {
            $interview_id = $this->input->post('interview_id');
            $interview_round = $this->input->post('interview_round');

            $data = array(
                'interview_round' => $interview_round
            );
            $this->db->where('id', $interview_id);
            $this->db->update('job_interview', $data);

            if ($this->db->affected_rows() > 0) {
                echo json_encode(array('status' => 'success', 'message' => 'Interview Round updated successfully!', 'interview_round' => $interview_round));
            } else {
                echo json_encode(array('status' => 'error', 'message' => 'Failed to update Interview Round.'));
            }
        }
    }

    public function update_selection_decision()
    {
        $this->form_validation->set_rules('interview_id', 'Interview Round', 'trim|required');
        $this->form_validation->set_rules('selection_decision', 'Selection Decision', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            $errors = array(
                'interview_id' => form_error('interview_id'),
                'selection_decision' => form_error('selection_decision')
            );
            echo json_encode(['status' => 'error', 'message' => $errors]);
        } else {
            $interview_id = $this->input->post('interview_id');
            $selection_decision = $this->input->post('selection_decision');

            $data = array(
                'selection_decision' => $selection_decision
            );
            $this->db->where('id', $interview_id);
            $this->db->update('job_interview', $data);
            $selectionData = [];
            $selectionData['status'] = 'success';
            $selectionData['message'] = 'Interview Selection Decision updated successfully!';
            if($selection_decision == '4'){
                $selectionData['url'] = base_url('addletter?interview_id='.$interview_id);
            } else {
                $selectionData['url'] = '';
            }
                echo json_encode($selectionData);
            
        }
    }

    public function fetch_interview_round()
    {
        $interview_id = $this->input->post('interview_id');

        // Fetch the current round number
        $results = $this->db->get_where('job_interview_round', array('interview_id' => $interview_id))->result();
        $round = 1;
        if(!empty($results)){
            foreach ($results as $key => $result) {
                if (empty($result)) {
                    $round = 1;
                } else if (!empty($result) && ($result->round_status == 1) &&  ($result->direct_selected == 1)){
                    $round = 0;
                } else if (!empty($result) && ($result->round_status == 1) &&  ($result->direct_selected == 0)){
                    $round = 0;
                } else {
                    $round = $result->round + 1;
                }
            }
        }
        

        // Fetch existing rounds and interviewer details
        $this->db->select('job_interview_round.round, job_interview_round.interviewers_id, job_interview_round.interviewer_accept, main_users.userfullname');
        $this->db->from('job_interview_round');
        $this->db->join('main_users', 'job_interview_round.interviewers_id = main_users.id', 'left');
        $this->db->where('job_interview_round.interview_id', $interview_id);
        $this->db->order_by('job_interview_round.id', 'ASC');
        $existing_rounds = $this->db->get()->result();

        // Determine if the form should be shown based on existing rounds
        $interviewerAccept = $this->db->get_where('job_interview', array('id' => $interview_id))->row();
        $showForm = true;
        foreach ($existing_rounds as $round_data) {
            if ($round_data->round == $interviewerAccept->interview_round) {
                $showForm = false;
                break;
            }
        }

        // Prepare response with necessary data
        $response = [
            'success' => true,
            'round' => $round,
            'existing_rounds' => $existing_rounds,
            'showForm' => $showForm
        ];

        echo json_encode($response);
    }

    public function add_interview_round()
    {
        $this->form_validation->set_rules('round', 'Interview Round', 'trim|required');
        $this->form_validation->set_rules('interviewers_id', 'Interviewer Name', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            $errors = [
                'round' => strip_tags(form_error('round')),
                'interviewers_id' => strip_tags(form_error('interviewers_id'))
            ];

            echo json_encode(['success' => false, 'errors' => $errors]);
        } else {
            $data = [
                'interview_id' => $this->input->post('interview_id'),
                'round' => $this->input->post('round'),
                'interviewers_id' => $this->input->post('interviewers_id')
            ];

            $this->db->insert('job_interview_round', $data);
            $round_id = $this->db->insert_id();

            if ($this->db->affected_rows() > 0) {
                // Fetch email address of the selected interviewer
                $interviewer_id = $this->input->post('interviewers_id');
                $interviewer = $this->db->get_where('main_users', ['id' => $interviewer_id])->row();

                if ($interviewer) {
                    $email = $interviewer->emailaddress;
                    //$email = 'ttttttt@mailinator.com';

                    $subject = "Interview Invitation";
                    $message = "Hello {$interviewer->userfullname},<br><br>";
                    $message .= "We hope this message finds you well.<br><br>";
                    $message .= "We are pleased to inform you that you have been selected to participate as an interviewer for an upcoming interview round. Your expertise and insights are invaluable as we evaluate candidates for this critical position.<br><br>";
                    $message .= "Please take a moment to review the details and confirm your availability by clicking one of the links below:<br><br>";
                    $message .= "<a href='" . base_url('accept_link') . "?round_id={$round_id}' style='text-decoration: none; padding: 10px 20px; background-color: #4CAF50; color: white; border-radius: 5px;'>Accept</a> ";
                    $message .= "<a href='" . base_url('reject_link') . "?round_id={$round_id}' style='text-decoration: none; padding: 10px 20px; background-color: #f44336; color: white; border-radius: 5px;'>Reject</a><br><br>";
                    $message .= "Your prompt response would be greatly appreciated.<br><br>";
                    $message .= "Best regards,<br>";
                    $message .= "CEG India<br>";
                    $message .= "HR Department";

                    $this->send_welcomeMail($email, $subject, $message);

                    $this->db->where('id', $round_id)->update('job_interview_round', ['interviewer_accept' => 0]);

                    echo json_encode(['success' => true]);
                } else {
                    echo json_encode(['success' => false, 'errors' => 'Failed to fetch interviewer details.']);
                }
            } else {
                echo json_encode(['success' => false, 'errors' => 'Failed to insert interview round.']);
            }
        }
    }

    private function send_welcomeMail($to, $subject, $msgDetails)
    {
        $ci = &get_instance();
        $ci->load->library('email');
        $ci->email->initialize(array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => true,
        ));
        $ci->email->from('marketing@cegindia.com', 'Do_not_reply');
        $ci->email->to($to);
        $ci->email->bcc('marketing@cegindia.com');
        $ci->email->subject($subject);
        $ci->email->message($msgDetails);
        $resp = $ci->email->send();
        return ($resp) ? $resp : $ci->email->print_debugger();
    }

    private function getLastInterviewId()
    {
        $this->db->select('inter_emp_id');
        $this->db->from('job_interview');
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        $query = $this->db->get();
        $result = $query->row();

        if ($result) {
            $lastId = intval(substr($result->inter_emp_id, 6));
            return $lastId;
        } else {
            return false;
        }
    }


    public function interview_ajax_listing()
    {
        $list = $this->InterviewModel->get_datatables();
        $data = [];
        $no = $_POST['start'];
        foreach ($list as $temp) {
            ++$no;
            $row = [];
            $row[] = $no;
            $row[] = $temp->title;
            $row[] = $temp->prefix . ' ' . $temp->first_name . ' ' . $temp->middle_name . ' ' . $temp->last_name;
            $row[] = $temp->contact;
            $row[] = $temp->email_id;

            // Interview round button
            $interviewRoundButton = !empty($temp->interview_round)
                ? "<a href='#' class='btn btn-secondary btn-sm' data-toggle='modal' data-target='#interviewModal' data-interview-round='" . $temp->id . "'>" . $temp->interview_round . "</a>"
                : "<a href='#' class='btn btn-primary btn-sm' data-toggle='modal' data-target='#interviewModal' data-interview-round='" . $temp->id . "'>0</a>";

            $row[] = $interviewRoundButton;

            if (!empty($temp->cv_document)) {
                $row[] = '<a href="' . RESUME . $temp->cv_document . '" target="_blank">View Resume</a>';
            } else {
                $row[] = '<a href="javascript:void(0)">-</a>';
            }

            if(!empty($temp->interview_round_status) && ($temp->interview_round_status == 1)){
                if(!empty($temp->selection_decision)){
                    if($temp->selection_decision == '1'){
                        $row[] = 'Not Suitable';
                    } else if($temp->selection_decision == '2'){
                        $row[] = 'Reserve in databank';
                    } else if($temp->selection_decision == '3'){
                        $row[] = 'Referred to other dept';
                    } else if($temp->selection_decision == '4'){
                        $row[] = 'suitable';
                    }
                    
                } else {
                    $row[] = "<a href='javascript:void(0);' class='btn btn-success selectionDecision' data-interview_id='" . $temp->id . "'>Selection Decision</a>";
                }
            } else {
                $row[] = '-';
            }

            // Edit and manage interview rounds links
            $editLink = '<a href="' . base_url("edit_job_interview/{$temp->id}") . '"><i class="fa fa-edit"></i></a>';
            $manageRoundsLink = '';

            // Check if interview round is within 1 to 3 to enable manageInterviewRoundsModal link
            if ($temp->interview_round >= 1 && $temp->interview_round <= 3) {
                $manageRoundsLink = '<a href="#" data-toggle="modal" data-target="#manageInterviewRoundsModal" data-interview-id="' . $temp->id . '"><i class="fa fa-users"></i></a>';
            } else {
                $manageRoundsLink = '<a href="javascript:void(0)"><i class="fa fa-users"></i></a>';
            }

            $row[] = '&nbsp;' . $editLink . '&nbsp;&nbsp;' . $manageRoundsLink . '&nbsp;';

            $data[] = $row;
        }
        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->InterviewModel->count_all(),
            'recordsFiltered' => $this->InterviewModel->count_filtered(),
            'data' => $data,
        ];
        echo json_encode($output);
    }
    
    public function interview_cvm_ajax_listing()
    {
        $this->load->model('job/InterviewCVMModel');
        $list = $this->InterviewCVMModel->get_datatables();
       // epd($list);
        $data = [];
        $no = $_POST['start'];
        foreach ($list as $temp) {
            ++$no;
            if($temp->interview_type == 'cv'){
                $temp->interviewTypes = 'Candidate';
                $temp->title = $this->pojectionname($temp->interview_type,$temp->cv_id);
                $Recordsjobs = $this->pojectionalldata($temp->interview_type,$temp->cv_id);
                $temp->emailaddress = (!empty($Recordsjobs->email)? $Recordsjobs->email:'');
                $temp->fname = (!empty($Recordsjobs->fname)? $Recordsjobs->fname:'');
                $temp->mname = (!empty($Recordsjobs->mname)? $Recordsjobs->mname:'');
                $temp->lname = (!empty($Recordsjobs->lname)? $Recordsjobs->lname:'');
                $temp->dob = (!empty($Recordsjobs->dob)? $Recordsjobs->dob:'');
                $temp->phone = (!empty($Recordsjobs->phone)? $Recordsjobs->phone:'');
                $temp->gender = (!empty($Recordsjobs->gender)? $Recordsjobs->gender:'');
                $temp->fathername = (!empty($Recordsjobs->fathername)? $Recordsjobs->fathername:'');
                $temp->mothername = (!empty($Recordsjobs->mothername)? $Recordsjobs->mothername:'');
                $temp->aadharno = (!empty($Recordsjobs->aadharno)? $Recordsjobs->aadharno:'');
                $temp->panno = (!empty($Recordsjobs->panno)? $Recordsjobs->panno:'');
                $temp->onlinesource = (!empty($Recordsjobs->onlinesource)? $Recordsjobs->onlinesource:'');
                $temp->filename = (!empty($Recordsjobs->filename)? $Recordsjobs->filename:'');
                //epd($temp);
            } else if($temp->interview_type == 'new'){
                $temp->interviewTypes = 'Job Seeker';
                $temp->title = $this->pojectionname($temp->interview_type,$temp->job_seeker_id);
                $Recordsjobs = $this->pojectionalldata($temp->interview_type,$temp->job_seeker_id);
                $temp->emailaddress = (!empty($Recordsjobs->email)? $Recordsjobs->email:'');
                $temp->fname = (!empty($Recordsjobs->first_name)? $Recordsjobs->first_name:'');
                $temp->mname = (!empty($Recordsjobs->middle_name)? $Recordsjobs->middle_name:'');
                $temp->lname = (!empty($Recordsjobs->last_name)? $Recordsjobs->last_name:'');
                $temp->dob = (!empty($Recordsjobs->dob)? $Recordsjobs->dob:'');
                $temp->phone = (!empty($Recordsjobs->phone)? $Recordsjobs->phone:'');
                $temp->gender = '';
                $temp->fathername = '';
                $temp->mothername = '';
                $temp->aadharno = '';
                $temp->panno = '';
                $temp->onlinesource = '';
                $temp->filename = (!empty($Recordsjobs->resume)? $Recordsjobs->resume:'');
            } else {
                $temp->interviewTypes = 'Job Post';
                $temp->title = $this->pojectionname($temp->interview_type,$temp->cvm_job_id);
                $Recordsjobs = $this->pojectionalldata($temp->interview_type,$temp->cvm_job_id,$temp->jobpost_application_id);
                $temp->emailaddress = (!empty($Recordsjobs->email)? $Recordsjobs->email:'');
                $temp->fname = (!empty($Recordsjobs->fname)? $Recordsjobs->fname:'');
                $temp->mname = (!empty($Recordsjobs->mname)? $Recordsjobs->mname:'');
                $temp->lname = (!empty($Recordsjobs->lname)? $Recordsjobs->lname:'');
                $temp->dob = (!empty($Recordsjobs->dob)? $Recordsjobs->dob:'');
                $temp->phone = (!empty($Recordsjobs->phone)? $Recordsjobs->phone:'');
                $temp->gender = (!empty($Recordsjobs->gender)? $Recordsjobs->gender:'');
                $temp->fathername = (!empty($Recordsjobs->fathername)? $Recordsjobs->fathername:'');
                $temp->mothername = (!empty($Recordsjobs->mothername)? $Recordsjobs->mothername:'');
                $temp->aadharno = (!empty($Recordsjobs->aadharno)? $Recordsjobs->aadharno:'');
                $temp->panno = (!empty($Recordsjobs->panno)? $Recordsjobs->panno:'');
                $temp->onlinesource = (!empty($Recordsjobs->onlinesource)? $Recordsjobs->onlinesource:'');
                $temp->filename = (!empty($Recordsjobs->filename)? $Recordsjobs->filename:'');
            }
            $row = [];
            $row[] = $no;
            $row[] = $temp->title;
            $row[] = $temp->interviewTypes;
            $row[] = $temp->fname . ' ' . $temp->mname . ' ' . $temp->last_nlnameame;
            $row[] = $temp->phone;
            $row[] = $temp->emailaddress;
            $row[] = $temp->interview_round;
            $row[] = $temp->salary;

           

           

            if(!empty($temp->interview_round_status) && ($temp->interview_round_status == 1)){
                if(!empty($temp->selection_decision)){
                   if($temp->selection_decision == '4'){
                        $row[] = 'suitable';
                    }
                } else {
                    $row[] = "-";
                }
            } else {
                $row[] = '-';
            }

            // Edit and manage interview rounds links
            $editLink = '<a target="_blank" href="' . base_url("addletter?cvm_interview_id=".$temp->id) . '"><i class="fa fa-edit"></i></a>';
            

            $row[] = '&nbsp;' . $editLink .'&nbsp;';

            $data[] = $row;
        }
        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->InterviewCVMModel->count_all(),
            'recordsFiltered' => $this->InterviewCVMModel->count_filtered(),
            'data' => $data,
        ];
        echo json_encode($output);
    }
    
    public function list_interview_cvm()
    {
        $data['title'] = 'Interview CVM';
        $this->load->view('job/list_interview_cvm', $data);
    }

    private function  pojectionname($types,$job_ids){
        
        $db4 = $this->db4->database;
        if($types == 'cv'){
            $records =$this->db->from("$db4.tblcv as a")->select('a.*')->where('a.id',$job_ids)->get()->row();
            return  $records->fname.' '.$records->mname.' '.$records->lname;
        } else if($types == 'new'){
            $records = $this->db->from("$db4.job_seeker as a")->select('a.*')->where('a.id',$job_ids)->get()->row();
            return  $records->fname.' '.$records->mname.' '.$records->lname;
        } else {
            $records = $this->db->from("$db4.tbljobpost as a")->select('a.*')->where('a.id',$job_ids)->get()->row();
            
            return  $records->title;
        }

    }

    private function pojectionalldata($types,$job_ids,$jobpost_application_id=null){
        
        $db4 = $this->db4->database;
        
        if($types == 'cv'){
            $records = $this->db->from("$db4.tblcv as cv")->select('cv.*,cvf.filename')->where('cv.id',$job_ids)->join("$db4.tblcvfiles AS cvf", 'cvf.candidate_id=cv.id','left')->get()->row();
            
            return  $records;
        } else if($types == 'new'){
            $records = $this->db->from("$db4.job_seeker as a")->select('a.*')->where('a.id',$job_ids)->get()->row();
            return  $records;
        } else {
            $records = $this->db->from("$db4.jobpost_application as a")->select('a.*,cv.email,cv.fname,cv.mname,cv.lname,cv.dob,cv.phone,cv.gender,cv.fathername,cv.mothername,cv.aadharno,cv.panno,cv.onlinesource,cvf.filename')->where('a.id',$jobpost_application_id)->where('a.job_id',$job_ids)->join("$db4.candidate_users AS cu", 'cu.id=a.apply_by','left')->join("$db4.tblcv AS cv", 'cv.email=cu.emailaddress','left')->join("$db4.tblcvfiles AS cvf", 'cvf.candidate_id=cv.id','left')->get()->row();
            return  $records;
        }
    }
}
