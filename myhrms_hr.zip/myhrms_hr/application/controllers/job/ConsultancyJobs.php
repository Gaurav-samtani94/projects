<?php

// require_once 'bootstrap.php';
defined('BASEPATH') or exit('No direct script access allowed');
require 'vendor/autoload.php';

class ConsultancyJobs extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('download');

        $this->load->library('session');
        $this->load->model('Mastermodel', 'mastermodel');
        $this->load->model('job/JobsModel');
        $this->load->model('job/ConsultancyJobs_model');
        //$this->load->model('job/InterviewModel');
        //$this->load->model('job/ConsultancyCompanyModel ');

        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->loginuser_id = $this->session->userdata('loginid');
        if (($this->session->userdata('loginid') == '') or ($this->session->userdata('assign_role') == '')) {
            redirect(base_url(''));
        }
    }

    public function index()
    {
        $data['title'] = 'Consultancy Company Job List';
        $this->load->view('consultancy_jobs/list_consult_job', $data);
    }
    public function  ajax_list_consultancy_jobs()
    {
        $list = $this->ConsultancyJobs_model->get_datatables();
        $data = [];
        $no = $_POST['start'];
        foreach ($list as $temp) {
            ++$no;
            $row = [];
            $row[] = $no;
            $row[] = $temp->company_name;
            $row[] = $temp->location;
            $row[] = $temp->country_name;
            $row[] = $temp->state_name;
            //  $row[] = $temp->city_name;
            $link1 = '&nbsp;<a href="' . base_url("edit_consultancy_jobs/$temp->id") . '"><i class="fa fa-edit"></i></a>&nbsp;';
            $row[] = $link1;
            $data[] = $row;
        }
        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->ConsultancyJobs_model->count_all(),
            'recordsFiltered' => $this->ConsultancyJobs_model->count_filtered(),
            'data' => $data,
        ];
        echo json_encode($output);
    }
    public function add_consultancy_jobs()
    {
        $this->form_validation->set_rules('company_name', 'Company Name', 'trim|required');
        if ($this->form_validation->run() == false) {
            $this->form_validation->error_array();
            $data['title'] = 'Add Consultancy Company Job ';
            $this->load->view('consultancy_jobs/add_consult_job', $data);
        } else {
            $records = $this->input->post();
            $record_jobs = [];
            $record_jobs['company_name'] = (!empty($records['company_name']) ? $records['company_name'] : null);
            $record_jobs['location'] = (!empty($records['company_location_id']) ? $records['company_location_id'] : null);
            $record_jobs['country_id'] = (!empty($records['country_id']) ? $records['country_id'] : null);
            $record_jobs['state_id'] = (!empty($records['state_id']) ? $records['state_id'] : null);
            $record_jobs['city_id'] = (!empty($records['city_id']) ? $records['city_id'] : null);
            $record_jobs['created_by'] = $this->loginuser_id;
            $this->db->insert('consultancy_company_job', $record_jobs);
            $ins_id = $this->db->insert_id();
            if ($ins_id) {
                //Temp ID Update..
                $this->session->set_flashdata('success_msg', 'Consultancy Company Added Successfully');
                redirect(base_url('consultancy_jobs'));
            } else {
                $this->session->set_flashdata('error_msg', 'Something Went Wrong !! ');
                redirect(base_url('add_consultancy_jobs'));
            }
        }
    }
    public function edit_consultancy_jobs($job_id)
    {
        
        $this->form_validation->set_rules('company_name', 'Company Name', 'trim|required');
        
        if ($this->form_validation->run() == false) {
            $this->form_validation->error_array();
            $data['title'] = 'Edit Consultancy Company Job';
            $data['getCompRec'] = $this->db->get_where('consultancy_company_job', ['id' => $job_id])->row();
            $data['getState'] = $this->db->get_where('tbl_states', array('isactive' => '1'))->result_array();
            $data['getCity'] = $this->db->get_where('tbl_cities', array('is_active' => '1'))->result_array();
            $this->load->view('consultancy_jobs/edit_consultancy_jobs', $data);
        } else {
            $records = $this->input->post();
            $record_jobs = [];
            $record_jobs['company_name'] = (!empty($records['company_name']) ? $records['company_name'] : null);
            $record_jobs['location'] = (!empty($records['location']) ? $records['location'] : null);
            $record_jobs['country_id'] = (!empty($records['country_id']) ? $records['country_id'] : null);
            $record_jobs['state_id'] = (!empty($records['state_id']) ? $records['state_id'] : null);
            $record_jobs['city_id'] = (!empty($records['city_id']) ? $records['city_id'] : null);
            $record_jobs['modefied_by'] = $this->loginuser_id;
            $this->db->where('id', $job_id);
            $this->db->update('consultancy_company_job', $record_jobs);
            $this->session->set_flashdata('success_msg', 'Consultancy Company updated Successfully');
            redirect(base_url('edit_jobs/' . $job_id));
        }
    }
}
