<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Active_emp_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Visiting_card_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function active_emp() {
        // echo "test"; die;
        $data['title'] = "New View";
        $this->load->view("active_emp/active_emp_view", $data);
    }

}
