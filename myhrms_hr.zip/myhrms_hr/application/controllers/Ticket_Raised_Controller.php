<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Ticket_Raised_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
         $this->load->model('ticket/Ticket_Raised_Model');
         $this->load->helper('download');
         
        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }

        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
        } else {
            redirect(base_url(""));
        }
        $this->login_user_id = $this->session->userdata('loginid');
    }


    public function index(){
        $userId=$this->session->userdata('loginid');
        $data['title'] = "Raise Tickets";
        $data['allcategoryId']=$this->Ticket_Raised_Model->GetAllCategoryId($userId);
        $returnArr=array();

        if($data['allcategoryId']){
            foreach($data['allcategoryId'] as $rOws){
                $cID=$rOws->category_id;
                $returnArr[]=$cID;
            }
        }

        $data['allinboxmessage'] = $this->Ticket_Raised_Model->GetAllInboxMessage($returnArr);
        //epd($data['allinboxmessage']);

        $data['allInboxCategory'] = $this->Ticket_Raised_Model->GetAllInboxCategory($userId);
        $this->load->view("ticket/ticket_inbox_view", $data);
    }

    public function GetCategoryInbox($categoryId){
        $userId=$this->session->userdata('loginid');
        $data['title'] = "Raise Tickets";
        $data['allinboxmessage']=$this->Ticket_Raised_Model->GetAllCategoryWiseInboxMessage($categoryId);
        $data['allInboxCategory']=$this->Ticket_Raised_Model->GetAllInboxCategoryId($categoryId);
        $this->load->view("ticket/ticket_inbox_view", $data);
    }

    public function getTicketHistory($TicktId){
        $data['title'] = "Ticket History";
        $data['ticketbyid']=$this->Ticket_Raised_Model->GetAllTicketHistory($TicktId);
        $this->load->view("ticket/ticket_history_view", $data);
    }

    public function ajax_get_byid(){
        $msgId=$this->input->post('editId');
        $statusId=$this->input->post('statusId');
        $updateArr=array('tick_status'=> '2');
        //epd($updateArr);
        $this->db->where("tick_ticket_raise.fld_id",$msgId);
        $replaymessage= $this->db->update("tick_ticket_raise", $updateArr);
        $this->TicketRaised_sendonmail($msgId);
        // $replaymessage=$this->Ticket_Raised_Model->GetAllInProgressMessage($entryBy);
        $output  = [];
        $output['status'] = 'success';
        $output['replaymessage'] = $replaymessage;
        echo json_encode($output);
        
     }

     public function TicketRaised_sendonmail($msgId) {
        $this->db->select("a.*,b.emailaddress,b.userfullname,b.employeeId,b.department_name,b.contactnumber");
        $this->db->from("tick_ticket_raise as a");
        $this->db->join("main_employees_summary as b", "a.entry_by=b.user_id", "LEFT");
        $this->db->where(["a.status" => "1", "a.fld_id" => $msgId]);
        $recData = $this->db->get()->row();
        if ($recData) {
            //=============== Mail ticket =================
            $msgDetails = $this->load->view('email/status_update_view', compact('recData'), true);
            $msgDetailsHr = $this->load->view('email/ticket_raised_hr', compact('recData'), true);
            //Send Attachment Payslip on Mail..
            $subject = $recData->subject;
            $ticket_no =$recData->ticket_no;
            // $msgDetails = "Message :- " . $recData->message;
            $respOns = $this->AttachmentsendMail($recData->emailaddress, $subject, $ticket_no, $msgDetails);
            $this->AttachmentsendMailHr($subject, $ticket_no, $msgDetailsHr);
        }
    }
    
    function AttachmentsendMail($to, $subject, $ticket_no, $msgDetails) {
        $CI = & get_instance();
        $CI->load->library('email');
        $CI->email->initialize(array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        ));
        $CI->email->from('hrms.admin@cegindia.com', 'Ticket Moved -'.$ticket_no);
        $CI->email->to($to);
       // $CI->email->bcc('marketing@cegindia.com');
        $CI->email->subject($subject);
        $CI->email->message($msgDetails);
       // $CI->email->message($ticket_no);
        $resp = $CI->email->send();
        return ($resp) ? $resp : $CI->email->print_debugger();
    }

    function AttachmentsendMailHR($subject, $ticket_no, $msgDetails) {
        $CI = & get_instance();
        $CI->load->library('email');
        $CI->email->initialize(array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        ));
        $CI->email->from('hrms.admin@cegindia.com', 'Ticket Moved -'.$ticket_no);
         $CI->email->to('marketing@cegindia.com');
        $CI->email->to('HRD1@cegindia.com');
        $CI->email->to('HRD2@cegindia.com');
       // $CI->email->bcc('marketing@cegindia.com');
        $CI->email->subject($subject);
        $CI->email->message($msgDetails);
       // $CI->email->message($ticket_no);
        $resp = $CI->email->send();
        return ($resp) ? $resp : $CI->email->print_debugger();
    }

    
   public function moveajax_get_byid(){
        $msgId=$this->input->post('editId');
        $statusId=$this->input->post('statusId');
        $updateArr=array('tick_status'=> '3');
      
        $this->db->where("tick_ticket_raise.fld_id",$msgId);
        $replaymessage= $this->db->update("tick_ticket_raise", $updateArr);
        $this->Ticketmove_sendonmail($msgId);
        // $replaymessage=$this->Ticket_Raised_Model->GetAllInProgressMessage($entryBy);
        $output  = [];
        $output['status'] = 'success';
        $output['replaymessage'] = $replaymessage;
        echo json_encode($output);
       
     }

     public function Ticketmove_sendonmail($msgId) {
        $this->db->select("a.*,b.emailaddress,b.userfullname,b.employeeId,b.department_name,b.contactnumber");
        $this->db->from("tick_ticket_raise as a");
        $this->db->join("main_employees_summary as b", "a.entry_by=b.user_id", "LEFT");
        $this->db->where(["a.status" => "1", "a.fld_id" => $msgId]);
        $recData = $this->db->get()->row();
        if ($recData) {
            //=============== Mail ticket =================
            $msgDetails = $this->load->view('email/status_inprogress_view', compact('recData'), true);
           $msgDetailsHr = $this->load->view('email/ticket_raised_hr', compact('recData'), true);
            //Send Attachment Payslip on Mail..
            $subject = $recData->subject;
            $ticket_no =$recData->ticket_no;
            // $msgDetails = "Message :- " . $recData->message;
            $this->InprogressAttachmentsendMail($recData->emailaddress, $subject, $ticket_no, $msgDetails);
             $this->InprogressAttachmentsendMailHr($subject, $ticket_no, $msgDetailsHr);
           
        }
    }
    
    function InprogressAttachmentsendMail($to, $subject, $ticket_no, $msgDetails) {
        $CI = & get_instance();
        $CI->load->library('email');
        $CI->email->initialize(array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        ));
        $CI->email->from('hrms.admin@cegindia.com', 'Ticket Moved -'.$ticket_no);
        $CI->email->to($to);
        $CI->email->subject($subject);
        $CI->email->message($msgDetails);
        $resp = $CI->email->send();
        return ($resp) ? $resp : $CI->email->print_debugger();
    }

    function InprogressAttachmentsendMailHr($subject, $ticket_no, $msgDetails) {
        $CI = & get_instance();
        $CI->load->library('email');
        $CI->email->initialize(array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        ));
        $CI->email->from('hrms.admin@cegindia.com', 'Ticket Moved -'.$ticket_no);
        $CI->email->to('marketing@cegindia.com');
        $CI->email->to('HRD1@cegindia.com');
        $CI->email->to('HRD2@cegindia.com');
        $CI->email->subject($subject);
        $CI->email->message($msgDetails);
        $resp = $CI->email->send();
        return ($resp) ? $resp : $CI->email->print_debugger();
    }

    public function usercomment(){
         $tcktId=$this->input->post('updateid');
          $original_filename= $_FILES['image']['name'];
            $new_name=time()."".str_replace('','-',$original_filename);
            $config['upload_path']          = '../myhrms/uploads/file';
            $config['allowed_types']        = '*';
            $config['file_name']        = $new_name;
            $this->load->library('upload', $config);
           if($this->upload->do_upload('image')){
            $docs_filename = $this->upload->data('file_name');
            }
          $postArr=$this->input->post();
              $insertArr=array(
             'parent_id'=>$tcktId,
            'message'=>$postArr['description'],
             'docs_file' =>$docs_filename,
            'entry_by'=> $this->login_user_id,
        );
        //epd($insertArr);
        $respU=$this->db->insert("tick_ticket_raise", $insertArr);
        if($respU);{
          $this->session->set_flashdata('success_msg', 'Message Successfully Done.');
           redirect($_SERVER['HTTP_REFERER']);
        }
    }

     public function ajax_get_bycommentid(){
        $updateId=$this->input->post('editId');
        echo json_encode($updateId);
    }

    public function replyhistroy($id){
        $data['error'] = '';
        $data['title'] = "Ticket Comment Section";
        $data['parentMessage']=$this->Ticket_Raised_Model->AllReplyParentMessage($id);
        //epd( $data['parentMessage']);
         $data['childMessage']=$this->Ticket_Raised_Model->AllReplyChildMessage($id);
        //epd($data['replayMessage']);
        $this->load->view("ticket/ticket_reply_view", $data);

    }
    


}