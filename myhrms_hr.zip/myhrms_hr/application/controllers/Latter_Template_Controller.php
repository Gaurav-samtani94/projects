<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Latter_Template_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('template/Template_Model','templateModel');
        $this->load->library('form_validation');
        $this->load->helper('security');
		 $this->db1 = $this->load->database('default', TRUE);
        $this->db2 = $this->load->database('online', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);

        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
        } else {
            redirect(base_url(""));
        }
    }
    public function GetAllJobHistory(){
        
        // die();
        $data['error'] = '';
        $data['title'] = "Employee Job History Details";
        // $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
        $data['RecEmplDetails'] = $recSingleEmplDetails;
        $data['BunitsRecArr'] = $this->mastermodel->GetTableData("main_businessunits", ["isactive" => "1", "id!=" => "0"]);
        $data['JobGroupRecArr'] = $this->mastermodel->GetTableData("main_jobtitles", ["isactive" => "1"]);
        $data['CompanyRecArr'] = $this->mastermodel->GetTableData("tbl_companyname", ["is_active" => "1"]);
        $data['PositionsRecArr'] = $this->mastermodel->GetTableData("main_positions", ["isactive" => "1"]);
        $data['ProjectsRecArr'] = $this->mastermodel->GetTableData("tm_projects", ["is_active" => "1"]);
        $data['jobhistoryRecArr'] = $this->templateModel->GetAllEmpljobhistoryDetails();
        // epd($data['RecEmplSkillsDetails'] );
        // $data['jobhistoryRecArr'] = $this->mastermodel->GetRecEmpljobhistoryDetails($empID);
        // $data['jobempId'] = $empID;
        $this->load->view("template/template_view", $data);

    }
    public function JoiningLetterShow($id,$empId){
        $data['error'] = '';
        $data['title'] = "Employee Joining Letter";
        $data['id']=$id;
        $letterheadNo= $this->templateModel->getLatestLetterheadNumber();
        if(empty($letterheadNo)){
            $year=date('y');
            $month=date('m');
            $day=date('d');
            $letterheadNo = 'LH'.$year . $month .$day.'0001'; //0001
        } else {
        $numericPart = (int)substr($letterheadNo, -4);
        $newNumericPart = str_pad($numericPart + 1, 4, '0', STR_PAD_LEFT);
    
        $year = date('y'); // Last two digits of the year
        $month = date('m'); // Current month
        $day = date('d'); // Current day
        $letterheadNo = 'LH'.$year . $month . $day . $newNumericPart;
    }
        // epd($letterheadNo);
        $data['letterheadNumber']=$letterheadNo;
        $data['empId']=$empId;
        $this->load->view("template/joining_letter_view", $data);
    }
    public function save_pdf_by_ajax()
    {
        // Load necessary libraries
        $this->load->library('upload');
        $id = $this->input->post('id');
        $letterheadNo = $this->input->post('lh');
    if (!$id) {
        echo json_encode([
            "success" => false,
            "message" => "No valid ID provided."
        ]);
        return;
    }
       
  
        // Set upload configuration
        $config['upload_path'] = './uploads/job_history_pdf_files';
        $config['allowed_types'] = 'pdf';
        $config['max_size'] = 2040000008;
        $config['file_name'] = uniqid('joining_letter_', true) . '.pdf';
        // Ensure the upload folder exists and is writable
    
       $this->upload->initialize($config);
        
        // epd('still done');
        // Check if file is uploaded
        if ($this->input->method() === 'post' && isset($_FILES['pdf'])) {
            
            if ($this->upload->do_upload('pdf')) {
                $uploadData = $this->upload->data();
                $filePath = $uploadData['full_path'];
                $fileName = $uploadData['file_name'];
                // epd( $filePath);
               
                // Prepare data to save to database
                $pdfData = [
                    'tem_pdf' => $fileName,
                    'pdf_lock' => '0',
                ];
                $this->db->where('id', $id); // Use the primary key for updating
                $updatedResp=$this->db->update('main_empjobhistory', $pdfData);
                if($updatedResp){
                    $insertArr=[
                        'emp_id'=>$id,
                        'letterhead_number'=>$letterheadNo,
                    ];
                    $this->db->insert('letterheads',$insertArr);
                }
                // Save PDF data to database (assuming your model's method `save_pdf`)
                if ($updatedResp) {
                    echo json_encode([
                        "success" => true,
                        "message" => "File uploaded and saved successfully.",
                        "file_path" => $filePath // Optionally, return the file path
                    ]);
                } else {
                    echo json_encode([
                        "success" => false,
                        "message" => "Failed to save PDF data in the database."
                    ]);
                }
            } else {
                epd($this->upload->display_errors());
                echo json_encode([
                    "success" => false,
                    "message" => $this->upload->display_errors()
                ]);
            }
        } else {
            echo json_encode([
                "success" => false,
                "message" => "No file uploaded or invalid request method."
            ]);
        }
    }
}