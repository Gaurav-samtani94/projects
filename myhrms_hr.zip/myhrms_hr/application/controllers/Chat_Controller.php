<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Chat_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('chat/Chat_Model');
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
        $this->load->helper('file');

         $this->load->database();
        $this->db1 = $this->load->database('default', TRUE);//sentrifugo ==default
        $this->db2 = $this->load->database('accdept_db', TRUE);//accceg_db 
        $this->db3 = $this->load->database('online', TRUE);//bdtechnonew_db
         $this->login_user_id = $this->session->userdata('loginid');
    }

    //Step 1 chat..
    public function index() {
        $data['error'] = '';
        $data['title'] = "Message To HR.";
        $data['allmessage']=$this->Chat_Model->GetAllusermessage($this->login_user_id);
        $data['hrmessage']=$this->Chat_Model->GetAllHrmessage();
        $data['username']=$this->Chat_Model->GetuserNameById($this->login_user_id);
         if(! $data['allmessage'])
               {
                  redirect(base_url('compose'), 'refresh');
               }
               //epd($data['allmessage']);
        $this->load->view("chat/chat_view", $data);
    }
     //Step 2 Inbox..
    public function inbox(){
         $data['error'] = '';
        $data['title'] = "Inbox";
        $this->load->view("chat/inbox_view", $data);

    }
    public function compose(){
         $data['error'] = '';
        $data['title'] = "Compose";
        // echo "hello";
        // die();
        $this->load->view("chat/compose_view", $data);

    }
    public function storemessage()
    {
         $db1 = $this->db1->database;
       $db2 = $this->db2->database;
        $original_filename= $_FILES['image']['name'];
            $new_name=time()."".str_replace('','-',$original_filename);
            $config['upload_path']          = './uploads/file';
            $config['allowed_types']        = '*';
            $config['file_name']        = $new_name;
            $this->load->library('upload', $config);
     if($this->upload->do_upload('image')){
            $st_filename = $this->upload->data('file_name');
            }
        $postArr=$this->input->post();
        // print_r($postArr);
        // die();
              $insertArr=array(
            'subject'=>$postArr['subject'],
            'chat_message'=>$postArr['ckmessage'],
            'to_user_id'=> '1',
             'ip_address'=> $_SERVER["REMOTE_ADDR"],
             'from_user_id'=> $this->login_user_id,
            'docs_file' =>$st_filename,
        );
        //epd($insertArr);
         $resinsrted = $this->db1->insert("hrchat_message", $insertArr);
          if($resinsrted)
               {
                  redirect(base_url('chat'), 'refresh');
                //    $this->session->set_flashdata('success_msg', 'Message send Successfully.');
                //    redirect($_SERVER['HTTP_REFERER']);
               }else{
                  $this->session->set_flashdata('success_msg', 'something went wrong.');
                   redirect($_SERVER['HTTP_REFERER']);

               }
        
    }
    public function ajax_get_byid(){
        $msgId=$this->input->post('replayid');
        $replaymsg=$this->input->post('replaymsg');
          $insertArr=array(
            'chat_message'=>$replaymsg,
            'to_user_id'=> '1',
            'ip_address'=> $_SERVER["REMOTE_ADDR"],
            'from_user_id'=> $msgId,
            'entry_by'=>$this->session->userdata('loginid'),
        );
        
        $resinsrted = $this->db1->insert("hrchat_message", $insertArr);
      
        $replaymessage=$this->Chat_Model->GetAllusermessage($msgId);
       
         echo json_encode($replaymessage);
}

    

}