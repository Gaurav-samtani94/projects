<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();

        //$this->load->model('attendance');
        $this->load->model('mastermodel');
        $this->load->library('session');
        $this->load->library("user_agent");
    }

    //Attendance Controller..
    public function index() {
        $recData = array('');
        $recData['title'] = "Monthly Employee Attendance";
        //$recData['atten_month'] = '01';//date("m");
        //$recData['atten_year'] = date("Y");


        if (@$_REQUEST["attendance_month"] and @ $_REQUEST["attendance_month"]) {
            $recData['atten_month'] = $_REQUEST["attendance_month"];
            $recData['atten_year'] = $_REQUEST["attendance_year"];
            $recData['userid'] = $_REQUEST["user_id"];
            $recData['bus_id'] = $_REQUEST["businessunit"];
            $recData['dpt_id'] = $_REQUEST["department"];
            $userid = '';
            $bus_id = '';
            $dpt_id = '';
            $recData['userrecArr'] = $this->empUserID($userid, $bus_id, $dpt_id);
            $recData['userrec'] = $this->empUserID($recData['userid'], $recData['bus_id'], $recData['dpt_id']);
            //echo "<pre>"; print_r($recData['userid']); die;
            //From Date To Date Comb..
            //date("Y")."-02"."-01";
            $from_date = $_REQUEST["attendance_year"] . '-' . $_REQUEST["attendance_month"] . "" . "-01";
            $to_date = date("t-m-Y", strtotime($from_date));
        } else {
            $userid = '';
            $bus_id = '';
            $dpt_id = '';
            $recData['userrec'] = array();
            //$recData['userrec'] = $this->empUserID($userid,$bus_id,$dpt_id);
            $recData['userrecArr'] = $this->empUserID($userid, $bus_id, $dpt_id);
            $recData['atten_month'] = date("m");

            //$data['atten_month'] = "02";
            $recData['atten_year'] = date("Y");
            $from_date = date("Y-m") . "-01";
            $to_date = date("t-m-Y", strtotime($from_date));
        }
        //echo "<pre>"; print_r($recData['atten_month']); die;
        $recData['dateRangeArr'] = $this->mastermodel->getDatesFromRange($from_date, $to_date);

        //echo "<pre>"; print_r($recData['userrec']); die;
        //$list = $this->attendance->GetAllPunchDetail('2020-01-31','280'); 
        //echo "<pre>";  print_r($list);die;
        $this->load->view('attendance_report/monthly_attendance_report', $recData);
    }

    public function empUserID($userId, $bus_id, $dpt_id) {
        $this->db->select("a.user_id,a.userfullname,a.employeeId,b.machine_id,a.department_name,a.department_id");
        $this->db->from('main_employees_summary as a');
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        if ($userId != ''):
            $this->db->where(array('a.user_id' => $userId));
        endif;
        if ($bus_id != ''):
            $this->db->where(array('a.businessunit_id' => $bus_id));
        endif;
        if ($dpt_id != ''):
            $this->db->where(array('a.department_id' => $dpt_id));
        endif;
        $this->db->where(array('a.isactive' => '1'));
        $this->db->where('b.machine_id !=', null);
        $this->db->group_by("a.user_id");
        $userRec = $this->db->get()->result();
        return ($userRec) ? $userRec : null;
    }

    // public function empUserID() {
    // $this->db->select("a.user_id,a.userfullname,a.employeeId,b.machine_id");
    // $this->db->from('main_employees_summary as a');
    // $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
    // $this->db->where(array('isactive' => '1','a.user_id' => '296'));
    // $this->db->where('b.machine_id !=', null);
    // $this->db->group_by("a.user_id");
    // $userRec = $this->db->get()->result();
    // return ($userRec) ? $userRec : null;
    // }

    public function punchAjaxList() {
        $list = $this->empUserID();
        $data = array();
        //$row=array();
        foreach ($list as $value):
            $row = array();
            $row[] = $value->userfullname;
            $row[] = $value->userfullname;
            $row[] = $value->employeeId;
            $row[] = $value->machine_id;
            $data[] = $row;
        endforeach;
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => '0',
            "recordsFiltered" => '0',
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function ajax_list() {

        //	echo "<pre>"; print_r($dateRangeArr); die;
        $userRec = $this->empUserID();
        //echo "<pre>"; print_r($userRec);
        $punchDate = '2020-01-31';
        $no = $_POST['start'];
        $data = array();
        //$list = $this->GetAllPunchDetail("2020-01-31", '212');
        //echo "<pre>"; print_r($list);
        foreach ($userRec as $val):
            //echo $val->userfullname.',';
            //endforeach;
            //die;


            $no++;

            $row = array();
            $repmonth = '4';
            $repyear = '2020';
            $n = '4';
            $day = '11';
            $row[] = $no;
            $row[] = $val->userfullname;
            //$row[] = $val->employeeId;
            //$row[] = $val->machine_id;
            $from_date = date("Y") . "-01" . "-01";
            $to_date = date("t-m-Y", strtotime($from_date));
            $dateRangeArr = $this->Mastermodel->getDatesFromRange($from_date, $to_date);
            foreach ($dateRangeArr as $dates):
                //$startDate = "1" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];     //"2020-01-31"
                //$date = $dates;
                $Attendlist = $this->GetAllPunchDetail($dates, $val->machine_id);
                $row[] = ($Attendlist["intime"]) ? $Attendlist["intime"] : "<span style='color:#FF0000'>No Punch</span>";
                //$row[] = $dates;
                //$row[] = $date;
                $day++;
                //$row[] = $val->machine_id;
            endforeach;
            //$row[] = $Attendlist['intime'].','.$Attendlist['outtime'];
            //$row[] = $Attendlist['intime'].','.$Attendlist['outtime'];
            $data[] = $row;
        endforeach;

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => '0',
            "recordsFiltered" => '0',
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function GetAllPunchDetail($punchDate, $userID) {
        $this->db->select("DATE_FORMAT(`LogDate`,'%H:%i:%s %p') as punchtime");
        $this->db->from('DeviceLogs_Processed');
        $this->db->where("(`UserId` = '" . $userID . "')");
        $this->db->where("LogDate LIKE '%$punchDate%'");
        $this->db->order_by("LogDate", "ASC");
        $this->db->group_by("LogDate");
        $PunchRecData = $this->db->get()->result();
        //return $PunchRecData;
        $In_timeArr = array();
        $Out_timeArr = array();

        if ($PunchRecData) {
            foreach ($PunchRecData as $kKeY => $rEcd) {
                $returnM = ($kKeY % 2);
                if ($returnM == 0) {
                    array_push($In_timeArr, $rEcd->punchtime);
                }
                if ($returnM == 1) {
                    array_push($Out_timeArr, $rEcd->punchtime);
                }
            }
            return array("intime" => $In_timeArr, "outtime" => $Out_timeArr);
        } else {
            return array("intime" => '', "outtime" => '');
        }
    }

}
