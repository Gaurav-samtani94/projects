<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Attendance_report_shift_chng_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Attendnacereport_late_shift');
        $this->load->model('attendance_report/Attendnacereportleave','Attendnacereportleave');
        $this->load->model('attendance_report/Attendnacereporttour','Attendnacereporttour');
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function attendance_report() {
		// $list = $this->Attendnacereport_late_shift->get_datatables();
		// echo "<pre>"; print_r($list); die;
        $title = 'Late Attendance Report';
        $jobtitle = $this->db->get_where('main_jobtitles', array('isactive' => '1'))->result();
        $business_title = $this->db->get_where('main_businessunits', array('isactive' => '1'))->result();
        $this->load->view('attendance_report/attendance_report_shiftwise', compact('title', 'jobtitle', 'business_title'));
    }
	
	
	 //Ajax List.. Attendance Report..
    public function ajax_attendance_report_list_all() {
        $no = 1;
        // $list = $this->Attendnacereport_late_shift->get_datatables();
        $list2 = $this->Attendnacereportleave->get_datatables();
        // $list3 = $this->Attendnacereporttour->get_datatables();
		// $list1_2 = array_merge($list,$list2);
		// $main_list = array_merge($list1_2,$list3);
		// echo "<pre>"; print_r($main_list); die;
        $data = array();
        $no = $_POST['start'];
		
		foreach ($list2 as $recemp) {
				$no ++;
				$row = array();
				$row[] = $no;
				$row[] = $recemp->employeeId;
				$row[] = $recemp->userfullname;
				$row[] = $recemp->jobtitle_name;
				$row[] = $recemp->businessunit_name;
				$row[] = $recemp->leavestatus;
				$row[] = $recemp->from_date;
				$row[] = $recemp->to_date;
				$data[] = $row;
        } 
		
		

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Attendnacereportleave->count_all(),
            "recordsFiltered" => $this->Attendnacereportleave->count_filtered(),
            "data" => $data
           );
        echo json_encode($output);
    }
	
	public function ajax_attendance_report_list_tour() {
        $no = 1;
        $list = $this->Attendnacereporttour->get_datatables();
		// echo "<pre>"; print_r($main_list); die;
        $data = array();
        $no = $_POST['start'];
		
		foreach ($list as $recemp) {
				$no++;
				$row = array();
				$row[] = $no;
				$row[] = $recemp->employeeId;
				$row[] = $recemp->userfullname;
				$row[] = $recemp->jobtitle_name;
				$row[] = $recemp->businessunit_name;
				$row[] = $recemp->start_date;
				$data[] = $row;
        } 

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Attendnacereport_late_shift->count_all(),
            "recordsFiltered" => $this->Attendnacereport_late_shift->count_filtered(),
            "data" => $data
           );
        echo json_encode($output);
    }
	
	
    //Ajax List.. Attendance Report..
    public function ajax_attendance_report_list() {
        $no = 1;
        $list = $this->Attendnacereport_late_shift->get_datatables();
		// $list1_2 = array_merge($list,$list2);
		// $main_list = array_merge($list1_2,$list3);
		// echo "<pre>"; print_r($list); die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $recemp) {
			$shifTime = get_shiftTiming_byUserId($recemp->user_id);
			$shifTime1 = get_shiftTiming_byUserId($recemp->user_id);
			if($shifTime == ''):
				$shifTime = "08:30";
			endif;
            $intime= date("h:i:s A", strtotime(($recemp->LogDate)));
            if((strtotime($intime) >= strtotime($shifTime.':59 AM')) AND (strtotime($intime) <= strtotime('11:00:00 AM'))) 
			{
				$no ++;
				$row = array();
				$row[] = $no;
				$row[] = $recemp->employeeId;
				$row[] = $recemp->userfullname;
				$row[] = $recemp->jobtitle_name;
				$row[] = $shifTime1;
				$row[] = date('h:i:s A', strtotime($recemp->LogDate));
				$row[] = date("Y-m-d", strtotime(($recemp->LogDate)));
				$data[] = $row;
            }

        } 

        $output = array(
            "draw" => $_POST['draw'],
            // "recordsTotal" => count(Live_attendance_report_model),
            // "recordsFiltered" => count(Live_attendance_report_model),
            "data" => $data
           );
        echo json_encode($output);
    }
    
    
    //Ajax List.. Attendance Report leave..
    public function ajax_attendance_report_leave_list() {
        $no = 1;
        $list = $this->Attendnacereport->get_datatables();
        $list2 = $this->Attendnacereportleave->get_datatables();
        $list3 = $this->Attendnacereporttour->get_datatables();
		$list1_2 = array_merge($list,$list2);
		$main_list = array_merge($list1_2,$list3);
		// echo "<pre>"; print_r($main_list); die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $recemp) {

            $intime= date("h:i:s A", strtotime(($recemp->FirstIn)));
            if((strtotime($intime) >= strtotime('09:35:01 AM')) AND (strtotime($intime) <= strtotime('09:45:00 AM'))) 
			{
				$no ++;
				$row = array();
				$row[] = $no;
				$row[] = $recemp->employeeId;
				$row[] = $recemp->userfullname;
				$row[] = $recemp->jobtitle_name;
				$row[] = $recemp->city_name;
				$row[] = date('h:i:s A', strtotime($recemp->FirstIn));
				$row[] = date("Y-m-d", strtotime(($recemp->FirstIn)));
				$data[] = $row;
            }

        } 

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Attendnacereport->count_all(),
            "recordsFiltered" => $this->Attendnacereport->count_filtered(),
            "data" => $data
           );
        echo json_encode($output);
    }

    
    
    //Ajax List.. Attendance Report Tour..
    public function ajax_attendance_report_tour_list() {
         $no = 1;
        $list = $this->Attendnacereport->get_datatables();
        $list2 = $this->Attendnacereportleave->get_datatables();
        $list3 = $this->Attendnacereporttour->get_datatables();
		$list1_2 = array_merge($list,$list2);
		$main_list = array_merge($list1_2,$list3);
		// echo "<pre>"; print_r($main_list); die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $recemp) {

            $intime= date("h:i:s A", strtotime(($recemp->FirstIn)));
            if((strtotime($intime) >= strtotime('09:45:01 AM')) AND (strtotime($intime) <= strtotime('10:30:00 AM'))) 
			{
				$no ++;
				$row = array();
				$row[] = $no;
				$row[] = $recemp->employeeId;
				$row[] = $recemp->userfullname;
				$row[] = $recemp->jobtitle_name;
				$row[] = $recemp->city_name;
				$row[] = date('h:i:s A', strtotime($recemp->FirstIn));
				$row[] = date("Y-m-d", strtotime(($recemp->FirstIn)));
				$data[] = $row;
            }

        } 

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Attendnacereport->count_all(),
            "recordsFiltered" => $this->Attendnacereport->count_filtered(),
            "data" => $data
           );
        echo json_encode($output);
    }


//    public function test() {
//        $ymD = '2020-1-3';
//        $query = $this->db->query("SELECT a.FirstIn, c.userfullname,c.userfullname,c.employeeId,c.jobtitle_name FROM thumb_attendance as a LEFT JOIN emp_otherofficial_data as b ON b.thumbcode = a.EmployeeID LEFT JOIN main_employees_summary as c ON b.user_id = c.user_id WHERE (STR_TO_DATE(a.FirstIn, '%m/%d/%Y')='$ymD') AND c.isactive='1' AND c.businessunit_id='1' order by jobtitle_name ASC");
//        $resultArr = $query->result();
//        $data = array();
//        if(@$resultArr){
//           foreach($resultArr as $resultArrRow){
//               $row = array();
//                $intime= date("h:i:s A", strtotime(($resultArrRow->FirstIn)));
//                if((strtotime($intime) >= strtotime('09:30:00 AM')) AND (strtotime($intime) <= strtotime('10:30:00 AM'))) {
//                $row['emp_id'] = $resultArrRow->employeeId;
//                $row['user_name'] = $resultArrRow->userfullname;
//                $row['job_title'] = $resultArrRow->jobtitle_name;
//                $row['time'] = date("h:i:s A", strtotime(($resultArrRow->FirstIn)));
//                $row['date'] = date("Y-m-d", strtotime(($resultArrRow->FirstIn)));
//                }
//                $data[] = $row;
//           }     
//        }
//        $filter_data = array_filter($data);
//        $sno =0;
//          echo '<table style="width:100%; border:1p solid #333;"><thead><tr><th>S.no</th><th>Emp Code</th><th>Emp Name</th><th>Job Title</th><th>Date</th><th>In Time</th></tr></thead><tbody>';
//          foreach($filter_data as $rrowdata){
//              $sno++;
//              echo '<tr><td>'.$sno.'</td><td>'.$rrowdata['emp_id'].'</td><td>'.$rrowdata['user_name'].'</td><td>'.$rrowdata['job_title'].'</td><td>'.$rrowdata['date'].'</td><td>'.$rrowdata['time'].'</td></tr>';
//          }
//          echo '</tbody></table>';
//    }

}

?>