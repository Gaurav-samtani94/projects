<?php

defined('BASEPATH') or exit('No direct script access allowed');
class Hr_Chat_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
         $this->load->model('hr_chat/Hr_Chat_Model');
         $this->load->helper('download');
         
        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
        } else {
            redirect(base_url(""));
        }
    }
    public function index()
    {
        $userId=$this->session->userdata('loginid');
        $data['title'] = "Inbox";
        $data['allinboxmessage']=$this->Hr_Chat_Model->GetAllInboxMessage();
    
       // epd($data['allinboxmessage']);
      
        $this->load->view("hr_chat/hr_inbox_view", $data);
    }
    public function inbox_chat($chat_id){
        $userId=$this->session->userdata('loginid');
        $data['title'] = "Chat";
        $data['messagebyid']=$this->Hr_Chat_Model->GetChatMessageBYId($chat_id);
        $data['username']=$this->Hr_Chat_Model->GetuserNameById($userId);
        $data['msgbyusername']=$this->Hr_Chat_Model->GetuserById($chat_id);
        $data['from_user_id'] =$chat_id;
       // epd($data['msgbyusername']);
         $this->load->view("hr_chat/hr_chat_view", $data);


    }
    
 public function ajax_get_byid(){
//vivek bahi
        $msgId=$this->input->post('replayid');
        $replaymsg=$this->input->post('replaymsg');
          $insertArr=array(
            'chat_message'=>$replaymsg,
            'to_user_id'=> $msgId,
            'ip_address'=> $_SERVER["REMOTE_ADDR"],
            'from_user_id'=> '1',
            'entry_by'=>$this->session->userdata('loginid'),
        );
        //epd($insertArr);
        $resinsrted = $this->db->insert("hrchat_message", $insertArr);
        $replaymessage=$this->Hr_Chat_Model->GetAllusermessage($msgId);
         echo json_encode($replaymessage);
     }


}