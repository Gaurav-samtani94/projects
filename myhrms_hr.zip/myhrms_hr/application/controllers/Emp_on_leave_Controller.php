<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Emp_on_leave_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Emp_on_leave_tour_report_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }

    public function emp_On_leave() {
        // echo "test"; die;
        $abc = $this->countemponfloor('7', '12');
        $countpresentEmp = '';
        // echo "<pre>"; print_r($abc); die;
        $presentEmpTour = $this->Emp_on_leave_tour_report_model->tour_atten_report_ceg();
        $presentEmpLeave = $this->Emp_on_leave_tour_report_model->leave_atten_report_ceg1();

        $countpresentEmpTour_ceg = $this->Emp_on_leave_tour_report_model->count_tour_atten_report_ceg(1);
		
        $countpresentEmpTour_cegth = $this->Emp_on_leave_tour_report_model->count_tour_atten_report_ceg(2);
        // echo count($countpresentEmpTour_cegth); die;
		// echo "<pre>";  print_r($countpresentEmpTour_cegth); die;
		$countpresentEmpTour = count($countpresentEmpTour_ceg) + count($countpresentEmpTour_cegth);
		// echo $countpresentEmpTour; die;
        $countpresentEmpLeave = $this->Emp_on_leave_tour_report_model->count_leave_atten_report_ceg1();
        $countpresentEmpPresent = $this->Emp_on_leave_tour_report_model->count_present_atten_report_ceg1();
        $countEmpPresentceg = $this->Emp_on_leave_tour_report_model->count_present_atten_report_ceg_nd_cegth(1);
        $countEmpPresentcegth = $this->Emp_on_leave_tour_report_model->count_present_atten_report_ceg_nd_cegth(2);
        $countEmpleaveceg = $this->Emp_on_leave_tour_report_model->count_leave_by_businessid(1);
        $countEmpleavecegth = $this->Emp_on_leave_tour_report_model->count_leave_by_businessid(2);
		// echo "<pre>"; print_r($countEmpleaveceg); die;
        $count_total = $this->Emp_on_leave_tour_report_model->count_absent();
        // echo $count_total; die;
        $absentCount = $count_total - ($countpresentEmpTour + $countpresentEmpLeave + $countpresentEmpPresent);
        
		
		
		// echo $absentCount; die;
        // echo "<pre>"; print_r($count_total); die;
        //calculating absent emp list by subtracting from all
        $countpresentEmpTour_ab = $this->Emp_on_leave_tour_report_model->count_tour_atten_report_ceg_absent();
        $countpresentEmpLeave_ab = $this->Emp_on_leave_tour_report_model->count_leave_atten_report_ceg_absent();
        $countpresentEmpPresent_ab = $this->Emp_on_leave_tour_report_model->count_present_atten_report_ceg_absent();
        $countpresentEmptotal = $this->Emp_on_leave_tour_report_model->count_absent_list();
        // echo "<pre>"; print_r($countpresentEmptotal); die;
        $arr1 = array();
        $abs_arr = array();
        $ab_totoal = json_decode(json_encode($countpresentEmptotal), true);
        $ab_present = json_decode(json_encode($countpresentEmpPresent_ab), true);
        $ab_leave = json_decode(json_encode($countpresentEmpLeave_ab), true);
        $ab_tour = json_decode(json_encode($countpresentEmpTour_ab), true);
        // $arr_mrg = array_merge($ab_present, $ab_leave);
        // $arr_mrg2 = array_merge($arr_mrg,$ab_tour);
        $singleArray = [];
        $n = 1;
        foreach ($countpresentEmptotal as $childArray) {

            $singleArray[] = $childArray;
        }
        // $result=array_diff($ab_totoal,$arr_mrg2);
        // echo "<pre>"; print_r($countpresentEmptotal); die;
        // foreach($countpresentEmpTour_ab as $key => $val):
        // $arr1[$key] = $val;
        // $arr1[$key]=object_2_array($val);
        // endforeach;
        // $abc = get_object_vars($arr1);
        // foreach($countpresentEmpPresent as $val):
        // $arr2[] = $val->userfullname;
        // endforeach;
        // echo "<pre>"; print_r($array1); die;
        // $result=array_diff($singleArray,$singleArray2);
        // echo "<pre>";print_r($result); die;
        // print_r($countpresentEmpPresent); die;
        //==============================================
        $empIdTotal = array();
        $empNameTotal = array();
        $empGradeTotal = array();
        $arr1 = array();
        $arr2 = array();
        $arr3 = array();
        $arr4 = array();
        $arr5 = array();

        $list = array("-1" => "-1", "0" => "0", "1" => "1", "2" => "2", "3" => "3", "4" => "4", "5" => "5", "6" => "6", "7" => "7");

        $GroupNumAname = $this->countemponfloor_names(-1, "8");
        $GroupNumBname = $this->countemponfloor_names(-1, "9");
        $GroupNumCname = $this->countemponfloor_names(-1, "10");
        $GroupNumDname = $this->countemponfloor_names(-1, "11");
        $GroupNumEname = $this->countemponfloor_names(-1, "12");
        $GroupNumFname = $this->countemponfloor_names(-1, "13");
        $grp1 = array_merge($GroupNumAname, $GroupNumBname);
        $grp2 = array_merge($GroupNumCname, $GroupNumDname);
        $grp3 = array_merge($GroupNumEname, $GroupNumFname);
        $grp4 = array_merge($grp1, $grp2);
        $grp5 = array_merge($grp3, $grp4);

        $GroupNumAname0 = $this->countemponfloor_names(0, "8");
        $GroupNumBname0 = $this->countemponfloor_names(0, "9");
        $GroupNumCname0 = $this->countemponfloor_names(0, "10");
        $GroupNumDname0 = $this->countemponfloor_names(0, "11");
        $GroupNumEname0 = $this->countemponfloor_names(0, "12");
        $GroupNumFname0 = $this->countemponfloor_names(0, "13");
        $grp10 = array_merge($GroupNumAname0, $GroupNumBname0);
        $grp20 = array_merge($GroupNumCname0, $GroupNumDname0);
        $grp30 = array_merge($GroupNumEname0, $GroupNumFname0);
        $grp40 = array_merge($grp10, $grp20);
        $grp50 = array_merge($grp30, $grp40);


        $GroupNumAname1 = $this->countemponfloor_names(1, "8");
        $GroupNumBname1 = $this->countemponfloor_names(1, "9");
        $GroupNumCname1 = $this->countemponfloor_names(1, "10");
        $GroupNumDname1 = $this->countemponfloor_names(1, "11");
        $GroupNumEname1 = $this->countemponfloor_names(1, "12");
        $GroupNumFname1 = $this->countemponfloor_names(1, "13");
        $grp11 = array_merge($GroupNumAname1, $GroupNumBname1);
        $grp21 = array_merge($GroupNumCname1, $GroupNumDname1);
        $grp31 = array_merge($GroupNumEname1, $GroupNumFname1);
        $grp41 = array_merge($grp11, $grp21);
        $grp51 = array_merge($grp31, $grp41);
        // print_r($grp51); die;
        $GroupNumAname2 = $this->countemponfloor_names(2, "8");
        $GroupNumBname2 = $this->countemponfloor_names(2, "9");
        $GroupNumCname2 = $this->countemponfloor_names(2, "10");
        $GroupNumDname2 = $this->countemponfloor_names(2, "11");
        $GroupNumEname2 = $this->countemponfloor_names(2, "12");
        $GroupNumFname2 = $this->countemponfloor_names(2, "13");
        $grp12 = array_merge($GroupNumAname2, $GroupNumBname2);
        $grp22 = array_merge($GroupNumCname2, $GroupNumDname2);
        $grp32 = array_merge($GroupNumEname2, $GroupNumFname2);
        $grp42 = array_merge($grp12, $grp22);
        $grp52 = array_merge($grp32, $grp42);

        $GroupNumAname3 = $this->countemponfloor_names(3, "8");
        $GroupNumBname3 = $this->countemponfloor_names(3, "9");
        $GroupNumCname3 = $this->countemponfloor_names(3, "10");
        $GroupNumDname3 = $this->countemponfloor_names(3, "11");
        $GroupNumEname3 = $this->countemponfloor_names(3, "12");
        $GroupNumFname3 = $this->countemponfloor_names(3, "13");
        $grp13 = array_merge($GroupNumAname3, $GroupNumBname3);
        $grp23 = array_merge($GroupNumCname3, $GroupNumDname3);
        $grp33 = array_merge($GroupNumEname3, $GroupNumFname3);
        $grp43 = array_merge($grp13, $grp23);
        $grp53 = array_merge($grp33, $grp43);

        $GroupNumAname4 = $this->countemponfloor_names(4, "8");
        $GroupNumBname4 = $this->countemponfloor_names(4, "9");
        $GroupNumCname4 = $this->countemponfloor_names(4, "10");
        $GroupNumDname4 = $this->countemponfloor_names(4, "11");
        $GroupNumEname4 = $this->countemponfloor_names(4, "12");
        $GroupNumFname4 = $this->countemponfloor_names(4, "13");
        $grp14 = array_merge($GroupNumAname4, $GroupNumBname4);
        $grp24 = array_merge($GroupNumCname4, $GroupNumDname4);
        $grp34 = array_merge($GroupNumEname4, $GroupNumFname4);
        $grp44 = array_merge($grp14, $grp24);
        $grp54 = array_merge($grp34, $grp44);

        $GroupNumAname5 = $this->countemponfloor_names(5, "8");
        $GroupNumBname5 = $this->countemponfloor_names(5, "9");
        $GroupNumCname5 = $this->countemponfloor_names(5, "10");
        $GroupNumDname5 = $this->countemponfloor_names(5, "11");
        $GroupNumEname5 = $this->countemponfloor_names(5, "12");
        $GroupNumFname5 = $this->countemponfloor_names(5, "13");
        $grp15 = array_merge($GroupNumAname5, $GroupNumBname5);
        $grp25 = array_merge($GroupNumCname5, $GroupNumDname5);
        $grp35 = array_merge($GroupNumEname5, $GroupNumFname5);
        $grp45 = array_merge($grp15, $grp25);
        $grp55 = array_merge($grp35, $grp45);

        $GroupNumAname6 = $this->countemponfloor_names(6, "8");
        $GroupNumBname6 = $this->countemponfloor_names(6, "9");
        $GroupNumCname6 = $this->countemponfloor_names(6, "10");
        $GroupNumDname6 = $this->countemponfloor_names(6, "11");
        $GroupNumEname6 = $this->countemponfloor_names(6, "12");
        $GroupNumFname6 = $this->countemponfloor_names(6, "13");
        $grp16 = array_merge($GroupNumAname6, $GroupNumBname6);
        $grp26 = array_merge($GroupNumCname6, $GroupNumDname6);
        $grp36 = array_merge($GroupNumEname6, $GroupNumFname6);
        $grp46 = array_merge($grp16, $grp26);
        $grp56 = array_merge($grp36, $grp46);

        $GroupNumAname7 = $this->countemponfloor_names(7, "8");
        $GroupNumBname7 = $this->countemponfloor_names(7, "9");
        $GroupNumCname7 = $this->countemponfloor_names(7, "10");
        $GroupNumDname7 = $this->countemponfloor_names(7, "11");
        $GroupNumEname7 = $this->countemponfloor_names(7, "12");
        $GroupNumFname7 = $this->countemponfloor_names(7, "13");
        $grp17 = array_merge($GroupNumAname7, $GroupNumBname7);
        $grp27 = array_merge($GroupNumCname7, $GroupNumDname7);
        $grp37 = array_merge($GroupNumEname7, $GroupNumFname7);
        $grp47 = array_merge($grp17, $grp27);
        $grp57 = array_merge($grp37, $grp47);




        //==============================================




        $today = date("Y-m-d");
        $data['title'] = "Employees On leave";
        $data['presentEmpTour'] = $presentEmpTour;
        $data['presentEmpLeave'] = $presentEmpLeave;
        $data['countpresentEmpPresent'] = $countpresentEmpPresent;
        $data['countpresentEmpTour'] = $countpresentEmpTour;
        $data['countpresentEmpTour_cegth'] = count($countpresentEmpTour_cegth);
        $data['countpresentEmpLeave'] = $countpresentEmpLeave;
        $data['absentCount'] = $absentCount;
        $data['countEmpPresentceg'] = $countEmpPresentceg;
        $data['countEmpPresentcegth'] = $countEmpPresentcegth;
        $data['countEmpleaveceg'] = $countEmpleaveceg;
        $data['countEmpleavecegth'] = $countEmpleavecegth;
        $data['grp5'] = $grp5;
        $data['grp50'] = $grp50;
        $data['grp51'] = $grp51;
        $data['grp52'] = $grp52;
        $data['grp53'] = $grp53;
        $data['grp54'] = $grp54;
        $data['grp55'] = $grp55;
        $data['grp56'] = $grp56;
        $data['grp57'] = $grp57;


        $data['EmpPresent_ceg'] = $this->Emp_on_leave_tour_report_model->count_present_atten_report_ceg_nd_cegth_full_detail(1);
        $data['EmpTour_ceg'] = $this->Emp_on_leave_tour_report_model->count_tour_atten_report_ceg(1);
        $data['EmpTour_cegth'] = $this->Emp_on_leave_tour_report_model->count_tour_atten_report_ceg(2);
        $data['EmpLeave_ceg'] = $this->Emp_on_leave_tour_report_model->count_leave_by_businessid(1);
        $data['EmpLeave_cegth'] = $this->Emp_on_leave_tour_report_model->count_leave_by_businessid(2);
        $data['EmpPresent_cegth'] = $this->Emp_on_leave_tour_report_model->count_present_atten_report_ceg_nd_cegth_full_detail(2);
		$data['activeEmployeeCeg'] = $this->mastermodel->getTotalActiveEmployeeCeg(1);
		$data['activeEmployeeCegTh'] = $this->mastermodel->getTotalActiveEmployeeCeg(2);
		// $absentEmpListCeg = array_merge($countpresentEmpTour_ceg,$);
		
        $this->load->view("emp_on_leave/emp_on_leave_view", $data);
    }

    public function ajax_emp_floor_report_data() {
        $list = array("-1" => "-1", "0" => "0", "1" => "1", "2" => "2", "3" => "3", "4" => "4", "5" => "5", "6" => "6", "7" => "7");
        // $list = array("1" => "1", "2" => "2", "3" => "3", "4" => "4", "5" => "5", "6" => "6", "7" => "7", "8" => "8", "9" => "9");
        $data = array();
        $no = $_POST['start'];
        $recData = array();
        $rowTotal = 0;
        $rowTotal2 = 0;
        $colTotal1 = 0;
        $colTotal2 = 0;
        $colTotal3 = 0;
        $colTotal4 = 0;
        $colTotal5 = 0;
        $colTotal6 = 0;
        $colTotal7 = 0;

        // $GroupNumAname = $this->countemponfloor_names("1", "8");
        // echo "<pre>"; print_r($GroupNumAname); die;
        foreach ($list as $kkeY => $rOws) {
            $no++;
            $GroupNumA = $this->countemponfloor($kkeY+2, "8");
            $GroupNumB = $this->countemponfloor($kkeY+2, "9");
            $GroupNumC = $this->countemponfloor($kkeY+2, "10");
            $GroupNumD = $this->countemponfloor($kkeY+2, "11");
            $GroupNumE = $this->countemponfloor($kkeY+2, "12");
            $GroupNumF = $this->countemponfloor($kkeY+2, "13");
            $rowTotal = $GroupNumA + $GroupNumB + $GroupNumC + $GroupNumD + $GroupNumE + $GroupNumF;

            // $GroupNumA = countemponfloor_names_new($kkeY, "8");
            // $GroupNumB = countemponfloor_names_new($kkeY, "9");
            // $GroupNumC = countemponfloor_names_new($kkeY, "10");
            // $GroupNumD = countemponfloor_names_new($kkeY, "11");
            // $GroupNumE = countemponfloor_names_new($kkeY, "12");
            // $GroupNumF = countemponfloor_names_new($kkeY, "13");
            // $rowTotal = $GroupNumA+$GroupNumB+$GroupNumC+$GroupNumD+$GroupNumE+$GroupNumF; 



            $row = array();
            $row[] = $no;
            $row[] = $kkeY;
            $row[] = $GroupNumA;
            $row[] = $GroupNumB;
            $row[] = $GroupNumC;
            $row[] = $GroupNumD;
            $row[] = $GroupNumE;
            $row[] = $GroupNumF;
            // $row[] = '<b><button onclick="showtable('.$rowTotal.')" id="count_'.$rowTotal.'" >'.$rowTotal.'</button></b>';
            $row[] = '<a class="btn" data-toggle="modal" data-target="#myModal" onclick="showtable(' . "'" . $rowTotal . "'" . ')">' . $rowTotal . '</a>';
            $data[] = $row;
        }
        // foreach ($list as $kkeY => $rOws) {
        // $no++;
        // $GroupNumA = $this->countemponfloor($kkeY, "8");
        // $GroupNumB = $this->countemponfloor($kkeY, "9");
        // $GroupNumC = $this->countemponfloor($kkeY, "10");
        // $GroupNumD = $this->countemponfloor($kkeY, "11");
        // $GroupNumE = $this->countemponfloor($kkeY, "12");
        // $GroupNumF = $this->countemponfloor($kkeY, "13");
        // $rowTotal2 = $GroupNumA+$GroupNumB+$GroupNumC+$GroupNumD+$GroupNumE+$GroupNumF; 
        // $colTotal1 += $GroupNumA; 
        // $colTotal2 += $GroupNumB; 
        // $colTotal3 += $GroupNumC; 
        // $colTotal4 += $GroupNumD; 
        // $colTotal5 += $GroupNumE; 
        // $colTotal6 += $GroupNumF; 
        // $colTotal7 += $rowTotal2; 
        // }
        // $row = array();
        // $row[] = '8';
        // $row[] = '-';
        // $row[] = "<b>".$colTotal1."</b>";
        // $row[] = "<b>".$colTotal2."</b>";
        // $row[] = "<b>".$colTotal3."</b>";
        // $row[] = "<b>".$colTotal4."</b>";
        // $row[] = "<b>".$colTotal5."</b>";
        // $row[] = "<b>".$colTotal6."</b>";
        // $row[] = "<b>".$colTotal7."</b>";
        // $data[] = $row;
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => count($list),
            "recordsFiltered" => count($list),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function countemponfloor($floorId, $groupID) {
        $today = date("Y-m-d");
        $this->db->select("c.*");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
        $this->db->where(array("a.isactive" => "1", "b.status" => "1", "b.floor_number" => $floorId, "a.jobtitle_id" => $groupID));
        $this->db->where("c.LogDate LIKE '%$today%'");
        $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }

    public function countemponfloor_names($floorId, $groupID) {
        $today = date("Y-m-d");
        $this->db->select("a.userfullname,a.jobtitle_name,a.employeeId");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
        $this->db->where(array("a.isactive" => "1", "b.status" => "1", "b.floor_number" => $floorId, "a.jobtitle_id" => $groupID));
        $this->db->where("c.LogDate LIKE '%$today%'");
        $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        $recArr = $this->db->get()->result();
        // return ($recArr) ? $recArr : null;
        return $recArr;
    }

}
