<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Attreport_controller extends CI_Controller {

    function __construct() {
        parent::__construct();

        $this->load->helper(array('form', 'url'));
        $this->load->library('../core/security');
        $this->load->library('form_validation');
        $this->load->model('attreport_model');
        $this->load->library('tank_auth');
        $this->load->library('session');
        $this->lang->load('tank_auth');
        $this->load->library("user_agent");
        //check permission..................................................
        $role = $this->tank_auth->get_role($this->tank_auth->get_user_id());
        $user_id = $this->tank_auth->get_user_id();
//        if (!has_permission($user_id, 'manage_cms', $role)):
//            $url = $this->agent->referrer();
//            echo PERMISSION_MESSAGE . '<a href=' . $url . '>Back</a>';
//            die;
//        endif;
        //end.....................
    }

    function index() {
        $data['errors'] = array();
        $recData = array('');
        $recData['htitle'] = "Employee Attendance Report View";
        if (isset($_REQUEST['filterrep'])) {
            $recData['reportmonth'] = $_REQUEST['repmonth'];
            $recData['reportyear'] = $_REQUEST['repyear'];
            $recData['reportbunit'] = $_REQUEST['businessunit'];
        }
        $this->load->view("back_end/Attreport/index", $recData);
    }

    public function ajax_list() {
        $repmonth = $_REQUEST['repmonth'];
        $repyear = $_REQUEST['repyear'];
        $reportbunit = $_REQUEST['reportbunit'];

        $filterArr = array(
            'repmonth' => $repmonth,
            'repyear' => $repyear,
            'reportbunit' => $reportbunit,
        );

        $list = $this->attreport_model->get_datatables($filterArr);
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $atten) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $atten['userfullname'];
            $row[] = $atten['position_name'];
            $row[] = $atten['department_name'];
            $row[] = $this->realformated($atten['1']);
            $row[] = $atten['2'];
            $row[] = $atten['3'];
            $row[] = $atten['4'];
            $row[] = $atten['5'];
            $row[] = $atten['6'];
            $row[] = $atten['7'];
            $row[] = $atten['8'];
            $row[] = $atten['9'];
            $row[] = $atten['10'];
            $row[] = $atten['11'];
            $row[] = $atten['12'];

            $data[] = $row;
        }
        $output = array("draw" => $_POST['draw'],
            "recordsTotal" => $this->attreport_model->count_all(),
            "recordsFiltered" => $this->attreport_model->count_filtered(),
            "data" => $data);
        //output to json format
        echo json_encode($output);
    }

    public function realformated($Record_att) {
        // return '09:30 AM / 06:00 PM'."<br>".'<span>P</span>';
        $outtm = '';
        $intm = '';
        $nooflate_come = 0;
        $Record_att = str_replace("&nbsp;", "", $Record_att);
        $AllRec = explode(",", $Record_att);
        return $AllRec[0];
    }

    public function _is_unique_name($value, $field) {
        $result = $this->db->where('name !=', $value)
                ->where($field, $value)
                ->get('cms')
                ->row_array();
        if ($result) {
            $this->form_validation->set_message('_is_unique_name', '%s already exists');
            return false;
        }
        return true;
    }

    function edit($id) {
        $data['errors'] = array();
        $data['result'] = $this->attreport_model->get_cms_by_id($id);
        if ($this->input->post('cms_id')) {
            $this->form_validation->set_rules('name', 'Name', 'required|trim|callback__is_unique_name[name]');
            if ($this->form_validation->run() == FALSE) {
                
            } else {
                $dataInfo['name'] = $this->input->post('name');
                $dataInfo['description'] = $this->input->post('description');
                $dataInfo['status'] = $this->input->post('status');
                if ($this->attreport_model->update($dataInfo, $this->input->post('cms_id'))) {
                    $this->session->set_flashdata('success_msg', 'CMS has been updated successfully');
                    redirect('/manage-cms-page');
                }
            }
        }
        $this->load->view("back_end/Attreport/edit", $data);
    }

    function view($id) {
        $data['result'] = $this->attreport_model->get_cms_by_id($id);
        $this->load->view('back_end/Attreport/view', $data);
    }

    public function att_miss_punch() {
        $data['error'] = array();
        $data['htitle'] = "Attendance Miss Punch Management";
        $this->db->select('thumbid,EmployeeID,EmployeeName');
        $this->db->where('Status', '1');
        $this->db->group_by('EmployeeID');
        $this->db->order_by('EmployeeName', 'ASC');
        $query = $this->db->get('thumb_attendance');
        $data['thumemplist'] = $query->result();
        $this->load->view('back_end/Attreport/miss_punch', $data);
    }

    //For All Employee
    public function setatten_puncha_all() {
        $datersArr = array('2019-07-01','2019-07-02','2019-07-03','2019-07-04','2019-07-05','2019-07-06','2019-07-07','2019-07-08');
        //,'2019-05-09','2019-05-10','2019-05-11','2019-05-12','2019-05-13','2019-05-14','2019-05-15','2019-05-16','2019-05-17','2019-05-18','2019-05-19','2019-05-20','2019-05-21','2019-05-22','2019-05-23','2019-05-24','2019-05-25','2019-05-26','2019-05-27','2019-05-28','2019-05-29','2019-05-30','2019-05-31'
        
        foreach ($datersArr as $rowers) {
            $_REQUEST['missp_date'] = $rowers;
            if ($_REQUEST['missp_date']):
                $mnth = intval(date("m", strtotime($_REQUEST['missp_date'])));
                $dateth = intval(date("d", strtotime($_REQUEST['missp_date'])));
                $frmtDate = intval($mnth) . "/" . intval($dateth) . "/" . date("Y", strtotime($_REQUEST['missp_date']));
                $frmtDate2 = (string) $frmtDate;
                $yearr = date("Y", strtotime($_REQUEST['missp_date']));
                // $empid = $_REQUEST['empthumb'];
                $datarecs = $this->getonedayatten_all($frmtDate2);
                if ($datarecs) {
                    foreach ($datarecs as $emprow):
                        $empID = $this->getuseridByThumb($emprow['EmployeeID']);
                        $updResult = '0';
                        if ($datarecs != '') {
                            $updResult = $emprow['FirstIn'] . ", " . $emprow['LastOut'];
                            $returnd = $this->db->query("UPDATE monthly_attendance SET `$dateth`='" . $updResult . "' WHERE (`emp_id` ='" . $empID . "' AND `year` = $yearr AND `month` = $mnth )  ");
                        }
                        echo $emprow['EmployeeName'] . $empID . '--' . $emprow['EmployeeID'] . "<br>";
                    endforeach;
                }
            endif;
        }
        die;
    }

    //Get One day Atten All Emp 
    public function getonedayatten_all($frmtDate) {
        $frmtDate1 = (string) $frmtDate;
        // echo $frmtDate; die;
        $this->db->select('*');
        $this->db->where(array('Status' => '1'));
        $this->db->like('FirstIn', "$frmtDate1", 'both');
        $query = $this->db->get('thumb_attendance');
        $datarecs = $query->result_array();
        return ($datarecs) ? $datarecs : false;
    }

    //Get USER ID By ThumbCode..
    public function getuseridByThumb($empthum) {
        $this->db->select('user_id');
        $this->db->where(array('thumbcode' => $empthum, 'status' => '1'));
        $query = $this->db->get('emp_otherofficial_data');
        $datarecs = $query->row();
        return ($datarecs) ? $datarecs->user_id : false;
    }

    //Set Day Attendance....
    public function setatten_punch() {
        if (($_REQUEST['missp_date']) and ( $_REQUEST['empthumb'])):
            $mnth = intval(date("m", strtotime($_REQUEST['missp_date'])));
            $dateth = intval(date("d", strtotime($_REQUEST['missp_date'])));
            $frmtDate = intval($mnth) . "/" . intval($dateth) . "/" . date("Y", strtotime($_REQUEST['missp_date']));
            $frmtDate2 = (string) $frmtDate;
            $yearr = date("Y", strtotime($_REQUEST['missp_date']));
            $empid = $_REQUEST['empthumb'];
            //Get This Date Attendance..
            $datarecs = $this->getonedayatten($empid, $frmtDate2);
            $empID = $this->getuseridByThumb($empid);
            $updResult = '0';
            if ($datarecs != '') {
                $updResult = $datarecs->FirstIn . ", " . $datarecs->LastOut;
            }
            $returnd = $this->db->query("UPDATE monthly_attendance SET `$dateth`='" . $updResult . "' WHERE (`emp_id` = $empID AND `year` = $yearr AND `month` = $mnth )  ");
            if ($returnd):
                $this->session->set_flashdata('message', 'Success');
            else:
                $this->session->set_flashdata('error', 'Something Went Error');
            endif;
        endif;
        redirect(base_url('att_miss_punch'));
    }

    //Set Day Attendance Insert ....
    public function setatten_punch_insert() {
        if (($_REQUEST['missp_date']) and ( $_REQUEST['empthumb']) and ( $_REQUEST['intime']) and ( $_REQUEST['outtime'])):
            $empid = $_REQUEST['empthumb'];
            $empID = $this->getuseridByThumb($empid);
            $mnth = intval(date("m", strtotime($_REQUEST['missp_date'])));
            $dateth = intval(date("d", strtotime($_REQUEST['missp_date'])));
            $frmtDate = intval($mnth) . "/" . intval($dateth) . "/" . date("Y", strtotime($_REQUEST['missp_date']));
            $frmtDate2 = (string) $frmtDate;
            $yearr = date("Y", strtotime($_REQUEST['missp_date']));
            $updResult = $frmtDate . " " . $_REQUEST['intime'] . "," . $frmtDate . " " . $_REQUEST['outtime'];
            $returnd = $this->db->query("UPDATE monthly_attendance SET `$dateth`='" . $updResult . "' WHERE (`emp_id` = $empID AND `year` = $yearr AND `month` = $mnth )  ");
            $recArrInout = $this->getonedayatten($empid, $frmtDate);
            $upd2RecArr = array('FirstIn' => $frmtDate . " " . $_REQUEST['intime'], 'LastOut' => $frmtDate . " " . $_REQUEST['outtime']);
            $myrespo = $this->updateonedayatten($empid, $frmtDate, $upd2RecArr);
            if ($myrespo):
                $this->session->set_flashdata('message', 'Success');
            else:
                $this->session->set_flashdata('error', 'Something Went Error');
            endif;

        endif;
        redirect(base_url('back_end/attreport_controller/att_miss_punch'));
    }

    public function updateonedayatten($empthumb, $frmtDate1, $upd2RecArr) {
        $this->db->like('FirstIn', "$frmtDate1", 'both');
        $this->db->where(array('Status' => '1', 'EmployeeID' => $empthumb));
        $datarecs = $this->db->update('thumb_attendance', $upd2RecArr);
        return ($datarecs) ? $datarecs : false;
    }

    public function getonedayatten($empthumb, $frmtDate) {
        $frmtDate1 = (string) $frmtDate;
        // echo $frmtDate; die;
        $this->db->select('FirstIn,LastOut');
        $this->db->where(array('Status' => '1', 'EmployeeID' => $empthumb));
        $this->db->like('FirstIn', "$frmtDate1", 'both');
        $query = $this->db->get('thumb_attendance');
        $datarecs = $query->row();
        return ($datarecs) ? $datarecs : false;
    }

}
