<?php

defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('max_execution_time', 0); 
class Attendance_controller extends CI_Controller {
	
    public function __construct() {
        parent::__construct();

        $this->load->model('attendance');
        // $this->load->model('attendanceteamwise');
        // $this->load->model('Siteofficeattendance');
        $this->load->helper(array('form', 'url'));
        $this->load->library('../core/security');
        $this->load->library('form_validation');
        // $this->load->model('User');
        // $this->load->model('Common_model');
        // $this->load->library('tank_auth');
        $this->load->library('session');
        // $this->lang->load('tank_auth');
        // $this->load->library("user_agent");
        // $this->load->library('phppass-0.1/PasswordHash');
//check permission..................................................
        // $role = $this->tank_auth->get_role($this->tank_auth->get_user_id());
        // $user_id = $this->tank_auth->get_user_id();
    }

    //Attendance Controller..
    public function index12() {
        $this->load->helper('url');
        $this->load->helper('form');
        $recData = array('');
        $recData['title'] = "Employee Attendance View All";
        if (isset($_REQUEST['filterrep'])) {
            $recData['reportmonth'] = $_REQUEST['repmonth'];
            $recData['reportyear'] = $_REQUEST['repyear'];
            $recData['reportbunit'] = $_REQUEST['businessunit'];
        }
		else{
			$recData['reportmonth'] = date('n');
            $recData['reportyear'] = date('Y');
			$recData['reportbunit'] = '1';
		}
		
        $this->load->view('back_end/attendance/list_view', $recData);
    }

    public function errorpage() {
        echo "Something went wrong";
        die;
    }

    //Code Modify on 08-12-2018.
    public function ajax_lists() {
        $repyear = $_REQUEST['repyear'];
        $repmonth = $_REQUEST['repmonth'];
        $reportbunit = $_REQUEST['reportbunit'];
		 // echo $repyear.','.$repmonth.','.$reportbunit; die;
//        $repyear = '2018';
//        $repmonth = '11';
//        $reportbunit = '1';

        $filterArr = array('repyear' => $repyear, 'repmonth' => $repmonth, 'reportbunit' => $reportbunit);
        $list = $this->attendance->get_datatables($repyear, $repmonth);
		// echo "<pre>"; print_r($list); die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $attend) {
            $no++;

            $RPNun77 = 0;

            $row = array();
            $row[] = $no;
            //  $row[] = "<b>" . $attend['userfullname'] . "</b><br><span style='color:green'>" . $attend['position_name'] . "</span><br>" . $attend['department_name'];
            $row[] = $attend['userfullname'];
            $row[] = $attend['position_name'];
            $row[] = $attend['department_name'];
//            $row[] = $attend['no_of_late_hd'];
            //1..
            $startDate11 = "1" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN1 = $this->checkallcond($attend['1'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN1 == 'P') {
                $RPNun = $this->secondlayerchk($attend['1'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN1;
            }
            //2...
            $startDate11 = "2" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN2 = $this->checkallcond($attend['2'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN2 == 'P') {
                $RPNun = $this->secondlayerchk($attend['2'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN2;
            }
            //3..
            $startDate11 = "3" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN3 = $this->checkallcond($attend['3'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN3 == 'P') {
                $RPNun = $this->secondlayerchk($attend['3'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN3;
            }
            //4
            $startDate11 = "4" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN4 = $this->checkallcond($attend['4'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN4 == 'P') {
                $RPNun = $this->secondlayerchk($attend['4'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN4;
            }
            //5..
            $startDate11 = "5" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN5 = $this->checkallcond($attend['5'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN5 == 'P') {
                $RPNun = $this->secondlayerchk($attend['5'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN5;
            }
            //6...
            $startDate11 = "6" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN6 = $this->checkallcond($attend['6'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN6 == 'P') {
                $RPNun = $this->secondlayerchk($attend['6'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN6;
            }
            //7..
            $startDate11 = "7" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN7 = $this->checkallcond($attend['7'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN7 == 'P') {
                $RPNun = $this->secondlayerchk($attend['7'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN7;
            }
            //8..
            $startDate11 = "8" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN8 = $this->checkallcond($attend['8'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN8 == 'P') {
                $RPNun = $this->secondlayerchk($attend['8'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN8;
            }
            //9..
            $startDate11 = "9" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN9 = $this->checkallcond($attend['9'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN9 == 'P') {
                $RPNun = $this->secondlayerchk($attend['9'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN9;
            }
            //10
            $startDate11 = "10" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN10 = $this->checkallcond($attend['10'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN10 == 'P') {
                $RPNun = $this->secondlayerchk($attend['10'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN10;
            }
            //11..
            $startDate11 = "11" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN11 = $this->checkallcond($attend['11'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN11 == 'P') {
                $RPNun = $this->secondlayerchk($attend['11'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN11;
            }
            //12..
            $startDate11 = "12" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN12 = $this->checkallcond($attend['12'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN12 == 'P') {
                $RPNun = $this->secondlayerchk($attend['12'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN12;
            }
            //13..
            $startDate11 = "13" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN13 = $this->checkallcond($attend['13'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN13 == 'P') {
                $RPNun = $this->secondlayerchk($attend['13'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN13;
            }
            //14..
            $startDate11 = "14" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN14 = $this->checkallcond($attend['14'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN14 == 'P') {
                $RPNun = $this->secondlayerchk($attend['14'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN14;
            }
            //15..
            $startDate11 = "15" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN15 = $this->checkallcond($attend['15'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN15 == 'P') {
                $RPNun = $this->secondlayerchk($attend['15'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN15;
            }

            //16..
            $startDate11 = "16" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN16 = $this->checkallcond($attend['16'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN16 == 'P') {
                $RPNun = $this->secondlayerchk($attend['16'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN16;
            }

            //17..
            $startDate11 = "17" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN17 = $this->checkallcond($attend['17'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN17 == 'P') {
                $RPNun = $this->secondlayerchk($attend['17'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN17;
            }
            //18..
            $startDate11 = "18" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN18 = $this->checkallcond($attend['18'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN18 == 'P') {
                $RPNun = $this->secondlayerchk($attend['18'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN18;
            }
            //19..
            $startDate11 = "19" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN19 = $this->checkallcond($attend['19'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN19 == 'P') {
                $RPNun = $this->secondlayerchk($attend['19'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN19;
            }
            //20..
            $startDate11 = "20" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN20 = $this->checkallcond($attend['20'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN20 == 'P') {
                $RPNun = $this->secondlayerchk($attend['20'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN20;
            }
            //21..
            $startDate11 = "21" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN21 = $this->checkallcond($attend['21'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN21 == 'P') {
                $RPNun = $this->secondlayerchk($attend['21'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN21;
            }
            //22..
            $startDate11 = "22" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN22 = $this->checkallcond($attend['22'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN22 == 'P') {
                $RPNun = $this->secondlayerchk($attend['22'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN22;
            }
            //23..
            $startDate11 = "23" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN23 = $this->checkallcond($attend['23'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN23 == 'P') {
                $RPNun = $this->secondlayerchk($attend['23'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN23;
            }
            //24..
            $startDate11 = "24" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN24 = $this->checkallcond($attend['24'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN24 == 'P') {
                $RPNun = $this->secondlayerchk($attend['24'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN24;
            }
            //25..
            $startDate11 = "25" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN25 = $this->checkallcond($attend['25'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN25 == 'P') {
                $RPNun = $this->secondlayerchk($attend['25'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN25;
            }

            //26..
            $startDate11 = "26" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN26 = $this->checkallcond($attend['26'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN26 == 'P') {
                $RPNun = $this->secondlayerchk($attend['26'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN26;
            }
            //27..
            $startDate11 = "27" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN27 = $this->checkallcond($attend['27'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN27 == 'P') {
                $RPNun = $this->secondlayerchk($attend['27'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN27;
            }

            //28..
            $startDate11 = "28" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN28 = $this->checkallcond($attend['28'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN28 == 'P') {
                $RPNun = $this->secondlayerchk($attend['28'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN28;
            }
            //29..
            $startDate11 = "29" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN29 = $this->checkallcond($attend['29'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN29 == 'P') {
                $RPNun = $this->secondlayerchk($attend['29'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN29;
            }
            //30,,
            $startDate11 = "30" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN30 = $this->checkallcond($attend['30'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN30 == 'P') {
                $RPNun = $this->secondlayerchk($attend['30'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN30;
            }
            //31..
            $startDate11 = "31" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
            $respN31 = $this->checkallcond($attend['31'], $filterArr, $startDate11, $attend['emp_id']);
            if ($respN31 == 'P') {
                $RPNun = $this->secondlayerchk($attend['31'], $filterArr, $startDate11, $attend['emp_id']);
                if ($RPNun == '1') {
                    $RPNun77 = ($RPNun77 + 1);
                }
                if (($RPNun77 > 3) and ( $RPNun == '1')) {
                    $row[] = 'LHD';
                } else {
                    $row[] = 'P';
                }
            } else {
                $row[] = $respN31;
            }
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->attendance->count_all($repyear, $repmonth),
            "recordsFiltered" => $this->attendance->count_filtered($repyear, $repmonth),
            "data" => $data,
        );
//echo "Asheesh";
        echo json_encode($output);
    }

    public function secondlayerchk($Record_att, $filterArr, $actdate, $emp_id) {
        $Record_att = str_replace("&nbsp;", "", $Record_att);
        $Record_att = str_replace(" ", "", $Record_att);
        $AllRec = explode(",", $Record_att);

        $inampm = substr($AllRec['0'], -2);
        $outampm = substr($AllRec['1'], -2);
        $i_tm = date('h:i:s A', strtotime($AllRec['0']));
        $hdNo = '0';
        if (strtotime($i_tm) > strtotime('09:45:00 AM')) {
            $hdNo = 1;
        }
        return $hdNo;
    }

//custom Code By Asheesh..
    public function checkallcond($Record_att, $filterArr, $actdate, $emp_id) {
        $monthN = array('1' => 'Jan', '2' => 'Feb', '3' => 'Mar', '4' => 'Apr', '5' => 'May', '6' => 'Jun', '7' => 'Jul', '8' => 'Aug', '9' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec');
        switch ($Record_att) {
            case 0:
                //Check Tour..
                $respoo = $this->tourexistondate($emp_id, date('Y-m-d', strtotime($actdate)));
                if ($respoo == 1) {
                    return 'T';
                }
                //check Leave..
                $resp_leave = $this->emp_leaveexist($emp_id, date('Y-m-d', strtotime($actdate)));
                if ($resp_leave == 1) {
                    return 'L';
                }
                //RH Holidays
                if ($resp_leave == 'RH') {
                    return 'RH';
                }
                //Holidays Check..
                $holidResp = $this->isholidays(date('Y-m-d', strtotime($actdate)));
                if ($holidResp == 1) {
                    return 'H';
                }
                //For sunday
                if (date('l', strtotime($actdate)) == "Sunday") {
                    return 'WO';
                }
                //For Sat CEG.
                if ($filterArr['reportbunit'] == 1) {
                    
                    $firstReturn = date("Y-m-d", strtotime("first saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));
                    $thirdReturn = date("Y-m-d", strtotime("third saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));

                    if (date('Y-m-d', strtotime($actdate)) == $firstReturn) {
                        return "WO";
                    }
                    if (date('Y-m-d', strtotime($actdate)) == $thirdReturn) {
                        return "WO";
                    }
                }
                //For Sat CEGTH..
                if ($filterArr['reportbunit'] == 2) {
                    $thirdReturn = date("Y-m-d", strtotime("third saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));
                    if (date('Y-m-d', strtotime($actdate) == $thirdReturn)) {
                        return "WOR";
                    } else {
                        return "A";
                    }
                }
                return "A";
                break;
            case ($Record_att != '0'):
                $outtm = '';
                $intm = '';
                $nooflate_come = 0;
                $Record_att = str_replace("&nbsp;", "", $Record_att);
                $Record_att = str_replace(" ", "", $Record_att);
                // return $Record_att;
                $AllRec = explode(",", $Record_att);
                if (count(array_filter($AllRec)) < 2) {
                    return 'MP';
                }
                $inampm = substr($AllRec['0'], -2);
                $outampm = substr($AllRec['1'], -2);
                $i_tm = date('h:i:s', strtotime($AllRec['0']));
                $o_tm = date('h:i:s', strtotime($AllRec['1']));
                $realintm = $i_tm . " " . $inampm;
                $realouttm = $o_tm . " " . $outampm;

                //Working Hour Less Than Four A..
                $time1 = strtotime("$realintm");
                $time2 = strtotime("$realouttm");
                $difference = round(abs($time2 - $time1) / 3600, 2);
                if ($difference < 4) {
                    return 'A';
                }
                if (strtotime($realintm) > strtotime('10:29:00 AM')) {
                    return 'HD';
                }
                if (strtotime($realouttm) < strtotime('5:00:00 PM')) {
                    return 'HD';
                }
                return 'P';
                break;
            //Check Starday
            default:
                return 'P';
        }
    }

    //Get Is Holiday on a Particular Date..
    public function isholidays($actDate) {
        $respon = $this->attendance->check_isholidays($actDate);
        return $respon;
    }

    //No Of Week Monthly 
    function weekOfMonth($date) {
        list($y, $m, $d) = explode('-', date('Y-m-d', strtotime($date)));
        $w = 1;
        for ($i = 1; $i <= $d; ++$i) {
            if ($i > 1 && date('w', strtotime("$y-$m-$i")) == 1) {
                ++$w;
            }
        }
        return $w;
    }

    //Check Exist Leave..
    public function emp_leaveexist($userid, $tdate) {
        $reqleaveArr = $this->attendance->all_emp_leaves($userid);
        if ($reqleaveArr):
            foreach ($reqleaveArr as $leavesrows):
                if ($leavesrows['leavestatus'] == 'Pending for approval' OR $leavesrows['leavestatus'] == 'Approved') {
                    $respoo = $this->check_in_range($leavesrows['from_date'], $leavesrows['to_date'], $tdate);
                    if ($respoo == 1) {
                        if ($leavesrows['leavetypeid'] == '5'):
                            return 'RH';
                        endif;

                        return 1;
                    }
                }
            endforeach;
        endif;
        return false;
    }

    //Check Tour Exist or Not a Particular Date ..
    public function tourexistondate($userid, $tdate) {
        $tourDates = $this->attendance->getallTourDates($userid);
        if ($tourDates):
            foreach ($tourDates as $tourcols):
                $respoo = $this->check_in_range($tourcols['start_date'], $tourcols['end_date'], $tdate);
                if ($respoo == 1) {
                    return 1;
                }
            endforeach;
        endif;
        return false;
    }

    //Date Range Exist or Not a Particular Date ..
    public function check_in_range($start_date, $end_date, $date_from_user) {
        // Convert to timestamp
        $start_ts = strtotime($start_date);
        $end_ts = strtotime($end_date);
        $user_ts = strtotime($date_from_user);
        // Check that user date is between start & end
        return (($user_ts >= $start_ts) && ($user_ts <= $end_ts));
    }

//Get All Weekends..
    public function getweekendbymonth() {
        $filterArr = array('repyear' => 2017, 'repmonth' => 11, 'reportbunit' => 1);
        foreach ($this->getSundays($filterArr['repyear'], $filterArr['repmonth']) as $wednesday) {
            echo date("l, Y-m-d\n", $wednesday);
        }
    }

//Get All Sunday..
    public function getSundays($y, $m) {
        $ts = strtotime("first wednesday $y-$m-01");
        $end = strtotime("last wednesday $y-$m");
        $wednesdays = array();
        while ($ts <= $end) {
            $wednesdays[] = $ts;
            $ts = strtotime('next wednesday', $ts);
        }
        return $wednesdays;
    }

    public function siteofficeAttendence() {
        $project = $this->Common_model->getAllproject();
        $this->load->view('back_end/attendance/siteofficeattendance_view', compact('project'));
    }

    public function siteofficeajax_list() {
        $list = $this->Siteofficeattendance->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $val) {
            $result[] = $this->getsiteofficeData($val->emp_id, $val->project_id, $val->ts_year, $val->ts_month, $val->userfullname, $val->position_name);
        }
        //echo '<pre>';
        $d1 = $d2 = $d3 = $d4 = $d5 = $d6 = $d7 = $d8 = $d9 = $d10 = $d11 = $d12 = $d13 = $d14 = $d15 = $d16 = $d17 = $d18 = $d19 = $d20 = $d21 = $d22 = $d23 = $d24 = $d25 = $d26 = $d27 = $d28 = $d29 = $d30 = $d31 = '';
        foreach ($result as $val1) {

            if (!empty($val1[1])) {
                $d1 = explode(',', $val1[1]);
                $d1 = isset($d1) ? $d1 : '';
            }
            if (!empty($val1[2])) {
                $d2 = explode(',', $val1[2]);
                $d2 = isset($d2) ? $d2 : '';
            }
            if (!empty($val1[3])) {
                $d3 = explode(',', $val1[3]);
                $d3 = isset($d3) ? $d3 : '';
            }
            if (!empty($val1[4])) {
                $d4 = explode(',', $val1[4]);
                $d4 = isset($d4) ? $d4 : '';
            }
            if (!empty($val1[5])) {
                $d5 = explode(',', $val1[5]);
                $d5 = isset($d5) ? $d5 : '';
            }
            if (!empty($val1[6])) {
                $d6 = explode(',', $val1[6]);
                $d6 = isset($d6) ? $d6 : '';
            }
            if (!empty($val1[7])) {
                $d7 = explode(',', $val1[7]);
                $d7 = isset($d7) ? $d7 : '';
            }
            if (!empty($val1[8])) {
                $d8 = explode(',', $val1[8]);
                $d8 = isset($d8) ? $d8 : '';
            }
            if (!empty($val1[9])) {
                $d9 = explode(',', $val1[9]);
                $d9 = isset($d9) ? $d9 : '';
            }
            if (!empty($val1[10])) {
                $d10 = explode(',', $val1[10]);
                $d10 = isset($d10) ? $d10 : '';
            }
            if (!empty($val1[11])) {
                $d11 = explode(',', $val1[11]);
                $d11 = isset($d11) ? $d11 : '';
            }
            if (!empty($val1[12])) {
                $d12 = explode(',', $val1[12]);
                $d12 = isset($d12) ? $d12 : '';
            }
            if (!empty($val1[13])) {
                $d13 = explode(',', $val1[13]);
                $d13 = isset($d13) ? $d13 : '';
            }
            if (!empty($val1[14])) {
                $d14 = explode(',', $val1[14]);
                $d14 = isset($d14) ? $d14 : '';
            }
            if (!empty($val1[15])) {
                $d15 = explode(',', $val1[15]);
                $d15 = isset($d15) ? $d15 : '';
            }
            if (!empty($val1[16])) {
                $d16 = explode(',', $val1[16]);
                $d16 = isset($d16) ? $d16 : '';
            }
            if (!empty($val1[17])) {
                $d17 = explode(',', $val1[17]);
                $d17 = isset($d17) ? $d17 : '';
            }
            if (!empty($val1[18])) {
                $d18 = explode(',', $val1[18]);
                $d18 = isset($d18) ? $d18 : '';
            }
            if (!empty($val1[19])) {
                $d19 = explode(',', $val1[19]);
                $d19 = isset($d19) ? $d19 : '';
            }
            if (!empty($val1[20])) {
                $d20 = explode(',', $val1[20]);
                $d20 = isset($d20) ? $d20 : '';
            }
            if (!empty($val1[21])) {
                $d21 = explode(',', $val1[21]);
                $d21 = isset($d21) ? $d21 : '';
            }
            if (!empty($val1[22])) {
                $d22 = explode(',', $val1[22]);
                $d22 = isset($d22) ? $d22 : '';
            }
            if (!empty($val1[23])) {
                $d23 = explode(',', $val1[23]);
                $d23 = isset($d23) ? $d23 : '';
            }
            if (!empty($val1[24])) {
                $d24 = explode(',', $val1[24]);
                $d24 = isset($d24) ? $d24 : '';
            }
            if (!empty($val1[25])) {
                $d25 = explode(',', $val1[25]);
                $d25 = isset($d25) ? $d25 : '';
            }

            if (!empty($val1[26])) {
                $d26 = explode(',', $val1[26]);
                $d26 = isset($d26) ? $d26 : '';
            }
            if (!empty($val1[27])) {
                $d27 = explode(',', $val1[27]);
                $d27 = isset($d27) ? $d27 : '';
            }
            if (!empty($val1[28])) {
                $d28 = explode(',', $val1[28]);
                $d28 = isset($d28) ? $d28 : '';
            }
            if (!empty($val1[29])) {
                $d29 = explode(',', $val1[29]);
                $d29 = isset($d29) ? $d29 : '';
            }
            if (!empty($val1[30])) {
                $d30 = explode(',', $val1[30]);
                $d30 = isset($d30) ? $d30 : '';
            }
            if (!empty($val1[31])) {
                $d31 = explode(',', $val1[31]);
                $d31 = isset($d31) ? $d31 : '';
            }
            $no++;
            $row = array();
            $row[] = $no;
            // $row[] = ($d1) ? $d1[2] : '';
            // $row[] = ($d1) ? $d1[3] : '';
            $row[] = $val1['name']['name'];
            $row[] = $val1['name']['position'];
            $row[] = ($d1) ? $d1[1] : '';
            $row[] = ($d2) ? $d2[1] : '';
            $row[] = ($d3) ? $d3[1] : '';
            $row[] = ($d4) ? $d4[1] : '';
            $row[] = ($d5) ? $d5[1] : '';
            $row[] = ($d6) ? $d6[1] : '';
            $row[] = ($d7) ? $d7[1] : '';
            $row[] = ($d8) ? $d8[1] : '';
            $row[] = ($d9) ? $d9[1] : '';
            $row[] = ($d10) ? $d10[1] : '';
            $row[] = ($d11) ? $d11[1] : '';
            $row[] = ($d12) ? $d12[1] : '';
            $row[] = ($d13) ? $d13[1] : '';
            $row[] = ($d14) ? $d14[1] : '';
            $row[] = ($d15) ? $d15[1] : '';
            $row[] = ($d16) ? $d16[1] : '';
            $row[] = ($d17) ? $d17[1] : '';
            $row[] = ($d18) ? $d18[1] : '';
            $row[] = ($d19) ? $d19[1] : '';
            $row[] = ($d20) ? $d20[1] : '';
            $row[] = ($d21) ? $d21[1] : '';
            $row[] = ($d22) ? $d22[1] : '';
            $row[] = ($d23) ? $d23[1] : '';
            $row[] = ($d24) ? $d24[1] : '';
            $row[] = ($d25) ? $d25[1] : '';
            $row[] = ($d26) ? $d26[1] : '';
            $row[] = ($d27) ? $d27[1] : '';
            $row[] = ($d28) ? $d28[1] : '';
            $row[] = ($d29) ? $d29[1] : '';
            $row[] = ($d30) ? $d30[1] : '';
            $row[] = ($d31) ? $d31[1] : '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Siteofficeattendance->count_all(),
            "recordsFiltered" => $this->Siteofficeattendance->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function getsiteofficeData($empid, $projectid, $ts_year, $ts_month, $userfullname, $position_name) {
        $this->db->select('*');
        $this->db->from('siteofc_timesheets');
        $where = array('emp_id' => $empid, 'project_id' => $projectid, 'ts_year' => $ts_year, 'ts_month' => $ts_month);
        $this->db->where($where);

        $res = $this->db->get()->result_object();
        $data = array();
        foreach ($res as $val) {
            if ($val->sun_date) {
                $data[] = array('filldate' => $val->sun_date, 'duration' => $val->sun_duration);
            }
            if ($val->mon_date) {
                $data[] = array('filldate' => $val->mon_date, 'duration' => $val->mon_duration);
            }
            if ($val->tue_date) {
                $data[] = array('filldate' => $val->tue_date, 'duration' => $val->tue_duration);
            }
            if ($val->wed_date) {
                $data[] = array('filldate' => $val->wed_date, 'duration' => $val->wed_duration);
            }
            if ($val->thu_date) {
                $data[] = array('filldate' => $val->thu_date, 'duration' => $val->thu_duration);
            }
            if ($val->fri_date) {
                $data[] = array('filldate' => $val->fri_date, 'duration' => $val->fri_duration);
            }
            if ($val->sat_date) {
                $data[] = array('filldate' => $val->sat_date, 'duration' => $val->sat_duration);
            }
        }
        foreach ($data as $val1) {
            $chkdate = date('j', strtotime($val1['filldate']));
            $dataval[$chkdate] = $val1['filldate'] . ',' . $val1['duration'] . ',' . $userfullname . ',' . $position_name;
        }
        $dataval['name'] = array('name' => $userfullname, 'position' => $position_name);
        return ($dataval) ? $dataval : false;
        //echo '<pre>'; print_r($data1); 
    }

    //July Code Of Att Report...
    public function atm_sigle_dateattendance_entry() {
        $Data['error'] = '';
        $Data['htitle'] = "Atm CSV Sigle Date Attendance Entry";
        $this->load->view('back_end/attendance/atmsigledateattendanceentry_view', $Data);
    }

    //Attendance Single Day Logic
    public function atm_sigle_dateattendance_save() {
        if ($_REQUEST) {
            $fillle = $_FILES['atmfile']['tmp_name'];
            $file = fopen($fillle, 'r');
            $n = 0;
            //Delete Proccess..
            $sDay = intval(date("d", strtotime($_REQUEST['entry_date'])));
            $sMonth = intval(date("m", strtotime($_REQUEST['entry_date'])));
            $sYear = intval(date("Y", strtotime($_REQUEST['entry_date'])));
            $matcherTm = $sMonth . "/" . $sDay . "/" . $sYear;

            $this->db->where("FirstIn LIKE '%$matcherTm%'");
            $delResp = $this->db->delete('thumb_attendance');

            $secDatyeConv = date("m-d-Y", strtotime($_REQUEST['entry_date']));

            $this->db->where("FirstIn LIKE '%$secDatyeConv%'");
            $delResp2 = $this->db->delete('thumb_attendance');

            while (($line = fgetcsv($file)) !== FALSE) {
                if ($n > 0) {
                    ($line[3]) ? $line[3] = '' : $line[3] = 1;
                    $InsrtrecArr = array('EmployeeName' => $line[0], 'TimeSheetID' => $line[1], 'EmployeeID' => $line[2], 'IsHalfDay' => $line[3], 'TotalTime' => $line[4], 'WorkHours' => $line[5], 'Attendence' => $line[6], 'FirstIn' => $line[7], 'LastOut' => $line[8], 'Status' => '1', 'IsFullDay' => '0');
                    $this->db->insert('thumb_attendance', $InsrtrecArr);
                }
                $n++;
            }
            fclose($file);
            $this->session->set_flashdata('successmsg', 'Attendance Record Updated Success');
            redirect(base_url('atm_sigle_dateattendance_entry'));
        }
        $this->session->set_flashdata('successmsg', 'Attendance Record Updated Success');
        redirect(base_url('atm_sigle_dateattendance_entry'));
    }

    public function ajax_list_attenteam() {
        $repyear = $_REQUEST['repyear'];
        $repmonth = $_REQUEST['repmonth'];
        $reportbunit = $_REQUEST['reportbunit'];
        $underEMplsArr = $this->allmyteamides();

        $intmL = '09:45:00 am';
        $OutmL = '06:00:00 Pm';

        $filterArr = array('repyear' => $repyear, 'repmonth' => $repmonth, 'reportbunit' => $reportbunit);
        $list = $this->attendanceteamwise->get_datatables($repyear, $repmonth);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $attend) {
            $emplID = $attend['emp_id'];
            if (in_array($emplID, $underEMplsArr)) {
                $no++;
                $row = array();
                $row[] = $no;
                //  $row[] = "<b>" . $attend['userfullname'] . "</b><br><span style='color:green'>" . $attend['position_name'] . "</span><br>" . $attend['department_name'];
                $row[] = $attend['userfullname'];
                $row[] = $attend['position_name'];
                $row[] = $attend['department_name'];

                $startDate11 = '';
                if (($attend['1'] == '0') or ( $attend['1'] == '')) {
                    $startDate11 = "1" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['1'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['1']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));

                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }

                $startDate11 = '';
                if (($attend['2'] == '0') or ( $attend['2'] == '')) {
                    $startDate11 = "2" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['2'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['2']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }
                $startDate11 = '';
                if (($attend['3'] == '0') or ( $attend['3'] == '')) {
                    $startDate11 = "3" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['4'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['3']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }
                $startDate11 = '';
                if (($attend['4'] == '0') or ( $attend['4'] == '')) {
                    $startDate11 = "4" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['4'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['4']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }

                $startDate11 = '';
                if (($attend['5'] == '0') or ( $attend['5'] == '')) {
                    $startDate11 = "5" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['5'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['5']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['6'] == '0') or ( $attend['6'] == '')) {
                    $startDate11 = "6" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['6'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['6']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['7'] == '0') or ( $attend['7'] == '')) {
                    $startDate11 = "7" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['7'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['7']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['8'] == '0') or ( $attend['8'] == '')) {
                    $startDate11 = "8" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['8'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['8']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['9'] == '0') or ( $attend['9'] == '')) {
                    $startDate11 = "9" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['9'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['9']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['10'] == '0') or ( $attend['10'] == '')) {
                    $startDate11 = "10" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['10'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['10']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['11'] == '0') or ( $attend['11'] == '')) {
                    $startDate11 = "11" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['11'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['11']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['12'] == '0') or ( $attend['12'] == '')) {
                    $startDate11 = "12" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['12'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['12']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['13'] == '0') or ( $attend['13'] == '')) {
                    $startDate11 = "13" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['13'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['13']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['14'] == '0') or ( $attend['14'] == '')) {
                    $startDate11 = "14" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['14'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['14']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['15'] == '0') or ( $attend['15'] == '')) {
                    $startDate11 = "15" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['15'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['15']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }



                $startDate11 = '';
                if (($attend['16'] == '0') or ( $attend['16'] == '')) {
                    $startDate11 = "16" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['16'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['16']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }



                $startDate11 = '';
                if (($attend['17'] == '0') or ( $attend['17'] == '')) {
                    $startDate11 = "17" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['16'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['17']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['18'] == '0') or ( $attend['18'] == '')) {
                    $startDate11 = "18" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['18'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['18']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['19'] == '0') or ( $attend['19'] == '')) {
                    $startDate11 = "19" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['19'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['19']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['20'] == '0') or ( $attend['20'] == '')) {
                    $startDate11 = "20" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['20'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['20']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }



                $startDate11 = '';
                if (($attend['21'] == '0') or ( $attend['21'] == '')) {
                    $startDate11 = "21" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['21'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['21']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['22'] == '0') or ( $attend['22'] == '')) {
                    $startDate11 = "22" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['22'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['22']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['23'] == '0') or ( $attend['23'] == '')) {
                    $startDate11 = "23" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['23'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['23']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['24'] == '0') or ( $attend['24'] == '')) {
                    $startDate11 = "24" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['24'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['24']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }

                $startDate11 = '';
                if (($attend['25'] == '0') or ( $attend['25'] == '')) {
                    $startDate11 = "25" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['25'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['25']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['26'] == '0') or ( $attend['26'] == '')) {
                    $startDate11 = "26" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['26'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['26']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['27'] == '0') or ( $attend['27'] == '')) {
                    $startDate11 = "27" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['27'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['27']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['28'] == '0') or ( $attend['28'] == '')) {
                    $startDate11 = "28" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['28'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['28']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['29'] == '0') or ( $attend['29'] == '')) {
                    $startDate11 = "29" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['29'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['29']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }


                $startDate11 = '';
                if (($attend['30'] == '0') or ( $attend['30'] == '')) {
                    $startDate11 = "30" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['30'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['30']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }

                $startDate11 = '';
                if (($attend['31'] == '0') or ( $attend['31'] == '')) {
                    $startDate11 = "31" . "-" . $filterArr['repmonth'] . "-" . $filterArr['repyear'];
                    $rowcdscf = $this->checkallcondatten($attend['31'], $filterArr, $startDate11, $attend['emp_id']);
                    $row[] = $rowcdscf;
                } else {
                    $ArrVal = explode(",", $attend['31']);
                    $qRecord = '';
                    if (is_array($ArrVal)) {
                        $FunllInTim = date("h:i:s a", strtotime($ArrVal[0]));
                        $FunllOutTim = date("h:i:s a", strtotime($ArrVal[1]));
                        if ((strtotime($FunllInTim) > strtotime($intmL)) or ( strtotime($FunllOutTim) < strtotime($OutmL))) {
                            $qRecord = "<span style='color:red'>" . $FunllInTim . "<br>" . $FunllOutTim . "</span>";
                        } else {
                            $qRecord = $FunllInTim . "<br>" . $FunllOutTim;
                        }
                    }
                    $row[] = $qRecord;
                }

                $data[] = $row;
            }
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->attendance->count_all($repyear, $repmonth),
            "recordsFiltered" => $this->attendance->count_filtered($repyear, $repmonth),
            "data" => $data,
        );
//echo "Asheesh";
        echo json_encode($output);
    }

    //custom Code By Asheesh..
    public function checkallcondatten($Record_att, $filterArr, $actdate, $emp_id) {
        $monthN = array('1' => 'Jan', '2' => 'Feb', '3' => 'Mar', '4' => 'Apr', '5' => 'May', '6' => 'Jun', '7' => 'Jul', '8' => 'Aug', '9' => 'Sep', '10' => 'Oct', '11' => 'Nov', '12' => 'Dec');
        switch ($Record_att) {
            case ($Record_att != '0'):
                //Check Tour..
                $respoo = $this->tourexistondate($emp_id, date('Y-m-d', strtotime($actdate)));
                if ($respoo == 1) {
                    return 'T';
                }
                //check Leave..
                $resp_leave = $this->emp_leaveexist($emp_id, date('Y-m-d', strtotime($actdate)));
                if ($resp_leave == 1) {
                    return 'L';
                }
                //RH Holidays
                if ($resp_leave == 'RH') {
                    return 'RH';
                }
                //Holidays Check..
                $holidResp = $this->isholidays(date('Y-m-d', strtotime($actdate)));
                if ($holidResp == 1) {
                    return 'H';
                }
                //For sunday
                if (date('l', strtotime($actdate)) == "Sunday") {
                    return 'WO';
                }
                //For Sat CEG.

                if ($filterArr['reportbunit'] == 1) {
                    $firstReturn = date("Y-m-d", strtotime("first saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));
                    $thirdReturn = date("Y-m-d", strtotime("third saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));

                    if (date('Y-m-d', strtotime($actdate)) == $firstReturn) {
                        return "WO";
                    }
                    if (date('Y-m-d', strtotime($actdate)) == $thirdReturn) {
                        return "WO";
                    }
                }
                //For Sat CEGTH..
                if ($filterArr['reportbunit'] == 2) {
                    $thirdReturn = date("Y-m-d", strtotime("third saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));
                    if (date('Y-m-d', strtotime($actdate) == $thirdReturn)) {
                        return "WOR";
                    } else {
                        return "A";
                    }
                }
                return "A";
                break;
            //Check Starday
            default:
                return 'P';
        }
    }

    //Server Cron job For Attendance..
    public function allmyteamides() {
        $LoginID = $this->tank_auth->get_user_id();
        // $LoginID = '263';
        $UnderEmpIdArr = $this->underempides($LoginID);
        $allUnderEmpArr = array();
        if ($UnderEmpIdArr) {
            foreach ($UnderEmpIdArr as $empids) {
                array_push($allUnderEmpArr, $empids);
                $UnderEmpIdArr2 = $this->underempides($empids);
                if ($UnderEmpIdArr2) {
                    foreach ($UnderEmpIdArr2 as $empids2) {
                        array_push($allUnderEmpArr, $empids2);
                        $UnderEmpIdArr3 = $this->underempides($empids2);
                        if ($UnderEmpIdArr3) {
                            foreach ($UnderEmpIdArr3 as $empids3) {
                                array_push($allUnderEmpArr, $empids3);
                            }
                        }
                    }
                }
            }
        }
        array_push($allUnderEmpArr, $LoginID);
        return($allUnderEmpArr) ? $allUnderEmpArr : false;
    }

    public function underempides($repmngrID) {
        $this->db->select('user_id');
        $this->db->where(array('reporting_manager' => $repmngrID, 'isactive' => '1'));
        $recArr = $this->db->get('main_employees_summary')->result();
        $arrayID = array();
        if ($recArr) {
            foreach ($recArr as $rowec) {
                $IDES = $rowec->user_id;
                array_push($arrayID, $IDES);
            }
        }
        return (count($arrayID) > 0) ? $arrayID : false;
    }

}
