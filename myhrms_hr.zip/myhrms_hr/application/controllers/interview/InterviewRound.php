<?php

defined('BASEPATH') or exit('No direct script access allowed');

class InterviewRound extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('download');

        $this->load->library('session');
        
        $this->load->model('interview/InterviewRoundModel');
        $this->load->model('interview/CandidateInterviewRoundModel');

        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->loginuser_id = $this->session->userdata('loginid');
        if (($this->session->userdata('loginid') == '') or ($this->session->userdata('assign_role') == '')) {
            redirect(base_url(''));
        }
    }

    public function index()
    {
        
        $data['title'] = 'Listing of Interviews';
        $this->load->view('interview/list_interviewround', $data);
    }

    public function ajax_listing()
    {
        $list = $this->InterviewRoundModel->get_datatables();
        $data = [];
        $no = $_POST['start'];
        foreach ($list as $temp) {
            ++$no;
            $row = [];
            $row[] = $no;
           
            $row[] = $temp->userfullname . ' ' . '<b>' . $temp->inter_emp_id . '</b>';
            $row[] = $temp->contact;
            $row[] = $temp->country_name;
            $row[] = $temp->state_name;
            $row[] = $temp->city_name;
            // $row[] = $temp->round;
            $row[] = $temp->interview_round;
            $row[] = !empty($temp->title) ? $temp->title : '-';
            if(!empty($temp->types) && ($temp->types == '1')){
                $row[] = !empty($temp->reference_by) ? 'Consultancy Company ( ' .$temp->company_name.' )' : '-';
            } else if(!empty($temp->types) && ($temp->types == '2')){
                $row[] = !empty($temp->reference_by) ? 'Reference ( ' .$temp->reference_by.' )' : '-';
            } else if(!empty($temp->types) && ($temp->types == '3')){
                $row[] = 'Other';
            }
            
            if (!empty($temp->cv_document)) {
                $row[] = '<a href="' . RESUME . $temp->cv_document . '" target="_blank">View Resume</a>';
            } else {
                $row[] = '<a href="javascript:void(0)">No Data Found</a>';
            }
            $link1 = '&nbsp;<a href="' . base_url("interview_rounds/$temp->id") . '"><i class="fa fa-edit"></i></a>&nbsp;';
            $row[] = $link1;
            $data[] = $row;
        }
        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->InterviewRoundModel->count_all(),
            'recordsFiltered' => $this->InterviewRoundModel->count_filtered(),
            'data' => $data,
        ];
        echo json_encode($output);
    }

    public function interview_rounds($id)
    {
        $data['title'] = 'Candidate Interview Rounds';
        $data['interview_id'] = $id;
        $data['getCandidateName'] = $this->db->get_where('job_interview', array('id' => $id))->row_array();
        $data['getTypes'] = $this->db->get_where('mstr_competencies_job', array('status', '1'))->result_array();
        $this->load->view('interview/candidate_interview_round', $data);
    }

    public function fetch_competencies_job()
    {
        $roundId = $this->input->post('roundId');
        $competency_id = $this->input->post('competency_id');
        $competenciesData = $this->CandidateInterviewRoundModel->get_competency_data($roundId, $competency_id);
        $roundStatus = $this->CandidateInterviewRoundModel->get_round_status($roundId);

        if ($competenciesData) {
            echo json_encode([
                'status' => 'success',
                'data' => $competenciesData,
                'round_status' => $roundStatus
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No data found']);
        }
    }

    public function save_competencies_job()
    {
        $round_id = $this->input->post('round_id');
        $marks = $this->input->post('marks');
        $competencies = $this->input->post('competency_id');
        $existingData = $this->CandidateInterviewRoundModel->get_competency_data_by_round($round_id);

        $data = [];
        for ($i = 0; $i < count($marks); $i++) {
            if (!empty($competencies[$i])) {
                $data[] = [
                    'interview_round_id' => $round_id,
                    'competency_id' => $competencies[$i],
                    'marks' => $marks[$i]
                ];
            }
        }

        if (!$existingData) {
            $this->CandidateInterviewRoundModel->save_competencies($data);
        } else {
            foreach ($data as $item) {
                $competency_id = $item['competency_id'];
                $marks = $item['marks'];

                $existingRow = $this->CandidateInterviewRoundModel->get_competency_data($round_id, $competency_id);
                if (!$existingRow) {
                    $this->CandidateInterviewRoundModel->save_competencies([$item]);
                } elseif ($existingRow['round_status'] === null) {
                    $update_data = [
                        'marks' => $marks
                    ];
                    $this->CandidateInterviewRoundModel->update_competency_data($round_id, $competency_id, $update_data);
                }
            }
        }

        echo json_encode(['status' => 'success']);
    }


    public function update_round_status()
    {
        $round_id = $this->input->post('round_id');
        $round_status = $this->input->post('round_status');
        $competencies_job = $this->db->get_where('competencies_job', ['interview_round_id' => $round_id, 'status' => 1])->row();
        if (!empty($competencies_job)) {
            $update_data = array(
                'round_status' => $round_status
            );
            $this->CandidateInterviewRoundModel->update_round_status($round_id, $update_data);

            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'msg' => 'Please Provide the marks.']);
        }
    }

    public function update_selected_status()
    {
        $round_id = $this->input->post('round_id');
        $direct_selected = $this->input->post('direct_selected');
        $competencies_job = $this->db->get_where('competencies_job', ['interview_round_id' => $round_id, 'status' => 1])->row();
        if (!empty($competencies_job)) {
            $update_data = array(
                'direct_selected' => $direct_selected
            );
            $this->CandidateInterviewRoundModel->update_selected_status($round_id, $update_data);
            $job_interview_round = $this->db->get_where('job_interview_round', ['id' => $round_id, 'status' => 1])->row();
            $job_marks_sum = $this->db->select('SUM(marks) as sum_marks')->get_where('job_interview_round',['interview_id'=>$job_interview_round->interview_id,'round_status'=>1,'interviewer_accept'=>1])->row();
            $update_interview['interview_round_status'] = $direct_selected;
            $update_interview['total_marks'] = (!empty($job_marks_sum->sum_marks)? $job_marks_sum->sum_marks:0);
            $this->db->where('id',$job_interview_round->interview_id);
            $this->db->update('job_interview',$update_interview);

            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'msg' => 'Please Provide the marks.']);
        }
    }

    public function fetch_final_round_details()
    {
        $final_round = $this->input->post('final_round');

        $this->load->model('CandidateInterviewRoundModel');
        $round_details = $this->CandidateInterviewRoundModel->getRoundDetails($final_round);

        if ($round_details) {
            echo json_encode(['status' => 'success', 'data' => $round_details]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to fetch round details.']);
        }
    }

    public function update_final_round()
    {
        $round_id = $this->input->post('final_round');
        $location = $this->input->post('location');
        $comment = $this->input->post('comment');
        $mode = $this->input->post('interviewers_mode');

        $todayDate = date('Y-m-d');
        $data = [
            'interviewers_location' => $location,
            'interviewers_comments' => $comment,
            'interviewers_mode' => $mode,
            'interviewers_date' => $todayDate
        ];
        // echo "<pre>";
        // print_r($data);die;

        $update = $this->CandidateInterviewRoundModel->updateRoundDetails($round_id, $data);
        // echo $this->db->last_query();die;
        echo json_encode(['status' => 'success', 'message' => 'Round details updated successfully']);

        // if ($update) {
        //     echo json_encode(['status' => 'success', 'message' => 'Round details updated successfully']);
        // } else {
        //     echo json_encode(['status' => 'error', 'message' => 'Failed to update round details.']);
        // }
    }

    public function round_listing()
    {
        $interview_id = $this->input->post('interview_id');
        $list = $this->CandidateInterviewRoundModel->get_datatables($interview_id);
        $data = [];
        $no = $_POST['start'];

        foreach ($list as $temp) {
            ++$no;
            $row = [];
            $row[] = $no;
            $row[] = $temp->round;

            if ($temp->round_status === null) {
                $row[] = '<input type="radio" name="round_status_' . $temp->id . '" id="round_status_clear_' . $temp->id . '" value="1">&nbsp; Completed &nbsp;<input type="radio" name="round_status_' . $temp->id . '" id="round_status_notclear_' . $temp->id . '" value="0">&nbsp; Not Completed &nbsp;';
            } else {
                $statusText = $temp->round_status == 1 ? 'Completed' : 'Not Completed';
                $row[] = $statusText;
            }

            $totalMarks = $this->CandidateInterviewRoundModel->calculateTotalMarks($temp->id);
            $row[] = $totalMarks;

            if ($temp->round_status !== null && $totalMarks !== null) {
                $overallPosition = $this->calculateOverallPosition($totalMarks);
                $row[] = $overallPosition;

                $this->CandidateInterviewRoundModel->updateRoundDetails($temp->id, [
                    'marks' => $totalMarks,
                    'overall_suitability_position' => $overallPosition
                ]);
            } else {
                $row[] = '';
            }

            if ($temp->direct_selected === null) {
                $row[] = '<input type="radio" name="direct_selected_' . $temp->id . '" id="direct_selected_selected_' . $temp->id . '" value="1">&nbsp; Selected &nbsp;<input type="radio" name="direct_selected_' . $temp->id . '" id="direct_selected_notselected_' . $temp->id . '" value="0">&nbsp; Not Selected &nbsp;';
            } else {
                $statusText = $temp->direct_selected == 1 ? 'Selected' : 'Not Selected';
                $row[] = $statusText;
            }

            $row[] = '<a href="javascript:void(0)" class="edit_round" data-round_id="' . $temp->id . '"><i class="fa fa-edit"></i></a> &nbsp; <a href="javascript:void(0)" title="Final Round" class="final_touch" data-final_round="' . $temp->id . '"><i class="fa fa-circle-o"></i></a>';
            $data[] = $row;
        }

        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->CandidateInterviewRoundModel->count_all($interview_id),
            'recordsFiltered' => $this->CandidateInterviewRoundModel->count_filtered($interview_id),
            'data' => $data,
        ];
        echo json_encode($output);
    }


    private function calculateOverallPosition($totalMarks)
    {
        if ($totalMarks >= 0 && $totalMarks <= 10) {
            return 'Poor';
        } elseif ($totalMarks >= 11 && $totalMarks <= 20) {
            return 'Average';
        } elseif ($totalMarks >= 21 && $totalMarks <= 30) {
            return 'Good';
        } elseif ($totalMarks >= 31 && $totalMarks <= 40) {
            return 'Very Good';
        } elseif ($totalMarks >= 41 && $totalMarks <= 50) {
            return 'Excellent';
        } else {
            return null;
        }
    }
}

/* End of file Controllername.php */
