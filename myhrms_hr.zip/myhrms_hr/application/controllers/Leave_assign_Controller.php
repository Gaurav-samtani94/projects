<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Leave_assign_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('mastermodel');
        //======================code start by durgesh (06-08-2020)=====================//
        $this->load->model('Leave_assign_model', 'Leave_assign_model');
        //======================code end by durgesh (06-08-2020)=====================//
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }





    public function leaveassign()
    {
        $data['title'] = "Leave Assign Update";
        $data['Employeerecord'] = $this->Leave_assign_model->GetEmployeerecord();

        $this->load->view('project/leave_assign_view', $data);
    }


    public function updateleave()
    {
        $emp_id = $this->input->post('user_id');
        $year = $this->input->post('leave_year');
        $leave_day = $this->input->post('leave_day');

        $res = $this->Leave_assign_model->check_main_allottedleaveslog($emp_id, $year, $leave_day);
        $rest = $this->Leave_assign_model->check_main_employeeleaves($emp_id, $year, $leave_day);
        $this->session->set_flashdata('success_msg', 'Leave assign successfully');
        redirect(base_url('leaveassign'));
    }


    public function Leave_assign_report()
    {
        // $data = array();
        // $user_id = $this->session->userdata('loginid');
        $list = $this->Leave_assign_model->get_datatables();
        $no = 0;
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $value->employeeId;
            $row[] = $value->userfullname;
            $row[] = $value->department_name;
            $row[] = $value->position_name;
            $row[] = $value->alloted_year;
            $row[] = $value->emp_leave_limit;
            $row[] = $value->used_leaves;
            $data[] = $row;
        }

        $output = array(
            "draw" =>  $_POST['draw'],
            "recordsTotal" => $this->Leave_assign_model->count_all(),
            "recordsFiltered" => $this->Leave_assign_model->count_filtered(),
            "data" => $data,
        );

        echo json_encode($output);
    }

// Abhishek 31-08-2022
      public function excel_leave_upload()
    {
        $data['title'] = 'Leave Assign Update';
        $data['Employeerecord'] = $this->Leave_assign_model->GetEmployeerecord();
         $this->form_validation->set_rules('file', 'Excel File Formate', 'callback_file_check');
        $this->form_validation->set_rules('leave_years', 'Year', 'required');
        // $file = $_FILES['file'];
        if ($this->form_validation->run() == false) {
            $this->load->view('project/leave_assign_view', $data);
        } else {
            $uploadFilePath = 'public/uploads/leave_excel/'.basename($_FILES['file']['name']);
            // print_R($uploadFilePath);
            // die();
            move_uploaded_file($_FILES['file']['tmp_name'], $uploadFilePath);
            // $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            // $spreadsheet = $reader->load($uploadFilePath);
			// $sheet_data = $spreadsheet->getActiveSheet()->toArray();
            // print_r($sheet_data);
            // die();
            $this->load->library('excel');
 
//read file from path
$objPHPExcel = PHPExcel_IOFactory::load($uploadFilePath);

//get only the Cell Collection
$cell_collection = $objPHPExcel->getActiveSheet()->getCellCollection();
$i = 1;
//extract to a PHP readable array format
foreach ($cell_collection as $cell) {
    // print_R($cell);
    // die();
  
    $column = $objPHPExcel->getActiveSheet()->getCell($cell)->getColumn();
    $row = $objPHPExcel->getActiveSheet()->getCell($cell)->getRow();
   
    $data_value = $objPHPExcel->getActiveSheet()->getCell($cell)->getValue();

    //The header will/should be in row 1 only. of course, this can be modified to suit your need.
    if ($row == 1) {
        $header[$row][$column] = $data_value;
    } else {
        $arr_data[$row][$column] = $data_value;
       
    }
  
}

foreach($arr_data as $key=>$value)
{
  
   
  
    $pyroll_code= $value['B'];
    $year =  $year = $_REQUEST['leave_years'] != '' ? $_REQUEST['leave_years'] : date('Y'); //date('Y');

    $leave_day = $value['C'];

// print_R($leave_day);
// die();

    if ($pyroll_code != '' and $year != '' and $leave_day != '') {
        
        $this->db->select("a.id as user_id");
        $this->db->from("main_users as a");
        $this->db->join("emp_otherofficial_data as b","b.user_id=a.id","LEFT");
        $this->db->where("b.payrollcode",$pyroll_code);
        $this->db->where("a.isactive",'1');
       $RecRows = $this->db->get()->row();
    //    print_R($RecRows);
    //    die();
        // $this->db->select('a.user_id');
        // $this->db->from('emp_otherofficial_data as a');
        // $this->db->join("main_users as b","b.id=a.user_id","LEFT");
        // $this->db->where(['a.payrollcode' => $pyroll_code, 'b.isactive' => '1']);
        // $RecRows = $this->db->get()->row();
        // print_r($RecRows->user_id);
        // die();
        $empoyee_id = $RecRows != '' ? $RecRows->user_id : ''; //get_emp_user_id_by_payrolcode($pyroll_code);
//   print_r($empoyee_id);
//   die();
        if (@$empoyee_id) {
            $this->Leave_assign_model->check_main_allottedleaveslog_secound($empoyee_id, $year, $leave_day);
            $this->Leave_assign_model->check_main_employeeleaves_secound($empoyee_id, $year, $leave_day);
           
        }
    }
 

}

$this->session->set_flashdata('success_msg', 'Leave assign successfully');
           
            redirect(base_url('leaveRequest'));
            // $this->load->view('project/leave_assign_view', $data);
        }
    }

    public function file_check()
    {
        $file_ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        // print_r($filename);
        // $file_ext = pathinfo($filename, PATHINFO_EXTENSION);
        // print_r($file_ext);
        // die();
        if ($_FILES['file']['name'] == '') {
            $this->form_validation->set_message('file_check', 'File is Required');

            return false;
        }
        if ($file_ext != 'xlsx') {
            $this->form_validation->set_message('file_check', 'Only excel xlsx File Format is Required');

            return false;
        }
       
    }

}
