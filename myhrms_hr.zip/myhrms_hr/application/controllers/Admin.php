<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->helper('cookie');
       // $this->session->unset_userdata('loginid');
       
        
        if (!empty($this->session->userdata('loginid'))) {
            redirect(base_url("userdashboard"));
        }
        // $permission = GetUserIDHRPermission();
        // if (in_array($this->session->userdata('loginid'), $permission)) {
        // redirect(base_url("userdashboard"));
        // }
        // else
        // {
        // redirect(base_url("admin/auth/login"));
        // }
    }

    public function index() {
        $this->load->view('admin/auth/login');
    }

    //Login Control..
    public function loginchecker() {
        $empid = $this->input->post('username');
        $empPass = $this->input->post('password');
        if ($empid == '' or $empPass == ''):
            $this->session->set_flashdata('error_msg', 'Required Field Must be Validate');
        else:
            $LoginCredentialArr = array('username' => $this->input->post('username'), 'password' => $this->input->post('password'));
            $user_details = $this->mastermodel->login_user_action($LoginCredentialArr);
            if ($user_details):
				// echo "test"; die;
                $this->session->set_userdata(array('assign_role' => $user_details[0]->emprole, 'loginid' => $user_details[0]->id, 'username' => $user_details[0]->userfullname));
                redirect(base_url("userdashboard"));
				// echo "test"; die;
            else:
                $this->session->set_flashdata('error_msg', 'Your Login Credential is Invalid.');
                redirect(base_url(""));
            endif;
        endif;
    }

}
