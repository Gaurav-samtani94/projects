<?php

// require_once 'bootstrap.php';
defined('BASEPATH') or exit('No direct script access allowed');
require 'vendor/autoload.php';

class Employee extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('download');
        $this->load->library('session');
        $this->load->model('Mastermodel', 'mastermodel');
        $this->load->model('job/EmployeeModel');
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->loginuser_id = $this->session->userdata('loginid');
        if (($this->session->userdata('loginid') == '') or ($this->session->userdata('assign_role') == '')) {
            redirect(base_url(''));
        }
    }

    public function index()
    {
        $data['title'] = 'Employee Type List';
        $this->load->view('employee_type/list_employee', $data);
    }
    public function  ajax_listing()
    {
        $list = $this->EmployeeModel->get_datatables();
        $data = [];
        $no = $_POST['start'];
        foreach ($list as $temp) {
            ++$no;
            $row = [];
            $row[] = $no;
            $row[] = $temp->type_name;

            $link1 = '&nbsp;<a href="javascript:void(0)" class="edit-employee" data-toggle="modal" data-target="#editEmployeeModal" data-emp-id="' . $temp->emp_id . '"><i class="fa fa-edit"></i></a>&nbsp;';
            $row[] = $link1;
            $data[] = $row;
        }
        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->EmployeeModel->count_all(),
            'recordsFiltered' => $this->EmployeeModel->count_filtered(),
            'data' => $data,
        ];
        echo json_encode($output);
    }

    public function add_employee()
    {
        $this->form_validation->set_rules('type_name', 'Type Name', 'trim|required|is_unique[mstr_employment_type.type_name]');

        if ($this->form_validation->run() == false) {
            $response = [
                'status' => 'error',
                'errors' => [
                    'type_name' => strip_tags(form_error('type_name'))
                ]
            ];
            echo json_encode($response);
        } else {
            $records = $this->input->post();
            $record_jobs = [];
            $record_jobs['type_name'] = (!empty($records['type_name']) ? $records['type_name'] : null);
            $record_jobs['created_by'] = $this->session->userdata('loginid');

            $this->db->insert('mstr_employment_type', $record_jobs);
            // $ins_id = $this->db->insert_id();
            $response = [
                'status' => 'success',
                'message' => 'Employee Type Added Successfully'
            ];
            json_encode($response);
        }
    }

    public function get_employee_data($employee_id)
    {
        $employeeData = $this->db->get_where('mstr_employment_type', array('emp_id' => $employee_id))->row_array();
        if ($employeeData) {
            $response = [
                'status' => 'success',
                'data' => $employeeData
            ];
        } else {
            $response = [
                'status' => 'error',
                'message' => 'Employee data not found'
            ];
        }
        echo json_encode($response);
    }

    public function update_employee()
    {
        $records = $this->input->post();
        $employee_id = $records['employee_id'];
        $type_name = $records['type_name'];
        $employeeData = $this->db->get_where('mstr_employment_type', array('emp_id !=' => $employee_id,'type_name'=>$type_name))->row();
        
        if(!empty($employeeData)){
            $response = [
                'status' => 'error',
                'errors' => [
                    'type_name' => 'Type name Already exist'
                ]
            ];
            echo json_encode($response);
        } else {
        
            $params = array(
                'type_name' => $this->input->post('type_name'),
                'updated_by' => $this->session->userdata('loginid')
            );
            $this->db->where('emp_id', $employee_id);
            $this->db->update('mstr_employment_type', $params);
            $response = [
                'status' => 'success',
                'message' => 'Employee Type updated Successfully'
            ];
            // if ($this->db->affected_rows() > 0) {
            //     $response = [
            //         'status' => 'success',
            //         'message' => 'Employee Type updated Successfully'
            //     ];
            // } else {
            //     $response = [
            //         'status' => 'error',
            //         'message' => 'Failed to update Employee Type: '
            //     ];
            // }
            echo json_encode($response);
        }
    }
}
