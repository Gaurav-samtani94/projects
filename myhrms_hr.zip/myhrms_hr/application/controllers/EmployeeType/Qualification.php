<?php

// require_once 'bootstrap.php';
defined('BASEPATH') or exit('No direct script access allowed');
require 'vendor/autoload.php';

class Qualification extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('download');
        $this->load->library('session');
        $this->load->model('Mastermodel', 'mastermodel');
        $this->load->model('job/QualificationModel');
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->loginuser_id = $this->session->userdata('loginid');
        if (($this->session->userdata('loginid') == '') or ($this->session->userdata('assign_role') == '')) {
            redirect(base_url(''));
        }
    }

    public function index()
    {
        $data['title'] = 'Qualification List';
        $this->load->view('qualification/list_qualification', $data);
    }
    public function  ajax_listing()
    {
        $list = $this->QualificationModel->get_datatables();
        $data = [];
        $no = $_POST['start'];
        foreach ($list as $temp) {
            ++$no;
            $row = [];
            $row[] = $no;
            $row[] = $temp->educationlevelcode;

            $link1 = '&nbsp;<a href="javascript:void(0)" class="edit-qualification" data-toggle="modal" data-target="#editQualificationModal" data-quli-id="' . $temp->id . '"><i class="fa fa-edit"></i></a>&nbsp;';
            $row[] = $link1;
            $data[] = $row;
        }
        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->QualificationModel->count_all(),
            'recordsFiltered' => $this->QualificationModel->count_filtered(),
            'data' => $data,
        ];
        echo json_encode($output);
    }

    public function add_qualification()
    {
        $this->form_validation->set_rules('educationlevelcode', 'Name', 'trim|required|is_unique[mstr_qualification.educationlevelcode]');

        if ($this->form_validation->run() == false) {
            $response = [
                'status' => 'error',
                'errors' => [
                    'name' => strip_tags(form_error('educationlevelcode'))
                ]
            ];
            echo json_encode($response); // Return error response
        } else {
            $records = $this->input->post();
            $record_jobs = [
                'educationlevelcode' => (!empty($records['educationlevelcode']) ? $records['educationlevelcode'] : null),
                'createdby' => $this->session->userdata('loginid'),
                'createddate' => date('Y-m-d H:i:s')
            ];

            $this->db->insert('main_educationlevelcode', $record_jobs);

            if ($this->db->affected_rows() > 0) {
                $response = [
                    'status' => 'success',
                    'message' => 'Qualification Added Successfully'
                ];
            } else {
                $response = [
                    'status' => 'error',
                    'message' => 'Failed to add Qualification'
                ];
            }
            echo json_encode($response); // Return success or failure response
        }
    }


    public function get_qualification_data($qualification_id)
    {
        $employeeData = $this->db->get_where('main_educationlevelcode', array('id' => $qualification_id))->row_array();
        if ($employeeData) {
            $response = [
                'status' => 'success',
                'data' => $employeeData
            ];
        } else {
            $response = [
                'status' => 'error',
                'message' => 'Employee data not found'
            ];
        }
        echo json_encode($response);
    }
    

    public function update_employee()
    {
        $records = $this->input->post();
        $qualification_id = $records['qualification_id'];
        $educationlevelcode = $records['name'];
        $employeeData = $this->db->get_where('main_educationlevelcode', array('id !=' => $qualification_id,'educationlevelcode'=>$educationlevelcode))->row();
        
        if(!empty($employeeData)){
            $response = [
                'status' => 'error',
                'errors' => [
                    'name' => 'Name Already exist'
                ]
            ];
            echo json_encode($response);
        } else {
            $params = array(
                'educationlevelcode' => $this->input->post('name'),
                'modifiedby' => $this->session->userdata('loginid'),
                'modifieddate' => date('Y-m-d H:i:s')
            );
            $this->db->where('id', $qualification_id);
            $this->db->update('main_educationlevelcode', $params);
            $response = [
                'status' => 'success',
                'message' => 'Qualification updated Successfully'
            ];
            echo json_encode($response);
        }
    }
}
