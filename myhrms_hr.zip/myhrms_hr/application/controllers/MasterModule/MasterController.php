<?php

defined('BASEPATH') or exit('No direct script access allowed');

class MasterController extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        $this->load->library('form_validation');
		$this->load->helper('url');
        $this->db1 = $this->load->database('online', TRUE);
        $this->db2 = $this->load->database('default', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);
        $this->db4 = $this->load->database('cvmanager', TRUE);
        $this->load->library('form_validation');
    }
    public function index()
    {
		$data['tables'] = $this->db4->list_tables();
       $data['title'] = 'Master Tables';
        $this->load->view('MasterModule/master', $data);
    }
	public function fetchcvmrecord()
	{
		$db4 = $this->db4->database;
		$data = $_REQUEST['name'];
		$this->db->select("$db4.a.*");
		$rs['title']='Table Records';
		$this->db->from("$db4.$data as a");
		$rs['record'] = $this->db->get()->result();
		
		$rowdata = $rs['record'][0];
		foreach($rowdata as $key=>$val)
		{
			
			$table = array('institutename','univname');
			if(in_array($key,$table)>0){
				$rs['fieldname'] = $key;
			}
		}
		$this->load->view('MasterModule/view_table_recod',$rs);

	}
	public function getemployes()
	{
		$data['title']='Employee Ids';
		$db4 = $this->db4->database;
		$dat = $_REQUEST['name'];
		$id = $_REQUEST['op'];
	$data['name']=getrecordname($dat,$id);
		
	$data['record'] = getrecord_cadidate_list($dat,$id);
	//if($rec>0)
	//{
	//foreach($rec as $k=>$v)
	//{
		//echo"$v->candidate_id";echo"<br>";
	//}
	//}
	$this->load->view("MasterModule/view_employe_id",$data);
	}
	
}
