<?php

defined('BASEPATH') or exit('No direct script access allowed');


class Employee_Report_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Employe_Report_Model');
        $this->load->helper('download');
        $this->load->helper('url');
        // $this->load->model('All_employee_list_Model');
        // $this->load->model('Employecsv_model');
        // $this->load->library('form_validation');
        // $this->load->helper('download');
        $this->load->library('excel');



        // if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
        //     redirect(base_url(""));
        // }
        // $permission = GetUserIDHRPermission();
        // if (in_array($this->session->userdata('loginid'), $permission)) {
        // } else {
        //     redirect(base_url(""));
        // }
    }
    public function set_reportingmanager_bybunit_dropd_ajax()
    {
        $gotBunitId = $_REQUEST["bunitid"];
        $department_idd = $_REQUEST['department_id'];
        $recAllRepManager = null;
        if ($gotBunitId) {
            $this->db->select('b.user_id as user,b.userfullname as userfull,b.employeeId as emp');
            $this->db->from("main_employees_summary as a");
            $this->db->join("main_employees_summary as b", "a.reporting_manager=b.user_id", "LEFT");
            $this->db->where(array("a.isactive" => '1', "a.businessunit_id" => $gotBunitId, "a.department_id" => $department_idd));
            $this->db->group_by('b.id');
            $this->db->order_by("a.userfullname", "ASC");
            $recAllRepManager = $this->db->get()->result();
        }
        echo ($recAllRepManager) ? json_encode($recAllRepManager) : null;
    }
    public function set_reportingmanager_bybunit_dropd()
    {
        $gotBunitId = $_REQUEST["bunitid"];
        $recAllRepManager = null;
        if ($gotBunitId) {
            $this->db->select('a.user_id,a.userfullname,a.employeeId');
            $this->db->from("main_employees_summary as a");
            $this->db->where(array("a.isactive" => '1', "a.businessunit_id" => $gotBunitId));
            $this->db->order_by("a.userfullname", "ASC");
            $recAllRepManager = $this->db->get()->result();
        }
        echo ($recAllRepManager) ? json_encode($recAllRepManager) : null;
    }

    public function Fetch_Employee_Report()
    {
        $data['title'] = 'Fetch Employe Report';
        $this->db->select('a.id,a.unitname');
        $this->db->from('main_businessunits as a');
        $bus = $this->db->get()->result();
        $data['busineess_unit'] = $bus;
        $this->db->select('b.*');
        $this->db->from('main_departments as b');
        $data['department'] = $this->db->get()->result();

        $this->load->view('hrms_employee_list/Employee_Report', $data);
    }
    public function Fetch_Employee()
    {
        $bunitid =  $this->input->post('bunitid');
        $department_id = $this->input->post('department_id');
        $reporting_manager = $this->input->post('reporting_manager');
        $employe_result = $this->Employe_Report_Model->index($bunitid, $department_id, $reporting_manager);
        echo json_encode($employe_result);
        // print_r($data);
    }
    public function FetchReportinExcel()
    {
        // die();
        // $this->load->library('excel');
        $bunitid = $this->input->post('business_unit');
        $department_id  = $this->input->post('department_id');
        $reporting_manager = $this->input->post('reporting_manager');
        $empid = $this->input->post('Employe_id');
        $status = $this->input->post('EmployeActive_Inactive');
        $subdepartment = $this->input->post('subdepartment');
        // print_r($bunitid);
        // print_r($department_id);
        // print_r($empid);
        // die();
        $data = $this->Employe_Report_Model->getEmpDetailsByUserID($bunitid, $department_id, $subdepartment, $reporting_manager, $empid, $status);
        // if ($data) {
        // echo "<pre>";
        // print_r($data);
        // die;
        $this->load->library('excel');
        $spreadsheet = new PHPExcel();

        $HeadeingArray =
            array(
                'font'    => array(
                    'bold'      => true
                ),


            );
        $styleArray =
            array(
                'font'    => array(
                    'bold'      => true
                ),
                'alignment' => array(
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                ),
                'borders' => array(
                    'top'     => array(
                        'style' => PHPExcel_Style_Border::BORDER_THIN
                    )
                ),
                'fill' => array(
                    'type'       => PHPExcel_Style_Fill::FILL_SOLID,
                    'rotation'   => 90,
                    'startcolor' => array(
                        'argb' => 'FF90EE90'
                    ),

                )

            );
        $count = 1;
        $spreadsheet->getActiveSheet()->setCellValue('A' . $count, 'S. No.')->getStyle('A' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $spreadsheet->getActiveSheet()->setCellValue('B' . $count, 'EMP CODE')->getStyle('B' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('B')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('C' . $count, 'Payroll Code')->getStyle('C' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('C')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('D' . $count, 'Salutation')->getStyle('D' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('D')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('E' . $count, 'Emp Name')->getStyle('E' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('E')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('F' . $count, 'DOJ-O (With CEG Since)')->getStyle('F' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('F')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('G' . $count, 'DOJ-C (Latest)')->getStyle('G' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('G')->setWidth(30);
        // Abhishek change on 13-09-2022
        $spreadsheet->getActiveSheet()->setCellValue('H' . $count, 'AADHAR CARD')->getStyle('H' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('H')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('I' . $count, 'DOB')->getStyle('I' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('I')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('J' . $count, 'PROJECT NAME')->getStyle('J' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('J')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('K' . $count, 'PROJECT DESIGNATION')->getStyle('K' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('K')->setWidth(30);
        // end

        $spreadsheet->getActiveSheet()->setCellValue('L' . $count, 'Company Name')->getStyle('L' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('L')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('M' . $count, 'Business Unit (HO/RO/Project)')->getStyle('M' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('M')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('N' . $count, 'Location/Project')->getStyle('N' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('N')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('O' . $count, 'DEPARTMENT')->getStyle('O' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('O')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('P' . $count, 'DESIGNATION')->getStyle('P' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('P')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('Q' . $count, 'GRADE')->getStyle('Q' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('Q')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('R' . $count, 'Job Type')->getStyle('R' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('R')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('S' . $count, 'EMPLOYEE /CONSULTANT ')->getStyle('S' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('S')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('T' . $count, 'Overall CTC')->getStyle('T' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('T')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('U' . $count, 'CTC')->getStyle('U' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('U')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('V' . $count, 'GROSS')->getStyle('V' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('V')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('W' . $count, '-')->getStyle('W' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('W')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('X' . $count, 'ACTIVE / INACTIVE /ABSCONDING ')->getStyle('X' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('X')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('Y' . $count, 'Actual LWD')->getStyle('Y' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('Y')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('Z' . $count, 'F&F Status')->getStyle('Z' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('Z')->setWidth(30);

        $spreadsheet->getActiveSheet()->setCellValue('AA' . $count, 'Type of Exit')->getStyle('AA' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AA')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AB' . $count, 'Notice Served /Unserved')->getStyle('AB' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AB')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AC' . $count, 'Resignation Date')->getStyle('AC' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AC')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AD' . $count, 'Demobilization / Termination Date')->getStyle('AD' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AD')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AE' . $count, 'Last Working day as per letter issued')->getStyle('AE' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AE')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AF' . $count, 'Reason for Resignation')->getStyle('AF' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AF')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AG' . $count, 'Resignation Acceptance date by HOD ')->getStyle('AG' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AG')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AH' . $count, 'Resignation Acceptance Letter sent date ')->getStyle('AH' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AH')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AI' . $count, 'Notice Pay Deduction')->getStyle('AI' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AI')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AJ' . $count, 'PCB/ ALB- Yes- NO ')->getStyle('AJ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AJ')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AK' . $count, 'ALB/ PCB Amount')->getStyle('AK' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AK')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AL' . $count, 'F&F Amount')->getStyle('AL' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AL')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AM' . $count, 'F&F Date')->getStyle('AM' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AM')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AN' . $count, 'F&F Handover to Accounts - date')->getStyle('AN' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AM')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AO' . $count, 'Recovery Amount')->getStyle('AO' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AO')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AP' . $count, 'Recovery Received')->getStyle('AP' . $count)->applyFromArray($styleArray);
        //
        $spreadsheet->getActiveSheet()->getColumnDimension('AP')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AQ' . $count, 'Experience Certificate Issue Date')->getStyle('AQ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AQ')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AR' . $count, 'Exit Remarks')->getStyle('AR' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AR')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AS' . $count, 'Job Role')->getStyle('AS' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->getColumnDimension('AS')->setWidth(30);
        $spreadsheet->getActiveSheet()->setCellValue('AT' . $count, 'Grade Metro')->getStyle('AT' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AU' . $count, 'Increment Cycle')->getStyle('AU' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AV' . $count, 'Next Increment Due Date')->getStyle('AV' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AW' . $count, 'Pay Day')->getStyle('AW' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AX' . $count, 'Salary Apply From')->getStyle('AX' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AY' . $count, 'Consolidated/ Consultancy Fee')->getStyle('AY' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('AZ' . $count, 'Basic')->getStyle('AZ' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('BA' . $count, 'HRA')->getStyle('BA' . $count)->applyFromArray($styleArray);
        //  LAST UPDATE

        $spreadsheet->getActiveSheet()->setCellValue('BB' . $count, 'Education Allowance')->getStyle('BB' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BC' . $count, 'Telephone Allowance')->getStyle('BC' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BD' . $count, 'Adv. Bonus')->getStyle('BD' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BE' . $count, 'Special Allowance')->getStyle('BE' . $count)->applyFromArray($styleArray);
        //    ABHISHEK LAST UPDATE

        $spreadsheet->getActiveSheet()->setCellValue('BF' . $count, 'Monthly Gross')->getStyle('BF' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BG' . $count, 'Employer Contri. to Gratuity')->getStyle('BG' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BH' . $count, 'Employer Contri. to PF')->getStyle('BH' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BI' . $count, 'Employer Contri. to ESIC ')->getStyle('BI' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BJ' . $count, 'GPAI')->getStyle('BJ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BK' . $count, 'Mediclaim')->getStyle('BK' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BL' . $count, 'Others/ Reimbursement')->getStyle('BL' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BM' . $count, 'ALB')->getStyle('BM' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BN' . $count, 'PCB')->getStyle('BN' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BO' . $count, 'CTC pre-Annual Bonus')->getStyle('BO' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BP' . $count, 'ANNUAL BONUS')->getStyle('BP' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BQ' . $count, 'ANNUAL CTC')->getStyle('BQ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BR' . $count, 'Monthly CTC')->getStyle('BR' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BS' . $count, 'P1 (S Case)')->getStyle('BS' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BT' . $count, 'P2 (S Case)')->getStyle('BT' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BU' . $count, 'Driver')->getStyle('BU' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BV' . $count, 'Vehicle Agreement')->getStyle('BV' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BW' . $count, 'Fuel Expenses')->getStyle('BW' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BX' . $count, 'Leave Travel Allowance')->getStyle('BX' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BY' . $count, 'Reimbursement')->getStyle('BY' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('BZ' . $count, 'Washing')->getStyle('BZ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CA' . $count, 'Others')->getStyle('CA' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CB' . $count, 'Overall  Monthly CTC')->getStyle('CB' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CC' . $count, 'Salary Remarks')->getStyle('CC' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CD' . $count, 'Gratuity Start Date')->getStyle('CD' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CE' . $count, 'Gratuity Accumulated till Date')->getStyle('CE' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CF' . $count, 'HRMS User ID')->getStyle('CF' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CG' . $count, 'Bank Name')->getStyle('CG' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CH' . $count, 'Account Holder Name')->getStyle('CH' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CI' . $count, 'Account Number')->getStyle('CI' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CJ' . $count, 'Branch Name')->getStyle('CJ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CK' . $count, 'IFSC')->getStyle('CK' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CL' . $count, 'pan card Number')->getStyle('CL' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CM' . $count, 'Appraisal Due Date')->getStyle('CM' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CN' . $count, 'PF Applicable')->getStyle('CN' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('CO' . $count, 'UAN')->getStyle('CO' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CP' . $count, 'PF NO.')->getStyle('CP' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CQ' . $count, 'PF START DATE')->getStyle('CQ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CR' . $count, 'ESI Applicable')->getStyle('CR' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CS' . $count, 'ESIC IP NO.')->getStyle('CS' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CT' . $count, 'ESIC START DATE')->getStyle('CT' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CU' . $count, 'ESIC Coverage Under Branch')->getStyle('CU' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CV' . $count, 'Employer ESIC No.')->getStyle('CV' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CW' . $count, 'CEG Exp. (in month)')->getStyle('CW' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CX' . $count, 'CEG Exp. (in years)')->getStyle('CX' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CY' . $count, 'Prev. Exp.(fill in months)')->getStyle('CY' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('CZ' . $count, 'Prev. Exp. (in years)')->getStyle('CZ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('DA' . $count, 'Total Exp.(in month)')->getStyle('DA' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('DB' . $count, 'Total Exp. (in years)')->getStyle('DB' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('DC' . $count, 'Preeti Vlookup Qualification level ')->getStyle('DC' . $count)->applyFromArray($styleArray);
        // $spreadsheet->getActiveSheet()->setCellValue('DB' . $count, 'PCB')->getStyle('AL' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DD' . $count, 'Qualification Level')->getStyle('DD' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DE' . $count, 'Qualification')->getStyle('DE' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DF' . $count, 'Tech. Highest Qual')->getStyle('DF' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DG' . $count, 'Non Tech. Highest Qual')->getStyle('DG' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DH' . $count, 'Diploma / ITI')->getStyle('DH' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DI' . $count, 'Diploma Year Year')->getStyle('DI' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DJ' . $count, 'Diploma / ITI Institute')->getStyle('DJ' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DK' . $count, 'UG Degree')->getStyle('DK' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DL' . $count, 'UG Year')->getStyle('DL' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DM' . $count, 'UG College/Univ.')->getStyle('DM' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DN' . $count, 'PG Degree ')->getStyle('DN' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DO' . $count, 'PG Year')->getStyle('DO' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DP' . $count, 'PG College/Univ.')->getStyle('DP' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DQ' . $count, 'Doctorate')->getStyle('DQ' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DR' . $count, 'Doctorate Year')->getStyle('DR' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DS' . $count, 'Doctorate College/Univ.')->getStyle('DS' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DT' . $count, 'Professional Qualification')->getStyle('DT' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DU' . $count, 'Gender')->getStyle('DU' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DV' . $count, 'Contact Number')->getStyle('DV' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DW' . $count, 'Contact Number2')->getStyle('DW' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DX' . $count, 'Personal Email')->getStyle('DX' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DY' . $count, 'Official Email')->getStyle('DY' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('DZ' . $count, 'Appt Letter No. & Date')->getStyle('DZ' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('EA' . $count, 'Floor @ HO')->getStyle('EA' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->setCellValue('EB' . $count, 'City Location (Base)')->getStyle('EB' . $count)->applyFromArray($styleArray);

        // $spreadsheet->getActiveSheet()->setCellValue('DA' . $count, 'Others/ Reimbursement')->getStyle('AL' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EC' . $count, 'State')->getStyle('EC' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('ED' . $count, 'IO')->getStyle('ED' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EE' . $count, 'RO')->getStyle('EE' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EF' . $count, 'HOD')->getStyle('EF' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EG' . $count, 'Age')->getStyle('EG' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EH' . $count, 'Age Group')->getStyle('EH' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EI' . $count, 'Vintage Tenure')->getStyle('EI' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EJ' . $count, 'Probation Due Date')->getStyle('EJ' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EK' . $count, 'Confirmation Status')->getStyle('EK' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EL' . $count, 'Mediclaim Applicable (Yes/No)')->getStyle('EL' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EM' . $count, 'Mediclaim Coverage Start Date')->getStyle('EM' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EN' . $count, 'GPAI Applicable (Yes/No)')->getStyle('EN' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EO' . $count, 'GPAI Coverage Start Date')->getStyle('EO' . $count)->applyFromArray($styleArray);
        $spreadsheet->getActiveSheet()->setCellValue('EP' . $count, 'Sub Department')->getStyle('EP' . $count)->applyFromArray($styleArray);

        $spreadsheet->getActiveSheet()->getColumnDimension('AT')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('AU')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('AV')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('AW')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('AX')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('AY')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('AZ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BA')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BB')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BC')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BD')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BE')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BF')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BG')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BH')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BI')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BJ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BK')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BL')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BM')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BN')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BO')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BP')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BQ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BR')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BS')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BT')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BU')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BV')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BW')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BX')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BY')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('BZ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CA')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CB')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CD')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CE')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CF')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CG')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CH')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CI')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CJ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CK')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CL')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CM')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CN')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CO')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CP')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CQ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CR')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CS')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CT')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CU')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CV')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CW')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CX')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CY')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('CZ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DA')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DB')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DC')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DD')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DE')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DF')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DG')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DH')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DI')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DJ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DK')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DL')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DM')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DN')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DO')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DP')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DQ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DR')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DS')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DT')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DU')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DV')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DW')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DX')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DY')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('DZ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EA')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EB')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EC')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('ED')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EE')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EF')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EG')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EH')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EI')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EJ')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EK')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EL')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EL')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EN')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EO')->setWidth(30);
        $spreadsheet->getActiveSheet()->getColumnDimension('EP')->setWidth(30);
        // $spreadsheet->getActiveSheet()->getColumnDimension('EQ')->setWidth(30);
        // $spreadsheet->getActiveSheet()->getColumnDimension('ER')->setWidth(30);
        // $spreadsheet->getActiveSheet()->getColumnDimension('ES')->setWidth(30);
        // $spreadsheet->getActiveSheet()->getColumnDimension('ET')->setWidth(30);




        $count++;
        $no = 1;
        foreach ($data as $KEY => $rows) {
            $salary = getemployesalary($rows->afids);
            $dateOfBirth = $rows->dob;
            $today = date("Y-m-d");
            $diff = date_diff(date_create($dateOfBirth), date_create($today));
            $years = $diff->format('%y-years%m-months-%d-days');
            // print_r($years);
            // die();
            $ro_name = $this->db->get_where('main_users', array('id' => $rows->ro))->row()->userfullname;
            $joiningDate = $rows->join_date_withceg;
            $leaving_date = $rows->date_of_leaving;
            if ($joiningDate != '' && $leaving_date != '') {
                $exp = date_diff(date_create($joiningDate), date_create($leaving_date));
                $experice = $exp->format('%y-years');
            } else {
                $exp = date_diff(date_create($joiningDate), date_create($today));
                $experice = $exp->format('%y-years');
            }
            $spreadsheet->getActiveSheet()->setCellValue('A' . $count, $no++);

            $spreadsheet->getActiveSheet()->setCellValue('B' . $count, $rows->employeeId);

            $spreadsheet->getActiveSheet()->setCellValue('C' . $count, $rows->payrollcode);

            $spreadsheet->getActiveSheet()->setCellValue('D' . $count, $rows->prefix);
            //n.rolename,b.firstname,b.lastname,m.gendername,i.*,l.religion_name,k.nationalitycode,j.maritalstatusname,i.mother_nm,i.father_nm,g.pancard_no,g.appraisalduedate,g.bankname,g.accountholder_name,g.accountnumber,g.branchname,g.ifsc_code,h.freqtype,g.salary,c.sub_department,c.probation_period_no,,c.noticeperiod,C.floor_number,C.payrollcode,f.city_name,c.reviewing_officer_ro as roName,d.subdepartment,a.userfullname,a.emailaddress,a.contactnumber,a.employeeId,b.date_of_leaving,b.profileimg,b.years_exp,b.emp_status_name,b.extension_number,b.businessunit_name,b.department_name,b.jobtitle_name,b.reporting_manager_name,b.position_name,b.date_of_joining

            $spreadsheet->getActiveSheet()->setCellValue('E' . $count, $rows->userfullname);
            $spreadsheet->getActiveSheet()->setCellValue('F' . $count, $rows->date_of_joining);
            $spreadsheet->getActiveSheet()->setCellValue('G' . $count, $rows->date_of_joining);
            // abhishek change 
            $spreadsheet->getActiveSheet()->setCellValue('H' . $count, $rows->aadhar_no_enrolment); //->getStyle('H' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('I' . $count, $rows->dob); //->getStyle('I' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('J' . $count, $rows->project_name); //->getStyle('H' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('K' . $count, $rows->designation_name);
            // end chnage

            $spreadsheet->getActiveSheet()->setCellValue('L' . $count, $rows->company_name); //->getStyle('J' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('M' . $count, $rows->unitname); //->getStyle('K' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('N' . $count, '-'); //->getStyle('L' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('O' . $count, $rows->department_name); //->getStyle('M' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('P' . $count, $rows->position_name); //->getStyle('N' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('Q' . $count, $rows->jobtitle_name); //->getStyle('O' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('R' . $count, '-'); //->getStyle('P' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('S' . $count, $rows->emprole_name); //->getStyle('Q' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('T' . $count, '-'); //->getStyle('R' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('U' . $count, '-'); //->getStyle('S' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('V' . $count, $salary[0]->grosssalary); //->getStyle('T' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('W' . $count, '-'); //->getStyle('U' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('X' . $count, '-'); //->getStyle('V' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('Y' . $count, '-'); //->getStyle('W' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('Z' . $count, '-'); //->getStyle('X' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AA' . $count, '-'); ///->getStyle('Y' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AB' . $count, '-'); //->getStyle('Z' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AC' . $count, '-'); //->getStyle('AA' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AD' . $count, '-'); //->getStyle('AB' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AE' . $count, '-'); //->getStyle('AC' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AF' . $count, '-'); //->getStyle('AD' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AG' . $count, '-'); //->getStyle('AE' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AH' . $count, '-'); //->getStyle('AF' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AI' . $count, '-'); //->getStyle('AG' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AJ' . $count, '-'); //->getStyle('AH' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AK' . $count, '-'); //->getStyle('AI' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AL' . $count, '-'); //->getStyle('AJ' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AM' . $count, '-'); //->getStyle('AK' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AN' . $count, '-'); //->getStyle('AL' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AO' . $count, '-'); //->getStyle('AM' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AP' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('AQ' . $count, '-'); //->getStyle('AA' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AR' . $count, '-'); //->getStyle('AB' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AS' . $count, '-'); //->getStyle('AC' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AT' . $count, '-'); //->getStyle('AD' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AU' . $count, '-'); //->getStyle('AE' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AV' . $count, '-'); //->getStyle('AF' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AW' . $count, '-'); //->getStyle('AG' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AX' . $count, $salary[0]->appraisal_datemmyy); //->getStyle('AH' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AY' . $count, '-'); //->getStyle('AI' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('AZ' . $count, $salary[0]->basicsalary); //->getStyle('AJ' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BA' . $count, $salary[0]->emp_hra); //->getStyle('AK' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BB' . $count, $salary[0]->education_allowance); //->getStyle('AL' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BC' . $count, '-'); //->getStyle('AM' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BD' . $count, $salary[0]->bonus_adv); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BE' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BF' . $count, $salary[0]->special_allowance); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BG' . $count, $salary[0]->grosssalary); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BH' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BI' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BJ' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BK' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BL' . $count, $salary[0]->medical_allowance); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BM' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BN' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BO' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BP' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BQ' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BR' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BS' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BT' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BU' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BV' . $count, $salary[0]->driver_wagers); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('BW' . $count, $salary[0]->vehicle_agreement); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BX' . $count, $salary[0]->leave_travel_allowance); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BY' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BZ' . $count, $salary[0]->fuel_expenses); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CA' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CB' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('BC' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CD' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CE' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CF' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CG' . $count, $rows->user_id); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CH' . $count, $rows->bankname); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CI' . $count, $rows->accountholder_name); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CJ' . $count, $rows->accountnumber); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CK' . $count, $rows->branchname); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CL' . $count, $rows->ifsc_code); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CM' . $count, $rows->pancard_no); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CN' . $count, $rows->appraisalduedate); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CO' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CP' . $count, $rows->pf_uan); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CQ' . $count, $rows->pf_ac_no); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CR' . $count, $rows->pf_date); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CS' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CT' . $count, $rows->esic_ip_no); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CU' . $count, $rows->esic_start_date); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CV' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CW' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CX' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CY' . $count, $experice); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('CZ' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DA' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DB' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DC' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('DD' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DE' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DF' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DG' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DH' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DI' . $count, $rows->diplomacource); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DJ' . $count, $rows->diplomatodate); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DK' . $count, $rows->diplomaInstitute); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DL' . $count, $rows->ugcource); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DM' . $count, $rows->ugtodate); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DN' . $count, $rows->ugInstitute); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DO' . $count, $rows->pgcource); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DP' . $count, $rows->pgtodate); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DQ' . $count, $rows->pgInstitute); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DR' . $count, $rows->doctratecource); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DS' . $count, $rows->doctratetodate); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DT' . $count, $rows->doctrateInstitute); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DU' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DV' . $count, $rows->gendername); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DW' . $count, $rows->contactnumber); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DX' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DY' . $count, $rows->emailaddress); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('DZ' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            // $spreadsheet->getActiveSheet()->setCellValue('EA' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EA' . $count, $rows->floor_number); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EB' . $count, $rows->perm_city_name); //->getStyle('AN' . $count)->applyFromArray($styleArray);

            $spreadsheet->getActiveSheet()->setCellValue('EC' . $count, $rows->perm_state_name); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('ED' . $count, $rows->io); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EE' . $count, $ro_name); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EG' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EH' . $count, $years); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EI' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EJ' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EK' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EL' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EM' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EN' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EO' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $spreadsheet->getActiveSheet()->setCellValue('EP' . $count, $rows->subdepartment); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            // $spreadsheet->getActiveSheet()->setCellValue('EQ' . $count, '-'); //->getStyle('AN' . $count)->applyFromArray($styleArray);
            $count++;
        }
        $writer = PHPExcel_IOFactory::createWriter($spreadsheet, 'Excel5');
        $name = rand(1000000, 10000000);
        $file_name = "report_$name.xls";
        $location = "assets/report/";
        $writer->save($location . $file_name);
        // force_download($location . $file_name, NULL);
        $user_id = $this->session->userdata('loginid');
        // print_r($user_id);
        // die();
        $report_Filename = array(
            'user_id' => $user_id,
            'file_name' =>  $file_name
        );
        $this->db->insert('Employe_single_report_download', $report_Filename);
        $this->db->select('file_name');
        $this->db->from('Employe_single_report_download');
        $this->db->where('user_id', $user_id);
        $this->db->where('file_name', $file_name);
        $this->db->order_by('id', 'desc');
        $selectfilename = $this->db->get()->row();

        // print_R(($location . $selectfilename->file_name));
        force_download($location . $selectfilename->file_name, null);
        redirect(base_url('Fetch_Employee_Report'));
        // } else {
        //     echo "hi";
        //     redirect(base_url('Fetch_Employee_Report'));
        // }
    }
    public function set_subdepartment()
    {
        $dept_id = $this->input->post('department_id');
        $depart_array = array("deptid" => $dept_id, "is_active" => 1);
        $this->db->select("*");
        $this->db->from("main_subdepartments");
        $this->db->where($depart_array);
        $data = $this->db->get()->result();
        // $this->db->where($depart_array);
        // $data =  $this->db->get("main_subdepartments")->result();
        echo json_encode($data ? $data : '');
    }
}
