<?php

defined('BASEPATH') or exit('No direct script access allowed');

class EmpSalary_Relation_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('SalrayRelation/SalaryRelation_Model');
        // $this->load->library('form_validation');
        // $this->load->helper('security');

        // if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
        //     redirect(base_url(""));
        // }
        // $permission = GetUserIDHRPermission();
        // if (in_array($this->session->userdata('loginid'), $permission)) {
        // } else {
        //     redirect(base_url(""));
        // }
    }

    public function index()
    {

        $data['title'] = 'Employe Salary Relation';
        $this->load->view('salary_relation/EmployeSalary_Relation', $data);
    }
    public function ajax_employeSalary_relation()
    {
        $list = $this->SalaryRelation_Model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        // echo "<pre>"; print_r($list); die;
        foreach ($list as $value) {

            //$disbl = ($value->main_status == 2) ? "disabled=disabled" : "";
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $value->userfullname;

            $row[] = "<a href='#exampleModal' data-toggle='modal' data-target='#exampleModal' onclick='getallemployess(" . $value->related_with . ")'>" . relatedwith_employe($value->related_with) . "</a>";
            // $row[] = '<input type="hidden" name="checkboxArr[]" value="'.$value->fld_id.'">&ensp;
            // <button class="btn btn-danger" '.$disbl.'onclick="delete_temp_salary_details('.$value->fld_id.')">Delete</button>';
            // $row[] = ;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->SalaryRelation_Model->count_all(),
            "recordsFiltered" => $this->SalaryRelation_Model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }
    public function EmployeRelationdetail()
    {
        $user_id = $this->input->post('user_id');
        $this->db->select('a.*,b.userfullname,b.employeeId');
        $this->db->from("emp_otherofficial_data as a");
        $this->db->join("main_users as b", "a.user_id=b.id", "LEFT");
        $this->db->where("a.related_with", $user_id);
        $return['employe'] = $this->db->get()->result();
        echo json_encode($return);
    }
    //Main_users Form..
    // public function main_usersFormArr($postRec)
    // {
    //     $userFullName1 = ($postRec['first_name']) ? $postRec['first_name'] : '';
    //     $userFullName2 = ($postRec['middle_name']) ? " " . $postRec['middle_name'] : '';
    //     $userFullName3 = ($postRec['last_name']) ? " " . $postRec['last_name'] : '';
    //     $userFullName = $userFullName1 . $userFullName2 . $userFullName3;
    //     $employeeId = $postRec['employee_code'] . $postRec['employee_id'];

    //     $insertArr = [
    //         "emprole" => $postRec['role'], "userstatus" => $postRec['employment_status'],
    //         "firstname" => $postRec['first_name'],
    //         "middle_name" => ($postRec['middle_name']) ? $postRec['middle_name'] : "",
    //         "lastname" => ($postRec['last_name']) ? $postRec['last_name'] : "",
    //         "userfullname" => $userFullName,
    //         "emailaddress" => $postRec['official_emailid'],
    //         "contactnumber" => $postRec['mob_number'],
    //         "backgroundchk_status" => 'Yet to start',
    //         "emptemplock" => '0',
    //         "empreasonlocked" => '',
    //         "emppassword" => md5('123456'),
    //         "createdby" => $this->session->userdata('loginid'),
    //         "createddate" => date("Y-m-d h:i:s"),
    //         "modifieddate" => date("Y-m-d h:i:s"),
    //         "employeeId" => $employeeId,
    //         "modeofentry" => $postRec['mode_employment'],
    //         "selecteddate" => date("y-m-d", strtotime($postRec['dateofjoining'])),
    //         "company_id" => $postRec['company_id'],
    //         "ofc_locationid" => $postRec['joining_at'],
    //         "jobtitle_id" => $postRec['job_titlegroup'],
    //         "company_nameid" => $postRec['company_id'],
    //         "recruitment_for" => $postRec['recruitment_for'],
    //         "replaced_with_userid" => $postRec['replaced_with_userid'],
    //         "emp_onproject" => ($postRec['project_id']) ? $postRec['project_id'] : null,
    //         "emp_project_designation" => ($postRec['project_designationid']) ? $postRec['project_designationid'] : null,
    //         "ofcialemail" => $postRec['official_emailid']
    //     ];
    //     return ($insertArr) ? $insertArr : null;
    // }

    // //Main_users Form Edit / Update .. role
    // public function main_usersFormUpdArr($postRec)
    // {
    //     $userFullName1 = ($postRec['first_name']) ? $postRec['first_name'] : '';
    //     $userFullName2 = ($postRec['middle_name']) ? " " . $postRec['middle_name'] : '';
    //     $userFullName3 = ($postRec['last_name']) ? " " . $postRec['last_name'] : '';
    //     $userFullName = $userFullName1 . $userFullName2 . $userFullName3;
    //     $insertArr = [
    //         "emprole" => $postRec['role'], "userstatus" => $postRec['employment_status'],
    //         "firstname" => $postRec['first_name'],
    //         "middle_name" => ($postRec['middle_name']) ? $postRec['middle_name'] : "",
    //         "lastname" => ($postRec['last_name']) ? $postRec['last_name'] : "",
    //         "userfullname" => $userFullName,
    //         "emailaddress" => $postRec['official_emailid'],
    //         "contactnumber" => $postRec['mob_number'],
    //         "modifieddate" => date("Y-m-d h:i:s"),
    //         "modeofentry" => $postRec['mode_employment'],
    //         "selecteddate" => date("y-m-d", strtotime($postRec['dateofjoining'])),
    //         "company_id" => $postRec['company_id'],
    //         "ofc_locationid" => $postRec['joining_at'],
    //         "jobtitle_id" => $postRec['job_titlegroup'],
    //         "company_nameid" => $postRec['company_id'],
    //         "emp_onproject" => ($postRec['project_id']) ? $postRec['project_id'] : null,
    //         "emp_project_designation" => ($postRec['project_designationid']) ? $postRec['project_designationid'] : null,
    //         "ofcialemail" => $postRec['official_emailid']
    //     ];
    //     return ($insertArr) ? $insertArr : null;
    // }
    // public function main_employee($postRec)
    // {
    //     // $userFullName1 = ($postRec['first_name']) ? $postRec['first_name'] : '';
    //     // $userFullName3 = ($postRec['last_name']) ? " " . $postRec['last_name'] : '';
    //     // $userFullName = $userFullName1 . $userFullName3;
    //     $main_employee = array(
    //         "date_of_joining" => date("Y-m-d", strtotime($postRec['dateofjoining'])),
    //         "reporting_manager" => $postRec['reporting_manager'],
    //         // "reporting_manager_name" => get_ro_details_by_Id($postRec['reporting_manager']),
    //         "emp_status_id" => $postRec['employment_status'],
    //         "businessunit_id" => $postRec['business_unit'],
    //         "department_id" => $postRec['department'],
    //         "jobtitle_id" => $postRec['job_titlegroup'],
    //         "position_id" => $postRec['designation'],
    //         "years_exp" => $postRec['yearofexp_prev'],
    //         "prefix_id" => $postRec['prefix_id'],
    //         "extension_number" => $postRec['extension_number'],
    //         "office_number" => $postRec['mob_number'],
    //         // "firstname" => $postRec['first_name'],
    //         // "lastname" => ($postRec['last_name']) ? $postRec['last_name'] : "",
    //         // "userfullname" => $userFullName,
    //         // // "ofc_locationid" => $postRec['joining_at'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "modifiedby" => $this->session->userdata('loginid'),
    //         // "emprole" => $postRec['role'],
    //         // "office_number" => $postRec['mob_number'],
    //         // "firstname" => $postRec['first_name'],
    //         // "lastname" => ($postRec['last_name']) ? $postRec['last_name'] : "",
    //         // "userfullname" => $userFullName,
    //         // // "ofc_locationid" => $postRec['joining_at'],
    //         // "createdby" => $this->session->userdata('loginid'),
    //         // "modifiedby" => $this->session->userdata('loginid'),
    //         // "createddate" => date("Y-m-d h:i:s"),
    //         // "modifieddate" => date("Y-m-d h:i:s"),
    //         // // "reporting_manager_io" => $postRec['reporting_manager']
    //         // // "company_nameid" => $postRec['company_id'],
    //         // "employeeId" => $postRec['employee_code'] . $postRec['employee_id'],
    //         // "modeofentry" => $postRec['mode_employment'],
    //         // "selecteddate" => date('Y-m-d'),
    //         // "contactnumber" => $postRec['mob_number'],
    //         // "isactive" => 1,
    //         // "emailaddress" => $postRec['official_emailid']
    //     );
    //     return ($main_employee) ? $main_employee : null;
    // }


    // //For Employee.. Insert
    // public function main_employeeFormArr($postRec)
    // {
    //     $userFullName1 = ($postRec['first_name']) ? $postRec['first_name'] : '';
    //     $userFullName3 = ($postRec['last_name']) ? " " . $postRec['last_name'] : '';
    //     $userFullName = $userFullName1 . $userFullName3;
    //     $main_employeeArr = array(
    //         "date_of_joining" => date("Y-m-d", strtotime($postRec['dateofjoining'])),
    //         "reporting_manager" => $postRec['reporting_manager'],
    //         "reporting_manager_name" => get_ro_details_by_Id($postRec['reporting_manager']),
    //         "emp_status_id" => $postRec['employment_status'],
    //         "businessunit_id" => $postRec['business_unit'],
    //         "department_id" => $postRec['department'],
    //         "jobtitle_id" => $postRec['job_titlegroup'],
    //         "position_id" => $postRec['designation'],
    //         "years_exp" => $postRec['yearofexp_prev'],
    //         "prefix_id" => $postRec['prefix_id'],
    //         "extension_number" => $postRec['extension_number'],
    //         "emprole" => $postRec['role'],
    //         "office_number" => $postRec['mob_number'],
    //         "firstname" => $postRec['first_name'],
    //         "lastname" => ($postRec['last_name']) ? $postRec['last_name'] : "",
    //         "userfullname" => $userFullName,
    //         // "ofc_locationid" => $postRec['joining_at'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "modifiedby" => $this->session->userdata('loginid'),
    //         "createddate" => date("Y-m-d h:i:s"),
    //         "modifieddate" => date("Y-m-d h:i:s"),
    //         // "reporting_manager_io" => $postRec['reporting_manager']
    //         // "company_nameid" => $postRec['company_id'],
    //         "employeeId" => $postRec['employee_code'] . $postRec['employee_id'],
    //         "modeofentry" => $postRec['mode_employment'],
    //         "selecteddate" => date('Y-m-d'),
    //         "contactnumber" => $postRec['mob_number'],
    //         "isactive" => 1,
    //         "emailaddress" => $postRec['official_emailid']
    //     );
    //     return ($main_employeeArr) ? $main_employeeArr : null;
    // }

    // //For Employee.. Update
    // public function main_employeeFormUpdArr($postRec)
    // {
    //     if ($postRec['employment_status'] == '8' or $postRec['employment_status'] == '9' or $postRec['employment_status'] == '4') {
    //         $active = 0;
    //     } else {
    //         $active = 1;
    //     }
    //     $main_employeeArr = array(
    //         "date_of_joining" => date("Y-m-d", strtotime($postRec['dateofjoining'])),
    //         "date_of_leaving" => date("Y-m-d", strtotime($postRec['resigned_date'])),
    //         "reporting_manager" => $postRec['reporting_manager'],
    //         "emp_status_id" => $postRec['employment_status'],
    //         "businessunit_id" => $postRec['business_unit'],
    //         "department_id" => $postRec['department'],
    //         "company_nameid" => $postRec['company_id'],
    //         "ofcialemail" => $postRec['official_emailid'],
    //         "jobtitle_id" => $postRec['job_titlegroup'],
    //         "position_id" => $postRec['designation'],
    //         "years_exp" => $postRec['yearofexp_prev'],
    //         "prefix_id" => $postRec['prefix_id'],
    //         "extension_number" => $postRec['extension_number'],
    //         "office_number" => $postRec['mob_number'],
    //         "ofc_locationid" => $postRec['joining_at'],
    //         "modifiedby" => $this->session->userdata('loginid'),
    //         "modifieddate" => date("Y-m-d h:i:s"),
    //         "reporting_manager_io" => $postRec['reporting_manager'],
    //         "isactive" => $active
    //     );
    //     return ($main_employeeArr) ? $main_employeeArr : null;
    // }

    // //On Project Project Field..
    // public function joining_proj_cond()
    // {
    //     $joiningat = $_POST['joining_at'];
    //     $onProjID = $_POST['project_id'];
    //     if (($joiningat == "4") && ($onProjID == "")) {
    //         $this->form_validation->set_message('joining_proj_cond', 'Please Select Project.');
    //         return false;
    //     } else {
    //         return true;
    //     }
    // }

    // //Condition 2.. Replacement With ..
    // public function replacedwithusercond()
    // {
    //     @$recruitment_for = $_POST['recruitment_for'];
    //     @$replaced_with_userid = $_POST['replaced_with_userid'];
    //     if ((@$recruitment_for == "2") && (@$replaced_with_userid == "")) {
    //         $this->form_validation->set_message('replaced_with_userid', 'Select Replace with User.');
    //         return false;
    //     } else {
    //         return true;
    //     }
    // }

    // //Check Unique Employee ID..
    // public function checkunique_emplid()
    // {
    //     $employeeId = $_POST['employee_code'] . $_POST['employee_id'];
    //     $this->db->where('employeeId', $employeeId);
    //     $num = $this->db->count_all_results('main_users');
    //     if ($num > 0) {
    //         $this->form_validation->set_message('checkunique_emplid', 'Employee id already exists.');
    //         return false;
    //     } else {
    //         return true;
    //     }
    // }

    // //on Project ..Project Designation..
    // public function joining_proj_designation()
    // {
    //     $joiningat = $_POST['joining_at'];
    //     $onProjID = $_POST['project_id'];
    //     $proj_designationid = $_POST['project_designationid'];

    //     if (($joiningat == "4") && ($onProjID) && ($proj_designationid == "")) {
    //         $this->form_validation->set_message('joining_proj_designation', 'Please Select Project Designation.');
    //         return false;
    //     } else {
    //         return true;
    //     }
    // }

    // //Get All Department By Bunit..
    // public function set_department_bybunit_dropd_ajax()
    // {
    //     $unitid = $_REQUEST['bunitid'];
    //     if ($unitid) {
    //         $AllDeprtArr = $this->mastermodel->GetTableData("main_departments", ["isactive" => "1", "unitid" => $unitid]);
    //         echo ($AllDeprtArr) ? json_encode($AllDeprtArr) : FALSE;
    //     }
    // }

    // //Display All Rep Manager Name By B-unit..
    // public function set_reportingmanager_bybunit_dropd_ajax()
    // {
    //     $gotBunitId = $_REQUEST["bunitid"];
    //     $recAllRepManager = null;
    //     if ($gotBunitId != '3') {
    //         $this->db->select('a.user_id,a.userfullname,a.employeeId');
    //         $this->db->from("main_employees_summary as a");
    //         $this->db->where(array("a.isactive" => '1', "a.businessunit_id" => $gotBunitId));
    //         $this->db->order_by("a.userfullname", "ASC");
    //         $this->db->group_by('a.user_id');
    //         $recAllRepManager = $this->db->get()->result();
    //     }

    //     if ($gotBunitId == '3') {
    //         $this->db->select('a.user_id,a.userfullname,a.employeeId');
    //         $this->db->from("main_employees_summary as a");
    //         $whereArr = '(a.businessunit_id="1" or a.businessunit_id = "3")';
    //         $this->db->where($whereArr);
    //         $this->db->where(array("a.isactive" => '1'));
    //         $this->db->order_by("a.userfullname", "ASC");
    //         $this->db->group_by('a.user_id');
    //         $recAllRepManager = $this->db->get()->result();
    //     }


    //     echo ($recAllRepManager) ? json_encode($recAllRepManager) : null;
    // }

    // //Display All Designation on Job Title/Job Group..
    // public function set_designation_position_bybunit_dropd_ajax()
    // {
    //     $gotJobtitleId = $_REQUEST["jtitleid"];
    //     $recAllRepManager = array();
    //     if ($gotJobtitleId) {
    //         $this->db->select('a.id,a.positionname');
    //         $this->db->from("main_positions as a");
    //         $this->db->where(array("a.isactive" => '1', "a.jobtitleid" => $gotJobtitleId));
    //         $this->db->order_by("a.positionname", "ASC");
    //         $recAllRepManager = $this->db->get()->result();
    //     }
    //     echo ($recAllRepManager) ? json_encode($recAllRepManager) : null;
    // }

    // //Get Project Designation By Bd Tem DB..
    // public function set_prodesignation_byprojidbd_dropd_ajax()
    // {
    //     $tsProjId = $_REQUEST["projid"];
    //     $recAllRepManager = null;
    //     if ($tsProjId) {
    //         $AllDeprtArr = $this->mastermodel->set_prodesignation_byprojidbd_dropd_ajax($tsProjId);
    //         echo ($AllDeprtArr) ? json_encode($AllDeprtArr) : FALSE;
    //     }
    // }

    // //Add New Employee..
    // public function employee_add()
    // {
    //     error_reporting(0);
    //     $this->form_validation->set_rules('recruitment_for', 'Recruitment for', 'required|trim');
    //     $this->form_validation->set_rules('prefix_id', 'Prefix', 'required|trim');
    //     $this->form_validation->set_rules('first_name', 'First Name', 'required|trim|min_length[2]|max_length[100]');
    //     $this->form_validation->set_rules('mode_employment', 'Mode of Employment', 'required|trim');
    //     $this->form_validation->set_rules('role', 'Role', 'required|trim');
    //     $this->form_validation->set_rules('employee_id', 'EMPID', 'required|trim|min_length[4]|max_length[6]|callback_checkunique_emplid');
    //     $this->form_validation->set_rules('official_emailid', 'Email ID', 'required|trim|valid_email|is_unique[main_users.emailaddress]');
    //     $this->form_validation->set_rules('business_unit', 'Business Unit', 'required|trim');
    //     $this->form_validation->set_rules('company_id', 'Company', 'required|trim');
    //     $this->form_validation->set_rules('department', 'Department', 'required|trim');
    //     $this->form_validation->set_rules('reporting_manager', 'Reporting Manager', 'required|trim');
    //     $this->form_validation->set_rules('job_titlegroup', 'Job Title', 'required|trim');
    //     $this->form_validation->set_rules('designation', 'Designation', 'required|trim');
    //     $this->form_validation->set_rules('employment_status', 'EMP Status', 'required|trim');
    //     $this->form_validation->set_rules('dateofjoining', 'Date of Joining', 'required|trim');
    //     $this->form_validation->set_rules('yearofexp_prev', 'Year of Experience', 'required|trim');
    //     $this->form_validation->set_rules('mob_number', 'Mob Number', 'required|trim|regex_match[/^[0-9]{10}$/]');
    //     $this->form_validation->set_rules('joining_at', 'joining at', 'required|trim');
    //     $this->form_validation->set_rules('project_id', 'On Project', 'callback_joining_proj_cond');
    //     $this->form_validation->set_rules('replaced_with_userid', 'Replace with User', 'callback_replacedwithusercond');
    //     // $this->form_validation->set_rules('project_designationid', 'Project Designation', 'callback_joining_proj_designation');


    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Add New Employee";

    //         $data['preFixRecArr'] = $this->mastermodel->GetTableData("main_prefix", ["isactive" => "1"]);
    //         $data['roleRecArr'] = $this->mastermodel->GetTableData("main_roles", ["isactive" => "1"]);
    //         $data['BunitsRecArr'] = $this->mastermodel->GetTableData("main_businessunits", ["isactive" => "1", "id!=" => "0"]);
    //         $data['JobGroupRecArr'] = $this->mastermodel->GetTableData("main_jobtitles", ["isactive" => "1"]);
    //         $data['CompanyRecArr'] = $this->mastermodel->GetTableData("tbl_companyname", ["is_active" => "1"]);
    //         $data['EMPCodeRow'] = $this->mastermodel->GetEmpIDCode();
    //         $data['EmpStatusArr'] = $this->mastermodel->GetTableData("tbl_employmentstatus", ["isactive" => "1"]);
    //         $data['ActiveProjectListArr'] = $this->mastermodel->GetAllActiveProjectList();

    //         $data['Lt_EMPID_CEG'] = $this->mastermodel->GetLastEmpIdByCompanyID(1);
    //         $data['Lt_EMPID_CEGTH'] = $this->mastermodel->GetLastEmpIdByCompanyID(2);
    //         $data['Lt_EMPID_PCC'] = $this->mastermodel->GetLastEmpIdByCompanyID(3);
    //         $data['Lt_EMPID_TECHNO'] = $this->mastermodel->GetLastEmpIdByCompanyID(4);
    //         $data['Lt_EMPID_KCPL'] = $this->mastermodel->GetLastEmpIdByCompanyID(5);
    //         $data['Lt_EMPID_SKES'] = $this->mastermodel->GetLastEmpIdByCompanyID(6);
    //         $data['Lt_EMPID_VDP'] = $this->mastermodel->GetLastEmpIdByCompanyID(7);
    //         $data['Lt_EMPID_CegProj'] = $this->mastermodel->GetLastEmpIdCEGProj();
    //         $data['ReplacedWithAllUserListArr'] = $this->mastermodel->GetAllEmployeeListReplacedWith();
    //         $this->load->view("employee/add_emp_official_details", $data);
    //     } else {
    //         $insertArr = $this->main_usersFormArr($this->input->post());
    //         //Update Profile Pic Users..
    //         if (@$_FILES['empprofile_pic']['name']) {
    //             $folder = 'public/uploads/profile/';
    //             $configThm = $this->getUploadConfig($folder);
    //             $this->load->library('upload', $configThm);
    //             $this->upload->initialize($configThm);
    //             if ($this->upload->do_upload('empprofile_pic')) {
    //                 $fileData = $this->upload->data();
    //                 $insertArr['profileimg'] = $fileData['file_name'];
    //             }
    //         }
    //         // echo "<pre>"; print_r($this->input->post()); die;
    //         $this->db->insert("main_users", $insertArr);
    //         $insert_id = $this->db->insert_id();
    //         if ($this->db->trans_status() === FALSE) {
    //             $this->db->trans_rollback();
    //             redirect(base_url("employee_add"));
    //         } else {
    //             //Insert Into Employee Table..
    //             $postRec = $this->input->post();
    //             if ($insert_id) :
    //                 $main_employeeArr = $this->main_employeeFormArr($postRec);
    //                 $main_employeeArr['user_id'] = $insert_id;
    //                 $main_employee = $this->main_employee($postRec);
    //                 $main_employee['user_id'] = $insert_id;
    //                 // $this->db->insert("main_employees", $main_employee);
    //                 // echo "<pre>"; print_r($main_employeeArr); die;
    //                 $this->db->insert("main_employees", $main_employee);
    //                 $this->session->set_flashdata('success_msg', 'Employee Registration Successfully completed.');
    //             endif;
    //             //Inser if On Project Joining..
    //             //                if (($postRec['joining_at'] == '4') and ( $postRec['project_id']) and ( $postRec['project_designationid'])) {
    //             //                    $Team_on_projArr = ['user_id' => $insert_id, 'project_id' => $postRec['project_id'], 'proj_designationid' => $postRec['project_designationid'], 'entry_by' => $this->session->userdata('loginid')];
    //             //                    $this->db->insert("main_team_on_project", $Team_on_projArr);
    //             //                }
    //             //                $this->db->trans_commit();
    //             redirect(base_url("edit_emp_otherofficial/" . $insert_id));
    //         }
    //     }
    //     redirect(base_url("employee_add"));
    // }



    // //Edit Employee Official Details Section..
    // public function employee_edit($empID)
    // {
    //     error_reporting(0);
    //     $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);

    //     if ($this->input->post('official_emailid') != $recSingleEmplDetails->emailaddress) {
    //         $is_unique = '|is_unique[main_users.emailaddress]';
    //     } else {
    //         $is_unique = '';
    //     }

    //     $this->form_validation->set_rules('prefix_id', 'Prefix', 'required|trim');
    //     $this->form_validation->set_rules('first_name', 'First Name', 'required|trim|min_length[2]|max_length[100]');
    //     $this->form_validation->set_rules('mode_employment', 'Mode of Employment', 'required|trim');
    //     $this->form_validation->set_rules('role', 'Role', 'required|trim');
    //     $this->form_validation->set_rules('official_emailid', 'Email ID', 'required|trim|valid_email' . $is_unique);
    //     $this->form_validation->set_rules('business_unit', 'Business Unit', 'required|trim');
    //     $this->form_validation->set_rules('company_id', 'Company', 'required|trim');
    //     $this->form_validation->set_rules('department', 'Department', 'required|trim');
    //     $this->form_validation->set_rules('reporting_manager', 'Reporting Manager', 'required|trim');
    //     $this->form_validation->set_rules('job_titlegroup', 'Job Title', 'required|trim');
    //     $this->form_validation->set_rules('designation', 'Designation', 'required|trim');
    //     $this->form_validation->set_rules('employment_status', 'EMP Status', 'required|trim');
    //     $this->form_validation->set_rules('dateofjoining', 'Date of Joining', 'required|trim');
    //     $this->form_validation->set_rules('yearofexp_prev', 'Year of Experience', 'required|trim');
    //     $this->form_validation->set_rules('mob_number', 'Mob Number', 'required|trim|regex_match[/^[0-9]{10}$/]');
    //     $this->form_validation->set_rules('joining_at', 'joining at', 'required|trim');
    //     $this->form_validation->set_rules('project_id', 'On Project', 'callback_joining_proj_cond');
    //     // $this->form_validation->set_rules('project_designationid', 'Project Designation', 'callback_joining_proj_designation');

    //     if ($this->form_validation->run() == FALSE) {
    //         if ((empty($recSingleEmplDetails) or ($empID == ""))) {
    //             $this->session->set_flashdata('error_msg', 'Something went gone wrong');
    //             redirect(base_url("employee_add"));
    //         }
    //         if ($recSingleEmplDetails) {
    //             $data['error'] = '';
    //             $data['title'] = "Employee Official Details View/Edit/Update";

    //             $data['RecEmplDetails'] = $recSingleEmplDetails;
    //             $data['preFixRecArr'] = $this->mastermodel->GetTableData("main_prefix", ["isactive" => "1"]);
    //             $data['roleRecArr'] = $this->mastermodel->GetTableData("main_roles", ["isactive" => "1"]);
    //             $data['BunitsRecArr'] = $this->mastermodel->GetTableData("main_businessunits", ["isactive" => "1", "id!=" => "0"]);
    //             $data['JobGroupRecArr'] = $this->mastermodel->GetTableData("main_jobtitles", ["isactive" => "1"]);
    //             $data['CompanyRecArr'] = $this->mastermodel->GetTableData("tbl_companyname", ["is_active" => "1"]);
    //             $data['EMPCodeRow'] = $this->mastermodel->GetEmpIDCode();
    //             $data['EmpStatusArr'] = $this->mastermodel->GetTableData("tbl_employmentstatus", ["isactive" => "1"]);
    //             $data['ActiveProjectListArr'] = $this->mastermodel->GetAllActiveProjectList();
    //             $data['ReplacedWithAllUserListArr'] = $this->mastermodel->GetAllEmployeeListReplacedWith();


    //             // echo "<pre>";
    //             // print_r($data);
    //             // die;


    //             $this->load->view("employee/edit_emp_official_details", $data);
    //         }
    //     } else {
    //         //Update Query Official Data..
    //         $postRec = $this->input->post();
    //         $UpdDataArr = $this->main_usersFormUpdArr($postRec);
    //         // echo "<pre>"; print_r($UpdDataArr); die;
    //         if (@$_FILES['empprofile_pic']['name']) {
    //             $folder = 'public/uploads/profile/';
    //             $configThm = $this->getUploadConfig($folder);
    //             $this->load->library('upload', $configThm);
    //             $this->upload->initialize($configThm);
    //             if ($this->upload->do_upload('empprofile_pic')) {
    //                 $fileData = $this->upload->data();
    //                 $UpdDataArr['profileimg'] = $fileData['file_name'];
    //             }
    //         }

    //         $this->db->where(['id' => $empID]);
    //         $return_resp = $this->db->update('main_users', $UpdDataArr);
    //         if ($this->db->trans_status() === FALSE) {
    //             $this->db->trans_rollback();
    //             redirect(base_url("employee_edit/" . $empID));
    //         } else {
    //             //Update Into Employee Table..
    //             if ($return_resp) :
    //                 $main_employeeUpdArr = $this->main_employeeFormUpdArr($postRec);
    //                 $this->db->where(['user_id' => $empID]);
    //                 $return_resp = $this->db->update('main_employees', $main_employeeUpdArr);
    //                 $this->session->set_flashdata('success_msg', 'Employee Record Updated Success');
    //             endif;
    //             $this->db->trans_commit();
    //             redirect(base_url("employee_edit/" . $empID));
    //         }
    //     }
    //     redirect(base_url("employee_edit/" . $empID));
    // }



    // //View / Update / Edit - Employee Personnal Details..
    // public function edit_emp_otherofficial($empID)
    // {
    //     // echo $empID;die;
    //     // echo "test"; die;
    //     // $this->form_validation->set_rules('sub_department', 'Sub Department', 'required|trim');
    //     $this->form_validation->set_rules('reviewing_officer_ro', 'Reviewing Officer RO', 'required|trim');
    //     $this->form_validation->set_rules('nodays_probation_period', 'Probation Period', 'required|trim|numeric|min_length[1]|max_length[3]');
    //     $this->form_validation->set_rules('notice_period_days', 'Notice Period Days', 'required|trim|numeric|min_length[1]|max_length[3]');
    //     // $this->form_validation->set_rules('thumb_code', 'Thumb Code', 'required|trim');
    //     // $this->form_validation->set_rules('ofc_locationid', 'Company Location', 'required|trim');
    //     // $this->form_validation->set_rules('attendance_type', 'Attendance Type', 'required|trim');
    //     $this->form_validation->set_rules('billablenonbillable', 'Billable Non Billable', 'required|trim');

    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Other Official Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['OtherOfcRecDataArr'] = $this->mastermodel->GetEmpotherOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         // echo "<pre>";// print_r($recSingleEmplDetails); die;
    //         if ((empty($recSingleEmplDetails) or ($empID == ""))) {
    //             $this->session->set_flashdata('error_msg', 'Something went gone wrong');
    //             redirect(base_url("employee_add"));
    //         }
    //         if ($recSingleEmplDetails->department_id) {
    //             $data['SubDepartmentRecArr'] = $this->mastermodel->GetTableData("main_subdepartments", ["is_active" => "1", "deptid" => $recSingleEmplDetails->department_id]);
    //         }
    //         if ($recSingleEmplDetails->businessunit_id) {
    //             $data['SubDepartmentRec2'] = $this->mastermodel->GetTableDataRec("sub_dept_second", ["status" => "1", "subdept_type" => '1', "bunit_id" => $recSingleEmplDetails->businessunit_id]);
    //             $data['SubDepartmentRec3'] = $this->mastermodel->GetTableDataRec("sub_dept_second", ["status" => "1", "subdept_type" => '2', "bunit_id" => $recSingleEmplDetails->businessunit_id]);
    //         }

    //         //Company Location..
    //         $data['ofclocationRecArr'] = $this->mastermodel->GetTableData("tbl_ofclocation", ["is_active" => "1"]);
    //         $data['FloorRecArr'] = get_floor_detail();
    //         $data['RO_managerListArr'] = GetAllRepManagerByBUnit($recSingleEmplDetails->businessunit_id);
    //         $jTitleArr = array("8", "9", "10");
    //         $data['RO_managerNewListArr'] = GetAllDesignationByNewJtitID($jTitleArr);
    //         $data['allActiveThumb'] = $this->mastermodel->GetAllActiveThumbCode();


    //         // echo "<pre>".$recSingleEmplDetails->department_id;
    //         // print_r($data['SubDepartmentRecArr']);
    //         // die;


    //         $this->load->view("employee/edit_emp_otherofficial", $data);
    //     } else {
    //         $postRec = $this->input->post();

    //         if ($postRec['payroll_code']) {
    //             $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //             $FnameArr = explode(" ", $recSingleEmplDetails->firstname);
    //             $payroll_with_name = trim($FnameArr[0]) . "_" . $postRec['payroll_code'];
    //             $payroll_with_name = strtolower($payroll_with_name);
    //             $postRec['payroll_with_name'] = ($payroll_with_name) ? $payroll_with_name : '';
    //         }

    //         $numRows = $this->mastermodel->chkExistanceRec('emp_otherofficial_data', ["user_id" => $empID]);
    //         if ($numRows < 1) {
    //             //Insert into emp_otherofficial_data Query.. 
    //             $insertArr = $this->OtherOfficialInsert($empID, $postRec);
    //             // echo "<pre>"; print_r($insertArr); die;
    //             if ($insertArr) :
    //                 $this->db->insert("emp_otherofficial_data", $insertArr);
    //                 $this->session->set_flashdata('success_msg', 'Employee Other Official Details Added Successfully.');
    //             endif;
    //             $this->db->trans_commit();
    //             redirect(base_url("edit_emp_salarydetails/" . $empID));
    //         } else {
    //             //Update emp_otherofficial_data rec Query..
    //             $updRecArr = $this->OtherOfficialUpdate($postRec);

    //             $this->db->where(['user_id' => $empID]);
    //             $return_resp = $this->db->update('emp_otherofficial_data', $updRecArr);
    //             $this->session->set_flashdata('success_msg', 'Employee Other Official Details Updated Successfully.');
    //             redirect(base_url("edit_emp_otherofficial/" . $empID));
    //         }
    //     }
    // }

    // //Employee Salary Details..
    // public function edit_emp_salarydetails($empID)
    // {
    //     $this->form_validation->set_rules('currencyid', 'Currency', 'required|trim');
    //     $this->form_validation->set_rules('salarytype', 'Salary Type', 'required|trim');
    //     $this->form_validation->set_rules('salary', 'Gross Salary', 'required|trim|numeric|min_length[4]|max_length[10]');
    //     $this->form_validation->set_rules('appraisalduedate', 'Appraisal Due Date', 'required|trim');

    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Salary Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         $data['RecEmplSalaryDetails'] = $this->mastermodel->GetEmpSalaryDetailsByUserID($empID);
    //         $data['PayFrequencyRecArr'] = $this->mastermodel->GetTableData("main_payfrequency", ["isactive" => "1"]);
    //         $data['CurrencyRecArr'] = $this->mastermodel->GetTableData("main_currency", ["isactive" => "1"]);
    //         $this->load->view("employee/emp_salarydetails", $data);
    //     } else {
    //         $postRec = $this->input->post();
    //         $numRows = $this->mastermodel->chkExistanceRec('main_empsalarydetails', ["user_id" => $empID]);
    //         if ($numRows < 1) {
    //             //Insert into emp_otherofficial_data Query.. 
    //             $insertArr = $this->EmpSalaryInsert($empID, $postRec);
    //             if ($insertArr) :
    //                 $this->db->insert("main_empsalarydetails", $insertArr);
    //                 $this->session->set_flashdata('success_msg', 'Employee Salary Details Added Successfully.');
    //             endif;
    //             $this->db->trans_commit();
    //             redirect(base_url("edit_emp_personaldetails/" . $empID));
    //         } else {
    //             //Update emp_otherofficial_data rec Query..
    //             $updRecArr = $this->EmpSalaryUpdate($postRec);
    //             $this->db->where(['user_id' => $empID]);
    //             $return_resp = $this->db->update('main_empsalarydetails', $updRecArr);
    //             $this->session->set_flashdata('success_msg', 'Employee Salary Details Updated Successfully.');
    //             redirect(base_url("edit_emp_salarydetails/" . $empID));
    //         }
    //     }
    // }

    // //Employee Personnal Details..
    // public function edit_emp_personaldetails($empID)
    // {
    //     $this->form_validation->set_rules('father_nm', 'Father Name', 'required|trim|min_length[3]|max_length[50]');
    //     $this->form_validation->set_rules('mother_nm', 'Mother Name', 'required|trim|min_length[3]|max_length[50]');
    //     $this->form_validation->set_rules('genderid', 'Gender', 'required|trim');
    //     $this->form_validation->set_rules('maritalstatusid', 'Marital Status', 'required|trim');
    //     $this->form_validation->set_rules('maritalstatusid', 'Marital Status', 'required|trim');
    //     $this->form_validation->set_rules('nationalityid', 'Nationality', 'required|trim');
    //     $this->form_validation->set_rules('religion', 'Religion', 'required|trim');
    //     $this->form_validation->set_rules('languageid', 'Mother Tongue', 'required|trim');
    //     $this->form_validation->set_rules('dob', 'Date of Birth', 'required|trim');

    //     $this->form_validation->set_rules('bloodgroup', 'Blood Group', 'min_length[1]|max_length[20]');
    //     $this->form_validation->set_rules('skypee_id', 'Skypee ID', 'min_length[4]|max_length[100]');
    //     $this->form_validation->set_rules('aadhar_no_enrolment', 'Aadhar No Enrolment', 'min_length[7]|max_length[20]');
    //     $this->form_validation->set_rules('driving_liscence', 'Driving Liscence', 'min_length[4]|max_length[50]');

    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Personal Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         $data['RecEmplPersonalDetails'] = $this->mastermodel->GetEmpPersonalDetailsByUserID($empID);
    //         $data['GenderRecArr'] = $this->mastermodel->GetTableData("main_gender", ["isactive" => "1"]);
    //         $data['MaritalStatusRecArr'] = $this->mastermodel->GetTableData("main_maritalstatus", ["isactive" => "1"]);
    //         $data['NationalityRecArr'] = $this->mastermodel->GetTableData("main_nationality", ["isactive" => "1"]);
    //         $data['ReligionRecArr'] = $this->mastermodel->GetTableData("tbl_religion", ["is_active" => "1"]);
    //         $data['LanguageRecArr'] = $this->mastermodel->GetTableData("main_language", ["isactive" => "1"]);
    //         $this->load->view("employee/emp_personaldetails", $data);
    //     } else {
    //         $postRec = $this->input->post();
    //         $numRows = $this->mastermodel->chkExistanceRec('main_emppersonaldetails', ["user_id" => $empID]);
    //         if ($numRows < 1) {
    //             //Insert into emp_otherofficial_data Query.. 
    //             $insertArr = $this->EmpPersonalDetailsInsert($empID, $postRec);
    //             if ($insertArr) :
    //                 $this->db->insert("main_emppersonaldetails", $insertArr);
    //                 $this->session->set_flashdata('success_msg', 'Employee Personal Details Added Successfully.');
    //             endif;
    //             $this->db->trans_commit();
    //             redirect(base_url("edit_emp_contact/" . $empID));
    //         } else {
    //             //Update Personal Details rec Query..
    //             $updRecArr = $this->EmpPersonalDetailsUpd($postRec);
    //             $this->db->where(['user_id' => $empID]);
    //             $return_resp = $this->db->update('main_emppersonaldetails', $updRecArr);
    //             $this->session->set_flashdata('success_msg', 'Employee Personal Details Updated Successfully.');
    //             redirect(base_url("edit_emp_contact/" . $empID));
    //         }
    //     }
    // }

    // //Employee Contact Details...
    // public function edit_emp_contact($empID)
    // {
    //     $this->form_validation->set_rules('perm_hono', 'House No.', 'required|trim|min_length[3]|max_length[200]');
    //     $this->form_validation->set_rules('perm_streetaddress', 'Street Address', 'required|trim|min_length[5]|max_length[200]');
    //     $this->form_validation->set_rules('perm_area_locality', 'Area / Locality', 'required|trim|min_length[5]|max_length[150]');
    //     $this->form_validation->set_rules('perm_city', 'City', 'required|trim|min_length[1]|max_length[10]');
    //     $this->form_validation->set_rules('perm_state', 'State', 'required|trim|min_length[1]|max_length[10]');
    //     $this->form_validation->set_rules('perm_country', 'Country', 'required|trim|min_length[1]|max_length[10]');
    //     $this->form_validation->set_rules('perm_pincode', 'Pin Code', 'required|trim|min_length[6]|max_length[7]|numeric');
    //     $this->form_validation->set_rules('personalemail', 'Email', 'required|trim|min_length[6]|max_length[100]|valid_email');

    //     $this->form_validation->set_rules('current_hono', 'House No.', 'required|trim|min_length[3]|max_length[200]');
    //     $this->form_validation->set_rules('current_streetaddress', 'Street Address', 'required|trim|min_length[5]|max_length[200]');
    //     $this->form_validation->set_rules('current_area_locality', 'Area / Locality', 'required|trim|min_length[5]|max_length[150]');
    //     $this->form_validation->set_rules('current_city', 'City', 'required|trim|min_length[1]|max_length[10]');
    //     $this->form_validation->set_rules('current_state', 'State', 'required|trim|min_length[1]|max_length[10]');
    //     $this->form_validation->set_rules('current_country', 'Country', 'required|trim|min_length[1]|max_length[10]');
    //     $this->form_validation->set_rules('current_pincode', 'Pin Code', 'required|trim|min_length[6]|max_length[7]|numeric');

    //     $this->form_validation->set_rules('emergency_name', 'Name', 'required|trim|min_length[3]|max_length[150]');
    //     $this->form_validation->set_rules('emergency_namerelation', 'Relation', 'required|trim|min_length[3]|max_length[150]');
    //     $this->form_validation->set_rules('emergency_email', 'Email', 'required|trim|min_length[3]|max_length[100]|valid_email');
    //     $this->form_validation->set_rules('emergency_number', 'Contact', 'required|trim|min_length[10]|max_length[12]|numeric');
    //     $this->form_validation->set_rules('emergency_address', 'Address', 'required|trim|min_length[4]|max_length[200]');

    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Contact Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         // echo "<pre>"; print_r($data['RecEmplDetails']); die;
    //         $data['countriesRecArr'] = $this->mastermodel->GetAllcountries();
    //         //Get Contact Recd..
    //         $data['RecEmplContactDetails'] = $this->mastermodel->GetRecEmplContactDetails($empID);

    //         $this->load->view("employee/emp_contact", $data);
    //     } else {
    //         $postRec = $this->input->post();
    //         $numRows = $this->mastermodel->chkExistanceRec('main_empcommunicationdetails', ["user_id" => $empID]);
    //         if ($numRows < 1) {
    //             //Insert into emp_otherofficial_data Query.. 
    //             $insertArr = $this->EmpContactDetailsInsert($empID, $postRec);
    //             if ($insertArr) :
    //                 $this->db->insert("main_empcommunicationdetails", $insertArr);
    //                 $this->session->set_flashdata('success_msg', 'Employee Contact Details Added Successfully.');
    //             endif;
    //             $this->db->trans_commit();
    //             redirect(base_url("edit_emp_skills/" . $empID));
    //         } else {
    //             //Update Personal Details rec Query..
    //             $updRecArr = $this->EmpContactDetailsUpdate($postRec);
    //             $this->db->where(['user_id' => $empID]);
    //             $return_resp = $this->db->update('main_empcommunicationdetails', $updRecArr);
    //             $this->session->set_flashdata('success_msg', 'Employee Contact Details Updated Successfully.');
    //             redirect(base_url("edit_emp_skills/" . $empID));
    //         }
    //     }
    // }

    // //Employee Skills Details..
    // public function edit_emp_skills($empID)
    // {
    //     // echo $empID; die;
    //     $this->form_validation->set_rules('skillname', 'Skill Name', 'required|trim|min_length[3]|max_length[200]');
    //     $this->form_validation->set_rules('training_type', 'Training Type', 'required|trim|min_length[3]|max_length[200]');
    //     $this->form_validation->set_rules('institute_clg_name', 'Institute Name', 'required|trim|min_length[3]|max_length[200]');
    //     $this->form_validation->set_rules('university', 'University', 'required|trim|min_length[3]|max_length[200]');
    //     $this->form_validation->set_rules('marks_obtained', 'Marks Obtained', 'required|trim|min_length[3]|max_length[200]');
    //     $this->form_validation->set_rules('tenure_from_to', 'Tenure From & To', 'required|trim|min_length[3]|max_length[200]');
    //     $this->form_validation->set_rules('percentage_grade', 'Percentage', 'required|trim|min_length[1]|max_length[200]');
    //     $this->form_validation->set_rules('competency_level', 'Competency Level', 'required|trim|min_length[1]|max_length[3]');
    //     $this->form_validation->set_rules('year_skill_last_used', 'Skill Last Used', 'required|trim|min_length[3]|max_length[200]');

    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Skills Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         // echo "dd<pre>"; print_r($recSingleEmplDetails); die;
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         $data['skillArrlv'] = CompetencyLevel();

    //         //Get Skills Recd..
    //         $data['RecEmplSkillsDetails'] = $this->mastermodel->GetRecEmplSkillsDetails($empID);
    //         // echo "<pre>"; print_r($data['RecEmplDetails']); die;
    //         $this->load->view("employee/emp_skills", $data);
    //     } else {
    //         $postRec = $this->input->post();
    //         //Insert into Skills Query.. 
    //         $insertArr = $this->EmpSkillsDetailsInsert($empID, $postRec);
    //         if ($insertArr) :
    //             $this->db->insert("main_empskills", $insertArr);
    //             $this->session->set_flashdata('success_msg', ' Skills Details Added Successfully.');
    //         endif;
    //         $this->db->trans_commit();
    //         redirect(base_url("edit_emp_skills/" . $empID));
    //     }
    // }

    // //Delete Skills..
    // public function delete_skill($fldID)
    // {
    //     if ($fldID) {
    //         $this->db->set("isactive", "0");
    //         $this->db->where("id", $fldID);
    //         $this->db->update("main_empskills", $updArr);
    //         $this->session->set_flashdata('success_msg', 'Skills Deleted Successfully.');
    //     }
    //     redirect($_SERVER['HTTP_REFERER']);
    // }

    // //Delete Job History..
    // public function delete_jobhistory($fldID)
    // {
    //     if ($fldID) {
    //         $this->db->set("isactive", "0");
    //         $this->db->where("id", $fldID);
    //         $this->db->update("main_empjobhistory", $updArr);
    //         $this->session->set_flashdata('success_msg', 'Job History Deleted Successfully.');
    //     }
    //     redirect($_SERVER['HTTP_REFERER']);
    // }

    // //Delete Experiance..
    // public function delete_experience($fldID)
    // {
    //     if ($fldID) {
    //         $this->db->set("isactive", "0");
    //         $this->db->where("id", $fldID);
    //         $this->db->update("main_empexperiancedetails", $updArr);
    //         $this->session->set_flashdata('success_msg', 'Experiance Deleted Successfully.');
    //     }
    //     redirect($_SERVER['HTTP_REFERER']);
    // }

    // //Delete family Details..
    // public function deletefamilydetails($fldID)
    // {
    //     if ($fldID) {
    //         $this->db->set("isactive", "0");
    //         $this->db->where("id", $fldID);
    //         $this->db->update("main_empdependencydetails", $updArr);
    //         $this->session->set_flashdata('success_msg', 'Dependency/Family Deleted Successfully.');
    //     }
    //     redirect($_SERVER['HTTP_REFERER']);
    // }

    // //Delete Training Certification Details..
    // public function delete_trainingcertification($fldID)
    // {
    //     if ($fldID) {
    //         $this->db->set("isactive", "0");
    //         $this->db->where("id", $fldID);
    //         $this->db->update("main_empcertificationdetails", $updArr);
    //         $this->session->set_flashdata('success_msg', 'Training Certification Deleted Successfully.');
    //     }
    //     redirect($_SERVER['HTTP_REFERER']);
    // }

    // //Delete Educational Details..
    // public function delete_educational($fldID)
    // {
    //     if ($fldID) {
    //         $this->db->set("isactive", "0");
    //         $this->db->where("id", $fldID);
    //         $this->db->update("main_empeducationdetails", $updArr);
    //         $this->session->set_flashdata('success_msg', 'Educational Deleted Successfully.');
    //     }
    //     redirect($_SERVER['HTTP_REFERER']);
    // }

    // //Employee Job History...
    // public function edit_emp_jobhistory($empID)
    // {
    //     $this->form_validation->set_rules('business_unit', 'Business Unit', 'required|trim');
    //     $this->form_validation->set_rules('department', 'Department', 'required|trim');
    //     $this->form_validation->set_rules('job_titlegroup', 'Job Title', 'required|trim');
    //     $this->form_validation->set_rules('designation', 'Designation', 'required|trim');
    //     $this->form_validation->set_rules('vendor', 'Company', 'required|trim');
    //     $this->form_validation->set_rules('start_date', 'Start Date', 'required|trim');
    //     $this->form_validation->set_rules('end_date', 'End Date', 'required|trim');

    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Job History Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         $data['BunitsRecArr'] = $this->mastermodel->GetTableData("main_businessunits", ["isactive" => "1", "id!=" => "0"]);
    //         $data['JobGroupRecArr'] = $this->mastermodel->GetTableData("main_jobtitles", ["isactive" => "1"]);
    //         $data['CompanyRecArr'] = $this->mastermodel->GetTableData("tbl_companyname", ["is_active" => "1"]);
    //         $data['PositionsRecArr'] = $this->mastermodel->GetTableData("main_positions", ["isactive" => "1"]);
    //         $data['ProjectsRecArr'] = $this->mastermodel->GetTableData("tm_projects", ["is_active" => "1"]);
    //         $data['RecEmplSkillsDetails'] = $this->mastermodel->GetRecEmpljobhistoryDetails($empID);
    //         $data['jobhistoryRecArr'] = $this->mastermodel->GetRecEmpljobhistoryDetails($empID);

    //         $this->load->view("employee/emp_jobhistory", $data);
    //     } else {
    //         $postRec = $this->input->post();
    //         //Insert into Skills Query.. 
    //         $insertArr = $this->EmpJobHistoryDetailsInsert($empID, $postRec);
    //         if ($insertArr) :
    //             $this->db->insert("main_empjobhistory", $insertArr);
    //             $this->session->set_flashdata('success_msg', 'Employee Job History Added Successfully.');
    //         endif;
    //         $this->db->trans_commit();
    //         redirect(base_url("edit_emp_jobhistory/" . $empID));
    //     }
    // }

    // //Employee Experience..
    // public function edit_emp_experience($empID)
    // {

    //     $this->form_validation->set_rules('comp_name', 'Company Name', 'required|trim|min_length[2]|max_length[100]');
    //     $this->form_validation->set_rules('comp_website', 'Company Website', 'required|trim|min_length[4]|max_length[100]');
    //     $this->form_validation->set_rules('comp_location', 'comp_location', 'required|trim|min_length[2]|max_length[100]');
    //     $this->form_validation->set_rules('designation', 'Designation', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('from_date', 'From Date', 'required|trim');
    //     $this->form_validation->set_rules('to_date', 'To Date', 'required|trim');
    //     $this->form_validation->set_rules('reason_for_leaving', 'Reason For Leaving', 'required|trim');
    //     $this->form_validation->set_rules('reference_name', 'Reference Name', 'required|trim');
    //     $this->form_validation->set_rules('reference_contact', 'Reference Contact', 'required|trim');
    //     $this->form_validation->set_rules('reference_email', 'Reference Email', 'required|trim');
    //     $this->form_validation->set_rules('last_salary_drawn', 'Last Salary', 'required|trim');
    //     $this->form_validation->set_rules('is_ceg_exper', 'Is CEG Experience', 'required|trim');

    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Experience Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         $data['EmplExperienceRecArr'] = $this->mastermodel->GetTableData("main_empexperiancedetails", ["isactive" => "1", "user_id" => $empID]);

    //         $this->load->view("employee/emp_experience", $data);
    //     } else {
    //         $postRec = $this->input->post();
    //         //Insert into Experiance Query.. 
    //         $insertArr = $this->EmpExperianceDetailsInsert($empID, $postRec);
    //         if ($insertArr) :
    //             $this->db->insert("main_empexperiancedetails", $insertArr);
    //             $this->session->set_flashdata('success_msg', 'Employee Experiance Details Added Successfully.');
    //         endif;
    //         $this->db->trans_commit();
    //         redirect(base_url("edit_emp_experience/" . $empID));
    //     }
    // }

    // //Employee Educational Details..
    // public function edit_emp_educationdetails($empID)
    // {
    //     $this->form_validation->set_rules('educationlevel', 'Education Level', 'required|trim|min_length[1]|max_length[3]');
    //     $this->form_validation->set_rules('coursetype_id', 'Course Type', 'required|trim|min_length[1]|max_length[3]');
    //     $this->form_validation->set_rules('institution_name', 'Institution Name', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('course', 'Course Name', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('board_university', 'Board / University', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('marks_obtained', 'Marks Obtained', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('from_date', 'From Date', 'required|trim');
    //     $this->form_validation->set_rules('to_date', 'To Date', 'required|trim');
    //     $this->form_validation->set_rules('stream', 'Stream', 'required|trim');
    //     $this->form_validation->set_rules('percentage', 'Percentage / Grade', 'required|trim');
    //     $this->form_validation->set_rules('spc_location', 'Location', 'required|trim');
    //     $this->form_validation->set_rules('passing_year', 'Passing Year', 'required|trim');
    //     $this->form_validation->set_rules('specialization', 'Specialization', 'required|trim');

    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Educational Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         $data['EducationLevelRecArr'] = $this->mastermodel->GetTableData("main_educationlevelcode", ["isactive" => "1"]);
    //         $data['CourseTypeRecArr'] = $this->mastermodel->GetTableData("tbl_coursetype", ["is_active" => "1"]);
    //         $data['EmplEducationalRecArr'] = $this->mastermodel->GetTableData("main_empeducationdetails", ["isactive" => "1", "user_id" => $empID]);

    //         $this->load->view("employee/emp_educationdetails", $data);
    //     } else {
    //         $postRec = $this->input->post();
    //         //Insert into Educational Details Query.. 
    //         $insertArr = $this->EmpEducationalDetailsInsert($empID, $postRec);
    //         if ($insertArr) :
    //             $this->db->insert("main_empeducationdetails", $insertArr);
    //             $this->session->set_flashdata('success_msg', 'Employee Educational Details Added Successfully.');
    //         endif;
    //         $this->db->trans_commit();
    //         redirect(base_url("edit_emp_educationdetails/" . $empID));
    //     }
    // }

    // //Employee Training Details...
    // public function edit_emp_trainingcertification($empID)
    // {
    //     $this->form_validation->set_rules('course_name', 'Course', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('course_level', 'Course Level', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('certification_name', 'Certification Name', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('course_offered_by', 'Course Offered By', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('description', 'Description', 'required|trim');
    //     $this->form_validation->set_rules('certification_name', 'Certification Name', 'required|trim');
    //     $this->form_validation->set_rules('marks_obtained', 'Marks Obtained', 'required|trim');
    //     $this->form_validation->set_rules('issued_date', 'Issued Date', 'required|trim');


    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = "";
    //         $data['title'] = "Employee Training Certification Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         $data['TrainingCertificationRecArr'] = $this->mastermodel->GetTableData("main_empcertificationdetails", ["isactive" => "1", "user_id" => $empID]);

    //         $this->load->view("employee/emp_trainingcertification", $data);
    //     } else {
    //         $postRec = $this->input->post();
    //         //Insert Training & Certification Query.. 
    //         $insertArr = $this->EmpTrainingCertificationDetailsInsert($empID, $postRec);
    //         if ($insertArr) :
    //             $this->db->insert("main_empcertificationdetails", $insertArr);
    //             $this->session->set_flashdata('success_msg', 'Training & Certification Details Added Successfully.');
    //         endif;
    //         $this->db->trans_commit();
    //         redirect(base_url("edit_emp_trainingcertification/" . $empID));
    //     }
    // }

    // //Employee Insurance Details...
    // public function edit_emp_insurance($empID)
    // {
    //     $this->form_validation->set_rules('year_skill_last_used', 'Skill Last Used', 'required|trim|min_length[3]|max_length[200]');
    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Insurance/Mediclaim Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         //$data['BunitsRecArr'] = $this->mastermodel->GetTableData("main_businessunits", ["isactive" => "1", "id!=" => "0"]);
    //         //$data['JobGroupRecArr'] = $this->mastermodel->GetTableData("main_jobtitles", ["isactive" => "1"]);
    //         //$data['CompanyRecArr'] = $this->mastermodel->GetTableData("tbl_companyname", ["is_active" => "1"]);
    //         // $data['RecEmplSkillsDetails'] = $this->mastermodel->GetRecEmplSkillsDetails($empID);
    //         $this->load->view("employee/emp_insurance", $data);
    //     } else {
    //         echo "<pre>";
    //         print_r($_REQUEST);
    //         die;
    //         // $postRec = $this->input->post();
    //         //Insert into Skills Query.. 
    //         // $insertArr = $this->EmpSkillsDetailsInsert($empID, $postRec);
    //         //  if ($insertArr):
    //         //  $this->db->insert("main_empskills", $insertArr);
    //         //  $this->session->set_flashdata('success_msg', 'Employee Skills Details Added Successfully.');
    //         // endif;
    //         // $this->db->trans_commit();
    //         //  redirect(base_url("edit_emp_skills/" . $empID));
    //     }
    // }

    // //Add Family Details..
    // public function edit_emp_family($empID)
    // {
    //     $this->form_validation->set_rules('dependent_name', 'Dependent Name', 'required|trim|min_length[3]|max_length[200]');
    //     $this->form_validation->set_rules('dependent_relation', 'Relation', 'required|trim|min_length[2]|max_length[200]');
    //     $this->form_validation->set_rules('dependent_dob', 'Date of Birth', 'required|trim');


    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Family Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         $data['RecFamilyMemberRelationMaster'] = $this->mastermodel->FamilyMemberRelationMaster();
    //         $data['RecFamilyDetailsArr'] = $this->mastermodel->GetRecEmplFamilyDetails($empID);

    //         $this->load->view("employee/emp_family", $data);
    //     } else {
    //         $postRec = $this->input->post();
    //         //Insert into Family Details.. 
    //         $insertArr = $this->EmpDependencyFamilyDetailsInsert($empID, $postRec);
    //         if ($insertArr) :
    //             $this->db->insert("main_empdependencydetails", $insertArr);
    //             $this->session->set_flashdata('success_msg', 'Family Details Added Successfully.');
    //         endif;
    //         $this->db->trans_commit();
    //         redirect(base_url("edit_emp_family/" . $empID));
    //     }
    // }

    // //Employee Account Section .. 
    // public function edit_emp_accountsection($empID)
    // {
    //     $this->form_validation->set_rules('year_skill_last_used', 'Skill Last Used', 'required|trim|min_length[3]|max_length[200]');
    //     if ($this->form_validation->run() == FALSE) {
    //         $data['error'] = '';
    //         $data['title'] = "Employee Family Details";
    //         $recSingleEmplDetails = $this->mastermodel->GetEmpOfficialDataByUserID($empID);
    //         $data['RecEmplDetails'] = $recSingleEmplDetails;
    //         $data['ITrRecArr'] = $this->mastermodel->GetTableData("main_itr", ["is_active" => "1", "user_id" => $empID]);
    //         $data['RecEmplRecentPayslip'] = $this->mastermodel->GetRecentPayslipDetails($empID);
    //         $this->load->view("employee/emp_accountsection", $data);
    //     } else {
    //         redirect(base_url("employee_edit/" . $empID));
    //     }
    // }

    // //File Upload Config Details..
    // protected function getUploadConfig($folder)
    // {
    //     $config = array();
    //     $config['upload_path'] = $folder;
    //     $config['allowed_types'] = 'JPG|jpg|png|jpeg';
    //     $config['max_size'] = '1020'; //1MB
    //     $config['file_name'] = "profile_" . time();
    //     return $config;
    // }

    // //Other Official Form Insert..
    // public function OtherOfficialInsert($empID, $PostRec)
    // {
    //     $insertArr = array(
    //         "user_id" => $empID,
    //         "sub_department" => $PostRec['sub_department'],
    //         "payroll_with_name" => $PostRec['payroll_with_name'],
    //         "sub_dept_second" => $PostRec['sub_department_two'],
    //         "sub_dept_third" => $PostRec['sub_department_three'],
    //         "reviewing_officer_ro" => $PostRec['reviewing_officer_ro'],
    //         "company_location" => $PostRec['ofc_locationid'],
    //         "probation_period_no" => $PostRec['nodays_probation_period'],
    //         "noticeperiod" => $PostRec['notice_period_days'],
    //         "thumbcode" => $PostRec['thumb_code'],
    //         "payrollcode" => $PostRec['payroll_code'],
    //         "atten_punch" => $PostRec['attendance_type'],
    //         "billable_non_billable" => $PostRec['billablenonbillable'],
    //         "machine_id" => $PostRec['attend_machineid'],
    //         "floor_number" => $PostRec['floor_number'],
    //         "related_with" => $PostRec['related_with']
    //     );
    //     return ($insertArr) ? $insertArr : $insertArr;
    // }

    // //Other Official Form Insert..
    // public function OtherOfficialUpdate($PostRec)
    // {
    //     $UpdateArr = array(
    //         "sub_department" => $PostRec['sub_department'],
    //         "payroll_with_name" => $PostRec['payroll_with_name'],
    //         "sub_dept_second" => $PostRec['sub_department_two'],
    //         "sub_dept_third" => $PostRec['sub_department_three'],
    //         "reviewing_officer_ro" => $PostRec['reviewing_officer_ro'],
    //         "company_location" => $PostRec['ofc_locationid'],
    //         "probation_period_no" => $PostRec['nodays_probation_period'],
    //         "noticeperiod" => $PostRec['notice_period_days'],
    //         "thumbcode" => $PostRec['thumb_code'],
    //         "payrollcode" => $PostRec['payroll_code'],
    //         "atten_punch" => $PostRec['attendance_type'],
    //         "billable_non_billable" => $PostRec['billablenonbillable'],
    //         "machine_id" => $PostRec['attend_machineid'],
    //         "floor_number" => $PostRec['floor_number'],
    //         "related_with" => $PostRec['related_with']
    //     );
    //     return ($UpdateArr) ? $UpdateArr : $UpdateArr;
    // }

    // //Employee Salary..
    // public function EmpSalaryInsert($empID, $PostRec)
    // {
    //     $insertArr = array(
    //         "user_id" => $empID,
    //         "currencyid" => $PostRec['currencyid'],
    //         "salarytype" => $PostRec['salarytype'],
    //         "salary" => $PostRec['salary'],
    //         "bankname" => $PostRec['bankname'],
    //         "accountnumber" => $PostRec['accountnumber'],
    //         "accountholder_name" => $PostRec['accountholder_name'],
    //         "branchname" => $PostRec['branchname'],
    //         "ifsc_code" => $PostRec['ifsc_code'],
    //         "pancard_no" => $PostRec['pancard_no'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "appraisalduedate" => date('F Y', strtotime($PostRec['appraisalduedate'])),
    //         "createddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($insertArr) ? $insertArr : $insertArr;
    // }

    // //Update Salary Details...
    // public function EmpSalaryUpdate($PostRec)
    // {
    //     $UpdArr = array(
    //         "currencyid" => $PostRec['currencyid'],
    //         "salarytype" => $PostRec['salarytype'],
    //         "salary" => $PostRec['salary'],
    //         "bankname" => $PostRec['bankname'],
    //         "accountnumber" => $PostRec['accountnumber'],
    //         "accountholder_name" => $PostRec['accountholder_name'],
    //         "branchname" => $PostRec['branchname'],
    //         "ifsc_code" => $PostRec['ifsc_code'],
    //         "pancard_no" => $PostRec['pancard_no'],
    //         "modifiedby" => $this->session->userdata('loginid'),
    //         "appraisalduedate" => date('F Y', strtotime($PostRec['appraisalduedate'])),
    //         "modifieddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($UpdArr) ? $UpdArr : $UpdArr;
    // }

    // //Insert Employee Personnal Details..
    // public function EmpPersonalDetailsInsert($empID, $PostRec)
    // {
    //     $insertArr = array(
    //         "user_id" => $empID, "genderid" => $PostRec['genderid'],
    //         "mother_nm" => $PostRec['mother_nm'],
    //         "father_nm" => $PostRec['father_nm'],
    //         "maritalstatusid" => $PostRec['maritalstatusid'],
    //         "maritaldate" => '',
    //         "nationalityid" => $PostRec['nationalityid'],
    //         "religion" => $PostRec['religion'],
    //         "languageid" => $PostRec['languageid'],
    //         "language_known" => ($PostRec['language_known']) ? json_encode($PostRec['language_known']) : '',
    //         "dob" => date("Y-m-d", strtotime($PostRec['dob'])),
    //         "bloodgroup" => $PostRec['bloodgroup'],
    //         "skypee_id" => $PostRec['skypee_id'],
    //         "aadhar_no_enrolment" => $PostRec['aadhar_no_enrolment'],
    //         "height_cms" => $PostRec['height_cms'],
    //         "weight" => $PostRec['weight'],
    //         "driving_liscence" => $PostRec['driving_liscence'],
    //         "ration_card" => $PostRec['ration_card'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "createddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($insertArr) ? $insertArr : $insertArr;
    // }

    // //Update Employee Personnal Details..
    // public function EmpPersonalDetailsUpd($PostRec)
    // {
    //     $insertArr = array(
    //         "genderid" => $PostRec['genderid'],
    //         "mother_nm" => $PostRec['mother_nm'],
    //         "father_nm" => $PostRec['father_nm'],
    //         "maritalstatusid" => $PostRec['maritalstatusid'],
    //         "maritaldate" => '',
    //         "nationalityid" => $PostRec['nationalityid'],
    //         "religion" => $PostRec['religion'],
    //         "languageid" => $PostRec['languageid'],
    //         "language_known" => ($PostRec['language_known']) ? json_encode($PostRec['language_known']) : '',
    //         "dob" => date("Y-m-d", strtotime($PostRec['dob'])),
    //         "bloodgroup" => $PostRec['bloodgroup'],
    //         "skypee_id" => $PostRec['skypee_id'],
    //         "height_cms" => $PostRec['height_cms'],
    //         "weight" => $PostRec['weight'],
    //         "aadhar_no_enrolment" => $PostRec['aadhar_no_enrolment'],
    //         "driving_liscence" => $PostRec['driving_liscence'],
    //         "ration_card" => $PostRec['ration_card'],
    //         "modifiedby" => $this->session->userdata('loginid'),
    //         "modifieddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($insertArr) ? $insertArr : $insertArr;
    // }

    // public function ajax_setstate_bycountryid()
    // {
    //     $countryid = $_REQUEST['country_id'];
    //     if ($countryid) {
    //         $this->db->select('state_id,state_name');
    //         $this->db->from('states');
    //         $this->db->where(array('country_id' => $countryid, 'status' => '1'));
    //         $this->db->order_by('state_name', 'ASC');
    //         $resultArr = $this->db->get()->result();
    //         echo json_encode($resultArr);
    //     }
    //     exit();
    // }

    // //Get City...
    // public function ajax_setcity_bystateid()
    // {
    //     $stateid = $_REQUEST['state_id'];
    //     if ($stateid) {
    //         $this->db->select('city_id,city_name');
    //         $this->db->from('cities');
    //         $this->db->where(array('state_id' => $stateid, 'status' => '1'));
    //         $this->db->order_by('city_name', 'ASC');
    //         $resultArr = $this->db->get()->result();
    //         echo json_encode($resultArr);
    //     }
    //     exit();
    // }

    // //Contact ..
    // public function EmpContactDetailsInsert($empID, $PostRec)
    // {
    //     $insertArr = array(
    //         "user_id" => $empID,
    //         "perm_streetaddress" => $PostRec['perm_streetaddress'],
    //         "perm_area_locality" => $PostRec['perm_area_locality'],
    //         "perm_country" => $PostRec['perm_country'],
    //         "perm_state" => $PostRec['perm_state'],
    //         "perm_city" => $PostRec['perm_city'],
    //         "perm_pincode" => $PostRec['perm_pincode'],
    //         "personalemail" => $PostRec['personalemail'],
    //         "current_streetaddress" => $PostRec['current_streetaddress'],
    //         "current_area_locality" => $PostRec['current_area_locality'],
    //         "current_country" => $PostRec['current_country'],
    //         "current_state" => $PostRec['current_state'],
    //         "current_city" => $PostRec['current_city'],
    //         "current_pincode" => $PostRec['current_pincode'],
    //         "current_email" => $PostRec['current_email'],
    //         "emergency_number" => $PostRec['emergency_number'],
    //         "emergency_name" => $PostRec['emergency_name'],
    //         "emergency_namerelation" => $PostRec['emergency_namerelation'],
    //         "emergency_email" => $PostRec['emergency_email'],
    //         "emergency_address" => $PostRec['emergency_address'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "createddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($insertArr) ? $insertArr : $insertArr;
    // }

    // //Contact Details Update..
    // public function EmpContactDetailsUpdate($PostRec)
    // {
    //     $UpdateArr = array(
    //         "perm_hono" => $PostRec['perm_hono'],
    //         "perm_streetaddress" => $PostRec['perm_streetaddress'],
    //         "perm_area_locality" => $PostRec['perm_area_locality'],
    //         "perm_country" => $PostRec['perm_country'],
    //         "perm_state" => $PostRec['perm_state'],
    //         "perm_city" => $PostRec['perm_city'],
    //         "perm_pincode" => $PostRec['perm_pincode'],
    //         "personalemail" => $PostRec['personalemail'],
    //         "current_hono" => $PostRec['current_hono'],
    //         "current_streetaddress" => $PostRec['current_streetaddress'],
    //         "current_area_locality" => $PostRec['current_area_locality'],
    //         "current_country" => $PostRec['current_country'],
    //         "current_state" => $PostRec['current_state'],
    //         "current_city" => $PostRec['current_city'],
    //         "current_pincode" => $PostRec['current_pincode'],
    //         "current_email" => $PostRec['current_email'],
    //         "emergency_number" => $PostRec['emergency_number'],
    //         "emergency_name" => $PostRec['emergency_name'],
    //         "emergency_namerelation" => $PostRec['emergency_namerelation'],
    //         "emergency_email" => $PostRec['emergency_email'],
    //         "emergency_address" => $PostRec['emergency_address'],
    //         "modifiedby" => $this->session->userdata('loginid'),
    //         "modifieddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($UpdateArr) ? $UpdateArr : $UpdateArr;
    // }

    // //Skill Insert..
    // public function EmpSkillsDetailsInsert($empID, $PostRec)
    // {
    //     $UpdateArr = array(
    //         "user_id" => $empID,
    //         "skillname" => $PostRec['skillname'],
    //         "training_type" => $PostRec['training_type'],
    //         "institute_clg_name" => $PostRec['institute_clg_name'],
    //         "university" => $PostRec['university'],
    //         "marks_obtained" => $PostRec['marks_obtained'],
    //         "tenure_from_to" => $PostRec['tenure_from_to'],
    //         "percentage_grade" => $PostRec['percentage_grade'],
    //         "competency_level" => $PostRec['competency_level'],
    //         "yearsofexp" => $PostRec['yearsofexp'],
    //         "competencylevelid" => $PostRec['competencylevelid'],
    //         "year_skill_last_used" => $PostRec['year_skill_last_used'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "createddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($UpdateArr) ? $UpdateArr : $UpdateArr;
    // }

    // //Job History..
    // public function EmpJobHistoryDetailsInsert($empID, $PostRec)
    // {
    //     $UpdateArr = array(
    //         "user_id" => $empID,
    //         "businessunit" => $PostRec['business_unit'],
    //         "positionheld" => $PostRec['designation'],
    //         "department" => $PostRec['department'],
    //         "jobtitleid" => $PostRec['job_titlegroup'],
    //         "start_date" => date("Y-m-d", strtotime($PostRec['start_date'])),
    //         "end_date" => date("Y-m-d", strtotime($PostRec['end_date'])),
    //         "vendor" => $PostRec['vendor'],
    //         "project_id" => $PostRec['project_id'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "isactive" => "1",
    //         "createddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($UpdateArr) ? $UpdateArr : $UpdateArr;
    // }

    // //Experiance Details Insert..
    // public function EmpExperianceDetailsInsert($empID, $PostRec)
    // {
    //     $InsertArr = array(
    //         "user_id" => $empID,
    //         "comp_name" => $PostRec['comp_name'],
    //         "comp_website" => $PostRec['comp_website'],
    //         "comp_location" => $PostRec['comp_location'],
    //         "designation" => $PostRec['designation'],
    //         "from_date" => date("Y-m-d", strtotime($PostRec['from_date'])),
    //         "to_date" => date("Y-m-d", strtotime($PostRec['to_date'])),
    //         "reason_for_leaving" => $PostRec['reason_for_leaving'],
    //         "reference_name" => $PostRec['reference_name'],
    //         "reference_contact" => $PostRec['reference_contact'],
    //         "reference_email" => $PostRec['reference_email'],
    //         "is_ceg_exper" => $PostRec['is_ceg_exper'],
    //         "last_salary_drawn" => $PostRec['last_salary_drawn'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "isactive" => "1",
    //         "createddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($InsertArr) ? $InsertArr : $InsertArr;
    // }

    // //Educational Details Insert..
    // public function EmpEducationalDetailsInsert($empID, $PostRec)
    // {
    //     $InsertArr = array(
    //         "user_id" => $empID,
    //         "educationlevel" => $PostRec['educationlevel'],
    //         "course" => $PostRec['course'],
    //         "coursetype_id" => $PostRec['coursetype_id'],
    //         "institution_name" => $PostRec['institution_name'],
    //         "from_date" => date("Y-m-d", strtotime($PostRec['from_date'])),
    //         "to_date" => date("Y-m-d", strtotime($PostRec['to_date'])),
    //         "board_university" => $PostRec['board_university'],
    //         "marks_obtained" => $PostRec['marks_obtained'],
    //         "stream" => $PostRec['stream'],
    //         "percentage" => $PostRec['percentage'],
    //         "spc_location" => $PostRec['spc_location'],
    //         "passing_year" => $PostRec['passing_year'],
    //         "specialization" => $PostRec['specialization'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "isactive" => "1",
    //         "createddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($InsertArr) ? $InsertArr : $InsertArr;
    // }

    // //Training and Certification Details..
    // public function EmpTrainingCertificationDetailsInsert($empID, $PostRec)
    // {
    //     $InsertArr = array(
    //         "user_id" => $empID,
    //         "course_name" => $PostRec['course_name'],
    //         "description" => $PostRec['description'],
    //         "course_level" => $PostRec['course_level'],
    //         "course_offered_by" => $PostRec['course_offered_by'],
    //         "issued_date" => date("Y-m-d", strtotime($PostRec['issued_date'])),
    //         "certification_name" => $PostRec['certification_name'],
    //         "marks_obtained" => $PostRec['marks_obtained'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "isactive" => "1",
    //         "createddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($InsertArr) ? $InsertArr : $InsertArr;
    // }

    // //Dependancy or family details insert..
    // public function EmpDependencyFamilyDetailsInsert($empID, $PostRec)
    // {
    //     $InsertArr = array(
    //         "user_id" => $empID,
    //         "dependent_name" => $PostRec['dependent_name'],
    //         "dependent_relation" => $PostRec['dependent_relation'],
    //         "aadhar_no" => $PostRec['aadhar_no'],
    //         "dependent_dob" => date("Y-m-d", strtotime($PostRec['dependent_dob'])),
    //         "dependent_select" => $PostRec['dependent_select'],
    //         "createdby" => $this->session->userdata('loginid'),
    //         "createddate" => date("Y-m-d h:i:s")
    //     );
    //     return ($InsertArr) ? $InsertArr : $InsertArr;
    // }

    // //Send mail fo
    // public function send_welcome_mail_to_new_emp()
    // {
    //     $fname = $_REQUEST['fname'];
    //     $mname = $_REQUEST['mname'];
    //     $lname = $_REQUEST['lname'];
    //     $userID = $_REQUEST['userID'];
    //     $userFullname = $fname . " " . $mname . " " . $lname;
    //     $userDetail = get_ro_full_details_by_Id($userID);
    //     // echo json_encode($userDetail); die;
    //     $password = rand() . time();
    //     $newPass = md5($password);
    //     $passUpdate = updateRecUsingUserID($userID, $newPass);
    //     if ($_REQUEST['prefix_id']) {
    //         $prefix = $_REQUEST['prefix_id'];
    //         $subject = "Welcome To CEG " . $prefix . " " . $userFullname;
    //     } else {
    //         $prefix = "";
    //         $subject = "Welcome To CEG " . $prefix . " " . $userFullname;
    //     }
    //     $msgDetails = $this->load->view('email/welcome_mail_view', compact('userDetail', 'password'), true);
    //     // $msgDetails = $this->load->view('email/birthday_mail_by_mdSir', compact('userDetail'), true);
    //     // echo $msgDetails; die;
    //     $to = $userDetail->emailaddress;
    //     // $to = "gkumar871@gmail.com";
    //     // $to = "gmhr@cegindia.com";
    //     // $msgDetail = "Testing";
    //     // $resp = false;
    //     if ($passUpdate) {
    //         $resp = send_welcomeMail($to, $subject, $msgDetails);
    //     }
    //     if ($resp) {
    //         $msg = 1;
    //     } else {
    //         $msg = 2;
    //     }
    //     echo json_encode($msg);
    // }
    // public function not_intables()
    // {

    //     $this->db->select('emp.user_id as empuserid,emp.id as emp_id,users.user_id as userid,users.date_of_joining as date_of_joinings,users.reporting_manager as reporting_managers,users.emp_status_id as emp_status_ids,users.businessunit_id as businessunit_ids,users.department_id as department_ids,users.jobtitle_id as jobtitle_ids,users.position_id as position_ids,users.years_exp as years_exps,users.prefix_id as prefix_ids,users.extension_number as extension_numbers,users.createdby as createdbys,users.modifiedby asmodifiedbys,users.createddate as createddates,users.modifieddate as modifieddates,users.isactive as isactives');
    //     $this->db->from('main_employees_summary as users');
    //     $this->db->join('main_employees as emp', 'emp.user_id = users.user_id', 'LEFT');

    //     $this->db->where('emp.user_id', null);
    //     $data = $this->db->get()->result();
    //     // $this->db->insert('main_employees', $data);
    //     // $insert = array();
    //     foreach ($data as $result) {
    //         $inserto = array(
    //             'user_id' => $result->userid,
    //             'date_of_joining' => $result->date_of_joinings,
    //             'reporting_manager' => $result->reporting_managers,
    //             'emp_status_id' => $result->emp_status_ids,
    //             'businessunit_id' => $result->businessunit_ids,
    //             'department_id' => $result->department_ids,
    //             'jobtitle_id' => $result->jobtitle_ids,
    //             'position_id' => $result->position_ids,
    //             'years_exp' => $result->years_exps,
    //             'prefix_id' => $result->prefix_ids,
    //             'extension_number' => $result->extension_numbers,
    //             'createdby' => $result->createdbys,
    //             'modifiedby' => $result->modifiedbys,
    //             'createddate' => $result->createddates,
    //             'modifieddate' => $result->modifieddates,
    //             'isactive' => $result->isactives

    //         );
    //         echo "<pre>";
    //         print_r($inserto);
    //         //$this->db->insert('main_employees_abhi', $inserto);
    //         // foreach ($insert as $ins) {

    //         // }
    //     }

    //     // foreach ($insert as $inser) {
    //     //     $this->db->insert('main_employees', $inser);
    //     // }
    //     // echo "<pre>";
    //     // print_r($insert);
    //     //  print_r($data);
    // }
    // public function insertdata()
    // {

    //     $this->db->select('users.user_id as userid,users.date_of_joining as date_of_joinings,users.reporting_manager as reporting_managers,users.emp_status_id as emp_status_ids,users.businessunit_id as businessunit_ids,users.department_id as department_ids,users.jobtitle_id as jobtitle_ids,users.position_id as position_ids,users.years_exp as years_exps,users.prefix_id as prefix_ids,users.extension_number as extension_numbers,users.createdby as createdbys,users.modifiedby asmodifiedbys,users.createddate as createddates,users.modifieddate as modifieddates,users.isactive as isactives');
    //     $this->db->from('main_employees_abhi as users');
    //     // $this->db->join('main_employees as emp', 'emp.user_id = users.user_id', 'LEFT');

    //     // $this->db->where('emp.user_id', null);
    //     $data = $this->db->get()->result();
    //     // $this->db->insert('main_employees', $data);
    //     // $insert = array();
    //     foreach ($data as $result) {
    //         $inserto = array(
    //             'user_id' => $result->userid,
    //             'date_of_joining' => $result->date_of_joinings,
    //             'reporting_manager' => $result->reporting_managers,
    //             'emp_status_id' => $result->emp_status_ids,
    //             'businessunit_id' => $result->businessunit_ids,
    //             'department_id' => $result->department_ids,
    //             'jobtitle_id' => $result->jobtitle_ids,
    //             'position_id' => $result->position_ids,
    //             'years_exp' => $result->years_exps,
    //             'prefix_id' => $result->prefix_ids,
    //             'extension_number' => $result->extension_numbers,
    //             'createdby' => $result->createdbys,
    //             'modifiedby' => $result->modifiedbys,
    //             'createddate' => $result->createddates,
    //             'modifieddate' => $result->modifieddates,
    //             'isactive' => $result->isactives
    //         );
    //         echo "<pre>";
    //         print_r($inserto);
    //         //$this->db->insert('main_employees', $inserto);
    //         // foreach ($insert as $ins) {

    //         // }
    //     }

    //     // foreach ($insert as $inser) {
    //     //     $this->db->insert('main_employees', $inser);
    //     // }
    //     // echo "<pre>";
    //     // print_r($insert);
    //     //  print_r($data);
    // }
}
