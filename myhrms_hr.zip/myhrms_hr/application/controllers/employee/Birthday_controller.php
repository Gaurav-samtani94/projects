<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Birthday_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Employee/Todaybirthday_model', 'Todaybirthday_model');
        $this->load->library('form_validation');
        $this->load->helper('security');

        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }

    public function Birthday_wish()
    {
        $data['title'] = 'Today Employee Birthday';
        $data['todaybirthday'] = $this->Todaybirthday_model->Gettodaybirthday();
        $this->load->view('employee/birthday_view', $data);
    }


    public function requestmail() // abhimanyu
    {
        $data['dataemailpta'] = $this->Todaybirthday_model->getEmployeeemaildata();
        $UserDetails = $this->Todaybirthday_model->getEmployeeemail();
        $to = ("abhishekbca6393@gmail.com");
        $subject = "Happy Birthday";
  	    $oldpath = 'public/uploads/birthdaywish';
        $a = scandir($oldpath);        
        unset($a[0]);
        unset($a[1]);
        $i = array_rand($a);
        $Birthday_image_name = $a[$i];
        
        $colors =["D8E2DC","eae8ff","e9f1f7","fae3e3","F4EBBE","77B6EA","efcfe3","ffb7c3","a7bed3","7161ef"];
        $i = array_rand($colors);
        $bg_color = $colors[$i];
        // print_r($bg_color);
        // die;
        $data['Birthday_image_name'] = $Birthday_image_name;
        $data['bg_color'] = $bg_color;
        $msgDetails2 = $this->load->view('email/birthdaywishemail_view', $data,true);
        // print_r($msgDetails2);
        // die;
        $this->sendMail($to, $subject, $msgDetails2);
        $this->session->set_flashdata('success_mail', 'Mail  Send successfully');
        redirect(base_url('Birthday_wish'));
    }



    // public function requestmail() // abhimanyu
    // {


    //     $data['dataemailpta'] = $this->Todaybirthday_model->getEmployeeemaildata();


    //     $UserDetails = $this->Todaybirthday_model->getEmployeeemail();

     
    //     // $data['name'] = $UserDetails;
    //     // $to = $UserDetails->emailaddress;
    //     $to = ("abhishekbca6393@gmail.com");

    //     $subject = "Happy Birthday";
  	//     $oldpath = 'public/uploads/birthdaywish';
    //     $a = scandir($oldpath);

    //     unset($a[0]);
    //     unset($a[1]);
    //     $i = array_rand($a);
    //     $Birthday_image_name = $a[$i];
    //     $data['Birthday_image_name'] = $Birthday_image_name;



    //     $msgDetails2 = $this->load->view('email/birthdaywishemail_view', $data,true);

    //     $this->sendMail($to, $subject, $msgDetails2);



    //     $this->session->set_flashdata('success_mail', 'Mail  Send successfully');
    //     redirect(base_url('Birthday_wish'));
    // }

    function sendMail($to, $subject, $msgDetails)
    {
	    $CI = &get_instance();
        $CI->load->library('email');
        $CI->email->initialize(array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        ));
        $CI->email->from('marketing@cegindia.com','CEG-INDIA');//hrms.admin@cegindia.com
        $CI->email->to('cegapps@cegindia.com');
        // $CI->email->bcc('cegapps@cegindia.com');
        $CI->email->subject($subject);
        $CI->email->message($msgDetails);
        $resp = $CI->email->send();
        return ($resp) ? $resp : $CI->email->print_debugger();
    }

    // function sendMail($to, $subject, $msgDetails)
    // {
	//     $CI = &get_instance();
    //     $CI->load->library('email');
    //     $CI->email->initialize(array(
    //         'protocol' => 'smtp',
    //         'smtp_host' => 'mail.cegindia.com',
    //         'smtp_user' => 'marketing@cegindia.com',
    //         'smtp_pass' => 'MARK-2015ceg',
    //         'smtp_port' => 587,
    //         'crlf' => "\r\n",
    //         'newline' => "\r\n",
    //         'mailtype' => 'html',
    //         'charset' => 'iso-8859-1',
    //         'wordwrap' => TRUE
    //     ));
    //     $CI->email->from('marketing@cegindia.com','CEG-INDIA');//hrms.admin@cegindia.com
    //     $CI->email->to('manojwebdesigner476@gmail.com');
    //     $CI->email->bcc('cegapps@cegindia.com');

    //     $CI->email->subject($subject);
    //     $CI->email->message($msgDetails);

    //     $resp = $CI->email->send();


    //     return ($resp) ? $resp : $CI->email->print_debugger();
    // }
}
