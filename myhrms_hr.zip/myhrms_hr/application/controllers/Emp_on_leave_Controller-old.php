<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Emp_on_leave_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Emp_on_leave_tour_report_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function emp_On_leave() {
        // echo "test"; die;
        $abc = $this->countemponfloor('7', '12');
        // echo "<pre>"; print_r($abc); die;
        $presentEmpTour = $this->Emp_on_leave_tour_report_model->tour_atten_report_ceg();
        $presentEmpLeave = $this->Emp_on_leave_tour_report_model->leave_atten_report_ceg1();

        // echo "<pre>"; print_r($presentEmpLeave); die;
        $today = date("Y-m-d");
        $data['title'] = "Employees On leave";
        $data['presentEmpTour'] = $presentEmpTour;
        $data['presentEmpLeave'] = $presentEmpLeave;

        $this->load->view("emp_on_leave/emp_on_leave_view", $data);
    }

    public function ajax_emp_floor_report_data() {
        $list = array("-1" => "-1", "0" => "0", "1" => "1", "2" => "2", "3" => "3", "4" => "4", "5" => "5", "6" => "6", "7" => "7");
        $data = array();
        $no = $_POST['start'];
        $recData = array();
        $rowTotal = 0;
        $rowTotal2 = 0;
        $colTotal1 = 0;
        $colTotal2 = 0;
        $colTotal3 = 0;
        $colTotal4 = 0;
        $colTotal5 = 0;
        $colTotal6 = 0;
        $colTotal7 = 0;
        foreach ($list as $kkeY => $rOws) {
            $no++;
            $GroupNumA = $this->countemponfloor($kkeY, "8");
            $GroupNumB = $this->countemponfloor($kkeY, "9");
            $GroupNumC = $this->countemponfloor($kkeY, "10");
            $GroupNumD = $this->countemponfloor($kkeY, "11");
            $GroupNumE = $this->countemponfloor($kkeY, "12");
            $GroupNumF = $this->countemponfloor($kkeY, "13");
            $rowTotal = $GroupNumA + $GroupNumB + $GroupNumC + $GroupNumD + $GroupNumE + $GroupNumF;

            $row = array();
            $row[] = $no;
            $row[] = $rOws;
            $row[] = $GroupNumA;
            $row[] = $GroupNumB;
            $row[] = $GroupNumC;
            $row[] = $GroupNumD;
            $row[] = $GroupNumE;
            $row[] = $GroupNumF;
            $row[] = '<b>' . $rowTotal . '</b>';
            $data[] = $row;
        }
        // foreach ($list as $kkeY => $rOws) {
        // $no++;
        // $GroupNumA = $this->countemponfloor($kkeY, "8");
        // $GroupNumB = $this->countemponfloor($kkeY, "9");
        // $GroupNumC = $this->countemponfloor($kkeY, "10");
        // $GroupNumD = $this->countemponfloor($kkeY, "11");
        // $GroupNumE = $this->countemponfloor($kkeY, "12");
        // $GroupNumF = $this->countemponfloor($kkeY, "13");
        // $rowTotal2 = $GroupNumA+$GroupNumB+$GroupNumC+$GroupNumD+$GroupNumE+$GroupNumF; 
        // $colTotal1 += $GroupNumA; 
        // $colTotal2 += $GroupNumB; 
        // $colTotal3 += $GroupNumC; 
        // $colTotal4 += $GroupNumD; 
        // $colTotal5 += $GroupNumE; 
        // $colTotal6 += $GroupNumF; 
        // $colTotal7 += $rowTotal2; 
        // }
        // $row = array();
        // $row[] = '8';
        // $row[] = '-';
        // $row[] = "<b>".$colTotal1."</b>";
        // $row[] = "<b>".$colTotal2."</b>";
        // $row[] = "<b>".$colTotal3."</b>";
        // $row[] = "<b>".$colTotal4."</b>";
        // $row[] = "<b>".$colTotal5."</b>";
        // $row[] = "<b>".$colTotal6."</b>";
        // $row[] = "<b>".$colTotal7."</b>";
        // $data[] = $row;
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => count($list),
            "recordsFiltered" => count($list),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function countemponfloor($floorId, $groupID) {
        $today = date("Y-m-d");
        $this->db->select("c.*");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
        $this->db->where(array("a.isactive" => "1", "b.status" => "1", "b.floor_number" => $floorId, "a.jobtitle_id" => $groupID));
        $this->db->where("c.LogDate LIKE '%$today%'");
        // $this->db->where("c.LogDate LIKE %2020-01-24%");
        $this->db->where("c.Direction", "in");
        $this->db->order_by("c.DeviceLogId", "ASC");
        $this->db->group_by("c.UserId");
        // $recArr = $this->db->Get()->result();
        // $this->db->select("c.UserId");
        // $this->db->from("main_employees_summary as a");
        // $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        // $this->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
        // $this->db->where(array("a.isactive" => "1", "b.status" => "1", "b.floor_number" => $floorId, "a.jobtitle_id" => $groupID));
        // $this->db->where(array("c.DeviceId" => "1", "c.Direction" => "out"));
        // $this->db->where("c.LogDate LIKE '%$today%'");
        // $this->db->group_by("c.UserId");
        // $recArr = $this->db->get()->result();
        $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }

}
