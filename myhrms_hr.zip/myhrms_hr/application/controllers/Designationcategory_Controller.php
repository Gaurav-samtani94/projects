<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Designationcategory_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');

        $this->load->database();
        $this->db1 = $this->load->database('default', true);
        $this->db2 = $this->load->database('online', true);

        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
            
        } else {
            redirect(base_url(""));
        }
    }

    //Designation Category Master Home Page ...
    public function homepage() {
        $data['error'] = '';
        $data['DesignationCategoryHrmsArr'] = $this->db->where(["bd_hrms" => "1", "status" => "1"])->get("designation_category_hrmsbd")->result();
        $data['DesignationCategoryBdArr'] = $this->db->where(["bd_hrms" => "2", "status" => "1"])->get("designation_category_hrmsbd")->result();
        $data['title'] = "Designation Category Master";
        $this->load->view("designationcateg_master/designation_category_master_view", $data);
    }

    //Designation Category..
    public function save_designation_category() {
        $designation_categ = $this->input->post("designation_categ");
        $bd_hrms = $this->input->post("bd_hrms");
        $query = $this->db->where(["designation_categ" => $designation_categ, "bd_hrms" => $bd_hrms, "status" => "1"])->get("designation_category_hrmsbd");
        if ($query->num_rows() < 1) {
            $insertArr = array("designation_categ" => $designation_categ, "bd_hrms" => $bd_hrms, "entry_by" => $this->session->userdata('loginid'));
            if ($insertArr) {
                $this->db->insert("designation_category_hrmsbd", $insertArr);
                if ($this->db->insert_id()):
                    $this->session->set_flashdata('success_msg', 'Designation Category Added Successfully.');
                endif;
            }
        } else {
            $this->session->set_flashdata('error_msg', 'Designation Category Already Exists.');
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    //Get All Designation Category By Group HRMS or BD
    public function set_designationcateg_bydesgroup_ajax() {
        $groupId = $_REQUEST['designgroupid'];
        $DesigCategoryArr = $this->db->where(["bd_hrms" => $groupId, "status" => "1"])->get("designation_category_hrmsbd")->result();
        echo json_encode($DesigCategoryArr);
    }

    //Get All Designation By Group HRMS or BD..
    public function set_designation_bycategory_ajax() {
        $groupId = $_REQUEST['designgroupid'];
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;

        if ($groupId == "1") {
            $DesignationRecArr = $this->db->where(["isactive" => "1"])->get("main_positions")->result();
        }
        if ($groupId == "2") {
            $this->db2->select("$db2.designation_master_requisition.fld_id as id,$db2.designation_master_requisition.designation_name as positionname");
            $this->db2->from("$db2.designation_master_requisition");
            $this->db2->where("$db2.designation_master_requisition.is_active", "1");
            $this->db2->group_by("$db2.designation_master_requisition.designation_name");
            $DesignationRecArr = $this->db2->get()->result();
        }
        echo json_encode($DesignationRecArr);
    }

    //Save Update Designation On Desig Category,,,,
    public function saveupd_assign_designation_oncategory() {
        $category_group = $this->input->post("category_group");
        $DesignationCategory = $this->input->post("DesignationCategory");
        $designation_rec = $this->input->post("designation_rec");

        if (($category_group) and ( $DesignationCategory) and ( count($designation_rec) > 0)) {
            foreach ($designation_rec as $KeYy => $roWs) {
                $insertArr = ["desig_categ_group" => $category_group, "designation_categoryid" => $DesignationCategory, "designation_id" => $roWs, "entry_by" => $this->session->userdata('loginid')];

                $numRows = $this->db->where(["desig_categ_group" => $category_group, "designation_id" => $roWs, "status" => "1"])->get("assign_designation_category")->num_rows();
                if ($numRows < 1) {
                    $this->db->insert("assign_designation_category", $insertArr);
                    $this->session->set_flashdata('success_msg', 'Designation Update/Added Successfully.');
                }
            }
        } else {
            $this->session->set_flashdata('error_msg', 'something went wrong.');
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    //Display Designataion By Designation Categ ID..
    public function display_designation_bycategoryid_ajax() {
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        // $designgcatid = $_REQUEST['designgcatid'];
        //$groupcid = $_REQUEST['groupcid'];

        $designgcatid = '16';
        $groupcid = '2';

        if (($designgcatid) and ( $groupcid == "1")) {
            $this->db->select("$db1.main_positions.positionname");
            $this->db->from("$db1.assign_designation_category");
            $this->db->join("$db1.main_positions", "$db1.assign_designation_category.designation_id=$db1.main_positions.id", "LEFT");
            $this->db->where(["$db1.assign_designation_category.status" => "1", "$db1.assign_designation_category.designation_categoryid" => $designgcatid]);
            $this->db->order_by("$db1.main_positions.positionname", "ASC");
            $DesignationRecArr = $this->db->get()->result();
        }


        if (($designgcatid) and ( $groupcid == "2")) {
            $this->db->select("assign_designation_category.designation_id");
            $this->db->from("assign_designation_category");
            $this->db->where("assign_designation_category.designation_categoryid", $designgcatid);
            $DesignationArr = $this->db->get()->result();
            $desigArr = array();
            if ($DesignationArr) {
                foreach ($DesignationArr as $rOWs) {
                    $desigArr[] = $rOWs->designation_id;
                }
            }
            $this->db2->select("$db2.designation_master_requisition.designation_name as positionname");
            $this->db2->from("$db2.designation_master_requisition");
            $this->db2->where_in("$db2.designation_master_requisition.fld_id", $desigArr);
            $DesignationRecArr = $this->db2->get()->result();
        }

        if (@$DesignationRecArr) {
            foreach (@$DesignationRecArr as $kk => $roWs) {
                echo "<li>" . @$roWs->positionname . "</li>";
            }
        }
    }

}
