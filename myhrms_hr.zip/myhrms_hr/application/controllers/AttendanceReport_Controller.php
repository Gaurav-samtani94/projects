<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class AttendanceReport_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // $this->load->model('mastermodel');
        $this->load->model('AttenReport_model');
        $this->load->model('AttenReport_cegth_model');
        $this->load->model('Absent_List_Report_Model');
        $this->load->model('AttenReport_cegproject_model');
        // $this->load->library('form_validation');
    }

    public function absentList() {
        // echo "test"; die;
        // $empDetail = getEmpDetailByMachineID();
        $data['list'] = $this->Absent_List_Report_Model->get_datatables();
        // echo "dd<pre>"; print_r(count($data['list'])); die;
        $data['title'] = "Absent List";
        $this->load->view('absent_list/asbsent_list_view', $data);
    }

    public function sendSMStoAbsentEmployees() {
        $list = $this->Absent_List_Report_Model->get_datatables();
        // echo "<pre>"; print_r($list); die;
        $keyOfficials = array('173', '190', '175', '2', '1317');
        $itDpt = array('296', '2109', '297', '2438', '2173');
        $curDate = date('Y-m-d');
        // $curDate = date('2021-03-28');
        foreach ($list as $value) {
            if (in_array($value->user_id, $keyOfficials)) {
                
            }
            // if(in_array($value,$keyOfficials)){}
            else {
                $woChk = date("D", strtotime($curDate));
                if (($woChk == "Sat") || ($woChk == "Sun")) {
                    
                } else {
                    $tourChk = TourCheckOfEmployeeBetween($value->user_id, $curDate);
                    $leaveChk = LeaveCheckOfEmployeeBetween($value->user_id, $curDate);
                    if (($tourChk) || ($leaveChk)) {
                        
                    } else {
                        $usrRcd = get_ro_full_details_by_Id($value->user_id);
                        // echo $usrRcd->userfullname."<br>"; 
                        $content = "Dear " . $usrRcd->userfullname . ",\n";
                        $content .= "MISSED PUNCH of attendance reported today. Get it regularised within next 72 hours/3 days to avoid loss of pay. \n";
                        $content .= "URL : https://bit.ly/3eot16m";
                        $smscontent = urlencode($content);
                        $mob = "7411579453";
                        // $mob = $usrRcd->contactnumber;
                        $respon = file_get_contents("http://alerts.prioritysms.com/api/web2sms.php?workingkey=Ab5ee72734a45936f490c955c9e1215db&to=" . $mob . "&sender=CEGLTD&message=" . $smscontent);
                    }
                }
            }
        }
        // die;
        if ($respon):
            echo "Done";
        else:
            echo "Not Done";
        endif;
    }

    public function cegProjectAtten() {
        $data['title'] = 'Ceg Project Attendance Report';
        // $res = $this->AttenReport_cegproject_model->get_datatables();
        // echo "testing"; die;
        // echo "<pre>"; print_r($res); die;
        $this->load->view('monthly_atten_report/cegProject_atten_report_view', $data);
    }

    public function ajax_listattendance_cegProject() {
        $list = $this->AttenReport_cegproject_model->get_datatables();
        // echo "<pre>"; print_r($list); die;

        $data = array();
        $no = $_POST['start'];
        foreach ($list as $key => $val) {
            $no++;
            $row = array();
            $row[] = $no;
            // $row[] = $val['employeeId'];
            $row[] = $val['employeeId'];
            $row[] = $val['userfullname'];
            $row[] = $val['project_name'];
            $row[] = $val['jobtitle_name'];
            for ($i = 1; $i <= 30; $i++) {
                if (date('D', strtotime($val['year'] . '-' . $val['month'] . '-' . $i)) == 'Sun') {
                    $row[] = ($val[$i]) ? strtoupper($val[$i]) : "<span style='color:green'>WO</span>";
                } elseif ((date('Y-m-d', strtotime($val['year'] . '-' . $val['month'] . '-' . $i))) > (date('Y-m-d'))) {
                    $row[] = "<span style='color:green'>--</span>";
                } else {
                    $row[] = ($val[$i]) ? strtoupper($val[$i]) : "<span style='color:red'>A</span>";
                }
            }
            // $row[] = ($val['2'])?$val['2']:"<span style='color:red'>A</span>";
            // $row[] = ($val['3'])?$val['3']:"<span style='color:red'>A</span>";
            // $row[] = ($val['4'])?$val['4']:"<span style='color:red'>A</span>";
            // $row[] = ($val['5'])?$val['5']:"<span style='color:red'>A</span>";
            // $row[] = ($val['6'])?$val['6']:"<span style='color:red'>A</span>";
            // $row[] = ($val['7'])?$val['7']:"<span style='color:red'>A</span>";
            // $row[] = ($val['8'])?$val['8']:"<span style='color:red'>A</span>";
            // $row[] = ($val['9'])?$val['9']:"<span style='color:red'>A</span>";
            // $row[] = ($val['10'])?$val['10']:"<span style='color:red'>A</span>";
            // $row[] = ($val['11'])?$val['11']:"<span style='color:red'>A</span>";
            // $row[] = ($val['12'])?$val['12']:"<span style='color:red'>A</span>";
            // $row[] = ($val['13'])?$val['13']:"<span style='color:red'>A</span>";
            // $row[] = ($val['14'])?$val['14']:"<span style='color:red'>A</span>";
            // $row[] = ($val['15'])?$val['15']:"<span style='color:red'>A</span>";
            // $row[] = ($val['16'])?$val['16']:"<span style='color:red'>A</span>";
            // $row[] = ($val['17'])?$val['17']:"<span style='color:red'>A</span>";
            // $row[] = ($val['18'])?$val['19']:"<span style='color:red'>A</span>";
            // $row[] = ($val['20'])?$val['20']:"<span style='color:red'>A</span>";
            // $row[] = ($val['21'])?$val['21']:"<span style='color:red'>A</span>";
            // $row[] = ($val['22'])?$val['22']:"<span style='color:red'>A</span>";
            // $row[] = ($val['23'])?$val['23']:"<span style='color:red'>A</span>";
            // $row[] = ($val['24'])?$val['24']:"<span style='color:red'>A</span>";
            // $row[] = ($val['25'])?$val['25']:"<span style='color:red'>A</span>";
            // $row[] = ($val['26'])?$val['26']:"<span style='color:red'>A</span>";
            // $row[] = ($val['27'])?$val['27']:"<span style='color:red'>A</span>";
            // $row[] = ($val['28'])?$val['28']:"<span style='color:red'>A</span>";
            // $row[] = ($val['29'])?$val['29']:"<span style='color:red'>A</span>";
            // $row[] = ($val['30'])?$val['30']:"<span style='color:red'>A</span>";
            // $row[] = ($val['31'])?$val['31']:"<span style='color:red'>A</span>";

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->AttenReport_cegproject_model->count_all(),
            "recordsFiltered" => $this->AttenReport_cegproject_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function ajax_list_monthly_attendance_ceg() {
        $list = $this->AttenReport_model->get_datatables();
        // echo "<pre>"; print_r($list); die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($value->employeeId) ? $value->employeeId : "";
            $row[] = ($value->userfullname) ? $value->userfullname : "";
            $row[] = ($value->city_name) ? $value->city_name : "";
            $row[] = ($value->department_name) ? $value->department_name : "";
            $row[] = ($value->jobtitle_name) ? $value->jobtitle_name : "";

            $totalArr = array();
            $TotalLateCount = '';
            $countql = '';
            $countthd = '';
            $countleave = '';
            $counthdleave = '';
            $countsleave = '';
            $countwoleave = '';
            $countwfhleave = '';
            $counttleave = '';
            $counthleave = '';
            $countrhleave = '';
            $countpleave = '';
            $countaleave = '';
            $qlprint = '';
            $qlprint1 = '';
            $lqlprint = '';
            $countlql = '';
            $countlql1 = '';
            $lqlprint1 = '';
            $lqlprint2 = '';
            $countlql2 = '';
            $countlhd = '';
            $lhdprint = '';

            for ($i = 1; $i <= 31; $i++) {
                $dateComb = str_pad($i, 2, "0", STR_PAD_LEFT) . "-" . str_pad('3', 2, "0", STR_PAD_LEFT) . "-" . '2021';
                $intimedata = $this->GetIntimeData($value->machine_id, $dateComb);
                $CheckCond = $this->CheckAllCond($i, $dateComb, $value->user_id);
                // echo "<pre>"; print_r($CheckCond); die;
                if ($CheckCond) {

                    if ($CheckCond == 'L'):
                        $printleave = '1';
                        $countleave += $printleave;
                        $CheckCondNew = "<span style='color:red'>L</span>";
                    endif;
                    if ($CheckCond == 'HDL'):
                        $printhdleave = '1';
                        $counthdleave += $printhdleave;
                        $CheckCondNew = "<span style='color:#49c5b6'>HDL</span>";
                    endif;
                    if ($CheckCond == 'SL'):
                        $printsleave = '1';
                        $countsleave += $printsleave;
                        $CheckCondNew = "<span style='color:blue'>SL</span>";
                    endif;
                    if ($CheckCond == 'WO'):
                        $printwoleave = '1';
                        $countwoleave += $printwoleave;
                        $CheckCondNew = "<span style='color:green'>WO</span>";
                    endif;
                    if ($CheckCond == 'WFH'):
                        $printwfhleave = '1';
                        $countwfhleave += $printwfhleave;
                        $CheckCondNew = "<span style='color:grey'>WFH</span>";
                    endif;
                    if ($CheckCond == 'T'):
                        $printtleave = '1';
                        $counttleave += $printtleave;
                        $CheckCondNew = "<span style='color:light-blue'>T</span>";
                    endif;
                    if ($CheckCond == 'H'):
                        $printhleave = '1';
                        $counthleave += $printhleave;
                        $CheckCondNew = "<span style='color:orange'>H</span>";
                    endif;
                    if ($CheckCond == 'RH'):
                        $printrhleave = '1';
                        $countrhleave += $printrhleave;
                        $CheckCondNew = "<span style='color:green'>RH</span>";
                    endif;
                    $row[] = $CheckCondNew;
                    // $row[] = '';				 
                    //InTime Condition
                }elseif (!empty($intimedata->user_id)) {
                    $late = ($intimedata->LateBy) ? ($intimedata->LateBy) : "";
                    $early = ($intimedata->EarlyBy) ? ($intimedata->EarlyBy) : "";
                    $mincount = ($late + $early);

                    //Late Minutes Condition.......
                    if ($mincount) {

                        //Quater Leave Condition.......
                        if (($mincount > 60) AND ( $mincount <= 135)) {
                            $qlprint1 = '1';
                            $qlprint = 'QL';
                            $countql += $qlprint1;
                            $row[] = '' . $qlprint . '';
                            // $row[] = '';
                            //Half Day Condition......
                        } elseif (($mincount > 135) AND ( $mincount < 270)) {
                            $hdprint1 = '1';
                            $hdprint = 'HD';
                            $countthd += $hdprint1;
                            $row[] = '' . $hdprint . '';
                            // $row[] = ''; 
                        } elseif (($mincount > 270)) {
                            $hdprint2 = '1';
                            $hdprint = 'HD';
                            $countthd += $hdprint2;
                            $row[] = '' . $hdprint . '';
                            // $row[] = ''; 
                            //Late Quater Leave Condition .........  
                        } elseif ($mincount < 60) {
                            $lqlprint = "<span style='color:brown'>LQL</span>";
                            $lhdprint = 'LHD';
                            $TotalLateCount += $mincount;

                            //Condtion for total Late Condition Grather Than 60........
                            if ($TotalLateCount > 60) {
                                $lqlprint2 = '1';
                                $countlql1 += $lqlprint2;

                                //if Late Quater leave is grather than 8 condition then Late Half Day Count......
                                if ($countlql1 > 8) {
                                    $lhdprint1 = '1';
                                    $countlhd += $lhdprint1;
                                    $row[] = '' . $lhdprint;
                                    // $row[] = '';
                                }

                                //if Late Quater leave is Less than 8 condition then Late Half Day Count........
                                else {
                                    $lqlprint1 = '1';
                                    $countlql += $lqlprint1;
                                    $row[] = '' . $lqlprint;
                                    // $row[] = '';  
                                }
                            } elseif (is_null($intimedata->OutTime) AND ! ($intimedata->Intime)) {
                                $row[] = 'MP';
                            }
                            //Condition for leass than 60 minutes minutes........
                            else {
                                $printp2 = '1';
                                $countpleave += $printp2;
                                $row[] = 'P';
                                // $row[] = '';
                            }
                        } elseif (is_null($intimedata->Intime)) {
                            $row[] = 'MP';
                            // $row[] = '';
                        } else {
                            $printa1 = '1';
                            $countaleave += $printa1;
                            $row[] = 'A';
                            // $row[] = '';
                        }
                    } elseif (is_null($intimedata->Intime)) {
                        $row[] = 'MP';
                        // $row[] = '';
                    } elseif (is_null($intimedata->OutTime)) {
                        $row[] = 'MP';
                        // $row[] = '';
                    }
                    //Condition for not late minutes........
                    else {
                        $printp1 = '1';
                        $countpleave += $printp1;
                        $row[] = 'P';
                        // $row[] = '';
                    }
                } else {
                    $printa2 = '1';
                    $countaleave += $printa2;
                    $row[] = '<span style="color:red">A</span>';
                    // $row[] = '';
                }
            }

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->AttenReport_model->count_all(),
            "recordsFiltered" => $this->AttenReport_model->count_filtered(),
            "data" => $data,
        );
        //output to json format...............
        echo json_encode($output);
    }

    public function ajax_list_monthly_attendance_cegth() {
        $list = $this->AttenReport_cegth_model->get_datatables();
        // echo "<pre>"; print_r($list); die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($value->employeeId) ? $value->employeeId : "";
            $row[] = ($value->userfullname) ? $value->userfullname : "";
            $row[] = ($value->city_name) ? $value->city_name : "";
            $row[] = ($value->department_name) ? $value->department_name : "";
            $row[] = ($value->jobtitle_name) ? $value->jobtitle_name : "";

            $totalArr = array();
            $TotalLateCount = '';
            $countql = '';
            $countthd = '';
            $countleave = '';
            $counthdleave = '';
            $countsleave = '';
            $countwoleave = '';
            $countwfhleave = '';
            $counttleave = '';
            $counthleave = '';
            $countrhleave = '';
            $countpleave = '';
            $countaleave = '';
            $qlprint = '';
            $qlprint1 = '';
            $lqlprint = '';
            $countlql = '';
            $countlql1 = '';
            $lqlprint1 = '';
            $lqlprint2 = '';
            $countlql2 = '';
            $countlhd = '';
            $lhdprint = '';

            for ($i = 1; $i <= 31; $i++) {
                $dateComb = str_pad($i, 2, "0", STR_PAD_LEFT) . "-" . str_pad('3', 2, "0", STR_PAD_LEFT) . "-" . '2021';
                $intimedata = $this->GetIntimeData($value->machine_id, $dateComb);
                $CheckCond = $this->CheckAllCond($i, $dateComb, $value->user_id);
                // echo "<pre>"; print_r($CheckCond); die;
                if ($CheckCond) {

                    if ($CheckCond == 'L'):
                        $printleave = '1';
                        $countleave += $printleave;
                        $CheckCondNew = "<span style='color:red'>L</span>";
                    endif;
                    if ($CheckCond == 'HDL'):
                        $printhdleave = '1';
                        $counthdleave += $printhdleave;
                        $CheckCondNew = "<span style='color:#49c5b6'>HDL</span>";
                    endif;
                    if ($CheckCond == 'SL'):
                        $printsleave = '1';
                        $countsleave += $printsleave;
                        $CheckCondNew = "<span style='color:blue'>SL</span>";
                    endif;
                    if ($CheckCond == 'WO'):
                        $printwoleave = '1';
                        $countwoleave += $printwoleave;
                        $CheckCondNew = "<span style='color:green'>WO</span>";
                    endif;
                    if ($CheckCond == 'WFH'):
                        $printwfhleave = '1';
                        $countwfhleave += $printwfhleave;
                        $CheckCondNew = "<span style='color:grey'>WFH</span>";
                    endif;
                    if ($CheckCond == 'T'):
                        $printtleave = '1';
                        $counttleave += $printtleave;
                        $CheckCondNew = "<span style='color:light-blue'>T</span>";
                    endif;
                    if ($CheckCond == 'H'):
                        $printhleave = '1';
                        $counthleave += $printhleave;
                        $CheckCondNew = "<span style='color:orange'>H</span>";
                    endif;
                    if ($CheckCond == 'RH'):
                        $printrhleave = '1';
                        $countrhleave += $printrhleave;
                        $CheckCondNew = "<span style='color:green'>RH</span>";
                    endif;
                    $row[] = $CheckCondNew;
                    // $row[] = '';				 
                    //InTime Condition
                }elseif (!empty($intimedata->user_id)) {
                    $late = ($intimedata->LateBy) ? ($intimedata->LateBy) : "";
                    $early = ($intimedata->EarlyBy) ? ($intimedata->EarlyBy) : "";
                    $mincount = ($late + $early);

                    //Late Minutes Condition.......
                    if ($mincount) {

                        //Quater Leave Condition.......
                        if (($mincount > 60) AND ( $mincount <= 135)) {
                            $qlprint1 = '1';
                            $qlprint = 'QL';
                            $countql += $qlprint1;
                            $row[] = '' . $qlprint . '';
                            // $row[] = '';
                            //Half Day Condition......
                        } elseif (($mincount > 135) AND ( $mincount < 270)) {
                            $hdprint1 = '1';
                            $hdprint = 'HD';
                            $countthd += $hdprint1;
                            $row[] = '' . $hdprint . '';
                            // $row[] = ''; 
                        } elseif (($mincount > 270)) {
                            $hdprint2 = '1';
                            $hdprint = 'HD';
                            $countthd += $hdprint2;
                            $row[] = '' . $hdprint . '';
                            // $row[] = ''; 
                            //Late Quater Leave Condition .........  
                        } elseif ($mincount < 60) {
                            $lqlprint = "<span style='color:brown'>LQL</span>";
                            $lhdprint = 'LHD';
                            $TotalLateCount += $mincount;

                            //Condtion for total Late Condition Grather Than 60........
                            if ($TotalLateCount > 60) {
                                $lqlprint2 = '1';
                                $countlql1 += $lqlprint2;

                                //if Late Quater leave is grather than 8 condition then Late Half Day Count......
                                if ($countlql1 > 8) {
                                    $lhdprint1 = '1';
                                    $countlhd += $lhdprint1;
                                    $row[] = '' . $lhdprint;
                                    // $row[] = '';
                                }

                                //if Late Quater leave is Less than 8 condition then Late Half Day Count........
                                else {
                                    $lqlprint1 = '1';
                                    $countlql += $lqlprint1;
                                    $row[] = '' . $lqlprint;
                                    // $row[] = '';  
                                }
                            } elseif (is_null($intimedata->OutTime) AND ! ($intimedata->Intime)) {
                                $row[] = 'MP';
                            }
                            //Condition for leass than 60 minutes minutes........
                            else {
                                $printp2 = '1';
                                $countpleave += $printp2;
                                $row[] = 'P';
                                // $row[] = '';
                            }
                        } elseif (is_null($intimedata->Intime)) {
                            $row[] = 'MP';
                            // $row[] = '';
                        } else {
                            $printa1 = '1';
                            $countaleave += $printa1;
                            $row[] = 'A';
                            // $row[] = '';
                        }
                    } elseif (is_null($intimedata->Intime)) {
                        $row[] = 'MP';
                        // $row[] = '';
                    } elseif (is_null($intimedata->OutTime)) {
                        $row[] = 'MP';
                        // $row[] = '';
                    }
                    //Condition for not late minutes........
                    else {
                        $printp1 = '1';
                        $countpleave += $printp1;
                        $row[] = 'P';
                        // $row[] = '';
                    }
                } else {
                    $printa2 = '1';
                    $countaleave += $printa2;
                    $row[] = '<span style="color:red">A</span>';
                    // $row[] = '';
                }
            }

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->AttenReport_cegth_model->count_all(),
            "recordsFiltered" => $this->AttenReport_cegth_model->count_filtered(),
            "data" => $data,
        );
        //output to json format...............
        echo json_encode($output);
    }

    public function GetIntimeData($UserId, $datacomb) {
        $date = date("Y-m-d", strtotime($datacomb));
        $this->db->select("a.machine_id,a.user_id,a.Intime,a.OutTime,a.LateBy,a.EarlyBy");
        $this->db->from("daily_attendance_oct_report as a");
        $this->db->where(array('a.machine_id' => $UserId, 'a.LogDate' => $date));
        $this->db->where('a.user_id IS NOT NULL', null, false);
        $RowArr = $this->db->get()->row();
        if ($RowArr) {
            return ($RowArr) ? $RowArr : "";
        }
    }

    //custom Code By Durgesh for check all Condition.....................
    public function CheckAllCond($recAtte, $actdate, $emp_id) {
        switch ($recAtte) {
            case ($recAtte != '0'):
                $firstReturn = date("Y-m-d", strtotime("first saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));
                $secondReturn = date("Y-m-d", strtotime("second saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));
                $thirdReturn = date("Y-m-d", strtotime("third saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));
                $fourthReturn = date("Y-m-d", strtotime("fourth saturday of " . date('M', strtotime($actdate)) . " " . date('Y', strtotime($actdate)) . ""));

                //For first saturday
//                if(date('Y-m-d', strtotime($actdate)) == $firstReturn) {
//                        return "WO";
//                }
//                
//                //For second saturday
//                if(date('Y-m-d', strtotime($actdate)) == $secondReturn) {
//                        return "WO";
//                }
//                
//                //For third saturday
//                if (date('Y-m-d', strtotime($actdate)) == $thirdReturn) {
//                        return "WO";
//                }
//                
//                //For fourth saturday
//                if(date('Y-m-d', strtotime($actdate)) == $fourthReturn) {
//                        return "WO";
//                }
                //For sunday
                if (date('D', strtotime($actdate)) == "Sat") {
                    return "WO";
                }

                //For sunday
                if (date('D', strtotime($actdate)) == "Sun") {
                    return "WO";
                }

                //Holidays Check..
                $holidResp = $this->isholidays(date('Y-m-d', strtotime($actdate)));
                if ($holidResp == 1) {
                    return "H";
                }

                //check Leave..
                $resp_leave = $this->emp_leaveexist($emp_id, date('Y-m-d', strtotime($actdate)));
                if ($resp_leave == 1) {
                    return "L";
                }
                //RH Holidays
                if ($resp_leave == 'RH') {
                    return "RH";
                }

                if ($resp_leave == 'HDL') {
                    return "HDL";
                }

                if ($resp_leave == 'SL') {
                    return "SL";
                }

                //Check Tour..
                $respoo = $this->tourexistondate($emp_id, date('Y-m-d', strtotime($actdate)));
                if ($respoo == 1) {
                    return "T";
                }

                //Check work from home
                $wfh = $this->WorkFromHome($emp_id, '3', '2021', date('Y-m-d', strtotime($actdate)));
                if ($wfh == 1) {
                    return "WFH";
                }

                return "";

                break;
            default:
                return "";
        }
    }

    //Check Exist Leave........................
    public function emp_leaveexist($userid, $tdate) {
        $reqleaveArr = $this->AttenReport_model->all_emp_leaves($userid);
        //$RecArr = array();
        if ($reqleaveArr):
            foreach ($reqleaveArr as $leavesrows):
                if ($leavesrows['leavestatus'] == 'Pending for approval' OR $leavesrows['leavestatus'] == 'Approved') {
                    $respoo = $this->AttenReport_model->check_in_range($leavesrows['from_date'], $leavesrows['to_date'], $tdate);
                    if ($respoo == 1) {

                        //Leave Type Restricted Holiday Apply....................
                        if ($leavesrows['leavetypeid'] == '5') {
                            return 'RH';
                            //$RecArr[] = 'RH';
                        }

                        //Leave Type Half Day Leave Apply And Leave day half......................
                        if (($leavesrows['leavetypeid'] == '3') AND ( $leavesrows['leaveday'] == '2')) {
                            /// $RecArr[] = 'HDL';
                            return 'HDL';
                        }

                        //Leave Type Sort  Leave Apply......................
                        if (($leavesrows['leavetypeid'] == '3') AND ( $leavesrows['leaveday'] == '3')) {
                            //$RecArr[] = 'SL';
                            return 'SL';
                        }

                        return 1;
                        //$RecArr[] = '1';
                    }
                }
            endforeach;
        endif;
        return false;
    }

    //Get Is Holiday on a Particular Date..
    public function isholidays($actDate) {
        $respon = $this->AttenReport_model->check_isholidays($actDate);
        return $respon;
    }

    //Check Tour Exist or Not a Particular Date ..
    public function tourexistondate($userid, $tdate) {
        $tourDates = $this->AttenReport_model->getallTourDates($userid);
        if ($tourDates):
            foreach ($tourDates as $tourcols):
                $respoo = $this->AttenReport_model->check_in_range($tourcols['start_date'], $tourcols['end_date'], $tdate);
                if ($respoo == 1) {
                    return 1;
                }
            endforeach;
        endif;
        return false;
    }

    //=========condition start for work from home============//
    public function WorkFromHome($emp_id, $month, $year, $actdate) {
        $this->db->select(array('*'));
        $this->db->from('roster_weekly_schedule');
        $this->db->where(array('user_id' => $emp_id, 'roster_month' => $month, 'roster_year' => $year, 'status' => '1'));
        $recArr = $this->db->get()->result();
        if ($recArr):
            foreach ($recArr as $wfhcols):

                switch ($actdate) {
                    case ($actdate):

                        //Monday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->mon_date))) AND $wfhcols->mon_action == 'WFH') {
                            return 1;
                        }

                        //Tuesday Date WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->tue_date))) AND $wfhcols->tue_action == 'WFH') {
                            return 1;
                        }

                        //Wednesday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->wed_date))) AND $wfhcols->wed_action == 'WFH') {
                            return 1;
                        }

                        //Thusday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->thu_date))) AND $wfhcols->thu_action == 'WFH') {
                            return 1;
                        }

                        //Friday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->fri_date))) AND $wfhcols->fri_action == 'WFH') {
                            return 1;
                        }

                        //Saturday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->sat_date))) AND $wfhcols->sat_action == 'WFH') {
                            return 1;
                        }

                        //Sunday Date  WFH Condition.................. 
                        if ((date('Y-m-d', strtotime($actdate)) == date('Y-m-d', strtotime($wfhcols->sun_date))) AND $wfhcols->sun_action == 'WFH') {
                            return 1;
                        }
                }

            endforeach;
        endif;
        return false;
    }

    //=========condition end for work from home============//
}
