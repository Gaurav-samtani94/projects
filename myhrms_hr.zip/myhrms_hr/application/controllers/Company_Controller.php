<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Company_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        // $this->load->model('Appraisal_new_model', 'appraisalmodel');
        // $this->load->model('Appraisal_cru_part_model', 'Appraisalcrupartmodel');
        // $this->load->model('Appraisal_acc_part_model', 'Appraisalaccpartmodel');
		 
        // $this->load->model('Edititrprofiledetail_model', 'eipm');
        // $this->load->model('Appraisal_model', 'appraisal');
        // $this->load->model('Appraisalio_model', 'appraisalio');
        // $this->load->model('Appraisalreporthr_model', 'appraisalreport');
        // $this->load->model('Appraisalreporthrcegth_model', 'appraisalreportcegth');
        // $this->load->model('Appraisalreportajax_model', 'appraisalreportajax');
        // $this->load->model('Appraisalreportajaxcegth_model', 'appraisalreportajaxcegth');

        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    ### Load view for Company Report ###
	public function companyreport(){
		$data['error'] = '';
		$data['title'] = 'Company Report';
		$data['getBusinessUnit'] = $this->mastermodel->getBusinessUnit();
		$data['getCompanyName'] = $this->mastermodel->getCompanyName();
		$this->load->view('company-report/company', $data);
		
	}

   ### Load view for Project Report ###
	public function companyProjectReport(){
		$data['error'] = '';
		$data['title'] = 'Company Project Report';
		$data['getBusinessUnit'] = $this->mastermodel->getBusinessUnit();
		$data['getCompanyName'] = $this->mastermodel->getCompanyName();
		// echo "<pre>";print_r($data); die;
		$this->load->view('company-report/company-project', $data);
		
	}
	
	### Load View for Employee Lsit ###
	
	
	public function employeeList(){
		$data['error'] = '';
		$data['title'] = 'Employee List';
		$data['empList'] = $this->mastermodel->getEmployeeList();
		$this->load->view('employee-list/employee', $data);
		
	}
	
	public function newAjaxCompanyData(){
		
		$business_id = $this->input->post('business_id');
		$company_id = $this->input->post('company_id');
		
		$companyGradea = [];
		$cegTha = [];
		$cegProjecta = [];
		$noBusinessUnit = []; 
		$data = [];

		if($business_id == 1 || $business_id == 100){
			$list = $this->mastermodel->getCompanyLocation("tbl_ofclocation");
			foreach ($list as $rec) {
				$location_id = $rec->id;
				$location_name = $rec->city_name;
				$companyGradea[] = $this->mastermodel->getCompanyGradeAjax($location_id, $business_id, $company_id);
			}			
		}
			
		if($business_id == 2 || $business_id == 100){	  
		$cegTha = $this->mastermodel->getCompanyGradeByIdAjax(2, $company_id);	
		}
		if($business_id == 3 || $business_id == 100){
		$cegProjecta = $this->mastermodel->getCompanyGradeByIdAjax(3, $company_id);
		}
		if($business_id == 0 || $business_id == 100){
		$noBusinessUnit = $this->mastermodel->getCompanyGradeByIdAjax(0, $company_id);
		}
		
		
		### Process Array Data for CEG ###
		if(is_array($companyGradea) || is_object($companyGradea)){
			$i = 0;
			foreach ($companyGradea as $key => $dat) {
			  
			// #### function to handle foreach data ###
			$data[] = $this->finalData($dat, 1);
		}
		}

		### Process Array Data for CEG TH ###
		if(is_array($cegTha) || is_object($cegTha)){
			$dat = $cegTha;
			// #### function to handle foreach data ###
			$data[] = $this->finalData($dat, 2);
		}


		### Process Array Data for CEG Project ###
		if(is_array($cegProjecta) || is_object($cegProjecta)){
		 $dat = $cegProjecta;
			// #### function to handle foreach data ###
			$data[] = $this->finalData($dat, 3);
		}

		### Process Array Data for No Business Unit ###
		if(is_array($noBusinessUnit) || is_object($noBusinessUnit)){
		$dat = $cegProjecta;
			// #### function to handle foreach data ###
			$data[] = $this->finalData($dat, 4);
		}

		$arrayFirstd = ['company'=>0,'a'=>0,'b'=>0,'c'=>0,'d'=>0,'e'=>0,'f'=>0,'g'=>0];
        $data[] = $arrayFirstd;
        
       
		  
		$results = [
               //"draw" => $_POST['draw'],
			"data" => $data,
			"recordsTotal" => count($data),
			"recordsFiltered" => count($data),
			];
		echo json_encode($results);
				
	}
	
	
	
	 
	
	
	public function ajaxCompanyData(){
		$data['error'] = '';
		$data['ajaxCompany'] = 'Company Report';
		
		$business_id = $this->input->post('business_id');
		$company_id = $this->input->post('company_id');
		
		$list = $this->mastermodel->getCompanyLocation("tbl_ofclocation");
		foreach ($list as $rec) {
			$location_id = $rec->id;
			$location_name = $rec->city_name;
			$data['companyGrade'][$location_name] = $this->mastermodel->getCompanyGradeAjax($location_id, $business_id, $company_id);
		}
		if($business_id == 2){
		$data['cegTh'] = $this->mastermodel->getCompanyGradeByIdAjax($business_id, $company_id);
		}
		if($business_id == 3){
		$data['cegProject'] = $this->mastermodel->getCompanyGradeByIdAjax($business_id, $company_id);
		}
		
		 
		
		
		$data['getBusinessUnit'] = $this->mastermodel->getBusinessUnit();
		$data['getCompanyName'] = $this->mastermodel->getCompanyName();


		$data1 = $this->load->view('company-report/ajaxcompanydata',$data, TRUE);
		
		//echo $data;
		 
        echo json_encode($data1);
		 
		
	}
	
	
	### Function to iterate foreach data for CEG , CEG TH , CEG Project ###
	public function finalData($dat, $companyStatus){
			
		$arrayFirsta = ['company'=>0,'a'=>0,'b'=>0,'c'=>0,'d'=>0,'e'=>0,'f'=>0,'g'=>0];
		if(is_array($dat) || is_object($dat)){
		foreach ($dat as $key => $dt){

		if($companyStatus == 1){
		$arrayFirsta['company'] = 'CEG '.$dt->cityName;
		}if($companyStatus == 2){
		$arrayFirsta['company'] = 'CEG TH';
		}if($companyStatus == 4){
		$arrayFirsta['company'] = 'No Business Unit';
		}if($companyStatus == 3){
		$arrayFirsta['company'] = 'CEG Project';
		}

		if($dt->Grade == 'A'){ 
		$arrayFirsta['a'] = ($dt->countGrade ? $dt->countGrade : '0');
		}
		if($dt->Grade == 'B'){ 
		$arrayFirsta['b'] = ($dt->countGrade ? $dt->countGrade : '0');
		}
		if($dt->Grade == 'C'){ 
		$arrayFirsta['c'] = ($dt->countGrade ? $dt->countGrade : '0');
		}
		if($dt->Grade == 'D'){ 
		$arrayFirsta['d'] = ($dt->countGrade ? $dt->countGrade : '0');
		}
		if($dt->Grade == 'E'){ 
		$arrayFirsta['e'] = ($dt->countGrade ? $dt->countGrade : '0');
		}
		if($dt->Grade == 'F'){ 
		$arrayFirsta['f'] = ($dt->countGrade ? $dt->countGrade : '0');
		}

		}

		if(count($arrayFirsta)){
		$arrayFirsta = array_merge($arrayFirsta);
		}
		}
		return $arrayFirsta;
		
	}
	
	public function newAjaxCompanyProjectData(){
		
		$business_id = $this->input->post('business_id');
		$company_id = $this->input->post('company_id');
		
		$companyGradea = [];
		$cegTha = [];
		$cegProjecta = [];
		$noBusinessUnit = [];
		$data = [];

		if($business_id == 1 || $business_id == 100){
			$list = $this->mastermodel->getCompanyLocation("tbl_ofclocation");
			foreach ($list as $rec) {
				$location_id = $rec->id;
				$location_name = $rec->city_name;
				$companyGradea[] = $this->mastermodel->getCompanyProjectGradeAjax($location_id, $business_id, $company_id);
			}			
		}
			
		if($business_id == 2 || $business_id == 100){	  
		$cegTha = $this->mastermodel->getCompanyGradeByIdAjax(2, $company_id);	
		}
		if($business_id == 3 || $business_id == 100){
		$cegProjecta = $this->mastermodel->getCompanyProjectGradeByIdAjax(3, $company_id);
		}
		if($business_id == 0 || $business_id == 100){
		$noBusinessUnit = $this->mastermodel->getCompanyProjectGradeByIdAjax(0, $company_id);
		}
		
		
		 ### Process Array Data for CEG ###
		if(is_array($companyGradea) || is_object($companyGradea)){
				$i = 0;
				foreach ($companyGradea as $key => $dat) {
				// #### function to handle foreach data ###
				$data[] = $this->finalData($dat, 1);
						
						 
			}
		}
			
		 ### Process Array Data for CEG TH ###	
		if(is_array($cegTha) || is_object($cegTha)){
			
			$dat = $cegTha;
			// #### function to handle foreach data ###
			$data[] = $this->finalData($dat, 2);

					
		}
        
		 ### Process Array Data for CEG Project ###		
		if(is_array($cegProjecta) || is_object($cegProjecta)){
			
			##$dat = $cegProjecta;
			// #### function to handle foreach data ###
			##$data[] = $this->finalProjectData($dat, 1);
			$arrayFirstc = ['company'=>0,'a'=>0,'b'=>0,'c'=>0,'d'=>0,'e'=>0,'f'=>0,'g'=>0];
			foreach ($cegProjecta as $key => $dt) {
							
					$arrayFirstc['company'] = $dt['company']['company'];
					if(isset($dt['A'])){ 
						$arrayFirstc['a'] = ($dt['A'] ? $dt['A'] : '0');
					}
					
					if(isset($dt['B'])){ 
						$arrayFirstc['b'] = ($dt['B'] ? $dt['B'] : '0');
					}
					if(isset($dt['C'])){ 
						$arrayFirstc['c'] = ($dt['C'] ? $dt['C'] : '0');
					}
					if(isset($dt['D'])){ 
						$arrayFirstc['d'] = ($dt['D'] ? $dt['D'] : '0');
					}
					if(isset($dt['E'])){ 
						$arrayFirstc['e'] = ($dt['E'] ? $dt['E'] : '0');
					}
					if(isset($dt['F'])){  
						$arrayFirstc['f'] = ($dt['F'] ? $dt['F'] : '0');
					}
				
				$data[] = $arrayFirstc;
				}
			
				
			}

			### Process Array Data for No Business Unit ###
			if(is_array($noBusinessUnit) || is_object($noBusinessUnit)){
				$dat = $noBusinessUnit;
				// #### function to handle foreach data ###
				$data[] = $this->finalData($dat, 4);
			}

			$arrayFirstd = ['company'=>0,'a'=>0,'b'=>0,'c'=>0,'d'=>0,'e'=>0,'f'=>0,'g'=>0];
			$data[] = $arrayFirstd;
             
			$results = [
            //"draw" => $_POST['draw'],
			"data" => $data,
			"recordsTotal" => count($data),
			"recordsFiltered" => count($data),
			];
			echo json_encode($results);
				
	}
	
	
}
