<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dpr_control extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->helper(array('form', 'url'));
        $this->load->library('session', 'form_validation');
        $this->load->model('dpr_project/DPR_projectlist_model', 'dprproject');
        $this->load->model('Accountdept_model');

        $this->db1 = $this->load->database('online', TRUE);
        $this->db2 = $this->load->database('default', TRUE);
        $this->db3 = $this->load->database('accdept_db', TRUE);

        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
            
        } else {
            redirect(base_url(""));
        }
    }

    
    //Code By Asheesh 18-11-2020..
    //############################################
    //CEG Project Appraisal List Report....
    public function dpr_invoice_projectlist() {
        $data['title'] = "DPR Project Expenditure";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');
        $data['DprProjectListArr'] = $this->dpr_AllProjectList();
        if (!is_null($user_id)) {
            $this->load->view('dpr/dpr_project_list_view', $data);
        } else {
            redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function ajax_list_dprproject() {
        $list = $this->dprproject->get_datatables();
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $customers) {
            $AssignedDepartments = $this->dpr_AssignedDepartments($customers->id);
            $AssignedActivity = $this->dpr_AssignedActivity($customers->id);

            if ((count($AssignedDepartments) > 0) and ( count($AssignedActivity) > 0)):
                $invc_genr = '<a href="' . base_url('dpr_project_invoice_generate/' . $customers->id) . '"><button class="btn btn-info btn-sm" title="Invoice" >Invoice</button></a>';
            else:
                $invc_genr = '';
            endif;

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $customers->project_name;
            $row[] = count($AssignedDepartments);
            $row[] = count($AssignedActivity);
            $row[] = $invc_genr;
            $row[] = '<a href="' . base_url('project_config_dpr/' . $customers->id) . '"><button class="btn btn-info btn-sm" title="View/Assign" >View & Assign</button></a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->dprproject->count_all(),
            "recordsFiltered" => $this->dprproject->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function dpr_AllProjectList() {
        $this->db->select("a.id,a.project_name");
        $this->db->from("tm_projects as a");
        $this->db->where("a.is_active", "1");
        $this->db->where("(a.project_category='DPR' OR a.project_category='dpr' OR a.project_category='3')", NULL, FALSE);
        $this->db->order_by("a.project_name", "ASC");
        $recordArr = $this->db->get()->result();
        return ($recordArr) ? $recordArr : null;
    }

    public function project_config_dpr($projID) {
        $data['title'] = "DPR Project Configuration";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');
        $data['ProjectDetailsByID'] = $this->GetProjectDetailsByID($projID);
        if ($data['ProjectDetailsByID'] == null) {
            redirect(base_url(""));
        }

        $data['AllDepartment_DPR'] = $this->dpr_AllDepartments();
        $data['AllActivity_DPR'] = $this->dpr_AllActivity();

        $data['AssignedDepartments'] = $this->dpr_AssignedDepartments($projID);
        $data['AssignedActivity'] = $this->dpr_AssignedActivity($projID);

        if (!is_null($user_id)) {
            $this->load->view('dpr/dpr_project_configuration_view', $data);
        } else {
            redirect($_SERVER['HTTP_REFERER']);
        }
    }

    public function dpr_AssignedDepartments($projId) {
        $db3 = $this->db3->database;
        $this->db->select("$db3.a.fld_id,$db3.a.sr_no,b.dpr_department_name");
        $this->db->from("$db3.dpr_assign_attribute as a");
        $this->db->join("$db3.dpr_department_master as b", "a.master_tbl_id=b.fld_id", "LEFT");

        $this->db->where(["$db3.a.status" => "1"]);
        $this->db->where(["$db3.a.type" => "1"]);
        $this->db->where(["$db3.a.project_id" => $projId]);
        $this->db->order_by("$db3.a.sr_no", "ASC");
        $respRecd = $this->db->get()->result();
        return ($respRecd) ? $respRecd : null;
    }

    public function dpr_AssignedActivity($projId) {
        $db3 = $this->db3->database;
        $this->db->select("$db3.a.fld_id,$db3.a.sr_no,b.activity_title");
        $this->db->from("$db3.dpr_assign_attribute as a");
        $this->db->join("$db3.dpr_activity_master as b", "a.master_tbl_id=b.fld_id", "LEFT");
        $this->db->where(["$db3.a.status" => "1"]);
        $this->db->where(["$db3.a.type" => "2"]);
        $this->db->where(["$db3.a.project_id" => $projId]);
        $this->db->order_by("$db3.a.sr_no", "ASC");
        $respRecd = $this->db->get()->result();
        return ($respRecd) ? $respRecd : null;
    }

    public function GetProjectDetailsByID($projID) {
        $this->db->select("a.*,b.client_name");
        $this->db->from("tm_projects as a");
        $this->db->join("tm_clients as b", "a.client_id=b.id", "LEFT");

        $this->db->where("a.is_active", "1");
        $this->db->where("(a.project_category='DPR' OR a.project_category='dpr' OR a.project_category='3')", NULL, FALSE);
        $this->db->where("a.id", $projID);
        $recordArr = $this->db->get()->row();
        return ($recordArr) ? $recordArr : null;
    }

    public function dpr_AllDepartments() {
        $db3 = $this->db3->database;
        $this->db->select("$db3.a.fld_id,$db3.a.dpr_department_name");
        $this->db->from("$db3.dpr_department_master as a");
        $this->db->where(["$db3.a.status" => "1"]);
        $this->db->order_by("$db3.a.dpr_department_name", "ASC");

        $respRecd = $this->db->get()->result();
        return ($respRecd) ? $respRecd : null;
    }

    public function dpr_AllActivity() {
        $db3 = $this->db3->database;
        $this->db->select("$db3.a.fld_id,$db3.a.activity_title,$db3.a.activity_sort_description");
        $this->db->from("$db3.dpr_activity_master as a");
        $this->db->where(["$db3.a.status" => "1"]);
        $this->db->order_by("$db3.a.activity_title", "ASC");

        $respRecd = $this->db->get()->result();
        return ($respRecd) ? $respRecd : null;
    }

    //Insert.. ""
    public function assign_departmentsaveupdate() {
        $db3 = $this->db3->database;

        $user_id = $this->session->userdata('loginid');
        $projId = $this->input->post('proj_id');
        $master_tbl_id = $this->input->post('master_tbl_id');
        $type = $this->input->post('type');
        $sr_no = $this->input->post('sr_no');

        $insertArr = array("project_id" => $projId, "master_tbl_id" => $master_tbl_id, "type" => $type, "sr_no" => $sr_no, "entry_by" => $user_id);

        $this->db->where(["a.project_id" => $projId, "a.master_tbl_id" => $master_tbl_id, "a.type" => $type, "a.status" => "1"]);
        $num = $this->db->count_all_results("$db3.dpr_assign_attribute as a");
        if ($num > 0) {
            $this->session->set_flashdata('error_msg', 'attributes already assigned');
        } else {
            $this->session->set_flashdata('success_msg', 'Attributes Assiged Successfully.');
            $this->db->insert("$db3.dpr_assign_attribute", $insertArr);
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    //Delete Attributes
    public function delete_attr($attrID) {
        $db3 = $this->db3->database;
        $this->db->where("$db3.dpr_assign_attribute.fld_id", $attrID);
        $this->db->where("$db3.dpr_assign_attribute.status", '1');
        $respN = $this->db->update("$db3.dpr_assign_attribute", ["$db3.dpr_assign_attribute.status" => "0", "$db3.dpr_assign_attribute.update_by" => $this->session->userdata('loginid'), "$db3.dpr_assign_attribute.updated_date" => date("Y-m-d H:i:s")]);
        if ($respN):
            $this->session->set_flashdata('success_msg', 'Attributes Deleted Successfully.');
        endif;

        redirect($_SERVER['HTTP_REFERER']);
    }

    //Delete expenditurebill_info
    public function delete_expenditurebill_info($attrID) {
        $db3 = $this->db3->database;
        $this->db->where("$db3.dpr_expenditurebill_info.fld_id", $attrID);
        $this->db->where("$db3.dpr_expenditurebill_info.status", '1');
        $respN = $this->db->update("$db3.dpr_expenditurebill_info", ["$db3.dpr_expenditurebill_info.status" => "0", "$db3.dpr_expenditurebill_info.updated_by" => $this->session->userdata('loginid'), "$db3.dpr_expenditurebill_info.updated_date" => date("Y-m-d H:i:s")]);
        if ($respN):
            $this->session->set_flashdata('success_msg', 'Expenditure Bill Info Deleted Successfully.');
        endif;
        redirect($_SERVER['HTTP_REFERER']);
    }

    //DPR Project Expenditure Generate..
    public function dpr_project_invoice_generate($projID) {
        $data['title'] = "DPR Project Expenditure Generate";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');

        $data['ProjectDetailsByID'] = $this->GetProjectDetailsByID($projID);
        if ($data['ProjectDetailsByID'] == null) {
            redirect(base_url(""));
        }

        $data['AssignedDepartments'] = $this->dpr_AssignedDepartments($projID);
        $data['AssignedActivity'] = $this->dpr_AssignedActivity($projID);
        //Get if Existing Invoice By Project ID..
        $data['ExistingRecord'] = $this->GetExpenditureInfo($projID);

        if (!is_null($user_id)) {
            $this->load->view('dpr/dpr_proj_invc_generate_view', $data);
        } else {
            redirect($_SERVER['HTTP_REFERER']);
        }
    }

    
    //Invoice Create Proccess..
    public function create_dpr_invoice() {
        $db3 = $this->db3->database;
        $user_id = $this->session->userdata('loginid');
        $projId = $this->input->post('proj_id');
        $invoice_name = $this->input->post('invoice_name');
        $invoice_date = $this->input->post('invoice_date');

        $whereArr = ["a.project_id" => $projId, "a.status" => '1', "a.year" => date("Y", strtotime($invoice_date)), "a.month" => date("m", strtotime($invoice_date))];
        $this->db->where($whereArr);
        $num = $this->db->count_all_results("$db3.dpr_expenditurebill_info as a");
        if ($num > 0) {
            $this->session->set_flashdata('error_msg', 'this month Invoice already existing');
            redirect($_SERVER['HTTP_REFERER']);
        }

        if ($user_id && $projId && $invoice_name && $invoice_date) {
            $insertArr = array("project_id" => $projId, "invoice_date" => $invoice_date, "invoice_name" => $invoice_name, "year" => date("Y", strtotime($invoice_date)), "month" => date("m", strtotime($invoice_date)), "entry_by" => $user_id);

            $respN = $this->db->insert("$db3.dpr_expenditurebill_info", $insertArr);
            $insertID = $this->db->insert_id();

            if ($insertID) {
                $updDataArr = ["invoice_gen_id" => INVCPRE . "/" . $insertID];
                $this->db->where(["fld_id" => $insertID]);
                $this->db->update("$db3.dpr_expenditurebill_info", $updDataArr);
            }

            if ($respN):
                $this->session->set_flashdata('success_msg', 'Invoice Create Successfully.');
            endif;
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    //Expenditure Bill
    public function GetExpenditureInfo($projid) {
        $db3 = $this->db3->database;
        $this->db->select("$db3.a.*");
        $this->db->from("$db3.dpr_expenditurebill_info as a");
        $this->db->where(["$db3.a.status" => "1", "$db3.a.project_id" => $projid]);
        $this->db->order_by("$db3.a.invoice_date", "DESC");
        $respRecd = $this->db->get()->result();
        return ($respRecd) ? $respRecd : null;
    }

}
