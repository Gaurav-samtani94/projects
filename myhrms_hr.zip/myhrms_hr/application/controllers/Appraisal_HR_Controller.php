<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Appraisal_HR_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('appraisal/Emp_appraisal_model', 'appraisalmodel');

        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }

        $ApprSessionRecd = GetLastApprSession();
        $this->AppraisalFullMonth = date('M Y',strtotime($ApprSessionRecd->cycle_date));
        $this->AppraisalDate = date('Y-m-d',strtotime($ApprSessionRecd->cycle_date));
    }

    //Appraisal Assign By HR,..
    public function appraisal_assign() { 
        $data[] = '';
        $data['title'] = "Appraisal Assign By HR";
        $data['AppraisalListMaster'] = $this->mastermodel->GetTableDataRec("appr_increment_cycle_master", ["status" => "1"]);
        $this->load->view('appraisal/appraisal_list_master', $data);
    }


    //Appraisal Assign..
    public function appraisal_assign_employees($apprSessionID) {
        $data[] = '';
        $data['title'] = "Appraisal Assign To Employee";
        $data['appr_sessionid'] = $apprSessionID;
        $data['AppraisalSession'] = $this->AppraisalDetailsByID($apprSessionID);


        if($data['AppraisalSession']<date('Y-m-d')){
            $this->session->set_flashdata('error_msg', 'Appraisal Session Date Expired.');
			redirect(base_url('appraisal_assign'));
        }

        $ApprSessionRecd = GetLastApprSession();
        $this->AppraisalFullMonth = date('F Y',strtotime($ApprSessionRecd->cycle_date));
        $this->AppraisalDate = date('Y-m-d',strtotime($ApprSessionRecd->cycle_date));

        // echo $this->AppraisalFullMonth;
        // die; 

        $this->load->view('appraisal/appraisal_assign_employee', $data);
    }


    public function ajax_list_assignappraisal() { 
        $no = 1;
        $list = $this->appraisalmodel->get_datatables();

        $data = array();
        $no = $_POST['start'];
        foreach ($list as $recemp) {
            $no ++;
            $row = array();
            $row[] = $no;
            $row[] = ($recemp->employeeId) ? $recemp->employeeId . "<br><span style='color:blue'>" . @$recemp->appraisalduedate . "</span>" : "";
            $row[] = ($recemp->userfullname) ? $recemp->userfullname : "";
            $row[] = ($recemp->date_of_joining) ? date("d-m-Y", strtotime($recemp->date_of_joining)) : "";
            $row[] = ($recemp->businessunit_name) ? $recemp->businessunit_name : "";
            $row[] = ($recemp->department_name) ? $recemp->department_name : "";
            $row[] = ($recemp->reporting_manager_name) ? $recemp->reporting_manager_name : "";
            if ($recemp->apprsession) {
                $row[] = '<button class="btn btn-info" > Assigned </button>';
            } else {
                $row[] = '<button class="btn btn-success" id="' . $recemp->id . '" onclick="assignappraisalform(this.id)" > Assign </button>';
            }
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->appraisalmodel->count_all(),
            "recordsFiltered" => $this->appraisalmodel->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }


    //Assign Appraisal Form By Hr Ajax,,..
    public function ajax_assignappraisalformby_hr() {
        $userId = $_REQUEST['emplid'];
        $apprSessionId = $_REQUEST['apprsessionid'];
        $todayDate = date("Y-m-d");

        $user_bunit = GetBunitByUserID($userId);
        $RepManagerID = GetReportingManagerIDByUserID($userId);

        //Appraisal Assign Code of CEG B unit..
        if ($user_bunit == 1) {
            //Gate Last Date of Lock..
            $this->db->select("a.day_diff_user");
            $this->db->from("appr_auto_lockdate as a");
            $this->db->where(array('a.appr_cycle_id' => '12', 'a.status' => '1'));
            $recDD = $this->db->get()->row();

            if ((@$userId) and (@$apprSessionId) and ($recDD->day_diff_user)) {
                $lastDate = date('Y-m-d', strtotime($todayDate . " + $recDD->day_diff_user day"));
               // $lastDate = "2023-05-01";
                $insertArr = array("emp_id" => $userId, "emp_last_date" => $lastDate, "emp_grace_period" => date('Y-m-d', strtotime($lastDate . " +$recDD->day_diff_user day")), "appraisal_cycle_id" => $apprSessionId, "email_status" => '1',"assign_group_id" => '1');

                $this->db->select('id');
                $this->db->from('appr_mail_appraisal');
                $this->db->where(array("emp_id" => $userId, "appraisal_cycle_id" => $apprSessionId, "status" => "1"));
                $numRows = $this->db->count_all_results();
                if ($numRows < 1):
                    $this->db->insert("appr_mail_appraisal", $insertArr);
                    $insert_id = $this->db->insert_id();
                    //Assign Mail..
                    if ($insert_id) {
                        $this->appraisalassignmail($insert_id);
                    }
                endif;
            }
            echo ($insert_id) ? $insert_id : null;
        }
    }



    //Single Appraisal Details By Appraisal ID..
    public function AppraisalDetailsByID($apprID) {
        $this->db->select("a.cycle_date");
        $this->db->from("appr_increment_cycle_master as a");
        $this->db->where(array('a.fld_id' => $apprID, 'a.status' => '1'));
        $recDD = $this->db->get()->row();
        return ($recDD) ? $recDD->cycle_date : null;
    }

    //Single Appraisal Details By Appraisal ID..
    public function AppraisalRecordDetailsByID($apprID) {
        $this->db->select("a.*,b.cycle_date,c.userfullname,c.emailaddress");
        $this->db->from("appr_mail_appraisal as a");
        $this->db->join("appr_increment_cycle_master as b", "a.appraisal_cycle_id=b.fld_id", "LEFT");
        $this->db->join("main_employees_summary as c", "a.emp_id=c.user_id", "LEFT");
        $this->db->where(array('a.id' => $apprID, 'a.status' => '1'));
        $recDD = $this->db->get()->row();
        return ($recDD) ? $recDD : null;
    }

    //Appraisal Assign Mail..
    public function appraisalassignmail($apprID) {
        $data['error'] = '';
        $AppraisalRecArr = $this->AppraisalRecordDetailsByID($apprID);
        $data['singleRecAppraisal'] = $AppraisalRecArr;
        //########## Appraisal Employee Self #############
        $to = $AppraisalRecArr->emailaddress;
        //$to = "cegapps@cegindia.com";

        $ApprSessionRecd = GetLastApprSession();
        $PrevYear = date('Y',strtotime($ApprSessionRecd->cycle_date));
        $NextYear = ($PrevYear+1);

        $subject = "Performance Appraisal for $PrevYear - $NextYear is initiated - Please Fill";
        $msgDetails = $this->load->view('email/appraisal_assign_byhr', $data, true);
        $returVaL = $this->sendMail($to, $subject, $msgDetails);
        return ($returVaL) ? $returVaL : true;
    }

    //
    public function tests() {
        $loginid = $this->session->userdata('loginid');
        echo GetBunitByUserID($loginid);
        die;
    }

    function sendMail($to, $subject, $msgDetails) {
        //return true;
        $CI = & get_instance();
        $CI->load->library('email');
        $CI->email->initialize(array('protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        ));
        $CI->email->from('hrms.admin@cegindia.com', 'CEG-HRMS');
        $CI->email->to($to);
        $CI->email->bcc('marketing@cegindia.com');
        $CI->email->subject($subject);
        $CI->email->message($msgDetails);
        $resp = $CI->email->send();
        return ($resp) ? $resp : true;
    }

}