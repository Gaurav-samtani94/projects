<?php

defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
require_once APPPATH . "/third_party/excel1/vendor/autoload.php";

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Font;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Style\Protection;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\RichText\RichText;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class Project_MM_excel_export_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('appraisalonproject/Report_projectmm_model', 'accdeptmodel');
        $this->load->model("Accountdept_model");
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }
	

	
    public function projectMM_reportExcelDownload($projID) {
		
        $list = $this->accdeptmodel->get_datatables();
		// $hrmsProjID = 81;

		$spreadsheet = new Spreadsheet();
		$spreadsheet->setActiveSheetIndex(0);
		$spreadsheet->getActiveSheet()->setCellValue('A1', 'Project MM Report');
		$spreadsheet->getActiveSheet()->mergeCells('A1:M1');
		
		
		$admincellval = '2';
		$jadminID = '3';
		$jadminID2 = 1;
		$jadminID3 = 1;
		
		$spreadsheet->getActiveSheet()->setCellValue('A' . $admincellval, "S.No."); 	
		$spreadsheet->getActiveSheet()->setCellValue('B' . $admincellval, "Emp Name"); 
		$spreadsheet->getActiveSheet()->setCellValue('C' . $admincellval, "Designation / Position"); 	
		$spreadsheet->getActiveSheet()->setCellValue('D' . $admincellval, "Designation"); 
		$spreadsheet->getActiveSheet()->setCellValue('E' . $admincellval, "Total MM"); 
		$spreadsheet->getActiveSheet()->setCellValue('F' . $admincellval, "Tot. MM+EOT-MM"); 
		$spreadsheet->getActiveSheet()->setCellValue('G' . $admincellval, "Total Cum. Prev. MM"); 
		$spreadsheet->getActiveSheet()->setCellValue('H' . $admincellval, "Balance MM"); 
		$spreadsheet->getActiveSheet()->setCellValue('I' . $admincellval, "EOT (un approved)"); 	
		$spreadsheet->getActiveSheet()->setCellValue('J' . $admincellval, "Start Date"); 	
		$spreadsheet->getActiveSheet()->setCellValue('K' . $admincellval, "End Date");
		$spreadsheet->getActiveSheet()->setCellValue('L' . $admincellval, "Project Name");
		$spreadsheet->getActiveSheet()->setCellValue('M' . $admincellval, "Employee ID");
		foreach($list as $vals){
			$hrmsProjID = $vals->id;
		
			$data = $this->Accountdept_model->GetProjectDesignCategByProjID($hrmsProjID);
			
			$DesignationListArr = $this->Accountdept_model->GetProjectDesignationListArr($hrmsProjID);
			if($DesignationListArr){
				// $spreadsheet->getActiveSheet()->mergeCells('A' . $admincellval.':'. 'K' .$admincellval);
				// $spreadsheet->getActiveSheet()->setCellValue('A' . $admincellval, "");  
				// $admincellval++;
				
				
				// $spreadsheet->getActiveSheet()->getStyle("A$admincellval:L$admincellval")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
				// $spreadsheet->getActiveSheet()->mergeCells('A' . $admincellval.':'. 'L' .$admincellval);
				
				
				// $spreadsheet->getActiveSheet()->getStyle("A$admincellval:L$admincellval")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
				// $spreadsheet->getActiveSheet()->setCellValue('A' . $admincellval, "$vals->project_name");  
				// $admincellval++;
				
				foreach($data as $d1){
					
					// $spreadsheet->getActiveSheet()->setCellValue('A' . $admincellval, "");
					
					// $spreadsheet->getActiveSheet()->getStyle("A$admincellval:K$admincellval")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
					// $spreadsheet->getActiveSheet()->getStyle("A$admincellval:K$admincellval")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
					// $spreadsheet->getActiveSheet()->mergeCells('A' . $admincellval.':'. 'K' .$admincellval);
					

					// $admincellval++;
					
					
					// $spreadsheet->getActiveSheet()->getStyle('A' . $admincellval:'K' . $admincellval)->getFont()->setBold( true );					
					$designationAllRecd = $DesignationListArr[$d1->design_categid];
					// echo "<pre>"; print_r($designationAllRecd); die;
						foreach($designationAllRecd as $KKey => $keyRow){
							$sum_ApprvEOTRec = $this->Accountdept_model->ApprvEOTDetails_SumMM($keyRow->hrms_projid, $keyRow->designation_id);
							$sum_UnApprvEOTRec = $this->Accountdept_model->UnApprvEOTDetails_SumMM($keyRow->hrms_projid, $keyRow->designation_id);
							$endDateOfProject = $this->Accountdept_model->getEndDateOfProjectByProjectID($keyRow->hrms_projid);
							// echo "<pre>"; print_r($endDateOfProject); die;
							$admincellval++;
							$empFullName = '';
							if ($keyRow->company_id == "74" or $keyRow->company_id == null) {
								if ($keyRow->userfullname_repl != "") {
									$empFullName = $keyRow->userfullname_repl . " / ";
								}
								$empFullName .= $keyRow->prefix_name . " " . $keyRow->userfullname;
							}
							if ($keyRow->company_id != "74") {
								$empFullName = $keyRow->emp_name;
							}

							if ($keyRow->flag_of_repl == "2") {
								$empFullName = $keyRow->emp_name;
							}
							if($empFullName){
								$newEmpName = $empFullName;
							}else{
								$newEmpName = "TBN"; 
							}
							
							if($endDateOfProject->eot_extn_end_date){
								$startDate = date('d-m-Y',strtotime($keyRow->start_date));
							}else{
								$startDate = "--";
							}
							
							if($endDateOfProject->eot_extn_end_date){
								$endDate = date('d-m-Y',strtotime($endDateOfProject->eot_extn_end_date));
							}else{
								$endDate = "--";
							}
							// $newEmpName = ($empFullName) ? $empFullName : "TBN";
							$KKey++;
							$spreadsheet->getActiveSheet()->setCellValue('A' . $admincellval, "$KKey");
							$spreadsheet->getActiveSheet()->setCellValue('B' . $admincellval, "$newEmpName");
							$spreadsheet->getActiveSheet()->setCellValue('C' . $admincellval, "$keyRow->designation_name\n ($keyRow->company_name)");
							$spreadsheet->getActiveSheet()->setCellValue('D' . $admincellval, "$d1->ktype_name"); // country_name
							$spreadsheet->getActiveSheet()->setCellValue('E' . $admincellval, "$keyRow->mm"); // country_name
							$spreadsheet->getActiveSheet()->setCellValue('F' . $admincellval, number_format(($keyRow->mm + $sum_ApprvEOTRec), 2));
							$spreadsheet->getActiveSheet()->setCellValue('G' . $admincellval, number_format(($keyRow->cumul_prev_mm), 2)); 
							$spreadsheet->getActiveSheet()->setCellValue('H' . $admincellval, number_format(($keyRow->mm + $sum_ApprvEOTRec) - $keyRow->cumul_prev_mm, 2)); 
							$spreadsheet->getActiveSheet()->setCellValue('I' . $admincellval, number_format($sum_UnApprvEOTRec, 2)); 
							$spreadsheet->getActiveSheet()->setCellValue('J' . $admincellval, "$startDate"); 
							$spreadsheet->getActiveSheet()->setCellValue('K' . $admincellval, "$endDate"); 
							$spreadsheet->getActiveSheet()->setCellValue('L' . $admincellval, "$vals->project_name"); 
							$spreadsheet->getActiveSheet()->setCellValue('M' . $admincellval, "$keyRow->employeeId"); 
						// }
						}
			
					// $admincellval = $admincellval + 1;
					$jadminID++;
				}
			}
		}
		$spreadsheet->getActiveSheet()->getColumnDimension('A')->setWidth(5);  
		$spreadsheet->getActiveSheet()->getColumnDimension('B')->setWidth(30); 
		$spreadsheet->getActiveSheet()->getColumnDimension('C')->setWidth(55); 
		$spreadsheet->getActiveSheet()->getColumnDimension('D')->setWidth(20); 
		$spreadsheet->getActiveSheet()->getColumnDimension('E')->setWidth(15); 
		$spreadsheet->getActiveSheet()->getColumnDimension('F')->setWidth(15); 
		$spreadsheet->getActiveSheet()->getColumnDimension('G')->setWidth(15); 
		$spreadsheet->getActiveSheet()->getColumnDimension('H')->setWidth(15); 
		$spreadsheet->getActiveSheet()->getColumnDimension('I')->setWidth(20); 
		$spreadsheet->getActiveSheet()->getColumnDimension('J')->setWidth(20); 
		$spreadsheet->getActiveSheet()->getColumnDimension('K')->setWidth(20); 
		$spreadsheet->getActiveSheet()->getColumnDimension('L')->setWidth(28); 
		$spreadsheet->getActiveSheet()->getColumnDimension('M')->setWidth(20); 
		
		// $spreadsheet->getActiveSheet()->getStyle("B3:H$jadminID", $spreadsheet->getActiveSheet()->getHighestRow())->getAlignment()->setWrapText(true);
		
		$spreadsheet->getActiveSheet()->getRowDimension('1')->setRowHeight(25);
		$spreadsheet->getActiveSheet()->getPageSetup()->setOrientation(PageSetup::ORIENTATION_LANDSCAPE);
		$spreadsheet->getActiveSheet()->getPageSetup()->setPaperSize(PageSetup::PAPERSIZE_A4);
		$spreadsheet->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1,3);
		$spreadsheet->getActiveSheet()->getPageMargins()->setTop(0.1);
		$spreadsheet->getActiveSheet()->getPageMargins()->setRight(0.1);
		$spreadsheet->getActiveSheet()->getPageMargins()->setLeft(0.1);
		$spreadsheet->getActiveSheet()->getPageMargins()->setBottom(0.1);
		
		$spreadsheet->getActiveSheet()->getPageSetup()->setPrintArea("A1:M$admincellval");

		$spreadsheet->getActiveSheet()->getStyle("A1:M1")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
		// $spreadsheet->getActiveSheet()->getStyle("A1:H1", $spreadsheet->getActiveSheet()->getHighestRow())->getAlignment()->setWrapText(true);
		$spreadsheet->getActiveSheet()->getStyle("A1:M1")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
		
		
		// $spreadsheet->getActiveSheet()->getStyle("B4:H$jadminID")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
		
		// $spreadsheet->getActiveSheet()->getStyle("C4:H$jadminID")->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
		
		// $spreadsheet->getActiveSheet()->getStyle("C4:H$jadminID")->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
		
		$spreadsheet->getActiveSheet()->setTitle('Project MM List');
		$spreadsheet->setActiveSheetIndex(0);
		
		
		$file = "Prject_mm_report";
		$filename = './uploads/projectMM/' . $file;
		
		$writer = new Xlsx($spreadsheet);
		$writer->save($filename.'.xlsx');
		
		$filename2 = 'uploads/projectMM/' . $file;
		$path= HOSTNAME.$filename2.'.xlsx';   
		echo $path;	
    }

}
