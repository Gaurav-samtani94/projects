<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class All_emp_list_with_io_ro_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        // $this->load->model('Appraisal_new_model', 'appraisalmodel');
        $this->load->model('All_emplist_with_IO_RO_model', 'empWithIoRo');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
            
        } else {
            redirect(base_url(""));
        }
    }

    public function allEMpLIst() {
		$data['title'] = "Employee with IO/RO Detail";
		$this->load->view("all_emp_with_io_ro_detail/all_emp_io_ro_detail", $data);
    }
	


	public function allEMpLIstWithIORO() {
        $list = $this->empWithIoRo->get_datatables();
		$data = array();
		$count=$_POST['start'];
		foreach($list as $value):

			$IO = get_ro_full_details_by_Id($value->reporting_manager);
            $RO = get_ro_full_details_by_Id($value->reviewing_officer_ro);


			// echo "<pre>"; print_r($IO); die;
			$row = array();
			$row[] = $count+1;
            $row[] = $value->userfullname;
            $row[] = date('d-m-Y', strtotime($value->date_of_joining));
            $row[] = $value->appraisalduedate ==''?'-':date('M-Y', strtotime($value->appraisalduedate));
            $row[] = $value->businessunit_name;
            $row[] = $value->employeeId;
            $row[] = $value->jobtitle_name;
            $row[] = $value->department_name;
            $row[] = $IO->userfullname;
            $row[] = $IO->employeeId;
			$row[] = $RO->userfullname;
            $row[] = $RO->employeeId;

			$data[] = $row;
			
			$count++;
		endforeach;
		$output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->empWithIoRo->count_all(),
            "recordsFiltered" => $this->empWithIoRo->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
		exit;
    }




    

}
