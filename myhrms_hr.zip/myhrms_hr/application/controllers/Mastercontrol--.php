<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mastercontrol extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->helper(array('form', 'url'));
        $this->load->library('session', 'form_validation');
        $this->load->model('Employeereport_model', 'empreport');
        $this->load->model('Report_leave_model', 'repleavemodel');
        $this->load->model('Report_model', 'repmodel');
        $this->load->model('Employeereportleft_model');
        $this->load->model('job_exp_history_report_model');
        $this->load->model('Empreporteduqual_model', 'educational');
        $this->load->model('Empreporteduexp_model', 'emprepeduexp');
        $this->load->model('Employeereportleft_model', 'empreportleft');
        $this->load->model('appraisalonproject/Report_appraisalnew_model', 'apprproject');
        $this->load->model('appraisalonproject/Report_projectmm_model', 'accdeptmodel');

        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
            
        } else {
            redirect(base_url(""));
        }
    }

    //Employee List Controller... Report 1
    public function employee_report_list() {
        $data['error'] = array();
        $data['title'] = "Employee Basic Details Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');
        if (!is_null($user_id)) {
            $this->load->view('new_report/emp_list', $data);
        } else {
            redirect('admin', true);
        }
    }

    //Employee List Controller... Report 2
    public function employee_report_newjoin() {
        $data['error'] = array();
        $data['title'] = "Employee New Joining Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');
        if (!is_null($user_id)) {
            $this->load->view('new_report/emp_list_newjoin', $data);
        } else {
            redirect('admin', true);
        }
    }

    //Employee List Controller... Report 3
    public function employee_left() {
        $leftEmpArr = $this->Employeereportleft_model->_get_datatables_query();
        $error = array();
        $title = "Employee Left / Resignation Report";
        // $role = $this->session->userdata('assign_role');
        $user_id = $this->session->userdata('loginid');
        if (@$_REQUEST['filter']) {
            $bus_unit = $_REQUEST['businessunit_name'];
            $company = $_REQUEST['company_name'];
            $dpt = $_REQUEST['department_id'];
            $design = $_REQUEST['potion_design'];
            $emp_name = $_REQUEST['userfullname'];
            $from_date = $_REQUEST['from_date'];
            $to_date = $_REQUEST['to_date'];
            $leftEmpArr = $this->Employeereportleft_model->_get_datatables_query($bus_unit, $company, $dpt, $design, $from_date, $to_date, $emp_name);
        }
        if (@$_REQUEST['yearsel']):
            $jan = array();
            $months = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
            for ($i = 1; $i < 13; $i++):
                if ($i % 2 == 0) {
                    if ($i == 2) {
                        $k = 28;
                    } elseif ($i == 8) {
                        $k = 31;
                    } else {
                        $k = 30;
                    }
                } else {
                    $k = 31;
                }
                $year = $_REQUEST['yearsel'];
                $st_date = date($year . "-" . $i . "-01");
                $end_date = date($year . "-" . $i . "-" . $k);
                $leftEmpGraphArr = $this->Employeereportleft_model->get_left_emp_graph($st_date, $end_date);
                $jan[] = $leftEmpGraphArr;
            endfor;
            $data1 = array_combine($months, $jan);
            if (!is_null($user_id)) {
                $this->load->view('new_report/emp_left_view', compact('year', 'data1', 'title', 'leftEmpArr', 'leftEmpGraphArr', 'bus_unit', 'company', 'dpt', 'design', 'from_date', 'to_date', 'emp_name'));
            } else {
                redirect('admin', true);
            }
        else:
            $jan = array();
            $months = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
            for ($i = 1; $i < 13; $i++):
                if ($i % 2 == 0) {
                    if ($i == 2) {
                        $k = 28;
                    } elseif ($i == 8) {
                        $k = 31;
                    } else {
                        $k = 30;
                    }
                } else {
                    $k = 31;
                }
                $st_date = date("Y-" . $i . "-01");
                $end_date = date("Y-" . $i . "-" . $k);
                $leftEmpGraphArr = $this->Employeereportleft_model->get_left_emp_graph($st_date, $end_date);
                $jan[] = $leftEmpGraphArr;

            endfor;
            $data1 = array_combine($months, $jan);
            if (!is_null($user_id)) {
                $this->load->view('new_report/emp_left_view', compact('data1', 'title', 'leftEmpArr', 'leftEmpGraphArr', 'bus_unit', 'company', 'dpt', 'design', 'from_date', 'to_date', 'emp_name'));
            } else {
                redirect('admin', true);
            }
        endif;
    }

    public function ajax_yearwise_graph() {
        $jan = array();
        $months = array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
        for ($i = 1; $i < 13; $i++):
            if ($i % 2 == 0) {
                if ($i == 2) {
                    $k = 28;
                } elseif ($i == 8) {
                    $k = 31;
                } else {
                    $k = 30;
                }
            } else {
                $k = 31;
            }
            $year = $_REQUEST['year'];
            if ($year):
                $st_date = date($year . "-" . $i . "-01");
                $end_date = date($year . "-" . $i . "-" . $k);
            else:
                $st_date = date("Y-" . $i . "-01");
                $end_date = date("Y-" . $i . "-" . $k);
            endif;
            $leftEmpGraphArr = $this->Employeereportleft_model->get_left_emp_graph($st_date, $end_date);
            $jan[] = $leftEmpGraphArr;
        endfor;
        $data1 = array_combine($months, $jan);
        print_r($data1);
    }

    public function ajax_yearwise_graph1() {
        $t = $_REQUEST['yearsel'];
        echo $t;
        die;
    }

    //Leave index
    public function leave_report() {
        $data['error'] = '';
        $data['title'] = "Employee Leave Management";
        $role = $this->session->userdata('assign_role');
        $user_id = $this->session->userdata('loginid');
        if (!is_null($user_id)) {
            $this->load->view('new_report/leave_index_view', $data);
        } else {
            redirect('admin', true);
        }
    }

    public function ajax_list_leave() {
        $list = $this->repleavemodel->get_datatables();
        // print_r($list); die;
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $customers->userfullname;
            $row[] = $customers->businessunit_name;
            $row[] = $customers->department_name;
            $row[] = $customers->reporting_manager_name;
            $row[] = date('d-m-Y', strtotime($customers->from_date));
            $row[] = date('d-m-Y', strtotime($customers->to_date));
            $row[] = $customers->appliedleavescount;
            $row[] = $customers->leavetype_name;
            $row[] = $customers->leavestatus;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->repleavemodel->count_all(),
            "recordsFiltered" => $this->repleavemodel->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    //Tour Index..
    public function tour_report() {
        $data['title'] = "Employee Tour Management";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');
        if (!is_null($user_id)) {
            $this->load->view('new_report/tour_index_view', $data);
        } else {
            redirect('admin', true);
        }
    }

    public function ajax_list_tour() {
        $list = $this->repmodel->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            $tour_status = $customers->approved_bypmanager;
            if ($tour_status == 0):
                $to_s = "<span style='color:red'>Pending Approval</span>";
            endif;
            if ($tour_status == 1):
                $to_s = "<span style='color:green'>Approved</span>";
            endif;
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $customers->userfullname;
            $row[] = $customers->businessunit_name;
            $row[] = $customers->department_name;
            $row[] = $customers->reporting_manager_name;
            $row[] = date('d-m-Y', strtotime($customers->start_date));
            $row[] = date('d-m-Y', strtotime($customers->end_date));
            $row[] = $customers->project_name;
            $row[] = $customers->tour_location;
            $row[] = $to_s;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->repmodel->count_all(),
            "recordsFiltered" => $this->repmodel->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    //Report of Education & Experiance ...
    public function employee_expr() {
        $data['error'] = array();
        $data['title'] = "Employee Experience Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');
        if (!is_null($user_id)) {
            $this->load->view('new_report/emp_list_eduexp', $data);
        } else {
            redirect('admin', true);
        }
    }

    //Report Of Qualif... 
    public function employee_qualification() {
        $data['error'] = array();
        $data['title'] = "Employee Educational Qualification Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');
        if (!is_null($user_id)) {
            $this->load->view('new_report/emp_list_qul_fication', $data);
        } else {
            redirect('admin', true);
        }
    }

    //Employee New Report Of Qualification... 
    public function employee_qualification_new() {
        $data['error'] = array();
        $data['title'] = "Employee Educational Qualification Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('user_id');
        if (!is_null($user_id)) {
            $this->load->view('new_report/emp_list_qul_fication_new', $data);
        } else {
            redirect('admin', true);
        }
    }

    //26-05-2018 Code For Salary Details...
    public function employee_salarydetails() {
        $data['error'] = array();
        $data['title'] = "Employee Salary Details Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('user_id');
        if (!is_null($user_id)) {
            $this->load->view('new_report/emp_list_salarydetails', $data);
        } else {
            redirect('admin', true);
        }
    }

    // Report Group of employee Designation
    public function employee_design_group_report() {
        $data['error'] = array();
        $data['title'] = "Employee Job Group Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('user_id');
        if (!is_null($user_id)) {
            $this->load->view('new_report/emp_design_group_report', $data);
        } else {
            redirect('admin', true);
        }
    }

    public function ajax_list_empreport() {
        $list = $this->Employeereportleft_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            if (!empty($customers->reviewing_officer_ro)) {
                $results = $this->empreport->getUsernameByID($customers->reviewing_officer_ro);
                $RO = isset($results[0]->userfullname) ? $results[0]->userfullname : '';
            } else {
                $RO = '';
            }
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($customers->employeeId) ? $customers->employeeId : '';
            $row[] = ($customers->userfullname) ? $customers->userfullname : '';
            $row[] = ($customers->date_of_joining) ? date("d-m-Y", strtotime($customers->date_of_joining)) : '';
            $row[] = ($customers->probation_date) ? date("d-m-Y", strtotime($customers->probation_date)) : '';
            $row[] = ($customers->department_name) ? $customers->department_name : '';
            $row[] = ($customers->position_name) ? $customers->position_name : '';
            $row[] = ($customers->reporting_manager_name) ? $customers->reporting_manager_name : '';
            $row[] = $RO;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Employeereportleft_model->count_all(),
            "recordsFiltered" => $this->Employeereportleft_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function ajax_list_newjoinreport() {
        $list = $this->empreportnewjoin->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            if (!empty($customers->reviewing_officer_ro)) {
                $results = $this->empreport->getUsernameByID($customers->reviewing_officer_ro);
                $RO = isset($results[0]->userfullname) ? $results[0]->userfullname : '';
            } else {
                $RO = '';
            }
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($customers->employeeId) ? $customers->employeeId : '';
            $row[] = ($customers->userfullname) ? $customers->userfullname : '';
            $row[] = ($customers->date_of_joining) ? date("d-m-Y", strtotime($customers->date_of_joining)) : '';
            $row[] = ($customers->probation_date) ? date("d-m-Y", strtotime($customers->probation_date)) : '';
            $row[] = ($customers->department_name) ? $customers->department_name : '';
            $row[] = ($customers->position_name) ? $customers->position_name : '';
            $row[] = ($customers->reporting_manager_name) ? $customers->reporting_manager_name : '';
            $row[] = $RO;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->empreportnewjoin->count_all(),
            "recordsFiltered" => $this->empreportnewjoin->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    //Left Employee Report Ajax
    public function ajax_list_empleftreport() {
        $list = $this->empreportleft->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            if (!empty($customers->reviewing_officer_ro)) {
                $results = $this->empreport->getUsernameByID($customers->reviewing_officer_ro);
                $RO = isset($results[0]->userfullname) ? $results[0]->userfullname : '';
            } else {
                $RO = '';
            }
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($customers->employeeId) ? $customers->employeeId : '';
            $row[] = ($customers->userfullname) ? $customers->userfullname : '';
            $row[] = ($customers->department_name) ? $customers->department_name : '';
            $row[] = ($customers->position_name) ? $customers->position_name : '';
            $row[] = ($customers->date_of_joining) ? date("d-m-Y", strtotime($customers->date_of_joining)) : '';
            $row[] = ($customers->date_of_leaving) ? date("d-m-Y", strtotime($customers->date_of_leaving)) : '';
            $row[] = ($customers->emp_status_name) ? $customers->emp_status_name : '';
            $row[] = ($customers->date_of_leaving) ? date("d-m-Y", strtotime($customers->date_of_leaving)) : '';
            $row[] = ($customers->empctc) ? number_format($customers->empctc, 2) : '';
            $row[] = ($customers->reporting_manager_name) ? $customers->reporting_manager_name : '';
            $row[] = $RO;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->empreportleft->count_all(),
            "recordsFiltered" => $this->empreportleft->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

//Educational Details
    public function ajax_list_empeducational_new() {
        $list = $this->educational_new->get_datatables();
        $data = array();
        $courseType = array('1' => 'Regular', '2' => 'Distance', '3' => 'Correspondence');
        $no = $_POST['start'];
        foreach ($list as $customers) {

            $empid = $customers->id;
            $eduRecArr1 = cegproj_edulvldetails($empid, '1');
            $eduRecArr2 = cegproj_edulvldetails($empid, '2');
            $eduRecArr3 = cegproj_edulvldetails($empid, '3');
            $eduRecArr4 = cegproj_edulvldetails($empid, '4');
            $eduRecArr5 = cegproj_edulvldetails($empid, '5');
            $eduRecArr6 = cegproj_edulvldetails($empid, '6');
            $eduRecArr7 = cegproj_edulvldetails($empid, '7');

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($customers->employeeId) ? $customers->employeeId : '';
            $row[] = ($customers->userfullname) ? $customers->userfullname : '';
            $row[] = ($customers->position_name) ? $customers->position_name : '';
            $row[] = ($customers->department_name) ? $customers->department_name : '';

            $row[] = ($eduRecArr1) ? $eduRecArr1->educationlevelcode : '';
            $row[] = ($eduRecArr1) ? $eduRecArr1->institution_name : '';
            $row[] = ($eduRecArr1) ? $courseType[$eduRecArr1->coursetype_id] : '';
            $row[] = ($eduRecArr1) ? $eduRecArr1->spc_location : '';
            $row[] = ($eduRecArr1) ? $eduRecArr1->specialization : '';
            $row[] = ($eduRecArr1) ? date("Y-m-d", strtotime($eduRecArr1->from_date)) : '';
            $row[] = ($eduRecArr1) ? $eduRecArr1->percentage : '';

            $row[] = ($eduRecArr2) ? $eduRecArr2->educationlevelcode : '';
            $row[] = ($eduRecArr2) ? $eduRecArr2->institution_name : '';
            $row[] = ($eduRecArr2) ? $courseType[$eduRecArr2->coursetype_id] : '';
            $row[] = ($eduRecArr2) ? $eduRecArr2->spc_location : '';
            $row[] = ($eduRecArr2) ? $eduRecArr2->specialization : '';
            $row[] = ($eduRecArr2) ? date("Y-m-d", strtotime($eduRecArr2->from_date)) : '';
            $row[] = ($eduRecArr2) ? $eduRecArr2->percentage : '';

            $row[] = ($eduRecArr3) ? $eduRecArr3->educationlevelcode : '';
            $row[] = ($eduRecArr3) ? $eduRecArr3->institution_name : '';
            $row[] = ($eduRecArr3) ? $courseType[$eduRecArr3->coursetype_id] : '';
            $row[] = ($eduRecArr3) ? $eduRecArr3->spc_location : '';
            $row[] = ($eduRecArr3) ? $eduRecArr3->specialization : '';
            $row[] = ($eduRecArr3) ? date("Y-m-d", strtotime($eduRecArr3->from_date)) : '';
            $row[] = ($eduRecArr3) ? $eduRecArr3->percentage : '';

            $row[] = ($eduRecArr4) ? $eduRecArr4->educationlevelcode : '';
            $row[] = ($eduRecArr4) ? $eduRecArr4->institution_name : '';
            $row[] = ($eduRecArr4) ? $courseType[$eduRecArr4->coursetype_id] : '';
            $row[] = ($eduRecArr4) ? $eduRecArr4->spc_location : '';
            $row[] = ($eduRecArr4) ? $eduRecArr4->specialization : '';
            $row[] = ($eduRecArr4) ? date("Y-m-d", strtotime($eduRecArr4->from_date)) : '';
            $row[] = ($eduRecArr4) ? $eduRecArr4->percentage : '';

            $row[] = ($eduRecArr5) ? $eduRecArr5->educationlevelcode : '';
            $row[] = ($eduRecArr5) ? $eduRecArr2->institution_name : '';
            $row[] = ($eduRecArr5) ? $courseType[$eduRecArr5->coursetype_id] : '';
            $row[] = ($eduRecArr5) ? $eduRecArr5->spc_location : '';
            $row[] = ($eduRecArr5) ? $eduRecArr5->specialization : '';
            $row[] = ($eduRecArr5) ? date("Y-m-d", strtotime($eduRecArr5->from_date)) : '';
            $row[] = ($eduRecArr5) ? $eduRecArr5->percentage : '';

            $row[] = ($eduRecArr6) ? $eduRecArr6->educationlevelcode : '';
            $row[] = ($eduRecArr6) ? $eduRecArr6->institution_name : '';
            $row[] = ($eduRecArr6) ? $courseType[$eduRecArr6->coursetype_id] : '';
            $row[] = ($eduRecArr6) ? $eduRecArr6->spc_location : '';
            $row[] = ($eduRecArr6) ? $eduRecArr6->specialization : '';
            $row[] = ($eduRecArr6) ? date("Y-m-d", strtotime($eduRecArr6->from_date)) : '';
            $row[] = ($eduRecArr6) ? $eduRecArr6->percentage : '';

            $row[] = ($eduRecArr7) ? $eduRecArr7->educationlevelcode : '';
            $row[] = ($eduRecArr7) ? $eduRecArr7->institution_name : '';
            $row[] = ($eduRecArr7) ? $courseType[$eduRecArr7->coursetype_id] : '';
            $row[] = ($eduRecArr7) ? $eduRecArr7->spc_location : '';
            $row[] = ($eduRecArr7) ? $eduRecArr7->specialization : '';
            $row[] = ($eduRecArr7) ? date("Y-m-d", strtotime($eduRecArr7->from_date)) : '';
            $row[] = ($eduRecArr7) ? $eduRecArr7->percentage : '';

            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->educational_new->count_all(),
            "recordsFiltered" => $this->educational_new->count_filtered(),
            "data" => $data,
        );

        echo json_encode($output);
    }

    //New Function For Salary 26-05-2018....
    public function ajax_list_empsalarydetails() {
        error_reporting(0);
        $list = $this->empsalary->get_datatables();

        $data = array();
        @$no = $_POST['start'];

        foreach ($list as $customers) {
            @$no++;
            $row = array();
            $row[] = @$no;
            $row[] = (@$customers->employeeId) ? @$customers->employeeId : '';
            $row[] = (@$customers->userfullname) ? @$customers->userfullname : '';
            $row[] = (@$customers->position_name) ? @$customers->position_name : '';
            $row[] = (@$customers->department_name) ? @$customers->department_name : '';
            $row[] = (@$customers->bankname) ? @$customers->bankname : '';
            $row[] = (@$customers->accountholder_name) ? @$customers->accountholder_name : '';
            $row[] = (@$customers->branchname) ? @$customers->branchname : '';
            $row[] = (@$customers->accountnumber) ? @$customers->accountnumber : '';
            $row[] = (@$customers->ifsc_code) ? @$customers->ifsc_code : '';
            $row[] = (@$customers->pancard_no) ? @$customers->pancard_no : '';
            $row[] = (@$customers->empctc) ? number_format(@$customers->empctc, 2) : '';
            $row[] = (@$customers->grosssalary) ? number_format(@$customers->grosssalary, 2) : '';
            $row[] = (@$customers->appraisal_datemmyy) ? date("d-m-Y", strtotime(@$customers->appraisal_datemmyy)) : '';
            $row[] = (@$customers->basicsalary) ? number_format(@$customers->basicsalary, 2) : '';
            $row[] = (@$customers->emp_hra) ? number_format(@$customers->emp_hra, 2) : '';
            $row[] = (@$customers->education_allowance) ? number_format(@$customers->education_allowance, 2) : '';
            $row[] = (@$customers->tele_empsal_allowance) ? number_format(@$customers->tele_empsal_allowance, 2) : '';
            $row[] = (@$customers->medical_allowance) ? number_format(@$customers->medical_allowance, 2) : '';
            $row[] = (@$customers->transportation_allowance) ? number_format(@$customers->transportation_allowance, 2) : '';
            $row[] = (@$customers->special_allowance) ? number_format(@$customers->special_allowance, 2) : '';
            $row[] = (@$customers->project_allowance) ? number_format(@$customers->project_allowance, 2) : '';
            $row[] = (@$customers->statutory_deduct) ? number_format(@$customers->statutory_deduct, 2) : '';
            $row[] = (@$customers->empepf) ? number_format(@$customers->empepf, 2) : '';
            $row[] = (@$customers->emp_esi) ? number_format(@$customers->emp_esi, 2) : '';
            $row[] = (@$customers->emp_gratuity) ? number_format(@$customers->emp_gratuity, 2) : '';
            $row[] = (@$customers->emp_sal_gpai) ? number_format(@$customers->emp_sal_gpai, 2) : '';
            $row[] = (@$customers->loyaltybonus) ? number_format(@$customers->loyaltybonus, 2) : '';
            $row[] = (@$customers->projectcomp_bonus) ? number_format(@$customers->projectcomp_bonus, 2) : '';
            $row[] = (@$customers->empctcp1) ? number_format(@$customers->empctcp1, 2) : '';
            $row[] = (@$customers->empctcp2) ? number_format(@$customers->empctcp2, 2) : '';
            $row[] = (@$customers->driver_wagers) ? number_format(@$customers->driver_wagers, 2) : '';
            $row[] = (@$customers->vehicle_agreement) ? number_format(@$customers->vehicle_agreement, 2) : '';
            $row[] = (@$customers->fuel_expenses) ? number_format(@$customers->fuel_expenses, 2) : '';
            $row[] = (@$customers->food_expenses) ? number_format(@$customers->food_expenses, 2) : '';
            $row[] = (@$customers->leave_travel_allowance) ? number_format(@$customers->leave_travel_allowance, 2) : '';
            $row[] = (@@$customers->sal_other) ? number_format(@$customers->sal_other, 2) : '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->empsalary->count_all(),
            "recordsFiltered" => $this->empsalary->count_filtered(),
            "data" => $data);
        echo json_encode($output);
        exit();
    }

    // Ajax Report Group of employee Designation
    public function ajax_list_empgroupreport() {
        $list = $this->jobgroupmodel->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($customers->position_name) ? $customers->position_name : '';
            $row[] = ($customers->jobtitle_name) ? $customers->jobtitle_name : '';
            $row[] = ($customers->total) ? $customers->total : '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->jobgroupmodel->count_all(),
            "recordsFiltered" => $this->jobgroupmodel->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    //Education And Experiance Details Ajax...
    public function ajax_list_empeduexp() {
        $list = $this->emprepeduexp->get_datatables();
        $data = array();
        $no = $_POST['start'];
        $currdate = date('d-m-Y');
        foreach ($list as $customers) {
            $locationName = get_locationBy_ID($customers->company_location);

            $years = 0;
            $months = 0;
            $diff = 0;
            $CountCegExp = 0;
            $countOtherExp = 0;
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($customers->employeeId) ? $customers->employeeId : '';
            $row[] = ($customers->userfullname) ? $customers->userfullname : '';
            $row[] = ($customers->position_name) ? $customers->position_name : '';
            $row[] = ($customers->department_name) ? $customers->department_name : '';
            $row[] = ($locationName) ? $locationName : '';
            $row[] = ($customers->jobtitle_name) ? $customers->jobtitle_name : '';
            //$row[] = ($customers->selecteddate) ? date("d-m-Y", strtotime($customers->selecteddate)) : '';
            $selecteddate = ($customers->selecteddate) ? date("d-m-Y", strtotime($customers->selecteddate)) : '';
            $diff = abs(strtotime($selecteddate) - strtotime($currdate));
            $years = floor($diff / (365 * 60 * 60 * 24));
            $months = floor(($diff - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));

            $CountCegExp = $years . '.' . $months;
            $countOtherExp = round($this->get_total_otherexp($customers->id), 1);
            $row[] = $CountCegExp;
            $row[] = $countOtherExp;
            $row[] = ($customers->years_exp) ? $customers->years_exp : '';
            // $row[] = ($CountCegExp + $countOtherExp);

            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->emprepeduexp->count_all(),
            "recordsFiltered" => $this->emprepeduexp->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function ajax_list_empeducational() {
        $list = $this->educational->get_datatables();
        $data = array();
        $courseType = array('1' => 'Regular', '2' => 'Distance', '3' => 'Correspondence');
        $no = $_POST['start'];
        foreach ($list as $customers) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($customers->employeeId) ? $customers->employeeId : '';
            $row[] = ($customers->userfullname) ? $customers->userfullname : '';
            $row[] = ($customers->position_name) ? $customers->position_name : '';
            $row[] = ($customers->department_name) ? $customers->department_name : '';
            $row[] = ($customers->educationlevelcode) ? $customers->educationlevelcode : '';
            $row[] = ($customers->institution_name) ? $customers->institution_name : '';
            $row[] = ($customers->coursetype_id) ? $courseType[$customers->coursetype_id] : '';
            $row[] = ($customers->spc_location) ? $customers->spc_location : '';
            $row[] = ($customers->specialization) ? $customers->specialization : '';
            $row[] = ($customers->from_date) ? date("Y-m-d", strtotime($customers->from_date)) : '';
            $row[] = ($customers->percentage) ? $customers->percentage : '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->educational->count_all(),
            "recordsFiltered" => $this->educational->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    //Get Total Exp.
    public function get_total_otherexp($empid) {
        $getmonth = 0;
        $otherExpArr = $this->mastermodel->GetTableData('main_empexperiancedetails', array('user_id' => $empid, 'isactive' => '1'));
        if ($otherExpArr):
            foreach ($otherExpArr as $recRw) {
                $getmonth += getDateDiffMonth($recRw->from_date, $recRw->to_date);
            }
            return ($getmonth > 0) ? number_format(($getmonth / 12), 2) : 0;
        else:
            return 0;
        endif;
    }

    //1 March 2019...
    public function ajax_list_empreport_new() {
        $genderArr = array('1' => 'Male', '2' => 'Female', '3' => 'Other');
        $list = $this->apprempreport->get_datatables();

        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {
            $no++;

            $row = array();
            $row[] = $no;
            $row[] = '';
            $row[] = '';
            $row[] = '';
            $row[] = '';
            $row[] = '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->apprempreport->count_all(),
            "recordsFiltered" => $this->apprempreport->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    //Notice Period Report By Asheesh..
    public function notice_period() {
        $data['error'] = array();
        $data['title'] = "Employee Notice Period Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('user_id');
        if (!is_null($user_id)) {
            $this->load->view('new_report/emp_list_noticeperiod_view', $data);
        } else {
            redirect('admin', true);
        }
    }

    //Notice Period Report DataTable Ajax..
    public function ajax_list_empnoticeperiodrep() {
        $list = $this->empnoticeperiodreport->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $customers) {

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = ($customers->businessunit_name) ? $customers->businessunit_name : '';
            $row[] = ($customers->company_name) ? $customers->company_name : '';
            $row[] = ($customers->employeeId) ? $customers->employeeId : '';
            $row[] = ($customers->userfullname) ? $customers->userfullname : '';
            $row[] = ($customers->position_name) ? $customers->position_name : '';
            $row[] = ($customers->department_name) ? $customers->department_name : '';
            $row[] = ($customers->date_of_joining) ? date("d-m-Y", strtotime($customers->date_of_joining)) : '';
            $row[] = ($customers->noticeperiod) ? $customers->noticeperiod : '';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->empreportnewjoin->count_all(),
            "recordsFiltered" => $this->empreportnewjoin->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    //List View Of Group and Emp job Location Asheesh ... 
    public function empjob_grouplocation_list() {
        $locID = $this->uri->segment(2);
        $groupID = $this->uri->segment(3);
        if ($locID == "" or $groupID == "") {
            redirect(base_url("company_jobtitle_report"));
        }
        $title = "Employee job Group & Location List";
        $this->load->view('new_report/empjob_grouplocation_list', compact('title', 'locID', 'groupID'));
    }

    //code by Asheesh(27-08-2019)
    public function employee_company_group_report() {
        $title = "Company or Group";
        $this->load->view('new_report/emp_company_group_report', compact('title'));
    }

    // code by Asheesh(27-08-2019)
    public function ajax_list_empjobgroupreport() {
        // $list = $this->companyjobgroupmodel->get_datatables();
        $list = array("1" => "Jaipur", "2" => "New Delhi", "4" => "Bengaluru", "5" => "Mumbai", "77" => "Project");
        $data = array();
        $no = $_POST['start'];
        $recData = array();
        foreach ($list as $kkeY => $rOws) {
            $no++;
            $GroupNumA = $this->countemponlocation($kkeY, "8");
            $GroupNumB = $this->countemponlocation($kkeY, "9");
            $GroupNumC = $this->countemponlocation($kkeY, "10");
            $GroupNumD = $this->countemponlocation($kkeY, "11");
            $GroupNumE = $this->countemponlocation($kkeY, "12");
            $GroupNumF = $this->countemponlocation($kkeY, "13");

            $row = array();
            $row[] = $no;
            $row[] = $rOws;
            $row[] = "<a style='color:black' href='" . base_url("empjob_grouplocation_list/" . $kkeY . "/8") . "'>" . $GroupNumA . "</a>";
            $row[] = "<a style='color:black' href='" . base_url("empjob_grouplocation_list/" . $kkeY . "/9") . "'>" . $GroupNumB . "</a>";
            $row[] = "<a style='color:black' href='" . base_url("empjob_grouplocation_list/" . $kkeY . "/10") . "'>" . $GroupNumC . "</a>";
            $row[] = "<a style='color:black' href='" . base_url("empjob_grouplocation_list/" . $kkeY . "/11") . "'>" . $GroupNumD . "</a>";
            $row[] = "<a style='color:black' href='" . base_url("empjob_grouplocation_list/" . $kkeY . "/12") . "'>" . $GroupNumE . "</a>";
            $row[] = "<a style='color:black' href='" . base_url("empjob_grouplocation_list/" . $kkeY . "/13") . "'>" . $GroupNumF . "</a>";
            $data[] = $row;
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => count($list),
            "recordsFiltered" => count($list),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function ajax_list_empjobgrouplocationlist() {
        $jobLocationId = $this->uri->segment(2);
        $JobGroupID = $this->uri->segment(3);
        $list = $this->viewdetailsemponlocation($jobLocationId, $JobGroupID);
        $data = array();
        $no = $_POST['start'];
        $recData = array();
        foreach ($list as $kkeY => $rOws) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $rOws->businessunit_name;
            $row[] = $rOws->prefix_name . " " . $rOws->userfullname;
            $row[] = $rOws->employeeId;
            $row[] = ($rOws->date_of_joining) ? date("d-m-Y", strtotime($rOws->date_of_joining)) : "";
            $row[] = $rOws->jobtitle_name;
            $row[] = $rOws->department_name;
            $row[] = $rOws->position_name;
            $row[] = $rOws->reporting_manager_name;
            $data[] = $row;
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => count($list),
            "recordsFiltered" => count($list),
            "data" => $data,
        );
        echo json_encode($output);
    }

    // code by Asheesh(27-08-2019)
    public function countemponlocation($compLocID, $groupID) {
        if ($compLocID == 77) {
            $this->db->select("a.userfullname");
            $this->db->from("main_employees_summary as a");
            $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
            $this->db->where(array("a.isactive" => "1", "b.status" => "1", "a.businessunit_id" => "3", "a.jobtitle_id" => $groupID));
            $this->db->group_by("a.user_id");
            $recArr2 = $this->db->get()->num_rows();
            return ($recArr2) ? $recArr2 : '0';
        }
        $this->db->select("a.userfullname");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->where(array("a.isactive" => "1", "b.status" => "1", "b.company_location" => $compLocID, "a.jobtitle_id" => $groupID));
        $this->db->group_by("a.user_id");
        $recArr = $this->db->get()->num_rows();
        return ($recArr) ? $recArr : '0';
    }

    public function viewdetailsemponlocation($compLocID, $groupID) {
        if ($compLocID == 77) {
            $this->db->select("a.reporting_manager_name,a.position_name,a.department_name,a.prefix_name,a.userfullname,a.businessunit_name,a.employeeId,a.date_of_joining,a.jobtitle_name");
            $this->db->from("main_employees_summary as a");
            $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
            $this->db->where(array("a.isactive" => "1", "b.status" => "1", "a.businessunit_id" => "3", "a.jobtitle_id" => $groupID));
            $this->db->group_by("a.user_id");
            $recArr2 = $this->db->get()->result();
            return ($recArr2) ? $recArr2 : null;
        }
        $this->db->select("a.reporting_manager_name,a.position_name,a.department_name,a.prefix_name,a.userfullname,a.businessunit_name,a.employeeId,a.date_of_joining,a.jobtitle_name");
        $this->db->from("main_employees_summary as a");
        $this->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
        $this->db->where(array("a.isactive" => "1", "b.status" => "1", "b.company_location" => $compLocID, "a.jobtitle_id" => $groupID));
        $this->db->group_by("a.user_id");
        $recArr = $this->db->get()->result();
        return ($recArr) ? $recArr : null;
    }

    //Reward And Award..
    public function ajax_list_rewardandaward() {
        $list = $this->emprewardmodel->get_datatables();
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $rows) {
            if ($rows->reporting_manager > 0):
                $FormrecdArr = $this->GetAllAssignForms($rows->reporting_manager);
                $no++;
                $row = array();
                $row[] = $no;
                $row[] = $rows->employeeId;
                $row[] = $rows->prefix_name . " " . $rows->userfullname;
                $row[] = $rows->department_name;
                $row[] = $rows->position_name;
                $row[] = ($FormrecdArr['forms']) ? $FormrecdArr['forms'] : "";
                $row[] = ($FormrecdArr['entryby']) ? $FormrecdArr['entryby'] . "<br>" . $FormrecdArr['date'] : "";
                $row[] = '<button class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal" title="Assign" onclick="assignrewardform(' . "'" . $rows->reporting_manager . "'" . ')">Assign</button>';
                $data[] = $row;
            endif;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->emprewardmodel->count_all(),
            "recordsFiltered" => $this->emprewardmodel->count_filtered(),
            "data" => $data,
        );
        //output to json format
        echo json_encode($output);
    }

    public function GetAllAssignForms($user_id) {
        $returnFormsNm = '';
        $this->db->select("a.assign_date,a.from_no_id,b.categ_group_name,c.userfullname");
        $this->db->from("award_assign_group_form_user as a");
        $this->db->join("award_group_master as b", "a.from_no_id=b.fld_id", "LEFT");
        $this->db->join("main_employees_summary as c", "a.entry_by=c.user_id", "LEFT");
        $this->db->where(array("a.status" => "1", "a.user_id" => $user_id));
        $recArr2 = $this->db->get()->result();
        if ($recArr2) {
            foreach ($recArr2 as $reCd) {
                $returnFormsNm .= $reCd->categ_group_name . ",<br>";
            }
        }
        return(["forms" => $returnFormsNm, "date" => ($recArr2[0]->assign_date) ? date("d-m-Y", strtotime($recArr2[0]->assign_date)) : '', "entryby" => $recArr2[0]->userfullname]);
    }

    //Get All Assign Form IDs..
    public function get_all_assign_formids_ajax() {
        $user_id = $_REQUEST['empuser_id'];
        //$user_id = 199;
        $this->db->select("a.from_no_id");
        $this->db->from("award_assign_group_form_user as a");
        $this->db->where(array("a.status" => "1", "a.user_id" => $user_id));
        $recArr2 = $this->db->get()->result();
        if ($recArr2) {
            foreach ($recArr2 as $reCd) {
                $returnFormsNm[] = $reCd->from_no_id;
            }
        }
        echo ($returnFormsNm) ? json_encode($returnFormsNm) : '';
    }

    //Code By Asheesh 21-10-2020..
    //############################################
    //CEG Project Appraisal List Report....
    public function ceg_project_appr_report() {
        $data['title'] = "CEG Project Appraisal Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');
        $data['SessionMasterArr'] = $this->appr_sessionList();
        $data['ReportingManagerArr'] = $this->apprcegproject_ReportingManagerList();

        if (!is_null($user_id)) {
            $this->load->view('new_report/ceg_project_appr_report_view', $data);
        } else {
            redirect('admin', true);
        }
    }

    public function ajax_list_ceg_project_appr_report() {
        $list = $this->apprproject->get_datatables();
        $data = array();
        $no = $_POST['start'];
        $statusArr = array("1" => "<span style='color:green'>Fill by IO</span>", "2" => "<span style='color:green'>Lock by IO</span>", "3" => "<span style='color:green'>Lock by RO</span>", "4" => "<span style='color:green'>Lock by RO</span>");

        foreach ($list as $customers) {
            if (($customers->bc_current_status == "") and ( $customers->de_current_status == "")) {
                $bc_status = "<span style='color:red'>Fill Pending</span>";
                $de_status = "<span style='color:red'>Fill Pending</span>";
            } else {
                $bc_status = '';
                $de_status = '';
            }
            if ($customers->bc_current_status):
                $bc_status = $statusArr[$customers->bc_current_status];
            endif;
            if ($customers->de_current_status):
                $de_status = $statusArr[$customers->de_current_status];
            endif;

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = '10-2020 (<b>' . $customers->jobtitle_name . "</b>)";
            $row[] = $customers->userfullname . " [ " . $customers->employeeId . " ] ";
            $row[] = $customers->reporting_manager_name;
            $row[] = $bc_status;
            $row[] = $de_status;
            $row[] = $customers->appraisalduedate;
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->apprproject->count_all(),
            "recordsFiltered" => $this->apprproject->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function appr_sessionList() {
        $this->db->select("a.appr_session,a.fld_id");
        $this->db->from("appr_proj_assignbyhr as a");
        $this->db->where("a.status", "1");
        $this->db->group_by("a.appr_session");
        $recordArr = $this->db->get()->result();
        return ($recordArr) ? $recordArr : null;
    }

    public function apprcegproject_ReportingManagerList() {
        $this->db->select("a.rep_manager_id,a.fld_id,b.userfullname,b.employeeId");
        $this->db->from("appr_proj_assignbyhr as a");
        $this->db->join("main_employees_summary as b", "a.rep_manager_id=b.user_id", "LEFT");
        $this->db->where("a.status", "1");
        $this->db->group_by("a.rep_manager_id");
        $this->db->order_by("b.userfullname", "ASC");
        $recordArr = $this->db->get()->result();
        return ($recordArr) ? $recordArr : null;
    }

    //22-10-2020 ................................
    //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

    public function project_mm_report() {
        $data['title'] = "Project MM Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');

        if (!is_null($user_id)) {
            $this->load->view('new_report/projectmm_report_view', $data);
        } else {
            redirect('admin', true);
        }
    }

    public function ajax_list_ceg_project_mm_report() {
        $list = $this->accdeptmodel->get_datatables();
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $customers) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $customers->project_name;
            $row[] = '<a href="' . base_url('view_project_mm/' . $customers->id) . '"><button class="btn btn-info btn-sm" title="View" >View</button></a>';
            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->accdeptmodel->count_all(),
            "recordsFiltered" => $this->accdeptmodel->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    //View Single Project MM..
    public function view_project_mm($hrmsProjID) {
        $this->load->model("Accountdept_model");
        $data['title'] = "Single Project MM Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');

        if ($hrmsProjID) {
            $data['ProjectInfoArr'] = $this->Accountdept_model->GetAccountInfoData($hrmsProjID);
            $data['DesignationCategArr'] = $this->Accountdept_model->GetProjectDesignCategByProjID($hrmsProjID);
            $data['DesignationListArr'] = $this->Accountdept_model->GetProjectDesignationListArr($hrmsProjID);      
        }
        if (!is_null($user_id)) {
            $this->load->view('new_report/single_project_mm_report_view', $data);
        } else {
            redirect('admin', true);
        }
    }
	
	//View Experiance Report..
    public function emp_job_history_report_view() {
		// echo "test"; die;
        $data['title'] = "Single Project MM Report";
        $role = $this->session->userdata('emprole');
        $user_id = $this->session->userdata('loginid');
		$this->load->view('new_report/emp_job_history_report_view', $data);
    }
	
	//=========== Job History Of Emp Report =====================
	public function job_exp_history_report_ajax() {
        $list = $this->job_exp_history_report_model->get_datatables();
		
		// echo "<pre>"; print_r($_REQUEST); die;
        $data = array();
        $no = $_POST['start'];
		// echo "<pre>"; print_r($list); die;
        foreach ($list as $val) {
			$comName = get_company_nameBy_id($val->users_id);
            $no++;
            $row = array();
			if($comName != 'grv'):
				foreach($comName as $comVal):
					$row[] = $no;
					$row[] = ($val->userfullname) ? $val->userfullname : "--";
					$row[] = ($val->employeeId) ? $val->employeeId : "--";
					$row[] = ($val->businessunit_name) ? $val->businessunit_name : "--";
					$row[] = ($val->payrollcode) ? $val->payrollcode : "--";
					$row[] = ($comVal->company_name) ? $comVal->company_name : "--";
					
				$data[] = $row;
				endforeach;
			else:
				$row[] = $no;
				$row[] = ($val->userfullname) ? $val->userfullname : "--";
				$row[] = ($val->employeeId) ? $val->employeeId : "--";
				$row[] = ($val->businessunit_name) ? $val->businessunit_name : "--";
				$row[] = ($val->payrollcode) ? $val->payrollcode : "--";
				$row[] = "--";
				$data[] = $row;
			endif;
			
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->job_exp_history_report_model->count_all(),
            "recordsFiltered" => $this->job_exp_history_report_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

}
