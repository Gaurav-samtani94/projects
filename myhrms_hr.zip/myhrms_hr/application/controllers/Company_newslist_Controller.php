<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
class Company_newslist_Controller extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->library('form_validation');
		if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$this->load->model("News_list_model","News_list_model");
    }

    public function news_list(){
		$data['title'] = "News List";
		$data['GetAllCompanyNews'] = $this->News_list_model->GetAllCompanyNews();
		$this->load->view("/company_news/company_news_view",$data);	
	}
	
	public function news_add(){
		$id = $this->session->userdata('loginid');
        $news_category = $_REQUEST['news_category'];
		$title = $_REQUEST['title'];
        $description = $_REQUEST['description'];
        $expiry_date = $_REQUEST['expiry_date'];
        $show_in_headline = $_REQUEST['show_in_headline'];
        $mark_important = $_REQUEST['mark_important'];
		if($_FILES['doc_file']['name']!=''){
			$config = array(
				'upload_path' => "public/uploads/company_news/",
				'allowed_types' => "gif|jpg|png|jpeg|pdf|doc|docx|xls|xlsx|ppt|pptx|csv",
				'overwrite' => TRUE,
				'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
				'encrypt_name' => FALSE,
			);
		
			$array = explode('.', $_FILES['doc_file']['name']);
			$extension = end($array);
			$new_name = 'news_'.time().'.'.$extension;
			$config['file_name'] = $new_name;
			$this->load->library('upload', $config);
		
			if($this->upload->do_upload('doc_file')){
				$data = array(
					'news_category' => $news_category,
					'show_headline' => ($show_in_headline) ? "1" : "2",
					'mark_important_new' => ($mark_important) ? "1" : "2",
					'title' => $title,
					'description' => $description,
					'doc_file' => $new_name,  
					'Expiry_date' => $expiry_date,  
					'created_by' => $id,  
					'is_active' => "1",  
				);
				$insert_arr = $this->db->insert('main_companynews', $data);	
				if ($insert_arr){
					$this->session->set_flashdata('success_msg', 'News Added Successfully !');
					redirect(base_url('news_list'));
				}else{
					$this->session->set_flashdata('error_msg', 'Something went gone wrong');
					redirect(base_url('news_list'));
				}	
				}else{
					$this->session->set_flashdata('error_msg', 'Document Upload Failed !!');
					redirect(base_url('news_list'));
				}
		}else{
			$data = array(
					'news_category' => $news_category,
					'show_headline' => ($show_in_headline) ? "1" : "2",
					'mark_important_new' => ($mark_important) ? "1" : "2",
					'title' => $title,
					'description' => $description,
					'doc_file' => "",  
					'Expiry_date' => $expiry_date,  
					'created_by' => $id,  
					'is_active' => "1",  
				);
			$insert_arr = $this->db->insert('main_companynews', $data);	
			if ($insert_arr){
				$this->session->set_flashdata('success_msg', 'News Added Successfully !');
				redirect(base_url('news_list'));
			}else{
				$this->session->set_flashdata('error_msg', 'Something went gone wrong');
				redirect(base_url('news_list'));
			}
		}
	}
	
	public function ajax_getsinglenews_id(){
		$news_id = $_REQUEST['news_id'];
        if ($news_id) {
            $singleRecNews = $this->News_list_model->GetSingleNewsDetailsByID($news_id);
        }
        echo json_encode($singleRecNews);
	}
	
	public function news_update(){
		$news_id = $_REQUEST['news_id'];
		$id = $this->session->userdata('loginid');
		$news_category = $_REQUEST['edit_news_category'];
        $title = $_REQUEST['edit_title'];
        $description = $_REQUEST['edit_description'];
        $expiry_date = $_REQUEST['edit_expiry_date'];
		$show_in_headline = $_REQUEST['edit_show_in_headline'];
        $mark_important = $_REQUEST['edit_mark_important'];
	
		if($_FILES['edit_doc_file']['name']!=''){
			$config = array(
				'upload_path' => "public/uploads/company_news/",
				'allowed_types' => "gif|jpg|png|jpeg|pdf|doc|docx|xls|xlsx|ppt|pptx|csv",
				'overwrite' => TRUE,
				'max_size' => "2048000", // Can be set to particular file size , here it is 2 MB(2048 Kb)
				'encrypt_name' => FALSE,
			);
			$array = explode('.', $_FILES['edit_doc_file']['name']);
			$extension = end($array);
			$new_name = 'news_'.time().'.'.$extension;
			$config['file_name'] = $new_name;
			$this->load->library('upload', $config);
			if($this->upload->do_upload('edit_doc_file')){
				$updArr = array(
					'news_category' => $news_category,
					'show_headline' => ($show_in_headline) ? "1" : "2",
					'mark_important_new' => ($mark_important) ? "1" : "2",
					'title' => $title,
					'description' => $description,
					'doc_file' => $new_name, 
					'Expiry_date' => $expiry_date,  				
					'is_active' => "1",  
					'update_date' => date("Y-m-d H:i:s"), 
					'update_by' => $id, 
				);
				$this->db->where(['id' => $news_id]);
				$returnResp = $this->db->update('main_companynews', $updArr);
				if ($returnResp){
					$this->session->set_flashdata('success_msg', 'News Edit/Updated Successfully !');
					redirect(base_url('news_list'));
				}else{
					$this->session->set_flashdata('error_msg', 'Something went gone wrong');
					redirect(base_url('news_list'));
				
				}
			}
		}else{
			$updArr = array(
					'news_category' => $news_category,
					'show_headline' => ($show_in_headline) ? "1" : "2",
					'mark_important_new' => ($mark_important) ? "1" : "2",
					'title' => $title,
					'description' => $description,
					'doc_file' => $new_name, 
					'Expiry_date' => $expiry_date,  				
					'is_active' => "1",  
					'update_date' => date("Y-m-d H:i:s"), 
					'update_by' => $id, 
			);
			$this->db->where(['id' => $news_id]);
			$returnResp = $this->db->update('main_companynews', $updArr);
			if ($returnResp){
				$this->session->set_flashdata('success_msg', 'News Edit/Updated Successfully !');
				redirect(base_url('news_list'));
			}else{
				$this->session->set_flashdata('error_msg', 'Something went gone wrong');
				redirect(base_url('news_list'));
			
			}
		}
	}
	
	public function news_delete($news_id){
        $updateArr = array("is_active" => "2");
        $this->db->where('id',$news_id);
        $returnResp = $this->db->update('main_companynews', $updateArr);
        if ($returnResp):
            $this->session->set_flashdata('success_msg', 'News Deleteted Successfully.');
        endif;
        redirect(base_url("news_list"));
	}

	public function news_view($news_id){
        if ($news_id!='') {
			$data['title'] = "News";
			$data['singleRecNews'] = $this->News_list_model->GetSingleNewsDetailsByID($news_id);
			$this->load->view("/company_news/company_news_singleview",$data);	
        }
	}
}
