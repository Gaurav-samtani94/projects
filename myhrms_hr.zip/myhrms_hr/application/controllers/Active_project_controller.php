<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Active_project_controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('All_active_projects_model');
        $this->load->model('mastermodel');
        $this->load->model('Visiting_card_model');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		
    }

    public function active_project_list() {
		$projArr = array('15','16','113','114','115','116','117','119','121','130','131','132','233','234','237','255','234');
		$data['title'] = "New View";
		$this->db->select("project_name,project_status");
		$this->db->from("tm_projects");
		$this->db->where(array("is_active" => "1"));
		$this->db->where_not_in('id',$projArr);
		$this->db->order_by("project_name","asc");
		$result = $this->db->get()->result();
        $data['title'] = "All Projects";
        $data['all_projects'] = $result;
        $this->load->view("all_project_list/project_list_view", $data);
    }
	
	public function ajax_all_active_projects() {
		$list = $this->All_active_projects_model->get_datatables();
		$srn = $_POST['start'];
		$data = array();
		if($list){
			foreach($list as $val){
				$srn++;
				$row = array();
				$row[] = $srn;
				$row[] = ($val->project_name) ? $val->project_name : "--";
				$row[] = ($val->project_status) ? $val->project_status : "--";
				$row[] = ($val->start_date) ? date('d-m-Y',strtotime($val->start_date)) : "--";
				$row[] = ($val->end_date) ? date('d-m-Y',strtotime($val->end_date)) : "--";
				$data[] = $row;
			}
		}
		$output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->All_active_projects_model->count_all(),
            "recordsFiltered" => $this->All_active_projects_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
		
	}
	
	public function getAllPRojects() {
		error_reporting(0);
		$projArr = array('15','16','113','114','115','116','117','119','121','130','131','132','233','234','237','255','234');
		$this->db->select("project_name,project_status");
		$this->db->from("tm_projects");
		$this->db->where(array("is_active" => "1"));
		$this->db->where_not_in('id',$projArr);
		$this->db->order_by("project_name","asc");
		$result = $this->db->get()->result();
		
		$data = array();
		$count=0;
		foreach($result as $value):
			$row = array();
			$row[] = $count+1;
            $row[] = $value->project_name;
			$data[] = $row;
			
			$count++;
		endforeach;
		$output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => '0',
            "recordsFiltered" => '0',
            "data" => $data,
        );
        echo json_encode($output);
		exit;
	}

}
