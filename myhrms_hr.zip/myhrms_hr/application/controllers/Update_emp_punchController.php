<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Update_emp_punchController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Update_emp_punchModel');
        $this->load->model('attendance_report/Attendnacereportleave');
        $this->load->model('attendance_report/Attendnacereporttour');
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function update_punch() {
        $title = 'Attendance Report';
        $jobtitle = $this->db->get_where('main_jobtitles', array('isactive' => '1'))->result();
        $business_title = $this->db->get_where('main_businessunits', array('isactive' => '1'))->result();
		// $punchTime = get_in_out_time();
		// echo "<pre>"; print_r($punchTime); die;
        $this->load->view('update_emp_punch_view', compact('title', 'jobtitle', 'business_title'));
    }
	
	
	 //Ajax List.. Attendance Report..
    public function ajax_update_punch_report() {
        $no = 1;
        $list = $this->Update_emp_punchModel->get_datatables();
        $data = array();
        $no = $_POST['start'];
		$direction = 'in';
        foreach ($list as $recemp) {
			$Dispdate = date("d-m-Y");
			$punchRec = getSingleDateAttByUserID($Dispdate, $recemp->machine_id);
            $punchTime = get_punchTime_byMachineID($recemp->machine_id,$direction);
			if($punchTime != null): 
			$inTime = date('h:i',strtotime($punchTime));
			else: 
			 $inTime = ""; 
			endif;
				$no ++;
				$row = array();
				$row[] = $no;
				$row[] = $recemp->employeeId;
				$row[] = $recemp->userfullname;
				$row[] = $recemp->department_name;
				$row[] = '<span id="msg_' . $recemp->user_id . '" class="alert alert-success alert-dismissible" style="display:none;"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success ! </strong></span><input style="width:150px;" autocomplete="off" placeholder="Ex. 09:15:35 AM" type="time" name="Intime_' . $recemp->user_id . '" id="Intime_' . $recemp->user_id . '" class="form-control" value="'. $inTime.'">';
				// $row[] = '<input style="width:150px;" autocomplete="off" placeholder="Update Out Time" type="text" name="Outtime_' . $recemp->user_id . '" id="Outtime_' . $recemp->user_id . '" class="form-control" value="'.(@$punchRec['outtime']) .'">';
				$row[] =  '<input style="width:150px;" autocomplete="off" placeholder="NA" type="text" name="machine_' . $recemp->user_id . '" id="machine_' . $recemp->user_id . '" class="form-control" value="'.($recemp->machine_id) .'" readonly>';
				$row[] = '<button type="submit" onclick="update_punch_time(' . $recemp->user_id . ')" class="btn btn-info">Update</button>';
				
				$data[] = $row;
        } 
		
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Update_emp_punchModel->count_all(),
            "recordsFiltered" => $this->Update_emp_punchModel->count_filtered(),
            "data" => $data
           );
        echo json_encode($output);
    }
	

	//Ajax List.. Attendance Report..
    public function ajax_update_outPunch_report() {
        $no = 1;
        $list = $this->Update_emp_punchModel->get_datatables();
        $data = array();
        $no = $_POST['start'];
		$direction = 'out';
        foreach ($list as $recemp) {
			$Dispdate = date("d-m-Y");
			$punchRec = getSingleDateAttByUserID($Dispdate, $recemp->machine_id);
            $punchTime = get_punchTime_byMachineID($recemp->machine_id,$direction);
			if($punchTime != null): 
			$outTime = date('h:i',strtotime($punchTime));
			else: 
			 $outTime = ""; 
			endif;
				$no ++;
				$row = array();
				$row[] = $no;
				$row[] = $recemp->employeeId;
				$row[] = $recemp->userfullname;
				$row[] = $recemp->department_name;
				$row[] = '<span id="msgs_' . $recemp->user_id . '" class="alert alert-success alert-dismissible" style="display:none;"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success ! </strong></span><input style="width:150px;" autocomplete="off" placeholder="Ex. 06:05:50 PM" type="time" name="Outtime_' . $recemp->user_id . '" id="Outtime_' . $recemp->user_id . '" class="form-control" value="'.$outTime.'">';
				// $row[] = '<input style="width:150px;" autocomplete="off" placeholder="Update Out Time" type="text" name="Outtime_' . $recemp->user_id . '" id="Outtime_' . $recemp->user_id . '" class="form-control" value="'.(@$punchRec['outtime']) .'">';
				$row[] =  '<input style="width:150px;" autocomplete="off" placeholder="NA" type="text" name="machine_' . $recemp->user_id . '" id="machine_' . $recemp->user_id . '" class="form-control" value="'.($recemp->machine_id) .'" readonly>';
				$row[] = '<button type="submit" onclick="update_punchOut_time(' . $recemp->user_id . ')" class="btn btn-info">Update</button>';
				
				$data[] = $row;
        } 
		
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->Update_emp_punchModel->count_all(),
            "recordsFiltered" => $this->Update_emp_punchModel->count_filtered(),
            "data" => $data
           );
        echo json_encode($output);
    }
	
	public function updateInTime() {
        $empid = $_REQUEST['empid'];
		$id=$this->session->userdata('loginid');
        $In_time = $_REQUEST['In_time'];
        $Out_time = $_REQUEST['Out_time'];
        $machine_id = $_REQUEST['machine_id'];
		// echo $machine_id.", ".$Out_time; die;
        if ($In_time or $Out_time) {
			// echo "test"; die;
			$today = date('Y-m-d',strtotime("-1 days"));
			$today_withTime = date('Y-m-d h:i:sa');
			$recArr = array(
				'DownloadDate' => $today_withTime,
				'DeviceId' => '6',
				'UserId' => $machine_id,
                'LogDate' => $today.' '.$In_time.':00 AM',
                'Direction' => 'in',
                'AttDirection' => '',
                'C1' => 'in',
                'C2' => '0',
                'C3' => '0',
                'C4' => '10',
                'C5' => '0',
                'C6' => '0',
                'C7' => '0',
                'WorkCode' => '0',
            );
			$this->db->where(array('UserId'=>$machine_id,'C4'=>'10','Direction'=>'in'));
			$rec = $this->db->get('DeviceLogs_Processed')->num_rows();
			if($rec > 0){
				$data = array(
					'LogDate' => $today.' '.$In_time.':00 AM',
					);
				$this->db->where(array('UserId'=>$machine_id,'C4'=>'10','Direction'=>'in'));
				$respp = $this->db->update('DeviceLogs_Processed',$data);
			}
			else{
				$respp = $this->db->insert('DeviceLogs_Processed',$recArr);
			}
			
            echo json_encode($respp);
        }
    }
	
	
	public function updateOutTime() {
        $empid = $_REQUEST['empid'];
		$id=$this->session->userdata('loginid');
        // $In_time = $_REQUEST['In_time'];
        $Out_time = $_REQUEST['Out_time'];
        $machine_id = $_REQUEST['machine_id'];
		// echo $machine_id.", ".$Out_time; die;
        if ($In_time or $Out_time) {
			// echo "test"; die;
			$today = date('Y-m-d',strtotime("-1 days"));
			$today_withTime = date('Y-m-d h:i:sa');
			$recArr = array(
				'DownloadDate' => $today_withTime,
				'DeviceId' => '6',
				'UserId' => $machine_id,
                'LogDate' => $today.' '.$Out_time.':00 AM',
                'Direction' => 'out',
                'AttDirection' => '',
                'C1' => 'out',
                'C2' => '0',
                'C3' => '0',
                'C4' => '10',
                'C5' => '0',
                'C6' => '0',
                'C7' => '0',
                'WorkCode' => '0',
            );
			$this->db->where(array('UserId'=>$machine_id,'C4'=>'10','Direction'=>'out'));
			$rec = $this->db->get('DeviceLogs_Processed')->num_rows();
			if($rec > 0){
				$data = array(
					'LogDate' => $today.' '.$Out_time.':00 AM',
					);
				$this->db->where(array('UserId'=>$machine_id,'C4'=>'10','Direction'=>'out'));
				$respp = $this->db->update('DeviceLogs_Processed',$data);
			}
			else{
				$respp = $this->db->insert('DeviceLogs_Processed',$recArr);
			}
            echo json_encode($respp);
        }
    }
	
}

?>