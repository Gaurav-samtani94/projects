<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Department_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
       $this->load->model('Mastermodel');
       $this->load->model('Department/Department_model');
       if($this->session->userdata('loginid') == '')
       {
        redirect(base_url(''));
       }
    }
    public function index()
    {
       
		 $this->form_validation->set_rules('deptname', 'Department Name', 'required|is_unique[main_departments.deptname]');
   
    $this->form_validation->set_rules('deptcode', 'Department Code', 'required|is_unique[main_departments.deptcode]');
    $this->form_validation->set_rules('description', 'Department description', 'required');
    $this->form_validation->set_rules('startdate', 'Start date', 'required');
    $this->form_validation->set_rules('country', 'Country', 'required');
    $this->form_validation->set_rules('state', 'State', 'required');
    $this->form_validation->set_rules('city', 'City', 'required');
    $this->form_validation->set_rules('address1', 'Address', 'required');
    $this->form_validation->set_rules('address2', 'Department Name', 'required');
    $this->form_validation->set_rules('address3', 'Address', 'required');
    $this->form_validation->set_rules('depthead', 'Department HOD', 'required');
    $this->form_validation->set_rules('unitid', 'Business Unit', 'required');
    // $this->form_validation->set_rules('replaced_with_userid', 'Replace with User', 'callback_replacedwithusercond');
    // $this->form_validation->set_rules('project_designationid', 'Project Designation', 'callback_joining_proj_designation');


    if ($this->form_validation->run() == FALSE) {
		 $data['countries'] = $this->Mastermodel->GetCountries();
        $data['business_unit'] = $this->get_all_bussiness_unit();
        $data['title']='Department';
        $this->load->view("Department/department",$data);
    
    }
    else{
            $data = $this->input->post();
            $data['createdby'] = $this->session->userdata('loginid');
			$this->db->insert("main_departments",$data);
			$ret_id = $this->db->insert_id();
			if($ret_id){
				  $this->session->set_flashdata('success_msg', 'Department Added Successfully.');
			redirect(base_url('add_department'));
			}
			else{
				 $this->session->set_flashdata('error_msg', 'Something went wrong.');
			redirect(base_url('add_department'));
			}
          
            // print_r($data);
            // die();
            // 

    }
    }
    public function get_state()
    {
       $country_id = $_REQUEST['country_id'];
       $this->db->select("a.id,a.state_name");
       $this->db->from("tbl_states as a");
       $this->db->where("a.country_id", $country_id);
      $data = $this->db->get()->result();
     echo json_encode($data);
    }
    public function get_city()
    {
        $state = $_REQUEST['state_id'];
        $this->db->select("a.id,a.city_name");
        $this->db->from("tbl_cities as a");
        $this->db->where("a.state_id",$state);
        $data = $this->db->get()->result();
        echo json_encode($data);
    }
    public function get_all_bussiness_unit()
    {
        $this->db->select("*");
        $this->db->from("main_businessunits");
        $data = $this->db->get()->result();
        return $data;
    }
public function get_employes()
{
    $business_unit_id = $_REQUEST['unitid'];
    $this->db->select("a.user_id,a.userfullname");
    $this->db->from("main_employees_summary as a");
    $this->db->where("a.businessunit_id",$business_unit_id);
   $data = $this->db->get()->result();
   echo json_encode($data);
}
public function add_department()
{
      $this->form_validation->set_rules('deptname', 'Department Name', 'required|is_unique[main_departments.deptname]');
   
    $this->form_validation->set_rules('deptcode', 'Department Code', 'required|is_unique[main_departments.deptcode]');
    $this->form_validation->set_rules('description', 'Department description', 'required');
    $this->form_validation->set_rules('startdate', 'Start date', 'required');
    $this->form_validation->set_rules('country', 'Country', 'required');
    $this->form_validation->set_rules('state', 'State', 'required');
    $this->form_validation->set_rules('city', 'City', 'required');
    $this->form_validation->set_rules('address1', 'Address', 'required');
    $this->form_validation->set_rules('address2', 'Department Name', 'required');
    $this->form_validation->set_rules('address3', 'Address', 'required');
    $this->form_validation->set_rules('depthead', 'Department HOD', 'required');
    $this->form_validation->set_rules('unitid', 'Business Unit', 'required');
    // $this->form_validation->set_rules('replaced_with_userid', 'Replace with User', 'callback_replacedwithusercond');
    // $this->form_validation->set_rules('project_designationid', 'Project Designation', 'callback_joining_proj_designation');


    if ($this->form_validation->run() == FALSE) {
       $this->index();
    }
    else{
            $data = $this->input->post();
            $data['createdby'] = $this->session->userdata('loginid');
            $this->session->set_flashdata('success_msg', 'Department Added Successfully.');
            $this->index();
            // print_r($data);
            // die();
            // $this->db->insert("main_departments",$data);

    }
       
}
public function Department()
{
    $list = $this->Department_model->get_datatables();
    // print_r($list);
    $data = array();
    $no = $_POST['start'];

    foreach ($list as $dataRow)
    {
        $sub_departments = "";
        $sub_department = get_sub_department_names($dataRow->id);
        foreach ($sub_department as $value)
        {
            $sub_departments .= $value->subdepartment.","; 
        }

        $no++;
        $row = array();
        $row[] = $no;
        //  $row[] = ($dataRow->userfullname) ? $image1 . "&nbsp;&nbsp;" . $dataRow->userfullname . "" : '';
        $row[] = isset($dataRow->deptname) ? $dataRow->deptname : '';
        $row[] = isset($dataRow->deptcode) ? $dataRow->deptcode : '';
        $row[] = $sub_departments;
        $row[] = isset($dataRow->description) ? $dataRow->description : '';
        //  $row[] = isset($dataRow->jobtitlename) ? $dataRow->jobtitlename : '';
        $row[] = '<a href="'.base_url("edit_department?edit_id=$dataRow->id").'">Edit</a>';
        //<a title='View' class='btn' href='javascript:void(0);'  onclick='NewsView(" . $dataRow->id . ")'><i class='fa fa-eye'></i></a><a title='Delete' class='btn' href='javascript:void(0);'  onclick='NewsDelete(" . $dataRow->id . ")'><i class='fa fa-trash'></i>
        //   $row[] = isset($dataRow->jobtitlename) ? $dataRow->jobtitlename : '';

        //$row[] = "<span style='display:flex;flex-direction: row-reverse;'><a href='".base_url("pdfgenerate/".$dataRow->user_id)."' class='btn btn-info' target='_blank' title='Download'><i class='fa fa-download'></i></a>&ensp;<a href='".base_url("employee_edit/".$dataRow->user_id)."' class='btn btn-info' title='Edit'><i class='fa fa-edit'></i></a>&nbsp; <a href='" . base_url("excelgenerate/" . $dataRow->user_id) . "' class='btn btn-info' target='_blank' title='Download Excel'><i class='fa fa-file-excel-o'></i></a></span>";
        // $row[] = "<input type='hidden' class='txt_csrfname' name='" . $this->security->get_csrf_token_name() . "' value='" . $this->security->get_csrf_hash() . "'><span style='display:flex;flex-direction: row-reverse;'><a href='" . base_url("pdfgenerate/" . $dataRow->user_id) . "' class='btn btn-info' target='_blank' title='Download'><i class='fa fa-download'></i></a>&ensp;<a href='" . base_url("employee_edit/" . $dataRow->user_id) . "' class='btn btn-info' title='Edit'><i class='fa fa-edit'></i></a>&nbsp;<span style='float:right'> <form method='POST' action='" . base_url('FetchEmp_ReportData') . "'><input type='hidden' name='Employe_id' value='" . $dataRow->user_id . "'> <button type='submit' class='btn btn-info'><i class='fa fa-file-excel-o'></i></button></form></span></span>";

        $data[] = $row;
    }
    $output = array(
        "draw" => $_POST['draw'],
        "recordsTotal" => $this->Department_model->count_all(),
        "recordsFiltered" => $this->Department_model->count_filtered(),
        "data" => $data,
    );
    echo json_encode($output);
}

public function add_sub_department()
{
    $this->form_validation->set_rules('department_name', 'Department Name', 'required');
    $this->form_validation->set_rules('sub_department_name', 'Sub Department Name', 'required|is_unique[main_subdepartments.subdepartment]');

    if ($this->form_validation->run() == false)
    {
        $data['error'] = '';
        $data['title'] = 'Add Sub Department';
        $data['departments'] = $this->Department_model->get_departments();
        $data['get_hod'] = get_hod();
        $this->load->view("Department/add_sub_department",$data);
    }
    else
    {
        $postDataArr = $this->input->post();
        if ($postDataArr)
        {
            $insertArr = [
                            'deptid' => $postDataArr['department_name'],
                            'hod_id' => $postDataArr['reporting_manager'],
                            'subdepartment' => $postDataArr['sub_department_name'],
                            'is_active' => 1,
                        ];
            $resU = $this->db->insert('main_subdepartments', $insertArr);
            if ($resU)
            {
                $this->session->set_flashdata('success', 'Sub Department Added Successfully');
                redirect($_SERVER['HTTP_REFERER']);
            }
        }
    }
}

public function edit_department()
{
    $data['countries'] = $this->Mastermodel->GetCountries();
    $data['business_unit'] = $this->get_all_bussiness_unit();
    $data['title']='Edit Department';
    if($_REQUEST['edit_id']){
        $id = $_REQUEST['edit_id'];
    }


    $this->db->select("*");
    $this->db->from("main_departments");
    $this->db->where("id",$id);
    $data['department_detail'] = $this->db->get()->row();
    $this->load->view("Department/edit_department",$data);
    // return $data ;
}
public function update_department()
{
    $subDepartmentsStore = [];
    $subDepartments = get_sub_department_names($this->input->post('edit_id'));
    foreach ($subDepartments as $value)
    {
        $subDepartmentsStore[] = $value->id;
    }
    // ep($subDepartmentsStore);
    $subDepartmentsUserEdit = $this->input->post("subDepartments");
    // ep($subDepartmentsUserEdit);
    $result=array_diff($subDepartmentsStore,$subDepartmentsUserEdit);
    
    foreach ($result as $key => $value)
    {
        $this->db->where('id', $value);
        $this->db->update("main_subdepartments", array('deptid' => 0));
        // ep($value);
    }
    // die;


    $edit_id = $this->input->post('edit_id');
    $this->form_validation->set_rules('deptname', 'Department Name', 'required');

    $this->form_validation->set_rules('deptcode', 'Department Code', 'required');
    $this->form_validation->set_rules('description', 'Department description', 'required');
    $this->form_validation->set_rules('startdate', 'Start date', 'required');
    $this->form_validation->set_rules('country', 'Country', 'required');
    $this->form_validation->set_rules('state', 'State', 'required');
    $this->form_validation->set_rules('city', 'City', 'required');
    $this->form_validation->set_rules('address1', 'Address', 'required');
    $this->form_validation->set_rules('address2', 'Department Name', 'required');
    $this->form_validation->set_rules('address3', 'Address', 'required');
    $this->form_validation->set_rules('depthead', 'Department HOD', 'required');
    $this->form_validation->set_rules('unitid', 'Business Unit', 'required');
    // $this->form_validation->set_rules('replaced_with_userid', 'Replace with User', 'callback_replacedwithusercond');
    // $this->form_validation->set_rules('project_designationid', 'Project Designation', 'callback_joining_proj_designation');


    if ($this->form_validation->run() == FALSE) {
        $this->session->set_flashdata('error_msg', 'Oops Department Not Updated');
        // $this->edit_department();
        // edit_department
    redirect(base_url("edit_department?edit_id=$edit_id"));
    //    $this->edit_department();
    }
    else{
        $data = $this->input->post();
        unset($data['subDepartments']);
        unset($data['edit_id']);
        $data['modifiedby']=$this->session->userdata('loginid');
        $this->db->where("id",$edit_id);
        $this->db->update("main_departments",$data);
        $this->session->set_flashdata('success_msg', 'Department updated Successfully.');
        
        redirect(base_url("edit_department?edit_id=$edit_id"));

    }
    
}
    // public function index()
    // {
    //     $data['title'] = "News List";
    //     // $data['job_title'] = 

    //     $this->load->view("Designation/designation", $data);
    // }

    // public function Designation()
    // {
    //     $list = $this->Designation_List_model->get_datatables();
    //     // print_r($list);
    //     $data = array();
    //     $no = $_POST['start'];

    //     foreach ($list as $dataRow) {

    //         $no++;
    //         $row = array();
    //         $row[] = $no;
    //         //  $row[] = ($dataRow->userfullname) ? $image1 . "&nbsp;&nbsp;" . $dataRow->userfullname . "" : '';
    //         $row[] = isset($dataRow->positionname) ? $dataRow->positionname : '';
    //         $row[] = isset($dataRow->jobtitlename) ? $dataRow->jobtitlename : '';
    //         $row[] = isset($dataRow->description) ? $dataRow->description : '';
    //         //  $row[] = isset($dataRow->jobtitlename) ? $dataRow->jobtitlename : '';
    //         $row[] = "<a class='btn' href='javascript:void(0);' onclick='seteditupdatedata(" . $dataRow->id . ")' data-toggle='modal' data-target='#myModal2'><i class='fa fa-edit'></i></a>";
    //         //<a title='View' class='btn' href='javascript:void(0);'  onclick='NewsView(" . $dataRow->id . ")'><i class='fa fa-eye'></i></a><a title='Delete' class='btn' href='javascript:void(0);'  onclick='NewsDelete(" . $dataRow->id . ")'><i class='fa fa-trash'></i>
    //         //   $row[] = isset($dataRow->jobtitlename) ? $dataRow->jobtitlename : '';

    //         //$row[] = "<span style='display:flex;flex-direction: row-reverse;'><a href='".base_url("pdfgenerate/".$dataRow->user_id)."' class='btn btn-info' target='_blank' title='Download'><i class='fa fa-download'></i></a>&ensp;<a href='".base_url("employee_edit/".$dataRow->user_id)."' class='btn btn-info' title='Edit'><i class='fa fa-edit'></i></a>&nbsp; <a href='" . base_url("excelgenerate/" . $dataRow->user_id) . "' class='btn btn-info' target='_blank' title='Download Excel'><i class='fa fa-file-excel-o'></i></a></span>";
    //         // $row[] = "<input type='hidden' class='txt_csrfname' name='" . $this->security->get_csrf_token_name() . "' value='" . $this->security->get_csrf_hash() . "'><span style='display:flex;flex-direction: row-reverse;'><a href='" . base_url("pdfgenerate/" . $dataRow->user_id) . "' class='btn btn-info' target='_blank' title='Download'><i class='fa fa-download'></i></a>&ensp;<a href='" . base_url("employee_edit/" . $dataRow->user_id) . "' class='btn btn-info' title='Edit'><i class='fa fa-edit'></i></a>&nbsp;<span style='float:right'> <form method='POST' action='" . base_url('FetchEmp_ReportData') . "'><input type='hidden' name='Employe_id' value='" . $dataRow->user_id . "'> <button type='submit' class='btn btn-info'><i class='fa fa-file-excel-o'></i></button></form></span></span>";

    //         $data[] = $row;
    //     }
    //     $output = array(
    //         "draw" => $_POST['draw'],
    //         "recordsTotal" => $this->Designation_List_model->count_all(),
    //         "recordsFiltered" => $this->Designation_List_model->count_filtered(),
    //         "data" => $data,
    //     );
    //     echo json_encode($output);
    // }
    // public function addDesignation()
    // {
    //     $position_name = $this->input->post('position_name');
    //     $jobtitle = $this->input->post('jobtitle');
    //     $description = $this->input->post('description');
    //     $data = array();
    //     if ($position_name != '' and $jobtitle != '' and $description != '') {
    //         $createdby = $this->session->userdata('loginid');
    //         // print_r($createdby);
    //         // $this->
    //         // $createdby = ;
    //         $return = $this->Designation_List_model->AdddDesignation($position_name, $jobtitle, $description, $createdby);
    //         // print_r($return);
    //         if ($return) {
    //             $data['Status'] = 'Succesfully Saved';
    //         } else {
    //             $data['error'] = 'Something Went Wrong';
    //         }
    //     } else {
    //         $data['error'] = 'All Fields Are Required';
    //     }
    //     echo json_encode($data);

    //     // print_r($jobtitle);
    // }
    // public function edit_Designation()
    // {
    //     $position = $this->input->post('position_id');
    //     $data = $this->Designation_List_model->editdesignation($position);
    //     echo json_encode($data);
    // }
    // public function edit_Designation_update()
    // {
    //     $posid =  $this->input->post('position_id');
    //     $posi_name = $this->input->post('position_Name');
    //     $jobtitle = $this->input->post('jobtitle_id');
    //     $description = $this->input->post('description');
    //     $return =  $this->Designation_List_model->updatedesignation($posid, $posi_name, $jobtitle, $description);
    //     if ($return) {
    //         $data['status'] = 'Update Successfully';
    //     } else {
    //         $data['error'] = 'Not Updated . Something Went Wrong';
    //     }
    //     echo json_encode($data);
    // }
}
