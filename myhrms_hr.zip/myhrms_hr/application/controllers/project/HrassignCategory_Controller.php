<?php

defined('BASEPATH') or exit('No direct script access allowed');

class HrassignCategory_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Project/HrCategory_model', 'HrCategory_model');
        $this->load->library('form_validation');

        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }

    public function assigncategory()
    {

        $data['title'] = 'Hr Assign Category';
        $data['Category'] = $this->HrCategory_model->GetCatehoryecord();
        $data['hrlist'] = $this->HrCategory_model->getHrlist();
        $data['assignlist'] = $this->HrCategory_model->getassignlist();
        // echo "<pre>";
        // print_r($data['assignlist']);
        // die;

        $this->load->view("project/Hrassigncategory", $data);
    }




    public function Hrassigncate()
    {
        $category = $this->input->post('c_name');
        $hruser_id = $this->input->post('userfullname');
        $this->session->set_userdata('category_id',    $category);
        $this->session->set_userdata('hruser_id',    $hruser_id);
        $array = array();
        $array['category_id'] = $this->session->userdata('category_id');
        $array['hruser_id'] = $this->session->userdata('hruser_id');
        $array['assign_date'] = date("Y-m-d");
        $resp = $this->HrCategory_model->inserted_data($array);
        if ($resp) {
            $this->session->set_flashdata('success_msg', 'Hr Category Assign Successfully');
            redirect(base_url("assigncategory"));
        }
    }


    public function ajax_getsinglecate_id()
    {
        // echo "<skjdhsjkd";
        // die;
        $hruser_id = $_REQUEST['hruser_id'];

        if ($hruser_id) {
            $singleCategory = $this->HrCategory_model->GetcategoryAssigndata($hruser_id);

?>

            <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                <thead>
                    <tr>
                        <th>Sr.No.</th>
                        <th>Hr Name</th>
                        <th>Project Name</th>
                        <th>Assign Date</th>

                    </tr>
                </thead>
                <?php
                $i = 1;
                foreach ($singleCategory as $vs) {
                ?>
                    <tr>
                        <td><?php echo $i ?></td>
                        <td><?= $vs->userfullname ?></td>
                        <td><?= $vs->c_name ?></td>

                        <td><?= $vs->assign_date ?></td>



                    </tr>

                <?php
                    $i++;
                }
                ?>

                <tfoot>
                    <tr>
                        <th>Sr.No.</th>
                        <th>Hr Name</th>
                        <th>Category_name</th>
                        <th>Assign Date</th>
                    </tr>
                </tfoot>
            </table>
            </div>
            </div>
            </div>

<?php

        }
        // echo json_encode($singleRecfloor[0]);
    }
}
