<?php
class EmplEdit_PermController extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');

        $this->load->model('Project/Permission_Model');
        $this->load->database();

        // if (($this->session->userdata('assign_role') != "1")) {
        //     redirect(base_url(""));
        // }
    }




    public function Emplperm()
    {
        $data['title'] = "Employee Edit Permissiom";
        $this->load->view('project/Emplperm_view', $data);
    }



    public function empldetail()
    {
        $data = array();
        $user_id = $this->session->userdata('loginid');
        $list = $this->Permission_Model->get_datatables();
        $no = 0;

        foreach ($list as $value) {
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $value->userfullname; //department name
            $row[] = $value->employeeId; //floor name department_name
            $row[] = $value->department_name;
            $row[] = $value->position_name; //dat

            $emp_id = $value->emp_id;
            if ($value->status == '1') {
                $row[] = '<button class="btn btn-success" onclick="Send_request_yes(' . "'" . $emp_id . "'" . ')" >Yes</button>';
            } else {
                $row[] = '<button class="btn btn-danger" onclick="Send_request_no(' . "'" . $emp_id . "'" . ')" >No</button>';
            }
            $data[] = $row;
        }

        $output = array(
            "draw" =>  $_POST['draw'],
            "recordsTotal" => $this->Permission_Model->count_all(),
            "recordsFiltered" => $this->Permission_Model->count_filtered(),
            "data" => $data,
        );

        echo json_encode($output);
    }


    public function Send_request_yes()
    {
        $emp_id = $_REQUEST['emp_id'];
        $return = $this->Permission_Model->Send_request_yes($emp_id);
        echo json_encode($return);
    }


    public function Send_request_no()
    {
        $emp_id = $_REQUEST['emp_id'];
        $return = $this->Permission_Model->Send_request_no($emp_id);
        echo json_encode($return);
    }
}
