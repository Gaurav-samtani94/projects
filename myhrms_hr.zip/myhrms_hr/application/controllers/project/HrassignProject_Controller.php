<?php

defined('BASEPATH') or exit('No direct script access allowed');

class HrassignProject_Controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Assign_project_hr_model');
        $this->load->library('form_validation');

        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }

    public function assignproject()
    {
        $data['projectlist'] = $this->Assign_project_hr_model->getProjectlist();
        $data['hrlist'] = $this->Assign_project_hr_model->getHrlist();
        $data['assignlist'] = $this->Assign_project_hr_model->getassignlist();

        //$data['assignlist'] = $this->mastermodel->getbookfloordata();

        // echo "<pre>";
        // print_r($data['assignlist']);
        // die;

        $this->load->view("project/Hrassignproject", $data);
    }

    public function hrassignpro()
    {
        $project = $this->input->post('project_name');
        $department = $this->input->post('userfullname');

        $this->session->set_userdata('project_id',    $project);
        $this->session->set_userdata('hruser_id',    $department);
        $array = array();
        $array['project_id'] = $this->session->userdata('project_id');
        $array['hruser_id'] = $this->session->userdata('hruser_id');
$array['assign_date'] = date("Y-m-d");
        $resp = $this->Assign_project_hr_model->inserted_data($array);
        redirect(base_url("assignproject"));
    }


    public function ajax_getsingleproby_tid()
    {
        // echo "<skjdhsjkd";
        // die;
        $hruser_id = $_REQUEST['hruser_id'];

        if ($hruser_id) {
            $singleRecfloor = $this->Assign_project_hr_model->getbookfloordata($hruser_id);
?>

            <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                <thead>
                    <tr>
                        <th>Sr.No.</th>
                        <th>Hr Name</th>
                        <th>Project Name</th>
                        <th>Assign Date</th>

                    </tr>
                </thead>
                <?php
                $i = 1;
                foreach ($singleRecfloor as $vs) {
                ?>
                    <tr>
                        <td><?php echo $i ?></td>
                        <td><?= $vs->userfullname ?></td>
                        <td><?= $vs->project_name ?></td>

                        <td><?= $vs->assign_date ?></td>



                    </tr>

                <?php
                    $i++;
                }
                ?>

                <tfoot>
                    <tr>
                        <th>Sr.No.</th>
                        <th>Hr Name</th>
                        <th>project_name</th>
                        <th>Assign Date</th>
                    </tr>
                </tfoot>
            </table>
            </div>
            </div>
            </div>

<?php

        }
        // echo json_encode($singleRecfloor[0]);
    }
}
