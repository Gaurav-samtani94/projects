<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class All_emp_appraisal_list_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('All_emplist_Appraisal_model', 'appraisal');
        $this->load->model('CegProject_BC_emplist_Appraisal_model', 'appraisalCegProject');
        $this->load->model('CegProject_DE_emplist_Appraisal_model', 'appraisalCegProjectDE');
        $this->load->library('form_validation');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }

     //Employee Appraisal List..
    public function all_empappraisal_list() {
        error_reporting(0);
        $data = array();
        $data['title'] = "All Appraisal List";
        $data['Emplylist'] = $this->appraisal->get_datatables();
		// echo "<pre>"; print_r($data['Emplylist']); die;
        $this->load->view('appraisal/all_emp_appraisal_view', $data);
    }
	
	//CEG Project Employee Appraisal List..
    public function cegProject_empappraisal_list() {
        error_reporting(0);
        $data = array();
        $data['title'] = "All Appraisal List";
        $appr_bc = $this->appraisalCegProject->get_datatables();
        $appr_de = $this->appraisalCegProjectDE->get_datatables();
		$appr_bc_de = array_merge($appr_bc, $appr_de);
		$data['Emplylist'] = $appr_bc_de;
		// echo "<pre>"; print_r($data['Emplylist']); die;
        $this->load->view('appraisal/cegProject_emp_appraisal_view', $data);
    }
	
	 //Employee Appraisal List..
    public function rnr_form_detail() {
        error_reporting(0);
        $data = array();
        $data['title'] = "All Appraisal List";
        $data['Emplylist'] = $this->form_rnr_data();
        $data['rnr_emp_list4'] = $this->form_rnr_data1('4');
        $data['rnr_emp_list5'] = $this->form_rnr_data1('5');
        $data['rnr_emp_list6'] = $this->form_rnr_data1('6');
        $data['rnr_emp_list7'] = $this->form_rnr_data1('7');
        $data['rnr_emp_list8'] = $this->form_rnr_data1('8');
        $data['rnr_emp_list3'] = $this->form_rnr_data3();
		// echo "<pre>"; print_r($data['rnr_emp_list3']); die;
        $this->load->view('appraisal/rnr_form_view', $data);
    }
	
	public function form_rnr_data() {
		$user_id = $this->session->userdata('loginid');
        $this->db->select('a.presentation_paper_innovative_activit_proj,b.project_type,b.project_name,a.team_members,a.recommended_not_recommended,a.additional_task_performed,a.complexit_terrain_bypasses,a.min_issu_delay_submission,a.percen_payment_receipt,a.continuity_order_client,a.quality_proj__docs,a.satisfaction_client,a.quality_proj__docs,a.satisfaction_client,a.quality_proj__docs,a.satisfaction_client,a.quality_proj__docs,a.satisfaction_client,b.project_category,b.start_date,b.end_date');
        $this->db->from('award_reward_formdata_2 as a');
        $this->db->join("tm_projects as b", "b.id=a.assign_project", "INNER");
        $this->db->where(array("a.status" => "1"));
		$recArr = $this->db->get()->result();
		return ($recArr) ? $recArr : '011';
		
	}
	
	public function form_rnr_data3() {
		$user_id = $this->session->userdata('loginid');
        $this->db->select('a.team_members,b.project_type,b.project_name,a.job_description,a.recommended_not_recommended');
        $this->db->from('award_reward_formdata_3 as a');
        $this->db->join("tm_projects as b", "b.id=a.assign_project", "INNER");
        $this->db->where(array("a.status" => "1"));
		$recArr = $this->db->get()->result();
		return ($recArr) ? $recArr : '011';
		
	}
	
	public function form_rnr_data1($id) {
        $this->db->select('b.*,c.*,a.*,e.project_name');
        $this->db->from('main_employees_summary as a');
        $this->db->join("award_reward_formdata_4 as c", "c.team_members=a.user_id", "left");
        $this->db->join("emp_otherofficial_data as d", "d.user_id=a.user_id", "left");
        $this->db->join("tbl_companyname as b", "b.id=d.company_name", "left");
        $this->db->join("tm_projects as e", "e.id=c.assign_project", "left");
        $this->db->where(array("a.isactive" => "1","c.award_group_formcateg" => $id));
		$recArr = $this->db->get()->result();
		return ($recArr) ? $recArr : '011';
		
	}
	
	 public function create_pdf() {
        $this->load->library("Pdf");
        // create new PDF document
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // set document information
        /* $pdf->SetCreator(PDF_CREATOR);
          $pdf->SetAuthor('Muhammad Saqlain Arif');
          $pdf->SetTitle('TCPDF Example 001');
          $pdf->SetSubject('TCPDF Tutorial');
          $pdf->SetKeywords('TCPDF, PDF, example, test, guide'); */

        // set default header data
        //$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 001', PDF_HEADER_STRING, array(0,64,255), array(0,64,128));
        //$pdf->setFooterData(array(0,64,0), array(0,64,128)); 
        // set header and footer fonts
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

        // set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // set margins
        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

        // set auto page breaks
        //$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM); 
        // set image scale factor
        //$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);  
        // set some language-dependent strings (optional)
        /* if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
          require_once(dirname(__FILE__).'/lang/eng.php');
          $pdf->setLanguageArray($l);
          } */

        // ---------------------------------------------------------    
        // set default font subsetting mode
        $pdf->setFontSubsetting(true);

        // Set font
        // dejavusans is a UTF-8 Unicode font, if you only need to
        // print standard ASCII chars, you can use core fonts like
        // helvetica or times to reduce file size.
        //$pdf->SetFont('dejavusans', '', 14, '', true);   
        // Add a page
        // This method has several options, check the source code documentation for more information.
        $pdf->AddPage();

        // set text shadow effect
        $pdf->setTextShadow(array('enabled' => true, 'depth_w' => 0.2, 'depth_h' => 0.2, 'color' => array(196, 196, 196), 'opacity' => 1, 'blend_mode' => 'Normal'));

        // Set some content to print
        $html = '<style>h1 {
  page-break-before: always;
}</style><h1 style="text-align:center">1</h1><table border="1px solid">
<tbody>
<tr>
<td colspan="3" width="706">
<p><strong>&nbsp;</strong></p>
<p><strong>CONSULTING ENGINEERS GROUP LIMITED</strong></p>
<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nomination Form for </strong><strong>Outstanding Managed IE/PMC/CS Project</strong><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td colspan="3" width="706">
<table border="1px solid">
<tbody>
<tr>
<td width="176">
<p><strong>&nbsp;</strong></p>
<p><strong>Name of the Project</strong></p>
</td>
<td width="186">
<p><strong>D150 - Chakeri-Allahabad</strong></p>
</td>
<td width="159">
<p><strong>&nbsp;</strong></p>
<p><strong>Team Leader</strong></p>
</td>
<td width="160">
<p><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td width="176">
<p><strong>Type of project</strong></p>
<p><strong>(IE/PMC/CS)</strong></p>
</td>
<td width="186">
<p><strong>billable</strong></p>
</td>
<td width="159">
<p><strong>&nbsp;</strong></p>
<p><strong>Location</strong></p>
</td>
<td width="160">
<p><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td colspan="2" width="362">
<p><strong><u>Project Date</u></strong><strong>&nbsp;:</strong></p>
<p>Start <strong>01-01-1970 </strong> | Completion <strong>01-01-1970</strong></p>
<p>&nbsp;</p>
<p>Upto March’19 (About =&gt;70%)___ % Completed</p>
</td>
<td colspan="2" width="319">
<p><strong><u>Project Value</u></strong><strong>&nbsp;:</strong></p>
<p>Contractual Value : ________________</p>
<p>&nbsp;</p>
<p>Payment Received as on ____________</p>
</td>
</tr>
</tbody>
</table>
<p><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td width="130">
<p><strong>Key Parameter</strong></p>
</td>
<td width="302">
<p><strong>Sub Parameters</strong></p>
</td>
<td width="274">
<p>&nbsp;</p>
</td>
</tr>
<tr>
<td rowspan="7" width="130">
<p><strong>Overall Performance</strong></p>
</td>
<td width="302">
<p>Complexities like Hilly terrain,   Tunnel, Elevated, Bypasses, etc</p>
</td>
<td width="274">
<p>The Project highway having a length about 145.066 km from four laning to Six Laning.
•	To Minimize the PCC quantity on existing four lane carriageway
•	Drainage design in Plain Terrain
•	Overlay/Milling proposal 
•	CBR of Embankment
•	TCS
•	Minimize the RE wall length
•	Design of 9 Flyovers and Elevated, 5 nos are continuous structure
•	Length of Protection wall (Retaining wall) for all structure optimized to meet site condition.
•	Protection works of all cross drainage structure optimized by introduction of wing wall on rigid apron.
•	Design of Integrated structure of LVUPs and VUPs with precast planks.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Minimum issues for delay in submissions</p>
</td>
<td width="274">
<p>The project highway is approximately 145.066 Km length. TCS, Main Carriageway P&amp;P (145.066 km), Service road P&amp;P (145.066 km), Drain P&amp;P (300 km), Pavement design report,  Toll plaza, Truck LAY bye Bus bay are submitted within 4-6 Month and gots approvals from IIT Roorkee.

As per NHAI letter regarding COS of 25 PUP to 25 LVUP dated 31st Oct 2018, same shall be submitted to Client and additional amount of Rs. 15 lacs+ GST issued by the Client.

Major, Minor Bridges, Elevated/Flyovers,  25 PUPs/LVUPs, 14 Nos of VUP and Culverts, Toll plaza building have been submitted within 6.0 months and approval from IIT Roorkee.</p>
</td>
</tr>
<tr>
<td width="302">
<p>% of Payment receipt in first year</p>
</td>
<td width="274">
<p>59</p>
</td>
</tr>
<tr>
<td width="302">
<p>Continuity of Orders by same Client</p>
<p>&nbsp;</p>
</td>
<td width="274">
<p>Yes, Purvanchal expressway Package V &amp; VI are awarded after this WO.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Quality of the project and timely delivery of the documents </p>
</td>
<td width="274">
<p>Quality of design &amp; drawing developed is good and appreciate by the Client &amp; IIT Roorkee. P&amp;P drawings of Main Carriageway, service road &amp; drain, Toll plaza, Truck lay Bye, Major Junction &amp; Structure drawings are submitted as per Time schedule agreed by client.

Optimized Design and drawing of Major, Minor Bridges, Elevated/Flyovers, 25 PUPs/LVUPs, 14 Nos of VUP and Culverts, Toll plaza building have been submitted within Time schedule as per satisfaction of client.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Satisfaction of the client </p>
</td>
<td width="274">
<p>Client satisfaction was realized by repeat order and timely release of payments.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Presentation of papers for innovative activities in the project </p>
</td>
<td width="274">
<p>Papers preparation will be initiated on 
Optimization of PCC by Milling
Recycling of Bituminous layers</p>
</td>
</tr>

</tbody>
</table>
<table border="1px solid">
<tbody>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Initiated by IO: </em></strong></em></strong></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><em><em>Significant / Special Achievements:</em></em></p>

<p><em><em></em></em></p>
<p><em><em>Additional task performed :</em></em></p>
<p><em><em>The project highway is approximately 145.066 Km length. TCS, Main Carriageway P&amp;P (145.066 km), Service road P&amp;P (145.066 km), Drain P&amp;P (300 km), Pavement design report,  Toll plaza, Truck LAY bye Bus bay are submitted within 4-6 Month and gots approvals from IIT Roorkee.

As per NHAI letter regarding COS of 25 PUP to 25 LVUP dated 31st Oct 2018, same shall be submitted to Client and additional amount of Rs. 15 lacs+ GST issued by the Client.

Major, Minor Bridges, Elevated/Flyovers,  25 PUPs/LVUPs, 14 Nos of VUP and Culverts, Toll plaza building have been submitted within 6.0 months and approval from IIT Roorkee.</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Recommendation by RO :</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Recommended/ Not Recommended</em></strong></em></strong></p>
<p><em><em>(Justification with supporting write up)</em></em></p>
<p><em><em>Recommended for the reward as best Project</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Recommendation by Committee: Recommended/Not Recommended</em></strong></em></strong></p>
<p><em><em>(Remarks to be put by senior most member of the committee after discussion with all other members off line)</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<table border="1px solid">
<tbody>
<tr>
<td width="149">
<p><strong><em><strong><em>Name</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="149">
<p><strong><em><strong><em>Signature</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
</tbody>
</table>
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Names of Team Members </em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><em><em>S.No</em></em></p>
</td>
<td width="118">
<p><em><em>Name</em></em></p>
</td>
<td width="132">
<p><em><em>Designation</em></em></p>
</td>
<td width="141">
<p><em><em>With project since</em></em></p>
</td>
<td width="75">
<p><em><em>Attn%</em></em></p>
</td>
<td width="85">
<p><em><em>Perf Rating</em></em></p>
</td>
<td width="75">
<p><em><em>Any disciplinary </em></em></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>1</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Arvind Kumar Jain</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Associate Director</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>2</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Kamalkishore Ramakant Sharma</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Sr General Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>3</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Shyam Sunder Khandelwal</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Associate Director</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>4</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Shailesh Kumar Gupta</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Chief General Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>5</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Ankur Kumar Gupta</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>6</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Shanil Anshuman</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Dy General Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>7</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Narendra .</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>CAD Draughtsman</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>8</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Chandan Kumar Jha</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Asst Quantity Surveyor</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>9</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Gaurav Kumar</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Asst Quantity Surveyor</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>10</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Rajendra Kumar Paliwal</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Sr CAD Draughtsman</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>11</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Aditya Choudhary</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Assistant Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>12</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Babulal Suthar</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>CAD Draughtsman</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>13</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Divyansh Jain</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Assistant Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>14</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Prateesh Mathur</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Assistant Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>15</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Ketan Rane</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Assistant Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>16</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Rajendra Prajapat</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>CAD Draughtsman</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>17</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Rahul Kaurav</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Assistant Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>


</tbody>
</table><br>
	<h1 style="text-align:center">2</h1>									   
										   
										   
										   
											<table border="1px solid">
<tbody>
<tr>
<td colspan="3" width="706">
<p><strong>&nbsp;</strong></p>
<p><strong>CONSULTING ENGINEERS GROUP LIMITED</strong></p>
<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nomination Form for </strong><strong>Outstanding Managed IE/PMC/CS Project</strong><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td colspan="3" width="706">
<table border="1px solid">
<tbody>
<tr>
<td width="176">
<p><strong>&nbsp;</strong></p>
<p><strong>Name of the Project</strong></p>
</td>
<td width="186">
<p><strong>D046 - Paonta Sahib Guma NH-72B</strong></p>
</td>
<td width="159">
<p><strong>&nbsp;</strong></p>
<p><strong>Team Leader</strong></p>
</td>
<td width="160">
<p><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td width="176">
<p><strong>Type of project</strong></p>
<p><strong>(IE/PMC/CS)</strong></p>
</td>
<td width="186">
<p><strong>billable</strong></p>
</td>
<td width="159">
<p><strong>&nbsp;</strong></p>
<p><strong>Location</strong></p>
</td>
<td width="160">
<p><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td colspan="2" width="362">
<p><strong><u>Project Date</u></strong><strong>&nbsp;:</strong></p>
<p>Start <strong>01-01-2016 </strong> | Completion <strong>23-10-2018</strong></p>
<p>&nbsp;</p>
<p>Upto March’19 (About =&gt;70%)___ % Completed</p>
</td>
<td colspan="2" width="319">
<p><strong><u>Project Value</u></strong><strong>&nbsp;:</strong></p>
<p>Contractual Value : ________________</p>
<p>&nbsp;</p>
<p>Payment Received as on ____________</p>
</td>
</tr>
</tbody>
</table>
<p><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td width="130">
<p><strong>Key Parameter</strong></p>
</td>
<td width="302">
<p><strong>Sub Parameters</strong></p>
</td>
<td width="274">
<p>&nbsp;</p>
</td>
</tr>
<tr>
<td rowspan="7" width="130">
<p><strong>Overall Performance</strong></p>
</td>
<td width="302">
<p>Complexities like Hilly terrain,   Tunnel, Elevated, Bypasses, etc</p>
</td>
<td width="274">
<p>Ponta Guma project is very complex project having complete hilly tarrain funded by World bank in which every approval has been taken from World bank. It is a first GNSHP project approved by world bank and CEG presented very good in front of worldbank. World bank officials appriciated our final report on Environment and social as well as proposal prepared for resourse efficiency with minimum use of carban emmission material.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Minimum issues for delay in submissions</p>
</td>
<td width="274">
<p>after taking over project with world bank, every submission for preparation in modified report  to world bank, we are the first consultant who has submitted report in time  among all other consultant who is working for world bank funded project.</p>
</td>
</tr>
<tr>
<td width="302">
<p>% of Payment receipt in first year</p>
</td>
<td width="274">
<p>completed payment received for eligible invoices. No due payment with client</p>
</td>
</tr>
<tr>
<td width="302">
<p>Continuity of Orders by same Client</p>
<p>&nbsp;</p>
</td>
<td width="274">
<p>Yes. ,MORTH and NHAI are our regular client.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Quality of the project and timely delivery of the documents </p>
</td>
<td width="274">
<p>quality of deliverable  always appreciated by world bank and MORTH  and PWD Himachal   and used our reports for sample reports for other consultants also. As of now all deliverables completed  regarding  DPR. only forest clearance is under process with  MOEF which is very tough task in hilly region and tree enumeration  and assessment for minimum tree cutting in complete forest stretch project  was very complex task.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Satisfaction of the client </p>
</td>
<td width="274">
<p> client is satisfied . No hard letter or and observation on our quality received till date.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Presentation of papers for innovative activities in the project </p>
</td>
<td width="274">
<p>we have  presented in front of Worldbank team for resourse efficiency and use of bio engineering for slope protections measures as well as Japanies technodlgy in contract documents.</p>
</td>
</tr>

</tbody>
</table>
<table border="1px solid">
<tbody>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Initiated by IO: </em></strong></em></strong></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><em><em>Significant / Special Achievements:</em></em></p>

<p><em><em></em></em></p>
<p><em><em>Additional task performed :</em></em></p>
<p><em><em> we have also taken addition fees for modification in DPR based on new GNSHP concept and latest world bank guideline for Rs 35 lacs which is approved by finance secretary because of more than 20% variation. It is worth mentioning that approval of more than 20% variation in DPR project from finance secretary is very tough task .</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Recommendation by RO :</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Recommended/ Not Recommended</em></strong></em></strong></p>
<p><em><em>(Justification with supporting write up)</em></em></p>
<p><em><em></em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Recommendation by Committee: Recommended/Not Recommended</em></strong></em></strong></p>
<p><em><em>(Remarks to be put by senior most member of the committee after discussion with all other members off line)</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<table border="1px solid">
<tbody>
<tr>
<td width="149">
<p><strong><em><strong><em>Name</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="149">
<p><strong><em><strong><em>Signature</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
</tbody>
</table>
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Names of Team Members </em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><em><em>S.No</em></em></p>
</td>
<td width="118">
<p><em><em>Name</em></em></p>
</td>
<td width="132">
<p><em><em>Designation</em></em></p>
</td>
<td width="141">
<p><em><em>With project since</em></em></p>
</td>
<td width="75">
<p><em><em>Attn%</em></em></p>
</td>
<td width="85">
<p><em><em>Perf Rating</em></em></p>
</td>
<td width="75">
<p><em><em>Any disciplinary </em></em></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>1</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Vivek Ashok Kulkarni</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>General Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>2</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Sanjay Kashinatharao Ekbote</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>General Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>3</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Surendra Kumar Sharma</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Dy General Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>4</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Ashish Kumar Soni</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>CAD Operator</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>5</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Pramod Kumar Jain</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Vice President</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>6</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Jayanta Kumar Samanta</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Assistant</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>7</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Giriraj Kumawat</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Executive</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>8</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Chandan Kumar Jha</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Asst Quantity Surveyor</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>9</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Bhagchand Bairwa</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>CAD Draughtsman</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>10</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Naveen Mathur</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Asst Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>11</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Aparna Gupta</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Assistant Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>12</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Shankar Lal Kumawat</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>CAD Draughtsman</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>13</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Suraj Laxman Mokal</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>CAD Draughtsman</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>


</tbody>
</table><br>
	<h1 style="text-align:center">3</h1>									   
										   
										   
										   
											<table border="1px solid">
<tbody>
<tr>
<td colspan="3" width="706">
<p><strong>&nbsp;</strong></p>
<p><strong>CONSULTING ENGINEERS GROUP LIMITED</strong></p>
<p><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nomination Form for </strong><strong>Outstanding Managed IE/PMC/CS Project</strong><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td colspan="3" width="706">
<table border="1px solid">
<tbody>
<tr>
<td width="176">
<p><strong>&nbsp;</strong></p>
<p><strong>Name of the Project</strong></p>
</td>
<td width="186">
<p><strong>S01- Misc Design</strong></p>
</td>
<td width="159">
<p><strong>&nbsp;</strong></p>
<p><strong>Team Leader</strong></p>
</td>
<td width="160">
<p><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td width="176">
<p><strong>Type of project</strong></p>
<p><strong>(IE/PMC/CS)</strong></p>
</td>
<td width="186">
<p><strong>billable</strong></p>
</td>
<td width="159">
<p><strong>&nbsp;</strong></p>
<p><strong>Location</strong></p>
</td>
<td width="160">
<p><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td colspan="2" width="362">
<p><strong><u>Project Date</u></strong><strong>&nbsp;:</strong></p>
<p>Start <strong>01-01-1970 </strong> | Completion <strong>01-01-1970</strong></p>
<p>&nbsp;</p>
<p>Upto March’19 (About =&gt;70%)___ % Completed</p>
</td>
<td colspan="2" width="319">
<p><strong><u>Project Value</u></strong><strong>&nbsp;:</strong></p>
<p>Contractual Value : ________________</p>
<p>&nbsp;</p>
<p>Payment Received as on ____________</p>
</td>
</tr>
</tbody>
</table>
<p><strong>&nbsp;</strong></p>
</td>
</tr>
<tr>
<td width="130">
<p><strong>Key Parameter</strong></p>
</td>
<td width="302">
<p><strong>Sub Parameters</strong></p>
</td>
<td width="274">
<p>&nbsp;</p>
</td>
</tr>
<tr>
<td rowspan="7" width="130">
<p><strong>Overall Performance</strong></p>
</td>
<td width="302">
<p>Complexities like Hilly terrain,   Tunnel, Elevated, Bypasses, etc</p>
</td>
<td width="274">
<p>Hilly Terrain, Heavy cutting sections.  Mots of the road section is between deep valley and high mountains.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Minimum issues for delay in submissions</p>
</td>
<td width="274">
<p>Submitted the design to the authority engineer with-in the planned time frame and received the approvals of complete highway design.</p>
</td>
</tr>
<tr>
<td width="302">
<p>% of Payment receipt in first year</p>
</td>
<td width="274">
<p>79%</p>
</td>
</tr>
<tr>
<td width="302">
<p>Continuity of Orders by same Client</p>
<p>&nbsp;</p>
</td>
<td width="274">
<p>First Project with the client. Contractor is bidding for new projects and likely to get the design work done from CEG.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Quality of the project and timely delivery of the documents </p>
</td>
<td width="274">
<p>The Project is completely approved from the Authority Engineer with on time submissions to the full satisfaction of the Engineer and the contractor.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Satisfaction of the client </p>
</td>
<td width="274">
<p>Client is absolutely satisfied and willing to give subsequent project to CEG if wins.</p>
</td>
</tr>
<tr>
<td width="302">
<p>Presentation of papers for innovative activities in the project </p>
</td>
<td width="274">
<p>The presentations shall be arranged after the completion of the project which will definitely enhance the competencies of the in house design engineers.</p>
</td>
</tr>

</tbody>
</table>
<table border="1px solid">
<tbody>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Initiated by IO: </em></strong></em></strong></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><em><em>Significant / Special Achievements:</em></em></p>

<p><em><em></em></em></p>
<p><em><em>Additional task performed :</em></em></p>
<p><em><em>Value Engineering to save almost 10 to 12% cost of the project.</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Recommendation by RO :</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Recommended/ Not Recommended</em></strong></em></strong></p>
<p><em><em>(Justification with supporting write up)</em></em></p>
<p><em><em></em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Recommendation by Committee: Recommended/Not Recommended</em></strong></em></strong></p>
<p><em><em>(Remarks to be put by senior most member of the committee after discussion with all other members off line)</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<p><em><em>&nbsp;</em></em></p>
<table border="1px solid">
<tbody>
<tr>
<td width="149">
<p><strong><em><strong><em>Name</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="149">
<p><strong><em><strong><em>Signature</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="122">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
</tbody>
</table>
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td colspan="7" width="706">
<p><strong><em><strong><em>Names of Team Members </em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><em><em>S.No</em></em></p>
</td>
<td width="118">
<p><em><em>Name</em></em></p>
</td>
<td width="132">
<p><em><em>Designation</em></em></p>
</td>
<td width="141">
<p><em><em>With project since</em></em></p>
</td>
<td width="75">
<p><em><em>Attn%</em></em></p>
</td>
<td width="85">
<p><em><em>Perf Rating</em></em></p>
</td>
<td width="75">
<p><em><em>Any disciplinary </em></em></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>1</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Himanshu Vashistha</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Sr Site Engineer</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>2</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Devendra Kumar Mourya</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>CAD Draughtsman</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>
<tr>
<td width="77">
<p><strong><em><strong><em>3</em></strong></em></strong></p>
</td>
<td width="118">
<p><strong><em><strong><em>Shivam Jaiswal</em></strong></em></strong></p>
</td>
<td width="132">
<p><strong><em><strong><em>Assistant Manager</em></strong></em></strong></p>
</td>
<td width="141">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="85">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
<td width="75">
<p><strong><em><strong><em>&nbsp;</em></strong></em></strong></p>
</td>
</tr>


</tbody>
</table>';
echo $html; die;

        // Print text using writeHTMLCell()
        $pdf->writeHTMLCell(0, 0, '', '', $html, 0, 1, 0, true, '', true);

        // ---------------------------------------------------------    
        // Close and output PDF document
        // This method has several options, check the source code documentation for more information.
        $pdf->Output('example_001.pdf', 'I');

        //============================================================+
        // END OF FILE
        //============================================================+
    }
	
	
	
	
}
