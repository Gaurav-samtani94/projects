<?php

defined('BASEPATH') or exit('No direct script access allowed');

class CronJob_controller extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Employee/Todaybirthday_model', 'Todaybirthday_model');
        $this->load->library('form_validation');
        $this->load->helper('security');
    }

    public function requestmail() // abhimanyu
    {
        $data['dataemailpta'] = $this->Todaybirthday_model->getEmployeeemaildata();
        $to = "cegapps@cegindia.com";
        
        $subject = "Happy Birthday";
  	    $oldpath = 'public/uploads/birthdaywish';
        
        // Random Image
        $a = scandir($oldpath);        
        unset($a[0]);
        unset($a[1]);
        $i = array_rand($a);
        $Birthday_image_name = $a[$i];
        
        // Random Color
        $colors =["D8E2DC","eae8ff","e9f1f7","fae3e3","F4EBBE","77B6EA","efcfe3","ffb7c3","a7bed3","7161ef"];
        $i = array_rand($colors);
        $bg_color = $colors[$i];
        $data['Birthday_image_name'] = $Birthday_image_name;
        $data['bg_color'] = $bg_color;

        // Email Page
        $msgDetails2 = $this->load->view('email/birthdaywishemail_view', $data,true);
    
        $this->sendMail($to, $subject, $msgDetails2);
        echo "success";
        die;
        foreach($data['dataemailpta'] as $value)
        {
            // $this->sendMail($value['emailaddress'], $subject, $msgDetails2);
        }
    }

    function sendMail($to, $subject, $msgDetails)
    {
	    $CI = &get_instance();
        $CI->load->library('email');
        $CI->email->initialize(array(
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        ));
        $CI->email->from('marketing@cegindia.com','CEG-INDIA');
        $CI->email->to($to);
        $CI->email->subject($subject);
        $CI->email->message($msgDetails);
        $resp = $CI->email->send();
        return ($resp) ? $resp : $CI->email->print_debugger();
    }

    public function job_accept_link()
    {
        $round_id = $this->input->get('round_id');
        if ($round_id) {
            $round_details = $this->db->get_where('job_interview_round', ['id' => $round_id])->row();
            if ($round_details) {
                $interviewers_id = $round_details->interviewers_id;
                $interview_id = $round_details->interview_id;
                $rounds = $round_details->round;
                $job_id = $this->db->get_where('job_interview', ['id' => $interview_id])->row()->job_id;

                $this->db->where('id', $round_id)->update('job_interview_round', ['interviewer_accept' => 1]);

                $data = [
                    'job_id' => $job_id,
                    'interview_round_id' => $round_id,
                    'interview_id' => $interview_id,
                    'interviewers_id' => $interviewers_id,
                    'mail_status' => 1,
                    'round_id' => $rounds,
                    'created_by' => $interviewers_id,
                ];
                $this->db->insert('interviewer_mail_history_job', $data);

                redirect(rootUrls.'myhrms/index.php/');
            }
        }
    }

    public function job_reject_link()
    {
        $round_id = $this->input->get('round_id');
        if ($round_id) {
            $round_details = $this->db->get_where('job_interview_round', ['id' => $round_id])->row();
            if ($round_details) {
                $interviewers_id = $round_details->interviewers_id;
                $interview_id = $round_details->interview_id;
                $rounds = $round_details->round;
                $job_id = $this->db->get_where('job_interview', ['id' => $interview_id])->row()->job_id;

                // Update job_interview_round
                $this->db->where('id', $round_id)->update('job_interview_round', [
                    'round' => null,
                    'interviewers_id' => null,
                    'interviewer_accept'=>2
                ]);

                // Insert into interviewer_mail_history_job
                $data = [
                    'job_id' => $job_id,
                    'interview_round_id' => $round_id,
                    'interview_id' => $interview_id,
                    'interviewers_id' => $interviewers_id,
                    'round_id' => $rounds,
                    'mail_status' => 2,
                    'created_by' => $interviewers_id,
                ];
                $this->db->insert('interviewer_mail_history_job', $data);

                redirect(rootUrls.'myhrms/index.php/');
            }
        }
    }
}