<?php

// require_once 'bootstrap.php';
defined('BASEPATH') or exit('No direct script access allowed');
require 'vendor/autoload.php';

class EditLetter_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('session');
        $this->load->model('letter/LetterModel');
        $this->load->model('letter/Letter_templte_Master_Model');
        $this->load->helper('url');
        // $this->db1 = $this->load->database('online', TRUE);
        // $this->db2 = $this->load->database('default', TRUE);
        // $this->db3 = $this->load->database('accdept_db', TRUE);
        // $this->db4 = $this->load->database('cvmanager', TRUE);
        $this->load->library('form_validation');
    }

    public function index()
    {
        $letter_edit_id = $this->uri->segment(2);
        // print_r($letter_edit_id);
        $data['title'] = 'Edit Letter';
        $data['form_data'] = $this->fetch_letter($letter_edit_id);
        $data['description'] = $this->get_description($letter_edit_id);
        // echo'<pre>';

        // die();
        // $temp_ids = get_temp_max_value();
        // // print_r($temp_ids);
        // // die();
        // // $data['tables'] = $this->db4->list_tables();
        // $data['temp_id'] = $temp_ids;
        // $data['state'] = $this->getallstate();
        // $data['city'] = $this->getallcity();
        // $data['title'] = 'Add Letter';
        // $data['form_data'] = $this->input->post();

        $this->load->view('letter_view/edit_letter', $data);
    }

    public function fetch_letter($letter_id)
    {
        $this->db->select('a.*,b.employeeId,b.businessunit_id');
        $this->db->from('main_letter as a');
        $this->db->join('temp_hr_official_details as b', 'b.fld_id=a.tmp_emp_id', 'LEFT');
        $this->db->where('a.id', $letter_id);
        $data = $this->db->get()->row();

        return $data ? $data : '';
    }

    public function get_description($letter_id)
    {
        $this->db->select('b.description');
        $this->db->from('main_letter as a');
        $this->db->join('main_letter_type_master as b', '(b.id=a.templete_id AND a.letter_type_id=b.letter_type_id)', 'LEFT');
        $this->db->where('a.id', $letter_id);
        $data = $this->db->get()->row();

        return $data->description ? $data->description : '';
    }

    public function update_letter()
    {
        $data = $this->input->post();
        $update = $this->update_letter_data($data);
    }

    public function update_letter_data($data)
    {
        echo'<pre>';
        print_r($data['letter_id']);
        // die();
        $this->db->where('id', );
        $this->db->update();
    }

//     public function addletter()
//     {
//         $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
//         $this->form_validation->set_rules('pincode', 'pincode', 'required');
//         $this->form_validation->set_rules('contact_no', 'Mobile Number ', 'required|regex_match[/^[0-9]{10}$/]'); //{10} for 10 digits number

//         if ($this->form_validation->run() == false) {
//             $this->form_validation->error_array();
//             $data['form_data'] = $this->input->post();
//             $this->index();
//         } else {
//             $data = $this->input->post();

//             if ($data) {
//                 $employe_id = $this->add_tmp_employe($data);
//                 if ($employe_id) {
//                     $entery_by = $this->session->userdata('loginid');

//                     $fullname = $data['name'].''.$data['lastname'];

//                     $filename = $data['cegcode'].$data['name'].$employe_id.rand();
//                     $insarray = [
//                     //'ceg_code' => $data['cegcode'],
//                     'tmp_emp_id' => $employe_id,
//                     'offer_date' => $data['from_date'],
//                     'templete_id' => $data['Templete_id'],
//                     'letter_type_id' => $data['lettertype'],
//                     'prefix' => $data['prefix'],
//                     'firstname' => $data['name'],
//                     'lastname' => $data['lastname'],
//                     'userfullname' => $fullname,
//                     'address1' => $data['address_one'],
//                     'address2' => $data['address_two'],
//                     'city' => $data['city'],
//                     'state' => $data['state'],
//                     'country' => $data['country'],
//                     'pincode' => $data['pincode'],
//                     'contact' => $data['contact_no'],
//                     'email' => $data['email'],
//                     'position' => $data['position'],
//                     'sub_offerletter' => $data['subject'],
//                     // 'offerlettter_desc' => $data['description'],
//                     'offer_letter_fill' => $data['name'],
//                     'status' => '1',
//                     'lock' => '0',
//                     'company_id' => $data['company_id'],
//                     'amount' => $data['ammount'],
//                     'hr_name' => $data['hrname'],
//                     'hr_position' => $data['hr_position'],
//                     'entry_by' => $entery_by,
//                     'cmp_location' => $data['cmp_location'],
//                     // 'filename' => $filename.'.docx',
//                 ];
//                     $ins_data = (object) $insarray;

//                     // $this->letter_exportdata_word($ins_data);

//                     $this->db->insert('main_letter', $insarray);
//                     $ins_id = $this->db->insert_id();
//                     redirect(base_url('edit_letter/'.$ins_id));

//                     $this->session->set_flashdata('success', 'You Add Letter Successfully');
//                 } else {
//                     $this->session->set_flashdata('error', 'Letter Not Successfully Added');
//                 }
//             }

//             redirect(base_url('add_letter'));
//         }
//     }

//     public function getleterdata()
//     {
//         // $start_date = $this->input->post('start_date');
//         // $end_date = $this->input->post('end_date');
//         $list = $this->LetterModel->get_datatables();

//         $data = [];
//         $no = $_POST['start'];

//         foreach ($list as $val) {
//             ++$no;
//             $GotTotLeave = 0;

//             $row = [];
//             $row[] = $no;
//             //    $row[] = $val->ceg_code;
//             $row[] = $val->offer_date;
//             $row[] = $val->userfullname;
//             //  $row[] = $val->address1;
//             $row[] = $val->email;
//             $position_name = get_positions($val->position);
//             $row[] = $position_name;
//             $row[] = Get_Hrname($val->hr_name);
//             $row[] = get_positions($val->hr_position);
//             if ($val->status == 1) {
//                 $row[] = 'Letter Added By HR';
//             } elseif ($val->status == 2) {
//                 $row[] = 'Locked By HR';
//             } elseif ($val->status == 3) {
//                 $row[] = 'Send By HR';
//             } elseif ($val->status == 4) {
//                 $row[] = 'Accept By Employe';
//             } else {
//                 $row[] = '';
//             }
//             $uplink = $val->lock == 1 ? '<a href="'.base_url("sendletter/$val->id").'"><i class="fa fa-paper-plane" aria-hidden="true"></i></a>' : '<a title="Letter Edit" href="javascript:void(0)" onclick="editpopup('.$val->id.')">'.
//                 '<spam class="fa fa-edit" data-toggle="modal" data-target="#myModal"></spam></a>&nbsp;';
//             $up = $val->lock != 1 ? '&nbsp;<a href="'.base_url("lockLetter/$val->id").'"><i class="fa fa-lock"></i></a>' : '';
//             $row[] = '<a title="Download"  href="'.base_url("../public/uploads/letter/$val->filename").'" download><spam class="fa fa-download"></spam></a>'.'&nbsp;&nbsp;'.$uplink.''.$up;
//             $data[] = $row;
//         }

//         $output = [
//             'draw' => $_POST['draw'],
//             'recordsTotal' => $this->LetterModel->count_all(),
//             'recordsFiltered' => $this->LetterModel->count_filtered(),
//             'data' => $data,
//         ];
//         //output to json format
//         echo json_encode($output);
//     }

//     public function letter_exportdata_word($letterdata)
//     {
//         // $no = $this->uri->segment(2);
//         // print_r($no);
//         // die();
//         // $letterdata = $this->getletter_info($no);

//         // Creating the new document...
//         $phpWord = new \PhpOffice\PhpWord\PhpWord();

//         /* Note: any element you append to a document must reside inside of a Section. */

//         // Adding an empty Section to the document...
//         $section = $phpWord->addSection(['marginTop' => 1000]);

//         // Adding Text element to the Section having font styled by default...
//         $section->addText(
//           //  $letterdata->ceg_code,
//         );
//         $section->addText(
//             $letterdata->offer_date
//         );
//         $section->addText(
//             ''
//         );
//         $section->addText(
//             $letterdata->prefix.' '.$letterdata->userfullname
//         );
//         $section->addText(
//             $letterdata->address1
//         );
//         $section->addText(
//             $letterdata->city.''.$letterdata->pincode
//         );
//         $section->addText(
//             'Contact No : '.$letterdata->contact
//         );
//         $section->addText(
//             'Email : '.$letterdata->email
//         );
//         $section->addText(
//             ' '
//         );
//         $section->addText(
//             'Subject : '.$letterdata->sub_offerletter
//         );
//         $section->addText(
//             ''
//         );
//         $section->addText(
//             'Dear '.$letterdata->firstname.' '.$letterdata->firstname.' ,'
//         );
//         $section->addText(
//             ' '
//         );

//         \PhpOffice\PhpWord\Shared\Html::addHtml($section, $letterdata->offerlettter_desc);

//         $section->addText(
//             $letterdata->company_name
//         );

//         $section->addText(
//             ''
//         );
//         $section->addText(
//             $letterdata->hr_name
//         );
//         $section->addText(
//             $letterdata->hr_position
//         );
//         $section->addText(
//             ''
//         );
//         $section->addLine(['weight' => 1, 'width' => 600, 'height' => 0]);
//         $section->addText(
//             'I accept the above offer and agree to join on or before …………………….'
//         );

//         $section->addText(
//             '('.$letterdata->userfullname.')', ['align' => 'center', 'bold' => true]
//         );

//         // Saving the document as OOXML file...
//         $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
//         $file = $letterdata->filename;
//         $objWriter->save("public/uploads/letter/$file");
//     }

//     public function getletter_info($no)
//     {
//         $this->db->select('a.*,b.company_name');
//         $this->db->from('main_letter as a');
//         $this->db->join('tbl_companyname as b', 'b.id=a.company_id');
//         $this->db->where('a.id', $no);
//         $data = $this->db->get()->row();

//         return $data;
//     }

//     public function Fetch_letter_decription()
//     {
//         $letertype = $this->input->post('lettertype');
//         $positionn = $this->input->post('position');
//         $ammount = $this->input->post('ammount');
//         $templete_id = $this->input->post('templete_id');
//         //print_r($ammount);
//         // print_r($positionn);
//         $cmp_location = $this->input->post('cmp_location');
//         $this->db->select('a.*');
//         $this->db->from('main_letter_type_master as a');
//         $this->db->where('a.id', $templete_id);

//         $letter_description = $this->db->get()->row();
//         $position_update = $letter_description->description;
//         // print_R($position_update);
//         $replacedata = str_replace('Replaceposition', "$positionn", "$position_update");
//         $replacedatatwo = str_replace('Replacecmp_location', "$cmp_location", "$replacedata");
//         $replacedatathree = str_replace('Replacecmp_ammountttt', "$ammount", "$replacedatatwo");
//         // print_r($replacedatathree);
//         echo json_encode($replacedatathree);
//     }

//     public function addLetterformat()
//     {
//         $entery_by = $this->session->userdata('loginid');
//         $data = $this->input->post();
//         // print_r($data);
//         $insarray = [
//             'letter_type_id' => $data['letter_type'],
//             'letter_templete_name' => $data['letter_templte_name'],
//             'description' => $data['letter_dec'],
//             'created_by' => $entery_by, ];
//         $this->db->insert('main_letter_type_master', $insarray);
//         echo json_encode('success');
// //
//         // $this->load->view()
//     }

//     //27-06-2022 vivek(ajax_get_byid)================
//     public function ajax_get_byid()
//     {
//         $editId = $this->input->post('editId');
//         $AllLetterDataById = $this->GetAllLetterDataById($editId);
//         // epd($AllLetterDataById);
//         echo json_encode($AllLetterDataById);
//     }

//     public function GetAllLetterDataById($editId)
//     {
//         $this->db->select('a.*');
//         $this->db->from('main_letter as a');

//         $this->db->where('a.id', $editId);
//         $recors = $this->db->get()->row();

//         return ($recors) ? $recors : '';
//     }

//     public function updateletter()
//     {
//         $letterId = $this->input->post('letterid');
//         //epd($letterId);
//         $data = $this->input->post();
//         if ($data['saveandlock']) {
//             $lock = 1;
//             $status = 2;
//         } else {
//             $lock = 0;
//         }

//         $this->db->select('a.filename');
//         $this->db->from('main_letter as a');
//         $this->db->where('a.id', $letterId);
//         $filename = $this->db->get()->row();
//         $file = $filename->filename;
//         $entery_by = $this->session->userdata('loginid');
//         $fullname = $data['name'].' '.$data['lastname'];

//         $insarray = [
//             'offer_date' => $data['from_date'],
//             'prefix' => $data['prefix'],
//             'firstname' => $data['name'],
//             'lastname' => $data['lastname'],
//             'userfullname' => $fullname,
//             'address1' => $data['address_one'],
//             'address2' => $data['address_two'],
//             'city' => $data['city'],
//             'state' => $data['state'],
//             'country' => $data['country'],
//             'pincode' => $data['pincode'],
//             'contact' => $data['contact_no'],
//             'email' => $data['email'],
//             'position' => $data['position'],
//             'sub_offerletter' => $data['subject'],
//             'offerlettter_desc' => $data['mdescription'],
//             'offer_letter_fill' => $data['name'],
//             'company_id' => $data['company_id'],
//             'amount' => $data['amount'],
//             'hr_name' => $data['hrname'],
//             'hr_position' => $data['hr_position'],
//             'entry_by' => $entery_by,
//             'cmp_location' => $data['cmp_location'],
//             'status' => $status ? $status : '',
//             'lock' => $lock,

//             'filename' => $file,
//         ];

//         unlink("public/uploads/letter/$file");
//         $obj = (object) $insarray;
//         $this->letter_exportdata_word($obj);

//         //update letter
//         $this->db->where('main_letter.id', $letterId);
//         $resU = $this->db->update('main_letter', $insarray);

//         $this->session->set_flashdata('success', 'Letter Record Update Successfully');
//         redirect(base_url('add_letter'));
//     }

//     public function add_tmp_employe($data)
//     {
//         $insarray = [
//             'employeeId' => $data['emp_id'],
//             'prefix_id' => $data['prefix'],
//             'firstname' => $data['name'],
//             'lastname' => $data['lastname'],
//             'businessunit_id' => $data['business_unit'],
//             'contactnumber' => $data['contact_no'],
//             'emailaddress' => $data['email'],
//         ];
//         $this->db->insert('temp_hr_official_details', $insarray);
//         // print_r($data);
//         $insert_id = $this->db->insert_id();
//         // print_R($insert_id);
//         return $insert_id ? $insert_id : null;
//     }

//     public function sendletter()
//     {
//         $letter_id = $this->uri->segment(2);
//         $this->db->select('a.*,b.letter_templete_name');
//         $this->db->from('main_letter as a');
//         $this->db->join('main_letter_type_master as b', 'b.id=a.letter_type_id', 'LEFT');
//         $this->db->where('a.id', $letter_id);
//         $letter_data = $this->db->get()->row();
//         // print_r($letter_data);
//         // die();
//         $to = "$letter_data->email";
//         $subject = "$letter_data->letter_templete_name";
//         $msgDetails = $this->load->view('email/letter', compact('letter_data'), true);
//         $file = "public/uploads/letter/$letter_data->filename";

//         $this->send_letterMail($to, $subject, $msgDetails, $file);
//         $uparray = ['status' => 3];
//         $this->db->where('id', $letter_id);
//         $this->db->update('main_letter', $uparray);
//         redirect(base_url('add_letter'));
//     }

//     public function send_letterMail($to, $subject, $msgDetails, $file)
//     {
//         $this->load->library('email');
//         $this->email->initialize([
//             'protocol' => 'smtp',
//             'smtp_host' => 'mail.cegindia.com',
//             'smtp_user' => 'marketing@cegindia.com',
//             'smtp_pass' => 'MARK-2015ceg',
//             'smtp_port' => 587,
//             'crlf' => "\r\n",
//             'newline' => "\r\n",
//             'mailtype' => 'html',
//             'charset' => 'iso-8859-1',
//             'wordwrap' => true,
//         ]);
//         $this->email->from('marketing@cegindia.com', 'Oficial Letter');
//         $this->email->to($to);
//         $this->email->bcc('cegapps@cegindia.com');
//         $this->email->subject($subject);
//         $this->email->message($msgDetails);
//         $this->email->attach($file);
//         $resp = $this->email->send();

//         return ($resp) ? $resp : $this->email->print_debugger();
//     }

//     public function add_letter_master()
//     {
//         $data['title'] = 'Add Leter template';
//         $this->load->view('letter_view/add_letter_type', $data);
//     }

//     public function getletermasterdata()
//     {
//         // $start_date = $this->input->post('start_date');
//         // $end_date = $this->input->post('end_date');
//         $list = $this->Letter_templte_Master_Model->get_datatables();

//         $data = [];
//         $no = $_POST['start'];

//         foreach ($list as $val) {
//             ++$no;

//             $row = [];
//             $row[] = $no;
//             $row[] = $val->letter_type_name;
//             $row[] = $val->letter_templete_name;
//             $row[] = strip_tags($val->description);
//             $row[] = '<a title="Letter Edit" href="javascript:void(0)" onclick="editpopup('.$val->id.')">'.'<spam class="fa fa-edit" data-toggle="modal" data-target="#exampleModal"></spam></a>&nbsp;';
//             $data[] = $row;
//         }

//         $output = [
//             'draw' => $_POST['draw'],
//             'recordsTotal' => $this->Letter_templte_Master_Model->count_all(),
//             'recordsFiltered' => $this->Letter_templte_Master_Model->count_filtered(),
//             'data' => $data,
//         ];
//         //output to json format
//         echo json_encode($output);
//     }

//     public function ajax_get_letterTemplete()
//     {
//         $templete_id = $this->input->post('editId');
//         // print_R($templete_id);
//         $this->db->select('a.*');
//         $this->db->from('main_letter_type_master as a');
//         $this->db->where('id', $templete_id);
//         $templte = $this->db->get()->row();
//         echo json_encode($templte);
//     }

//     public function get_letter_templete()
//     {
//         $lettertype = $this->input->post('lettertype');
//         $this->db->select('a.*');
//         $this->db->from('main_letter_type_master as a');
//         $this->db->where('a.letter_type_id', $lettertype);
//         $data = $this->db->get()->result();
//         echo json_encode($data);
//     }

//     public function lockLetter()
//     {
//         $letter_id = $this->uri->segment(2);
//         $uparray = ['lock' => '1'];
//         $this->db->where('id ', $letter_id);
//         $this->db->update('main_letter', $uparray);
//         redirect(base_url('add_letter'));
//     }

//     public function getstate()
//     {
//         $country_id = $this->input->post('country');
//         $state = getState_country($country_id);
//         echo json_encode($state);
//     }

//     public function getcity()
//     {
//         $state_id = $this->input->post('state');
//         $city = getcity_State($state_id);
//         echo json_encode($city);
//     }

//     public function getallstate()
//     {
//         $this->db->select('a.*');
//         $this->db->from('tbl_states as a');
//         $this->db->where(['a.isactive' => '1']);
//         $states = $this->db->get()->result();

//         return $states ? $states : '';
//     }

//     public function getallcity()
//     {
//         $this->db->select('a.*');
//         $this->db->from('tbl_cities as a');
//         $this->db->where(['a.is_active' => '1']);
//         $states = $this->db->get()->result();

//         return $states ? $states : '';
//     }
}
