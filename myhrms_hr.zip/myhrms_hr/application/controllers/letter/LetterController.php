<?php

// require_once 'bootstrap.php';
defined('BASEPATH') or exit('No direct script access allowed');
require 'vendor/autoload.php';

class LetterController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('download');

        $this->load->library('session');
        $this->load->model('Mastermodel', 'mastermodel');
        $this->load->model('letter/LetterModel');
        $this->load->model('letter/Letter_templte_Master_Model');
        $this->load->model('letter/Employee_list_temp_model', 'emplist_temp_model');

        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->loginuser_id = $this->session->userdata('loginid');
        if (($this->session->userdata('loginid') == '') or ($this->session->userdata('assign_role') == '')) {
            redirect(base_url(''));
        }
    }

    //Employee List..
    public function list_temp_employee()
    {
        $data['error'] = '';
        $data['title'] = 'Prospective Employee List';
        $data['PositionListArr'] = $this->emplist_temp_model->GetAllPositionList();
        $this->load->view('letter_view/list_temp_employe', $data);
    }

    //Letter List Ajax..
    public function ajax_list_letter()
    {
        $list = $this->emplist_temp_model->get_datatables();
        $data = [];
        $no = $_POST['start'];
        foreach ($list as $temp) {
            ++$no;
            $row = [];
            $row[] = $no;
            $row[] = $temp->tmp_emp_id;
            $row[] = $temp->userfullname;
            $row[] = $temp->contact;
            $row[] = $temp->email;
            $row[] = $temp->positionname;
            $row[] = $temp->letter_date;
            $row[] = $temp->current_status;
            $link1 = '<a href="'.base_url("sendletter/$temp->id").'"><i class="fa fa-paper-plane" aria-hidden="true"></i></a>';
            $link2 = '<a href=""><i class="fa fa-lock"></i></a>&nbsp;';
            $link3 = '&nbsp;<a href="'.base_url("edit_letter/$temp->id").'"><i class="fa fa-edit"></i></a>&nbsp;';
            $row[] = $link1.' &nbsp; '.$link3;
            $data[] = $row;
        }
        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->emplist_temp_model->count_all(),
            'recordsFiltered' => $this->emplist_temp_model->count_filtered(),
            'data' => $data,
        ];
        echo json_encode($output);
    }

    public function addletter()
    {
        $interview_id = $this->input->get('interview_id');
        $cvm_interview_id = $this->input->get('cvm_interview_id');
        
        $interview_record = null;
        $cvm_interview_record = null;

        if(!empty($interview_id)){
            $interview_record = $this->getInterviewRecord($interview_id);
            
        }
        
        if(!empty($cvm_interview_id)){
            $cvm_interview_record = $this->getCvmInterviewRecord($cvm_interview_id);
            if(empty($cvm_interview_record->result_status)){
                $this->db->where('id',$cvm_interview_record->id);
                $this->db->update('job_interview_cvm',['result_status'=>'1']);
            }
        }
       // epd($cvm_interview_record);
        $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
        //$this->form_validation->set_rules('pincode', 'pincode', 'required|min_length[6]|max_length[6]|regex_match[/^[0-9]{6-6}$/]');
        $this->form_validation->set_rules('contact_no', 'Mobile Number ', 'required|regex_match[/^[0-9]{10}$/]'); //{10} for 10 digits number
        $this->form_validation->set_rules('emp_id', 'Employe id ', 'required'); //{10} for 10 digits number
        $this->form_validation->set_rules('business_unit', 'Bussiness Unit ', 'required'); //{10} for 10 digits number
        $this->form_validation->set_rules('lettercode', 'Letter Code', 'required'); //{10} for 10 digits number
        $this->form_validation->set_rules('Templete_id', 'Template', 'required');
        $this->form_validation->set_rules('subject', 'Subject', 'required');
        $this->form_validation->set_rules('letter_date', 'Letter Date', 'required');
        $this->form_validation->set_rules('prefix', 'Prefix', 'required');
        $this->form_validation->set_rules('name', 'Name', 'required|alpha');
        $this->form_validation->set_rules('lastname', 'Last Name', 'required|alpha');
        $this->form_validation->set_rules('address_one', 'Address', 'required');
        $this->form_validation->set_rules('address_two', 'Address', 'required');
        $this->form_validation->set_rules('country', 'Country', 'required');
        $this->form_validation->set_rules('state_id', 'State', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('position', 'Position', 'required');
        $this->form_validation->set_rules('company_id', 'Company Id', 'required');
        $this->form_validation->set_rules('cmp_location', 'Company Location', 'required');
        $this->form_validation->set_rules('hrname', 'HR Name', 'required');
        $this->form_validation->set_rules('amount', 'amount', 'required');

        if ($this->form_validation->run() == false) {
            $this->form_validation->error_array();

            $temp_ids = get_temp_max_value();
            $data['temp_id'] = $temp_ids;
            $data['interview_record'] = $interview_record;
            $data['cvm_interview_record'] = $cvm_interview_record;

            $data['state'] = $this->getallstate();
            $data['city'] = $this->getallcity();
            $data['title'] = 'Prospective Employee';
            //$data['form_data'] = $this->input->post();
            //Get All Offer Letter,..

            $data['AllTempleteArr'] = $this->get_letter_templete('1');
            // print_r($data['AllTempleteArr']);
            //   die();

            $this->load->view('letter_view/add_letter', $data);
        } else {
            $data = $this->input->post();
            if ($data) {
                $fullname = $data['name'].' '.$data['lastname'];
                $insarray = ['letter_type_id' => '1',
                    'templete_id' => $data['Templete_id'],
                    'lettercode' => $data['lettercode'],
                    'letter_date' => $data['letter_date'],
                    'prefix' => $data['prefix'],
                    'firstname' => $data['name'],
                    'middle_name' => $data['middle_name'],
                    'lastname' => $data['lastname'],
                    'userfullname' => $fullname,
                    'address1' => $data['address_one'],
                    'address2' => $data['address_two'],
                    'city' => $data['city'],
                    'state' => $data['state_id'],
                    'country' => $data['country'],
                    'pincode' => $data['pincode'],
                    'contact' => $data['contact_no'],
                    'email' => $data['email'],
                    'position' => $data['position'],
                    'sub_offerletter' => $data['subject'],
                    'company_id' => $data['company_id'],
                    'amount' => $data['amount'],
                    'hr_name' => $data['hrname'],
                    'entry_by' => $this->session->userdata('loginid'),
                    'cmp_location' => $data['cmp_location'], ];

                $this->db->insert('main_letter', $insarray);
                $ins_id = $this->db->insert_id();
                if ($ins_id) {
                    //Temp ID Update..
                    $tmpID = TEMPID.$ins_id;
                    $this->db->where(['id' => $ins_id]);
                    $this->db->update('main_letter', ['tmp_emp_id' => $tmpID]);
                    $this->session->set_flashdata('success_msg', 'Prospective Employee Added Successfully');
                    redirect(base_url('edit_letter/'.$ins_id));
                } else {
                    $this->session->set_flashdata('error_msg', 'Something Went Wrong !! ');
                    redirect(base_url('addletter'));
                }
            } else {
                $this->session->set_flashdata('error', 'Something Went Wrong');
            }
        }
        redirect(base_url('addletter'));
    }

    //Edit @@@
    public function edit_letter($letID)
    {
        $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
        $this->form_validation->set_rules('pincode', 'pincode', 'required');
        $this->form_validation->set_rules('contact_no', 'Mobile Number ', 'required|regex_match[/^[0-9]{10}$/]'); //{10} for 10 digits number
            $this->form_validation->set_rules('emp_id', 'Employe id ', 'required'); //{10} for 10 digits number
            $this->form_validation->set_rules('business_unit', 'Bussiness Unit ', 'required'); //{10} for 10 digits number
            $this->form_validation->set_rules('lettercode', 'Letter Code', 'required'); //{10} for 10 digits number
            $this->form_validation->set_rules('Templete_id', 'Template', 'required');
        $this->form_validation->set_rules('subject', 'Subject', 'required');
        $this->form_validation->set_rules('letter_date', 'Letter Date', 'required');
        $this->form_validation->set_rules('prefix', 'Prefix', 'required');
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        $this->form_validation->set_rules('address_one', 'Address', 'required');
        $this->form_validation->set_rules('address_two', 'Address', 'required');
        $this->form_validation->set_rules('country', 'Country', 'required');
        $this->form_validation->set_rules('state_id', 'State', 'required');
        $this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('position', 'Position', 'required');
        $this->form_validation->set_rules('company_id', 'Company Id', 'required');
        $this->form_validation->set_rules('cmp_location', 'Company Location', 'required');
        $this->form_validation->set_rules('hrname', 'HR Name', 'required');
        $this->form_validation->set_rules('amount', 'amount', 'required');

        $SingleRecordArr = $this->emplist_temp_model->GetSingleRowByID($letID);
        $letterCode = $this->get_letter_code();
        $TempEmpl_LetterRecArr = $this->emplist_temp_model->TempEmpl_LetterRecArr($letID);

        // echo "<pre>";
        // print_r($TempEmpl_LetterRecArr);
        // die;
        $data['title'] = 'Edit Prospective Employee';
        $data['preFixRecArr'] = $this->mastermodel->GetTableData('main_prefix', ['isactive' => '1']);
        $data['roleRecArr'] = $this->mastermodel->GetTableData('main_roles', ['isactive' => '1']);
        $data['BunitsRecArr'] = $this->mastermodel->GetTableData('main_businessunits', ['isactive' => '1', 'id!=' => '0']);
        $data['JobGroupRecArr'] = $this->mastermodel->GetTableData('main_jobtitles', ['isactive' => '1']);
        $data['CompanyRecArr'] = $this->mastermodel->GetTableData('tbl_companyname', ['is_active' => '1']);
        $data['EMPCodeRow'] = $this->mastermodel->GetEmpIDCode();
        $data['EmpStatusArr'] = $this->mastermodel->GetTableData('tbl_employmentstatus', ['isactive' => '1']);
        $data['ActiveProjectListArr'] = $this->mastermodel->GetAllActiveProjectList();

        $data['Lt_EMPID_CEG'] = $this->mastermodel->GetLastEmpIdByCompanyID(1);
        $data['Lt_EMPID_CEGTH'] = $this->mastermodel->GetLastEmpIdByCompanyID(2);
        $data['Lt_EMPID_PCC'] = $this->mastermodel->GetLastEmpIdByCompanyID(3);
        $data['Lt_EMPID_TECHNO'] = $this->mastermodel->GetLastEmpIdByCompanyID(4);
        $data['Lt_EMPID_KCPL'] = $this->mastermodel->GetLastEmpIdByCompanyID(5);
        $data['Lt_EMPID_SKES'] = $this->mastermodel->GetLastEmpIdByCompanyID(6);
        $data['Lt_EMPID_VDP'] = $this->mastermodel->GetLastEmpIdByCompanyID(7);
        $data['Lt_EMPID_CegProj'] = $this->mastermodel->GetLastEmpIdCEGProj();
        $data['ReplacedWithAllUserListArr'] = $this->mastermodel->GetAllEmployeeListReplacedWith();
        $data['TempEmpl_LetterRecArr'] = $TempEmpl_LetterRecArr;
        $data['letterCode'] = $letterCode;
        $data['SingleRecordArr'] = $SingleRecordArr;
        if ($this->form_validation->run() == false) {
            // echo "hello";
            // die();
            $this->form_validation->error_array();
            $state = $this->getallstate();
            $city = $this->getallcity();

            $title = 'Edit / Update Prospective Employee';
            $data['AllTempleteArr'] = $this->get_letter_templete('1');
            // $AllTempleteArr = $this->get_letter_templete("1");
            $data['TemplateContentArr'] = $this->get_Template_Content($SingleRecordArr->templete_id);
            $this->load->view('letter_view/edit_upd_letter', $data); //compact('TempEmpl_LetterRecArr', 'letterCode', 'state', 'city', 'title', 'AllTempleteArr', 'SingleRecordArr', 'TemplateContentArr')
        } else {
            $UpdDataArr = $this->input->post();

            // echo "<pre>";
            // print_r($UpdDataArr);
            // die;
            if ($UpdDataArr) {
                $f_name = $UpdDataArr['name'];
                $m_name = ($UpdDataArr['middle_name']) ? ' '.$UpdDataArr['middle_name'].' ' : '';
                $l_name = ($UpdDataArr['lastname']) ? $UpdDataArr['lastname'] : '';
                $fullname = $f_name.$m_name.$l_name;

                $UpdataArr = ['lettercode' => $UpdDataArr['lettercode'],
                    'templete_id' => $UpdDataArr['Templete_id'],
                    'letter_date' => $UpdDataArr['letter_date'],
                    'prefix' => $UpdDataArr['prefix'],
                    'firstname' => $UpdDataArr['name'],
                    'middle_name' => $UpdDataArr['middle_name'],
                    'lastname' => $UpdDataArr['lastname'],
                    'userfullname' => $fullname,
                    'address1' => $UpdDataArr['address_one'],
                    'address2' => $UpdDataArr['address_two'],
                    'city' => $UpdDataArr['city'],
                    'state' => $UpdDataArr['state_id'],
                    'country' => $UpdDataArr['country'],
                    'pincode' => $UpdDataArr['pincode'],
                    'contact' => $UpdDataArr['contact_no'],
                    'email' => $UpdDataArr['email'],
                    'position' => $UpdDataArr['position'],
                    'sub_offerletter' => $UpdDataArr['subject'],
                    'company_id' => $UpdDataArr['company_id'],
                    'amount' => $UpdDataArr['amount'],
                    'hr_name' => $UpdDataArr['hrname'],
                    'entry_by' => $this->session->userdata('loginid'),
                    'cmp_location' => $UpdDataArr['cmp_location'], ];
                // echo "<pre>";
                // print_r($UpdataArr);
                // die();
                $this->db->where('main_letter.id', $letID);
                $resU = $this->db->update('main_letter', $UpdataArr);
                if ($resU) :
                       $this->session->set_flashdata('success_msg', 'Prospective Employee Update Successfully');
                redirect($_SERVER['HTTP_REFERER']);
                endif;
            }
        }
    }

    public function get_Template_Content($templete_id = '')
    {
        $this->db->select('a.id,a.description');
        $this->db->from('main_letter_templates as a');
        $this->db->where(['a.is_active' => '1', 'a.id' => $templete_id]);
        $respArr = $this->db->get()->row();

        return ($respArr) ? $respArr : null;
    }

    // //Save Upd Letter Content..
    // public function save_upd_letter_content(){
    //     $temp_empl_id = $_REQUEST['temp_emp_id'];
    //     $letter_desc = $_REQUEST['letter_desc'];

    //     $numRow = $this->db->get_where('main_letter_content', array('temp_empl_id' => $temp_empl_id))->num_rows();
    //     if ($numRow < 1) {
    //         $insertArr = array('temp_empl_id' => $temp_empl_id,'content' => $letter_desc, 'entry_by' => $this->loginuser_id, 'last_update_by' => $this->loginuser_id,'last_update' => date('Y-m-d h:i:s'));
    //         $this->db->insert('main_letter_content', $insertArr);
    //         $this->session->set_flashdata('success_msg', 'Prospective Employee Added Successfully.');
    //         redirect($_SERVER["HTTP_REFERER"]);
    //     } else {
    //         $updateArr = array('content' => $letter_desc,'entry_by' => $this->loginuser_id,'last_update' => date('Y-m-d h:i:s'));
    //         $WhereArr = array('temp_empl_id' => $temp_empl_id);
    //         $this->db->where($WhereArr);
    //         $this->db->update('main_letter_content', $updateArr);
    //         $this->session->set_flashdata('success_msg', 'Prospective Employee has been Updated Successfully .');
    //         redirect($_SERVER["HTTP_REFERER"]);
    //     }
    // }

    //Save Upd Letter Content..
    public function save_upd_letter_content()
    {
        $letterDesc = $this->input->post('letter_desc');
        $tempId = $this->input->post('temp_id');
        $letterTypeId = $this->input->post('letter_type_id');
        $templated = $this->input->post('template_id');
        $val = $this->input->post();
        //epd($val);

        $numRow = $this->db->get_where('main_temp_emp_letter', ['temp_id' => $tempId])->num_rows();
        if ($numRow < 1) {
            $insertArr = ['temp_id' => $tempId, 'letter_type_id' => $letterTypeId, 'template_id' => $templated, 'letter_content' => $letterDesc, 'entry_by' => $this->session->userdata('loginid'), 'update_by' => $this->session->userdata('loginid'), 'entry_date' => date('Y-m-d h:i:s')];
            // epd($insertArr);
            $this->db->insert('main_temp_emp_letter', $insertArr);
            $this->session->set_flashdata('success_msg', 'Prospective Employee Added Successfully.');
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $updateArr = ['letter_content' => $letterDesc, 'update_by' => $this->session->userdata('loginid'), 'last_update' => date('Y-m-d h:i:s')];
            // epd($updateArr);
            $WhereArr = ['temp_id' => $tempId];
            $this->db->where($WhereArr);
            $this->db->update('main_temp_emp_letter', $updateArr);
            $this->session->set_flashdata('success_msg', 'Prospective Employee has been Updated Successfully .');
            redirect($_SERVER['HTTP_REFERER']);
        }
    }

    //Add Letter Template..
    public function add_letter_templete()
    {
        $this->form_validation->set_rules('letter_type', 'Letter Type', 'required');
        $this->form_validation->set_rules('template_name', 'Template Name', 'required');
        $this->form_validation->set_rules('letter_desc', 'Letter Description', 'required');

        if ($this->form_validation->run() == false) {
            $data['error'] = '';
            $data['title'] = 'Add Letter template';
            $data['letterCode'] = $this->get_letter_code();
            //epd($data['letterCode']);
            $this->load->view('letter_view/add_letter_template', $data);
        } else {
            $postDataArr = $this->input->post();

            if ($postDataArr) {
                $insertArr = [
                'letter_type_id' => $postDataArr['letter_type'],
                'letter_templete_name' => $postDataArr['template_name'],
                'description' => $postDataArr['letter_desc'],
                'created_by' => $this->session->userdata('loginid'), ];
                // echo "<pre>";
                // print_r($insertArr);
                // die();
                $resU = $this->db->insert('main_letter_templates', $insertArr);
                if ($resU) :
                 $this->session->set_flashdata('success', 'Letter Record Add Successfully');
                redirect($_SERVER['HTTP_REFERER']);
                endif;
            }
        }
    }

    public function letter_template_ajax_data()
    {
        $list = $this->Letter_templte_Master_Model->get_datatables();
        $data = [];
        $no = $_POST['start'];

        foreach ($list as $val) {
            ++$no;
            $row = [];
            $row[] = $no;
            $row[] = $val->letter_type_name;
            $row[] = $val->letter_templete_name;
            $row[] = strip_tags($val->description);
            $row[] = '<a title="Letter Edit" href="javascript:void(0)" onclick="editpopup('.$val->id.')">'.'<spam class="fa fa-edit" data-toggle="modal" data-target="#exampleModal"></spam></a>&nbsp;';
            $data[] = $row;
        }

        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->Letter_templte_Master_Model->count_all(),
            'recordsFiltered' => $this->Letter_templte_Master_Model->count_filtered(),
            'data' => $data,
        ];
        //output to json format
        echo json_encode($output);
    }

    public function set_status_lockbyhr($lid)
    {
        if ($lid) {
            $this->db->where(['id' => $lid, 'status < ' => '3']);
            $resp = $this->db->update('main_letter', ['status' => '3']);

            if ($resp) {
                $this->session->set_flashdata('success_msg', 'Letter Status has been Updated Successfully .');
            }
        }
        redirect($_SERVER['HTTP_REFERER']);
    }

    //25-07-2022 vivek
    public function letter_template_update()
    {
        $update_id = $this->input->post('update_id');
        $UpostDataArr = $this->input->post();
        $UPdateArr = ['letter_type_id' => $UpostDataArr['letter_type_id'], 'letter_templete_name' => $UpostDataArr['tempelte_name'], 'description' => $UpostDataArr['dckeditor']];
        $this->db->where('id', $update_id);
        $resU = $this->db->update('main_letter_templates', $UPdateArr);
        if ($resU) :
         $this->session->set_flashdata('success', 'Letter Record Update Successfully');
        redirect(base_url('add_letter_templete'));
        endif;
    }

    public function letter_exportdata_word($letterdata)
    {
        $letterdata = $this->GetLetterContent($letterdata);
        // print_r($letterdata);
        // die();
        // Creating the new document...
        $phpWord = new \PhpOffice\PhpWord\PhpWord();

        /* Note: any element you append to a document must reside inside of a Section. */

        // Adding an empty Section to the document...
        $section = $phpWord->addSection(['marginTop' => 1000]);
        // $header = $section->addHeader();

        // Adding Text element to the Section having font styled by default...
        // $section->addText(
        //  $letterdata[0],
        // );
        // $section->addText(
        //     $letterdata->offer_date
        // );
        // $section->addText(
        //     ''
        // );
        // $section->addText(
        //     $letterdata->prefix.' '.$letterdata->userfullname
        // );
        // $section->addText(
        //     $letterdata->address1
        // );
        // $section->addText(
        // $letterdata->city.''.$letterdata->pincode
        // );
        // $section->addText(
        //     'Contact No : '.$letterdata->contact
        // );
        // $section->addText(
        //     'Email : '.$letterdata->email
        // );
        // $section->addText(
        //     ' '
        // );
        // $section->addText(
        //     'Subject : '.$letterdata->sub_offerletter
        // );
        // $section->addText(
        //     ''
        // );
        // $section->addText(
        //     'Dear '.$letterdata->firstname.' '.$letterdata->firstname.' ,'
        // );
        // $section->addText(
        //     ' '
        // );

        // \PhpOffice\PhpWord\Shared\Html::addHtml($section, $letterdata->offerlettter_desc);
        // print_r($letterdata[0]);
        // die();

//           $html = "<h1 style='font-size :20px;'>helo
        // </h1>";

        \PhpOffice\PhpWord\Shared\Html::addHtml($section, $letterdata[0]);

        // $section->addText(
        //     $letterdata->company_name
        // );

        // $section->addText(
        //     ''
        // );
        // $section->addText(
        //     $letterdata->hr_name
        // );
        // $section->addText(
        //     $letterdata->hr_position
        // );
        // $section->addText(
        //     ''
        // );
        // $section->addLine(['weight' => 1, 'width' => 600, 'height' => 0]);

        // $section->addText(
        //     'I accept the above offer and agree to join on or before …………………….'
        // );

        // $section->addText(
        //     '('.$letterdata->userfullname.')', ['align' => 'center', 'bold' => true]
        // );

        // Saving the document as OOXML file...
        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
        // epd($objWriter);
        $file = 'offerLetter.doc';

        $objWriter->save("public/uploads/letter/$file");
        force_download("public/uploads/letter/$file", null);
        //  unlink("public/uploads/letter/$file");
    }

    public function GetLetterContent($tempId)
    {
        $SingleRecordArr = $this->emplist_temp_model->GetSingleRowByID($tempId);
        $country = GetCountryById($SingleRecordArr->country);
        $state = GetStateById($SingleRecordArr->state);
        $city = GetCityById($SingleRecordArr->city);
        $position = GetPositionsById($SingleRecordArr->position);
        $companylist = GetCompanyNameById($SingleRecordArr->company_id);
        $comp_location = GetCompancyLocationById($SingleRecordArr->cmp_location);
        $hr = GetHrById($SingleRecordArr->hr_name);
        // $business_unit = GetBusinessunitById($SingleRecordArr->prefix);
        $Prefix = GetPrefixById($SingleRecordArr->prefix);
        // epd($Prefix);
        //  epd($SingleRecordArr);

        $this->db->select('a.*');
        $this->db->from('main_temp_emp_letter as a');
        $this->db->where('a.temp_id', $tempId);
        $data = $this->db->get()->row();

        //epd($data);
        // $find = $findArr;
        // $replace= $replaceArr;
        $find = ['<h1>', '<h2>', '{{FNAME}}', '{{LNAME}}', '{{FULLNAME}}', '{{OFFERDATE}}', '{{PREFIX}}', '{{ADDRONE}}', '{{ADDRTWO}}', '{{CITY}}', '{{STATE}}', '{{COUNTRY}}', '{{CONTACT}}', '{{EMAIL}}', '{{POSITION}}', '{{SUBOFFLETTER}}', '{{OFFERLETTERDESC}}', '{{COMPID}}', '{{HRNAME}}', '{{HRPOSITION}}', '{{COMPLOCATION}}', '{{AMT}}', '{{TMPEMPID}}', '{{LETTER_TYPE}}', '{{LETTER_NO}}', '{{BUSSINES_UNIT}}', '{{MIDDL_NAME}}', '{{AMOUNT}}', '{{PINCODE}}'];
        $replace = ["<h1 style='font-size :28px;'>", "<h2 style='font-size :24px;'>", $SingleRecordArr->firstname, $SingleRecordArr->lastname, $SingleRecordArr->userfullname, $SingleRecordArr->letter_date, $Prefix->prefix, $SingleRecordArr->address1, $SingleRecordArr->address2, $city->city_name, $state->state_name, $country->country_name, $SingleRecordArr->contact, $SingleRecordArr->email, $position->positionname, $SingleRecordArr->sub_offerletter, $SingleRecordArr->offerlettter_desc, $companylist->company_name, $hr->userfullname, $SingleRecordArr->position_name, $comp_location->city_name, $SingleRecordArr->amount, $SingleRecordArr->tmp_emp_id, 'Offer Letter', $SingleRecordArr->lettercode, 'CEG Pvt Ltd', $SingleRecordArr->middle_name, $SingleRecordArr->amount, $SingleRecordArr->pincode];
        $Arr = [$data->letter_content];
        $replacedata = str_replace($find, $replace, $Arr);
        // epd($replacedata);
        return $replacedata;
    }

    public function getletter_info($no)
    {
        $this->db->select('a.*,b.company_name');
        $this->db->from('main_letter as a');
        $this->db->join('tbl_companyname as b', 'b.id=a.company_id');
        $this->db->where('a.id', $no);
        $data = $this->db->get()->row();

        return $data;
    }

    public function Fetch_letter_decription()
    {
        $letertype = $this->input->post('lettertype');
        $positionn = $this->input->post('position');
        $ammount = $this->input->post('ammount');
        $templete_id = $this->input->post('templete_id');
        //print_r($ammount);
        // print_r($positionn);
        $cmp_location = $this->input->post('cmp_location');
        $this->db->select('a.*');
        $this->db->from('main_letter_type_master as a');
        $this->db->where('a.id', $templete_id);

        $letter_description = $this->db->get()->row();
        $position_update = $letter_description->description;
        // print_R($position_update);
        $replacedata = str_replace('Replaceposition', "$positionn", "$position_update");
        $replacedatatwo = str_replace('Replacecmp_location', "$cmp_location", "$replacedata");
        $replacedatathree = str_replace('Replacecmp_ammountttt', "$ammount", "$replacedatatwo");
        // print_r($replacedatathree);
        echo json_encode($replacedatathree);
    }

    public function addLetterformat()
    {
        $entery_by = $this->session->userdata('loginid');
        $data = $this->input->post();
        // print_r($data);
        $insarray = [
            'letter_type_id' => $data['letter_type'],
            'letter_templete_name' => $data['letter_templte_name'],
            'description' => $data['letter_dec'],
            'created_by' => $entery_by, ];
        $this->db->insert('main_letter_type_master', $insarray);
        echo json_encode('success');
//
        // $this->load->view()
    }

    //27-06-2022 vivek(ajax_get_byid)================
    public function ajax_get_byid()
    {
        $editId = $this->input->post('editId');
        $AllLetterDataById = $this->GetAllLetterDataById($editId);
        // epd($AllLetterDataById);
        echo json_encode($AllLetterDataById);
    }

    public function GetAllLetterDataById($editId)
    {
        $this->db->select('a.*');
        $this->db->from('main_letter as a');

        $this->db->where('a.id', $editId);
        $recors = $this->db->get()->row();

        return ($recors) ? $recors : '';
    }

    public function updateletter()
    {
        $letterId = $this->input->post('letterid');
        //epd($letterId);
        $data = $this->input->post();
        if ($data['saveandlock']) {
            $lock = 1;
            $status = 2;
        } else {
            $lock = 0;
        }

        $this->db->select('a.filename');
        $this->db->from('main_letter as a');
        $this->db->where('a.id', $letterId);
        $filename = $this->db->get()->row();
        $file = $filename->filename;
        $entery_by = $this->session->userdata('loginid');
        $fullname = $data['name'].' '.$data['lastname'];

        $insarray = [
            'offer_date' => $data['from_date'],
            'prefix' => $data['prefix'],
            'firstname' => $data['name'],
            'lastname' => $data['lastname'],
            'userfullname' => $fullname,
            'address1' => $data['address_one'],
            'address2' => $data['address_two'],
            'city' => $data['city'],
            'state' => $data['state'],
            'country' => $data['country'],
            'pincode' => $data['pincode'],
            'contact' => $data['contact_no'],
            'email' => $data['email'],
            'position' => $data['position'],
            'sub_offerletter' => $data['subject'],
            'offerlettter_desc' => $data['mdescription'],
            'offer_letter_fill' => $data['name'],
            'company_id' => $data['company_id'],
            'amount' => $data['amount'],
            'hr_name' => $data['hrname'],
            'hr_position' => $data['hr_position'],
            'entry_by' => $entery_by,
            'cmp_location' => $data['cmp_location'],
            'status' => $status ? $status : '',
            'lock' => $lock,
            'filename' => $file,
        ];

        unlink("public/uploads/letter/$file");
        $obj = (object) $insarray;
        // $this->letter_exportdata_word($obj);

        //update letter
        $this->db->where('main_letter.id', $letterId);
        $resU = $this->db->update('main_letter', $insarray);

        $this->session->set_flashdata('success', 'Letter Record Update Successfully');
        redirect(base_url('add_letter'));
    }

    public function add_tmp_employe($data)
    {
        $insarray = [
            'employeeId' => $data['emp_id'],
            'prefix_id' => $data['prefix'],
            'firstname' => $data['name'],
            'lastname' => $data['lastname'],
            'businessunit_id' => $data['business_unit'],
            'contactnumber' => $data['contact_no'],
            'emailaddress' => $data['email'],
        ];
        $this->db->insert('temp_hr_official_details', $insarray);
        // print_r($data);
        $insert_id = $this->db->insert_id();
        // print_R($insert_id);
        return $insert_id ? $insert_id : null;
    }

    public function sendletter()
    {
        $letter_id = $this->uri->segment(2);
        // print_r($letter_id);
        $letter_content = $this->GetLetterContent($letter_id);
        // print_r($letter_content[0]);
        // die();
        $this->db->select('a.*,b.letter_content,b.template_id as templete_id_main,d.letter_type_name');
        $this->db->from('main_letter as a');
        $this->db->join('main_temp_emp_letter as b', 'a.id=b.temp_id', 'LEFT');
        $this->db->join('main_letter_templates as c', 'c.id=b.template_id', 'LEFT');
        $this->db->join('letter_type_master as d', 'd.id=c.letter_type_id', 'LEFT');

        $this->db->where('a.id', $letter_id);
        $letter_data = $this->db->get()->row();
        // echo'<pre>';
        // print_r($letter_data);
        // die();
        // Abhishek Sharma work on 28-07-2022
        $phpWord = new \PhpOffice\PhpWord\PhpWord();

        $section = $phpWord->addSection(['marginTop' => 1000]);
        \PhpOffice\PhpWord\Shared\Html::addHtml($section, $letter_content[0]);
        $objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
        $rand = rand(111111, 11000000);
        $filename = $letter_data->letter_type_name.''.$letter_data->tmp_emp_id.''.$rand.'.doc';
        $objWriter->save("public/uploads/sendletter/$filename");
        // print_r($rand);

        // print_r($filename);
        // die();
        // force_download("public/uploads/sendletter/$file", null);
        // unlink("public/uploads/sendletter/$file");

        //end Abhishek

        // print_r($letter_data);
        // die();
        $to = "$letter_data->email";
        $subject = "$letter_data->sub_offerletter";
        $msgDetails = $this->load->view('email/letter', compact('letter_data'), true);
        $file = "public/uploads/sendletter/$filename";

        $this->send_letterMail($to, $subject, $msgDetails, $file);
        $uparray = ['status' => 4];
        $this->db->where('id', $letter_id);
        $this->db->update('main_letter', $uparray);

        redirect(base_url("edit_letter/$letter_id"));
    }

    public function send_letterMail($to, $subject, $msgDetails, $file)
    {
        $this->load->library('email');
        $this->email->initialize([
            'protocol' => 'smtp',
            'smtp_host' => 'mail.cegindia.com',
            'smtp_user' => 'marketing@cegindia.com',
            'smtp_pass' => 'MARK-2015ceg',
            'smtp_port' => 587,
            'crlf' => "\r\n",
            'newline' => "\r\n",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => true,
        ]);
        $this->email->from('marketing@cegindia.com', 'CEG HR Dept.');
       // $this->email->to('cegapps@cegindia.com',$subject); //$to
        $this->email->to($to,$subject); //$to
        // $this->email->bcc('cegapps@cegindia.com');
        $this->email->subject($subject);
        $this->email->message($msgDetails);
        $this->email->attach($file);
        $resp = $this->email->send();
        if ($resp) {
            $this->session->set_flashdata('success_msg', 'Letter Sent Successfully');
        }

        return ($resp) ? $resp : $this->email->print_debugger();
    }

    public function ajax_get_letterTemplete()
    {
        $templete_id = $this->input->post('editId');
        // echo "<pre>";
        //  print_r($templete_id);
        //  die();
        $this->db->select('a.*');
        $this->db->from('main_letter_templates as a');
        $this->db->where('id', $templete_id);
        $templte = $this->db->get()->row();
        echo json_encode($templte);
    }

    //Get Letter Template By ID..
    public function get_letter_templete($lettertypeID)
    {
        $this->db->select('a.id,a.letter_templete_name');
        $this->db->from('main_letter_templates as a');
        $this->db->where(['a.letter_type_id' => $lettertypeID, 'a.is_active' => '1']);
        $dataResult = $this->db->get()->result();

        return ($dataResult) ? $dataResult : null;
    }

    // public function lockLetter()
    // {
    //     $letter_id = $this->uri->segment(2);
    //     $uparray = ['lock' => '1'];
    //     $this->db->where('id ', $letter_id);
    //     $this->db->update('main_letter', $uparray);
    //     redirect(base_url('add_letter'));
    // }

    public function getstate()
    {
        $country_id = $this->input->post('country');
        $state = getState_country($country_id);
        echo json_encode($state);
    }

    public function getcity()
    {
        $state_id = $this->input->post('state');
        $city = getcity_State($state_id);
        echo json_encode($city);
    }

    public function getallstate()
    {
        $this->db->select('a.*');
        $this->db->from('tbl_states as a');
        $this->db->where(['a.isactive' => '1']);
        $states = $this->db->get()->result();

        return $states ? $states : '';
    }

    public function getallcity()
    {
        $this->db->select('a.*');
        $this->db->from('tbl_cities as a');
        $this->db->where(['a.is_active' => '1']);
        $states = $this->db->get()->result();

        return $states ? $states : '';
    }

    public function get_letter_code()
    {
        $recordArr = [];

        $this->db->select('a.*');
        $this->db->from('letter_code_set as a');
        $this->db->where(['a.status' => '1']);
        $lettterCode = $this->db->get()->result();

        if ($lettterCode) {
            foreach ($lettterCode as $key => $value) {
                $recordArr[$value->fld_id] = $value;
            }
        }

        return $recordArr ? $recordArr : '';
    }

    //Letter

    private function  getInterviewRecord($interview_id){
        
        $this->db->select('a.*,b.business_unit_id,b.company_id,b.company_location_id,b.employment_type,b.position');
        $this->db->from('job_interview as a');
        $this->db->join('jobs as b','b.id=a.job_id','left');
        $this->db->where('a.id',$interview_id);
        return  $this->db->get()->row();
    }
    
    private function  getCvmInterviewRecord($interview_id){
        $db1 = $this->db1->database;
        $db2 = $this->db2->database;
        $db3 = $this->db3->database;
        $db4 = $this->db4->database;
        $this->db->select('a.interview_type');
        $this->db->where('a.id',$interview_id);
        $this->db->from('job_interview_cvm as a');
        $querys= $this->db->get()->row();
        $interview_type = $querys->interview_type;

        if($interview_type == 'cv'){
            $this->db->select('a.* , cv.email as emailaddress,cv.fname,cv.mname,cv.lname,cv.dob,cv.phone,cv.gender,cv.fathername,cv.mothername,cv.aadharno,cv.panno,cv.onlinesource,cv.dob'); 
        
            $this->db->from('job_interview_cvm as a');
            $this->db->join("$db4.tblcv as cv", "cv.id = a.cv_id", "LEFT");
            $this->db->where('a.id',$interview_id);
            return  $this->db->get()->row();
        } else if($interview_type == 'job'){
            $this->db->select('a.* , j.title,ja.apply_by,cu.emailaddress,cv.fname,cv.mname,cv.lname,cv.dob,cv.phone,cv.gender,cv.fathername,cv.mothername,cv.aadharno,cv.panno,cv.onlinesource,cv.dob'); 
        
            $this->db->from('job_interview_cvm as a');
            $this->db->join("$db4.tbljobpost as j", "j.id = a.cvm_job_id", "LEFT");
            $this->db->join("$db4.jobpost_application as ja", "ja.id = a.jobpost_application_id", "LEFT");
            $this->db->join("$db4.candidate_users as cu", "cu.id = ja.apply_by", "LEFT");
            $this->db->join("$db4.tblcv as cv", "cv.email = cu.emailaddress", "LEFT");
            $this->db->where('a.id',$interview_id);
            return  $this->db->get()->row();
        } else {
            $this->db->select('a.* , cv.email as emailaddress,cv.first_name as fname,cv.middle_name as mname,cv.last_name as lname,cv.dob,cv.phone,cv.resume'); 
        
            $this->db->from('job_interview_cvm as a');
            $this->db->join("$db4.job_seeker as cv", "cv.id = a.cv_id", "LEFT");
            $this->db->where('a.id',$interview_id);
            return  $this->db->get()->row();
        }
    }
}