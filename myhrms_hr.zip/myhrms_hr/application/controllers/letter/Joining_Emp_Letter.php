<?php

// require_once 'bootstrap.php';
defined('BASEPATH') or exit('No direct script access allowed');
require 'vendor/autoload.php';

class Joining_Emp_Letter extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('session');
        $this->load->model('letter/Letter_accept_model');
        $this->load->model('mastermodel');
        $this->load->helper('url');
        // $this->db1 = $this->load->database('online', TRUE);
        // $this->db2 = $this->load->database('default', TRUE);
        // $this->db3 = $this->load->database('accdept_db', TRUE);
        // $this->db4 = $this->load->database('cvmanager', TRUE);
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['preFixRecArr'] = $this->mastermodel->GetTableData('main_prefix', ['isactive' => '1']);
        $data['roleRecArr'] = $this->mastermodel->GetTableData('main_roles', ['isactive' => '1']);
        $data['BunitsRecArr'] = $this->mastermodel->GetTableData('main_businessunits', ['isactive' => '1', 'id!=' => '0']);
        $data['JobGroupRecArr'] = $this->mastermodel->GetTableData('main_jobtitles', ['isactive' => '1']);
        $data['CompanyRecArr'] = $this->mastermodel->GetTableData('tbl_companyname', ['is_active' => '1']);
        $data['EMPCodeRow'] = $this->mastermodel->GetEmpIDCode();
        $data['EmpStatusArr'] = $this->mastermodel->GetTableData('tbl_employmentstatus', ['isactive' => '1']);
        $data['ActiveProjectListArr'] = $this->mastermodel->GetAllActiveProjectList();

        $data['Lt_EMPID_CEG'] = $this->mastermodel->GetLastEmpIdByCompanyID(1);
        $data['Lt_EMPID_CEGTH'] = $this->mastermodel->GetLastEmpIdByCompanyID(2);
        $data['Lt_EMPID_PCC'] = $this->mastermodel->GetLastEmpIdByCompanyID(3);
        $data['Lt_EMPID_TECHNO'] = $this->mastermodel->GetLastEmpIdByCompanyID(4);
        $data['Lt_EMPID_KCPL'] = $this->mastermodel->GetLastEmpIdByCompanyID(5);
        $data['Lt_EMPID_SKES'] = $this->mastermodel->GetLastEmpIdByCompanyID(6);
        $data['Lt_EMPID_VDP'] = $this->mastermodel->GetLastEmpIdByCompanyID(7);
        $data['Lt_EMPID_CegProj'] = $this->mastermodel->GetLastEmpIdCEGProj();
        $data['ReplacedWithAllUserListArr'] = $this->mastermodel->GetAllEmployeeListReplacedWith();
        $data['title'] = 'Tempory To Employe';
        $this->load->view('letter_view/temp_to_employe', $data);
    }

    public function getall_Accept_Offer_Letter_Employe()
    {
        // $start_date = $this->input->post('start_date');
        // $end_date = $this->input->post('end_date');
        $list = $this->Letter_accept_model->get_datatables();

        $data = [];
        $no = $_POST['start'];

        foreach ($list as $val) {
            ++$no;
            $GotTotLeave = 0;

            $row = [];
            $row[] = $no;
            //    $row[] = $val->ceg_code;
            $row[] = $val->temp_employe_id;
            $row[] = $val->userfullname;
            $row[] = $val->email;
            $row[] = $val->letter_type_name;
            $row[] = $val->position;
            $row[] = $val->hr_name;
            $row[] = '<a title="Letter Edit" href="javascript:void(0)" onclick="editpopup('.$val->id.')">'.'<spam class="fa fa-edit" data-toggle="modal" data-target="#exampleModal"></spam></a>&nbsp;';
            // $row[] = '<a title="Download"  href="'.base_url("../public/uploads/letter/$val->filename").'" download><spam class="fa fa-download"></spam></a>'.'&nbsp;&nbsp;'.$uplink.''.$up;
            $data[] = $row;
        }

        $output = [
            'draw' => $_POST['draw'],
            'recordsTotal' => $this->Letter_accept_model->count_all(),
            'recordsFiltered' => $this->Letter_accept_model->count_filtered(),
            'data' => $data,
        ];
        //output to json format
        echo json_encode($output);
    }

    public function get_temp_employe()
    {
        $letter_id = $this->input->post('letter_id');
        $this->db->select('*');
        $this->db->from('main_letter');
        $this->db->where('id', $letter_id);
        $employe_data = $this->db->get()->row();
        // print_r($employe_data); //getemploye datil
        echo json_encode($employe_data ? $employe_data : '');
    }

    public function addtemp_toemp()
    {
        $data = $this->input->post();
        // print_r($data);
        // die();
        $letter_id = $data['id'];
        $emp_id = $this->main_usersFormArr($data); //done
        //$temp_emp_id = $this->get_temp_emp_id($letter_id);
        // $this->update_employe_id_ontmp($temp_emp_id, $emp_id);
        $personal_data = $this->temp_hr_emp_personal_details($letter_id, $emp_id);

        $communication = $this->temp_hr_communication_details($letter_id, $emp_id); //done
        //done

        $empexperiancedetails = $this->get_tmp_temp_hr_empexperiancedetails($letter_id, $emp_id); // done
        $empskills = $this->temp_hr_empskills($letter_id, $emp_id); //done
        $temp_hr_empdependencydetails = $this->temp_hr_empdependencydetails($letter_id, $emp_id); //done
        $education = $this->temp_hr_empeducation_detail($letter_id, $emp_id); // done
        if ($emp_id > 0) {
            $this->temp_to_employe($letter_id);
            echo json_encode($emp_id);
        }
    }

    public function temp_hr_emp_personal_details($tmpemp_id, $emp_id)
    {
        // print_R($tmpemp_id);
        $this->db->select('*'); //user_id,genderid,mother_nm,maritalstatusid,maritaldate,nationalityid,ethniccodeid,racecodeid,languageid,language_known,dob,
        $this->db->from('temp_hr_emp_personal_details');
        $this->db->where('user_id', $tmpemp_id);
        $ins_array = $this->db->get()->row();
        // print_r($ins_array);
        unset($ins_array->id);
        unset($ins_array->user_id);
        $ins_array->user_id = $emp_id;
        // print_r($ins_array);
        // die();
        if ($ins_array) {
            $this->db->insert('main_emppersonaldetails', $ins_array);
        }

        return true;
    }

    public function temp_to_employe($letter_id)
    {
        $uparray = ['status' => '9'];
        $this->db->where('id', $letter_id);
        $this->db->update('main_letter', $uparray);

        return true;
    }

    //Main_users Form..
    public function main_usersFormArr($postRec)
    {
        // $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
        // $this->form_validation->set_rules('pincode', 'pincode', 'required');
        // $this->form_validation->set_rules('contact_no', 'Mobile Number ', 'required|regex_match[/^[0-9]{10}$/]'); //{10} for 10 digits number
        // $this->form_validation->set_rules('emp_id', 'Employe id ', 'required'); //{10} for 10 digits number
        // $this->form_validation->set_rules('business_unit', 'Bussiness Unit ', 'required'); //{10} for 10 digits number
        // $this->form_validation->set_rules('lettercode', 'Letter Code', 'required'); //{10} for 10 digits number
        // $this->form_validation->set_rules('Templete_id', 'Templete', 'required');
        // $this->form_validation->set_rules('subject', 'Subject', 'required');
        // $this->form_validation->set_rules('letter_date', 'Letter Date', 'required');
        // $this->form_validation->set_rules('prefix', 'Prefix', 'required');
        // $this->form_validation->set_rules('name', 'Name', 'required');
        // $this->form_validation->set_rules('lastname', 'Last Name', 'required');
        // $this->form_validation->set_rules('address_one', 'Address', 'required');
        // $this->form_validation->set_rules('address_two', 'Address', 'required');
        // $this->form_validation->set_rules('country', 'Country', 'required');
        // $this->form_validation->set_rules('state_id', 'State', 'required');
        // $this->form_validation->set_rules('city', 'City', 'required');
        // $this->form_validation->set_rules('position', 'Position', 'required');
        // $this->form_validation->set_rules('company_id', 'Company Id', 'required');
        // $this->form_validation->set_rules('cmp_location', 'Company Location', 'required');
        // $this->form_validation->set_rules('hrname', 'HR Name', 'required');
        // $this->form_validation->set_rules('amount', 'amount', 'required');

        // if ($this->form_validation->run() == false) {
        //     $data['error'] = $this->form_validation->error_array();
        //     echo json_encode($data);
        // // $temp_ids = get_temp_max_value();
        //     // $data['temp_id'] = $temp_ids;

        //     // $data['state'] = $this->getallstate();
        //     // $data['city'] = $this->getallcity();
        //     // $data['title'] = 'Add Letter';
        //     // //$data['form_data'] = $this->input->post();
        //     // //Get All Offer Letter,..

        //     // $data['AllTempleteArr'] = $this->get_letter_templete('1');
        //     // print_r($data['AllTempleteArr']);
        //     //   die();

        //     // $this->load->view('letter_view/add_letter', $data);
        // } else {
        $userFullName1 = ($postRec['first_name']) ? $postRec['first_name'] : '';
        $userFullName2 = ($postRec['middle_name']) ? ' '.$postRec['middle_name'] : '';
        $userFullName3 = ($postRec['last_name']) ? ' '.$postRec['last_name'] : '';
        $userFullName = $userFullName1.$userFullName2.$userFullName3;
        $employeeId = $postRec['employee_code'].$postRec['employee_id'];

        $insertArr = [
         'emprole' => $postRec['role'],
         'userstatus' => $postRec['employment_status'],
         'firstname' => $postRec['first_name'],
         'middle_name' => ($postRec['middle_name']) ? $postRec['middle_name'] : '',
         'lastname' => ($postRec['last_name']) ? $postRec['last_name'] : '',
         'userfullname' => $userFullName,
         'emailaddress' => $postRec['official_emailid'],
         'contactnumber' => $postRec['mob_number'],
         'backgroundchk_status' => 'Yet to start',
         'emptemplock' => '0',
         'empreasonlocked' => '',
         'emppassword' => md5('123456'),
         'createdby' => $this->session->userdata('loginid'),
         'createddate' => date('Y-m-d h:i:s'),
         'modifieddate' => date('Y-m-d h:i:s'),
         'employeeId' => $employeeId,
         'modeofentry' => $postRec['mode_employment'],
         'selecteddate' => date('Y-m-d', strtotime($postRec['dateofjoining'])),
         'company_id' => $postRec['company_id'],
         'ofc_locationid' => $postRec['joining_at'],
         'jobtitle_id' => $postRec['job_titlegroup'],
         'company_nameid' => $postRec['company_id'],
         'recruitment_for' => $postRec['recruitment_for'],
         'replaced_with_userid' => $postRec['replaced_with_userid'],
         'emp_onproject' => ($postRec['project_id']) ? $postRec['project_id'] : null,
         'emp_project_designation' => ($postRec['project_designationid']) ? $postRec['project_designationid'] : null,
         'ofcialemail' => $postRec['official_emailid'],
     ];
        // print_r($insertArr);
        // die();
        $this->db->insert('main_users', $insertArr);
        $this->db->trans_complete();

        $inserted_id = $this->db->insert_id();
        $this->insert_employe($postRec, $inserted_id);

        return ($inserted_id) ? $inserted_id : null;
        // }
    }

    public function update_employe_id_ontmp($temp_emp_id, $emp_id)
    {
        $uparray = ['user_id' => $emp_id,
                    'is_tmp_emp_joined' => 1,
];
        $this->db->where('fld_id', $temp_emp_id);
        $this->db->update('temp_hr_official_details', $uparray);

        return true;
    }

    public function insert_employe($postRec, $inserted_id)
    {
        $reportngmngr_io = GetReportingManagerIDByUserID($postRec['reporting_manager']);
        $ins_emplo = [
        'user_id' => $inserted_id,
        'date_of_joining' => date('Y-m-d', strtotime($postRec['dateofjoining'])),
        'reporting_manager' => $postRec['reporting_manager'],
        'emp_status_id' => $postRec['employment_status'],
        'businessunit_id' => $postRec['business_unit'],
        'department_id' => $postRec['department'],
        'ofc_locationid' => $postRec['business_unit'],
        'company_nameid' => $postRec['company_id'],
        'ofcialemail' => $postRec['official_emailid'],
        'replacementby_id' => $postRec['replaced_with_userid'],
        'jobtitle_id' => $postRec['job_titlegroup'],
        'position_id' => $postRec['designation'],
        'years_exp' => $PostRec['yearofexp_prev'],
        'prefix_id' => $postRec['prefix_id'],
        'extension_number' => $postRec['extension_number'],
        'office_number' => $postRec['mob_number'],
        'createdby' => $this->session->userdata('loginid'),
        'reporting_manager_io' => $reportngmngr_io,
       ];
        $data = $this->db->insert('main_employees', $ins_emplo);

        return $data ? $data : '';
    }

    public function get_tmp_education($tmp_id)
    {
        $this->db->select('*');
        $this->db->from('temp_hr_communication_details');
        $this->db->where('user_id', $tmp_id);
        $data = $this->db->get()->result();
        // $temp_toemp = [''];
        // print_r($data);

        return $data;
    }

    public function get_temp_emp_id($letter_id)
    {
        // print_r($letter_id);
        $this->db->select('tmp_emp_id');
        $this->db->from('main_letter');
        $this->db->where('id', $letter_id);
        $temp_emp = $this->db->get()->row();
        $temp_emp_id = $temp_emp->tmp_emp_id;
        // die();

        return $temp_emp_id ? $temp_emp_id : '';
    }

    public function temp_hr_empdependencydetails($tmpemp_id, $emp_id)
    {
        $this->db->select('dependent_name,dependent_relation,dependent_dob,dependent_age,aadhar_no,dependent_select');
        $this->db->from('temp_hr_empdependencydetails');
        $this->db->where('user_id', $tmpemp_id);
        $empdependencydetails = $this->db->get()->result();
        if ($empdependencydetails) {
            foreach ($empdependencydetails as $key => $val) {
                $val->user_id = $emp_id;
                $this->db->insert('main_empdependencydetails', $val);
            }
        }

        return true;
    }

    public function temp_hr_communication_details($tmpemp_id, $emp_id)
    {
        $this->db->select('personalemail,perm_streetaddress,perm_country,perm_state,perm_city,perm_pincode,current_streetaddress,current_country,current_state,current_city,current_pincode,emergency_name,emergency_namerelation,emergency_email,emergency_number');
        $this->db->from('temp_hr_communication_details');
        $this->db->where('user_id', $tmpemp_id);
        $data = $this->db->get()->result();
        if ($data) {
            foreach ($data as $key => $val) {
                $val->user_id = $emp_id;
                $this->db->insert('main_empcommunicationdetails', $val);
            }
        }

        return $data ? $data : '';
    }

    public function temp_hr_empeducation_detail($tmpemp_id, $emp_id)
    {
        $this->db->select('educationlevel,institution_name,spc_location,course,coursetype_id,percentage,from_date,specialization,highestedulevelfield');
        $this->db->from('temp_hr_empeducation_detail');
        $this->db->where('user_id', $tmpemp_id);
        $data = $this->db->get()->result();
        if ($data) {
            foreach ($data as $key => $val) {
                $val->user_id = $emp_id;
                $this->db->insert('main_empeducationdetails', $val);
            }
        }

        return $data ? $data : '';
    }

    public function get_tmp_temp_hr_empexperiancedetails($tmpemp_id, $emp_id)
    {
        $this->db->select('comp_name,comp_website,comp_location,comp_expdoctype,designation,from_date,to_date,reason_for_leaving,reference_name,reference_contact,reference_email,createdby,modifiedby,createddate,is_ceg_exper,ceg_exp_copmid,ceg_exp_projects,last_salary_drawn');
        $this->db->from('temp_hr_empexperiancedetails');
        $this->db->where('user_id', $tmpemp_id);
        $data = $this->db->get()->result();
        if ($data) {
            foreach ($data as $key => $val) {
                $val->user_id = $emp_id;
                $this->db->insert('main_empexperiancedetails', $val);
            }
        }

        return $data ? $data : '';
    }

    public function temp_hr_empskills($tmpemp_id, $emp_id)
    {
        $this->db->select('skillname,yearsofexp,competencylevelid,year_skill_last_used');
        $this->db->from('temp_hr_empskills');
        $this->db->where('user_id', $tmpemp_id);
        $data = $this->db->get()->result();
        if ($data) {
            foreach ($data as $key => $val) {
                $val->user_id = $emp_id;
                $this->db->insert('main_empskills', $val);
            }
        }

        return $data ? $data : '';
    }

    public function get_hr_id_position()
    {
        $hr_id = $this->input->post('hr_id');
        $posiotns = $this->get_hr_poasiotn($hr_id);
        echo json_encode($posiotns);
    }

    public function get_hr_poasiotn($hr_emp_id)
    {
        $this->db->select('position_id');
        $this->db->from('main_employees_summary');
        $this->db->where('user_id', $hr_emp_id);
        $emp_position = $this->db->get()->row();

        return $emp_position->position_id ? $emp_position->position_id : '';
    }
}