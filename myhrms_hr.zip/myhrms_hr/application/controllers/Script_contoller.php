<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Script_contoller extends CI_Controller {

    public function __construct() {
        parent::__construct();

      $this->db1= $this->load->database("accdept_db",true); // accounts
      $this->db2 = $this->load->database("default",true);// sentrifugo
    }

  public function index()
  {
    $db1 = $this->db1->database;// acounts
    $db2 = $this->db2->database;// sentrifugo 
    $this->db->select("$db1.a.user_id,$db2.b.employeeId,$db2.c.payrollcode,$db2.b.userfullname,$db2.d.date_of_joining,$db2.d.date_of_leaving,$db2.e.deptname");
    $this->db->from("$db1.ts_financial_year_emp_projwise as a");
    $this->db->join("$db2.main_users as b","$db2.b.id= $db1.a.user_id","LEFT");
    $this->db->join("$db2.emp_otherofficial_data as c","$db2.c.user_id=$db2.b.id","LEFT");
    $this->db->join("$db2.main_employees as d","$db2.d.user_id=$db2.c.user_id");
    $this->db->join("$db2.main_departments as e","$db2.e.id=$db2.d.department_id","LEFT");
	 $this->db->where("$db2.b.isactive",'1');
   $data = $this->db->get()->result();
   $this->db->select("$db2.a.id");
   $this->db->from("$db2.tm_projects as a");
   $all_project = $this->db->get()->result();
   $i=0;
   $total= array();
   foreach($data as $key=>$val)
   {
   
  //  $user_id = $val->user_id;
  $total['employee_detail'][$i] = $val;
   foreach($all_project as $keyy=>$vall)
   {
 

   $vald[$vall->id] = $this->fetch_project_hours($val->user_id,$vall->id);
 

   }
   $total['employee_detail'][$i]->total_hours = (object)$vald;
 
  //  $sum[] = $total;
  //  $total['employee_hours'] = $sum_hours;
 
$i++;

  
   }
   echo"<pre>";
   print_r($total);
   die();
   $this->load->view("script/hours",$total);
 
  }
  public function fetch_project_hours($user_id,$project_id){
    $db1 = $this->db1->database;// acounts
    $db2 = $this->db2->database;// sentrifugo 
    $this->db->select("SEC_TO_TIME(SUM(TIME_TO_SEC(a.total_hour))) as total_hours");
    $this->db->from("$db1.ts_financial_year_emp_projwise as a");
    $this->db->where("$db1.a.user_id",$user_id);
    $this->db->where("$db1.a.project_id",$project_id);
  $user_timesheet_data = $this->db->get()->row();
  return $user_timesheet_data?$user_timesheet_data->total_hours:'';
  // echo"<pre>";
  // print_r($user_timesheet_data);
  // die();

  }
 
	
	

}
