<?php

defined('BASEPATH') or exit('No direct script access allowed');
//require_once('vendor/autoload.php');
//use PhpOffice\PhpSpreadsheet\Spreadsheet;
//use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
class Hrms_emp_fam_insurance_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('All_employee_fam_insurance_model');
        $this->load->model('Employecsv_model');
        $this->load->library('form_validation');
        $this->load->helper('download');
        if (($this->session->userdata('loginid') == "") or ($this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
        } else {
            redirect(base_url(""));
        }
    }

    public function emp_list()
    {
        $data['title'] = "Employee Family Member Insured";
        
        $this->load->view("hrms_employee_list/employee_fam_insurance", $data);
    }

    //================Emp list for profile PDF =============================
    public function ajax_employee_list()
    {
        $list = $this->All_employee_fam_insurance_model->get_datatables();
        // epd($list);
        $data = array();
        $no = $_POST['start'];
          

        $gender ="";
        foreach ($list as $dataRow) {
        if($dataRow->gender_select == 1)
        {
            $gender ="Male";
        } 
        elseif($dataRow->gender_select == 2)
        {
            $gender = "Female";
        }
        elseif($dataRow->gender_select == 3)
        {
            $gender = "Other";
        }
        else
        {
            $gender = "Not Filled";
        }
            $no++;
            $row = array();
            $row[] = $no;
            
            $row[] = isset($dataRow->employeeId) ? $dataRow->employeeId : '';
            $row[] = isset($dataRow->userfullname) ? $dataRow->userfullname : '';
            $row[] = isset($dataRow->dependent_name) ? $dataRow->dependent_name : '';
            $row[] = isset($dataRow->dependent_relation) ? $dataRow->dependent_relation : '';          
            $row[] = isset($dataRow->dependent_dob) ? $dataRow->dependent_dob : '';          
            $row[] = $gender;         

            $data[] = $row;
        }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->All_employee_fam_insurance_model->count_all(),
            "recordsFiltered" => $this->All_employee_fam_insurance_model->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }
}
