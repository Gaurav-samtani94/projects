<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Userdashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->library('form_validation');
        $this->load->model('Emp_leave_model');
		$this->load->model('Emp_on_leave_tour_report_model');
        if ($this->session->userdata('loginid') == "") {
            redirect(base_url(""));
        }
        $permission = GetUserIDHRPermission();
        if (in_array($this->session->userdata('loginid'), $permission)) {
            // redirect(base_url("userdashboard"));
        } else {
            $this->logout();
            redirect('../../../myhrms', 'refresh');
        }
    }

    public function home() {
        $data['error'] = '';
        $data['title'] = 'Dashboard';
        $id = $this->session->userdata('loginid');
        $BasicDetailRec = $this->mastermodel->GetBasicRecLoginUser();
        $data['recInOutArr'] = $this->mastermodel->GetInOutTimeDetails($BasicDetailRec->thumbcode);
		$data['countEmpleaveceg'] = count($this->Emp_on_leave_tour_report_model->count_leave_by_businessid(1));
		$data['countEmpleavecegth'] = count($this->Emp_on_leave_tour_report_model->count_leave_by_businessid(2));
   $data['employeeLeaveData'] = $this->Emp_leave_model->get_employee_leave_data(); //Made by Abhishek
        $data['ActiveEmployeedata'] = $this->Emp_leave_model->ActiveEmployeedata();
   $data['empontourtoday'] = $this->Emp_on_leave_tour_report_model->emp_on_tour_today();
 //$data['floarwisedata'] = $this->Emp_leave_model->ActiveEmployefloar(); //abhishek 26/01/2022       
 $this->load->view('userdashboard_view', $data);
    }

    public function logout() {
        $this->session->sess_destroy();
        $this->session->unset_userdata('loginid');
        $this->session->unset_userdata('username');
        $this->session->set_userdata(array('loginid' => null, 'username' => null));
        redirect(base_url(""));
    }

}
