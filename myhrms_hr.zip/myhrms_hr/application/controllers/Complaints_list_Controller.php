<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
class Complaints_list_Controller extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
		$this->load->model('mastermodel');
		if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
    }

    public function complaints_list(){
		$data['title'] = "Complaints List";
		$data['complaints_lists'] = $this->complaints_lists();
		$this->load->view("/complaints_list/complaints_list_view",$data);		
	}

	/*Get all Complaints  -->table(add_complaints)*/
	public function complaints_lists(){
		$this->db->select('a.id,a.complaint_desc,,a.complaint_date,a.ticket_id,a.ticket_status,b.complaint_category as complaint_category,a.complaint_title,a.entryby');
        $this->db->from('add_complaints as a');
        $this->db->join('complaint_category_master as b', "a.complaint_cate=b.id", "LEFT");	
		$this->db->where(array('a.status' => '1'));
        $querArr = $this->db->get()->result();
        return ($querArr) ? $querArr : false; 	
	}
}
