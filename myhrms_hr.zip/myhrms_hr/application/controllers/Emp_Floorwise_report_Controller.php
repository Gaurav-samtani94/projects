<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Emp_Floorwise_report_Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('mastermodel');
        $this->load->model('Emp_Floorwise_report_model');
        $this->load->model('Emp_Floorwise_report_model_new');
        $this->load->library('form_validation');
        $this->load->helper('common_helper');
        if (($this->session->userdata('loginid') == "") or ( $this->session->userdata('assign_role') == "")) {
            redirect(base_url(""));
        }
		$permission = GetUserIDHRPermission();
		if (in_array($this->session->userdata('loginid'), $permission)) {
        }
		else
		{
			redirect(base_url(""));
		}
    }

    public function emp_floorwise_report_data() {
        $data['title'] = "Floor Emp list";
		// echo $data['title']; die;
		// $data['empArr'] = $this->Emp_Floorwise_report_model->floorwise_details();
		// echo "<pre>"; print_r($empArr); die;
        $this->load->view("floor_wise_emp_report/emp_floor_wise_report_view", $data);
    }

    public function ajax_emp_floorwise_report() {
		// echo "testing";
        $list = $this->Emp_Floorwise_report_model_new->get_datatables();
        $data = array();
        $no = $_POST['start'];
		// echo "<pre>"; print_r($list); die;
        foreach ($list as $kkeY => $dataRow) {
            $no++;
           
            $row = array();
            $row[] = $no;
            $row[] = ($dataRow->userfullname) ? $dataRow->prefix_name . " " . $dataRow->userfullname : "";
            $row[] = ($dataRow->employeeId) ? $dataRow->employeeId : "";
            $row[] = ($dataRow->department_name) ? $dataRow->department_name : "";
            $row[] = ($dataRow->floor_number) ? $dataRow->floor_number : "";
            $data[] = $row;
        }
        
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $this->Emp_Floorwise_report_model_new->count_all(),
            "recordsFiltered" => $this->Emp_Floorwise_report_model_new->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

}
