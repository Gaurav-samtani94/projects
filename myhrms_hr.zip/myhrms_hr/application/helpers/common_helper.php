<?PHP

//current_url
function thisurl()
{
    $actual_link = (isset($_SERVER['HTTP']) ? "http" : "https") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    return $actual_link;
}

//Get All Active Project Code By Durgesh
function get_all_active_project()
{
    $ci = &get_instance();
    $ci->load->database();
    $query = $ci->db->query("SELECT id,project_name FROM `tm_projects` WHERE is_active='1' AND (`id`!=86 and `id`!=41 and `id`!=119 and `id`!=93 and `id`!=132 and `id`!=94 and `id`!=92 and `id`!=16 and `id`!=116 and `id`!=115 and `id`!=15 and `id`!=114 and `id`!=131 and `id`!=130 and `id`!=113 and `id`!=121 and `id`!=117) ORDER BY `project_name` ASC ");
    return $query->result();
}

//Get Education By User ID...Though Durgesh
function GetEducationByUserid($userid)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("*");
    $ci->db->from("main_empeducationdetails");
    $ci->db->where(array('isactive' => '1', 'user_id' => $userid));
    $ci->db->order_by("id", "ASC");
    $data = $ci->db->get()->result();
    return ($data) ? $data : null;
}

//Get Experience By User ID...Though Durgesh
function GetExperienceByUserid($userid)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("*");
    $ci->db->from("main_empexperiancedetails");
    $ci->db->where(array('isactive' => '1', 'user_id' => $userid));
    $ci->db->order_by("id", "ASC");
    $data = $ci->db->get()->result();
    return ($data) ? $data : null;
}

//code by durgesh for package work details
function getpkgworkdetail($pkg_sum_id, $work_id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['pkg_work_id' => $work_id, 'pkg_summary_id' => $pkg_sum_id]);
    $datapkgworkdetail = $ci->db->get('package_work_detail')->row();
    return ($datapkgworkdetail) ? $datapkgworkdetail : null;
}

//code by durgesh for city name
function getprojectname($projid)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['fld_id' => $projid, 'status' => "1"]);
    $dataproject = $ci->db->get('project_master')->row();
    return ($dataproject) ? $dataproject : null;
}

//code by durgesh for contractor name
function getcontractorname($contractorid)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['fld_id' => $contractorid, 'status' => "1"]);
    $dataContractor = $ci->db->get('contractor_master')->row();
    return ($dataContractor) ? $dataContractor : null;
}

//code by durgesh for city name
function getcityname($cityid)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['fld_id' => $cityid, 'status' => "1"]);
    $dataCity = $ci->db->get('tbl_cities')->row();
    return ($dataCity) ? $dataCity : null;
}

//code by durgesh for package data
function get_package_data($proj_summr_id, $pkg_id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['proj_summ_id' => $proj_summr_id, "pkg_number" => $pkg_id]);
    $datapackage = $ci->db->get('package_summary')->result();
    return ($datapackage) ? $datapackage : null;
}

function getAllMasterMenu()
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['parent' => "0", 'status' => "1", 'menu_category' => "2"]);
    $dataMenu = $ci->db->get('menu_master')->result();
    return ($dataMenu) ? $dataMenu : null;
}

function getSecondAllMasterMenu()
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['parent' => "0", 'status' => "1"]);
    $ci->db->where(['fld_id' => "15"]);
    $dataMenu = $ci->db->get('menu_master')->result();
    return ($dataMenu) ? $dataMenu : null;
}

function getChildMenuByParentID($parentID)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['parent' => $parentID, 'status' => "1"]);
    $dataMenu = $ci->db->get('menu_master')->result();
    return ($dataMenu) ? $dataMenu : null;
}

function checkRolePermission($accessurl)
{
    $ci = &get_instance();
    $LoginUserRole = $ci->session->userdata('assign_role');
    if ($LoginUserRole == "1") {
        $accesArr = array("add_project", "project_data_ajax", "editproject", "district_management", "district_data_ajax", "editdistrict", "component_management", "component_data_ajax", "edit_component");
    }
    if (in_array($accessurl, $accesArr)) {
        return true;
    } else {
        redirect(base_url("access_denied"));
    }
}

// Get Single Rec Details By Clearnce ID..
function GetSingleRec_Clearance($tblWorkID)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['work_id' => $tblWorkID, 'status' => "1"]);
    $dataMenu = $ci->db->get('clearance')->row();
    return ($dataMenu) ? $dataMenu : null;
}

// Get Single Rec Details By Physical Progress ID..
function GetSingleRec_PhysicalProgress($tblWorkID)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->where(['work_id' => $tblWorkID, 'status' => "1"]);
    $dataMenu = $ci->db->get('physical_progress_details')->row();
    return ($dataMenu) ? $dataMenu : null;
}

//Get Profile Details..
function GetBasicRecLoginUser()
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->load->model('mastermodel');
    $dataRec = $ci->mastermodel->GetBasicRecLoginUser();
    return ($dataRec) ? $dataRec : null;
}

//code by gaurav
function get_emp_dpt_data($id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("department_id");
    $ci->db->from("main_employees_summary");
    $ci->db->where(array('isactive' => '1', 'user_id' => $id));
    $data = $ci->db->get()->result();
    return ($data) ? $data : null;
}

//Return Month
function getDateDiffMonth($from_ymd, $to_ymd)
{
    $datetime1 = new DateTime($from_ymd);
    $datetime2 = new DateTime($to_ymd);
    $interval = $datetime2->diff($datetime1);
    return (($interval->format('%y') * 12) + $interval->format('%m'));
}

function get_businessunits()
{
    $ci = &get_instance();
    $ci->load->database();
    $query = $ci->db->query("SELECT id,unitname FROM `main_businessunits` WHERE isactive='1' ");
    return $query->result();
}

function get_companyname()
{
    $ci = &get_instance();
    $ci->load->database();
    $query = $ci->db->query("SELECT * FROM `tbl_companyname` WHERE is_active='1' ORDER BY company_name");
    return $query->result();
}

function get_departments()
{
    $ci = &get_instance();
    $ci->load->database();
    $query = $ci->db->query("SELECT id,deptname FROM `main_departments` WHERE isactive='1'ORDER BY deptname ");
    return $query->result();
}

function get_designation()
{
    $ci = &get_instance();
    $ci->load->database();
    $query = $ci->db->query("SELECT id,positionname FROM `main_positions` WHERE isactive='1'ORDER BY positionname");
    return $query->result();
}

function getUsernameByID($id)
{
    $ci = &get_instance();
    $arr = array('id' => $id, 'isactive' => '1');
    $ci->db->select('*');
    $ci->db->from('main_users');
    $ci->db->where($arr);
    $query = $ci->db->get();
    $result = $query->result();
    return $result;
}

function countmenpower($groupID, $st_date, $end_date)
{
    $ci = &get_instance();
    if ($end_date == ''):
        $end_date = date("Y-n-j", strtotime("last day of previous month"));
    endif;
    if ($st_date == ''):
        $st_date = date("Y-n-j", strtotime("first day of previous month"));
    endif;
    $ci->db->select('a.*');
    $ci->db->from('main_users as a');
    $ci->db->where_not_in('b.isactive', '1');
    $ci->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
    $ci->db->where('date_of_leaving >=', $st_date);
    $ci->db->where('date_of_leaving <=', $end_date);
    $ci->db->where(array("b.jobtitle_id" => $groupID));
    $ci->db->group_by('b.user_id');
    $recArr = $ci->db->get()->num_rows();
    return ($recArr) ? $recArr : '0';
}

function countmenpower_joined($groupID, $st_date, $end_date)
{
    if ($end_date == ''):
        $end_date = date("Y-n-j", strtotime("last day of previous month"));
    endif;
    if ($st_date == ''):
        $st_date = date("Y-n-j", strtotime("first day of previous month"));
    endif;
    $ci = &get_instance();
    $ci->db->select('a.*');
    $ci->db->from('main_users as a');
    $ci->db->where('b.isactive', '1');
    $ci->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
    $ci->db->where(array("b.businessunit_id" => '3'));
    $ci->db->where('date_of_joining >=', $st_date);
    $ci->db->where('date_of_joining <=', $end_date);
    $ci->db->where(array("b.jobtitle_id" => $groupID));
    $ci->db->group_by('b.user_id');
    $recArr = $ci->db->get()->num_rows();
    return ($recArr) ? $recArr : '0';
}

function countmenpower_open_bal($groupID, $st_date, $end_date)
{
    if ($end_date == ''):
        $end_date = date("Y-n-j", strtotime("last day of previous month"));
    endif;
    if ($st_date == ''):
        $st_date = date("Y-n-j", strtotime("first day of previous month"));
    endif;
    $ci = &get_instance();
    $ci->db->select('a.*');
    $ci->db->from('main_users as a');
    $ci->db->where('b.isactive', '1');
    $ci->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
    $ci->db->where(array("b.businessunit_id" => '3'));
    $ci->db->where('date_of_joining <', $st_date);
    $ci->db->where(array("b.jobtitle_id" => $groupID));
    $ci->db->group_by('b.user_id');
    $recArr = $ci->db->get()->num_rows();
    return ($recArr) ? $recArr : '0';
}

function countcom_report($st_date, $end_date, $com_name)
{
    $ci = &get_instance();
    $ci->db->select('a.id');
    $ci->db->from('main_users as a');
    $ci->db->where_not_in('b.isactive', '1');
    $ci->db->join("main_employees_summary as b", 'a.id = b.user_id', 'left');
    $ci->db->join("emp_otherofficial_data as c", 'c.user_id = b.user_id', 'left');
    if ($com_name != ''):
        $ci->db->where(array("c.company_name" => $com_name));
    endif;
    //if ($unit_name != ''):
    //$ci->db->wher_in("b.businessunit_id" => '3'));
    //endif;
    $ci->db->where('date_of_leaving >=', $st_date);
    $ci->db->where('date_of_leaving <=', $end_date);
    $ci->db->group_by('b.user_id');
    $recArr = $ci->db->get()->num_rows();
    return ($recArr) ? $recArr : '0';
}

//Project Name By Id..
function get_project_name($prjid)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("id,project_name");
    $ci->db->from("tm_projects");
    $ci->db->where(array('is_active' => '1', 'id' => $prjid));
    $data = $ci->db->get()->row_array();
    return ($data) ? $data['project_name'] : 'null';
}

function countcom_report_joined($st_date, $end_date, $com_name)
{

    $ci = &get_instance();
    $ci->db->select('a.user_id');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where('a.isactive', '1');
    $ci->db->join("emp_otherofficial_data as b", 'b.user_id = a.user_id', 'left');
    if ($com_name != ''):
        $ci->db->where(array("b.company_name" => $com_name));
    endif;
    // if ($unit_name != ''):
    //$ci->db->where(array("a.businessunit_id" => '3'));
    //endif;
    $ci->db->where('a.date_of_joining >=', $st_date);
    $ci->db->where('a.date_of_joining <=', $end_date);
    $ci->db->group_by('a.user_id');
    $recArr = $ci->db->get()->num_rows();
    return ($recArr) ? $recArr : '0';
}

function countcom_report_open_bal($st_date, $com_name)
{
    $ci = &get_instance();
    $ci->db->select('a.user_id');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where('a.isactive', '1');
    $ci->db->join("emp_otherofficial_data as b", 'b.user_id = a.user_id', 'left');
    if ($com_name != ''):
        $ci->db->where(array("b.company_name" => $com_name));
    endif;
    //if ($unit_name != ''):
    // $ci->db->where(array("a.businessunit_id" => '3'));
    // endif;
    $ci->db->where('a.date_of_joining <', $st_date);
    $ci->db->group_by('a.user_id');
    $recArr = $ci->db->get()->num_rows();
    return ($recArr) ? $recArr : '0';
}

//Mode of Employeement..
function ModeofEmployeement()
{
    $ci = &get_instance();
    $recArr = array(
        '' => 'Select mode of entry',
        'Dummy' => 'Dummy',
        'Direct' => 'Direct',
        'Interview' => 'Interview',
        'Other' => 'Other',
        'Reference' => 'Reference',
    );
    return ($recArr) ? $recArr : '0';
}

//Get All Department By B-Unit ID.. Asheesh
function GetAllDepartmentByBUnit($bunitID)
{
    $ci = &get_instance();
    $ci->db->select('a.id,a.deptname');
    $ci->db->from('main_departments as a');
    $ci->db->where(array('a.isactive' => '1', "a.unitid" => $bunitID));
    $ci->db->order_by('a.deptname', "ASC");
    $recArr = $ci->db->get()->result();
    return ($recArr) ? $recArr : null;
}

//Get All Reporting Manager By B-Unit ID.. Asheesh next abhishek change this
function GetAllRepManagerByBUnit($bunitID)
{
    $ci = &get_instance();
    if ($bunitID == 3) {
        $ci->db->select('a.user_id,a.userfullname,a.employeeId');
        $ci->db->from('main_employees_summary as a');
        $ci->db->where(array('a.isactive' => '1'));

        $whereArr = '(a.businessunit_id="1" or a.businessunit_id = "3")';
        $ci->db->where($whereArr);

        $ci->db->order_by('a.userfullname', "ASC");
        $ci->db->group_by('a.user_id');
        $recArr = $ci->db->get()->result();
    } else {
        $ci->db->select('a.user_id,a.userfullname,a.employeeId');
        $ci->db->from('main_employees_summary as a');

        $whereArr = '(a.businessunit_id="1" or a.businessunit_id = "2")';
        $ci->db->where($whereArr);

        $ci->db->where(array('a.isactive' => '1'));
        $ci->db->order_by('a.userfullname', "ASC");
        $ci->db->group_by('a.user_id');
        $recArr = $ci->db->get()->result();
    }
    return ($recArr) ? $recArr : null;
}

//Get All Designation By Job Tit..
function GetAllDesignationByJtitID($JobtitID)
{
    $ci = &get_instance();
    $ci->db->select('a.id,a.positionname');
    $ci->db->from('main_positions as a');
    $ci->db->where(array('a.isactive' => '1', "a.jobtitleid" => $JobtitID));
    $ci->db->order_by('a.positionname', "ASC");
    $recArr = $ci->db->get()->result();
    return ($recArr) ? $recArr : null;
}

//Get All Project Designation By ProjID..
function GetAllProjDesignationByProjID($ProjID = '')
{
    $ci = &get_instance();
    $ci->load->model('mastermodel');
    $designRec = $ci->mastermodel->set_prodesignation_byprojidbd_dropd_ajax_new($ProjID);
    return ($designRec) ? $designRec : null;
}

function AttendanceTypeArr()
{
    $ci = &get_instance();
    $AttTypeArr = ["1" => 'Card', "2" => 'Finger', "3" => 'Both'];
    return ($AttTypeArr) ? $AttTypeArr : null;
}

//Get Bunit By Empl ID..
function GetBunitByUserID($userID)
{
    $ci = &get_instance();
    $ci->db->select('a.businessunit_id');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where(array('a.isactive' => '1', "a.user_id" => $userID));
    $recArr = $ci->db->get()->row();
    return ($recArr) ? $recArr->businessunit_id : "";
}

//Get Rep Manager Id By UserId..
function GetReportingManagerIDByUserID($userID)
{
    $ci = &get_instance();
    $ci->db->select('a.reporting_manager');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where(array('a.isactive' => '1', "a.user_id" => $userID));
    $recArr = $ci->db->get()->row();
    return ($recArr) ? $recArr->reporting_manager : "";
}

//(HR Functions Use) Employee Ids for HR Permissions..
function GetUserIDHRPermission()
{
    $ci = &get_instance();
    $ci->db->select("a.user_id");
    $ci->db->from("main_employees_summary as a");
    $ci->db->where(array('a.isactive' => '1'));
    $ci->db->where("(a.department_id='11' OR a.department_id='29')", null, false);
    $empHridArr = $ci->db->get()->result();
    $recArr = array("297", "296", "2787", "2789", "2788", "2888", "175", "1","2");
    if ($empHridArr) {
        foreach ($empHridArr as $roWs) {
            $recArr[] = $roWs->user_id;
        }
    }
    return ($recArr) ? $recArr : null;
}

//======= (Gaurav) Start Code 29-02-2020 ==============//

function countemponfloor_names_new($floorId, $groupID)
{
    $today = date("Y-m-d");
    $ci = &get_instance();
    $ci->db->select("a.userfullname,a.jobtitle_name,a.employeeId");
    $ci->db->from("main_employees_summary as a");
    $ci->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
    $ci->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
    $ci->db->where(array("a.isactive" => "1", "b.status" => "1", "b.floor_number" => $floorId, "a.jobtitle_id" => $groupID));
    $ci->db->where("c.LogDate LIKE '%$today%'");
    // $ci->db->where("c.Direction", "in");
    $ci->db->order_by("c.DeviceLogId", "ASC");
    $ci->db->group_by("c.UserId");
    $recArr = $ci->db->get()->result();
    // $recArr = $ci->db->get()->num_rows();
    // return ($recArr) ? $recArr : null;
    return $recArr;
}

function countemponfloor($floorId, $groupID)
{
    $ci = &get_instance();
    $today = date("Y-m-d");
    $ci->db->select("c.*");
    $ci->db->from("main_employees_summary as a");
    $ci->db->join("emp_otherofficial_data as b", "a.user_id=b.user_id", "LEFT");
    $ci->db->join("DeviceLogs_Processed as c", "c.UserId=b.machine_id", "LEFT");
    $ci->db->where(array("a.isactive" => "1", "b.status" => "1", "b.floor_number" => $floorId, "a.jobtitle_id" => $groupID));
    $ci->db->where("c.LogDate LIKE '%$today%'");
    $ci->db->where("c.Direction", "in");
    $ci->db->order_by("c.DeviceLogId", "ASC");
    $ci->db->group_by("c.UserId");
    $recArr = $ci->db->get()->num_rows();
    return ($recArr) ? $recArr : '0';
}


//Last Status of Appraisal By UserId..
function LastApprStatusByuserID($userID)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("a.emp_io_lock,a.emp_self_lock,a.fld_id,a.emp_ro_lock");
    $ci->db->from("appr_action_master as a");
    $ci->db->where(array('a.status' => '1', 'a.user_id' => $userID));
    $ci->db->order_by("a.fld_id", "DESC");
    $SngldataArr = $ci->db->get()->row();
    return ($SngldataArr) ? $SngldataArr : null;
}

function get_ro_details_by_Id($userID)
{
    $ci = &get_instance();
    $ci->db->select('a.userfullname');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where(array('a.user_id' => $userID, 'a.isactive' => '1'));
    $RecRows = $ci->db->get()->row();
    return ($RecRows) ? $RecRows->userfullname : null;
}

function get_project_names()
{
    $ci = &get_instance();
    $ci->load->database();
    $query = $ci->db->query("SELECT id,project_name FROM `tm_projects` WHERE is_active='1' ORDER BY project_name ASC ");
    return $query->result();
}

//======= (Gaurav) End Code 03-03-2020 ==============//
//================12-03-2020 ========================
function get_empctc_detail($userID)
{
    $ci = &get_instance();
    $ci->db->select_max('a.empctc');
    // $ci->db->select('a.empctc');
    $ci->db->from('main_empsal_increment as a');
    $ci->db->where(array('a.user_id' => $userID, 'a.isactive' => '1'));
    $RecRows = $ci->db->get()->row();
    return ($RecRows) ? $RecRows->empctc : null;
}

//Asheesh 17-03-2020..
function get_floor_detail()
{
    $ci = &get_instance();
    $FloorArr = array(
        "-1" => "Basement (-1)",
        "0" => "Ground Floor (0)",
        "1" => "1st. Floor (1)",
        "2" => "2nd. Floor (2)",
        "3" => "3rd. Floor (3)",
        "4" => "4th. Floor (4)",
        "5" => "5th. Floor (5)",
        "6" => "6th. Floor (6)",
        "7" => "7th. Floor (7)",
        "8" => "8th. Floor (8)",
        "9" => "9th. Floor (9)",
    );
    return ($FloorArr) ? $FloorArr : null;
}

function GetAllStateBycountryID($countryid)
{
    $ci = &get_instance();
    $resultArr = null;
    if ($countryid) {
        $ci->db->select('a.id,a.state_name');
        $ci->db->from('tbl_states as a');
        $ci->db->where(array('a.country_id' => $countryid, 'a.isactive' => '1'));
        $ci->db->order_by('a.state_name', 'ASC');
        $resultArr = $ci->db->get()->result();
    }
    return ($resultArr) ? $resultArr : null;
}
// function GetAllStateBycountryID($countryid)
// {
// $ci = &get_instance();
// $resultArr = null;
// if ($countryid) {
// $ci->db->select('state_id,state_name');
// $ci->db->from('states');
// $ci->db->where(array('country_id' => $countryid, 'status' => '1'));
// $ci->db->order_by('state_name', 'ASC');
// $resultArr = $ci->db->get()->result();
// }
// return ($resultArr) ? $resultArr : null;
// }
function GetAllCityByStateID($stateid)
{
    $ci = &get_instance();
    $resultArr = null;
    if ($stateid) {
        $ci->db->select('a.id as city_id,a.city_name');
        $ci->db->from('tbl_cities as a');
        $ci->db->where(array('a.state_id' => $stateid, 'a.is_active' => '1'));
        $ci->db->order_by('a.city_name', 'ASC');
        $resultArr = $ci->db->get()->result();
    }
    return ($resultArr) ? $resultArr : null;
}
// function GetAllCityByStateID($stateid)
// {
// $ci = &get_instance();
// $resultArr = null;
// if ($stateid) {
// $ci->db->select('city_id,city_name');
// $ci->db->from('cities');
// $ci->db->where(array('state_id' => $stateid, 'status' => '1'));
// $ci->db->order_by('city_name', 'ASC');
// $resultArr = $ci->db->get()->result();
// }
// return ($resultArr) ? $resultArr : null;
// }

//Competency Level...
function CompetencyLevel()
{
    $ci = &get_instance();
    $returnArr = array("1" => "Basic", "2" => "Expert", "3" => "Medium");
    return ($returnArr) ? $returnArr : null;
}

//Count Designation On Category..
function CountAssignDesignin_desigCateg($desigCateg)
{
    $ci = &get_instance();
    $resultreturn = '0';
    if ($desigCateg) {
        $ci->db->select('fld_id');
        $ci->db->from('assign_designation_category');
        $ci->db->where(array('designation_categoryid' => $desigCateg, 'status' => '1'));
        $resultreturn = $ci->db->get()->num_rows();
    }
    return ($resultreturn) ? $resultreturn : null;
}

//coded on 26-4-2020
function get_locationBy_ID($id)
{
    $ci = &get_instance();
    $ci->db->select('a.city_name');
    $ci->db->from('tbl_ofclocation as a');
    $ci->db->where(array('a.id' => $id, 'a.is_active' => '1'));
    // $ci->db->where("a.LogDate LIKE '%$today%'");
    $RecRows = $ci->db->get()->row();
    return ($RecRows) ? $RecRows->city_name : null;
}

function GetAllPunchDetail($punchDate, $userID)
{

    $ci = &get_instance();
    $ci->load->model('Attendance');
    $punchRecs = $ci->Attendance->GetAllPunchDetail($punchDate, $userID);
    return ($punchRecs) ? $punchRecs : null;
}

function GetAllPunchDetailNew($punchDate, $userID)
{
    $ci = &get_instance();
    $ci->db->select("DATE_FORMAT(`LogDate`,'%H:%i:%s %p') as punchtime");
    $ci->db->from('DeviceLogs_Processed');
    $ci->db->where("(`UserId` = '" . $userID . "')");
    $ci->db->where("LogDate LIKE '%$punchDate%'");
    $ci->db->order_by("LogDate", "ASC");
    $ci->db->group_by("LogDate");
    $PunchRecData = $ci->db->get()->result();
    //return $PunchRecData;
    $In_timeArr = array();
    $Out_timeArr = array();

    if ($PunchRecData) {
        foreach ($PunchRecData as $kKeY => $rEcd) {
            $returnM = ($kKeY % 2);
            if ($returnM == 0) {
                array_push($In_timeArr, $rEcd->punchtime);
            }
            if ($returnM == 1) {
                array_push($Out_timeArr, $rEcd->punchtime);
            }
        }
        return array("intime" => $In_timeArr, "outtime" => $Out_timeArr);
    } else {
        return array("intime" => '', "outtime" => '');
    }
}

//=========================coded on 27-06-2020===========================================
function getIo_RO_remark($id, $year)
{
    $ci = &get_instance();
    $ci->db->select("*");
    $ci->db->from('appr_performfactor');
    $ci->db->where(array('status' => '1', 'appr_parent_id' => $id));
    if ($year):
        $ci->db->like('entry_date', $year);
    endif;
    $userRec = $ci->db->get()->result();
    return ($userRec) ? $userRec : null;
}

//code start by Anil kumar --> get Location 03-07-2020
function get_location()
{
    $ci = &get_instance();
    $ci->load->database();
    $query = $ci->db->query("SELECT id,city_name FROM tbl_ofclocation WHERE is_active='1' ");
    return $query->result();
}
//code end by Anil kumar --> get Location 03-07-2020

//code start by Anil kumar --> get business_unit name 06-07-2020
function get_business_unit_name($business_unit_id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("unitname");
    $ci->db->from("main_businessunits");
    $ci->db->where(array('isactive' => '1', 'id' => $business_unit_id));
    $data = $ci->db->get()->row_array();
    return ($data) ? $data['unitname'] : 'null';
}
//code end by Anil kumar --> get business_unit name 06-07-2020

//code start by Anil kumar --> get dept name 06-07-2020
function get_dept_name($dept_id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("deptname");
    $ci->db->from("main_departments");
    $ci->db->where(array('isactive' => '1', 'id' => $dept_id));
    $data = $ci->db->get()->row_array();
    return ($data) ? $data['deptname'] : 'null';
}
//code end by Anil kumar --> get dept name 06-07-2020

//code start by Anil kumar --> get location  06-07-2020
function get_location_value($location_id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("city_name");
    $ci->db->from("tbl_ofclocation");
    $ci->db->where(array('is_active' => '1', 'id' => $location_id));
    $data = $ci->db->get()->row_array();
    return ($data) ? $data['city_name'] : 'null';
}
//code end by Anil kumar --> get location 06-07-2020

//code start by Anil kumar --> get company name 06-07-2020
function get_company_name($company_id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("company_name");
    $ci->db->from("tbl_companyname");
    $ci->db->where(array('is_active' => '1', 'id' => $company_id));
    $data = $ci->db->get()->row_array();
    return ($data) ? $data['company_name'] : 'null';
}
//code end by Anil kumar --> get company name 06-07-2020

//Coded by gaurav on 15-07-2020
function get_shiftTiming_byUserId($uId)
{
    $ci = &get_instance();
    // $uId = $ci->session->userdata('loginid');
    $ci->db->select("*");
    $ci->db->from("emp_otherofficial_data");
    $ci->db->where(array("status" => "1", "user_id" => $uId));
    $rsp = $ci->db->get()->row();
    return ($rsp) ? $rsp->shift_in_time : "";
}

//code start by Anil kumar --> get all news category for dropdown 22-07-2020
function get_news_category()
{
    $ci = &get_instance();
    $ci->load->database();
    $query = $ci->db->query("SELECT id,news_category FROM news_category_master WHERE status='1' ");
    return $query->result();
}
//code start by Anil kumar --> get all news category for dropdown 22-07-2020

/* * ************* For search the user record coded by durgesh(16-01-2020)************ */

function getuserrecord()
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('b.*');
    $ci->db->from('main_users as a');
    $ci->db->join('main_employees_summary as b', 'b.user_id=a.id', 'left');
    $ci->db->where('a.isactive', '1');
    $ci->db->order_by('a.id');
    $ci->db->group_by('a.id');
    $result = $ci->db->get()->result();
    return ($result) ? $result : nul;
}

function get_ro_full_details_by_Id($userID)
{
    $ci = &get_instance();
    $ci->db->select('a.userfullname,a.user_id,a.employeeId,a.reporting_manager,contactnumber,a.emailaddress');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where(array('a.user_id' => $userID, 'a.isactive' => '1'));
    $RecRows = $ci->db->get()->row();
    return ($RecRows) ? $RecRows : null;
}

function LeaveCheckOfEmployee($userId, $date)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('user_id');
    $ci->db->from("main_leaverequest");
    $ci->db->where(array("user_id" => $userId, "from_date" => $date));
    // $this->db->where('from_date >=', $date);
    // $this->db->where('to_date <=', $date);
    $data = $ci->db->get()->result();
    return ($data) ? $data : null;
}

function LeaveCheckOfEmployeeBetween($userId, $date)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('user_id');
    $ci->db->from("main_leaverequest");
    $ci->db->where(array("user_id" => $userId, "leaveday" => 1));
    $ci->db->where('from_date <=', $date);
    $ci->db->where('to_date >=', $date);
    $data = $ci->db->get()->result();
    return ($data) ? $data : null;
}

function TourCheckOfEmployee($userId, $date)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('emp_id');
    $ci->db->from("emp_tourapply");
    $ci->db->where(array("emp_id" => $userId, "start_date" => $date));
    // $this->db->where('from_date >=', $date);
    // $this->db->where('to_date <=', $date);
    $data = $ci->db->get()->result();
    return ($data) ? $data : null;
}
function TourCheckOfEmployeeBetween($userId, $date)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('emp_id');
    $ci->db->from("emp_tourapply");
    $ci->db->where(array("emp_id" => $userId));
    $ci->db->where('start_date <=', $date);
    $ci->db->where('end_date >=', $date);
    $data = $ci->db->get()->result();
    return ($data) ? $data : null;
}
//====== project attendance =========
function getSundays($y, $m, $dayNum)
{
    $CI = &get_instance();
    $date = "$y-$m-01";
    $first_day = date('N', strtotime($date));
    $first_day = $dayNum - $first_day + 1;
    $last_day = date('t', strtotime($date));
    $days = array();
    for ($i = $first_day; $i <= $last_day; $i = $i + 7) {
        $days[] = $i;
    }
    return $days;
}

function getuseattendance($project_id, $designation_id, $month, $year)
{
    $CI = &get_instance();
    $CI->load->model('Front_model');
    $respOnArr = $CI->Front_model->getuseattendance($project_id, $designation_id, $month, $year);
    return ($respOnArr) ? $respOnArr : "";
}

//Get Present Days..
function gettimesheetdetail($project_id, $designation_id, $month, $year)
{
    $CI = &get_instance();
    $CI->load->model('Front_model');
    $details = $CI->Front_model->gettimesheetdetail($project_id, $designation_id, $month, $year);
    return $details;
}

function get_company_nameBy_id($userid)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("a.vendor,b.company_name");
    $ci->db->from("main_empjobhistory as a");
    $ci->db->join("tbl_companyname as b", "a.vendor=b.id", "LEFT");
    $ci->db->where(array('a.isactive' => '1', 'a.user_id' => $userid));
    $data = $ci->db->get()->result();
    return ($data) ? $data : 'grv';
}

function getAllActiveCurrency()
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("id,currencyname");
    $ci->db->from("main_currency");
    $ci->db->where(array('isactive' => '1'));
    $data = $ci->db->get()->result();
    return ($data) ? $data : '';
}

function getEmpWithSalDetails()
{
    $keyOfficialArr = array('173', '175', '190', '2');
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select("b.*,a.userfullname,a.user_id as empID,a.businessunit_name,a.jobtitle_name");
    $ci->db->from("main_employees_summary as a");
    $ci->db->join("main_empsalarydetails as b", "b.user_id=a.user_id", "LEFT");
    $ci->db->where_not_in('a.user_id', $keyOfficialArr);
    $ci->db->where(array('a.isactive' => '1'));
    $ci->db->group_by("a.user_id");
    $data = $ci->db->get()->result();
    return ($data) ? $data : '';
}

function get_emp_user_id_by_emp_code($empcode)
{
    $ci = &get_instance();
    $ci->db->select('a.user_id');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where(array('a.employeeId' => $empcode, 'a.isactive' => '1'));
    $RecRows = $ci->db->get()->row();
    return ($RecRows->user_id) ? $RecRows->user_id : '';
}

//Get All Key officials By Job Tit..
function GetAllDesignationByNewJtitID($JobtitID)
{
    $ci = &get_instance();
    $ci->db->select('a.id,a.userfullname,a.user_id,a.employeeId');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where(array('a.isactive' => '1'));
    $ci->db->where_in("a.jobtitle_id", $JobtitID);
    $ci->db->order_by('a.id', "DESC");
    $recArr = $ci->db->get()->result();
    return ($recArr) ? $recArr : null;
}

function send_welcomeMail($to, $subject, $msgDetails)
{
    $ci = &get_instance();
    $ci->load->library('email');
    $ci->email->initialize(array(
        'protocol' => 'smtp',
        'smtp_host' => 'mail.cegindia.com',
        'smtp_user' => 'marketing@cegindia.com',
        'smtp_pass' => 'MARK-2015ceg',
        'smtp_port' => 587,
        'crlf' => "\r\n",
        'newline' => "\r\n",
        'mailtype' => 'html',
        'charset' => 'iso-8859-1',
        'wordwrap' => true,
    ));
    $ci->email->from('marketing@cegindia.com', 'Do_not_reply');
    $ci->email->to($to);
    $ci->email->bcc('marketing@cegindia.com');
    $ci->email->subject($subject);
    $ci->email->message($msgDetails);
    $resp = $ci->email->send();
    return ($resp) ? $resp : $ci->email->print_debugger();
}

function updateRecUsingUserID($userID, $newPass)
{
    $ci = &get_instance();
    $where = array("id" => $userID);
    $data = array("emppassword" => $newPass);
    $resp = $ci->db->update("main_users", $data, $where);
    return ($resp) ? $resp : null;
}
function getemployesalary($afids) //this- is use for

{
    $ci = &get_instance();
    $ci->db->select('a.*'); //,a.empctc,a.grosssalary,a.basicsalary,a.empepf,a.emp_hra,a.emp_esi,a.special_allowance,a.emp_gratuity,a.transportation_allowance,a.emp_sal_gpai,a.tele_empsal_allowance,a.education_allowance,a.medical_allowance
    $ci->db->from('main_empsal_increment as a');
    $ci->db->where(array('a.id' => $afids));

    $recArr = $ci->db->get()->result();
    return ($recArr) ? $recArr : null;
}
function getState_country($country)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('*');
    $ci->db->from('tbl_states as a');
    $ci->db->where('a.country_id', $country);
    $ci->db->where(array('a.isactive' => '1'));
    $queryRecArr = $ci->db->get()->result();
    return ($queryRecArr) ? $queryRecArr : null;
}
function getcity_State($state)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('a.*');
    $ci->db->from('tbl_cities as a');
    $ci->db->where('a.state_id ', $state);
    $ci->db->where(array('a.is_active' => '1'));
    $queryRecArr = $ci->db->get()->result();
    return ($queryRecArr) ? $queryRecArr : null;
}
function Getjobtitle()
{
    $ci = &get_instance();
    $ci->db->select('a.*');
    $ci->db->from('main_jobtitles as a');
    $ci->db->where(array('a.isactive' => '1'));
    // $ci->db->where_in("a.jobtitle_id", $JobtitID);
    // $ci->db->order_by('a.id', "DESC");
    $recArr = $ci->db->get()->result();
    return ($recArr) ? $recArr : null;
}
function getrecord_cadidate_list($fieldname, $tab)
{

    if ($fieldname == 'univname') {
        $metakey = 'university';
    }
    if ($fieldname == 'institutename') {
        $metakey = 'institute';
    }
    $ci = &get_instance();
    $ci->db4 = $ci->load->database('cvmanager', true);
    $db4 = $ci->db4->database;

    $ci->db->select("$db4.a.candidate_id");
    $ci->db->from("$db4.tblsearchmeta as a");
    $ci->db->where(array("$db4.a.meta_key" => $metakey, "$db4.a.meta_value" => $tab));
    $recArr = $ci->db->get()->result();

    return ($recArr) ? $recArr : null;
}
function getrecordname($fieldname, $id)
{
    if ($fieldname == 'univname') {
        $tablename = 'tbluniversities';
    }
    if ($fieldname == 'institutename') {
        $tablename = 'tblinstitutes';
    }
    $ci = &get_instance();
    $ci->db4 = $ci->load->database('cvmanager', true);
    $db4 = $ci->db4->database;

    $ci->db->select("$db4.a.$fieldname");
    $ci->db->from("$db4.$tablename as a");
    $ci->db->where(array("$db4.a.id" => $id));
    $recArr = $ci->db->get()->row();

    return ($recArr->$fieldname) ? $recArr->$fieldname : null;
}
function number_getrecord_cadidate_list($fieldname, $tab)
{
    if ($fieldname == 'univname') {
        $metakey = 'university';
        $table = 'tbluniversities';
    }
    if ($fieldname == 'institutename') {
        $metakey = 'institute';
        $table = 'tblinstitutes';
    }
    $ci = &get_instance();
    $ci->db4 = $ci->load->database('cvmanager', true);
    $db4 = $ci->db4->database;

    $ci->db->select("$db4.a.candidate_id");
    $ci->db->from("$db4.tblsearchmeta as a");
    $ci->db->where(array("$db4.a.meta_key" => $metakey, "$db4.a.meta_value" => $tab));
    $recArr = $ci->db->get()->num_rows();
// if($recArr =='')
    // {
    // // echo "no_data";
    //  $up_array = array("$db4.a.is_active"=>"0");
    // $ci->db->where("$db4.a.id",$tab);
    // $ci->db->update("$db4.$table as a",$up_array);
    // }
    // else{
    //     $up_array = array("$db4.a.is_active"=>"1");
    //     $ci->db->where("$db4.a.id",$tab);
    //     $ci->db->update("$db4.$table as a",$up_array);

// }

// die();

    return ($recArr) ? $recArr : null;
}
function modeofentry($user_id)
{
    $ci = &get_instance();
    $ci->db->select('a.Modeofentry');
    $ci->db->from('main_users as a');

    $ci->db->where(array('a.isactive' => '1', 'a.id' => $user_id));
    // $ci->db->where_in("a.jobtitle_id", $JobtitID);
    // $ci->db->order_by('a.id', "DESC");
    $recArr = $ci->db->get()->row();
    return ($recArr->Modeofentry) ? $recArr->Modeofentry : null;
}
function activeemploye()
{
    $ci = &get_instance();
    $ci->db->select('a.*');
    $ci->db->from('main_users as a');
    $recArr = $ci->db->get()->result();
    return ($recArr) ? $recArr : null;
}
function relatedwith_employe($User_id)
{
    $ci = &get_instance();
    $ci->db->select('a.*');
    $ci->db->from('emp_otherofficial_data as a');
    $ci->db->where("a.related_with", $User_id);
    $recArr = $ci->db->get()->num_rows();
    return ($recArr) ? $recArr : null;
}
function GetDepartmentBYId($userid) //vivek bahi

{
    $ci = &get_instance();
    $ci->db->select('a.userfullname,a.department_name');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where("a.user_id", $userid);
    $recArr = $ci->db->get()->row();
    return ($recArr) ? $recArr : null;

}
function GetChatUserPic($picid) //vivek bahi

{
    $ci = &get_instance();
    $ci->load->database();
    $ci->load->model('mastermodel');
    $dataRec = $ci->mastermodel->GetChatUserPic($picid);
    return ($dataRec) ? $dataRec : null;
}

function getletter_type()
{
    $ci = &get_instance();
    $ci->db->select('*');
    $ci->db->from('main_letter_type_master');
    $result = $ci->db->get()->result();

    return $result ? $result : null;
}

function getletterType()
{
    $ci = &get_instance();
    $ci->db->select('*');
    $ci->db->from('letter_type_master');
    $ci->db->where('is_active', '1');
    $result = $ci->db->get()->result();

    return $result ? $result : null;
}

function getcountry() //abhishek 01-07-2022

{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('*');
    $ci->db->from('tbl_countries as a');
    // $ci->db->where('a.country_id', $country);
    $ci->db->where(['a.is_active' => '1']);
    $queryRecArr = $ci->db->get()->result();
    return ($queryRecArr) ? $queryRecArr : null;
}

// 11-07-2022 vivek
function GetStatusCountBYId($statusId)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->load->model('ticket/Ticket_Raised_Model');
    $data['countprogress'] = $ci->Ticket_Raised_Model->GetprogressCountBYId($statusId);

    $data['countopen'] = $ci->Ticket_Raised_Model->GetStatusCountBYId($statusId);
    //epd($data['countopen']);

    $data['countclose'] = $ci->Ticket_Raised_Model->GetcloseCountBYId($statusId);

    return ($data) ? $data : null;
}
function GetChildUserPic($childPicid)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->load->model('Ticket_Raised_Model');
    $dataRec = $ci->Ticket_Raised_Model->GetChildUserPic($childPicid);

    return ($dataRec) ? $dataRec : null;
}
function epd($masterId)
{
    $CI = &get_instance();
    echo "<pre>";
    print_r($masterId);
    die();
}

function get_temp_max_value()
{
    $ci = &get_instance();
    $ci->db->select_max('id');
    $ci->db->from('main_letter');
    $val = $ci->db->get()->row();
    $tmp_id = 0;
    if ($val) {
        $tmp_id = $val->id + 1;
    }
    return ($tmp_id) ? $tmp_id : 1;
}

function get_positions($position)
{
    $ci = &get_instance();
    $ci->db->select('*');
    $ci->db->from('main_positions as a');
    $ci->db->where(['a.isactive' => '1']);
    $ci->db->where('a.id', $position);
    // $ci->db->where("(a.department_id='11' OR a.department_id='29')");
    $positons = $ci->db->get()->row();
    return ($positons->positionname) ? $positons->positionname : null;
}

function Get_Hrname($hr_id)
{
    $ci = &get_instance();
    $ci->db->select('a.user_id,a.userfullname,a.employeeId');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where(['a.isactive' => '1']);
    $ci->db->where("(a.department_id='11' OR a.department_id='29')");
    $ci->db->where('a.user_id', $hr_id);
    $empHridArr = $ci->db->get()->row();
    return ($empHridArr->userfullname) ? $empHridArr->userfullname : null;
}

function get_compancy_location()
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('id,city_name');
    $ci->db->from('tbl_ofclocation');
    $ci->db->where(['is_active' => '1']);
    $data = $ci->db->get()->result();

    return ($data) ? $data : 'null';
}

//(HR Functions Use) Employee Ids for HR Permissions..
function GetAll_Hr()
{
    $ci = &get_instance();
    $ci->db->select('a.user_id,a.userfullname,a.employeeId');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where(['a.isactive' => '1']);
    $ci->db->where("(a.department_id='11' OR a.department_id='29')");
    $empHridArr = $ci->db->get()->result();
    return ($empHridArr) ? $empHridArr : null;
}

function get_all_positions()
{
    $ci = &get_instance();
    $ci->db->select('*');
    $ci->db->from('main_positions as a');
    $ci->db->where(['a.isactive' => '1']);
    // $ci->db->where("(a.department_id='11' OR a.department_id='29')");
    $positons = $ci->db->get()->result();
    return ($positons) ? $positons : null;
}

function main_prefix()
{
    $ci = &get_instance();
    $ci->db->select('id ,prefix');
    $ci->db->from('main_prefix');
    $ci->db->where('isactive', '1');
    $result = $ci->db->get()->result();

    return $result ? $result : null;
}

function get_all_templete()
{
    $ci = &get_instance();
    $ci->db->select('*');
    $ci->db->from('main_letter_type_master as a');
    $ci->db->where(['a.is_active' => '1']);
    // $ci->db->where("(a.department_id='11' OR a.department_id='29')");
    $positons = $ci->db->get()->result();

    return ($positons) ? $positons : null;
}

//vivek 28-07-2022

function GetCountryById($id) //abhishek 01-07-2022

{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('*');
    $ci->db->from('tbl_countries as a');
    $ci->db->where('a.id', $id);
    $ci->db->where(['a.is_active' => '1']);
    $queryRecArr = $ci->db->get()->row();

    return ($queryRecArr) ? $queryRecArr : null;
}
function GetStateById($id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('*');
    $ci->db->from('tbl_states as a');
    $ci->db->where('a.id', $id);
    $ci->db->where(['a.isactive' => '1']);
    $queryRecArr = $ci->db->get()->row();

    return ($queryRecArr) ? $queryRecArr : null;
}
function GetCityById($id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('a.*');
    $ci->db->from('tbl_cities as a');
    $ci->db->where('a.id', $id);
    $ci->db->where(['a.is_active' => '1']);
    $queryRecArr = $ci->db->get()->row();

    return ($queryRecArr) ? $queryRecArr : null;
}
function GetPositionsById($id)
{
    $ci = &get_instance();
    $ci->db->select('*');
    $ci->db->from('main_positions as a');
    $ci->db->where(['a.id' => $id]);
    $ci->db->where(['a.isactive' => '1']);
    // $ci->db->where("(a.department_id='11' OR a.department_id='29')");
    $positons = $ci->db->get()->row();
    return ($positons) ? $positons : null;
}
function GetCompanyNameById($id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('a.*');
    $ci->db->from('tbl_companyname as a');
    $ci->db->where('a.id', $id);
    $ci->db->where(['a.is_active' => '1']);
    $queryRecArr = $ci->db->get()->row();
    return ($queryRecArr) ? $queryRecArr : null;
}
function GetCompancyLocationById($id)
{
    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('a.id,a.city_name');
    $ci->db->from('tbl_ofclocation as a');
    $ci->db->where('a.id', $id);
    $data = $ci->db->get()->row();
    return ($data) ? $data : 'null';
}
function GetHrById($id)
{
    $ci = &get_instance();
    $ci->db->select('a.user_id,a.userfullname,a.employeeId');
    $ci->db->from('main_employees_summary as a');
    $ci->db->where(['a.user_id' => $id]);
    // $ci->db->where("(a.department_id='11' OR a.department_id='29')");
    $empHridArr = $ci->db->get()->row();
    return ($empHridArr) ? $empHridArr : null;
}
function GetBusinessunitById()
{
    $ci = &get_instance();
    $ci->load->database();
    $query = $ci->db->query("SELECT id,unitname FROM `main_businessunits` WHERE isactive='1' ");

    return $query->result();
}
function GetPrefixById($id)
{
    $ci = &get_instance();
    $ci->db->select('id ,prefix');
    $ci->db->from('main_prefix');
    $ci->db->where('id', $id);
    $result = $ci->db->get()->row();
    return $result ? $result : null;
}
//abhishek 02-08-2022
function Get_loginemploye_hr_or_not()
{
    $ci = &get_instance();
    $id = $ci->session->userdata('loginid');
    // print_r($id);
    $ci->db->select('user_id,position_id');
    $ci->db->from('main_employees');
    $ci->db->where('user_id', $id);
    $ci->db->where('department_id', 11);
    // $ci->db->or_where('department_id', 11);
    $result = $ci->db->get()->row();
    // print_r($result);
    if ($result) {
        $user_id = $result;
    }
    // echo'<pre>';
    // echo'hi';
    // print_r($user_id);
    // print_r($result);
    // die();

    return $user_id ? $user_id : null;
}
function Get_employess($business_unit_id)
{
    $ci = &get_instance();
    $ci->db->select("a.user_id,a.userfullname");
    $ci->db->from("main_employees_summary as a");
    $ci->db->where("a.businessunit_id", $business_unit_id);
    $data = $ci->db->get()->result();
    return $data;
}

function get_sub_department_names($deptid)
{
    $ci = &get_instance();
    $ci->db->select("a.*");
    $ci->db->from("main_subdepartments as a");
    $ci->db->where("a.deptid", $deptid);
    $data = $ci->db->get()->result();
    return $data;
}

function subDeptEmployeeCountActive($deptid)
{
    $ci = &get_instance();
    $ci->db->select("b.sub_department");
    $ci->db->from("main_users as a");
    $ci->db->join("emp_otherofficial_data as b", 'a.id = b.user_id', 'left');
    $ci->db->where("b.sub_department", $deptid);
    $ci->db->where("a.isactive", 1);
    $data = $ci->db->get()->num_rows();
    return ($data) ? $data : "0";
}

function subDeptEmployeeCountNotActive($deptid)
{
    $ci = &get_instance();
    $ci->db->select("b.sub_department");
    $ci->db->from("main_users as a");
    $ci->db->join("emp_otherofficial_data as b", 'a.id = b.user_id', 'left');
    $ci->db->where("b.sub_department", $deptid);
    $ci->db->where("a.isactive !=", 1);
    $data = $ci->db->get()->num_rows();
    return ($data) ? $data : "0";
}

function get_hod()
{
    $ci = &get_instance();
    $ci->db->select("a.reporting_manager,a.reporting_manager_name");
    $ci->db->from("main_employees_summary as a");
    $ci->db->where("a.isactive", 1);
    $ci->db->where("a.reporting_manager != ", 0);
    $ci->db->where("a.reporting_manager != ", null);
    $ci->db->group_by('a.reporting_manager');
    $data = $ci->db->get()->result();
    return $data;
}
function get_all_country_code()
{

    $ci = &get_instance();
    $ci->load->database();
    $ci->db->select('a.id,a.country_mob_code');
    $ci->db->from('tbl_countries as a');
    $ci->db->where('a.country_mob_code !=" "');
    $ci->db->where(['a.is_active' => '1']);
    $queryRecArr = $ci->db->get()->result();
    return ($queryRecArr) ? $queryRecArr : null;

}

// add document
function GetGeneralDocNameByID($doc_folder_id = '')
{
    $CI = &get_instance();
    $folder_name = $CI->db->get_where("user_document_folder", ['fld_id' => $doc_folder_id, 'status' => '1'])->row();
    if ($folder_name) {
        if ($folder_name->main_folder == 1) {
            $folder_full_path = "Education_folder/" . $folder_name->folder_name;
        }
        if ($folder_name->main_folder == 2) {
            $folder_full_path = "Other/" . $folder_name->folder_name;
        }
        if ($folder_name->main_folder == 3) {
            $folder_full_path = "Hr_Folder/" . $folder_name->folder_name;
        }
        return $folder_full_path;
    }
}
function get_client_ip()
{
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP')) {
        $ipaddress = getenv('HTTP_CLIENT_IP');
    } else if (getenv('HTTP_X_FORWARDED_FOR')) {
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    } else if (getenv('HTTP_X_FORWARDED')) {
        $ipaddress = getenv('HTTP_X_FORWARDED');
    } else if (getenv('HTTP_FORWARDED_FOR')) {
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    } else if (getenv('HTTP_FORWARDED')) {
        $ipaddress = getenv('HTTP_FORWARDED');
    } else if (getenv('REMOTE_ADDR')) {
        $ipaddress = getenv('REMOTE_ADDR');
    } else {
        $ipaddress = 'UNKNOWN';
    }

    return $ipaddress;
}

function get_cource_name($course_id){
    $ci = &get_instance();

    $ci->load->database();
    $ci->db->select('a.degreename');
    $ci->db->from('tbldegree as a');
    $ci->db->where("a.id", $course_id);
    $courrce_name = $ci->db->get()->row();
    return $courrce_name ? $courrce_name->degreename : '';
}

function GetLastApprSession(){
    $ci = &get_instance();
    $ci->load->database();

    $ci->db->select("a.fld_id,a.cycle_date");
    $ci->db->from("appr_increment_cycle_master as a");
    $ci->db->where(array('a.status' => '1'));
    $ci->db->order_by("a.fld_id", "DESC");
    $ci->db->limit("1");
    $SngldataArr = $ci->db->get()->row();
    return ($SngldataArr) ? $SngldataArr : null;
}
