<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
    xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!--<link href="https://fonts.googleapis.com/css?family=Kreon:400,700|Playfair+Display:400,400i,700,700i|Raleway:400,400i,700,700i|Roboto:400,400i,700,700i" rel="stylesheet" />-->
    <title>Welcome to CEG</title>
    <style type="text/css" media="screen">
    body {
        padding: 0 !important;
        margin: 0 !important;
        display: block !important;
        min-width: 100% !important;
        width: 100% !important;
        -webkit-text-size-adjust: none
    }

    a {
        color: #000001;
        /* text-decoration: none */
    }

    p {
        padding: 0 !important;
        margin: 0 !important
    }

    img {
        -ms-interpolation-mode: bicubic;
    }

    .mcnPreviewText {
        display: none !important;
    }

    .text-footer2 a {
        color: #ffffff;
    }

    /* Mobile styles */
    @media only screen and (max-device-width: 480px),
    only screen and (max-width: 480px) {
        .mobile-shell {
            width: 100% !important;
            min-width: 100% !important;
        }

        .m-center {
            text-align: center !important;
        }

        .m-left {
            text-align: left !important;
            margin-right: auto !important;
        }

        .center {
            margin: 0 auto !important;
        }

        .content2 {
            padding: 8px 15px 12px !important;
        }

        .t-left {
            float: left !important;
            margin-right: 30px !important;
        }

        .t-left-2 {
            float: left !important;
        }

        .td {
            width: 100% !important;
            min-width: 100% !important;
        }

        .content {
            padding: 30px 15px !important;
        }

        .section {
            padding: 30px 15px 0px !important;
        }

        .m-br-15 {
            height: 15px !important;
        }

        .mpb5 {
            padding-bottom: 5px !important;
        }

        .mpb15 {
            padding-bottom: 15px !important;
        }

        .mpb20 {
            padding-bottom: 20px !important;
        }

        .mpb30 {
            padding-bottom: 30px !important;
        }

        .mp30 {
            padding-bottom: 30px !important;
        }

        .m-padder {
            padding: 0px 15px !important;
        }

        .m-padder2 {
            padding-left: 15px !important;
            padding-right: 15px !important;
        }

        .p70 {
            padding: 30px 0px !important;
        }

        .pt70 {
            padding-top: 30px !important;
        }

        .p0-15 {
            padding: 0px 15px !important;
        }

        .p30-15 {
            padding: 30px 15px !important;
        }

        .p30-15-0 {
            padding: 30px 15px 0px 15px !important;
        }

        .p0-15-30 {
            padding: 0px 15px 30px 15px !important;
        }

        .text-footer {
            text-align: center !important;
        }

        .m-td,
        .m-hide {
            display: none !important;
            width: 0 !important;
            height: 0 !important;
            font-size: 0 !important;
            line-height: 0 !important;
            min-height: 0 !important;
        }

        .m-block {
            display: block !important;
        }

        .fluid-img img {
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
        }

        .column,
        .column-dir,
        .column-top,
        .column-empty,
        .column-top-30,
        .column-top-60,
        .column-empty2,
        .column-bottom {
            float: left !important;
            width: 100% !important;
            display: block !important;
        }

        .column-empty {
            padding-bottom: 15px !important;
        }

        .column-empty2 {
            padding-bottom: 30px !important;
        }

        .content-spacing {
            width: 15px !important;
        }
    }

    .mobile-shell {
        background: #fff;
        border: 1px solid #000;

    }

    a:active {
        color: blue;
    }
    </style>
</head>

<body class="body"
    style="padding:0 !important; margin:0 !important;background: #f1f0f0; display:block !important; min-width:100% !important; width:100% !important; -webkit-text-size-adjust:none;">
    <table width="650" align="center" border="0" cellspacing="0" cellpadding="0"
        style="background: #d7d5d5;padding: 15px;">
        <tr>
            <td align="center" valign="top">
                <table width="100%" border="0" cellspacing="0" cellpadding="0" class="mobile-shell">
                    <tbody>
                        <!--<tr style="text-align: center;">
                     <td class="td" style="width:350px; min-width:650px; font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal;">
                         <div mc:repeatable="Select" mc:variant="Section 1">
                             <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ebebeb">
                                 <tr style="text-align: center;">
                                     <img src="https://cegindia.com/assets/images/logo.png" height="100" />
                                 </tr>
                             </table>
                         </div>


                     </td>
                     <p style="font-style: italic;padding-top: 80px!important;padding-left: 40px!important;"><?=@$username.'<br/>'; ?> <?=@$desig_name; ?></p>
                     </tr>-->
                        <tr style="text-align:center;">
                            <td class="td">
                                <!--<div style="background-image:url('https://cegindia.com/assets/images/bday1.png'); height:500px; background-repeat: no-repeat;background-size: 500px 500px;" mc:repeatable="Select" mc:variant="Section 1">-->
                                <img src="https://cegindia.com/assets/images/cegwl.png"
                                    style="width:100%;background-repeat: no-repeat;background-size: 500px 500px;">
                                <p
                                    style="color:#2f0bf7; font-style: italic;padding-top: 0px!important;padding-left: 90px!important;">
                                </p>
                                <?php /* echo @$username.' ( ';?> <?=@$desig_name.' )'; */?>
                            </td>
                        </tr>
                        <tr>
                            <td style="padding:0px 15px">
                                <p style="font-family: sans-serif;">
                                <p>
                                   Dear <?=$letter_data->userfullname; ?>,<br><br>
                                    Congratulations! you have been selected in the final round of interview.<br><br>

Further process requires your acceptance of the offer. You can do so by clicking the link below and filling your details.

 <br><br>
                                    <?php $encodedatas = base64_encode($letter_data->id); ?>
                                    <?php /*
                                    <a style=" color: blue;"
                                        href="https://apps.cegtechno.com/myhrms/index.php/Letter/<?=$encodedatas; ?>">Accept</a> */ ?>
                                    <a style=" color: blue;"
                                        href="<?= rootUrls; ?>myhrms/index.php/Letter/<?=$encodedatas?>">Accept</a>

                                </p>
                                </p>
                            </td>
                        </tr>
<br><br>
                        <tr class="footer" style="background:#ebebeb">
                            <td align="center" valign="top" class="content-block powered-by" style="padding: 20px 0px;">
                                Powered by <a style="text-decoration: none" target="_blanck"
                                    href="https://cegindia.com">Consulting Engineers Group
                                    Ltd. </a>
                            <td>
                        </tr>
                        <!--<tr class="footer" style="bgcolor:#ebebeb">
                     <td align="center" valign="top">
                        <table  width="650" border="0" cellpadding="10" cellspacing="10" bgcolor="#ebebeb">
                           <tr style="text-align: center;">
                              <td class="content-block powered-by">
                                 Powered by <a target="_blanck" href="https://cegindia.com">Consulting Engineers Group Ltd. </a>
                              </td>
                           </tr>
                        </table>
                     <td>
                  </tr>-->
                        <div style="clear:both"></div>
                </table>
                <div style="clear:both"></div>
            </td>
            </tbody>
        </tr>
    </table>
</body>

</html>