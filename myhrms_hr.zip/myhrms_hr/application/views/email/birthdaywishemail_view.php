<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
    xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="format-detection" content="date=no" />
    <meta name="format-detection" content="address=no" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="x-apple-disable-message-reformatting" />
    <!--[if !mso]><!-->
    <link
        href="https://fonts.googleapis.com/css?family=Kreon:400,700|Playfair+Display:400,400i,700,700i|Raleway:400,400i,700,700i|Roboto:400,400i,700,700i"
        rel="stylesheet" />
    <!--<![endif]-->
    <title>CEG Project Appraisal Form Lock </title>

   
</head>


<body class="body" id="bcakground">
    <table width="600" align="center" style="background-color:rgb(255,255,255)" bgcolor="#fff" border="0" cellspacing="0" cellpadding="0">
    <!-- <table width="600" align="center"  bgcolor="#fff" border="0" cellspacing="0" cellpadding="0"> -->
        <tbody style="dispaly:table-row-grouo;vertical-align:middle;">
            <tr>
                <td>
                    <table style="margin:0 !important; " width="560" align="center" border="0" cellspacing="0" cellpadding="0">
                        <tbody>
                            <tr>
                                <td align="center">
                                    <img width="559" height="93" style="display:block"  alt="ceg logo" src="https://apps.cegtechno.com/myhrms_hr/assets/images/logo-email.png" border="0" >
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <table width="558" style="border:1px solid rgb(89,89,89); background-color:#<?php echo $bg_color; ?>;" border="0" cellspacing="0" cellpadding="0">
                        <tbody>
                            
                            <tr>
                                <td align="center" style="font:25px/normal Arial, Helvetica;padding:45px 10px;color:rgb(40,40,40);font-size-adjust:none;font-stretch:normal">
                                    CEG family wishes a very Happy Birthday To ....
                                </td>
                            </tr>
                            <tr>
                                <td>
                                <?php foreach ($dataemailpta as $vs) { ?>
                                    <table width="480" align="center" border="0" cellspacing="0" cellpadding="0" style="background:#f7f9fa;padding:16px;border-radius:8px;overflow:hidden;margin-bottom:5px">
                                        <tbody>
                                             <tr>
					                        	<td width="480" align="left" valign="middle" style="border-collapse:collapse;padding:8px 0px;border-bottom:1px solid #eaeaed;font-size:12px">
                                                    <table  width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="50%" align="left" valign="top" style="border-collapse:collapse;text-transfrom:capitalize">
                                                                    Name
                                                                </td>
                                                                <td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">
                                                                    :
                                                                </td>
                                                                <td  align="left" valign="top" style="border-collapse:collapse;text-transfrom:capitalize">
                                                                    <?= $vs['userfullname']; ?>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    
					                        	</td>
                                             </tr>
                                             <tr>
                                                <td width="480" align="left" valign="middle" style="border-collapse:collapse;padding:8px 0px;border-bottom:1px solid #eaeaed;font-size:12px">
                                                    <table  width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="50%" align="left" valign="top" style="border-collapse:collapse;text-transfrom:capitalize">
                                                                    Position
                                                                </td>
                                                                <td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">
                                                                    :
                                                                </td>
                                                                <td  align="left" valign="top" style="border-collapse:collapse;text-transfrom:capitalize">
                                                                    <?= $vs['position_name']; ?>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    
					                        	</td>
                                                </tr>
                                                <tr>
                                                <td width="480" align="left" valign="middle" style="border-collapse:collapse;padding:8px 0px;border-bottom:1px solid #eaeaed;font-size:12px">
                                                    <table  width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="50%" align="left" valign="top" style="border-collapse:collapse;text-transfrom:capitalize">
                                                                    Department
                                                                </td>
                                                                <td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">
                                                                    :
                                                                </td>
                                                                <td  align="left" valign="top" style="border-collapse:collapse;text-transfrom:capitalize">
                                                                    <?= $vs['department_name']; ?>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    
					                        	</td>
                                                </tr>
                                                <tr>
					                        	<td width="480" align="left" valign="middle" style="border-collapse:collapse;padding:8px 0px;border-bottom:1px solid #eaeaed;font-size:12px">
                                                    <table  width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <td width="50%" align="left" valign="top" style="border-collapse:collapse;text-transfrom:capitalize">
                                                                    Contact
                                                                </td>
                                                                <td width="16" align="left" valign="top" style="border-collapse:collapse;font-weight:normal">
                                                                    :
                                                                </td>
                                                                <td  align="left" valign="top" style="border-collapse:collapse;text-transfrom:capitalize">
                                                                    <?= $vs['contactnumber']; ?>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    
					                        	</td>
                                              </tr>
					                        
                                        </tbody>
                                    </table>
                                <?php } ?>
                                </td>
                            </tr>
                            <tr>
                            <b>
                                <td>
                                    <br>
                                   <img width="558" height="300" src="https://apps.cegtechno.com/myhrms_hr/public/uploads/birthdaywish/<?php echo $Birthday_image_name; ?>">
                                </td>
                            </tr>
							<tr>
                                <td align="center" style="font:20px/normal Arial, Helvetica;padding:45px 10px;padding-bottom:10px;color:rgb(40,40,40);font-size-adjust:none;font-stretch:normal;color:black">
                                May your birthday and every day be filled with the warmth of sunshine, the happiness of
				                smiles, the sounds of laughter, the feeling of love and the sharing of good cheer
                                </td>
                            </tr>
                            <tr>
                                <td align="center" style="font:20px/normal Arial, Helvetica;padding:45px 0px;padding-top:0px;color:rgb(40,40,40);font-size-adjust:none;font-stretch:normal;color:red">
                                <b>Have a Great year ahead</b>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
      
</body>

</html>