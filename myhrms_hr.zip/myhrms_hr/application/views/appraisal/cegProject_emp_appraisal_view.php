<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$disAbl = 'readonly="readonly"';
$skillArrlv = array("3" => "Medium", "2" => "Expert", "1" => "BASIC");
$genderidArr = array("1" => "Male", "2" => "Female", "3" => "Other");
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>

        <div id="main-content" class="profilepage_1">
            <div class="container-fluid">

                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>My Appraisal</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>            
                    </div>
                    <?php if ($this->session->flashdata('successmsg')) { ?>
                        <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong> Success ! </strong> <?= $this->session->flashdata('successmsg'); ?>
                        </div>
                    <?php } ?>
                    <?php if ($this->session->flashdata('errormsg')) { ?>
                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong> Danger ! </strong> <?= $this->session->flashdata('errormsg'); ?>
                        </div>
                    <?php } ?>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 left-box">
                        <div class="card single_post">
                            <div class="body">  
                                <div class="tab-content">
                                    <div class="body"> 
                                        <div class="table-responsive">
                                            <!--<table class="table table-bordered table-striped table-hover dataTable js-exportable">-->
                                            <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Name</th>
                                                        <th>Grade</th>
                                                        <th>EmployeeID</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    <?php
                                                    if ($Emplylist) {
                                                        foreach ($Emplylist as $kKey => $reDd) {

                                                            $IO_name = get_ro_details_by_Id($reDd->rep_io_id);
                                                            $RO_name = get_ro_details_by_Id($reDd->rep_ro_id);
                                                            $StAtus = '';
                                                            if ($reDd->current_status == '1') {
                                                                $StAtus = "<span style='color:red'>Filled by IO</span>";
                                                            } elseif ($reDd->current_status == '2') {
                                                                $StAtus = "<span style='color:green'>Locked by IO</span>";
                                                            } elseif ($reDd->current_status == '3') {
                                                                $StAtus = "<span style='color:red'>Filled by RO</span>";
                                                            } elseif ($reDd->current_status == '4') {
                                                                $StAtus = "<span style='color:green'>Locked by RO</span>";
                                                            }
                                                            ?>
                                                            <tr>
                                                                <td><?= $kKey + 1; ?></td>
                                                                <td><?= ($reDd->userfullname) ? $reDd->userfullname : ""; ?></td>
                                                                <td><?= ($reDd->jobtitle_name) ? $reDd->jobtitle_name : ""; ?></td>
                                                                <td><?= ($reDd->employeeId) ? $reDd->employeeId : ""; ?></td>
                                                                <td><?= ($IO_name) ? $IO_name : ""; ?></td>
                                                                <td><?= ($RO_name) ? $RO_name : ""; ?></td>
                                                                <td>
                                                                    <?= $StAtus; ?>
                                                                </td>   
                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                    ?>

                                                </tbody>

                                                <tfoot class="d-none">
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Name</th>
                                                        <th>Grade</th>
                                                        <th>EmployeeID</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Status</th>
<!--                                                        <th>Appraisal Cycle</th>-->
<!--                                                        <th>if(CEGTH)</th>-->
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <?php $this->load->view('admin/includes/footer'); ?>
        </div>
</body>

<link rel="stylesheet" href="<?= FRONTASSETS; ?>jquery-ui.css">
<script src="<?= FRONTASSETS; ?>jquery-ui.js"></script>