<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$disAbl = 'readonly="readonly"';
$skillArrlv = array("3" => "Medium", "2" => "Expert", "1" => "BASIC");
$genderidArr = array("1" => "Male", "2" => "Female", "3" => "Other");
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content" class="profilepage_1">
            <div class="container-fluid">

                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>My Appraisal</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>            
                    </div>
                    <?php if ($this->session->flashdata('successmsg')) { ?>
                        <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong> Success ! </strong> <?= $this->session->flashdata('successmsg'); ?>
                        </div>
                    <?php } ?>
                    <?php if ($this->session->flashdata('errormsg')) { ?>
                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong> Error ! </strong> <?= $this->session->flashdata('errormsg'); ?>
                        </div>
                    <?php } ?>
                </div>

                <?php
                // $list_appr = user_latest_appraisal_list(); 
                // $app_list_arr = array();
                // foreach($list_appr as $val):
                // $app_list_arr[] = $val->emp_id;
                // endforeach;
                // $not_filled_app = user_latest_appraisal_list2($app_list_arr);
                // foreach($not_filled_app as $val):
                // $app_list_arr2[] = $val->user_id;
                // endforeach;
                // $new_arr = array_diff($app_list_arr,$app_list_arr2);
                // echo count($new_arr); die;
                // $phno_app = user_latest_appraisal_list3($new_arr);
                // echo "<pre>"; print_r($phno_app); die;
                ?>

                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 left-box">
                        <div class="card single_post">
                            <div class="body">  
                                <div class="tab-content">
                                    <div class="body"> 
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>EmployeeID</th>
                                                        <th>Name</th>
                                                        <th>Job Grade</th>
                                                        <th>Self Remark <span style="color:red">(150)</span></th>
                                                        <th>IO Remark <span style="color:red">(150)</span></th>
                                                        <th>RO Remark <span style="color:red">(150)</span></th>
<!--                                                        <th>if(CEGTH)</th>-->
                                                    </tr>
                                                </thead>
                                                

                                                <tbody>
                                                    <?php
                                                    if ($Emplylist) {
                                                        foreach ($Emplylist as $kKey => $reDd) {

                                                            // $ApprStatus = LastApprStatusByuserID($reDd->AppraisalID);
                                                            $remarkCount = getIo_RO_remark($reDd->fld_id,$year);
                                                            $IoRemark = 0;
                                                            $RoRemark = 0;
                                                            $SelfRemark = 0;
                                                            foreach ($remarkCount as $kEy => $val):
                                                                $IoRemark += $val->ro_rating;
                                                                $RoRemark += $val->io_rating;
                                                                $SelfRemark += $val->perform_fact_rating;
                                                            endforeach;
                                                            ?>
                                                            <tr>
                                                                <td><?= $kKey + 1; ?></td>
                                                                <td><?= ($reDd->employeeId) ? $reDd->employeeId : ""; ?></td>
                                                                <td><?= ($reDd->userfullname) ? $reDd->userfullname : ""; ?></td>
                                                                <td><?= ($reDd->jobtitle_name) ? $reDd->jobtitle_name : ""; ?></td>
                                                                <td><?= ($SelfRemark) ? $SelfRemark : "<span style='color:red'>Pending</span>"; ?></td>
                                                                <td><?= ($IoRemark) ? $IoRemark : "<span style='color:red'>Pending</span>"; ?></td>
                                                                <td><?= ($RoRemark) ? $RoRemark : "<span style='color:red'>Pending</span>"; ?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                    ?>

                                                </tbody>

                                                <tfoot class="d-none">
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>EmployeeID</th>
                                                        <th>Name</th>
                                                        <th>Job Grade</th>
                                                        <th>Self Remark</th>
                                                        <th>IO Remark</th>
                                                        <th>RO Remark</th>
<!--                                                        <th>Appraisal Cycle</th>-->
<!--                                                        <th>if(CEGTH)</th>-->
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <?php $this->load->view('admin/includes/footer'); ?>
        </div>
</body>

<script>

$(document).ready(function(){
      $("#example").DataTable({

     });

</script>

<link rel="stylesheet" href="<?= FRONTASSETS; ?>jquery-ui.css">
<script src="<?= FRONTASSETS; ?>jquery-ui.js"></script>