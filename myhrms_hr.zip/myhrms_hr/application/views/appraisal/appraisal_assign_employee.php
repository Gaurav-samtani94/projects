<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$ModeofEmployeementArr = ModeofEmployeement();
?>

<link href="<?= HOSTNAME . 'assets/datatables/css/jquery.dataTables.min.css' ?>" rel="stylesheet">
<link href="<?= HOSTNAME . 'assets/datatables/css/dataTables.colVis.css' ?>" rel="stylesheet">
<link href="<?= HOSTNAME . 'assets/datatables/css/buttons.dataTables.min.css' ?>" rel="stylesheet">

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar');  ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Appraisal</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if ($this->session->flashdata('success_msg')): ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($this->session->flashdata('error_msg')): ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item"><a class="nav-link active" > Assign Appraisal </a></li>
                                    <li class="nav-item">
                                        <a href="<?= base_url("project_appraisal_assignbyhr"); ?>" class="nav-link" > Assign Appraisal On Project</a>
                                    </li>
                                </ul>
                            </div>

                            <div class="tab-content">
                                <form id="form-filter" >  
                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row filter-row">
                                        <div class="col-sm-2 col-xs-4"> 
                                            <label class="control-label">Appraisal Session/Name : </label>
                                            <span style="color:green"><?= (@$AppraisalSession) ? @$AppraisalSession : ""; ?></span>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="form-group form-focus select-focus">
                                                <label class="control-label">Business Unit : </label>
                                                <select id="businessunit_name" class="form-control">
                                                    <option value="1" > CEG </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-xs-4">  <br>
                                            <button type="button" id="btn-filter" class="btn btn-success btn-block"> Filter </button>
                                        </div>
                                        <div class="col-sm-2 col-xs-4">  <br>
                                            <a href="<?= base_url("appraisal_assign"); ?>" type="button" class="btn btn-round btn-primary"> Back </a>
                                        </div>
                                    </div>
                                </form>  
                                <hr>

                                <!-- Start Professional -->
                                <div class="tab-pane active" id="official">
                                    <div class="panel panel-default"> 
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div id="colvis"></div>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table id="table" class="table table-striped display">
                                                <thead>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Emp Code</th>
                                                        <th>Employee Name</th>
                                                        <th>DOJ</th>
                                                        <th>B-Unit</th>
                                                        <th>Department</th> 
                                                        <th>IO Name/Rep. Manager</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th>Sr. No</th>
                                                        <th>Emp Code</th>
                                                        <th>Employee Name</th>
                                                        <th>DOJ</th>
                                                        <th>B-Unit</th>
                                                        <th>Department</th>  
                                                        <th>IO Name/Rep. Manager</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="<?= HOSTNAME . 'assets/datatables/js/jquery.dataTables.min.js'; ?>"></script>
        <script src="<?= HOSTNAME . 'assets/datatables/js/dataTables.colVis.js'; ?>"></script> 
        <script src="<?= HOSTNAME . 'assets/datatables/js/pdfmake.min.js'; ?>"></script>

        <script>
            function assignappraisalform(userid) {
                var csrfName = '<?= $this->security->get_csrf_token_name(); ?>';
                var csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
                var apprasal_sessionid = <?= $appr_sessionid; ?>;

                $.ajax({
                    url: '<?= base_url("ajax_assignappraisalformby_hr"); ?>',
                    data: ({[csrfName]: csrfHash, emplid: userid, apprsessionid: apprasal_sessionid}),
                    type: 'post',
                    success: function (data) {
                        if (data) {
                            $("#" + userid).addClass("btn btn-info");
                            $("#" + userid).html("Assigned");
                        }
                    }
                });
            }
        </script>
        


        <script type="text/javascript">
            var table;
            $(document).ready(function () {
                var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
                var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                table = $('#table').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "order": [],
                    "ajax": {
                        "url": "<?= base_url('ajax_list_assignappraisal'); ?>",
                        "type": "POST",
                        data: ({[csrfName]: csrfHash, appr_sessionid: <?= $appr_sessionid; ?>}),
                    },
                    "dom": 'lBfrtip',
                    "buttons": [{
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [{
                            "targets": [0],
                            "orderable": false,
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                var colvis = new $.fn.dataTable.ColVis(table);
                $('#colvis').html(colvis.button());
                $('#btn-filter').click(function () {
                    table.ajax.reload();
                });
                $('#btn-reset').click(function () {
                    $('#form-filter')[0].reset();
                    table.ajax.reload();
                });
            });
        </script>
        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>