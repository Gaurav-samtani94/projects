<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$disAbl = 'readonly="readonly"';
$skillArrlv = array("3" => "Medium", "2" => "Expert", "1" => "BASIC");
$genderidArr = array("1" => "Male", "2" => "Female", "3" => "Other");
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content" class="profilepage_1">
            <div class="container-fluid">

                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                        class="fa fa-arrow-left"></i></a>My Appraisal</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                    <?php if ($this->session->flashdata('successmsg')) { ?>
                        <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong> Success ! </strong> <?= $this->session->flashdata('successmsg'); ?>
                        </div>
                    <?php } ?>
                    <?php if ($this->session->flashdata('errormsg')) { ?>
                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong> Danger ! </strong> <?= $this->session->flashdata('errormsg'); ?>
                        </div>
                    <?php } ?>
                </div>


                <div class="card">
                    <div class="body">
                        <ul class="nav nav-tabs">
                            <li class="nav-item"><a class="nav-link active show" data-toggle="tab" href="#Home">Group
                                    B-C</a></li>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Profile">Group D-E</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane show active" id="Home" style="margin:20px">
                                <form id="form-filter">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row clearfix">

                                        <div class="col-lg-3 col-md-4">
                                            <label>Assign Appraisal</label>
                                            <select required name="appr_session_bc" id="appr_session_bc" class="form-control">
                                                <option value="10-2024"> October, 2024 </option>
                                                <option value="10-2023"> October, 2023 </option>
                                                <option value="09-2021"> October, 2021 </option>
                                                <option value="04-2021"> April, 2021 </option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 col-md-4">
                                            <label>Assign DueDate</label>
                                            <select required name="appr_duedate_bc" id="appr_duedate_bc" class="form-control">
                                                <option value="October 2024"> October, 2024 </option>
                                                <option value="October 2023"> October, 2023 </option>
                                                <option value="October 2021"> October, 2021 </option>
                                                <option value="April 2021"> April, 2021 </option>
                                            </select>
                                        </div>

                                        <div class="col-lg-4 col-md-4">
                                            <div class="mt-sm-3">
                                                <button type="button" id="btn-filter" class="btn btn-one">
                                                    Filter </button>

                                                <button type="button" id="btn-reset" class="btn btn-success">
                                                    Reset </button>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                                <hr>
                                <div class="table-responsive">
                                    <table id="table" class="table table-bordered table-striped table-hover dataTable" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Name</th>
                                                <th>Grade</th>
                                                <th>EmployeeID</th>
                                                <th>IO</th>
                                                <th>RO</th>
                                                <th>IO Remark</th>
                                                <th>RO Remark</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Name</th>
                                                <th>Grade</th>
                                                <th>EmployeeID</th>
                                                <th>IO</th>
                                                <th>RO</th>
                                                <th>Io Remark</th>
                                                <th>Ro Remark</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>


                            </div>
                            <div class="tab-pane" id="Profile" style="margin:20px">
                                <form id="form-filter_de">
                                    <div class="row clearfix">

                                        <div class="col-lg-3 col-md-4">
                                            <label>Assign Appraisal</label>
                                            <select required name="appr_session_de" id="appr_session_de" class="form-control">
                                                <option value="10-2024"> October, 2024 </option>
                                                <option value="10-2023"> October, 2023 </option>
                                                <option value="09-2021"> October, 2021 </option>
                                                <option value="04-2021"> April, 2021 </option>
                                            </select>
                                        </div>

                                        <div class="col-lg-3 col-md-4">
                                            <label>Assign DueDate</label>
                                            <select required name="appr_duedate_de" id="appr_duedate_de" class="form-control">
                                               <option value="October 2024"> October, 2024 </option>
                                                <option value="April 2021"> April, 2021 </option>
                                                <option value="October 2021"> October, 2021 </option>
                                                <option value="April 2021"> April, 2021 </option>
                                            </select>
                                        </div>

                                        <div class="col-lg-4 col-md-4">
                                            <div class="mt-sm-3">
                                                <button type="button" id="btn-filter_de" class="btn btn-one"> Filter
                                                </button>

                                                <button type="button" id="btn-reset_de" class="btn btn-success"> Reset
                                                </button>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                                <hr>
                                <div class="table-responsive">
                                    <table id="table1" class="table table-bordered table-striped table-hover dataTable" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Name</th>
                                                <th>Grade</th>
                                                <th>EmployeeID</th>
                                                <th>IO</th>
                                                <th>RO</th>
                                                <th>IO Remark</th>
                                                <th>RO Remark</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Name</th>
                                                <th>Grade</th>
                                                <th>EmployeeID</th>
                                                <th>IO</th>
                                                <th>RO</th>
                                                <th>Io Remark</th>
                                                <th>Ro Remark</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

    <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <script>
        var table;
        $(document).ready(function() {
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

            //datatables
            // alert($('#appr_session').val())
            // alert($('#appr_duedate').val())
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "paging": true,
                "order": [],
                "scrollY": '62vh',
                "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('All_emp_appraisal_list_Controller/empAppraisal_remart_project'); ?>",
                    "type": "POST",
                    "data": function(data) {
                        data.appr_session = $('#appr_session_bc').val();
                        data.appr_duedate = $('#appr_duedate_bc').val();


                    },
                    // data: {[csrfName]: csrfHash},

                },

                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: ['excel', 'csv', 'pdf', 'print']
                }],

                "columnDefs": [{
                    "targets": [0],
                    "orderable": false
                }],

                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            // var colvis1 = new $.fn.dataTable.ColVis(table1); //initial colvis
            // $('#colvis1').html(colvis1.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function() { //button filter event click
                // alert($('#appr_duedate').val())
                table.ajax.reload(); //just reload table
            });
            $('#btn-reset').click(function() { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload(); //just reload table
            });
        });


        var table1;


        //datatables
        // alert($('#appr_session_de').val())
        // alert($('#appr_duedate_de').val())
        $(document).ready(function() {
            table1 = $('#table1').DataTable({
                "processing": true,
                "serverSide": true,
                "paging": true,
                "order": [],
                "scrollY": '62vh',
                "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('All_emp_appraisal_list_Controller/empAppraisal_remart_project_de'); ?>",
                    "type": "POST",
                    "data": function(data) {
                        data.appr_session_de = $('#appr_session_de').val();
                        data.appr_duedate_de = $('#appr_duedate_de').val();

                    },
                    // data: {[csrfName]: csrfHash},
                },

                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: ['excel', 'csv', 'pdf', 'print']
                }],

                "columnDefs": [{
                    "targets": [0],
                    "orderable": false
                }],

                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });

            // var colvis1 = new $.fn.dataTable.ColVis(table1); //initial colvis
            // $('#colvis1').html(colvis1.button()); //add colvis button to div with id="colvis"
            $('#btn-filter_de').click(function() { //button filter event click
                // alert("gaurav")
                table1.ajax.reload(); //just reload table
            });
            $('#btn-reset_de').click(function() { //button reset event click
                $('#form-filter_de')[0].reset();
                // alert("reset")
                table1.ajax.reload(); //just reload table
            });
        });
    </script>
    <?php $this->load->view('admin/includes/footer'); ?>
</body>