<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$disAbl = 'readonly="readonly"';
$skillArrlv = array("3" => "Medium", "2" => "Expert", "1" => "BASIC");
$genderidArr = array("1" => "Male", "2" => "Female", "3" => "Other");
?>

<body class="theme-cyan">
    <div id="wrapper">
<?php
$this->load->view('admin/includes/sidebar');
?>

        <div id="main-content" class="profilepage_1">
            <div class="container-fluid">

                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>My Appraisal</h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>            
                    </div>
<?php if ($this->session->flashdata('successmsg')) { ?>
                        <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong> Success ! </strong> <?= $this->session->flashdata('successmsg'); ?>
                        </div>
<?php } ?>
                    <?php if ($this->session->flashdata('errormsg')) { ?>
                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong> Danger ! </strong> <?= $this->session->flashdata('errormsg'); ?>
                        </div>
<?php } ?>
                </div>
                    <?php
                    // $list_appr = user_latest_appraisal_list(); 
                    // $app_list_arr = array();
                    // foreach($list_appr as $val):
                    // $app_list_arr[] = $val->emp_id;
                    // endforeach;
                    // $not_filled_app = user_latest_appraisal_list2($app_list_arr);
                    // foreach($not_filled_app as $val):
                    // $app_list_arr2[] = $val->user_id;
                    // endforeach;
                    // $new_arr = array_diff($app_list_arr,$app_list_arr2);
                    // echo count($new_arr); die;
                    // $phno_app = user_latest_appraisal_list3($new_arr);
// echo "<pre>"; print_r($phno_app); die;
                    ?>
                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 left-box">
                        <div class="card single_post">

                            <div class="header">
                                <form id="form-filter" >
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <!--<div class="card-header" id="headingOne">-->
                                    <div class="row clearfix">
                                        <div class="col-lg-3 col-md-6">
                                            <label>Assign Appraisal</label>
                                            <select required name="appr_session" class="form-control">
                                                <option value="1"> October, 2020 </option>
                                                <option value="2"> April, 2020 </option>
                                                <option value="3"> September, 2019 </option>
                                            </select>
                                        </div>

                                        <div class="col-lg-1 col-md-6">
                                            <div class="mb-2">
                                                <label>&nbsp;</label>
                                                <button type="button" id="btn-filter" class="btn btn-success btn-block"> Filter </button>
                                            </div>
                                        </div>
                                        <div class="col-lg-1 col-md-6">
                                            <div class="mb-2">
                                                <label>&nbsp;</label>
                                                <button type="button" id="btn-reset" class="btn btn-primary btn-block"> Reset </button>
                                            </div>
                                        </div>



                                    </div>
                                    <!--</div> -->                               

                                </form>


                            </div>

                            <div class="body">  
                                <div class="tab-content">
                                    <div class="body"> 
                                        <div class="table-responsive">
                                            <table id="table" class="table table-bordered table-striped table-hover ">
                                                <thead>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Name</th>
                                                        <th>Grade</th>
                                                        <th>EmployeeID</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>IO Remark</th>
                                                        <th>RO Remark</th>

<!--                                                        <th>if(CEGTH)</th>-->
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>S.No.</th>
                                                        <th>Name</th>
                                                        <th>Grade</th>
                                                        <th>EmployeeID</th>
                                                        <th>IO</th>
                                                        <th>RO</th>
                                                        <th>Io Remark</th>
                                                        <th>Ro Remark</th>
<!--                                                        <th>Appraisal Cycle</th>-->
<!--                                                        <th>if(CEGTH)</th>-->
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <script>
                var table;
                $(document).ready(function () {
                    var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                    //datatables
                    table = $('#table').DataTable({
                        "processing": true,
                        "serverSide": true,
                        "order": [],
                        "ajax": {
                            "url": "<?php echo base_url('All_emp_appraisal_list_Controller/empAppraisal_remart_project') ?>",
                            "type": "POST",
                            function(data) {
                                data.apprSession = $('#appr_session').val();

                            },
                                data:{[csrfName]: csrfHash}, 
    
                        },

                        "dom": 'lBfrtip',
                        "buttons": [{extend: 'collection', text: 'Export', buttons: ['excel', 'csv', 'pdf', 'print']}
                        ],

                        "columnDefs": [{"targets": [0], "orderable": false}],

                        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    });
                    // var colvis1 = new $.fn.dataTable.ColVis(table1); //initial colvis
                    // $('#colvis1').html(colvis1.button()); //add colvis button to div with id="colvis"
                    $('#btn-filter').click(function () { //button filter event click
                        table1.ajax.reload();  //just reload table
                    });
                    $('#btn-reset').click(function () { //button reset event click
                        $('#form-filter')[0].reset();
                        table1.ajax.reload();  //just reload table
                    });
                });
            </script>
<?php $this->load->view('admin/includes/footer'); ?>
        </div>
</body>

<link rel="stylesheet" href="<?= FRONTASSETS; ?>jquery-ui.css">
<script src="<?= FRONTASSETS; ?>jquery-ui.js"></script>