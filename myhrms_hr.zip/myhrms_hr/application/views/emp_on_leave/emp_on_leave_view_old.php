

<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?= ($title) ? $title : ""; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <!--<li class="breadcrumb-item">Home</li>-->
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>
				
				
				<div class="row clearfix">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card text-center bg-info">
                        <div class="body">
                            <div class="p-15 text-light">
                                <h3><?= $countpresentEmpPresent; ?></h3>
                                <span>Present Employees</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card text-center bg-secondary">
                        <div class="body">
                            <div class="p-15 text-light">
                                <h3><?= $countpresentEmpTour;?></h3>
                                <span>On Tour</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card text-center bg-warning">
                        <div class="body">
                            <div class="p-15 text-light">
                                <h3><?= $countpresentEmpLeave;?></h3>
                                <span>On Leave</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card text-center bg-dark">
                        <div class="body">
                            <div class="p-15 text-light">
                                <h3><?= $absentCount;?></h3>
                                <span>Absent</span>
                            </div>
                        </div>
                    </div>
                </div>                
            </div>
			
			
                <div class="row clearfix">
                    <div class="col-lg-12">

                        <div class="card">						
                            <div class="body">
                                <h4>Employee On Tour.</h4>
                                <div class="table-responsive">
                                    <table id="table1" class="table table-bordered table-striped table-hover dataTable js-exportable" cellspacing="0" width="100%">
                                        <thead>

                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Emp. ID</th>
                                                <th>Emp Name</th>
                                                <th>Job Grade</th>
                                                <th>Bus. Unit</th>
                                                <th>Location</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($presentEmpTour) {
                                                foreach ($presentEmpTour as $kEy => $data) {
                                                    ?>
                                                    <tr style="">
                                                        <td><?= $kEy + 1; ?></td>
                                                        <td><?= ($data->employeeId) ? $data->employeeId : ""; ?></td>
                                                        <td><?= ($data->userfullname) ? $data->userfullname : ""; ?></td>
                                                        <td><?= ($data->jobtitle_name) ? $data->jobtitle_name : ""; ?></td>
                                                        <td><?= ($data->businessunit_name) ? $data->businessunit_name : ""; ?></td>
                                                        <td><?= ($data->city_name) ? $data->city_name : ""; ?></td>
                                                        <td><?= ($data->start_date) ? $data->start_date : ""; ?></td>
                                                        <?php
                                                    }
                                                } else {
                                                    ?>
                                                <tr>
                                                    <td style="color:red;text-align:center;" colspan="9"> Record Not Found.  </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Emp. ID</th>
                                                <th>Emp Name</th>
                                                <th>Job Grade</th>
                                                <th>Bus. Unit</th>
                                                <th>Location</th>
                                                <th>Date</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>


                            <div class="body">
                                <h4>Employee Leave Status.</h4>
                                <div class="table-responsive">
                                    <table id="table1" class="table table-bordered table-striped table-hover dataTable js-exportable" cellspacing="0" width="100%">
                                        <thead>

                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Emp. ID</th>
                                                <th>Emp Name</th>
                                                <th>Job Grade</th>
                                                <th>Bus. Unit</th>
                                                <th>Leave Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($presentEmpLeave) {
                                                foreach ($presentEmpLeave as $kEy => $data) {
                                                    ?>
                                                    <tr style="">
                                                        <td><?= $kEy + 1; ?></td>
                                                        <td><?= ($data->employeeId) ? $data->employeeId : ""; ?></td>
                                                        <td><?= ($data->userfullname) ? $data->userfullname : ""; ?></td>
                                                        <td><?= ($data->jobtitle_name) ? $data->jobtitle_name : ""; ?></td>
                                                        <td><?= ($data->businessunit_name) ? $data->businessunit_name : ""; ?></td>
                                                        <td><?= ($data->leavestatus) ? $data->leavestatus : ""; ?></td>
                                                        <?php
                                                    }
                                                } else {
                                                    ?>
                                                <tr>
                                                    <td style="color:red;text-align:center;" colspan="9"> Record Not Found. </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Emp. ID</th>
                                                <th>Emp Name</th>
                                                <th>Job Grade</th>
                                                <th>Bus. Unit</th>
                                                <th>Leave Status</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>




                            <div class="body">
                                <h4>Floor Wise Attendance.</h4>
                                <div class="table-responsive">
                                    <table id="table" class="table table-striped display" cellspacing="0" width="100%">
                                        <thead>

                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Floor No.</th>
                                                <th>A</th>
                                                <th>B</th>
                                                <th>C</th>
                                                <th>D</th>
                                                <th>E</th>
                                                <th>F</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Floor No.</th>
                                                <th>A</th>
                                                <th>B</th>
                                                <th>C</th>
                                                <th>D</th>
                                                <th>E</th>
                                                <th>F</th>
                                                <th>Total</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
        
        <script type="text/javascript">
            var table;
            $(document).ready(function () {
                 var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                // var compid = $('#companynames').val();
                table = $('#table').DataTable({
                    "processing": true,
                    "serverSide": true,
                    "order": [], //Initial no order.
                    // Load data for the table's content from an Ajax source
                    "ajax": {
                        "url": "<?php echo base_url('ajax_emp_floor_report_data') ?>",
                        "type": "POST",
                        "data": function (data) {
                            data.start_dates = $('#start_dates').val();
                            data.end_dates = $('#end_dates').val();
                        },
                                data:{[csrfName]: csrfHash}, 
                    },
                    "dom": 'lBfrtip',
                    "buttons": [
                        {
                            extend: 'collection',
                            text: 'Export',
                            buttons: [
                                'copy',
                                'excel',
                                'csv',
                                'pdf',
                                'print'
                            ]
                        }
                    ],
                    //Set column definition initialisation properties.
                    "columnDefs": [
                        {
                            "targets": [0], //first column / numbering column
                            "orderable": false, //set not orderable
                        },
                    ],
                    "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                });
                // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                $('#btn-filter').click(function () { //button filter event click
                    table.ajax.reload();  //just reload table
                });
                $('#btn-reset').click(function () { //button reset event click
                    $('#form-filter')[0].reset();
                    table.ajax.reload();  //just reload table
                });
            });
            setInterval(function () {
                table.ajax.reload();
            }, 3000);
        </script>

        <?php $this->load->view('admin/includes/footer'); ?>
    </div>



</body>
