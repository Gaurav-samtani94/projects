<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$disabledAct = '';
$ModeofEmployeementArr = ModeofEmployeement();
if ($SingleRecordArr->status > 2) {
    $disabledAct = 'disabled';
}
?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/css/select2.min.css">
<style>
/* .copied::before {
    display: block;
    width: 15px;
    margin: 0 auto;
} */

.copied::after {
    position: absolute;
    top: 0px;
    right: 35px;
    height: 30px;
    line-height: 25px;
    display: block;
    content: "copied";
    font-size: 1.5em;

    padding: 2px 10px;
    color: #ff6347;
    background-color: #4099FF;
    border-radius: 3px;
    opacity: 1;
    will-change: opacity, transform;
    animation: showcopied 1.5s ease;
}

/* } */

:hover {
    cursor: pointer;
    background-color: darken(#f8f8f8, 10%);
    transition: background-color .3s ease-in;
}


@keyframes showcopied {
    0% {
        opacity: 0;
        transform: translateX(100%);
    }

    70% {
        opacity: 1;
        transform: translateX(0);
    }

    100% {
        opacity: 0;
    }
}
.media-left .rounded-circle {
    width: 125px;
    height: 125px;
    padding: 5px;
}
.mkkk{
	position: relative;
}
.iop{
	position: relative;
}
.mk,.select2,.iop{
	width: 100% !important;
}
.importantRule { 
top: 54px!important;
left: 0px!important; 
}
</style>
<script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Details Management</h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?= base_url('list_temp_employee'); ?>" class="">
                                        <i class="fa fa-users"></i> Letter List
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                

                <?php if ($this->session->flashdata('success_msg')) : ?>
                <div class="alert alert-success alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')) : ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                </div>
                <?php endif; ?>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <form method="post" action="" id="empform" name="hrmsempform" enctype="multipart/form-data">
                                <!-- Start Professional -->
                                <div class="body">
                                    <div class="row clearfix">

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label for="email">Temp ID : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s21"><?=$letterCode[21]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s21')"
                                                        style="cursor:pointer"></i></label>
                                                <input type="text" readonly id="emp_id" name="emp_id"
                                                    value="<?= $SingleRecordArr->tmp_emp_id; ?>" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <span id="reqd" class="error_lettertype">
                                                    <?= form_error('lettertype'); ?>
                                                </span>
                                                <label for="email">Letter Type : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s22"><?= $letterCode[22]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s22')"
                                                        style="cursor:pointer"></i>
                                                </label>
                                                <input type="text" readonly value="Letter Type" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                               
                                                <label for="email">Letter Template : <span style="color:red;">*</span></label>
                                                <select <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="Templete_id" id="Templete_id" class="form-control select2">
                                                    <option
                                                        <?= ($SingleRecordArr->templete_id == '') ? 'selected' : ''; ?>
                                                        value=''> -- Select Template -- </option>
                                                    <?php
                                                        if ($AllTempleteArr) {
                                                            foreach (@$AllTempleteArr as $key => $reCdd) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->templete_id == $reCdd->id) ? 'selected' : ''; ?>
                                                        <?= set_select('Templete_id', @$reCdd->id, (!empty($data) && $data == @$reCdd->id ? true : false)); ?>
                                                        value="<?= @$reCdd->id; ?>">
                                                        <?= @$reCdd->letter_templete_name; ?></option>
                                                    <?php }
                                                        } ?>
                                                </Select>
                                                <span id="reqd"
                                                    class="error_Templete_id"><?= form_error('Templete_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Letter No. : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s23"><?= $letterCode[23]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s23')"
                                                        style="cursor:pointer"></i>
                                                </label>
                                                <input <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    type="text" id="lettercode" name="lettercode"
                                                    value="<?= set_value('lettercode', $SingleRecordArr->lettercode); ?>"
                                                    class="form-control">
                                                    <span id="reqd"
                                                    class="error_lettercode"><?= form_error('lettercode'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Letter Subject : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s14"><?=$letterCode[14]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s14')"
                                                        style="cursor:pointer"></i>
                                                </label>
                                                <input <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    type="text" name="subject" id="subject"
                                                    value="<?= set_value('subject', $SingleRecordArr->sub_offerletter); ?>"
                                                    class="form-control">
                                                    <span id="reqd"
                                                    class="error_subject"><?= form_error('subject'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Offer Date : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s3"><?=$letterCode[3]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s3')"
                                                        style="cursor:pointer"></i></label>
                                                <input <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    type="date" id="letter_date" name="letter_date"
                                                    value="<?= set_value('letter_date', $SingleRecordArr->letter_date); ?>"
                                                    class="form-control date">
                                                    <span id="reqd"
                                                    class="error_letter_date"><?= form_error('letter_date'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Bussines Unit : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s24"><?=$letterCode[24]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s24')"
                                                        style="cursor:pointer"></i>
                                                </label>
                                                <select <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="business_unit" id="business_unit"
                                                    class="form-control select2">
                                                    <option
                                                        <?= ($SingleRecordArr->business_unit == '') ? 'selected' : ''; ?>
                                                        <?= set_select('business_unit', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="">-- Select Unit</option>
                                                    <?php
                                                            $business_unit = get_businessunits();
                                                                foreach ($business_unit as $key => $vall) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->templete_id == $vall->id) ? 'selected' : ''; ?>
                                                        <?= set_select('business_unit', $vall->id, (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="<?= $vall->id; ?>"><?= $vall->unitname; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_business_unit">
                                                    <?= form_error('business_unit'); ?>
                                                </span>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Prefix : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s4"><?=$letterCode[4]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s4')"
                                                        style="cursor:pointer"></i></label>
                                                <select <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="prefix" id="prefix" class="form-control select2">
                                                    <option <?= ($SingleRecordArr->prefix == '') ? 'selected' : ''; ?>
                                                        <?=set_select('prefix', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="">Select Prefix</option>
                                                    <?php
                                                            $main_prefix = main_prefix();
                                                            foreach ($main_prefix as $k => $v) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->templete_id == $v->id) ? 'selected' : ''; ?>
                                                        <?=set_select('prefix', $v->id, (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="<?= $v->id; ?>"><?= $v->prefix; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_prefix"><?= form_error('prefix'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">First Name : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s1"><?=$letterCode[1]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s1')"
                                                        style="cursor:pointer"></i></label>
                                                <input <?= $disabledAct; ?> type="text"
                                                    onclick="rmvalidationerror(this.id)" id="name" name="name"
                                                    value="<?= set_value('name', $SingleRecordArr->firstname); ?>"
                                                    class="form-control ">
                                                    <span id="reqd" class="error_name"><?= form_error('name'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Middle Name : &nbsp;&nbsp;
                                                    <b id="s25"><?=$letterCode[25]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s25')"
                                                        style="cursor:pointer"></i> </label>
                                                <input <?= $disabledAct; ?> type="text"
                                                    onclick="rmvalidationerror(this.id)" id="middle_name"
                                                    name="middle_name"
                                                    value="<?= set_value('middle_name', $SingleRecordArr->middle_name); ?>"
                                                    class="form-control ">
                                                    <span id="reqd"
                                                    class="error_name"><?= form_error('middle_name'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Last Name : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s2"><?=$letterCode[2]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s2')"
                                                        style="cursor:pointer"></i> </label>
                                                <input <?= $disabledAct; ?> type="text"
                                                    onclick="rmvalidationerror(this.id)" name="lastname" id="lastname"
                                                    value="<?= set_value('lastname', $SingleRecordArr->lastname); ?>"
                                                    class="form-control ">
                                                    <span id="reqd"
                                                    class="error_lastname"><?= form_error('lastname'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Full Name : &nbsp;&nbsp;
                                                    <b id="s26"><?=$letterCode[26]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s26')"
                                                        style="cursor:pointer"></i> </label>
                                                <input disabled type="text"
                                                    value="<?= $SingleRecordArr->userfullname; ?>" class="form-control">
                                                    <span id="reqd"
                                                    class="error_lettercode"><?= form_error('lettercode'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Contact No : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s11"><?=$letterCode[11]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s11')"
                                                        style="cursor:pointer"></i></label>
                                                <input <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    type="number" name="contact_no" id="contact_no"
                                                    value="<?= set_value('contact_no', $SingleRecordArr->contact); ?>"
                                                    class="form-control">
                                                    <span id="reqd"
                                                    class="error_contact_no"><?= form_error('contact_no'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Email : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s12"><?=$letterCode[12]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s12')"
                                                        style="cursor:pointer"></i>
                                                </label>
                                                <input <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    type="email" name="email" id="email" class="form-control"
                                                    value="<?= set_value('email', $SingleRecordArr->email); ?>">
                                                    <span id="reqd" class="error_email"><?= form_error('email'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Address 1 : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s5"><?=$letterCode[5]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s5')"
                                                        style="cursor:pointer"></i></label>
                                                <textarea <?= $disabledAct; ?> name="address_one" id="address_one"
                                                    onclick="rmvalidationerror(this.id)"
                                                    class="form-control"><?= set_value('address_one', $SingleRecordArr->address1); ?></textarea>
                                                    <span id="reqd"
                                                    class="error_address_one"><?= form_error('address_one'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Address 2 : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s566"><?=$letterCode[6]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s6')"
                                                        style="cursor:pointer"></i></label>
                                                <textarea <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="address_two" id="address_two"
                                                    class="form-control"><?= set_value('address_two', $SingleRecordArr->address2); ?></textarea>
                                                    <span id="reqd"
                                                    class="error_address_two"><?= form_error('address_two'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Country : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s9"><?=$letterCode[9]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s9')"
                                                        style="cursor:pointer"></i></label>
                                                <select <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="country" id="country" onchange="getstate()"
                                                    class="form-control select2">
                                                    <option <?= ($SingleRecordArr->country == '') ? 'selected' : ''; ?>
                                                        <?= set_select('country', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                        value=''> -- Select Country -- </option>
                                                    <?php
                                                             $country = getcountry();
                                                               foreach ($country as $key => $value) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->country == $value->id) ? 'selected' : ''; ?>
                                                        <?= set_select('country', $value->id, (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="<?= $value->id; ?>"> <?= $value->country_name; ?>
                                                    </option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd"
                                                    class="error_country"><?= form_error('country'); ?></span>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">State : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s8"><?=$letterCode[8]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s8')"
                                                        style="cursor:pointer"></i></label>
                                                <select <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="state_id" id="state_id" onchange="getcity_State()"
                                                    class="form-control select2">
                                                    <option <?= ($SingleRecordArr->state_id == '') ? 'selected' : ''; ?>
                                                        value=''> -- Select -- </option>
                                                    <?php
                                                     if (set_value('country') or $SingleRecordArr->country) {
                                                         $states = getState_country($SingleRecordArr->country);
                                                         foreach ($states as $key => $val) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->state == $val->id) ? 'selected' : ''; ?>
                                                        value="<?= $val->id; ?>"
                                                        <?=set_select('state_id', $val->id, (!empty($data) && $data == $val->id ? true : false)); ?>>
                                                        <?= $val->state_name; ?></option>
                                                    <?php }
                                                     } ?>
                                                </select>
                                                <span id="reqd"
                                                    class="error_state_id"><?= form_error('state_id'); ?></span>
                                            </div>
                                        </div>


                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">City : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s7"><?=$letterCode[7]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s7')"
                                                        style="cursor:pointer"></i></label>
                                                <select <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="city" id="city" class="form-control select2">
                                                    <option <?= ($SingleRecordArr->city == '') ? 'selected' : ''; ?>
                                                        value=''> -- Select -- </option>
                                                    <?php
                                                      if (set_value('city') or $SingleRecordArr->state) {
                                                          $cityArr = getcity_State($SingleRecordArr->state);
                                                          foreach ($cityArr as $key => $val) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->city == $val->id) ? 'selected' : ''; ?>
                                                        value="<?= $val->id; ?>"
                                                        <?= set_select('city', $val->id, (!empty($data) && $data == $val->id ? true : false)); ?>>
                                                        <?= $val->city_name; ?></option>
                                                    <?php }
                                                      } ?>
                                                </select>
                                                <span id="reqd" class="error_city"><?= form_error('city'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Pin Code :  <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s10"><?=$letterCode[10]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s10')"
                                                        style="cursor:pointer"></i></label>
                                                <input <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    maxlength="6"
                                                    value="<?= set_value('pincode', $SingleRecordArr->pincode); ?>"
                                                    type="text" name="pincode" id="pincode" class="form-control">
                                                    <span id="reqd"
                                                    class="error_pincode"><?= form_error('pincode'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Position : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s13"><?=$letterCode[13]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s13')"
                                                        style="cursor:pointer"></i></label>
                                                <select <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="position" id="position" class="form-control select2">
                                                    <option <?= ($SingleRecordArr->position == '') ? 'selected' : ''; ?>
                                                        <?=set_select('position', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                        value=""> -- Select -- </option>
                                                    <?php
                                                        $position = get_all_positions();
                                                         foreach ($position as $key => $val) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->position == $val->id) ? 'selected' : ''; ?>
                                                        <?=set_select('position', $val->id, (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="<?= $val->id; ?>"> <?= $val->positionname; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd"
                                                    class="error_position"><?= form_error('position'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Company Name : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s16"><?=$letterCode[16]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s16')"
                                                        style="cursor:pointer"></i></label>
                                                <select <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="company_id" id="company_id" class="form-control select2">
                                                    <option
                                                        <?= ($SingleRecordArr->company_id == '') ? 'selected' : ''; ?>
                                                        <?= set_select('company_id', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="">-- Select Company --</option>
                                                    <?php
                                                      $companylist = get_companyname();
                                                        foreach ($companylist as $key => $val) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->company_id == $val->id) ? 'selected' : ''; ?>
                                                        <?= set_select('company_id', $val->id, (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="<?=$val->id; ?>"><?=$val->company_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd"
                                                    class="error_company_id"><?= form_error('company_id'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Comp. Location: <span style="color:red;">*</span>
                                                    <b id="s19"><?=$letterCode[19]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s19')"
                                                        style="cursor:pointer"></i></label>
                                                <select <?= $disabledAct; ?> name="cmp_location"
                                                    onclick="rmvalidationerror(this.id)" id="cmp_location"
                                                    class="form-control select2">
                                                    <option
                                                        <?= ($SingleRecordArr->cmp_location == '') ? 'selected' : ''; ?>
                                                        <?= set_select('cmp_location', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                        value=''> -- Select Location -- </option>
                                                    <?php
                                                            $comp_location = get_compancy_location();
                                                            foreach ($comp_location as $key => $va) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->cmp_location == $va->id) ? 'selected' : ''; ?>
                                                        <?= set_select('cmp_location', $va->id, (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="<?= $va->id; ?>"><?= $va->city_name; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd"
                                                    class="error_cmp_location"><?= form_error('cmp_location'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">HR Name : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s17"><?=$letterCode[17]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s17')"
                                                        style="cursor:pointer"></i></label>
                                                <select <?= $disabledAct; ?> onclick="rmvalidationerror(this.id)"
                                                    name="hrname" id="hrname" class="form-control select2">
                                                    <option <?= ($SingleRecordArr->hr_name == '') ? 'selected' : ''; ?>
                                                        value="">-- Select HR --</option>
                                                    <?php
                                                           $hr = GetAll_Hr();
                                                            foreach ($hr as $key => $val) { ?>
                                                    <option
                                                        <?= ($SingleRecordArr->hr_name == $val->user_id) ? 'selected' : ''; ?>
                                                        <?= set_select('hrname', $val->user_id, (!empty($data) && $data == '' ? true : false)); ?>
                                                        value="<?= $val->user_id; ?>">
                                                        <?= $val->userfullname.' - '.$val->employeeId; ?></option>
                                                    <?php } ?>
                                                </select>
                                                <span id="reqd" class="error_hrname"><?= form_error('hrname'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">HR Position : &nbsp;&nbsp;
                                                    <b id="s18"> <?=$letterCode[18]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s18')"
                                                        style="cursor:pointer"></i></label>
                                                <input <?= $disabledAct; ?> type="text" disabled
                                                    value="<?= $SingleRecordArr->position_name; ?>"
                                                    class="form-control">
                                                    <span id="reqd"
                                                    class="error_hr_position"><?= form_error('hr_position'); ?></span>
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                
                                                <label for="email">Amount : <span style="color:red;">*</span>&nbsp;&nbsp;
                                                    <b id="s20"><?=$letterCode[20]->slug_str; ?></b>
                                                    <i class="fa fa-copy" onclick="copyToClipboard('#s20')"
                                                        style="cursor:pointer"></i>
                                                </label>
                                                <input <?= $disabledAct; ?> type="text"
                                                    onclick="rmvalidationerror(this.id)" id="amount" name="amount"
                                                    value="<?= set_value('amount', $SingleRecordArr->amount); ?>"
                                                    class="form-control">
                                                <span id="reqd" class="error_amount"><?= form_error('amount'); ?></span>
                                            </div>
                                        </div>

                                        <?php if ($SingleRecordArr->status < 3) { ?>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <input type="hidden"
                                                    name="<?= $this->security->get_csrf_token_name(); ?>"
                                                    value="<?= $this->security->get_csrf_hash(); ?>">
                                                <input <?= $disabledAct; ?> class="btn btn-one" type="submit"
                                                    value="Update" name="submit" id="submit">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="text-muted"> &nbsp; </label> <br>
                                                <a href="<?= base_url('set_status_lockbyhr/'.$SingleRecordArr->id); ?>"
                                                    class="btn btn-one" type="button"> Lock By HR </a>
                                            </div>
                                            <strong style='color:red; padding-left:20px'> * Letter Template will be
                                                visible After Lock </strong>
                                        </div>

                                        <?php } ?>

                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>



                <?php if ($SingleRecordArr->status > 2) { ?>
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <form method="post" action="<?= base_url('save_upd_letter_content'); ?>"
                            enctype="multipart/form-data">
                            <div class="card">
                                <div class="row">
                                    <div class="col-md-12">
                                        <?php if ($TempEmpl_LetterRecArr) { ?>
                                        <div class="form-group">
                                            <textarea name="letter_desc" id="letter_desc" class="form-control">
                                                <?= $TempEmpl_LetterRecArr->letter_content; ?>
                                            </textarea>
                                        </div>
                                        <?php } else { ?>
                                        <div class="form-group">
                                            <textarea name="letter_desc" id="letter_desc"
                                                class="form-control"><?= $TemplateContentArr->description; ?></textarea>
                                        </div>
                                        <?php } ?>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="hidden" name="temp_id" value="<?= $SingleRecordArr->id; ?>">
                                            <input type="hidden" name="letter_type_id"
                                                value="<?= $SingleRecordArr->letter_type_id; ?>">
                                            <input type="hidden" name="template_id"
                                                value="<?= $SingleRecordArr->templete_id; ?>">
                                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>"
                                                value="<?= $this->security->get_csrf_hash(); ?>">
                                            <input class="btn btn-one" type="submit" value="Save & Update">
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
                <?php } ?>


                <?php if ($TempEmpl_LetterRecArr) { ?>
                <div class="card">
                    <div class="body">
                        <div class="row clearfix">
                            <div class="col-lg-12">
							<div class="table-response">
                                <table class="table table-striped table-bordered  table-hover">
                                    <thead>
                                        <tr>
                                            <th>TEMP-EMPID</th>
                                            <th>User FullName</th>
                                            <th>Letter Name</th>
                                            <th>Email ID</th>
                                            <th>Contact No</th>
                                            <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?= ($TempEmpl_LetterRecArr->tmp_emp_id) ? $TempEmpl_LetterRecArr->tmp_emp_id : ''; ?>
                                            </td>
                                            <td><?= ($TempEmpl_LetterRecArr->userfullname) ? $TempEmpl_LetterRecArr->userfullname : ''; ?>
                                            </td>
                                            <td><?= ($TempEmpl_LetterRecArr->letter_type_name) ? $TempEmpl_LetterRecArr->letter_type_name : ''; ?>
                                            </td>
                                            <td><?= ($TempEmpl_LetterRecArr->email) ? $TempEmpl_LetterRecArr->email : ''; ?>
                                            </td>
                                            <td><?= ($TempEmpl_LetterRecArr->contact) ? $TempEmpl_LetterRecArr->contact : ''; ?>
                                            </td>
                                            <td>
                                                <?php if ($TempEmpl_LetterRecArr->status <= 6) {
                                                                ?>
                                                <a href="<?= base_url('sendletter/'.$SingleRecordArr->id); ?>">
                                                    <i class='fa fa-send'></i></a>
                                                <?php
                                                            }?>
                                                &nbsp;

                                                <a
                                                    href="<?= base_url('letter_exportdata_word/'.$SingleRecordArr->id); ?>">
                                                    <i class='fa fa-download'></i>
                                                </a>
                                                &nbsp;

                                                <?php if ($TempEmpl_LetterRecArr->status != 9 && $TempEmpl_LetterRecArr->status >= 7) {
                                                                ?>

                                                <a title="Joining Process" href="javascript:void(0)"
                                                    onclick="editpopup(<?=$SingleRecordArr->id; ?>)">
                                                    <spam class="fa fa-plus" data-toggle="modal"
                                                        data-target="#exampleModal"></spam>
                                                </a>
                                                <?php
                                                            }?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                <?php } ?>

            </div>
        </div>
    </div>

    <!-- MOdel  Start -->

    <!-- Abhsihek  -->
    <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog  modal-lg" role="document" style="width:80% !importent;max-width:80% !importent;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Joining Process</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="" id="my-form" name="hrmsempform" enctype="multipart/form-data">

                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>"
                            value="<?php echo $this->security->get_csrf_hash(); ?>">
                        <input type="hidden" name="id" id="ids">
                        <!-- <input type="hidden" name="id" value=""> -->
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-sm-2">
                                    <div class="media">
                                        <div class="media-left m-r-15">
                                            <img id="blah" height="105" width="100"
                                                src="<?= HOSTNAME; ?>assets/images/avatar2.jpg" class="rounded-circle"
                                                alt="">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-3">
                                    <div class="media-body">
                                        <input type="text" class="btn btn-default-dark" value="" />
                                        <span style="color:red" id="uploaderror2"> File Upload Error </span>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input btn" name="empprofile_pic"
                                                id="inputGroupFile03">
                                            <label class="custom-file-label" for="inputGroupFile03">Choose
                                                file</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-7">
                                    <div class="row">
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="email">CEG </label>
                                                <p> <?= ($Lt_EMPID_CEG) ? $Lt_EMPID_CEG : ''; ?> </p>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="email">CEGTH </label>
                                                <p> <?= ($Lt_EMPID_CEGTH) ? $Lt_EMPID_CEGTH : ''; ?> </p>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="email">PCC </label>
                                                <p> <?= ($Lt_EMPID_PCC) ? $Lt_EMPID_PCC : ''; ?> </p>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="email">TECHNO </label>
                                                <p> <?= ($Lt_EMPID_TECHNO) ? $Lt_EMPID_TECHNO : ''; ?> </p>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="email">KCPL </label>
                                                <p> <?= ($Lt_EMPID_KCPL) ? $Lt_EMPID_KCPL : ''; ?> </p>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="email">SKES </label>
                                                <p> <?= ($Lt_EMPID_SKES) ? $Lt_EMPID_SKES : ''; ?> </p>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="email">VDP </label>
                                                <p> <?= ($Lt_EMPID_VDP) ? $Lt_EMPID_VDP : ''; ?> </p>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="email">CEG Project </label>
                                                <p> <?= ($Lt_EMPID_CegProj) ? $Lt_EMPID_CegProj : ''; ?> </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                        </div>


                        <!-- Start Professional -->
                        <!-- <div class="tab-pane" id="official"> -->
                        <div class="">

                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group mkkk">
                                        <span id="recruitment_for_error"
                                            class="error_recruitment_for"><?= form_error('recruitment_for'); ?></span>
                                        <label class="text-muted">Recruitment For : <span id="">*</span></label> <br>
                                        
										<select onchange="ReplacementConSection()" onclick="rmvalidationerror(this.id)"
                                            class="form-control show-tick ms mk custom-dropdown" name="recruitment_for"
                                            id="recruitment_for" data-placeholder="Select">
                                            <option
                                                <?= set_select('recruitment_for', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value="" selected='true'> -- Select-- </option>
                                            <option
                                                <?= set_select('recruitment_for', '1', (!empty($data) && $data == '1' ? true : false)); ?>
                                                value="1"> New </option>
                                            <option
                                                <?= set_select('recruitment_for', '2', (!empty($data) && $data == '2' ? true : false)); ?>
                                                value="2"> Replacement </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3" id="div_replacedwithuserid"
                                    style="<?= (set_value('recruitment_for') != '2') ? 'display:none' : ''; ?>">
                                    <div class="form-group">
                                        <span id=""
                                            class="error_replaced_with_userid"><?= form_error('replaced_with_userid'); ?></span>
                                        <label class="text-muted"> Replaced With : <span id="">*</span></label> <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="replaced_with_userid" id="replaced_with_userid"
                                            data-placeholder="Select">
                                            <option
                                                <?= set_select('replaced_with_userid', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select-- </option>
                                            <?php
                                                        if (@$ReplacedWithAllUserListArr) {
                                                            foreach (@$ReplacedWithAllUserListArr as $empRow) {
                                                                ?>
                                            <option
                                                <?= set_select('replaced_with_userid', $empRow->id, (!empty($data) && $data == $empRow->id ? true : false)); ?>
                                                value="<?= $empRow->id; ?>">
                                                <?= $empRow->userfullname.' [ '.$empRow->employeeId.' ]'; ?>
                                            </option>
                                            <?php
                                                            }
                                                        } ?>
                                        </select>
                                    </div>
                                </div>


                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="" class="error_prefix_id"><?= form_error('prefix_id'); ?></span>
                                        <label class="text-muted">Prefix : <span id="">*</span></label>
                                        <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="prefix_id" id="prefix_i" data-placeholder="Select">
                                            <option
                                                <?= set_select('prefix_id', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if ($preFixRecArr) {
                                                            foreach ($preFixRecArr as $keyy => $recD) {
                                                                ?>
                                            <option
                                                <?= set_select('prefix_id', $recD->id, (!empty($data) && $data == $recD->id ? true : false)); ?>
                                                value="<?= $recD->id; ?>"><?= $recD->prefix; ?></option>
                                            <?php
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_first_name"
                                            class="error_first_name"><?= form_error('first_name'); ?></span>
                                        <label class="text-muted">First Name : <span id="">*</span></label> <br>
                                        <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                            class="form-control" type="text" name="first_name" id="first_name"
                                            value="<?= set_value('first_name'); ?>">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">

                                        <label class="text-muted">Middle Name : </label> <br>
                                        <input autocomplete="off" class="form-control" type="text" name="middle_name"
                                            id="middle_name" value="<?= set_value('middle_name'); ?>">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_last_name"
                                            class="error_last_name"><?= form_error('error_last_name'); ?></span>
                                        <label class="text-muted">Last Name : </label> <br>
                                        <input autocomplete="off" class="form-control" type="text" name="last_name"
                                            id="last_name" value="<?= set_value('last_name'); ?>">
                                    </div>
                                </div>

                                <div class="col-md-1">
                                    <div class="form-group">
                                        <span id="error_employee_code"
                                            class="error_employee_code"><?= form_error('employee_code'); ?></span>
                                        <label class="text-muted">EmpCode</label> <br>
                                        <input autocomplete="off" class="form-control" type="text" name="employee_code"
                                            id="employee_code" readonly value="<?= @$EMPCodeRow; ?>">
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <span id="error_employee_id"
                                            class="error_employee_id"><?= form_error('employee_id'); ?></span>
                                        <label class="text-muted">Employee ID : <span id="">*</span></label> <br>
                                        <input autocomplete="off" onclick="rmvalidationerror(this.id)"
                                            class="form-control" type="text" name="employee_id" id="employee_id"
                                            value="<?= set_value('employee_id'); ?>">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_mode_employment"
                                            class="error_mode_employment"><?= form_error('mode_employment'); ?></span>
                                        <label class="text-muted">Mode of Employment : <span id="">*</span></label> <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="mode_employment" id="mode_employment" data-placeholder="Select">
                                            <option
                                                <?= set_select('mode_employment', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if ($ModeofEmployeementArr) {
                                                            foreach ($ModeofEmployeementArr as $RecD) {
                                                                ?>
                                            <option
                                                <?= set_select('mode_employment', $RecD, (!empty($data) && $data == $RecD ? true : false)); ?>
                                                value="<?= $RecD; ?>"><?= $RecD; ?></option>
                                            <?php
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_role" class="error_role"><?= form_error('role'); ?></span>
                                        <label class="text-muted"> Role : <span id="">*</span></label>
                                        <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="role" id="role" data-placeholder="Select">
                                            <option
                                                <?= set_select('role', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if ($roleRecArr) {
                                                            foreach ($roleRecArr as $keyy => $recD) {
                                                                ?>
                                            <option
                                                <?= set_select('role', $recD->id, (!empty($data) && $data == $recD->id ? true : false)); ?>
                                                value="<?= $recD->id; ?>"><?= $recD->rolename; ?></option>
                                            <?php
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_official_emailid"
                                            class="error_official_emailid"><?= form_error('official_emailid'); ?></span>
                                        <label class="text-muted">Official Email : <span id="">*</span></label> <br>
                                        <input autocomplete="off" type="text" onclick="rmvalidationerror(this.id)"
                                            value="<?= set_value('official_emailid'); ?>" name="official_emailid"
                                            id="official_emailid" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_business_unitss"
                                            class="error_business_unitss"><?= form_error('business_unitss'); ?></span>
                                        <label class="text-muted">Business Unit : <span id="">*</span></label> <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control "
                                            name="business_unit" id="business_unitss" onchange="setAllDeptByBunit()"
                                            data-placeholder="Select">
                                            <option
                                                <?= set_select('business_unit', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if ($BunitsRecArr) {
                                                            foreach ($BunitsRecArr as $keyy => $recD) {
                                                                ?>
                                            <option
                                                <?= set_select('business_unit', $recD->id, (!empty($data) && $data == $recD->id ? true : false)); ?>
                                                value="<?= $recD->id; ?>"><?= $recD->unitname; ?></option>
                                            <?php
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_company_ids"
                                            class="error_company_id"><?= form_error('error_company_id'); ?></span>
                                        <label class="text-muted">Company : <span id="">*</span></label>
                                        <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="company_id" id="company_ids" data-placeholder="Select">
                                            <option
                                                <?= set_select('company_id', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if ($CompanyRecArr) {
                                                            foreach ($CompanyRecArr as $Ckey => $Crows) {
                                                                ?>
                                            <option
                                                <?= set_select('company_id', $Crows->id, (!empty($data) && $data == $Crows->id ? true : false)); ?>
                                                value="<?= $Crows->id; ?>"><?= $Crows->company_name; ?>
                                            </option>
                                            <?php
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_department"
                                            class="error_department"><?= form_error('department'); ?></span>
                                        <label class="text-muted">Department : <span id="">*</span></label> <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="department" id="department" onchange="setRepManagerByBunit()"
                                            data-placeholder="Select">
                                            <option
                                                <?= set_select('department', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if (set_value('business_unit')) {
                                                            @$deptArr = GetAllDepartmentByBUnit(set_value('business_unit'));
                                                            if (@$deptArr) {
                                                                foreach (@$deptArr as $reCdd) {
                                                                    ?>
                                            <option
                                                <?= set_select('department', $reCdd->id, (!empty($data) && $data == $reCdd->id ? true : false)); ?>
                                                value="<?= $reCdd->id; ?>"><?= $reCdd->deptname; ?></option>
                                            <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group iop">
                                        <span id="error_reporting_manager"
                                            class="error_reporting_manager"><?= form_error('reporting_manager'); ?></span>
                                        <label class="text-muted">Reporting Manager (IO) : <span id="">*</span></label>
                                        <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms io"
                                            name="reporting_manager" id="reporting_manager" data-placeholder="Select">
                                            <option
                                                <?= set_select('reporting_manager', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if (set_value('reporting_manager')) {
                                                            @$reportngmngrArr = GetAllRepManagerByBUnit(set_value('business_unit'));
                                                            if (@$reportngmngrArr) {
                                                                foreach (@$reportngmngrArr as $rePmngr) {
                                                                    ?>
                                            <option
                                                <?= set_select('reporting_manager', $rePmngr->user_id, (!empty($data) && $data == $rePmngr->user_id ? true : false)); ?>
                                                value="<?= $rePmngr->user_id; ?>">
                                                <?= $rePmngr->userfullname.' ['.$rePmngr->employeeId.'] '; ?>
                                            </option>
                                            <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_job_titlegroup"
                                            class="error_job_titlegroup"><?= form_error('job_titlegroup'); ?></span>
                                        <label class="text-muted">Job Title/Group : <span id="">*</span></label> <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="job_titlegroup" id="job_titlegroup"
                                            onchange="setDesignationByJobTitID()" data-placeholder="Select">
                                            <option
                                                <?= set_select('job_titlegroup', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if ($JobGroupRecArr) {
                                                            foreach ($JobGroupRecArr as $keyy => $recD) {
                                                                ?>
                                            <option
                                                <?= set_select('job_titlegroup', $recD->id, (!empty($data) && $data == $recD->id ? true : false)); ?>
                                                value="<?= $recD->id; ?>"><?= $recD->jobtitlename; ?>
                                            </option>
                                            <?php
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_designation"
                                            class="error_designation"><?= form_error('designation'); ?></span>
                                        <label class="text-muted">Designation : <span id="">*</span></label> <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="designation" id="designation" data-placeholder="Select">
                                            <option
                                                <?= set_select('designation', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if (set_value('designation')) {
                                                            @$allDesignationArr = GetAllDesignationByJtitID(set_value('job_titlegroup'));
                                                            if (@$allDesignationArr) {
                                                                foreach (@$allDesignationArr as $desRow) {
                                                                    ?>
                                            <option
                                                <?= set_select('designation', $desRow->id, (!empty($data) && $data == $desRow->id ? true : false)); ?>
                                                value="<?= $desRow->id; ?>"><?= $desRow->positionname; ?>
                                            </option>
                                            <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_employment_status"
                                            class="error_employment_status"><?= form_error('employment_status'); ?></span>
                                        <label class="text-muted">Employment Status : <span id="">*</span></label> <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="employment_status" id="employment_status" data-placeholder="Select">
                                            <option
                                                <?= set_select('employment_status', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select -- </option>
                                            <?php
                                                        if ($EmpStatusArr) {
                                                            foreach ($EmpStatusArr as $keyy => $recD) {
                                                                ?>
                                            <option
                                                <?= set_select('employment_status', $recD->id, (!empty($data) && $data == $recD->id ? true : false)); ?>
                                                value="<?= $recD->id; ?>"><?= $recD->employemnt_status; ?>
                                            </option>
                                            <?php
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_dateofjoining"
                                            class="error_dateofjoining"><?= form_error('dateofjoining'); ?></span>
                                        <label class="text-muted">Date of Joining : <span id="">*</span></label> <br>
                                        <div class="input-group date" data-date-autoclose="true"
                                            data-provide="datepicker">
                                            <input autocomplete="off" onclick="rmvalidationerror(this.id)" type="text"
                                                class="form-control" name="dateofjoining" autocomplete="off"
                                                id="dateofjoining" value="<?= set_value('dateofjoining'); ?>">
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="button"><i
                                                        class="fa fa-calendar"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="text-muted">Years of Experience (Previous ) : </label>
                                        <br>
                                        <input autocomplete="off" type="text"
                                            value="<?= set_value('yearofexp_prev'); ?>" name="yearofexp_prev"
                                            id="yearofexp_prev" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_mob_number"
                                            class="error_mob_number"><?= form_error('mob_number'); ?></span>
                                        <label class="text-muted">Mobile Number : <span id="">*</span></label> <br>
                                        <input autocomplete="off" onclick="rmvalidationerror(this.id)" type="text"
                                            value="<?= set_value('mob_number'); ?>" name="mob_number" id="mob_number"
                                            class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="text-muted">Extension : </label> <br>
                                        <input autocomplete="off" type="text"
                                            value="<?= set_value('extension_number'); ?>" name="extension_number"
                                            id="extension_number" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <span id="error_joining_at"
                                            class="error_joining_at"><?= form_error('joining_at'); ?></span>
                                        <label class="text-muted"> Joining at : <span id="">*</span></label> <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms "
                                            name="joining_at" id="joining_at" onchange="onprojcondition()"
                                            data-placeholder="Select">
                                            <option
                                                <?= set_select('joining_at', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select-- </option>
                                            <option
                                                <?= set_select('joining_at', '1', (!empty($data) && $data == '1' ? true : false)); ?>
                                                value="1"> HO - Jaipur </option>
                                            <option
                                                <?= set_select('joining_at', '2', (!empty($data) && $data == '2' ? true : false)); ?>
                                                value="2"> RO - Delhi </option>
                                            <option
                                                <?= set_select('joining_at', '3', (!empty($data) && $data == '3' ? true : false)); ?>
                                                value="3"> RO - Mumbai </option>
                                            <option
                                                <?= set_select('joining_at', '4', (!empty($data) && $data == '4' ? true : false)); ?>
                                                value="4"> On Project </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3" id="onproj_devsection1"
                                    style="<?= (set_value('joining_at') != '4') ? 'display:none' : ''; ?>">
                                    <div class="form-group">
                                        <span id="" class="error_project_id"><?= form_error('project_id'); ?></span>
                                        <label class="text-muted"> Project : <span id="">*</span></label> <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control  show-tick ms "
                                            name="project_id" id="project_id" onchange="setproj_designation()"
                                            data-placeholder="Select">
                                            <option
                                                <?= set_select('project_id', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select-- </option>
                                            <?php
                                                        if ($ActiveProjectListArr) {
                                                            foreach ($ActiveProjectListArr as $keyy => $recD) {
                                                                ?>
                                            <option
                                                <?= set_select('project_id', $recD->id, (!empty($data) && $data == $recD->id ? true : false)); ?>
                                                value="<?= $recD->id; ?>"><?= $recD->project_name; ?>
                                            </option>
                                            <?php
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-3" id="onproj_devsection2"
                                    style="<?= (set_value('joining_at') != '4') ? 'display:none' : ''; ?>">
                                    <div class="form-group">
                                        <span id=""
                                            class="error_project_designationid"><?= form_error('project_designationid'); ?></span>
                                        <label class="text-muted"> Project Designation : <span id="">*</span></label>
                                        <br>
                                        <select onclick="rmvalidationerror(this.id)" class="form-control show-tick ms"
                                            name="project_designationid" id="project_designationid"
                                            data-placeholder="Select">
                                            <option
                                                <?= set_select('project_designationid', '', (!empty($data) && $data == '' ? true : false)); ?>
                                                value=""> -- Select-- </option>
                                            <?php
                                                        if (set_value('project_id')) {
                                                            @$allProjDesignationArr = GetAllProjDesignationByProjID(set_value('project_id'));
                                                            if (@$allProjDesignationArr) {
                                                                foreach (@$allProjDesignationArr as $prjRow) {
                                                                    ?>
                                            <option
                                                <?= set_select('project_designationid', $prjRow->designation_id, (!empty($data) && $data == $desRow->designation_id ? true : false)); ?>
                                                value="<?= $prjRow->designation_id; ?>">
                                                <?= $prjRow->designation_name; ?></option>
                                            <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label class="text-muted"> &nbsp; </label> <br>
                                        <button class="btn btn-success" type="button" onclick="add_tempto_employe()">
                                            Submit</button>
                                        <!-- <input class="btn btn-one" type="button" onclick="add_tempto_employe()" value="Submit"
                                                        name="submit" > -->
                                    </div>
                                </div>

                            </div>

                        </div>
                        <!-- </div> -->

                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- end Model  -->
	</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <script>
    // CKEDITOR.replace('letter_desc');
    CKEDITOR.replace('letter_desc');
    CKEDITOR.replace('description');
    CKEDITOR.replace('kk');
    </script>
    <?php /*
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous">
    </script> */ ?>
	
	

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
    $("#recruitment_for").select2({
        allowClear: true,
        placeholder: " -- "
    });
    </script>
    <script>
    //Validation Error Removed..
    function rmvalidationerror(returnarrg) {
        $('.error_' + returnarrg).html("");
    }

    function gtetemplete() {
        var lettertype = $('#lettertype').val();
        $.ajax({
            url: "<?=base_url('get_letter_templete'); ?>",
            type: "POST",
            data: {
                lettertype: lettertype,
            },
            dataType: 'json',
            success: function(res) {
                $('#Templete_id').html('');
                $('#Templete_id').trigger("change");
                $('#Templete_id').append("<option>Select Templete</option>");
                if (res) {
                    $.each(res, function(key, val) {
                        $('#Templete_id').append("<option value=" + val.id + ">" + val
                            .letter_templete_name + "</option>");
                    });
                } else {
                    $('#Templete_id').append("<option>Select Templete</option>");
                }
            }
        });
    }


    function getstate() {
        var country = $("#country").val();

        $('#state_id').html('');
        $('#state_id').val('');
        $('#state_id').trigger("change");

        $("#state_id").select2({
            allowClear: true,
            placeholder: " -- "
        });

        $.ajax({
            url: "<?=base_url('getstate'); ?>",
            type: "POST",
            data: {
                country: country
            },
            dataType: 'json',
            success: function(res) {
                $('#state_id').html();
                $('#state_id').append("<option value=''> -- Select State -- </option>");
                $.each(res, function(key, val) {
                    $('#state_id').append("<option value=" + val.id + ">" + val.state_name +
                        "</option>");
                });
            }
        });

    }

    function getcity_State() {
        var state = $("#state_id").val();

        $('#city').html('');
        $('#city').val('');
        $('#city').trigger("change");

        $("#city").select2({
            allowClear: true,
            placeholder: " -- "
        });

        $.ajax({
            url: "<?=base_url('getcity'); ?>",
            type: "POST",
            data: {
                state: state
            },
            dataType: 'json',
            success: function(res) {
                $('#city').html();
                $('#city').append("<option value=''> -- Select City -- </option>");

                $.each(res, function(key, val) {
                    $('#city').append("<option value=" + val.id + ">" + val.city_name +
                        "</option>");
                });
            }
        });
    }
    </script>
    <!-- last time add this -->

    <!-- end last time  -->
    <script>
    function add_tempto_employe() {
        
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
        // var form = $('#my-form')[0];
        // console.log(form);
        var a = $('#recruitment_for').val();
        var b = $('#prefix_i').val();
        var c = $('#first_name').val();
        var d = $('#last_name').val();
        var e = $('#employee_id').val();
        var f = $('#mode_employment').val();
        var g = $('#role').val();
        var h = $('#official_emailid').val();
        var i = $('#business_unitss').val();
        var j = $('#company_ids').val();
        var k = $('#department').val();
        var l = $('#reporting_manager').val();
        var m = $('#job_titlegroup').val();
        var n = $("#designation").val();
        var o = $('#employment_status').val();
        var p = $('#dateofjoining').val();
        var q = $('#mob_number').val();
        var r = $('#joining_at').val();

        if (a == '') {
            $('#recruitment_for_error').html('<p class="requ" style>Recruitment for is Required</p>');
        }
        if (b == '') {
            $('#error_prefix_id').html('<p class="requ">Prefix is Required</p>');
        }
        if (c == '') {
            $('#error_first_name').html('<p class="requ">First Name is Required</p>')
        }
        if (d == '') {
            $('#error_last_name').html('<p class="requ">Last Name is Required</p>')
        }
        if (e == '') {
            $('#error_employee_id').html('<p class="requ">Employe Id is Required</p>')
        }
        if (f == '') {
            $('#error_mode_employment').html('<p class="requ">Mode of Employemnet is Required</p>')
        }
        if (g == '') {
            $('#error_role').html('<p class="requ">Role is Required</p>')
        }
        if (h == '') {
            $('#error_official_emailid').html('<p class="requ">Official for is Required</p>')
        }
        if (i == '') {
            $('#error_business_unitss').html('<p class="requ">Business Unit is Required</p>')
        }
        if (j == '') {
            $('#error_company_ids').html('<p class="requ">Company Name is Required</p>')
        }
        if (k == '') {
            $('#error_department').html('<p class="requ">Department Name is Required</p>')
        }
        if (l == '') {
            $('#error_reporting_manager').html('<p class="requ">Reporting Manager Name is Required</p>')
        }
        if (m == '') {
            $('#error_job_titlegroup').html('<p class="requ">Job Title/Group Name is Required</p>')
        }
        if (n == '') {
            $('#error_designation').html('<p class="requ">Designation Name is Required</p>')
        }
        if (o == '') {
            $('#error_employment_status').html('<p class="requ">Employment Status Name is Required</p>')
        }
        if (p == '') {
            $('#error_dateofjoining').html('<p class="requ">Date Of Joining is Required</p>')
        }
        if (q == '') {
            $('#error_mob_number').html('<p class="requ">Mobile Number is Required</p>')
        }
        if (r == '') {
            $('#error_joining_at').html('<p class="requ">Joining at is Required</p>')
        }



        if (a != '' && b != '' && c != '' && d != '' && e != '' && f != '' && g != '' && h != '' && i != '' && j !=
            '' && k !== '' && l != '' && m != '' && n != '' && o != '' && p != '' && q != '' && r != '') {
            // alert('yesw');

            // alert(a);
            // die();
            // Create an FormData object 
            var datas = $("#my-form").serialize();
            // datas.append("login_name", "731004167");
            // console.log(datas);

            $.ajax({
                type: 'POST',
                url: '<?= base_url('addtemp_toemp'); ?>',
                data: datas,
                success: function(response) {
                    if (response > 0) {
                        window.location = '<?=base_url('employee_edit');?>/' +
                            response;
                    }
                },
            });
        }
    }
    //Validation Error Removed..
    function rmvalidationerror(returnarrg) {
        $('.error_' + returnarrg).html("");
    }
    //Condition Script for Replaced By..
    function ReplacementConSection() {
        var recruitment_for = $('#recruitment_for').val();

        $('#replaced_with_userid').val("");
        $('#replaced_with_userid').trigger("change");

        $('#div_replacedwithuserid').hide();
        if (recruitment_for == "2") {
            $('#div_replacedwithuserid').show();
        }
    }

    function setAllDeptByBunit() {
        var bunitID = $("#business_unitss").val();
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

        $('#department').html('');
        $('#department').trigger("change");

        if (bunitID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_department_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'bunitid': bunitID
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    // $('#department').html('');
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#department').append('<option value="' + val.id + '">' + val
                                .deptname + '</option>');
                        });
                    }
                },
            });
        }
    }

    //Set Reporting Manager By Bunit..
    function setRepManagerByBunit() {
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
        var bunitID = $("#business_unit").val();

        $('#reporting_manager').val('');
        $('#reporting_manager').trigger("change");
        $('#reporting_manager').val('');
        $('#reporting_manager').html('');

        if (bunitID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_reportingmanager_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'bunitid': bunitID
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    $('#reporting_manager').html('');
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#reporting_manager').append('<option value="' + val.user_id +
                                '">' +
                                val.userfullname + ' [' + val.employeeId + '] </option>');
                        });
                    }
                },

            });
        }
    }

    function setDesignationByJobTitID() {
        var jobtitleID = $('#job_titlegroup').val();
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

        $('#designation').html('');
        $('#designation').trigger("change");

        if (jobtitleID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_designation_position_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'jtitleid': jobtitleID
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    $('#designation').html('');
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#designation').append('<option value="' + val.id + '">' + val
                                .positionname + ' </option>');
                        });
                    }
                },
            });
        }
    }

    //On project Condition..
    function onprojcondition() {
        var joiningat = $('#joining_at').val();
        $('#onproj_devsection1').hide();
        $('#onproj_devsection2').hide();
        if (joiningat == "4") {
            $('#onproj_devsection1').show();
            $('#onproj_devsection2').show();
        }
    }

    function editpopup(val) {
        // alert(val);
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
        if (val) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_temp_employe'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'letter_id': val
                },
                success: function(response) {
                    //         $('#first_name').val(data.firstname);
                    // $('#last_name').val('');
                    // $('#official_emailid').val('');
                    // $('#mob_number').val('');
                    // $('#prefix_id').val('');
                    if (response) {
                        var data = jQuery.parseJSON(response);
                        $('#first_name').val(data.firstname);
                        $('#last_name').val(data.lastname);
                        $('#official_emailid').val(data.email);
                        $('#mob_number').val(data.contact);
                        $('#prefix_i').val(data.prefix);
                        $('#ids').val(data.id);
                        $('#recruitment_for').val(data.recruitment_for);
                    }

                },
            });
        }

    }

    function setproj_designation() {
        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
        var projectid = $('#project_id').val();

        $('#project_designationid').empty().append('<option selected="selected" value="">-- Select --</option>');
        $('#project_designationid').trigger("change");

        if (projectid) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_prodesignation_byprojidbd_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'projid': projectid
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    $('#project_designationid').html('');
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#project_designationid').append('<option value="' + val
                                .designation_id + '">' + val.designation_name + ' </option>'
                            );
                        });
                    }
                },
            });
        }
    }
    </script>
    <!-- ecnd this abishek  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script>
    function copyToClipboard(element) {
        console.log(element);
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val($(element).text()).select();
        //console.log($temp);
        document.execCommand("copy");
        // copyyyyy(element);
        // element.classList.add("copied");
        // window.getSelection().removeAllRanges();
        // setTimeout(function() {
        //     element.classList.remove("copied");
        // }, 2500);






        $temp.remove();
    }

    function copyyyyy(e) {
        // console.log(e);
        // alert(e);
        // alert('this function was triggered');
        // find target element
        var

            c = e.dataset['copytarget'];
        t = e.dataset.copytarget;

        console.log(t);
        d = "#copy_text_" + c;
        console.log(d);
        inp = (d ? document.querySelector(d) : null);
        // console.log(inp);

        // check if input element exist and if it's selectable
        if (inp && inp.select) {
            // select text
            inp.select();
            try {
                // copy text
                document.execCommand('copy');
                inp.blur();

                // copied animation
                inp.classList.add('copied');

                setTimeout(function() {
                    t.classList.remove('copied');
                }, 1500);
            } catch (err) {
                //fallback in case exexCommand doesnt work
                alert('please press Ctrl/Cmd+C to copy');
            }

        }

    }
    </script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.0/js/select2.full.min.js"></script>
	<script>
			$('.mk').select2({
dropdownParent: $('.mkkk')
});	
$('.io').select2({
dropdownParent: $('.iop')
});
$(".select2.select2-container").click(function(){
	$(".select2 + .select2-container").addClass('importantRule');
 });
 
 
	</script>
	
    <?php $this->load->view('admin/includes/footer'); ?>
	
</body>