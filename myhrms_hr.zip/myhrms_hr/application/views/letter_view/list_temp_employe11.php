<?php
$this->load->view('admin/includes/head');

$this->load->view('admin/includes/header');
$ModeofEmployeementArr = ModeofEmployeement();
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">

                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?=($title) ? $title : ''; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?=base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?=($title) ? $title : ''; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>




                <div class="row clearfix">


                    <div class="col-lg-12">

                        
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Temp Employe ID</th>
                                                <th>Employe Name</th>
                                                <th>email</th>
                                                <th>Letter Type</th>
                                                <th>Position</th>
                                                <th>hr_name</th>
                                             <th>Action</th>
                                            </tr>
                                        </thead>


                                        <tfoot>
                                            <tr>
                                            <th>Sr.No.</th>
                                                <th>Temp Employe ID</th>
                                                <th>Employe Name</th>
                                                <th>email</th>
                                                <th>Letter Type</th>
                                                <th>Position</th>
                                                <th>hr_name</th>
                                             <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    </div>  

<script>
    function add_tempto_employe()
    {
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
        // var form = $('#my-form')[0];
// console.log(form);
     
       // Create an FormData object 
        var datas = $("#my-form").serialize();
        // datas.append("login_name", "731004167");
        // console.log(datas);
        
        $.ajax({
                type: 'POST',
                url: '<?= base_url('addtemp_toemp'); ?>',
                data: datas,
                success: function(response) {
                    if(response>0)
                    {
            window.location ='http://localhost/myhrms_hr/index.php/employee_edit/'+response;
                 }
                },
            });
    }
       //Validation Error Removed..
       function rmvalidationerror(returnarrg) {
        $('.error_' + returnarrg).html("");
    }
     //Condition Script for Replaced By..
     function ReplacementConSection() {
        var recruitment_for = $('#recruitment_for').val();

        $('#replaced_with_userid').val("");
        $('#replaced_with_userid').trigger("change");

        $('#div_replacedwithuserid').hide();
        if (recruitment_for == "2") {
            $('#div_replacedwithuserid').show();
        }
    }
    function setAllDeptByBunit() {
        var bunitID = $("#business_unit").val();
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

        $('#department').val('');
        $('#department').trigger("change");

        if (bunitID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_department_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'bunitid': bunitID
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    $('#department').html('');
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#department').append('<option value="' + val.id + '">' + val
                                .deptname + '</option>');
                        });
                    }
                },
            });
        }
    }

  //Set Reporting Manager By Bunit..
  function setRepManagerByBunit() {
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
        var bunitID = $("#business_unit").val();

        $('#reporting_manager').val('');
        $('#reporting_manager').trigger("change");
        $('#reporting_manager').val('');
        $('#reporting_manager').html('');

        if (bunitID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_reportingmanager_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'bunitid': bunitID
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#reporting_manager').append('<option value="' + val.user_id + '">' +
                                val.userfullname + ' [' + val.employeeId + '] </option>');
                        });
                    }
                },

            });
        }
    }

    function setDesignationByJobTitID() {
        var jobtitleID = $('#job_titlegroup').val();
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';

        $('#designation').val('');
        $('#designation').trigger("change");

        if (jobtitleID) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_designation_position_bybunit_dropd_ajax'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'jtitleid': jobtitleID
                },
                success: function(response) {
                    var data = jQuery.parseJSON(response);
                    if (data) {
                        $.each(data, function(index, val) {
                            $('#designation').append('<option value="' + val.id + '">' + val
                                .positionname + ' </option>');
                        });
                    }
                },
            });
        }
    }

    //On project Condition..
    function onprojcondition() {
        var joiningat = $('#joining_at').val();
        $('#onproj_devsection1').hide();
        $('#onproj_devsection2').hide();
        if (joiningat == "4") {
            $('#onproj_devsection1').show();
            $('#onproj_devsection2').show();
        }
    }
    function editpopup(val)
    {
        var csrfName = '<?= $this->security->get_csrf_token_name(); ?>',
            csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
        if(val)
        {
            $.ajax({
                type: 'POST',
                url: '<?= base_url('set_temp_employe'); ?>',
                data: {
                    [csrfName]: csrfHash,
                    'letter_id': val
                },
                success: function(response) {
            //         $('#first_name').val(data.firstname);
            // $('#last_name').val('');
            // $('#official_emailid').val('');
            // $('#mob_number').val('');
            // $('#prefix_id').val('');
                    if(response)
                    {
                         var data = jQuery.parseJSON(response);
            $('#first_name').val(data.firstname);
            $('#last_name').val(data.lastname);
            $('#official_emailid').val(data.email);
            $('#mob_number').val(data.contact);
            $('#prefix_id').val(data.prefix);
            $('#ids').val(data.id);
                    }
                
                },
            });
        }
        
    }

   

     var table;
        $(document).ready(function() {
            $('.hidden').hide();
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                // var compid = $('#companynames').val();
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [], //Initial no order.
                "scrollY": '10vh',
                "scrollX": true,
                // Load data for the table's content from an Ajax source
                "ajax": {
                    "url": "<?php echo base_url('getall_Accept_Offer_Letter_Employe'); ?>",
                    "type": "POST",
                    "data": function(data) {
                        // data.start_dates = $('#start_dates').val();
                        // data.end_dates = $('#end_dates').val();
                    },
                    data: {
                        [csrfName]: csrfHash
                    },


                },
                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }],
                //Set column definition initialisation properties.
                "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                }, ],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function() { //button filter event click
                table.ajax.reload(); //just reload table
            });
            $('#btn-reset').click(function() { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload(); //just reload table
            });
        });
</script>


   
        <?php $this->load->view('admin/includes/footer'); ?>





</body>
