<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
      <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?=($title) ? $title : ''; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?=base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?=($title) ? $title : ''; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <?php if ($this->session->flashdata('success')): ?>
                                        <div class="alert alert-success  ">
                                            <a href="#" class="close" data-dismiss="alert"
                                                aria-label="close">&times;</a>
                                            <strong>Success ! </strong>
                                            <?php echo $this->session->flashdata('success'); ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($this->session->flashdata('error')): ?>
                                        <div class="alert alert-danger  ">
                                            <a href="#" class="close" data-dismiss="alert"
                                                aria-label="close">&times;</a>
                                            <strong>error ! </strong>
                                            <?php echo $this->session->flashdata('error'); ?>
                                        </div>
                                        <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                               
                                       
    
                                        <form method="post" action="<?=base_url('addletter'); ?>"> 
                                            <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                            <!--<div class="card-header" id="headingOne">-->
                                            <div class="row clearfix">

                                                <div class="col-lg-3">
                                                    
                                                </div>

                                                <div class="col-lg-3">
                                                <div class="form-group">
                                                <span id="reqd"
                                                        class="error_business_unit"><?= form_error('business_unit'); ?></span>
                                                   <label for="">
                                                    <b>Bussines Unit: </b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('business_unit'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <select  name="business_unit" id="business_unit" class="form-control select2">
                                                            <option value="">-- Select Unit</option>
                                                            <?php $business_unit = get_businessunits();
                                                                foreach ($business_unit as $key => $vall) {
                                                                    ?>
                                                                <option  <?= set_select('business_unit', $vall->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?=$vall->id; ?>"><?=$vall->unitname; ?></option>
                                                                <?php
                                                              } ?>
                                                        </select>
                                                        <!-- <input type="text" id="businessunits" name="businessunits"
                                                            class="form-control"> -->
                                                    </div>
                                                  </div>
                                                </div>


                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Letter Code :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('cegcode'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <input type="text"  id="cegcode" name="cegcode" value="<?= set_value('cegcode') ? set_value('cegcode') : ''; ?>"
                                                            class="form-control">
                                                    </div>
</div>
                                                </div>


                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Letter Type :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('lettertype'); ?></span>
                                                    <div class="input-group mb-3">
                                                  
                                                        <select name="lettertype"  onchange="gtetemplete()" id="lettertype" class="form-control select2"
                                                            aria-readonly>
                                                            <option value="">Select Letter Type</option>
                                                            <?php
                                                            $lettertype = getletterType();
                                                            foreach ($lettertype as $k => $val) {
                                                                ?>
                                                               <option <?=set_select('lettertype', $val->id, (!empty($data) && $data == '' ? true : false)); ?>value="<?=$val->id; ?>"><?=$val->letter_type_name; ?></option>
                                                            <?php
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
</div>

                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Letter Templete:</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('Templete_id'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <!-- <div class="input-group-prepend">
                                                             <span class="input-group-text"><i
                                                                    class="icon-calendar"></i></span>
                                                        </div> -->
                                                       <Select name="Templete_id"  id="Templete_id" class="form-control select2">
                                                        <option >Select Templete</option>
                                                        <?php
                                                        if (set_value('lettertype')) {
                                                            @$deptArr = get_all_templete_id(set_value('lettertype'));
                                                            if (@$deptArr) {
                                                                foreach (@$deptArr as $key => $reCdd) {
                                                                    ?>
                                                        <option
                                                            <?= set_select('Templete_id', @$reCdd->id, (!empty($data) && $data == '' ? true : false)); ?>
                                                            value="<?= @$reCdd->id; ?>"><?= @$reCdd->letter_templete_name; ?></option>
                                                        <?php
                                                                }
                                                            }
                                                        }
                                                        ?>
                                                       </Select>
                                                    </div>
                                                </div>
                                            </div>

                                             <div class="col-lg-3 col-md-6">
                                                <div class="form-group">                                      
                                                   <label for="email">
                                                    <b>Subject :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('subject'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <input type="text" name="subject" id="subject"value="<?= set_value('subject') ? set_value('subject') : ''; ?>" class="form-control">
                                                    </div>
                                                  </div>
                                             </div>

                                                <div class="col-lg-3 col-md-6">
                                                  <div class="form-group">
                                                   <label for="email">
                                                    <b>Offer/Joining Date :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('letter_date'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i
                                                                    class="icon-calendar"></i></span>
                                                        </div>
                                                        <input type="date" id="from_date"  name="from_date" value="<?= set_value('from_date') ? set_value('from_date') : ''; ?>"
                                                            class="form-control date" >
                                                    </div>
                                                  </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                   <div class="form-group">                                       
                                                   <label for="email">
                                                    <b>Prefix :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('prefix'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <select name="prefix" id="prefix"  class="form-control select2">
                                                            <option value="">Select Prefix</option>
                                                            <?php    $main_prefix = main_prefix();
                                                            foreach ($main_prefix as $k => $v) {
                                                                ?>
                                                                <option <?=set_select('prefix', $v->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?=$v->id; ?>"><?= $v->prefix; ?></option><?php
                                                            }
                                                            ?>
                                                            <!-- <option <?php //@$form_data['prefix'] == 1 ? 'Selected' : '';?> value="1">Mr</option>
                                                            <option <?php //@$form_data['prefix'] == 2 ? 'Selected' : '';?> value="2">Ms</option>
                                                            <option <?php //@$form_data['prefix'] == 3 ? 'Selected' : '';?> value="3">Mrs</option> -->
                                                            <!-- <option value="">Select Prefix</option> -->

                                                        </select>
                                                    </div>
</div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>First Name :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('name'); ?></span>
                                                    <div class="input-group mb-3">

                                                        <input type="text" id="name"  name="name" value="<?= set_value('name') ? set_value('name') : ''; ?>" class="form-control ">
                                                    </div>
</div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Last Name :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('lastname'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <input type="text" name="lastname"  id="lastname" value="<?= @$form_data['lastname'] ? @$form_data['lastname'] : ''; ?>"
                                                            class="form-control ">
                                                    </div>
                                                </div></div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Address1 :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('address_one'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <textarea name="address_one" id="address_one"  
                                                            class="form-control"><?= set_value('address_one') ? set_value('address_one') : ''; ?></textarea>
                                                    </div>
</div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Address2 :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('address_two'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <textarea name="address_two" id="address_two"  
                                                            class="form-control"><?= set_value('address_two') ? set_value('address_two') : ''; ?></textarea>
                                                    </div>
                                                </div>
</div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Country :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('country'); ?></span>
                                                    <div class="input-group mb-3">
                                                            <select name="country" id="country"  onchange="getstate()" class="form-control select2">
                                                            <option> Select Country</option>
                                                            <?php $country = getcountry();

                                                            foreach ($country as $key => $value) {
                                                                ?>
                                                                <option <?=set_select('country', $value->id, (!empty($data) && $data == '' ? true : false)); ?>  value="<?=$value->id; ?>"><?=$value->country_name; ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                                
                                                            </select>
                                                        <!-- <input type="text" name="country" id="country"
                                                            class="form-control"> -->
                                                    </div>
                                                        </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>State :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('state'); ?></span>
                                                    <div class="input-group mb-3">
                                                    <select name="state" id="state"  onchange="getcity_State()" class="form-control select2">
                                                                <option></option>
                                                                <?php if (set_value('state')) {
                                                                $states = getState_country(set_value('country'));
                                                                foreach ($states as $key => $val) {
                                                                    ?>
                                                                    <option  value="<?=$val->id; ?>" <?=set_select('state', $val->id, (!empty($data) && $data == $val->id ? true : false)); ?>><?= $val->state_name; ?></option>
                                                                    <?php
                                                                }
                                                            }?>
                                                            </select>
                                                        <!-- <input type="text" name="state" id="state" class="form-control"> -->
                                                    </div>
                                                </div>
                                                        </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>City :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('city'); ?></span>
                                                    <div class="input-group mb-3">
                                                    <select name="city" id="city"  class="form-control select2">
                                                                <option></option>
                                                                <?php if (set_value('city')) {
                                                                $city = getcity_State(set_value('state'));
                                                                foreach ($city as $key => $val) {
                                                                    ?>
                                                                    <option  value="<?=$val->id; ?>" <?=set_select('city', $val->id, (!empty($data) && $data == $val->id ? true : false)); ?>><?= $val->city_name; ?></option>
                                                                    <?php
                                                                }
                                                            }?>
                                                            </select>

                                                        <!-- <input type="text" name="city" id="city" class="form-control"> -->
                                                    </div>
                                                        </div>
                                                </div>


                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="">
                                                    <b>PinCode :</b></label>
                                                  
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('pincode'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <input  maxlength="6" value="<?= set_value('pincode') ? set_value('pincode') : ''; ?>" type="text" name="pincode" id="pincode" 
                                                            class="form-control">
                                                    </div>
                                                        </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Contact No :</b></label>
                                                   
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('contact_no'); ?></span>
                                                    <div class="input-group mb-3">

                                                        <input  type="number" name="contact_no" id="contact_no"value="<?= set_value('contact_no') ? set_value('contact_no') : ''; ?>"
                                                            class="form-control">
                                                    </div>
                                                        </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Email : </b>
                                                        </label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('email'); ?></span>
                                                    <div class="input-group mb-3">
                                                
                                                        <input type="email"  name="email" class="form-control"value="<?= set_value('email') ? set_value('email') : ''; ?>">
                                                      
                                                    </div>
                                                        </div>
                                                    
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Position :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('position'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <select  name="position" id="position" class="form-control select2">
                                                        <option value="">-- Select Position --</option>
                                                            <?php $position = get_all_positions();
                                                            foreach ($position as $key => $val) {
                                                                ?>
                                                            <option <?=set_select('position', $val->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $val->id; ?>"> <?= $val->positionname; ?></option>
                                                            <?php
                                                            }?>
                                                        <option></option>
                                                        </select>

                                                        <!-- <input type="text"  value="<?php //= @$form_data['position'] ? @$form_data['position'] : '';?>"
                                                            class="form-control"> -->
                                                    </div>
                                                </div>
                                                        </div>
                                           

                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Company Name :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('company_id'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <select name="company_id" id="company_id" class="form-control select2">
                                                            <option value="">-- Select Company --</option>
                                                            <?php
                                                                $companylist = get_companyname();
                                                                foreach ($companylist as $key => $val) {
                                                                    ?>
                                                                                                                            <option  <?=set_select('company_id', $val->id, (!empty($data) && $data == '' ? true : false)); ?>value="<?=$val->id; ?>"><?=$val->company_name; ?>
                                                                                                                            </option>
                                                                                                                            <?php
                                                                }?>
                                                        </select>
                                                    </div>
</div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Company Location :</b></label>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('cmp_location'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <select name="cmp_location"  id="cmp_location" class="form-control select2">
                                                            <option>-- Select Location --</option>
                                                            <?php $comp_location = get_compancy_location();
                                                            foreach ($comp_location as $key => $va) {
                                                                ?>
                                                                <option <?=set_select('cmp_location', $va->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?=$va->id; ?>" ><?= $va->city_name; ?></option>
                                                                <?php
                                                            } ?>
                                                        </select>
                                                        
                                                    </div>
</div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>HR Name :</b>
                                                    <span id="reqd" class="error_perm_hono"><?= form_error('hrname'); ?></span>
</label>
                                                    <div class="input-group mb-3">
                                                        <select name="hrname"  id="hrname" onchange="fetch_positon()"  class="form-control select2">
                                                        <option value="">-- Select HR --</option>
                                                           <?php $hr = GetAll_Hr();
                                                            foreach ($hr as $key => $val) {
                                                                ?>
                                                                <option <?=set_select('hrname', $val->user_id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $val->user_id; ?>"><?= $val->userfullname.''.$val->employeeId; ?></option>
                                                                <?php
                                                            }?>
                                                        </select>
                                                        <!-- <input type="text" value="<?php//= @$form_data['hrname'] ? @$form_data['hrname'] : ''; ?>"
                                                            class="form-control"> -->
                                                    </div>
</div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>HR Position :</b>
</label>        <span id="reqd" class="error_perm_hono"><?= form_error('hr_position'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <select name="hr_position"  id="hr_position" class="form-control select2">
                                                        <option value="">-- Select positions --</option>
                                                            <?php $hr_postions = get_all_positions();
                                                            foreach ($hr_postions as $key => $val) {
                                                                ?>
                                                          
                                                            <option value="<?= @$val->id; ?>"><?= @$val->positionname; ?></option>
                                                            <?php
                                                            }?>
                                                            
                                                        </select>
                                                        <!-- <input type="text" value="<?= @$form_data['hr_position'] ? @$form_data['hr_position'] : ''; ?>"
                                                            class="form-control"> -->
                                                    </div>
</div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Ammount:</b>
</label>        <span id="reqd" class="error_perm_hono"><?= form_error('ammount'); ?></span>
                                                    <div class="input-group mb-3">
                                                        <input type="text" name="ammount"  id="ammount" value="<?= set_value('ammount') ? set_value('ammount') : ''; ?>"
                                                            class="form-control">
                                                    </div>
</div>
                                                </div>
                                                <!-- <div class="col-lg-3 col-md-6">
                                                    <br>
                                                    <a href="javascript:void(0)" onclick="ftechDescription()">Fetch
                                                        description</a>
                                                     <button id="ftechDescription" onclick="()" class="btn btn-primary">Fetch description</button>
                                                </div>
                                                <div class="col-md-12 "> -->
                                                <!-- <div class="form-group">
                                                   
                                                   <label for="email">
                                                    <b>Description :</b>
</label>
                                                    <div class="form-control">

                                                        <textarea name="description" id="description" required
                                                            class="form-control"><?php //= @$form_data['description'] ? @$form_data['$description'] : '';?></textarea>
                                                    </div>
</div>
                                                </div> -->

                                                <div class="col-lg-1 col-md-6 ">

                                                    <div class="mb-2">
                                                        <b></b>
                                                        <br>
                                                        <input type="submit" value="Add Letter"
                                                            class="btn btn-primary form-contol">
                                                        <!-- <input type="reset" style="margin-top: 20px;" id="" value="Reset" name="submit" class="btn btn-round btn-primary"> -->
                                                    </div>
                                                </div>


                                            </div>
                                            <h5 class="mb-0">


                                            </h5>
                                            <!--</div> -->

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <!-- <th>ceg_code</th> -->
                                                <th>offer_date</th>
                                                <th>userfullname</th>
                                                <!-- <th>address1</th> -->
                                                <th>email</th>
                                                <th>position</th>
                                                <th>hr_name</th>
                                                <th>hr_position</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>


                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                           
                                                <th>offer_date</th>
                                                <th>userfullname</th>
                                                <!-- <th>address1</th> -->
                                                <th>email</th>
                                                <th>position</th>
                                                <th>hr_name</th>
                                                <th>hr_position</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- //editpopup model========= -->
        <!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button> -->

        <!-- Modal -->
        <div id="main-content">
            <div class="container-fluid">
                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="modal" id="myModal" role="dialog">
                            <div class="modal-dialog modal-lg">

                                <!-- Modal content-->
                                <form method="post"
                                            action="<?=base_url('letter/LetterController/updateletter'); ?>">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h4 class="modal-title">Update Records</h4>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>

                                    </div>
                                    <div class="modal-body">

                                            <input type="hidden"
                                                name="<?php echo $this->security->get_csrf_token_name(); ?>"
                                                value="<?php echo $this->security->get_csrf_hash(); ?>">
                                            <!--<div class="card-header" id="headingOne">-->
                                            <div class="row clearfix">
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Ceg Code :</b>
                                                    <div class="input-group mb-3">
                                                        <input type="text" id="mcegcode" name="cegcode"
                                                            class="form-control">
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Letter Type :</b>
                                                    <div class="input-group mb-3">

                                                        <select name="lettertype" id="mlettertype" class="form-control"
                                                            disabled>
                                                            <option value="">Select Letter Type</option>
                                                            <option value="1">Offer Letter</option>
                                                            <option value="2">Ressigne Letter</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Offer Date :</b>
                                                    <div class="input-group mb-3">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i
                                                                    class="icon-calendar"></i></span>
                                                        </div>
                                                        <input type="date" id="mfrom_date" name="from_date"
                                                            class="form-control date" value="<?=@$from_date; ?>">
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Prefix :</b>
                                                    <div class="input-group mb-3">
                                                        <select name="prefix" id="mprefix" class="form-control">
                                                            <option value="">Select Prefix</option>
                                                            <?php
                                                            $main_prefix = main_prefix();
                                                            foreach ($main_prefix as $key => $vasl) {
                                                                ?>
        
        <option value="<?=$vasl->id; ?>"><?= $vasl->prefix; ?></option>
        <?php
                                                            }?>
                                                            <!-- <option value="1">Mr</option>
                                                            <option value="2">Ms</option>
                                                            <option value="3">Mrs</option> -->
                                                            <!-- <option value="">Select Prefix</option> -->

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>First Name :</b>
                                                    <div class="input-group mb-3">

                                                        <input type="text" id="mname" name="name" class="form-control ">
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Last Name :</b>
                                                    <div class="input-group mb-3">
                                                        <input type="text" name="lastname" id="mlastname"
                                                            class="form-control ">
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Address1 :</b>
                                                    <div class="input-group mb-3">
                                                        <textarea name="address_one" id="maddress_one"
                                                            class="form-control"></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Address2 :</b>
                                                    <div class="input-group mb-3">
                                                        <textarea name="address_two" id="maddress_two"
                                                            class="form-control"></textarea>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Country :</b>
                                                    <div class="input-group mb-3">
                                                        <select name="country" id="mcountry" onchange="mgetstate()" class="form-control">
                                                        <option> Select Country</option>
                                                            <?php $country = getcountry();

                                                            foreach ($country as $key => $value) {
                                                                ?>
                                                                <option value="<?=$value->id; ?>"><?=$value->country_name; ?></option>
                                                                <?php
                                                            }
                                                            ?></select>
<!-- 
                                                        <input type="text" name="country" id="mcountry"
                                                            class="form-control"> -->
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>State :</b>
                                                    <div class="input-group mb-3">
                                                        <select name="state" onchange="mgetcity_State()" id="mstate" class="form-control">
                                                            <option>Select State</option>
                                                            <?php

                                                            foreach ($state as $key => $val) {
                                                                ?>
                                                                <option value="<?=$val->id; ?>"><?=$val->state_name; ?></option>
                                                                <?php
                                                            }
                                                            ?>
                                                        </select>
                                                        <!-- <input type="text" name="state" id="mstate"
                                                            class="form-control"> -->
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>City :</b>
                                                    <div class="input-group mb-3">
                                                        <select name="city" id="mcity" class="form-control">
                                                            <option>Select city</option>
                                                            <?php

foreach ($city as $key => $val) {
    ?>
    <option value="<?=$val->id; ?>"><?=$val->city_name; ?></option>
    <?php
}
?>
                                                        </select>
                                                        <!-- <input type="text" name="city" id="mcity" class="form-control"> -->
                                                    </div>
                                                </div>


                                                <div class="col-lg-3 col-md-6">
                                                    <b>PinCode :</b>
                                                    <div class="input-group mb-3">
                                                        <input type="text" name="pincode" id="mpincode"
                                                            class="form-control">
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Contact No :</b>
                                                    <div class="input-group mb-3">

                                                        <input type="number" name="contact_no" id="mcontact_no"
                                                            class="form-control">
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Email :</b>
                                                    <div class="input-group mb-3">

                                                        <input type="email" name="email" id=memail class="form-control">
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Position :</b>
                                                    <div class="input-group mb-3">
                                                        <select name="position" id="mposition"
                                                            class="form-control">
                                                            <option value="">-- Select Position --</option>
<?php $position = get_all_positions();
foreach ($position as $key => $val) {
    ?>
    <option value="<?= $val->id; ?>"> <?= $val->positionname; ?></option>
    <?php
} ?>
</select>
                                                      
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Subject :</b>
                                                    <div class="input-group mb-3">

                                                        <input type="text" name="subject" id="msubject"
                                                            class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-lg-3 col-md-6">
                                                    <b>Company Name :</b>
                                                    <div class="input-group mb-3">
                                                        <select name="company_id" id="mcompany_id" class="form-control">
                                                            <option value="">-- Select Company --</option>
                                                            <?php
$companylist = get_companyname();
foreach ($companylist as $key => $val) {
    ?>
                                                            <option value="<?=$val->id; ?>"><?=$val->company_name; ?>
                                                            </option>
                                                            <?php
}?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Company Location :</b>
                                                    <div class="input-group mb-3">
                                                        <select name="cmp_location" id="mcmp_location"
                                                            class="form-control">
                                                            <option value="">-- Select Location --</option>
                                                    <?php $comp_location = get_compancy_location();
                                                            foreach ($comp_location as $key => $va) {
                                                                ?>
                                                                <option value="<?=$va->id; ?>" <?= @$form_data['cmp_location'] == $va->id ? 'Selected' : ''; ?>><?= $va->city_name; ?></option>
                                                                <?php
                                                            } ?>
                                                            </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>HR Name :</b>
                                                    <div class="input-group mb-3">
                                                        <Select  name="hrname" id="mhrname"
                                                            class="form-control">
                                                            <option value="">-- Select HR --</option>
                                                    <?php $hr = GetAll_Hr();
                                                            foreach ($hr as $key => $val) {
                                                                ?>
                                                                <option value="<?= $val->user_id; ?>"><?= $val->userfullname.''.$val->employeeId; ?></option>
                                                                <?php
                                                            }?>
                                                            </select>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>HR Position :</b>
                                                    <div class="input-group mb-3">
                                                        <select name="hr_position" id="mhr_position"
                                                            class="form-control">
                                                            <option value="">-- Select HR Position --</option>
                                                    <?php $position = get_all_positions();
foreach ($position as $key => $val) {
    ?>
    <option value="<?= $val->id; ?>"> <?= $val->positionname; ?></option>
    <?php
} ?>
                                                        </select>
                                                       
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 col-md-6">
                                                    <b>Ammount:</b>
                                                    <div class="input-group mb-3">
                                                        <input type="text" name="amount" id="mamount"
                                                            class="form-control">
                                                    </div>
                                                </div>

                                                <div class="col-md-12">
                                                    <b>Description :</b>
                                                    <textarea id="mdescription" name="mdescription" class="" rows="10"></textarea>
                                                </div>

                                                <div class="col-lg-12 col-md-6">
                                                    <div class="mb-2">
                                                        <input type="hidden" id="letterid" name="letterid" value="">
                                                        <input type="submit" value="Update" class="btn btn-primary form-contol">
                                                    </div>
                                                </div>
                                            </div>



                                    </div>
                                    <div class="modal-footer">
                                        <input type="submit" name="saveandlock" value="Save And Lock" class="btn btn-primary form-contol">

                                        <button type="button" class="btn btn-default"
                                            data-dismiss="modal">Close</button>
                                    </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

        <!-- MOdel -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div>
                            <div>
                                <div class="alert alert-success">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Success ! </strong> Letter Type added Successfully .
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" onclick="addletter()" class="btn btn-primary">Add
                                        Letter</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="//cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script>
        CKEDITOR.replace('letter_desc');
        CKEDITOR.replace('description');
        CKEDITOR.replace('mdescription');
    </script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script type="text/javascript">
            function gtetemplete(){
                var lettertype =$('#lettertype').val();
                $.ajax({
                url: "<?=base_url('get_letter_templete'); ?>",
                type: "POST",
                data: {
                    lettertype: lettertype,
                },
                dataType: 'json',
                success: function(res) {
                    $('#Templete_id').html('');
                    $('#Templete_id').append("<option>Select Templete</option>");
                    if(res){
                     $.each(res, function(key,val) {
                        $('#Templete_id').append("<option value="+val.id+">"+val.letter_templete_name+"</option>");
                    });
               } else {
                  $('#Templete_id').append("<option>Select Templete</option>");
                 }
                }
              });
            }

        function editpopup(valfield) {
            $.ajax({
                type: 'POST',
                dataType: "text",
                url: "<?=base_url('letter/LetterController/ajax_get_byid'); ?>",
                data: {
                    'editId': valfield
                },
                method: 'POST',
                dataType: 'json',
                success: function(response) {
                    CKEDITOR.instances['mdescription'].setData(response.offerlettter_desc);
                    $('#mcegcode').val(response.ceg_code);
                    $('#mlettertype').val(response.letter_type_id);
                    $('#mfrom_date').val(response.offer_date);
                    $('#mprefix').val(response.prefix);
                    $('#mname').val(response.firstname);
                    $('#mlastname').val(response.lastname);
                    $('#maddress_one').val(response.address1);
                    $('#maddress_two').val(response.address2);
                    $('#mcountry').val(response.country);
                    $('#mstate').val(response.state);
                    $('#mcity').val(response.city);
                    $('#mpincode').val(response.pincode);
                    $('#mcontact_no').val(response.contact);
                    $('#memail').val(response.email);
                    $('#mposition').val(response.position);
                    $('#msubject').val(response.sub_offerletter);
                    $('#mcompany_id').val(response.company_id);
                    $('#mcmp_location').val(response.cmp_location);
                    $('#mhrname').val(response.hr_name);
                    $('#mhr_position').val(response.hr_position);
                    $('#mamount').val(response.amount);
                    $('#letterid').val(response.id);
                }
            });
        }

        function addletter() {
            var letter_dec = CKEDITOR.instances['letter_desc'].getData();
            var letter_type = $("#letter_type").val();
            $.ajax({
                url: "<?=base_url('addLetterformat'); ?>",
                type: "POST",
                data: {
                    letter_dec: letter_dec,
                    letter_type: letter_type
                },
                dataType: 'json',
                success: function(res) {
                    if (res) {
                        $('#hidden').show()
                    }
                }
            });
        }

        function ftechDescription() {
            var lettertype = $('#lettertype').val();
            var templete_id = $('#Templete_id').val();
            var position = $('#position').val();
            var cmp_location = $('#cmp_location').val();
            var ammount = $('#ammount').val();

        if(templete_id !='') {
            $.ajax({
                url: "<?=base_url('Fetch_letter_decription'); ?>",
                type: "POST",
                data: {
                    lettertype: lettertype,
                    position: position,
                    cmp_location: cmp_location,
                    ammount: ammount,
                    templete_id:templete_id
                },
                dataType: 'json',
                success: function(res) {
                    CKEDITOR.instances['description'].setData(res);
                    $('.hidden').show();
                }
            });
        } else{
            toastr.error('You clicked Error Toast')
        }
     }

        var table;
        $(document).ready(function() {
            $('.hidden').hide();
            var csrfName = '<?= $this->security->get_csrf_token_name(); ?>', csrfHash = '<?= $this->security->get_csrf_hash(); ?>';
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [], //Initial no order.
                "scrollY": '10vh',
                "scrollX": true,
                // Load data for the table's content from an Ajax source
                "ajax": {
                    "url": "<?php echo base_url('getleterdata'); ?>",
                    "type": "POST",
                    "data": function(data) {
                        data.start_dates = $('#start_dates').val();
                        data.end_dates = $('#end_dates').val();
                    },
                    data: {
                        [csrfName]: csrfHash
                    },


                },
                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }],
                //Set column definition initialisation properties.
                "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                }, ],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function() { //button filter event click
                table.ajax.reload(); //just reload table
            });
            $('#btn-reset').click(function() { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload(); //just reload table
            });
        });

        function getstate() {
           var country = $("#country").val();
            $.ajax({
                url: "<?=base_url('getstate'); ?>",
                type: "POST",
                data: {
                    country:country
                },
                dataType: 'json',
                success: function(res) {
                    $('#state').html('');
                    $('#city').html('');
                    $('#city').append("<option>Select City</option>");
                    $('#state').append("<option>Select State</option>");
                    $.each(res, function(key,val) {
                        $('#state').append("<option value="+val.id+">"+val.state_name+"</option>");
                     });
                }
            });
        }

        function getcity_State(){
            var state = $("#state").val();
            $.ajax({
                url: "<?=base_url('getcity'); ?>",
                type: "POST",
                data: {
                    state:state
                },
                dataType: 'json',
                success: function(res) {
                    $('#city').html('');
                    $('#city').append("<option>Select City</option>");
                    $.each(res, function(key,val) {
                        $('#city').append("<option value="+val.id+">"+val.city_name+"</option>");
                     });       
                }
            });

        }

        //editbutton 
        function mgetstate(){
           var country = $("#mcountry").val();
            $.ajax({
                url: "<?=base_url('getstate'); ?>",
                type: "POST",
                data: {
                    country:country
                },
                dataType: 'json',
                success: function(res) {
                    $('#mstate').html('');
                    $('#mcity').html('');
                    $('#mcity').append("<option>Select City</option>");
                    $('#mstate').append("<option>Select State</option>");

                    $.each(res, function(key,val) {
                        $('#mstate').append("<option value="+val.id+">"+val.state_name+"</option>");
                     });
                }
            });
        }

        function mgetcity_State(){
            var state = $("#mstate").val();
            $.ajax({
                url: "<?=base_url('getcity'); ?>",
                type: "POST",
                data: {
                    state:state
                },
                dataType: 'json',
                success: function(res) {
                    $('#mcity').html('');
                    $('#mcity').append("<option>Select City</option>");
                    $.each(res, function(key,val) {
                        $('#mcity').append("<option value="+val.id+">"+val.city_name+"</option>");
                   }); 
                }
            });
        }

        function fetch_positon() {
          var hr_id = $('#hrname').val();
          $.ajax({
                url: "<?=base_url('get_hr_id_position'); ?>",
                type: "POST",
                data: {
                    hr_id:hr_id
                },
                dataType: 'json',
                success: function(res) {
                    $('#hr_position').val(res).change();
                }
            });

        }
        </script>
        <?php $this->load->view('admin/includes/footer'); ?>
</body>