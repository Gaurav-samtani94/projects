<?php
$this->load->view('admin/includes/head');

$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
$this->load->view('admin/includes/sidebar');
?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i
                                        class="fa fa-arrow-left"></i></a><?=($title) ? $title : ''; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?=base_url(); ?>"><i class="icon-home"></i></a>
                                </li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?=($title) ? $title : ''; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">


                    <div class="col-lg-12">

                        <div class="card">
                            <!-- <div class="container"><a href="" data-toggle="modal" data-target="#exampleModal"
                                    style=" float: right">+ Add Letter Format</a></div> -->
                            <br>
                            <div class="body">
                                <div class="accordion" id="accordion">
                                    <div>
                                        <?php if ($this->session->flashdata('success')): ?>
                                        <div class="alert alert-success  ">
                                            <a href="#" class="close" data-dismiss="alert"
                                                aria-label="close">&times;</a>
                                            <strong>Success ! </strong>
                                            <?php echo $this->session->flashdata('success'); ?>
                                        </div>
                                        <?php endif; ?>
                                        <?php if ($this->session->flashdata('error')): ?>
                                        <div class="alert alert-danger  ">
                                            <a href="#" class="close" data-dismiss="alert"
                                                aria-label="close">&times;</a>
                                            <strong>error ! </strong>
                                            <?php echo $this->session->flashdata('error'); ?>
                                        </div>
                                        <?php endif; ?>
                                        <div>
                                            <?php $this->session->flashdata('message'); ?>
                                        </div>
      <!-- Abhsihek added  -->
      <div class="modal-body">
                        <div>
                            <div>

                                <div class="alert alert-success hidden" id="hidden">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Success ! </strong> Letter Type added Successfully .
                                </div>

                                <div>
                                    <b>letter Type :</b>
                                    <select name="letter_type" id="letter_type" class="form-control">
                                        <option value="">Select letter Type</option>
                                        <?php
$LetterType = getletterType();

foreach ($LetterType as $Key => $val) {
    ?>
                                            <option value="<?=$val->id; ?>"><?=$val->letter_type_name; ?></option>
                                            <?php
}?>
                                    </select>
                                    <!-- <input type="text" name="letter_type" id="letter_type" class="form-control"> -->
                                    <br>
                                    <b>letter Templete Name :</b>
                                    <input type="text" name="letter_templete" id="letter_templete" class="form-control">
                                    <br>
                                    <b>Description :</b>
                                    <pre>   1.<?=strtolower('replaceposition'); ?>    2.replacecmp_location    3.replacecmp_ammountttt</pre>
                                    <div class="">

                                        <textarea name="letter_desc" id="letter_desc" class="form-control"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" onclick="addletter()" class="btn btn-primary">Add
                                        Letter</button>
                                </div>
                            </div>
                            </div>
                             </div>
                         </div>
                             </div>
                            <!-- end Abhishek  -->
                                     </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table">
                                        <thead>
                                            <tr>
                                            <th>Sr.No.</th>
                                                <th>letter_type_name</th>
                                                <th>letter_templete_name</th>
                                                <th>description</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>


                                        <tfoot>
                                            <tr>

                                                <th>Sr.No.</th>
                                                <th>letter_type_name</th>
                                                <th>letter_templete_name</th>
                                                <th>description</th>
                                                <th>Action</th>
                                                <!-- <th>address1</th> -->
                                                <!-- <th>email</th>
                                                <th>position</th>
                                                <th>hr_name</th>
                                                <th>hr_position</th>
                                                <th>Status</th>
                                                <th>Action</th> -->
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



<!-- Abhishek edit templete  Model-->

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div>
                            <div>

                                <div class="alert alert-success hidden" id="hidden">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Success ! </strong> Letter Type added Successfully .
                                </div>
<form meth>
                                <div>
                                    <b>letter Type :</b>
                                    <select name="letter_type_id" id="letter_type_id" class="form-control">
                                    <option value="">Select Letter Type</option>
                                    <?php
$LetterType = getletterType();
foreach ($LetterType as $Key => $val) {
    ?>
                                            <option value="<?=$val->id; ?>"><?=$val->letter_type_name; ?></option>
                                            <?php
}?>


                                    </select>
                                    <!-- <input type="text" name="letter_type" id="letter_type" class="form-control"> -->
                                    <br>

 <b>Letter Templete Name :</b>
                                    <div class="input-group">

                                    <input type="text" name="tempelte_name" id="tempelte_name" class="form-control">
                                    </div>
                                    <b>Descriptionssss :</b>
                                    <div class="input-group">

                                    <textarea name="kk" id="kk" class="form-control"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" onclick="addletter()" class="btn btn-primary">Add
                                        Letter</button>
                                </div>
</form>
                            </div>
                        </div>
                </div>
                </div>
            </div>
        </div>


        <script src="//cdn.ckeditor.com/4.19.0/standard/ckeditor.js"></script>

        <script>
        // CKEDITOR.replace('letter_desc');
        CKEDITOR.replace('letter_desc');
        CKEDITOR.replace('description');
        CKEDITOR.replace('kk');
        </script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous">
        </script>



        <script type="text/javascript">
        
 function addletter() {
            // var letter_dec = $('#letter_desc').val();
            var letter_dec = CKEDITOR.instances['letter_desc'].getData();
            var letter_type = $("#letter_type").val();
            var letter_templte_name = $("#letter_templete").val();
            $.ajax({
                url: "<?=base_url('addLetterformat'); ?>",
                type: "POST",
                data: {
                    letter_dec: letter_dec,
                    letter_type: letter_type,
                    letter_templte_name: letter_templte_name
                    // position:position,
                    // cmp_location:cmp_location
                },
                dataType: 'json',
                success: function(res) {
                    if (res) {
                        $('#hidden').show()
                    }

                    // CKEDITOR.instances['description'].setData(res);

                    //                 $('.hidden').show();

                }
            });
        }
        var table;
        $(document).ready(function() {
            $('.hidden').hide();
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                // var compid = $('#companynames').val();
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [], //Initial no order.
                "scrollY": '10vh',
                "scrollX": true,
                // Load data for the table's content from an Ajax source
                "ajax": {
                    "url": "<?php echo base_url('getletermasterdata'); ?>",
                    "type": "POST",
                    "data": function(data) {
                        // data.start_dates = $('#start_dates').val();
                        // data.end_dates = $('#end_dates').val();
                    },
                    data: {
                        [csrfName]: csrfHash
                    },


                },
                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }],
                //Set column definition initialisation properties.
                "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                }, ],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function() { //button filter event click
                table.ajax.reload(); //just reload table
            });
            $('#btn-reset').click(function() { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload(); //just reload table
            });
        });
        function editpopup(valfield) {
            $.ajax({
                type: 'POST',
                dataType: "text",
                url: "<?=base_url('letter/LetterController/ajax_get_letterTemplete'); ?>",
                data: {
                    'editId': valfield
                },
                method: 'POST',
                dataType: 'json',
                success: function(response) {

                    //alert(response);
      



                    CKEDITOR.instances['kk'].setData(response.description);
                //    CKEDITOR.instances['#kk'].setData(response.description);
                   
                    $('#letter_type_id').val(response.letter_type_id);
                    $('#tempelte_name').val(response.letter_templete_name);

                    //hold the response in id and show on popup


                    // $('#myModal').modal({
                    //     backdrop: 'static',
                    //     keyboard: true,
                    //     show: true
                    // });
                }
            });
        }
        </script>
        <?php $this->load->view('admin/includes/footer'); ?>





</body>