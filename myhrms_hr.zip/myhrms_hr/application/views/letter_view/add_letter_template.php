<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<style>
/* .copied::before {
    display: block;
    width: 15px;
    margin: 0 auto;
} */

.copied::after {
    position: absolute;
    top: 0px;
    right: 35px;
    height: 30px;
    line-height: 25px;
    display: block;
    content: "copied";
    font-size: 1.5em;

    padding: 2px 10px;
    color: #ff6347;
    background-color: #4099FF;
    border-radius: 3px;
    opacity: 1;
    will-change: opacity, transform;
    animation: showcopied 1.5s ease;
}

/* } */

:hover {
    cursor: pointer;
    background-color: darken(#f8f8f8, 10%);
    transition: background-color .3s ease-in;
}
.table tbody tr th,.table tbody tr td{
    vertical-align: middle;
    white-space:inherit;
}
.table tbody tr td:nth-child(4){
	width: 70%;
}
@keyframes showcopied {
    0% {
        opacity: 0;
        transform: translateX(100%);
    }

    70% {
        opacity: 1;
        transform: translateX(0);
    }

    100% {
        opacity: 0;
    }
}
</style>
<script src="<?= FRONTASSETS; ?>ckeditor/ckeditor.js"></script>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <!--<h2>
                                <a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"> <i
                                        class="fa fa-arrow-left"></i> </a><?=($title) ? $title : ''; ?>
                            </h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>



                <?php if ($this->session->flashdata('success')): ?>
                <div class="alert alert-success  ">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong> Success ! </strong>
                    <?= $this->session->flashdata('success'); ?>
                </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error')): ?>
                <div class="alert alert-danger  ">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>error ! </strong>
                    <?php echo $this->session->flashdata('error'); ?>
                </div>
                <?php endif; ?>

                <?php if (validation_errors()): ?>
                <div class="alert alert-danger  ">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>error ! </strong>
                    <?= validation_errors(); ?>
                </div>
                <?php endif; ?>



                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">

                            <form method="post" action="">
                                <div class="body">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="email">Letter Type : </label>
                                            <select name="letter_type" id="letter_type" class="form-control">
                                                <option value="">Select letter Type</option>
                                                <?php
                                                  $LetterType = getletterType();
                                                    foreach ($LetterType as $Key => $val) {  ?>
                                                <option value="<?=$val->id; ?>"><?=$val->letter_type_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="email">Template Name : </label>
                                            <input type="text" class="form-control"
                                                value="<?= set_value('template_name'); ?>" id="template_name"
                                                placeholder="Eg:- General CEG / Advance CEG....." name="template_name">
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="row">
                                            <?php
                                            foreach ($letterCode as $rOws) {
                                                ?>
                                            <div class="col-md-3">
                                                <label class="email">
                                                    <span
                                                        id="pwd_spn_<?= $rOws->fld_id; ?>"><?= $rOws->slug_str; ?></span>
                                                    <i class="fa fa-copy"
                                                        onclick="copy_password('<?= $rOws->fld_id; ?>')"
                                                        style="cursor:pointer"></i>
                                                </label>
                                            </div>
                                            <?php
                                            }
                                            ?>


                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="email">Letter Content :</label>
                                            <textarea name="letter_desc" id="letter_desc"
                                                class="form-control"><?= set_value('letter_desc'); ?></textarea>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-primary">Add Letter</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="body">
                        <div class="">
                            <table id="table" class="table table-striped table-bordered  table-hover">
                                <thead>
                                    <tr>
                                        <th>Sr.No.</th>
                                        <th>Letter Type</th>
                                        <th>Letter Template</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tfoot class="d-none">
                                    <tr>
                                        <th>Sr.No.</th>
                                        <th>Letter Type</th>
                                        <th>Letter Template</th>
                                        <th>Description</th>
                                        <th>Action</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>


                <!-- Abhishek edit templete  Model-->
                <div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Edit Letter Template</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div>
                                    <div>
                                        <div class="alert alert-success hidden" id="hidden">
                                            <a href="#" class="close" data-dismiss="alert"
                                                aria-label="close">&times;</a>
                                            <strong>Success ! </strong> Letter Type added Successfully .
                                        </div>
                                        <form method="post" action="<?= base_url('update'); ?>">
                                            <div class="form-group">
                                                <label>Letter Type : </label>
                                                <select name="letter_type_id" id="letter_type_id" class="form-control">
                                                    <option value="">Select Letter Type</option>
                                                    <?php
                                            $LetterType = getletterType();
                                            foreach ($LetterType as $Key => $val) { ?>
                                                    <option value="<?=$val->id; ?>"><?=$val->letter_type_name; ?>
                                                    </option>
                                                    <?php  } ?>
                                                </select>
                                            </div class="form-group">
                                            <label>Letter Template Name : </label>

                                            <div class="input-group">
                                                <input type="text" name="tempelte_name" id="tempelte_name"
                                                    class="form-control" value="" ;>
                                            </div>

                                    </div>

                                    <hr>

                                    <div class="form-group">
                                        <div class="col-md-12">
                                            <div class="row">
                                                <?php foreach ($letterCode as $rOws) {
                                                ?> <div class="col-md-4"><span class="fa fa-copy"
                                                        id="copy_text_<?= $rOws->fld_id; ?>" style="cursor:pointer"
                                                        data-copytarget="<?=$rOws->fld_id; ?>"
                                                        onclick="copyText('<?= $rOws->fld_id; ?>')"><?=$rOws->slug_str; ?></span>
                                                </div><?php
                                            }
                                                        ?>
                                            </div>
                                        </div>
                                    </div>

                                    <b>Descriptionssss :</b>
                                    <div class="form-control">
                                        <textarea name="dckeditor" id="dckeditor" class="form-control"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <input type="hidden" value="" id="update_id" name="update_id">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary" value="Update">Update</button>
                                </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script>
        CKEDITOR.replace('letter_desc');
        CKEDITOR.replace('dckeditor');
        CKEDITOR.replace('kk');
        </script>
        <?php /*
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script> */ ?>


        <script type="text/javascript">
        function copycont(fldid) {
            $(document).ready(function() {
                // var copyText = document.getElementById("conts_" + fldid);
                //copyText.select();
                //copyText.setSelectionRange(0, 99999);
                // $("#conts_1" + fldid).select();
                // $("#conts_1").html('PILLI');
                // $("#conts_1").selector();
                alert("dfdfdrgfre" + fldid);
            });
        }

        function addletter() {
            var letter_dec = CKEDITOR.instances['letter_desc'].getData();
            var letter_type = $("#letter_type").val();
            var letter_templte_name = $("#letter_templete").val();
            $.ajax({
                url: "<?=base_url('addLetterformat'); ?>",
                type: "POST",
                data: {
                    letter_dec: letter_dec,
                    letter_type: letter_type,
                    letter_templte_name: letter_templte_name
                },
                dataType: 'json',
                success: function(res) {
                    if (res) {
                        $('#hidden').show()
                    }
                }
            });
        }

        var table;
        $(document).ready(function() {
            $('.hidden').hide();
            var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',
                csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
            // var compid = $('#companynames').val();
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [], //Initial no order.
                "scrollY": '10vh',
                "scrollX": true,
                // Load data for the table's content from an Ajax source
                "ajax": {
                    "url": "<?= base_url('letter_template_ajax_data'); ?>",
                    "type": "POST",
                    "data": function(data) {
                        // data.start_dates = $('#start_dates').val();
                        // data.end_dates = $('#end_dates').val();
                    },
                    data: {
                        [csrfName]: csrfHash
                    },
                },
                "dom": 'lBfrtip',
                "buttons": [{
                    extend: 'collection',
                    text: 'Export',
                    buttons: [
                        'copy',
                        'excel',
                        'csv',
                        'pdf',
                        'print'
                    ]
                }],
                //Set column definition initialisation properties.
                "columnDefs": [{
                    "targets": [0], //first column / numbering column
                    "orderable": false, //set not orderable
                }, ],
                "aLengthMenu": [
                    [10, 25, 50, -1],
                    [10, 25, 50, "All"]
                ],
            });
            // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function() { //button filter event click
                table.ajax.reload(); //just reload table
            });
            $('#btn-reset').click(function() { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload(); //just reload table
            });
        });


        function editpopup(valfield) {
            $.ajax({
                type: 'POST',
                dataType: "text",
                url: "<?=base_url('letter/LetterController/ajax_get_letterTemplete'); ?>",
                data: {
                    'editId': valfield
                },
                method: 'POST',
                dataType: 'json',
                success: function(response) {
                    $('#update_id').val(response.id);
                    $('#letter_type_id').val(response.letter_type_id);
                    $('#tempelte_name').val(response.letter_templete_name);
                    CKEDITOR.instances['dckeditor'].setData(response.description)
                }
            });
        }
        </script>

        <script>
        // document.getElementById("cp_btn").addEventListener("click", copy_password);

        function copy_password(fldid) {
            var copyText = document.getElementById("pwd_spn_" + fldid);
            // var copyText = document.getElementById("copy_text_" + fldid);
            var textArea = document.createElement("textarea");

            textArea.value = copyText.textContent;
            document.body.appendChild(textArea);

            textArea.select();
            textArea.focus(); //SET FOCUS on the TEXTFIELD

            document.execCommand("Copy");
            // added by abhishek 

            copyToClipboard(copyText);
            copyText.classList.add("copied");
            window.getSelection().removeAllRanges();
            setTimeout(function() {
                copyText.classList.remove("copied");
            }, 2500);

            //end


            textArea.remove();

            // alert("Copied the text: " + $("#pwd_spn_" + fldid).html());
        }
        </script>
        <script>
        function copyText(text) {
            document.body.addEventListener('click', copy, true);

            //  alert(text);
            var copy = document.getElementById("copy_text_" + text);
            var textField = document.createElement('textarea');
            console.log(copy);
            textField.value = copy.textContent;
            document.body.appendChild(textField);
            textField.select();
            textField.focus(); //SET FOCUS on the TEXTFIELD
            document.execCommand('copy');
            console.log(copy);
            copyToClipboard(copy);
            copy.classList.add("copied");
            window.getSelection().removeAllRanges();
            setTimeout(function() {
                copy.classList.remove("copied");
            }, 2500);



            textField.remove();
            //console.log('should have copied ' + text);

        }
        // event handler
        function copyToClipboard(e) {
            console.log(e);
            // alert(e);
            // alert('this function was triggered');
            // find target element
            var

                c = e.dataset['copytarget'];
            t = e.dataset.copytarget;

            console.log(t);
            d = "#copy_text_" + c;
            console.log(d);
            inp = (d ? document.querySelector(d) : null);
            // console.log(inp);

            // check if input element exist and if it's selectable
            if (inp && inp.select) {
                // select text
                inp.select();
                try {
                    // copy text
                    document.execCommand('copy');
                    inp.blur();

                    // copied animation
                    inp.classList.add('copied');

                    setTimeout(function() {
                        t.classList.remove('copied');
                    }, 1500);
                } catch (err) {
                    //fallback in case exexCommand doesnt work
                    alert('please press Ctrl/Cmd+C to copy');
                }

            }

        }
        </script>

        <?php $this->load->view('admin/includes/footer'); ?>
</body>