<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Monthly Tour Management</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div> 
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <h5> Filter Data / Records </h5>
                                <form method="post" action="<?= base_url('joining_report_data'); ?>" id="visitingcard_form">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                        <!--<div class="card-header" id="headingOne">-->
                                        <div class="row clearfix">
                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                    <label for="email">Name : </label>
                                                    <input type="text" class="form-control" id="userfullname">
                                                </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                    <label for="email">Email : </label>
                                                    <input type="text" class="form-control" id="emailid">
                                                 </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                    <label for="email">Contact No : </label>
                                                    <input type="number" class="form-control" id="contact_no">
                                                 </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <div class="form-group">
                                                <label for="email">Position : </label>
                                                    <select class="form-control select2" id="empl_position">
                                                        <option value=""> -- Select -- </option>
                                                            <?php 
                                                              if($PositionListArr){ 
                                                                foreach($PositionListArr as $rOws){  ?>
                                                                <option value="<?= $rOws->id; ?>"> <?= $rOws->positionname; ?> - [<?= $rOws->jobtitlename; ?>] </option>
                                                            <?php } } ?>
                                                        </select>
                                                </div>
                                            </div>

                                            <div class="col-lg-3">
                                                    <div class="form-group">
                                                        <label for="email">Status : </label>
                                                        <select class="form-control" id="curr_status">
                                                            <option value=""> -- Select -- </option>
                                                            <option value="1"> Added by CRU </option>
                                                            <option value="2"> Added by HR </option>
                                                            <option value="3"> Locked by HR </option>
                                                            <option value="4"> Offer Letter Send </option>
                                                            <option value="5"> Accept by Employee </option>
                                                            <option value="6"> Filled By Employee </option>
                                                            <option value="7"> Locked By Employee </option>
                                                            <option value="8"> Generate Joining Letter </option>
                                                            <option value="9"> Final Locked & Datamoved </option>
                                                        </select>
                                                    </div>
                                            </div>

                                            <div class="col-lg-3">
                                                    <div class="form-group">
                                                        <label for="email">From Date : </label>
                                                        <input type="date" class="form-control" id="start_dates">
                                                    </div>
                                            </div>

                                            <div class="col-lg-3">
                                                    <div class="form-group">
                                                        <label for="email">End Date : </label>
                                                        <input type="date" class="form-control" id="end_dates">
                                                    </div>
                                            </div>

                                            <div class="col-lg-2">
                                                    <div class="mt-sm-3">
                                                        <button type="button" id="btn-filter" class="btn btn-one" style="margin-top:10px"> Filter </button>
                                                        <button type="reset" class="btn btn-primary btn-xs" style="margin-top:10px;"> Reset </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>                          
                                    </form>
                                
                            </div>
                        </div>


                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="table" class="table table-striped display table-bordered" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>TMP EMPID</th>
                                                <th>Employee Name</th>
                                                <th>Contact No.</th>
                                                <th>Email ID</th>
                                                <th>Position</th>
                                                <th>L Date</th>
                                                <th>Current Status</th>
                                                <th>Action</th>   
                                            </tr>
                                        </thead>

                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>TMP EMPID</th>
                                                <th>Employee Name</th>
                                                <th>Contact No.</th>
                                                <th>Email ID</th>
                                                <th>Position</th>
                                                <th>L Date</th>
                                                <th>Current Status</th>
                                                <th>Action</th>   
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
        
    </div>

    
    <script type="text/javascript">
        var table;
        $(document).ready(function () {
             var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

          //  var compid = $('#companynames').val();
            table = $('#table').DataTable({
                "processing": true,
                "serverSide": true,
                "order": [], //Initial no order.
                // Load data for the table's content from an Ajax source
				"scrollY":'62vh',
             "scrollX": true,
                "ajax": {
                    "url": "<?= base_url('ajax_list_letter'); ?>",
                    "type": "POST",
                    "data": function (data) {
                       data.start_dates = $('#start_dates').val();
                       data.end_dates = $('#end_dates').val();
                       data.curr_status = $('#curr_status').val(); 
                       data.userfullname = $('#userfullname').val();
                       data.emailid = $('#emailid').val(); 
                       data.contact_no = $('#contact_no').val();
                       data.empl_position = $('#empl_position').val();
					   data.<?= $this->security->get_csrf_token_name(); ?> = '<?= $this->security->get_csrf_hash(); ?>';
                    },
                },
                "dom": 'lBfrtip',
                "buttons": [
                    {
                        extend: 'collection',
                        text: 'Export',
                        buttons: [
                            'copy',
                            'excel',
                            'csv',
                            'pdf',
                            'print'
                        ]
                    }
                ],
                //Set column definition initialisation properties.
                "columnDefs": [
                    {
                        "targets": [0], //first column / numbering column
                        "orderable": false, //set not orderable
                    },
                ],
                "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            });
            // var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
            // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
            $('#btn-filter').click(function () { //button filter event click
                table.ajax.reload();  //just reload table
            });
            $('#btn-reset').click(function () { //button reset event click
                $('#form-filter')[0].reset();
                table.ajax.reload();  //just reload table
            });
        });

    </script>
	<?php $this->load->view('admin/includes/footer'); ?>
</body>