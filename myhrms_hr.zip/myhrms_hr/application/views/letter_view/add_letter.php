<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');

?>


<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

          <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-8 col-md-8 col-sm-12">
                            <!-- <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a>Employee Details Management</h2> -->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="fa fa-home"></i></a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ''; ?></li>
                                <li class="breadcrumb-item float-right">
                                    <a href="<?php //base_url('emp_list'); ?>" class="">
                                    <i class="fa fa-users"></i> Prospective Employee List </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a><?=($title) ? $title : ''; ?></h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?=base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?=($title) ? $title : ''; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>


                <?php if ($this->session->flashdata('success_msg')) : ?>
                    <div class="alert alert-success alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Success ! </strong> <?= $this->session->flashdata('success_msg'); ?>
                    </div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('error_msg')) : ?>
                    <div class="alert alert-danger alert-dismissable">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                        <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
                    </div>
                <?php endif; ?>


                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                        
                            <form method="post" action="<?=base_url('addletter'); ?>" id="empform" name="hrmsempform" enctype="multipart/form-data">
                                <!-- Start Professional --> 
                                 <?php 
                                //epd($cvm_interview_record); ?>
                                    <div class="body">
                                        <div class="row clearfix">

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Temp ID : <span style="color:red;">*</span></label>
                                                    <input type="text" readonly id="emp_id"  name="emp_id" value="<?= TEMPID.$temp_id; ?>" class="form-control">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                <label for="email">Letter Type : <span style="color:red;">*</span></label>
                                                <input type="text" readonly value="Offer Letter" class="form-control">
                                                <span id="reqd" class="error_lettertype"><?= form_error('lettertype'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Letter Template : <span style="color:red;">*</span></label>
                                                    <select onclick="rmvalidationerror(this.id)" name="Templete_id"  id="Templete_id" class="form-control select2">
                                                        <option value=''> -- Select Template -- </option>
                                                        <?php
                                                        if ($AllTempleteArr) {
                                                            foreach (@$AllTempleteArr as $key => $reCdd) { ?>
                                                              <option <?= set_select('Templete_id', @$reCdd->id, (!empty($data) && $data == @$reCdd->id ? true : false)); ?>  value="<?= @$reCdd->id; ?>"><?= @$reCdd->letter_templete_name; ?></option>
                                                        <?php } }  ?>
                                                    </Select>
                                                    <span id="reqd" class="error_Templete_id"><?= form_error('Templete_id'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                               
                                                    <label for="email">Letter Code / No. : <span style="color:red;">*</span></label>
                                                    <input onclick="rmvalidationerror(this.id)" type="text" id="lettercode" name="lettercode" value="<?= set_value('lettercode') ? set_value('lettercode') : ''; ?>" class="form-control">
                                                    <span id="reqd" class="error_lettercode"><?= form_error('lettercode'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Letter Subject : <span style="color:red;">*</span></label>
                                                    <input onclick="rmvalidationerror(this.id)" type="text" name="subject" id="subject" value="<?= set_value('subject') ? set_value('subject') : ''; ?>" class="form-control">
                                                    <span id="reqd" class="error_subject"><?= form_error('subject'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Offer Date : <span style="color:red;">*</span></label>
                                                    <input onclick="rmvalidationerror(this.id)" type="date" id="letter_date" name="letter_date" value="<?= set_value('letter_date') ? set_value('letter_date') : ''; ?>" class="form-control date" >
                                                    <span id="reqd" class="error_letter_date"><?= form_error('letter_date'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">                                               
                                                    <label for="email">Bussines Unit : <span style="color:red;">*</span></label>
                                                    <?php 
                                                    $business_unit = get_businessunits();
                                                    //epd($interview_record);
                                                    
                                                    ?>
                                                    <select onclick="rmvalidationerror(this.id)" name="business_unit" id="business_unit" class="form-control select2">
                                                        <option  <?= set_select('business_unit', '', (!empty($data) && $data == '' ? true : false)); ?> value="">-- Select Unit</option>
                                                            <?php 
                                                            if($business_unit){
                                                                foreach ($business_unit as $key => $value) {
                                                                    if(!empty($interview_record->business_unit_id) && ($interview_record->business_unit_id == $value->id)){
                                                                        $selected = 'selected';
                                                                    } else {
                                                                        $selected = '';
                                                                    }
                                                                    echo '<option '.$selected.' value="'.$value->id.'">'.$value->unitname.'</option>';
                                                                }
                                                            }   ?>
                                                    </select>
                                                    <span id="reqd" class="error_business_unit"><?= form_error('business_unit'); ?></span>
                                                </div>
                                            </div>
                                           

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Prefix : <span style="color:red;">*</span></label>
                                                    <select onclick="rmvalidationerror(this.id)" name="prefix" id="prefix"  class="form-control select2">
                                                      <option <?=set_select('prefix', '', (!empty($data) && $data == '' ? true : false)); ?> value="">Select Prefix</option>
                                                        <?php  
                                                            $main_prefix = main_prefix();
                                                            foreach ($main_prefix as $k => $v) { 
                                                                if(!empty($interview_record->prefix) && ($interview_record->prefix == $v->id)){
                                                                    $selected = 'selected';
                                                                } else {
                                                                    $selected = '';
                                                                }
                                                                ?>
                                                                <option <?=$selected?> <?=set_select('prefix', $v->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?=$v->id; ?>"><?= $v->prefix; ?></option>
                                                        <?php } ?>
                                                    </select>
                                                    <span id="reqd" class="error_prefix"><?= form_error('prefix'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">                                                
                                                    <label for="email">First Name : <span style="color:red;">*</span></label>
                                                    <?php 
                                                    if(!empty($cvm_interview_record)){ ?>
                                                        <input type="text" onclick="rmvalidationerror(this.id)" id="name" name="name" value="<?= (!empty($cvm_interview_record->fname)? $cvm_interview_record->fname:'') ?>" class="form-control ">
                                                        <?php 
                                                    } else { ?>
                                                        <input type="text" onclick="rmvalidationerror(this.id)" id="name" name="name" value="<?= (!empty($interview_record->first_name)? $interview_record->first_name:'') ?>" class="form-control ">
                                                        <?php 
                                                    }
                                                    ?>
                                                    
                                                    <span id="reqd" class="error_name"><?= form_error('name'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Middle Name : </label>
                                                    <?php 
                                                    if(!empty($cvm_interview_record)){ ?>
                                                        <input type="text" onclick="rmvalidationerror(this.id)" id="middle_name" name="middle_name" value="<?= (!empty($cvm_interview_record->mname)? $cvm_interview_record->mname:'') ?>" class="form-control ">
                                                        <?php 
                                                    } else { ?>
                                                        <input type="text" onclick="rmvalidationerror(this.id)" id="middle_name" name="middle_name" value="<?= (!empty($interview_record->middle_name)? $interview_record->middle_name:'') ?>" class="form-control ">
                                                        <?php 
                                                    }
                                                    ?>
                                                    <span id="reqd" class="error_name"><?= form_error('middle_name'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Last Name : <span style="color:red;">*</span></label>
                                                    <?php 
                                                    if(!empty($cvm_interview_record)){ ?>
                                                        <input type="text" onclick="rmvalidationerror(this.id)" id="lastname" name="lastname" value="<?= (!empty($cvm_interview_record->lname)? $cvm_interview_record->lname:'') ?>" class="form-control ">
                                                        <?php 
                                                    } else { ?>
                                                        <input type="text" onclick="rmvalidationerror(this.id)" name="lastname" id="lastname" value="<?= (!empty($interview_record->last_name)? $interview_record->last_name:'') ?>" class="form-control ">
                                                        <?php 
                                                    }?>
                                                    <span id="reqd" class="error_lastname"><?= form_error('lastname'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Contact No : <span style="color:red;">*</span></label>
                                                    <?php 
                                                    if(!empty($cvm_interview_record)){ ?>
                                                        <input type="number" onclick="rmvalidationerror(this.id)" id="contact_no" name="contact_no" value="<?= (!empty($cvm_interview_record->phone)? str_replace("+91","",$cvm_interview_record->phone):'') ?>" class="form-control ">
                                                        <?php 
                                                    } else { ?>
                                                        <input onclick="rmvalidationerror(this.id)" type="number" name="contact_no" id="contact_no"value="<?= (!empty($interview_record->contact)? $interview_record->contact:'') ?>" class="form-control">
                                                        <?php 
                                                    } ?>
                                                    <span id="reqd" class="error_contact_no"><?= form_error('contact_no'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Email : <span style="color:red;">*</span></label>
                                                    <?php 
                                                    
                                                    if(!empty($cvm_interview_record)){ ?>
                                                        <input type="text" onclick="rmvalidationerror(this.id)" id="email" name="email" value="<?= (!empty($cvm_interview_record->emailaddress)? $cvm_interview_record->emailaddress:'') ?>" class="form-control ">
                                                        <?php 
                                                    } else {  ?>
                                                        <input onclick="rmvalidationerror(this.id)" type="email" name="email" id="email" class="form-control"value="<?= (!empty($interview_record->email_id)? $interview_record->email_id:'') ?>">
                                                        <?php 
                                                    } ?>
                                                    <span id="reqd" class="error_email"><?= form_error('email'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Address 1 : <span style="color:red;">*</span></label>
                                                    <textarea name="address_one" id="address_one" onclick="rmvalidationerror(this.id)" class="form-control"><?= (!empty($interview_record->address)? $interview_record->address:'') ?></textarea>
                                                    <span id="reqd" class="error_address_one"><?= form_error('address_one'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Address 2 : <span style="color:red;">*</span></label>
                                                    <textarea onclick="rmvalidationerror(this.id)" name="address_two" id="address_two" class="form-control"><?= set_value('address_two') ? set_value('address_two') : ''; ?></textarea>
                                                    <span id="reqd" class="error_address_two"><?= form_error('address_two'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Country : <span style="color:red;">*</span></label>
                                                    <select onclick="rmvalidationerror(this.id)" name="country" id="country"  onchange="getstate()" class="form-control select2">
                                                        <option <?= set_select('country', "", (!empty($data) && $data == '' ? true : false)); ?> value=''> -- Select Country -- </option>
                                                            <?php 
                                                            $country = getcountry();
                                                            foreach ($country as $key => $value) { 
                                                                if(!empty($interview_record->prefix) && ($interview_record->country_id == $value->id)){
                                                                    $selected = 'selected';
                                                                } else {
                                                                    $selected = '';
                                                                }
                                                                ?>
                                                                <option <?=$selected?> <?= set_select('country', $value->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?=$value->id; ?>"> <?=$value->country_name; ?> </option>
                                                            <?php } ?>
                                                    </select>
                                                    <span id="reqd" class="error_country"><?= form_error('country'); ?></span>
                                                </div>
                                            </div>


                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    
                                                    <label for="email">State : <span style="color:red;">*</span></label>
                                                    <select onclick="rmvalidationerror(this.id)" name="state_id" id="state_id"  onchange="getcity_State()" class="form-control select2">
                                                        <option value=''> -- Select -- </option>
                                                        <?php 
                                                        if (set_value('country')) {
                                                            $states = getState_country(set_value('country'));
                                                            foreach ($states as $key => $val) { ?>
                                                                <option value="<?=$val->id; ?>" <?=set_select('state_id', $val->id, (!empty($data) && $data == $val->id ? true : false)); ?>><?= $val->state_name; ?></option>
                                                                <?php 
                                                            } 
                                                        } ?>
                                                    </select>
                                                    <span id="reqd" class="error_state_id"><?= form_error('state_id'); ?></span>
                                                </div>
                                            </div>


                                            <div class="col-md-3">
                                               <div class="form-group">
                                                  <label for="email">City : <span style="color:red;">*</span></label>
                                                  <select onclick="rmvalidationerror(this.id)" name="city" id="city"  class="form-control select2">
                                                    <option value=''> -- Select -- </option>
                                                    <?php 
                                                      if (set_value('city')) {
                                                        $city = getcity_State(set_value('state_id'));
                                                          foreach ($city as $key => $val) { ?>
                                                            <option  value="<?= $val->id; ?>" <?= set_select('city', $val->id, (!empty($data) && $data == $val->id ? true : false)); ?>><?= $val->city_name; ?></option>
                                                    <?php }  } ?>
                                                    </select>
                                                    <span id="reqd" class="error_city"><?= form_error('city'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Pin Code : <span style="color:red;">*</span></label>
                                                    <input onclick="rmvalidationerror(this.id)" maxlength="6" value="<?= (!empty($interview_record->pincode)? $interview_record->pincode:'') ?>" type="text" name="pincode" id="pincode" class="form-control">
                                                    <span id="reqd" class="error_pincode"><?= form_error('pincode'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Position : <span style="color:red;">*</span></label>
                                                    
                                                    <select onclick="rmvalidationerror(this.id)" name="position" id="position" class="form-control select2">
                                                      <option <?=set_select('position', "", (!empty($data) && $data == '' ? true : false)); ?> value=""> -- Select -- </option>
                                                      <?php 
                                                        $position = get_all_positions();
                                                        foreach ($position as $key => $val) {
                                                            if(!empty($val->positionname)){
                                                                if(!empty($interview_record->position) && ($interview_record->position == $val->id)){
                                                                    $selected = 'selected';
                                                                } else {
                                                                    $selected = '';
                                                                } ?>
                                                                <option <?=$selected?> <?=set_select('position', $val->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $val->id; ?>"> <?= $val->positionname; ?></option>
                                                                <?php
                                                            } 
                                                            
                                                       } ?>  
                                                    </select>
                                                    <span id="reqd" class="error_position"><?= form_error('position'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                  <label for="email">Company Name : <span style="color:red;">*</span></label>
                                                  <select onclick="rmvalidationerror(this.id)" name="company_id" id="company_id" class="form-control select2">
                                                    <option <?=set_select('company_id', '', (!empty($data) && $data == '' ? true : false)); ?> value="">-- Select Company --</option>
                                                    <?php
                                                      $companylist = get_companyname();
                                                        foreach ($companylist as $key => $val) { 
                                                            if(!empty($interview_record->company_id) && ($interview_record->company_id == $val->id)){
                                                                $selected = 'selected';
                                                            } else {
                                                                $selected = '';
                                                            }?>
                                                            <option <?=$selected?> <?= set_select('company_id', $val->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?=$val->id; ?>"><?=$val->company_name; ?></option>
                                                    <?php } ?>
                                                   </select>
                                                   <span id="reqd" class="error_company_id"><?= form_error('company_id'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Company Location : <span style="color:red;">*</span></label>
                                                    <select name="cmp_location" onclick="rmvalidationerror(this.id)" id="cmp_location" class="form-control select2">
                                                        <option <?=set_select('cmp_location', '', (!empty($data) && $data == '' ? true : false)); ?> value=''> -- Select Location -- </option>
                                                        <?php 
                                                            $comp_location = get_compancy_location();
                                                            foreach ($comp_location as $key => $va) { 
                                                                if(!empty($interview_record->company_location_id) && ($interview_record->company_location_id == $va->id)){
                                                                    $selected = 'selected';
                                                                } else {
                                                                    $selected = '';
                                                                }?>
                                                                <option <?=$selected?> <?=set_select('cmp_location', $va->id, (!empty($data) && $data == '' ? true : false)); ?> value="<?=$va->id; ?>" ><?= $va->city_name; ?></option>
                                                                <?php 
                                                            } ?>
                                                    </select>
                                                    <span id="reqd" class="error_cmp_location"><?= form_error('cmp_location'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">HR Name : <span style="color:red;">*</span></label>
                                                    <?php  $hr_id = Get_loginemploye_hr_or_not(); ?>
                                                    <select onclick="rmvalidationerror(this.id)" name="hrname"  id="hrname" onchange="fetch_positon()"  class="form-control select2">
                                                        <option value="">-- Select HR --</option>
                                                        <?php 
                                                        $hr = GetAll_Hr();
                                                        foreach ($hr as $key => $val) { ?>
                                                            <option <?= $hr_id->user_id == $val->user_id ? 'Selected' : ''; ?><?=set_select('hrname', $val->user_id, (!empty($data) && $data == '' ? true : false)); ?> value="<?= $val->user_id; ?>"><?= $val->userfullname.' - '.$val->employeeId; ?></option>
                                                            <?php 
                                                        } ?>
                                                    </select>
                                                    <span id="reqd" class="error_hrname"><?= form_error('hrname'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">HR Position : <span style="color:red;">*</span></label>
                                                    <select readonly onclick="rmvalidationerror(this.id)" name="hr_position"  id="hr_position" class="form-control select2">
                                                        <option <?=set_select('hr_position', '', (!empty($data) && $data == '' ? true : false)); ?> value="">-- Select positions --</option>
                                                        <?php 
                                                        $hr_postions = get_all_positions();
                                                        foreach ($hr_postions as $key => $val) { ?> 
                                                            <option <?= $hr_id->position_id == $val->id ? 'Selected' : ''; ?><?= set_select('hr_position', $val->id, (!empty($data) && $data == $val->id ? true : false)); ?> value="<?= @$val->id; ?>"><?= @$val->positionname; ?></option>
                                                            <?php 
                                                        } ?> 
                                                    </select>
                                                    <span id="reqd" class="error_hr_position"><?= form_error('hr_position'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                               <div class="form-group">
                                                    <label for="email">Amount / Salary : <span style="color:red;">*</span></label>
                                                    <?php 
                                                    if(!empty($cvm_interview_record)){ ?>
                                                        <input type="text" onclick="rmvalidationerror(this.id)" id="amount" name="amount" value="<?= (!empty($cvm_interview_record->salary)? $cvm_interview_record->salary:'') ?>" class="form-control ">
                                                        <?php 
                                                    } else { ?>
                                                        <input type="number" onclick="rmvalidationerror(this.id)" id="amount" name="amount" value="<?= set_value('amount') ? set_value('amount') : ''; ?>" class="form-control">
                                                        <?php
                                                    } ?>
                                                    <span id="reqd" class="error_amount"><?= form_error('amount'); ?></span>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="form-group">
                                                    <label class="text-muted"> &nbsp; </label> <br>
                                                    <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                                                    <input class="btn btn-one" type="submit" value="Submit" name="submit" id="submit">
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                            </form>

                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        var state_id = '<?=(($interview_record->state_id)? $interview_record->state_id:'')?>';
        var city_id = '<?=(($interview_record->city_id)? $interview_record->city_id:'')?>';
    //Validation Error Removed..
    function rmvalidationerror(returnarrg) {
        $('.error_' + returnarrg).html("");
    }

    

    function gtetemplete(){
        var lettertype =$('#lettertype').val();
            $.ajax({
                url: "<?=base_url('get_letter_templete'); ?>",
                type: "POST",
                data: {
                    lettertype: lettertype,
                },
                dataType: 'json',
                success: function(res) {
                    $('#Templete_id').html('');
                    $('#Templete_id').trigger("change");
                    $('#Templete_id').append("<option>Select Template</option>");
                    if(res){
                     $.each(res, function(key,val) {
                        $('#Templete_id').append("<option value="+val.id+">"+val.letter_templete_name+"</option>");
                    });
               } else {
                  $('#Templete_id').append("<option>Select Template</option>");
                 }
                }
              });
            }


    // function readURL(input) {
    //     if (input.files && input.files[0]) {
    //         var reader = new FileReader();
    //         reader.onload = function(e) {
    //             $('#blah').removeAttr('src');
    //             $('#blah').attr('src', e.target.result);
    //         }
    //         reader.readAsDataURL(input.files[0]);
    //     }
    // }


    function getstate() {
           var country = $("#country").val();
         
           $('#state_id').html('');
           $('#state_id').val('');
           $('#state_id').trigger("change");

           $("#state_id").select2({
              allowClear: true,
              placeholder: " -- "
            });

            $.ajax({
                url: "<?=base_url('getstate'); ?>",
                type: "POST",
                data: {
                    country:country
                },
                dataType: 'json',
                success: function(res) {
                  $('#state_id').append("<option value=''> -- Select State -- </option>");
                    $.each(res, function(key,val) {
                        if(state_id == val.id){
                            $('#state_id').append("<option selected value="+val.id+">"+val.state_name+"</option>");
                        } else {
                            $('#state_id').append("<option value="+val.id+">"+val.state_name+"</option>");
                        }
                        
                     });
                     $('#state_id').trigger('change');
                }
            });

        }

        function getcity_State(){
            var state = $("#state_id").val();

           $('#city').html('');
           $('#city').val('');
           $('#city').trigger("change");

           $("#city").select2({
              allowClear: true,
              placeholder: " -- "
            });

            $.ajax({
                url: "<?=base_url('getcity'); ?>",
                type: "POST",
                data: {
                    state:state
                },
                dataType: 'json',
                success: function(res) {

                    $('#city').append("<option value=''> -- Select City -- </option>");

                    $.each(res, function(key,val) {
                        if(city_id == val.id){
                            $('#city').append("<option selected value="+val.id+">"+val.city_name+"</option>");
                        } else {
                            $('#city').append("<option value="+val.id+">"+val.city_name+"</option>");
                        }
                     });       
                     $('#city').trigger("change");
                }
            });
        }

        // //editbutton 
        // function mgetstate(){
        //    var country = $("#mcountry").val();
        //     $.ajax({
        //         url: "<?php // base_url('getstate'); ?>",
        //         type: "POST",
        //         data: {
        //             country:country
        //         },
        //         dataType: 'json',
        //         success: function(res) {
        //             $('#state').html('');
        //             $('#city').html('');

        //             $('#city').append("<option value=''> -- Select City -- </option>");
        //             $('#state').append("<option>Select State</option>");

        //             $('#state').trigger("change");
        //             $('#city').trigger("change");

        //             $.each(res, function(key,val) {
        //                 $('#state').append("<option value="+val.id+">"+val.state_name+"</option>");
        //              });
        //         }
        //     });
        // }

        // function mgetcity_State(){
        //     var state = $("#state").val();
        //     $.ajax({
        //         url: "<?php // base_url('getcity'); ?>",
        //         type: "POST",
        //         data: {
        //             state:state
        //         },
        //         dataType: 'json',
        //         success: function(res) {
        //             $('#mcity').html('');
        //             $('#city').trigger("change");
        //             $('#mcity').append("<option>Select City</option>");
        //             $.each(res, function(key,val) {
        //                 $('#mcity').append("<option value="+val.id+">"+val.city_name+"</option>");
        //            }); 
        //         }
        //     });
        // }

        function fetch_positon() {
          var hr_id = $('#hrname').val();
          $.ajax({
                url: "<?=base_url('get_hr_id_position'); ?>",
                type: "POST",
                data: {
                    hr_id:hr_id
                },
                dataType: 'json',
                success: function(res) {
                    $('#hr_position').val(res).change();
                }
            });
        }
        $(document).ready(function(){
            $('#country').trigger('change');
        });

        
    </script>

    <?php $this->load->view('admin/includes/footer'); ?>
</body>