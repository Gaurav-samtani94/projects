<?php $this->load->view('admin/includes/head'); ?>
<div class="vertical-align-wrap">
    <div class="vertical-align-middle auth-main">
        <?php if ($this->session->flashdata('error_msg')): ?>
        <div class="alert alert-danger alert-dismissable">
            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
            <strong>Error ! </strong> <?= $this->session->flashdata('error_msg'); ?>
        </div>
        <?php endif; ?>
        <div class="auth-box w-75">

            <div class="w-75 m-auto form-login">
                <div class=" row">
                    <div class="col-md-6">
                        <img src="https://cegindia.com/assets/images/logo.png" class="w-50 mb-4" />
                        <video loop muted autoplay class="w-100">
                            <source src="https://apps.cegtechno.com/myhrms_hr/assets/images/blog/login-videos.mp4"
                                type="video/mp4">
                        </video>

                    </div>
                    <div class="col-md-6">

                        <form class="form-auth-small" action="<?= base_url('admin/loginchecker'); ?>" method="POST"
                            id="myform1">
                            <?php //form_open(base_url('admin/loginchecker'));?>
                            <h5 class="text-center mt-5 mb-4">Sign Into Your Account</h5>
                            <input type="hidden" name="<?=$this->security->get_csrf_token_name(); ?>"
                                value="<?=$this->security->get_csrf_hash(); ?>">
                            <div class="form-floating mb-4">
                                <input type="text" required class="form-control" name="username" id="signin-email"
                                    value="" placeholder="">

                                <label for="floatingInput">Enter Emp Code</label>
                            </div>
                            <div class="form-floating mb-4">
                                <input type="password" required class="form-control" name="password"
                                    id="signin-password" value="" placeholder="">

                                <label for="floatingPassword">Enter Password</label>
                            </div>
                            <div class="text-center mb-4">
                                <button type="submit" class="btn btn-login" name="submit_login">LOGIN</button>
                            </div>
                            <?php //echo form_close();?>

                        </form>

                    </div>
                </div>


            </div>
        </div>
    </div>
</div>
<?php $this->load->view('admin/includes/footer'); ?>
<script>

</script>