<style>
    .vl {
        border-left: 1px solid green;
        height: 80px;
    }
</style>
<!--Start Section Form All Element Included  -->
<script src="<?= FRONTASSETS; ?>bundles/vendorscripts.bundle.js"></script>
<script src="<?= ASSETSVENDOR; ?>bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
<script src="<?= ASSETSVENDOR; ?>jquery-inputmask/jquery.inputmask.bundle.js"></script>
<script src="<?= ASSETSVENDOR; ?>jquery.maskedinput/jquery.maskedinput.min.js"></script>
<script src="<?= ASSETSVENDOR; ?>multi-select/js/jquery.multi-select.js"></script>
<script src="<?= ASSETSVENDOR; ?>bootstrap-multiselect/bootstrap-multiselect.js"></script>
<script src="<?= ASSETSVENDOR; ?>bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="<?= ASSETSVENDOR; ?>bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
<script src="<?= ASSETSVENDOR; ?>nouislider/nouislider.js"></script>
<script src="<?= ASSETSVENDOR; ?>select2/select2.min.js"></script>
<script src="<?= FRONTASSETS; ?>bundles/mainscripts.bundle.js"></script>
<script src="<?= FRONTASSETS; ?>js/pages/forms/advanced-form-elements.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- Close Section For Data Table  -->
<!-- Start Javascript -->
<script src="<?= ASSETSVENDOR; ?>jquery-datatable/buttons/dataTables.buttons.min.js"></script>
<script src="<?= ASSETSVENDOR; ?>jquery-datatable/buttons/buttons.bootstrap4.min.js"></script>
<script src="<?= ASSETSVENDOR; ?>jquery-datatable/buttons/buttons.colVis.min.js"></script>
<script src="<?= ASSETSVENDOR; ?>jquery-datatable/buttons/buttons.html5.min.js"></script>
<script src="<?= ASSETSVENDOR; ?>jquery-datatable/buttons/buttons.print.min.js"></script>
<script src="<?= ASSETSVENDOR; ?>sweetalert/sweetalert.min.js"></script>
<script src="<?= FRONTASSETS; ?>js/pages/tables/jquery-datatable.js"></script>

<!-- Close Javascript -->
<style>
    #reqd{color:red}
    ul#ui-id-1 {width:100%!important;}
</style>
</body>
</html>