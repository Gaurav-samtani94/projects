<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">

<head>
    <title><?= PROJECTNAME; ?></title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta name="description"
        content="Consulting Engineers Group India (cegindia) is a leading International infrastructure consulting company. It provides services in highways, brides, railways, metro, tunnels ,buildings, water resources & more.">
    <meta name="author" content="CEG india HRMS">
    <link rel="icon" href="https://cegindia.com/public/assets/site//favs/favicon-16x16.png" type="image/x-icon">
    <!-- MAIN CSS -->
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/main.css">
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/inbox.css">
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/chatapp.css">
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/color_skins.css">
    <!-- Start New Section For All Form  -->
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>nestable/jquery-nestable.css">
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>bootstrap-multiselect/bootstrap-multiselect.css">
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>bootstrap-datepicker/css/bootstrap-datepicker3.min.css">
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>bootstrap-colorpicker/css/bootstrap-colorpicker.css" />
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>multi-select/css/multi-select.css">
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>bootstrap-tagsinput/bootstrap-tagsinput.css">
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>select2/select2.css" />
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/main.css">
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/color_skins.css">
    <!-- <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>font-awesome/css/font-awesome.min.css"> -->
    <!-- Close Section For All Form . -->
    <link rel="stylesheet" href="<?=FRONTASSETS;?>customselect/jquery-customselect.css">
    <!-- <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>bootstrap/css/bootstrap.min.css"> -->
    <!-- <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>font-awesome/css/font-awesome.min.css"> -->
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>jquery-datatable/dataTables.bootstrap4.min.css">
    <link rel="stylesheet"
        href="<?= ASSETSVENDOR; ?>jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css">
    <link rel="stylesheet"
        href="<?= ASSETSVENDOR; ?>jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css">
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>sweetalert/sweetalert.css" />
    <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>toastr/toastr.min.css">
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/main.css">
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/color_skins.css">
    <link rel="stylesheet" href="<?=FRONTASSETS;?>css/jquery-ui.css">
    <link rel="stylesheet" href="<?= SLIDER; ?>jquery.simpleTicker.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" href="<?= ASSETSVENDOR; ?>font-awesome/css/font-awesome.min.css"> -->
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/mycss.css">
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>css/responsive.css">
    <link rel="stylesheet" href="<?= FRONTASSETS; ?>tre/css/file-explore.css">

    <style>
    .vertical-align-wrap {
        background-image: url('./public/hrms_background.jpg');
        background-position: center;
        background-size: cover;
        background-repeat: no-repeat;
    }
    </style>
</head>