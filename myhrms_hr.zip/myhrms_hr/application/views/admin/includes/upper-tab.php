<?php
$Gurl = thisurl();
$GurlArr = explode("/", $Gurl);
?>

<div class="row">
    <div class="col-sm-2">
        <div class="media">
            <div class="media-left m-r-15">
                <?php if (@$RecEmplDetails->profileimg) { ?>
                    <img id="blah" height="105" width="100" src="<?= MYHRMSHOSTNAME; ?>public/uploads/profile/<?= @$RecEmplDetails->profileimg; ?>" class="rounded-circle" alt="">
                <?php } else { ?>
                    <img id="blah" height="105" width="100" src="<?= HOSTNAME; ?>public/uploads/profile/user.jpg" class="rounded-circle" alt="">
                <?php } ?>
            </div>
        </div>
    </div>

    <?php if (in_array("employee_edit", $GurlArr) || in_array("employee_add", $GurlArr)) { ?>
        <div class="col-sm-2">
            <div class="media-body">
                <p>&nbsp;</p>
                <span style="color:red" id="uploaderror2"> File Upload Error </span>
                <div class="custom-file">
                    <input type="file" class="custom-file-input btn" name="empprofile_pic" id="inputGroupFile03">
                    <label class="custom-file-label" for="inputGroupFile03">Choose file</label>
                </div>
            </div>
        </div>
    <?php } ?>

    <div class="col-sm-8">
        <div class="row">
            <div class="col-sm-3">
                <div class="form-group">
                    <label for="email">Employee Name : </label> 
                    <p> <span style="color:green"><?= (@$RecEmplDetails->userfullname) ? @$RecEmplDetails->prefix_name . " " . @$RecEmplDetails->userfullname : ""; ?></span> </p>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-group">
                    <label for="email">Employee Id : </label>
                    <p>  <span style="color:green"><?= (@$RecEmplDetails->employeeId) ? @$RecEmplDetails->employeeId : ""; ?></span> </p>
                </div>
            </div>

            <div class="col-sm-3">
                <div class="form-group">
                    <label for="email">Email Id : </label>
                    <p> <span style="color:green"><?= (@$RecEmplDetails->emailaddress) ? @$RecEmplDetails->emailaddress : ""; ?></span> </p>
                </div>
            </div>

            <div class="col-sm-2">
                <div class="form-group">
                    <label for="email">Contact No : </label>
                    <p> <span style="color:green"><?= (@$RecEmplDetails->contactnumber) ? @$RecEmplDetails->contactnumber : ""; ?></span> </p>
                </div>
            </div>
        </div>
    </div>
</div>
<hr>
