<nav class="navbar navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-btn">
            <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
        </div>
        <div class="navbar-brand">
            <a href="<?= base_url(""); ?>">
                <img src="https://cegindia.com/assets/images/logo.png" style="width:80px;" alt="CEG" class="img-responsive logo">
            </a>                
        </div>
        <div class="navbar-right">
            <!-- <form id="navbar-search" class="navbar-form search-form">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                <input value="" class="form-control" placeholder="Search here" type="text" id="search">
                <button type="button" class="btn btn-default"><i class="icon-magnifier"></i></button>
            </form>                 -->
            <div id="navbar-menu">
                <ul class="nav navbar-nav">
                    <div class="user-account m-0">
                        <!-- <li class="float-left">
                            <form id="navbar-search" class="navbar-form search-form mt-0">
                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                <input value="" class="form-control" placeholder="Search here" type="text" id="search">
                                <button type="button" class="btn btn-default"><i class="icon-magnifier"></i></button>
                            </form> 
                        </li> -->
                        <li class="float-left">
                            <div class="dropdown icon text-info mt-0">
                                <a href="javascript:void(0);" class="dropdown-toggle user-name icon-menu logout" data-toggle="dropdown"><i class="fa fa-sign-out" aria-hidden="true"></i></a>
                                <ul class="dropdown-menu dropdown-menu-right account">
                                    <li><a href="../../../myhrms"><i class="icon-user"></i>Employee</a></li>
                                    <li class="divider"></li>
                                    <li><a href="<?= base_url('logout'); ?>" class=""><i class="icon-power"></i>Logout</a></li>
                                </ul>
                            </div>
                        </li>
                    </div>
                </ul>
            </div>
        </div>
    </div>
</nav>