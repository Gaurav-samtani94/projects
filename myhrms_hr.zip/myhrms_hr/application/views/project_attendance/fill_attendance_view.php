<?php
$toDateCond = date("Y-m-d");
$fromDateCond = date('Y-m-d', strtotime($toDateCond . ' -' . ATTOPEN . ' day'));

$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
$noOfMonthDaysInvc = date('t', strtotime($AttendanceStartDate . "-1 month"));

$satbgColor = "#e5e8e8";
$sunbgColor = "#ccd1d1";
$holidayColor = "#ff57224a";
$MonthNameArr = ["1" => 'January', "2" => 'February', "3" => 'March', "4" => 'April', "5" => 'May', "6" => 'June', "7" => 'July', "8" => 'August', "9" => 'September', "10" => 'October', "11" => 'November', "12" => 'December'];

$DisableTab = '';
?>
<style>
#table_length {
    position: absolute;
    margin-left: 100px !important;
}
.table tbody tr td, .table tbody th td {
    vertical-align: middle;
    white-space: normal !important;
	border: .25px dashed #ccc; 
}
div.scrollmenu {
  overflow: auto;
  white-space: nowrap;
}
</style>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Attendance </h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>



                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body scrollmenu">
                                <div class="box-inner">
                                    <h4> <span style="color:green"> Project Name : </span> <?= $projectinfo->project_name; ?></h4>
                                    <form action="<?= base_url("fill_attendance_project/" . $projectinfo->project_numberid); ?>" method="post">
                                        <div class="form-group row">
                                            <div class="col-md-2">
                                                <select class="form-control" name="year_rcd">
                                                    <option <?= ($getyear == '') ? "selected" : ""; ?> value=""> -- Select -- </option>
                                                    <?php for ($i = 2018; $i < date('Y') + 1; $i++) { ?>
                                                        <option <?= ($getyear == $i) ? "selected" : ""; ?> value="<?= $i; ?>"><?= $i; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-md-2">
                                                <select class="form-control" name="month_rcd">
                                                    <?php for ($ij = 1; $ij < 13; $ij++) { ?>
                                                        <option <?= ($getmonth == $ij) ? "selected" : ""; ?> value="<?= $ij; ?>"><?= $MonthNameArr[$ij]; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-md-2">
                                                <input type="hidden" name="attenbdprojectid" value="<?= $projectinfo->project_numberid; ?>">
												<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                                <input type="submit" class="btn btn-primary" name="filterAttend" value="Filter">
                                            </div>

                                            <div class="col-md-3"> </div>
                                            <div class="col-md-2"> 
                                                <a class="btn btn-primary btn-xs" href="<?= base_url("fill_attendance"); ?>"> << Back  </a>
                                            </div>

                                        </div>
                                    </form>

                                    <?php if ($this->session->flashdata('msg')) { ?>
                                        <div class="alert alert-success alert-dismissable" >
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                            <strong><div id="msgs"> Success ! </div></strong> <?= $this->session->flashdata('msg'); ?>
                                        </div>
                                    <?php } ?>
                                    <?php if ($this->session->flashdata('errot_msg')) { ?>
                                        <div class="alert alert-danger alert-dismissable" >
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                            <strong><div id="msgs"> Error ! </div></strong> <?= $this->session->flashdata('errot_msg'); ?>
                                        </div>
                                    <?php } ?>
                                </div>


                                <form action="<?= base_url("attendance_control/addsaveupd_attendance"); ?>" method="post">
								<div id="tableContainer">
									
                                    <table class="table" cellspacing="0" border="1" width="100%">
									
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Empl. Name </th>
                                                <th>Position</th>
                                                <?php for ($i = 1; $i < 16; $i++) { ?>
                                                    <th style="<?= (in_array((int) $i, $Holiday_List)) ? "background:$holidayColor" : ""; ?> <?= (in_array($i, $SatDay_List)) ? "background:$satbgColor" : ""; ?> <?= (in_array($i, $SunDay_List)) ? "background:$sunbgColor" : ""; ?>"> <?= $i; ?></th>
                                                <?php } ?>
                                                <th>Empl. Name </th>
                                                <th>Position</th>
                                                <?php for ($i = 16; $i <= $noOfMonthDaysInvc; $i++) { ?>
                                                    <th style="<?= (in_array((int) $i, $Holiday_List)) ? "background:$holidayColor" : ""; ?> <?= (in_array($i, $SatDay_List)) ? "background:$satbgColor" : ""; ?> <?= (in_array($i, $SunDay_List)) ? "background:$sunbgColor" : ""; ?>"> <?= $i; ?></th>
                                                <?php } ?>
                                                <th>MM</th>
                                            </tr>
                                        </thead>

                                        <tbody class="content">
                                            <?php
                                            if ($DesignCategList) {
                                                $noOfDaysInMonth = $lastdate_month;

                                                foreach ($DesignCategList as $rowC) {
                                                    ?>

                                                    <tr>
                                                        <th style="color:green" colspan="34"><?= $rowC->ktype_name; ?></th>
                                                    </tr>
                                                    <?php
                                                    $AllDesignationList = $DesignationAllList[$rowC->desigcat_id];
                                                    if ($AllDesignationList):
                                                        foreach ($AllDesignationList as $kEyy => $rOws) {
                                                            $record_existAttend = $existAttendRec[$rOws->designation_id];
                                                            if ($rOws->is_intermittent == "1") {
                                                                $TotPresentDays = getuseattendance($rOws->hrms_projid, $rOws->designation_id, $getmonth, $getyear);
                                                            } else {
                                                                $TotPresentDays = gettimesheetdetail($rOws->hrms_projid, $rOws->designation_id, $getmonth, $getyear);
                                                            }
                                                            ?>

                                                            <tr>
                                                                <td><?= $kEyy + 1; ?></td>
                                                                <td>
                                                                    <small>
                                                                        <?php
                                                                        $empFullName = '';
                                                                        if ($rOws->company_id == "74" or $rOws->company_id == null) {
                                                                            if ($rOws->userfullname_repl != "") {
                                                                                $empFullName = $rOws->userfullname_repl . " / ";
                                                                            }
                                                                            $empFullName .= $rOws->prefix_name . " " . $rOws->userfullname;
                                                                            if (($rOws->userfullname == "Tbn") or ( $rOws->userfullname == "")) {
                                                                                $empFullName .= '<span style="color:red; text-transform:uppercase;">' . ucwords("TBN") . '</span>';
                                                                            }
                                                                        }
                                                                        if ($rOws->company_id != "74") {
                                                                            $empFullName = $rOws->emp_name;
                                                                        }
                                                                        if ($rOws->flag_of_repl == "2") {
                                                                            $empFullName = $rOws->emp_name;
                                                                        }
                                                                        echo ($rOws->repl_other_tbl_empl) ? $rOws->repl_other_tbl_empl . " / " : "";
                                                                        echo ($empFullName) ? $empFullName : "<span style='color:red;text-transform:uppercase;'>TBN</span>";
                                                                        ?>
                                                                    </small>
                                                                </td>
                                                                <td><small><?= $rOws->designation_name; ?></small></td>

                                                                <?php
                                                                $disaBled = '';
                                                                for ($i = 1; $i < 16; $i++) {

                                                                   
                                                                    $disaBled = 'disabled'; 
                                                                    $aTtendDate = $getyear . "-" . str_pad($getmonth, 2, "0", STR_PAD_LEFT) . "-" . str_pad($i, 2, "0", STR_PAD_LEFT);
                                                                    if (($fromDateCond <= $aTtendDate) && ($toDateCond >= $aTtendDate)) {
                                                                        $disaBled = ''; 
                                                                    } 
                                                                    ?>
                                                                    <td style="<?= (in_array((int) $i, $Holiday_List)) ? "background:$holidayColor" : ""; ?> <?= (in_array($i, $SatDay_List)) ? "background:$satbgColor" : ""; ?> <?= (in_array($i, $SunDay_List)) ? "background:$sunbgColor" : ""; ?>">
                                                                        <select disabled <?= $disaBled; ?> title="<?= $i; ?>" name="atten_<?= $rOws->designation_id; ?>_<?= $i; ?>">
                                                                            <option <?= ($record_existAttend[$i] == "") ? "selected" : ""; ?> value="">--</option>
                                                                            <option <?= ($record_existAttend[$i] == "p") ? "selected" : ""; ?> value="p">P</option>
                                                                            <option <?= ($record_existAttend[$i] == "a") ? "selected" : ""; ?> value="a">A</option>
                                                                            <option <?= ($record_existAttend[$i] == "l") ? "selected" : ""; ?> value="l">L</option>
                                                                            <option <?= ($record_existAttend[$i] == "hd") ? "selected" : ""; ?> value="hd">HD</option>
                                                                            <option <?= ($record_existAttend[$i] == "v") ? "selected" : ""; ?> value="v">V</option>
                                                                        </select>
                                                                        <span style="color:red; font-size:10px"><?= $i; ?></span>
                                                                    </td>
                                                                <?php } ?>

                                                                <td>
                                                                    <small>
                                                                        <?php
                                                                        $empFullName = '';
                                                                        if ($rOws->company_id == "74" or $rOws->company_id == null) {
                                                                            if ($rOws->userfullname_repl != "") {
                                                                                $empFullName = $rOws->userfullname_repl . " / ";
                                                                            }
                                                                            $empFullName .= $rOws->prefix_name . " " . $rOws->userfullname;
                                                                            if (($rOws->userfullname == "Tbn") or ( $rOws->userfullname == "")) {
                                                                                $empFullName .= '<span style="color:red; text-transform:uppercase;">' . ucwords("TBN") . '</span>';
                                                                            }
                                                                        }
                                                                        if ($rOws->company_id != "74") {
                                                                            $empFullName = $rOws->emp_name;
                                                                        }
                                                                        if ($rOws->flag_of_repl == "2") {
                                                                            $empFullName = $rOws->emp_name;
                                                                        }
                                                                        echo ($rOws->repl_other_tbl_empl) ? $rOws->repl_other_tbl_empl . " / " : "";
                                                                        echo ($empFullName) ? $empFullName : "<span style='color:red;text-transform:uppercase;'>TBN</span>";
                                                                        ?>
                                                                    </small>
                                                                </td>

                                                                <td><small><?= $rOws->designation_name; ?></small></td>

                                                                <?php
                                                                for ($i = 16; $i <= $noOfMonthDaysInvc; $i++) {
                                                                    $disaBled = 'disabled'; 
                                                                    $aTtendDate = $getyear . "-" . str_pad($getmonth, 2, "0", STR_PAD_LEFT) . "-" . str_pad($i, 2, "0", STR_PAD_LEFT);
                                                                    if (($fromDateCond <= $aTtendDate) && ($toDateCond >= $aTtendDate)) {
                                                                        $disaBled = ''; 
                                                                    } 
                                                                    ?>
                                                                    <td style="<?= (in_array((int) $i, $Holiday_List)) ? "background:$holidayColor" : ""; ?> <?= (in_array($i, $SatDay_List)) ? "background:$satbgColor" : ""; ?> <?= (in_array($i, $SunDay_List)) ? "background:$sunbgColor" : ""; ?>">
                                                                         <select disabled <?= $disaBled; ?> title="<?= $i; ?>" name="atten_<?= $rOws->designation_id; ?>_<?= $i; ?>">
                                                                            <option <?= ($record_existAttend[$i] == "") ? "selected" : ""; ?> value="">--</option>
                                                                            <option <?= ($record_existAttend[$i] == "p") ? "selected" : ""; ?> value="p">P</option>
                                                                            <option <?= ($record_existAttend[$i] == "a") ? "selected" : ""; ?> value="a">A</option>
                                                                            <option <?= ($record_existAttend[$i] == "l") ? "selected" : ""; ?> value="l">L</option>
                                                                            <option <?= ($record_existAttend[$i] == "hd") ? "selected" : ""; ?> value="hd">HD</option>
                                                                            <option <?= ($record_existAttend[$i] == "v") ? "selected" : ""; ?> value="v">V</option>
                                                                        </select>
                                                                        <span style="color:red; font-size:10px"><?= $i; ?></span>
                                                                    </td>
                                                                <?php } ?>


                                                                <td>
                                                                    <?php
                                                                    $aTtendanCeCount = '';
                                                                    $decimalplace = 3;
                                                                    if ($rOws->user_identity == "1") {
                                                                        $aTtendanCeCount = ($TotPresentDays->present > 0) ? ($noOfDaysInMonth - $TotPresentDays->leave - $TotPresentDays->absent) : "";
                                                                    } else if ($rOws->user_identity == "2") {
                                                                        $aTtendanCeCount = ($TotPresentDays->present > 0) ? ($noOfDaysInMonth - $TotPresentDays->leave - $TotPresentDays->absent) : "";
                                                                    } else if ($rOws->user_identity == "3") {
                                                                        $aTtendanCeCount = ($TotPresentDays->present > 0) ? $TotPresentDays->present : "";
                                                                    }
                                                                    echo $aTtendanCeCount;
                                                                    ?>

                                                                    <!-- Calculate MM -->
                                                                    <?php
                                                                    if ($rOws->user_identity == "3") {
                                                                        if (($TotPresentDays->present) > 0) {
                                                                            $mmcountscrukey = round(($TotPresentDays->present / $noOfDaysInMonth), $decimalplace);
                                                                        } else {
                                                                            $mmcountscrukey = 0;
                                                                        }
                                                                    } else {
                                                                        if (($TotPresentDays->leave + $TotPresentDays->absent) > 0) {
                                                                            $mmcountscrukey = round((1 - ($TotPresentDays->leave + $TotPresentDays->absent) / $noOfDaysInMonth), $decimalplace);
                                                                            if ($mmcountscrukey < 0) {
                                                                                $mmcountscrukey = 0;
                                                                            }
                                                                        } else {
                                                                            if (($TotPresentDays->present) > 0) {
                                                                                $mmcountscrukey = 1;
                                                                            } else {
                                                                                $mmcountscrukey = 0;
                                                                            }
                                                                        }
                                                                    }
                                                                    echo ($mmcountscrukey) ? "<span style='color:green'> (" . $mmcountscrukey . ") </span>" : "";
                                                                    ?>
                                                                </td>

                                                        <input type="hidden" name="assign_designation_onproj[]" value="<?= $rOws->designation_id; ?>" >
                                                        <input type="hidden" name="emplid_act[]" value="<?= $rOws->user_id; ?>" >
                                                        </tr>
                                                    <?php } endif; ?>
                                                <?php
                                            }
                                        }
                                        ?>
                                        <tr>
                                            <th colspan="37">
                                                <!--<input type="submit" value="Submit" class="btn btn-primary">
                                                <input type="hidden" value="<?= $getmonth; ?>" name="attend_month" >
                                                <input type="hidden" value="<?= $getyear; ?>" name="attend_year" >
                                                <input type="hidden" value="<?= $projectinfo->project_numberid; ?>" name="attend_projid" >-->
                                            </th>
                                        </tr>
                                        </tbody>
                                    </table>
									</div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>
<script>
    $('#right-button').click(function () {
        event.preventDefault();
        $('#content').animate({
            scrollLeft: "+=200px"
        }, "slow");
    });

    $('#left-button').click(function () {
        event.preventDefault();
        $('#content').animate({
            scrollLeft: "-=200px"
        }, "slow");
    });
</script>


<style>
    div.scrollmenu {
        overflow: auto;
        white-space: nowrap;
    }
    div.scrollmenu a {
        display: inline-block;
        color: white;
        text-align: center;
        padding: 14px;
        text-decoration: none;
    }
    div.scrollmenu a:hover {
        background-color: #777;
    }


	
		
	
</style>





