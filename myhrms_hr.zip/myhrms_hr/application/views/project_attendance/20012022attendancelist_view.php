<?php
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>

        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Attendance </h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">

                    <div class="col-lg-12">
                        <div class="card">

                            <div class="body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                        <thead>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Project Name </th> 
                                                <th>Employee Name </th> 
                                                <th>Last Entry </th>
                                                <th>Action</th>                                            
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php
                                            if ($ProjectListRecArr) {
                                                foreach ($ProjectListRecArr as $kEy => $dataRow) {

                                                    if (in_array($dataRow->id, $ProjIDesRecArr)) {
                                                        ?>
                                                        <tr>
                                                            <td><?= $kEy + 1; ?></td>
                                                            <td><?= ($dataRow->project_name) ? $dataRow->project_name : ""; ?></td>                                                       
                                                            <td><?= ($dataRow->userfullname) ? $dataRow->userfullname : ""; ?></td>                                                     
                                                            <td><?= ($dataRow->fill_date) ? date('d-m-Y',strtotime($dataRow->fill_date)) : ""; ?></td>                                                    
                                                            <td> 
                                                                <a href="<?= base_url("fill_attendance_project/" . $dataRow->id); ?>">
                                                                    <i class="fa fa-eye"></i>
                                                                </a>                                                     
                                                            </td>                                                      
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                            } else {
                                                ?>
                                                <tr>
                                                    <td style="color:red" colspan="8"> Record Not Found. </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>

                                        <tfoot>
                                            <tr>
                                                <th>Sr.No.</th>
                                                <th>Project Name </th> 
                                                <th>Employee Name </th> 
                                                <th>Last Entry </th>                                           
                                                <th>Action</th>                                            
                                            </tr>
                                        </tfoot>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <?php $this->load->view('admin/includes/footer'); ?>
    </div>
</body>