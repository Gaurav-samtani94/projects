<?PHP
error_reporting(0);
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php $this->load->view('admin/includes/sidebar'); ?>
        <div id="main-content">
            <div class="container-fluid">
                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Timesheet</h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>
                                <li class="breadcrumb-item">Home</li>
                                <li class="breadcrumb-item active"><?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>

                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <form id="form-filter"> 
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                    <div class="row filter-row"> 
                                        
                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Business Unit : </label>
                                                <select name="unit_name" id="unit_name" class="form-control">
                                                    <option value="">-Select Unit-</option>
                                                    <?php
                                                    if ($unit_arr):
                                                        foreach ($unit_arr as $unit_row) {
                                                            ?>
                                                            <option value="<?= $unit_row->id ?>"><?= $unit_row->unitname ?></option>
                                                        <?php } endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">Start Date : </label>
                                                <input  type="text" value="" id="start_date" autocomplete="off" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-3">
                                            <div class="deptinfo" id="deptinfo" style="margin-bottom:15px;">
                                                <label class="email">End Date : </label>
                                                <input type="text" value="" id="end_date" autocomplete="off" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <div class="col-sm-3">
										<div class="mt-sm-3">
                                            <button  type="button" id="btn-filter" class="btn btn-one"> Filter </button>
                                        
                                            <button type="button"  id="btn-reset" class="btn btn-success"> Reset </button>
											</div>
                                        </div>
                                    </div>
                                </form>
                            </div> 
                        </div> 
                    </div> 
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="body">
                                <div class="table-responsive">
                                    <table id="tabledata" class="table table-bordered table-striped table-hover display" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp Code</th>
                                                <th>Emp Name</th>
                                                <th>Department</th>
                                                <th>Designation</th>
                                                <th>D.O.J</th>
                                                <th>Total Hour</th>
                                                <th>Total Leave</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot class="d-none">
                                            <tr>
                                                <th>Sr. No</th>
                                                <th>Emp Code</th>
                                                <th>Emp Name</th>
                                                <th>Department</th>
                                                <th>Designation</th>
                                                <th>D.O.J</th>
                                                <th>Total Hour</th>
                                                <th>Total Leave</th>
                                                <th>Status</th>
                                            </tr>
                                        </tfoot>
                                    </table>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

            <style>
                #table_length{margin-left:20px;}
                #table_filter{margin-right:2%;}
                .selectpicker  {background-color: #ffff;}
                .ui-datepicker-calendar {
                    display: none;
                }
            </style>

            <script type="text/javascript">
                $(function () {
                    $("#start_date").datepicker({
                        dateFormat: 'MM yy',
                        changeMonth: true,
                        changeYear: true,
                        showButtonPanel: true,
                        onClose: function (dateText, inst) {
                            var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
                            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
                            $(this).datepicker('setDate', new Date(year, month, 1));
                        }
                    });
                });
                $(function () {
                    $("#end_date").datepicker({
                        dateFormat: 'MM yy',
                        changeMonth: true,
                        changeYear: true,
                        showButtonPanel: true,
                        onClose: function (dateText, inst) {
                            var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
                            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
                            $(this).datepicker('setDate', new Date(year, month, 1));
                        }
                    });
                });

                var table;
                $(document).ready(function () {
                     var unit_name = $('#unit_name').val();
                     //alert(unit_name);
                     var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';
                   
    table = $('#tabledata').DataTable({
                        "processing": true,
                        "serverSide": true,
                        "order": [], //Initial no order.
						"scrollY":'62vh',
             "scrollX": true,
                        "ajax": {
                            "url": "<?= base_url('Timesheet_Controller/ajax_list_attentimesheet') ?>",
                            "type": "POST",
                            "data": function (data) {
                                data.unit_name = $('#unit_name').val();
                                data.start_date = $('#start_date').val();
                                data.end_date = $('#end_date').val();
                                data.<?php echo $this->security->get_csrf_token_name(); ?> = "<?php echo $this->security->get_csrf_hash(); ?>";
                            }
                            //data:{[csrfName]: csrfHash, 'unit_name':unit_name}, 

                        },
                        "dom": 'lBfrtip',
                        "buttons": [
                            {
                                extend: 'collection',
                                text: 'Export',
                                buttons: ['copy', 'excel', 'csv', 'pdf', 'print']
                            }
                        ],
                        "columnDefs": [{"targets": [0], "orderable": false, }, ],
                        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    });

//                    var colvis = new $.fn.dataTable.ColVis(table);
//                    $('#colvis').html(colvis.button());
                    $('#btn-filter').click(function () {
                        table.ajax.reload();
                    });
                    $('#btn-reset').click(function () {
                        $('#form-filter')[0].reset();
                        table.ajax.reload();
                    });

                });
            </script>
        </div>
    </div>
</body>
<?php $this->load->view('admin/includes/footer'); ?>
