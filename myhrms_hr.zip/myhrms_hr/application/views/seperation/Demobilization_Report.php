<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">

                <div class="block-header stepper">
                    <div class="row">
                        <div class="col-lg-5 col-md-8 col-sm-12">                        
                            <!--<h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?> </h2>-->
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>                            
                                <li class="breadcrumb-item active">Home / <?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 left-box">
                        <div class="card single_post">
                            <div class="body">  

                                <form id="form-filter" class="form-horizontal">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                                <div class="row filter-row">

                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12"> 
                                        <div class="form-group">
                                            <label for="control-label">Business Unit</label>
                                            <select id="businessunit_name" class="form-control"> 
                                                <option value="">All Business Unit</option>
                                                <?php foreach ($form_businessunit as $unit) { ?>
                                                    <option value="<?= $unit->id; ?>"><?= $unit->unitname; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12"> 
                                        <div class="form-group">
                                            <label for="control-label">Company Name</label>
                                            <select id="company_name" class="form-control custom-select"> 
                                                <option value="">-Select Company-</option>
                                                <?php foreach ($companyname as $company) { ?>
                                                    <option value="<?= $company->id; ?>"><?= $company->company_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>  

                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">  
                                        <div class="form-group">
                                            <label for="control-label">Employee Name</label>
                                            <input type="text" id="userfullname" class="form-control" />
                                        </div>
                                    </div> 

                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">  
                                        <div class="form-group">
                                            <label for="control-label">Employee ID</label>
                                            <input type="text" id="employeeId" class="form-control" />
                                        </div>
                                    </div>

                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12"> 
                                        <div class="form-group">
                                            <label for="control-label">Designation</label>
                                            <select id="designation_name" class="form-control custom-select"> 
                                                <option value="">-Select Designation-</option>
                                                <?php foreach ($position as $designation) { ?>
                                                    <option value="<?= $designation->id; ?>"><?= $designation->positionname; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div> 

                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12"> 
                                        <div class="form-group">
                                            <label for="control-label">Department</label>
                                            <select id="department_name" class="form-control custom-select"> 
                                                <option value="">-Select Department-</option>
                                                <?php foreach ($departmentname as $dept) { ?>
                                                    <option value="<?= $dept->id; ?>"><?= $dept->deptname; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div> 

                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12"> 
                                        <div class="form-group">
                                            <label for="control-label">Location/Project Name</label>
                                            <?php $proj = get_all_active_project(); ?>
                                            <select id="project_name" class="form-control custom-select"> 
                                                <option value="">-Select Project-</option>
                                                <?php foreach ($proj as $rrrow) { ?>
                                                    <option value="<?= $rrrow->id; ?>"><?= $rrrow->project_name; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>     


                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">  
									<div class="mt-md-3 pt-md-2">	
                                        <button type="button" id="btn-filter" class="btn btn-one"> Search </button>   
                                   
                                        <button type="button" id="btn-reset" class="btn btn-success"> Reset </button>   
                                    </div>     
                                    </div>     

                                </div>
                                </form>
                                <br>
                                <br>
                                <div class="panel panel-default">
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <?php if ($this->session->flashdata('error')): ?>
                                                <div class="alert alert-danger alert-dismissible fade in">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                    <strong>Success ! </strong> <?php echo $this->session->flashdata('error'); ?>
                                                </div>
                                            <?php endif; ?> 
                                            <?php if ($this->session->flashdata('success')): ?>
                                                <div class="alert alert-info alert-dismissible fade in">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                    <strong>Success ! </strong> <?php echo $this->session->flashdata('success'); ?>
                                                </div>
                                            <?php endif; ?> 
                                        </div>
                                    </div>
                                    <div class="panel-body">

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div id="colvis"></div>
                                            </div>
                                        </div>	

                                        <div class="table-responsive">
                                            <table id="table" class="table table-striped display">
                                                <thead>
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Early Relieving</th>
                                                        <th>Late Relieving</th>
                                                        <th>Notice Period</th>
                                                        <th>Last Working</th>
                                                        <th>Actual Working</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot class="d-none">
                                                    <tr>
                                                        <th>S No.</th>
                                                        <th>Employee ID</th>
                                                        <th>Employee Name</th>
                                                        <th>Designation</th>
                                                        <th>Department</th>
                                                        <th>Early Relieving</th>
                                                        <th>Late Relieving</th>
                                                        <th>Notice Period</th>
                                                        <th>Last Working</th>
                                                        <th>Actual Working</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>       



                            </div>    </div>
                    </div>    

                </div>
            </div>    
		
		
        </div>

		
		<div id="add_demobilization" class="modal fade" role="dialog" >
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Add Demobilization</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
							<div class="col-md-2">
                                    <a href="#"><img class="avatar rounded-circle" src="" alt=""></a>
                            </div>
							<div class="col-md-2"></div>
							<div class="col-md-8">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Employee Name :</label>
                                            <input type="text" disabled="disabled" class="form-control user-name" value="">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Position:</label>
                                            <input type="text" disabled="disabled" class="form-control position-name" value="">
                                        </div>
                                    </div>
                                </div>
								<div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Employee ID :</label>
                                            <input type="text" disabled="disabled" class="form-control emp_id" value="">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Phone:</label>
                                            <input type="text" disabled="disabled" class="form-control phone" value="">
                                        </div>
                                    </div>
                                </div>
								<div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Email :</label>
                                            <input type="text" disabled="disabled" class="form-control email" value="">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">DOJ :</label>
                                            <input type="text" disabled="disabled" class="form-control birthday" value="">
                                        </div> 
                                    </div>
                                </div>
								
								<div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">IO :</label>
                                            <input type="text" disabled="disabled" class="form-control ro" value="">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Department :</label>
                                            <input type="text" disabled="disabled" class="form-control dept" value="">
                                        </div> 
                                    </div>
                                </div>
							</div>
						</div>
						<br>
						<div class="row">
							<div class="col-md-12">    
                                <h4 class="page_title">Extension of Demobilization:</h4><hr/>  
                            </div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
                                    <label class="control-label">Extension for Demobilization<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="extension_for_demobilization" id="extension_for_demobilization" value="" required="required"/>
                                </div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
                                    <label class="control-label">Reason for Extension<span class="text-danger">*</span></label>
                                    <textarea class="form-control" name="reason_for_extension" id="reason_for_extension" value="" required="required"/></textarea>
                                </div>
							</div>
							<div class="col-md-4">  
                                <div class="form-group">
                                    <label class="control-label">Date of Extension <span class="text-danger">*</span></label>
                                    <div class="cal-icon">
										<input type="text" name="date_of_extension" id="date_of_extension" value="" class="form-control" required="required"/>
									</div>
                                </div>
                            </div>
							<div class="col-md-4">  
                                <div class="form-group">
                                    <label class="control-label">Extension Upto <span class="text-danger">*</span></label>
                                    <div class="cal-icon">
										<input type="text" name="extension_upto" id="extension_upto" value="" class="form-control" required="required"/>
									</div>
                                </div>
                            </div> 
                            <div class="col-md-4" id="approval-received">
                                <div class="form-group">
                                    <label class="control-label">Special Comment<span class="text-danger">*</span></label>
                                    <textarea class="form-control" name="special_comment" id="special_comment" value="" required="required"/></textarea>
                                </div>
                            </div>
						</div>
						
						
						<br/>   
                        <div class="row">
                            <div class="col-md-12">    
                                <h4 class="page_title">Cancellation of Demobilization:</h4>   
                            </div>
                            <br/>     
                            <div class="col-md-4">  
                                <div class="form-group">
                                    <label class="control-label">Cancellation Date <span class="text-danger">*</span></label>
                                    <div class="cal-icon">
										<input type="text" name="cancellation_date" id="cancellation_date" value="" class="form-control" required="required"/>
									</div>
                                </div>
                            </div> 

                            <div class="col-md-4" id="approval-received">
                                <div class="form-group">
                                    <label class="control-label">Reason for Cancellation<span class="text-danger">*</span></label>
                                    <textarea class="form-control" name="reason_for_cancellation" id="reason_for_cancellation" value="" required="required"/></textarea>
                                </div>
                            </div>
                        </div> 
                        <br/>
						
                        <div class="row">
                            <div class="col-md-12">    
                                <h4 class="page_title">F&F Process (On Last Working Day):</h4>   
                            </div>
                            <br/>     
                            <div class="col-md-4">  
                                <div class="form-group">
                                    <label class="control-label">F&F Processing Date <span class="text-danger">*</span></label>
                                    <div class="cal-icon"><input type="text" name="ff_processing_date" id="ff_processing_date" value="" class="form-control" required="required"/></div>
                                </div>
                            </div> 

                            <div class="col-md-4">  
                                <div class="form-group">
                                    <label class="control-label">Actual Last Working Day <span class="text-danger">*</span></label>
                                    <div class="cal-icon"><input type="text" name="actual_last_working_date" id="actual_last_working_date" value="" class="form-control" required="required"/></div>
                                </div>
                            </div>
							
							<div class="col-md-4" id="approval-received">
                                <div class="form-group">
                                    <label class="control-label">F & F Amount<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="ff_amount" id="ff_amount" value="" required="required"/>
                                </div>
                            </div>     

                            <div class="col-md-4" id="approval-received">
                                <div class="form-group">
                                    <label class="control-label">Cheque No.<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="cheque_no" id="cheque_no" value="" required="required"/>
                                </div>
                            </div>      

                            <div class="col-md-4" id="approval-received">
                                <div class="form-group">
                                    <label class="control-label">Bank Name<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="bank_name" id="bank_name" value="" required="required"/>
                                </div>
                            </div>
						</div>
						
						<br/>
                        <div class="row">
                            <div class="col-md-12">    
                                <h4 class="page_title">Experience Certificate:</h4>   
                            </div>
                            <br/>
                            <div class="col-md-4">  
                                <div class="form-group">
                                    <label class="control-label">Experience Certificate Issued Date <span class="text-danger">*</span></label>
                                    <div class="cal-icon"><input type="text" name="exp_certificate_issue_date" id="exp_certificate_issue_date" value="" class="form-control" required="required"/></div>
                                </div>
                            </div>   

                            <div class="col-md-4">  
                                <div class="form-group">
                                    <label class="control-label">Cheque Clearing Date <span class="text-danger">*</span></label>
                                    <div class="cal-icon"><input type="text" name="cheque_clearing_date" id="cheque_clearing_date" value="" class="form-control" required="required"/></div>
                                </div>
                            </div> 
							
							<div class="col-md-4">
                                <div class="form-group">
                                    <label class="control-label">Eligible for Rehire<span class="text-danger">*</span></label>
                                    <select id="eligible_for_rehire" name="eligible_for_rehire" class="form-control" autocomplete="off" required="required">
                                        <option value="">-Select Eligible-</option>
                                        <option value="1">Yes</option>
                                        <option value="2">No</option>
                                    </select>
                                </div>
                            </div>
						</div>
						
						<div class="row">
							<div class="col-sm-4">
								<input type="hidden" value="" name="type_id" id="type_id">
								<input type="hidden" value="" name="id" id="ids">
								<input type="submit" required class="btn btn-primary" value="submit">
							</div>
						</div>
                    </div>
                </div>
            </div>
		</div>
		</div>
                <style>
                    #table_length{margin-left:20px;}
                    #table_filter{margin-right:2%;}
                </style>
                <script src="<?= FRONTASSETS; ?>jquery.min.js"></script>
                <script type="text/javascript">
                    var table;
                    $(document).ready(function () {
                        var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                        table = $('#table').DataTable({
                            "processing": true, //Feature control the processing indicator.
                            "serverSide": true, //Feature control DataTables' server-side processing mode.
                            "order": [],
							"scrollY":'62vh',
             "scrollX": true,
                            "ajax": {
                                "url": "<?= base_url('ajax_demobilization_list') ?>",
                                "type": "POST",
                                "data": function (data) {
									console.log(data);
                                    data.businessunit_name = $('#businessunit_name').val();
                                    data.company_name = $('#company_name').val();
                                    data.userfullname = $('#userfullname').val();
                                    data.employeeId = $('#employeeId').val();
                                    data.designation_name = $('#designation_name').val();
                                    data.department_name = $('#department_name').val();
                                    data.project_name = $('#project_name').val();

                                },
                                        data:{[csrfName]: csrfHash}, 


                            },
                            "dom": 'lBfrtip',
                            "buttons": [{
                                    extend: 'collection',
                                    text: 'Export',
                                    buttons: [
                                        'copy',
                                        'excel',
                                        'csv',
                                        'pdf',
                                        'print'
                                    ]
                                }
                            ],
                            //Set column definition initialisation properties.
                            "columnDefs": [{
                                    "targets": [0], //first column / numbering column
                                    "orderable": false, //set not orderable
                                },
                            ],
                            "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                        });
                        //var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                       // $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                        $('#btn-filter').click(function () { //button filter event click
                            table.ajax.reload();  //just reload table
                        });
                        $('#btn-reset').click(function () { //button reset event click
                            $('#form-filter')[0].reset();
                            table.ajax.reload();  //just reload table
                        });
                    });
                </script>

                <script>
                    function myFunction(id) {
						//alert(id);
                        $.ajax({
                            type: 'POST',
                            url: '<?= base_url('seperation/Seperation_Controller/getDataByresignationid/'); ?>',
                            data: {'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>', 'id': id},
                            success: function (res) {
								console.log(res);
                                var result = JSON.parse(res);
								//console.log(result);
                                $('#ids').val(result.user_id);
                                $('#type_id').val(result.type_of_seperation);
                                if (result.profileimg) {
                                    $('.avatar').attr('src', '<?= HOSTNAME; ?>/public/uploads/profile/' + result.profileimg);
                                } else {
                                    $('.avatar').attr('src', '<?= HOSTNAME; ?>/assets/img/user.jpg');
                                }
                                $('.user-name').val(result.userfullname);
                                $('.position-name').val(result.position_name);
                                $('.emp_id').val(result.employeeId);
                                $('.phone').val(result.contactnumber);
                                $('.email').val(result.emailaddress);
                                $('.birthday').val(result.date_of_joining);
                                $('.ro').val(result.reporting_manager_name);
                                $('.dept').val(result.department_name);
                                $('#notice_period').val(result.noticeperiod);
                                $('#type_seperation').val(result.type_of_seperation);
                                $('#demobilization_first').val(result.demobilization);
                                $('#early_relieving').val(result.early_relieving);
                                $('#late_relieving').val(result.late_relieving);
                                $('#notice_period').val(result.notice_period);
                                $('#last_working_day').val(result.last_working_date);
                                $('#actual_last_working_date').val(result.actual_last_working_date);

                            },
                                data:{[csrfName]: csrfHash}, 


                        });

                    }
                </script>

                <script>
                    $(document).ready(function () {
                        $('.summernote').summernote({
                            height: 200, // set editor height
                            minHeight: null, // set minimum height of editor
                            maxHeight: null, // set maximum height of editor
                            focus: false                 // set focus to editable area after initializing summernote
                        });
                    });
                </script>
                <script>
                    $('#cheque_clearing_date').datepicker();
                    $('#exp_certificate_issue_date').datepicker();
                    $('#actual_last_working_date').datepicker();
                    $('#ff_processing_date').datepicker();
                    $('#date_of_extension').datepicker();
                    $('#extension_upto').datepicker();
                    $('#cancellation_date').datepicker();
                </script>
                <script type="text/javascript">
                    $(function () {
                        $("#project_name,#company_name,#designation_name, #department_name").customselect();
                    });
                </script>
                <style>
                    .custom-select{width:100%!important;padding: 0!important;}
                    .custom-select input{width:100%!important;}
                </style>
                </body>
                </html>
				
				<style>
                /* Extra small devices (phones, 600px and down) */
                @media only screen and (max-width: 600px) {
                    .modal-dialog {
                        max-width: 1200px!important;
                    }
                }

                /* Small devices (portrait tablets and large phones, 600px and up) */
                @media only screen and (min-width: 600px) {
                    .modal-dialog {
                        max-width: 1200px!important;
                    }
                }

                /* Medium devices (landscape tablets, 768px and up) */
                @media only screen and (min-width: 768px) {
                    .modal-dialog {
                        max-width: 1200px!important;
                    }
                }

                /* Large devices (laptops/desktops, 992px and up) */
                @media only screen and (min-width: 992px) {
                    .modal-dialog {
                        max-width: 1200px!important;
                    }
                }

                /* Extra large devices (large laptops and desktops, 1200px and up) */
                @media only screen and (min-width: 1200px) {
                    .modal-dialog {
                        max-width: 1200px!important;
                    }
                } 
            </style>
<?php $this->load->view('admin/includes/footer'); ?>
				