<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
$this->load->view('admin/includes/head');
$this->load->view('admin/includes/header');
?>
<link rel="stylesheet" href="../assets/vendor/summernote/dist/summernote.css"/>

<body class="theme-cyan">
    <div id="wrapper">
        <?php
        $this->load->view('admin/includes/sidebar');
        ?>
        <div id="main-content">
            <div class="container-fluid">
                <br/><br/><br/>
                <div class="block-header">
                    <div class="row">
                        <div class="col-lg-9 col-md-8 col-sm-12">                        
                            <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> <?= ($title) ? $title : ""; ?> </h2>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?= base_url(); ?>"><i class="icon-home"></i></a></li>                            
                                <li class="breadcrumb-item active">Home / <?= ($title) ? $title : ""; ?></li>
                            </ul>
                        </div>
                        <?php if (!$numRows) { ?>
                            <div class="col-lg-3 col-md-8 col-sm-12">
                                <button type="button" class="btn btn-success rounded pull-right" data-toggle="modal" data-target="#add_initaiate_status"><i class="fa fa-plus"></i> Add Initiate Status</button>
                            </div>
                        <?php } ?>
                    </div>
                </div>

                <div class="row clearfix">
                    <div class="col-lg-12 col-md-12 left-box">
                        <div class="card single_post">
                            <div class="body">  
                                <?php if ($numRows) { ?>
                                    <div class="panel panel-default">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <?php if ($this->session->flashdata('success')): ?>
                                                    <div class="alert alert-info alert-dismissible fade in">
                                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                        <strong>Success ! </strong> <?php echo $this->session->flashdata('success'); ?>
                                                    </div>
                                                <?php endif; ?> 
                                                <?php if ($this->session->flashdata('error')): ?>
                                                    <div class="alert alert-danger alert-dismissible fade in">
                                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                        <strong>Error ! </strong> <?php echo $this->session->flashdata('error'); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="panel-body">   
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div id="ColVis"></div>
                                                </div>
                                            </div>	
                                            <div class="table-responsive">
                                                <table id="table" class="table table-striped display">
                                                    <thead>
                                                        <tr>
                                                            <th>S No.</th>
                                                            <th>Emp ID</th>
                                                            <th>Emp Name</th>
                                                            <th>Designation</th>
                                                            <th>Department</th>
                                                            <!--<th>Resign Type</th>-->
                                                            <th>Notice Period</th>
                                                            <th>Resign Date</th>
                                                            <th>Last Working date</th>
                                                            <th>IO Approval</th>
                                                            <th>HR Approval</th>
                                                            <th>RO Approval</th>
                                                            <!--<th>Action</th>-->
                                                        </tr>
                                                    </thead>
                                                    <tfoot>
                                                        <tr>
                                                            <th>S No.</th>
                                                            <th>Emp ID</th>
                                                            <th>Emp Name</th>
                                                            <th>Designation</th>
                                                            <th>Department</th>
                                                            <!--<th>Resign Type</th>-->
                                                            <th>Notice Period</th>
                                                            <th>Resign Date</th>
                                                            <th>Last Working date</th>
                                                            <th>IO Approval</th>
                                                            <th>HR Approval</th>
                                                            <th>RO Approval</th>
                                                            <!--<th>Action</th>-->
                                                        </tr>
                                                    </tfoot>
                                                    <tbody>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>       
                                <?php } ?>

                            </div>    
                        </div>
                    </div>    

                </div>
            </div>    
            <?php $this->load->view('admin/includes/footer'); ?>
        </div>


        <div id="add_initaiate_status" class="modal fade" role="dialog" >
            <div class="modal-dialog">

                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Exit Procedure Details</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-2">
                                <?php $file_exist = 'http://localhost/myhrms/public/uploads/profile'.$row_detail['profileimg'] ?>
                                <?php if ($file_exist) { ?>
                                    <a href="#"><img class="rounded-circle" src="<?= HOSTNAME; ?>/public/uploads/profile/<?= $row_detail['profileimg']; ?>" alt=""></a>
                                <?php } else { ?>
                                    <a href="#"><img class="rounded-circle" src="<?= HOSTNAME; ?>/assets/img/user.jpg" alt=""></a>
                                <?php } ?> 
                            </div>
                            <div class="col-md-2"></div>
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Employee Name :</label>
                                            <input type="text" disabled="disabled" class="form-control" value="<?= $row_detail['userfullname']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Position:</label>
                                            <input type="text" disabled="disabled" class="form-control" value="<?= $row_detail['position_name']; ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Employee ID :</label>
                                            <input type="text" disabled="disabled" class="form-control" value="<?= $row_detail['employeeId']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Phone:</label>
                                            <input type="text" disabled="disabled" class="form-control" value="<?= $row_detail['contactnumber']; ?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Email :</label>
                                            <input type="text" disabled="disabled" class="form-control" value="<?= $row_detail['emailaddress']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">DOJ :</label>
                                            <input type="text" disabled="disabled" class="form-control" value="<?= date("d-m-Y", strtotime($row_detail['date_of_joining'])); ?>">
                                        </div> 
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">IO :</label>
                                            <input type="text" disabled="disabled" class="form-control" value="<?= $row_detail['reporting_manager_name']; ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label class="label-control">Notice Period :</label>
                                            <input type="text" disabled="disabled" class="form-control" value="<?= $row_detail['noticeperiod']; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?= form_open(base_url('add_employee_check_status'), array('method' => 'post')); ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="control-label">Exit Type<span class="text-danger">*</span></label>
                                    <select id="exit_type" name="exit_type" class="form-control" required="required">
                                        <option value="">Select Exit Type</option>
                                        <?php if (@$exit_type): ?>
                                            <?php foreach ($exit_type as $exit): ?>
                                                <?php $role = $this->session->userdata('emprole'); ?>
                                                <?php if (($exit->id == '1')) { ?>
                                                    <option value="<?= $exit->id; ?>"><?= $exit->exit_type; ?></option>
                                                <?php } ?>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm-8">
                                <div class="form-group">
                                    <label class="control-label">Reason<span class="text-danger">*</span></label>
                                    <textarea class="form-control summernote" name="each_of_comment" id="each_of_comment" required="required" row="4" col="10"/></textarea>
									
									
									
									
                                </div>
                            </div> 
                            <?php if ($row_detail['on_project']) { ?>  
                                <div class="col-sm-4">
                                    <div class="form-group">
                                        <label class="control-label">On Project<span class="text-danger">*</span></label>
                                        <select required="required" class="form-control" id="exit_project_id" name="exit_project_id">
                                            <option>-Select-</option>
                                            <?php $project_id = explode(',', $row_detail['on_project']); ?>
                                            <?php $project_name = get_project_name_exit($project_id); ?>
                                            <?php foreach ($project_name as $rrow) { ?>
                                                <option value="<?= $rrow->id; ?>"><?= $rrow->project_name; ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <input type="submit" class="btn btn-primary" value="Initiate">
                            </div>
                        </div>
                        <?= form_close(); ?>  
                    </div>
                </div>
            </div>




            <style>
                #table_length{margin-left:20px;}
                #table_filter{margin-right:2%;}
            </style>
            <script>
                $(document).ready(function () {
                    $('.summernote').summernote({
                        height: 200, // set editor height
                        minHeight: null, // set minimum height of editor
                        maxHeight: null, // set maximum height of editor
                        focus: false                 // set focus to editable area after initializing summernote
                    });
                });
            </script>
            <script type="text/javascript">
                var table;
                $(document).ready(function () {
                     var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>',  csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

                    table = $('#table').DataTable({
                        "processing": true, //Feature control the processing indicator.
                        "serverSide": true, //Feature control DataTables' server-side processing mode.
                        "order": [],
                        "ajax": {
                            "url": "<?= base_url('ajax_exit_process_list') ?>",
                            "type": "POST",
                            "data": function (data) {
                            },
                            data:{[csrfName]: csrfHash}, 

                        },
                        "dom": 'lBfrtip',
                        "buttons": [{
                                extend: 'collection',
                                text: 'Export',
                                buttons: [
                                    'copy',
                                    'excel',
                                    'csv',
                                    'pdf',
                                    'print'
                                ]
                            }
                        ],
                        //Set column definition initialisation properties.
                        "columnDefs": [{
                                "targets": [0], //first column / numbering column
                                "orderable": false, //set not orderable
                            },
                        ],
                        "aLengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    });
                    var colvis = new $.fn.dataTable.ColVis(table); //initial colvis
                    $('#colvis').html(colvis.button()); //add colvis button to div with id="colvis"
                    $('#btn-filter').click(function () { //button filter event click
                        table.ajax.reload();  //just reload table
                    });
                    $('#btn-reset').click(function () { //button reset event click
                        $('#form-filter')[0].reset();
                        table.ajax.reload();  //just reload table
                    });
                });
				
				
				
            </script>
<script src="../assets/vendor/summernote/dist/summernote.js"></script>


            </body>

            <style>
                /* Extra small devices (phones, 600px and down) */
                @media only screen and (max-width: 600px) {
                    .modal-dialog {
                        max-width: 800px!important;
                    }
                }

                /* Small devices (portrait tablets and large phones, 600px and up) */
                @media only screen and (min-width: 600px) {
                    .modal-dialog {
                        max-width: 800px!important;
                    }
                }

                /* Medium devices (landscape tablets, 768px and up) */
                @media only screen and (min-width: 768px) {
                    .modal-dialog {
                        max-width: 800px!important;
                    }
                }

                /* Large devices (laptops/desktops, 992px and up) */
                @media only screen and (min-width: 992px) {
                    .modal-dialog {
                        max-width: 800px!important;
                    }
                }

                /* Extra large devices (large laptops and desktops, 1200px and up) */
                @media only screen and (min-width: 1200px) {
                    .modal-dialog {
                        max-width: 800px!important;
                    }
                } 
            </style>
